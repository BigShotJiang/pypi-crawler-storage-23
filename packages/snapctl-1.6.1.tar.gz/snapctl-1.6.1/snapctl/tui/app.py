from __future__ import annotations

import asyncio
import json
import shlex
import os
import signal
import errno
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

import click
import typer
import re
import subprocess
import sys
from rich.ansi import AnsiDecoder
from rich.text import Text
from platformdirs import user_data_dir
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, ScrollableContainer
from textual.widgets import Button, Footer, Header, Input, Label, ListItem, ListView, RichLog, Static, Select
from snapctl.commands.application import Application
from snapctl.commands.byosnap import ByoSnap
from snapctl.commands.byogs import ByoGs
from snapctl.commands.game import Game
from snapctl.commands.generate import Generate
from snapctl.commands.snapend import Snapend
from snapctl.commands.byows import Byows
from snapctl.commands.snaps import Snaps
from snapctl.commands.snapend_manifest import SnapendManifest
from snapctl.commands.release_notes import ReleaseNotes

# Special imports for Windows
IS_WINDOWS = sys.platform.startswith("win")
if not IS_WINDOWS:
    import pty
    import fcntl

APP_NAME = "snapctl"


@dataclass
class RunRecord:
    ts_iso: str
    argv: list[str]        # e.g. ["release-notes", "releases"]
    exit_code: int


def _history_path() -> Path:
    d = Path(user_data_dir(APP_NAME))
    d.mkdir(parents=True, exist_ok=True)
    return d / "history.jsonl"


def append_history(rec: RunRecord) -> None:
    p = _history_path()
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(rec)) + "\n")


def load_history(limit: int = 200) -> list[RunRecord]:
    p = _history_path()
    if not p.exists():
        return []
    out: list[RunRecord] = []
    with p.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                out.append(RunRecord(**d))
            except Exception:
                continue
    return out[-limit:]


def clear_history() -> None:
    p = _history_path()
    if p.exists():
        p.unlink()


TOP_LEVEL_COMMANDS = [
    "validate",
    "release-notes",
    "byogs",
    "byosnap",
    "game",
    "application",
    "generate",
    "snapend",
    "byows",
    "snaps",
    "snapend-manifest",
]

COMMAND_SUBCOMMANDS: dict[str, list[str]] = {
    "application": Application.SUBCOMMANDS,
    "byogs": ByoGs.SUBCOMMANDS,
    "byosnap": ByoSnap.SUBCOMMANDS,
    "byows": Byows.SUBCOMMANDS,
    "game": Game.SUBCOMMANDS,
    "generate": Generate.SUBCOMMANDS,
    "release-notes": ReleaseNotes.SUBCOMMANDS,
    "snapend-manifest": SnapendManifest.SUBCOMMANDS,
    "snapend": Snapend.SUBCOMMANDS,
    "snaps": Snaps.SUBCOMMANDS,
}


def run_tui(typer_app: typer.Typer) -> None:
    click_app = typer.main.get_command(typer_app)  # Click Group/Command
    SnapserCLI(click_app=click_app).run()


class SnapserCLI(App):
    CSS = """
    #root { height: 1fr; }

    #row1 { height: 1fr; }
    #row2 { height: 1fr; }

    /* Left column width (22%) */
    #commands_pane { width: 22%; border: solid $accent; padding-left: 1; padding-right: 1; }
    #history_pane  { width: 22%; border: solid $accent; padding-left: 1; padding-right: 1; height: auto; }

    /* Right column width (78%) */
    #runner_pane { width: 78%; border: solid $accent; padding-left: 1; padding-right: 1; layout: vertical; }
    #logs_pane   { width: 78%; border: solid $accent; padding-left: 1; padding-right: 1; layout: vertical; }

    /* Lists fill their panes */
    #cmd_list { height: 1fr; }
    #history  { height: 1fr; }

    /* Runner: keep it compact + predictable */
    #cmd_preview { height: 6; }     /* prevents runner bloat */
    #subcmd_select { height: 3; }
    #run_row { height: 3; }
    #args_input { height: 3; }      /* Textual Input likes 3 */

    /* Logs */
    #output_header { height: 3; }
    #output { height: 1fr; }

    /* Optional: reduce padding bloat */
    Label { margin: 0; padding: 0; }
    Button {
        height: 3;
        padding: 0 1;
        min-width: 6;
    }
    #commands_label, #runner_label, #history_label, #output_label {
        color: cyan;
    }
    #actions_label { color: gray; padding-left: 2; padding-right: 2; padding-top: 1; }
    #runner_btns { border: solid gray; }
    #subcmd_select.disabled {
        opacity: 60%;
        text-style: italic;
    }
    """

    def __init__(self, click_app: click.BaseCommand) -> None:
        super().__init__()
        self.click_app = click_app
        self.selected_top: str = TOP_LEVEL_COMMANDS[0]
        self._is_running: bool = False
        self._history_cache: list[RunRecord] = []
        self._running_proc = None

    # Matches CSI sequences like ESC [ ... letter
    _CSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

    def _sanitize_ansi(self, s: str) -> str:
        """
        Keep only SGR color/style sequences (ending in 'm').
        Strip cursor movement/show/hide/etc that produce gibberish in logs.
        """
        def repl(m: re.Match) -> str:
            seq = m.group(0)
            return seq if seq.endswith("m") else ""
        return self._CSI_RE.sub(repl, s)

    def _strip_all_ansi(self, s: str) -> str:
        """Strip all ANSI CSI sequences (for copy buffer)."""
        return self._CSI_RE.sub("", s)

    def _write_ansi(self, s: str) -> None:
        if not hasattr(self, "_ansi_decoder"):
            self._ansi_decoder = AnsiDecoder()
        if not hasattr(self, "_plain_buffer"):
            self._plain_buffer = ""

        s = s.replace("\r", "")
        s = self._sanitize_ansi(s)

        # Save plain text for copy
        self._plain_buffer += self._strip_all_ansi(s)

        # Decode ANSI -> Rich Text and write exactly what’s produced
        for segment in self._ansi_decoder.decode(s):
            self.output_log.write(segment)

    def _out(self, text: str) -> None:
        """Write a line of output to the output pane (Log/RichLog compatible)."""
        # RichLog uses .write(), not .write_line()
        # Ensure we keep line breaks consistent.
        if not text.endswith("\n"):
            text += "\n"
        self.output_log.write(text)
    

    async def _run_in_pty(self, argv: list[str]) -> int:
        """
        Run `snapctl ...` under a pseudo-terminal and stream all output (incl docker).
        Returns exit code.
        """
        master_fd, slave_fd = pty.openpty()

        # Make master non-blocking
        flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
        fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

        env = os.environ.copy()
        env["SNAPCTL_TUI"] = "1"
        env["PYTHONUNBUFFERED"] = "1"

        proc = await asyncio.create_subprocess_exec(
            "snapctl", *argv,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            env=env,
            start_new_session=True,
        )
        self._running_proc = proc
        os.close(slave_fd)

        loop = asyncio.get_running_loop()
        # done = asyncio.Event()
        buffer = ""

        def _drain_pty() -> None:
            nonlocal buffer
            try:
                while True:
                    try:
                        data = os.read(master_fd, 4096)
                    except BlockingIOError:
                        break
                    except OSError as e:
                        if e.errno in (errno.EIO, errno.EBADF):
                            # PTY closed
                            break
                        raise

                    if not data:
                        break

                    text = data.decode(errors="replace")

                    # Normalize carriage returns; progress spinners use them
                    text = text.replace("\r", "")

                    buffer += text
                    # Emit full lines, keep partial line in buffer
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        self._write_ansi(line + "\n")
            finally:
                # Keep UI responsive by returning quickly
                pass

        # Register file-descriptor reader callback
        loop.add_reader(master_fd, _drain_pty)

        try:
            exit_code = await proc.wait()
            # After process ends, drain whatever is left
            _drain_pty()
            if buffer.strip():
                self._write_ansi(buffer)
            return exit_code
        finally:
            try:
                loop.remove_reader(master_fd)
            except Exception:
                pass
            try:
                os.close(master_fd)
            except OSError:
                pass
            self._running_proc = None

    async def _run_without_pty(self, argv: list[str]) -> int:
        env = os.environ.copy()
        env["SNAPCTL_TUI"] = "1"
        env["PYTHONUNBUFFERED"] = "1"

        proc = await asyncio.create_subprocess_exec(
            # "snapctl", *argv,
            sys.executable, '-m', 'snapctl', *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            env=env,
        )
        self._running_proc = proc

        try:
            while True:
                line = await proc.stdout.readline()
                if not line:
                    break
                self._write_ansi(line.decode(errors="replace"))
            return await proc.wait()
        finally:
            self._running_proc = None
    
    async def _run_command(self, argv: list[str]) -> int:
        if IS_WINDOWS:
            return await self._run_without_pty(argv)
        else:
            return await self._run_in_pty(argv)


    def _get_subcommand(self) -> str:
        """Return selected subcommand or '' if none/blank."""
        val = getattr(self.subcmd_select, "value", "")
        if val is None:
            return ""

        s = str(val).strip()

        # 1) your existing cross-version Blank handling
        if not s or "select.blank" in s.lower() or s.lower() == "select.blank":
            return ""

        # 2) placeholder sentinel when no subcommands exist
        if s == "__none__":
            return ""

        return s

    def compose(self) -> ComposeResult:
        yield Header()

        with Vertical(id="root"):

            # ===== Row 1 =====
            with Horizontal(id="row1"):
                # Commands (left)
                with Vertical(id="commands_pane"):
                    yield Label("Commands", id="commands_label")
                    self.cmd_list = ListView(id="cmd_list")
                    yield self.cmd_list

                # Runner (right)
                with Vertical(id="runner_pane"):
                    yield Label("Runner", id="runner_label")

                    self.preview = Static("", id="cmd_preview")
                    yield self.preview

                    self.subcmd_select = Select(
                        [], prompt="Subcommand", id="subcmd_select")
                    yield self.subcmd_select

                    with Horizontal(id="run_row"):
                        self.args_input = Input(
                            placeholder="--options (or use -h for help). Enter to run.",
                            id="args_input",
                        )
                        yield self.args_input
                    with Horizontal(id="runner_btns"):
                        yield Label("Actions", id="actions_label")
                        yield Button("Run Command", id="run_btn", variant="success")
                        yield Button("Stop Command", id="stop_btn", variant="error")
                        yield Button("Copy Output", id="copy_btn", variant="primary")
                        yield Button("Refresh History", id="hist_refresh_btn")
                        yield Button("Clear History", id="hist_clear_btn", variant="warning")

            # ===== Row 2 =====
            with Horizontal(id="row2"):
                # History (left)
                with Vertical(id="history_pane"):
                    yield Label("History (latest first)", id="history_label")
                    self.hist_list = ListView(id="history")
                    yield self.hist_list
                    # with Horizontal(id="history_controls"):
                    #     yield Button("Refresh", id="hist_refresh_btn")
                    #     yield Button("Clear", id="hist_clear_btn", variant="warning")

                # Logs (right)
                with Vertical(id="logs_pane"):
                    yield Label("Output", id="output_label")
                    # with Horizontal(id="output_header"):
                    #     yield Label("Output", id="output_label")
                    # yield Button("Copy", id="copy_btn")

                    self.output_log = RichLog(
                        id="output", highlight=True, markup=True)
                    yield self.output_log

        yield Footer()

    def _refresh_subcommands(self) -> None:
        subs = COMMAND_SUBCOMMANDS.get(self.selected_top, [])

        if subs:
            options = [(s, s) for s in subs]
            self.subcmd_select.set_options(options)

            # keep current if valid else default first
            if self.subcmd_select.value not in subs:
                self.subcmd_select.value = subs[0]

            # enable
            self.subcmd_select.disabled = False  # Textual >= 0.40ish
            self.subcmd_select.can_focus = True
            self.subcmd_select.add_class("enabled")
            self.subcmd_select.remove_class("disabled")

        else:
            # show a placeholder option, but prevent using it
            self.subcmd_select.set_options(
                [("— no subcommands —", "__none__")])
            self.subcmd_select.value = "__none__"

            # disable (non-interactive)
            try:
                self.subcmd_select.disabled = True
            except Exception:
                pass
            self.subcmd_select.can_focus = False
            self.subcmd_select.add_class("disabled")
            self.subcmd_select.remove_class("enabled")

    def on_mount(self) -> None:
        self.cmd_list.clear()
        for c in TOP_LEVEL_COMMANDS:
            self.cmd_list.append(ListItem(Label(c)))
        self.cmd_list.index = 0
        self._load_history()
        self._refresh_subcommands()
        self._update_preview()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if event.list_view is self.cmd_list:
            idx = self.cmd_list.index or 0
            self.selected_top = TOP_LEVEL_COMMANDS[idx]
            # 🔹 CLEAR OPTIONS WHEN COMMAND CHANGES
            self.args_input.value = ""
            self._refresh_subcommands()
            self._update_preview()
            return

        if event.list_view is self.hist_list:
            idx = self.hist_list.index
            if idx is None or idx >= len(self._history_cache):
                return

            rec = self._history_cache[idx]
            if not rec.argv:
                return

            self.selected_top = rec.argv[0]
            try:
                self.cmd_list.index = TOP_LEVEL_COMMANDS.index(
                    self.selected_top)
            except ValueError:
                pass

            self._refresh_subcommands()

            rest = rec.argv[1:]
            subs = COMMAND_SUBCOMMANDS.get(self.selected_top, [])
            if rest and subs and rest[0] in subs:
                self.subcmd_select.value = rest[0]
                rest = rest[1:]
            else:
                # no subcommand stored / not applicable
                if subs:
                    self.subcmd_select.value = subs[0]

            self.args_input.value = " ".join(shlex.quote(x) for x in rest)
            self._update_preview()

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select is self.subcmd_select:
            if self.subcmd_select.value == "__none__":
                return
            self._update_preview()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input is self.args_input:
            self._update_preview()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input is self.args_input:
            await self._run()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "run_btn":
            await self._run()
            return

        if event.button.id == "hist_refresh_btn":
            self._load_history()
            return

        if event.button.id == "hist_clear_btn":
            clear_history()
            self._load_history()
            self._out("🧹 History cleared.")
            return

        if event.button.id == "stop_btn":
            if self._running_proc and self._running_proc.returncode is None:
                try:
                    os.killpg(self._running_proc.pid, signal.SIGINT)
                    self._out("… sent SIGINT …")
                except Exception as e:
                    self._out(f"❌ Stop failed: {e!r}")
            return

        if event.button.id == "copy_btn":
            text = getattr(self, "_plain_buffer", "")
            try:
                subprocess.run(
                    ["pbcopy"], input=text.encode("utf-8"), check=True)
                self._out("✅ Copied output to clipboard.")
            except Exception as e:
                self._out(f"❌ Copy failed: {e!r}")
            return

    def _update_preview(self) -> None:
        args = self.args_input.value.strip()
        pieces = ["snapctl", self.selected_top]

        sub = self._get_subcommand()
        if sub:
            pieces.append(sub)

        if args:
            pieces.append(args)

        self.preview.update("Command:\n$ " + " ".join(pieces))

    def _fmt_ts_local(self, ts_iso: str) -> str:
        """Return 'mm/dd hh:mm' in local time from an ISO-8601 timestamp."""
        try:
            dt = datetime.fromisoformat(ts_iso.replace("Z", "+00:00"))
            return dt.astimezone().strftime("%m/%d %H:%M")
        except Exception:
            return "??/?? ??:??"

    def _split_cmd(self, argv: list[str]) -> tuple[str, str, list[str]]:
        """
        Return (cmd, subcmd, rest_args).
        Subcmd is only recognized if it matches your COMMAND_SUBCOMMANDS map.
        """
        if not argv:
            return "", "", []

        cmd = argv[0]
        subs = COMMAND_SUBCOMMANDS.get(cmd, [])
        if len(argv) >= 2 and argv[1] in subs:
            return cmd, argv[1], argv[2:]

        return cmd, "", argv[1:]

    def _load_history(self) -> None:
        hist = load_history(limit=200)
        hist = list(reversed(hist))  # newest first
        self._history_cache = hist

        self.hist_list.clear()
        for rec in hist:
            cmd, sub, rest = self._split_cmd(rec.argv)

            # Left side: "command subcommand" (compact)
            left = cmd
            if sub:
                left += f" {sub}"

            # Optional: include a SHORT args preview (comment out if you don't want it)
            args_preview = " ".join(rest)
            if len(args_preview) > 18:
                args_preview = args_preview[:18] + "…"
            if args_preview:
                left = f"{left} {args_preview}"

            # Right side: local time mm/dd hh:mm
            ts = self._fmt_ts_local(rec.ts_iso)

            # Final label: "<cmd subcmd args>  mm/dd hh:mm  [exit]"
            label = f"{ts} {left:<22}  [{rec.exit_code}]"
            self.hist_list.append(ListItem(Label(label)))

    async def _run(self) -> None:
        if self._is_running:
            self._out("⚠️ Already running.")
            return

        raw_args = self.args_input.value.strip()
        extra = shlex.split(raw_args) if raw_args else []
        argv = [self.selected_top]

        sub = self._get_subcommand()  # use your blank-normalizer helper
        if sub:
            argv.append(sub)

        argv.extend(extra)

        self.output_log.clear()
        self._plain_buffer = ""
        self._out(
            f"$ snapctl {' '.join(shlex.quote(x) for x in argv)}")

        self._is_running = True
        try:
            exit_code = await self._run_command(argv)
        finally:
            self._is_running = False

        self._out(f"— exit {exit_code} —")

        append_history(
            RunRecord(
                ts_iso=datetime.now(timezone.utc).isoformat(),
                argv=argv,
                exit_code=exit_code,
            )
        )
        self._load_history()

    # def _invoke_click(self, argv: list[str]):
    #     runner = CliRunner()
    #     return runner.invoke(
    #         self.click_app,
    #         argv,
    #         prog_name="snapctl",
    #         catch_exceptions=True,
    #     )
