#!/usr/bin/env python3
"""Main entry point for fancy_tree."""

if __name__ == "__main__":
    from cli import app
    app()