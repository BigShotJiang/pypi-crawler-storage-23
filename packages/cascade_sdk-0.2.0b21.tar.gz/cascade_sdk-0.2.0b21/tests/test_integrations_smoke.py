import pytest


def test_instrument_langgraph_smoke(monkeypatch):
    import cascade.integrations.langgraph as mod

    monkeypatch.setattr(mod, "_instrumented", False)
    try:
        mod.instrument_langgraph()
    except ImportError:
        pytest.skip("langgraph/langchain-core not installed")
    # Idempotency path
    mod.instrument_langgraph()
    assert mod._instrumented is True


def test_instrument_openai_agents_smoke(monkeypatch):
    import cascade.integrations.openai_agents as mod

    monkeypatch.setattr(mod, "_instrumented", False)
    try:
        mod.instrument_openai_agents()
    except ImportError:
        pytest.skip("openai-agents not installed")
    mod.instrument_openai_agents()
    assert mod._instrumented is True


def test_instrument_claude_agents_smoke(monkeypatch):
    import cascade.integrations.claude_agents as mod

    monkeypatch.setattr(mod, "_instrumented", False)
    try:
        with pytest.warns(DeprecationWarning, match="wrap_claude_query"):
            mod.instrument_claude_agents()
    except ImportError:
        pytest.skip("claude-agent-sdk not installed")
    assert mod._instrumented is True


def test_wrap_claude_query_returns_callable():
    from cascade.integrations.claude_agents import wrap_claude_query

    async def fake_query(*, prompt, options=None):
        yield {"type": "result"}

    traced = wrap_claude_query(fake_query, name="TestSession")
    assert callable(traced)


def test_traced_claude_client_is_importable():
    from cascade.integrations.claude_agents import TracedClaudeClient

    assert TracedClaudeClient is not None

