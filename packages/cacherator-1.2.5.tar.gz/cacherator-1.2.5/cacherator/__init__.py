from .cacherator import JSONCache, Cached

__version__ = "1.2.5"
__all__ = ["JSONCache", "Cached"]