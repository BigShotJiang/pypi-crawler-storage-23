"""Tests for merlya.fingerprint module."""
