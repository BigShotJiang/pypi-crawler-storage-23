"""Tests for provisioners providers module."""
