"""Tests for merlya.pipelines module."""
