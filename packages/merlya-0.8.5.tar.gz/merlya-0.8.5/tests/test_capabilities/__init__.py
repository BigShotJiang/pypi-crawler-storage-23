"""Tests for the capabilities module."""
