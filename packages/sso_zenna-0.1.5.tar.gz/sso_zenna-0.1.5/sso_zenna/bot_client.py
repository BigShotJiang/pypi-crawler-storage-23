"""Клиент для бота: создание пользователей и сессий Telegram ACTUALY DEPRACTED"""

from typing import Optional

from .base import BaseClient
from .models import TelegramSessionResponse, UserInfo, ProfileInfo


class BotClient(BaseClient):
    """
    Клиент для внутренних вызовов от бота.
    Требует X-Bot-Service-Key для аутентификации.
    """

    def __init__(
        self,
        base_url: str,
        bot_service_key: str,
        api_version: str = "v1",
        timeout: int = 30,
        session=None,
    ):
        super().__init__(base_url, api_version, timeout, session, auto_refresh_token=False)
        self.bot_service_key = bot_service_key

    def _get_headers(self, access_token: Optional[str] = None):
        """Заголовки с X-Bot-Service-Key"""
        headers = {"Content-Type": "application/json", "X-Bot-Service-Key": self.bot_service_key}
        return headers

    async def _refresh_token(self) -> None:
        """BotClient не поддерживает refresh"""
        raise NotImplementedError("BotClient не использует токены")

    def _get_access_token(self) -> Optional[str]:
        return None

    async def create_telegram_user(
        self,
        id: int,
        tz: int = 3,
        phone: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Optional[UserInfo]:
        """
        Создать или получить пользователя по Telegram ID.

        Returns:
            UserInfo или None при ошибке
        """
        payload = {"id": id, "tz": tz}
        if phone is not None:
            payload["phone"] = phone
        if name is not None:
            payload["name"] = name
        try:
            data = await self.post("users/telegram", json_data=payload)
            return UserInfo(**data)
        except Exception:
            return None

    async def create_telegram_session(self, user_id: int) -> Optional[TelegramSessionResponse]:
        """
        Создать сессию для web-авторизации.
        Возвращает session_token и auth_url для кнопки «Авторизоваться».

        Returns:
            TelegramSessionResponse или None при ошибке
        """
        try:
            data = await self.post(
                "auth/telegram-session",
                params={"user_id": user_id},
            )
            return TelegramSessionResponse(**data)
        except Exception:
            return None

    async def update_user(
        self,
        user_id: int,
        *,
        phone: Optional[str] = None,
        name: Optional[str] = None,
        last_seen: Optional[str] = None,
    ) -> Optional[UserInfo]:
        """Обновить telegram-пользователя (PATCH users/{user_id}). last_seen — ISO строка."""
        payload = {}
        if phone is not None:
            payload["phone"] = phone
        if name is not None:
            payload["name"] = name
        if last_seen is not None:
            payload["last_seen"] = last_seen
        if not payload:
            return None
        try:
            data = await self.patch(f"users/{user_id}", json_data=payload)
            return UserInfo(**data)
        except Exception:
            return None

    async def get_profile(self, user_id: int) -> Optional[ProfileInfo]:
        """
        Получить профиль пользователя по user_id (Telegram id).

        Returns:
            ProfileInfo или None при ошибке/404
        """
        try:
            data = await self.get(f"profiles/{user_id}")
            return ProfileInfo(**data)
        except Exception:
            return None

    async def update_profile(
        self,
        user_id: int,
        *,
        lang: Optional[str] = None,
        name: Optional[str] = None,
        notify_telegram: Optional[bool] = None,
        notify_email: Optional[bool] = None,
        about: Optional[str] = None,
        age: Optional[str] = None,
        weight: Optional[float] = None,
        height: Optional[float] = None,
    ) -> Optional[ProfileInfo]:
        """
        Обновить профиль (PATCH). Передавать только изменяемые поля.
        SSO принимает form-data.

        Returns:
            ProfileInfo или None при ошибке
        """
        form_data = {}
        if lang is not None:
            form_data["lang"] = lang
        if name is not None:
            form_data["name"] = name
        if notify_telegram is not None:
            form_data["notify_telegram"] = "true" if notify_telegram else "false"
        if notify_email is not None:
            form_data["notify_email"] = "true" if notify_email else "false"
        if about is not None:
            form_data["about"] = about
        if age is not None:
            form_data["age"] = age
        if weight is not None:
            form_data["weight"] = str(weight)
        if height is not None:
            form_data["height"] = str(height)
        if not form_data:
            return await self.get_profile(user_id)
        try:
            data = await self.patch(f"profiles/{user_id}", form_data=form_data)
            return ProfileInfo(**data)
        except Exception:
            return None
