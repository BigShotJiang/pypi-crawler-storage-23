"""
SSO Zenna Client - Python клиент для взаимодействия с zenna-sso API

- UserClient: OAuth 2.0 с PKCE (login/password, /me, refresh)
- ServiceClient: Client Credentials для микросервисов
- BotClient: создание пользователей и сессий Telegram (X-Bot-Service-Key)
- verify_sso_jwt_and_get_user_id: проверка JWT (RS256) для микросервисов
"""

from .user_client import UserClient
from .service_client import ServiceClient
from .bot_client import BotClient
from .bot_service_client import BotServiceClient
from .jwt_verify import verify_sso_jwt_and_get_user_id
from .models import (
    UserInfo,
    TokenResponse,
    PKCEParams,
    TelegramSessionResponse,
    TelegramUserCreate,
)
from .exceptions import (
    SSOClientError,
    AuthenticationError,
    AuthorizationError,
    APIError,
    TokenError,
)

__all__ = [
    "UserClient",
    "ServiceClient",
    "BotClient",
    "BotServiceClient",
    "verify_sso_jwt_and_get_user_id",
    "UserInfo",
    "TokenResponse",
    "PKCEParams",
    "TelegramSessionResponse",
    "TelegramUserCreate",
    "SSOClientError",
    "AuthenticationError",
    "AuthorizationError",
    "APIError",
    "TokenError",
]

__version__ = "0.1.0"

