"""Клиент бота через OAuth2 client_credentials (client_id + client_secret)."""

from typing import Optional

from .service_client import ServiceClient
from .models import TelegramSessionResponse, UserInfo, ProfileInfo


class BotServiceClient(ServiceClient):
    """
    Клиент для бота: те же методы, что у BotClient, но аутентификация через
    client_credentials (client_id + client_secret). Единообразие с остальными микросервисами.
    """

    async def _ensure_token(self) -> None:
        if not self._access_token:
            await self.get_access_token()

    async def create_telegram_user(
        self,
        id: int,
        tz: int = 3,
        phone: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Optional[UserInfo]:
        """Создать или получить пользователя по Telegram ID."""
        await self._ensure_token()
        payload = {"id": id, "tz": tz}
        if phone is not None:
            payload["phone"] = phone
        if name is not None:
            payload["name"] = name
        try:
            data = await self.post(
                "users/telegram",
                json_data=payload,
                access_token=self._access_token,
            )
            return UserInfo(**data)
        except Exception:
            return None

    async def create_telegram_session(self, user_id: int) -> Optional[TelegramSessionResponse]:
        """Создать сессию для web-авторизации. Возвращает session_token и auth_url."""
        await self._ensure_token()
        try:
            data = await self.post(
                "auth/telegram-session",
                params={"user_id": user_id},
                access_token=self._access_token,
            )
            return TelegramSessionResponse(**data)
        except Exception:
            return None

    async def update_user(
        self,
        user_id: int,
        *,
        phone: Optional[str] = None,
        name: Optional[str] = None,
        last_seen: Optional[str] = None,
    ) -> Optional[UserInfo]:
        """Обновить telegram-пользователя (PATCH users/{user_id})."""
        payload = {}
        if phone is not None:
            payload["phone"] = phone
        if name is not None:
            payload["name"] = name
        if last_seen is not None:
            payload["last_seen"] = last_seen
        if not payload:
            return None
        await self._ensure_token()
        try:
            data = await self.patch(
                f"users/{user_id}",
                json_data=payload,
                access_token=self._access_token,
            )
            return UserInfo(**data)
        except Exception:
            return None

    async def get_profile(self, user_id: int) -> Optional[ProfileInfo]:
        """Получить профиль по user_id (Telegram id)."""
        await self._ensure_token()
        try:
            data = await self.get(
                f"profiles/{user_id}",
                access_token=self._access_token,
            )
            return ProfileInfo(**data)
        except Exception:
            return None

    async def update_profile(
        self,
        user_id: int,
        *,
        lang: Optional[str] = None,
        name: Optional[str] = None,
        notify_telegram: Optional[bool] = None,
        notify_email: Optional[bool] = None,
        about: Optional[str] = None,
        age: Optional[str] = None,
        weight: Optional[float] = None,
        height: Optional[float] = None,
    ) -> Optional[ProfileInfo]:
        """Обновить профиль (PATCH). Передавать только изменяемые поля."""
        form_data = {}
        if lang is not None:
            form_data["lang"] = lang
        if name is not None:
            form_data["name"] = name
        if notify_telegram is not None:
            form_data["notify_telegram"] = "true" if notify_telegram else "false"
        if notify_email is not None:
            form_data["notify_email"] = "true" if notify_email else "false"
        if about is not None:
            form_data["about"] = about
        if age is not None:
            form_data["age"] = age
        if weight is not None:
            form_data["weight"] = str(weight)
        if height is not None:
            form_data["height"] = str(height)
        if not form_data:
            return await self.get_profile(user_id)
        await self._ensure_token()
        try:
            data = await self.patch(
                f"profiles/{user_id}",
                form_data=form_data,
                access_token=self._access_token,
            )
            return ProfileInfo(**data)
        except Exception:
            return None
