
@.pearls/CLAUDE.md

Use the ./output folder here to make test images and as an output location for all test images.
