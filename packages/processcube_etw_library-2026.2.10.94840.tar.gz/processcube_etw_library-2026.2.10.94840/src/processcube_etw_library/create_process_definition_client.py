from .processcube_client.process_definition import ProcessDefinitionClient

from .identity_provider import IdentityProvider
from .settings import load_settings


def create_process_definition_client() -> ProcessDefinitionClient:
    settings = load_settings()
    authority_url = settings.processcube_authority_url
    engine_url = settings.processcube_engine_url
    client_name = settings.processcube_etw_client_id
    client_secret = settings.processcube_etw_client_secret
    client_scopes = settings.processcube_etw_client_scopes
    max_get_oauth_access_token_retries = (
        settings.processcube_max_get_oauth_access_token_retries
    )

    # TODO: Don't use the ETW client credentials for the Process Definition Client. Create separate credentials for the Process Definition Client and use those here.
    identity_provider = IdentityProvider(
        authority_url,
        client_name,
        client_secret,
        client_scopes,
        max_get_oauth_access_token_retries,
    )
    client = ProcessDefinitionClient(
        engine_url,
        identity=identity_provider,
    )

    return client
