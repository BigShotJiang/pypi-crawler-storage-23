# systemd user service integration (Linux)
