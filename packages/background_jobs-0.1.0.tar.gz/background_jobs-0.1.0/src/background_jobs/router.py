"""FastAPI router exposing job queue management endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from .models import JobInfo, JobStatus, ScheduledJob
from .queue import (
    cancel_job,
    get_dead_letter_jobs,
    get_job,
    get_queue_length,
    list_jobs,
    retry_dead_job,
)
from .scheduler import get_scheduled_jobs
from errors import AuthorizationError, BusinessLogicError, ConflictError, NotFoundError, ValidationError
from api_core.responses import ApiResponse, PaginatedResponse

router = APIRouter(prefix="/jobs", tags=["jobs"])


@router.get("", response_model=list[JobInfo])
async def list_recent_jobs(
    status: JobStatus | None = Query(None, description="Filter by job status"),
    limit: int = Query(50, ge=1, le=500, description="Maximum number of jobs to return"),
) -> list[JobInfo]:
    """List recent jobs, optionally filtered by status."""
    return await list_jobs(status=status, limit=limit)


@router.get("/queues")
async def queue_lengths(
    queues: str = Query("default", description="Comma-separated queue names"),
) -> dict[str, int]:
    """Return the current length of one or more queues."""
    names = [q.strip() for q in queues.split(",") if q.strip()]
    result: dict[str, int] = {}
    for name in names:
        result[name] = await get_queue_length(name)
    return result


@router.get("/dead-letter", response_model=list[JobInfo])
async def dead_letter_jobs(
    limit: int = Query(50, ge=1, le=500),
) -> list[JobInfo]:
    """List jobs in the dead-letter queue."""
    return await get_dead_letter_jobs(limit=limit)


@router.get("/scheduled", response_model=list[ScheduledJob])
async def scheduled_jobs() -> list[ScheduledJob]:
    """List all registered cron schedules."""
    return await get_scheduled_jobs()


@router.get("/{job_id}", response_model=JobInfo)
async def job_detail(job_id: str) -> JobInfo:
    """Get full details of a single job."""
    info = await get_job(job_id)
    if info is None:
        raise NotFoundError("Job not found")
    return info


@router.post("/{job_id}/cancel")
async def cancel(job_id: str) -> dict[str, bool]:
    """Cancel a pending job."""
    success = await cancel_job(job_id)
    if not success:
        raise ConflictError("Job cannot be cancelled (not found or already running)",
        )
    return {"cancelled": True}


@router.post("/dead-letter/{job_id}/retry")
async def retry_dead(job_id: str) -> dict[str, str]:
    """Re-enqueue a dead-letter job as a fresh attempt."""
    try:
        new_id = await retry_dead_job(job_id)
    except ValueError as exc:
        raise NotFoundError(str(exc))
    return {"new_job_id": new_id}
