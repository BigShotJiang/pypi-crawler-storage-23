"""Data models for jobs, statuses, and scheduled tasks."""

from __future__ import annotations

import enum
from datetime import datetime, timezone
from uuid import uuid4

from pydantic import BaseModel, Field


class JobStatus(str, enum.Enum):
    """Lifecycle status of a job."""

    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    dead = "dead"


class JobInfo(BaseModel):
    """Full state of a single job."""

    id: str = Field(default_factory=lambda: uuid4().hex)
    name: str
    args: dict = Field(default_factory=dict)
    status: JobStatus = JobStatus.pending
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None
    retries: int = 0
    max_retries: int = 3
    queue: str = "default"


class ScheduledJob(BaseModel):
    """A cron-based recurring job definition."""

    id: str = Field(default_factory=lambda: uuid4().hex)
    name: str
    job_name: str
    cron_expression: str
    args: dict = Field(default_factory=dict)
    next_run_at: datetime | None = None
    enabled: bool = True
