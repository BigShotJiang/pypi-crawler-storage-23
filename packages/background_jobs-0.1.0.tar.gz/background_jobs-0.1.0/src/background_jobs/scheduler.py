"""Cron-based job scheduling backed by Redis."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from uuid import uuid4

from croniter import croniter

from .config import get_redis
from .models import ScheduledJob

logger = logging.getLogger("background_jobs.scheduler")

SCHEDULES_KEY = "wj:schedules"


def _next_run(cron_expression: str) -> datetime:
    """Calculate the next UTC run time for a cron expression."""
    now = datetime.now(timezone.utc)
    cron = croniter(cron_expression, now)
    return cron.get_next(datetime).replace(tzinfo=timezone.utc)


async def schedule(
    name: str,
    cron: str,
    job_name: str,
    args: dict | None = None,
) -> ScheduledJob:
    """Register a cron-based recurring job.

    Args:
        name: Unique schedule name (e.g. "nightly-cleanup").
        cron: Cron expression (e.g. "0 2 * * *").
        job_name: Name of a registered job handler to invoke.
        args: Arguments passed to the job handler.

    Returns:
        The created ScheduledJob.
    """
    if not croniter.is_valid(cron):
        raise ValueError(f"Invalid cron expression: '{cron}'")

    r = get_redis()

    sj = ScheduledJob(
        id=uuid4().hex,
        name=name,
        job_name=job_name,
        cron_expression=cron,
        args=args or {},
        next_run_at=_next_run(cron),
        enabled=True,
    )

    await r.hset(SCHEDULES_KEY, name, sj.model_dump_json())
    logger.info("Schedule '%s' registered — cron=%s, job=%s", name, cron, job_name)
    return sj


async def get_scheduled_jobs() -> list[ScheduledJob]:
    """Return all registered schedules."""
    r = get_redis()
    raw_map = await r.hgetall(SCHEDULES_KEY)
    return [ScheduledJob.model_validate_json(v) for v in raw_map.values()]


async def get_schedule(name: str) -> ScheduledJob | None:
    """Fetch a single schedule by name."""
    r = get_redis()
    raw = await r.hget(SCHEDULES_KEY, name)
    if raw is None:
        return None
    return ScheduledJob.model_validate_json(raw)


async def remove_schedule(name: str) -> bool:
    """Delete a schedule by name. Returns True if it existed."""
    r = get_redis()
    removed = await r.hdel(SCHEDULES_KEY, name)
    if removed:
        logger.info("Schedule '%s' removed", name)
    return bool(removed)


async def enable_schedule(name: str) -> bool:
    """Enable a disabled schedule. Returns True if found and updated."""
    return await _set_enabled(name, True)


async def disable_schedule(name: str) -> bool:
    """Disable a schedule without removing it. Returns True if found and updated."""
    return await _set_enabled(name, False)


async def _set_enabled(name: str, enabled: bool) -> bool:
    r = get_redis()
    raw = await r.hget(SCHEDULES_KEY, name)
    if raw is None:
        return False

    sj = ScheduledJob.model_validate_json(raw)
    sj.enabled = enabled
    if enabled:
        sj.next_run_at = _next_run(sj.cron_expression)
    await r.hset(SCHEDULES_KEY, name, sj.model_dump_json())
    logger.info("Schedule '%s' %s", name, "enabled" if enabled else "disabled")
    return True


async def _process_scheduled_jobs() -> None:
    """Check all enabled schedules and enqueue jobs that are due.

    Called by the worker's scheduled loop. This import is deferred to avoid
    circular imports with queue.py.
    """
    from .queue import enqueue as enqueue_job

    r = get_redis()
    now = datetime.now(timezone.utc)
    raw_map = await r.hgetall(SCHEDULES_KEY)

    for schedule_name, raw in raw_map.items():
        sj = ScheduledJob.model_validate_json(raw)
        if not sj.enabled:
            continue
        if sj.next_run_at is None:
            continue
        if sj.next_run_at > now:
            continue

        # Due — enqueue and advance next_run_at
        job_id = await enqueue_job(sj.job_name, args=sj.args)
        logger.info(
            "Schedule '%s' fired — enqueued job %s (%s)",
            schedule_name,
            job_id,
            sj.job_name,
        )

        sj.next_run_at = _next_run(sj.cron_expression)
        await r.hset(SCHEDULES_KEY, schedule_name, sj.model_dump_json())
