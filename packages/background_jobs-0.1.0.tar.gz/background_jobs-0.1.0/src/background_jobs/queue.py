"""Queue operations: enqueue, inspect, cancel, and dead-letter management."""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from uuid import uuid4

from .config import get_config, get_redis
from .models import JobInfo, JobStatus
from .registry import get_job_meta

logger = logging.getLogger("background_jobs.queue")

# Redis key conventions
QUEUE_PREFIX = "wj:queue:"
JOB_PREFIX = "wj:job:"
DELAYED_KEY = "wj:delayed"
DEAD_LETTER_KEY = "wj:dead"


def _queue_key(queue: str | None = None) -> str:
    cfg = get_config()
    return f"{QUEUE_PREFIX}{queue or cfg.queue_name}"


def _job_key(job_id: str) -> str:
    return f"{JOB_PREFIX}{job_id}"


async def enqueue(
    job_name: str,
    args: dict | None = None,
    delay_seconds: int = 0,
    queue: str | None = None,
) -> str:
    """Push a job onto the queue for processing.

    Args:
        job_name: Name of a registered job handler.
        args: Keyword arguments to pass to the handler.
        delay_seconds: If > 0, delay execution by this many seconds.
        queue: Target queue name. Falls back to the job's registered queue,
               then to the global default.

    Returns:
        The job ID (hex UUID).
    """
    r = get_redis()
    cfg = get_config()

    # Resolve queue: explicit arg > job-level override > global default
    resolved_queue = queue
    if resolved_queue is None:
        try:
            meta = get_job_meta(job_name)
            resolved_queue = meta.get("queue")
        except KeyError:
            pass
    if resolved_queue is None:
        resolved_queue = cfg.queue_name

    # Resolve max_retries from job meta or global config
    max_retries = cfg.max_retries
    try:
        meta = get_job_meta(job_name)
        if meta.get("max_retries") is not None:
            max_retries = meta["max_retries"]
    except KeyError:
        pass

    job_info = JobInfo(
        id=uuid4().hex,
        name=job_name,
        args=args or {},
        status=JobStatus.pending,
        max_retries=max_retries,
        queue=resolved_queue,
    )

    payload = job_info.model_dump_json()

    # Persist job state
    await r.set(_job_key(job_info.id), payload)

    if delay_seconds > 0:
        run_at = time.time() + delay_seconds
        await r.zadd(DELAYED_KEY, {payload: run_at})
        logger.info("Job %s (%s) delayed by %ds", job_info.id, job_name, delay_seconds)
    else:
        await r.lpush(_queue_key(resolved_queue), payload)
        logger.info("Job %s (%s) enqueued on '%s'", job_info.id, job_name, resolved_queue)

    return job_info.id


async def get_job(job_id: str) -> JobInfo | None:
    """Fetch the current state of a job by ID."""
    r = get_redis()
    raw = await r.get(_job_key(job_id))
    if raw is None:
        return None
    return JobInfo.model_validate_json(raw)


async def cancel_job(job_id: str) -> bool:
    """Mark a pending job as failed (cancelled).

    Only jobs that have not started running can be cancelled. Returns True if
    the job was successfully cancelled.
    """
    r = get_redis()
    raw = await r.get(_job_key(job_id))
    if raw is None:
        return False

    job_info = JobInfo.model_validate_json(raw)
    if job_info.status != JobStatus.pending:
        return False

    job_info.status = JobStatus.failed
    job_info.error = "Cancelled by user"
    job_info.completed_at = datetime.now(timezone.utc)
    await r.set(_job_key(job_id), job_info.model_dump_json())

    # Remove from queue list (best-effort — may already have been popped)
    queue_payload = raw
    await r.lrem(_queue_key(job_info.queue), 1, queue_payload)

    # Also remove from delayed set if present
    await r.zrem(DELAYED_KEY, queue_payload)

    logger.info("Job %s cancelled", job_id)
    return True


async def get_queue_length(queue: str | None = None) -> int:
    """Return the number of jobs waiting in the given queue."""
    r = get_redis()
    return await r.llen(_queue_key(queue))


async def get_dead_letter_jobs(limit: int = 50) -> list[JobInfo]:
    """Return the most recent dead-letter jobs."""
    r = get_redis()
    raw_items = await r.lrange(DEAD_LETTER_KEY, 0, limit - 1)
    jobs: list[JobInfo] = []
    for raw in raw_items:
        jobs.append(JobInfo.model_validate_json(raw))
    return jobs


async def retry_dead_job(job_id: str) -> str:
    """Re-enqueue a dead-letter job as a fresh attempt.

    Returns:
        The new job ID.
    """
    r = get_redis()
    raw = await r.get(_job_key(job_id))
    if raw is None:
        raise ValueError(f"Job {job_id} not found")

    old_job = JobInfo.model_validate_json(raw)
    if old_job.status != JobStatus.dead:
        raise ValueError(f"Job {job_id} is not in dead-letter state (status={old_job.status})")

    new_id = await enqueue(old_job.name, args=old_job.args, queue=old_job.queue)
    logger.info("Dead job %s retried as %s", job_id, new_id)
    return new_id


async def list_jobs(
    status: JobStatus | None = None,
    queue: str | None = None,
    limit: int = 50,
) -> list[JobInfo]:
    """List recent jobs, optionally filtered by status.

    This scans job keys in Redis (suitable for dashboards, not high-frequency
    queries). For production at scale you'd back this with a proper index.
    """
    r = get_redis()
    keys: list[str] = []

    cursor: int | str = 0
    while True:
        cursor, batch = await r.scan(cursor=int(cursor), match=f"{JOB_PREFIX}*", count=200)
        keys.extend(batch)
        if cursor == 0:
            break

    jobs: list[JobInfo] = []
    for key in keys:
        raw = await r.get(key)
        if raw is None:
            continue
        job_info = JobInfo.model_validate_json(raw)

        if status is not None and job_info.status != status:
            continue
        if queue is not None and job_info.queue != queue:
            continue

        jobs.append(job_info)
        if len(jobs) >= limit:
            break

    jobs.sort(key=lambda j: j.created_at, reverse=True)
    return jobs[:limit]
