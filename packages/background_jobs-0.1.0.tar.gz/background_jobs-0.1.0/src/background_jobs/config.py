"""Global configuration and Redis connection management."""

from __future__ import annotations

import redis.asyncio as redis
from pydantic import BaseModel


class JobConfig(BaseModel):
    """Configuration for the background jobs system."""

    redis_url: str = "redis://localhost:6379"
    queue_name: str = "default"
    max_retries: int = 3
    retry_delay_seconds: int = 60
    job_timeout_seconds: int = 300
    concurrency: int = 5


_redis_client: redis.Redis | None = None
_config: JobConfig | None = None


def init_jobs(config: JobConfig | None = None) -> None:
    """Initialize the jobs system with a Redis connection and config.

    Args:
        config: Job configuration. Uses defaults if not provided.
    """
    global _redis_client, _config
    _config = config or JobConfig()
    _redis_client = redis.from_url(_config.redis_url, decode_responses=True)


def get_redis() -> redis.Redis:
    """Return the active Redis client. Raises if not initialized."""
    if _redis_client is None:
        raise RuntimeError("Job system not initialized. Call init_jobs() first.")
    return _redis_client


def get_config() -> JobConfig:
    """Return the active job config. Raises if not initialized."""
    if _config is None:
        raise RuntimeError("Job system not initialized. Call init_jobs() first.")
    return _config


def set_redis_client(client: redis.Redis) -> None:
    """Override the Redis client (used for testing with fakeredis)."""
    global _redis_client
    _redis_client = client


def set_config(config: JobConfig) -> None:
    """Override the config (used for testing)."""
    global _config
    _config = config
