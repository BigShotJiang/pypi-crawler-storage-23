"""Async worker that processes jobs from Redis queues."""

from __future__ import annotations

import asyncio
import logging
import signal
import time
from datetime import datetime, timezone

from .config import JobConfig, get_config, get_redis
from .models import JobInfo, JobStatus
from .queue import DEAD_LETTER_KEY, DELAYED_KEY, _job_key, _queue_key
from .registry import get_handler, get_job_meta
from .scheduler import _process_scheduled_jobs

logger = logging.getLogger("background_jobs.worker")


class JobWorker:
    """Pulls jobs from Redis queues and executes them with concurrency control.

    Handles retries with exponential backoff, dead-letter routing, delayed job
    promotion, and cron schedule checking.
    """

    def __init__(
        self,
        config: JobConfig | None = None,
        queues: list[str] | None = None,
    ) -> None:
        self._config = config or get_config()
        self._queues = queues or [self._config.queue_name]
        self._shutdown = False
        self._semaphore = asyncio.Semaphore(self._config.concurrency)
        self._active_tasks: set[asyncio.Task] = set()  # type: ignore[type-arg]

    async def run(self) -> None:
        """Main loop: pop jobs, execute them, handle delayed and scheduled jobs.

        Blocks until a shutdown signal is received (SIGINT / SIGTERM).
        """
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._request_shutdown)

        logger.info(
            "Worker started — queues=%s, concurrency=%d",
            self._queues,
            self._config.concurrency,
        )

        delayed_task = asyncio.create_task(self._delayed_loop())
        scheduled_task = asyncio.create_task(self._scheduled_loop())

        try:
            await self._poll_loop()
        finally:
            self._shutdown = True
            delayed_task.cancel()
            scheduled_task.cancel()
            # Wait for in-flight jobs to finish
            if self._active_tasks:
                logger.info("Waiting for %d active jobs to finish...", len(self._active_tasks))
                await asyncio.gather(*self._active_tasks, return_exceptions=True)
            logger.info("Worker shut down gracefully.")

    async def _poll_loop(self) -> None:
        """Continuously BRPOP from all watched queues."""
        r = get_redis()
        keys = [_queue_key(q) for q in self._queues]

        while not self._shutdown:
            try:
                result = await r.brpop(keys, timeout=1)
            except Exception:
                if self._shutdown:
                    break
                logger.exception("Redis BRPOP error, retrying in 1s")
                await asyncio.sleep(1)
                continue

            if result is None:
                # Timeout — go around and check shutdown flag
                continue

            _key, payload = result
            await self._semaphore.acquire()
            task = asyncio.create_task(self._execute(payload))
            self._active_tasks.add(task)
            task.add_done_callback(self._task_done)

    def _task_done(self, task: asyncio.Task) -> None:  # type: ignore[type-arg]
        self._active_tasks.discard(task)
        self._semaphore.release()

    async def _execute(self, payload: str) -> None:
        """Deserialize and run a single job, handling all failure modes."""
        r = get_redis()
        job_info = JobInfo.model_validate_json(payload)

        # Mark running
        job_info.status = JobStatus.running
        job_info.started_at = datetime.now(timezone.utc)
        await r.set(_job_key(job_info.id), job_info.model_dump_json())

        # Resolve timeout
        timeout = self._config.job_timeout_seconds
        try:
            meta = get_job_meta(job_info.name)
            if meta.get("timeout") is not None:
                timeout = meta["timeout"]
        except KeyError:
            pass

        try:
            handler = get_handler(job_info.name)
            logger.info("Job %s (%s) started", job_info.id, job_info.name)

            if asyncio.iscoroutinefunction(handler):
                await asyncio.wait_for(handler(**job_info.args), timeout=timeout)
            else:
                # Run sync handlers in a thread so we don't block the loop
                await asyncio.wait_for(
                    asyncio.get_running_loop().run_in_executor(
                        None, lambda: handler(**job_info.args)
                    ),
                    timeout=timeout,
                )

            job_info.status = JobStatus.completed
            job_info.completed_at = datetime.now(timezone.utc)
            await r.set(_job_key(job_info.id), job_info.model_dump_json())
            logger.info("Job %s (%s) completed", job_info.id, job_info.name)

        except asyncio.TimeoutError:
            await self._handle_failure(job_info, f"Timed out after {timeout}s")

        except Exception as exc:
            await self._handle_failure(job_info, str(exc))

    async def _handle_failure(self, job_info: JobInfo, error: str) -> None:
        """Retry with exponential backoff or move to the dead-letter queue."""
        r = get_redis()
        job_info.retries += 1
        job_info.error = error

        if job_info.retries >= job_info.max_retries:
            job_info.status = JobStatus.dead
            job_info.completed_at = datetime.now(timezone.utc)
            await r.set(_job_key(job_info.id), job_info.model_dump_json())
            await r.lpush(DEAD_LETTER_KEY, job_info.model_dump_json())
            logger.error(
                "Job %s (%s) moved to dead-letter after %d retries: %s",
                job_info.id,
                job_info.name,
                job_info.retries,
                error,
            )
        else:
            job_info.status = JobStatus.pending
            delay = self._config.retry_delay_seconds * (2 ** (job_info.retries - 1))
            run_at = time.time() + delay
            updated_payload = job_info.model_dump_json()
            await r.set(_job_key(job_info.id), updated_payload)
            await r.zadd(DELAYED_KEY, {updated_payload: run_at})
            logger.warning(
                "Job %s (%s) failed (attempt %d/%d), retrying in %ds: %s",
                job_info.id,
                job_info.name,
                job_info.retries,
                job_info.max_retries,
                delay,
                error,
            )

    async def _delayed_loop(self) -> None:
        """Periodically promote delayed jobs whose run time has arrived."""
        r = get_redis()
        while not self._shutdown:
            try:
                now = time.time()
                ready = await r.zrangebyscore(DELAYED_KEY, "-inf", now)
                for payload in ready:
                    removed = await r.zrem(DELAYED_KEY, payload)
                    if removed:
                        job_info = JobInfo.model_validate_json(payload)
                        await r.lpush(_queue_key(job_info.queue), payload)
                        logger.debug("Promoted delayed job %s to queue '%s'", job_info.id, job_info.queue)
            except asyncio.CancelledError:
                return
            except Exception:
                logger.exception("Error in delayed-job loop")

            await asyncio.sleep(1)

    async def _scheduled_loop(self) -> None:
        """Check cron schedules every 30 seconds and enqueue due jobs."""
        while not self._shutdown:
            try:
                await _process_scheduled_jobs()
            except asyncio.CancelledError:
                return
            except Exception:
                logger.exception("Error in scheduled-job loop")
            await asyncio.sleep(30)

    def _request_shutdown(self) -> None:
        logger.info("Shutdown signal received")
        self._shutdown = True
