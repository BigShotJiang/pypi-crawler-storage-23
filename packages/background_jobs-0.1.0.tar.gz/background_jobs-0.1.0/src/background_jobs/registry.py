"""Job handler registry with decorator-based registration."""

from __future__ import annotations

import asyncio
import functools
from typing import Any, Callable

_registry: dict[str, dict[str, Any]] = {}


def job(
    name: str | None = None,
    max_retries: int | None = None,
    timeout: int | None = None,
    queue: str | None = None,
) -> Callable:
    """Register a function as a named job handler.

    The decorated function can still be called directly (sync or async).

    Args:
        name: Job name. Defaults to "module.function_name".
        max_retries: Override default max retries for this job.
        timeout: Override default timeout (seconds) for this job.
        queue: Override default queue name for this job.
    """

    def decorator(func: Callable) -> Callable:
        job_name = name or f"{func.__module__}.{func.__qualname__}"

        _registry[job_name] = {
            "handler": func,
            "max_retries": max_retries,
            "timeout": timeout,
            "queue": queue,
        }

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if asyncio.iscoroutinefunction(func):
                return func(*args, **kwargs)
            return func(*args, **kwargs)

        wrapper._job_name = job_name  # type: ignore[attr-defined]
        return wrapper

    return decorator


def get_handler(job_name: str) -> Callable:
    """Look up a registered handler by name.

    Raises:
        KeyError: If no handler is registered for the given name.
    """
    entry = _registry.get(job_name)
    if entry is None:
        raise KeyError(f"No handler registered for job '{job_name}'")
    return entry["handler"]


def get_job_meta(job_name: str) -> dict[str, Any]:
    """Return the full registration metadata for a job.

    Raises:
        KeyError: If no handler is registered for the given name.
    """
    entry = _registry.get(job_name)
    if entry is None:
        raise KeyError(f"No handler registered for job '{job_name}'")
    return entry


def list_registered_jobs() -> list[str]:
    """Return all registered job names."""
    return list(_registry.keys())


def clear_registry() -> None:
    """Remove all registered jobs (used for testing)."""
    _registry.clear()
