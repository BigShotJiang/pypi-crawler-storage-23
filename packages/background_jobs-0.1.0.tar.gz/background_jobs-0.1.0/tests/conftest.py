"""Shared fixtures for all test modules."""

from __future__ import annotations

import pytest
import fakeredis.aioredis

from background_jobs.config import JobConfig, set_config, set_redis_client
from background_jobs.registry import clear_registry


@pytest.fixture(autouse=True)
async def _setup_fake_redis():
    """Provide a fresh fakeredis instance and config for every test."""
    fake = fakeredis.aioredis.FakeRedis(decode_responses=True)
    config = JobConfig(
        redis_url="redis://fake",
        queue_name="default",
        max_retries=3,
        retry_delay_seconds=1,
        job_timeout_seconds=5,
        concurrency=2,
    )
    set_redis_client(fake)
    set_config(config)
    clear_registry()
    yield
    await fake.aclose()
