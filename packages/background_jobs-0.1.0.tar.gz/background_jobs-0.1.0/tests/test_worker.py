"""Tests for the async worker: execution, retries, timeouts, dead-letter."""

from __future__ import annotations

import asyncio

import pytest

from background_jobs.config import get_config, get_redis
from background_jobs.models import JobInfo, JobStatus
from background_jobs.queue import (
    DEAD_LETTER_KEY,
    _job_key,
    _queue_key,
    enqueue,
    get_dead_letter_jobs,
    get_job,
)
from background_jobs.registry import job
from background_jobs.worker import JobWorker


# ---------------------------------------------------------------------------
# Helper: run the worker for a bounded time
# ---------------------------------------------------------------------------


async def _run_worker_briefly(worker: JobWorker, seconds: float = 0.5) -> None:
    """Start the worker and stop it after a short delay.

    We avoid relying on signals in tests; instead we flip the shutdown flag.
    """
    task = asyncio.create_task(_worker_loop(worker))
    await asyncio.sleep(seconds)
    worker._shutdown = True
    await task


async def _worker_loop(worker: JobWorker) -> None:
    """Run the worker poll loop (without signal handlers, for test safety)."""
    delayed_task = asyncio.create_task(worker._delayed_loop())
    try:
        await worker._poll_loop()
    finally:
        worker._shutdown = True
        delayed_task.cancel()
        if worker._active_tasks:
            await asyncio.gather(*worker._active_tasks, return_exceptions=True)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestWorkerExecution:
    async def test_worker_processes_async_job(self):
        results: list[str] = []

        @job(name="greet")
        async def greet(name: str = "world") -> None:
            results.append(f"hello {name}")

        job_id = await enqueue("greet", args={"name": "Willian"})
        worker = JobWorker()
        await _run_worker_briefly(worker, seconds=0.5)

        assert results == ["hello Willian"]
        info = await get_job(job_id)
        assert info is not None
        assert info.status == JobStatus.completed

    async def test_worker_processes_sync_job(self):
        results: list[int] = []

        @job(name="sync_add")
        def sync_add(a: int = 0, b: int = 0) -> None:
            results.append(a + b)

        await enqueue("sync_add", args={"a": 3, "b": 7})
        worker = JobWorker()
        await _run_worker_briefly(worker, seconds=0.5)

        assert results == [10]

    async def test_worker_marks_failed_on_exception(self):
        @job(name="boom", max_retries=1)
        async def boom() -> None:
            raise RuntimeError("kaboom")

        job_id = await enqueue("boom")
        worker = JobWorker()
        await _run_worker_briefly(worker, seconds=0.5)

        info = await get_job(job_id)
        assert info is not None
        # With max_retries=1, the first failure should move it to dead
        assert info.status == JobStatus.dead
        assert "kaboom" in (info.error or "")

    async def test_worker_retries_before_dead_letter(self):
        call_count = 0

        @job(name="flaky", max_retries=3)
        async def flaky() -> None:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("not yet")

        job_id = await enqueue("flaky")
        # Run long enough for retries (delayed jobs need promotion)
        worker = JobWorker()
        await _run_worker_briefly(worker, seconds=2.0)

        # The job should have been attempted at least once, and retries
        # get pushed to the delayed set. The delayed loop promotes them.
        info = await get_job(job_id)
        assert info is not None
        # At minimum the first attempt happened
        assert info.retries >= 1

    async def test_worker_timeout(self):
        @job(name="slow", timeout=1, max_retries=1)
        async def slow() -> None:
            await asyncio.sleep(60)

        job_id = await enqueue("slow")
        worker = JobWorker()
        await _run_worker_briefly(worker, seconds=2.0)

        info = await get_job(job_id)
        assert info is not None
        assert info.status == JobStatus.dead
        assert "Timed out" in (info.error or "")


class TestWorkerDelayedJobs:
    async def test_delayed_job_promoted_and_executed(self):
        results: list[str] = []

        @job(name="delayed_hello")
        async def delayed_hello() -> None:
            results.append("done")

        await enqueue("delayed_hello", delay_seconds=1)
        worker = JobWorker()
        await _run_worker_briefly(worker, seconds=2.5)

        assert results == ["done"]


class TestWorkerMultipleQueues:
    async def test_worker_listens_to_multiple_queues(self):
        results: list[str] = []

        @job(name="q1_job")
        async def q1_job() -> None:
            results.append("q1")

        @job(name="q2_job")
        async def q2_job() -> None:
            results.append("q2")

        await enqueue("q1_job", queue="alpha")
        await enqueue("q2_job", queue="beta")

        worker = JobWorker(queues=["alpha", "beta"])
        await _run_worker_briefly(worker, seconds=1.0)

        assert sorted(results) == ["q1", "q2"]
