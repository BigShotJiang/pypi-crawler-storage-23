"""Tests for queue operations: enqueue, get, cancel, dead-letter."""

from __future__ import annotations

import pytest

from background_jobs.config import get_redis
from background_jobs.models import JobStatus
from background_jobs.queue import (
    DELAYED_KEY,
    cancel_job,
    enqueue,
    get_dead_letter_jobs,
    get_job,
    get_queue_length,
    list_jobs,
    retry_dead_job,
    _queue_key,
    _job_key,
)
from background_jobs.registry import job


# ---------------------------------------------------------------------------
# Helpers — register some dummy handlers
# ---------------------------------------------------------------------------


def _register_echo():
    @job(name="echo")
    async def echo_handler(message: str = "") -> str:
        return message


def _register_custom_queue():
    @job(name="custom_q", queue="priority")
    async def handler() -> None:
        pass


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestEnqueue:
    async def test_enqueue_returns_job_id(self):
        _register_echo()
        job_id = await enqueue("echo", args={"message": "hello"})
        assert isinstance(job_id, str)
        assert len(job_id) == 32  # hex uuid

    async def test_enqueue_creates_job_state(self):
        _register_echo()
        job_id = await enqueue("echo", args={"message": "hi"})
        info = await get_job(job_id)
        assert info is not None
        assert info.name == "echo"
        assert info.args == {"message": "hi"}
        assert info.status == JobStatus.pending
        assert info.queue == "default"

    async def test_enqueue_pushes_to_queue_list(self):
        _register_echo()
        await enqueue("echo")
        length = await get_queue_length()
        assert length == 1

    async def test_enqueue_uses_job_level_queue(self):
        _register_custom_queue()
        job_id = await enqueue("custom_q")
        info = await get_job(job_id)
        assert info is not None
        assert info.queue == "priority"
        assert await get_queue_length("priority") == 1

    async def test_enqueue_explicit_queue_overrides_job_level(self):
        _register_custom_queue()
        job_id = await enqueue("custom_q", queue="urgent")
        info = await get_job(job_id)
        assert info is not None
        assert info.queue == "urgent"

    async def test_enqueue_with_delay(self):
        _register_echo()
        job_id = await enqueue("echo", delay_seconds=60)
        # Should NOT be in the immediate queue
        assert await get_queue_length() == 0
        # Should be in the delayed sorted set
        r = get_redis()
        count = await r.zcard(DELAYED_KEY)
        assert count == 1

    async def test_enqueue_unregistered_job_still_works(self):
        """Enqueue must work even if the handler isn't registered yet
        (it only needs to exist when the worker picks it up)."""
        job_id = await enqueue("not.registered.yet")
        assert job_id
        info = await get_job(job_id)
        assert info is not None
        assert info.name == "not.registered.yet"


class TestGetJob:
    async def test_get_nonexistent_returns_none(self):
        assert await get_job("nonexistent") is None


class TestCancelJob:
    async def test_cancel_pending_job(self):
        _register_echo()
        job_id = await enqueue("echo")
        assert await cancel_job(job_id) is True
        info = await get_job(job_id)
        assert info is not None
        assert info.status == JobStatus.failed
        assert info.error == "Cancelled by user"

    async def test_cancel_nonexistent_returns_false(self):
        assert await cancel_job("does_not_exist") is False

    async def test_cancel_already_running_returns_false(self):
        """Manually set a job to running, then try to cancel."""
        _register_echo()
        job_id = await enqueue("echo")
        info = await get_job(job_id)
        assert info is not None
        info.status = JobStatus.running
        r = get_redis()
        await r.set(_job_key(job_id), info.model_dump_json())
        assert await cancel_job(job_id) is False


class TestQueueLength:
    async def test_empty_queue(self):
        assert await get_queue_length() == 0

    async def test_after_multiple_enqueues(self):
        _register_echo()
        await enqueue("echo")
        await enqueue("echo")
        await enqueue("echo")
        assert await get_queue_length() == 3


class TestDeadLetter:
    async def test_empty_dead_letter(self):
        jobs = await get_dead_letter_jobs()
        assert jobs == []

    async def test_retry_nonexistent_raises(self):
        with pytest.raises(ValueError, match="not found"):
            await retry_dead_job("ghost")

    async def test_retry_non_dead_raises(self):
        _register_echo()
        job_id = await enqueue("echo")
        with pytest.raises(ValueError, match="not in dead-letter"):
            await retry_dead_job(job_id)


class TestListJobs:
    async def test_list_returns_enqueued_jobs(self):
        _register_echo()
        await enqueue("echo", args={"message": "a"})
        await enqueue("echo", args={"message": "b"})
        jobs = await list_jobs()
        assert len(jobs) == 2

    async def test_list_filter_by_status(self):
        _register_echo()
        job_id = await enqueue("echo")
        await cancel_job(job_id)
        await enqueue("echo")
        pending = await list_jobs(status=JobStatus.pending)
        failed = await list_jobs(status=JobStatus.failed)
        assert len(pending) == 1
        assert len(failed) == 1

    async def test_list_respects_limit(self):
        _register_echo()
        for i in range(10):
            await enqueue("echo", args={"i": i})
        jobs = await list_jobs(limit=3)
        assert len(jobs) == 3
