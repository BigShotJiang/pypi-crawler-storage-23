"""Tests for cron scheduling: register, list, enable/disable, fire."""

from __future__ import annotations

from datetime import datetime, timezone, timedelta

import pytest

from background_jobs.config import get_redis
from background_jobs.models import JobStatus
from background_jobs.queue import get_queue_length, list_jobs
from background_jobs.registry import job
from background_jobs.scheduler import (
    SCHEDULES_KEY,
    _process_scheduled_jobs,
    disable_schedule,
    enable_schedule,
    get_schedule,
    get_scheduled_jobs,
    remove_schedule,
    schedule,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _register_noop():
    @job(name="noop")
    async def noop() -> None:
        pass


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestScheduleRegistration:
    async def test_create_schedule(self):
        _register_noop()
        sj = await schedule("daily-noop", "0 2 * * *", "noop")
        assert sj.name == "daily-noop"
        assert sj.cron_expression == "0 2 * * *"
        assert sj.job_name == "noop"
        assert sj.enabled is True
        assert sj.next_run_at is not None

    async def test_create_schedule_with_args(self):
        _register_noop()
        sj = await schedule("param-job", "*/5 * * * *", "noop", args={"key": "value"})
        assert sj.args == {"key": "value"}

    async def test_invalid_cron_raises(self):
        with pytest.raises(ValueError, match="Invalid cron expression"):
            await schedule("bad", "not a cron", "noop")

    async def test_schedule_persisted_in_redis(self):
        _register_noop()
        await schedule("persist-test", "0 * * * *", "noop")
        r = get_redis()
        raw = await r.hget(SCHEDULES_KEY, "persist-test")
        assert raw is not None


class TestScheduleListing:
    async def test_list_empty(self):
        jobs = await get_scheduled_jobs()
        assert jobs == []

    async def test_list_multiple(self):
        _register_noop()
        await schedule("a", "0 1 * * *", "noop")
        await schedule("b", "0 2 * * *", "noop")
        jobs = await get_scheduled_jobs()
        assert len(jobs) == 2
        names = {j.name for j in jobs}
        assert names == {"a", "b"}

    async def test_get_single_schedule(self):
        _register_noop()
        await schedule("single", "30 4 * * *", "noop")
        sj = await get_schedule("single")
        assert sj is not None
        assert sj.cron_expression == "30 4 * * *"

    async def test_get_nonexistent_returns_none(self):
        assert await get_schedule("ghost") is None


class TestScheduleRemoval:
    async def test_remove_existing(self):
        _register_noop()
        await schedule("removable", "0 0 * * *", "noop")
        assert await remove_schedule("removable") is True
        assert await get_schedule("removable") is None

    async def test_remove_nonexistent(self):
        assert await remove_schedule("nope") is False


class TestEnableDisable:
    async def test_disable_schedule(self):
        _register_noop()
        await schedule("toggle", "0 0 * * *", "noop")
        assert await disable_schedule("toggle") is True
        sj = await get_schedule("toggle")
        assert sj is not None
        assert sj.enabled is False

    async def test_enable_schedule(self):
        _register_noop()
        await schedule("toggle2", "0 0 * * *", "noop")
        await disable_schedule("toggle2")
        assert await enable_schedule("toggle2") is True
        sj = await get_schedule("toggle2")
        assert sj is not None
        assert sj.enabled is True

    async def test_enable_nonexistent(self):
        assert await enable_schedule("ghost") is False

    async def test_disable_nonexistent(self):
        assert await disable_schedule("ghost") is False


class TestProcessScheduledJobs:
    async def test_due_schedule_enqueues_job(self):
        _register_noop()
        sj = await schedule("due-test", "* * * * *", "noop")

        # Manually set next_run_at to the past so it fires immediately
        r = get_redis()
        sj.next_run_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        await r.hset(SCHEDULES_KEY, "due-test", sj.model_dump_json())

        await _process_scheduled_jobs()

        jobs = await list_jobs()
        assert len(jobs) == 1
        assert jobs[0].name == "noop"

        # next_run_at should have advanced
        updated = await get_schedule("due-test")
        assert updated is not None
        assert updated.next_run_at is not None
        assert updated.next_run_at > datetime.now(timezone.utc)

    async def test_disabled_schedule_does_not_fire(self):
        _register_noop()
        sj = await schedule("disabled-test", "* * * * *", "noop")
        await disable_schedule("disabled-test")

        # Set to past
        r = get_redis()
        sj.next_run_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        sj.enabled = False
        await r.hset(SCHEDULES_KEY, "disabled-test", sj.model_dump_json())

        await _process_scheduled_jobs()

        jobs = await list_jobs()
        assert len(jobs) == 0

    async def test_future_schedule_does_not_fire(self):
        _register_noop()
        await schedule("future-test", "0 0 1 1 *", "noop")  # Jan 1 midnight

        await _process_scheduled_jobs()

        jobs = await list_jobs()
        assert len(jobs) == 0
