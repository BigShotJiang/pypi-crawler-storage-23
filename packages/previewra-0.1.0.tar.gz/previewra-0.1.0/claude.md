# DevPreview — Claude Code CLI Execution Blueprint v5

> **本文档 = CLAUDE.md + Phase Prompts + 完整实现规格**
> 将本文档放在项目根目录作为 `CLAUDE.md`，Claude Code 会自动读取。
> 每个 Phase 的 Prompt 可直接复制粘贴到 Claude Code CLI 执行。

---

## PROJECT IDENTITY

- **Name:** devpreview
- **One-liner:** AI-native Runtime OS Layer — instant preview for AI-coded projects
- **License:** MIT
- **Python:** >=3.10
- **Architecture:** Multi-Service · Event-Driven · Reverse Proxy · Sessionized · i18n Tri-Language

---

## CONVENTIONS

- All source code under `src/devpreview/`
- Use `async/await` for all IO operations
- Use Pydantic v2 `BaseModel` for all data structures
- Use `Literal` types for all enums/states
- Never use `print()` directly — use `utils/log.py` which wraps `rich.console`
- All user-facing strings go through `i18n/` module — **never hardcode Chinese or English strings**
- File naming: avoid Python keyword conflicts (use `fastapi_.py`, `python_.py`, `platform_.py`)
- Tests mirror source structure: `tests/test_<module>.py`

---

## LANGUAGE ARCHITECTURE (i18n)

三语支持：简体中文 (zh-CN)、繁体中文 (zh-TW)、English (en)

```
src/devpreview/i18n/
├── __init__.py          # get_text(key) / set_locale(locale) / T(key) shortcut
├── locale.py            # locale detection + config persistence
└── messages/
    ├── zh_CN.json       # 简体中文
    ├── zh_TW.json       # 繁体中文
    └── en.json          # English
```

Design rules:
- `T("detecting_project")` returns localized string
- CLI flag: `devpreview --lang en preview .`
- Config persistence: `.devpreview/config.json` → `{"locale": "zh-CN"}`
- Fallback chain: user config → system locale → en
- Dashboard language: follows same config, switchable via UI dropdown

---

## DIRECTORY STRUCTURE (FINAL)

```
devpreview/
├── CLAUDE.md                          ← this file
├── pyproject.toml
├── README.md
├── LICENSE
│
├── src/
│   └── devpreview/
│       ├── __init__.py                # from .version import __version__
│       ├── version.py                 # __version__ = "0.1.0"
│       ├── cli.py                     # Typer app, all commands
│       ├── config.py                  # constants + paths
│       │
│       ├── i18n/                      # ★ internationalization
│       │   ├── __init__.py            # T(), set_locale(), get_locale()
│       │   ├── locale.py             # detect + persist locale
│       │   └── messages/
│       │       ├── zh_CN.json
│       │       ├── zh_TW.json
│       │       └── en.json
│       │
│       ├── core/
│       │   ├── __init__.py
│       │   ├── context.py            # RuntimeContext dataclass
│       │   ├── session.py            # Session create/list/show/cleanup
│       │   └── lifecycle.py          # LifecycleState enum + transitions
│       │
│       ├── detector/
│       │   ├── __init__.py
│       │   ├── base.py               # BaseDetector ABC + DetectionResult
│       │   ├── registry.py           # DetectorRegistry.detect(path) → list[ServiceConfig]
│       │   ├── react.py              # priority=30
│       │   ├── fastapi_.py           # priority=10
│       │   ├── flask_.py             # priority=20
│       │   ├── static.py             # priority=90
│       │   └── python_script.py      # priority=80
│       │
│       ├── installer/
│       │   ├── __init__.py
│       │   ├── base.py               # BaseInstaller ABC
│       │   ├── node.py               # NodeInstaller
│       │   └── python_.py            # PythonInstaller (venv + pip)
│       │
│       ├── runner/
│       │   ├── __init__.py
│       │   ├── process.py            # ProcessRunner (single service)
│       │   └── manager.py            # RunnerManager (multi-service)
│       │
│       ├── monitor/
│       │   ├── __init__.py
│       │   ├── event_bus.py          # EventBus pub/sub
│       │   ├── process_probe.py      # psutil probe
│       │   ├── port_probe.py         # TCP + HTTP probe
│       │   ├── healthcheck.py        # health engine
│       │   ├── simulator.py          # GET homepage validation
│       │   └── aggregator.py         # RuntimeAggregator → RuntimeState
│       │
│       ├── dashboard/
│       │   ├── __init__.py
│       │   ├── app.py                # FastAPI server
│       │   ├── proxy.py              # reverse proxy handler
│       │   ├── ws.py                 # WebSocket: /ws/logs, /ws/status
│       │   └── static/
│       │       └── index.html        # single-file Dashboard (HTML+CSS+JS)
│       │
│       ├── doctor/
│       │   ├── __init__.py
│       │   └── diagnose.py           # DiagnosticEngine
│       │
│       ├── manifest/
│       │   ├── __init__.py
│       │   └── schema.py             # Manifest + ServiceConfig Pydantic models
│       │
│       ├── runtime/
│       │   ├── __init__.py
│       │   ├── history.py            # session history CRUD
│       │   └── snapshot.py           # RuntimeState snapshot save/load
│       │
│       ├── watcher/
│       │   ├── __init__.py
│       │   └── file_watcher.py       # watchdog + debounce
│       │
│       └── utils/
│           ├── __init__.py
│           ├── port.py               # is_port_in_use / find_free_port
│           ├── platform_.py          # is_wsl / open_browser
│           └── log.py                # Rich console wrapper + log buffer
│
└── tests/
    ├── __init__.py
    ├── test_detector.py
    ├── test_installer.py
    ├── test_runner.py
    ├── test_monitor.py
    ├── test_doctor.py
    └── test_i18n.py
```

---

## DATA MODELS (Pydantic)

### ServiceConfig
```python
class ServiceConfig(BaseModel):
    name: str                                    # "backend", "frontend"
    project_type: str                            # "fastapi", "react", etc.
    start_command: str
    install_command: Optional[str] = None
    port: Optional[int] = None
    env: dict[str, str] = {}
    working_dir: Optional[str] = None           # relative to project_root
```

### Manifest
```python
class Manifest(BaseModel):
    version: str = "2"
    session_id: str
    project_root: str
    services: list[ServiceConfig]
    detected_at: str                             # ISO timestamp
    locale: str = "en"                           # zh-CN / zh-TW / en
```

### RuntimeState
```python
class RuntimeState(BaseModel):
    session_id: str
    services: dict[str, ServiceRuntimeState]
    overall_status: Literal["STARTING", "HEALTHY", "DEGRADED", "FAILED", "CRASHED"]
    timestamp: str

class ServiceRuntimeState(BaseModel):
    name: str
    process: Optional[ProcessInfo] = None
    port: Optional[PortInfo] = None
    health: Optional[HealthResult] = None
    simulator: Optional[SimulatorResult] = None
    status: Literal["STARTING", "RUNNING", "HEALTHY", "DEGRADED", "FAILED", "CRASHED", "STOPPED"]
```

### ProcessInfo
```python
class ProcessInfo(BaseModel):
    pid: int
    status: str                                  # "running", "sleeping", "dead"
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    uptime_seconds: float = 0.0
```

### PortInfo
```python
class PortInfo(BaseModel):
    port: int
    status: Literal["CONNECTION_REFUSED", "TIMEOUT", "HTTP_200", "HTTP_500", "HTTP_OTHER"]
    response_time_ms: float = 0.0
    content_length: int = 0
    status_code: Optional[int] = None
```

### HealthResult
```python
class HealthResult(BaseModel):
    status: Literal["HEALTHY", "DEGRADED", "FAILED"]
    checks: list[dict] = []
```

### SimulatorResult
```python
class SimulatorResult(BaseModel):
    passed: bool
    checks: dict = {}
    error: Optional[str] = None
```

### DiagnosticReport
```python
class DiagnosticReport(BaseModel):
    session_id: str
    service: str
    status: str
    reason: str                                  # PROCESS_CRASHED / PORT_IN_USE / etc.
    details: dict
    suggestion: str                              # localized via i18n
    timestamp: str
```

---

## STATE MACHINE

```
DETECTED → INSTALLING → STARTING → RUNNING → MONITORING
                                                   ↓
                                    ┌──────────────┼──────────────┐
                                    ↓              ↓              ↓
                                 HEALTHY       DEGRADED     FAILED/CRASHED

Any state + refresh → back to DETECTED
Any state + stop → STOPPED
```

Decision logic in aggregator:
```python
if process.status == "dead":        → CRASHED
elif port.status == "CONNECTION_REFUSED": → FAILED
elif port.status.startswith("HTTP_5"):   → DEGRADED
elif health.status == "HEALTHY":         → HEALTHY
else:                                    → STARTING
```

---

## EVENT BUS EVENTS

```python
class EventType(str, Enum):
    PROCESS_STARTED  = "process.started"
    PROCESS_EXITED   = "process.exited"
    PROCESS_LOG      = "process.log"
    PROCESS_ERROR    = "process.error"
    PORT_OPEN        = "port.open"
    PORT_FAIL        = "port.fail"
    HEALTH_OK        = "health.ok"
    HEALTH_FAIL      = "health.fail"
    STATE_CHANGED    = "state.changed"
    FILE_CHANGED     = "file.changed"
```

---

## REVERSE PROXY SPEC

Dashboard route: `GET /preview/{service_name}/{path:path}`

```python
# proxy.py pseudocode
async def proxy_request(service_name: str, path: str, request: Request):
    service = context.manifest.get_service(service_name)
    target_url = f"http://localhost:{service.port}/{path}"

    async with httpx.AsyncClient() as client:
        proxy_resp = await client.request(
            method=request.method,
            url=target_url,
            headers=dict(request.headers),
            content=await request.body(),
            timeout=10.0
        )
        return Response(
            content=proxy_resp.content,
            status_code=proxy_resp.status_code,
            headers=dict(proxy_resp.headers)
        )
```

Dashboard iframe src: `/preview/backend/` (not `http://localhost:8000/`)

---

## i18n MESSAGE KEYS

下面列出所有需要翻译的 key。每个 JSON 文件必须包含全部 key。

### messages/en.json (partial — full set in Phase 1)
```json
{
  "app_name": "DevPreview",
  "detecting_project": "Detecting project type...",
  "detected_as": "Detected as: {project_type}",
  "no_project_detected": "No project type detected in {path}",
  "installing_deps": "Installing dependencies for {name}...",
  "install_success": "Dependencies installed for {name}",
  "install_failed": "Failed to install dependencies for {name}",
  "starting_service": "Starting {name}...",
  "service_running": "{name} running on port {port}",
  "service_crashed": "{name} crashed (exit code: {code})",
  "port_in_use": "Port {port} is in use, switching to {new_port}",
  "dashboard_started": "Dashboard started at {url}",
  "opening_browser": "Opening browser...",
  "watching_files": "Watching for file changes...",
  "file_changed": "File changed: {path}, refreshing...",
  "stopping_services": "Stopping all services...",
  "all_stopped": "All services stopped",
  "session_created": "Session: {session_id}",
  "doctor_healthy": "All services are healthy",
  "doctor_report": "Diagnostic report for {name}:",
  "status_healthy": "HEALTHY",
  "status_degraded": "DEGRADED",
  "status_failed": "FAILED",
  "status_crashed": "CRASHED",
  "status_starting": "STARTING",
  "suggest_missing_dep": "Missing dependency detected. Try: {command}",
  "suggest_port_conflict": "Port conflict. DevPreview auto-resolved to port {port}",
  "suggest_check_logs": "Check logs for details: devpreview status",
  "lang_switched": "Language switched to {lang}",
  "sessions_list_header": "Session History",
  "sessions_empty": "No sessions found",
  "unknown_error": "Unknown error occurred"
}
```

### messages/zh_CN.json
```json
{
  "app_name": "DevPreview",
  "detecting_project": "正在检测项目类型...",
  "detected_as": "检测到项目类型：{project_type}",
  "no_project_detected": "未能在 {path} 中检测到项目类型",
  "installing_deps": "正在为 {name} 安装依赖...",
  "install_success": "{name} 依赖安装完成",
  "install_failed": "{name} 依赖安装失败",
  "starting_service": "正在启动 {name}...",
  "service_running": "{name} 已在端口 {port} 上运行",
  "service_crashed": "{name} 已崩溃（退出码：{code}）",
  "port_in_use": "端口 {port} 已被占用，切换到 {new_port}",
  "dashboard_started": "仪表盘已启动：{url}",
  "opening_browser": "正在打开浏览器...",
  "watching_files": "正在监听文件变化...",
  "file_changed": "文件变化：{path}，正在刷新...",
  "stopping_services": "正在停止所有服务...",
  "all_stopped": "所有服务已停止",
  "session_created": "会话：{session_id}",
  "doctor_healthy": "所有服务运行正常",
  "doctor_report": "{name} 的诊断报告：",
  "status_healthy": "健康",
  "status_degraded": "降级",
  "status_failed": "失败",
  "status_crashed": "已崩溃",
  "status_starting": "启动中",
  "suggest_missing_dep": "检测到缺少依赖，请尝试：{command}",
  "suggest_port_conflict": "端口冲突，DevPreview 已自动切换到端口 {port}",
  "suggest_check_logs": "查看日志了解详情：devpreview status",
  "lang_switched": "语言已切换为 {lang}",
  "sessions_list_header": "会话历史",
  "sessions_empty": "暂无会话记录",
  "unknown_error": "发生未知错误"
}
```

### messages/zh_TW.json
```json
{
  "app_name": "DevPreview",
  "detecting_project": "正在偵測專案類型...",
  "detected_as": "偵測到專案類型：{project_type}",
  "no_project_detected": "未能在 {path} 中偵測到專案類型",
  "installing_deps": "正在為 {name} 安裝依賴...",
  "install_success": "{name} 依賴安裝完成",
  "install_failed": "{name} 依賴安裝失敗",
  "starting_service": "正在啟動 {name}...",
  "service_running": "{name} 已在連接埠 {port} 上執行",
  "service_crashed": "{name} 已崩潰（結束碼：{code}）",
  "port_in_use": "連接埠 {port} 已被佔用，切換到 {new_port}",
  "dashboard_started": "儀表板已啟動：{url}",
  "opening_browser": "正在開啟瀏覽器...",
  "watching_files": "正在監聽檔案變化...",
  "file_changed": "檔案變化：{path}，正在重新整理...",
  "stopping_services": "正在停止所有服務...",
  "all_stopped": "所有服務已停止",
  "session_created": "工作階段：{session_id}",
  "doctor_healthy": "所有服務運作正常",
  "doctor_report": "{name} 的診斷報告：",
  "status_healthy": "健康",
  "status_degraded": "降級",
  "status_failed": "失敗",
  "status_crashed": "已崩潰",
  "status_starting": "啟動中",
  "suggest_missing_dep": "偵測到缺少依賴，請嘗試：{command}",
  "suggest_port_conflict": "連接埠衝突，DevPreview 已自動切換到連接埠 {port}",
  "suggest_check_logs": "查看記錄檔瞭解詳情：devpreview status",
  "lang_switched": "語言已切換為 {lang}",
  "sessions_list_header": "工作階段歷史",
  "sessions_empty": "暫無工作階段記錄",
  "unknown_error": "發生未知錯誤"
}
```

---

## CLI COMMANDS SPEC

```
devpreview preview <path>              # detect → install → run → monitor → dashboard → browser
devpreview watch <path>                # preview + file watcher loop
devpreview refresh [path]              # re-detect → restart (for Claude Code Hook)
devpreview status [path]               # output RuntimeState JSON
devpreview stop [path]                 # graceful stop all
devpreview doctor [path] [--json]      # diagnostic report
devpreview sessions list               # list all sessions
devpreview sessions show <id>          # show session detail
devpreview config lang <zh-CN|zh-TW|en>  # set language
```

Global option: `--lang <zh-CN|zh-TW|en>` overrides config for this invocation.

---

## DASHBOARD index.html SPEC

Single HTML file, embedded CSS + JS. Dark theme. No build step.

Features:
- Top bar: "DevPreview" + session_id (truncated) + language dropdown (zh-CN/zh-TW/en)
- Service tabs: clickable tabs for each service in manifest
- Status badge: colored dot (green/yellow/red/blue) + localized status text
- Metrics row: CPU | Memory | Uptime | Port | Response Time
- Preview area: `<iframe src="/preview/{active_service}/">` (reverse proxy)
- Logs area: auto-scroll, WebSocket /ws/logs, monospace font
- Action buttons: Refresh | Restart | Doctor | Stop (call POST /api/*)
- All UI strings loaded from `/api/i18n` endpoint, reactive to language switch

Color scheme:
```
HEALTHY  → #22c55e (green)
DEGRADED → #f59e0b (amber)
FAILED   → #ef4444 (red)
CRASHED  → #ef4444 (red)
STARTING → #3b82f6 (blue)
```

Dashboard API:
```
GET  /                           → index.html
GET  /api/status                 → RuntimeState JSON
GET  /api/logs?service=x&n=100  → recent logs
GET  /api/manifest               → Manifest JSON
GET  /api/doctor                 → DiagnosticReport JSON
GET  /api/i18n                   → current locale messages dict
POST /api/refresh                → trigger refresh
POST /api/restart/{service}      → restart single service
POST /api/stop                   → stop all
POST /api/lang/{locale}          → switch language
GET  /preview/{service}/{path}   → reverse proxy
WS   /ws/logs                    → real-time log stream
WS   /ws/status                  → status push every 2s
```

---

## DETECTOR RULES

| Detector | priority | File check | Content check | start_command | default_port |
|----------|----------|-----------|---------------|---------------|-------------|
| fastapi_ | 10 | `*.py` exists | first 50 lines contain `from fastapi` or `import fastapi` | `uvicorn {file_stem}:app --host 0.0.0.0 --port {port} --reload` | 8000 |
| flask_ | 20 | `*.py` exists | first 50 lines contain `from flask` or `import flask` | `python {file}` | 5000 |
| react | 30 | `package.json` exists | dependencies or devDependencies contains `react` or `vite` | `npm run dev -- --host 0.0.0.0` | 5173 (vite) or 3000 (CRA) |
| python_script | 80 | `main.py` or `app.py` exists | NOT matching fastapi/flask | `python {file}` | None |
| static | 90 | `index.html` exists | — | built-in Python http.server | 8080 |

Important: FastAPI start_command must include `--host 0.0.0.0` for WSL compatibility.
Important: React/Vite must include `--host` flag for WSL.
Important: Detector scans ONLY first 50 lines of .py files.
Important: When fastapi is detected, find the file containing `app = FastAPI()` to use as {file_stem}.

---

## WSL HANDLING

```python
def is_wsl() -> bool:
    try:
        return "microsoft" in Path("/proc/version").read_text().lower()
    except (FileNotFoundError, PermissionError):
        return False

def open_browser(url: str):
    if is_wsl():
        try:
            subprocess.run(["wslview", url], check=True, capture_output=True)
        except FileNotFoundError:
            subprocess.run(["cmd.exe", "/c", "start", url.replace("&", "^&")])
    else:
        webbrowser.open(url)
```

All servers bind `0.0.0.0` (not `127.0.0.1`) when WSL detected.

---

## GRACEFUL SHUTDOWN

```python
async def stop(self):
    if self.process and self.process.returncode is None:
        self.process.terminate()          # SIGTERM
        try:
            await asyncio.wait_for(self.process.wait(), timeout=5)
        except asyncio.TimeoutError:
            self.process.kill()           # SIGKILL
            await self.process.wait()
    self.state = "STOPPED"
```

---

## PORT RESOLUTION

```python
async def resolve_port(preferred: int) -> int:
    if not is_port_in_use(preferred):
        return preferred
    for p in range(preferred + 1, preferred + 100):
        if not is_port_in_use(p):
            log(T("port_in_use", port=preferred, new_port=p))
            return p
    raise RuntimeError(f"No free port in range {preferred}-{preferred+99}")
```

---

# ================================================================
#  PHASE PROMPTS — 直接复制粘贴到 Claude Code CLI
# ================================================================

---

## PHASE 1 PROMPT

```
我正在开发一个名为 devpreview 的 Python CLI 工具。请严格按照项目根目录的 CLAUDE.md 中的规格实现 Phase 1。

Phase 1 需要创建以下文件：

1. pyproject.toml — 完全按照 CLAUDE.md 中的内容
2. src/devpreview/__init__.py
3. src/devpreview/version.py
4. src/devpreview/config.py — 所有常量定义
5. src/devpreview/utils/__init__.py
6. src/devpreview/utils/port.py — is_port_in_use() + find_free_port() + resolve_port()
7. src/devpreview/utils/platform_.py — is_wsl() + open_browser()
8. src/devpreview/utils/log.py — 封装 rich.console，提供 log_info/log_warn/log_error/log_success，内部维护 log_buffer: list[tuple[str, str, str]] 用于 Dashboard 读取
9. src/devpreview/i18n/__init__.py — 实现 T(key, **kwargs) 函数（读 JSON，format 变量），set_locale(locale)，get_locale()
10. src/devpreview/i18n/locale.py — detect_system_locale()（读系统 LANG 环境变量映射到 zh-CN/zh-TW/en），load_config_locale()（读 .devpreview/config.json），save_config_locale()
11. src/devpreview/i18n/messages/en.json — 完整的英文消息（按 CLAUDE.md 中的 key 列表）
12. src/devpreview/i18n/messages/zh_CN.json — 完整的简体中文消息
13. src/devpreview/i18n/messages/zh_TW.json — 完整的繁体中文消息
14. src/devpreview/core/__init__.py
15. src/devpreview/core/context.py — RuntimeContext dataclass，包含 session_id, manifest, runner_manager, monitor, event_bus, dashboard 字段（全部 Optional，后续 Phase 填充）
16. src/devpreview/core/session.py — SessionManager：create_session() 生成 uuid + 创建目录 .devpreview/sessions/{id}/logs/ + /snapshots/ + manifest.json；list_sessions() 返回所有 session；get_session(id)
17. src/devpreview/core/lifecycle.py — LifecycleState 枚举：DETECTED, INSTALLING, STARTING, RUNNING, MONITORING, HEALTHY, DEGRADED, FAILED, CRASHED, STOPPED
18. src/devpreview/manifest/__init__.py
19. src/devpreview/manifest/schema.py — ServiceConfig + Manifest Pydantic models（按 CLAUDE.md DATA MODELS 节），Manifest 包含 save(path) 和 load(path) 方法
20. src/devpreview/cli.py — Typer app，实现以下命令（全部暂时只调用 i18n 打印占位消息）：
    - preview(path, lang) — 打印 "detecting_project"
    - watch(path, lang)
    - refresh(path, lang)
    - status(path, lang)
    - stop(path, lang)
    - doctor(path, lang, json_output: bool)
    - sessions_list()
    - sessions_show(session_id)
    - config_lang(locale) — 调用 save_config_locale
    所有命令接受 --lang 全局 option
21. tests/__init__.py
22. tests/test_i18n.py — 测试 T() 在三个 locale 下都能返回正确字符串，测试变量替换
23. README.md — 项目简介 + 安装 + 使用方法（英文，含中文说明段落）
24. LICENSE — MIT

完成后请运行:
- pip install -e .
- devpreview --help（确认所有命令显示）
- devpreview config lang zh-CN（确认写入配置）
- devpreview preview .（确认输出中文 "正在检测项目类型..."）
- devpreview config lang en
- devpreview preview .（确认输出英文 "Detecting project type..."）
- python -m pytest tests/test_i18n.py（确认通过）
```

---

## PHASE 2 PROMPT

```
继续开发 devpreview，实现 Phase 2：Detector + Installer。严格按照 CLAUDE.md 规格。

需要创建/修改的文件：

1. src/devpreview/detector/__init__.py
2. src/devpreview/detector/base.py:
   - BaseDetector(ABC): name, priority 属性; detect(path: Path) -> Optional[DetectionResult] 抽象方法
   - DetectionResult(BaseModel): project_type, name, start_command, port, install_command, env, working_dir

3. src/devpreview/detector/registry.py:
   - DetectorRegistry 类：auto-import 所有检测器，按 priority 升序排列
   - detect(path) → list[ServiceConfig]（遍历检测器，收集所有匹配结果，转为 ServiceConfig）
   - MVP 阶段只取优先级最高的一个结果

4. src/devpreview/detector/fastapi_.py:
   - priority = 10
   - 扫描 path 下所有 .py 文件（不递归进 IGNORE_DIRS）
   - 读每个文件前 50 行
   - 匹配 "from fastapi" 或 "import fastapi"
   - 找到包含 "FastAPI()" 的文件作为入口
   - start_command: "uvicorn {stem}:app --host 0.0.0.0 --port {port} --reload"
   - install_command: "pip install -r requirements.txt" (if requirements.txt exists)

5. src/devpreview/detector/flask_.py:
   - priority = 20，类似逻辑，匹配 flask import
   - start_command: "python {file}"，Flask 默认 port 5000

6. src/devpreview/detector/react.py:
   - priority = 30
   - 检查 package.json 是否存在
   - JSON parse 检查 dependencies/devDependencies 中是否有 "react" 或 "vite"
   - 判断 vite(port 5173) vs CRA(port 3000)
   - start_command: "npm run dev -- --host 0.0.0.0" (vite) 或 "npm start" (CRA)

7. src/devpreview/detector/python_script.py:
   - priority = 80
   - 匹配 main.py 或 app.py，但排除已被 fastapi/flask 匹配的文件
   - port = None

8. src/devpreview/detector/static.py:
   - priority = 90
   - 匹配 index.html
   - start_command: "python -m http.server {port} --bind 0.0.0.0"
   - port = 8080

9. src/devpreview/installer/__init__.py
10. src/devpreview/installer/base.py:
    - BaseInstaller(ABC): install(path) -> bool 异步方法; error: Optional[str]

11. src/devpreview/installer/node.py:
    - 检查 node_modules 是否存在，不存在则 npm install
    - 捕获 stderr，失败时设置 self.error

12. src/devpreview/installer/python_.py:
    - 创建 .venv（如不存在）: python3 -m venv .venv
    - 使用 .venv/bin/pip install -r requirements.txt
    - 失败时设置 self.error

13. 修改 cli.py 的 preview 命令：
    - 调用 DetectorRegistry.detect(path)
    - 如果无结果，打印 T("no_project_detected") 并退出
    - 打印 T("detected_as")
    - 生成 session
    - 创建 Manifest 并 save
    - 调用对应 Installer
    - 打印安装结果
    - （Runner 部分暂时 pass）

14. tests/test_detector.py:
    - 创建临时目录模拟 FastAPI 项目（写一个含 from fastapi import 的 main.py）
    - 测试 DetectorRegistry.detect 返回正确的 ServiceConfig
    - 测试 React 项目（写一个 package.json with react in dependencies）
    - 测试空目录返回空列表

验收：
- 在一个含 FastAPI 代码的目录运行 devpreview preview . → 显示 "检测到项目类型：fastapi" → 写入 .devpreview.json
- pytest tests/test_detector.py 全部通过
```

---

## PHASE 3 PROMPT

```
继续开发 devpreview，实现 Phase 3：Runner + EventBus。严格按照 CLAUDE.md 规格。

需要创建/修改的文件：

1. src/devpreview/monitor/__init__.py
2. src/devpreview/monitor/event_bus.py:
   - EventType 枚举（按 CLAUDE.md EVENT BUS EVENTS 节）
   - EventBus 类：subscribe(event_type, async_handler), emit(event_type, payload: dict)
   - listeners 为 defaultdict(list)
   - emit 时并发调用所有 handler（asyncio.gather）

3. src/devpreview/runner/__init__.py
4. src/devpreview/runner/process.py:
   - ProcessRunner 类
   - 属性：service_config, state (Literal), process (asyncio.subprocess.Process), pid, log_buffer (deque maxlen=1000)
   - async start(): 设置 env（Python 项目 PATH 前置 .venv/bin）, create_subprocess_shell, 启动 _read_output task, emit PROCESS_STARTED
   - async stop(): SIGTERM → 5s timeout → SIGKILL, emit PROCESS_EXITED, state="STOPPED"
   - async restart(): stop + start
   - async _read_output(): 逐行读 stdout 和 stderr，每行 append 到 log_buffer 并 emit PROCESS_LOG/PROCESS_ERROR
   - 进程退出时检查 returncode，非零则 state="CRASHED" 并 emit PROCESS_EXITED
   - get_recent_logs(n) → list[str]

5. src/devpreview/runner/manager.py:
   - RunnerManager 类
   - runners: dict[str, ProcessRunner]
   - async start_all(services: list[ServiceConfig], event_bus: EventBus)
   - async stop_all()
   - async restart_service(name: str)
   - get_runner(name) → ProcessRunner

6. 修改 cli.py 的 preview 命令：
   - detect → install → 创建 EventBus → 创建 RunnerManager → start_all
   - 打印每个服务启动信息 T("starting_service") / T("service_running")
   - 使用 try/finally 确保 Ctrl+C 时调用 stop_all
   - 暂时 await asyncio.Event().wait() 保持运行

7. tests/test_runner.py:
   - 测试 ProcessRunner 启动一个 "python -c 'import time; time.sleep(10)'" 进程
   - 验证 start 后 state=="RUNNING"，pid > 0
   - 验证 stop 后 state=="STOPPED"
   - 验证 log_buffer 捕获输出

验收：
- devpreview preview . 在 FastAPI 项目中：检测 → 安装 → 启动 uvicorn → 终端显示日志 → Ctrl+C 优雅停止
- pytest tests/test_runner.py 通过
```

---

## PHASE 4 PROMPT

```
继续开发 devpreview，实现 Phase 4：Monitor 完整体系。严格按照 CLAUDE.md 规格。

需要创建/修改的文件：

1. src/devpreview/monitor/process_probe.py:
   - ProcessProbe 类
   - async probe(pid: int) → ProcessInfo
   - 使用 psutil.Process(pid) 获取 status, cpu_percent(interval=0.5), memory_info().rss, create_time
   - NoSuchProcess 异常 → 返回 status="dead"

2. src/devpreview/monitor/port_probe.py:
   - PortProbe 类
   - async probe(port: int) → PortInfo
   - 步骤 1: socket TCP connect 检测
   - 步骤 2: httpx GET http://localhost:{port}/ timeout=5s
   - 返回 status + response_time_ms + content_length + status_code

3. src/devpreview/monitor/healthcheck.py:
   - HealthCheckEngine 类
   - async check(port: int, project_type: str) → HealthResult
   - 基础检查：port_probe 结果
   - FastAPI 额外检查：/docs 和 /openapi.json
   - 聚合：HTTP_200 → HEALTHY, HTTP_5xx → DEGRADED, 其他 → FAILED

4. src/devpreview/monitor/simulator.py:
   - Simulator 类
   - async simulate(port: int) → SimulatorResult
   - GET http://localhost:{port}/ timeout=10s
   - checks: status_ok (200), has_content (len>100), has_html_tag ("<html" in lower)
   - passed = status_ok AND has_content

5. src/devpreview/monitor/aggregator.py:
   - RuntimeAggregator 类
   - 持有所有 probe 实例 + RunnerManager 引用 + EventBus 引用
   - async aggregate() → RuntimeState（遍历所有 service，逐个 probe，按状态机逻辑决策 overall_status）
   - async wait_until_ready(timeout=30) → RuntimeState（每秒轮询，直到 HEALTHY/DEGRADED/CRASHED 或超时）
   - 订阅 EventBus 的 PROCESS_EXITED 事件，立即触发 re-aggregate
   - async start_periodic_check(interval=2.0)：后台 task，定期 aggregate 并 emit STATE_CHANGED

6. 修改 cli.py:
   - preview: detect → install → start → 创建 aggregator → wait_until_ready → 打印最终状态
   - status: 加载 manifest → 创建 aggregator → aggregate → 输出 JSON（rich.print_json 或 json.dumps）

7. tests/test_monitor.py:
   - 测试 ProcessProbe 对当前进程的 probe
   - 测试 PortProbe 对一个未开放端口返回 CONNECTION_REFUSED
   - 测试 aggregator 状态机逻辑（mock process/port probe 结果）

验收：
- devpreview preview . 启动 FastAPI 后，终端显示 "HEALTHY" + 进程和端口信息
- devpreview status . 输出完整 RuntimeState JSON
- pytest tests/test_monitor.py 通过
```

---

## PHASE 5 PROMPT

```
继续开发 devpreview，实现 Phase 5：Dashboard + Reverse Proxy。严格按照 CLAUDE.md 规格。

需要创建/修改的文件：

1. src/devpreview/dashboard/__init__.py
2. src/devpreview/dashboard/proxy.py:
   - async def proxy_request(service_name, path, request, context) → Response
   - 查找 service.port，用 httpx AsyncClient 转发请求
   - 保持 method, headers, body
   - 处理 WebSocket 升级场景（MVP 可跳过，返回 501）
   - 错误时返回 502 + 错误信息

3. src/devpreview/dashboard/ws.py:
   - WebSocket /ws/logs: 从 runner.log_buffer 推送新增行，每 500ms 检查
   - WebSocket /ws/status: 每 2s 发送 aggregator.aggregate() 的 JSON

4. src/devpreview/dashboard/app.py:
   - create_dashboard_app(context: RuntimeContext) → FastAPI
   - 挂载所有路由（按 CLAUDE.md DASHBOARD API 节）
   - GET / → 返回 FileResponse(static/index.html)
   - GET /api/status, /api/logs, /api/manifest, /api/doctor, /api/i18n
   - POST /api/refresh, /api/restart/{service}, /api/stop, /api/lang/{locale}
   - GET /preview/{service_name}/{path:path} → proxy_request
   - CORS middleware: allow all origins（本地工具）

5. src/devpreview/dashboard/static/index.html:
   - 单文件 HTML+CSS+JS，深色主题
   - 按 CLAUDE.md DASHBOARD index.html SPEC 节实现
   - 顶部栏：DevPreview logo + session_id + 语言切换下拉框 (zh-CN/zh-TW/en)
   - 服务标签页：动态生成，点击切换 active service
   - 状态徽章：颜色 + 本地化文字
   - 指标行：CPU / MEM / Uptime / Port / Response Time
   - iframe 预览区：src="/preview/{active_service}/"，高度 50vh
   - 日志区：monospace，自动滚动，WebSocket /ws/logs
   - 按钮行：Refresh / Restart / Doctor / Stop
   - JS: fetch /api/i18n 获取文案，语言切换时 POST /api/lang/{locale} 并刷新文案
   - JS: WebSocket /ws/status 更新状态和指标
   - JS: WebSocket /ws/logs 追加日志行
   - 颜色：HEALTHY=#22c55e, DEGRADED=#f59e0b, FAILED=#ef4444, CRASHED=#ef4444, STARTING=#3b82f6
   - 背景色 #0f0f17，文字 #e4e4ef，卡片 #1a1a26，边框 #2a2a3a
   - 字体：monospace 为主，系统 sans-serif 辅助

6. 修改 cli.py preview:
   - 在 wait_until_ready 之后：
   - 创建 Dashboard app
   - 在后台线程启动 uvicorn.run(app, host="0.0.0.0", port=dashboard_port)
   - 打印 T("dashboard_started", url=...)
   - 调用 open_browser(url)
   - await asyncio.Event().wait() 保持运行

验收：
- devpreview preview . → 浏览器自动打开 Dashboard
- Dashboard 显示服务状态 + 指标
- iframe 通过 /preview/backend/ 正确显示应用
- 日志实时滚动
- 切换语言后界面文字变化
- Refresh 按钮触发刷新
```

---

## PHASE 6 PROMPT

```
继续开发 devpreview，实现 Phase 6：Doctor + Watcher + Runtime History + Sessions。严格按照 CLAUDE.md 规格。

需要创建/修改的文件：

1. src/devpreview/doctor/__init__.py
2. src/devpreview/doctor/diagnose.py:
   - DiagnosticEngine 类
   - async diagnose(context: RuntimeContext) → list[DiagnosticReport]
   - 遍历每个 service，基于其 ServiceRuntimeState 判断：
     - HEALTHY → reason="NONE", suggestion=T("doctor_healthy")
     - CRASHED → reason="PROCESS_CRASHED", details 含 exit_code + last_logs, suggestion=T("suggest_missing_dep") 或 T("suggest_check_logs")
     - FAILED → reason="PORT_NOT_RESPONDING", suggestion 含端口信息
     - DEGRADED → reason="HTTP_ERROR"
   - 每条 report 的 suggestion 使用 i18n T() 生成本地化建议

3. src/devpreview/runtime/__init__.py
4. src/devpreview/runtime/history.py:
   - save_session_history(session): 将 session 信息写入 .devpreview/sessions/{id}/manifest.json
   - list_session_history() → list[dict]: 扫描 sessions 目录，返回 id + detected_at + services
   - get_session_history(id) → dict

5. src/devpreview/runtime/snapshot.py:
   - save_snapshot(session_id, runtime_state): JSON 写入 sessions/{id}/snapshots/{timestamp}.json
   - load_latest_snapshot(session_id) → Optional[RuntimeState]

6. src/devpreview/watcher/__init__.py
7. src/devpreview/watcher/file_watcher.py:
   - DevPreviewWatcher 类
   - 使用 watchdog.observers.Observer + FileSystemEventHandler
   - 忽略 IGNORE_DIRS 中的路径
   - debounce DEBOUNCE_SECONDS
   - 变化时 emit EventType.FILE_CHANGED → 触发 refresh 逻辑

8. 修改 cli.py:
   - doctor: 创建 DiagnosticEngine → diagnose → 格式化输出（--json 时 print JSON，否则 rich 表格）
   - watch: 调用 preview 逻辑 + 启动 DevPreviewWatcher
   - sessions list: 调用 list_session_history → rich 表格显示
   - sessions show: 调用 get_session_history → 输出详情 + 最后一次 snapshot
   - refresh: 加载现有 manifest → re-detect → restart → re-monitor

9. tests/test_doctor.py:
   - mock RuntimeState 为 CRASHED → 验证 diagnose 返回 PROCESS_CRASHED reason
   - mock RuntimeState 为 HEALTHY → 验证 diagnose 返回 NONE reason
   - 验证 suggestion 在三个 locale 下都有值

10. 最后在 preview 流程中加入：
    - start 后每 30 秒自动 save_snapshot
    - stop 时 save 最终 snapshot

验收：
- devpreview doctor . 对崩溃的项目输出正确诊断（中/英文）
- devpreview doctor . --json 输出纯 JSON
- devpreview watch . 修改文件后 2 秒内自动刷新
- devpreview sessions list 显示历史
- devpreview sessions show {id} 显示详情
- pytest tests/test_doctor.py 通过

全部完成后，运行完整端到端测试：
1. mkdir /tmp/test-fastapi && cd /tmp/test-fastapi
2. 创建一个最小 FastAPI 项目（main.py + requirements.txt）
3. devpreview config lang zh-CN
4. devpreview preview .
5. 验证：浏览器打开 → Dashboard 中文显示 → iframe 显示 FastAPI 响应 → 日志滚动
6. 在 Dashboard 切换语言到 English → 界面变英文
7. 点击 Doctor → 显示 HEALTHY
8. Ctrl+C → 优雅停止
9. devpreview sessions list → 显示刚才的会话
```

---

# END OF BLUEPRINT

此文档同时作为项目的 CLAUDE.md 使用。
将其放在项目根目录，Claude Code 会在每次对话开始时自动读取。
