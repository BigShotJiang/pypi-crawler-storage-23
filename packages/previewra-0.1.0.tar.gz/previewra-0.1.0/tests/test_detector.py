"""Tests for the detector module."""

import json
import pytest
from pathlib import Path

from pvr.detector.registry import DetectorRegistry


class TestFastAPIDetector:
    def test_detect_fastapi_project(self, tmp_path: Path):
        main_py = tmp_path / "main.py"
        main_py.write_text(
            "from fastapi import FastAPI\n\napp = FastAPI()\n\n@app.get('/')\ndef root():\n    return {'hello': 'world'}\n"
        )
        (tmp_path / "requirements.txt").write_text("fastapi\nuvicorn\n")

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        svc = results[0]
        assert svc.project_type == "fastapi"
        assert svc.name == "backend"
        assert "uvicorn" in svc.start_command
        assert "main:app" in svc.start_command
        assert "--host 0.0.0.0" in svc.start_command
        assert svc.port == 8000
        assert svc.install_command == "pip install -r requirements.txt"

    def test_detect_fastapi_import_style(self, tmp_path: Path):
        app_py = tmp_path / "app.py"
        app_py.write_text("import fastapi\n\napp = fastapi.FastAPI()\n")

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        assert results[0].project_type == "fastapi"
        assert "app:app" in results[0].start_command


class TestFlaskDetector:
    def test_detect_flask_project(self, tmp_path: Path):
        app_py = tmp_path / "app.py"
        app_py.write_text(
            "from flask import Flask\n\napp = Flask(__name__)\n\n@app.route('/')\ndef hello():\n    return 'Hello'\n"
        )

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        svc = results[0]
        assert svc.project_type == "flask"
        assert svc.port == 5000
        assert "python app.py" in svc.start_command


class TestReactDetector:
    def test_detect_vite_react(self, tmp_path: Path):
        pkg = tmp_path / "package.json"
        pkg.write_text(json.dumps({
            "dependencies": {"react": "^18.0.0"},
            "devDependencies": {"vite": "^5.0.0"},
        }))

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        svc = results[0]
        assert svc.project_type == "react"
        assert svc.port == 5173
        assert "npm run dev" in svc.start_command
        assert "--host" in svc.start_command

    def test_detect_cra_react(self, tmp_path: Path):
        pkg = tmp_path / "package.json"
        pkg.write_text(json.dumps({
            "dependencies": {"react": "^18.0.0"},
        }))

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        svc = results[0]
        assert svc.project_type == "react"
        assert svc.port == 3000
        assert "npm start" in svc.start_command


class TestPythonScriptDetector:
    def test_detect_main_py(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("print('hello world')\n")

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        svc = results[0]
        assert svc.project_type == "python_script"
        assert svc.port is None
        assert "python main.py" in svc.start_command

    def test_fastapi_not_matched_as_script(self, tmp_path: Path):
        """FastAPI file should be detected as fastapi, not python_script."""
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\napp = FastAPI()\n"
        )

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        assert results[0].project_type == "fastapi"


class TestStaticDetector:
    def test_detect_static_site(self, tmp_path: Path):
        (tmp_path / "index.html").write_text("<html><body>Hello</body></html>")

        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        svc = results[0]
        assert svc.project_type == "static"
        assert svc.port == 8080
        assert "http.server" in svc.start_command


class TestEmptyDirectory:
    def test_detect_empty_dir(self, tmp_path: Path):
        registry = DetectorRegistry()
        results = registry.detect(tmp_path)
        assert results == []


class TestPriority:
    def test_fastapi_wins_over_script(self, tmp_path: Path):
        """FastAPI (priority=10) should win over python_script (priority=80)."""
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\napp = FastAPI()\n"
        )
        registry = DetectorRegistry()
        results = registry.detect(tmp_path)

        assert len(results) == 1
        assert results[0].project_type == "fastapi"
