"""Tests for the runner module."""

import asyncio
import sys

import pytest

from pvr.manifest.schema import ServiceConfig
from pvr.monitor.event_bus import EventBus, EventType
from pvr.runner.process import ProcessRunner


@pytest.fixture
def event_bus():
    return EventBus()


@pytest.fixture
def sleep_config():
    return ServiceConfig(
        name="test-sleep",
        project_type="python_script",
        start_command=f"{sys.executable} -c \"import time; print('started'); time.sleep(30)\"",
        port=None,
    )


@pytest.fixture
def echo_config():
    return ServiceConfig(
        name="test-echo",
        project_type="python_script",
        start_command=f"{sys.executable} -c \"import sys; print('hello stdout'); print('hello stderr', file=sys.stderr)\"",
        port=None,
    )


class TestProcessRunner:
    @pytest.mark.asyncio
    async def test_start_sets_running_state(self, event_bus, sleep_config, tmp_path):
        runner = ProcessRunner(sleep_config, event_bus, tmp_path)
        await runner.start()

        assert runner.state == "RUNNING"
        assert runner.pid is not None
        assert runner.pid > 0

        await runner.stop()

    @pytest.mark.asyncio
    async def test_stop_sets_stopped_state(self, event_bus, sleep_config, tmp_path):
        runner = ProcessRunner(sleep_config, event_bus, tmp_path)
        await runner.start()
        await runner.stop()

        assert runner.state == "STOPPED"

    @pytest.mark.asyncio
    async def test_log_buffer_captures_output(self, event_bus, echo_config, tmp_path):
        runner = ProcessRunner(echo_config, event_bus, tmp_path)
        await runner.start()

        # Wait for the process to finish and output to be read
        await asyncio.sleep(1.0)

        logs = runner.get_recent_logs()
        log_text = "\n".join(logs)
        assert "hello stdout" in log_text
        assert "hello stderr" in log_text

        await runner.stop()

    @pytest.mark.asyncio
    async def test_restart(self, event_bus, sleep_config, tmp_path):
        runner = ProcessRunner(sleep_config, event_bus, tmp_path)
        await runner.start()
        old_pid = runner.pid

        await runner.restart()

        assert runner.state == "RUNNING"
        assert runner.pid != old_pid

        await runner.stop()

    @pytest.mark.asyncio
    async def test_event_bus_receives_started(self, event_bus, sleep_config, tmp_path):
        events = []

        async def on_started(payload):
            events.append(payload)

        event_bus.subscribe(EventType.PROCESS_STARTED, on_started)

        runner = ProcessRunner(sleep_config, event_bus, tmp_path)
        await runner.start()

        assert len(events) == 1
        assert events[0]["name"] == "test-sleep"
        assert events[0]["pid"] > 0

        await runner.stop()

    @pytest.mark.asyncio
    async def test_crashed_process_sets_crashed_state(self, event_bus, tmp_path):
        config = ServiceConfig(
            name="test-crash",
            project_type="python_script",
            start_command=f"{sys.executable} -c \"raise SystemExit(1)\"",
            port=None,
        )
        runner = ProcessRunner(config, event_bus, tmp_path)
        await runner.start()

        # Wait for the process to crash and the _read_output task to detect it
        await asyncio.sleep(1.0)

        assert runner.state == "CRASHED"

    @pytest.mark.asyncio
    async def test_get_recent_logs_limit(self, event_bus, tmp_path):
        config = ServiceConfig(
            name="test-many-lines",
            project_type="python_script",
            start_command=f"{sys.executable} -c \"[print(f'line {{i}}') for i in range(20)]\"",
            port=None,
        )
        runner = ProcessRunner(config, event_bus, tmp_path)
        await runner.start()
        await asyncio.sleep(1.0)

        logs_5 = runner.get_recent_logs(5)
        assert len(logs_5) == 5
        assert logs_5[-1] == "line 19"

        await runner.stop()


class TestEventBus:
    @pytest.mark.asyncio
    async def test_subscribe_and_emit(self):
        bus = EventBus()
        received = []

        async def handler(payload):
            received.append(payload)

        bus.subscribe(EventType.PROCESS_LOG, handler)
        await bus.emit(EventType.PROCESS_LOG, {"line": "test"})

        assert len(received) == 1
        assert received[0]["line"] == "test"

    @pytest.mark.asyncio
    async def test_emit_no_subscribers(self):
        bus = EventBus()
        # Should not raise
        await bus.emit(EventType.PORT_OPEN, {"port": 8000})

    @pytest.mark.asyncio
    async def test_multiple_handlers(self):
        bus = EventBus()
        results = []

        async def h1(p):
            results.append("h1")

        async def h2(p):
            results.append("h2")

        bus.subscribe(EventType.STATE_CHANGED, h1)
        bus.subscribe(EventType.STATE_CHANGED, h2)
        await bus.emit(EventType.STATE_CHANGED, {})

        assert set(results) == {"h1", "h2"}
