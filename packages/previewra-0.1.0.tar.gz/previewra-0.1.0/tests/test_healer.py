"""Tests for the AI self-correction healer."""

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pvr.ai.config import AIConfig
from pvr.ai.healer import AutoHealer, _collect_project_context, _build_prompt
from pvr.i18n import set_locale
from pvr.manifest.schema import ServiceConfig, RuntimeState, ServiceRuntimeState


DUMMY_CFG = AIConfig(api_key="test-key", base_url="https://api.example.com/v1", model="test-model")


def make_service(name="backend", project_type="fastapi", port=8000):
    return ServiceConfig(
        name=name,
        project_type=project_type,
        start_command=f"uvicorn {name}:app --port {port}",
        port=port,
    )


def make_state(service_name="backend", status="CRASHED"):
    return RuntimeState(
        session_id="test-session",
        services={service_name: ServiceRuntimeState(name=service_name, status=status)},
        overall_status=status,
        timestamp="2026-01-01T00:00:00",
    )


def make_runner_manager(logs=None):
    rm = MagicMock()
    runner = MagicMock()
    runner.get_recent_logs.return_value = logs or []
    rm.get_runner.return_value = runner
    return rm


def ai_resp(*, analysis="fix", cannot_fix=False, start_command=None,
            install_command=None, port=None, env=None, confidence=0.9):
    return "```json\n" + json.dumps({
        "analysis": analysis,
        "cannot_fix": cannot_fix,
        "start_command": start_command,
        "install_command": install_command,
        "port": port,
        "env": env or {},
        "confidence": confidence,
    }) + "\n```"


# ---------------------------------------------------------------------------
# _collect_project_context
# ---------------------------------------------------------------------------

class TestCollectProjectContext:

    def test_config_file_content_included(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("fastapi\nuvicorn")
        ctx = _collect_project_context(tmp_path)
        assert "requirements.txt" in ctx["config_files"]
        assert "fastapi" in ctx["config_files"]["requirements.txt"]

    def test_source_code_content_not_included(self, tmp_path):
        """Source files must appear in source_files list, never in config_files."""
        (tmp_path / "main.py").write_text("SECRET = 'top-secret'\napp = FastAPI()")
        ctx = _collect_project_context(tmp_path)
        assert "main.py" not in ctx["config_files"]
        assert "main.py" in ctx["source_files"]

    def test_source_files_listed_by_name(self, tmp_path):
        (tmp_path / "app.py").write_text("x=1")
        (tmp_path / "utils.py").write_text("y=2")
        ctx = _collect_project_context(tmp_path)
        assert "app.py" in ctx["source_files"]
        assert "utils.py" in ctx["source_files"]

    def test_ignored_dirs_excluded(self, tmp_path):
        for d in (".venv", "node_modules", "__pycache__"):
            (tmp_path / d).mkdir()
            (tmp_path / d / "internal.py").write_text("x=1")
        (tmp_path / "app.py").write_text("real")
        ctx = _collect_project_context(tmp_path)
        names = [Path(f).name for f in ctx["source_files"]]
        assert "internal.py" not in names
        assert "app.py" in names

    def test_package_json_included(self, tmp_path):
        (tmp_path / "package.json").write_text('{"dependencies":{"react":"^18"}}')
        ctx = _collect_project_context(tmp_path)
        assert "package.json" in ctx["config_files"]


# ---------------------------------------------------------------------------
# _build_prompt
# ---------------------------------------------------------------------------

class TestBuildPrompt:

    def test_scope_restriction_present(self, tmp_path):
        prompt = _build_prompt(tmp_path, make_service(), [], _collect_project_context(tmp_path))
        assert "STRICT PROHIBITIONS" in prompt
        assert "source code" in prompt.lower()

    def test_cannot_fix_field_documented(self, tmp_path):
        prompt = _build_prompt(tmp_path, make_service(), [], _collect_project_context(tmp_path))
        assert "cannot_fix" in prompt

    def test_current_config_in_prompt(self, tmp_path):
        svc = make_service(name="api", port=9000)
        prompt = _build_prompt(tmp_path, svc, [], _collect_project_context(tmp_path))
        assert "api" in prompt
        assert "9000" in prompt

    def test_error_logs_in_prompt(self, tmp_path):
        logs = ["ModuleNotFoundError: No module named 'uvicorn'"]
        prompt = _build_prompt(tmp_path, make_service(), logs, _collect_project_context(tmp_path))
        assert "ModuleNotFoundError" in prompt


# ---------------------------------------------------------------------------
# AutoHealer.heal()
# ---------------------------------------------------------------------------

class TestAutoHealerHeal:

    @pytest.mark.asyncio
    async def test_fix_applied_when_ai_returns_valid_command(self, tmp_path):
        svc = make_service()
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(
                return_value=ai_resp(start_command="uvicorn backend:app --host 0.0.0.0 --port 8000")
            )
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        assert result is not None
        assert "--host 0.0.0.0" in result[0].start_command

    @pytest.mark.asyncio
    async def test_port_corrected(self, tmp_path):
        svc = make_service(port=8000)
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(
                return_value=ai_resp(port=8080, analysis="Project listens on 8080")
            )
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        assert result is not None
        assert result[0].port == 8080

    @pytest.mark.asyncio
    async def test_env_merged(self, tmp_path):
        svc = make_service()
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(
                return_value=ai_resp(env={"PYTHONPATH": "."})
            )
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        assert result is not None
        assert result[0].env.get("PYTHONPATH") == "."

    @pytest.mark.asyncio
    async def test_cannot_fix_returns_none(self, tmp_path):
        """AI says root cause is user code → no changes made."""
        svc = make_service()
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(
                return_value=ai_resp(cannot_fix=True, analysis="SyntaxError in main.py", confidence=0.0)
            )
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        assert result is None

    @pytest.mark.asyncio
    async def test_cannot_fix_logs_i18n_message(self, tmp_path):
        """cannot_fix warning should use the localized ai_heal_cannot_fix key."""
        set_locale("zh-CN")
        svc = make_service()
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient, \
             patch("pvr.ai.healer.log_warn") as mock_warn:
            MockClient.return_value.complete = AsyncMock(
                return_value=ai_resp(cannot_fix=True, analysis="用户代码有 ImportError", confidence=0.0)
            )
            await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        warned = mock_warn.call_args[0][0]
        # Should contain the i18n text (zh-CN)
        assert "previewra" in warned
        assert "超出" in warned

    @pytest.mark.asyncio
    async def test_low_confidence_returns_none(self, tmp_path):
        svc = make_service()
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(
                return_value=ai_resp(start_command="python main.py", confidence=0.2)
            )
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        assert result is None

    @pytest.mark.asyncio
    async def test_degraded_service_skipped(self, tmp_path):
        """DEGRADED = user app error, healer must not call AI at all."""
        svc = make_service()
        state = make_state(status="DEGRADED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock()
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        MockClient.return_value.complete.assert_not_called()
        assert result is None

    @pytest.mark.asyncio
    async def test_healthy_service_skipped(self, tmp_path):
        svc = make_service()
        state = make_state(status="HEALTHY")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock()
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        MockClient.return_value.complete.assert_not_called()
        assert result is None

    @pytest.mark.asyncio
    async def test_ai_request_failure_returns_none(self, tmp_path):
        svc = make_service()
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(side_effect=Exception("network error"))
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        assert result is None

    @pytest.mark.asyncio
    async def test_unparseable_response_returns_none(self, tmp_path):
        svc = make_service()
        state = make_state(status="CRASHED")

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(return_value="Sorry, I cannot help.")
            result = await AutoHealer().heal(tmp_path, [svc], make_runner_manager(), state, DUMMY_CFG)

        assert result is None

    @pytest.mark.asyncio
    async def test_only_crashed_service_in_multi_service_state(self, tmp_path):
        """Only CRASHED services get fixed; HEALTHY ones are untouched."""
        svc_ok = make_service(name="frontend", project_type="react", port=3000)
        svc_bad = make_service(name="backend", project_type="fastapi", port=8000)
        state = RuntimeState(
            session_id="multi",
            services={
                "frontend": ServiceRuntimeState(name="frontend", status="HEALTHY"),
                "backend": ServiceRuntimeState(name="backend", status="CRASHED"),
            },
            overall_status="CRASHED",
            timestamp="2026-01-01T00:00:00",
        )

        with patch("pvr.ai.healer.AIClient") as MockClient:
            MockClient.return_value.complete = AsyncMock(
                return_value=ai_resp(start_command="uvicorn backend:app --host 0.0.0.0 --port 8000")
            )
            result = await AutoHealer().heal(
                tmp_path, [svc_ok, svc_bad], make_runner_manager(), state, DUMMY_CFG
            )

        assert result is not None
        # frontend untouched
        assert result[0].start_command == svc_ok.start_command
        # backend fixed
        assert "--host 0.0.0.0" in result[1].start_command
        # AI called exactly once (only for backend)
        assert MockClient.return_value.complete.call_count == 1
