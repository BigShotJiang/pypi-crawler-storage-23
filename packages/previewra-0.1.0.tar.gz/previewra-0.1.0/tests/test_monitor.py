"""Tests for the monitor module."""

import asyncio
import os
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pvr.manifest.schema import (
    HealthResult,
    PortInfo,
    ProcessInfo,
    RuntimeState,
    ServiceRuntimeState,
)
from pvr.monitor.event_bus import EventBus
from pvr.monitor.port_probe import PortProbe
from pvr.monitor.process_probe import ProcessProbe


class TestProcessProbe:
    @pytest.mark.asyncio
    async def test_probe_current_process(self):
        """Probing the current process should return a running status."""
        probe = ProcessProbe()
        info = await probe.probe(os.getpid())

        assert info.pid == os.getpid()
        assert info.status in ("running", "sleeping", "idle", "disk-sleep")
        assert info.memory_mb > 0
        assert info.uptime_seconds >= 0

    @pytest.mark.asyncio
    async def test_probe_dead_process(self):
        """Probing a non-existent PID should return status='dead'."""
        probe = ProcessProbe()
        info = await probe.probe(999999)

        assert info.status == "dead"


class TestPortProbe:
    @pytest.mark.asyncio
    async def test_probe_closed_port(self):
        """Probing a port that's not open should return CONNECTION_REFUSED."""
        probe = PortProbe()
        info = await probe.probe(19999)

        assert info.status == "CONNECTION_REFUSED"
        assert info.port == 19999


class TestAggregatorStateMachine:
    """Test the aggregator's state decision logic without running real services."""

    def test_crashed_when_process_dead(self):
        """Process dead → CRASHED."""
        proc = ProcessInfo(pid=1, status="dead")
        svc = ServiceRuntimeState(name="test")
        svc.process = proc

        if proc.status == "dead":
            svc.status = "CRASHED"

        assert svc.status == "CRASHED"

    def test_failed_when_port_refused(self):
        """Port CONNECTION_REFUSED → FAILED."""
        port = PortInfo(port=8000, status="CONNECTION_REFUSED")
        svc = ServiceRuntimeState(name="test")
        svc.port = port

        if port.status == "CONNECTION_REFUSED":
            svc.status = "FAILED"

        assert svc.status == "FAILED"

    def test_degraded_when_http_500(self):
        """Port HTTP_500 → DEGRADED."""
        port = PortInfo(port=8000, status="HTTP_500", status_code=500)
        svc = ServiceRuntimeState(name="test")
        svc.port = port

        if port.status == "HTTP_500":
            svc.status = "DEGRADED"

        assert svc.status == "DEGRADED"

    def test_healthy_when_all_ok(self):
        """HTTP_200 + HEALTHY health → HEALTHY."""
        port = PortInfo(port=8000, status="HTTP_200", status_code=200, response_time_ms=50)
        health = HealthResult(status="HEALTHY", checks=[])
        svc = ServiceRuntimeState(name="test")
        svc.port = port
        svc.health = health

        if health.status == "HEALTHY":
            svc.status = "HEALTHY"

        assert svc.status == "HEALTHY"

    def test_overall_crashed_if_any_crashed(self):
        """Overall status is CRASHED if any service is CRASHED."""
        services = {
            "a": ServiceRuntimeState(name="a", status="HEALTHY"),
            "b": ServiceRuntimeState(name="b", status="CRASHED"),
        }
        statuses = {s.status for s in services.values()}

        if "CRASHED" in statuses:
            overall = "CRASHED"
        elif "FAILED" in statuses:
            overall = "FAILED"
        elif "DEGRADED" in statuses:
            overall = "DEGRADED"
        else:
            overall = "HEALTHY"

        assert overall == "CRASHED"

    def test_overall_healthy_when_all_healthy(self):
        """Overall status is HEALTHY when all services are HEALTHY."""
        services = {
            "a": ServiceRuntimeState(name="a", status="HEALTHY"),
            "b": ServiceRuntimeState(name="b", status="HEALTHY"),
        }
        statuses = {s.status for s in services.values()}

        if "CRASHED" in statuses:
            overall = "CRASHED"
        elif "FAILED" in statuses:
            overall = "FAILED"
        elif "DEGRADED" in statuses:
            overall = "DEGRADED"
        else:
            overall = "HEALTHY"

        assert overall == "HEALTHY"

    def test_overall_degraded_if_any_degraded(self):
        """Overall is DEGRADED if any service is DEGRADED."""
        services = {
            "a": ServiceRuntimeState(name="a", status="HEALTHY"),
            "b": ServiceRuntimeState(name="b", status="DEGRADED"),
        }
        statuses = {s.status for s in services.values()}

        if "CRASHED" in statuses:
            overall = "CRASHED"
        elif "FAILED" in statuses:
            overall = "FAILED"
        elif "DEGRADED" in statuses:
            overall = "DEGRADED"
        else:
            overall = "HEALTHY"

        assert overall == "DEGRADED"
