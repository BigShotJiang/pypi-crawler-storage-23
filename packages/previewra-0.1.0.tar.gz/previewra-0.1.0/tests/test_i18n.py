"""Tests for the i18n module."""

import pytest
from pvr.i18n import T, set_locale, get_locale


class TestI18nBasic:
    """Test basic i18n functionality."""

    def test_default_locale_is_en(self):
        set_locale("en")
        assert get_locale() == "en"

    def test_set_locale_zh_cn(self):
        set_locale("zh-CN")
        assert get_locale() == "zh-CN"

    def test_set_locale_zh_tw(self):
        set_locale("zh-TW")
        assert get_locale() == "zh-TW"

    def test_invalid_locale_falls_back_to_en(self):
        set_locale("xx-YY")
        assert get_locale() == "en"


class TestI18nTranslation:
    """Test T() returns correct strings for each locale."""

    def test_en_detecting_project(self):
        set_locale("en")
        assert T("detecting_project") == "Detecting project type..."

    def test_zh_cn_detecting_project(self):
        set_locale("zh-CN")
        assert T("detecting_project") == "正在检测项目类型..."

    def test_zh_tw_detecting_project(self):
        set_locale("zh-TW")
        assert T("detecting_project") == "正在偵測專案類型..."

    def test_en_all_stopped(self):
        set_locale("en")
        assert T("all_stopped") == "All services stopped"

    def test_zh_cn_all_stopped(self):
        set_locale("zh-CN")
        assert T("all_stopped") == "所有服务已停止"

    def test_zh_tw_all_stopped(self):
        set_locale("zh-TW")
        assert T("all_stopped") == "所有服務已停止"


class TestI18nVariableSubstitution:
    """Test T() with variable substitution."""

    def test_en_detected_as(self):
        set_locale("en")
        result = T("detected_as", project_type="fastapi")
        assert result == "Detected as: fastapi"

    def test_zh_cn_detected_as(self):
        set_locale("zh-CN")
        result = T("detected_as", project_type="fastapi")
        assert result == "检测到项目类型：fastapi"

    def test_en_service_running(self):
        set_locale("en")
        result = T("service_running", name="backend", port=8000)
        assert result == "backend running on port 8000"

    def test_zh_cn_port_in_use(self):
        set_locale("zh-CN")
        result = T("port_in_use", port=8000, new_port=8001)
        assert result == "端口 8000 已被占用，切换到 8001"

    def test_missing_key_returns_key(self):
        set_locale("en")
        assert T("nonexistent_key") == "nonexistent_key"


class TestI18nAllKeysPresent:
    """Ensure all three locale files have the same keys."""

    def test_all_locales_have_same_keys(self):
        import json
        from pathlib import Path

        messages_dir = Path(__file__).parent.parent / "src" / "pvr" / "i18n" / "messages"
        locales = {}
        for name in ("en.json", "zh_CN.json", "zh_TW.json"):
            with open(messages_dir / name, encoding="utf-8") as f:
                locales[name] = set(json.load(f).keys())

        assert locales["en.json"] == locales["zh_CN.json"], "zh_CN missing keys"
        assert locales["en.json"] == locales["zh_TW.json"], "zh_TW missing keys"
