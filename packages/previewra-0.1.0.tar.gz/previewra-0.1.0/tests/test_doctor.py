"""Tests for the doctor/diagnose module."""

import pytest

from pvr.i18n import T, set_locale
from pvr.manifest.schema import (
    RuntimeState,
    ServiceRuntimeState,
    ProcessInfo,
    PortInfo,
    HealthResult,
)
from pvr.doctor.diagnose import diagnose_from_state


class TestDiagnoseCrashed:
    @pytest.mark.asyncio
    async def test_crashed_returns_process_crashed(self):
        state = RuntimeState(
            session_id="test-123",
            services={
                "backend": ServiceRuntimeState(
                    name="backend",
                    status="CRASHED",
                    process=ProcessInfo(pid=1, status="dead"),
                ),
            },
            overall_status="CRASHED",
            timestamp="2026-01-01T00:00:00",
        )
        set_locale("en")
        reports = await diagnose_from_state(state)

        assert len(reports) == 1
        assert reports[0].reason == "PROCESS_CRASHED"
        assert reports[0].status == "CRASHED"
        assert reports[0].service == "backend"


class TestDiagnoseHealthy:
    @pytest.mark.asyncio
    async def test_healthy_returns_none_reason(self):
        state = RuntimeState(
            session_id="test-456",
            services={
                "backend": ServiceRuntimeState(
                    name="backend",
                    status="HEALTHY",
                    process=ProcessInfo(pid=100, status="running", cpu_percent=1.0, memory_mb=50.0),
                    port=PortInfo(port=8000, status="HTTP_200", response_time_ms=20, status_code=200),
                    health=HealthResult(status="HEALTHY"),
                ),
            },
            overall_status="HEALTHY",
            timestamp="2026-01-01T00:00:00",
        )
        set_locale("en")
        reports = await diagnose_from_state(state)

        assert len(reports) == 1
        assert reports[0].reason == "NONE"
        assert reports[0].suggestion == "All services are healthy"


class TestDiagnoseFailed:
    @pytest.mark.asyncio
    async def test_failed_returns_port_not_responding(self):
        state = RuntimeState(
            session_id="test-789",
            services={
                "api": ServiceRuntimeState(
                    name="api",
                    status="FAILED",
                    port=PortInfo(port=8000, status="CONNECTION_REFUSED"),
                ),
            },
            overall_status="FAILED",
            timestamp="2026-01-01T00:00:00",
        )
        set_locale("en")
        reports = await diagnose_from_state(state)

        assert len(reports) == 1
        assert reports[0].reason == "PORT_NOT_RESPONDING"


class TestDiagnoseDegraded:
    @pytest.mark.asyncio
    async def test_degraded_returns_http_error(self):
        state = RuntimeState(
            session_id="test-abc",
            services={
                "web": ServiceRuntimeState(
                    name="web",
                    status="DEGRADED",
                    port=PortInfo(port=3000, status="HTTP_500", status_code=500),
                ),
            },
            overall_status="DEGRADED",
            timestamp="2026-01-01T00:00:00",
        )
        set_locale("en")
        reports = await diagnose_from_state(state)

        assert len(reports) == 1
        assert reports[0].reason == "HTTP_ERROR"


class TestDiagnoseI18n:
    @pytest.mark.asyncio
    async def test_suggestion_in_all_locales(self):
        state = RuntimeState(
            session_id="test-i18n",
            services={
                "svc": ServiceRuntimeState(name="svc", status="HEALTHY"),
            },
            overall_status="HEALTHY",
            timestamp="2026-01-01T00:00:00",
        )

        for locale in ("en", "zh-CN", "zh-TW"):
            set_locale(locale)
            reports = await diagnose_from_state(state)
            assert len(reports) == 1
            assert reports[0].suggestion  # non-empty

    @pytest.mark.asyncio
    async def test_crashed_suggestion_in_zh_cn(self):
        state = RuntimeState(
            session_id="test-zh",
            services={
                "svc": ServiceRuntimeState(name="svc", status="CRASHED"),
            },
            overall_status="CRASHED",
            timestamp="2026-01-01T00:00:00",
        )
        set_locale("zh-CN")
        reports = await diagnose_from_state(state)
        assert "pvr status" in reports[0].suggestion


class TestDiagnoseMultiService:
    @pytest.mark.asyncio
    async def test_multiple_services(self):
        state = RuntimeState(
            session_id="multi",
            services={
                "frontend": ServiceRuntimeState(name="frontend", status="HEALTHY"),
                "backend": ServiceRuntimeState(name="backend", status="CRASHED"),
            },
            overall_status="CRASHED",
            timestamp="2026-01-01T00:00:00",
        )
        set_locale("en")
        reports = await diagnose_from_state(state)

        assert len(reports) == 2
        reasons = {r.service: r.reason for r in reports}
        assert reasons["frontend"] == "NONE"
        assert reasons["backend"] == "PROCESS_CRASHED"
