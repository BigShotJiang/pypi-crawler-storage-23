"""FastAPI project detector."""

from pathlib import Path
from typing import Optional

from pvr.config import DEFAULT_FASTAPI_PORT, IGNORE_DIRS
from pvr.detector.base import BaseDetector, DetectionResult


class FastAPIDetector(BaseDetector):
    name = "fastapi"
    priority = 10

    def detect(self, path: Path) -> Optional[DetectionResult]:
        py_files = [
            f for f in path.iterdir()
            if f.is_file() and f.suffix == ".py" and f.name not in IGNORE_DIRS
        ]

        fastapi_file: Optional[Path] = None
        app_file: Optional[Path] = None

        for f in py_files:
            try:
                lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()[:50]
            except OSError:
                continue

            content = "\n".join(lines)

            if "from fastapi" in content or "import fastapi" in content:
                if fastapi_file is None:
                    fastapi_file = f
                if "FastAPI(" in content:
                    app_file = f

        if fastapi_file is None:
            return None

        entry = app_file or fastapi_file
        stem = entry.stem
        port = DEFAULT_FASTAPI_PORT

        install_cmd = None
        if (path / "requirements.txt").exists():
            install_cmd = "pip install -r requirements.txt"

        return DetectionResult(
            project_type="fastapi",
            name="backend",
            start_command=f"uvicorn {stem}:app --host 0.0.0.0 --port {port} --reload",
            port=port,
            install_command=install_cmd,
        )
