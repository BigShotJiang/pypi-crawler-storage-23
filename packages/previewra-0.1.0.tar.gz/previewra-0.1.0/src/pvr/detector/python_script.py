"""Generic Python script detector."""

from pathlib import Path
from typing import Optional

from pvr.detector.base import BaseDetector, DetectionResult


class PythonScriptDetector(BaseDetector):
    name = "python_script"
    priority = 80

    def detect(self, path: Path) -> Optional[DetectionResult]:
        candidates = [path / "main.py", path / "app.py"]
        target: Optional[Path] = None

        for f in candidates:
            if not f.exists():
                continue

            try:
                lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()[:50]
            except OSError:
                continue

            content = "\n".join(lines)

            # Exclude files already matched by fastapi/flask detectors
            if "from fastapi" in content or "import fastapi" in content:
                continue
            if "from flask" in content or "import flask" in content:
                continue

            target = f
            break

        if target is None:
            return None

        install_cmd = None
        if (path / "requirements.txt").exists():
            install_cmd = "pip install -r requirements.txt"

        return DetectionResult(
            project_type="python_script",
            name="script",
            start_command=f"python {target.name}",
            port=None,
            install_command=install_cmd,
        )
