"""Static site detector."""

from pathlib import Path
from typing import Optional

from pvr.config import DEFAULT_STATIC_PORT
from pvr.detector.base import BaseDetector, DetectionResult


class StaticDetector(BaseDetector):
    name = "static"
    priority = 90

    def detect(self, path: Path) -> Optional[DetectionResult]:
        if not (path / "index.html").exists():
            return None

        port = DEFAULT_STATIC_PORT
        return DetectionResult(
            project_type="static",
            name="static",
            start_command=f"python -m http.server {port} --bind 0.0.0.0",
            port=port,
        )
