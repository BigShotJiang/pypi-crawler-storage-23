"""Detector registry — auto-discovers and runs all detectors."""

from pathlib import Path

from pvr.detector.base import BaseDetector, DetectionResult
from pvr.detector.fastapi_ import FastAPIDetector
from pvr.detector.flask_ import FlaskDetector
from pvr.detector.react import ReactDetector
from pvr.detector.node import NodeDetector
from pvr.detector.python_script import PythonScriptDetector
from pvr.detector.static import StaticDetector
from pvr.manifest.schema import ServiceConfig


class DetectorRegistry:
    """Registry of all project detectors, ordered by priority."""

    def __init__(self) -> None:
        self.detectors: list[BaseDetector] = sorted(
            [
                FastAPIDetector(),
                FlaskDetector(),
                ReactDetector(),
                NodeDetector(),
                PythonScriptDetector(),
                StaticDetector(),
            ],
            key=lambda d: d.priority,
        )

    def detect(self, path: Path) -> list[ServiceConfig]:
        """Run all detectors against a path. MVP: return only the first (highest priority) match."""
        results: list[ServiceConfig] = []

        for detector in self.detectors:
            result = detector.detect(path)
            if result is not None:
                config = ServiceConfig(
                    name=result.name,
                    project_type=result.project_type,
                    start_command=result.start_command,
                    install_command=result.install_command,
                    port=result.port,
                    env=result.env,
                    working_dir=result.working_dir,
                )
                results.append(config)
                # MVP: take only the highest-priority match
                break

        return results
