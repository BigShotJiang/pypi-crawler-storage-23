"""Flask project detector."""

from pathlib import Path
from typing import Optional

from pvr.config import DEFAULT_FLASK_PORT, IGNORE_DIRS
from pvr.detector.base import BaseDetector, DetectionResult


class FlaskDetector(BaseDetector):
    name = "flask"
    priority = 20

    def detect(self, path: Path) -> Optional[DetectionResult]:
        flask_file: Optional[Path] = None

        # 1. Scan top-level .py files
        py_files = [
            f for f in path.iterdir()
            if f.is_file() and f.suffix == ".py" and f.name not in IGNORE_DIRS
        ]

        for f in py_files:
            try:
                lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()[:50]
            except OSError:
                continue

            content = "\n".join(lines)

            if "from flask" in content or "import flask" in content:
                flask_file = f
                break

        # 2. Scan immediate subdirectories for Flask imports (e.g. routes/, views/)
        if flask_file is None:
            entry_candidates = [path / "app.py", path / "main.py"]
            for entry in entry_candidates:
                if not entry.exists():
                    continue
                # Check subdirs for flask imports
                for subdir in path.iterdir():
                    if not subdir.is_dir() or subdir.name in IGNORE_DIRS or subdir.name.startswith("."):
                        continue
                    for f in subdir.iterdir():
                        if not f.is_file() or f.suffix != ".py":
                            continue
                        try:
                            lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()[:50]
                        except OSError:
                            continue
                        content = "\n".join(lines)
                        if "from flask" in content or "import flask" in content:
                            flask_file = entry
                            break
                    if flask_file is not None:
                        break
                if flask_file is not None:
                    break

        # 3. Fallback: check requirements.txt for flask
        if flask_file is None:
            req_file = path / "requirements.txt"
            if req_file.exists():
                try:
                    req_content = req_file.read_text(encoding="utf-8", errors="ignore").lower()
                    if "flask" in req_content:
                        for candidate in [path / "app.py", path / "main.py"]:
                            if candidate.exists():
                                flask_file = candidate
                                break
                except OSError:
                    pass

        if flask_file is None:
            return None

        install_cmd = None
        if (path / "requirements.txt").exists():
            install_cmd = "pip install -r requirements.txt"

        return DetectionResult(
            project_type="flask",
            name="backend",
            start_command=f"python {flask_file.name}",
            port=DEFAULT_FLASK_PORT,
            install_command=install_cmd,
        )
