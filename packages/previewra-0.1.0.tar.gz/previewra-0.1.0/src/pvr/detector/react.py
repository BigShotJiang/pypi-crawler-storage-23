"""React/Vite project detector."""

import json
from pathlib import Path
from typing import Optional

from pvr.config import DEFAULT_VITE_PORT, DEFAULT_CRA_PORT
from pvr.detector.base import BaseDetector, DetectionResult


class ReactDetector(BaseDetector):
    name = "react"
    priority = 30

    def detect(self, path: Path) -> Optional[DetectionResult]:
        pkg_json = path / "package.json"
        if not pkg_json.exists():
            return None

        try:
            with open(pkg_json, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            return None

        deps = data.get("dependencies", {})
        dev_deps = data.get("devDependencies", {})
        all_deps = {**deps, **dev_deps}

        has_react = "react" in all_deps
        has_vite = "vite" in all_deps

        if not has_react and not has_vite:
            return None

        if has_vite:
            return DetectionResult(
                project_type="react",
                name="frontend",
                start_command="npm run dev -- --host 0.0.0.0",
                port=DEFAULT_VITE_PORT,
                install_command="npm install",
            )
        else:
            return DetectionResult(
                project_type="react",
                name="frontend",
                start_command="npm start",
                port=DEFAULT_CRA_PORT,
                install_command="npm install",
            )
