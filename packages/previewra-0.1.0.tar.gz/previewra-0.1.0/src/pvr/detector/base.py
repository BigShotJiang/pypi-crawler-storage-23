"""Base detector ABC and DetectionResult model."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from pydantic import BaseModel


class DetectionResult(BaseModel):
    project_type: str
    name: str
    start_command: str
    port: Optional[int] = None
    install_command: Optional[str] = None
    env: dict[str, str] = {}
    working_dir: Optional[str] = None


class BaseDetector(ABC):
    """Abstract base class for project detectors."""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def priority(self) -> int: ...

    @abstractmethod
    def detect(self, path: Path) -> Optional[DetectionResult]:
        """Detect project type at the given path. Returns None if not matched."""
        ...
