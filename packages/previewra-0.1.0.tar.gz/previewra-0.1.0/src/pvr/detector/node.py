"""Generic Node.js / TypeScript project detector."""

import json
from pathlib import Path
from typing import Optional

from pvr.config import DEFAULT_CRA_PORT
from pvr.detector.base import BaseDetector, DetectionResult


class NodeDetector(BaseDetector):
    """Detects generic Node.js/TypeScript projects (non-React/Vite).

    Matches any project with a package.json that has a 'dev' or 'server' script,
    but is NOT already matched by the ReactDetector (no react/vite dependency).
    Priority 40 — runs after React (30) but before python_script (80).
    """

    name = "node"
    priority = 40

    def detect(self, path: Path) -> Optional[DetectionResult]:
        pkg_json = path / "package.json"
        if not pkg_json.exists():
            return None

        try:
            with open(pkg_json, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            return None

        deps = data.get("dependencies", {})
        dev_deps = data.get("devDependencies", {})
        all_deps = {**deps, **dev_deps}

        # Skip if already handled by ReactDetector
        if "react" in all_deps or "vite" in all_deps:
            return None

        scripts = data.get("scripts", {})

        # Prefer 'dev', then 'server', then 'start'
        for script_name in ("dev", "server", "start"):
            if script_name in scripts:
                # Detect package manager
                pkg_manager = "npm"
                if (path / "pnpm-lock.yaml").exists():
                    pkg_manager = "pnpm"
                elif (path / "yarn.lock").exists():
                    pkg_manager = "yarn"

                install_cmd = f"{pkg_manager} install"

                return DetectionResult(
                    project_type="node",
                    name="app",
                    start_command=f"{pkg_manager} run {script_name}",
                    port=DEFAULT_CRA_PORT,
                    install_command=install_cmd,
                )

        return None
