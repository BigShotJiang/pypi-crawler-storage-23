"""AI provider configuration for Auto-Heal."""

import os
import json
from pathlib import Path
from typing import Optional

from pydantic import BaseModel


class AIConfig(BaseModel):
    model: str = "moonshot-v1-8k"
    api_key: str = ""
    base_url: str = "https://api.moonshot.cn/v1"
    provider: str = ""


PRESETS: dict[str, dict] = {
    "kimi": {
        "base_url": "https://api.moonshot.cn/v1",
        "model": "moonshot-v1-8k",
        "models": ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k", "kimi-v1", "k1"],
    },
    "openai": {
        "base_url": "https://api.openai.com/v1",
        "model": "gpt-4o-mini",
        "models": ["gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "gpt-4.1", "o3-mini"],
    },
    "qwen": {
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "model": "qwen-turbo",
        "models": ["qwen-turbo", "qwen-plus", "qwen-max"],
    },
    "deepseek": {
        "base_url": "https://api.deepseek.com/v1",
        "model": "deepseek-chat",
        "models": ["deepseek-chat", "deepseek-reasoner"],
    },
    "gemini": {
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
        "model": "gemini-2.0-flash",
        "models": ["gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro"],
    },
    "anthropic": {
        "base_url": "https://api.anthropic.com/v1",
        "model": "claude-sonnet-4-6",
        "models": ["claude-sonnet-4-6", "claude-opus-4-6", "claude-haiku-4-5-20251001"],
    },
}


def _config_path(project_path: Path) -> Path:
    return project_path / ".pvr" / "config.json"


def load_ai_config(project_path: Path) -> Optional[AIConfig]:
    """Load AI config from env vars (highest priority) and .pvr/config.json."""
    api_key = os.environ.get("PVR_AI_API_KEY", "")
    base_url = os.environ.get("PVR_AI_BASE_URL", "")
    model = os.environ.get("PVR_AI_MODEL", "")

    # Try loading from file
    file_data: dict = {}
    cfg_path = _config_path(project_path)
    if cfg_path.exists():
        try:
            raw = json.loads(cfg_path.read_text(encoding="utf-8"))
            file_data = raw.get("ai", {})
        except (json.JSONDecodeError, OSError):
            pass

    merged_key = api_key or file_data.get("api_key", "")
    merged_url = base_url or file_data.get("base_url", "https://api.moonshot.cn/v1")
    merged_model = model or file_data.get("model", "moonshot-v1-8k")
    merged_provider = file_data.get("provider", "")

    if not merged_key:
        return None

    return AIConfig(
        api_key=merged_key, base_url=merged_url,
        model=merged_model, provider=merged_provider,
    )


def save_ai_config(config: AIConfig, project_path: Path) -> None:
    """Write AI config to .pvr/config.json (merges with existing keys)."""
    cfg_path = _config_path(project_path)
    cfg_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if cfg_path.exists():
        try:
            existing = json.loads(cfg_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    existing["ai"] = {
        "api_key": config.api_key,
        "base_url": config.base_url,
        "model": config.model,
        "provider": config.provider,
    }
    cfg_path.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")


def get_available_models(project_path: Path) -> list[str]:
    """Return available models for the stored provider preset."""
    cfg = load_ai_config(project_path)
    if not cfg or not cfg.provider:
        return []
    preset = PRESETS.get(cfg.provider, {})
    return preset.get("models", [])
