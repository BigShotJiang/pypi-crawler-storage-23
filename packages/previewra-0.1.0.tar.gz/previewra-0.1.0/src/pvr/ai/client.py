"""Minimal async AI client — supports OpenAI-compatible APIs and Anthropic."""

import json
from typing import Optional

import httpx

from pvr.ai.config import AIConfig


class AIClient:
    def __init__(self, config: AIConfig) -> None:
        self._config = config

    @property
    def _is_anthropic(self) -> bool:
        return "anthropic.com" in self._config.base_url

    async def complete(self, prompt: str) -> str:
        """Send a prompt and return the response text."""
        if self._is_anthropic:
            return await self._complete_anthropic(prompt)
        return await self._complete_openai_compat(prompt)

    async def _complete_openai_compat(self, prompt: str) -> str:
        url = self._config.base_url.rstrip("/") + "/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._config.api_key}",
            "Content-Type": "application/json",
        }
        body = {
            "model": self._config.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2,
        }
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(url, headers=headers, json=body)
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

    async def _complete_anthropic(self, prompt: str) -> str:
        url = self._config.base_url.rstrip("/") + "/messages"
        headers = {
            "x-api-key": self._config.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        body = {
            "model": self._config.model,
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": prompt}],
        }
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(url, headers=headers, json=body)
            resp.raise_for_status()
            data = resp.json()
            return data["content"][0]["text"]
