"""AI Self-Correction — fixes previewra's own detection/configuration mistakes."""

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from pvr.ai.client import AIClient
from pvr.ai.config import AIConfig
from pvr.manifest.schema import ServiceConfig
from pvr.runner.manager import RunnerManager
from pvr.i18n import T
from pvr.utils.log import log_info, log_warn, log_error


# Config/setup files whose content helps infer correct startup params
_CONFIG_NAMES = {"requirements.txt", "package.json", "pyproject.toml", "Pipfile",
                 "setup.py", "setup.cfg", ".env.example", "Procfile", "Makefile"}
# Source file extensions — listed by name only, content NOT sent to AI
_SOURCE_EXTS = {".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs"}
_IGNORE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".pvr", "dist", "build"}
_MAX_CONFIG_CHARS = 1000
_MAX_LOG_LINES = 30


@dataclass
class HealingSuggestion:
    analysis: str
    cannot_fix: bool = False          # True when root cause is user code, not previewra config
    start_command: Optional[str] = None
    install_command: Optional[str] = None
    env: dict[str, str] = field(default_factory=dict)
    port: Optional[int] = None
    confidence: float = 0.0


def _collect_project_context(project_path: Path) -> dict:
    """Collect structural project info for AI context.

    Returns config file contents (small setup files) + source file name listing.
    Source code content is intentionally NOT collected — the AI must not suggest code changes.
    """
    config_files: dict[str, str] = {}
    source_files: list[str] = []

    for p in sorted(project_path.rglob("*")):
        if any(part in _IGNORE_DIRS for part in p.parts):
            continue
        if not p.is_file():
            continue
        rel = str(p.relative_to(project_path))
        if p.name in _CONFIG_NAMES:
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
                config_files[rel] = content[:_MAX_CONFIG_CHARS]
            except OSError:
                pass
        elif p.suffix in _SOURCE_EXTS:
            source_files.append(rel)

    return {"config_files": config_files, "source_files": source_files}


def _extract_json_block(text: str) -> Optional[dict]:
    """Extract the first ```json ... ``` block from AI response text."""
    pattern = r"```(?:json)?\s*(\{.*?\})\s*```"
    match = re.search(pattern, text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
    # Fallback: bare JSON object containing known keys
    match2 = re.search(r"\{[^{}]*\"analysis\"[^{}]*\}", text, re.DOTALL)
    if match2:
        try:
            return json.loads(match2.group(0))
        except json.JSONDecodeError:
            pass
    return None


def _build_prompt(
    project_path: Path,
    svc: ServiceConfig,
    error_logs: list[str],
    ctx: dict,
) -> str:
    config_section = "\n\n".join(
        f"### {name}\n```\n{content}\n```" for name, content in ctx["config_files"].items()
    ) or "(no setup/config files found)"
    source_listing = "\n".join(f"  {f}" for f in ctx["source_files"]) or "  (none)"
    logs_text = "\n".join(error_logs[-_MAX_LOG_LINES:]) or "(no logs captured)"

    return f"""You are previewra's self-correction module.

previewra is a CLI tool that auto-detects project types and generates startup configurations.
It failed to launch the service below. Your only job is to correct previewra's OWN detection
or configuration mistakes — NOT to fix the user's application code.

## SCOPE — you may ONLY correct previewra's own parameters:
- start_command  : shell command previewra uses to launch the service
- install_command: dependency installation command run before starting
- port           : port previewra expects the service to listen on
- env            : environment variables previewra injects at launch

## STRICT PROHIBITIONS:
- Do NOT suggest modifying the user's source code
- Do NOT suggest editing requirements.txt, package.json, or any project files
- Do NOT suggest creating new files in the user's project
- Do NOT ask the developer to do anything manually
If the root cause is in the user's application logic → set cannot_fix: true.

## previewra's current (broken) configuration:
- name           : {svc.name}
- project_type   : {svc.project_type}
- start_command  : {svc.start_command}
- install_command: {svc.install_command or "(none)"}
- port           : {svc.port or "(auto)"}
- env            : {json.dumps(svc.env)}

## Startup error logs (last {_MAX_LOG_LINES} lines):
```
{logs_text}
```

## Project setup/config files (content):
{config_section}

## Source files present (names only — do NOT suggest code changes):
{source_listing}

## Decision guide:
- Wrong entrypoint file name in command → fix start_command
- Missing --host 0.0.0.0 / --host flag → fix start_command
- Wrong port number → fix port
- Missing pip/npm install step → fix install_command
- Missing env var previewra should set → fix env
- Error is a Python exception / JS runtime error in user code → cannot_fix: true

Return ONLY a JSON block:

```json
{{
  "analysis": "What previewra got wrong (or why this is beyond previewra's scope)",
  "cannot_fix": false,
  "start_command": null,
  "install_command": null,
  "port": null,
  "env": {{}},
  "confidence": 0.9
}}
```

Rules:
- cannot_fix: true when root cause is user code, not previewra config
- For Python/FastAPI: start_command must include --host 0.0.0.0
- For React/Vite: start_command must include --host flag
- confidence: 0.0–1.0
- Use null for fields you are not changing
"""


class AutoHealer:

    async def heal(
        self,
        project_path: Path,
        services: list[ServiceConfig],
        runner_manager: RunnerManager,
        state,  # RuntimeState
        ai_config: AIConfig,
    ) -> Optional[list[ServiceConfig]]:
        """Ask AI to correct previewra's own config mistakes for CRASHED/FAILED services."""
        client = AIClient(ai_config)
        ctx = _collect_project_context(project_path)
        updated = list(services)
        any_fix = False

        for i, svc in enumerate(services):
            svc_state = state.services.get(svc.name)
            if not svc_state:
                continue
            if svc_state.status not in ("CRASHED", "FAILED"):
                continue

            runner = runner_manager.get_runner(svc.name)
            error_logs: list[str] = runner.get_recent_logs(_MAX_LOG_LINES) if runner else []

            prompt = _build_prompt(project_path, svc, error_logs, ctx)

            try:
                response = await client.complete(prompt)
            except Exception as exc:
                log_error(f"AI request failed: {exc}")
                continue

            suggestion_data = _extract_json_block(response)
            if not suggestion_data:
                log_error("AI did not return a parseable JSON block")
                continue

            # If AI determined the issue is in user code, report and skip
            if suggestion_data.get("cannot_fix"):
                reason = suggestion_data.get("analysis", "user code issue")
                log_warn(f"[AI] {svc.name}: " + T("ai_heal_cannot_fix", reason=reason))
                continue

            suggestion = HealingSuggestion(
                analysis=suggestion_data.get("analysis", ""),
                cannot_fix=False,
                start_command=suggestion_data.get("start_command"),
                install_command=suggestion_data.get("install_command"),
                env=suggestion_data.get("env") or {},
                port=suggestion_data.get("port"),
                confidence=float(suggestion_data.get("confidence", 0.0)),
            )

            if suggestion.confidence < 0.3:
                log_info(
                    f"[AI] {svc.name}: confidence too low ({suggestion.confidence:.1f}), skipping"
                )
                continue

            new_svc = svc.model_copy(update={
                k: v for k, v in {
                    "start_command": suggestion.start_command,
                    "install_command": suggestion.install_command,
                    "port": suggestion.port,
                    "env": {**svc.env, **suggestion.env} if suggestion.env else svc.env,
                }.items() if v is not None
            })
            updated[i] = new_svc
            any_fix = True
            log_info(f"[AI] fixed {svc.name}: {suggestion.analysis}")

        return updated if any_fix else None
