"""Base installer ABC."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional


class BaseInstaller(ABC):
    """Abstract base class for dependency installers."""

    def __init__(self) -> None:
        self.error: Optional[str] = None

    @abstractmethod
    async def install(self, path: Path) -> bool:
        """Install dependencies. Returns True on success."""
        ...
