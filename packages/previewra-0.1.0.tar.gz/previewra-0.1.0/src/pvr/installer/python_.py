"""Python dependency installer (venv + pip)."""

import asyncio
import sys
from pathlib import Path

from pvr.installer.base import BaseInstaller


class PythonInstaller(BaseInstaller):
    """Install Python dependencies via venv + pip."""

    async def install(self, path: Path) -> bool:
        venv_dir = path / ".venv"

        # Create venv if it doesn't exist
        if not venv_dir.exists():
            try:
                proc = await asyncio.create_subprocess_exec(
                    sys.executable, "-m", "venv", str(venv_dir),
                    cwd=str(path),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await proc.communicate()
                if proc.returncode != 0:
                    self.error = f"Failed to create venv: {stderr.decode(errors='ignore').strip()}"
                    return False
            except Exception as e:
                self.error = f"Failed to create venv: {e}"
                return False

        # Install requirements if requirements.txt exists
        req_file = path / "requirements.txt"
        if not req_file.exists():
            return True

        pip_path = venv_dir / "bin" / "pip"
        if not pip_path.exists():
            # Windows fallback
            pip_path = venv_dir / "Scripts" / "pip.exe"

        try:
            proc = await asyncio.create_subprocess_exec(
                str(pip_path), "install", "-r", str(req_file),
                cwd=str(path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()

            if proc.returncode != 0:
                self.error = stderr.decode(errors="ignore").strip()
                return False
            return True
        except FileNotFoundError:
            self.error = f"pip not found at {pip_path}"
            return False
        except Exception as e:
            self.error = str(e)
            return False
