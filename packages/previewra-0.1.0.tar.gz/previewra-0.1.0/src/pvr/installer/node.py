"""Node.js dependency installer."""

import asyncio
from pathlib import Path

from pvr.installer.base import BaseInstaller


class NodeInstaller(BaseInstaller):
    """Install Node.js dependencies via npm install."""

    async def install(self, path: Path) -> bool:
        node_modules = path / "node_modules"
        if node_modules.exists():
            return True

        try:
            proc = await asyncio.create_subprocess_exec(
                "npm", "install",
                cwd=str(path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()

            if proc.returncode != 0:
                self.error = stderr.decode(errors="ignore").strip()
                return False
            return True
        except FileNotFoundError:
            self.error = "npm not found. Please install Node.js."
            return False
        except Exception as e:
            self.error = str(e)
            return False
