"""Rich console wrapper with log buffer for Dashboard."""

from collections import deque
from datetime import datetime, timezone

from rich.console import Console

from pvr.config import LOG_BUFFER_MAX

console = Console()

# (timestamp, level, message)
log_buffer: deque[tuple[str, str, str]] = deque(maxlen=LOG_BUFFER_MAX)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _record(level: str, message: str) -> None:
    log_buffer.append((_now(), level, message))


def log_info(message: str) -> None:
    """Log an info message."""
    _record("INFO", message)
    console.print(f"[bold blue]ℹ[/bold blue] {message}")


def log_warn(message: str) -> None:
    """Log a warning message."""
    _record("WARN", message)
    console.print(f"[bold yellow]⚠[/bold yellow] {message}")


def log_error(message: str) -> None:
    """Log an error message."""
    _record("ERROR", message)
    console.print(f"[bold red]✗[/bold red] {message}")


def log_success(message: str) -> None:
    """Log a success message."""
    _record("SUCCESS", message)
    console.print(f"[bold green]✓[/bold green] {message}")


def get_recent_logs(n: int = 100) -> list[tuple[str, str, str]]:
    """Get the most recent n log entries."""
    items = list(log_buffer)
    return items[-n:] if len(items) > n else items
