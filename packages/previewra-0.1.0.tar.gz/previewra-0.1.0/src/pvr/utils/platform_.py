"""Platform detection utilities."""

import subprocess
import webbrowser
from pathlib import Path


def is_wsl() -> bool:
    """Detect if running under WSL."""
    try:
        return "microsoft" in Path("/proc/version").read_text().lower()
    except (FileNotFoundError, PermissionError):
        return False


def open_browser(url: str) -> None:
    """Open a URL in the default browser, with WSL support."""
    if is_wsl():
        try:
            subprocess.run(["wslview", url], check=True, capture_output=True)
        except FileNotFoundError:
            subprocess.run(["cmd.exe", "/c", "start", url.replace("&", "^&")])
    else:
        webbrowser.open(url)
