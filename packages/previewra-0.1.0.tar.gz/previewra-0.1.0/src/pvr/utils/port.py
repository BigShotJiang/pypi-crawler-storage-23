"""Port utilities: check, find, resolve."""

import socket

from pvr.config import LOG_BUFFER_MAX


def is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """Check if a TCP port is in use."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        try:
            s.connect((host, port))
            return True
        except (ConnectionRefusedError, TimeoutError, OSError):
            return False


def find_free_port(start: int = 9000, end: int = 9100) -> int:
    """Find a free port in the given range."""
    for port in range(start, end):
        if not is_port_in_use(port):
            return port
    raise RuntimeError(f"No free port in range {start}-{end}")


async def resolve_port(preferred: int) -> int:
    """Resolve a port, finding an alternative if the preferred one is in use."""
    if not is_port_in_use(preferred):
        return preferred

    from pvr.utils.log import log_info
    from pvr.i18n import T

    for p in range(preferred + 1, preferred + 100):
        if not is_port_in_use(p):
            log_info(T("port_in_use", port=preferred, new_port=p))
            return p
    raise RuntimeError(f"No free port in range {preferred}-{preferred + 99}")
