"""Locale detection and config persistence."""

import json
import os
from pathlib import Path
from typing import Optional

from pvr.config import DEFAULT_LOCALE, SUPPORTED_LOCALES, get_config_file, get_config_dir


def detect_system_locale() -> str:
    """Detect system locale from LANG environment variable."""
    lang = os.environ.get("LANG", "")
    lang_lower = lang.lower()

    if "zh_cn" in lang_lower or "zh-cn" in lang_lower:
        return "zh-CN"
    elif "zh_tw" in lang_lower or "zh-tw" in lang_lower or "zh_hk" in lang_lower:
        return "zh-TW"
    else:
        return DEFAULT_LOCALE


def load_config_locale(project_root: Path | None = None) -> Optional[str]:
    """Load locale from .pvr/config.json."""
    config_file = get_config_file(project_root)
    if not config_file.exists():
        return None
    try:
        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)
        locale = data.get("locale")
        if locale in SUPPORTED_LOCALES:
            return locale
    except (json.JSONDecodeError, OSError):
        pass
    return None


def save_config_locale(locale: str, project_root: Path | None = None) -> None:
    """Save locale to .pvr/config.json."""
    config_file = get_config_file(project_root)
    config_dir = get_config_dir(project_root)
    config_dir.mkdir(parents=True, exist_ok=True)

    data = {}
    if config_file.exists():
        try:
            with open(config_file, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            data = {}

    data["locale"] = locale
    with open(config_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
