"""Internationalization module for pvr."""

import json
from pathlib import Path
from typing import Optional

from pvr.config import DEFAULT_LOCALE, SUPPORTED_LOCALES

_messages: dict[str, dict[str, str]] = {}
_current_locale: str = DEFAULT_LOCALE
_messages_dir = Path(__file__).parent / "messages"


def _load_messages(locale: str) -> dict[str, str]:
    """Load messages for a given locale from JSON file."""
    if locale in _messages:
        return _messages[locale]

    # Map locale to filename: zh-CN -> zh_CN
    filename = locale.replace("-", "_") + ".json"
    filepath = _messages_dir / filename

    if not filepath.exists():
        filepath = _messages_dir / "en.json"

    with open(filepath, encoding="utf-8") as f:
        data = json.load(f)

    _messages[locale] = data
    return data


def T(key: str, **kwargs: object) -> str:
    """Get a translated string by key, with optional variable substitution."""
    msgs = _load_messages(_current_locale)
    template = msgs.get(key, key)
    if kwargs:
        try:
            return template.format(**kwargs)
        except (KeyError, IndexError):
            return template
    return template


def set_locale(locale: str) -> None:
    """Set the current locale."""
    global _current_locale
    if locale in SUPPORTED_LOCALES:
        _current_locale = locale
    else:
        _current_locale = DEFAULT_LOCALE


def get_locale() -> str:
    """Get the current locale."""
    return _current_locale


def get_all_messages(locale: Optional[str] = None) -> dict[str, str]:
    """Get all messages for a locale (defaults to current)."""
    loc = locale or _current_locale
    return _load_messages(loc)


def init_locale() -> None:
    """Initialize locale from config or system detection."""
    from pvr.i18n.locale import load_config_locale, detect_system_locale

    config_locale = load_config_locale()
    if config_locale and config_locale in SUPPORTED_LOCALES:
        set_locale(config_locale)
    else:
        detected = detect_system_locale()
        set_locale(detected)
