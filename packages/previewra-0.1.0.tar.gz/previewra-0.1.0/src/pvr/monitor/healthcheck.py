"""HealthCheckEngine — aggregate health from port probe results."""

import httpx

from pvr.config import PORT_PROBE_TIMEOUT
from pvr.manifest.schema import HealthResult
from pvr.monitor.port_probe import PortProbe


class HealthCheckEngine:
    """Run health checks for a service."""

    def __init__(self) -> None:
        self.port_probe = PortProbe()

    async def check(self, port: int, project_type: str) -> HealthResult:
        """Run health checks and return aggregated result."""
        checks: list[dict] = []

        # Basic port check
        port_info = await self.port_probe.probe(port)
        checks.append({
            "name": "port_reachable",
            "status": port_info.status,
            "port": port,
        })

        if port_info.status == "CONNECTION_REFUSED":
            return HealthResult(status="FAILED", checks=checks)
        if port_info.status == "TIMEOUT":
            return HealthResult(status="FAILED", checks=checks)
        if port_info.status == "HTTP_500":
            return HealthResult(status="DEGRADED", checks=checks)

        # FastAPI extra checks: /docs and /openapi.json
        if project_type == "fastapi":
            for endpoint in ("/docs", "/openapi.json"):
                try:
                    async with httpx.AsyncClient(trust_env=False) as client:
                        resp = await client.get(
                            f"http://127.0.0.1:{port}{endpoint}",
                            timeout=PORT_PROBE_TIMEOUT,
                            follow_redirects=True,
                        )
                    checks.append({
                        "name": f"fastapi_{endpoint.strip('/')}",
                        "status_code": resp.status_code,
                        "ok": resp.status_code == 200,
                    })
                except Exception as e:
                    checks.append({
                        "name": f"fastapi_{endpoint.strip('/')}",
                        "ok": False,
                        "error": str(e),
                    })

        # If we got HTTP_200 on the base, it's healthy
        if port_info.status == "HTTP_200":
            return HealthResult(status="HEALTHY", checks=checks)

        # HTTP_OTHER — service responds but not with 200
        return HealthResult(status="DEGRADED", checks=checks)
