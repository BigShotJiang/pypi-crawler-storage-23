"""EventBus — async pub/sub for runtime events."""

import asyncio
from collections import defaultdict
from enum import Enum
from typing import Any, Callable, Coroutine


class EventType(str, Enum):
    PROCESS_STARTED = "process.started"
    PROCESS_EXITED = "process.exited"
    PROCESS_LOG = "process.log"
    PROCESS_ERROR = "process.error"
    PORT_OPEN = "port.open"
    PORT_FAIL = "port.fail"
    PORT_DISCOVERED = "port.discovered"
    HEALTH_OK = "health.ok"
    HEALTH_FAIL = "health.fail"
    STATE_CHANGED = "state.changed"
    FILE_CHANGED = "file.changed"


# Handler type: async callable that takes a dict payload
Handler = Callable[[dict[str, Any]], Coroutine[Any, Any, None]]


class EventBus:
    """Async event bus with pub/sub."""

    def __init__(self) -> None:
        self._listeners: defaultdict[EventType, list[Handler]] = defaultdict(list)

    def subscribe(self, event_type: EventType, handler: Handler) -> None:
        """Subscribe a handler to an event type."""
        self._listeners[event_type].append(handler)

    async def emit(self, event_type: EventType, payload: dict[str, Any] | None = None) -> None:
        """Emit an event, calling all subscribed handlers concurrently."""
        handlers = self._listeners.get(event_type, [])
        if not handlers:
            return
        data = payload or {}
        await asyncio.gather(
            *(h(data) for h in handlers),
            return_exceptions=True,
        )
