"""RuntimeAggregator — aggregate all probes into RuntimeState."""

import asyncio
from datetime import datetime, timezone
from typing import Optional

from pvr.config import PERIODIC_CHECK_INTERVAL, WAIT_READY_TIMEOUT
from pvr.manifest.schema import (
    RuntimeState,
    ServiceRuntimeState,
)
from pvr.monitor.event_bus import EventBus, EventType
from pvr.monitor.healthcheck import HealthCheckEngine
from pvr.monitor.port_probe import PortProbe
from pvr.monitor.process_probe import ProcessProbe
from pvr.monitor.simulator import Simulator
from pvr.runner.manager import RunnerManager


class RuntimeAggregator:
    """Aggregate probe results into a unified RuntimeState."""

    def __init__(
        self,
        runner_manager: RunnerManager,
        event_bus: EventBus,
        session_id: str,
    ) -> None:
        self.runner_manager = runner_manager
        self.event_bus = event_bus
        self.session_id = session_id
        self.process_probe = ProcessProbe()
        self.port_probe = PortProbe()
        self.health_engine = HealthCheckEngine()
        self.simulator = Simulator()
        self._periodic_task: Optional[asyncio.Task] = None

        # Subscribe to process exit events for immediate re-aggregation
        self.event_bus.subscribe(EventType.PROCESS_EXITED, self._on_process_exited)

    async def _on_process_exited(self, payload: dict) -> None:
        """Handle process exit — trigger immediate state check."""
        state = await self.aggregate()
        await self.event_bus.emit(EventType.STATE_CHANGED, {
            "state": state.model_dump(),
        })

    async def aggregate(self) -> RuntimeState:
        """Probe all services and build RuntimeState."""
        service_states: dict[str, ServiceRuntimeState] = {}

        for name, runner in self.runner_manager.runners.items():
            svc_state = ServiceRuntimeState(name=name)

            # Process probe
            if runner.pid:
                proc_info = await self.process_probe.probe(runner.pid)
                svc_state.process = proc_info

                if proc_info.status == "dead":
                    svc_state.status = "CRASHED"
                    service_states[name] = svc_state
                    continue

            # If runner state is STOPPED, reflect that
            if runner.state == "STOPPED":
                svc_state.status = "STOPPED"
                service_states[name] = svc_state
                continue

            # Port probe (only if service has a port)
            port = runner.service_config.port
            if port:
                port_info = await self.port_probe.probe(port)
                svc_state.port = port_info

                if port_info.status == "CONNECTION_REFUSED":
                    # Could be still starting
                    if runner.state == "RUNNING":
                        svc_state.status = "STARTING"
                    else:
                        svc_state.status = "FAILED"
                    service_states[name] = svc_state
                    continue

                if port_info.status == "TIMEOUT":
                    svc_state.status = "FAILED"
                    service_states[name] = svc_state
                    continue

                if port_info.status == "HTTP_500":
                    svc_state.status = "DEGRADED"
                    service_states[name] = svc_state
                    continue

                # Health check
                health = await self.health_engine.check(port, runner.service_config.project_type)
                svc_state.health = health

                # Simulator
                sim = await self.simulator.simulate(port)
                svc_state.simulator = sim

                if health.status == "HEALTHY":
                    svc_state.status = "HEALTHY"
                elif health.status == "DEGRADED":
                    svc_state.status = "DEGRADED"
                else:
                    svc_state.status = "FAILED"
            else:
                # No port — if process running, mark as RUNNING
                if runner.state == "RUNNING":
                    svc_state.status = "RUNNING"
                else:
                    svc_state.status = runner.state

            service_states[name] = svc_state

        # Determine overall status
        overall = self._compute_overall(service_states)

        return RuntimeState(
            session_id=self.session_id,
            services=service_states,
            overall_status=overall,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def _compute_overall(
        self, services: dict[str, ServiceRuntimeState]
    ) -> str:
        """Compute overall status from individual service states."""
        statuses = {s.status for s in services.values()}

        if "CRASHED" in statuses:
            return "CRASHED"
        if "FAILED" in statuses:
            return "FAILED"
        if "DEGRADED" in statuses:
            return "DEGRADED"
        if "STARTING" in statuses:
            return "STARTING"
        if all(s in ("HEALTHY", "RUNNING") for s in statuses):
            return "HEALTHY"
        return "STARTING"

    async def wait_until_ready(self, timeout: float = WAIT_READY_TIMEOUT) -> RuntimeState:
        """Poll until overall status settles (HEALTHY/DEGRADED/CRASHED/FAILED) or timeout."""
        terminal = {"HEALTHY", "DEGRADED", "CRASHED", "FAILED"}
        deadline = asyncio.get_event_loop().time() + timeout

        while asyncio.get_event_loop().time() < deadline:
            state = await self.aggregate()
            if state.overall_status in terminal:
                return state
            await asyncio.sleep(1.0)

        # Timeout — return current state
        return await self.aggregate()

    async def start_periodic_check(self, interval: float = PERIODIC_CHECK_INTERVAL) -> None:
        """Start a background task that periodically aggregates and emits STATE_CHANGED."""
        self._periodic_task = asyncio.create_task(self._periodic_loop(interval))

    async def _periodic_loop(self, interval: float) -> None:
        """Periodic aggregation loop."""
        try:
            while True:
                state = await self.aggregate()
                await self.event_bus.emit(EventType.STATE_CHANGED, {
                    "state": state.model_dump(),
                })
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            return

    async def stop_periodic_check(self) -> None:
        """Stop the periodic check task."""
        if self._periodic_task and not self._periodic_task.done():
            self._periodic_task.cancel()
            try:
                await self._periodic_task
            except asyncio.CancelledError:
                pass
