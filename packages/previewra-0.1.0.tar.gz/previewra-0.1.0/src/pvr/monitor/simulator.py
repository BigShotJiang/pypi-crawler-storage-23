"""Simulator — GET homepage and validate response."""

import httpx

from pvr.config import SIMULATOR_TIMEOUT
from pvr.manifest.schema import SimulatorResult


class Simulator:
    """Simulate a user visiting the homepage."""

    async def simulate(self, port: int, host: str = "127.0.0.1") -> SimulatorResult:
        """GET the homepage and validate the response."""
        url = f"http://{host}:{port}/"
        try:
            async with httpx.AsyncClient(trust_env=False) as client:
                resp = await client.get(url, timeout=SIMULATOR_TIMEOUT, follow_redirects=True)

            status_ok = resp.status_code == 200
            content = resp.text
            has_content = len(content) > 100
            has_html_tag = "<html" in content.lower()

            checks = {
                "status_ok": status_ok,
                "has_content": has_content,
                "has_html_tag": has_html_tag,
                "content_length": len(content),
                "status_code": resp.status_code,
            }
            passed = status_ok and has_content

            return SimulatorResult(passed=passed, checks=checks)
        except Exception as e:
            return SimulatorResult(
                passed=False,
                checks={},
                error=str(e),
            )
