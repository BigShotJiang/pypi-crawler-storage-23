"""PortProbe — TCP + HTTP probe for a port."""

import socket
import time

import httpx

from pvr.config import PORT_PROBE_TIMEOUT
from pvr.manifest.schema import PortInfo


class PortProbe:
    """Probe a port via TCP connect and HTTP GET."""

    async def probe(self, port: int, host: str = "127.0.0.1") -> PortInfo:
        """Probe a port. Returns PortInfo with connection status."""
        # Step 1: TCP connect check
        tcp_ok = False
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)
            try:
                s.connect((host, port))
                tcp_ok = True
            except (ConnectionRefusedError, TimeoutError, OSError):
                pass

        if not tcp_ok:
            return PortInfo(port=port, status="CONNECTION_REFUSED")

        # Step 2: HTTP GET
        url = f"http://{host}:{port}/"
        start = time.monotonic()
        try:
            async with httpx.AsyncClient(trust_env=False) as client:
                resp = await client.get(url, timeout=PORT_PROBE_TIMEOUT, follow_redirects=True)
            elapsed_ms = round((time.monotonic() - start) * 1000, 1)

            if resp.status_code == 200:
                status = "HTTP_200"
            elif 500 <= resp.status_code < 600:
                status = "HTTP_500"
            else:
                status = "HTTP_OTHER"

            return PortInfo(
                port=port,
                status=status,
                response_time_ms=elapsed_ms,
                content_length=len(resp.content),
                status_code=resp.status_code,
            )
        except httpx.TimeoutException:
            elapsed_ms = round((time.monotonic() - start) * 1000, 1)
            return PortInfo(port=port, status="TIMEOUT", response_time_ms=elapsed_ms)
        except Exception:
            return PortInfo(port=port, status="CONNECTION_REFUSED")
