"""ProcessProbe — probe a process via psutil."""

import time

import psutil

from pvr.manifest.schema import ProcessInfo


class ProcessProbe:
    """Probe process status using psutil."""

    async def probe(self, pid: int) -> ProcessInfo:
        """Probe a process by PID. Returns ProcessInfo with status='dead' if not found."""
        try:
            p = psutil.Process(pid)
            status = p.status()
            cpu = p.cpu_percent(interval=0.5)
            mem_mb = p.memory_info().rss / (1024 * 1024)
            uptime = time.time() - p.create_time()
            return ProcessInfo(
                pid=pid,
                status=status,
                cpu_percent=cpu,
                memory_mb=round(mem_mb, 2),
                uptime_seconds=round(uptime, 1),
            )
        except psutil.NoSuchProcess:
            return ProcessInfo(pid=pid, status="dead")
        except (psutil.AccessDenied, psutil.ZombieProcess):
            return ProcessInfo(pid=pid, status="dead")
