"""Constants and paths for pvr."""

from pathlib import Path

# Application
APP_NAME = "Previewra"
CONFIG_DIR_NAME = ".pvr"
CONFIG_FILE_NAME = "config.json"

# Default ports
DEFAULT_FASTAPI_PORT = 8000
DEFAULT_FLASK_PORT = 5000
DEFAULT_VITE_PORT = 5173
DEFAULT_CRA_PORT = 3000
DEFAULT_STATIC_PORT = 8080
DEFAULT_DASHBOARD_PORT = 9000

# Timeouts
PROCESS_STOP_TIMEOUT = 5  # seconds
PORT_PROBE_TIMEOUT = 5  # seconds
SIMULATOR_TIMEOUT = 10  # seconds
WAIT_READY_TIMEOUT = 30  # seconds

# Monitor intervals
PERIODIC_CHECK_INTERVAL = 2.0  # seconds
LOG_WS_INTERVAL = 0.5  # seconds
SNAPSHOT_INTERVAL = 30  # seconds

# Watcher
DEBOUNCE_SECONDS = 2.0
IGNORE_DIRS = {
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    ".git",
    ".pvr",
    ".devpreview",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "egg-info",
}

# Locales
SUPPORTED_LOCALES = ("zh-CN", "zh-TW", "en")
DEFAULT_LOCALE = "en"

# Log buffer
LOG_BUFFER_MAX = 1000


def get_config_dir(project_root: Path | None = None) -> Path:
    """Get the .pvr config directory path."""
    root = project_root or Path.cwd()
    return root / CONFIG_DIR_NAME


def get_config_file(project_root: Path | None = None) -> Path:
    """Get the config.json path."""
    return get_config_dir(project_root) / CONFIG_FILE_NAME


def get_sessions_dir(project_root: Path | None = None) -> Path:
    """Get the sessions directory path."""
    return get_config_dir(project_root) / "sessions"
