"""DiagnosticEngine — analyze runtime state and produce reports."""

from datetime import datetime, timezone

from pvr.core.context import RuntimeContext
from pvr.i18n import T
from pvr.manifest.schema import DiagnosticReport, RuntimeState


class DiagnosticEngine:
    """Diagnose service issues and produce localized reports."""

    async def diagnose(self, context: RuntimeContext) -> list[DiagnosticReport]:
        """Run diagnostics on all services. Requires an aggregator in context."""
        if not context.aggregator:
            return []

        state: RuntimeState = await context.aggregator.aggregate()
        reports: list[DiagnosticReport] = []
        now = datetime.now(timezone.utc).isoformat()

        for name, svc in state.services.items():
            if svc.status == "HEALTHY":
                reports.append(DiagnosticReport(
                    session_id=state.session_id,
                    service=name,
                    status=svc.status,
                    reason="NONE",
                    details={},
                    suggestion=T("doctor_healthy"),
                    timestamp=now,
                ))
            elif svc.status == "CRASHED":
                details: dict = {}
                if svc.process:
                    details["pid"] = svc.process.pid
                    details["process_status"] = svc.process.status
                # Grab last logs from runner
                if context.runner_manager:
                    runner = context.runner_manager.get_runner(name)
                    if runner:
                        details["last_logs"] = runner.get_recent_logs(10)
                reports.append(DiagnosticReport(
                    session_id=state.session_id,
                    service=name,
                    status=svc.status,
                    reason="PROCESS_CRASHED",
                    details=details,
                    suggestion=T("suggest_check_logs"),
                    timestamp=now,
                ))
            elif svc.status == "FAILED":
                details = {}
                if svc.port:
                    details["port"] = svc.port.port
                    details["port_status"] = svc.port.status
                reports.append(DiagnosticReport(
                    session_id=state.session_id,
                    service=name,
                    status=svc.status,
                    reason="PORT_NOT_RESPONDING",
                    details=details,
                    suggestion=T("suggest_check_logs"),
                    timestamp=now,
                ))
            elif svc.status == "DEGRADED":
                details = {}
                if svc.port:
                    details["port"] = svc.port.port
                    details["status_code"] = svc.port.status_code
                reports.append(DiagnosticReport(
                    session_id=state.session_id,
                    service=name,
                    status=svc.status,
                    reason="HTTP_ERROR",
                    details=details,
                    suggestion=T("suggest_check_logs"),
                    timestamp=now,
                ))
            else:
                # STARTING / RUNNING / STOPPED
                reports.append(DiagnosticReport(
                    session_id=state.session_id,
                    service=name,
                    status=svc.status,
                    reason=svc.status,
                    details={},
                    suggestion="",
                    timestamp=now,
                ))

        return reports


async def diagnose_from_state(
    state: RuntimeState,
    runner_manager: object = None,
) -> list[DiagnosticReport]:
    """Diagnose from an existing RuntimeState (used by tests and dashboard)."""
    reports: list[DiagnosticReport] = []
    now = datetime.now(timezone.utc).isoformat()

    for name, svc in state.services.items():
        if svc.status == "HEALTHY":
            reports.append(DiagnosticReport(
                session_id=state.session_id,
                service=name,
                status=svc.status,
                reason="NONE",
                details={},
                suggestion=T("doctor_healthy"),
                timestamp=now,
            ))
        elif svc.status == "CRASHED":
            reports.append(DiagnosticReport(
                session_id=state.session_id,
                service=name,
                status=svc.status,
                reason="PROCESS_CRASHED",
                details={},
                suggestion=T("suggest_check_logs"),
                timestamp=now,
            ))
        elif svc.status == "FAILED":
            reports.append(DiagnosticReport(
                session_id=state.session_id,
                service=name,
                status=svc.status,
                reason="PORT_NOT_RESPONDING",
                details={},
                suggestion=T("suggest_check_logs"),
                timestamp=now,
            ))
        elif svc.status == "DEGRADED":
            reports.append(DiagnosticReport(
                session_id=state.session_id,
                service=name,
                status=svc.status,
                reason="HTTP_ERROR",
                details={},
                suggestion=T("suggest_check_logs"),
                timestamp=now,
            ))
        else:
            reports.append(DiagnosticReport(
                session_id=state.session_id,
                service=name,
                status=svc.status,
                reason=svc.status,
                details={},
                suggestion="",
                timestamp=now,
            ))

    return reports
