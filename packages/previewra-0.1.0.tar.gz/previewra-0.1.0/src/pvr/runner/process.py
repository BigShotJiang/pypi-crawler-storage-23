"""ProcessRunner — manages a single service subprocess."""

import asyncio
import os
import re
from collections import deque
from pathlib import Path
from typing import Literal, Optional

from pvr.config import LOG_BUFFER_MAX, PROCESS_STOP_TIMEOUT
from pvr.manifest.schema import ServiceConfig
from pvr.monitor.event_bus import EventBus, EventType

# Patterns to detect actual listening port from process log output.
# Covers Flask, Uvicorn, Node/Vite, and common generic formats.
_PORT_PATTERNS = [
    re.compile(r"[Rr]unning on https?://[\w.]+:(\d+)"),
    re.compile(r"[Ss]tarted on https?://[\w.]+:(\d+)"),
    re.compile(r"Uvicorn running on https?://[\w.]+:(\d+)"),
    re.compile(r"[Ll]ocal:\s+https?://[\w.]+:(\d+)"),
    re.compile(r"[Ll]istening on https?://[\w.]+:(\d+)"),
    re.compile(r"[Ss]erver.*?\s:(\d{4,5})\b"),
    re.compile(r"[Ll]istening on port (\d+)"),
]


class ProcessRunner:
    """Run and manage a single service process."""

    def __init__(
        self,
        service_config: ServiceConfig,
        event_bus: EventBus,
        project_root: Path,
    ) -> None:
        self.service_config = service_config
        self.event_bus = event_bus
        self.project_root = project_root
        self.state: Literal["IDLE", "RUNNING", "CRASHED", "STOPPED"] = "IDLE"
        self.process: Optional[asyncio.subprocess.Process] = None
        self.pid: Optional[int] = None
        self.log_buffer: deque[str] = deque(maxlen=LOG_BUFFER_MAX)
        self._read_task: Optional[asyncio.Task] = None
        self._port_discovered: bool = False

    async def start(self) -> None:
        """Start the service process."""
        env = os.environ.copy()
        env.update(self.service_config.env)

        working_dir = self.project_root
        if self.service_config.working_dir:
            working_dir = self.project_root / self.service_config.working_dir

        # For Python projects, prepend .venv/bin to PATH
        venv_bin = working_dir / ".venv" / "bin"
        if venv_bin.exists():
            env["PATH"] = str(venv_bin) + os.pathsep + env.get("PATH", "")
            env["VIRTUAL_ENV"] = str(working_dir / ".venv")

        self.process = await asyncio.create_subprocess_shell(
            self.service_config.start_command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(working_dir),
            env=env,
        )
        self.pid = self.process.pid
        self.state = "RUNNING"

        await self.event_bus.emit(EventType.PROCESS_STARTED, {
            "name": self.service_config.name,
            "pid": self.pid,
        })

        self._read_task = asyncio.create_task(self._read_output())

    async def stop(self) -> None:
        """Gracefully stop the process: SIGTERM → timeout → SIGKILL."""
        if self.process and self.process.returncode is None:
            self.process.terminate()
            try:
                await asyncio.wait_for(
                    self.process.wait(), timeout=PROCESS_STOP_TIMEOUT
                )
            except asyncio.TimeoutError:
                self.process.kill()
                await self.process.wait()

        if self._read_task and not self._read_task.done():
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass

        self.state = "STOPPED"
        await self.event_bus.emit(EventType.PROCESS_EXITED, {
            "name": self.service_config.name,
            "pid": self.pid,
            "returncode": self.process.returncode if self.process else None,
            "state": "STOPPED",
        })

    async def restart(self) -> None:
        """Restart the process."""
        await self.stop()
        await self.start()

    async def _read_output(self) -> None:
        """Read stdout and stderr, buffer lines and emit events."""
        assert self.process is not None

        async def _read_stream(
            stream: Optional[asyncio.StreamReader],
            event_type: EventType,
        ) -> None:
            if stream is None:
                return
            while True:
                line_bytes = await stream.readline()
                if not line_bytes:
                    break
                line = line_bytes.decode(errors="ignore").rstrip("\n")
                self.log_buffer.append(line)
                await self.event_bus.emit(event_type, {
                    "name": self.service_config.name,
                    "line": line,
                })

                # Port discovery: parse actual listening port from log output
                if not self._port_discovered:
                    for pattern in _PORT_PATTERNS:
                        m = pattern.search(line)
                        if m:
                            discovered = int(m.group(1))
                            if discovered != self.service_config.port:
                                self.service_config.port = discovered
                            self._port_discovered = True
                            await self.event_bus.emit(EventType.PORT_DISCOVERED, {
                                "name": self.service_config.name,
                                "port": discovered,
                            })
                            break

        try:
            await asyncio.gather(
                _read_stream(self.process.stdout, EventType.PROCESS_LOG),
                _read_stream(self.process.stderr, EventType.PROCESS_ERROR),
            )
        except asyncio.CancelledError:
            return

        # Process has exited — check return code
        returncode = await self.process.wait()
        if returncode != 0 and self.state != "STOPPED":
            self.state = "CRASHED"
            await self.event_bus.emit(EventType.PROCESS_EXITED, {
                "name": self.service_config.name,
                "pid": self.pid,
                "returncode": returncode,
                "state": "CRASHED",
            })

    def get_recent_logs(self, n: int = 100) -> list[str]:
        """Get the most recent n log lines."""
        items = list(self.log_buffer)
        return items[-n:] if len(items) > n else items
