"""RunnerManager — manages multiple service runners."""

from pathlib import Path
from typing import Optional

from pvr.manifest.schema import ServiceConfig
from pvr.monitor.event_bus import EventBus
from pvr.runner.process import ProcessRunner


class RunnerManager:
    """Manage multiple ProcessRunners."""

    def __init__(self, event_bus: EventBus, project_root: Path) -> None:
        self.event_bus = event_bus
        self.project_root = project_root
        self.runners: dict[str, ProcessRunner] = {}

    async def start_all(self, services: list[ServiceConfig]) -> None:
        """Start all services."""
        for svc in services:
            runner = ProcessRunner(svc, self.event_bus, self.project_root)
            self.runners[svc.name] = runner
            await runner.start()

    async def stop_all(self) -> None:
        """Stop all running services."""
        for runner in self.runners.values():
            if runner.state == "RUNNING":
                await runner.stop()

    async def restart_service(self, name: str) -> None:
        """Restart a single service by name."""
        runner = self.runners.get(name)
        if runner:
            await runner.restart()

    def get_runner(self, name: str) -> Optional[ProcessRunner]:
        """Get a runner by service name."""
        return self.runners.get(name)
