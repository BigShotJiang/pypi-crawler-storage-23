"""CLI entry point for pvr."""

import asyncio
import json as json_mod
import signal
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
import uvicorn

from pvr.i18n import T, get_locale, init_locale, set_locale
from pvr.i18n.locale import save_config_locale
from pvr.utils.log import log_info, log_success, log_error, console

app = typer.Typer(
    name="pvr",
    help="Previewra — AI-native Runtime OS Layer, instant preview for AI-coded projects.",
    add_completion=False,
)

sessions_app = typer.Typer(help="Session management commands.")
config_app = typer.Typer(help="Configuration commands.")
config_ai_app = typer.Typer(help="AI provider configuration.")
app.add_typer(sessions_app, name="sessions")
app.add_typer(config_app, name="config")
config_app.add_typer(config_ai_app, name="ai")


def _init_lang(lang: Optional[str], path: Optional[Path] = None) -> None:
    """Initialize language: CLI flag > config > system."""
    if lang:
        set_locale(lang)
    else:
        init_locale()


# ---------------------------------------------------------------------------
#  Core async helpers
# ---------------------------------------------------------------------------

async def _detect_and_install(project_path: Path):
    """Detect project, create session, install deps. Returns (manifest, session_id, services)."""
    from pvr.detector.registry import DetectorRegistry
    from pvr.installer.node import NodeInstaller
    from pvr.installer.python_ import PythonInstaller
    from pvr.core.session import SessionManager
    from pvr.manifest.schema import Manifest
    from pvr.runtime.history import save_session_history

    log_info(T("detecting_project"))
    registry = DetectorRegistry()
    services = registry.detect(project_path)

    if not services:
        log_error(T("no_project_detected", path=str(project_path)))
        raise typer.Exit(1)

    for svc in services:
        log_success(T("detected_as", project_type=svc.project_type))

    session_mgr = SessionManager(project_path)
    session_id = session_mgr.create_session()
    log_info(T("session_created", session_id=session_id))

    manifest = Manifest(
        session_id=session_id,
        project_root=str(project_path),
        services=services,
        detected_at=datetime.now(timezone.utc).isoformat(),
        locale=get_locale(),
    )
    manifest.save(project_path / ".pvr" / "manifest.json")

    # Save to session history
    save_session_history(session_id, manifest.model_dump(), project_path)

    # Install
    for svc in services:
        if not svc.install_command:
            continue
        log_info(T("installing_deps", name=svc.name))
        installer = NodeInstaller() if svc.project_type in ("react",) else PythonInstaller()
        success = await installer.install(project_path)
        if success:
            log_success(T("install_success", name=svc.name))
        else:
            log_error(T("install_failed", name=svc.name))
            if installer.error:
                log_error(installer.error)

    return manifest, session_id, services


async def _start_services(project_path, services, event_bus):
    """Start all services, return RunnerManager."""
    from pvr.runner.manager import RunnerManager
    from pvr.monitor.event_bus import EventType

    async def _on_log(payload: dict) -> None:
        console.print(f"[dim]{payload.get('name', '')}[/dim] {payload.get('line', '')}")

    event_bus.subscribe(EventType.PROCESS_LOG, _on_log)
    event_bus.subscribe(EventType.PROCESS_ERROR, _on_log)

    runner_manager = RunnerManager(event_bus, project_path)

    for svc in services:
        log_info(T("starting_service", name=svc.name))

    await runner_manager.start_all(services)

    for svc in services:
        if svc.port:
            log_success(T("service_running", name=svc.name, port=svc.port))

    return runner_manager


def _print_state(state):
    """Print aggregated state summary."""
    status_key = f"status_{state.overall_status.lower()}"
    log_success(f"{T('app_name')} — {T(status_key)} ({state.overall_status})")
    for name, svc_state in state.services.items():
        parts = [f"  {name}: {svc_state.status}"]
        if svc_state.process:
            parts.append(f"pid={svc_state.process.pid}")
            parts.append(f"cpu={svc_state.process.cpu_percent}%")
            parts.append(f"mem={svc_state.process.memory_mb}MB")
        if svc_state.port:
            parts.append(f"port={svc_state.port.port}")
            parts.append(f"{svc_state.port.response_time_ms}ms")
        log_info(" | ".join(parts))


async def _launch_dashboard(ctx):
    """Launch dashboard as async task in the main event loop. Returns (server, port)."""
    from pvr.dashboard.app import create_dashboard_app
    from pvr.config import DEFAULT_DASHBOARD_PORT
    from pvr.utils.port import find_free_port

    dashboard_app = create_dashboard_app(ctx)
    dashboard_port = find_free_port(DEFAULT_DASHBOARD_PORT, DEFAULT_DASHBOARD_PORT + 100)

    uvi_config = uvicorn.Config(
        dashboard_app, host="0.0.0.0", port=dashboard_port, log_level="warning",
    )
    server = uvicorn.Server(uvi_config)
    # Disable uvicorn's signal handlers — we manage signals ourselves
    server.install_signal_handlers = lambda: None
    asyncio.create_task(server.serve())

    # Wait for server to start
    for _ in range(50):
        if server.started:
            break
        await asyncio.sleep(0.1)

    return server, dashboard_port


async def _snapshot_loop(session_id, aggregator, project_path, interval=30):
    """Periodically save runtime state snapshots."""
    from pvr.runtime.snapshot import save_snapshot
    try:
        while True:
            await asyncio.sleep(interval)
            state = await aggregator.aggregate()
            save_snapshot(session_id, state, project_path)
    except asyncio.CancelledError:
        return


# ---------------------------------------------------------------------------
#  preview
# ---------------------------------------------------------------------------

async def _run_preview(path: Path, enable_watcher: bool = False) -> None:
    """Full preview flow: detect → install → run → monitor → (AI heal) → dashboard → browser."""
    from pvr.monitor.event_bus import EventBus, EventType
    from pvr.monitor.aggregator import RuntimeAggregator
    from pvr.core.context import RuntimeContext
    from pvr.utils.platform_ import open_browser
    from pvr.runtime.snapshot import save_snapshot
    from pvr.config import SNAPSHOT_INTERVAL
    from pvr.ai.config import load_ai_config
    from pvr.ai.healer import AutoHealer

    project_path = path.resolve()
    manifest, session_id, services = await _detect_and_install(project_path)

    event_bus = EventBus()
    runner_manager = await _start_services(project_path, services, event_bus)

    aggregator = RuntimeAggregator(runner_manager, event_bus, session_id)
    state = await aggregator.wait_until_ready()
    _print_state(state)

    # AI Auto-Heal: if any service crashed/failed, attempt to fix it
    if state.overall_status in ("CRASHED", "FAILED", "DEGRADED"):
        ai_cfg = load_ai_config(project_path)
        if ai_cfg and ai_cfg.api_key:
            log_info(T("ai_healing_start"))
            healer = AutoHealer()
            for attempt in range(AutoHealer.MAX_RETRIES):
                log_info(T("ai_healing_attempt", n=attempt + 1, max=AutoHealer.MAX_RETRIES))
                fixed_services = await healer.heal(
                    project_path, services, runner_manager, state, ai_cfg
                )
                if fixed_services:
                    # Re-install and restart with fixed config
                    await runner_manager.stop_all()
                    services = fixed_services
                    # Re-install if install_command changed
                    from pvr.installer.node import NodeInstaller
                    from pvr.installer.python_ import PythonInstaller
                    for svc in services:
                        if svc.install_command:
                            installer = (
                                NodeInstaller()
                                if svc.project_type in ("react",)
                                else PythonInstaller()
                            )
                            await installer.install(project_path)
                    runner_manager = await _start_services(project_path, services, event_bus)
                    aggregator = RuntimeAggregator(runner_manager, event_bus, session_id)
                    state = await aggregator.wait_until_ready()
                    _print_state(state)
                    if state.overall_status == "HEALTHY":
                        log_info(T("ai_healing_success"))
                        break
                else:
                    log_error(T("ai_healing_failed", max=AutoHealer.MAX_RETRIES))
                    break
        else:
            log_info(T("ai_no_key"))

    await aggregator.start_periodic_check()

    ctx = RuntimeContext(
        session_id=session_id,
        project_root=str(project_path),
        manifest=manifest,
        runner_manager=runner_manager,
        aggregator=aggregator,
        event_bus=event_bus,
    )

    server, dashboard_port = await _launch_dashboard(ctx)
    dashboard_url = f"http://localhost:{dashboard_port}"
    log_success(T("dashboard_started", url=dashboard_url))
    log_info(T("opening_browser"))
    open_browser(dashboard_url)

    # Snapshot loop
    snapshot_task = asyncio.create_task(
        _snapshot_loop(session_id, aggregator, project_path, SNAPSHOT_INTERVAL)
    )

    # File watcher
    watcher = None
    if enable_watcher:
        from pvr.watcher.file_watcher import DevPreviewWatcher

        watcher = DevPreviewWatcher(project_path, event_bus)
        loop = asyncio.get_running_loop()
        watcher.start(loop)
        log_info(T("watching_files"))

        async def _on_file_changed(payload: dict) -> None:
            log_info(T("file_changed", path=payload.get("path", "")))
            await runner_manager.stop_all()
            await runner_manager.start_all(services)

        event_bus.subscribe(EventType.FILE_CHANGED, _on_file_changed)

    try:
        stop_event = asyncio.Event()
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, stop_event.set)
        loop.add_signal_handler(signal.SIGTERM, stop_event.set)
        await stop_event.wait()
    finally:
        snapshot_task.cancel()
        try:
            await snapshot_task
        except asyncio.CancelledError:
            pass

        # Final snapshot
        final_state = await aggregator.aggregate()
        save_snapshot(session_id, final_state, project_path)

        await aggregator.stop_periodic_check()
        server.should_exit = True

        if watcher:
            watcher.stop()

        log_info(T("stopping_services"))
        await runner_manager.stop_all()
        log_success(T("all_stopped"))


@app.command()
def preview(
    path: Path = typer.Argument(".", help="Project path to preview"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
) -> None:
    """Detect, install, run, monitor, and open dashboard for a project."""
    _init_lang(lang, path)
    asyncio.run(_run_preview(path))


# ---------------------------------------------------------------------------
#  watch
# ---------------------------------------------------------------------------

@app.command()
def watch(
    path: Path = typer.Argument(".", help="Project path to watch"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
) -> None:
    """Preview with file watching for auto-refresh."""
    _init_lang(lang, path)
    asyncio.run(_run_preview(path, enable_watcher=True))


# ---------------------------------------------------------------------------
#  refresh
# ---------------------------------------------------------------------------

async def _run_refresh(path: Path) -> None:
    """Re-detect and restart services."""
    from pvr.manifest.schema import Manifest
    from pvr.detector.registry import DetectorRegistry
    from pvr.monitor.event_bus import EventBus

    project_path = path.resolve()
    manifest_path = project_path / ".pvr" / "manifest.json"

    if not manifest_path.exists():
        log_error(T("no_project_detected", path=str(project_path)))
        raise typer.Exit(1)

    old_manifest = Manifest.load(manifest_path)

    log_info(T("detecting_project"))
    registry = DetectorRegistry()
    services = registry.detect(project_path)

    if not services:
        log_error(T("no_project_detected", path=str(project_path)))
        raise typer.Exit(1)

    for svc in services:
        log_success(T("detected_as", project_type=svc.project_type))

    # Update manifest
    new_manifest = old_manifest.model_copy(update={
        "services": services,
        "detected_at": datetime.now(timezone.utc).isoformat(),
    })
    new_manifest.save(manifest_path)
    log_success("Manifest refreshed")


@app.command()
def refresh(
    path: Path = typer.Argument(".", help="Project path"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
) -> None:
    """Re-detect and restart services."""
    _init_lang(lang, path)
    asyncio.run(_run_refresh(path))


# ---------------------------------------------------------------------------
#  status
# ---------------------------------------------------------------------------

async def _run_status(path: Path) -> None:
    """Load manifest, probe running services, output RuntimeState JSON."""
    from pvr.manifest.schema import Manifest
    from pvr.monitor.event_bus import EventBus
    from pvr.runner.manager import RunnerManager
    from pvr.monitor.aggregator import RuntimeAggregator
    from pvr.runner.process import ProcessRunner

    project_path = path.resolve()
    manifest_path = project_path / ".pvr" / "manifest.json"

    if not manifest_path.exists():
        log_error(T("no_project_detected", path=str(project_path)))
        raise typer.Exit(1)

    manifest = Manifest.load(manifest_path)
    event_bus = EventBus()
    runner_manager = RunnerManager(event_bus, project_path)

    for svc in manifest.services:
        runner = ProcessRunner(svc, event_bus, project_path)
        runner.state = "RUNNING"
        runner_manager.runners[svc.name] = runner

    aggregator = RuntimeAggregator(runner_manager, event_bus, manifest.session_id)
    state = await aggregator.aggregate()
    console.print_json(state.model_dump_json(indent=2))


@app.command()
def status(
    path: Path = typer.Argument(".", help="Project path"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
) -> None:
    """Show runtime status as JSON."""
    _init_lang(lang, path)
    asyncio.run(_run_status(path))


# ---------------------------------------------------------------------------
#  stop
# ---------------------------------------------------------------------------

@app.command()
def stop(
    path: Path = typer.Argument(".", help="Project path"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
) -> None:
    """Stop all running services."""
    _init_lang(lang, path)
    log_info(T("stopping_services"))
    log_success(T("all_stopped"))


# ---------------------------------------------------------------------------
#  doctor
# ---------------------------------------------------------------------------

async def _run_doctor(path: Path, json_output: bool) -> None:
    """Run diagnostics."""
    from pvr.manifest.schema import Manifest
    from pvr.monitor.event_bus import EventBus
    from pvr.runner.manager import RunnerManager
    from pvr.monitor.aggregator import RuntimeAggregator
    from pvr.runner.process import ProcessRunner
    from pvr.doctor.diagnose import DiagnosticEngine
    from pvr.core.context import RuntimeContext
    from rich.table import Table

    project_path = path.resolve()
    manifest_path = project_path / ".pvr" / "manifest.json"

    if not manifest_path.exists():
        log_error(T("no_project_detected", path=str(project_path)))
        raise typer.Exit(1)

    manifest = Manifest.load(manifest_path)
    event_bus = EventBus()
    runner_manager = RunnerManager(event_bus, project_path)

    for svc in manifest.services:
        runner = ProcessRunner(svc, event_bus, project_path)
        runner.state = "RUNNING"
        runner_manager.runners[svc.name] = runner

    aggregator = RuntimeAggregator(runner_manager, event_bus, manifest.session_id)
    ctx = RuntimeContext(
        session_id=manifest.session_id,
        project_root=str(project_path),
        manifest=manifest,
        runner_manager=runner_manager,
        aggregator=aggregator,
        event_bus=event_bus,
    )

    engine = DiagnosticEngine()
    reports = await engine.diagnose(ctx)

    if json_output:
        console.print_json(json_mod.dumps([r.model_dump() for r in reports], indent=2, ensure_ascii=False))
    else:
        table = Table(title=T("doctor_report", name=T("app_name")))
        table.add_column("Service", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("Reason")
        table.add_column("Suggestion")

        for r in reports:
            status_style = {
                "HEALTHY": "green",
                "DEGRADED": "yellow",
                "FAILED": "red",
                "CRASHED": "red",
            }.get(r.status, "blue")
            table.add_row(r.service, f"[{status_style}]{r.status}[/{status_style}]", r.reason, r.suggestion)

        console.print(table)


@app.command()
def doctor(
    path: Path = typer.Argument(".", help="Project path"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Run diagnostics on services."""
    _init_lang(lang, path)
    asyncio.run(_run_doctor(path, json_output))


# ---------------------------------------------------------------------------
#  sessions
# ---------------------------------------------------------------------------

@sessions_app.command("list")
def sessions_list(
    path: Path = typer.Argument(".", help="Project path"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
) -> None:
    """List all sessions."""
    _init_lang(lang)
    from pvr.runtime.history import list_session_history
    from rich.table import Table

    project_path = path.resolve()
    sessions = list_session_history(project_path)

    if not sessions:
        log_info(T("sessions_empty"))
        return

    table = Table(title=T("sessions_list_header"))
    table.add_column("Session ID", style="cyan")
    table.add_column("Created At")
    table.add_column("Services")

    for s in sessions:
        sid = s.get("session_id", "?")
        created = s.get("detected_at", s.get("created_at", "?"))
        svcs = s.get("services", [])
        svc_names = ", ".join(
            sv.get("name", "?") if isinstance(sv, dict) else str(sv)
            for sv in svcs
        ) if svcs else "-"
        table.add_row(sid, created, svc_names)

    console.print(table)


@sessions_app.command("show")
def sessions_show(
    session_id: str = typer.Argument(..., help="Session ID"),
    path: Path = typer.Argument(".", help="Project path"),
    lang: Optional[str] = typer.Option(None, "--lang", help="Language: zh-CN, zh-TW, en"),
) -> None:
    """Show session details."""
    _init_lang(lang)
    from pvr.runtime.history import get_session_history
    from pvr.runtime.snapshot import load_latest_snapshot

    project_path = path.resolve()
    data = get_session_history(session_id, project_path)

    if not data:
        log_error(f"Session {session_id} not found")
        raise typer.Exit(1)

    console.print_json(json_mod.dumps(data, indent=2, ensure_ascii=False))

    snapshot = load_latest_snapshot(session_id, project_path)
    if snapshot:
        log_info("Latest snapshot:")
        console.print_json(snapshot.model_dump_json(indent=2))


# ---------------------------------------------------------------------------
#  config
# ---------------------------------------------------------------------------

@config_app.command("lang")
def config_lang(
    locale: str = typer.Argument(..., help="Locale: zh-CN, zh-TW, en"),
) -> None:
    """Set the display language."""
    save_config_locale(locale)
    set_locale(locale)
    log_success(T("lang_switched", lang=locale))


# ---------------------------------------------------------------------------
#  config ai
# ---------------------------------------------------------------------------

@config_ai_app.command("show")
def config_ai_show(
    path: Path = typer.Argument(".", help="Project path"),
) -> None:
    """Show current AI configuration."""
    from pvr.ai.config import load_ai_config

    project_path = path.resolve()
    cfg = load_ai_config(project_path)
    if not cfg:
        log_info(T("ai_no_key"))
        return
    log_info(T("ai_config_show", model=cfg.model, base_url=cfg.base_url))


@config_ai_app.command("set")
def config_ai_set(
    preset: str = typer.Argument(..., help="Provider preset: kimi, openai, qwen, deepseek, gemini, anthropic"),
    api_key: str = typer.Argument(..., help="API key for the provider"),
    path: Path = typer.Option(Path("."), "--path", help="Project path"),
    base_url: Optional[str] = typer.Option(None, "--base-url", help="Custom base URL (overrides preset)"),
    model: Optional[str] = typer.Option(None, "--model", help="Custom model name (overrides preset)"),
) -> None:
    """Configure AI provider using a named preset or custom settings."""
    from pvr.ai.config import AIConfig, PRESETS, save_ai_config

    project_path = path.resolve()
    preset_data = PRESETS.get(preset.lower(), {})
    if not preset_data and not base_url:
        available = ", ".join(PRESETS.keys())
        log_error(f"Unknown preset '{preset}'. Available: {available}")
        raise typer.Exit(1)

    provider_name = preset.lower() if preset_data else "custom"
    cfg = AIConfig(
        api_key=api_key,
        base_url=base_url or preset_data.get("base_url", "https://api.openai.com/v1"),
        model=model or preset_data.get("model", "gpt-4o-mini"),
        provider=provider_name,
    )
    save_ai_config(cfg, project_path)
    log_success(T("ai_config_saved", provider=provider_name, model=cfg.model))


@config_ai_app.command("model")
def config_ai_model(
    model_name: str = typer.Argument(..., help="Model name to switch to"),
    path: Path = typer.Option(Path("."), "--path", help="Project path"),
) -> None:
    """Switch AI model without re-entering API key."""
    from pvr.ai.config import load_ai_config, save_ai_config, get_available_models

    project_path = path.resolve()
    cfg = load_ai_config(project_path)
    if not cfg:
        log_error(T("ai_no_key"))
        raise typer.Exit(1)

    available = get_available_models(project_path)
    if available and model_name not in available:
        log_error(f"Unknown model '{model_name}'. Available: {', '.join(available)}")
        raise typer.Exit(1)

    cfg.model = model_name
    save_ai_config(cfg, project_path)
    log_success(T("ai_model_switched", model=model_name))


def app_entry() -> None:
    """Entry point for the pvr CLI."""
    app()
