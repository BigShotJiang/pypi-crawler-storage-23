"""File watcher with debounce — triggers refresh on file changes."""

import asyncio
import time
from pathlib import Path
from typing import Optional

from watchdog.events import FileSystemEventHandler, FileSystemEvent
from watchdog.observers import Observer

from pvr.config import DEBOUNCE_SECONDS, IGNORE_DIRS
from pvr.monitor.event_bus import EventBus, EventType


class _Handler(FileSystemEventHandler):
    """Debounced file change handler."""

    def __init__(self, event_bus: EventBus, loop: asyncio.AbstractEventLoop) -> None:
        self._event_bus = event_bus
        self._loop = loop
        self._last_trigger = 0.0

    def _should_ignore(self, path: str) -> bool:
        parts = Path(path).parts
        return any(p in IGNORE_DIRS for p in parts)

    def on_any_event(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        if self._should_ignore(event.src_path):
            return

        now = time.monotonic()
        if now - self._last_trigger < DEBOUNCE_SECONDS:
            return
        self._last_trigger = now

        asyncio.run_coroutine_threadsafe(
            self._event_bus.emit(EventType.FILE_CHANGED, {"path": event.src_path}),
            self._loop,
        )


class DevPreviewWatcher:
    """Watch a directory for file changes and emit events."""

    def __init__(self, path: Path, event_bus: EventBus) -> None:
        self.path = path
        self.event_bus = event_bus
        self._observer: Optional[Observer] = None

    def start(self, loop: asyncio.AbstractEventLoop) -> None:
        """Start watching (runs in a background thread via watchdog)."""
        handler = _Handler(self.event_bus, loop)
        self._observer = Observer()
        self._observer.schedule(handler, str(self.path), recursive=True)
        self._observer.daemon = True
        self._observer.start()

    def stop(self) -> None:
        """Stop watching."""
        if self._observer:
            self._observer.stop()
            self._observer.join(timeout=2)
