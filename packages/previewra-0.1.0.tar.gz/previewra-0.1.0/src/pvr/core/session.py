"""Session management: create, list, get."""

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from pvr.config import get_sessions_dir


class SessionManager:
    """Manages pvr sessions."""

    def __init__(self, project_root: Path | None = None):
        self.project_root = project_root or Path.cwd()
        self.sessions_dir = get_sessions_dir(self.project_root)

    def create_session(self) -> str:
        """Create a new session with directory structure. Returns session_id."""
        session_id = uuid.uuid4().hex[:12]
        session_dir = self.sessions_dir / session_id

        (session_dir / "logs").mkdir(parents=True, exist_ok=True)
        (session_dir / "snapshots").mkdir(parents=True, exist_ok=True)

        meta = {
            "session_id": session_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "project_root": str(self.project_root),
        }
        with open(session_dir / "manifest.json", "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)

        return session_id

    def list_sessions(self) -> list[dict]:
        """List all sessions."""
        if not self.sessions_dir.exists():
            return []

        sessions = []
        for d in sorted(self.sessions_dir.iterdir()):
            if not d.is_dir():
                continue
            manifest_path = d / "manifest.json"
            if manifest_path.exists():
                try:
                    with open(manifest_path, encoding="utf-8") as f:
                        data = json.load(f)
                    sessions.append(data)
                except (json.JSONDecodeError, OSError):
                    sessions.append({"session_id": d.name})
            else:
                sessions.append({"session_id": d.name})
        return sessions

    def get_session(self, session_id: str) -> dict | None:
        """Get a single session by ID."""
        session_dir = self.sessions_dir / session_id
        manifest_path = session_dir / "manifest.json"
        if not manifest_path.exists():
            return None
        try:
            with open(manifest_path, encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return None
