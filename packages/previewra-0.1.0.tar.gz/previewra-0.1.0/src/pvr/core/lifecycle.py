"""Lifecycle state enum."""

from enum import Enum


class LifecycleState(str, Enum):
    DETECTED = "DETECTED"
    INSTALLING = "INSTALLING"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    MONITORING = "MONITORING"
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    FAILED = "FAILED"
    CRASHED = "CRASHED"
    STOPPED = "STOPPED"
