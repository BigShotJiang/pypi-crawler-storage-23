"""RuntimeContext — central state holder for a pvr session."""

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class RuntimeContext:
    """Holds all runtime references for a pvr session."""

    session_id: str = ""
    project_root: str = ""
    manifest: Any = None
    runner_manager: Any = None
    aggregator: Any = None
    event_bus: Any = None
    dashboard: Any = None
