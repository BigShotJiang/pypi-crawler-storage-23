"""WebSocket handlers for real-time logs and status."""

import asyncio
import json

from fastapi import WebSocket, WebSocketDisconnect

from pvr.core.context import RuntimeContext


async def ws_logs(websocket: WebSocket, context: RuntimeContext) -> None:
    """Stream log lines via WebSocket. Checks for new lines every 500ms."""
    await websocket.accept()

    # Track how many lines we've sent per runner
    sent_counts: dict[str, int] = {}

    try:
        while True:
            if context.runner_manager:
                for name, runner in context.runner_manager.runners.items():
                    prev = sent_counts.get(name, 0)
                    current_len = len(runner.log_buffer)
                    if current_len > prev:
                        new_lines = list(runner.log_buffer)[prev:current_len]
                        for line in new_lines:
                            await websocket.send_json({
                                "service": name,
                                "line": line,
                            })
                        sent_counts[name] = current_len
            await asyncio.sleep(0.5)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass


async def ws_status(websocket: WebSocket, context: RuntimeContext) -> None:
    """Push RuntimeState JSON every 2 seconds."""
    await websocket.accept()

    try:
        while True:
            if context.aggregator:
                state = await context.aggregator.aggregate()
                await websocket.send_text(state.model_dump_json())
            await asyncio.sleep(2)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
