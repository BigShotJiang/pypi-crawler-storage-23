"""Dashboard FastAPI application."""

import asyncio
from pathlib import Path

from fastapi import FastAPI, Request, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

from pvr.core.context import RuntimeContext
from pvr.dashboard.proxy import proxy_request
from pvr.dashboard.ws import ws_logs, ws_status
from pvr.i18n import get_all_messages, set_locale, get_locale

STATIC_DIR = Path(__file__).parent / "static"


async def _heal_background(context: RuntimeContext, ai_cfg, initial_state) -> None:
    """Run AutoHealer in background and hot-swap runner_manager/aggregator on success."""
    from pvr.ai.healer import AutoHealer
    from pvr.runner.manager import RunnerManager
    from pvr.monitor.aggregator import RuntimeAggregator

    healer = AutoHealer()
    services = list(context.manifest.services)

    try:
        fixed_services = await healer.heal(
            Path(context.project_root), services,
            context.runner_manager, initial_state, ai_cfg,
        )
    except Exception:
        return

    if not fixed_services:
        return

    # Stop old services
    if context.runner_manager:
        await context.runner_manager.stop_all()

    # Update manifest with fixed service configs
    context.manifest = context.manifest.model_copy(update={"services": fixed_services})

    # Start new runner_manager
    new_rm = RunnerManager(context.event_bus, Path(context.project_root))
    await new_rm.start_all(fixed_services)
    context.runner_manager = new_rm

    # Replace aggregator
    if context.aggregator:
        await context.aggregator.stop_periodic_check()
    new_agg = RuntimeAggregator(new_rm, context.event_bus, context.session_id)
    await new_agg.start_periodic_check()
    context.aggregator = new_agg


def create_dashboard_app(context: RuntimeContext) -> FastAPI:
    """Create and configure the Dashboard FastAPI app."""
    dashboard = FastAPI(title="Previewra Dashboard", docs_url=None, redoc_url=None)

    dashboard.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # --- Static ---

    @dashboard.get("/")
    async def index():
        return FileResponse(STATIC_DIR / "index.html")

    # --- API ---

    @dashboard.get("/api/status")
    async def api_status():
        if context.aggregator:
            state = await context.aggregator.aggregate()
            return JSONResponse(state.model_dump())
        return JSONResponse({"error": "No aggregator"}, status_code=503)

    @dashboard.get("/api/logs")
    async def api_logs(service: str = "", n: int = 100):
        if not context.runner_manager:
            return JSONResponse([])
        if service:
            runner = context.runner_manager.get_runner(service)
            if runner:
                return JSONResponse([
                    {"service": service, "line": l}
                    for l in runner.get_recent_logs(n)
                ])
            return JSONResponse([])
        # All services
        lines = []
        for name, runner in context.runner_manager.runners.items():
            for l in runner.get_recent_logs(n):
                lines.append({"service": name, "line": l})
        return JSONResponse(lines[-n:])

    @dashboard.get("/api/manifest")
    async def api_manifest():
        if context.manifest:
            return JSONResponse(context.manifest.model_dump())
        return JSONResponse({"error": "No manifest"}, status_code=503)

    @dashboard.get("/api/doctor")
    async def api_doctor():
        from pvr.doctor.diagnose import DiagnosticEngine
        engine = DiagnosticEngine()
        reports = await engine.diagnose(context)
        return JSONResponse([r.model_dump() for r in reports])

    @dashboard.get("/api/i18n")
    async def api_i18n():
        return JSONResponse(get_all_messages())

    @dashboard.post("/api/heal")
    async def api_heal():
        """Trigger AI self-correction for CRASHED/FAILED services (previewra config mistakes only)."""
        from pvr.ai.config import load_ai_config

        if not context.runner_manager or not context.aggregator:
            return JSONResponse({"error": "No runner"}, status_code=503)

        ai_cfg = load_ai_config(Path(context.project_root))
        if not ai_cfg:
            return JSONResponse({"error": "no_ai_key"}, status_code=400)

        state = await context.aggregator.aggregate()
        # Only attempt self-correction when previewra failed to launch the service.
        # DEGRADED means the service IS running but returning 5xx — that's user code, not us.
        if state.overall_status not in ("CRASHED", "FAILED"):
            return JSONResponse({"status": "healthy", "skipped": True})

        asyncio.create_task(_heal_background(context, ai_cfg, state))
        return JSONResponse({"status": "healing_started"})

    @dashboard.post("/api/refresh")
    async def api_refresh():
        # Will be fully implemented in Phase 6
        return JSONResponse({"status": "ok"})

    @dashboard.post("/api/restart/{service}")
    async def api_restart(service: str):
        if context.runner_manager:
            await context.runner_manager.restart_service(service)
            return JSONResponse({"status": "restarted", "service": service})
        return JSONResponse({"error": "No runner"}, status_code=503)

    @dashboard.post("/api/stop")
    async def api_stop():
        if context.runner_manager:
            await context.runner_manager.stop_all()
            return JSONResponse({"status": "stopped"})
        return JSONResponse({"error": "No runner"}, status_code=503)

    @dashboard.post("/api/lang/{locale}")
    async def api_lang(locale: str):
        set_locale(locale)
        return JSONResponse({"status": "ok", "locale": locale})

    @dashboard.get("/api/ai/models")
    async def api_ai_models():
        from pvr.ai.config import load_ai_config, get_available_models
        project_path = Path(context.project_root)
        cfg = load_ai_config(project_path)
        models = get_available_models(project_path)
        return JSONResponse({
            "models": models,
            "current": cfg.model if cfg else "",
            "provider": cfg.provider if cfg else "",
        })

    @dashboard.post("/api/ai/model/{model}")
    async def api_ai_model(model: str):
        from pvr.ai.config import load_ai_config, save_ai_config, get_available_models
        project_path = Path(context.project_root)
        cfg = load_ai_config(project_path)
        if not cfg:
            return JSONResponse({"error": "no_ai_key"}, status_code=400)
        available = get_available_models(project_path)
        if available and model not in available:
            return JSONResponse({"error": f"Unknown model: {model}"}, status_code=400)
        cfg.model = model
        save_ai_config(cfg, project_path)
        return JSONResponse({"status": "ok", "model": model})

    # --- WebSocket ---

    @dashboard.websocket("/ws/logs")
    async def websocket_logs(websocket: WebSocket):
        await ws_logs(websocket, context)

    @dashboard.websocket("/ws/status")
    async def websocket_status(websocket: WebSocket):
        await ws_status(websocket, context)

    # --- Reverse Proxy ---

    @dashboard.api_route(
        "/preview/{service_name}/{path:path}",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
    )
    async def preview_proxy(service_name: str, path: str, request: Request):
        return await proxy_request(service_name, path, request, context)

    # Also handle /preview/{service_name}/ with empty path
    @dashboard.api_route(
        "/preview/{service_name}/",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
    )
    async def preview_proxy_root(service_name: str, request: Request):
        return await proxy_request(service_name, "", request, context)

    return dashboard
