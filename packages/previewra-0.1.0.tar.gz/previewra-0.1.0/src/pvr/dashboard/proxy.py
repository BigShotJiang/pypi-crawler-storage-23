"""Reverse proxy handler for previewing services."""

import re
from typing import Optional

from fastapi import Request
from fastapi.responses import Response

import httpx

from pvr.core.context import RuntimeContext

# Regex to rewrite absolute paths in HTML attributes (href="/...", src="/...", action="/...")
# Matches href="/ or src='/ or action="/ but NOT href="// (protocol-relative)
_ATTR_RE = re.compile(
    r"""((?:href|src|action|data-src)\s*=\s*['"])\/(?!\/)""",
    re.IGNORECASE,
)

# Fetch/XHR interceptor script injected into HTML pages.
# Rewrites absolute-path fetch/XHR URLs to go through the proxy prefix.
_INTERCEPTOR_TEMPLATE = """<script>(function(){{
var P='{prefix}';
var _f=window.fetch;
window.fetch=function(u,o){{if(typeof u==='string'&&u.charAt(0)==='/'&&u.indexOf(P)!==0)u=P+u;return _f.call(this,u,o)}};
var _o=XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open=function(m,u){{if(typeof u==='string'&&u.charAt(0)==='/'&&u.indexOf(P)!==0)u=P+u;return _o.apply(this,arguments)}};
}})();</script>"""


def _rewrite_html(content: bytes, service_name: str) -> bytes:
    """Rewrite absolute paths in HTML so resources load through the proxy."""
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        return content

    prefix = f"/preview/{service_name}"

    # 1. Rewrite href="/...", src="/...", action="/..." to go through proxy
    text = _ATTR_RE.sub(rf"\1{prefix}/", text)

    # 2. Rewrite url('/...') in inline CSS
    text = re.sub(
        r"""(url\s*\(\s*['"])\/(?!\/)""",
        rf"\1{prefix}/",
        text,
    )

    # 3. Inject fetch/XHR interceptor right after <head> (or at start if no <head>)
    interceptor = _INTERCEPTOR_TEMPLATE.format(prefix=prefix)
    if "<head>" in text:
        text = text.replace("<head>", "<head>" + interceptor, 1)
    elif "<head " in text.lower():
        text = re.sub(
            r"(<head[^>]*>)", r"\1" + interceptor, text, count=1, flags=re.IGNORECASE
        )
    elif "<html" in text.lower():
        text = re.sub(
            r"(<html[^>]*>)", r"\1" + interceptor, text, count=1, flags=re.IGNORECASE
        )

    return text.encode("utf-8")


async def proxy_request(
    service_name: str,
    path: str,
    request: Request,
    context: RuntimeContext,
) -> Response:
    """Proxy a request to the target service."""
    # Find service port
    if not context.manifest:
        return Response(content="No manifest loaded", status_code=502)

    service = None
    for svc in context.manifest.services:
        if svc.name == service_name:
            service = svc
            break

    if service is None:
        return Response(content=f"Service '{service_name}' not found", status_code=404)

    # Prefer the runner's live port (updated by port discovery) over the manifest's
    # static port (which may reflect only the detected default, e.g. 5000 for Flask).
    live_port: Optional[int] = None
    if context.runner_manager:
        runner = context.runner_manager.get_runner(service_name)
        if runner:
            live_port = runner.service_config.port

    port = live_port or service.port
    if not port:
        return Response(content=f"Service '{service_name}' has no port", status_code=502)

    target_url = f"http://127.0.0.1:{port}/{path}"
    if request.url.query:
        target_url += f"?{request.url.query}"

    # Filter hop-by-hop headers
    skip_headers = {"host", "connection", "transfer-encoding"}
    fwd_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in skip_headers
    }

    try:
        async with httpx.AsyncClient(trust_env=False) as client:
            proxy_resp = await client.request(
                method=request.method,
                url=target_url,
                headers=fwd_headers,
                content=await request.body(),
                timeout=10.0,
                follow_redirects=True,
            )

        # Filter response hop-by-hop headers
        resp_headers = {
            k: v for k, v in proxy_resp.headers.items()
            if k.lower() not in ("transfer-encoding", "connection", "content-encoding")
        }

        content = proxy_resp.content

        # Rewrite HTML content to fix absolute paths
        content_type = proxy_resp.headers.get("content-type", "")
        if "text/html" in content_type:
            content = _rewrite_html(content, service_name)
            # Update content-length after rewriting
            resp_headers.pop("content-length", None)

        # Rewrite CSS content to fix url('/...') paths
        if "text/css" in content_type:
            try:
                css_text = content.decode("utf-8")
                prefix = f"/preview/{service_name}"
                css_text = re.sub(
                    r"""(url\s*\(\s*['"]?)\/(?!\/)""",
                    rf"\1{prefix}/",
                    css_text,
                )
                content = css_text.encode("utf-8")
                resp_headers.pop("content-length", None)
            except UnicodeDecodeError:
                pass

        return Response(
            content=content,
            status_code=proxy_resp.status_code,
            headers=resp_headers,
        )
    except httpx.TimeoutException:
        return Response(content="Proxy timeout", status_code=504)
    except Exception as e:
        return Response(content=f"Proxy error: {e}", status_code=502)
