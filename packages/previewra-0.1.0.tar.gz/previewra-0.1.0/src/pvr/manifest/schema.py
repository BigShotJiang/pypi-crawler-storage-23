"""Manifest and ServiceConfig Pydantic models."""

import json
from pathlib import Path
from typing import Literal, Optional

from pydantic import BaseModel


class ServiceConfig(BaseModel):
    name: str
    project_type: str
    start_command: str
    install_command: Optional[str] = None
    port: Optional[int] = None
    env: dict[str, str] = {}
    working_dir: Optional[str] = None


class ProcessInfo(BaseModel):
    pid: int
    status: str  # "running", "sleeping", "dead"
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    uptime_seconds: float = 0.0


class PortInfo(BaseModel):
    port: int
    status: Literal["CONNECTION_REFUSED", "TIMEOUT", "HTTP_200", "HTTP_500", "HTTP_OTHER"]
    response_time_ms: float = 0.0
    content_length: int = 0
    status_code: Optional[int] = None


class HealthResult(BaseModel):
    status: Literal["HEALTHY", "DEGRADED", "FAILED"]
    checks: list[dict] = []


class SimulatorResult(BaseModel):
    passed: bool
    checks: dict = {}
    error: Optional[str] = None


class ServiceRuntimeState(BaseModel):
    name: str
    process: Optional[ProcessInfo] = None
    port: Optional[PortInfo] = None
    health: Optional[HealthResult] = None
    simulator: Optional[SimulatorResult] = None
    status: Literal["STARTING", "RUNNING", "HEALTHY", "DEGRADED", "FAILED", "CRASHED", "STOPPED"] = "STARTING"


class RuntimeState(BaseModel):
    session_id: str
    services: dict[str, ServiceRuntimeState]
    overall_status: Literal["STARTING", "HEALTHY", "DEGRADED", "FAILED", "CRASHED"] = "STARTING"
    timestamp: str


class DiagnosticReport(BaseModel):
    session_id: str
    service: str
    status: str
    reason: str
    details: dict = {}
    suggestion: str = ""
    timestamp: str


class Manifest(BaseModel):
    version: str = "2"
    session_id: str
    project_root: str
    services: list[ServiceConfig]
    detected_at: str
    locale: str = "en"

    def save(self, path: Path) -> None:
        """Save manifest to a JSON file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.model_dump_json(indent=2))

    @classmethod
    def load(cls, path: Path) -> "Manifest":
        """Load manifest from a JSON file."""
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return cls.model_validate(data)
