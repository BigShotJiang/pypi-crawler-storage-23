"""RuntimeState snapshot save/load."""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from pvr.config import get_sessions_dir
from pvr.manifest.schema import RuntimeState


def save_snapshot(session_id: str, runtime_state: RuntimeState, project_root: Path | None = None) -> Path:
    """Save a RuntimeState snapshot to sessions/{id}/snapshots/{timestamp}.json."""
    sessions_dir = get_sessions_dir(project_root)
    snapshots_dir = sessions_dir / session_id / "snapshots"
    snapshots_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    path = snapshots_dir / f"{ts}.json"
    with open(path, "w", encoding="utf-8") as f:
        f.write(runtime_state.model_dump_json(indent=2))
    return path


def load_latest_snapshot(session_id: str, project_root: Path | None = None) -> Optional[RuntimeState]:
    """Load the most recent snapshot for a session."""
    sessions_dir = get_sessions_dir(project_root)
    snapshots_dir = sessions_dir / session_id / "snapshots"

    if not snapshots_dir.exists():
        return None

    files = sorted(snapshots_dir.glob("*.json"))
    if not files:
        return None

    latest = files[-1]
    try:
        with open(latest, encoding="utf-8") as f:
            data = json.load(f)
        return RuntimeState.model_validate(data)
    except (json.JSONDecodeError, OSError, Exception):
        return None
