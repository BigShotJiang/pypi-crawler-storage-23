"""Session history CRUD."""

import json
from pathlib import Path

from pvr.config import get_sessions_dir


def save_session_history(session_id: str, manifest_data: dict, project_root: Path | None = None) -> None:
    """Save session manifest to .pvr/sessions/{id}/manifest.json."""
    sessions_dir = get_sessions_dir(project_root)
    session_dir = sessions_dir / session_id
    session_dir.mkdir(parents=True, exist_ok=True)

    manifest_path = session_dir / "manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f, ensure_ascii=False, indent=2)


def list_session_history(project_root: Path | None = None) -> list[dict]:
    """List all sessions from .pvr/sessions/."""
    sessions_dir = get_sessions_dir(project_root)
    if not sessions_dir.exists():
        return []

    sessions = []
    for d in sorted(sessions_dir.iterdir()):
        if not d.is_dir():
            continue
        manifest_path = d / "manifest.json"
        if manifest_path.exists():
            try:
                with open(manifest_path, encoding="utf-8") as f:
                    data = json.load(f)
                data["session_id"] = data.get("session_id", d.name)
                sessions.append(data)
            except (json.JSONDecodeError, OSError):
                sessions.append({"session_id": d.name})
        else:
            sessions.append({"session_id": d.name})
    return sessions


def get_session_history(session_id: str, project_root: Path | None = None) -> dict | None:
    """Get a single session's data."""
    sessions_dir = get_sessions_dir(project_root)
    session_dir = sessions_dir / session_id
    manifest_path = session_dir / "manifest.json"

    if not manifest_path.exists():
        return None

    try:
        with open(manifest_path, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
