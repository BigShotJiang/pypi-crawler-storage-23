"""Einstein Probe (EP) mission-specific utilities.

This module provides mission-specific helpers for Einstein Probe observations.
"""

from __future__ import annotations

__all__ = []
