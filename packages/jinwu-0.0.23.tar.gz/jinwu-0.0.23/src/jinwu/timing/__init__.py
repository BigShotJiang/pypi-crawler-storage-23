"""Timing analysis utilities.

This module provides timing-related analysis tools for high-energy astrophysics.
"""

from __future__ import annotations

__all__ = []
