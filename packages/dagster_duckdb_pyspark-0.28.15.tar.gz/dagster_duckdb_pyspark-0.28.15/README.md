# dagster-duckdb-pyspark

The docs for `dagster-duckdb-pyspark` can be found
[here](https://docs.dagster.io/integrations/libraries/duckdb/dagster-duckdb-pyspark).
