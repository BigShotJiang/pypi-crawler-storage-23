"""LangChain tools for Nativ — AI-powered localization.

Quickstart::

    from langchain_nativ import NativToolkit

    tools = NativToolkit().get_tools()       # reads NATIV_API_KEY from env
    tools = NativToolkit(api_key="nativ_...").get_tools()
"""

from langchain_nativ.tools import (
    NativAddTranslationMemoryEntryTool,
    NativGetBrandVoiceTool,
    NativGetLanguagesTool,
    NativGetStyleGuidesTool,
    NativGetTranslationMemoryStatsTool,
    NativSearchTranslationMemoryTool,
    NativToolkit,
    NativTranslateBatchTool,
    NativTranslateTool,
)

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "NativToolkit",
    "NativTranslateTool",
    "NativTranslateBatchTool",
    "NativSearchTranslationMemoryTool",
    "NativAddTranslationMemoryEntryTool",
    "NativGetLanguagesTool",
    "NativGetStyleGuidesTool",
    "NativGetBrandVoiceTool",
    "NativGetTranslationMemoryStatsTool",
]
