"""LangChain tools for the Nativ AI localization platform.

Each tool wraps a method on the ``nativ.Nativ`` / ``nativ.AsyncNativ``
client and returns a human-readable string so LLM agents can consume
the output directly.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Type

from langchain_core.callbacks import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

import nativ as _nativ_sdk


# ---------------------------------------------------------------------------
# Input schemas
# ---------------------------------------------------------------------------


class _TranslateInput(BaseModel):
    text: str = Field(description="The text to translate.")
    target_language: str = Field(
        description="Full target language name, e.g. 'French', 'German', 'Japanese'."
    )
    target_language_code: Optional[str] = Field(
        default=None,
        description="ISO language code, e.g. 'fr', 'de', 'ja'. Auto-detected if omitted.",
    )
    source_language: str = Field(
        default="English", description="Source language name."
    )
    source_language_code: str = Field(
        default="en", description="Source language ISO code."
    )
    context: Optional[str] = Field(
        default=None,
        description=(
            "Context to guide the translation, e.g. "
            "'mobile app button', 'marketing headline for Gen Z'."
        ),
    )
    glossary: Optional[str] = Field(
        default=None,
        description="Inline glossary as CSV, e.g. 'term,translation\\nbrand,marque'.",
    )
    formality: Optional[str] = Field(
        default=None,
        description="Tone: very_informal | informal | neutral | formal | very_formal.",
    )
    max_characters: Optional[int] = Field(
        default=None, description="Strict character limit for the output."
    )
    backtranslate: bool = Field(
        default=False,
        description="If true, also return a back-translation to verify intent.",
    )


class _TranslateBatchInput(BaseModel):
    texts: List[str] = Field(description="List of texts to translate.")
    target_language: str = Field(
        description="Full target language name, e.g. 'French'."
    )
    target_language_code: Optional[str] = Field(
        default=None, description="ISO language code."
    )
    source_language: str = Field(default="English", description="Source language name.")
    source_language_code: str = Field(default="en", description="Source language code.")
    context: Optional[str] = Field(
        default=None, description="Context hint for all translations."
    )
    formality: Optional[str] = Field(
        default=None,
        description="Tone: very_informal | informal | neutral | formal | very_formal.",
    )


class _SearchTMInput(BaseModel):
    query: str = Field(description="Text to search for in the translation memory.")
    source_language_code: str = Field(
        default="en", description="Source language code."
    )
    target_language_code: Optional[str] = Field(
        default=None, description="Target language code to filter results."
    )
    min_score: float = Field(
        default=0.0, description="Minimum fuzzy-match score (0–100)."
    )
    limit: int = Field(default=10, description="Maximum number of results.")


class _AddTMEntryInput(BaseModel):
    source_text: str = Field(description="The original text.")
    target_text: str = Field(description="The approved translation.")
    source_language_code: str = Field(
        description="Source language code, e.g. 'en'."
    )
    target_language_code: str = Field(
        description="Target language code, e.g. 'fr'."
    )
    name: Optional[str] = Field(
        default=None,
        description="Optional label for this entry, e.g. 'homepage hero copy'.",
    )


class _EmptyInput(BaseModel):
    """No input required."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fmt_translation(t: _nativ_sdk.Translation) -> str:
    parts = [t.translated_text]
    if t.rationale:
        parts.append(f"Rationale: {t.rationale}")
    if t.backtranslation:
        parts.append(f"Back-translation: {t.backtranslation}")
    if t.tm_match and t.tm_match.score > 0:
        parts.append(
            f"TM match: {t.tm_match.score:.0f}% ({t.tm_match.match_type})"
        )
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------


class _NativTool(BaseTool):
    """Shared config for every Nativ tool."""

    api_key: Optional[str] = Field(default=None, exclude=True)
    base_url: Optional[str] = Field(default=None, exclude=True)

    def _client(self) -> _nativ_sdk.Nativ:
        return _nativ_sdk.Nativ(api_key=self.api_key, base_url=self.base_url)

    def _async_client(self) -> _nativ_sdk.AsyncNativ:
        return _nativ_sdk.AsyncNativ(api_key=self.api_key, base_url=self.base_url)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


class NativTranslateTool(_NativTool):
    """Translate text using Nativ's AI localization engine.

    Automatically leverages the team's translation memory, brand voice,
    and style guides for consistent, on-brand translations.
    """

    name: str = "nativ_translate"
    description: str = (
        "Translate text to another language using Nativ's AI localization engine. "
        "Uses the team's translation memory, brand voice, and style guides "
        "automatically. Returns the translated text with optional rationale "
        "and back-translation."
    )
    args_schema: Type[BaseModel] = _TranslateInput

    def _run(
        self,
        text: str,
        target_language: str,
        target_language_code: Optional[str] = None,
        source_language: str = "English",
        source_language_code: str = "en",
        context: Optional[str] = None,
        glossary: Optional[str] = None,
        formality: Optional[str] = None,
        max_characters: Optional[int] = None,
        backtranslate: bool = False,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            result = c.translate(
                text,
                target_language,
                target_language_code=target_language_code,
                source_language=source_language,
                source_language_code=source_language_code,
                context=context,
                glossary=glossary,
                formality=formality,
                max_characters=max_characters,
                backtranslate=backtranslate,
            )
        return _fmt_translation(result)

    async def _arun(
        self,
        text: str,
        target_language: str,
        target_language_code: Optional[str] = None,
        source_language: str = "English",
        source_language_code: str = "en",
        context: Optional[str] = None,
        glossary: Optional[str] = None,
        formality: Optional[str] = None,
        max_characters: Optional[int] = None,
        backtranslate: bool = False,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            result = await c.translate(
                text,
                target_language,
                target_language_code=target_language_code,
                source_language=source_language,
                source_language_code=source_language_code,
                context=context,
                glossary=glossary,
                formality=formality,
                max_characters=max_characters,
                backtranslate=backtranslate,
            )
        return _fmt_translation(result)


class NativTranslateBatchTool(_NativTool):
    """Translate multiple texts to the same target language in one call."""

    name: str = "nativ_translate_batch"
    description: str = (
        "Translate a list of texts to the same target language. "
        "Returns each translation on its own line."
    )
    args_schema: Type[BaseModel] = _TranslateBatchInput

    def _run(
        self,
        texts: Sequence[str],
        target_language: str,
        target_language_code: Optional[str] = None,
        source_language: str = "English",
        source_language_code: str = "en",
        context: Optional[str] = None,
        formality: Optional[str] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            results = c.translate_batch(
                texts,
                target_language,
                target_language_code=target_language_code,
                source_language=source_language,
                source_language_code=source_language_code,
                context=context,
                formality=formality,
            )
        return "\n".join(
            f"{i+1}. {r.translated_text}" for i, r in enumerate(results)
        )

    async def _arun(
        self,
        texts: Sequence[str],
        target_language: str,
        target_language_code: Optional[str] = None,
        source_language: str = "English",
        source_language_code: str = "en",
        context: Optional[str] = None,
        formality: Optional[str] = None,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            results = await c.translate_batch(
                texts,
                target_language,
                target_language_code=target_language_code,
                source_language=source_language,
                source_language_code=source_language_code,
                context=context,
                formality=formality,
            )
        return "\n".join(
            f"{i+1}. {r.translated_text}" for i, r in enumerate(results)
        )


class NativSearchTranslationMemoryTool(_NativTool):
    """Fuzzy-search the translation memory for existing translations."""

    name: str = "nativ_search_translation_memory"
    description: str = (
        "Search the translation memory for existing translations. "
        "Use this to check if a translation already exists before creating "
        "a new one, or to find reference translations for consistency."
    )
    args_schema: Type[BaseModel] = _SearchTMInput

    def _run(
        self,
        query: str,
        source_language_code: str = "en",
        target_language_code: Optional[str] = None,
        min_score: float = 0.0,
        limit: int = 10,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            matches = c.search_tm(
                query,
                source_language_code=source_language_code,
                target_language_code=target_language_code,
                min_score=min_score,
                limit=limit,
            )
        if not matches:
            return "No matches found in translation memory."
        lines = [f"Found {len(matches)} match(es):"]
        for m in matches:
            lines.append(
                f"- [{m.score:.0f}% {m.match_type}] "
                f'"{m.source_text}" → "{m.target_text}"'
            )
        return "\n".join(lines)

    async def _arun(
        self,
        query: str,
        source_language_code: str = "en",
        target_language_code: Optional[str] = None,
        min_score: float = 0.0,
        limit: int = 10,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            matches = await c.search_tm(
                query,
                source_language_code=source_language_code,
                target_language_code=target_language_code,
                min_score=min_score,
                limit=limit,
            )
        if not matches:
            return "No matches found in translation memory."
        lines = [f"Found {len(matches)} match(es):"]
        for m in matches:
            lines.append(
                f"- [{m.score:.0f}% {m.match_type}] "
                f'"{m.source_text}" → "{m.target_text}"'
            )
        return "\n".join(lines)


class NativAddTranslationMemoryEntryTool(_NativTool):
    """Add an approved translation to the translation memory for reuse."""

    name: str = "nativ_add_translation_memory_entry"
    description: str = (
        "Store an approved translation in the translation memory so it is "
        "reused in future translations. Provide the source text, its "
        "translation, and both language codes."
    )
    args_schema: Type[BaseModel] = _AddTMEntryInput

    def _run(
        self,
        source_text: str,
        target_text: str,
        source_language_code: str,
        target_language_code: str,
        name: Optional[str] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            entry = c.add_tm_entry(
                source_text,
                target_text,
                source_language_code,
                target_language_code,
                name=name,
            )
        return (
            f"Added TM entry {entry.id}: "
            f'"{entry.source_text}" ({entry.source_language_code}) → '
            f'"{entry.target_text}" ({entry.target_language_code})'
        )

    async def _arun(
        self,
        source_text: str,
        target_text: str,
        source_language_code: str,
        target_language_code: str,
        name: Optional[str] = None,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            entry = await c.add_tm_entry(
                source_text,
                target_text,
                source_language_code,
                target_language_code,
                name=name,
            )
        return (
            f"Added TM entry {entry.id}: "
            f'"{entry.source_text}" ({entry.source_language_code}) → '
            f'"{entry.target_text}" ({entry.target_language_code})'
        )


class NativGetLanguagesTool(_NativTool):
    """List languages configured in the Nativ workspace."""

    name: str = "nativ_get_languages"
    description: str = (
        "Get all target languages configured in the Nativ workspace, "
        "including their ISO codes and formality settings."
    )
    args_schema: Type[BaseModel] = _EmptyInput

    def _run(
        self,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            langs = c.get_languages()
        if not langs:
            return "No languages configured."
        lines = ["Configured languages:"]
        for lang in langs:
            entry = f"- {lang.language} ({lang.language_code})"
            if lang.formality:
                entry += f" — formality: {lang.formality}"
            lines.append(entry)
        return "\n".join(lines)

    async def _arun(
        self,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            langs = await c.get_languages()
        if not langs:
            return "No languages configured."
        lines = ["Configured languages:"]
        for lang in langs:
            entry = f"- {lang.language} ({lang.language_code})"
            if lang.formality:
                entry += f" — formality: {lang.formality}"
            lines.append(entry)
        return "\n".join(lines)


class NativGetStyleGuidesTool(_NativTool):
    """Get all style guides configured in the workspace."""

    name: str = "nativ_get_style_guides"
    description: str = (
        "Retrieve the titles and content of all style guides. "
        "Useful for understanding the brand's writing rules before translating."
    )
    args_schema: Type[BaseModel] = _EmptyInput

    def _run(
        self,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            guides = c.get_style_guides()
        if not guides:
            return "No style guides configured."
        lines = [f"Style guides ({len(guides)}):"]
        for g in guides:
            status = "enabled" if g.is_enabled else "disabled"
            lines.append(f"\n## {g.title} [{status}]\n{g.content}")
        return "\n".join(lines)

    async def _arun(
        self,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            guides = await c.get_style_guides()
        if not guides:
            return "No style guides configured."
        lines = [f"Style guides ({len(guides)}):"]
        for g in guides:
            status = "enabled" if g.is_enabled else "disabled"
            lines.append(f"\n## {g.title} [{status}]\n{g.content}")
        return "\n".join(lines)


class NativGetBrandVoiceTool(_NativTool):
    """Get the brand voice prompt that shapes all translations."""

    name: str = "nativ_get_brand_voice"
    description: str = (
        "Get the brand voice prompt — the master prompt that shapes the "
        "tone, personality, and terminology of all translations."
    )
    args_schema: Type[BaseModel] = _EmptyInput

    def _run(
        self,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            bv = c.get_brand_voice()
        if not bv.exists or not bv.prompt:
            return "No brand voice configured."
        return f"Brand voice:\n{bv.prompt}"

    async def _arun(
        self,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            bv = await c.get_brand_voice()
        if not bv.exists or not bv.prompt:
            return "No brand voice configured."
        return f"Brand voice:\n{bv.prompt}"


class NativGetTranslationMemoryStatsTool(_NativTool):
    """Get translation memory statistics."""

    name: str = "nativ_get_translation_memory_stats"
    description: str = (
        "Get statistics about the translation memory: total entries, "
        "enabled/disabled counts, and breakdown by source type."
    )
    args_schema: Type[BaseModel] = _EmptyInput

    def _run(
        self,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        with self._client() as c:
            stats = c.get_tm_stats()
        lines = [
            f"Translation memory: {stats.total} total entries",
            f"  Enabled: {stats.enabled}",
            f"  Disabled: {stats.disabled}",
        ]
        if stats.by_source:
            lines.append("  By source:")
            for source, counts in stats.by_source.items():
                lines.append(f"    {source}: {counts}")
        return "\n".join(lines)

    async def _arun(
        self,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        async with self._async_client() as c:
            stats = await c.get_tm_stats()
        lines = [
            f"Translation memory: {stats.total} total entries",
            f"  Enabled: {stats.enabled}",
            f"  Disabled: {stats.disabled}",
        ]
        if stats.by_source:
            lines.append("  By source:")
            for source, counts in stats.by_source.items():
                lines.append(f"    {source}: {counts}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Toolkit helper
# ---------------------------------------------------------------------------

ALL_TOOLS: List[Type[_NativTool]] = [
    NativTranslateTool,
    NativTranslateBatchTool,
    NativSearchTranslationMemoryTool,
    NativAddTranslationMemoryEntryTool,
    NativGetLanguagesTool,
    NativGetStyleGuidesTool,
    NativGetBrandVoiceTool,
    NativGetTranslationMemoryStatsTool,
]


class NativToolkit:
    """Create LangChain tools backed by the Nativ localization API.

    Usage::

        from langchain_nativ import NativToolkit

        tools = NativToolkit(api_key="nativ_...").get_tools()
        # or let it read NATIV_API_KEY from the environment:
        tools = NativToolkit().get_tools()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url

    def get_tools(self) -> List[BaseTool]:
        """Return all Nativ tools."""
        kwargs: Dict[str, Any] = {
            "api_key": self.api_key,
            "base_url": self.base_url,
        }
        return [cls(**kwargs) for cls in ALL_TOOLS]
