# langchain-nativ

[![PyPI](https://img.shields.io/pypi/v/langchain-nativ)](https://pypi.org/project/langchain-nativ/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

[LangChain](https://www.langchain.com/) integration for **[Nativ](https://usenativ.com)** — AI-powered localization.

Give any LangChain agent the ability to translate text, search translation memory, manage terminology, and more — all backed by your team's brand voice and style guides.

## Installation

```bash
pip install langchain-nativ
```

## Quick start

```python
from langchain_nativ import NativTranslateTool

tool = NativTranslateTool()  # reads NATIV_API_KEY from env

result = tool.invoke({
    "text": "Hello world",
    "target_language": "French",
})
print(result)
# Bonjour le monde
# Rationale: Standard greeting translated with neutral register.
```

## Use with a LangChain agent

```python
from langchain_nativ import NativToolkit
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

tools = NativToolkit().get_tools()
llm = ChatOpenAI(model="gpt-4o")
agent = create_react_agent(llm, tools)

result = agent.invoke({
    "messages": [{
        "role": "user",
        "content": "Translate 'Welcome back!' to French, German, and Japanese",
    }]
})
```

## Available tools

| Tool | Description |
|------|-------------|
| `NativTranslateTool` | Translate text with cultural adaptation |
| `NativTranslateBatchTool` | Translate multiple texts to one language |
| `NativSearchTranslationMemoryTool` | Fuzzy-search existing translations |
| `NativAddTranslationMemoryEntryTool` | Store an approved translation for reuse |
| `NativGetLanguagesTool` | List configured target languages |
| `NativGetStyleGuidesTool` | Get style guide content |
| `NativGetBrandVoiceTool` | Get the brand voice prompt |
| `NativGetTranslationMemoryStatsTool` | Get TM statistics |

## Configuration

All tools accept `api_key` and `base_url` parameters:

```python
tool = NativTranslateTool(api_key="nativ_...", base_url="https://api.usenativ.com")
```

Or set the environment variable:

```bash
export NATIV_API_KEY=nativ_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Use individual tools

```python
from langchain_nativ import NativSearchTranslationMemoryTool

search = NativSearchTranslationMemoryTool()
print(search.invoke({"query": "Welcome"}))
# Found 3 match(es):
# - [98% exact] "Welcome" → "Bienvenue"
# - [85% fuzzy] "Welcome back" → "Content de vous revoir"
# ...
```

## License

MIT
