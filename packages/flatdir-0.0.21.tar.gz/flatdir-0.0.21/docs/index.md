# flatdir

`flatdir` scans a directory tree and generates a flat JSON file with metadata for each entry.

## Installation

# flatdir

`flatdir` scans a directory tree and generates a flat JSON file with metadata for each entry.

## Installation

```bash
pip install -e .
```

Or from PyPI:

```bash
pip install flatdir
```

## Usage

```bash
python -m flatdir .
```
