# contest-client

Python SDK for the `contest-server`.

## Install (dev)
```bash
cd contest_client
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

## Usage
サーバー側で用意されたコンテスト（`contest_id` は運営が `contest-provision --spec ...` 実行時の出力から取得し、必要な範囲で配布する想定）に対して、ユーザー登録・ログイン・提出を行うシナリオをサポートします。コンテスト作成や参加者(チーム)作成はクライアントからできません。
```python
from contest_client import ContestClient

c = ContestClient("http://127.0.0.1:8000")

# contest_id は運営から共有済み
contest_id = "cst_xxxxxx"

# 1) 初回登録
reg = c.register_user(contest_id, user_name="alice", password="secret123")
print("user_id:", reg["user_id"])
print("api_key (use for submissions):", reg["api_key"])

# 2) ログイン（APIキーをローテーションして取得）
login = c.login(contest_id, user_name="alice", password="secret123")
api_key = login["api_key"]

# 3) 提出
res = c.submit(contest_id, user_name="alice", api_key=api_key, x={"x1": 0.1, "x2": 0.7, "x3": 0.9})
print(res)

print(c.leaderboard(contest_id))
```
