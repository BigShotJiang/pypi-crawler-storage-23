from __future__ import annotations
from typing import Any, Dict, List, Tuple, Optional
import requests

class ContestClient:
    def __init__(self, base_url: str, timeout: float = 20.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # ---------------- low-level ----------------
    def _post(self, path: str, json_body: Dict[str, Any], headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        r = requests.post(self.base_url + path, json=json_body, headers=headers or {}, timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        r = requests.get(self.base_url + path, params=params or {}, timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    # ---------------- high-level helpers ----------------
    def get_contest(self, contest_id: str) -> Dict[str, Any]:
        return self._get(f"/contests/{contest_id}")

    def register_user(self, contest_id: str, user_name: str, password: str) -> Dict[str, Any]:
        body = {"contest_id": contest_id, "user_name": user_name, "password": password}
        return self._post("/auth/register", body)

    def login(self, contest_id: str, user_name: str, password: str) -> Dict[str, Any]:
        body = {"contest_id": contest_id, "user_name": user_name, "password": password}
        return self._post("/auth/login", body)

    def submit(self, contest_id: str, user_name: str, api_key: str, x: Dict[str, Any]) -> Dict[str, Any]:
        headers = {"X-API-Key": api_key}
        body = {"user_name": user_name, "x": x}
        return self._post(f"/contests/{contest_id}/submit", body, headers=headers)

    def leaderboard(self, contest_id: str, top: int = 50) -> Dict[str, Any]:
        return self._get(f"/contests/{contest_id}/leaderboard", params={"top": top})
