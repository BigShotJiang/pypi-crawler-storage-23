from .html_report import write_error_model_report_html, write_fitness_report_html

__all__ = ["write_error_model_report_html", "write_fitness_report_html"]
