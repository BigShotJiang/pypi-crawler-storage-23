"""
Platform-specific data models for AiVibe universal platform integration.

Provides TenantInfo (from platform API), TenantStatus (lifecycle enum),
and PlatformSession (holds all platform context for a session including
clients and credentials).

Tenant Lifecycle:
    - Email is the PRIMARY unique identifier across all login methods.
    - All login methods (email+password, OTP, Google, GitHub) for the same
      email map to the same active tenant.
    - When an account is deleted, the tenant status is set to INACTIVE.
      This is irreversible -- there is no mechanism to reactivate an
      inactive tenant.
    - If the same email signs up again after deletion, a NEW tenant ID is
      assigned with ACTIVE status.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime

    from aicippy.billing.models import PlanInfo
    from aicippy.platform.app_client import AppClient
    from aicippy.platform.client import PlatformClient


class TenantStatus(StrEnum):
    """Tenant account lifecycle status.

    ACTIVE:   The tenant is fully operational. All login methods work.
    INACTIVE: The tenant has been deleted (soft-delete). This is
              irreversible -- no feature, UI, or API can reactivate an
              inactive tenant. The email may be re-used for a new signup
              which creates a brand-new tenant.
    """

    ACTIVE = "active"
    INACTIVE = "inactive"


@dataclass(frozen=True, slots=True)
class TenantInfo:
    """Tenant information returned by the platform API.

    The ``email`` field is the primary unique identifier across ALL login
    methods (email+password, OTP, Google, GitHub). Regardless of which
    provider is used, the same email always resolves to the same active
    tenant.

    Attributes:
        tenant_id: Unique tenant identifier (e.g. 'vk_abc123').
        org_tenant_id: Parent organization tenant ID (for multi-tenant orgs).
        email: Primary email address -- unique key across all login methods.
        name: Display name.
        created_at: When the tenant was created on the platform.
        status: Lifecycle status (``active`` or ``inactive``). Once set to
                ``inactive`` this is permanent.
        login_providers: Login methods linked to this tenant
                         (e.g. ``["email", "google", "github"]``).
    """

    tenant_id: str
    org_tenant_id: str
    email: str
    name: str
    created_at: datetime
    status: str = TenantStatus.ACTIVE.value
    login_providers: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class TenantRole:
    """Tenant role assignment from the platform API.

    Attributes:
        tenant_id: Tenant identifier.
        role: Role name (e.g. 'admin', 'user', 'readonly').
        apps: App domains this role applies to (e.g. ['*'] for all apps).
            Note: This is a mutable list in a frozen dataclass -- callers
            must not mutate the list after construction.
        granted_at: When the role was assigned.
        granted_by: Email of the admin who assigned the role.
    """

    tenant_id: str
    role: str
    apps: list[str]
    granted_at: datetime
    granted_by: str


@dataclass(slots=True)
class PlatformSession:
    """Holds all platform context for a single CLI session.

    Created after successful Cognito auth + platform tenant lookup.
    Passed through to billing, memory, and interactive modules.

    Attributes:
        tenant: Tenant info from platform API.
        plan: Plan validation result.
        auth_token: Bearer token for platform API calls.
        platform_client: HTTP client for api.aivibe.cloud.
        app_client: HTTP client for api.aicippy.com.
    """

    tenant: TenantInfo
    plan: PlanInfo
    auth_token: str
    platform_client: PlatformClient
    app_client: AppClient
