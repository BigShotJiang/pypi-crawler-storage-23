# Changelog

All notable changes to **temp-logger** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.2] — 2026-02-28

## [0.5.1] — 2026-02-23

## [0.5.0] — 2026-02-23

### Changed in v0.5.0

- **Modular extraction:** The following modules have been extracted into
  dedicated shared packages and are no longer shipped directly with temp-logger:
  - `device_scanner`, `wifi_config_gui`, `ota_client`, `ota_manager_gui` → **neng-wifi-tools**
  - `scpi_client`, `connection_panel`, `myserial/` → **neng-scpi-tools**
- Entry points `scpi-client`, `wifi-config-gui`, `update-firmware`,
  `neng-device-scan`, and `ota-manager-gui` now come from the companion
  packages above (installed automatically as dependencies).
- temp-logger now provides only: `temp-logger`, `temp-logger-gui`, and
  `pid-controller-gui`.
- Re-export shim files for `device_scanner`, `ota_client`, `ota_manager_gui`,
  and `wifi_config_gui` have been removed — import directly from
  `neng_wifi_tools` instead.
- `test_git_deploy.py` moved to `neng-wifi-tools/tests/`.

## [0.4.5] — 2026-02-22

## [0.4.4] — 2026-02-20

### Added

- **Multi-network auto-detection** across ALL tools:
  - `tmp117-scan` now scans all network interfaces (WiFi, Ethernet, VLANs, bridges) by default
  - `scpi-client -w` (without IP) auto-detects devices across all networks
  - `update-firmware --git-deploy` auto-detects device on all networks (no IP needed)
  - All GUI tools (`wifi-config-gui`, `pid-controller-gui`, `temp-logger-gui`) now auto-discover via network scanning when USB is unavailable
  - `--scan-network` flag for `update-firmware` to scan specific network
- **File deletion support** in git-aware OTA deployment:
  - Automatically removes files deleted from git repository during `--git-deploy`
  - SCPI command `:SYST:UPD:DELETE` for remote file deletion
  - Safe deletion with backup and error handling

### Changed in v0.4.4

- **10-12x performance improvement** for OTA uploads:
  - Upload speed increased from 5-7 KB/s to 50-100 KB/s
  - Optimized TCP receive buffer (4 KB) on ESP32 device side
  - Increased chunk size to 8 KB for WiFi transfers
  - Batch mode output improved (1 line per file, no verbose chatter)
- Network scanning now uses `ifconfig` parsing to discover all network interfaces
- `get_all_local_networks()` replaces single-network `get_local_network()` in device scanner

### Fixed

- Auto-detection now finds devices on non-default network interfaces (e.g., device on 10.104.32.0/24 while default route is 130.104.134.0/24)
- File deletion bug in git-aware deployment (incorrect path handling)
- Network scanning timeout handling for unavailable interfaces

## [0.4.3] — 2026-02-16

## [0.4.2] — 2026-02-16

## [0.4.1] — 2026-02-16

## [0.4.0] — 2026-02-16

### Added in v0.4.0

- `update-firmware` — OTA (Over-The-Air) update client for NEnG CircuitPython instruments
  - Single-file upload with SHA-256 or CRC-32 checksum verification
  - Batch upload of multiple files in one session
  - Git-aware deployment (`--git-deploy`): uploads only files changed since the
    last deployed commit, with automatic path mapping to the device filesystem
  - Dry-run mode (`--dry-run`) to preview what would be uploaded
  - `--force-full` flag to push every tracked file regardless of git diff
  - Verbose progress reporting (`-v`) with per-chunk transfer details
  - Optimized 8 KiB chunk size for faster WiFi transfers on ESP32
  - Automatic device reboot after update (`--reboot`)
  - Secure authenticated sessions with password support
  - Automatic rollback on transfer failure
- OTA update status display in `scpi-client` (`:SYST:UPD:STATUS?`) with
  colour-coded state, progress, and authentication indicators
- CI/CD pipeline configuration (`.gitlab-ci.yml`) with lint, test, and
  publish stages
- Release checklist documentation (`RELEASE_CHECKLIST.md`)

### Fixed in v0.4.0

- Verification script (`verify-code.sh`) updated to use `python3 -m` for
  `ruff` and `pytest` to work reliably in CI environments

## [0.3.0] — 2026-02-14

### Added in v0.2.11

- `tmp117-scan` — Fast network scanner for discovering TMP117 devices on port 5025
  - Concurrent TCP port scanning (~3-5 seconds for /24 network)
  - Auto-detection of local network or manual CIDR specification
  - SCPI *IDN? verification to confirm TMP117 devices
  - Multiple output formats: table, JSON, simple (IP list)
  - Verbose mode for detailed scanning progress
  - Save results to file
  - Configurable worker threads and port number

## [0.2.10] — 2026-02-13

## [0.2.9] — 2026-02-13

## [0.2.8] — 2026-02-13

### Added in v0.2.8

- `wifi-config-gui` — WiFi configuration GUI for network management via SCPI
  - WiFi enable/disable control with status monitoring
  - Network scanning with SSID, RSSI, channel, and security display
  - Add/remove fallback networks with password prompts
  - Primary network configuration with save/load functionality
  - Connection status display (IP, MAC, RSSI, channel)
  - CIRCUITPY mount status warning for persistent configuration
  - SCPI console for manual command execution
  - Dark/light theme toggle with professional styling
  - Auto-connect support via USB or WiFi/TCP

## [0.2.7] — 2026-02-12

## [0.2.6] — 2026-02-12

## [0.2.5] — 2026-02-12

## [0.2.4] — 2026-02-12

## [0.2.3] — 2026-02-09

## [0.2.2] — 2026-02-08

## [0.2.1] — 2026-02-08

## [0.2.0] — 2026-02-08

## [0.1.12] — 2026-02-08

## [0.1.11] — 2026-02-08

### Added in v0.1.11

- `pid-controller-gui` — PID temperature controller GUI with ramp control, tuning,
  TEC power monitoring, and live graphs.
- `scpi-client` — Interactive SCPI terminal with tab-completion, command history,
  pretty-printed output, and OPC synchronization.
- WiFi/TCP support across all four tools (auto-discovery, `wifi_config.txt`).
- `--version` flag on all entry points.
- Dark theme for `temp-logger-gui`.
- Dual-sensor synchronised logging with timing-skew subplot.

### Fixed in v0.1.11

- Cross-talk between GUI logger and SCPI console (threading lock).
- Graph reset timing after reconnect.
- TCP server `max_clients=1` on firmware side.
- macOS soft-reboot prevention in `boot.py`.
- WiFi discover retry and serial drain logic.

## [0.1.0] — 2025-12-01

### Added in v0.1.0

- Initial release with `temp-logger` CLI and `temp-logger-gui`.
- CSV logging with automatic timestamped filenames.
- Live matplotlib plots (4 subplots for dual sensor).
- Auto-detection of single vs. dual sensor mode.
- USB serial connection via `SCPISerial`.

[Unreleased]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.5.2...HEAD
[0.5.2]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.5.1...v0.5.2[0.5.1]: https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.5.0...v0.5.1[0.5.0]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.4.5...v0.5.0[0.4.5>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.4.4...v0.4.5[0.4.4>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.4.3...v0.4.4[0.4.3>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.4.2...v0.4.3[0.4.2>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.4.1...v0.4.2[0.4.1>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.4.0...v0.4.1[0.4.0>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.3.0...v0.4.0[0.3.0>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.10...v0.3.0[0.2.10>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.9...v0.2.10[0.2.9>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.8...v0.2.9[0.2.8>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.7...v0.2.8[0.2.7>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.6...v0.2.7[0.2.6>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.5...v0.2.6[0.2.5>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.4...v0.2.5[0.2.4>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.3...v0.2.4[0.2.3>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.2...v0.2.3[0.2.2>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.1...v0.2.2[0.2.1>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.2.0...v0.2.1[0.2.0>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.12...v0.2.0[0.1.12>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.11...v0.1.12[0.1.11>]: <https://gitlab.flavio.be/flavio/temp-logger/-/compare/v0.1.10...v0.1.11>
[0.1.0]: <https://gitlab.flavio.be/flavio/temp-logger/-/releases/v0.1.0>
