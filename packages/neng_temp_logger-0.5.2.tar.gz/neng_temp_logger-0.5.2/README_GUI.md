# Temperature Logger & PID Controller — Complete Documentation

Welcome to the NEnG TMP117 instrument control suite!

## Quick Navigation

### First-time users

Start here → **[GUI_QUICKSTART.md](GUI_QUICKSTART.md)**

### Setup & installation

All tools at a glance → **[GUI_SETUP_GUIDE.md](GUI_SETUP_GUIDE.md)**

### Detailed references

| Tool | Documentation |
| --- | --- |
| `temp-logger-gui` | [GUI_README.md](GUI_README.md) |
| `temp-logger` (CLI) | [REALTIME_LOGGER_README.md](REALTIME_LOGGER_README.md) |
| `pid-controller-gui` | [GUI_SETUP_GUIDE.md](GUI_SETUP_GUIDE.md#pid-controller-gui--pid-controller-gui) |
| `scpi-client` | [GUI_SETUP_GUIDE.md](GUI_SETUP_GUIDE.md#scpi-client--interactive-scpi-terminal) |

### WiFi connectivity

- Quick WiFi setup → **[WIFI_QUICKSTART.md](WIFI_QUICKSTART.md)**
- Full WiFi guide → **[WIFI_SUPPORT.md](WIFI_SUPPORT.md)**

### macOS Tkinter installation

**[TKINTER_INSTALLATION.md](TKINTER_INSTALLATION.md)**

---

## 30-second quick start

```bash
# 1. Install
cd temp-logger
python3 -m venv .venv && source .venv/bin/activate
pip install -e .

# 2. Run any tool
temp-logger-gui          # logger GUI
pid-controller-gui       # PID controller GUI
scpi-client              # interactive SCPI terminal
temp-logger              # CLI logger with live plot
```

---

## Source files

| Module | Purpose |
| --- | --- |
| `src/temp_logger/gui_realtime_logger.py` | `temp-logger-gui` — Tkinter GUI logger |
| `src/temp_logger/pid_controller_gui.py` | `pid-controller-gui` — PID controller GUI |
| `src/temp_logger/pc_realtime_logger.py` | `temp-logger` — CLI logger engine |
| `src/temp_logger/logger.py` | Shared logging / CSV backend |

The following modules have been extracted into shared packages:

| Module | Package | Purpose |
| --- | --- | --- |
| `neng_scpi_tools.scpi_client` | neng-scpi-tools | `scpi-client` — interactive SCPI terminal |
| `neng_scpi_tools.myserial.scpi_universal` | neng-scpi-tools | USB + WiFi SCPI interface |
| `neng_scpi_tools.myserial.scpi_serial` | neng-scpi-tools | USB serial SCPI interface |
| `neng_wifi_tools.device_scanner` | neng-wifi-tools | Network device scanner |
| `neng_wifi_tools.ota_client` | neng-wifi-tools | OTA firmware update client |
| `neng_wifi_tools.wifi_config_gui` | neng-wifi-tools | WiFi configuration GUI |
| `neng_wifi_tools.ota_manager_gui` | neng-wifi-tools | OTA Manager GUI |

---

## Common tasks

### Log temperature data

```bash
temp-logger-gui              # GUI with live plots
temp-logger --output exp.csv # CLI with CSV export
```

### Control PID temperature

```bash
pid-controller-gui           # full GUI
scpi-client ":PID:RAMP 35,2" # single SCPI command
```

### Calibrate sensors

```bash
scpi-client
# then interactively:
#   :CONF1:OFFS -0.05
#   :CONF2:OFFS +0.02
#   :SYST:CAL:SAVE
```

### Simultaneous logging + control

```bash
# Terminal 1 — USB logging
temp-logger --output data.csv

# Terminal 2 — WiFi control
pid-controller-gui
```

---

## System requirements

- Python 3.9+
- Dependencies: `pyserial`, `numpy`, `matplotlib`, `pandas`, `psutil`
- `tkinter` (for GUIs — see [TKINTER_INSTALLATION.md](TKINTER_INSTALLATION.md) on macOS)

(c) 2024-26 Prof. Flavio ABREU ARAUJO. All rights reserved.
