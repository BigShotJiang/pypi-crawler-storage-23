# Code Verification Guide

This project includes a comprehensive code verification script (`verify-code.sh`) that ensures code quality through linting and testing.

## Quick Start

```bash
# Run full verification (lint + tests)
./verify-code.sh

# Auto-fix common linting issues
./verify-code.sh --fix

# Run only linting (skip tests)
./verify-code.sh --no-tests
```

## What Gets Verified

### 1. **Ruff Linting** (Python code style & quality)

- **E**: PEP 8 errors
- **F**: Pyflakes (undefined names, unused imports)
- **W**: PEP 8 warnings
- **I**: isort (import sorting)
- **UP**: PyUpgrade (modern Python syntax)
- **B**: Bugbear (likely bugs)
- **SIM**: Simplify (code simplification)

   Line length: **100 characters**

### 2. **Pytest** (Unit tests)

- Location: `tests/`
- Coverage: 35 tests across:
  - Import checks
  - TCP socket functionality
  - SCPI protocol handling
  - Logger configuration
  - Temperature data collection

## Script Features

- **Color-coded output** for easy reading
- **Auto-fix capability** (`--fix` flag) for common issues
- **Optional test skipping** (`--no-tests` flag) for faster checks
- **Tool version reporting** at the end
- **Appropriate exit codes** for CI/CD integration

## Common Issues & Fixes

| Issue | Fix |
| ----- | --- |
| W293: Blank line contains whitespace | `./verify-code.sh --fix` |
| F401: Unused imports | `./verify-code.sh --fix` |
| I001: Unsorted imports | `./verify-code.sh --fix` |
| F841: Unused variables | Manual removal required |
| Test failures | Check test output and fix code |

## Integration with CI/CD

The script is designed for GitLab CI/CD:

```yaml
# .gitlab-ci.yml
verify:
  stage: test
  script:
    - cd TMP117/Python/temp-logger
    - ./verify-code.sh
```

The script will:

- Exit with code `0` if all checks pass
- Exit with code `1` if any check fails
- Report all issues with helpful messages

## Manual Linting

If you prefer to run tools individually:

```bash
# Check code style
ruff check src/ tests/

# Auto-fix issues
ruff check src/ tests/ --fix

# Format imports and code
ruff format src/ tests/

# Run tests
python3 -m pytest tests/ -v
```

## Configuration

Ruff configuration is in `pyproject.toml`:

```toml
[tool.ruff]
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "W", "I", "UP", "B", "SIM"]
ignore = ["E501"]  # Line too long (handled by formatter)
```

## Tips

1. **Run before committing**: `./verify-code.sh --fix && git add . && git commit`
2. **Fix in bulk**: Use `--fix` flag to resolve most issues automatically
3. **Check diffs**: Always review auto-fixes with `git diff` before committing
4. **Keep it fast**: Use `--no-tests` for quick syntax checks during development

---

Created: 2026-02-08
Script version: 1.0
Last updated: 2026-02-08
