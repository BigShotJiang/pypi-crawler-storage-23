"""GUI entrypoint.

Launches the Tkinter real-time temperature logger GUI.

(c) 2025-26 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys

from . import __version__
from .gui_realtime_logger import main as _gui_main

__all__ = ["main"]


def main() -> None:
    """Entry point for ``temp-logger-gui`` command."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"temp-logger-gui {__version__}")
        return
    _gui_main()


if __name__ == "__main__":
    main()
