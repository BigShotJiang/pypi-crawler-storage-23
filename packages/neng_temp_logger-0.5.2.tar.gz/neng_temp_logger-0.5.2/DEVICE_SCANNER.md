# NEnG Device Scanner

> **Moved:** The device scanner is now maintained in the
> **[neng-wifi-tools](../../neng-wifi-tools/README.md)** package.
> The CLI entry point is `neng-device-scan` (replaces the old `neng-device-scan`).
> The underlying module is `neng_wifi_tools.device_scanner`.

Fast network scanner for discovering NEnG instruments on SCPI port 5025.

## Overview

The `neng-device-scan` tool scans **all your network interfaces** (WiFi, Ethernet, VLANs, bridges) to find NEnG devices. It uses concurrent TCP port scanning for speed (~3-5 seconds for a /24 network) and verifies devices by querying the SCPI `*IDN?` command. Any device that returns a non-empty `*IDN?` response is reported.

Multi-network auto-detection scans all active network interfaces simultaneously, finding devices even when they're on a different subnet than your primary network connection.

## Installation

The scanner is installed as part of the `neng-wifi-tools` package:

```bash
pip install neng-wifi-tools
```

Or for development (from monorepo root):

```bash
pip install -e neng-scpi-tools/    # dependency
pip install -e neng-wifi-tools/
```

## Quick Start

### Scan All Network Interfaces (Recommended)

```bash
neng-device-scan
```

This will:

1. Auto-detect **all network interfaces** (WiFi, Ethernet, VLANs, bridges)
2. Scan all networks concurrently for devices on port 5025
3. Verify each device with `*IDN?` query
4. Display results in a formatted table

Example output when multiple networks are detected:

```txt
Scanning 3 network(s) for NEnG devices...
  • 192.168.1.0/24
  • 10.104.32.0/24
  • 130.104.134.0/24

======================================================================
Found 1 NEnG device(s):
======================================================================
  • 10.104.32.54    - NEnG,TMP117-PID,SN001,v1.0
======================================================================
Scan completed in 5.12s
```

### Scan Specific Network

```bash
neng-device-scan -n 192.168.1.0/24
```

### Verbose Mode

See detailed scanning progress:

```bash
neng-device-scan -v
```

Output:

```txt
Auto-detected network: 192.168.1.0/24
Scanning 192.168.1.0/24 (254 hosts) for port 5025...
  Port 5025 open: 192.168.1.100
  ✓ NEnG device found: 192.168.1.100 → NEnG,TMP117-PID,SN001,v1.0
Verifying 1 device(s)...

======================================================================
Found 1 NEnG device(s):
======================================================================
  • 192.168.1.100   - NEnG,TMP117-PID,SN001,v1.0
======================================================================
Scan completed in 4.23s
```

## Output Formats

### Table (Default)

Human-friendly formatted table:

```bash
neng-device-scan
```

### JSON

Machine-readable JSON output:

```bash
neng-device-scan --json
```

Output:

```json
{
  "devices": [
    {
      "ip": "192.168.1.100",
      "id": "NEnG,TMP117-PID,SN001,v1.0"
    }
  ],
  "count": 1
}
```

### Simple

IP addresses only (one per line):

```bash
neng-device-scan --simple
```

Output:

```txt
192.168.1.100
```

## Saving Results

Save scan results to a file:

```bash
neng-device-scan -o devices.txt
neng-device-scan --json -o devices.json
```

## Advanced Usage

### Scan Large Networks

For larger networks, increase the number of concurrent workers:

```bash
neng-device-scan -n 10.0.0.0/16 -w 200
```

Default is 100 workers, which is optimal for most /24 networks.

### Custom Port

If your devices use a non-standard port:

```bash
neng-device-scan -p 5555
```

### Multiple Networks

**Automatic**: The scanner now automatically detects and scans all network interfaces concurrently without any configuration.

If you want to scan **specific** multiple networks only:

```bash
neng-device-scan -n 192.168.1.0/24 -o net1.txt
neng-device-scan -n 192.168.2.0/24 -o net2.txt
cat net1.txt net2.txt
```

But in most cases, simply running `neng-device-scan` will find all devices across all your networks.

## Performance

Scan times for typical networks (on modern hardware):

| Network Size | Hosts | Time (approx) |
|--------------|-------|---------------|
| /24          | 254   | 3-5 seconds   |
| /23          | 510   | 6-8 seconds   |
| /22          | 1022  | 12-15 seconds |
| /16          | 65534 | 10-15 minutes |

Performance tips:

- **Timeout tuning**: Default is 0.5s for port check, 1.5s for SCPI
- **Worker count**: 100-200 threads is optimal for local networks
- **Network targeting**: Scan only your subnet, not entire address spaces

## Troubleshooting

### No Devices Found

1. **Verify device is on network**:

   ```bash
   scpi-client ":WIFI:IP?"  # Check device IP via USB
   ```

2. **Verify device is reachable**:

   ```bash
   ping 192.168.1.100
   ```

3. **Test port manually**:

   ```bash
   nc -zv 192.168.1.100 5025
   ```

4. **Check firewall**: Ensure port 5025 is not blocked

### Device Not Found with Auto-Detection

The scanner auto-detects **all network interfaces**, so this should be rare. If a device is still not found:

1. **Verify device is connected to a network you have access to**
2. **Manually specify the network** if you know which one the device is on:

   ```bash
   neng-device-scan -n 192.168.1.0/24
   ```

3. **Use verbose mode** to see all networks being scanned:

   ```bash
   neng-device-scan -v
   ```

### Slow Scanning

Increase worker count for faster scanning:

```bash
neng-device-scan -w 200
```

Or reduce network size:

```bash
neng-device-scan -n 192.168.1.100/29  # Only scan 192.168.1.97-102
```

## Integration Examples

### Use with Other Tools

```bash
# Find devices and connect with scpi-client
IP=$(neng-device-scan --simple | head -1)
scpi-client -w $IP "*IDN?"

# Start logger on first found device
neng-device-scan --simple | head -1 | xargs -I {} temp-logger --wifi {}
```

### Scripting

```python
#!/usr/bin/env python3
import subprocess
import json

# Run scanner and get JSON output
result = subprocess.run(
    ["neng-device-scan", "--json"],
    capture_output=True,
    text=True
)

devices = json.loads(result.stdout)
print(f"Found {devices['count']} device(s)")

for device in devices['devices']:
    print(f"  {device['ip']}: {device['id']}")
```

## Command Reference

```txt
usage: neng-device-scan [-h] [-n NETWORK] [-p PORT] [-w WORKERS] [-o OUTPUT] [-v]
                        [--json | --simple]

optional arguments:
  -h, --help            Show help message
  -n, --network NETWORK Network in CIDR notation (e.g., 192.168.1.0/24)
  -p, --port PORT       SCPI port to scan (default: 5025)
  -w, --workers WORKERS Number of parallel threads (default: 100)
  -o, --output OUTPUT   Save results to file
  -v, --verbose         Show detailed progress
  --json                Output as JSON
  --simple              Output only IP addresses
  --version, -V         Show version number
```

## See Also

- [WiFi Quick Start](WIFI_QUICKSTART.md) - Configure WiFi on devices
- [WiFi Support](WIFI_SUPPORT.md) - Full WiFi documentation
- [neng-wifi-tools README](../../neng-wifi-tools/README.md) - Package that maintains this scanner
- [neng-scpi-tools README](../../neng-scpi-tools/README.md) - SCPI communication tools

---

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
