# WiFi Support for Temperature Logger

The TMP117 Temperature Logger now supports both USB Serial and WiFi/TCP connections, allowing you to log data while keeping the USB port available for command-line control.

## Features

- **Automatic Connection Detection**: Automatically tries WiFi, then falls back to USB
- **WiFi IP Auto-Discovery**: Queries the device via USB to get its WiFi IP address
- **Flexible Connection Options**: Force WiFi, force USB, or let it auto-detect
- **Same Interface**: Works transparently with existing code

## Command-Line Logger

### Auto-detect (WiFi → USB fallback)

```bash
temp-logger
```

### Force WiFi Connection

```bash
temp-logger --wifi 192.168.1.100
temp-logger --wifi 192.168.1.100:5025  # Custom port
```

### Force USB Connection

```bash
temp-logger --port /dev/cu.usbmodem2101
temp-logger --prefer-usb  # Try USB first, then WiFi
```

### Command-Line Options

- `--wifi IP[:PORT]` or `-w IP[:PORT]`: Connect via WiFi/TCP (default port: 5025)
- `--port PORT` or `-p PORT`: Connect via USB serial on specific port
- `--prefer-usb`: Try USB first instead of WiFi
- `--no-plot`: Disable live plotting (faster logging)
- `--interval SECONDS`: Plot update interval (default: 0.1s)
- `--output FILE`: CSV output filename

## GUI Logger

The GUI logger provides a dropdown menu for connection type selection:

### Connection Options

1. **Auto (WiFi → USB)** (default)
   - Tries WiFi first, falls back to USB
   - Automatically discovers WiFi IP via USB if needed
   - Best for most use cases

2. **Auto (USB → WiFi)**
   - Tries USB first, falls back to WiFi
   - Good when USB connection is more reliable

3. **Force WiFi**
   - Only connects via WiFi/TCP
   - Requires manual IP address entry
   - Best when USB is in use by another application

4. **Force USB**
   - Only connects via USB serial
   - Can specify port or auto-detect
   - Best when WiFi is not available

### Usage

1. **Auto Mode (Recommended)**:
   - Select "Auto (WiFi → USB)" from Connection dropdown
   - Click START - it will auto-discover and connect

2. **Force WiFi Mode**:
   - Select "Force WiFi" from Connection dropdown
   - Enter device IP address (e.g., `192.168.1.100`)
   - Click START

3. **Force USB Mode**:
   - Select "Force USB" from Connection dropdown
   - Select serial port (or use Auto-detect)
   - Click START

## WiFi Auto-Discovery

The logger can automatically discover the device's WiFi IP address by:

1. Temporarily connecting via USB
2. Querying `:WIFI:CONNECTED?` to check WiFi status
3. Querying `:WIFI:IP?` to get the IP address
4. Closing USB connection
5. Connecting via WiFi/TCP

This allows seamless WiFi usage without manual IP entry.

## Use Cases

### 1. Single USB Port Available

- Use auto-detect mode
- Logger will use WiFi, leaving USB free for SCPI commands

### 2. WiFi Not Available

- Use Force USB mode
- Logger will use USB serial connection

### 3. Known WiFi IP Address

- Use Force WiFi mode
- Enter IP address manually
- Fastest connection (skips auto-discovery)

### 4. Multiple Devices

- Use specific IP addresses via Force WiFi
- Log from multiple devices simultaneously

## Technical Details

### SCPI Commands Used

- `:WIFI:CONNECTED?` - Check if WiFi is enabled and connected
- `:WIFI:IP?` - Get device's WiFi IP address

### Default Port

- TCP Port: 5025 (standard SCPI port)

### Connection Priority

The `SCPIUniversal` class handles connection attempts:

1. **prefer_wifi=True** (default):
   - Try provided WiFi host
   - Try auto-discovered WiFi IP (via USB query)
   - Fall back to USB serial

2. **prefer_wifi=False**:
   - Try USB serial
   - Try provided WiFi host
   - Try auto-discovered WiFi IP (via USB query)

### Implementation

The logger uses the new `SCPIUniversal` class which wraps both:

- `SCPISerial` for USB connections
- `TCPSocket` for WiFi/TCP connections

Both provide the same interface, allowing transparent switching.

## Troubleshooting

### WiFi Connection Fails

1. Check WiFi is enabled: `scpi-client ":WIFI:ENAB?"`
2. Check WiFi is connected: `scpi-client ":WIFI:CONNECTED?"`
3. Check IP address: `scpi-client ":WIFI:IP?"`
4. Verify network connectivity: `ping <device-ip>`

### Auto-Discovery Fails

1. Ensure USB cable is connected during startup
2. Check USB serial port is accessible
3. Try manually entering IP address in Force WiFi mode

### USB Still In Use After WiFi Connection

The auto-discovery process:

1. Opens USB temporarily to query WiFi IP
2. Closes USB connection
3. Opens WiFi connection

If USB is still busy, restart the application.

## Examples

### Basic Usage (Auto-detect)

```bash
# Start logger - will try WiFi first, fall back to USB
temp-logger
```

### WiFi Only (Known IP)

```bash
# Force WiFi connection with known IP
temp-logger --wifi 192.168.132.123
```

### USB Only

```bash
# Force USB on specific port
temp-logger --port /dev/cu.usbmodem2101

# Or let it auto-detect USB port
temp-logger --prefer-usb
```

### Logging via WiFi While Sending Commands via USB

```bash
# Terminal 1: Start logger via WiFi
temp-logger --wifi 192.168.132.123

# Terminal 2: Send SCPI commands via USB
scpi-client ":PID:ENAB 1"
scpi-client ":PID:SETP 25"
```

## See Also

- `scpi_universal.py` - Universal SCPI interface implementation
- `scpi_serial.py` - USB serial SCPI interface
- Main README for general logger usage
