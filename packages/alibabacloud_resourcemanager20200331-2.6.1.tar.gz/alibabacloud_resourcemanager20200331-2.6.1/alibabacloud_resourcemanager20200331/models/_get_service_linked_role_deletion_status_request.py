# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class GetServiceLinkedRoleDeletionStatusRequest(DaraModel):
    def __init__(
        self,
        deletion_task_id: str = None,
    ):
        # The ID of the deletion task.
        self.deletion_task_id = deletion_task_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.deletion_task_id is not None:
            result['DeletionTaskId'] = self.deletion_task_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('DeletionTaskId') is not None:
            self.deletion_task_id = m.get('DeletionTaskId')

        return self

