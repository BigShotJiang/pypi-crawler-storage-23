"""Configuration data for Vox MCP Server."""
