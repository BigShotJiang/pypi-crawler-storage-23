
## Search_vulns -- Web Server Files
Contains files for the web frontend of search_vulns

### Compile Tailwind / DaisyUI CSS
```
npx tailwindcss -i tailwind_input.css -o static/css/daisyui.css
```
