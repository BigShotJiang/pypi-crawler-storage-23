import argparse
import contextlib
import functools
import logging
import os
import typing

import joblib
import joinem
from joinem._dataframe_cli import _add_parser_base, _run_dataframe_cli
import numpy as np
import opytional as opyt
import pandas as pd
import sklearn

from ._alifestd_has_contiguous_ids import alifestd_has_contiguous_ids
from ._alifestd_is_strictly_bifurcating_asexual import (
    alifestd_is_strictly_bifurcating_asexual,
)
from ._alifestd_mark_leaves import alifestd_mark_leaves
from ._alifestd_mark_node_depth_asexual import alifestd_mark_node_depth_asexual
from ._alifestd_unfurl_traversal_inorder_asexual import (
    alifestd_unfurl_traversal_inorder_asexual,
)
from ._configure_prod_logging import configure_prod_logging
from ._delegate_polars_implementation import delegate_polars_implementation
from ._format_cli_description import format_cli_description
from ._get_hstrat_version import get_hstrat_version
from ._jit import jit
from ._log_context_duration import log_context_duration
from ._warn_once import warn_once


@jit(nopython=True)
def _calc_boundaries(
    node_depths: np.ndarray, indices: typing.Iterable[int], default: int
) -> np.ndarray:
    """Iterate over the provided 'indices' and at each index 'i' find the
    most recent index that satisfies:

    node_depths[j] <= node_depths[i]
    """
    result = np.empty_like(node_depths)
    stack = []
    for i in indices:
        while stack and node_depths[stack[-1]] > node_depths[i]:
            stack.pop()
        result[i] = stack[-1] if stack else default
        stack.append(i)

    return result


def alifestd_mark_clade_logistic_growth_children_asexual(
    phylogeny_df: pd.DataFrame,
    mutate: bool = False,
    *,
    parallel_backend: typing.Optional[str] = None,
    progress_wrap: typing.Callable = lambda x: x,
    work_mask: typing.Optional[np.ndarray] = None,
) -> pd.DataFrame:
    """Add column `clade_logistic_growth_children`, containing the coefficient
    of a logistic regression fit to origin times of the leaf descendants of
    each node.

    Nodes with left/right child clades with equal growth rates will have value
    approximately 0.0. If left child clade has greater growth rate, value will
    be negative. If right child clade has greater growth rate, value will be positive.

    Pass "loky" to `parallel_backend` to use joblib with loky backend.

    Leaf nodes will have value NaN. If provided, any nodes not included in
    `work_mask` will also have value NaN.

    Tree must be strictly bifurcating and single-rooted.

    Dataframe reindexing (e.g., df.index) may be applied.

    Input `phylogeny_df` and `work_mask` are not mutated by this operation
    unless `mutate` set True. If mutate set True, operation does not occur in
    place; still use return value to get transformed phylogeny dataframe.

    References
    ----------
    Bonetti Franceschi V and Volz E. Phylogenetic signatures reveal
        multilevel selection and fitness costs in SARS-CoV-2 [version 2; peer
        review: 2 approved, 1 approved with reservations]. Wellcome Open Res
        2024, 9:85 (https://doi.org/10.12688/wellcomeopenres.20704.2)

    Volz, E. Fitness, growth and transmissibility of SARS-CoV-2 genetic
        variants. Nat Rev Genet 24, 724-734 (2023).
        https://doi.org/10.1038/s41576-023-00610-z
    """

    if not mutate:
        phylogeny_df = phylogeny_df.copy()
        work_mask = opyt.apply_if(work_mask, np.copy)

    if not alifestd_is_strictly_bifurcating_asexual(phylogeny_df):
        raise ValueError("phylogeny_df must be strictly bifurcating")

    if work_mask is not None:
        phylogeny_df[
            "alifestd_mark_clade_logistic_growth_children_asexual_mask"
        ] = work_mask

    if "origin_time" not in phylogeny_df.columns:
        raise ValueError("phylogeny_df must contain `origin_time` column")

    if "node_depth" not in phylogeny_df.columns:
        phylogeny_df = alifestd_mark_node_depth_asexual(
            phylogeny_df, mutate=True
        )

    if "is_leaf" not in phylogeny_df.columns:
        phylogeny_df = alifestd_mark_leaves(phylogeny_df, mutate=True)

    inorder_traversal = alifestd_unfurl_traversal_inorder_asexual(
        phylogeny_df, mutate=True
    )

    if alifestd_has_contiguous_ids(phylogeny_df):
        phylogeny_df.reset_index(drop=True, inplace=True)
    else:
        phylogeny_df.index = phylogeny_df["id"]

    if work_mask is not None:
        work_mask = phylogeny_df.loc[
            inorder_traversal,
            "alifestd_mark_clade_logistic_growth_children_asexual_mask",
        ].values

    leaves_mask = phylogeny_df.loc[inorder_traversal, "is_leaf"].values
    leaves = leaves_mask.astype(float, copy=True)  # contiguous for perf

    node_depths = phylogeny_df.loc[inorder_traversal, "node_depth"].values
    node_depths = node_depths.copy()  # contiguous for perf

    origin_times = phylogeny_df.loc[inorder_traversal, "origin_time"].values
    origin_times = origin_times.astype(float, copy=True)  # contiguous for perf

    n = len(node_depths)
    range_n = np.arange(n)
    lb_exclusive = _calc_boundaries(node_depths, range_n, default=-1)
    ub_exclusive = _calc_boundaries(node_depths, range_n[::-1], default=n)
    lb_inclusive = lb_exclusive + 1

    for arr in (leaves, node_depths, origin_times, ub_exclusive, lb_inclusive):
        arr.flags.writeable = False  # probably not needed?

    @(joblib.delayed if parallel_backend else lambda x: x)
    def fit_logistic_regression(target_idx: int) -> float:
        lb_inclusive_ = lb_inclusive[target_idx]
        ub_exclusive_ = ub_exclusive[target_idx]
        # leaf case should be masked out
        assert lb_inclusive_ < target_idx < ub_exclusive_ - 1

        descendant_slice = slice(lb_inclusive_, ub_exclusive_)
        sliced_target = target_idx - descendant_slice.start

        # predictor values; reshape to (N x 1) array for sklearn
        X = origin_times[descendant_slice].reshape(-1, 1)

        # sample weights; exclude target node and internal nodes
        assert leaves[target_idx] == 0.0
        w = leaves[descendant_slice]

        # classification target (response); 0 for left clade, 1 for right clade
        y = np.zeros(len(X), dtype=int)
        y[sliced_target:] = 1

        if np.ptp(X) < 1e-3:  # sklearn defaults handle singular case better
            model = sklearn.linear_model.LogisticRegression()
        else:
            model = sklearn.linear_model.LogisticRegression(
                fit_intercept=False,  # disable for perf (not used)
                # scikit docs: for small datasets, 'liblinear' is a good choice
                # whereas 'sag' and 'saga' are faster for large ones
                solver=["liblinear", "sag"][
                    ub_exclusive_ - lb_inclusive_ > 10000  # arbitrary thresh
                ],
            )

        model.fit(X=X, y=y, sample_weight=w)
        res = model.coef_[0][0]
        if np.isnan(res):
            warn_once("clade logistic growth regression produced NaN")
        return res

    sparse_mask = ~leaves_mask
    if work_mask is not None:
        sparse_mask &= work_mask

    results = np.full_like(node_depths, np.nan, dtype=float)
    if sparse_mask.any():
        sparse_operands = np.arange(len(node_depths))[sparse_mask]

        # use multiprocessing backend, although scikit suggests threading backend
        # see https://scikit-learn.org/stable/computing/parallelism.html#higher-level-parallelism-with-joblib
        context = (
            joblib.parallel_backend(parallel_backend, n_jobs=-1)
            if parallel_backend
            else contextlib.nullcontext()
        )
        with context:
            collect = (
                joblib.Parallel(batch_size=1000, n_jobs=-1)
                if parallel_backend
                else lambda x: np.fromiter(
                    x, dtype=float, count=len(sparse_operands)
                )
            )
            sparse_results = collect(
                map(fit_logistic_regression, progress_wrap(sparse_operands)),
            )

        results[sparse_mask] = sparse_results

    assert len(results) == len(node_depths)
    phylogeny_df["clade_logistic_growth_children"] = pd.Series(
        results, index=inorder_traversal, dtype=float
    )

    phylogeny_df.drop(
        columns=[
            "alifestd_mark_clade_logistic_growth_children_asexual_mask",
        ],
        errors="ignore",
        inplace=True,
    )

    return phylogeny_df


_raw_description = f"""{os.path.basename(__file__)} | (hstrat v{get_hstrat_version()}/joinem v{joinem.__version__})

Add column `clade_logistic_growth_children`, containing the coefficient of a logistic regression fit to origin times of the leaf descendants of each node.

Data is assumed to be in alife standard format.

Additional Notes
================
- Use `--eager-read` if modifying data file inplace.

- This CLI entrypoint is experimental and may be subject to change.
"""


def _create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        add_help=False,
        description=format_cli_description(_raw_description),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser = _add_parser_base(
        parser=parser,
        dfcli_module="hstrat._auxiliary_lib._alifestd_mark_clade_logistic_growth_children_asexual",
        dfcli_version=get_hstrat_version(),
    )
    parser.add_argument(
        "--parallel-backend",
        type=str,
        default=None,
        help="joblib parallel backend to use (default: None)",
    )
    return parser


if __name__ == "__main__":
    configure_prod_logging()

    parser = _create_parser()
    args, __ = parser.parse_known_args()
    with log_context_duration(
        "hstrat._auxiliary_lib._alifestd_mark_clade_logistic_growth_children_asexual",
        logging.info,
    ):
        _run_dataframe_cli(
            base_parser=parser,
            output_dataframe_op=delegate_polars_implementation()(
                functools.partial(
                    alifestd_mark_clade_logistic_growth_children_asexual,
                    parallel_backend=args.parallel_backend,
                ),
            ),
        )
