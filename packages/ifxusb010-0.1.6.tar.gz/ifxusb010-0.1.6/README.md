# ifxusb010

Python API for Infineon USB010 dongle. Allows Python users to control the USB010 dongle.

## Installation

```bash
pip install ifxusb010
```

---

## Quick Start

```python
import ifxusb010

# connect USB010 dongle
dev = ifxusb010.connect_device()
```

---


### `search_I2C(start_address, end_address, debug, enable_8bit_mode)`

scan I2C bus to find devices

| parameter | type | default | description |
|------|------|--------|------|
| `start_address` | int | `0x20` | start address (8-bit) |
| `end_address` | int | `0xFE` | end address (8-bit) |
| `debug` | bool | `False` | print more info for debug |
| `enable_8bit_mode` | bool | `True` | `True` return 8-bits address，`False` return 7-bits address |

**return type：** `list` , example [ 0x40 , 0x58 , 0x60 ]  

```python
mydongle = ifxusb010.dongle()
devices = mydongle.search_I2C(start_address=0x40,end_address=0x60)

```

---
Device read and write command 
```python
import ifxusb010
from ifxusb010 import mckinley,rainier 

#init usb010 dongle
mydongle = ifxusb010.dongle()

#init Infineon XDPE152xx chip and device address is 0x40
mydevice =mckinley.xdpe152xx(0x40,mydongle)

# read OTP checksum from XDPE152xx, you can check programming guide to get more information.
mydevice.device_write([0xFD,0x04,0x00,0x00,0x00,0x00])
mydevice.device_write([0xFE,0x2D])

my_result=mydevice.device_read([0xFD],5,result_reverse=True)
# my_result is dict,
# the dict format is {'transactionErrorCode': 0, 'readData': [num1,num2,num3,num4,...]}
# transactionErrorCode = 0 -> successful , 1-> error.

print(f"read result={my_result['readData'][0:4]}")
>> read result=[115, 233, 87, 249]
```

xdpe152xx.get_device_otp_checksum()

```python
import ifxusb010
from ifxusb010 import mckinley 


mydongle = ifxusb010.dongle()

mydevice =mckinley.xdpe152xx(0x40,mydongle)
mydevice.get_device_otp_checksum()
print(f"device_checksum={mydevice.device_otp_checksum}")
>> device_checksum=0x73e957f9
```