import ifxusb010 

class PMBusDevice:
    def __init__(self, device_address, dongle_instance):
        self.device_address = device_address
        self.dongle_instance = dongle_instance                

    def device_read(self, write_command_code_list, read_number_length,result_reverse=True):
        result = self.dongle_instance.multi_readr_write(device_address=self.device_address, write_command_code_list=write_command_code_list, read_number_length=read_number_length)
        if result_reverse and 'readData' in result and isinstance(result['readData'], list):
            result['readData'] = result['readData'][::-1]
        return result
    
    def device_write(self, write_command_code_list):
        self.dongle_instance.multi_readr_write(device_address=self.device_address, write_command_code_list=write_command_code_list, read_number_length=0)
    
    
    def device_read_word(self, command, result_reverse=True):
        """Read a 2-byte word from the device."""
        return self.device_read([command], 2, result_reverse=result_reverse)
    
    def device_write_word(self, command, data):
        """Write a 2-byte word to the device. data can be int or list of 2 bytes."""
        if isinstance(data, int):
            data_bytes = data.to_bytes(2, byteorder='big')
            write_list = [command] + list(data_bytes)
        else:
            write_list = [command] + data
        self.device_write(write_list)
    
    def device_read_block(self, command, length, result_reverse=True):
        """Read a block of data from the device."""
        return self.device_read([command], length, result_reverse=result_reverse)
    
    def device_write_block(self, command, data):
        """Write a block of data to the device. data is a list of bytes."""
        write_list = [command] + data
        self.device_write(write_list)  

