import usb.core
import usb.util
import usb.backend.libusb1
import time
import libusb_package


class dongle:
    def __init__(self, vendor_id=0x058B, product_id=0x0230):
        """初始化並連接 USB dongle"""        
        self.vendor_id = vendor_id
        self.product_id = product_id
        self.dev = self._connect_device()

    def _connect_device(self):
        """連接 USB 裝置"""
        backend = usb.backend.libusb1.get_backend(find_library=libusb_package.find_library)
        dev = usb.core.find(idVendor=self.vendor_id, idProduct=self.product_id, backend=backend)
        if dev is None:
            raise ValueError('Device not found')
        dev.set_configuration()
        return dev

    def scan_I2C(self, start_address=0x20, end_address=0xFE, debug=False, enable_8bit_mode=True):
        if self.dev is None:
            self.dev = self.connect_device()
        writeAddress = 0x40
        avaliable_addr_list=list()
        for writeAddress in range(start_address,end_address,2):
            if debug==True:
                if enable_8bit_mode==True:
                    print(f"scan 8bits device address: {hex(writeAddress)}")
                else:
                    print(f"scan 7bits device address: {hex(writeAddress>>1)}")
            readAddress  = writeAddress+1    
            writeData = [9, 0]    
            readCount = 1    
            writeCount = 3   
            writeData.append(1)   
            writeData.append(readAddress)    
            writeData.append(1)    
            writeData.append(0x99)    
            writeData.append(3)    
            readCount += 3    
            writeCount += 4    
            writeData.insert(0, writeCount)    
            writeData.insert(1, 0)    

            # 先清空殘留資料
            try:
                self.dev.read(0x81, 64, 50)
            except usb.core.USBTimeoutError:
                pass

            try:
                self.dev.write(0x02, writeData, 1000)
                returnedData = self.dev.read(0x81, readCount, 1000)
                transactionErrorCode = returnedData[0]
                returnedCommandData = returnedData[1]
                if transactionErrorCode == 0:
                    if enable_8bit_mode==True:
                        print(f"avaliable device found at 8bits address {hex(writeAddress)}")
                        avaliable_addr_list.append(writeAddress)
                    else:
                        print(f"avaliable device found at 7bits address {hex(writeAddress>>1)}")
                        avaliable_addr_list.append(writeAddress>>1)
            except usb.core.USBTimeoutError:
                print(f"device address: {hex(writeAddress)} - Timeout, skipping...")

            time.sleep(0.05)
        return avaliable_addr_list    

    def multi_readr_write(self, device_address=0x40, write_command_code_list=None, read_number_length=0, debug=False):
        """通用 I2C Multi Read Write Function"""
        writeData = [9, 0]           # command header
        writeCount = 3               # 基本 writeCount

        if read_number_length > 0:
            # write+read 模式：使用奇數地址
            readAddress = device_address | 0x01
            readCount = 1 + read_number_length  # transactionErrorCode + read data
        else:
            # 純 write 模式：使用偶數地址，不讀回資料
            readAddress = device_address & 0xFE
            readCount = 0

        writeData.append(1)                       # 1 個 sub-transaction
        writeData.append(readAddress)              # I2C 地址
        writeData.append(len(write_command_code_list))  # 寫入的 byte 數
        writeData.extend(write_command_code_list)  # 寫入的資料
        if read_number_length > 0:
            writeData.append(read_number_length)   # 告訴 dongle 要讀幾個 byte
        writeData.append(3)                        # stop condition
        extra = 1 if read_number_length > 0 else 0
        writeCount += len(write_command_code_list) + 3 + extra

        writeData.insert(0, writeCount)
        writeData.insert(1, 0)

        if debug:
            print(f"writeData: {[hex(x) for x in writeData]}")
            if readCount > 0:
                print(f"readCount: {readCount}")

        # 先清空所有殘留資料（純 write 模式不讀回，response 會積在 buffer）
        while True:
            try:
                self.dev.read(0x81, 64, 50)
            except usb.core.USBTimeoutError:
                break

        max_retries = 3
        for attempt in range(max_retries):
            try:
                self.dev.write(0x02, writeData, 1000)
                if debug:
                    print(f"write success (attempt {attempt+1})")

                if read_number_length > 0:
                    # write+read 模式：讀回資料
                    returnedData = self.dev.read(0x81, 64, 1000)
                    transactionErrorCode = returnedData[0]
                    readData = list(returnedData[1:]) if len(returnedData) > 1 else []

                    if debug:
                        print(f"returnedData: {[hex(x) for x in returnedData]}")
                        print(f"transactionErrorCode: {transactionErrorCode}")
                        if readData:
                            print(f"readData: {[hex(x) for x in readData]}")

                    if transactionErrorCode == 0:
                        pass
                        #print(f"I2C write+read to {hex(device_address)} success, readData: {[hex(x) for x in readData]}")
                    else:
                        print(f"I2C to {hex(device_address)} failed, error code: {transactionErrorCode}")

                    return {"transactionErrorCode": transactionErrorCode, "readData": readData}
                else:
                    # 純 write 模式：不讀回，直接成功
                    if debug:
                        print(f"pure write, no read back")
                        print(f"I2C write to {hex(device_address)} success")
                    return {"transactionErrorCode": 0, "readData": []}

            except usb.core.USBTimeoutError:
                if debug:
                    print(f"I2C to {hex(device_address)} - Timeout (attempt {attempt+1}/{max_retries})")
                # 清除端點狀態後重試
                try:
                    self.clear_halt(0x02)
                except usb.core.USBError:
                    pass
                try:
                    self.clear_halt(0x81)
                except usb.core.USBError:
                    pass
                try:
                    self.read(0x81, 64, 100)
                except usb.core.USBTimeoutError:
                    pass
                time.sleep(0.1)

        print(f"I2C to {hex(device_address)} - Timeout after {max_retries} retries")
        return {"transactionErrorCode": -1, "readData": []}
    







### 以下為獨立函式，保留給需要直接使用 USB 裝置物件的使用者


def connect_device(vendor_id=0x058B, product_id=0x0230):
    """連接 USB 裝置並回傳 device 物件"""
    backend = usb.backend.libusb1.get_backend(find_library=libusb_package.find_library)
    dev = usb.core.find(idVendor=vendor_id, idProduct=product_id, backend=backend)
    if dev is None:
        raise ValueError('Device not found')
    dev.set_configuration()

    return dev


def search_I2C(dev=None,start_address=0x20, end_address=0xFE,debug=False,enable_8bit_mode=True):
    if dev is None:
        dev = connect_device()
    writeAddress = 0x40
    avaliable_addr_list=list()
    for writeAddress in range(start_address,end_address,2):
        if debug==True:
            if enable_8bit_mode==True:
                print(f"scan 8bits device address: {hex(writeAddress)}")
            else:
                print(f"scan 7bits device address: {hex(writeAddress>>1)}")
        readAddress  = writeAddress+1    
        writeData = [9, 0]    
        readCount = 1    
        writeCount = 3   
        writeData.append(1)   
        writeData.append(readAddress)    
        writeData.append(1)    
        writeData.append(0x99)    
        writeData.append(3)    
        readCount += 3    
        writeCount += 4    
        writeData.insert(0, writeCount)    
        writeData.insert(1, 0)    

        # 先清空殘留資料
        try:
            dev.read(0x81, 64, 50)
        except usb.core.USBTimeoutError:
            pass

        try:
            dev.write(0x02, writeData, 1000)
            returnedData = dev.read(0x81, readCount, 1000)
            transactionErrorCode = returnedData[0]
            returnedCommandData = returnedData[1]
            if transactionErrorCode == 0:
                if enable_8bit_mode==True:
                    print(f"avaliable device found at 8bits address {hex(writeAddress)}")
                    avaliable_addr_list.append(writeAddress)
                else:
                    print(f"avaliable device found at 7bits address {hex(writeAddress>>1)}")
                    avaliable_addr_list.append(writeAddress>>1)
        except usb.core.USBTimeoutError:
            print(f"device address: {hex(writeAddress)} - Timeout, skipping...")

        time.sleep(0.05)
    return avaliable_addr_list


def mrw(dev=None, device_address=0x40, data=None, debug=False):
    """對指定 I2C 裝置發送 write command（使用 multiReadWriteFunction 實作）
    
    Args:
        dev: USB 裝置物件，若為 None 會自動連接
        device_address: I2C 裝置寫地址 (8-bit)，預設 0x40
        data: 要寫入的資料列表，預設 [0xFD, 0x04, 0x00, 0x00, 0x00, 0x00]
        debug: 是否印出 debug 資訊
    
    Returns:
        transactionErrorCode: 0 表示成功
    """
    if data is None:
        data = [0xFD, 0x04, 0x00, 0x00, 0x00, 0x00]
    result = multiReadWriteFunction(dev=dev, device_address=device_address,
                                     write_command_code_list=data,
                                     read_number_length=0, debug=debug)
    return result["transactionErrorCode"]


def multiReadWriteFunction(dev=None, device_address=0x40, write_command_code_list=None, read_number_length=0, debug=False):
    """通用 I2C Multi Read Write Function
    
    根據 read_number_length 決定操作模式：
      - read_number_length == 0 → 純 write（使用偶數地址）
      - read_number_length > 0  → write + read（使用奇數地址）

    Args:
        dev: USB 裝置物件，若為 None 會自動連接
        device_address: I2C 裝置寫地址 (8-bit，偶數)，預設 0x40
        write_command_code_list: 要寫入的資料列表，例如 [0xFD, 0x04, 0x00, 0x00, 0x00, 0x00]
        read_number_length: 要讀取的 byte 數，0 表示純 write
        debug: 是否印出 debug 資訊
    
    Returns:
        dict: {
            "transactionErrorCode": int,  # 0 表示成功
            "readData": list              # 讀回的資料（純 write 時為空列表）
        }
    """
    if dev is None:
        dev = connect_device()
    if write_command_code_list is None:
        write_command_code_list = []

    writeData = [9, 0]           # command header
    writeCount = 3               # 基本 writeCount

    if read_number_length > 0:
        # write+read 模式：使用奇數地址
        readAddress = device_address | 0x01
        readCount = 1 + read_number_length  # transactionErrorCode + read data
    else:
        # 純 write 模式：使用偶數地址，不讀回資料
        readAddress = device_address & 0xFE
        readCount = 0

    writeData.append(1)                       # 1 個 sub-transaction
    writeData.append(readAddress)              # I2C 地址
    writeData.append(len(write_command_code_list))  # 寫入的 byte 數
    writeData.extend(write_command_code_list)  # 寫入的資料
    if read_number_length > 0:
        writeData.append(read_number_length)   # 告訴 dongle 要讀幾個 byte
    writeData.append(3)                        # stop condition
    extra = 1 if read_number_length > 0 else 0
    writeCount += len(write_command_code_list) + 3 + extra

    writeData.insert(0, writeCount)
    writeData.insert(1, 0)

    if debug:
        print(f"writeData: {[hex(x) for x in writeData]}")
        if readCount > 0:
            print(f"readCount: {readCount}")

    # 先清空所有殘留資料（純 write 模式不讀回，response 會積在 buffer）
    while True:
        try:
            dev.read(0x81, 64, 50)
        except usb.core.USBTimeoutError:
            break

    max_retries = 3
    for attempt in range(max_retries):
        try:
            dev.write(0x02, writeData, 1000)
            if debug:
                print(f"write success (attempt {attempt+1})")

            if read_number_length > 0:
                # write+read 模式：讀回資料
                returnedData = dev.read(0x81, 64, 1000)
                transactionErrorCode = returnedData[0]
                readData = list(returnedData[1:]) if len(returnedData) > 1 else []

                if debug:
                    print(f"returnedData: {[hex(x) for x in returnedData]}")
                    print(f"transactionErrorCode: {transactionErrorCode}")
                    if readData:
                        print(f"readData: {[hex(x) for x in readData]}")

                if transactionErrorCode == 0:
                    pass
                    #print(f"I2C write+read to {hex(device_address)} success, readData: {[hex(x) for x in readData]}")
                else:
                    print(f"I2C to {hex(device_address)} failed, error code: {transactionErrorCode}")

                return {"transactionErrorCode": transactionErrorCode, "readData": readData}
            else:
                # 純 write 模式：不讀回，直接成功
                if debug:
                    print(f"pure write, no read back")
                print(f"I2C write to {hex(device_address)} success")
                return {"transactionErrorCode": 0, "readData": []}

        except usb.core.USBTimeoutError:
            if debug:
                print(f"I2C to {hex(device_address)} - Timeout (attempt {attempt+1}/{max_retries})")
            # 清除端點狀態後重試
            try:
                dev.clear_halt(0x02)
            except usb.core.USBError:
                pass
            try:
                dev.clear_halt(0x81)
            except usb.core.USBError:
                pass
            try:
                dev.read(0x81, 64, 100)
            except usb.core.USBTimeoutError:
                pass
            time.sleep(0.1)

    print(f"I2C to {hex(device_address)} - Timeout after {max_retries} retries")
    return {"transactionErrorCode": -1, "readData": []}