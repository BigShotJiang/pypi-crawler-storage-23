"""Tests for MADSci CLI."""
