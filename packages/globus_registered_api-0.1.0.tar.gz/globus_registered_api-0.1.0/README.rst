..
    This file is a part of globus-registered-api.
    https://github.com/globus/globus-registered-api
    Copyright 2025-2026 Globus <support@globus.org>
    SPDX-License-Identifier: Apache-2.0

Globus Registered API
#####################

    ⚠️ **NOTE** ⚠️

    This software, and the feature it interacts with, is in a closed preview.

    It is not generally available for use yet.

This is the Globus Registered API CLI.
