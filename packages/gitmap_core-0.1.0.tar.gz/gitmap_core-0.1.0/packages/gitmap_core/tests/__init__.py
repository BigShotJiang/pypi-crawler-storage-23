"""GitMap core library tests."""
