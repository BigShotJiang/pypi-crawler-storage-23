"""GitMap Packages.

Contains first-party libraries for GitMap.

Metadata:
    Version: 0.1.0
"""
from __future__ import annotations


