"""GitMap MCP tools package.

Execution Context:
    Library module - imported by MCP server

Dependencies:
    - gitmap_core: Core GitMap functionality

Metadata:
    Version: 0.1.0
    Author: GitMap Team
"""
