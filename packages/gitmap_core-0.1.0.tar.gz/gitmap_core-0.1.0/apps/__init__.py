"""GitMap Applications Package.

Contains runnable applications for GitMap.

Metadata:
    Version: 0.1.0
"""
from __future__ import annotations


