"""Widgets for GitMap Client TUI.

Reusable UI components for the GitMap terminal user interface.
"""
from __future__ import annotations
