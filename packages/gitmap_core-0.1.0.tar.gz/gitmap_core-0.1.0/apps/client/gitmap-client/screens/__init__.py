"""Screens for GitMap Client TUI.

Full-screen views for different GitMap operations.
"""
from __future__ import annotations
