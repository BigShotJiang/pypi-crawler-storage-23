"""GitMap GUI - Web-based graphical interface for GitMap."""
