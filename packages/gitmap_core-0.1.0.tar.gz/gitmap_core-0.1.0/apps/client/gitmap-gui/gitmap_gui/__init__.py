"""GitMap GUI package."""
