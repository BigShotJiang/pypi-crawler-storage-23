"""GitMap CLI Scripts.

Contains business logic and utilities for the GitMap CLI.
This module holds the implementation details that main.py orchestrates.

Metadata:
    Version: 0.1.0
"""
from __future__ import annotations


