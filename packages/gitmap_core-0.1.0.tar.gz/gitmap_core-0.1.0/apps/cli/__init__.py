"""GitMap CLI Applications Package.

Contains command-line interface applications.

Metadata:
    Version: 0.1.0
"""
from __future__ import annotations


