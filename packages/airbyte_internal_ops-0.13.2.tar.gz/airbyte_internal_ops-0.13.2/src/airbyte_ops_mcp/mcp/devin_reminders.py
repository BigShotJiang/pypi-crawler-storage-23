# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""MCP tool for scheduling Devin agent reminders.

This module exposes the reminder scheduling operation as an MCP tool for AI agents.
It is a thin wrapper around the core dispatch function in the devin_reminders module.
"""

from __future__ import annotations

import logging
from typing import Annotated

from fastmcp import FastMCP
from fastmcp_extensions import mcp_tool, register_mcp_tools
from pydantic import BaseModel, Field

from airbyte_ops_mcp.devin_reminders import dispatch_reminder

logger = logging.getLogger(__name__)


class SetDevinReminderResponse(BaseModel):
    """Response from the set_devin_reminder tool."""

    success: bool = Field(description="Whether the workflow was triggered successfully")
    message: str = Field(description="Human-readable status message")
    workflow_url: str | None = Field(
        default=None,
        description="URL to view the GitHub Actions workflow file",
    )
    run_id: int | None = Field(
        default=None,
        description="GitHub Actions workflow run ID",
    )
    run_url: str | None = Field(
        default=None,
        description="Direct URL to the GitHub Actions workflow run",
    )


@mcp_tool(
    read_only=False,
    idempotent=False,
    open_world=True,
)
def set_devin_reminder(
    delay_minutes: Annotated[
        int,
        "Number of minutes until the reminder fires. Must be a positive "
        "multiple of 30, up to 4320 (3 days). Examples: 30, 60, 120, 1440.",
    ],
    reminder_message: Annotated[
        str,
        "The reminder message to deliver. Should clearly describe what "
        "you need to be reminded about.",
    ],
    agent_session_url: Annotated[
        str,
        "Your Devin session URL so the reminder can be injected back into "
        "your session. Use the session URL from your system prompt.",
    ],
    slack_users_cc: Annotated[
        str | None,
        "Optional comma-delimited list of Slack user tags to CC on the "
        "reminder notification. Example: '<@U12345>, <@U67890>'.",
    ] = None,
) -> SetDevinReminderResponse:
    """Schedule a reminder that fires after a specified delay.

    Creates a reminder that will be delivered back to your Devin session
    and posted to the #devin-reminders Slack channel when the time arrives.
    Reminders are checked every 30 minutes via a cron schedule.

    The reminder is stored as a GitHub Actions artifact and processed by
    the devin-reminders-action. When the reminder is due, it injects a
    message into the originating Devin session and sends a Slack notification.

    Use this tool when you need to schedule a follow-up action, check on
    a long-running process, or remind yourself about a task.
    """
    try:
        result = dispatch_reminder(
            delay_minutes=delay_minutes,
            reminder_message=reminder_message,
            agent_session_url=agent_session_url,
            slack_users_cc=slack_users_cc,
        )
    except ValueError as e:
        return SetDevinReminderResponse(
            success=False,
            message=f"Invalid input: {e}",
        )
    except Exception as e:
        logger.exception("Failed to dispatch reminder workflow")
        return SetDevinReminderResponse(
            success=False,
            message=f"Failed to trigger reminder workflow: {e}",
        )

    view_url = result.run_url or result.workflow_url
    return SetDevinReminderResponse(
        success=True,
        message=(
            f"Reminder scheduled to fire in {delay_minutes} minutes. "
            f"View progress at: {view_url}"
        ),
        workflow_url=result.workflow_url,
        run_id=result.run_id,
        run_url=result.run_url,
    )


def register_devin_reminder_tools(app: FastMCP) -> None:
    """Register Devin reminder tools with the FastMCP app."""
    register_mcp_tools(app, mcp_module=__name__)
