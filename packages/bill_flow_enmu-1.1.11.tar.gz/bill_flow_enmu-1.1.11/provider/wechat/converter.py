from provider.wechat.wecaht_types import WechatOrder, DealType
from ir.ir import IR, Order, Type


def get_meta_data(o: WechatOrder) -> dict:
    # 支付时间
    source = "WeChat"
    d = {}
    if source:
        d["source"] = source
    if o.pay_time:
        d["pay_time"] = o.pay_time
    if o.mechant_order_id:
        d["merchant_id"] = o.mechant_order_id
    if o.tx_type_original:
        d["tx_type"] = o.tx_type_original
    if o.method:
        d["method"] = o.method
    if o.status:
        d["status"] = o.status
    if o.order_id:
        d["order_id"] = o.order_id
    if o.commision:
        d["commision"] = o.commision
    return d


def convert_type(type: DealType):
    type_dict: dict[DealType, Type] = {
        DealType.SEND: Type.SEND,
        DealType.RECV: Type.RECV,
        DealType.NIL: Type.UNKNOW,
    }

    return type_dict.get(type, Type.UNKNOW)


def convert_to_ir(a_orders: list[WechatOrder]):
    ir = IR()
    for o in a_orders:
        iro = Order(
            peer=o.peer,
            item=o.item,
            method=o.method,
            pay_time=o.pay_time,
            money=o.money,
            order_id=o.order_id,
            type=convert_type(o.type),
            type_original=o.type_original,
            tx_type_original=o.tx_type_original,
        )

        iro.meta_data = get_meta_data(o)

        if o.mechant_order_id:
            iro.merchant_order_id = o.mechant_order_id
        ir.orders.append(iro)

    return ir
