from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from decimal import Decimal


class DealType(Enum):
    SEND = "支出"
    RECV = "收入"
    NIL = "UnKnown"


class TxType(Enum):
    tx_type_consume = "商户消费"


@dataclass
class WechatOrder:
    order_id: str
    mechant_order_id: str
    pay_time: datetime
    type: DealType
    type_original: str
    peer: str
    item: str
    money: Decimal
    tx_type: TxType
    tx_type_original: str
    status: str
    method: str
    commision: str
