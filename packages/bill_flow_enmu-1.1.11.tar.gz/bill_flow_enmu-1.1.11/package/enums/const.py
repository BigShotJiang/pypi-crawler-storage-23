from enum import Enum


class Const(Enum):
    PROVIDERALIPAY = "alipay"
    PROVIDERWECHAT = "wechat"
