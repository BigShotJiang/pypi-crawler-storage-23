"""
Package entry point for running as: python -m package
"""

from package.cmd.root import app

if __name__ == "__main__":
    app()
