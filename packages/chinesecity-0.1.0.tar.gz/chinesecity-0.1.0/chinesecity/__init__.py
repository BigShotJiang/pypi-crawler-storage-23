__version__ = "0.1.0"

from .devecho.py import dprint,ftprint,dinput,fdinput
