from lqs.client.core.core import LogQS
