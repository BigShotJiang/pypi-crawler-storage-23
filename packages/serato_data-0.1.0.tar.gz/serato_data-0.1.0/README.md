# serato_data
Python library to parse data from Serato DJ.

## Installation

To install, `pip install serato_data`.  To enable command line functionality,
run `pip install serato_data[cli]` and run with `python3 -m serato_data`.

## Usage

The `serato_data` package exposes a main entrypoint class `Serato`, which when
constructed will attempt to locate Serato's data directory, and raise an
exception if it can't find exactly one data directory.  Alternatively, the path
argument can be used to point directly to the desired data directory in the case
of a nonstandard location, or multiple installations.

Serato objects have a `history` property, which when iterated over produces a
list of all sessions.  Iterating over a session produces a list of songs in the
session.

For more detailed information, see the `docs/` folder.

## Development

For local development, run `pipenv install -d`, which will install development
dependencies as well.

### Testing

Run `pipenv run python -m unittest`

### Documentation Generation

Run `pipenv run pdoc --html --output-dir docs serato_data --force`

### Deployment

  1. Ensure tests pass
  2. Ensure latest documentation is generated
  3. Update the version in `src/serato_data/__init__.py`
  4. Build the packages: `pipenv run python -m build`
  5. Upload the packages: `pipenv run python -m twine upload dist/*`