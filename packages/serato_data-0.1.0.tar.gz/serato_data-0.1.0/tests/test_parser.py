from unittest import TestCase
from unittest.mock import MagicMock, patch, call

import arrow

from src.serato_data.parser import Parser
from src.serato_data.exc import ParserError, ParserReadError


class TestParser_ReadChunks(TestCase):
    def test_read(self):
        data = b'typ1\x00\x00\x00\x03footyp2\x00\x00\x00\x03bartyp3\x00\x00\x00\x03baztyp4\x00\x00\x00\x04quux'
        parser = Parser('test.filename')
        chunks = parser._read_chunks(data)
        self.assertEqual(next(chunks), (b'typ1', b'foo'))
        self.assertEqual(next(chunks), (b'typ2', b'bar'))
        self.assertEqual(next(chunks), (b'typ3', b'baz'))
        self.assertEqual(next(chunks), (b'typ4', b'quux'))

    def test_read__short_chunk_header(self):
        data = b'typ1\x00\x00\x00\x03footyp2\x00\x00\x00\x03bartyp3\x00\x00\x00\x03baztyp4\x00\x00'
        parser = Parser('test.filename')
        chunks = parser._read_chunks(data)
        self.assertEqual(next(chunks), (b'typ1', b'foo'))
        self.assertEqual(next(chunks), (b'typ2', b'bar'))
        self.assertEqual(next(chunks), (b'typ3', b'baz'))
        with self.assertRaisesRegex(ParserReadError, 'header'):
            _ = next(chunks)

    def test_read__short_chunk_data(self):
        data = b'typ1\x00\x00\x00\x03footyp2\x00\x00\x00\x03bartyp3\x00\x00\x00\x03baztyp4\x00\x00\x00\x04qu'
        parser = Parser('test.filename')
        chunks = parser._read_chunks(data)
        self.assertEqual(next(chunks), (b'typ1', b'foo'))
        self.assertEqual(next(chunks), (b'typ2', b'bar'))
        self.assertEqual(next(chunks), (b'typ3', b'baz'))
        with self.assertRaisesRegex(ParserReadError, 'data'):
            _ = next(chunks)


class TestParser_ReadChunksNestedOne(TestCase):
    def test_read_one(self):
        data = b'typ1\x00\x00\x00\x03foo'
        parser = Parser('test.filename')
        raw = parser._read_chunks_nested_one(b'typ1', data)
        self.assertEqual(raw, b'foo')

    def test_read_multi_fail(self):
        data = b'typ1\x00\x00\x00\x03footyp2\x00\x00\x00\x03bar'
        parser = Parser('test.filename')
        with self.assertRaisesRegex(ParserReadError, 'found more'):
            raw = parser._read_chunks_nested_one(b'typ1', data)

    def test_read_bad_type(self):
        data = b'typ1\x00\x00\x00\x03foo'
        parser = Parser('test.filename')
        with self.assertRaisesRegex(ParserReadError, 'found type'):
            raw = parser._read_chunks_nested_one(b'typ2', data)


@patch('src.serato_data.parser.open')
@patch('src.serato_data.parser.Parser._read_chunks')
class TestParser_ReadFile(TestCase):
    def test_read_file(self, mock_read_chunks, mock_open):
        res = Parser('test.filename')._read_file()
        self.assertEqual(res, mock_read_chunks.return_value)
        mock_open.assert_called_once_with('test.filename', 'rb')
        mock_open.return_value.__enter__.assert_called_once_with()
        mock_open.return_value.__enter__.return_value.read.assert_called_once_with()
        mock_open.return_value.__exit__.assert_called_once()
        mock_read_chunks.assert_called_once_with(mock_open.return_value.__enter__.return_value.read.return_value)


class TestParser_ParseFields(TestCase):
    def test_parse_fields(self):
        mock_parse_tf1 = MagicMock()
        mock_parse_tf1.side_effect = lambda v: v
        mock_parse_tf2 = MagicMock()
        mock_parse_tf2.side_effect = lambda v: v
        mock_recast_tf2 = MagicMock()
        mock_recast_tf2.side_effect = lambda v: v
        mock_parse_tf3 = MagicMock()
        mock_parse_tf3.side_effect = TypeError()
        mock_parse_tf4 = MagicMock()
        mock_parse_tf4.side_effect = lambda v: v
        mock_recast_tf4 = MagicMock()
        mock_recast_tf4.side_effect = ValueError()
        mock_fields = {
            # normal, valid
            b'a': ('tf1', mock_parse_tf1, None),
            # normal, valid, with recast
            b'b': ('tf2', mock_parse_tf2, mock_recast_tf2),
            # parser raises error
            b'c': ('tf3', mock_parse_tf3, None),
            # recast raises error
            b'd': ('tf4', mock_parse_tf4, mock_recast_tf4),
            # ignored
            b'e': False,
            # default
            b'g': ('tf6', None, None),
        }
        data = [
            (b'a', 'a_val'),
            (b'b', 'b_val'),
            (b'c', 'c_val'),
            (b'd', 'd_val'),
            (b'e', 'e_val'),
            (b'f', 'f_val'),
        ]
        with patch('src.serato_data.parser.Parser._read_chunks', return_value=data) as mock_read_chunks:
            with patch('src.serato_data.parser.Parser.FIELDS', mock_fields):
                parser = Parser('test.filename')
                res = parser._parse_fields(b'foo')
                self.assertEqual(res, {
                    'tf1': 'a_val',
                    'tf2': 'b_val',
                    'tf3': None,
                    'tf4': None,
                    'tf6': None,
                })


@patch('src.serato_data.parser.Parser._read_file')
@patch('src.serato_data.parser.Parser.parse_version', side_effect=lambda r: ('v', 'vs'))
@patch('src.serato_data.parser.Parser._read_chunks_nested_one', return_value={'foo': 'bar'})
@patch('src.serato_data.parser.Parser._parse_fields', side_effect=lambda v: v)
@patch('src.serato_data.parser.Parser.make_dataclass_args', side_effect=lambda *a,**ka: (a,ka))
@patch('src.serato_data.parser.Parser.loaded')
@patch('src.serato_data.parser.Parser.SKIP_CTYPES', [b'skip1', b'skip2'])
@patch('src.serato_data.parser.Parser.MAIN_CTYPE', b'main')
class TestParser_Load(TestCase):
    def test_load(self, mock_loaded, mock_mk_dc_args, mock_parse_fields, mock_rc_nested1, mock_parse_ver, mock_read_file):
        data = [
            (b'vrsn', 'rawversion'),
            (b'skip1', 'rawskip1'),
            (b'main', 'rawmain'),
            (b'inval', 'rawinvalid'),
            (b'skip2', 'rawskip2'),
        ]
        mock_read_file.return_value = data

        parser = Parser('test.filename')
        parser.load()
        parser.load()
        self.assertEqual(parser._version, 'v')
        self.assertEqual(parser._version_str, 'vs')
        self.assertEqual(parser.data, [{'foo': 'bar'}])
        mock_read_file.assert_called_once_with()
        mock_parse_ver.assert_called_once_with('rawversion')
        mock_rc_nested1.assert_called_once_with(b'adat', 'rawmain')
        mock_parse_fields.assert_called_once_with({'foo': 'bar'})
        mock_mk_dc_args.assert_called_once_with(foo='bar')
        mock_loaded.assert_called_once_with()

    @patch('src.serato_data.parser.Parser.HAS_VERSION', False)
    def test_load_without_version(self, mock_loaded, mock_mk_dc_args, mock_parse_fields, mock_rc_nested1, mock_parse_ver, mock_read_file):
        data = [
            (b'vrsn', 'rawversion'),
            (b'skip1', 'rawskip1'),
            (b'main', 'rawmain'),
            (b'inval', 'rawinvalid'),
            (b'skip2', 'rawskip2'),
        ]
        mock_read_file.return_value = data

        parser = Parser('test.filename')
        parser.load()
        parser.load()
        self.assertIsNone(parser._version)
        self.assertIsNone(parser._version_str)
        self.assertEqual(parser.data, [{'foo': 'bar'}])
        mock_read_file.assert_called_once_with()
        mock_parse_ver.assert_not_called()
        mock_rc_nested1.assert_called_once_with(b'adat', 'rawmain')
        mock_parse_fields.assert_called_once_with({'foo': 'bar'})
        mock_mk_dc_args.assert_called_once_with(foo='bar')
        mock_loaded.assert_called_once_with()


@patch('src.serato_data.parser.Parser.load')
class TestParser_Properties(TestCase):
    def test_properties(self, mock_load):
        parser = Parser('test.filename')
        parser.data = ['foo', 'bar']
        parser._version = 'v'
        parser._version_str = 'vs'

        self.assertEqual(parser.version, 'v')
        self.assertEqual(parser.version_str, 'vs')
        self.assertEqual(list(parser), ['foo', 'bar'])

        mock_load.assert_has_calls([call(), call(), call()])


class TestParser_ParsingFns(TestCase):
    def test_parse_version(self):
        res = Parser.parse_version(b'foo/bar')
        self.assertEqual(res, ['foo', 'bar'])

    def test_parse_str__utf8(self):
        expected = 'Ḽơᶉëᶆ ȋṕšᶙṁ ḍỡḽǭᵳ ʂǐť ӓṁệẗ, ĉṓɲṩḙċťᶒțûɾ ấɖḯƥĭṩčįɳġ ḝłįʈ, șếᶑ ᶁⱺ ẽḭŭŝḿꝋď ṫĕᶆᶈṓɍ ỉñḉīḑȋᵭṵńť ṷŧ ḹẩḇőꝛế éȶ đꝍꞎôꝛȇ ᵯáꞡᶇā ąⱡîɋṹẵ.'
        raw = b'\xe1\xb8\xbc\xc6\xa1\xe1\xb6\x89\xc3\xab\xe1\xb6\x86 \xc8\x8b\xe1\xb9\x95\xc5\xa1\xe1\xb6\x99\xe1\xb9\x81 \xe1\xb8\x8d\xe1\xbb\xa1\xe1\xb8\xbd\xc7\xad\xe1\xb5\xb3 \xca\x82\xc7\x90\xc5\xa5 \xd3\x93\xe1\xb9\x81\xe1\xbb\x87\xe1\xba\x97, \xc4\x89\xe1\xb9\x93\xc9\xb2\xe1\xb9\xa9\xe1\xb8\x99\xc4\x8b\xc5\xa5\xe1\xb6\x92\xc8\x9b\xc3\xbb\xc9\xbe \xe1\xba\xa5\xc9\x96\xe1\xb8\xaf\xc6\xa5\xc4\xad\xe1\xb9\xa9\xc4\x8d\xc4\xaf\xc9\xb3\xc4\xa1 \xe1\xb8\x9d\xc5\x82\xc4\xaf\xca\x88, \xc8\x99\xe1\xba\xbf\xe1\xb6\x91 \xe1\xb6\x81\xe2\xb1\xba \xe1\xba\xbd\xe1\xb8\xad\xc5\xad\xc5\x9d\xe1\xb8\xbf\xea\x9d\x8b\xc4\x8f \xe1\xb9\xab\xc4\x95\xe1\xb6\x86\xe1\xb6\x88\xe1\xb9\x93\xc9\x8d \xe1\xbb\x89\xc3\xb1\xe1\xb8\x89\xc4\xab\xe1\xb8\x91\xc8\x8b\xe1\xb5\xad\xe1\xb9\xb5\xc5\x84\xc5\xa5 \xe1\xb9\xb7\xc5\xa7 \xe1\xb8\xb9\xe1\xba\xa9\xe1\xb8\x87\xc5\x91\xea\x9d\x9b\xe1\xba\xbf \xc3\xa9\xc8\xb6 \xc4\x91\xea\x9d\x8d\xea\x9e\x8e\xc3\xb4\xea\x9d\x9b\xc8\x87 \xe1\xb5\xaf\xc3\xa1\xea\x9e\xa1\xe1\xb6\x87\xc4\x81 \xc4\x85\xe2\xb1\xa1\xc3\xae\xc9\x8b\xe1\xb9\xb9\xe1\xba\xb5.'
        res = Parser.parse_field_str(raw)
        self.assertEqual(res, expected)

    def test_parse_str__ascii(self):
        expected = 'foo bar'
        raw = b'foo bar'
        res = Parser.parse_field_str(raw)
        self.assertEqual(res, expected)

    def test_parse_str__latin1(self):
        expected = 'ó æ ø å'
        raw = b'\xc3\xb3 \xc3\xa6 \xc3\xb8 \xc3\xa5'
        res = Parser.parse_field_str(raw)
        self.assertEqual(res, expected)

    # def test_parse_str__invalid(self):
    #     raw = b'\x11\x09\x1d'
    #     with self.assertRaises(UnicodeDecodeError):
    #         Parser.parse_field_str(raw)

    def test_parse_int(self):
        res = Parser.parse_field_int(b'\x00\x00\x00\xff')
        self.assertEqual(res, 255)

    def test_parse_byte(self):
        res = Parser.parse_field_byte(b'\x10')
        self.assertEqual(res, 16)

    def test_parse_bool(self):
        res = Parser.parse_field_bool(b'\x10')
        self.assertTrue(res)
        res = Parser.parse_field_bool(b'\x00')
        self.assertFalse(res)

    def test_parse_arrow(self):
        # 1771800140
        # 2026-02-22T15:42:20+00:00
        raw = b'\x69\x9b\x86\x4c'
        expected = arrow.get('2026-02-22T15:42:20+00:00', tzinfo='America/Denver')
        res = Parser.parse_field_arrow(raw)
        self.assertEqual(res, expected)
