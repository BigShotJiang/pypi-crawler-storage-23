from unittest import TestCase
from unittest.mock import MagicMock, patch, call

from src.serato_data.serato import Serato
from src.serato_data.exc import SeratoNotFoundError, SeratoFoundError


@patch('src.serato_data.serato.Serato.get_candidate_dirs')
class TestSerato__Construct(TestCase):
    def test_exception_on_no_valid_path(self, mock_candidate_dirs):
        mock_candidate_dirs.return_value = []
        with self.assertRaises(SeratoNotFoundError):
            s = Serato()
        mock_candidate_dirs.assert_called_once_with(path=None)

    def test_exception_on_multiple_valid_paths(self, mock_candidate_dirs):
        mock_candidate_dirs.return_value = [{'serato': 'foo'}, {'serato': 'bar'}]
        with self.assertRaises(SeratoNotFoundError):
            s = Serato()
        mock_candidate_dirs.assert_called_once_with(path=None)

    def test_one_valid_path(self, mock_candidate_dirs):
        mock_candidate_dirs.return_value = [{'serato': 'foo'}]
        s = Serato()
        self.assertEqual(s.paths, {'serato': 'foo'})
        mock_candidate_dirs.assert_called_once_with(path=None)

    def test_one_valid_path_passed(self, mock_candidate_dirs):
        mock_candidate_dirs.return_value = [{'serato': 'foo'}]
        s = Serato(path='bar')
        self.assertEqual(s.paths, {'serato': 'foo'})
        mock_candidate_dirs.assert_called_once_with(path='bar')


@patch('src.serato_data.serato.os.path.expanduser', lambda p: p.replace('~', '/user'))
@patch('src.serato_data.serato.os.path.normpath', lambda p: '/norm' + p)
@patch('src.serato_data.serato.os.path.abspath', lambda p: '/abs' + p)
@patch('src.serato_data.serato.os.path.exists', return_value=True)
@patch('src.serato_data.serato.os.path.isdir', side_effect=lambda p: '.' not in p)
@patch('src.serato_data.serato.os.path.isfile', side_effect=lambda p: '.' in p)
class TestSerato__GetCandidateDirs(TestCase):
    def test_all_found(self, mock_isfile, mock_isdir, mock_exists):
        res = list(Serato.get_candidate_dirs())
        self.assertEqual(res, [
            {
                'serato': '/abs/norm/user/Music/_Serato_',
                'history': '/abs/norm/user/Music/_Serato_/History',
                'history_file': '/abs/norm/user/Music/_Serato_/History/history.database',
                'sessions': '/abs/norm/user/Music/_Serato_/History/Sessions',
            },
            {
                'serato': '/abs/norm/user/Music/ScratchLIVE',
                'history': '/abs/norm/user/Music/ScratchLIVE/History',
                'history_file': '/abs/norm/user/Music/ScratchLIVE/History/history.database',
                'sessions': '/abs/norm/user/Music/ScratchLIVE/History/Sessions',
            },
            {
                'serato': '/abs/norm/user/My Documents/My Music/_Serato_',
                'history': '/abs/norm/user/My Documents/My Music/_Serato_/History',
                'history_file': '/abs/norm/user/My Documents/My Music/_Serato_/History/history.database',
                'sessions': '/abs/norm/user/My Documents/My Music/_Serato_/History/Sessions',
            },
            {
                'serato': '/abs/norm/user/My Documents/My Music/ScratchLIVE',
                'history': '/abs/norm/user/My Documents/My Music/ScratchLIVE/History',
                'history_file': '/abs/norm/user/My Documents/My Music/ScratchLIVE/History/history.database',
                'sessions': '/abs/norm/user/My Documents/My Music/ScratchLIVE/History/Sessions',
            },
        ])

    def test_one_found(self, mock_isfile, mock_isdir, mock_exists):
        mock_exists.side_effect = lambda p: '/Music/_Serato_' in p
        res = list(Serato.get_candidate_dirs())
        self.assertEqual(res, [
            {
                'serato': '/abs/norm/user/Music/_Serato_',
                'history': '/abs/norm/user/Music/_Serato_/History',
                'history_file': '/abs/norm/user/Music/_Serato_/History/history.database',
                'sessions': '/abs/norm/user/Music/_Serato_/History/Sessions',
            },
        ])

    def test_history_dir_not_found(self, mock_isfile, mock_isdir, mock_exists):
        mock_exists.side_effect = lambda p: '/Music/_Serato_' in p and '/History' not in p
        res = list(Serato.get_candidate_dirs())
        self.assertEqual(res, [
            {
                'serato': '/abs/norm/user/Music/_Serato_',
                'history': None,
                'history_file': None,
                'sessions': None,
            },
        ])

    def test_history_file_not_found(self, mock_isfile, mock_isdir, mock_exists):
        mock_exists.side_effect = lambda p: '/Music/_Serato_' in p and 'history.database' not in p
        res = list(Serato.get_candidate_dirs())
        self.assertEqual(res, [
            {
                'serato': '/abs/norm/user/Music/_Serato_',
                'history': '/abs/norm/user/Music/_Serato_/History',
                'history_file': None,
                'sessions': '/abs/norm/user/Music/_Serato_/History/Sessions',
            },
        ])

    def test_sessions_dir_not_found(self, mock_isfile, mock_isdir, mock_exists):
        mock_exists.side_effect = lambda p: '/Music/_Serato_' in p and '/Sessions' not in p
        res = list(Serato.get_candidate_dirs())
        self.assertEqual(res, [
            {
                'serato': '/abs/norm/user/Music/_Serato_',
                'history': '/abs/norm/user/Music/_Serato_/History',
                'history_file': '/abs/norm/user/Music/_Serato_/History/history.database',
                'sessions': None,
            },
        ])

    def test_with_path(self, mock_isfile, mock_isdir, mock_exists):
        res = list(Serato.get_candidate_dirs(path='/foo'))
        self.assertEqual(res, [
            {
                'serato': '/abs/norm/foo',
                'history': '/abs/norm/foo/History',
                'history_file': '/abs/norm/foo/History/history.database',
                'sessions': '/abs/norm/foo/History/Sessions',
            },
        ])


@patch('src.serato_data.serato.HistoryFile')
@patch('src.serato_data.serato.Serato.get_candidate_dirs')
class TestSerato__History(TestCase):
    def test_history(self, mock_candidate_dirs, mock_history_cls):
        mock_candidate_dirs.return_value = [{'history_file': 'foo'}]
        s = Serato()
        res = s.history
        assert res is mock_history_cls.return_value
        mock_history_cls.assert_called_once_with('foo')