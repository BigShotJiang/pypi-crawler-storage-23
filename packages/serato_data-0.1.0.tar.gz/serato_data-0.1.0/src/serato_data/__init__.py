"""Parse data from Serato DJ."""

# Do not add type annotation here; hatch won't parse it then
__VERSION__ = '0.1.0'

from .exc import (
    SeratoError,
    SeratoNotFoundError,
    SeratoFoundError,
)
from .serato import Serato

__all__ = ['Serato', 'SeratoError', 'SeratoNotFoundError', 'SeratoFoundError']