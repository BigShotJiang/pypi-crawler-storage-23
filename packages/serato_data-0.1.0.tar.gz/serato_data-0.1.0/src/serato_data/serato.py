"""Main Serato interface."""

import typing as t
import os


from .history import HistoryFile
from .exc import (
    SeratoError,
    SeratoNotFoundError,
    SeratoFoundError,
)


class Serato:
    """\
    Represents a Serato installation
    """

    def __init__(self, path: t.Optional[str]=None):
        """\
        Create a new Serato instance.  By default, attempts to find a valid
        Serato/ScratchLIVE installation (see `get_candidate_dirs()`).
        Alternatively you can specify the path to the `_Serato_` folder
        explicitly, in which case only that path is checked for validity.

        In either case, raises `SeratoNotFoundError` if the path could not be
        found or is not valid, and `SeratoFoundError` if multiple paths were
        found.
        """

        paths = list(self.get_candidate_dirs(path=path))
        if len(paths) == 0:
            raise SeratoNotFoundError("No Serato installation could be found", path)
        if len(paths) > 1:
            raise SeratoFoundError("Multiple Serato installations were found", [p['serato'] for p in paths])

        self.paths = paths[0]

    @classmethod
    def get_candidate_dirs(cls, path: t.Optional[str]=None) -> t.Generator[t.Dict[str, t.Optional[str]]]:
        """\
        Produce a list of candidate directories for a Serato installation.  The
        directories produced are only those that exist.

        An optional path may be provided, in which case only that path is used,
        if it exists.

        The yielded objects are dicts containing the following keys:

         * 'serato' - Path to the Serato data itself
         * 'history' - Path to the history directory
         * 'history_file' - Path to the main history database
         * 'sessions' - Path to the session files

        Each key will be None if the corresponding path does not exist
        """

        candidates = []
        if path is not None:
            candidates = [path]
        else:
            for music_dir in [['Music'], ['My Documents', 'My Music']]:
                for software_dir in ['_Serato_', 'ScratchLIVE']:
                    full_dir = ['~'] + music_dir + [software_dir]
                    candidates.append(os.path.join(*full_dir))

        candidates = [os.path.abspath(os.path.normpath(os.path.expanduser(c))) for c in candidates]
        for c in candidates:
            if os.path.exists(c) and os.path.isdir(c):
                hist_dir = os.path.join(c, 'History')
                if not (os.path.exists(hist_dir) and os.path.isdir(hist_dir)):
                    hist_dir = None

                hist_file = sess_dir = None
                if hist_dir:
                    hist_file = os.path.join(hist_dir, 'history.database')
                    if not (os.path.exists(hist_file) and os.path.isfile(hist_file)):
                        hist_file = None

                    sess_dir = os.path.join(hist_dir, 'Sessions')
                    if not (os.path.exists(sess_dir) and os.path.isdir(sess_dir)):
                        sess_dir = None
                out = {
                    'serato': c,
                    'history': hist_dir,
                    'history_file': hist_file,
                    'sessions': sess_dir,
                }
                yield out

    @property
    def history(self) -> HistoryFile:
        """\
        Return a `HistoryFile` object representing the full Serato history,
        which exposes full session data (see that class for more details).
        """

        return HistoryFile(self.paths['history_file'])