"""Exceptions raised by various parsing methods."""


class SeratoError(Exception):
    """General errors regarding Serato data"""
    pass


class SeratoNotFoundError(SeratoError):
    """Serato installation was not found"""
    pass


class SeratoFoundError(SeratoNotFoundError):
    """More than one Serato installation was found"""
    pass


class ParserError(Exception):
    """Errors occuring during parsing of data files"""
    pass


class ParserReadError(ParserError):
    """Failed to read from a data file"""
    pass