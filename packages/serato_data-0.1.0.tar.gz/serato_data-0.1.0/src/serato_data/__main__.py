import sys
import argparse
import logging

from tabulate import tabulate
import arrow

from .serato import Serato


TIMEZONE = arrow.now().tzinfo
# logging.basicConfig(level=logging.DEBUG)


def _format_time(dt):
    if dt:
        return dt \
            .to(TIMEZONE) \
            .format('ddd MMM Do YYYY, h:mm A')


def _format_bool(v):
    return 'Yes' if v else 'No'


def _format_duration(v):
    if v:
        parts = []
        divisors = [86400, 3600, 60, 1]
        for d in divisors:
            if v >= d:
                p, v = divmod(v, d)
                parts.append(int(p))
        while len(parts) < 2:
            parts.insert(0, 0)
        return ':'.join(('{:02d}'.format(p) for p in parts))


def _format_deck(v):
    if v:
        return '{}{}{}{}'.format(
            3 if v == 3 else ' ',
            1 if v == 1 else ' ',
            2 if v == 2 else ' ',
            4 if v == 4 else ' ',
        )


def parse_args():
    parser = argparse.ArgumentParser(
        description="Command line tool to parse data from Serato DJ",
        epilog="If not used with --all/--session/--latest, list discovered sessions",
    )
    parser.add_argument('-p', '--path', help="Path to Serato DJ installation, if not automatically discovered")
    parser.add_argument('-a', '--all', action='store_true', help="Print details for all sessions")
    parser.add_argument('-s', '--session', type=int, help="Print details for this session ID")
    parser.add_argument('-l', '--latest', action='store_true', help="Print details for the latest session")
    parser.add_argument('-v', '--verbose', action='store_true', help="Print verbose details")
    return parser.parse_args()


def main(args=None):
    args = args or parse_args()

    serato = Serato(path=args.path)
    if args.all:
        for session in serato.history:
            print(session.fields, len(session))
            # TODO: print entries from iter(session)
    elif args.session or args.latest:
        if args.session:
            session = [s for s in serato.history if s.session_id == args.session]
            if not session:
                raise RuntimeError(f"No session with ID {args.session} found")
            session = session[0]
        else:
            if not len(list(serato.history)):
                raise RuntimeError("No sessions found")
            session = list(serato.history)[-1]

        # {'entry_id': 12922, 'full_path': '/Users/alecelton/Music/Purchased/liquid dnb/Keeno, Alice Gasson - Etchings On A Glass Heart (Original Mix).mp3', 'location': None, 'filename': None, 'title': 'Etchings on a Glass Heart (Original Mix)',
        # 'artist': 'Keeno, Alice Gasson', 'album': 'Fast Soul Music 2', 'genre': 'Drum & Bass', 'length': None, 'size': None, 'bitrate': None, 'frequency': None, 'bpm': 88, 'comments': 'H', 'lang': None, 'grouping': 'Hospital Records',
        # 'remixer': None, 'label': 'Hospital Records', 'composer': None, 'year': '2018-05-25', 'start': <Arrow [2025-10-16T02:44:09+00:00]>, 'end': <Arrow [2025-10-16T06:23:29+00:00]>, 'deck': 1, 'preview': None, 'playtime': 13160,
        # 'session_id': None, 'played': True, 'key': 'C', 'added': False, 'updated_at': <Arrow [2025-10-17T00:02:42+00:00]>, 'hardware': 'DJ-202', 'comment_name': None, 'rejected': False, 'beatport_id': None, 'beatport_url': None}

        if args.verbose or True:
            headers = [
                'Title',
                'Artist',
                'Album',
                'Genre',
                'Length',
                'BPM',
                'Comments',
                'Start',
                'End',
                'Deck',
                'Preview',
                'Playtime',
                'Played',
                'Key',
                'Rejected',
                'Beatport URL',
            ]

        rows = []
        for entry in session:
            if args.verbose or True:
                rows.append([
                    entry.title,
                    entry.artist,
                    entry.album,
                    entry.genre,
                    _format_duration(entry.length),
                    entry.bpm,
                    entry.comments,
                    _format_time(entry.start),
                    _format_time(entry.end),
                    _format_deck(entry.deck),
                    _format_bool(entry.preview),
                    _format_duration(entry.playtime),
                    _format_bool(entry.played),
                    entry.key,
                    _format_bool(entry.rejected),
                    entry.beatport_url,
                ])

        print(tabulate(rows, headers=headers))
    else:
        if args.verbose:
            headers = ['Session ID', 'Software', 'Hardware', 'Collapsed', 'Start Time', 'End Time', 'Tracks']
        else:
            headers = ['Session ID', 'Hardware', 'Start Time', 'Tracks']
        rows = []
        for session in serato.history:
            if args.verbose:
                rows.append([
                    session.session_id,
                    f'{session.software} build {session.software_build}',
                    session.hardware,
                    _format_bool(session.collapsed),
                    _format_time(session.start),
                    _format_time(session.end),
                    len(list(session))
                ])
            else:
                rows.append([
                    session.session_id,
                    session.hardware,
                    _format_time(session.start),
                    len(list(session))
                ])

        print(tabulate(rows, headers=headers))

    sys.exit(0)


if __name__ == '__main__':
    main()