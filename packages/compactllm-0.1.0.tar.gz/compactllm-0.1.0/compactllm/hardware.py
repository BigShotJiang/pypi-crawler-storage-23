"""
hardware.py — Detects your device's hardware and assigns a tier.

AtomLLM uses this to automatically filter the model list to only
show models that will actually run smoothly on your machine.

Tiers:
    🥔 potato  — Under 4GB RAM  (old laptops, budget PCs, Raspberry Pi)
    💻 basic   — 4–8GB RAM     (most standard laptops)
    🖥️  mid     — 8–16GB RAM    (good laptops, most desktops)
    🚀 high    — 16GB+ RAM     (powerful workstations, gaming PCs)
"""

import psutil
import platform


def detect_hardware() -> dict:
    """
    Detect your system hardware and return a full summary.

    Returns a dict with keys:
        ram_gb       — Total system RAM in GB
        cpu_cores    — Number of physical CPU cores
        cpu_name     — CPU model name string
        has_gpu      — True if a compatible GPU is detected
        gpu_vram_gb  — GPU VRAM in GB (None if no GPU or Apple Silicon)
        tier         — 'potato', 'basic', 'mid', or 'high'
        platform     — 'Windows', 'Darwin' (macOS), or 'Linux'

    Example:
        from atomllm import detect_hardware

        hw = detect_hardware()
        print(hw['tier'])   # 'mid'
        print(hw['ram_gb']) # 16.0
    """
    ram_gb = psutil.virtual_memory().total / (1024 ** 3)
    cpu_cores = psutil.cpu_count(logical=False) or 2
    cpu_name = _get_cpu_name()

    has_gpu = False
    gpu_vram_gb = None

    try:
        import torch
        if torch.cuda.is_available():
            has_gpu = True
            gpu_vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
        elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            # Apple Silicon — GPU shares system RAM
            has_gpu = True
            gpu_vram_gb = None
    except ImportError:
        pass

    tier = _determine_tier(ram_gb, gpu_vram_gb)

    return {
        "ram_gb": round(ram_gb, 1),
        "cpu_cores": cpu_cores,
        "cpu_name": cpu_name,
        "has_gpu": has_gpu,
        "gpu_vram_gb": round(gpu_vram_gb, 1) if gpu_vram_gb else None,
        "tier": tier,
        "platform": platform.system(),
    }


def _determine_tier(ram_gb: float, gpu_vram_gb: float | None) -> str:
    """Pick a tier based on available memory."""
    # Prefer GPU VRAM if meaningfully present, else use system RAM
    effective = gpu_vram_gb if (gpu_vram_gb and gpu_vram_gb > 2) else ram_gb

    if effective < 4:
        return "potato"
    elif effective < 8:
        return "basic"
    elif effective < 16:
        return "mid"
    else:
        return "high"


def _get_cpu_name() -> str:
    """Return a human-readable CPU name string."""
    try:
        sys = platform.system()
        if sys == "Windows":
            import subprocess
            result = subprocess.run(
                ["wmic", "cpu", "get", "name"],
                capture_output=True, text=True
            )
            lines = [l.strip() for l in result.stdout.split('\n')
                     if l.strip() and l.strip() != "Name"]
            return lines[0] if lines else "Unknown CPU"

        elif sys == "Darwin":
            import subprocess
            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True, text=True
            )
            return result.stdout.strip() or "Apple Silicon"

        else:  # Linux
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if "model name" in line:
                        return line.split(":", 1)[1].strip()

    except Exception:
        pass

    return "Unknown CPU"
