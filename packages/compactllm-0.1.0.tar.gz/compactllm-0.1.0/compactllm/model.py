"""
model.py — The Model class. The heart of AtomLLM.

This is what most users will interact with. It wraps HuggingFace model
loading and inference into the simplest possible API.

Usage:
    from atomllm import Model

    model = Model('smollm2')
    print(model.ask('What is a neural network?'))

    # Stream responses
    for chunk in model.stream('Tell me a story'):
        print(chunk, end='', flush=True)

    # Auto-pick best model for your hardware
    model = Model.auto()

    # Filter by task
    model = Model.auto(task='coding')
"""

from __future__ import annotations
from typing import Optional, Iterator


class Model:
    """
    A free, locally-running AI model.

    AtomLLM automatically:
      - Detects your hardware
      - Warns you if a model is too large for your RAM
      - Downloads the model on first use and caches it
      - Picks CPU vs GPU inference automatically

    Args:
        model_id:  Short ID ('smollm2', 'mistral-7b'), a full HuggingFace
                   model ID ('mistralai/Mistral-7B-Instruct-v0.3'), or a
                   display name ('Mistral 7B Instruct').
        verbose:   Print loading status messages. Default True.

    Examples:
        # Basic usage
        model = Model('smollm2')
        print(model.ask('What is machine learning?'))

        # Use full HuggingFace ID
        model = Model('HuggingFaceTB/SmolLM2-1.7B-Instruct')

        # Quiet mode
        model = Model('smollm2', verbose=False)
    """

    def __init__(self, model_id: str, verbose: bool = True):
        from .registry import get_model_info
        from .hardware import detect_hardware

        self._model_id = model_id
        self._verbose = verbose
        self._pipeline = None
        self._hf_id: Optional[str] = None
        self._info: Optional[dict] = None

        # Resolve model ID → HuggingFace ID
        info = get_model_info(model_id)
        if info:
            self._info = info
            self._hf_id = info["hf_id"]
        else:
            # Treat as a raw HuggingFace model ID
            self._hf_id = model_id

        # RAM check — warn early rather than crash mid-download
        if self._info:
            try:
                hw = detect_hardware()
                safe_limit = hw["ram_gb"] * 0.6
                needed = self._info["min_ram_gb"]

                if needed > safe_limit:
                    from .registry import list_models
                    smaller = list_models(max_ram_gb=safe_limit)
                    suggestion = smaller[-1]["id"] if smaller else "smollm2"
                    self._warn(
                        f"'{model_id}' needs ~{needed}GB RAM but your safe limit "
                        f"is ~{safe_limit:.1f}GB.\n"
                        f"   → Consider Model('{suggestion}') or use Model.auto() "
                        f"to auto-select."
                    )
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Class methods
    # ------------------------------------------------------------------

    @classmethod
    def auto(cls, task: Optional[str] = None, verbose: bool = True) -> "Model":
        """
        Auto-select and return the best model for your hardware.

        AtomLLM detects your available RAM and picks the largest, highest-quality
        model that will run comfortably on your machine.

        Args:
            task:    Optional task hint to filter models.
                     Options: 'chat', 'coding', 'reasoning', 'multilingual', 'math'
            verbose: Print selection info. Default True.

        Returns:
            A Model instance loaded with the best available model.

        Example:
            # Best model for your machine
            model = Model.auto()

            # Best coding model for your machine
            model = Model.auto(task='coding')
        """
        from .registry import list_models

        candidates = list_models(task=task)
        if not candidates:
            candidates = list_models(show_all=True)

        if not candidates:
            raise RuntimeError(
                "No models found. Try: list_models(show_all=True) to see all options."
            )

        # Pick the largest model that fits (last in the filtered list)
        best = candidates[-1]

        if verbose:
            print(
                f"🎯 AtomLLM selected: {best['name']} "
                f"({best['params']} params | ~{best['min_ram_gb']}GB RAM)\n"
                f"   Use Model('{best['id']}') to load this model directly.\n"
            )

        return cls(best["id"], verbose=verbose)

    # ------------------------------------------------------------------
    # Core inference
    # ------------------------------------------------------------------

    def ask(
        self,
        prompt: str,
        max_new_tokens: int = 512,
        temperature: float = 0.7,
        system: Optional[str] = None,
    ) -> str:
        """
        Ask the model a question or give it an instruction.

        Args:
            prompt:         Your question or instruction.
            max_new_tokens: Maximum number of tokens to generate. Default 512.
            temperature:    Randomness of responses.
                            0.0 = deterministic, 1.0 = very creative. Default 0.7.
            system:         Optional system prompt to set the model's persona
                            or behaviour.

        Returns:
            The model's response as a plain string.

        Examples:
            # Simple question
            answer = model.ask('What is the capital of France?')

            # With a system prompt
            answer = model.ask(
                'Explain recursion.',
                system='You are a patient teacher who uses simple analogies.'
            )

            # Deterministic output
            answer = model.ask('List 3 planets.', temperature=0.0)
        """
        self._load()

        messages = self._build_messages(prompt, system)

        try:
            outputs = self._pipeline(
                messages,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=temperature > 0,
                return_full_text=False,
            )
            return outputs[0]["generated_text"].strip()
        except Exception as e:
            raise RuntimeError(
                f"Inference failed: {e}\n\n"
                "Tips:\n"
                "  • Try reducing max_new_tokens\n"
                "  • Try a smaller model: Model('smollm2-tiny')\n"
                "  • Check RAM: from atomllm import detect_hardware; detect_hardware()\n"
            )

    def stream(
        self,
        prompt: str,
        max_new_tokens: int = 512,
        temperature: float = 0.7,
        system: Optional[str] = None,
    ) -> Iterator[str]:
        """
        Stream the model's response, yielding text chunks as they are generated.

        Args:
            prompt:         Your question or instruction.
            max_new_tokens: Maximum number of tokens to generate. Default 512.
            temperature:    Randomness. 0.0 = deterministic. Default 0.7.
            system:         Optional system prompt.

        Yields:
            String chunks of the response as they are generated.

        Example:
            for chunk in model.stream('Write a short poem about the ocean'):
                print(chunk, end='', flush=True)
            print()  # newline at end
        """
        self._load()

        messages = self._build_messages(prompt, system)

        try:
            from transformers import TextIteratorStreamer
            import threading

            streamer = TextIteratorStreamer(
                self._pipeline.tokenizer,
                skip_prompt=True,
                skip_special_tokens=True,
            )

            gen_kwargs = dict(
                text_inputs=messages,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=temperature > 0,
                streamer=streamer,
            )

            thread = threading.Thread(target=self._pipeline, kwargs=gen_kwargs)
            thread.start()

            for chunk in streamer:
                yield chunk

            thread.join()

        except Exception:
            # Graceful fallback to non-streaming
            yield self.ask(prompt, max_new_tokens, temperature, system)

    def chat(self) -> None:
        """
        Start an interactive multi-turn chat session in the terminal.

        Maintains conversation history across turns so the model remembers
        what was said earlier in the session.

        Type 'quit', 'exit', or 'q' to end the session.
        Type 'clear' to reset the conversation history.
        Type 'help' to see available commands.

        Example:
            model = Model('smollm2')
            model.chat()
        """
        self._load()

        name = self._info["name"] if self._info else self._hf_id
        history = []

        print(f"\n{'─' * 50}")
        print(f"  🤖 AtomLLM Chat — {name}")
        print(f"  Commands: quit · clear · help")
        print(f"{'─' * 50}\n")

        while True:
            try:
                user_input = input("You: ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\n\nGoodbye! 👋")
                break

            if not user_input:
                continue

            if user_input.lower() in ("quit", "exit", "q"):
                print("Goodbye! 👋")
                break

            if user_input.lower() == "clear":
                history = []
                print("✅ Conversation cleared.\n")
                continue

            if user_input.lower() == "help":
                print("Commands:")
                print("  quit / exit / q — end the session")
                print("  clear           — reset conversation history\n")
                continue

            history.append({"role": "user", "content": user_input})

            try:
                outputs = self._pipeline(
                    history,
                    max_new_tokens=512,
                    temperature=0.7,
                    do_sample=True,
                    return_full_text=False,
                )
                response = outputs[0]["generated_text"].strip()
                history.append({"role": "assistant", "content": response})
                print(f"\nAI: {response}\n")
            except Exception as e:
                print(f"\n⚠️  Error: {e}\n")

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def info(self) -> Optional[dict]:
        """Model metadata dict from the registry, or None if using a raw HF ID."""
        return self._info

    @property
    def name(self) -> str:
        """Human-readable model name."""
        return self._info["name"] if self._info else self._hf_id

    @property
    def is_loaded(self) -> bool:
        """True if the model pipeline has been initialised."""
        return self._pipeline is not None

    def __repr__(self) -> str:
        status = "loaded" if self.is_loaded else "not loaded"
        return f"<atomllm.Model name='{self.name}' status='{status}'>"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self):
        """Lazy-load the model pipeline on first inference call."""
        if self._pipeline is not None:
            return

        if self._verbose:
            name = self._info["name"] if self._info else self._hf_id
            print(f"📥 Loading {name}...")
            print("   First run downloads the model — subsequent runs are instant.\n")

        try:
            from transformers import pipeline
            import torch

            # Auto-detect best device
            device = "cpu"
            dtype = None

            try:
                import torch
                if torch.cuda.is_available():
                    device = "cuda"
                    dtype = torch.float16
                elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                    device = "mps"
                    dtype = torch.float16
            except Exception:
                pass

            kwargs = dict(
                task="text-generation",
                model=self._hf_id,
                device=device,
                trust_remote_code=True,
            )
            if dtype:
                kwargs["torch_dtype"] = dtype

            self._pipeline = pipeline(**kwargs)

            if self._verbose:
                print(f"✅ {self.name} ready  [{device.upper()}]\n")

        except ImportError as e:
            raise ImportError(
                "AtomLLM requires 'transformers' and 'torch'. Install them with:\n\n"
                "    pip install transformers torch\n\n"
                "For a lighter CPU-only install:\n"
                "    pip install transformers\n"
                "    pip install torch --index-url https://download.pytorch.org/whl/cpu\n"
            ) from e

        except Exception as e:
            raise RuntimeError(
                f"Failed to load '{self._hf_id}'.\n"
                f"Error: {e}\n\n"
                "Suggestions:\n"
                "  • Try a smaller model:     Model('smollm2') or Model('tinyllama')\n"
                "  • Auto-select for you:     Model.auto()\n"
                "  • Check your hardware:     from atomllm import detect_hardware\n"
                "  • Browse compatible models: from atomllm import list_models\n"
            ) from e

    def _build_messages(self, prompt: str, system: Optional[str]) -> list[dict]:
        """Build a messages list for the chat pipeline."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        return messages

    def _warn(self, message: str):
        """Print a warning if verbose mode is on."""
        if self._verbose:
            print(f"\n⚠️  AtomLLM Warning: {message}\n")
