"""
compactllm — Compact AI, any device. No API key. No cost.

Run powerful AI models locally on any device — from old laptops
to modern desktops. Zero API keys. Zero subscriptions. One line of code.

Usage:
    from compactllm import Model, list_models

    model = Model('smollm2')
    print(model.ask('What is AI?'))

    # Or let CompactLLM pick the best model for your hardware
    model = Model.auto()
    print(model.ask('Hello!'))
"""

from .model import Model
from .registry import list_models, get_model_info
from .hardware import detect_hardware

__version__ = "0.1.0"
__author__ = "CompactLLM"
__license__ = "Apache-2.0"
__description__ = "Compact AI, any device. No API key. No cost."

__all__ = ["Model", "list_models", "get_model_info", "detect_hardware"]
