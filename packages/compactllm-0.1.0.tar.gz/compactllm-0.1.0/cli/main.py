"""
cli/main.py — CompactLLM command-line interface.

Registered as the `compact` command after `pip install compactllm`.

Commands:
    compact list                       List models for your hardware
    compact list --all                 List every available model
    compact list --tier basic          List only basic-tier models
    compact list --task coding         Filter by task
    compact ask smollm2 "question"     Ask a model a one-shot question
    compact chat smollm2               Start an interactive chat session
    compact hardware                   Show your hardware info and tier
    compact info smollm2               Show full details about a model
"""

import argparse
import sys


# ── ANSI colours (fallback gracefully if terminal doesn't support them) ────

def _c(text: str, code: str) -> str:
    """Wrap text in ANSI colour code."""
    try:
        return f"\033[{code}m{text}\033[0m"
    except Exception:
        return text

BOLD   = lambda t: _c(t, "1")
BLUE   = lambda t: _c(t, "34")
CYAN   = lambda t: _c(t, "36")
GREEN  = lambda t: _c(t, "32")
YELLOW = lambda t: _c(t, "33")
DIM    = lambda t: _c(t, "2")
RED    = lambda t: _c(t, "31")

TIER_EMOJI = {
    "potato": "🥔",
    "basic":  "💻",
    "mid":    "🖥️ ",
    "high":   "🚀",
}

TIER_LABEL = {
    "potato": "POTATO  (< 4 GB RAM)",
    "basic":  "BASIC   (4–8 GB RAM)",
    "mid":    "MID     (8–16 GB RAM)",
    "high":   "HIGH    (16 GB+ RAM)",
}


# ── Commands ───────────────────────────────────────────────────────────────

def cmd_list(args):
    from compactllm import list_models, detect_hardware

    if not args.all:
        hw = detect_hardware()
        print(f"\n  🖥️  {BOLD('Your hardware')}: {hw['ram_gb']} GB RAM  |  {hw['cpu_name'][:45]}")
        if hw["has_gpu"]:
            vram = f"{hw['gpu_vram_gb']} GB VRAM" if hw["gpu_vram_gb"] else "shared RAM"
            print(f"       GPU detected: {vram}")
        print(f"       Tier: {BOLD(hw['tier'].upper())}  — showing models that fit your machine\n")
    else:
        print(f"\n  📋  {BOLD('All CompactLLM models')} (ignoring hardware limits)\n")

    models = list_models(
        tier=args.tier if not args.all else "all",
        task=getattr(args, "task", None),
        show_all=args.all,
    )

    if not models:
        print("  No models matched your filters. Try --all to see everything.\n")
        return

    current_tier = None
    for m in models:
        # Print tier header when tier changes
        if m["tier"] != current_tier:
            current_tier = m["tier"]
            emoji = TIER_EMOJI.get(current_tier, "•")
            label = TIER_LABEL.get(current_tier, current_tier.upper())
            print(f"  {emoji}  {BOLD(CYAN(label))}")
            print(f"  {'─' * 56}")

        recommended = f"  {GREEN('⭐ recommended')}" if "recommended" in m.get("tags", []) else ""
        print(
            f"  {BOLD(m['name']):<32}"
            f"  {DIM(m['params']):<8}"
            f"  {YELLOW('~' + str(m['min_ram_gb']) + ' GB')}{recommended}"
        )
        print(f"    {DIM('ID:')} {CYAN('compact:' + m['id']):<34}  {DIM(m['best_for'])}")
        print()

    print(f"  {DIM('Run: compact ask <model-id> \"your question\"')}\n")


def cmd_ask(args):
    from compactllm import Model

    model_id = args.model.replace("compact:", "")
    prompt = " ".join(args.prompt)

    model = Model(model_id)
    print(model.ask(prompt))


def cmd_chat(args):
    from compactllm import Model

    model_id = args.model.replace("compact:", "")
    model = Model(model_id)
    model.chat()


def cmd_hardware(args):
    from compactllm import detect_hardware

    hw = detect_hardware()

    tier_descriptions = {
        "potato": "Can run tiny models (< 2B params). Great for quick tasks.",
        "basic":  "Can run small models (up to ~3.8B params). Good for everyday use.",
        "mid":    "Can run medium models (up to 7B params). Excellent quality.",
        "high":   "Can run large models (14B+ params). Best quality available locally.",
    }

    print(f"\n  {'─' * 48}")
    print(f"  🖥️   {BOLD('CompactLLM Hardware Report')}")
    print(f"  {'─' * 48}")
    print(f"  {'RAM:':<14} {YELLOW(str(hw['ram_gb']) + ' GB')}")
    print(f"  {'CPU:':<14} {hw['cpu_name'][:44]}")
    print(f"  {'CPU Cores:':<14} {hw['cpu_cores']}")
    if hw["has_gpu"]:
        vram = f"{hw['gpu_vram_gb']} GB VRAM" if hw["gpu_vram_gb"] else "Unified memory (Apple Silicon)"
        print(f"  {'GPU:':<14} {GREEN('Detected — ' + vram)}")
    else:
        print(f"  {'GPU:':<14} {DIM('None detected (CPU inference)')}")
    print(f"  {'Platform:':<14} {hw['platform']}")
    print(f"  {'─' * 48}")
    print(f"  {'Tier:':<14} {BOLD(GREEN(hw['tier'].upper()))}")
    print(f"  {DIM(tier_descriptions.get(hw['tier'], ''))}")
    print(f"  {'─' * 48}")
    print(f"\n  Run {CYAN('compact list')} to see models compatible with your hardware.\n")


def cmd_info(args):
    from compactllm.registry import get_model_info

    model_id = args.model.replace("compact:", "")
    info = get_model_info(model_id)

    if not info:
        print(f"\n  ❌ Model '{model_id}' not found in CompactLLM registry.")
        print(f"     Run {CYAN('compact list --all')} to browse all available models.\n")
        sys.exit(1)

    emoji = TIER_EMOJI.get(info["tier"], "•")
    print(f"\n  {'─' * 48}")
    print(f"  {emoji}  {BOLD(info['name'])}")
    print(f"  {'─' * 48}")
    print(f"  {'ID:':<16} {CYAN(info['id'])}")
    print(f"  {'HuggingFace:':<16} {DIM(info['hf_id'])}")
    print(f"  {'Parameters:':<16} {info['params']}")
    print(f"  {'Min RAM:':<16} {YELLOW('~' + str(info['min_ram_gb']) + ' GB')}")
    print(f"  {'Tier:':<16} {info['tier'].upper()}")
    print(f"  {'License:':<16} {info['license']}")
    print(f"  {'Tags:':<16} {', '.join(info['tags'])}")
    print(f"  {'Best for:':<16} {info['best_for']}")
    if info.get("quantized_gguf"):
        print(f"  {'GGUF:':<16} {DIM(info['quantized_gguf'])}")
    print(f"  {'─' * 48}")
    print(f"\n  {DIM('Load with:')} from compactllm import Model; model = Model('{info['id']}')\n")


# ── Argument parser ────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="compact",
        description="🤖 CompactLLM — Compact AI, any device. No API key. No cost.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  compact hardware                    Show your hardware tier
  compact list                        Models compatible with your machine
  compact list --all                  All available models
  compact list --tier basic           Only basic-tier models
  compact list --task coding          Only coding models
  compact ask smollm2 "What is AI?"   One-shot question
  compact chat mistral-7b             Interactive chat session
  compact info smollm2                Full details about a model
        """,
    )

    subparsers = parser.add_subparsers(dest="command", metavar="command")

    # list
    p_list = subparsers.add_parser("list", help="List available models")
    p_list.add_argument("--all", action="store_true", help="Show all models, ignore hardware limits")
    p_list.add_argument("--tier", choices=["potato", "basic", "mid", "high"], metavar="TIER",
                        help="Filter by tier: potato | basic | mid | high")
    p_list.add_argument("--task", metavar="TASK",
                        help="Filter by task: chat | coding | reasoning | math | multilingual")

    # ask
    p_ask = subparsers.add_parser("ask", help="Ask a model a question")
    p_ask.add_argument("model", help="Model ID e.g. smollm2 or compact:smollm2")
    p_ask.add_argument("prompt", nargs="+", help="Your prompt (wrap in quotes for multi-word)")

    # chat
    p_chat = subparsers.add_parser("chat", help="Start an interactive chat session")
    p_chat.add_argument("model", help="Model ID e.g. smollm2")

    # hardware
    subparsers.add_parser("hardware", help="Show your hardware info and compatible tier")

    # info
    p_info = subparsers.add_parser("info", help="Show full details about a specific model")
    p_info.add_argument("model", help="Model ID e.g. smollm2")

    # version
    subparsers.add_parser("version", help="Show CompactLLM version")

    args = parser.parse_args()

    if args.command == "list":
        cmd_list(args)
    elif args.command == "ask":
        cmd_ask(args)
    elif args.command == "chat":
        cmd_chat(args)
    elif args.command == "hardware":
        cmd_hardware(args)
    elif args.command == "info":
        cmd_info(args)
    elif args.command == "version":
        from compactllm import __version__
        print(f"CompactLLM v{__version__}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
