from .app import cli  # noqa: F401

__version__ = "4.8.0"
