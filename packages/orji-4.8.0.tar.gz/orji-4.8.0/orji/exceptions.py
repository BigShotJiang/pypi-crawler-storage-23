class OrjiError(Exception):
    pass


class Failure(Exception):
    pass
