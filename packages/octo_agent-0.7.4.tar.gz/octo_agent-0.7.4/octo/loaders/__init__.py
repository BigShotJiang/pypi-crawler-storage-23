"""Loaders for MCP tools, agents, and skills.

Backward-compat shim — actual implementations moved to octo.core.loaders.
"""
