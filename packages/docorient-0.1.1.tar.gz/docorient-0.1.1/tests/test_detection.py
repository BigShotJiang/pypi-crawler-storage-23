from docorient.config import OrientationConfig
from docorient.detection.engine import detect_orientation
from docorient.detection.projection import detect_orientation_by_projection
from docorient.types import OrientationResult


class TestProjectionDetection:
    def test_horizontal_text_returns_zero_angle(self, horizontal_text_image):
        result = detect_orientation_by_projection(horizontal_text_image)
        assert result.angle == 0
        assert result.reliable is True
        assert "projection" in result.method

    def test_vertical_text_returns_nonzero_angle(self, vertical_text_image):
        result = detect_orientation_by_projection(vertical_text_image)
        assert result.angle in (90, 270)
        assert result.reliable is True

    def test_blank_image_returns_result(self, small_blank_image):
        result = detect_orientation_by_projection(small_blank_image)
        assert isinstance(result, OrientationResult)
        assert result.angle in (0, 90, 270)

    def test_custom_target_dimension(self, horizontal_text_image):
        result = detect_orientation_by_projection(horizontal_text_image, target_dimension=400)
        assert isinstance(result, OrientationResult)


class TestEngineDetection:
    def test_horizontal_text_detection(self, horizontal_text_image):
        result = detect_orientation(horizontal_text_image)
        assert result.angle == 0
        assert result.reliable is True

    def test_vertical_text_detection(self, vertical_text_image):
        result = detect_orientation(vertical_text_image)
        assert result.angle in (90, 270)

    def test_with_custom_config(self, horizontal_text_image):
        config = OrientationConfig(
            osd_confidence_threshold=10.0,
            projection_target_dimension=400,
        )
        result = detect_orientation(horizontal_text_image, config=config)
        assert isinstance(result, OrientationResult)

    def test_result_has_all_fields(self, horizontal_text_image):
        result = detect_orientation(horizontal_text_image)
        assert hasattr(result, "angle")
        assert hasattr(result, "method")
        assert hasattr(result, "reliable")
        assert isinstance(result.angle, int)
        assert isinstance(result.method, str)
        assert isinstance(result.reliable, bool)
