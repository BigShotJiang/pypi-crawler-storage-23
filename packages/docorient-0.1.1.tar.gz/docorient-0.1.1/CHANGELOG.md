# Changelog

## 0.1.1 (2026-02-26)

- Docs: added `if __name__ == "__main__":` note for `process_directory` on macOS/Windows

## 0.1.0 (2026-02-25)

- Initial release
- Projection profile engine for 90°/270° detection
- Optional Tesseract OSD engine for 180° detection
- Single image and batch directory processing
- Multi-page majority voting
- Resumable batch processing
- CLI interface
