from docorient.batch.processor import process_directory

__all__ = ["process_directory"]
