from __future__ import annotations

import numpy as np
from PIL import Image

from docorient._imaging import downscale_to_max_dimension
from docorient.types import OrientationResult

PROJECTION_ANALYSIS_DIMENSION = 800
ENERGY_EPSILON = 1e-10


def _compute_projection_energy(pixel_array: np.ndarray, threshold: float) -> tuple[float, float]:
    binary_mask = (pixel_array < threshold).astype(np.float32)
    horizontal_projection = binary_mask.sum(axis=1)
    vertical_projection = binary_mask.sum(axis=0)
    horizontal_energy = float(np.mean(np.diff(horizontal_projection) ** 2))
    vertical_energy = float(np.mean(np.diff(vertical_projection) ** 2))
    return horizontal_energy, vertical_energy


def _compute_energy_ratio(horizontal_energy: float, vertical_energy: float) -> float:
    return horizontal_energy / (vertical_energy + ENERGY_EPSILON)


def detect_orientation_by_projection(
    image: Image.Image,
    target_dimension: int = PROJECTION_ANALYSIS_DIMENSION,
) -> OrientationResult:
    """Detect document orientation using horizontal/vertical projection profile energy analysis.

    Returns OrientationResult with angle 0 (horizontal), 90 or 270 (vertical, needs rotation).
    """
    grayscale_image = image.convert("L")
    downscaled_image = downscale_to_max_dimension(grayscale_image, target_dimension)
    if downscaled_image is not grayscale_image:
        grayscale_image.close()

    pixel_array = np.array(downscaled_image, dtype=np.float32)
    downscaled_image.close()
    brightness_threshold = float(pixel_array.mean())

    horizontal_energy, vertical_energy = _compute_projection_energy(
        pixel_array, brightness_threshold
    )
    energy_ratio = _compute_energy_ratio(horizontal_energy, vertical_energy)

    if energy_ratio > 1.0:
        return OrientationResult(
            angle=0,
            method=f"projection(h/v={energy_ratio:.2f},horizontal)",
            reliable=True,
        )

    rotated_array = np.rot90(pixel_array, k=1)
    rotated_horizontal_energy, rotated_vertical_energy = _compute_projection_energy(
        rotated_array, brightness_threshold
    )
    rotated_energy_ratio = _compute_energy_ratio(rotated_horizontal_energy, rotated_vertical_energy)

    if rotated_energy_ratio > energy_ratio:
        return OrientationResult(
            angle=90,
            method=f"projection(h/v={energy_ratio:.2f}->90ccw:{rotated_energy_ratio:.2f})",
            reliable=True,
        )

    return OrientationResult(
        angle=270,
        method=f"projection(h/v={energy_ratio:.2f}->270ccw)",
        reliable=True,
    )
