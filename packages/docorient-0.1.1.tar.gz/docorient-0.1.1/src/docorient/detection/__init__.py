from docorient.detection.engine import detect_orientation

__all__ = ["detect_orientation"]
