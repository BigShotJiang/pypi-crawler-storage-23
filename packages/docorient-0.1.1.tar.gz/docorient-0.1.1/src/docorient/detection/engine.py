from __future__ import annotations

from PIL import Image

from docorient.config import OrientationConfig
from docorient.detection.osd import detect_orientation_by_osd
from docorient.detection.projection import detect_orientation_by_projection
from docorient.types import OrientationResult


def detect_orientation(
    image: Image.Image,
    config: OrientationConfig | None = None,
) -> OrientationResult:
    """Detect the orientation of a document image.

    Uses projection profile analysis for 90°/270° detection
    and optionally Tesseract OSD for 180° detection.

    Args:
        image: PIL Image to analyze.
        config: Optional configuration. Uses defaults if not provided.

    Returns:
        OrientationResult with detected angle, method description, and reliability flag.
    """
    effective_config = config or OrientationConfig()

    projection_result = detect_orientation_by_projection(
        image,
        target_dimension=effective_config.projection_target_dimension,
    )

    if projection_result.angle in (90, 270):
        return projection_result

    osd_result = detect_orientation_by_osd(
        image,
        max_dimension=effective_config.max_osd_dimension,
        confidence_threshold=effective_config.osd_confidence_threshold,
    )

    if osd_result is not None:
        combined_method = f"{osd_result.method},{projection_result.method}"
        return OrientationResult(
            angle=osd_result.angle,
            method=combined_method,
            reliable=True,
        )

    return projection_result
