from __future__ import annotations

import warnings

from PIL import Image

from docorient._imaging import downscale_to_max_dimension
from docorient.types import OrientationResult

_tesseract_available: bool | None = None


def is_tesseract_available() -> bool:
    global _tesseract_available
    if _tesseract_available is None:
        try:
            import pytesseract  # noqa: F401

            _tesseract_available = True
        except ImportError:
            _tesseract_available = False
    return _tesseract_available


def _query_tesseract_osd(image: Image.Image) -> tuple[int, float]:
    import pytesseract

    try:
        osd_result = pytesseract.image_to_osd(image, output_type=pytesseract.Output.DICT)
        detected_angle = int(osd_result.get("orientation", 0))
        detection_confidence = float(osd_result.get("orientation_conf", 0.0))
        return detected_angle, detection_confidence
    except pytesseract.TesseractError:
        return 0, 0.0


def detect_orientation_by_osd(
    image: Image.Image,
    max_dimension: int = 1200,
    confidence_threshold: float = 2.0,
) -> OrientationResult | None:
    """Detect document orientation using Tesseract OSD.

    Returns OrientationResult if a confident detection is made, None otherwise.
    Returns None immediately if pytesseract is not installed.
    """
    if not is_tesseract_available():
        warnings.warn(
            "pytesseract is not installed. 180° detection is disabled. "
            "Install with: pip install docorient[ocr]",
            UserWarning,
            stacklevel=2,
        )
        return None

    downscaled_image = downscale_to_max_dimension(image, max_dimension)
    detected_angle, detection_confidence = _query_tesseract_osd(downscaled_image)

    if downscaled_image is not image:
        downscaled_image.close()

    if detection_confidence < confidence_threshold:
        return None

    if detected_angle not in (90, 180, 270):
        return None

    return OrientationResult(
        angle=detected_angle,
        method=f"osd(angle={detected_angle},conf={detection_confidence:.1f})",
        reliable=True,
    )
