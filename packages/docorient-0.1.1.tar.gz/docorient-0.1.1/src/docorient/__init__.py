from docorient._version import __version__
from docorient.batch.processor import process_directory
from docorient.config import OrientationConfig
from docorient.correction import correct_document_pages, correct_image
from docorient.detection.engine import detect_orientation
from docorient.exceptions import (
    BatchProcessingError,
    CorrectionError,
    DetectionError,
    DocorientError,
    TesseractNotAvailableError,
)
from docorient.types import (
    BatchSummary,
    CorrectionResult,
    OrientationResult,
    PageResult,
)

__all__ = [
    "BatchProcessingError",
    "BatchSummary",
    "CorrectionError",
    "CorrectionResult",
    "DetectionError",
    "DocorientError",
    "OrientationConfig",
    "OrientationResult",
    "PageResult",
    "TesseractNotAvailableError",
    "__version__",
    "correct_document_pages",
    "correct_image",
    "detect_orientation",
    "process_directory",
]
