from __future__ import annotations

from collections import Counter
from typing import overload

from PIL import Image

from docorient.config import OrientationConfig
from docorient.detection.engine import detect_orientation
from docorient.types import CorrectionResult, OrientationResult


def _apply_rotation(image: Image.Image, angle: int) -> Image.Image:
    if angle == 0:
        return image.copy()
    return image.rotate(angle, expand=True)


@overload
def correct_image(
    image: Image.Image,
    *,
    config: OrientationConfig | None = ...,
    return_metadata: bool = False,
) -> Image.Image: ...


@overload
def correct_image(
    image: Image.Image,
    *,
    config: OrientationConfig | None = ...,
    return_metadata: bool = True,
) -> CorrectionResult: ...


def correct_image(
    image: Image.Image,
    *,
    config: OrientationConfig | None = None,
    return_metadata: bool = False,
) -> Image.Image | CorrectionResult:
    """Detect and correct the orientation of a single document image.

    Args:
        image: PIL Image to correct.
        config: Optional configuration. Uses defaults if not provided.
        return_metadata: If True, returns CorrectionResult with image and detection metadata.

    Returns:
        Corrected PIL Image, or CorrectionResult if return_metadata is True.
    """
    orientation = detect_orientation(image, config=config)
    corrected_image = _apply_rotation(image, orientation.angle)

    if return_metadata:
        return CorrectionResult(image=corrected_image, orientation=orientation)
    return corrected_image


def _apply_majority_voting(
    detection_results: list[OrientationResult],
) -> list[OrientationResult]:
    confident_angles = [
        result.angle for result in detection_results if result.reliable
    ]

    if not confident_angles:
        return detection_results

    majority_angle = Counter(confident_angles).most_common(1)[0][0]
    corrected_results = []

    for result in detection_results:
        if not result.reliable and result.angle != majority_angle:
            corrected_results.append(
                OrientationResult(
                    angle=majority_angle,
                    method=f"{result.method}->majority({majority_angle},was={result.angle})",
                    reliable=True,
                )
            )
        else:
            corrected_results.append(result)

    return corrected_results


def correct_document_pages(
    pages: list[Image.Image],
    *,
    config: OrientationConfig | None = None,
) -> list[CorrectionResult]:
    """Correct orientation of multiple pages from the same document using majority voting.

    Detects orientation for each page individually, then applies majority voting
    to override low-confidence detections with the most common angle.

    Args:
        pages: List of PIL Images representing pages of the same document.
        config: Optional configuration. Uses defaults if not provided.

    Returns:
        List of CorrectionResult, one per input page.
    """
    effective_config = config or OrientationConfig()

    detection_results = [
        detect_orientation(page_image, config=effective_config) for page_image in pages
    ]

    if len(pages) > 1:
        detection_results = _apply_majority_voting(detection_results)

    correction_results = []
    for page_image, orientation in zip(pages, detection_results):
        corrected_page = _apply_rotation(page_image, orientation.angle)
        correction_results.append(
            CorrectionResult(image=corrected_page, orientation=orientation)
        )

    return correction_results
