=====
Usage
=====

To use the PACKMOL plug-in in a project::

    import packmol_step
