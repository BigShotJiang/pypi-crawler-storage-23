ANALYTICS_WEBHOOK_URL = "https://api.dooers.ai/api/webhooks/analytics"
ANALYTICS_BATCH_SIZE = 10
ANALYTICS_FLUSH_INTERVAL = 5.0  # seconds
