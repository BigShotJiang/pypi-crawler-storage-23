"""
HyperStack Python SDK
Cloud memory for AI agents. 3 lines to integrate.

Usage:
    from hyperstack import HyperStack

    hs = HyperStack("hs_your_key")
    hs.store("project-api", "API", "FastAPI on AWS", stack="projects", keywords=["fastapi", "python"])
    results = hs.search("python")
    cards = hs.list()
    hs.delete("project-api")
    stats = hs.stats()

    # Graph features (Pro)
    graph = hs.graph("project-api", depth=2)
    impact = hs.impact("project-api")
    recs = hs.recommend("project-api")
    result = hs.smart_search("what depends on the API?")

    # Branching (v1.4.0)
    branch = hs.fork("experiment/auth-migration")
    diff = hs.diff(branch["branchWorkspaceId"])
    hs.merge(branch["branchWorkspaceId"], strategy="ours")
    hs.discard(branch["branchWorkspaceId"])

    # Agent Identity (v1.4.0)
    identity = hs.identify("researcher", display_name="Research Agent")
    profile = hs.profile("researcher")

    # action=can / action=plan (v1.5.1)
    result = hs.can("deploy-prod", agent="cursor-agent", operation="deploy")
    plan = hs.plan("deploy-prod")

    # Auto-remember from transcript (v1.5.1)
    hs.auto_remember(transcript, source_agent="cursor-agent")

Install:
    pip install hyperstack-py

Docs: https://cascadeai.dev
"""

import json
import os
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional, List, Dict, Any

__version__ = "1.5.2"

DEFAULT_API_URL = "https://hyperstack-cloud.vercel.app"


class HyperStackError(Exception):
    """Base exception for HyperStack errors."""
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


class HyperStack:
    """
    HyperStack client â€” cloud memory for AI agents.

    Args:
        api_key: Your HyperStack API key (starts with hs_)
        workspace: Workspace name (default: "default")
        api_url: API base URL. Overrides HYPERSTACK_BASE_URL env var.
                 Set HYPERSTACK_BASE_URL to point at a self-hosted backend.
    """

    def __init__(
        self,
        api_key: str,
        workspace: str = "default",
        api_url: Optional[str] = None,
    ):
        if not api_key:
            raise HyperStackError("API key required. Get one free at https://cascadeai.dev")
        self.api_key = api_key
        self.workspace = workspace
        # HYPERSTACK_BASE_URL supports self-hosted deployments
        self.api_url = (api_url or os.environ.get("HYPERSTACK_BASE_URL", DEFAULT_API_URL)).rstrip("/")
        # Session-level agent identity â€” set by identify(), auto-stamps store() calls
        self._session_agent_id: Optional[str] = None

    def _request(
        self,
        endpoint: str,
        method: str = "GET",
        body: Optional[dict] = None,
        params: Optional[dict] = None,
        base_params: bool = True,
    ) -> dict:
        """Make an API request."""
        url = f"{self.api_url}/api/{endpoint}"
        if base_params:
            url += f"?workspace={urllib.parse.quote(self.workspace)}"
            if params:
                for k, v in params.items():
                    url += f"&{urllib.parse.quote(str(k))}={urllib.parse.quote(str(v))}"
        elif params:
            url += "?" + "&".join(
                f"{urllib.parse.quote(str(k))}={urllib.parse.quote(str(v))}"
                for k, v in params.items()
            )

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

        data = json.dumps(body).encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body_text = e.read().decode("utf-8", errors="replace")
            try:
                err_data = json.loads(body_text)
                msg = err_data.get("error", body_text)
            except Exception:
                msg = body_text
            raise HyperStackError(msg, status=e.code)
        except urllib.error.URLError as e:
            raise HyperStackError(f"Connection failed: {e.reason}")

    def store(
        self,
        slug: str,
        title: str,
        body: str,
        stack: str = "general",
        keywords: Optional[List[str]] = None,
        card_type: str = "general",
        links: Optional[List[Dict[str, str]]] = None,
        source_agent: Optional[str] = None,
        target_agent: Optional[str] = None,
        confidence: Optional[float] = None,
        truth_stratum: str = "hypothesis",
        verified_by: Optional[str] = None,
        ttl: Optional[str] = None,
    ) -> dict:
        """
        Store or update a memory card.

        Args:
            slug: Unique ID (kebab-case, e.g. "project-webapp")
            title: Short title
            body: The knowledge to remember
            stack: Category (projects|people|decisions|preferences|workflows|general)
            keywords: Tags for search
            card_type: Type (person|project|decision|preference|workflow|event|general|signal|scratchpad)
            links: List of dicts with 'target' and 'relation' keys
            source_agent: Agent storing this card
            target_agent: Agent this card is directed at (for inter-agent signals)
            confidence: Self-reported certainty 0.0â€“1.0 (default 1.0)
            truth_stratum: Epistemic status â€” draft|hypothesis|confirmed
            verified_by: Who/what confirmed this card (e.g. 'human:deeq', 'tool:web_search')
            ttl: ISO datetime for auto-expiry. Use with scratchpad cards.

        Returns:
            Card data dict
        """
        payload = {
            "slug": slug,
            "title": title,
            "body": body,
            "stack": stack,
            "cardType": card_type,
            "keywords": keywords or [],
            "truthStratum": truth_stratum,
        }
        if links:
            payload["links"] = links
        if source_agent:
            payload["sourceAgent"] = source_agent
        if target_agent:
            payload["targetAgent"] = target_agent
        if confidence is not None:
            payload["confidence"] = confidence
        if verified_by:
            payload["verifiedBy"] = verified_by
        if ttl:
            payload["ttl"] = ttl
        # Auto-stamp agent identity if identified this session
        if self._session_agent_id:
            payload["agentIdentityId"] = self._session_agent_id

        return self._request("cards", method="POST", body=payload)

    def search(self, query: str) -> List[dict]:
        """Search memory cards using vector + graph (GraphRAG)."""
        result = self._request("search", params={"q": query})
        return result.get("results", result.get("cards", []))

    def smart_search(self, query: str, slug: Optional[str] = None) -> dict:
        """
        Agentic RAG â€” automatically routes to the best retrieval mode
        (search, graph traversal, or impact analysis) based on the query.
        """
        params = {"q": query, "mode": "auto"}
        if slug:
            params["slug"] = slug
        return self._request("search", params=params)

    def list(self, stack: Optional[str] = None) -> List[dict]:
        """List all memory cards, optionally filtered by stack."""
        result = self._request("cards")
        cards = result.get("cards", [])
        if stack:
            cards = [c for c in cards if c.get("stack") == stack]
        return cards

    def get(self, slug: str) -> Optional[dict]:
        """Get a specific card by slug."""
        cards = self.list()
        for card in cards:
            if card.get("slug") == slug:
                return card
        return None

    def delete(self, slug: str) -> dict:
        """Delete a memory card by slug."""
        return self._request("cards", method="DELETE", params={"id": slug})

    def graph(
        self,
        from_slug: str,
        depth: int = 1,
        relation: Optional[str] = None,
        at: Optional[str] = None,
    ) -> dict:
        """Traverse the knowledge graph forward from a starting card. Requires Pro."""
        params = {"from": from_slug, "depth": str(depth)}
        if relation:
            params["relation"] = relation
        if at:
            params["at"] = at
        return self._request("graph", params=params)

    def impact(self, slug: str, depth: int = 2, relation: Optional[str] = None) -> dict:
        """Reverse traversal â€” finds all cards that point TO a given card. Requires Pro."""
        params = {"from": slug, "depth": str(depth), "mode": "impact"}
        if relation:
            params["relation"] = relation
        return self._request("graph", params=params)

    def recommend(self, slug: str, limit: int = 5) -> List[dict]:
        """Find related cards using co-citation scoring. Requires Pro."""
        params = {"from": slug, "mode": "recommend", "limit": str(limit)}
        result = self._request("graph", params=params)
        return result.get("recommendations", result.get("nodes", []))

    def stats(self) -> dict:
        """Get memory usage stats."""
        result = self._request("cards")
        cards = result.get("cards", [])
        total_tokens = sum(c.get("tokens", 0) for c in cards)
        without_hs = len(cards) * 6000
        stacks: Dict[str, int] = {}
        for c in cards:
            s = c.get("stack", "general")
            stacks[s] = stacks.get(s, 0) + 1
        return {
            "cards": len(cards),
            "plan": result.get("plan", "FREE"),
            "limit": result.get("limit", 50),
            "tokens_stored": total_tokens,
            "tokens_without_hs": without_hs,
            "savings_pct": round((1 - total_tokens / without_hs) * 100) if without_hs > 0 else 0,
            "stacks": stacks,
        }

    def ingest(self, text: str, source: str = "conversation") -> dict:
        """Auto-extract memory cards from raw text."""
        return self._request("ingest", method="POST", body={
            "text": text,
            "workspace": self.workspace,
            "source": source,
        })

    def prune(self, days: int = 30, dry: bool = True) -> dict:
        """
        Remove stale cards older than N days that are no longer referenced.
        Always run with dry=True first. Pinned and confirmed cards are never pruned.
        """
        params = {"prune": "true", "days": str(days)}
        if dry:
            params["dry"] = "true"
        return self._request("cards", method="DELETE", params=params)

    def commit(
        self,
        task_slug: str,
        title: str,
        outcome: str,
        keywords: Optional[List[str]] = None,
        source_agent: Optional[str] = None,
        target_agent: Optional[str] = None,
    ) -> dict:
        """
        Commit a completed task outcome to long-term memory as a decision card.
        Links back to the original task card via a 'decided' relation.
        """
        payload = {
            "taskSlug": task_slug,
            "title": title,
            "outcome": outcome,
            "keywords": keywords or [],
        }
        if source_agent:
            payload["sourceAgent"] = source_agent
        if target_agent:
            payload["targetAgent"] = target_agent
        return self._request("cards", method="POST", body=payload, params={"commit": "true"})

    # â”€â”€ Branching (v1.4.0) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def fork(self, branch_name: str) -> dict:
        """
        Fork the current workspace into an isolated branch.
        Write cards freely, test hypotheses, run experiments.
        Merge back to main if it worked â€” discard if it didn't.
        Main memory is never touched until you merge. Requires Pro.

        Args:
            branch_name: Name for this branch (e.g. 'experiment/auth-migration')

        Returns:
            Dict with branchWorkspaceId, cardsCopied, branchName, forkedAt
        """
        return self._request(
            "workspaces",
            method="POST",
            body={"branchName": branch_name},
            params={"action": "fork"},
        )

    def diff(self, branch_workspace_id: str) -> dict:
        """
        Compare a branch workspace against its parent.
        Returns added, changed, and deleted card slugs. Lightweight â€” slugs only.
        Requires Pro.

        Args:
            branch_workspace_id: Branch ID returned by fork()

        Returns:
            Dict with added, changed, deleted lists of {slug, title}
        """
        return self._request(
            "workspaces",
            method="GET",
            params={"action": "diff", "branchWorkspaceId": branch_workspace_id},
        )

    def merge(self, branch_workspace_id: str, strategy: str = "ours") -> dict:
        """
        Merge a branch workspace back into its parent.
        Whole-card granularity â€” no per-field merging. Requires Pro.

        Args:
            branch_workspace_id: Branch ID to merge
            strategy: 'ours' = branch cards win (default). 'theirs' = parent cards win.

        Returns:
            Dict with merged count, skipped count
        """
        if strategy not in ("ours", "theirs"):
            raise HyperStackError("strategy must be 'ours' or 'theirs'")
        return self._request(
            "workspaces",
            method="POST",
            body={"branchWorkspaceId": branch_workspace_id, "strategy": strategy},
            params={"action": "merge"},
        )

    def discard(self, branch_workspace_id: str) -> dict:
        """
        Destroy a branch workspace and all its cards.
        Parent workspace is completely untouched. Requires Pro.

        Args:
            branch_workspace_id: Branch ID to destroy

        Returns:
            Dict with deleted: True
        """
        return self._request(
            "workspaces",
            method="POST",
            body={"branchWorkspaceId": branch_workspace_id},
            params={"action": "discard"},
        )

    # â”€â”€ Agent Identity (v1.4.0) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def identify(self, agent_slug: str, display_name: Optional[str] = None) -> dict:
        """
        Register this agent's identity and stamp all subsequent store() calls with it.
        Idempotent â€” safe to call multiple times. Requires Pro.

        Args:
            agent_slug: Unique identifier for this agent (e.g. 'researcher')
            display_name: Human-readable name (defaults to agent_slug)

        Returns:
            Dict with agentSlug, fingerprint, registeredAt, isNew
        """
        payload: dict = {"agentSlug": agent_slug}
        if display_name:
            payload["displayName"] = display_name

        result = self._request(
            "agent-tokens",
            method="POST",
            body=payload,
            params={"action": "register"},
        )
        # Store fingerprint â€” auto-stamps all subsequent store() calls
        if result.get("fingerprint"):
            self._session_agent_id = result["fingerprint"]
        return result

    def profile(self, agent_slug: str) -> dict:
        """
        Get an agent's identity profile including computed trustScore.
        trustScore is computed on read only (never on write). Requires Pro.

        trustScore formula:
            (verifiedCards / totalCards) * 0.7 + min(cardCount / 100, 1.0) * 0.3

        Args:
            agent_slug: Agent slug to look up

        Returns:
            Dict with agentSlug, displayName, cardCount, verifiedCards,
            trustScore, registeredAt, lastActiveAt
        """
        return self._request(
            "agent-tokens",
            method="GET",
            params={"action": "profile", "agentSlug": agent_slug},
        )

    # -- Memory Hub (v1.5.0) ------------------------------------------------

    def memory(
        self,
        segment: str,
        workspace: Optional[str] = None,
        min_utility: Optional[float] = None,
        include_expired: bool = False,
    ) -> dict:
        """
        Query Memory Hub by segment type.

        Args:
            segment: "episodic" | "semantic" | "working"
            workspace: workspace slug (uses default if not provided)
            min_utility: optional float 0-1, filter by avg edge utility score
            include_expired: include expired TTL cards (working memory only)

        Returns:
            dict with segment, retentionPolicy, count, cards[]
            episodic: includes decayScore, daysSinceCreated, isStale per card
            semantic: includes confidence, truth_stratum, verified_by, isVerified per card
            working: includes ttl, expiresAt, isExpired, ttlExtended per card
        """
        if segment not in ("episodic", "semantic", "working"):
            raise HyperStackError("segment must be 'episodic', 'semantic', or 'working'")
        old_ws = self.workspace
        try:
            if workspace:
                self.workspace = workspace
            params: Dict[str, str] = {"memoryType": segment}
            if min_utility is not None:
                params["minUtility"] = str(min_utility)
            if include_expired:
                params["includeExpired"] = "true"
            return self._request("cards", params=params)
        finally:
            self.workspace = old_ws

    def replay(self, slug: str, workspace: Optional[str] = None) -> dict:
        """
        Decision replay -- reconstruct what the agent knew when a decision was made.
        Returns the full graph state at the moment the card was created, with
        hindsight detection (cards created AFTER the decision that would have changed it).

        Args:
            slug: the decision card slug to replay
            workspace: workspace slug (uses default if not provided)

        Returns:
            dict with slug, decidedAt, graphAtDecision[], hindsightCards[], replayMode
        """
        old_ws = self.workspace
        try:
            if workspace:
                self.workspace = workspace
            return self._request("graph", params={"from": slug, "mode": "replay"})
        finally:
            self.workspace = old_ws

    def feedback(
        self,
        card_slugs: List[str],
        outcome: str,
        agent: Optional[str] = None,
        task_id: Optional[str] = None,
        workspace: Optional[str] = None,
    ) -> dict:
        """
        Submit success/failure feedback on cards used in an agent task.
        Promotes utility scores on success (+0.1), penalises on failure (-0.05).
        Over time, edges self-sort by actual usefulness.

        Args:
            card_slugs: list of card slugs that were in context for this task
            outcome: "success" | "failure"
            agent: agent identifier string (optional)
            task_id: task identifier for logging (optional)
            workspace: workspace slug (uses default if not provided)

        Returns:
            dict with feedback, outcome, cardsAffected, edgesUpdated, agent
        """
        if outcome not in ("success", "failure"):
            raise HyperStackError("outcome must be 'success' or 'failure'")
        old_ws = self.workspace
        try:
            if workspace:
                self.workspace = workspace
            payload: Dict[str, Any] = {
                "cardSlugs": card_slugs,
                "outcome": outcome,
            }
            if agent:
                payload["agent"] = agent
            if task_id:
                payload["taskId"] = task_id
            return self._request("cards", method="POST", body=payload, params={"action": "feedback"})
        finally:
            self.workspace = old_ws

    def can(self, target: str, agent: str, operation: str, workspace: Optional[str] = None) -> dict:
        """
        Check if an agent can perform an operation using full graph state.
        Evaluates active blockers, stale dependencies, approvals, and agent trust score.
        Returns can=True/False with reasons. Zero LLM cost. Requires Pro.

        Args:
            target: card slug to check against
            agent: agent slug requesting the operation
            operation: operation name (e.g. 'deploy', 'write', 'approve')
            workspace: workspace slug (uses default if not provided)

        Returns:
            dict with can, blockers, staleDependencies, approvals, missingApprovals, reasons
        """
        old_ws = self.workspace
        try:
            if workspace:
                self.workspace = workspace
            return self._request(
                "graph",
                params={"action": "can", "agent": agent, "operation": operation, "target": target},
            )
        finally:
            self.workspace = old_ws

    def plan(self, target: str, workspace: Optional[str] = None) -> dict:
        """
        Generate a topologically-sorted execution plan for a target card.
        BFS traversal of the full depends-on chain (max depth 10).
        Each step includes truth_stratum, confidence, avgUtility, activeBlockers, criticalPath flag.
        Requires Pro.

        Args:
            target: card slug to plan from
            workspace: workspace slug (uses default if not provided)

        Returns:
            dict with target, plan[], readyToExecute, criticalPath[], lowestConfidence, stepCount
        """
        old_ws = self.workspace
        try:
            if workspace:
                self.workspace = workspace
            return self._request(
                "graph",
                params={"action": "plan", "target": target},
            )
        finally:
            self.workspace = old_ws

    def auto_remember(
        self,
        transcript: str,
        source_agent: Optional[str] = None,
        dry_run: bool = False,
        workspace: Optional[str] = None,
    ) -> dict:
        """
        Parse a conversation transcript and auto-extract cards into HyperStack.
        Extracts decisions, blockers, people, tasks (ttl: 7d), and technical facts.
        All parsing is client-side — calls existing /api/cards in batch. No new API endpoints.

        Args:
            transcript: full conversation text to parse
            source_agent: agent that produced this transcript (optional)
            dry_run: if True, parse and return extracted cards without storing
            workspace: workspace slug (uses default if not provided)

        Returns:
            dict with stored count, skipped count, and extracted cards list
        """
        old_ws = self.workspace
        try:
            if workspace:
                self.workspace = workspace
            payload: Dict[str, Any] = {"transcript": transcript, "workspace": self.workspace}
            if source_agent:
                payload["source_agent"] = source_agent
            if dry_run:
                payload["dry_run"] = True
            return self._request("cards", method="POST", body=payload, params={"action": "auto_remember"})
        finally:
            self.workspace = old_ws

    def __repr__(self) -> str:
        return f"HyperStack(workspace='{self.workspace}', key='...{self.api_key[-6:]}')"
