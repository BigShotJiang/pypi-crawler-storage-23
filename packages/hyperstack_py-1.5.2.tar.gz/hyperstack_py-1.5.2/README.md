# 🃏 HyperStack Python SDK

**Cloud memory for AI agents. Zero dependencies. 3 lines to integrate.**

## Install

```bash
pip install hyperstack-py
```

## Quick Start

```python
from hyperstack import HyperStack

hs = HyperStack("hs_your_key")

# Store a memory
hs.store("project-api", "API", "FastAPI 3.12 on AWS", stack="projects", keywords=["fastapi", "python"])

# Search memories
results = hs.search("python")

# List all cards
cards = hs.list()

# Delete a card
hs.delete("project-api")

# Get usage stats
stats = hs.stats()
print(f"Saving {stats['savings_pct']}% on tokens!")

# Auto-extract from conversation text
hs.ingest("Alice is a senior engineer. We decided to use FastAPI over Django.")
```

## Why HyperStack?

- **Zero dependencies** — just Python stdlib
- **No LLM costs** — memory ops are free
- **94% token savings** — ~350 tokens vs ~6,000 per message
- **30-second setup** — get key at [cascadeai.dev](https://cascadeai.dev)

## API Reference

| Method | Description |
|--------|-------------|
| `store(slug, title, body, stack, keywords)` | Create/update a card |
| `search(query)` | Search cards |
| `list(stack=None)` | List all cards |
| `get(slug)` | Get one card |
| `delete(slug)` | Delete a card |
| `stats()` | Usage summary |
| `ingest(text)` | Auto-extract memories |

## Get a free key

→ [cascadeai.dev](https://cascadeai.dev) — 50 cards free, no credit card.

## License

MIT © [CascadeAI](https://cascadeai.dev)
