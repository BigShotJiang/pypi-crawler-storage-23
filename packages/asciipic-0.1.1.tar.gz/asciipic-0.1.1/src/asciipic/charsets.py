ASCII_PRINTABLE = "".join(chr(i) for i in range(32, 127))

ASCII_SYMBOLS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,:;!?@#$%&*+-=/<>()[]{}|\\\"'`~^_"
