#!/usr/bin/env python3
import mhi.enerplot

with mhi.enerplot.application() as enerplot:
    enerplot.silence = True


    enerplot.new_workspace()
    enerplot.load_datafiles('C:\\Users\\Public\\Documents\\Enerplot\\1.0.0\\Examples\\DataFiles\\CSV_Files\\Cigre_47.csv', load_data=True)
    untitled = enerplot.book('Untitled')
    sheet1 = untitled.sheet('Sheet1')
    gf = sheet1.graph_frame()
    gf.position(1, 1)
    gf.extents(1, 1, 45, 32)
    gf.properties(title="Rectifier AC Voltage")
    graph = gf.panel(0)
    graph.properties(title="Phase Voltages (kV)")
    cigre_47 = enerplot.datafile('Cigre_47.csv')
    rectifier_ac_voltage_1 = cigre_47.channel('Rectifier\\AC Voltage:1')
    graph.add_curves(rectifier_ac_voltage_1)
    rectifier_ac_voltage_2 = cigre_47.channel('Rectifier\\AC Voltage:2')
    graph.add_curves(rectifier_ac_voltage_2)
    rectifier_ac_voltage_3 = cigre_47.channel('Rectifier\\AC Voltage:3')
    graph.add_curves(rectifier_ac_voltage_3)
    graph.zoom(xmin=0, xmax=0.2, ymin=-0.2, ymax=1.2)
    graph2 = gf.add_overlay_graph()
    graph2.properties(title="Zero Sequence Voltage (V)", gridvalue=0.200000, yintervalue=0.000000, ymin="-1", ymax=1)
    untitled.save_as('C:\\Users\\aneufeld\\Documents\\ScriptDemo.epbx')
    enerplot.save_workspace_as('C:\\Users\\aneufeld\\Documents\\ScriptDemo.epwx', save_projects=False)
