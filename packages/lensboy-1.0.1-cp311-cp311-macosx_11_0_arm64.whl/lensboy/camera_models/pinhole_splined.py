from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from lensboy import lensboy_bindings as lbb
from lensboy.camera_models.base_model import CameraModel, CameraModelConfig
from lensboy.camera_models.pinhole_remapped import PinholeRemapped


@dataclass
class PinholeSplinedConfig(CameraModelConfig):
    """Configuration for fitting a PinholeSplined model.

    Attributes:
        image_height: Image height in pixels.
        image_width: Image width in pixels.
        initial_focal_length: Initial focal length guess in pixels.
        num_knots_x: Number of spline knots along the x axis.
        num_knots_y: Number of spline knots along the y axis.
    """

    image_height: int
    image_width: int

    initial_focal_length: float

    num_knots_x: int
    num_knots_y: int


@dataclass
class PinholeSplined(CameraModel):
    """Pinhole camera model with a 2D B-spline distortion field.

    The distortion is represented as two grids of spline knot values (dx_grid,
    dy_grid) defined over the image domain. Use get_pinhole_model(),
    get_pinhole_model_fov(), or get_pinhole_model_alpha() to obtain an
    undistorted PinholeRemapped view.

    Attributes:
        image_width: Image width in pixels.
        image_height: Image height in pixels.
        fx: Focal length along x in pixels.
        fy: Focal length along y in pixels.
        cx: Principal point x in pixels.
        cy: Principal point y in pixels.
        dx_grid: Spline knot values for the x distortion component,
            shape (num_knots_y, num_knots_x).
        dy_grid: Spline knot values for the y distortion component,
            shape (num_knots_y, num_knots_x).
        num_knots_x: Number of spline knots along the x axis.
        num_knots_y: Number of spline knots along the y axis.
        fov_deg_x: Horizontal field of view in degrees.
        fov_deg_y: Vertical field of view in degrees.
        seed_opencv_distortion_parameters: Seed OpenCV distortion coefficients
            used during calibration; None otherwise.
    """

    image_width: int
    image_height: int

    fx: float
    fy: float
    cx: float
    cy: float

    dx_grid: np.ndarray
    dy_grid: np.ndarray

    num_knots_x: int
    num_knots_y: int

    fov_deg_x: float
    fov_deg_y: float

    seed_opencv_distortion_parameters: np.ndarray | None = None

    def __post_init__(self):
        assert self.dx_grid.ndim == 2, f"Expected 2D dx_grid, got {self.dx_grid.ndim}D"
        assert np.issubdtype(self.dx_grid.dtype, np.floating), (
            f"Expected floating dtype for dx_grid, got {self.dx_grid.dtype}"
        )
        assert self.dy_grid.ndim == 2, f"Expected 2D dy_grid, got {self.dy_grid.ndim}D"
        assert np.issubdtype(self.dy_grid.dtype, np.floating), (
            f"Expected floating dtype for dy_grid, got {self.dy_grid.dtype}"
        )

    def save(self, path: Path | str) -> None:
        """Serialize the model to a JSON file.

        Args:
            path: Destination file path.
        """
        Path(path).write_text(json.dumps(self.to_json(), indent=4))

    @staticmethod
    def load(path: Path | str) -> PinholeSplined:
        """Load a model from a JSON file written by save().

        Args:
            path: Path to the JSON file.

        Returns:
            Reconstructed model.
        """
        return PinholeSplined.from_json(json.loads(Path(path).read_text()))

    def to_json(self) -> dict:
        """Serialize the model to a JSON-compatible dict.

        Returns:
            Dict with all model parameters. Spline grids are stored as nested
            lists of shape (num_knots_y, num_knots_x).
        """
        return {
            "type": "pinhole_splined",
            "image_width": self.image_width,
            "image_height": self.image_height,
            "fx": self.fx,
            "fy": self.fy,
            "cx": self.cx,
            "cy": self.cy,
            "dx_grid": self.dx_grid.tolist(),
            "dy_grid": self.dy_grid.tolist(),
            "num_knots_x": self.num_knots_x,
            "num_knots_y": self.num_knots_y,
            "fov_deg_x": self.fov_deg_x,
            "fov_deg_y": self.fov_deg_y,
            "seed_opencv_distortion_parameters": (
                self.seed_opencv_distortion_parameters.tolist()
                if self.seed_opencv_distortion_parameters is not None
                else None
            ),
        }

    @staticmethod
    def from_json(data: dict) -> PinholeSplined:
        """Reconstruct a model from a dict produced by to_json().

        Args:
            data: Dict with all model parameters.

        Returns:
            Reconstructed model.
        """
        seed = data["seed_opencv_distortion_parameters"]
        return PinholeSplined(
            image_width=data["image_width"],
            image_height=data["image_height"],
            fx=data["fx"],
            fy=data["fy"],
            cx=data["cx"],
            cy=data["cy"],
            dx_grid=np.array(data["dx_grid"], dtype=np.float64),
            dy_grid=np.array(data["dy_grid"], dtype=np.float64),
            num_knots_x=data["num_knots_x"],
            num_knots_y=data["num_knots_y"],
            fov_deg_x=data["fov_deg_x"],
            fov_deg_y=data["fov_deg_y"],
            seed_opencv_distortion_parameters=(
                np.array(seed, dtype=np.float64) if seed is not None else None
            ),
        )

    @staticmethod
    def _camera_model_name() -> str:
        return "pinhole_splined"

    def _cpp_config(self) -> lbb.PinholeSplinedConfig:
        return lbb.PinholeSplinedConfig(
            self.image_width,
            self.image_height,
            self.fov_deg_x,
            self.fov_deg_y,
            self.num_knots_x,
            self.num_knots_y,
        )

    def _cpp_params(self) -> lbb.PinholeSplinedIntrinsicsParameters:
        return lbb.PinholeSplinedIntrinsicsParameters(
            self._k4(), self.dx_grid, self.dy_grid
        )

    def project_points(
        self,
        points_in_cam: np.ndarray,
    ) -> np.ndarray:
        """Project 3D camera-frame points to pixel coordinates.

        Args:
            points_in_cam: Shape (N, 3).

        Returns:
            Projected pixel coordinates, shape (N, 2).
        """
        assert points_in_cam.ndim == 2 and points_in_cam.shape[1] == 3, (
            f"Expected (N, 3) array, got {points_in_cam.shape}"
        )
        assert np.issubdtype(points_in_cam.dtype, np.floating), (
            f"Expected floating dtype, got {points_in_cam.dtype}"
        )
        return lbb.project_pinhole_splined_points(
            self._cpp_config(),
            self._cpp_params(),
            points_in_camera=points_in_cam,
        )

    def _k4(self):
        return (self.fx, self.fy, self.cx, self.cy)

    def _K(self):
        return np.array(
            [[self.fx, 0.0, self.cx], [0.0, self.fy, self.cy], [0.0, 0.0, 1.0]]
        )

    def get_pinhole_model_fov(
        self,
        target_fov_deg_x: float | None = None,
        target_fov_deg_y: float | None = None,
        image_size_wh: tuple[int, int] | None = None,
    ) -> PinholeRemapped:
        """Build an undistorted pinhole view with a specified field of view.

        Args:
            target_fov_deg_x: Desired horizontal FOV in degrees.
                Defaults to the model's fov_deg_x.
            target_fov_deg_y: Desired vertical FOV in degrees.
                Defaults to the model's fov_deg_y.
            image_size_wh: Output image size as (width, height).
                Defaults to the model's image size.

        Returns:
            Undistorted pinhole model with precomputed remap tables.
        """
        fov_x = target_fov_deg_x if target_fov_deg_x is not None else self.fov_deg_x
        fov_y = target_fov_deg_y if target_fov_deg_y is not None else self.fov_deg_y

        if image_size_wh is None:
            image_size_wh = (self.image_width, self.image_height)

        image_w, image_h = image_size_wh

        fx = image_w / (2 * np.tan(np.deg2rad(fov_x) / 2))
        fy = image_h / (2 * np.tan(np.deg2rad(fov_y) / 2))
        cx = image_w / 2.0
        cy = image_h / 2.0

        return self.get_pinhole_model(
            k4=(fx, fy, cx, cy),
            image_size_wh=image_size_wh,
        )

    def get_pinhole_model(
        self,
        k4: tuple[float, float, float, float] | None = None,
        image_size_wh: tuple[int, int] | None = None,
    ) -> PinholeRemapped:
        """Build an undistorted pinhole view with explicit intrinsics.

        Args:
            k4: Pinhole intrinsics as (fx, fy, cx, cy).
                Defaults to the model's intrinsics.
            image_size_wh: Output image size as (width, height).
                Defaults to the model's image size.

        Returns:
            Undistorted pinhole model with precomputed remap tables.
        """
        if k4 is None:
            k4 = self._k4()

        if image_size_wh is None:
            image_size_wh = (self.image_width, self.image_height)

        map_x, map_y = lbb.make_undistortion_maps_pinhole_splined(
            self._cpp_config(),
            self._cpp_params(),
            np.array(k4, dtype=float),
            image_size_wh,
        )

        return PinholeRemapped(
            image_width=image_size_wh[0],
            image_height=image_size_wh[1],
            input_image_width=self.image_width,
            input_image_height=self.image_height,
            fx=k4[0],
            fy=k4[1],
            cx=k4[2],
            cy=k4[3],
            map_x=map_x,
            map_y=map_y,
        )

    def get_pinhole_model_alpha(
        self,
        alpha: float,
        image_size_wh: tuple[int, int] | None = None,
    ) -> PinholeRemapped:
        """Build an undistorted pinhole view using OpenCV's alpha scaling.

        alpha=0 crops to only valid (non-black) pixels; alpha=1 keeps all
        pixels with black borders. Requires seed_opencv_distortion_parameters to be set.

        Args:
            alpha: Scaling parameter in [0, 1].
            image_size_wh: Output image size as (width, height).
                Defaults to the model's image size.

        Returns:
            Undistorted pinhole model with precomputed remap tables.
        """
        if self.seed_opencv_distortion_parameters is None:
            raise ValueError("Require reference opencv distortion coefficients for this")

        dist = self.seed_opencv_distortion_parameters
        K = self._K()

        if image_size_wh is None:
            image_size_wh = (self.image_width, self.image_height)

        new_K, _roi = cv2.getOptimalNewCameraMatrix(
            K, dist, (self.image_width, self.image_height), alpha, image_size_wh
        )

        fx = new_K[0, 0]
        fy = new_K[1, 1]
        cx = new_K[0, 2]
        cy = new_K[1, 2]

        return self.get_pinhole_model((fx, fy, cx, cy), image_size_wh)
