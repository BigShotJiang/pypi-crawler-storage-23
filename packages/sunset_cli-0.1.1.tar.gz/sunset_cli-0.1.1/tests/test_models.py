"""Tests for data models."""

from datetime import datetime

from netmind.models import (
    ApprovalRequest,
    ApprovalStatus,
    Checkpoint,
    CommandResult,
    CommandType,
    Device,
    DeviceCredentials,
    DeviceInfo,
    DeviceStatus,
    DeviceType,
)


class TestDevice:
    def test_create_device(self):
        creds = DeviceCredentials(username="admin", password="secret123")
        device = Device(
            device_id="R1",
            host="192.168.1.1",
            device_type=DeviceType.CISCO_IOS,
            credentials=creds,
        )
        assert device.device_id == "R1"
        assert device.host == "192.168.1.1"
        assert device.status == DeviceStatus.DISCONNECTED
        assert device.is_connected is False

    def test_display_name_with_hostname(self):
        creds = DeviceCredentials(username="admin", password="secret")
        device = Device(
            device_id="R1",
            host="192.168.1.1",
            credentials=creds,
            info=DeviceInfo(hostname="router-1"),
        )
        assert device.display_name == "router-1 (192.168.1.1)"

    def test_display_name_without_hostname(self):
        creds = DeviceCredentials(username="admin", password="secret")
        device = Device(device_id="R1", host="192.168.1.1", credentials=creds)
        assert device.display_name == "R1 (192.168.1.1)"

    def test_password_not_in_repr(self):
        creds = DeviceCredentials(username="admin", password="super_secret")
        assert "super_secret" not in repr(creds)


class TestCommandResult:
    def test_success_result(self):
        result = CommandResult(
            success=True,
            device_id="R1",
            command="show ip interface brief",
            output="Interface  IP-Address...",
        )
        assert result.success is True
        assert "OK" in result.summary

    def test_failure_result(self):
        result = CommandResult(
            success=False,
            device_id="R1",
            command="show ip interface brief",
            error="Connection timeout",
        )
        assert result.success is False
        assert "FAIL" in result.summary

    def test_to_tool_result_success(self):
        result = CommandResult(
            success=True,
            device_id="R1",
            command="show version",
            output="Cisco IOS...",
        )
        tool_result = result.to_tool_result()
        assert tool_result["status"] == "success"
        assert tool_result["output"] == "Cisco IOS..."

    def test_to_tool_result_error(self):
        result = CommandResult(
            success=False,
            device_id="R1",
            command="show version",
            error="Timeout",
        )
        tool_result = result.to_tool_result()
        assert tool_result["status"] == "error"
        assert tool_result["error"] == "Timeout"


class TestApprovalRequest:
    def test_create_request(self):
        req = ApprovalRequest(
            device_id="R1",
            commands=["router ospf 1", "router-id 1.1.1.1"],
            description="Configure OSPF",
        )
        assert req.is_pending is True
        assert req.is_approved is False

    def test_approve_request(self):
        req = ApprovalRequest(
            device_id="R1",
            commands=["router ospf 1"],
            description="Configure OSPF",
        )
        req.approve()
        assert req.is_approved is True
        assert req.status == ApprovalStatus.APPROVED
        assert req.resolved_at is not None

    def test_reject_request(self):
        req = ApprovalRequest(
            device_id="R1",
            commands=["router ospf 1"],
            description="Configure OSPF",
        )
        req.reject()
        assert req.is_approved is False
        assert req.status == ApprovalStatus.REJECTED

    def test_commands_display(self):
        req = ApprovalRequest(
            device_id="R1",
            commands=["router ospf 1", "router-id 1.1.1.1", "network 10.0.0.0 0.0.0.255 area 0"],
            description="Configure OSPF",
        )
        display = req.commands_display
        assert "router ospf 1" in display
        assert "network 10.0.0.0" in display
