"""Integration tests that run against REAL network devices.

These tests require:
  1. An inventory file at inventory.yml (or pass --inventory=path)
  2. Reachable devices with valid SSH credentials

Run:
    # All integration tests (uses inventory.yml)
    python -m pytest tests/test_integration.py -v

    # With a specific inventory file
    python -m pytest tests/test_integration.py -v --inventory=my_lab.yml

    # Just connection tests
    python -m pytest tests/test_integration.py -v -k "connect"

    # Just command execution tests
    python -m pytest tests/test_integration.py -v -k "command"

These tests are skipped if no inventory file is found.
"""

import tempfile
from pathlib import Path
from typing import Optional
from unittest.mock import patch

import pytest

from netmind.core.device_connection import DeviceConnection, DeviceConnectionError
from netmind.core.device_manager import DeviceManager
from netmind.core.safety import SafetyGuard, CheckpointManager
from netmind.models import DeviceStatus
from netmind.utils.inventory import load_inventory, InventoryError
from netmind.utils.session_logger import reset_session_logger, SessionLogger


# ── Fixtures ────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def inventory_path(request) -> Optional[str]:
    """Get the inventory path from the CLI or default locations."""
    return request.config.getoption("--inventory")


@pytest.fixture(scope="session")
def inventory(inventory_path) -> list[dict]:
    """Load the device inventory. Skip all tests if not available."""
    try:
        devices = load_inventory(inventory_path)
    except InventoryError as e:
        pytest.skip(f"Inventory error: {e}")
        return []

    if not devices:
        pytest.skip(
            "No inventory file found. Create inventory.yml or pass --inventory=path. "
            "See inventory.example.yml for format."
        )

    return devices


@pytest.fixture(scope="session")
def first_device(inventory) -> dict:
    """Get the first device from the inventory."""
    return inventory[0]


@pytest.fixture(autouse=True)
def _isolate_session_logger(tmp_path):
    """Ensure each test gets a fresh session logger."""
    reset_session_logger()
    with patch("netmind.utils.session_logger._instance", SessionLogger(log_dir=str(tmp_path))):
        yield
    reset_session_logger()


@pytest.fixture
def device_manager() -> DeviceManager:
    """Create a fresh DeviceManager."""
    dm = DeviceManager()
    yield dm
    dm.disconnect_all()


# ── Connection Tests ────────────────────────────────────────────


class TestDeviceConnect:
    """Test real SSH connections to devices."""

    def test_connect_first_device(self, first_device, device_manager):
        """Connect to the first device in the inventory."""
        dev = first_device
        conn = device_manager.add_device(
            device_id=dev["device_id"],
            host=dev["host"],
            username=dev["username"],
            password=dev["password"],
            device_type=dev["device_type"],
            port=dev["port"],
            enable_secret=dev.get("enable_secret"),
        )
        assert conn.is_connected
        assert conn.device.status == DeviceStatus.CONNECTED
        assert conn.device.info.hostname != ""

        print(f"\n  Connected: {dev['device_id']} @ {dev['host']}")
        print(f"  Hostname:  {conn.device.info.hostname}")
        print(f"  Version:   {conn.device.info.os_version}")
        print(f"  Model:     {conn.device.info.model}")

    def test_connect_all_devices(self, inventory, device_manager):
        """Connect to every device in the inventory."""
        errors = []
        for dev in inventory:
            try:
                conn = device_manager.add_device(
                    device_id=dev["device_id"],
                    host=dev["host"],
                    username=dev["username"],
                    password=dev["password"],
                    device_type=dev["device_type"],
                    port=dev["port"],
                    enable_secret=dev.get("enable_secret"),
                )
                print(f"\n  OK: {dev['device_id']} ({conn.device.info.hostname})")
            except DeviceConnectionError as e:
                errors.append(f"{dev['device_id']}: {e}")
                print(f"\n  FAIL: {dev['device_id']}: {e}")

        assert device_manager.connected_count > 0, "At least one device must connect"
        if errors:
            print(f"\n  {len(errors)} device(s) failed to connect")

    def test_disconnect_and_reconnect(self, first_device, device_manager):
        """Test disconnect and reconnect cycle."""
        dev = first_device
        conn = device_manager.add_device(
            device_id=dev["device_id"],
            host=dev["host"],
            username=dev["username"],
            password=dev["password"],
            device_type=dev["device_type"],
            port=dev["port"],
            enable_secret=dev.get("enable_secret"),
        )
        assert conn.is_connected

        conn.disconnect()
        assert not conn.is_connected
        assert conn.device.status == DeviceStatus.DISCONNECTED

        # Reconnect
        conn.connect()
        assert conn.is_connected


class TestLoadFromInventory:
    """Test the DeviceManager.load_from_inventory() method."""

    def test_load_inventory_file(self, inventory, inventory_path, device_manager):
        """Load all devices from the inventory file."""
        # The `inventory` fixture ensures we skip if no file exists
        success, errors = device_manager.load_from_inventory(inventory_path)

        print(f"\n  Loaded: {success} device(s)")
        if errors:
            for err in errors:
                print(f"  Error: {err}")

        assert success > 0, "At least one device must load successfully"


# ── Command Execution Tests ─────────────────────────────────────


class TestShowCommands:
    """Test executing show commands on real devices."""

    @pytest.fixture(autouse=True)
    def _connect_device(self, first_device, device_manager):
        """Connect the first device before each test."""
        dev = first_device
        self.conn = device_manager.add_device(
            device_id=dev["device_id"],
            host=dev["host"],
            username=dev["username"],
            password=dev["password"],
            device_type=dev["device_type"],
            port=dev["port"],
            enable_secret=dev.get("enable_secret"),
        )
        self.device_id = dev["device_id"]
        self.dm = device_manager

    def test_show_version(self):
        result = self.dm.execute_on_device(self.device_id, "show version")
        assert result.success, f"show version failed: {result.error}"
        assert "Cisco" in result.output or "cisco" in result.output.lower()
        assert result.execution_time_ms > 0
        print(f"\n  show version: {result.execution_time_ms:.0f}ms, {len(result.output)} chars")

    def test_show_ip_interface_brief(self):
        result = self.dm.execute_on_device(self.device_id, "show ip interface brief")
        assert result.success, f"show ip int brief failed: {result.error}"
        assert "Interface" in result.output
        print(f"\n  show ip int brief: {result.execution_time_ms:.0f}ms")
        print(f"  {result.output[:200]}")

    def test_show_running_config(self):
        try:
            config = self.conn.get_running_config()
            assert len(config) > 100, "Running config seems too short"
            assert "hostname" in config.lower() or "version" in config.lower()
            print(f"\n  Running config: {len(config)} chars")
        except Exception as e:
            if "privilege" in str(e).lower() or "failed to get" in str(e).lower():
                pytest.skip(
                    f"Cannot read running-config (insufficient privilege). "
                    f"Set enable_secret in inventory. Error: {e}"
                )
            raise

    def test_show_ip_route(self):
        result = self.dm.execute_on_device(self.device_id, "show ip route")
        assert result.success, f"show ip route failed: {result.error}"
        print(f"\n  show ip route: {result.execution_time_ms:.0f}ms")

    def test_show_ip_ospf_neighbor(self):
        result = self.dm.execute_on_device(self.device_id, "show ip ospf neighbor")
        assert result.success, f"show ip ospf neighbor failed: {result.error}"
        print(f"\n  show ip ospf neighbor: {result.execution_time_ms:.0f}ms")
        if "Neighbor" in result.output:
            print(f"  {result.output[:300]}")
        else:
            print("  (no OSPF neighbors)")

    def test_show_ip_ospf(self):
        result = self.dm.execute_on_device(self.device_id, "show ip ospf")
        assert result.success, f"show ip ospf failed: {result.error}"
        print(f"\n  show ip ospf: {result.execution_time_ms:.0f}ms")

    def test_invalid_command_returns_output(self):
        """Even an invalid command should return successfully (IOS returns error text)."""
        result = self.dm.execute_on_device(self.device_id, "show nonexistent")
        # Netmiko may return success with error text, or fail — both are valid
        print(f"\n  Invalid command: success={result.success}")
        if result.output:
            print(f"  Output: {result.output[:200]}")

    def test_command_timing(self):
        """Verify that execution timing is measured."""
        result = self.dm.execute_on_device(self.device_id, "show clock")
        assert result.success
        assert result.execution_time_ms > 0
        print(f"\n  show clock: {result.execution_time_ms:.0f}ms → {result.output.strip()}")


# ── Safety Guard Tests (with real devices) ──────────────────────


class TestSafetyWithRealDevices:
    """Test that safety mechanisms work correctly with real device context."""

    @pytest.fixture(autouse=True)
    def _connect_device(self, first_device, device_manager):
        dev = first_device
        self.conn = device_manager.add_device(
            device_id=dev["device_id"],
            host=dev["host"],
            username=dev["username"],
            password=dev["password"],
            device_type=dev["device_type"],
            port=dev["port"],
            enable_secret=dev.get("enable_secret"),
        )
        self.device_id = dev["device_id"]
        self.dm = device_manager

    def test_read_only_blocks_config_tool(self):
        """Safety guard should block config in read-only mode."""
        guard = SafetyGuard(read_only=True)
        allowed, reason = guard.can_execute_config(["router ospf 1"])
        assert not allowed
        assert "Read-only" in reason

    def test_checkpoint_creation(self):
        """Create a real checkpoint from the device's running config."""
        ckpt_mgr = CheckpointManager()
        checkpoint = ckpt_mgr.create_checkpoint(self.conn, description="Integration test checkpoint")

        if checkpoint is None:
            pytest.skip(
                "Cannot create checkpoint (likely insufficient privilege for show running-config). "
                "Set enable_secret in inventory."
            )

        assert len(checkpoint.config_snapshot) > 100
        assert checkpoint.device_id == self.device_id
        print(f"\n  Checkpoint: {checkpoint.name}")
        print(f"  Config snapshot: {len(checkpoint.config_snapshot)} chars")


# ── Parser Integration Tests ────────────────────────────────────


class TestParsersWithRealOutput:
    """Test parsers against real device output."""

    @pytest.fixture(autouse=True)
    def _connect_device(self, first_device, device_manager):
        dev = first_device
        self.conn = device_manager.add_device(
            device_id=dev["device_id"],
            host=dev["host"],
            username=dev["username"],
            password=dev["password"],
            device_type=dev["device_type"],
            port=dev["port"],
            enable_secret=dev.get("enable_secret"),
        )
        self.device_id = dev["device_id"]
        self.dm = device_manager

    def test_parse_real_show_version(self):
        from netmind.utils.parsers import parse_show_version

        result = self.dm.execute_on_device(self.device_id, "show version")
        assert result.success

        parsed = parse_show_version(result.output)
        print(f"\n  Parsed show version:")
        for k, v in parsed.items():
            print(f"    {k}: {v}")

        # At minimum we should get a version
        assert parsed.get("version"), "Failed to parse version from real output"

    def test_parse_real_show_ip_interface_brief(self):
        from netmind.utils.parsers import parse_show_ip_interface_brief

        result = self.dm.execute_on_device(self.device_id, "show ip interface brief")
        assert result.success

        interfaces = parse_show_ip_interface_brief(result.output)
        print(f"\n  Parsed {len(interfaces)} interfaces:")
        for iface in interfaces:
            print(f"    {iface['interface']:30s} {iface['ip_address']:16s} {iface['status']}/{iface['protocol']}")

        assert len(interfaces) > 0, "Should parse at least one interface"

    def test_parse_real_show_ip_ospf_neighbor(self):
        from netmind.utils.parsers import parse_show_ip_ospf_neighbor

        result = self.dm.execute_on_device(self.device_id, "show ip ospf neighbor")
        assert result.success

        neighbors = parse_show_ip_ospf_neighbor(result.output)
        print(f"\n  Parsed {len(neighbors)} OSPF neighbors:")
        for nbr in neighbors:
            print(f"    {nbr.get('neighbor_id', '?'):16s} state={nbr.get('state', '?')}")

    def test_parse_real_show_ip_route_ospf(self):
        from netmind.utils.parsers import parse_show_ip_route_ospf

        result = self.dm.execute_on_device(self.device_id, "show ip route ospf")
        assert result.success

        routes = parse_show_ip_route_ospf(result.output)
        print(f"\n  Parsed {len(routes)} OSPF routes:")
        for route in routes:
            print(f"    {route.get('network', '?'):20s} via {route.get('next_hop', '?')}")
