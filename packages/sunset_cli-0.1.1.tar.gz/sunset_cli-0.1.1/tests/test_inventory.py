"""Tests for the inventory loader."""

import os
import tempfile
from pathlib import Path

import pytest

from netmind.models import DeviceType
from netmind.utils.inventory import (
    InventoryError,
    load_inventory,
    _expand_env,
    _validate_device_entry,
)


class TestLoadInventory:
    def test_load_valid_inventory(self, tmp_path):
        inv = tmp_path / "inventory.yml"
        inv.write_text(
            "devices:\n"
            "  - id: R1\n"
            "    host: 192.168.1.1\n"
            "    username: admin\n"
            "    password: cisco\n"
        )
        devices = load_inventory(str(inv))
        assert len(devices) == 1
        assert devices[0]["device_id"] == "R1"
        assert devices[0]["host"] == "192.168.1.1"
        assert devices[0]["username"] == "admin"
        assert devices[0]["password"] == "cisco"
        assert devices[0]["device_type"] == DeviceType.CISCO_IOS
        assert devices[0]["port"] == 22

    def test_load_multiple_devices(self, tmp_path):
        inv = tmp_path / "inventory.yml"
        inv.write_text(
            "devices:\n"
            "  - id: R1\n"
            "    host: 10.0.0.1\n"
            "    username: admin\n"
            "    password: pass1\n"
            "  - id: R2\n"
            "    host: 10.0.0.2\n"
            "    username: admin\n"
            "    password: pass2\n"
            "    port: 2222\n"
        )
        devices = load_inventory(str(inv))
        assert len(devices) == 2
        assert devices[0]["device_id"] == "R1"
        assert devices[1]["device_id"] == "R2"
        assert devices[1]["port"] == 2222

    def test_load_with_optional_fields(self, tmp_path):
        inv = tmp_path / "inventory.yml"
        inv.write_text(
            "devices:\n"
            "  - id: SW1\n"
            "    host: 10.0.0.10\n"
            "    username: admin\n"
            "    password: cisco\n"
            "    enable_secret: enable123\n"
            "    device_type: cisco_ios\n"
            "    port: 8022\n"
        )
        devices = load_inventory(str(inv))
        assert len(devices) == 1
        assert devices[0]["enable_secret"] == "enable123"
        assert devices[0]["port"] == 8022

    def test_missing_file_explicit_path(self):
        with pytest.raises(InventoryError, match="not found"):
            load_inventory("/nonexistent/path/inventory.yml")

    def test_missing_file_default_returns_empty(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        devices = load_inventory(None)
        assert devices == []

    def test_empty_file(self, tmp_path):
        inv = tmp_path / "inventory.yml"
        inv.write_text("")
        devices = load_inventory(str(inv))
        assert devices == []

    def test_missing_devices_key(self, tmp_path):
        inv = tmp_path / "inventory.yml"
        inv.write_text("something_else:\n  - foo\n")
        with pytest.raises(InventoryError, match="devices"):
            load_inventory(str(inv))

    def test_invalid_yaml(self, tmp_path):
        inv = tmp_path / "inventory.yml"
        inv.write_text("{{invalid yaml: [}")
        with pytest.raises(InventoryError, match="Invalid YAML"):
            load_inventory(str(inv))

    def test_devices_not_a_list(self, tmp_path):
        inv = tmp_path / "inventory.yml"
        inv.write_text("devices:\n  host: 10.0.0.1\n")
        with pytest.raises(InventoryError, match="must be a list"):
            load_inventory(str(inv))


class TestValidateDeviceEntry:
    def test_missing_id(self):
        with pytest.raises(InventoryError, match="id"):
            _validate_device_entry({"host": "1.2.3.4", "username": "a", "password": "b"}, 0)

    def test_missing_host(self):
        with pytest.raises(InventoryError, match="host"):
            _validate_device_entry({"id": "R1", "username": "a", "password": "b"}, 0)

    def test_missing_username(self):
        with pytest.raises(InventoryError, match="username"):
            _validate_device_entry({"id": "R1", "host": "1.2.3.4", "password": "b"}, 0)

    def test_missing_password(self):
        with pytest.raises(InventoryError, match="password"):
            _validate_device_entry({"id": "R1", "host": "1.2.3.4", "username": "a"}, 0)

    def test_invalid_port(self):
        with pytest.raises(InventoryError, match="Invalid port"):
            _validate_device_entry(
                {"id": "R1", "host": "1.2.3.4", "username": "a", "password": "b", "port": 99999},
                0,
            )

    def test_invalid_device_type(self):
        with pytest.raises(InventoryError, match="Unknown device_type"):
            _validate_device_entry(
                {"id": "R1", "host": "1.2.3.4", "username": "a", "password": "b", "device_type": "juniper"},
                0,
            )

    def test_entry_not_a_dict(self):
        with pytest.raises(InventoryError, match="dict"):
            _validate_device_entry("not a dict", 0)


class TestExpandEnv:
    def test_expand_simple_var(self, monkeypatch):
        monkeypatch.setenv("MY_PASSWORD", "s3cr3t")
        assert _expand_env("${MY_PASSWORD}") == "s3cr3t"

    def test_expand_multiple_vars(self, monkeypatch):
        monkeypatch.setenv("USER", "admin")
        monkeypatch.setenv("PASS", "cisco")
        result = _expand_env("${USER}:${PASS}")
        assert result == "admin:cisco"

    def test_no_expansion_needed(self):
        assert _expand_env("plain_text") == "plain_text"

    def test_missing_var_left_as_is(self, monkeypatch):
        monkeypatch.delenv("NONEXISTENT_VAR", raising=False)
        assert _expand_env("${NONEXISTENT_VAR}") == "${NONEXISTENT_VAR}"

    def test_non_string_input(self):
        assert _expand_env(42) == "42"
        assert _expand_env(None) == ""
