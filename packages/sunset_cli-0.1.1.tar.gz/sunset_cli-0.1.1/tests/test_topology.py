"""Tests for the network topology model and inventory parsing."""

import os
import tempfile
from pathlib import Path

import pytest
import yaml

from netmind.core.topology import (
    InterfaceInfo,
    NetworkTopology,
    OSPFArea,
    OSPFConfig,
    TopologyLink,
    TopologyNode,
)
from netmind.utils.inventory import (
    InventoryError,
    load_full_inventory,
    load_inventory,
)


# ── Fixtures ─────────────────────────────────────────────────────────


@pytest.fixture
def sample_inventory_yaml() -> str:
    """A full production-style inventory YAML string."""
    return """
devices:
  - id: R1
    host: 192.168.1.1
    username: admin
    password: cisco
    device_type: cisco_ios
    role: router
    site: DC1
    interfaces:
      - name: GigabitEthernet0/0
        ip: 10.10.10.1
        mask: 255.255.255.0
        description: Link to R2
        connected_to: R2:GigabitEthernet0/0
      - name: GigabitEthernet0/1
        ip: 10.10.20.1
        mask: 255.255.255.0
        description: Link to R3
        connected_to: R3:GigabitEthernet0/0
      - name: Loopback0
        ip: 1.1.1.1
        mask: 255.255.255.255
        description: Router-ID
    ospf:
      process_id: 1
      router_id: 1.1.1.1
      areas:
        - id: 0
          networks:
            - network: 10.10.10.0
              wildcard: 0.0.0.255
            - network: 10.10.20.0
              wildcard: 0.0.0.255
      passive_interfaces:
        - Loopback0

  - id: R2
    host: 192.168.1.2
    username: admin
    password: cisco
    device_type: cisco_ios
    role: router
    site: DC1
    interfaces:
      - name: GigabitEthernet0/0
        ip: 10.10.10.2
        mask: 255.255.255.0
        description: Link to R1
        connected_to: R1:GigabitEthernet0/0
      - name: GigabitEthernet0/1
        ip: 10.10.30.1
        mask: 255.255.255.0
        description: Link to R3
        connected_to: R3:GigabitEthernet0/1
      - name: Loopback0
        ip: 2.2.2.2
        mask: 255.255.255.255
    ospf:
      process_id: 1
      router_id: 2.2.2.2
      areas:
        - id: 0
          networks:
            - network: 10.10.10.0
              wildcard: 0.0.0.255
            - network: 10.10.30.0
              wildcard: 0.0.0.255

  - id: R3
    host: 192.168.1.3
    username: admin
    password: cisco
    device_type: cisco_ios
    role: router
    site: DC2
    interfaces:
      - name: GigabitEthernet0/0
        ip: 10.10.20.2
        mask: 255.255.255.0
        description: Link to R1
        connected_to: R1:GigabitEthernet0/1
      - name: GigabitEthernet0/1
        ip: 10.10.30.2
        mask: 255.255.255.0
        description: Link to R2
        connected_to: R2:GigabitEthernet0/1
      - name: Loopback0
        ip: 3.3.3.3
        mask: 255.255.255.255
    ospf:
      process_id: 1
      router_id: 3.3.3.3
      areas:
        - id: 0
          networks:
            - network: 10.10.20.0
              wildcard: 0.0.0.255
            - network: 10.10.30.0
              wildcard: 0.0.0.255
"""


@pytest.fixture
def inventory_file(sample_inventory_yaml, tmp_path):
    """Write inventory YAML to a temp file and return the path."""
    path = tmp_path / "inventory.yml"
    path.write_text(sample_inventory_yaml)
    return str(path)


@pytest.fixture
def three_node_topology(inventory_file):
    """Load a 3-node topology from inventory."""
    _, topology = load_full_inventory(inventory_file)
    return topology


# ── Topology model tests ─────────────────────────────────────────────


class TestTopologyNode:
    """Tests for TopologyNode model."""

    def test_get_interface_exact(self):
        node = TopologyNode(
            device_id="R1",
            interfaces=[
                InterfaceInfo(name="GigabitEthernet0/0", ip="10.0.0.1"),
                InterfaceInfo(name="Loopback0", ip="1.1.1.1"),
            ],
        )
        iface = node.get_interface("Loopback0")
        assert iface is not None
        assert iface.ip == "1.1.1.1"

    def test_get_interface_partial(self):
        node = TopologyNode(
            device_id="R1",
            interfaces=[
                InterfaceInfo(name="GigabitEthernet0/0", ip="10.0.0.1"),
            ],
        )
        # Partial match
        iface = node.get_interface("gigabitethernet0/0")
        assert iface is not None
        assert iface.ip == "10.0.0.1"

    def test_get_interface_missing(self):
        node = TopologyNode(device_id="R1", interfaces=[])
        assert node.get_interface("Gi0/0") is None

    def test_management_ip_priority(self):
        node = TopologyNode(
            device_id="R1",
            host="192.168.1.1",
            loopback_ip="1.1.1.1",
            interfaces=[InterfaceInfo(name="Gi0/0", ip="10.0.0.1")],
        )
        assert node.management_ip == "192.168.1.1"

    def test_management_ip_loopback_fallback(self):
        node = TopologyNode(
            device_id="R1",
            loopback_ip="1.1.1.1",
            interfaces=[InterfaceInfo(name="Gi0/0", ip="10.0.0.1")],
        )
        assert node.management_ip == "1.1.1.1"


class TestNetworkTopology:
    """Tests for the NetworkTopology graph engine."""

    def test_add_node(self):
        topo = NetworkTopology()
        node = TopologyNode(device_id="R1")
        topo.add_node(node)
        assert topo.node_count == 1
        assert topo.get_node("R1") is not None

    def test_add_link(self):
        topo = NetworkTopology()
        topo.add_node(TopologyNode(device_id="R1"))
        topo.add_node(TopologyNode(device_id="R2"))
        link = TopologyLink(
            source_device="R1",
            source_interface="Gi0/0",
            target_device="R2",
            target_interface="Gi0/0",
        )
        topo.add_link(link)
        assert topo.link_count == 1

    def test_get_neighbors(self, three_node_topology):
        topo = three_node_topology
        neighbors = topo.get_neighbors("R1")
        neighbor_ids = {n["neighbor_id"] for n in neighbors}
        assert "R2" in neighbor_ids
        assert "R3" in neighbor_ids

    def test_get_neighbors_r2(self, three_node_topology):
        topo = three_node_topology
        neighbors = topo.get_neighbors("R2")
        neighbor_ids = {n["neighbor_id"] for n in neighbors}
        assert "R1" in neighbor_ids
        assert "R3" in neighbor_ids

    def test_find_path_direct(self, three_node_topology):
        topo = three_node_topology
        path = topo.find_path("R1", "R2")
        assert path is not None
        assert path == ["R1", "R2"]

    def test_find_path_same(self, three_node_topology):
        topo = three_node_topology
        path = topo.find_path("R1", "R1")
        assert path == ["R1"]

    def test_find_path_nonexistent(self, three_node_topology):
        topo = three_node_topology
        path = topo.find_path("R1", "R99")
        assert path is None

    def test_find_path_multi_hop(self):
        """Test path through a chain topology: A - B - C."""
        topo = NetworkTopology()
        topo.add_node(TopologyNode(device_id="A"))
        topo.add_node(TopologyNode(device_id="B"))
        topo.add_node(TopologyNode(device_id="C"))
        topo.add_link(TopologyLink(
            source_device="A", source_interface="eth0",
            target_device="B", target_interface="eth0",
        ))
        topo.add_link(TopologyLink(
            source_device="B", source_interface="eth1",
            target_device="C", target_interface="eth0",
        ))
        path = topo.find_path("A", "C")
        assert path == ["A", "B", "C"]

    def test_get_device_interfaces(self, three_node_topology):
        topo = three_node_topology
        interfaces = topo.get_device_interfaces("R1")
        assert interfaces is not None
        assert len(interfaces) == 3  # Gi0/0, Gi0/1, Lo0
        gi0 = next(i for i in interfaces if "0/0" in i["name"])
        assert gi0["connected_to_device"] == "R2"

    def test_get_device_interfaces_nonexistent(self, three_node_topology):
        topo = three_node_topology
        assert topo.get_device_interfaces("R99") is None

    def test_get_subnets(self, three_node_topology):
        topo = three_node_topology
        subnets = topo.get_subnets()
        assert len(subnets) > 0
        # 10.10.10.0/24 should have R1 and R2
        subnet_10 = subnets.get("10.10.10.0/24", [])
        devices_in_subnet = {e["device"] for e in subnet_10}
        assert "R1" in devices_in_subnet
        assert "R2" in devices_in_subnet

    def test_get_ospf_summary(self, three_node_topology):
        topo = three_node_topology
        ospf = topo.get_ospf_summary()
        assert 0 in ospf["ospf_areas"]
        assert "R1" in ospf["devices"]
        assert ospf["devices"]["R1"]["router_id"] == "1.1.1.1"

    def test_get_topology_summary(self, three_node_topology):
        topo = three_node_topology
        summary = topo.get_topology_summary()
        assert summary["node_count"] == 3
        assert summary["link_count"] == 3
        assert len(summary["nodes"]) == 3
        assert len(summary["links"]) == 3
        assert "diagram" in summary

    def test_ascii_diagram(self, three_node_topology):
        topo = three_node_topology
        diagram = topo.generate_ascii_diagram()
        assert "R1" in diagram
        assert "R2" in diagram
        assert "R3" in diagram
        assert "LINKS" in diagram

    def test_build_links_from_interfaces(self):
        """Links are auto-created from connected_to fields."""
        topo = NetworkTopology()
        topo.add_node(TopologyNode(
            device_id="A",
            interfaces=[InterfaceInfo(
                name="eth0",
                ip="10.0.0.1",
                cidr=24,
                connected_to="B:eth0",
            )],
        ))
        topo.add_node(TopologyNode(
            device_id="B",
            interfaces=[InterfaceInfo(
                name="eth0",
                ip="10.0.0.2",
                cidr=24,
                connected_to="A:eth0",
            )],
        ))
        count = topo.build_links_from_interfaces()
        assert count == 1  # deduplicated
        assert topo.link_count == 1

    def test_mask_to_cidr(self):
        assert NetworkTopology.mask_to_cidr("255.255.255.0") == 24
        assert NetworkTopology.mask_to_cidr("255.255.255.255") == 32
        assert NetworkTopology.mask_to_cidr("255.255.0.0") == 16
        assert NetworkTopology.mask_to_cidr("255.255.255.252") == 30

    def test_mask_to_wildcard(self):
        assert NetworkTopology.mask_to_wildcard("255.255.255.0") == "0.0.0.255"
        assert NetworkTopology.mask_to_wildcard("255.255.255.255") == "0.0.0.0"
        assert NetworkTopology.mask_to_wildcard("255.255.0.0") == "0.0.255.255"


# ── Inventory loading tests ──────────────────────────────────────────


class TestLoadFullInventory:
    """Tests for load_full_inventory."""

    def test_load_full_inventory(self, inventory_file):
        devices, topology = load_full_inventory(inventory_file)
        assert len(devices) == 3
        assert topology.node_count == 3
        assert topology.link_count == 3

    def test_device_dicts_have_required_fields(self, inventory_file):
        devices, _ = load_full_inventory(inventory_file)
        for dev in devices:
            assert "device_id" in dev
            assert "host" in dev
            assert "username" in dev
            assert "password" in dev
            assert "device_type" in dev
            assert "port" in dev

    def test_topology_has_ospf(self, inventory_file):
        _, topology = load_full_inventory(inventory_file)
        for node in topology.get_all_nodes():
            assert node.ospf is not None
            assert node.ospf.process_id == 1

    def test_topology_has_interfaces(self, inventory_file):
        _, topology = load_full_inventory(inventory_file)
        r1 = topology.get_node("R1")
        assert r1 is not None
        assert len(r1.interfaces) == 3

    def test_topology_has_roles_and_sites(self, inventory_file):
        _, topology = load_full_inventory(inventory_file)
        r1 = topology.get_node("R1")
        assert r1.role == "router"
        assert r1.site == "DC1"
        r3 = topology.get_node("R3")
        assert r3.site == "DC2"

    def test_loopback_ip_detection(self, inventory_file):
        _, topology = load_full_inventory(inventory_file)
        r1 = topology.get_node("R1")
        assert r1.loopback_ip == "1.1.1.1"

    def test_missing_file(self):
        with pytest.raises(InventoryError):
            load_full_inventory("/nonexistent/path.yml")

    def test_no_interfaces(self, tmp_path):
        """Inventory without interfaces still works for device connections."""
        yaml_content = """
devices:
  - id: R1
    host: 192.168.1.1
    username: admin
    password: cisco
"""
        path = tmp_path / "simple.yml"
        path.write_text(yaml_content)
        devices, topology = load_full_inventory(str(path))
        assert len(devices) == 1
        assert topology.node_count == 1
        assert topology.link_count == 0

    def test_explicit_links(self, tmp_path):
        """Test explicit links section."""
        yaml_content = """
devices:
  - id: R1
    host: 192.168.1.1
    username: admin
    password: cisco
    interfaces:
      - name: Gi0/0
        ip: 10.0.0.1
        mask: 255.255.255.0
  - id: R2
    host: 192.168.1.2
    username: admin
    password: cisco
    interfaces:
      - name: Gi0/0
        ip: 10.0.0.2
        mask: 255.255.255.0

links:
  - endpoints: [R1:Gi0/0, R2:Gi0/0]
    subnet: 10.0.0.0/24
    description: Core link
    ospf_area: 0
"""
        path = tmp_path / "explicit.yml"
        path.write_text(yaml_content)
        _, topology = load_full_inventory(str(path))
        assert topology.link_count == 1
        links = topology.get_all_links()
        assert links[0].description == "Core link"
        assert links[0].ospf_area == 0


class TestCIDRConversion:
    """Test mask-to-CIDR conversion during interface parsing."""

    def test_mask_converted_to_cidr(self, inventory_file):
        _, topology = load_full_inventory(inventory_file)
        r1 = topology.get_node("R1")
        gi0 = r1.get_interface("GigabitEthernet0/0")
        assert gi0.cidr == 24
        assert gi0.mask == "255.255.255.0"

    def test_loopback_mask(self, inventory_file):
        _, topology = load_full_inventory(inventory_file)
        r1 = topology.get_node("R1")
        lo0 = r1.get_interface("Loopback0")
        assert lo0.cidr == 32
