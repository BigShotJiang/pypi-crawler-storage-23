"""Tests for the ToolRegistry."""

import pytest

from netmind.agent.tool_registry import ToolRegistry, TOOLS


class TestToolRegistry:
    def test_register_handler(self):
        registry = ToolRegistry()

        async def mock_handler(tool_input, context):
            return {"status": "success"}

        registry.register("test_tool", mock_handler)
        assert "test_tool" in registry._handlers

    def test_get_tool_definitions(self):
        registry = ToolRegistry()
        defs = registry.get_tool_definitions()
        assert isinstance(defs, list)
        assert len(defs) > 0

        # All tools should have required fields
        for tool in defs:
            assert "name" in tool
            assert "description" in tool
            assert "input_schema" in tool

    def test_tool_names_match_expected(self):
        expected = {
            "execute_command",
            "execute_config_commands",
            "get_running_config",
            "get_device_info",
            "list_devices",
            # Protocol verification
            "verify_ospf",
            "verify_bgp",
            "verify_eigrp",
            "verify_isis",
            "verify_mpls",
            # Topology tools
            "get_topology",
            "get_device_interfaces",
            "get_neighbors",
            "find_path",
            "get_ospf_topology",
            "get_subnets",
            # Device management
            "add_device",
        }
        actual = {t["name"] for t in TOOLS}
        assert actual == expected

    @pytest.mark.asyncio
    async def test_execute_registered_tool(self):
        registry = ToolRegistry()

        async def my_handler(tool_input, context):
            return {"status": "success", "value": tool_input.get("x", 0) * 2}

        registry.register("double", my_handler)
        result = await registry.execute("double", {"x": 5}, {})
        assert result["status"] == "success"
        assert result["value"] == 10

    @pytest.mark.asyncio
    async def test_execute_unknown_tool(self):
        registry = ToolRegistry()
        result = await registry.execute("nonexistent", {}, {})
        assert "error" in result
        assert "Unknown tool" in result["error"]

    @pytest.mark.asyncio
    async def test_execute_handler_exception(self):
        registry = ToolRegistry()

        async def failing_handler(tool_input, context):
            raise RuntimeError("Something went wrong")

        registry.register("bad_tool", failing_handler)
        result = await registry.execute("bad_tool", {}, {})
        assert "error" in result
        assert "Something went wrong" in result["error"]

    @pytest.mark.asyncio
    async def test_context_passed_to_handler(self):
        registry = ToolRegistry()
        received_context = {}

        async def context_checker(tool_input, context):
            received_context.update(context)
            return {"status": "success"}

        registry.register("check_ctx", context_checker)
        await registry.execute("check_ctx", {}, {"key": "value"})
        assert received_context.get("key") == "value"
