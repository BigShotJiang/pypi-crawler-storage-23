"""Tests for the ClaudeAgent agentic loop.

Mocks the Anthropic API client and tool registry to test the
orchestration logic without requiring real API calls or devices.
"""

import tempfile
from dataclasses import dataclass
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from netmind.agent.claude_agent import (
    ClaudeAgent,
    DoneEvent,
    ErrorEvent,
    TextEvent,
    ToolCallEvent,
    ToolResultEvent,
)
from netmind.core.device_manager import DeviceManager
from netmind.core.safety import ApprovalManager, CheckpointManager, SafetyGuard
from netmind.utils.session_logger import reset_session_logger, SessionLogger


# ── Mock Anthropic response objects ─────────────────────────────

@dataclass
class MockUsage:
    input_tokens: int = 100
    output_tokens: int = 50


@dataclass
class MockTextBlock:
    type: str = "text"
    text: str = ""


@dataclass
class MockToolUseBlock:
    type: str = "tool_use"
    id: str = "tool_123"
    name: str = ""
    input: dict = None

    def __post_init__(self):
        if self.input is None:
            self.input = {}


@dataclass
class MockResponse:
    content: list = None
    usage: MockUsage = None

    def __post_init__(self):
        if self.content is None:
            self.content = []
        if self.usage is None:
            self.usage = MockUsage()


# ── Fixtures ────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _isolate_session_logger(tmp_path):
    """Ensure each test gets a fresh session logger."""
    reset_session_logger()
    with patch("netmind.utils.session_logger._instance", SessionLogger(log_dir=str(tmp_path))):
        yield
    reset_session_logger()


@pytest.fixture
def mock_config():
    """Mock the NetMind config."""
    config = MagicMock()
    config.anthropic_api_key = "sk-ant-test-key"
    config.claude_model = "claude-sonnet-4-20250514"
    config.max_conversation_history = 50
    return config


@pytest.fixture
def mock_client():
    """Mock the Anthropic async client."""
    client = AsyncMock()
    return client


@pytest.fixture
def agent(mock_config, mock_client):
    """Create a ClaudeAgent with mocked dependencies."""
    with patch("netmind.agent.claude_agent.get_config", return_value=mock_config):
        with patch("netmind.agent.claude_agent.anthropic.AsyncAnthropic", return_value=mock_client):
            agent = ClaudeAgent(
                device_manager=DeviceManager(),
                safety_guard=SafetyGuard(read_only=True),
                approval_manager=ApprovalManager(),
                checkpoint_manager=CheckpointManager(),
            )
            agent._client = mock_client
            return agent


# ── Helper ──────────────────────────────────────────────────────

async def collect_events(agent, message: str) -> list:
    """Collect all events from processing a message."""
    events = []
    async for event in agent.process_message(message):
        events.append(event)
    return events


# ── Tests ───────────────────────────────────────────────────────


class TestAgentTextOnlyResponse:
    """Test the agent when Claude responds with text only (no tools)."""

    @pytest.mark.asyncio
    async def test_simple_text_response(self, agent, mock_client):
        mock_client.messages.create.return_value = MockResponse(
            content=[MockTextBlock(text="Hello! I'm your network assistant.")],
        )

        events = await collect_events(agent, "hello")

        text_events = [e for e in events if isinstance(e, TextEvent)]
        done_events = [e for e in events if isinstance(e, DoneEvent)]

        assert len(text_events) == 1
        assert text_events[0].text == "Hello! I'm your network assistant."
        assert len(done_events) == 1

    @pytest.mark.asyncio
    async def test_multi_block_text(self, agent, mock_client):
        mock_client.messages.create.return_value = MockResponse(
            content=[
                MockTextBlock(text="First paragraph."),
                MockTextBlock(text="Second paragraph."),
            ],
        )

        events = await collect_events(agent, "explain OSPF")

        text_events = [e for e in events if isinstance(e, TextEvent)]
        assert len(text_events) == 2
        assert text_events[0].text == "First paragraph."
        assert text_events[1].text == "Second paragraph."


class TestAgentToolCalls:
    """Test the agent when Claude calls tools."""

    @pytest.mark.asyncio
    async def test_single_tool_call(self, agent, mock_client):
        # First call: Claude invokes list_devices
        tool_response = MockResponse(
            content=[
                MockTextBlock(text="Let me check the devices."),
                MockToolUseBlock(
                    id="tool_1",
                    name="list_devices",
                    input={},
                ),
            ],
        )

        # Second call: Claude gives final text
        final_response = MockResponse(
            content=[MockTextBlock(text="You have 0 devices connected.")],
        )

        mock_client.messages.create.side_effect = [tool_response, final_response]

        events = await collect_events(agent, "what devices do I have?")

        # Verify event sequence
        event_types = [type(e).__name__ for e in events]
        assert "TextEvent" in event_types
        assert "ToolCallEvent" in event_types
        assert "ToolResultEvent" in event_types
        assert "DoneEvent" in event_types

        # Verify tool call event
        tool_calls = [e for e in events if isinstance(e, ToolCallEvent)]
        assert len(tool_calls) == 1
        assert tool_calls[0].tool_name == "list_devices"

    @pytest.mark.asyncio
    async def test_multiple_tool_calls(self, agent, mock_client):
        # First call: Claude invokes two tools
        tool_response = MockResponse(
            content=[
                MockToolUseBlock(
                    id="tool_1",
                    name="list_devices",
                    input={},
                ),
                MockToolUseBlock(
                    id="tool_2",
                    name="get_device_info",
                    input={"device_id": "R1"},
                ),
            ],
        )

        # Second call: final text
        final_response = MockResponse(
            content=[MockTextBlock(text="Here's what I found.")],
        )

        mock_client.messages.create.side_effect = [tool_response, final_response]

        events = await collect_events(agent, "tell me about my devices")

        tool_calls = [e for e in events if isinstance(e, ToolCallEvent)]
        tool_results = [e for e in events if isinstance(e, ToolResultEvent)]

        assert len(tool_calls) == 2
        assert len(tool_results) == 2


class TestAgentErrorHandling:
    """Test error handling in the agent loop."""

    @pytest.mark.asyncio
    async def test_api_connection_error(self, agent, mock_client):
        import anthropic
        mock_client.messages.create.side_effect = anthropic.APIConnectionError(
            request=MagicMock(),
        )

        events = await collect_events(agent, "hello")

        error_events = [e for e in events if isinstance(e, ErrorEvent)]
        assert len(error_events) == 1
        assert "Cannot connect" in error_events[0].error

    @pytest.mark.asyncio
    async def test_auth_error(self, agent, mock_client):
        import anthropic
        mock_client.messages.create.side_effect = anthropic.AuthenticationError(
            message="Invalid API key",
            response=MagicMock(status_code=401),
            body={"error": {"message": "Invalid API key"}},
        )

        events = await collect_events(agent, "hello")

        error_events = [e for e in events if isinstance(e, ErrorEvent)]
        assert len(error_events) == 1
        assert "API key" in error_events[0].error

    @pytest.mark.asyncio
    async def test_rate_limit_error(self, agent, mock_client):
        import anthropic
        mock_client.messages.create.side_effect = anthropic.RateLimitError(
            message="Rate limited",
            response=MagicMock(status_code=429),
            body={"error": {"message": "Rate limited"}},
        )

        events = await collect_events(agent, "hello")

        error_events = [e for e in events if isinstance(e, ErrorEvent)]
        assert len(error_events) == 1
        assert "Rate limited" in error_events[0].error

    @pytest.mark.asyncio
    async def test_unexpected_error(self, agent, mock_client):
        mock_client.messages.create.side_effect = RuntimeError("Something broke")

        events = await collect_events(agent, "hello")

        error_events = [e for e in events if isinstance(e, ErrorEvent)]
        assert len(error_events) == 1
        assert "Unexpected error" in error_events[0].error

    @pytest.mark.asyncio
    async def test_max_iterations_limit(self, agent, mock_client):
        """Agent should stop after max iterations to prevent infinite loops."""
        # Always return tool calls to force infinite loop
        infinite_tool = MockResponse(
            content=[
                MockToolUseBlock(id="tool_n", name="list_devices", input={}),
            ],
        )
        mock_client.messages.create.return_value = infinite_tool

        events = await collect_events(agent, "loop forever")

        error_events = [e for e in events if isinstance(e, ErrorEvent)]
        assert len(error_events) >= 1
        assert "Maximum" in error_events[0].error


class TestAgentConversation:
    """Test conversation management."""

    @pytest.mark.asyncio
    async def test_conversation_cleared(self, agent, mock_client):
        mock_client.messages.create.return_value = MockResponse(
            content=[MockTextBlock(text="Hello.")],
        )

        await collect_events(agent, "first message")
        assert len(agent.conversation.get_messages()) > 0

        agent.clear_conversation()
        assert len(agent.conversation.get_messages()) == 0

    @pytest.mark.asyncio
    async def test_messages_accumulated(self, agent, mock_client):
        mock_client.messages.create.return_value = MockResponse(
            content=[MockTextBlock(text="Response.")],
        )

        await collect_events(agent, "message 1")
        count_after_first = len(agent.conversation.get_messages())

        await collect_events(agent, "message 2")
        count_after_second = len(agent.conversation.get_messages())

        assert count_after_second > count_after_first


class TestAgentModeToggle:
    """Test read-only mode toggle."""

    def test_read_only_default(self, agent):
        assert agent.read_only is True

    def test_toggle_mode(self, agent):
        agent.read_only = False
        assert agent.read_only is False
        assert agent.safety_guard.read_only is False

        agent.read_only = True
        assert agent.read_only is True


class TestAgentRepr:
    """Test event repr methods."""

    def test_text_event_repr(self):
        e = TextEvent("hello")
        assert "hello" in repr(e)

    def test_tool_call_event_repr(self):
        e = ToolCallEvent("list_devices", {})
        assert "list_devices" in repr(e)

    def test_tool_result_event_repr(self):
        e = ToolResultEvent("list_devices", {"status": "success"})
        assert "list_devices" in repr(e)

    def test_error_event_repr(self):
        e = ErrorEvent("something failed")
        assert "something failed" in repr(e)

    def test_done_event_repr(self):
        e = DoneEvent()
        assert "DoneEvent" in repr(e)
