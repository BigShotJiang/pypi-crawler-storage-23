"""Redact sensitive values for logging and API payloads."""

from typing import Any

SENSITIVE_KEYS = frozenset(("password", "secret", "enable_secret", "api_key"))


def redact_sensitive(obj: Any) -> Any:
    """Return a copy of obj with sensitive keys replaced by '***'.

    Use before logging or sending tool_use input to the API.
    """
    if isinstance(obj, dict):
        return {
            k: "***" if k in SENSITIVE_KEYS else redact_sensitive(v)
            for k, v in obj.items()
        }
    if isinstance(obj, (list, tuple)):
        return [redact_sensitive(item) for item in obj]
    return obj
