"""License key validation against Supabase.

Validates license keys via a Supabase RPC function, caches results
locally to avoid hitting the API on every launch.
"""

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import httpx

from netmind.utils.config import SUNSET_CONFIG_DIR, get_config

# ── Supabase credentials (public anon key — RLS protects data) ──
SUPABASE_URL = "https://qpzpnfyxnurjmzpqypvp.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwenBuZnl4bnVyam16cHF5cHZwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE1Njg3NzAsImV4cCI6MjA4NzE0NDc3MH0.a25X2j_poeiCnlr_bNY6JtNxHg4jRzF7BnIIFrrPBe8"

# ── Cache settings ──
CACHE_FILE = SUNSET_CONFIG_DIR / ".license_cache"
CACHE_TTL = 86400  # 24 hours


@dataclass
class LicenseResult:
    valid: bool
    error: str = ""
    email: str = ""
    expires_at: str = ""
    cached: bool = False


def validate_license(key: str) -> LicenseResult:
    """Validate a license key against Supabase RPC."""
    try:
        resp = httpx.post(
            f"{SUPABASE_URL}/rest/v1/rpc/validate_license_key",
            headers={
                "apikey": SUPABASE_ANON_KEY,
                "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
                "Content-Type": "application/json",
            },
            json={"license_key": key},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()

        result = LicenseResult(
            valid=data.get("valid", False),
            error=data.get("error", ""),
            email=data.get("email", ""),
            expires_at=data.get("expires_at") or "",
        )

        if result.valid:
            _write_cache(key, result)

        return result

    except httpx.HTTPStatusError as exc:
        return LicenseResult(valid=False, error=f"HTTP {exc.response.status_code}")
    except (httpx.RequestError, Exception) as exc:
        return LicenseResult(valid=False, error=f"network_error: {exc}")


def check_license() -> LicenseResult:
    """Check current license: cache first, then validate remotely.

    Returns a LicenseResult. On network failure, accepts a non-expired cache.
    """
    config = get_config()
    key = config.sunset_license_key

    if not key:
        return LicenseResult(valid=False, error="no_key")

    # Try cache first
    cached = _read_cache(key)
    if cached is not None:
        return cached

    # Cache miss or stale — validate remotely
    result = validate_license(key)

    # On network error, fall back to stale cache
    if not result.valid and "network_error" in result.error:
        stale = _read_cache(key, ignore_ttl=True)
        if stale is not None:
            stale.cached = True
            return stale

    return result


def clear_cache() -> None:
    """Delete the license cache file."""
    try:
        CACHE_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _write_cache(key: str, result: LicenseResult) -> None:
    """Write validation result to cache."""
    try:
        SUNSET_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "key": key,
            "valid": result.valid,
            "email": result.email,
            "expires_at": result.expires_at,
            "cached_at": time.time(),
        }
        CACHE_FILE.write_text(json.dumps(data))
    except OSError:
        pass


def _read_cache(key: str, ignore_ttl: bool = False) -> Optional[LicenseResult]:
    """Read cached validation result. Returns None if missing/stale/wrong key."""
    try:
        if not CACHE_FILE.is_file():
            return None

        data = json.loads(CACHE_FILE.read_text())

        if data.get("key") != key:
            return None

        if not data.get("valid"):
            return None

        age = time.time() - data.get("cached_at", 0)
        if not ignore_ttl and age > CACHE_TTL:
            return None

        return LicenseResult(
            valid=True,
            email=data.get("email", ""),
            expires_at=data.get("expires_at", ""),
            cached=True,
        )
    except (OSError, json.JSONDecodeError, KeyError):
        return None
