"""Debug session report generator.

Analyzes a debug session JSONL log and produces a structured report
suitable for sharing with an LLM for anomaly detection.

Usage:
    sunset logs --report          # Report on latest session
    sunset logs --report --full   # Include full command outputs
"""

import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ANSI color codes
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
MAGENTA = "\033[35m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"


def generate_report(
    log_path: Path,
    full: bool = False,
    output_path: Optional[Path] = None,
) -> str:
    """Generate a structured analysis report from a session log.

    Args:
        log_path: Path to the .jsonl session log.
        full: If True, include full command outputs in the report.
        output_path: If set, also write the report to this file.

    Returns:
        The report as a string.
    """
    entries = _load_entries(log_path)
    if not entries:
        return "No log entries found."

    sections: List[str] = []
    sections.append(_header(log_path, entries))
    sections.append(_session_overview(entries))
    sections.append(_inventory_section(entries))
    sections.append(_topology_section(entries))
    sections.append(_device_connections(entries))
    sections.append(_ssh_options_section(entries))
    sections.append(_command_analysis(entries, full=full))
    sections.append(_discovery_section(entries))
    sections.append(_tool_call_analysis(entries))
    sections.append(_api_call_analysis(entries))
    sections.append(_error_section(entries))
    sections.append(_safety_section(entries))
    sections.append(_timeline(entries))
    sections.append(_anomalies(entries))

    report = "\n".join(s for s in sections if s)

    if output_path:
        output_path.write_text(report)
        print(f"\n{GREEN}Report saved to: {output_path}{RESET}")

    return report


def _load_entries(path: Path) -> List[Dict[str, Any]]:
    """Load all JSON-lines entries from a log file."""
    entries = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return entries


def _by_type(entries: List[Dict], event_type: str) -> List[Dict]:
    """Filter entries by type."""
    return [e for e in entries if e.get("type") == event_type]


# ── Report Sections ────────────────────────────────────────────────


def _header(path: Path, entries: List[Dict]) -> str:
    """Report header with session metadata."""
    start = _by_type(entries, "session_start")
    meta = start[0].get("data", {}) if start else {}
    sys_info = meta.get("system", {})

    lines = [
        "=" * 72,
        "  SUNSET DEBUG SESSION REPORT",
        "=" * 72,
        "",
        f"  Session:    {meta.get('session_id', 'unknown')}",
        f"  Log file:   {path.name}",
        f"  Verbose:    {meta.get('verbose', False)}",
        f"  PID:        {meta.get('pid', '?')}",
        f"  Python:     {sys_info.get('python', '?').split()[0]}",
        f"  Platform:   {sys_info.get('platform', '?')}",
        f"  Events:     {len(entries)}",
    ]

    end = _by_type(entries, "session_end")
    if end:
        dur = end[0].get("data", {}).get("duration_seconds", 0)
        lines.append(f"  Duration:   {dur:.1f}s")

    lines.append("")
    return "\n".join(lines)


def _session_overview(entries: List[Dict]) -> str:
    """High-level event type breakdown."""
    counts: Dict[str, int] = defaultdict(int)
    for e in entries:
        counts[e.get("type", "unknown")] += 1

    lines = [
        "-" * 72,
        "  EVENT BREAKDOWN",
        "-" * 72,
    ]
    for etype, count in sorted(counts.items(), key=lambda x: -x[1]):
        lines.append(f"    {etype:<30s} {count:>5d}")
    lines.append("")
    return "\n".join(lines)


def _inventory_section(entries: List[Dict]) -> str:
    """Inventory loading details."""
    loads = _by_type(entries, "inventory_load")
    if not loads:
        return ""

    lines = [
        "-" * 72,
        "  INVENTORY",
        "-" * 72,
    ]
    for e in loads:
        d = e.get("data", {})
        lines.append(f"    Path:          {d.get('path', '?')}")
        lines.append(f"    Devices:       {d.get('device_count', 0)}")
        lines.append(f"    Connected:     {d.get('success_count', 0)}")
        lines.append(f"    Errors:        {d.get('error_count', 0)}")
        for err in d.get("errors", []):
            lines.append(f"      ERROR: {err}")
    lines.append("")
    return "\n".join(lines)


def _topology_section(entries: List[Dict]) -> str:
    """Topology build details."""
    builds = _by_type(entries, "topology_build")
    if not builds:
        return ""

    lines = [
        "-" * 72,
        "  TOPOLOGY",
        "-" * 72,
    ]
    for e in builds:
        d = e.get("data", {})
        lines.append(
            f"    Source: {d.get('source', '?')}  "
            f"Nodes: {d.get('node_count', 0)}  "
            f"Links: {d.get('link_count', 0)}"
        )
    lines.append("")
    return "\n".join(lines)


def _device_connections(entries: List[Dict]) -> str:
    """Device connection attempt details."""
    conns = _by_type(entries, "device_connect")
    if not conns:
        return ""

    lines = [
        "-" * 72,
        "  DEVICE CONNECTIONS",
        "-" * 72,
    ]
    for e in conns:
        d = e.get("data", {})
        status = "OK" if d.get("success") else f"FAIL: {d.get('error', '?')}"
        lines.append(
            f"    {d.get('device_id', '?'):12s} "
            f"{d.get('host', '?'):16s} "
            f"{d.get('elapsed_ms', 0):>8.0f}ms  "
            f"{status}"
        )
    lines.append("")
    return "\n".join(lines)


def _ssh_options_section(entries: List[Dict]) -> str:
    """SSH options used per device."""
    opts = _by_type(entries, "ssh_options")
    if not opts:
        return ""

    lines = [
        "-" * 72,
        "  SSH OPTIONS",
        "-" * 72,
    ]
    for e in opts:
        d = e.get("data", {})
        lines.append(f"    {d.get('device_id', '?')}: {json.dumps(d.get('options', {}))}")
    lines.append("")
    return "\n".join(lines)


def _command_analysis(entries: List[Dict], full: bool = False) -> str:
    """Device command execution analysis with timing stats."""
    cmds = _by_type(entries, "device_command")
    if not cmds:
        return ""

    lines = [
        "-" * 72,
        "  DEVICE COMMANDS",
        "-" * 72,
    ]

    # Per-device stats
    by_device: Dict[str, List[Dict]] = defaultdict(list)
    for e in cmds:
        d = e.get("data", {})
        by_device[d.get("device_id", "?")].append(d)

    for dev_id, dev_cmds in by_device.items():
        timings = [c["elapsed_ms"] for c in dev_cmds if c.get("elapsed_ms")]
        ok_count = sum(1 for c in dev_cmds if c.get("success"))
        fail_count = len(dev_cmds) - ok_count
        retries = sum(1 for c in dev_cmds if c.get("attempt", 1) > 1)

        lines.append(f"\n    [{dev_id}] {len(dev_cmds)} commands, {ok_count} OK, {fail_count} FAIL, {retries} retries")
        if timings:
            lines.append(
                f"      Timing: avg={statistics.mean(timings):.0f}ms  "
                f"min={min(timings):.0f}ms  max={max(timings):.0f}ms  "
                f"p95={_percentile(timings, 0.95):.0f}ms"
            )

        # List each command
        for c in dev_cmds:
            status = "OK" if c.get("success") else "FAIL"
            retry_str = f" (attempt {c.get('attempt')})" if c.get("attempt", 1) > 1 else ""
            cmd_str = c.get("command", "?")
            lines.append(
                f"      {c.get('elapsed_ms', 0):>7.0f}ms  "
                f"[{status}]{retry_str}  {cmd_str}"
            )

            # Show errors or full output
            if c.get("error"):
                lines.append(f"        ERROR: {c['error']}")
            if full and c.get("output"):
                output = c["output"]
                for oline in output.split("\n"):
                    lines.append(f"        | {oline}")

    # Failed commands summary
    failed = [e.get("data", {}) for e in cmds if not e.get("data", {}).get("success")]
    if failed:
        lines.append(f"\n    FAILED COMMANDS ({len(failed)} total):")
        for c in failed:
            lines.append(f"      {c.get('device_id', '?')}: {c.get('command', '?')}")
            if c.get("error"):
                lines.append(f"        -> {c['error']}")

    lines.append("")
    return "\n".join(lines)


def _discovery_section(entries: List[Dict]) -> str:
    """Discovery process details."""
    starts = _by_type(entries, "discovery_start")
    devices = _by_type(entries, "discovery_device")
    completions = _by_type(entries, "discovery_complete")

    if not starts and not devices and not completions:
        return ""

    lines = [
        "-" * 72,
        "  AUTO-DISCOVERY",
        "-" * 72,
    ]

    for s in starts:
        d = s.get("data", {})
        lines.append(f"    Started discovery on {d.get('device_count', 0)} device(s)")

    for e in devices:
        d = e.get("data", {})
        lines.append(
            f"    {d.get('device_id', '?'):12s}  "
            f"ifaces={d.get('interface_count', 0):>3d}  "
            f"ospf={'yes' if d.get('ospf_found') else 'no '}  "
            f"cdp={d.get('cdp_neighbor_count', 0)}  "
            f"lldp={d.get('lldp_neighbor_count', 0)}  "
            f"errors={d.get('error_count', 0)}"
        )
        for err in d.get("errors", []):
            lines.append(f"      ERROR: {err}")

    for c in completions:
        d = c.get("data", {})
        lines.append(
            f"    Completed: {d.get('device_count', 0)} devices, "
            f"{d.get('node_count', 0)} nodes, "
            f"{d.get('link_count', 0)} links, "
            f"{d.get('total_interfaces', 0)} interfaces  "
            f"({d.get('elapsed_ms', 0):.0f}ms)"
        )

    lines.append("")
    return "\n".join(lines)


def _tool_call_analysis(entries: List[Dict]) -> str:
    """Claude tool call patterns and timing."""
    calls = _by_type(entries, "tool_call")
    results = _by_type(entries, "tool_result")

    if not calls:
        return ""

    lines = [
        "-" * 72,
        "  CLAUDE TOOL CALLS",
        "-" * 72,
    ]

    # Aggregate by tool name
    call_counts: Dict[str, int] = defaultdict(int)
    for c in calls:
        tool = c.get("data", {}).get("tool", "?")
        call_counts[tool] += 1

    # Timing from results
    result_timings: Dict[str, List[float]] = defaultdict(list)
    result_errors: Dict[str, int] = defaultdict(int)
    for r in results:
        d = r.get("data", {})
        tool = d.get("tool", "?")
        elapsed = d.get("elapsed_ms", 0)
        if elapsed:
            result_timings[tool].append(elapsed)
        if d.get("error") or d.get("status") == "error":
            result_errors[tool] += 1

    for tool, count in sorted(call_counts.items(), key=lambda x: -x[1]):
        timings = result_timings.get(tool, [])
        errors = result_errors.get(tool, 0)
        timing_str = ""
        if timings:
            timing_str = (
                f"  avg={statistics.mean(timings):.0f}ms "
                f"max={max(timings):.0f}ms"
            )
        error_str = f"  ERRORS={errors}" if errors else ""
        lines.append(f"    {tool:<30s}  x{count:>3d}{timing_str}{error_str}")

    lines.append("")
    return "\n".join(lines)


def _api_call_analysis(entries: List[Dict]) -> str:
    """Claude API call analysis — latency, token usage, cost estimation."""
    api_calls = _by_type(entries, "api_call")
    if not api_calls:
        return ""

    lines = [
        "-" * 72,
        "  CLAUDE API CALLS",
        "-" * 72,
    ]

    total_in = 0
    total_out = 0
    latencies = []
    errors = 0

    for e in api_calls:
        d = e.get("data", {})
        latencies.append(d.get("elapsed_ms", 0))
        total_in += d.get("input_tokens", 0)
        total_out += d.get("output_tokens", 0)
        if d.get("error"):
            errors += 1

    lines.append(f"    Calls:          {len(api_calls)}")
    lines.append(f"    Errors:         {errors}")
    lines.append(f"    Input tokens:   {total_in:,}")
    lines.append(f"    Output tokens:  {total_out:,}")
    lines.append(f"    Total tokens:   {total_in + total_out:,}")

    if latencies:
        lines.append(
            f"    Latency:        avg={statistics.mean(latencies):.0f}ms  "
            f"min={min(latencies):.0f}ms  max={max(latencies):.0f}ms  "
            f"p95={_percentile(latencies, 0.95):.0f}ms"
        )

    # Per-call breakdown
    lines.append("")
    for i, e in enumerate(api_calls, 1):
        d = e.get("data", {})
        err = f"  ERROR: {d['error']}" if d.get("error") else ""
        lines.append(
            f"    #{i:>2d}  {d.get('model', '?'):30s}  "
            f"in={d.get('input_tokens', 0):>6,}  "
            f"out={d.get('output_tokens', 0):>6,}  "
            f"{d.get('elapsed_ms', 0):>8.0f}ms"
            f"{err}"
        )

    lines.append("")
    return "\n".join(lines)


def _error_section(entries: List[Dict]) -> str:
    """All errors, categorized."""
    errors = _by_type(entries, "error")
    if not errors:
        return ""

    lines = [
        "-" * 72,
        f"  ERRORS ({len(errors)} total)",
        "-" * 72,
    ]

    by_cat: Dict[str, List[Dict]] = defaultdict(list)
    for e in errors:
        d = e.get("data", {})
        cat = d.get("category", "unknown")
        by_cat[cat].append(d)

    for cat, errs in sorted(by_cat.items()):
        lines.append(f"\n    [{cat.upper()}] ({len(errs)})")
        for err in errs:
            lines.append(f"      {err.get('message', '?')}")
            details = err.get("details", {})
            if details:
                for k, v in details.items():
                    lines.append(f"        {k}: {v}")

    lines.append("")
    return "\n".join(lines)


def _safety_section(entries: List[Dict]) -> str:
    """Safety check and approval events."""
    checks = _by_type(entries, "safety_check")
    approvals = _by_type(entries, "approval")

    if not checks and not approvals:
        return ""

    lines = [
        "-" * 72,
        "  SAFETY & APPROVALS",
        "-" * 72,
    ]

    if checks:
        passed = sum(1 for e in checks if e.get("data", {}).get("allowed"))
        blocked = len(checks) - passed
        lines.append(f"    Safety checks: {len(checks)} total, {passed} passed, {blocked} blocked")
        for e in checks:
            d = e.get("data", {})
            if not d.get("allowed"):
                lines.append(f"      BLOCKED: {d.get('check_type', '?')} — {d.get('reason', '?')}")

    if approvals:
        lines.append(f"    Approvals: {len(approvals)}")
        for e in approvals:
            d = e.get("data", {})
            lines.append(
                f"      {d.get('action', '?').upper()} on {d.get('device_id', '?')}: "
                f"{d.get('description', '?')}"
            )

    lines.append("")
    return "\n".join(lines)


def _timeline(entries: List[Dict]) -> str:
    """Chronological timeline of major events."""
    major_types = {
        "session_start", "session_end",
        "user_message", "agent_done",
        "device_connect", "device_config",
        "error", "discovery_start", "discovery_complete",
        "inventory_load", "topology_build",
    }

    events = [e for e in entries if e.get("type") in major_types]
    if not events:
        return ""

    lines = [
        "-" * 72,
        "  TIMELINE (major events)",
        "-" * 72,
    ]

    for e in events:
        ts = e.get("ts", "")
        ts_short = ts[11:19] if len(ts) > 19 else ts
        t_ms = e.get("t_ms", 0)
        etype = e.get("type", "?")
        data = e.get("data", {})

        if etype == "user_message":
            msg = data.get("message", "")[:80]
            detail = f"USER: {msg}"
        elif etype == "agent_done":
            detail = f"AGENT DONE ({data.get('response_length', 0)} chars)"
        elif etype == "device_connect":
            ok = "OK" if data.get("success") else "FAIL"
            detail = f"SSH {data.get('device_id', '?')}@{data.get('host', '?')} [{ok}]"
        elif etype == "device_config":
            ok = "OK" if data.get("success") else "FAIL"
            detail = f"CONFIG {data.get('device_id', '?')} ({len(data.get('commands', []))} cmds) [{ok}]"
        elif etype == "error":
            detail = f"ERROR [{data.get('category', '?')}]: {data.get('message', '?')[:60]}"
        elif etype == "inventory_load":
            detail = f"INVENTORY {data.get('success_count', 0)}/{data.get('device_count', 0)} devices"
        elif etype == "topology_build":
            detail = f"TOPOLOGY {data.get('node_count', 0)} nodes, {data.get('link_count', 0)} links"
        elif etype == "discovery_start":
            detail = f"DISCOVERY START ({data.get('device_count', 0)} devices)"
        elif etype == "discovery_complete":
            detail = f"DISCOVERY DONE ({data.get('elapsed_ms', 0):.0f}ms)"
        elif etype == "session_start":
            detail = "SESSION START"
        elif etype == "session_end":
            detail = f"SESSION END ({data.get('duration_seconds', 0):.0f}s)"
        else:
            detail = etype

        lines.append(f"    {ts_short}  +{t_ms:>9.0f}ms  {detail}")

    lines.append("")
    return "\n".join(lines)


def _anomalies(entries: List[Dict]) -> str:
    """Detect potential anomalies in the session."""
    anomalies: List[str] = []

    # Check for command failures
    cmds = _by_type(entries, "device_command")
    failed_cmds = [c for c in cmds if not c.get("data", {}).get("success")]
    if failed_cmds:
        anomalies.append(
            f"[CMD-FAIL] {len(failed_cmds)} device command(s) failed"
        )
        for c in failed_cmds:
            d = c.get("data", {})
            anomalies.append(
                f"  -> {d.get('device_id', '?')}: {d.get('command', '?')} — {d.get('error', '?')}"
            )

    # Check for retried commands
    retries = [c for c in cmds if c.get("data", {}).get("attempt", 1) > 1]
    if retries:
        anomalies.append(f"[RETRY] {len(retries)} command(s) required retries")

    # Check for very slow commands (> 10s)
    slow = [c for c in cmds if c.get("data", {}).get("elapsed_ms", 0) > 10000]
    if slow:
        anomalies.append(f"[SLOW-CMD] {len(slow)} command(s) took >10s")
        for c in slow:
            d = c.get("data", {})
            anomalies.append(
                f"  -> {d.get('device_id', '?')}: {d.get('command', '?')} "
                f"({d.get('elapsed_ms', 0):.0f}ms)"
            )

    # Check for very slow API calls (> 30s)
    api_calls = _by_type(entries, "api_call")
    slow_api = [a for a in api_calls if a.get("data", {}).get("elapsed_ms", 0) > 30000]
    if slow_api:
        anomalies.append(f"[SLOW-API] {len(slow_api)} API call(s) took >30s")

    # Check for API errors
    api_errors = [a for a in api_calls if a.get("data", {}).get("error")]
    if api_errors:
        anomalies.append(f"[API-ERROR] {len(api_errors)} Claude API error(s)")
        for a in api_errors:
            d = a.get("data", {})
            anomalies.append(f"  -> {d.get('error', '?')}")

    # Check for connection failures
    conns = _by_type(entries, "device_connect")
    failed_conns = [c for c in conns if not c.get("data", {}).get("success")]
    if failed_conns:
        anomalies.append(f"[SSH-FAIL] {len(failed_conns)} SSH connection(s) failed")
        for c in failed_conns:
            d = c.get("data", {})
            anomalies.append(f"  -> {d.get('device_id', '?')}@{d.get('host', '?')}: {d.get('error', '?')}")

    # Check for tool errors
    results = _by_type(entries, "tool_result")
    tool_errors = [
        r for r in results
        if r.get("data", {}).get("error") or r.get("data", {}).get("status") == "error"
    ]
    if tool_errors:
        anomalies.append(f"[TOOL-ERROR] {len(tool_errors)} tool execution(s) failed")
        for r in tool_errors:
            d = r.get("data", {})
            anomalies.append(f"  -> {d.get('tool', '?')}: {d.get('error', '?')}")

    # Check for discovery errors
    disc_devices = _by_type(entries, "discovery_device")
    disc_errs = [d for d in disc_devices if d.get("data", {}).get("error_count", 0) > 0]
    if disc_errs:
        anomalies.append(f"[DISC-ERROR] Discovery errors on {len(disc_errs)} device(s)")

    # No anomalies
    if not anomalies:
        return (
            "-" * 72 + "\n"
            "  ANOMALIES\n"
            + "-" * 72 + "\n"
            "    None detected — clean session!\n"
        )

    lines = [
        "-" * 72,
        f"  ANOMALIES ({len(anomalies)} detected)",
        "-" * 72,
    ]
    for a in anomalies:
        lines.append(f"    {a}")
    lines.append("")
    return "\n".join(lines)


# ── Helpers ────────────────────────────────────────────────────────


def _percentile(data: List[float], q: float) -> float:
    """Calculate a percentile value from a list."""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    idx = int(q * (len(sorted_data) - 1))
    return sorted_data[idx]
