"""Structured session logging for debugging and improvement.

Captures every agent interaction, tool call, device operation, and error
into timestamped JSON-lines session logs. Each run gets its own file:

    logs/sessions/session_2026-02-15_20-34-12.jsonl

In VERBOSE mode (--debug), captures FULL untruncated outputs:

    logs/sessions/session_2026-02-15_20-34-12_debug.jsonl

Each line is a self-contained JSON object with a type, timestamp,
and payload — easy to grep, tail, and analyze.

Usage:
    from netmind.utils.session_logger import SessionLogger

    slog = SessionLogger(verbose=True)
    slog.log_user_message("analyze this router")
    slog.log_tool_call("execute_command", {"device_id": "R1", ...})
    slog.log_tool_result("execute_command", result, elapsed_ms=142.3)
"""

import json
import os
import platform
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from netmind.utils.logger import get_logger

logger = get_logger("utils.session_logger")

# Where session logs live
DEFAULT_LOG_DIR = str(Path.home() / ".sunset" / "logs" / "sessions")


class SessionLogger:
    """Writes structured JSON-lines logs for a single session.

    Each log entry has:
        - ts: ISO-8601 timestamp
        - t_ms: milliseconds since session start
        - type: event category (user_message, agent_text, tool_call, ...)
        - data: payload dict

    In verbose mode, outputs are NOT truncated and ALL data is captured.
    """

    def __init__(
        self,
        log_dir: Optional[str] = None,
        verbose: bool = False,
    ) -> None:
        self._log_dir = Path(log_dir or DEFAULT_LOG_DIR)
        self._log_dir.mkdir(parents=True, exist_ok=True)

        self._verbose = verbose
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self._session_id = ts
        suffix = "_debug" if verbose else ""
        self._log_path = self._log_dir / f"session_{ts}{suffix}.jsonl"
        self._start_time = time.monotonic()
        self._event_count = 0

        # Write session header with system info
        self._write({
            "type": "session_start",
            "data": {
                "session_id": self._session_id,
                "started_at": datetime.now().isoformat(),
                "pid": os.getpid(),
                "verbose": verbose,
                "system": {
                    "python": sys.version,
                    "platform": platform.platform(),
                    "arch": platform.machine(),
                },
            },
        })
        logger.info("Session log: %s (verbose=%s)", self._log_path, verbose)

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def log_path(self) -> Path:
        return self._log_path

    @property
    def verbose(self) -> bool:
        return self._verbose

    # ── User / Agent conversation ──────────────────────────────

    def log_user_message(self, message: str) -> None:
        """Log a user message sent to the agent."""
        self._write({
            "type": "user_message",
            "data": {"message": message},
        })

    def log_agent_text(self, text: str) -> None:
        """Log a text chunk from Claude's response."""
        self._write({
            "type": "agent_text",
            "data": {"text": text},
        })

    def log_agent_done(self, full_response: str) -> None:
        """Log the agent finishing its response."""
        self._write({
            "type": "agent_done",
            "data": {
                "response_length": len(full_response),
                "response": full_response if self._verbose else _truncate(full_response, 500),
            },
        })

    # ── Tool calls ─────────────────────────────────────────────

    def log_tool_call(self, tool_name: str, tool_input: dict) -> None:
        """Log Claude invoking a tool."""
        self._write({
            "type": "tool_call",
            "data": {
                "tool": tool_name,
                "input": _safe_serialize(tool_input),
            },
        })

    def log_tool_result(
        self,
        tool_name: str,
        result: dict,
        elapsed_ms: float = 0.0,
    ) -> None:
        """Log the result of a tool execution."""
        if self._verbose:
            # Full result in debug mode
            data: Dict[str, Any] = {
                "tool": tool_name,
                "elapsed_ms": round(elapsed_ms, 1),
                "result": _safe_serialize(result),
            }
        else:
            data = {
                "tool": tool_name,
                "status": result.get("status", "unknown"),
                "error": result.get("error"),
                "output_preview": _truncate(
                    result.get("output") or result.get("config") or "", 500
                ),
                "elapsed_ms": round(elapsed_ms, 1),
            }
        self._write({"type": "tool_result", "data": data})

    # ── Device operations ──────────────────────────────────────

    def log_device_connect(
        self,
        device_id: str,
        host: str,
        success: bool,
        elapsed_ms: float = 0.0,
        error: Optional[str] = None,
    ) -> None:
        """Log a device connection attempt."""
        self._write({
            "type": "device_connect",
            "data": {
                "device_id": device_id,
                "host": host,
                "success": success,
                "elapsed_ms": round(elapsed_ms, 1),
                "error": error,
            },
        })

    def log_device_command(
        self,
        device_id: str,
        command: str,
        success: bool,
        elapsed_ms: float = 0.0,
        output_preview: str = "",
        error: Optional[str] = None,
        attempt: int = 1,
    ) -> None:
        """Log a command execution on a device."""
        if self._verbose:
            # Full output in debug mode
            output_data = output_preview  # caller already passes full output
        else:
            output_data = _truncate(output_preview, 300)

        self._write({
            "type": "device_command",
            "data": {
                "device_id": device_id,
                "command": command,
                "success": success,
                "attempt": attempt,
                "elapsed_ms": round(elapsed_ms, 1),
                "output": output_data,
                "error": error,
            },
        })

    def log_device_config(
        self,
        device_id: str,
        commands: list,
        success: bool,
        elapsed_ms: float = 0.0,
        error: Optional[str] = None,
    ) -> None:
        """Log a configuration change on a device."""
        self._write({
            "type": "device_config",
            "data": {
                "device_id": device_id,
                "commands": commands,
                "success": success,
                "elapsed_ms": round(elapsed_ms, 1),
                "error": error,
            },
        })

    # ── Safety / approval ──────────────────────────────────────

    def log_safety_check(
        self,
        check_type: str,
        allowed: bool,
        reason: str = "",
        command: Optional[str] = None,
        commands: Optional[list] = None,
    ) -> None:
        """Log a safety guard check."""
        self._write({
            "type": "safety_check",
            "data": {
                "check_type": check_type,
                "allowed": allowed,
                "reason": reason,
                "command": command,
                "commands": commands,
            },
        })

    def log_approval(
        self,
        request_id: str,
        device_id: str,
        action: str,
        commands: list,
        description: str,
    ) -> None:
        """Log an approval flow event (requested/approved/rejected)."""
        self._write({
            "type": "approval",
            "data": {
                "request_id": request_id,
                "device_id": device_id,
                "action": action,
                "commands": commands,
                "description": description,
            },
        })

    # ── Agent loop ─────────────────────────────────────────────

    def log_agent_iteration(
        self,
        iteration: int,
        tool_calls_count: int = 0,
    ) -> None:
        """Log an agent loop iteration."""
        self._write({
            "type": "agent_iteration",
            "data": {
                "iteration": iteration,
                "tool_calls": tool_calls_count,
            },
        })

    def log_api_call(
        self,
        model: str,
        messages_count: int,
        elapsed_ms: float = 0.0,
        input_tokens: int = 0,
        output_tokens: int = 0,
        error: Optional[str] = None,
    ) -> None:
        """Log a Claude API call with token usage."""
        self._write({
            "type": "api_call",
            "data": {
                "model": model,
                "messages_count": messages_count,
                "elapsed_ms": round(elapsed_ms, 1),
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "error": error,
            },
        })

    # ── Errors ─────────────────────────────────────────────────

    def log_error(
        self,
        category: str,
        message: str,
        details: Optional[dict] = None,
    ) -> None:
        """Log an error event."""
        self._write({
            "type": "error",
            "data": {
                "category": category,
                "message": message,
                "details": details or {},
            },
        })

    # ── Checkpoint / rollback ──────────────────────────────────

    def log_checkpoint(
        self,
        device_id: str,
        checkpoint_name: str,
        action: str,
        success: bool,
    ) -> None:
        """Log checkpoint creation or rollback."""
        self._write({
            "type": "checkpoint",
            "data": {
                "device_id": device_id,
                "checkpoint_name": checkpoint_name,
                "action": action,
                "success": success,
            },
        })

    # ── Inventory / Topology / Discovery ───────────────────────

    def log_inventory_load(
        self,
        path: str,
        device_count: int,
        success_count: int,
        errors: List[str],
    ) -> None:
        """Log inventory loading results."""
        self._write({
            "type": "inventory_load",
            "data": {
                "path": path,
                "device_count": device_count,
                "success_count": success_count,
                "error_count": len(errors),
                "errors": errors,
            },
        })

    def log_topology_build(
        self,
        node_count: int,
        link_count: int,
        source: str = "inventory",
    ) -> None:
        """Log topology build results."""
        self._write({
            "type": "topology_build",
            "data": {
                "source": source,
                "node_count": node_count,
                "link_count": link_count,
            },
        })

    def log_discovery_start(self, device_count: int) -> None:
        """Log the start of auto-discovery."""
        self._write({
            "type": "discovery_start",
            "data": {"device_count": device_count},
        })

    def log_discovery_device(
        self,
        device_id: str,
        interface_count: int,
        ospf_found: bool,
        cdp_neighbor_count: int,
        lldp_neighbor_count: int,
        errors: List[str],
        elapsed_ms: float = 0.0,
    ) -> None:
        """Log discovery results for a single device."""
        self._write({
            "type": "discovery_device",
            "data": {
                "device_id": device_id,
                "interface_count": interface_count,
                "ospf_found": ospf_found,
                "cdp_neighbor_count": cdp_neighbor_count,
                "lldp_neighbor_count": lldp_neighbor_count,
                "error_count": len(errors),
                "errors": errors,
                "elapsed_ms": round(elapsed_ms, 1),
            },
        })

    def log_discovery_complete(
        self,
        device_count: int,
        node_count: int,
        link_count: int,
        total_interfaces: int,
        elapsed_ms: float = 0.0,
    ) -> None:
        """Log discovery completion."""
        self._write({
            "type": "discovery_complete",
            "data": {
                "device_count": device_count,
                "node_count": node_count,
                "link_count": link_count,
                "total_interfaces": total_interfaces,
                "elapsed_ms": round(elapsed_ms, 1),
            },
        })

    def log_ssh_options(
        self,
        device_id: str,
        options: Dict[str, Any],
    ) -> None:
        """Log SSH options used for a device connection."""
        self._write({
            "type": "ssh_options",
            "data": {
                "device_id": device_id,
                "options": options,
            },
        })

    # ── Session end ────────────────────────────────────────────

    def log_session_end(self) -> None:
        """Finalize the session log."""
        elapsed = time.monotonic() - self._start_time
        self._write({
            "type": "session_end",
            "data": {
                "session_id": self._session_id,
                "duration_seconds": round(elapsed, 1),
                "event_count": self._event_count,
                "verbose": self._verbose,
            },
        })

    # ── Internal ───────────────────────────────────────────────

    def _write(self, entry: dict) -> None:
        """Write a single JSON-lines entry to the log file."""
        entry["ts"] = datetime.now().isoformat()
        entry["t_ms"] = round((time.monotonic() - self._start_time) * 1000, 1)
        self._event_count += 1
        try:
            with open(self._log_path, "a") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except Exception as e:
            logger.warning("Failed to write session log: %s", e)


# ── Singleton access ───────────────────────────────────────────

_instance: Optional[SessionLogger] = None


def get_session_logger(
    log_dir: Optional[str] = None,
    verbose: Optional[bool] = None,
) -> SessionLogger:
    """Get or create the global session logger singleton."""
    global _instance
    if _instance is None:
        _instance = SessionLogger(
            log_dir=log_dir,
            verbose=verbose or False,
        )
    return _instance


def reset_session_logger() -> None:
    """Reset the singleton (for testing)."""
    global _instance
    _instance = None


# ── Helpers ────────────────────────────────────────────────────

def _safe_serialize(obj: Any) -> Any:
    """Make an object JSON-serializable, masking sensitive fields."""
    from netmind.utils.secrets import redact_sensitive
    return redact_sensitive(obj)


def _truncate(text: str, max_len: int) -> str:
    """Truncate text with an ellipsis marker."""
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"... ({len(text)} chars total)"
