"""Command output parsers for common IOS commands.

These are optional helpers - Claude can also parse outputs directly,
but these provide structured data for verification tools.
"""

import re
from typing import Optional


def parse_show_ip_interface_brief(output: str) -> list[dict]:
    """Parse 'show ip interface brief' output into structured data.

    Handles multi-word status fields like 'administratively down'.

    Returns:
        List of dicts with keys: interface, ip_address, ok, method, status, protocol
    """
    interfaces = []
    lines = output.strip().splitlines()

    for line in lines:
        # Skip header lines
        if line.startswith("Interface") or not line.strip():
            continue

        parts = line.split()
        if len(parts) < 6:
            continue

        # The protocol is always the last word, and everything between
        # method and protocol is the status (which may be multi-word,
        # e.g. "administratively down").
        interface = parts[0]
        ip_address = parts[1]
        ok = parts[2]
        method = parts[3]
        protocol = parts[-1]
        status = " ".join(parts[4:-1])

        interfaces.append({
            "interface": interface,
            "ip_address": ip_address,
            "ok": ok,
            "method": method,
            "status": status,
            "protocol": protocol,
        })

    return interfaces


def parse_show_ip_ospf_neighbor(output: str) -> list[dict]:
    """Parse 'show ip ospf neighbor' output.

    Returns:
        List of dicts with keys: neighbor_id, priority, state, dead_time, address, interface
    """
    neighbors = []
    lines = output.strip().splitlines()

    for line in lines:
        # Skip header and empty lines
        if line.startswith("Neighbor") or not line.strip() or "---" in line:
            continue

        parts = line.split()
        if len(parts) >= 6:
            neighbors.append({
                "neighbor_id": parts[0],
                "priority": parts[1],
                "state": parts[2].rstrip("/"),
                "dead_time": parts[3],
                "address": parts[4],
                "interface": parts[5],
            })

    return neighbors


def parse_show_ip_route_ospf(output: str) -> list[dict]:
    """Parse 'show ip route ospf' output for OSPF-learned routes.

    Returns:
        List of dicts with keys: code, network, mask, via, interface, metric
    """
    routes = []
    # Match lines like: O    10.0.0.0/24 [110/2] via 192.168.1.2, 00:01:00, GigabitEthernet0/1
    pattern = re.compile(
        r"(O\s*(?:IA|E[12])?)\s+"
        r"(\d+\.\d+\.\d+\.\d+(?:/\d+)?)\s+"
        r"\[(\d+/\d+)\]\s+"
        r"via\s+(\d+\.\d+\.\d+\.\d+)"
        r"(?:,\s+[\d:]+,\s+(\S+))?"
    )

    for line in output.strip().splitlines():
        match = pattern.search(line)
        if match:
            metric_parts = match.group(3).split("/")
            routes.append({
                "code": match.group(1).strip(),
                "network": match.group(2),
                "admin_distance": int(metric_parts[0]),
                "metric": int(metric_parts[1]),
                "via": match.group(4),
                "interface": match.group(5) or "",
            })

    return routes


def parse_show_version(output: str) -> dict:
    """Parse 'show version' output for device info.

    Returns:
        Dict with keys: hostname, version, model, serial, uptime, image
    """
    info: dict[str, str] = {}

    # Hostname - from the prompt or 'hostname' line
    hostname_match = re.search(r"(\S+)\s+uptime is", output)
    if hostname_match:
        info["hostname"] = hostname_match.group(1)

    # IOS version
    version_match = re.search(r"(?:Cisco IOS.*?Version|IOS.*?version)\s+([\S]+)", output, re.IGNORECASE)
    if version_match:
        info["version"] = version_match.group(1).rstrip(",")

    # Model/platform
    model_match = re.search(r"[Cc]isco\s+(\S+).*?(?:processor|bytes of memory)", output)
    if model_match:
        info["model"] = model_match.group(1)

    # Serial number
    serial_match = re.search(r"[Pp]rocessor board ID\s+(\S+)", output)
    if serial_match:
        info["serial"] = serial_match.group(1)

    # Uptime
    uptime_match = re.search(r"uptime is\s+(.+)", output)
    if uptime_match:
        info["uptime"] = uptime_match.group(1).strip()

    # Image file
    image_match = re.search(r'System image file is "(.+?)"', output)
    if image_match:
        info["image"] = image_match.group(1)

    return info


def extract_ospf_config(running_config: str) -> Optional[str]:
    """Extract OSPF configuration section from running config."""
    return _extract_router_block(running_config, r"^router ospf\s+\d+")


def extract_bgp_config(running_config: str) -> Optional[str]:
    """Extract BGP configuration section from running config."""
    return _extract_router_block(running_config, r"^router bgp\s+\d+")


def extract_eigrp_config(running_config: str) -> Optional[str]:
    """Extract EIGRP configuration section from running config."""
    return _extract_router_block(running_config, r"^router eigrp\s+\S+")


def extract_isis_config(running_config: str) -> Optional[str]:
    """Extract IS-IS configuration section from running config."""
    return _extract_router_block(running_config, r"^router isis\s*\S*")


def extract_mpls_config(running_config: str) -> Optional[str]:
    """Extract MPLS/LDP/RSVP related config lines from running config."""
    lines = running_config.splitlines()
    mpls_lines: list[str] = []
    in_block = False

    for line in lines:
        if re.match(r"^(mpls|ip rsvp)", line):
            in_block = True
            mpls_lines.append(line)
        elif in_block:
            if line.startswith(" ") or line.startswith("\t"):
                mpls_lines.append(line)
            else:
                in_block = False
                if re.match(r"^(mpls|ip rsvp)", line):
                    in_block = True
                    mpls_lines.append(line)

    # Also grab interface-level mpls/rsvp commands
    in_interface = False
    iface_name = ""
    iface_mpls_lines: list[str] = []
    for line in lines:
        if re.match(r"^interface\s+", line):
            in_interface = True
            iface_name = line
            iface_mpls_lines = []
        elif in_interface:
            if line.startswith(" ") or line.startswith("\t"):
                stripped = line.strip()
                if stripped.startswith(("mpls", "ip rsvp")):
                    iface_mpls_lines.append(line)
            else:
                if iface_mpls_lines:
                    mpls_lines.append(iface_name)
                    mpls_lines.extend(iface_mpls_lines)
                in_interface = False
                iface_mpls_lines = []

    return "\n".join(mpls_lines) if mpls_lines else None


def _extract_router_block(config: str, start_pattern: str) -> Optional[str]:
    """Generic extractor for 'router ...' config blocks."""
    lines = config.splitlines()
    block: list[str] = []
    in_block = False

    for line in lines:
        if re.match(start_pattern, line):
            in_block = True
            block.append(line)
        elif in_block:
            if line.startswith(" ") or line.startswith("\t"):
                block.append(line)
            else:
                in_block = False

    return "\n".join(block) if block else None


# ── BGP Parsers ────────────────────────────────────────────────

def parse_show_bgp_summary(output: str) -> list[dict]:
    """Parse 'show bgp summary' or 'show ip bgp summary' output.

    Returns:
        List of dicts with keys: neighbor, version, as_number, msg_rcvd,
        msg_sent, up_down, state_pfxrcd
    """
    neighbors = []
    lines = output.strip().splitlines()

    for line in lines:
        parts = line.split()
        if len(parts) < 8:
            continue
        # Neighbor lines start with an IP address
        if not re.match(r"\d+\.\d+\.\d+\.\d+", parts[0]):
            continue
        neighbors.append({
            "neighbor": parts[0],
            "version": parts[1],
            "as_number": parts[2],
            "msg_rcvd": parts[3],
            "msg_sent": parts[4],
            "up_down": parts[-2],
            "state_pfxrcd": parts[-1],
        })

    return neighbors


def parse_show_bgp_neighbors(output: str) -> list[dict]:
    """Parse 'show ip bgp neighbors' output for per-neighbor detail.

    Returns:
        List of dicts with keys: neighbor, remote_as, state, uptime,
        router_id, description
    """
    neighbors = []
    current: dict[str, str] = {}

    for line in output.splitlines():
        m = re.match(r"BGP neighbor is (\d+\.\d+\.\d+\.\d+),\s+remote AS (\d+)", line)
        if m:
            if current:
                neighbors.append(current)
            current = {"neighbor": m.group(1), "remote_as": m.group(2)}
            continue

        if "BGP state" in line or "BGP state =" in line:
            m2 = re.search(r"BGP state\s*=?\s*(\w+)", line)
            if m2:
                current["state"] = m2.group(1)

        if "Description:" in line:
            current["description"] = line.split("Description:")[-1].strip()

        m3 = re.search(r"BGP table version\s+(\d+)", line)
        if m3:
            current["table_version"] = m3.group(1)

    if current:
        neighbors.append(current)

    return neighbors


# ── EIGRP Parsers ──────────────────────────────────────────────

def parse_show_eigrp_neighbors(output: str) -> list[dict]:
    """Parse 'show ip eigrp neighbors' output.

    Returns:
        List of dicts with keys: address, interface, hold, uptime,
        srtt, rto, q_cnt, seq_num
    """
    neighbors = []
    lines = output.strip().splitlines()

    for line in lines:
        parts = line.split()
        if len(parts) < 7:
            continue
        if not re.match(r"\d+\.\d+\.\d+\.\d+", parts[1] if len(parts) > 1 else ""):
            # Try first column
            if not re.match(r"\d+\.\d+\.\d+\.\d+", parts[0]):
                continue

        # Format: H  Address  Interface  Hold  Uptime  SRTT  RTO  Q  Seq
        # Skip header row (starts with 'H')
        if parts[0] == "H":
            continue

        try:
            idx = 0
            # First field is the handle number
            if parts[0].isdigit() and not "." in parts[0]:
                idx = 1

            neighbors.append({
                "address": parts[idx],
                "interface": parts[idx + 1] if idx + 1 < len(parts) else "",
                "hold": parts[idx + 2] if idx + 2 < len(parts) else "",
                "uptime": parts[idx + 3] if idx + 3 < len(parts) else "",
                "srtt": parts[idx + 4] if idx + 4 < len(parts) else "",
                "rto": parts[idx + 5] if idx + 5 < len(parts) else "",
                "q_cnt": parts[idx + 6] if idx + 6 < len(parts) else "",
                "seq_num": parts[idx + 7] if idx + 7 < len(parts) else "",
            })
        except (IndexError, ValueError):
            continue

    return neighbors


def parse_show_eigrp_topology(output: str) -> list[dict]:
    """Parse 'show ip eigrp topology' output.

    Returns:
        List of dicts with keys: code, network, successors, fd
    """
    entries = []
    pattern = re.compile(
        r"([PAU])\s+"
        r"(\d+\.\d+\.\d+\.\d+(?:/\d+)?)\s*,\s*"
        r"(\d+)\s+successors?,\s*FD is\s+(\d+)"
    )

    for line in output.splitlines():
        m = pattern.search(line)
        if m:
            entries.append({
                "code": m.group(1),
                "network": m.group(2),
                "successors": int(m.group(3)),
                "fd": int(m.group(4)),
            })

    return entries


# ── IS-IS Parsers ──────────────────────────────────────────────

def parse_show_isis_neighbors(output: str) -> list[dict]:
    """Parse 'show isis neighbors' or 'show clns neighbors' output.

    Returns:
        List of dicts with keys: system_id, interface, state, holdtime, type
    """
    neighbors = []
    lines = output.strip().splitlines()

    for line in lines:
        if "System Id" in line or "---" in line or not line.strip():
            continue
        parts = line.split()
        if len(parts) >= 4:
            neighbors.append({
                "system_id": parts[0],
                "interface": parts[1] if len(parts) > 1 else "",
                "state": parts[2] if len(parts) > 2 else "",
                "holdtime": parts[3] if len(parts) > 3 else "",
                "type": parts[4] if len(parts) > 4 else "",
            })

    return neighbors


def parse_show_isis_database(output: str) -> list[dict]:
    """Parse 'show isis database' output.

    Returns:
        List of dicts with keys: lsp_id, seq_num, checksum, holdtime
    """
    entries = []
    lines = output.strip().splitlines()

    for line in lines:
        if "LSPID" in line or "---" in line or not line.strip():
            continue
        if "*" in line or "." in line.split()[0] if line.split() else False:
            parts = line.split()
            if len(parts) >= 4:
                entries.append({
                    "lsp_id": parts[0].lstrip("*"),
                    "seq_num": parts[1] if len(parts) > 1 else "",
                    "checksum": parts[2] if len(parts) > 2 else "",
                    "holdtime": parts[3] if len(parts) > 3 else "",
                })

    return entries


# ── MPLS/LDP/RSVP Parsers ─────────────────────────────────────

def parse_show_mpls_interfaces(output: str) -> list[dict]:
    """Parse 'show mpls interfaces' output.

    Returns:
        List of dicts with keys: interface, ip, tunnel, bgp, static, operational
    """
    interfaces = []
    lines = output.strip().splitlines()

    for line in lines:
        if "Interface" in line and "IP" in line:
            continue
        parts = line.split()
        if len(parts) >= 2 and re.match(r"[A-Z]", parts[0]):
            interfaces.append({
                "interface": parts[0],
                "ip": parts[1] if len(parts) > 1 else "",
                "tunnel": parts[2] if len(parts) > 2 else "",
                "bgp": parts[3] if len(parts) > 3 else "",
                "static": parts[4] if len(parts) > 4 else "",
                "operational": parts[5] if len(parts) > 5 else "",
            })

    return interfaces


def parse_show_mpls_ldp_neighbor(output: str) -> list[dict]:
    """Parse 'show mpls ldp neighbor' output.

    Returns:
        List of dicts with keys: peer, state, tcp_connection, msg_sent, msg_rcvd
    """
    neighbors = []
    current: dict[str, str] = {}

    for line in output.splitlines():
        m = re.match(r"\s*Peer LDP Ident:\s+(\S+)", line)
        if m:
            if current:
                neighbors.append(current)
            current = {"peer": m.group(1), "state": ""}
            continue

        if "State:" in line:
            m2 = re.search(r"State:\s+(\w+)", line)
            if m2 and current:
                current["state"] = m2.group(1)

        m3 = re.search(r"TCP connection:\s+(\S+)", line)
        if m3 and current:
            current["tcp_connection"] = m3.group(1)

        m4 = re.search(r"Msgs sent/rcvd:\s+(\d+)/(\d+)", line)
        if m4 and current:
            current["msg_sent"] = m4.group(1)
            current["msg_rcvd"] = m4.group(2)

    if current:
        neighbors.append(current)

    return neighbors


def parse_show_mpls_forwarding(output: str) -> list[dict]:
    """Parse 'show mpls forwarding-table' output.

    Returns:
        List of dicts with keys: local_label, outgoing_label, prefix,
        outgoing_interface, next_hop
    """
    entries = []
    lines = output.strip().splitlines()

    for line in lines:
        if "Local" in line and "Outgoing" in line:
            continue
        parts = line.split()
        if len(parts) >= 4 and parts[0].isdigit():
            entries.append({
                "local_label": parts[0],
                "outgoing_label": parts[1] if len(parts) > 1 else "",
                "prefix": parts[2] if len(parts) > 2 else "",
                "outgoing_interface": parts[3] if len(parts) > 3 else "",
                "next_hop": parts[4] if len(parts) > 4 else "",
            })

    return entries


def parse_show_ip_rsvp_neighbor(output: str) -> list[dict]:
    """Parse 'show ip rsvp neighbor' output.

    Returns:
        List of dicts with keys: neighbor, encapsulation
    """
    neighbors = []
    lines = output.strip().splitlines()

    for line in lines:
        if "Neighbor" in line and "Encap" in line:
            continue
        parts = line.split()
        if len(parts) >= 1 and re.match(r"\d+\.\d+\.\d+\.\d+", parts[0]):
            neighbors.append({
                "neighbor": parts[0],
                "encapsulation": parts[1] if len(parts) > 1 else "",
            })

    return neighbors
