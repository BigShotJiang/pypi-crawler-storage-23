"""Logging setup for NetMind.

Log levels:
  DEBUG   - Tool execution details, SSH commands, raw outputs
  INFO    - Major operations (device connected, config applied, agent actions)
  WARNING - Recoverable errors, retries, degraded functionality
  ERROR   - Failures requiring user attention
"""

import logging
import sys
from typing import Optional


def setup_logging(
    level: str = "INFO",
    log_file: Optional[str] = None,
    console: bool = True,
) -> None:
    """Configure the root logger for NetMind.

    Args:
        level: Log level string (DEBUG, INFO, WARNING, ERROR).
        log_file: Optional file path to write logs to.
        console: If True, also log to stderr. Set False when a TUI
                 is running to avoid stomping over the screen.
    """
    root_logger = logging.getLogger("netmind")
    root_logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    root_logger.handlers.clear()

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(name)-30s | %(levelname)-7s | %(message)s",
        datefmt="%H:%M:%S",
    )

    if console:
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    # Always have at least a file handler so logs aren't lost
    if not log_file and not console:
        from pathlib import Path
        log_dir = Path.home() / ".sunset" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(str(log_dir / "sunset.log"))
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    logging.getLogger("paramiko").setLevel(logging.WARNING)
    logging.getLogger("netmiko").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """Get a named logger under the netmind namespace.

    Usage:
        logger = get_logger(__name__)
        logger.info("Device connected")
    """
    return logging.getLogger(f"netmind.{name}")
