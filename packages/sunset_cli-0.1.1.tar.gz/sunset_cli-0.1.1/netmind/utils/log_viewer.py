"""CLI log viewer for Sunset session logs.

Provides human-readable formatted output of JSON-lines session logs,
with optional filtering, tailing, and raw JSON output.

Usage:
    sunset logs              # List all sessions
    sunset logs --last       # Show latest session
    sunset logs --tail       # Tail latest session in real-time
    sunset logs -t error     # Filter by event type
"""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

from netmind.utils.session_logger import DEFAULT_LOG_DIR

# ANSI color codes
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
MAGENTA = "\033[35m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"

# Event type → color mapping
TYPE_COLORS = {
    "session_start": CYAN,
    "session_end": CYAN,
    "user_message": GREEN,
    "agent_text": MAGENTA,
    "agent_done": MAGENTA,
    "agent_iteration": DIM,
    "api_call": DIM,
    "tool_call": YELLOW,
    "tool_result": YELLOW,
    "device_connect": CYAN,
    "device_command": CYAN,
    "device_config": CYAN,
    "safety_check": YELLOW,
    "approval": RED,
    "checkpoint": YELLOW,
    "error": RED,
    "inventory_load": CYAN,
    "topology_build": CYAN,
    "discovery_start": GREEN,
    "discovery_device": GREEN,
    "discovery_complete": GREEN,
    "ssh_options": DIM,
}


def generate_report_cmd(
    full: bool = False,
    save_path: Optional[str] = None,
) -> None:
    """CLI command to generate a debug report from the latest session log."""
    from netmind.utils.log_report import generate_report

    log_dir = Path(DEFAULT_LOG_DIR)
    if not log_dir.exists():
        print(f"No session logs found (looked in {log_dir}/)")
        return

    log_files = sorted(log_dir.glob("session_*.jsonl"))
    if not log_files:
        print(f"No session logs found in {log_dir}/")
        return

    latest = log_files[-1]
    output_path = Path(save_path) if save_path else None

    print(f"\n{BOLD}Analyzing: {latest.name}{RESET}\n")
    report = generate_report(latest, full=full, output_path=output_path)
    print(report)

    if not output_path:
        # Suggest saving
        report_name = latest.stem.replace("session_", "report_") + ".txt"
        default_report = log_dir / report_name
        print(
            f"\n{DIM}Tip: save this report with "
            f"--save {default_report}{RESET}"
        )


def view_logs(
    tail: bool = False,
    last: bool = False,
    raw_json: bool = False,
    event_filter: Optional[str] = None,
) -> None:
    """Main entry point for the log viewer CLI."""
    log_dir = Path(DEFAULT_LOG_DIR)

    if not log_dir.exists():
        print(f"No session logs found (looked in {log_dir}/)")
        return

    log_files = sorted(log_dir.glob("session_*.jsonl"))

    if not log_files:
        print(f"No session logs found in {log_dir}/")
        return

    if tail or last:
        # Work with the latest log file
        latest = log_files[-1]
        if tail:
            _tail_log(latest, raw_json, event_filter)
        else:
            _show_log(latest, raw_json, event_filter)
    else:
        # List all sessions
        _list_sessions(log_files)


def _list_sessions(log_files: list[Path]) -> None:
    """List all session log files with summary info."""
    print(f"\n{BOLD}Sunset Session Logs{RESET}")
    print(f"{'─' * 60}")

    for path in log_files:
        size = path.stat().st_size
        size_str = _format_size(size)
        name = path.stem.replace("session_", "")

        # Read first and last lines for timing
        lines = _read_lines(path)
        event_count = len(lines)

        # Count event types
        types: dict[str, int] = {}
        errors = 0
        for line in lines:
            entry = _parse_line(line)
            if entry:
                t = entry.get("type", "unknown")
                types[t] = types.get(t, 0) + 1
                if t == "error":
                    errors += 1

        error_str = f"  {RED}({errors} errors){RESET}" if errors else ""
        print(
            f"  {CYAN}{name}{RESET}  "
            f"{DIM}{event_count} events, {size_str}{RESET}"
            f"{error_str}"
        )

    print(f"\n{DIM}Use --last to view the latest, --tail to follow{RESET}\n")


def _show_log(path: Path, raw_json: bool, event_filter: Optional[str]) -> None:
    """Display a full session log."""
    print(f"\n{BOLD}Session: {path.stem}{RESET}")
    print(f"{'─' * 70}")

    for line in _read_lines(path):
        entry = _parse_line(line)
        if entry is None:
            continue
        if event_filter and entry.get("type") != event_filter:
            continue

        if raw_json:
            print(line.strip())
        else:
            _print_entry(entry)

    print()


def _tail_log(path: Path, raw_json: bool, event_filter: Optional[str]) -> None:
    """Tail a session log file in real-time."""
    print(f"\n{BOLD}Tailing: {path.name}{RESET}  (Ctrl+C to stop)")
    print(f"{'─' * 70}")

    # Show existing content first
    _show_log(path, raw_json, event_filter)

    # Then follow new lines
    try:
        with open(path) as f:
            f.seek(0, 2)  # Seek to end
            while True:
                line = f.readline()
                if line:
                    entry = _parse_line(line)
                    if entry is None:
                        continue
                    if event_filter and entry.get("type") != event_filter:
                        continue
                    if raw_json:
                        print(line.strip())
                    else:
                        _print_entry(entry)
                else:
                    time.sleep(0.3)
    except KeyboardInterrupt:
        print(f"\n{DIM}Stopped tailing.{RESET}")


def _print_entry(entry: dict) -> None:
    """Format and print a single log entry."""
    ts = entry.get("ts", "")
    event_type = entry.get("type", "unknown")
    data = entry.get("data", {})

    color = TYPE_COLORS.get(event_type, RESET)
    ts_short = ts[11:19] if len(ts) > 19 else ts  # HH:MM:SS

    # Format based on event type
    if event_type == "user_message":
        msg = data.get("message", "")
        print(f"  {DIM}{ts_short}{RESET}  {color}[USR]{RESET} {msg}")

    elif event_type == "agent_text":
        text = data.get("text", "")
        preview = text[:120].replace("\n", " ")
        print(f"  {DIM}{ts_short}{RESET}  {color}[LLM]{RESET} {preview}")

    elif event_type == "agent_done":
        length = data.get("response_length", 0)
        print(f"  {DIM}{ts_short}{RESET}  {color}[LLM]{RESET} {DIM}done ({length} chars){RESET}")

    elif event_type == "tool_call":
        tool = data.get("tool", "")
        inp = data.get("input", {})
        inp_str = json.dumps(inp, default=str)
        if len(inp_str) > 80:
            inp_str = inp_str[:80] + "..."
        print(f"  {DIM}{ts_short}{RESET}  {color}>> {tool}{RESET} {DIM}{inp_str}{RESET}")

    elif event_type == "tool_result":
        tool = data.get("tool", "")
        status = data.get("status", "")
        elapsed = data.get("elapsed_ms", 0)
        error = data.get("error")
        if error:
            print(
                f"  {DIM}{ts_short}{RESET}  {color}<< {tool}{RESET} "
                f"{RED}ERROR: {error}{RESET} {DIM}({elapsed:.0f}ms){RESET}"
            )
        else:
            print(
                f"  {DIM}{ts_short}{RESET}  {color}<< {tool}{RESET} "
                f"{GREEN}{status}{RESET} {DIM}({elapsed:.0f}ms){RESET}"
            )

    elif event_type == "api_call":
        model = data.get("model", "")
        elapsed = data.get("elapsed_ms", 0)
        in_tok = data.get("input_tokens", 0)
        out_tok = data.get("output_tokens", 0)
        print(
            f"  {DIM}{ts_short}  API {model} "
            f"in={in_tok} out={out_tok} ({elapsed:.0f}ms){RESET}"
        )

    elif event_type == "device_connect":
        dev = data.get("device_id", "")
        host = data.get("host", "")
        ok = data.get("success", False)
        elapsed = data.get("elapsed_ms", 0)
        status = f"{GREEN}OK{RESET}" if ok else f"{RED}FAIL: {data.get('error', '')}{RESET}"
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[SSH]{RESET} "
            f"{dev}@{host} {status} {DIM}({elapsed:.0f}ms){RESET}"
        )

    elif event_type == "device_command":
        dev = data.get("device_id", "")
        cmd = data.get("command", "")
        ok = data.get("success", False)
        elapsed = data.get("elapsed_ms", 0)
        attempt = data.get("attempt", 1)
        retry = f" (attempt {attempt})" if attempt > 1 else ""
        status = f"{GREEN}OK{RESET}" if ok else f"{RED}FAIL{RESET}"
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[CMD]{RESET} "
            f"{dev}: {cmd} {status}{retry} {DIM}({elapsed:.0f}ms){RESET}"
        )

    elif event_type == "device_config":
        dev = data.get("device_id", "")
        cmds = data.get("commands", [])
        ok = data.get("success", False)
        status = f"{GREEN}OK{RESET}" if ok else f"{RED}FAIL{RESET}"
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[CFG]{RESET} "
            f"{dev}: {len(cmds)} commands {status}"
        )

    elif event_type == "safety_check":
        check = data.get("check_type", "")
        allowed = data.get("allowed", False)
        reason = data.get("reason", "")
        status = f"{GREEN}PASS{RESET}" if allowed else f"{RED}BLOCKED: {reason}{RESET}"
        print(f"  {DIM}{ts_short}{RESET}  {color}[SAFE]{RESET} {check} {status}")

    elif event_type == "approval":
        action = data.get("action", "")
        dev = data.get("device_id", "")
        desc = data.get("description", "")
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[APPROVAL]{RESET} "
            f"{action.upper()} on {dev}: {desc}"
        )

    elif event_type == "error":
        cat = data.get("category", "")
        msg = data.get("message", "")
        print(f"  {DIM}{ts_short}{RESET}  {RED}[ERROR] {cat}: {msg}{RESET}")

    elif event_type == "checkpoint":
        dev = data.get("device_id", "")
        name = data.get("checkpoint_name", "")
        action = data.get("action", "")
        ok = data.get("success", False)
        status = f"{GREEN}OK{RESET}" if ok else f"{RED}FAIL{RESET}"
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[CKPT]{RESET} "
            f"{action} {name} on {dev} {status}"
        )

    elif event_type == "inventory_load":
        dc = data.get("device_count", 0)
        sc = data.get("success_count", 0)
        ec = data.get("error_count", 0)
        err = f"  {RED}({ec} errors){RESET}" if ec else ""
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[INV]{RESET} "
            f"loaded {sc}/{dc} devices{err}"
        )

    elif event_type == "topology_build":
        src = data.get("source", "?")
        nc = data.get("node_count", 0)
        lc = data.get("link_count", 0)
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[TOPO]{RESET} "
            f"{src}: {nc} nodes, {lc} links"
        )

    elif event_type == "discovery_start":
        dc = data.get("device_count", 0)
        print(f"  {DIM}{ts_short}{RESET}  {color}[DISC]{RESET} start ({dc} devices)")

    elif event_type == "discovery_device":
        dev = data.get("device_id", "")
        ic = data.get("interface_count", 0)
        ec = data.get("error_count", 0)
        err = f" {RED}({ec} errors){RESET}" if ec else ""
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[DISC]{RESET} "
            f"{dev}: {ic} interfaces{err}"
        )

    elif event_type == "discovery_complete":
        nc = data.get("node_count", 0)
        lc = data.get("link_count", 0)
        elapsed = data.get("elapsed_ms", 0)
        print(
            f"  {DIM}{ts_short}{RESET}  {color}[DISC]{RESET} "
            f"complete: {nc} nodes, {lc} links {DIM}({elapsed:.0f}ms){RESET}"
        )

    elif event_type == "ssh_options":
        dev = data.get("device_id", "")
        opts = data.get("options", {})
        print(
            f"  {DIM}{ts_short}  [SSH-OPT] {dev}: "
            f"{json.dumps(opts, default=str)[:80]}{RESET}"
        )

    elif event_type == "session_start":
        sid = data.get("session_id", "")
        verbose = data.get("verbose", False)
        v_str = f" {YELLOW}[VERBOSE]{RESET}" if verbose else ""
        print(f"  {DIM}{ts_short}{RESET}  {color}SESSION START{RESET} {DIM}{sid}{RESET}{v_str}")

    elif event_type == "session_end":
        dur = data.get("duration_seconds", 0)
        ec = data.get("event_count", 0)
        print(
            f"  {DIM}{ts_short}{RESET}  {color}SESSION END{RESET} "
            f"{DIM}(duration: {dur:.0f}s, {ec} events){RESET}"
        )

    else:
        # Fallback for unknown types
        print(f"  {DIM}{ts_short}{RESET}  [{event_type}] {json.dumps(data, default=str)[:100]}")


def _read_lines(path: Path) -> list[str]:
    """Read all lines from a file."""
    with open(path) as f:
        return f.readlines()


def _parse_line(line: str) -> Optional[dict]:
    """Parse a JSON-lines entry."""
    line = line.strip()
    if not line:
        return None
    try:
        return json.loads(line)
    except json.JSONDecodeError:
        return None


def _format_size(size: int) -> str:
    """Format byte size to human-readable."""
    if size < 1024:
        return f"{size}B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f}KB"
    else:
        return f"{size / (1024 * 1024):.1f}MB"
