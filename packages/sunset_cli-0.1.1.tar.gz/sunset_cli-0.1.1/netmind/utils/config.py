"""Configuration management for Sunset."""

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field


# Canonical user-level config directory.
SUNSET_CONFIG_DIR = Path.home() / ".sunset"
SUNSET_CONFIG_ENV = SUNSET_CONFIG_DIR / ".env"


def _find_env_file() -> Optional[Path]:
    """Walk up from CWD to find a .env, then fall back to ~/.sunset/.env."""
    current = Path.cwd()
    for parent in [current, *current.parents]:
        env_path = parent / ".env"
        if env_path.is_file():
            return env_path
    # Primary: new location
    if SUNSET_CONFIG_ENV.is_file():
        return SUNSET_CONFIG_ENV
    # Legacy fallback
    _legacy = Path.home() / ".netmind" / ".env"
    if _legacy.is_file():
        return _legacy
    return None


def save_env_file(values: dict) -> Path:
    """Write key=value pairs to ~/.sunset/.env (merge with existing)."""
    SUNSET_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if SUNSET_CONFIG_ENV.is_file():
        for line in SUNSET_CONFIG_ENV.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                existing[k.strip()] = v.strip()

    existing.update(values)

    lines = ["# Sunset Configuration (auto-generated)\n"]
    for k, v in existing.items():
        lines.append(f"{k}={v}\n")

    SUNSET_CONFIG_ENV.write_text("".join(lines))
    return SUNSET_CONFIG_ENV


class NetMindConfig(BaseModel):
    """Application configuration loaded from environment."""

    anthropic_api_key: str = Field(default="")
    sunset_license_key: str = Field(default="")
    claude_model: str = Field(default="claude-sonnet-4-20250514")
    log_level: str = Field(default="INFO")
    ssh_timeout: int = Field(default=30, description="SSH connection timeout in seconds")
    command_timeout: int = Field(default=60, description="Command execution timeout in seconds")
    max_conversation_history: int = Field(default=50, description="Max messages in conversation")
    max_checkpoints: int = Field(default=10, description="Max config checkpoints per device")
    read_only_default: bool = Field(default=True, description="Start in read-only mode")

    @classmethod
    def from_env(cls) -> "NetMindConfig":
        """Load configuration from environment variables."""
        env_file = _find_env_file()
        if env_file:
            load_dotenv(env_file)

        return cls(
            anthropic_api_key=os.getenv("ANTHROPIC_API_KEY", ""),
            sunset_license_key=os.getenv("SUNSET_LICENSE_KEY", ""),
            claude_model=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-20250514"),
            log_level=os.getenv("LOG_LEVEL", "INFO"),
            ssh_timeout=int(os.getenv("SSH_TIMEOUT", "30")),
            command_timeout=int(os.getenv("COMMAND_TIMEOUT", "60")),
            max_conversation_history=int(os.getenv("MAX_CONVERSATION_HISTORY", "50")),
            max_checkpoints=int(os.getenv("MAX_CHECKPOINTS", "10")),
            read_only_default=os.getenv("READ_ONLY_DEFAULT", "true").lower() == "true",
        )

    @property
    def has_api_key(self) -> bool:
        return bool(self.anthropic_api_key)

    @property
    def has_license(self) -> bool:
        return bool(self.sunset_license_key)


# Singleton config instance
_config: Optional[NetMindConfig] = None


def get_config() -> NetMindConfig:
    """Get the global configuration (lazy-loaded singleton)."""
    global _config
    if _config is None:
        _config = NetMindConfig.from_env()
    return _config


def reset_config() -> None:
    """Reset config (useful for testing)."""
    global _config
    _config = None


def reset_and_reload() -> NetMindConfig:
    """Reset the singleton and reload from environment."""
    global _config
    _config = None
    return get_config()
