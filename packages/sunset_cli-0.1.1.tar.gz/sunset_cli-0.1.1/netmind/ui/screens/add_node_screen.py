"""Add Node modal screen — cyberpunk neon style.

Collects device connection details and returns them to the caller.
The caller handles saving to inventory and connecting via SSH.
"""

from typing import Optional

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Checkbox, Input, Label, Select, Static

from netmind.models import DeviceType


class AddNodeScreen(ModalScreen[Optional[dict]]):
    """Modal for adding a new network node.

    Returns a dict with device fields on submit, or None on cancel.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False),
    ]

    DEFAULT_CSS = """
    AddNodeScreen {
        align: center middle;
        background: #0a0a14 80%;
    }

    #add-node-container {
        width: 60;
        max-height: 40;
        background: #0e0e1a;
        border: double #00ffff;
        padding: 1 2;
    }

    #add-node-header {
        text-style: bold;
        text-align: center;
        color: #00ffff;
        height: 1;
        content-align: center middle;
    }

    #add-node-sep {
        color: #00ffff 50%;
        height: 1;
    }

    .an-label {
        margin-top: 1;
        color: #5a5a7c;
        text-style: bold;
    }

    .an-input {
        margin-bottom: 0;
        background: #0a0a14;
        color: #00ffff;
    }

    #an-scroll {
        max-height: 24;
    }

    #add-node-status {
        margin-top: 1;
        height: 1;
        color: #5a5a7c;
    }

    #add-node-buttons {
        height: 3;
        align: center middle;
        margin-top: 1;
    }

    #add-node-buttons Button {
        margin: 0 2;
        min-width: 16;
    }

    #add-node-hint {
        text-align: center;
        color: #2a2a4c;
    }

    #an-legacy-row {
        height: 3;
        margin-top: 1;
    }

    #an-legacy-row Checkbox {
        background: transparent;
        color: #00ffff;
        border: none;
        padding: 0;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="add-node-container"):
            yield Static(
                "\u2552\u2550\u2550\u2550 ADD NEW NODE \u2550\u2550\u2550 SSH REGISTER \u2550\u2550\u2550\u2555",
                id="add-node-header",
            )
            yield Static("\u2500" * 54, id="add-node-sep")

            with VerticalScroll(id="an-scroll"):
                yield Label("DEVICE ID:", classes="an-label")
                yield Input(
                    placeholder="R3",
                    id="an-device-id",
                    classes="an-input",
                )

                yield Label("HOST:", classes="an-label")
                yield Input(
                    placeholder="10.10.10.4",
                    id="an-host",
                    classes="an-input",
                )

                yield Label("USERNAME:", classes="an-label")
                yield Input(
                    placeholder="admin",
                    id="an-username",
                    classes="an-input",
                )

                yield Label("PASSWORD:", classes="an-label")
                yield Input(
                    placeholder="********",
                    password=True,
                    id="an-password",
                    classes="an-input",
                )

                yield Label("SSH PORT:", classes="an-label")
                yield Input(
                    placeholder="22",
                    value="22",
                    id="an-port",
                    classes="an-input",
                )

                yield Label("DEVICE TYPE:", classes="an-label")
                yield Select(
                    [(dt.value, dt.value) for dt in DeviceType],
                    value=DeviceType.CISCO_IOS.value,
                    id="an-device-type",
                )

                yield Label("ENABLE SECRET:", classes="an-label")
                yield Input(
                    placeholder="(optional)",
                    password=True,
                    id="an-enable-secret",
                    classes="an-input",
                )

                with Horizontal(id="an-legacy-row"):
                    yield Checkbox(
                        "LEGACY SSH (old algorithms)",
                        id="an-legacy-ssh",
                    )

            yield Static("", id="add-node-status")

            with Horizontal(id="add-node-buttons"):
                yield Button("SAVE & CONNECT", variant="primary", id="btn-an-submit")
                yield Button("CANCEL", variant="default", id="btn-an-cancel")

            yield Static(
                "saves to inventory file  |  esc to cancel",
                id="add-node-hint",
            )

    def on_mount(self) -> None:
        self.query_one("#an-device-id", Input).focus()

    @on(Button.Pressed, "#btn-an-submit")
    def on_submit(self) -> None:
        """Validate and return form data."""
        device_id = self.query_one("#an-device-id", Input).value.strip()
        host = self.query_one("#an-host", Input).value.strip()
        username = self.query_one("#an-username", Input).value.strip()
        password = self.query_one("#an-password", Input).value
        port_str = self.query_one("#an-port", Input).value.strip() or "22"
        device_type = (
            self.query_one("#an-device-type", Select).value
            or DeviceType.CISCO_IOS.value
        )
        enable_secret = self.query_one("#an-enable-secret", Input).value.strip()
        legacy_ssh = self.query_one("#an-legacy-ssh", Checkbox).value

        if not all([device_id, host, username, password]):
            self._set_status("REQUIRED: DEVICE ID, HOST, USERNAME, PASSWORD", error=True)
            return

        try:
            port = int(port_str)
            if port < 1 or port > 65535:
                raise ValueError
        except ValueError:
            self._set_status("INVALID PORT NUMBER", error=True)
            return

        self.dismiss({
            "id": device_id,
            "host": host,
            "username": username,
            "password": password,
            "port": port,
            "device_type": device_type,
            "enable_secret": enable_secret or None,
            "legacy_ssh": legacy_ssh,
        })

    @on(Button.Pressed, "#btn-an-cancel")
    def on_cancel_button(self) -> None:
        self.dismiss(None)

    def action_cancel(self) -> None:
        self.dismiss(None)

    def _set_status(self, message: str, error: bool = False) -> None:
        status = self.query_one("#add-node-status", Static)
        if error:
            status.update(f" !! {message}")
            status.styles.color = "#ff1744"
        else:
            status.update(f" >> {message}")
            status.styles.color = "#00ff41"
