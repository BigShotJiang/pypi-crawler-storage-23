"""NetMind UI screens."""

from netmind.ui.screens.add_node_screen import AddNodeScreen
from netmind.ui.screens.main_screen import MainScreen
from netmind.ui.screens.device_manager import DeviceManagerScreen
from netmind.ui.screens.approval_screen import ApprovalScreen
from netmind.ui.screens.setup_screen import SetupScreen
from netmind.ui.screens.ssh_screen import SSHScreen

__all__ = [
    "AddNodeScreen",
    "ApprovalScreen",
    "DeviceManagerScreen",
    "MainScreen",
    "SetupScreen",
    "SSHScreen",
]
