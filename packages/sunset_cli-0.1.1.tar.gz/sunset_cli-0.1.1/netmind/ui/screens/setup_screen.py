"""Setup / onboarding screen — first-run configuration.

Shown when no ANTHROPIC_API_KEY is configured.  Collects the API key,
optionally a first network node, and saves to ~/.sunset/.env.
"""

from typing import Optional

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Select, Static

from netmind.models import DeviceType


class SetupScreen(Screen[Optional[dict]]):
    """First-run setup screen.  Returns config dict or ``None`` on quit."""

    BINDINGS = [
        Binding("ctrl+q", "quit_app", "Quit", show=False),
    ]

    DEFAULT_CSS = """
    SetupScreen {
        background: #0a0a14;
        align: center middle;
    }

    #setup-container {
        width: 64;
        max-height: 42;
        background: #0e0e1a;
        border: double #00ffff;
        padding: 1 2;
    }

    #setup-header {
        text-style: bold;
        text-align: center;
        color: #00ffff;
        height: 3;
        content-align: center middle;
    }

    #setup-sep {
        color: #00ffff 50%;
        height: 1;
    }

    #setup-welcome {
        color: #7a7a9c;
        margin: 1 0;
        text-align: center;
    }

    .setup-label {
        margin-top: 1;
        color: #5a5a7c;
        text-style: bold;
    }

    .setup-input {
        margin-bottom: 0;
        background: #0a0a14;
        color: #00ffff;
    }

    .setup-section {
        color: #ff00ff;
        text-style: bold;
        margin-top: 1;
    }

    #setup-scroll {
        max-height: 28;
    }

    #setup-status {
        margin-top: 1;
        height: 1;
        color: #5a5a7c;
    }

    #setup-buttons {
        height: 3;
        align: center middle;
        margin-top: 1;
    }

    #setup-buttons Button {
        margin: 0 2;
        min-width: 16;
    }

    #setup-hint {
        text-align: center;
        color: #2a2a4c;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="setup-container"):
            yield Static(
                "\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u2557\n"
                "\u2551          SUNSET \u2500\u2500 FIRST RUN SETUP"
                "         \u2551\n"
                "\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550"
                "\u2550\u2550\u2550\u2550\u255d",
                id="setup-header",
            )
            yield Static("\u2500" * 58, id="setup-sep")
            yield Static(
                "Configure your API key to begin.  Node setup is optional.",
                id="setup-welcome",
            )

            with VerticalScroll(id="setup-scroll"):
                yield Label(
                    "\u2500\u2500 API CONFIGURATION \u2500\u2500",
                    classes="setup-section",
                )

                yield Label("ANTHROPIC API KEY:", classes="setup-label")
                yield Input(
                    placeholder="sk-ant-...",
                    password=True,
                    id="setup-api-key",
                    classes="setup-input",
                )

                yield Label(
                    "\u2500\u2500 NETWORK NODE (OPTIONAL) \u2500\u2500",
                    classes="setup-section",
                )

                yield Label("DEVICE ID:", classes="setup-label")
                yield Input(
                    placeholder="R1",
                    id="setup-device-id",
                    classes="setup-input",
                )

                yield Label("HOST:", classes="setup-label")
                yield Input(
                    placeholder="192.168.1.1",
                    id="setup-host",
                    classes="setup-input",
                )

                yield Label("USERNAME:", classes="setup-label")
                yield Input(
                    placeholder="admin",
                    id="setup-username",
                    classes="setup-input",
                )

                yield Label("PASSWORD:", classes="setup-label")
                yield Input(
                    placeholder="********",
                    password=True,
                    id="setup-password",
                    classes="setup-input",
                )

                yield Label("DEVICE TYPE:", classes="setup-label")
                yield Select(
                    [(dt.value, dt.value) for dt in DeviceType],
                    value=DeviceType.CISCO_IOS.value,
                    id="setup-device-type",
                )

            yield Static("", id="setup-status")

            with Horizontal(id="setup-buttons"):
                yield Button(
                    "LAUNCH", variant="primary", id="btn-setup-launch",
                )
                yield Button(
                    "QUIT", variant="default", id="btn-setup-quit",
                )

            yield Static(
                "config saved to ~/.sunset/.env",
                id="setup-hint",
            )

    def on_mount(self) -> None:
        self.query_one("#setup-api-key", Input).focus()

    @on(Button.Pressed, "#btn-setup-launch")
    def on_launch(self) -> None:
        api_key = self.query_one("#setup-api-key", Input).value.strip()

        if not api_key:
            self._set_status("API KEY IS REQUIRED", error=True)
            return

        result: dict = {"api_key": api_key}

        # Optional node data — only include if all required fields filled.
        device_id = self.query_one("#setup-device-id", Input).value.strip()
        host = self.query_one("#setup-host", Input).value.strip()
        username = self.query_one("#setup-username", Input).value.strip()
        password = self.query_one("#setup-password", Input).value

        if device_id and host and username and password:
            device_type = (
                self.query_one("#setup-device-type", Select).value
                or DeviceType.CISCO_IOS.value
            )
            result["node"] = {
                "id": device_id,
                "host": host,
                "username": username,
                "password": password,
                "device_type": device_type,
                "port": 22,
            }

        self.dismiss(result)

    @on(Button.Pressed, "#btn-setup-quit")
    def on_quit_button(self) -> None:
        self.dismiss(None)

    def action_quit_app(self) -> None:
        self.dismiss(None)

    def _set_status(self, message: str, error: bool = False) -> None:
        status = self.query_one("#setup-status", Static)
        if error:
            status.update(f" !! {message}")
            status.styles.color = "#ff1744"
        else:
            status.update(f" >> {message}")
            status.styles.color = "#00ff41"
