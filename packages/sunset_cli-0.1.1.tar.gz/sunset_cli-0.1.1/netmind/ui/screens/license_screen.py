"""Gate screen — shown when setup is incomplete.

Cyberpunk-styled screen that directs the user to the appropriate
CLI command (sunset auth, sunset setup).
"""

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import Screen
from textual.widgets import Button, Static


class LicenseScreen(Screen[None]):
    """Blocks TUI access until configuration is complete."""

    BINDINGS = [
        Binding("ctrl+q", "quit_app", "Quit", show=False),
    ]

    DEFAULT_CSS = """
    LicenseScreen {
        background: #0a0a14;
        align: center middle;
    }

    #license-container {
        width: 56;
        height: auto;
        background: #0e0e1a;
        border: double #ff1744;
        padding: 1 2;
    }

    #license-header {
        text-style: bold;
        text-align: center;
        color: #ff1744;
        height: 3;
        content-align: center middle;
    }

    #license-sep {
        color: #ff1744 50%;
        height: 1;
    }

    #license-message {
        color: #7a7a9c;
        margin: 1 0;
        text-align: center;
    }

    #license-command {
        text-align: center;
        color: #00ffff;
        text-style: bold;
        margin: 1 0;
    }

    #license-error {
        text-align: center;
        color: #ff1744;
        margin: 1 0;
    }

    #license-buttons {
        height: 3;
        align: center middle;
        margin-top: 1;
    }

    #license-buttons Button {
        min-width: 16;
    }
    """

    def __init__(
        self,
        error: str = "",
        command: str = "sunset auth <your-license-key>",
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self._error = error
        self._command = command

    def compose(self) -> ComposeResult:
        with Vertical(id="license-container"):
            yield Static(
                "\u2554" + "\u2550" * 50 + "\u2557\n"
                "\u2551            SETUP REQUIRED            \u2551\n"
                "\u255a" + "\u2550" * 50 + "\u255d",
                id="license-header",
            )
            yield Static("\u2500" * 50, id="license-sep")

            if self._error:
                yield Static(self._error, id="license-error")

            yield Static(
                "Run the following command to continue:",
                id="license-message",
            )
            yield Static(
                self._command,
                id="license-command",
            )

            with Vertical(id="license-buttons"):
                yield Button("QUIT", variant="error", id="btn-license-quit")

    @on(Button.Pressed, "#btn-license-quit")
    def on_quit_button(self) -> None:
        self.dismiss(None)

    def action_quit_app(self) -> None:
        self.dismiss(None)
