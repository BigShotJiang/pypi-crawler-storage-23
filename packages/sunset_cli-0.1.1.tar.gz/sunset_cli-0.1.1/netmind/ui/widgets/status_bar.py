"""Status bar widget — cyberpunk neon style.

Terse, UPPERCASE, no emoji. Box-drawing separators.
"""

from textual.app import ComposeResult
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static


class StatusBar(Widget):
    """Top status bar showing app state at a glance."""

    DEFAULT_CSS = """
    StatusBar {
        dock: top;
        height: 1;
        background: #0e0e1a;
    }

    StatusBar #status-text {
        width: 1fr;
        color: #5a5a7c;
    }

    StatusBar #status-text .status-mode-ro {
        color: #ffb000;
        text-style: bold;
    }

    StatusBar #status-text .status-mode-int {
        color: #00ff41;
        text-style: bold;
    }
    """

    read_only: reactive[bool] = reactive(True)
    device_count: reactive[int] = reactive(0)
    connected_count: reactive[int] = reactive(0)
    is_processing: reactive[bool] = reactive(False)

    def compose(self) -> ComposeResult:
        yield Static(id="status-text")

    def _build_status_text(self) -> str:
        if self.read_only:
            mode = "LOCKED"
            mode_icon = "■"
        else:
            mode = "ARMED"
            mode_icon = "▶"

        processing = " │ PROCESSING..." if self.is_processing else ""

        return (
            f" SUNSET v0.1 "
            f"│ {mode_icon} {mode} "
            f"│ NODES: {self.connected_count}/{self.device_count} "
            f"│ SSH: {'ACTIVE' if self.connected_count > 0 else 'IDLE'}"
            f"{processing} "
        )

    def watch_read_only(self, value: bool) -> None:
        self._update_display()

    def watch_device_count(self, value: int) -> None:
        self._update_display()

    def watch_connected_count(self, value: int) -> None:
        self._update_display()

    def watch_is_processing(self, value: bool) -> None:
        self._update_display()

    def _update_display(self) -> None:
        try:
            label = self.query_one("#status-text", Static)
            text = self._build_status_text()
            label.update(text)

            # Color the whole bar based on mode
            if self.is_processing:
                label.styles.color = "#ff00ff"
            elif not self.read_only:
                label.styles.color = "#00ff41"
            else:
                label.styles.color = "#5a5a7c"
        except Exception:
            pass
