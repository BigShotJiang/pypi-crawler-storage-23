"""Chat panel widget — polished Claude-style rendering.

Uses Textual's Markdown widget for rich assistant responses
with proper headers, code blocks, bold, lists, and tables.
Tool calls are shown compactly and dimmed. User messages are clean.

Clickable elements: tool calls, tool results, and code blocks
copy to clipboard on click.
"""

import platform
import subprocess

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.events import Click
from textual.widget import Widget
from textual.widgets import Markdown, Static

from rich.text import Text


def copy_to_clipboard(text: str) -> bool:
    """Copy text to system clipboard."""
    try:
        system = platform.system()
        if system == "Darwin":
            cmd = ["pbcopy"]
        elif system == "Linux":
            cmd = ["xclip", "-selection", "clipboard"]
        else:
            cmd = ["clip"]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        proc.communicate(text.encode("utf-8"))
        return proc.returncode == 0
    except Exception:
        return False


class ChatMessage(Static):
    """A single plain-text message in the chat panel (user, system, tool)."""

    def __init__(self, renderable="", *, copyable_text: str = "", **kwargs):
        super().__init__(renderable, **kwargs)
        self._copyable_text = copyable_text

    def on_click(self, event: Click) -> None:
        """Copy text to clipboard on click."""
        if self._copyable_text:
            if copy_to_clipboard(self._copyable_text):
                self.app.notify("Copied to clipboard", timeout=2)
            else:
                self.app.notify("Copy failed", severity="error", timeout=2)

    DEFAULT_CSS = """
    ChatMessage {
        margin: 0 0 0 0;
        padding: 0 1;
    }
    ChatMessage.user-message {
        background: #151525;
        color: #e8e8f0;
        padding: 1 2;
        margin: 1 0 0 0;
    }
    ChatMessage.tool-call {
        background: transparent;
        color: #5a5a7c;
        padding: 0 2 0 4;
        margin: 0;
    }
    ChatMessage.tool-result {
        background: transparent;
        color: #4a4a6c;
        padding: 0 2 0 4;
        margin: 0 0 0 0;
    }
    ChatMessage.tool-output {
        background: #0c0c18;
        color: #6a6a8c;
        padding: 0 2 0 6;
        margin: 0;
    }
    ChatMessage.error-message {
        background: #1a0808;
        color: #ff4466;
        padding: 1 2 1 2;
        margin: 0;
    }
    ChatMessage.system-message {
        color: #6a6a8c;
        padding: 0 2;
        margin: 0;
    }
    ChatMessage.divider {
        color: #1a1a2e;
        height: 1;
        margin: 0;
    }
    ChatMessage.copyable:hover {
        background: #12122a;
    }
    """


class AssistantMarkdown(Markdown):
    """Markdown widget styled for assistant responses with clickable code blocks."""

    COMPONENT_CLASSES = Markdown.COMPONENT_CLASSES

    def on_click(self, event: Click) -> None:
        """Copy code block to clipboard when a code fence is clicked."""
        try:
            widget, _ = self.screen.get_widget_at(event.screen_x, event.screen_y)
            # Walk up from the clicked widget to find a MarkdownFence
            target = widget
            while target is not None and target is not self:
                if type(target).__name__ == "MarkdownFence":
                    code = getattr(target, "code", "")
                    if code:
                        if copy_to_clipboard(code):
                            self.app.notify("Code copied!", timeout=2)
                        else:
                            self.app.notify("Copy failed", severity="error", timeout=2)
                    return
                target = target.parent
        except Exception:
            pass

    DEFAULT_CSS = """
    AssistantMarkdown {
        background: transparent;
        padding: 1 2 1 2;
        margin: 0 0 1 0;
    }

    AssistantMarkdown MarkdownH1 {
        color: #00e0e0;
        text-style: bold;
        margin: 1 0 0 0;
        padding: 0;
        background: transparent;
        border-bottom: none;
    }
    AssistantMarkdown MarkdownH2 {
        color: #00cccc;
        text-style: bold;
        margin: 1 0 0 0;
        padding: 0;
        background: transparent;
        border-bottom: none;
    }
    AssistantMarkdown MarkdownH3 {
        color: #00bbbb;
        text-style: bold;
        margin: 1 0 0 0;
        padding: 0;
        background: transparent;
    }

    AssistantMarkdown MarkdownParagraph {
        color: #c0c0d8;
        margin: 0 0;
    }

    AssistantMarkdown MarkdownBulletList {
        color: #c0c0d8;
        margin: 0 0 0 0;
        padding: 0 0 0 0;
    }
    AssistantMarkdown MarkdownOrderedList {
        color: #c0c0d8;
        margin: 0 0 0 0;
        padding: 0 0 0 0;
    }
    AssistantMarkdown MarkdownOrderedListItem {
        color: #c0c0d8;
    }
    AssistantMarkdown MarkdownBulletListItem {
        color: #c0c0d8;
    }

    AssistantMarkdown MarkdownFence {
        background: #0e0e1c;
        color: #a0d0a0;
        margin: 0 0 0 0;
        padding: 1 2;
        border: round #1e1e3a;
    }
    AssistantMarkdown MarkdownFence:hover {
        border: round #00ffff 50%;
    }
    AssistantMarkdown MarkdownBlockQuote {
        background: #101020;
        color: #8888aa;
        margin: 0 0;
        padding: 0 2;
        border-left: thick #333355;
    }

    AssistantMarkdown MarkdownTable {
        margin: 0 0;
    }

    AssistantMarkdown MarkdownHorizontalRule {
        color: #1a1a2e;
        margin: 1 0;
    }
    """


class ChatPanel(Widget):
    """Scrollable chat conversation panel."""

    DEFAULT_CSS = """
    ChatPanel {
        height: 1fr;
        background: #0a0a14;
        border: solid #1a1a2e;
    }

    ChatPanel #chat-scroll {
        height: 1fr;
    }
    """

    def compose(self) -> ComposeResult:
        yield VerticalScroll(id="chat-scroll")

    def add_user_message(self, text: str) -> None:
        """Add a user message to the chat."""
        content = Text()
        content.append("> ", style="bold #555577")
        content.append(text, style="#e0e0f0")
        self._append_message(ChatMessage(content, classes="user-message"))

    def add_assistant_text(self, text: str) -> None:
        """Add assistant markdown response to the chat."""
        md = AssistantMarkdown(text)
        self._append_widget(md)

    def add_tool_call(self, tool_name: str, tool_input: dict) -> None:
        """Show a compact tool invocation line. Click to copy the command."""
        device_id = tool_input.get("device_id", "")
        command = tool_input.get("command", "")
        commands = tool_input.get("commands", [])

        content = Text()
        copyable = ""

        if command:
            target = f" {device_id}" if device_id else ""
            content.append("  > ", style="#3a3a5c")
            content.append(f"{command}", style="#5577aa")
            content.append(target, style="#3a3a5c")
            content.append("  \u2398", style="dim #2a2a4c")
            copyable = command
        elif commands:
            content.append("  > ", style="#3a3a5c")
            content.append("config ", style="#7755aa")
            content.append(f"{device_id} ", style="#5577aa")
            content.append(f"({len(commands)} cmds)", style="#3a3a5c")
            content.append("  \u2398", style="dim #2a2a4c")
            copyable = "\n".join(commands)
        else:
            target = f" {device_id}" if device_id else ""
            content.append("  > ", style="#3a3a5c")
            content.append(f"{tool_name}", style="#5577aa")
            content.append(target, style="#3a3a5c")

        self._append_message(
            ChatMessage(content, classes="tool-call copyable", copyable_text=copyable)
        )

    def add_tool_result(self, tool_name: str, result: dict) -> None:
        """Show the result of a tool execution. Click to copy full output."""
        status = result.get("status", "unknown")
        if status == "error":
            error = result.get("error", "Unknown error")
            content = Text()
            content.append("  x ", style="bold #ff4466")
            content.append(f"{error}", style="#ff4466")
            self._append_message(ChatMessage(content, classes="error-message"))
        else:
            output = result.get("output", "")
            if output:
                lines = output.splitlines()
                if len(lines) > 8:
                    preview = "\n".join(lines[:4]) + f"\n  ... ({len(lines) - 6} more lines) ...\n" + "\n".join(lines[-2:])
                else:
                    preview = output

                content = Text()
                content.append(preview, style="#5a5a7c")
                content.append("\n  \u2398 click to copy", style="dim #2a2a4c")
                self._append_message(
                    ChatMessage(
                        content,
                        classes="tool-output copyable",
                        copyable_text=output,
                    )
                )

    def add_error(self, error: str) -> None:
        """Add an error message to the chat."""
        content = Text()
        content.append("error: ", style="bold #ff4466")
        content.append(error, style="#cc4455")
        self._append_message(ChatMessage(content, classes="error-message"))

    def add_system_message(self, text: str) -> None:
        """Add a system/info message to the chat."""
        content = Text()
        content.append("- ", style="#3a3a5c")
        content.append(text, style="#6a6a8c")
        self._append_message(ChatMessage(content, classes="system-message"))

    def add_divider(self) -> None:
        """Add a visual divider line."""
        self._append_message(
            ChatMessage("\u2500" * 32, classes="divider")
        )

    def _append_message(self, message: ChatMessage) -> None:
        """Append a plain-text message widget and scroll to bottom."""
        try:
            scroll = self.query_one("#chat-scroll", VerticalScroll)
            scroll.mount(message)
            scroll.scroll_end(animate=False)
        except Exception:
            pass

    def _append_widget(self, widget: Widget) -> None:
        """Append any widget and scroll to bottom."""
        try:
            scroll = self.query_one("#chat-scroll", VerticalScroll)
            scroll.mount(widget)
            scroll.scroll_end(animate=False)
        except Exception:
            pass

    def clear(self) -> None:
        """Clear all messages."""
        try:
            scroll = self.query_one("#chat-scroll", VerticalScroll)
            scroll.remove_children()
        except Exception:
            pass
