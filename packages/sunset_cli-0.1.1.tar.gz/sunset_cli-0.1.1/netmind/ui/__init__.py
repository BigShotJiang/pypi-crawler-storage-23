"""NetMind UI - Textual TUI application."""

from netmind.ui.app import NetMindApp

__all__ = ["NetMindApp"]
