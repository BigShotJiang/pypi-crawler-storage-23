"""Tool definition and registration system for Claude.

Defines the tools Claude can use and routes tool calls to
the appropriate handlers. Tools are defined in the Anthropic
tool-use schema format.
"""

from typing import Any, Callable

from netmind.utils import get_logger
from netmind.utils.secrets import redact_sensitive

logger = get_logger("agent.tool_registry")

# ──────────────────────────────────────────────────────────────────────
# Tool definitions in Anthropic API schema format
# ──────────────────────────────────────────────────────────────────────

TOOLS: list[dict[str, Any]] = [
    {
        "name": "execute_command",
        "description": (
            "Execute a show/read-only command on a network device. "
            "Use this to gather information about device state, interfaces, "
            "routing tables, OSPF neighbors, etc. This is a READ-ONLY operation "
            "and will not modify the device configuration."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": (
                        "Device identifier (e.g., 'R1', 'R2'). "
                        "Use list_devices to see available devices."
                    ),
                },
                "command": {
                    "type": "string",
                    "description": (
                        "IOS CLI command to execute (e.g., 'show ip interface brief', "
                        "'show ip ospf neighbor', 'show running-config | section ospf')"
                    ),
                },
            },
            "required": ["device_id", "command"],
        },
    },
    {
        "name": "execute_config_commands",
        "description": (
            "Execute configuration commands on a device. This WILL MODIFY the device "
            "configuration. Requires user approval before execution. A checkpoint is "
            "automatically created before changes for rollback capability. "
            "Commands should be provided as a list of IOS config-mode commands "
            "(do NOT include 'configure terminal' or 'end')."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
                "commands": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "List of IOS configuration commands to execute. "
                        "Example: ['router ospf 1', 'router-id 1.1.1.1', "
                        "'network 10.0.0.0 0.0.0.255 area 0']"
                    ),
                },
                "description": {
                    "type": "string",
                    "description": (
                        "Clear, human-readable description of what these commands do "
                        "and why. This is shown to the user for approval."
                    ),
                },
            },
            "required": ["device_id", "commands", "description"],
        },
    },
    {
        "name": "get_running_config",
        "description": (
            "Retrieve the full running configuration from a device. "
            "Useful for reviewing the complete device configuration or "
            "extracting specific sections."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "get_device_info",
        "description": (
            "Get device information including OS version, model, hostname, "
            "uptime, and serial number."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "list_devices",
        "description": (
            "List all connected network devices with their status, "
            "hostname, IP, OS version, and model. Call this first to "
            "see what devices are available."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "verify_ospf",
        "description": (
            "Run OSPF-specific verification on a device. Checks OSPF process status, "
            "neighbor adjacencies, and learned routes. Returns a structured health report."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "verify_bgp",
        "description": (
            "Run BGP-specific verification on a device. Checks BGP neighbor sessions, "
            "Established state, prefix counts, and route presence. Returns a structured "
            "health report with per-neighbor details."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "verify_eigrp",
        "description": (
            "Run EIGRP-specific verification on a device. Checks EIGRP neighbor "
            "adjacencies, topology table (active vs passive routes), and EIGRP routes. "
            "Returns a structured health report."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "verify_isis",
        "description": (
            "Run IS-IS verification on a device. Checks IS-IS neighbor adjacencies, "
            "LSDB entries, and IS-IS routes. Returns a structured health report."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "verify_mpls",
        "description": (
            "Run MPLS/LDP/RSVP verification on a device. Checks MPLS-enabled interfaces, "
            "LDP neighbor sessions, MPLS forwarding table, RSVP neighbors, and TE tunnels. "
            "Returns a structured health report."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    # ── Device management tools ────────────────────────────────────
    {
        "name": "add_device",
        "description": (
            "Add a new network device to the managed topology and establish an SSH "
            "connection. Use this when the user asks you to add, connect, or onboard "
            "a new device. The device must be reachable via SSH. On success the device "
            "becomes available for all other tools (execute_command, verify_ospf, etc.) "
            "and is added to the topology graph. Requires INTERACTIVE mode."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": (
                        "User-assigned identifier for the device (e.g., 'R3', 'SW1'). "
                        "Must be unique among existing devices."
                    ),
                },
                "host": {
                    "type": "string",
                    "description": "IP address or hostname of the device.",
                },
                "username": {
                    "type": "string",
                    "description": "SSH username for authentication.",
                },
                "password": {
                    "type": "string",
                    "description": "SSH password for authentication.",
                },
                "device_type": {
                    "type": "string",
                    "enum": [
                        "cisco_ios",
                        "cisco_xe",
                        "cisco_nxos",
                        "juniper_junos",
                        "arista_eos",
                    ],
                    "description": (
                        "Device platform type. Defaults to 'cisco_ios' if omitted."
                    ),
                },
                "port": {
                    "type": "integer",
                    "description": "SSH port (default 22).",
                },
                "enable_secret": {
                    "type": "string",
                    "description": (
                        "Enable/privilege password if the device requires one."
                    ),
                },
                "legacy_ssh": {
                    "type": "boolean",
                    "description": (
                        "Set to true for older devices that need legacy SSH algorithms "
                        "(e.g., diffie-hellman-group14-sha1, ssh-rsa). Use when SSH "
                        "connection fails with key exchange errors."
                    ),
                },
            },
            "required": ["device_id", "host", "username", "password"],
        },
    },
    # ── Topology tools ───────────────────────────────────────────
    {
        "name": "get_topology",
        "description": (
            "Get the full network topology including all devices, interfaces, "
            "links, subnets, OSPF areas, and an ASCII diagram. Call this first "
            "to understand the network layout before making any changes. "
            "This data comes from the inventory file — no SSH needed."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "get_device_interfaces",
        "description": (
            "Get all interfaces for a specific device from the topology data, "
            "including IP addresses, masks, descriptions, and what each interface "
            "is connected to. Also includes OSPF configuration if present."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier (e.g., 'R1')",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "get_neighbors",
        "description": (
            "Get all directly connected neighbors of a device from the topology, "
            "with the local and remote interface names and shared subnets."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_id": {
                    "type": "string",
                    "description": "Device identifier",
                },
            },
            "required": ["device_id"],
        },
    },
    {
        "name": "find_path",
        "description": (
            "Find the shortest path between two devices in the network topology. "
            "Returns the list of devices along the path and the connecting "
            "interfaces at each hop."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "source_device": {
                    "type": "string",
                    "description": "Source device identifier",
                },
                "target_device": {
                    "type": "string",
                    "description": "Target device identifier",
                },
            },
            "required": ["source_device", "target_device"],
        },
    },
    {
        "name": "get_ospf_topology",
        "description": (
            "Get the OSPF topology from inventory data: which areas exist, "
            "which devices are in each area, their router-IDs, network statements, "
            "and passive interfaces. Use this to plan or verify OSPF configuration."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "get_subnets",
        "description": (
            "Get all IP subnets in the network and which device:interface "
            "belongs to each. Useful for IP address planning and verification."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
]


class ToolRegistry:
    """Registry that maps tool names to handler functions.

    Handlers are registered at runtime and called when Claude
    invokes a tool. Each handler receives the tool input dict
    and a context dict containing shared resources.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, Callable] = {}

    def register(self, tool_name: str, handler: Callable) -> None:
        """Register a handler function for a tool name."""
        self._handlers[tool_name] = handler
        logger.debug("Registered tool handler: %s", tool_name)

    def get_tool_definitions(self) -> list[dict[str, Any]]:
        """Return tool definitions for the Claude API call."""
        return TOOLS

    async def execute(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute a tool by name with the given input.

        Args:
            tool_name: Name of the tool to execute.
            tool_input: Input parameters from Claude.
            context: Shared context (device_manager, safety_guard, etc.).

        Returns:
            Tool result dict to send back to Claude.
        """
        handler = self._handlers.get(tool_name)
        if handler is None:
            logger.error("Unknown tool: %s", tool_name)
            return {"error": f"Unknown tool: {tool_name}"}

        try:
            logger.info("Executing tool: %s(%s)", tool_name, redact_sensitive(tool_input))
            result = await handler(tool_input, context)
            return result
        except Exception as e:
            logger.error("Tool execution error (%s): %s", tool_name, e)
            return {"error": f"Tool execution failed: {str(e)}"}
