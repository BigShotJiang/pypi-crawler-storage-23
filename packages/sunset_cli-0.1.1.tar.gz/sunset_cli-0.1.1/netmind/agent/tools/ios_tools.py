"""IOS-specific tool handlers: command execution and configuration.

These handlers implement the core network interaction tools
that Claude uses to gather state and apply config changes.
"""

import json
from typing import Any

from netmind.agent.tool_registry import ToolRegistry
from netmind.core.device_manager import DeviceManager
from netmind.core.safety import ApprovalManager, CheckpointManager, SafetyGuard
from netmind.utils import get_logger, get_session_logger

logger = get_logger("agent.tools.ios")


async def handle_execute_command(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the execute_command tool - run show commands."""
    dm: DeviceManager = context["device_manager"]
    guard: SafetyGuard = context["safety_guard"]

    device_id = tool_input["device_id"]
    command = tool_input["command"]

    slog = get_session_logger()

    # Safety check
    allowed, reason = guard.can_execute_show(command)
    if not allowed:
        slog.log_safety_check("show_command", False, reason, command=command)
        return {"status": "error", "error": reason}

    slog.log_safety_check("show_command", True, command=command)
    result = dm.execute_on_device(device_id, command)
    return result.to_tool_result()


async def handle_execute_config_commands(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the execute_config_commands tool - apply config changes.

    This tool triggers the approval flow:
    1. Check safety guard (read-only mode check)
    2. Validate commands for dangerous patterns
    3. Create a checkpoint
    4. Create an approval request
    5. Return the approval request ID (UI handles the rest)

    The actual execution happens after the user approves via the UI.
    """
    dm: DeviceManager = context["device_manager"]
    guard: SafetyGuard = context["safety_guard"]
    approval_mgr: ApprovalManager = context["approval_manager"]
    checkpoint_mgr: CheckpointManager = context["checkpoint_manager"]

    device_id = tool_input["device_id"]
    commands = tool_input["commands"]
    description = tool_input["description"]

    slog = get_session_logger()

    # Safety check - is config allowed?
    allowed, reason = guard.can_execute_config(commands)
    if not allowed:
        slog.log_safety_check("config_commands", False, reason, commands=commands)
        return {"status": "error", "error": reason}

    slog.log_safety_check("config_commands", True, commands=commands)

    # Validate commands for dangerous patterns
    valid, warnings = guard.validate_commands(commands)

    # Get device connection
    conn = dm.get_device(device_id)
    if conn is None:
        return {
            "status": "error",
            "error": f"Device '{device_id}' not found. Available: {', '.join(dm.get_device_ids())}",
        }

    # Create checkpoint before changes
    checkpoint = checkpoint_mgr.create_checkpoint(conn, description=description)
    checkpoint_name = checkpoint.name if checkpoint else None

    if checkpoint is None:
        logger.warning("Could not create checkpoint for %s - proceeding anyway", device_id)
        slog.log_checkpoint(device_id, "N/A", "create", False)
    else:
        slog.log_checkpoint(device_id, checkpoint_name, "create", True)

    # Create approval request
    request = approval_mgr.request_approval(
        device_id=device_id,
        commands=commands,
        description=description,
        checkpoint_name=checkpoint_name,
    )
    slog.log_approval(request.request_id, device_id, "requested", commands, description)

    # Signal the UI that approval is needed
    # The callback will be invoked by the UI layer
    approval_callback = context.get("approval_callback")
    if approval_callback:
        await approval_callback(request)

    # After callback returns, check the request status
    if request.is_approved:
        slog.log_approval(request.request_id, device_id, "approved", commands, description)
        # Execute the config
        result = dm.execute_config_on_device(device_id, commands)
        if result.success:
            return {
                "status": "success",
                "device_id": device_id,
                "message": f"Configuration applied successfully on {device_id}",
                "output": result.output,
                "checkpoint": checkpoint_name,
                "warnings": warnings if warnings else None,
            }
        else:
            # Config failed - offer rollback info
            return {
                "status": "error",
                "device_id": device_id,
                "error": f"Configuration failed: {result.error}",
                "checkpoint": checkpoint_name,
                "message": "A checkpoint was created before the change. Rollback is available.",
            }
    else:
        slog.log_approval(request.request_id, device_id, "rejected", commands, description)
        return {
            "status": "rejected",
            "device_id": device_id,
            "message": "Configuration was rejected by the user.",
            "commands": commands,
        }


async def handle_get_running_config(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the get_running_config tool."""
    dm: DeviceManager = context["device_manager"]
    device_id = tool_input["device_id"]

    conn = dm.get_device(device_id)
    if conn is None:
        return {
            "status": "error",
            "error": f"Device '{device_id}' not found",
        }

    try:
        config = conn.get_running_config()
        return {
            "status": "success",
            "device_id": device_id,
            "config": config,
        }
    except Exception as e:
        return {
            "status": "error",
            "device_id": device_id,
            "error": str(e),
        }


def register_ios_tools(registry: ToolRegistry) -> None:
    """Register IOS-specific tool handlers."""
    registry.register("execute_command", handle_execute_command)
    registry.register("execute_config_commands", handle_execute_config_commands)
    registry.register("get_running_config", handle_get_running_config)
