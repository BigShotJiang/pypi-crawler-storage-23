"""Main Claude API integration - the brain of NetMind.

Orchestrates the conversation loop: user message → Claude response →
tool execution → Claude continuation → ... until Claude finishes.
Supports streaming for real-time UI updates.
"""

import asyncio
import json
import time
from typing import Any, AsyncGenerator, Callable, Coroutine, Optional

import anthropic

from netmind.agent.conversation import ConversationManager
from netmind.agent.system_prompt import get_system_prompt
from netmind.agent.tool_registry import ToolRegistry
from netmind.agent.tools import register_all_tools
from netmind.core.device_manager import DeviceManager
from netmind.core.safety import ApprovalManager, CheckpointManager, SafetyGuard
from netmind.models import ApprovalRequest
from netmind.utils import get_config, get_logger, get_session_logger
from netmind.utils.secrets import redact_sensitive

logger = get_logger("agent.claude")


# Event types yielded to the UI during streaming
class AgentEvent:
    """Base class for events the agent yields to the UI."""
    pass


class TextEvent(AgentEvent):
    """A chunk of text from Claude's response."""

    def __init__(self, text: str) -> None:
        self.text = text

    def __repr__(self) -> str:
        return f"TextEvent({self.text!r})"


class ToolCallEvent(AgentEvent):
    """Claude is invoking a tool."""

    def __init__(self, tool_name: str, tool_input: dict[str, Any]) -> None:
        self.tool_name = tool_name
        self.tool_input = tool_input

    def __repr__(self) -> str:
        return f"ToolCallEvent({self.tool_name}, {self.tool_input})"


class ToolResultEvent(AgentEvent):
    """Result from a tool execution."""

    def __init__(self, tool_name: str, result: dict[str, Any]) -> None:
        self.tool_name = tool_name
        self.result = result

    def __repr__(self) -> str:
        return f"ToolResultEvent({self.tool_name})"


class ApprovalRequiredEvent(AgentEvent):
    """Config change requires user approval."""

    def __init__(self, request: ApprovalRequest) -> None:
        self.request = request

    def __repr__(self) -> str:
        return f"ApprovalRequiredEvent({self.request.request_id})"


class ErrorEvent(AgentEvent):
    """An error occurred during agent processing."""

    def __init__(self, error: str) -> None:
        self.error = error

    def __repr__(self) -> str:
        return f"ErrorEvent({self.error!r})"


class DoneEvent(AgentEvent):
    """Agent has finished processing."""

    def __init__(self, full_response: str = "") -> None:
        self.full_response = full_response

    def __repr__(self) -> str:
        return "DoneEvent()"


# Type for the approval callback
ApprovalCallback = Callable[[ApprovalRequest], Coroutine[Any, Any, None]]


class ClaudeAgent:
    """The main Claude-powered agent that orchestrates network automation.

    This class manages the conversation with Claude, handles tool calls,
    and coordinates with the device manager and safety systems.
    """

    def __init__(
        self,
        device_manager: DeviceManager,
        safety_guard: SafetyGuard,
        approval_manager: ApprovalManager,
        checkpoint_manager: CheckpointManager,
        approval_callback: Optional[ApprovalCallback] = None,
        topology: Optional[Any] = None,
    ) -> None:
        self._config = get_config()

        # Anthropic client
        self._client = anthropic.AsyncAnthropic(api_key=self._config.anthropic_api_key)

        # Core components
        self.device_manager = device_manager
        self.safety_guard = safety_guard
        self.approval_manager = approval_manager
        self.checkpoint_manager = checkpoint_manager

        # Conversation
        self.conversation = ConversationManager(
            max_messages=self._config.max_conversation_history,
        )

        # Tool registry
        self.tool_registry = ToolRegistry()
        register_all_tools(self.tool_registry)

        # Topology model (populated from inventory)
        self.topology = topology

        # Approval callback (set by UI)
        self._approval_callback = approval_callback

        logger.info(
            "ClaudeAgent initialized (model=%s, read_only=%s)",
            self._config.claude_model,
            self.safety_guard.read_only,
        )

    def set_approval_callback(self, callback: ApprovalCallback) -> None:
        """Set the callback for handling approval requests from the UI."""
        self._approval_callback = callback

    def _get_tool_context(self) -> dict[str, Any]:
        """Build the context dict passed to tool handlers."""
        return {
            "device_manager": self.device_manager,
            "safety_guard": self.safety_guard,
            "approval_manager": self.approval_manager,
            "checkpoint_manager": self.checkpoint_manager,
            "approval_callback": self._approval_callback,
            "topology": self.topology,
        }

    async def process_message(
        self, user_message: str
    ) -> AsyncGenerator[AgentEvent, None]:
        """Process a user message and yield events as Claude responds.

        This is the main entry point for the conversation loop:
        1. Add user message to history
        2. Call Claude API with tools
        3. Yield text/tool events as they come
        4. If tool calls, execute them and continue the loop
        5. Repeat until Claude sends a final text-only response

        Yields:
            AgentEvent instances (TextEvent, ToolCallEvent, etc.)
        """
        slog = get_session_logger()
        slog.log_user_message(user_message)
        self.conversation.add_user_message(user_message)

        system_prompt = get_system_prompt(read_only=self.safety_guard.read_only)

        # Agentic loop - Claude may call tools multiple times
        max_iterations = 20  # Safety limit
        iteration = 0

        while iteration < max_iterations:
            iteration += 1
            logger.debug("Agent loop iteration %d", iteration)

            try:
                # Call Claude API
                api_start = time.monotonic()
                messages = self.conversation.get_messages()

                response = await self._client.messages.create(
                    model=self._config.claude_model,
                    max_tokens=4096,
                    system=system_prompt,
                    tools=self.tool_registry.get_tool_definitions(),
                    messages=messages,
                )

                api_elapsed = (time.monotonic() - api_start) * 1000

                # Log API call with token usage
                slog.log_api_call(
                    model=self._config.claude_model,
                    messages_count=len(messages),
                    elapsed_ms=api_elapsed,
                    input_tokens=getattr(response.usage, "input_tokens", 0),
                    output_tokens=getattr(response.usage, "output_tokens", 0),
                )

                # Process response content blocks
                assistant_content: list[dict[str, Any]] = []
                tool_calls: list[dict[str, Any]] = []
                full_text_parts: list[str] = []

                for block in response.content:
                    if block.type == "text":
                        text = block.text
                        full_text_parts.append(text)
                        assistant_content.append({
                            "type": "text",
                            "text": text,
                        })
                        slog.log_agent_text(text)
                        yield TextEvent(text)

                    elif block.type == "tool_use":
                        # Store redacted input in conversation so API never receives secrets
                        tool_call_for_conversation = {
                            "type": "tool_use",
                            "id": block.id,
                            "name": block.name,
                            "input": redact_sensitive(block.input),
                        }
                        assistant_content.append(tool_call_for_conversation)
                        tool_calls.append({
                            "type": "tool_use",
                            "id": block.id,
                            "name": block.name,
                            "input": block.input,
                        })
                        slog.log_tool_call(block.name, block.input)
                        yield ToolCallEvent(block.name, block.input)

                # Add assistant's response to conversation
                self.conversation.add_assistant_message(assistant_content)

                # Log iteration summary
                slog.log_agent_iteration(iteration, tool_calls_count=len(tool_calls))

                # If no tool calls, we're done
                if not tool_calls:
                    full_text = "\n".join(full_text_parts)
                    slog.log_agent_done(full_text)
                    yield DoneEvent(full_response=full_text)
                    return

                # Execute tool calls and add results
                for tool_call in tool_calls:
                    tool_name = tool_call["name"]
                    tool_input = tool_call["input"]
                    tool_id = tool_call["id"]

                    logger.info("Executing tool: %s", tool_name)

                    # Check if this is a config tool that needs approval
                    if tool_name == "execute_config_commands" and self._approval_callback:
                        # The approval flow is handled inside the tool handler
                        pass

                    tool_start = time.monotonic()
                    result = await self.tool_registry.execute(
                        tool_name,
                        tool_input,
                        self._get_tool_context(),
                    )
                    tool_elapsed = (time.monotonic() - tool_start) * 1000

                    slog.log_tool_result(tool_name, result, elapsed_ms=tool_elapsed)
                    yield ToolResultEvent(tool_name, result)

                    # Add tool result to conversation
                    is_error = result.get("status") == "error" if isinstance(result, dict) else False
                    self.conversation.add_tool_result(tool_id, result, is_error=is_error)

                # Continue the loop - Claude will process tool results

            except anthropic.APIConnectionError as e:
                error_msg = f"Cannot connect to Claude API: {e}"
                logger.error(error_msg)
                slog.log_error("api_connection", error_msg)
                yield ErrorEvent(error_msg)
                return

            except anthropic.AuthenticationError:
                error_msg = "Invalid API key. Check your ANTHROPIC_API_KEY."
                logger.error(error_msg)
                slog.log_error("api_auth", error_msg)
                yield ErrorEvent(error_msg)
                return

            except anthropic.RateLimitError:
                error_msg = "Rate limited by Claude API. Please wait a moment."
                logger.error(error_msg)
                slog.log_error("api_rate_limit", error_msg)
                yield ErrorEvent(error_msg)
                return

            except anthropic.APIError as e:
                error_msg = f"Claude API error: {e}"
                logger.error(error_msg)
                slog.log_error("api_error", error_msg)
                yield ErrorEvent(error_msg)
                return

            except Exception as e:
                error_msg = f"Unexpected error: {e}"
                logger.error(error_msg, exc_info=True)
                slog.log_error("unexpected", error_msg, {"traceback": str(e)})
                yield ErrorEvent(error_msg)
                return

        # Safety limit reached
        slog.log_error("iteration_limit", "Maximum tool call iterations reached")
        yield ErrorEvent("Maximum tool call iterations reached. Please try a simpler request.")
        yield DoneEvent()

    async def process_message_simple(self, user_message: str) -> str:
        """Process a message and return the final text response.

        Simpler interface for non-streaming use cases (testing, etc.).
        """
        full_text = ""
        async for event in self.process_message(user_message):
            if isinstance(event, TextEvent):
                full_text += event.text
            elif isinstance(event, ErrorEvent):
                return f"Error: {event.error}"
            elif isinstance(event, DoneEvent):
                break
        return full_text

    def clear_conversation(self) -> None:
        """Clear the conversation history."""
        self.conversation.clear()
        logger.info("Conversation cleared")

    @property
    def read_only(self) -> bool:
        return self.safety_guard.read_only

    @read_only.setter
    def read_only(self, value: bool) -> None:
        self.safety_guard.read_only = value
        mode = "READ-ONLY" if value else "INTERACTIVE"
        logger.info("Mode changed to %s", mode)
