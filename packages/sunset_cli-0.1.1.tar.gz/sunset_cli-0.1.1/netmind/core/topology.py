"""Network topology model.

Builds a graph from the inventory data (interfaces, links, OSPF config)
and provides query methods for Claude to reason about the network.
"""

from collections import defaultdict, deque
from typing import Any, Dict, List, Optional, Set, Tuple

from pydantic import BaseModel, Field

from netmind.utils.logger import get_logger

logger = get_logger("core.topology")


# ── Data models ──────────────────────────────────────────────────────


class InterfaceInfo(BaseModel):
    """A single interface on a device."""

    name: str = Field(description="Interface name, e.g. GigabitEthernet0/0")
    ip: Optional[str] = Field(default=None, description="IP address")
    mask: Optional[str] = Field(default=None, description="Subnet mask")
    cidr: Optional[int] = Field(default=None, description="CIDR prefix length")
    description: Optional[str] = Field(default=None)
    enabled: bool = Field(default=True)
    connected_to: Optional[str] = Field(
        default=None,
        description="Link target: 'DEVICE_ID:INTERFACE_NAME' or 'DEVICE_ID'",
    )
    vlan: Optional[int] = Field(default=None)
    speed: Optional[str] = Field(default=None)
    duplex: Optional[str] = Field(default=None)
    shutdown: bool = Field(default=False)

    @property
    def subnet(self) -> Optional[str]:
        """Return the subnet in CIDR notation if IP is set."""
        if self.ip and self.cidr is not None:
            return f"{self.ip}/{self.cidr}"
        return None


class OSPFArea(BaseModel):
    """An OSPF area with its associated networks."""

    area_id: int = Field(description="OSPF area ID (0 = backbone)")
    networks: List[Dict[str, str]] = Field(
        default_factory=list,
        description="List of {network, wildcard} dicts",
    )


class OSPFConfig(BaseModel):
    """OSPF configuration for a device."""

    process_id: int = Field(default=1, description="OSPF process ID")
    router_id: Optional[str] = Field(default=None, description="Explicit router-id")
    areas: List[OSPFArea] = Field(default_factory=list)
    passive_interfaces: List[str] = Field(default_factory=list)
    default_information_originate: bool = Field(default=False)
    redistribute: List[str] = Field(default_factory=list)


class TopologyNode(BaseModel):
    """A node in the topology graph (represents a device)."""

    device_id: str
    host: Optional[str] = None
    device_type: str = "cisco_ios"
    interfaces: List[InterfaceInfo] = Field(default_factory=list)
    ospf: Optional[OSPFConfig] = None
    loopback_ip: Optional[str] = Field(
        default=None, description="Primary loopback IP (Loopback0)"
    )
    role: Optional[str] = Field(
        default=None, description="Device role: router, switch, firewall, etc."
    )
    site: Optional[str] = Field(default=None, description="Physical site/location")

    def get_interface(self, name: str) -> Optional[InterfaceInfo]:
        """Find an interface by name (case-insensitive partial match)."""
        name_lower = name.lower()
        for iface in self.interfaces:
            if iface.name.lower() == name_lower:
                return iface
        # Try partial match (e.g. "gi0/0" matches "GigabitEthernet0/0")
        for iface in self.interfaces:
            if name_lower in iface.name.lower():
                return iface
        return None

    @property
    def management_ip(self) -> Optional[str]:
        """Best management IP: host > loopback > first interface IP."""
        if self.host:
            return self.host
        if self.loopback_ip:
            return self.loopback_ip
        for iface in self.interfaces:
            if iface.ip:
                return iface.ip
        return None


class TopologyLink(BaseModel):
    """A link between two device interfaces."""

    source_device: str
    source_interface: str
    target_device: str
    target_interface: str
    subnet: Optional[str] = Field(default=None, description="Shared subnet")
    description: Optional[str] = None
    link_type: str = Field(
        default="ethernet", description="ethernet, serial, tunnel, etc."
    )
    ospf_area: Optional[int] = Field(
        default=None, description="OSPF area this link belongs to"
    )

    @property
    def label(self) -> str:
        """Human-readable link label."""
        return (
            f"{self.source_device}:{self.source_interface} <-> "
            f"{self.target_device}:{self.target_interface}"
        )

    @property
    def endpoints(self) -> Tuple[str, str]:
        """Device IDs at each end, sorted for consistent comparison."""
        return tuple(sorted([self.source_device, self.target_device]))


# ── Topology engine ──────────────────────────────────────────────────


class NetworkTopology:
    """Graph-based network topology model.

    Provides:
    - Node and link storage
    - Neighbor lookups
    - Shortest path calculation (BFS)
    - Subnet analysis
    - OSPF area mapping
    - ASCII topology diagram generation
    - Full topology summary for Claude's context
    """

    def __init__(self) -> None:
        self._nodes: Dict[str, TopologyNode] = {}
        self._links: List[TopologyLink] = []
        # Adjacency: device_id -> set of neighbor device_ids
        self._adjacency: Dict[str, Set[str]] = defaultdict(set)
        # Interface-level adjacency: (device, iface) -> (device, iface)
        self._iface_adj: Dict[Tuple[str, str], Tuple[str, str]] = {}

    # ── Build methods ────────────────────────────────────────────

    def add_node(self, node: TopologyNode) -> None:
        """Add a device node to the topology."""
        self._nodes[node.device_id] = node
        logger.debug("Topology: added node %s", node.device_id)

    def add_link(self, link: TopologyLink) -> None:
        """Add a link and update adjacency maps."""
        self._links.append(link)
        self._adjacency[link.source_device].add(link.target_device)
        self._adjacency[link.target_device].add(link.source_device)
        self._iface_adj[(link.source_device, link.source_interface)] = (
            link.target_device,
            link.target_interface,
        )
        self._iface_adj[(link.target_device, link.target_interface)] = (
            link.source_device,
            link.source_interface,
        )
        logger.debug("Topology: added link %s", link.label)

    def build_links_from_interfaces(self) -> int:
        """Infer links from interface `connected_to` fields.

        Scans all nodes' interfaces for `connected_to` references
        and creates TopologyLink entries. Avoids duplicate links.

        Returns:
            Number of links created.
        """
        seen: Set[Tuple[str, str, str, str]] = set()
        created = 0

        for device_id, node in self._nodes.items():
            for iface in node.interfaces:
                if not iface.connected_to:
                    continue

                target = self._parse_connected_to(iface.connected_to)
                if target is None:
                    logger.warning(
                        "%s:%s — cannot parse connected_to: %s",
                        device_id,
                        iface.name,
                        iface.connected_to,
                    )
                    continue

                target_device, target_iface = target

                # Skip if target device doesn't exist
                if target_device not in self._nodes:
                    logger.warning(
                        "%s:%s connected_to unknown device: %s",
                        device_id,
                        iface.name,
                        target_device,
                    )
                    continue

                # Deduplicate (A->B same as B->A)
                key = tuple(sorted([
                    (device_id, iface.name),
                    (target_device, target_iface),
                ]))
                flat_key = (key[0][0], key[0][1], key[1][0], key[1][1])
                if flat_key in seen:
                    continue
                seen.add(flat_key)

                # Determine subnet
                subnet = iface.subnet

                link = TopologyLink(
                    source_device=device_id,
                    source_interface=iface.name,
                    target_device=target_device,
                    target_interface=target_iface,
                    subnet=subnet,
                    description=iface.description,
                )
                self.add_link(link)
                created += 1

        logger.info("Built %d links from interface connected_to fields", created)
        return created

    def build_from_inventory(
        self,
        nodes: List[TopologyNode],
        explicit_links: Optional[List[TopologyLink]] = None,
    ) -> None:
        """Build topology from parsed inventory data.

        Args:
            nodes: List of TopologyNode objects.
            explicit_links: Optional explicit link definitions from YAML.
        """
        for node in nodes:
            self.add_node(node)

        # Add explicit links first
        if explicit_links:
            for link in explicit_links:
                self.add_link(link)

        # Then infer links from interface connected_to fields
        self.build_links_from_interfaces()

        logger.info(
            "Topology built: %d nodes, %d links",
            len(self._nodes),
            len(self._links),
        )

    # ── Query methods ────────────────────────────────────────────

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def link_count(self) -> int:
        return len(self._links)

    def get_node(self, device_id: str) -> Optional[TopologyNode]:
        """Get a topology node by device ID."""
        return self._nodes.get(device_id)

    def get_all_nodes(self) -> List[TopologyNode]:
        """Get all topology nodes."""
        return list(self._nodes.values())

    def get_all_links(self) -> List[TopologyLink]:
        """Get all topology links."""
        return list(self._links)

    def get_neighbors(self, device_id: str) -> List[Dict[str, Any]]:
        """Get neighbors of a device with link details.

        Returns:
            List of dicts with neighbor info and connecting interfaces.
        """
        neighbors = []
        for link in self._links:
            if link.source_device == device_id:
                neighbors.append({
                    "neighbor_id": link.target_device,
                    "local_interface": link.source_interface,
                    "remote_interface": link.target_interface,
                    "subnet": link.subnet,
                    "link_type": link.link_type,
                })
            elif link.target_device == device_id:
                neighbors.append({
                    "neighbor_id": link.source_device,
                    "local_interface": link.target_interface,
                    "remote_interface": link.source_interface,
                    "subnet": link.subnet,
                    "link_type": link.link_type,
                })
        return neighbors

    def get_device_interfaces(self, device_id: str) -> Optional[List[Dict[str, Any]]]:
        """Get all interfaces for a device with connection info.

        Returns:
            List of interface dicts, or None if device not found.
        """
        node = self._nodes.get(device_id)
        if node is None:
            return None

        interfaces = []
        for iface in node.interfaces:
            iface_dict: Dict[str, Any] = {
                "name": iface.name,
                "ip": iface.ip,
                "mask": iface.mask,
                "cidr": iface.cidr,
                "description": iface.description,
                "enabled": iface.enabled,
                "shutdown": iface.shutdown,
            }

            # Add remote end info
            remote = self._iface_adj.get((device_id, iface.name))
            if remote:
                iface_dict["connected_to_device"] = remote[0]
                iface_dict["connected_to_interface"] = remote[1]
            else:
                iface_dict["connected_to_device"] = None
                iface_dict["connected_to_interface"] = None

            interfaces.append(iface_dict)

        return interfaces

    def get_ospf_summary(self) -> Dict[str, Any]:
        """Get OSPF configuration summary across all devices.

        Returns:
            Dict with area-level and device-level OSPF info.
        """
        areas: Dict[int, List[str]] = defaultdict(list)
        devices_ospf = {}

        for device_id, node in self._nodes.items():
            if node.ospf is None:
                continue

            ospf_info: Dict[str, Any] = {
                "process_id": node.ospf.process_id,
                "router_id": node.ospf.router_id,
                "areas": [],
                "passive_interfaces": node.ospf.passive_interfaces,
            }

            for area in node.ospf.areas:
                areas[area.area_id].append(device_id)
                area_info = {
                    "area_id": area.area_id,
                    "networks": area.networks,
                }
                ospf_info["areas"].append(area_info)

            devices_ospf[device_id] = ospf_info

        return {
            "ospf_areas": {
                area_id: sorted(members)
                for area_id, members in sorted(areas.items())
            },
            "devices": devices_ospf,
        }

    def find_path(
        self, source: str, target: str
    ) -> Optional[List[str]]:
        """Find shortest path between two devices (BFS).

        Args:
            source: Source device ID.
            target: Target device ID.

        Returns:
            List of device IDs forming the path, or None if no path exists.
        """
        if source not in self._nodes or target not in self._nodes:
            return None

        if source == target:
            return [source]

        visited: Set[str] = {source}
        queue: deque[List[str]] = deque([[source]])

        while queue:
            path = queue.popleft()
            current = path[-1]

            for neighbor in self._adjacency.get(current, set()):
                if neighbor == target:
                    return path + [neighbor]
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(path + [neighbor])

        return None

    def get_subnets(self) -> Dict[str, List[Dict[str, str]]]:
        """Get all subnets and which device:interface belongs to each.

        Returns:
            Dict mapping subnet string to list of {device, interface, ip} dicts.
        """
        subnets: Dict[str, List[Dict[str, str]]] = defaultdict(list)

        for device_id, node in self._nodes.items():
            for iface in node.interfaces:
                if iface.ip and iface.cidr is not None:
                    subnet_key = self._calculate_network(
                        iface.ip, iface.cidr
                    )
                    subnets[subnet_key].append({
                        "device": device_id,
                        "interface": iface.name,
                        "ip": iface.ip,
                    })

        return dict(subnets)

    # ── Display methods ──────────────────────────────────────────

    def get_topology_summary(self) -> Dict[str, Any]:
        """Full topology summary for Claude's context window.

        Returns a comprehensive dict covering nodes, links, subnets,
        OSPF areas, and an ASCII diagram.
        """
        nodes_summary = []
        for node in self._nodes.values():
            node_dict: Dict[str, Any] = {
                "device_id": node.device_id,
                "host": node.host,
                "device_type": node.device_type,
                "role": node.role,
                "site": node.site,
                "interfaces": [
                    {
                        "name": i.name,
                        "ip": i.ip,
                        "mask": i.mask,
                        "description": i.description,
                        "shutdown": i.shutdown,
                    }
                    for i in node.interfaces
                ],
            }
            if node.ospf:
                node_dict["ospf"] = {
                    "process_id": node.ospf.process_id,
                    "router_id": node.ospf.router_id,
                    "areas": [
                        {"area_id": a.area_id, "networks": a.networks}
                        for a in node.ospf.areas
                    ],
                }
            nodes_summary.append(node_dict)

        links_summary = [
            {
                "source": f"{l.source_device}:{l.source_interface}",
                "target": f"{l.target_device}:{l.target_interface}",
                "subnet": l.subnet,
                "ospf_area": l.ospf_area,
            }
            for l in self._links
        ]

        return {
            "node_count": len(self._nodes),
            "link_count": len(self._links),
            "nodes": nodes_summary,
            "links": links_summary,
            "subnets": self.get_subnets(),
            "ospf": self.get_ospf_summary(),
            "diagram": self.generate_ascii_diagram(),
        }

    def generate_ascii_diagram(self) -> str:
        """Generate a text-based topology diagram.

        Produces a readable ASCII representation of the network.
        """
        if not self._nodes:
            return "(empty topology)"

        lines = []
        lines.append("╔══════════════════════════════════════════╗")
        lines.append("║         NETWORK TOPOLOGY DIAGRAM         ║")
        lines.append("╚══════════════════════════════════════════╝")
        lines.append("")

        # List nodes with their interfaces
        for device_id, node in sorted(self._nodes.items()):
            role_tag = f" [{node.role}]" if node.role else ""
            site_tag = f" @{node.site}" if node.site else ""
            host_tag = f" ({node.host})" if node.host else ""
            lines.append(f"  ┌─ {device_id}{role_tag}{site_tag}{host_tag}")

            for iface in node.interfaces:
                ip_str = f" {iface.ip}/{iface.cidr}" if iface.ip else ""
                desc = f"  # {iface.description}" if iface.description else ""
                shut = " [SHUTDOWN]" if iface.shutdown else ""
                lines.append(f"  │  ├─ {iface.name}{ip_str}{shut}{desc}")

            if node.ospf:
                rid = node.ospf.router_id or "auto"
                area_ids = [str(a.area_id) for a in node.ospf.areas]
                lines.append(
                    f"  │  └─ OSPF pid:{node.ospf.process_id} "
                    f"rid:{rid} areas:[{','.join(area_ids)}]"
                )
            lines.append("  │")

        lines.append("")
        lines.append("  ── LINKS ──")

        if not self._links:
            lines.append("  (no links defined)")
        else:
            for link in self._links:
                subnet_str = f" [{link.subnet}]" if link.subnet else ""
                area_str = f" area:{link.ospf_area}" if link.ospf_area is not None else ""
                lines.append(
                    f"  {link.source_device}:{link.source_interface}"
                    f" ←──→ "
                    f"{link.target_device}:{link.target_interface}"
                    f"{subnet_str}{area_str}"
                )

        return "\n".join(lines)

    # ── Helpers ──────────────────────────────────────────────────

    @staticmethod
    def _parse_connected_to(value: str) -> Optional[Tuple[str, str]]:
        """Parse 'DEVICE:INTERFACE' or just 'DEVICE'.

        Returns:
            (device_id, interface_name) or None if invalid.
        """
        if not value or not isinstance(value, str):
            return None

        if ":" in value:
            parts = value.split(":", 1)
            return (parts[0].strip(), parts[1].strip())
        else:
            return (value.strip(), "unknown")

    @staticmethod
    def _calculate_network(ip: str, cidr: int) -> str:
        """Calculate network address from IP and CIDR."""
        try:
            parts = [int(x) for x in ip.split(".")]
            mask_int = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
            ip_int = (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]
            net_int = ip_int & mask_int
            net_parts = [
                (net_int >> 24) & 0xFF,
                (net_int >> 16) & 0xFF,
                (net_int >> 8) & 0xFF,
                net_int & 0xFF,
            ]
            return f"{'.'.join(str(x) for x in net_parts)}/{cidr}"
        except (ValueError, IndexError):
            return f"{ip}/{cidr}"

    @staticmethod
    def mask_to_cidr(mask: str) -> int:
        """Convert dotted subnet mask to CIDR prefix length."""
        try:
            parts = [int(x) for x in mask.split(".")]
            bits = sum(bin(x).count("1") for x in parts)
            return bits
        except (ValueError, IndexError):
            return 24  # safe default

    @staticmethod
    def mask_to_wildcard(mask: str) -> str:
        """Convert dotted subnet mask to wildcard mask."""
        try:
            parts = [int(x) for x in mask.split(".")]
            return ".".join(str(255 - x) for x in parts)
        except (ValueError, IndexError):
            return "0.0.0.255"
