"""Safety mechanisms: approval flows, checkpoints, rollback, guard rails.

This module implements the safety-first philosophy of NetMind:
- Read-only mode enforcement
- Dangerous command detection
- Config checkpoints before changes
- Approval flow for config modifications
- Rollback on failure
"""

import re
from typing import Optional

from netmind.core.device_connection import DeviceConnection
from netmind.models import ApprovalRequest, ApprovalStatus, Checkpoint
from netmind.utils import get_config, get_logger

logger = get_logger("core.safety")

# Commands that are always blocked (even in interactive mode)
BLOCKED_COMMANDS = [
    r"^reload$",
    r"^erase\s+",
    r"^delete\s+",
    r"^format\s+",
    r"^squeeze\s+",
    r"^write\s+erase",
]

# Commands that require extra caution / warning
DANGEROUS_PATTERNS = [
    (r"no\s+ip\s+address", "Removing IP address can cause loss of connectivity"),
    (r"no\s+interface", "Removing interface configuration"),
    (r"shutdown", "Shutting down an interface"),
    (r"no\s+router\s+", "Removing an entire routing process"),
    (r"default\s+interface", "Resetting interface to defaults"),
    (r"no\s+ip\s+route\s+0\.0\.0\.0", "Removing default route"),
    (r"no\s+enable", "Removing enable password"),
    (r"no\s+username", "Removing user account"),
]


class SafetyGuard:
    """Enforces safety policies on command execution.

    Attributes:
        read_only: When True, all config commands are blocked.
    """

    def __init__(self, read_only: bool = True) -> None:
        self.read_only = read_only

    def can_execute_show(self, command: str) -> tuple[bool, str]:
        """Check if a show/read command can be executed.

        Show commands are always allowed, but we verify the command
        isn't sneaking in config via tricks.
        """
        cmd = command.strip().lower()

        # Block obvious config attempts disguised as show commands
        if any(cmd.startswith(prefix) for prefix in ["conf", "config"]):
            return False, "Configuration commands not allowed via execute_command"

        return True, ""

    def can_execute_config(self, commands: list[str]) -> tuple[bool, str]:
        """Check if config commands are allowed.

        Returns:
            (allowed, reason) tuple. If not allowed, reason explains why.
        """
        if self.read_only:
            return False, (
                "Read-only mode is active. Toggle to interactive mode "
                "to allow configuration changes."
            )

        # Check for blocked commands
        for cmd in commands:
            cmd_stripped = cmd.strip().lower()
            for pattern in BLOCKED_COMMANDS:
                if re.match(pattern, cmd_stripped):
                    return False, f"Command blocked for safety: '{cmd.strip()}'"

        return True, ""

    def validate_commands(self, commands: list[str]) -> tuple[bool, list[str]]:
        """Validate commands and return warnings for dangerous operations.

        Returns:
            (valid, warnings) - valid is True if commands pass validation,
            warnings lists any cautions.
        """
        warnings = []

        for cmd in commands:
            cmd_stripped = cmd.strip().lower()
            for pattern, warning_msg in DANGEROUS_PATTERNS:
                if re.search(pattern, cmd_stripped):
                    warnings.append(f"WARNING: '{cmd.strip()}' - {warning_msg}")

        return True, warnings


class CheckpointManager:
    """Manages configuration checkpoints for rollback capability.

    Stores running-config snapshots before changes so we can
    restore if something goes wrong.
    """

    def __init__(self, max_checkpoints: int = 10) -> None:
        self.max_checkpoints = max_checkpoints
        self._checkpoints: dict[str, list[Checkpoint]] = {}  # device_id -> checkpoints

    def create_checkpoint(
        self,
        conn: DeviceConnection,
        description: str = "",
    ) -> Optional[Checkpoint]:
        """Capture current running-config as a checkpoint.

        Args:
            conn: The device connection.
            description: Human-readable description of why this checkpoint exists.

        Returns:
            Checkpoint object, or None if capture failed.
        """
        device_id = conn.device.device_id
        try:
            config = conn.get_running_config()
            name = f"checkpoint-{device_id}-{len(self._get_device_checkpoints(device_id)) + 1}"

            checkpoint = Checkpoint(
                name=name,
                device_id=device_id,
                config_snapshot=config,
                description=description,
            )

            self._get_device_checkpoints(device_id).append(checkpoint)
            self._trim_checkpoints(device_id)

            logger.info("Checkpoint '%s' created for %s", name, device_id)
            return checkpoint

        except Exception as e:
            logger.error("Failed to create checkpoint for %s: %s", device_id, e)
            return None

    def rollback(
        self,
        conn: DeviceConnection,
        checkpoint: Optional[Checkpoint] = None,
    ) -> bool:
        """Rollback device to a checkpoint (default: most recent).

        This works by computing the diff between current config and
        the checkpoint, then applying 'no' versions of added lines
        and re-applying removed lines. For safety, we use
        Netmiko's config replacement when available, falling back
        to manual rollback.

        Args:
            conn: The device connection.
            checkpoint: Specific checkpoint to rollback to.
                       If None, uses the most recent checkpoint.

        Returns:
            True if rollback succeeded.
        """
        device_id = conn.device.device_id

        if checkpoint is None:
            checkpoints = self._get_device_checkpoints(device_id)
            if not checkpoints:
                logger.error("No checkpoints available for %s", device_id)
                return False
            checkpoint = checkpoints[-1]

        logger.info("Rolling back %s to checkpoint '%s'", device_id, checkpoint.name)

        try:
            # Get current running config
            current_config = conn.get_running_config()

            # Build rollback commands by comparing configs
            rollback_commands = self._compute_rollback_commands(
                current_config, checkpoint.config_snapshot
            )

            if not rollback_commands:
                logger.info("No differences found, nothing to rollback")
                return True

            result = conn.execute_config_commands(rollback_commands)
            if result.success:
                logger.info("Rollback successful for %s", device_id)
                return True

            logger.error("Rollback failed for %s: %s", device_id, result.error)
            return False

        except Exception as e:
            logger.error("Rollback error for %s: %s", device_id, e)
            return False

    def get_latest_checkpoint(self, device_id: str) -> Optional[Checkpoint]:
        """Get the most recent checkpoint for a device."""
        checkpoints = self._get_device_checkpoints(device_id)
        return checkpoints[-1] if checkpoints else None

    def get_checkpoints(self, device_id: str) -> list[Checkpoint]:
        """Get all checkpoints for a device."""
        return list(self._get_device_checkpoints(device_id))

    def _get_device_checkpoints(self, device_id: str) -> list[Checkpoint]:
        if device_id not in self._checkpoints:
            self._checkpoints[device_id] = []
        return self._checkpoints[device_id]

    def _trim_checkpoints(self, device_id: str) -> None:
        """Remove old checkpoints beyond the max limit."""
        checkpoints = self._get_device_checkpoints(device_id)
        while len(checkpoints) > self.max_checkpoints:
            removed = checkpoints.pop(0)
            logger.debug("Removed old checkpoint '%s'", removed.name)

    @staticmethod
    def _compute_rollback_commands(current: str, target: str) -> list[str]:
        """Compute minimal config commands to go from current to target.

        This is a simplified approach: extract section-level differences.
        For production, you'd want a proper config diff engine.
        """
        current_lines = set(
            line.rstrip()
            for line in current.splitlines()
            if line.strip() and not line.startswith("!")
        )
        target_lines = set(
            line.rstrip()
            for line in target.splitlines()
            if line.strip() and not line.startswith("!")
        )

        # Lines in current but not in target → need to negate
        to_remove = current_lines - target_lines
        # Lines in target but not in current → need to add
        to_add = target_lines - current_lines

        commands = []

        # Negate removed lines (prepend 'no' to config lines)
        for line in sorted(to_remove):
            stripped = line.strip()
            if stripped and not stripped.startswith(("Building", "Current", "end", "version")):
                commands.append(f"no {stripped}")

        # Add missing lines
        for line in sorted(to_add):
            stripped = line.strip()
            if stripped and not stripped.startswith(("Building", "Current", "end", "version")):
                commands.append(stripped)

        return commands


class ApprovalManager:
    """Manages the approval flow for configuration changes.

    Config changes are not executed immediately - they create an
    ApprovalRequest that must be approved by the user via the UI.
    """

    def __init__(self) -> None:
        self._pending: dict[str, ApprovalRequest] = {}
        self._history: list[ApprovalRequest] = []

    def request_approval(
        self,
        device_id: str,
        commands: list[str],
        description: str,
        checkpoint_name: Optional[str] = None,
    ) -> ApprovalRequest:
        """Create a new approval request.

        Args:
            device_id: The target device.
            commands: Config commands pending approval.
            description: What these commands do.
            checkpoint_name: Associated checkpoint name.

        Returns:
            The created ApprovalRequest.
        """
        request = ApprovalRequest(
            device_id=device_id,
            commands=commands,
            description=description,
            checkpoint_name=checkpoint_name,
        )

        self._pending[request.request_id] = request
        logger.info(
            "Approval requested [%s] for %s: %s",
            request.request_id,
            device_id,
            description,
        )
        return request

    def approve(self, request_id: str) -> Optional[ApprovalRequest]:
        """Mark a request as approved.

        Returns:
            The approved request, or None if not found.
        """
        request = self._pending.pop(request_id, None)
        if request:
            request.approve()
            self._history.append(request)
            logger.info("Approval [%s] APPROVED", request_id)
        return request

    def reject(self, request_id: str) -> Optional[ApprovalRequest]:
        """Mark a request as rejected.

        Returns:
            The rejected request, or None if not found.
        """
        request = self._pending.pop(request_id, None)
        if request:
            request.reject()
            self._history.append(request)
            logger.info("Approval [%s] REJECTED", request_id)
        return request

    def get_pending(self, request_id: str) -> Optional[ApprovalRequest]:
        """Get a pending request by ID."""
        return self._pending.get(request_id)

    def get_all_pending(self) -> list[ApprovalRequest]:
        """Get all pending approval requests."""
        return list(self._pending.values())

    def has_pending(self) -> bool:
        """Check if there are any pending requests."""
        return bool(self._pending)

    @property
    def history(self) -> list[ApprovalRequest]:
        """Get approval history."""
        return list(self._history)
