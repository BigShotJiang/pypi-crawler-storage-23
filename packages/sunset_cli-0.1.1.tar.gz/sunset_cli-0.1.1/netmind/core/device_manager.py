"""Centralized device connection manager.

Tracks all device sessions, provides bulk operations,
and serves as the single source of truth for device state.
"""

from typing import Any, Dict, List, Optional, Tuple

from netmind.core.device_connection import DeviceConnection, DeviceConnectionError
from netmind.core.discovery import DiscoveryResult, discover_all, discover_device
from netmind.core.topology import NetworkTopology
from netmind.models import (
    CommandResult,
    Device,
    DeviceCredentials,
    DeviceType,
    MultiDeviceResult,
)
from netmind.utils import get_logger, get_session_logger
from netmind.utils.inventory import load_full_inventory, load_inventory, InventoryError

logger = get_logger("core.device_manager")


class DeviceManager:
    """Manages all device connections in the application.

    Provides a centralized interface for adding, removing, and
    executing commands across multiple network devices.
    """

    def __init__(self) -> None:
        self._devices: dict[str, DeviceConnection] = {}
        self.topology: NetworkTopology = NetworkTopology()

    @property
    def device_count(self) -> int:
        return len(self._devices)

    @property
    def connected_count(self) -> int:
        return sum(1 for d in self._devices.values() if d.is_connected)

    def add_device(
        self,
        device_id: str,
        host: str,
        username: str,
        password: str,
        device_type: DeviceType = DeviceType.CISCO_IOS,
        port: int = 22,
        enable_secret: Optional[str] = None,
        ssh_options: Optional[Dict[str, Any]] = None,
    ) -> DeviceConnection:
        """Add a new device and establish connection.

        Args:
            device_id: User-assigned identifier (e.g., 'R1').
            host: IP address or hostname.
            username: SSH username.
            password: SSH password.
            device_type: Netmiko device type.
            port: SSH port (default 22).
            enable_secret: Enable password if required.
            ssh_options: Extra SSH/Netmiko kwargs (e.g., disabled_algorithms
                         for legacy devices).

        Returns:
            The DeviceConnection instance.

        Raises:
            ValueError: If device_id already exists.
            DeviceConnectionError: If SSH connection fails.
        """
        if device_id in self._devices:
            raise ValueError(f"Device '{device_id}' already exists")

        device = Device(
            device_id=device_id,
            host=host,
            port=port,
            device_type=device_type,
            credentials=DeviceCredentials(
                username=username,
                password=password,
                enable_secret=enable_secret,
            ),
            ssh_options=ssh_options or {},
        )

        conn = DeviceConnection(device)
        conn.connect()

        self._devices[device_id] = conn
        logger.info("Device '%s' added and connected", device_id)
        return conn

    def remove_device(self, device_id: str) -> bool:
        """Disconnect and remove a device.

        Args:
            device_id: The device identifier to remove.

        Returns:
            True if the device was removed.
        """
        conn = self._devices.pop(device_id, None)
        if conn is None:
            logger.warning("Device '%s' not found", device_id)
            return False

        conn.disconnect()
        logger.info("Device '%s' removed", device_id)
        return True

    def get_device(self, device_id: str) -> Optional[DeviceConnection]:
        """Get a device connection by ID.

        Args:
            device_id: The device identifier.

        Returns:
            DeviceConnection if found, None otherwise.
        """
        return self._devices.get(device_id)

    def get_all_devices(self) -> list[DeviceConnection]:
        """Return all device connections."""
        return list(self._devices.values())

    def get_device_ids(self) -> list[str]:
        """Return all device IDs."""
        return list(self._devices.keys())

    def execute_on_device(self, device_id: str, command: str) -> CommandResult:
        """Execute a show command on a specific device.

        Args:
            device_id: Target device identifier.
            command: The command to execute.

        Returns:
            CommandResult from execution.

        Raises:
            ValueError: If device not found.
        """
        conn = self.get_device(device_id)
        if conn is None:
            return CommandResult(
                success=False,
                device_id=device_id,
                command=command,
                error=f"Device '{device_id}' not found. Available devices: {', '.join(self.get_device_ids())}",
            )
        return conn.execute_command(command)

    def execute_config_on_device(
        self, device_id: str, commands: list[str]
    ) -> CommandResult:
        """Execute config commands on a specific device.

        Args:
            device_id: Target device identifier.
            commands: List of config commands.

        Returns:
            CommandResult from execution.
        """
        conn = self.get_device(device_id)
        if conn is None:
            return CommandResult(
                success=False,
                device_id=device_id,
                command="; ".join(commands),
                error=f"Device '{device_id}' not found",
            )
        return conn.execute_config_commands(commands)

    def execute_on_all(self, command: str) -> MultiDeviceResult:
        """Execute the same command on all connected devices.

        Args:
            command: The command to execute.

        Returns:
            MultiDeviceResult with per-device results.
        """
        multi = MultiDeviceResult(command=command)
        for device_id, conn in self._devices.items():
            if conn.is_connected:
                multi.results[device_id] = conn.execute_command(command)
            else:
                multi.results[device_id] = CommandResult(
                    success=False,
                    device_id=device_id,
                    command=command,
                    error="Device not connected",
                )
        return multi

    def load_from_inventory(
        self, path: Optional[str] = None
    ) -> Tuple[int, List[str]]:
        """Load devices from an inventory file, connect them, and build topology.

        Args:
            path: Path to inventory YAML file. If None, searches
                  default locations (inventory.yml, devices.yml).

        Returns:
            (success_count, errors) — number of devices connected and
            a list of error messages for any that failed.
        """
        try:
            devices, topology = load_full_inventory(path)
        except InventoryError as e:
            logger.error("Inventory error: %s", e)
            return 0, [str(e)]

        if not devices:
            logger.info("No devices found in inventory")
            return 0, []

        slog = get_session_logger()

        # Store the topology
        self.topology = topology
        logger.info(
            "Topology loaded: %d nodes, %d links",
            topology.node_count,
            topology.link_count,
        )
        slog.log_topology_build(
            topology.node_count, topology.link_count, source="inventory"
        )

        success = 0
        errors: List[str] = []

        for dev in devices:
            device_id = dev["device_id"]
            try:
                self.add_device(
                    device_id=device_id,
                    host=dev["host"],
                    username=dev["username"],
                    password=dev["password"],
                    device_type=dev["device_type"],
                    port=dev["port"],
                    enable_secret=dev.get("enable_secret"),
                    ssh_options=dev.get("ssh_options"),
                )
                success += 1
            except (DeviceConnectionError, ValueError) as e:
                msg = f"{device_id} ({dev['host']}): {e}"
                errors.append(msg)
                logger.error("Failed to load %s: %s", device_id, e)

        logger.info(
            "Inventory loaded: %d/%d devices connected (%d errors), "
            "topology: %d nodes, %d links",
            success, len(devices), len(errors),
            topology.node_count, topology.link_count,
        )
        slog.log_inventory_load(
            path=path or "(auto-detect)",
            device_count=len(devices),
            success_count=success,
            errors=errors,
        )
        return success, errors

    def run_discovery(self) -> Tuple[List[DiscoveryResult], int, int]:
        """Run auto-discovery on all connected devices.

        SSHes into each device and discovers interfaces, OSPF config,
        and CDP/LLDP neighbors. Rebuilds the topology from live data.

        Returns:
            (results, node_count, link_count)
        """
        import time as _time

        slog = get_session_logger()
        connections = [
            conn for conn in self._devices.values() if conn.is_connected
        ]

        if not connections:
            logger.warning("No connected devices for discovery")
            return [], 0, 0

        slog.log_discovery_start(len(connections))
        logger.info("Running auto-discovery on %d devices...", len(connections))

        t0 = _time.monotonic()
        results, topology = discover_all(connections)
        total_ms = (_time.monotonic() - t0) * 1000

        # Replace the topology
        self.topology = topology

        # Log per-device discovery results
        total_ifaces = 0
        for r in results:
            icount = len(r.interfaces)
            total_ifaces += icount
            slog.log_discovery_device(
                device_id=r.device_id,
                interface_count=icount,
                ospf_found=r.ospf is not None,
                cdp_neighbor_count=len(r.cdp_neighbors),
                lldp_neighbor_count=len(r.lldp_neighbors),
                errors=r.errors if hasattr(r, "errors") else [],
                elapsed_ms=0,
            )

        slog.log_discovery_complete(
            device_count=len(results),
            node_count=topology.node_count,
            link_count=topology.link_count,
            total_interfaces=total_ifaces,
            elapsed_ms=total_ms,
        )

        logger.info(
            "Discovery complete: %d nodes, %d links",
            topology.node_count, topology.link_count,
        )

        return results, topology.node_count, topology.link_count

    @property
    def has_topology_data(self) -> bool:
        """Check if topology has any interface data.

        Returns True if at least one node has interfaces defined.
        """
        for node in self.topology.get_all_nodes():
            if node.interfaces:
                return True
        return False

    def disconnect_all(self) -> None:
        """Disconnect all devices gracefully."""
        for device_id, conn in self._devices.items():
            try:
                conn.disconnect()
            except Exception as e:
                logger.warning("Error disconnecting %s: %s", device_id, e)
        logger.info("All devices disconnected")

    def get_devices_summary(self) -> List[Dict[str, Any]]:
        """Get a summary of all devices for display/tool results.

        Includes topology data (interfaces, neighbors) when available.

        Returns:
            List of device info dicts suitable for Claude tool results.
        """
        summary = []
        for device_id, conn in self._devices.items():
            d = conn.device
            entry: Dict[str, Any] = {
                "device_id": device_id,
                "host": d.host,
                "hostname": d.info.hostname,
                "os_version": d.info.os_version,
                "model": d.info.model,
                "status": d.status.value,
                "device_type": d.device_type.value,
                "privilege_level": conn.privilege_level,
            }

            # Enrich with topology data if available
            topo_node = self.topology.get_node(device_id)
            if topo_node:
                entry["interface_count"] = len(topo_node.interfaces)
                entry["role"] = topo_node.role
                entry["site"] = topo_node.site
                neighbors = self.topology.get_neighbors(device_id)
                entry["neighbor_count"] = len(neighbors)
                entry["neighbor_ids"] = [n["neighbor_id"] for n in neighbors]

            summary.append(entry)
        return summary
