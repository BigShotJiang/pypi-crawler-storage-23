"""SSH connection management using Netmiko.

Wraps Netmiko's ConnectHandler with structured error handling,
command result models, and checkpoint/rollback support.
"""

import re
import time
from typing import Optional

from netmiko import ConnectHandler
from netmiko.exceptions import (
    NetmikoAuthenticationException,
    NetmikoTimeoutException,
)

# IOS error patterns that indicate a command failed at the CLI level
_IOS_ERROR_PATTERNS = [
    re.compile(r"% Invalid input detected at", re.IGNORECASE),
    re.compile(r"% Incomplete command", re.IGNORECASE),
    re.compile(r"% Ambiguous command", re.IGNORECASE),
    re.compile(r"% Unknown command", re.IGNORECASE),
    re.compile(r"% Authorization failed", re.IGNORECASE),
]

from netmind.models import (
    CommandResult,
    CommandType,
    Device,
    DeviceCredentials,
    DeviceInfo,
    DeviceStatus,
    DeviceType,
)
from netmind.utils import get_config, get_logger, get_session_logger
from netmind.utils.parsers import parse_show_version

logger = get_logger("core.device_connection")


class DeviceConnectionError(Exception):
    """Raised when a device connection operation fails."""


class DeviceConnection:
    """Manages a single SSH connection to a network device.

    This class wraps Netmiko's ConnectHandler providing:
    - Structured command results (CommandResult)
    - Automatic device info discovery on connect
    - Retry logic for transient failures
    - Config checkpoint and rollback support
    """

    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds

    def __init__(self, device: Device) -> None:
        self.device = device
        self._connection: Optional[ConnectHandler] = None
        self._config = get_config()
        self._privilege_level: int = -1  # -1 = unknown, 1 = user, 15 = enable

    @property
    def privilege_level(self) -> int:
        """Return the detected privilege level (-1 if unknown)."""
        return self._privilege_level

    @property
    def is_connected(self) -> bool:
        """Check if the SSH session is alive."""
        if self._connection is None:
            return False
        try:
            return self._connection.is_alive()
        except Exception:
            return False

    def connect(self) -> bool:
        """Establish SSH connection and discover device info.

        Returns:
            True if connection was successful.

        Raises:
            DeviceConnectionError: On authentication or timeout failure.
        """
        slog = get_session_logger()
        logger.info("Connecting to %s (%s)...", self.device.device_id, self.device.host)
        self.device.status = DeviceStatus.CONNECTING
        connect_start = time.time()

        try:
            # Build connection kwargs
            connect_kwargs = {
                "device_type": self.device.device_type.value,
                "host": self.device.host,
                "port": self.device.port,
                "username": self.device.credentials.username,
                "password": self.device.credentials.password,
                "secret": self.device.credentials.enable_secret or "",
                "timeout": self._config.ssh_timeout,
                "read_timeout_override": self._config.command_timeout,
            }

            # Merge user-specified SSH options (legacy algorithms, etc.)
            if self.device.ssh_options:
                connect_kwargs.update(self.device.ssh_options)
                logger.debug(
                    "SSH options for %s: %s",
                    self.device.device_id,
                    list(self.device.ssh_options.keys()),
                )
                slog.log_ssh_options(self.device.device_id, self.device.ssh_options)

            self._connection = ConnectHandler(**connect_kwargs)

            # Try to enter enable mode if secret is provided
            if self.device.credentials.enable_secret:
                try:
                    self._connection.enable()
                    logger.info("Entered enable mode on %s", self.device.device_id)
                except Exception as e:
                    logger.warning(
                        "Could not enter enable mode on %s: %s. "
                        "Continuing in user exec mode (some commands may be restricted).",
                        self.device.device_id, e,
                    )
                    slog.log_error(
                        "enable_mode",
                        f"Failed to enter enable mode on {self.device.device_id}: {e}. "
                        f"Config commands will fail. Check that the router has an "
                        f"enable secret/password set and it matches the inventory.",
                        {"device_id": self.device.device_id, "host": self.device.host},
                    )

            # Verify actual privilege level after enable attempt
            try:
                priv_output = self._connection.send_command("show privilege")
                priv_level = 1
                if "level" in priv_output.lower():
                    # Parse "Current privilege level is 15"
                    for word in priv_output.split():
                        if word.isdigit():
                            priv_level = int(word)
                            break
                self._privilege_level = priv_level
                if priv_level < 15:
                    logger.warning(
                        "%s is at privilege level %d (need 15 for config). "
                        "Config commands will fail unless privilege is escalated.",
                        self.device.device_id, priv_level,
                    )
                    slog.log_error(
                        "privilege_level",
                        f"{self.device.device_id} connected at privilege level {priv_level} "
                        f"(need 15). The router may not have an enable secret set, or the "
                        f"enable_secret in the inventory is incorrect. Config commands will fail.",
                        {"device_id": self.device.device_id, "priv_level": priv_level},
                    )
                else:
                    logger.info(
                        "%s at privilege level %d", self.device.device_id, priv_level,
                    )
            except Exception:
                self._privilege_level = -1

            # Discover device info
            self._detect_device_info()

            self.device.status = DeviceStatus.CONNECTED
            self.device.connection_error = None
            elapsed = (time.time() - connect_start) * 1000
            logger.info(
                "Connected to %s - %s (%s)",
                self.device.device_id,
                self.device.info.hostname,
                self.device.info.os_version,
            )
            slog.log_device_connect(
                self.device.device_id, self.device.host, True, elapsed_ms=elapsed,
            )
            return True

        except NetmikoAuthenticationException as e:
            elapsed = (time.time() - connect_start) * 1000
            self.device.status = DeviceStatus.ERROR
            self.device.connection_error = f"Authentication failed: {e}"
            logger.error("Auth failed for %s: %s", self.device.host, e)
            slog.log_device_connect(
                self.device.device_id, self.device.host, False,
                elapsed_ms=elapsed, error=f"Auth failed: {e}",
            )
            raise DeviceConnectionError(f"Authentication failed for {self.device.host}") from e

        except NetmikoTimeoutException as e:
            elapsed = (time.time() - connect_start) * 1000
            self.device.status = DeviceStatus.ERROR
            self.device.connection_error = f"Connection timed out: {e}"
            logger.error("Timeout connecting to %s: %s", self.device.host, e)
            slog.log_device_connect(
                self.device.device_id, self.device.host, False,
                elapsed_ms=elapsed, error=f"Timeout: {e}",
            )
            raise DeviceConnectionError(f"Connection timed out for {self.device.host}") from e

        except Exception as e:
            elapsed = (time.time() - connect_start) * 1000
            self.device.status = DeviceStatus.ERROR
            self.device.connection_error = str(e)
            logger.error("Connection error for %s: %s", self.device.host, e)
            slog.log_device_connect(
                self.device.device_id, self.device.host, False,
                elapsed_ms=elapsed, error=str(e),
            )
            raise DeviceConnectionError(f"Failed to connect to {self.device.host}: {e}") from e

    def disconnect(self) -> None:
        """Close the SSH connection gracefully."""
        if self._connection:
            try:
                self._connection.disconnect()
                logger.info("Disconnected from %s", self.device.device_id)
            except Exception as e:
                logger.warning("Error disconnecting from %s: %s", self.device.device_id, e)
            finally:
                self._connection = None
                self.device.status = DeviceStatus.DISCONNECTED

    def execute_command(self, command: str) -> CommandResult:
        """Execute a single show/read-only command.

        Args:
            command: The CLI command to execute (e.g., 'show ip interface brief').

        Returns:
            CommandResult with the output or error.
        """
        slog = get_session_logger()
        self._ensure_connected()
        logger.debug("Executing on %s: %s", self.device.device_id, command)

        start_time = time.time()
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                output = self._connection.send_command(
                    command,
                    read_timeout=self._config.command_timeout,
                )
                elapsed = (time.time() - start_time) * 1000
                stripped = output.strip()

                # Detect IOS CLI errors in the output
                ios_error = _detect_ios_error(stripped)
                if ios_error:
                    logger.warning(
                        "IOS error on %s for '%s': %s",
                        self.device.device_id, command, ios_error,
                    )
                    slog.log_device_command(
                        self.device.device_id, command, False,
                        elapsed_ms=elapsed, error=ios_error,
                        attempt=attempt,
                    )
                    return CommandResult(
                        success=False,
                        device_id=self.device.device_id,
                        command=command,
                        command_type=CommandType.SHOW,
                        output=stripped,
                        error=ios_error,
                        execution_time_ms=elapsed,
                    )

                result = CommandResult(
                    success=True,
                    device_id=self.device.device_id,
                    command=command,
                    command_type=CommandType.SHOW,
                    output=stripped,
                    execution_time_ms=elapsed,
                )
                logger.debug(result.summary)
                slog.log_device_command(
                    self.device.device_id, command, True,
                    elapsed_ms=elapsed,
                    output_preview=stripped if slog.verbose else stripped[:200],
                    attempt=attempt,
                )
                return result

            except Exception as e:
                if attempt < self.MAX_RETRIES:
                    logger.warning(
                        "Command failed on %s (attempt %d/%d): %s",
                        self.device.device_id,
                        attempt,
                        self.MAX_RETRIES,
                        e,
                    )
                    slog.log_device_command(
                        self.device.device_id, command, False,
                        elapsed_ms=(time.time() - start_time) * 1000,
                        error=f"Retry {attempt}/{self.MAX_RETRIES}: {e}",
                        attempt=attempt,
                    )
                    time.sleep(self.RETRY_DELAY)
                else:
                    elapsed = (time.time() - start_time) * 1000
                    logger.error(
                        "Command failed on %s after %d attempts: %s",
                        self.device.device_id, self.MAX_RETRIES, e,
                    )
                    slog.log_device_command(
                        self.device.device_id, command, False,
                        elapsed_ms=elapsed, error=str(e),
                        attempt=attempt,
                    )
                    return CommandResult(
                        success=False,
                        device_id=self.device.device_id,
                        command=command,
                        command_type=CommandType.SHOW,
                        error=str(e),
                        execution_time_ms=elapsed,
                    )

        # Should not reach here, but satisfy type checker
        return CommandResult(
            success=False,
            device_id=self.device.device_id,
            command=command,
            error="Max retries exceeded",
        )

    def execute_config_commands(self, commands: list[str]) -> CommandResult:
        """Execute configuration-mode commands.

        Args:
            commands: List of config commands to execute.

        Returns:
            CommandResult with the config output or error.
        """
        slog = get_session_logger()
        self._ensure_connected()
        commands_str = "; ".join(commands)
        logger.info("Configuring %s: %s", self.device.device_id, commands_str)

        start_time = time.time()
        try:
            output = self._connection.send_config_set(
                commands,
                read_timeout=self._config.command_timeout,
            )
            elapsed = (time.time() - start_time) * 1000

            result = CommandResult(
                success=True,
                device_id=self.device.device_id,
                command=commands_str,
                command_type=CommandType.CONFIG,
                output=output.strip(),
                execution_time_ms=elapsed,
            )
            logger.info("Config applied on %s (%0.fms)", self.device.device_id, elapsed)
            slog.log_device_config(
                self.device.device_id, commands, True, elapsed_ms=elapsed,
            )
            return result

        except Exception as e:
            elapsed = (time.time() - start_time) * 1000
            logger.error("Config failed on %s: %s", self.device.device_id, e)
            slog.log_device_config(
                self.device.device_id, commands, False,
                elapsed_ms=elapsed, error=str(e),
            )
            return CommandResult(
                success=False,
                device_id=self.device.device_id,
                command=commands_str,
                command_type=CommandType.CONFIG,
                error=str(e),
                execution_time_ms=elapsed,
            )

    def get_running_config(self) -> str:
        """Retrieve the full running configuration.

        Tries 'show running-config' first. If that fails (e.g. insufficient
        privilege), falls back to 'show run' and then 'show startup-config'.

        Returns:
            The running configuration as a string.

        Raises:
            DeviceConnectionError: If all attempts fail.
        """
        # Try commands in order of preference
        commands = ["show running-config", "show run", "show startup-config"]
        last_error = ""

        for cmd in commands:
            result = self.execute_command(cmd)
            if result.success:
                return result.output
            last_error = result.error or "Unknown error"
            logger.debug(
                "get_running_config: '%s' failed on %s: %s",
                cmd, self.device.device_id, last_error,
            )

        raise DeviceConnectionError(
            f"Failed to get running config from {self.device.device_id}: {last_error}. "
            f"This usually means the SSH user lacks privilege level 15. "
            f"Set 'enable_secret' in the inventory or grant 'privilege 15' to the user."
        )

    def save_config(self) -> CommandResult:
        """Save running-config to startup-config (write memory)."""
        self._ensure_connected()
        try:
            output = self._connection.save_config()
            return CommandResult(
                success=True,
                device_id=self.device.device_id,
                command="write memory",
                output=output,
            )
        except Exception as e:
            return CommandResult(
                success=False,
                device_id=self.device.device_id,
                command="write memory",
                error=str(e),
            )

    def _detect_device_info(self) -> None:
        """Run 'show version' and populate device info."""
        if not self._connection:
            return

        try:
            output = self._connection.send_command("show version")
            parsed = parse_show_version(output)

            self.device.info = DeviceInfo(
                hostname=parsed.get("hostname", ""),
                os_version=parsed.get("version", ""),
                model=parsed.get("model", ""),
                serial=parsed.get("serial", ""),
                uptime=parsed.get("uptime", ""),
            )
        except Exception as e:
            logger.warning("Could not detect device info for %s: %s", self.device.host, e)

    def _ensure_connected(self) -> None:
        """Verify the connection is alive, reconnect if needed."""
        if not self.is_connected:
            logger.warning("Connection lost to %s, reconnecting...", self.device.device_id)
            self.connect()

    def __repr__(self) -> str:
        return (
            f"DeviceConnection(id={self.device.device_id!r}, "
            f"host={self.device.host!r}, "
            f"connected={self.is_connected})"
        )


def _detect_ios_error(output: str) -> Optional[str]:
    """Check if IOS command output contains a CLI error message.

    Returns:
        The error description string, or None if no error detected.
    """
    for pattern in _IOS_ERROR_PATTERNS:
        match = pattern.search(output)
        if match:
            # Return the matched line for context
            for line in output.splitlines():
                if pattern.search(line):
                    return line.strip()
            return match.group(0)
    return None
