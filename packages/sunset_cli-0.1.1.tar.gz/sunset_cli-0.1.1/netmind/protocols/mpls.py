"""MPLS/LDP/RSVP verification helpers.

Provides structured MPLS state analysis: label switching,
LDP sessions, RSVP tunnels, and forwarding table verification.
"""

from typing import Any, Optional

from netmind.core.device_connection import DeviceConnection
from netmind.protocols.base import ProtocolVerifier
from netmind.utils import get_logger
from netmind.utils.parsers import (
    extract_mpls_config,
    parse_show_mpls_interfaces,
    parse_show_mpls_ldp_neighbor,
    parse_show_mpls_forwarding,
    parse_show_ip_rsvp_neighbor,
)

logger = get_logger("protocols.mpls")


class MPLSVerifier(ProtocolVerifier):
    """MPLS/LDP/RSVP-specific verification and analysis."""

    @property
    def protocol_name(self) -> str:
        return "MPLS"

    def get_relevant_commands(self) -> list[str]:
        return [
            "show mpls interfaces",
            "show mpls ldp neighbor",
            "show mpls ldp bindings",
            "show mpls forwarding-table",
            "show mpls label range",
            "show ip rsvp neighbor",
            "show ip rsvp interface",
            "show ip rsvp reservation",
            "show mpls traffic-eng tunnels brief",
        ]

    def verify_status(self, conn: DeviceConnection) -> dict[str, Any]:
        """Verify MPLS/LDP/RSVP health on a device.

        Checks:
        - MPLS-enabled interfaces
        - LDP neighbor sessions
        - MPLS forwarding table
        - RSVP neighbors (if configured)

        Returns:
            Dict with health status and detailed findings.
        """
        device_id = conn.device.device_id
        result: dict[str, Any] = {
            "healthy": False,
            "summary": "",
            "details": {},
            "device_id": device_id,
        }

        # Check MPLS interfaces
        iface_output = conn.execute_command("show mpls interfaces")
        if not iface_output.success:
            result["summary"] = f"Failed to check MPLS on {device_id}: {iface_output.error}"
            return result

        if (
            "not a recognized" in iface_output.output.lower()
            or not iface_output.output.strip()
        ):
            result["summary"] = f"MPLS is not configured on {device_id}"
            result["details"]["mpls_enabled"] = False
            return result

        result["details"]["mpls_enabled"] = True
        interfaces = parse_show_mpls_interfaces(iface_output.output)
        result["details"]["mpls_interfaces"] = interfaces
        result["details"]["mpls_interface_count"] = len(interfaces)

        operational = [
            i for i in interfaces
            if i.get("operational", "").lower() == "yes"
        ]
        result["details"]["operational_interface_count"] = len(operational)

        # Check LDP neighbors
        ldp_output = conn.execute_command("show mpls ldp neighbor")
        ldp_neighbors: list = []
        if ldp_output.success and ldp_output.output.strip():
            ldp_neighbors = parse_show_mpls_ldp_neighbor(ldp_output.output)

        result["details"]["ldp_neighbors"] = ldp_neighbors
        result["details"]["ldp_neighbor_count"] = len(ldp_neighbors)

        ldp_oper = [
            n for n in ldp_neighbors
            if n.get("state", "").lower() in ("oper", "operational")
        ]
        result["details"]["ldp_operational_count"] = len(ldp_oper)

        # Check forwarding table
        fwd_output = conn.execute_command("show mpls forwarding-table")
        if fwd_output.success:
            fwd_entries = parse_show_mpls_forwarding(fwd_output.output)
            result["details"]["forwarding_entries"] = fwd_entries
            result["details"]["forwarding_count"] = len(fwd_entries)
        else:
            result["details"]["forwarding_count"] = 0

        # Check RSVP neighbors (optional — not all MPLS uses RSVP)
        rsvp_output = conn.execute_command("show ip rsvp neighbor")
        rsvp_neighbors: list = []
        if rsvp_output.success and rsvp_output.output.strip():
            rsvp_neighbors = parse_show_ip_rsvp_neighbor(rsvp_output.output)

        result["details"]["rsvp_neighbors"] = rsvp_neighbors
        result["details"]["rsvp_neighbor_count"] = len(rsvp_neighbors)
        result["details"]["rsvp_enabled"] = len(rsvp_neighbors) > 0

        # Check TE tunnels (if RSVP is present)
        if rsvp_neighbors:
            te_output = conn.execute_command("show mpls traffic-eng tunnels brief")
            if te_output.success:
                # Count tunnel lines (lines starting with a tunnel name)
                tunnel_lines = [
                    l for l in te_output.output.splitlines()
                    if "Tunnel" in l and "up" in l.lower()
                ]
                result["details"]["te_tunnel_count"] = len(tunnel_lines)
            else:
                result["details"]["te_tunnel_count"] = 0

        # Determine health
        issues = []
        if len(interfaces) == 0:
            result["summary"] = f"MPLS running on {device_id} but no MPLS interfaces"
            return result

        if len(operational) < len(interfaces):
            issues.append(
                f"{len(interfaces) - len(operational)} MPLS interface(s) not operational"
            )

        if ldp_neighbors and len(ldp_oper) < len(ldp_neighbors):
            issues.append(
                f"{len(ldp_neighbors) - len(ldp_oper)} LDP session(s) not operational"
            )

        if not issues:
            result["healthy"] = True
            parts = [
                f"{len(operational)} MPLS interfaces",
                f"{len(ldp_neighbors)} LDP neighbors",
                f"{result['details']['forwarding_count']} labels",
            ]
            if rsvp_neighbors:
                parts.append(f"{len(rsvp_neighbors)} RSVP neighbors")
                te_count = result["details"].get("te_tunnel_count", 0)
                if te_count:
                    parts.append(f"{te_count} TE tunnels UP")
            result["summary"] = f"MPLS healthy on {device_id}: {', '.join(parts)}"
        else:
            result["summary"] = (
                f"MPLS issues on {device_id}: {'; '.join(issues)}"
            )

        logger.info(result["summary"])
        return result


def verify_ldp_sessions(
    conn: DeviceConnection,
    expected_neighbors: Optional[list[str]] = None,
) -> tuple[bool, str]:
    """Quick check: are LDP sessions operational?"""
    output = conn.execute_command("show mpls ldp neighbor")
    if not output.success:
        return False, f"Failed to check LDP: {output.error}"

    neighbors = parse_show_mpls_ldp_neighbor(output.output)
    oper = [
        n for n in neighbors
        if n.get("state", "").lower() in ("oper", "operational")
    ]

    if not neighbors:
        return False, "No LDP neighbors found"

    if expected_neighbors:
        found_peers = {n["peer"].split(":")[0] for n in oper}
        missing = set(expected_neighbors) - found_peers
        if missing:
            return False, f"Missing LDP sessions: {', '.join(missing)}"

    if len(oper) < len(neighbors):
        return False, f"Some LDP sessions not operational: {len(oper)}/{len(neighbors)}"

    return True, f"All {len(oper)} LDP sessions operational"


def get_mpls_config(conn: DeviceConnection) -> Optional[str]:
    """Extract MPLS/LDP/RSVP configuration from running config."""
    try:
        running = conn.get_running_config()
        return extract_mpls_config(running)
    except Exception as e:
        logger.warning("Could not extract MPLS config: %s", e)
        return None
