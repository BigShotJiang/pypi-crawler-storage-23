"""IS-IS verification helpers.

Provides structured IS-IS state analysis: neighbor adjacencies,
LSDB entries, and configuration extraction.
"""

from typing import Any, Optional

from netmind.core.device_connection import DeviceConnection
from netmind.protocols.base import ProtocolVerifier
from netmind.utils import get_logger
from netmind.utils.parsers import (
    extract_isis_config,
    parse_show_isis_neighbors,
    parse_show_isis_database,
)

logger = get_logger("protocols.isis")


class ISISVerifier(ProtocolVerifier):
    """IS-IS-specific verification and analysis."""

    @property
    def protocol_name(self) -> str:
        return "IS-IS"

    def get_relevant_commands(self) -> list[str]:
        return [
            "show isis neighbors",
            "show isis database",
            "show isis topology",
            "show isis interface",
            "show ip route isis",
            "show clns neighbors",
            "show running-config | section router isis",
        ]

    def verify_status(self, conn: DeviceConnection) -> dict[str, Any]:
        """Verify IS-IS health on a device.

        Checks:
        - IS-IS process is running
        - Neighbor adjacencies are UP
        - LSDB has entries
        - IS-IS routes are present

        Returns:
            Dict with health status and detailed findings.
        """
        device_id = conn.device.device_id
        result: dict[str, Any] = {
            "healthy": False,
            "summary": "",
            "details": {},
            "device_id": device_id,
        }

        neighbor_output = conn.execute_command("show isis neighbors")
        if not neighbor_output.success:
            # Try CLNS neighbors as fallback
            neighbor_output = conn.execute_command("show clns neighbors")

        if not neighbor_output.success:
            result["summary"] = f"Failed to check IS-IS on {device_id}: {neighbor_output.error}"
            return result

        if (
            "not a recognized" in neighbor_output.output.lower()
            or "IS-IS" not in neighbor_output.output.upper()
            and not neighbor_output.output.strip()
        ):
            result["summary"] = f"IS-IS is not configured on {device_id}"
            result["details"]["isis_enabled"] = False
            return result

        result["details"]["isis_enabled"] = True
        neighbors = parse_show_isis_neighbors(neighbor_output.output)
        result["details"]["neighbors"] = neighbors
        result["details"]["neighbor_count"] = len(neighbors)

        up_neighbors = [
            n for n in neighbors
            if n.get("state", "").upper() in ("UP", "INIT")
        ]
        result["details"]["up_adjacencies"] = len(up_neighbors)

        # Check LSDB
        db_output = conn.execute_command("show isis database")
        if db_output.success:
            db_entries = parse_show_isis_database(db_output.output)
            result["details"]["lsdb_entries"] = db_entries
            result["details"]["lsdb_count"] = len(db_entries)
        else:
            result["details"]["lsdb_count"] = 0

        # Check IS-IS routes
        route_output = conn.execute_command("show ip route isis")
        if route_output.success:
            route_lines = [
                l for l in route_output.output.splitlines()
                if l.strip().startswith("i")
            ]
            result["details"]["isis_route_count"] = len(route_lines)
        else:
            result["details"]["isis_route_count"] = 0

        # Determine health
        if len(neighbors) == 0:
            result["summary"] = f"IS-IS running on {device_id} but no neighbors detected"
        elif len(up_neighbors) == len(neighbors):
            result["healthy"] = True
            result["summary"] = (
                f"IS-IS healthy on {device_id}: "
                f"{len(up_neighbors)} adjacencies UP, "
                f"{result['details'].get('lsdb_count', 0)} LSDB entries, "
                f"{result['details']['isis_route_count']} routes"
            )
        else:
            down = len(neighbors) - len(up_neighbors)
            result["summary"] = (
                f"IS-IS on {device_id}: {len(up_neighbors)}/{len(neighbors)} UP "
                f"({down} not UP)"
            )

        logger.info(result["summary"])
        return result


def verify_isis_adjacency(
    conn: DeviceConnection,
    expected_neighbors: Optional[list[str]] = None,
) -> tuple[bool, str]:
    """Quick check: are IS-IS adjacencies up?"""
    output = conn.execute_command("show isis neighbors")
    if not output.success:
        return False, f"Failed to check IS-IS neighbors: {output.error}"

    neighbors = parse_show_isis_neighbors(output.output)
    up = [n for n in neighbors if n.get("state", "").upper() in ("UP", "INIT")]

    if not neighbors:
        return False, "No IS-IS neighbors found"

    if expected_neighbors:
        found_ids = {n["system_id"] for n in up}
        missing = set(expected_neighbors) - found_ids
        if missing:
            return False, f"Missing IS-IS neighbors: {', '.join(missing)}"

    if len(up) < len(neighbors):
        return False, f"Some IS-IS adjacencies not UP: {len(up)}/{len(neighbors)}"

    return True, f"All {len(up)} IS-IS adjacencies are UP"


def get_isis_config(conn: DeviceConnection) -> Optional[str]:
    """Extract IS-IS configuration block from running config."""
    try:
        running = conn.get_running_config()
        return extract_isis_config(running)
    except Exception as e:
        logger.warning("Could not extract IS-IS config: %s", e)
        return None
