"""EIGRP verification helpers.

Provides structured EIGRP state analysis: neighbor adjacencies,
topology table entries, and configuration extraction.
"""

from typing import Any, Optional

from netmind.core.device_connection import DeviceConnection
from netmind.protocols.base import ProtocolVerifier
from netmind.utils import get_logger
from netmind.utils.parsers import (
    extract_eigrp_config,
    parse_show_eigrp_neighbors,
    parse_show_eigrp_topology,
)

logger = get_logger("protocols.eigrp")


class EIGRPVerifier(ProtocolVerifier):
    """EIGRP-specific verification and analysis."""

    @property
    def protocol_name(self) -> str:
        return "EIGRP"

    def get_relevant_commands(self) -> list[str]:
        return [
            "show ip eigrp neighbors",
            "show ip eigrp topology",
            "show ip eigrp interfaces",
            "show ip route eigrp",
            "show running-config | section router eigrp",
        ]

    def verify_status(self, conn: DeviceConnection) -> dict[str, Any]:
        """Verify EIGRP health on a device.

        Checks:
        - EIGRP process is running
        - Neighbor adjacencies are formed
        - Topology table has entries
        - EIGRP routes are present

        Returns:
            Dict with health status and detailed findings.
        """
        device_id = conn.device.device_id
        result: dict[str, Any] = {
            "healthy": False,
            "summary": "",
            "details": {},
            "device_id": device_id,
        }

        neighbor_output = conn.execute_command("show ip eigrp neighbors")
        if not neighbor_output.success:
            result["summary"] = f"Failed to check EIGRP on {device_id}: {neighbor_output.error}"
            return result

        if (
            "not a recognized" in neighbor_output.output.lower()
            or "EIGRP" not in neighbor_output.output
        ):
            result["summary"] = f"EIGRP is not configured on {device_id}"
            result["details"]["eigrp_enabled"] = False
            return result

        result["details"]["eigrp_enabled"] = True
        neighbors = parse_show_eigrp_neighbors(neighbor_output.output)
        result["details"]["neighbors"] = neighbors
        result["details"]["neighbor_count"] = len(neighbors)

        # Check topology table
        topo_output = conn.execute_command("show ip eigrp topology")
        if topo_output.success:
            topo_entries = parse_show_eigrp_topology(topo_output.output)
            result["details"]["topology_entries"] = topo_entries
            result["details"]["topology_count"] = len(topo_entries)

            passive_count = sum(1 for e in topo_entries if e["code"] == "P")
            active_count = sum(1 for e in topo_entries if e["code"] == "A")
            result["details"]["passive_routes"] = passive_count
            result["details"]["active_routes"] = active_count
        else:
            result["details"]["topology_count"] = 0
            result["details"]["active_routes"] = 0

        # Check EIGRP routes in RIB
        route_output = conn.execute_command("show ip route eigrp")
        if route_output.success:
            route_lines = [
                l for l in route_output.output.splitlines()
                if l.strip().startswith("D")
            ]
            result["details"]["eigrp_route_count"] = len(route_lines)
        else:
            result["details"]["eigrp_route_count"] = 0

        # Determine health
        active = result["details"].get("active_routes", 0)
        if len(neighbors) == 0:
            result["summary"] = f"EIGRP running on {device_id} but no neighbors detected"
        elif active > 0:
            result["summary"] = (
                f"EIGRP on {device_id}: {len(neighbors)} neighbors, "
                f"but {active} routes ACTIVE (reconverging)"
            )
        else:
            result["healthy"] = True
            result["summary"] = (
                f"EIGRP healthy on {device_id}: "
                f"{len(neighbors)} neighbors, "
                f"{result['details'].get('topology_count', 0)} topology entries, "
                f"{result['details']['eigrp_route_count']} routes"
            )

        logger.info(result["summary"])
        return result


def verify_eigrp_adjacency(
    conn: DeviceConnection,
    expected_neighbors: Optional[list[str]] = None,
) -> tuple[bool, str]:
    """Quick check: are EIGRP adjacencies up?"""
    output = conn.execute_command("show ip eigrp neighbors")
    if not output.success:
        return False, f"Failed to check EIGRP neighbors: {output.error}"

    neighbors = parse_show_eigrp_neighbors(output.output)

    if not neighbors:
        return False, "No EIGRP neighbors found"

    if expected_neighbors:
        found_addrs = {n["address"] for n in neighbors}
        missing = set(expected_neighbors) - found_addrs
        if missing:
            return False, f"Missing EIGRP neighbors: {', '.join(missing)}"

    return True, f"EIGRP has {len(neighbors)} active neighbor(s)"


def get_eigrp_config(conn: DeviceConnection) -> Optional[str]:
    """Extract EIGRP configuration block from running config."""
    try:
        running = conn.get_running_config()
        return extract_eigrp_config(running)
    except Exception as e:
        logger.warning("Could not extract EIGRP config: %s", e)
        return None
