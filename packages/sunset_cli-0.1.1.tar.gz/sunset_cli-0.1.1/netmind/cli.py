"""Sunset CLI entry point.

Used by python -m netmind and the installed 'sunset' command.
"""

import argparse
import sys

from netmind import __version__


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="sunset",
        description="Sunset - LLM-powered network automation agent",
    )
    parser.add_argument(
        "--version", "-V",
        action="version",
        version=f"sunset {__version__}",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--inventory", "-i",
        type=str,
        default=None,
        help="Path to device inventory YAML file (default: auto-detect)",
    )

    subparsers = parser.add_subparsers(dest="command")

    # --- setup ---
    subparsers.add_parser("setup", help="Interactive first-time setup")

    # --- config ---
    config_parser = subparsers.add_parser("config", help="View or edit configuration")
    config_sub = config_parser.add_subparsers(dest="config_action")
    config_set = config_sub.add_parser("set", help="Set a config value")
    config_set.add_argument("key", type=str, help="Config key (e.g. CLAUDE_MODEL)")
    config_set.add_argument("value", type=str, help="Config value")
    config_sub.add_parser("path", help="Print config file path")
    config_sub.add_parser("reset", help="Delete config file")

    # --- auth ---
    # Supports: sunset auth <key>, sunset auth status, sunset auth logout
    auth_parser = subparsers.add_parser(
        "auth", help="Manage license key",
    )
    auth_parser.add_argument(
        "key_or_action", nargs="?", default=None,
        metavar="KEY|status|logout",
        help="License key to activate, or 'status'/'logout'",
    )

    # --- update ---
    update_parser = subparsers.add_parser("update", help="Update sunset to the latest version")
    update_parser.add_argument(
        "--force", "-f", action="store_true",
        help="Reinstall even if already on the latest version",
    )

    # --- doctor ---
    subparsers.add_parser("doctor", help="Run diagnostic health checks")

    # --- logs ---
    logs_parser = subparsers.add_parser("logs", help="View session logs")
    logs_parser.add_argument(
        "--tail", "-f", action="store_true",
        help="Follow the latest session log in real-time",
    )
    logs_parser.add_argument(
        "--last", "-l", action="store_true",
        help="Show the most recent session log",
    )
    logs_parser.add_argument(
        "--json", action="store_true",
        help="Output raw JSON (default: formatted)",
    )
    logs_parser.add_argument(
        "--filter", "-t", type=str, default=None,
        help="Filter by event type (e.g. tool_call, error, device_command)",
    )
    logs_parser.add_argument(
        "--report", "-r", action="store_true",
        help="Generate a structured debug report from the latest session",
    )
    logs_parser.add_argument(
        "--full", action="store_true",
        help="Include full command outputs in the report (use with --report)",
    )
    logs_parser.add_argument(
        "--save", type=str, default=None,
        help="Save the report to a file (use with --report)",
    )

    args = parser.parse_args()

    # ── Subcommand dispatch ──

    if args.command == "setup":
        from netmind.cli_commands.setup import run_setup
        run_setup()
        return

    if args.command == "config":
        from netmind.cli_commands.config import run_config
        run_config(args)
        return

    if args.command == "auth":
        from netmind.cli_commands.auth import run
        run(args)
        return

    if args.command == "update":
        from netmind.cli_commands.update import run_update
        run_update(force=args.force)
        return

    if args.command == "doctor":
        from netmind.cli_commands.doctor import run_doctor
        run_doctor()
        return

    if args.command == "logs":
        if args.report:
            from netmind.utils.log_viewer import generate_report_cmd
            generate_report_cmd(full=args.full, save_path=args.save)
        else:
            from netmind.utils.log_viewer import view_logs
            view_logs(
                tail=args.tail,
                last=args.last,
                raw_json=args.json,
                event_filter=args.filter,
            )
        return

    # ── No subcommand: launch TUI ──
    _launch_tui(args)


def _launch_tui(args) -> None:
    """Launch the Textual TUI application."""
    slog = None
    try:
        from netmind.utils.session_logger import get_session_logger
        slog = get_session_logger(verbose=args.debug)
        print(f"Session log: {slog.log_path}", file=sys.stderr)
        if args.debug:
            print("DEBUG MODE: verbose session logging enabled", file=sys.stderr)
    except Exception:
        pass

    if args.inventory:
        from pathlib import Path
        inv_path = Path(args.inventory)
        if not inv_path.exists():
            print(f"Error: Inventory file not found: {args.inventory}", file=sys.stderr)
            sys.exit(1)

    from netmind.ui.app import NetMindApp

    app = NetMindApp(debug=args.debug, inventory_path=args.inventory)
    try:
        app.run()
    finally:
        if slog:
            slog.log_session_end()
