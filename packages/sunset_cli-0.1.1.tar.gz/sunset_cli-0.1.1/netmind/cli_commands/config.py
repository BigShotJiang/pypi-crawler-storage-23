"""sunset config - View and edit configuration."""

from rich.console import Console
from rich.table import Table


def run_config(args) -> None:
    """Handle sunset config subcommands."""
    console = Console()
    action = getattr(args, "config_action", None)

    if action == "set":
        _config_set(console, args.key, args.value)
    elif action == "path":
        _config_path(console)
    elif action == "reset":
        _config_reset(console)
    else:
        _config_show(console)


def _config_show(console: Console) -> None:
    """Show all current config values (redact API key)."""
    from netmind.utils.config import SUNSET_CONFIG_ENV, get_config

    config = get_config()

    table = Table(title="Sunset Configuration")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")

    api_display = config.anthropic_api_key
    if api_display:
        api_display = api_display[:10] + "..." + api_display[-4:]

    table.add_row("ANTHROPIC_API_KEY", api_display or "[dim]not set[/dim]")
    table.add_row("CLAUDE_MODEL", config.claude_model)
    table.add_row("LOG_LEVEL", config.log_level)
    table.add_row("SSH_TIMEOUT", str(config.ssh_timeout))
    table.add_row("COMMAND_TIMEOUT", str(config.command_timeout))
    table.add_row("MAX_CONVERSATION_HISTORY", str(config.max_conversation_history))
    table.add_row("MAX_CHECKPOINTS", str(config.max_checkpoints))
    table.add_row("READ_ONLY_DEFAULT", str(config.read_only_default))

    console.print()
    console.print(table)
    console.print(f"\n[dim]Config file: {SUNSET_CONFIG_ENV}[/dim]\n")


def _config_set(console: Console, key: str, value: str) -> None:
    """Set a single config value."""
    from netmind.utils.config import save_env_file

    save_env_file({key.upper(): value})
    console.print(f"[green]Set {key.upper()} = {value}[/green]")


def _config_path(console: Console) -> None:
    """Print the config file path."""
    from netmind.utils.config import SUNSET_CONFIG_ENV

    console.print(str(SUNSET_CONFIG_ENV))


def _config_reset(console: Console) -> None:
    """Delete the config file."""
    from netmind.utils.config import SUNSET_CONFIG_ENV

    if SUNSET_CONFIG_ENV.is_file():
        SUNSET_CONFIG_ENV.unlink()
        console.print("[yellow]Config file deleted.[/yellow]")
    else:
        console.print("[dim]No config file found.[/dim]")
