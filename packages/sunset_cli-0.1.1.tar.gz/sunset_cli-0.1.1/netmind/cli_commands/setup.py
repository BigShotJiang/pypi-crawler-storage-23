"""sunset setup - Interactive first-time configuration."""

import sys

from rich.console import Console
from rich.prompt import Prompt


def run_setup() -> None:
    """Interactive terminal setup (plain stdin/stdout, no TUI)."""
    console = Console()

    console.print("\n[bold cyan]Sunset[/bold cyan] -- First-Time Setup\n")
    console.print("This will save your configuration to ~/.sunset/.env\n")

    # 1. API key
    api_key = Prompt.ask("[bold]Anthropic API key[/bold]", password=True)

    if not api_key:
        console.print("[red]API key is required.[/red]")
        sys.exit(1)

    if not api_key.startswith("sk-ant-"):
        console.print(
            "[yellow]Warning:[/yellow] Key doesn't start with 'sk-ant-'. "
            "Saving anyway -- double-check your key."
        )

    # 2. License key
    license_key = Prompt.ask(
        "[bold]License key[/bold] (leave blank to skip)",
        default="",
    )

    # 3. Model selection
    model = Prompt.ask(
        "[bold]Claude model[/bold]",
        default="claude-sonnet-4-20250514",
    )

    # 4. Save
    from netmind.utils.config import save_env_file

    values = {"ANTHROPIC_API_KEY": api_key}
    if license_key:
        values["SUNSET_LICENSE_KEY"] = license_key
    if model != "claude-sonnet-4-20250514":
        values["CLAUDE_MODEL"] = model

    env_path = save_env_file(values)

    console.print(f"\n[green]Configuration saved to {env_path}[/green]")

    if license_key:
        # Validate the key
        from netmind.utils.license import validate_license

        console.print("[dim]Validating license...[/dim]")
        result = validate_license(license_key)
        if result.valid:
            email_str = f" ({result.email})" if result.email else ""
            console.print(f"[green]License active{email_str}[/green]")
        else:
            console.print(f"[yellow]License validation: {result.error}[/yellow]")
            console.print("You can re-activate later with [bold]sunset auth <key>[/bold]")
    else:
        console.print(
            "[dim]No license key provided. "
            "Activate later with [bold]sunset auth <key>[/bold][/dim]"
        )

    console.print("\nRun [bold cyan]sunset[/bold cyan] to start the TUI.\n")
