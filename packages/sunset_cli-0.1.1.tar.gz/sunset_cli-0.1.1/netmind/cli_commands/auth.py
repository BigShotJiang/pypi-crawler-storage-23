"""sunset auth — license key management."""

import argparse

from rich.console import Console

from netmind.utils.config import get_config, save_env_file, reset_and_reload
from netmind.utils.license import validate_license, check_license, clear_cache

console = Console()

ERROR_MESSAGES = {
    "key_not_found": "Invalid license key.",
    "key_revoked": "This license has been revoked.",
    "key_expired": "This license has expired.",
}


def run(args: argparse.Namespace) -> None:
    """Entry point for `sunset auth`."""
    value = getattr(args, "key_or_action", None)

    if value == "status" or value is None:
        _show_status()
    elif value == "logout":
        _logout()
    else:
        _activate(value)


def _activate(key: str) -> None:
    """Validate and store a license key."""
    console.print("\n[dim]Validating license key...[/dim]")

    result = validate_license(key)

    if result.valid:
        save_env_file({"SUNSET_LICENSE_KEY": key})
        reset_and_reload()

        email_str = f" ({result.email})" if result.email else ""
        expires_str = f"\n  Expires: {result.expires_at}" if result.expires_at else ""

        console.print(f"\n  [green bold]License activated{email_str}[/green bold]{expires_str}")
        console.print("\n  Run [cyan bold]sunset[/cyan bold] to start.\n")
    else:
        msg = ERROR_MESSAGES.get(result.error, result.error)
        console.print(f"\n  [red bold]{msg}[/red bold]\n")


def _show_status() -> None:
    """Show current license status."""
    config = get_config()

    if not config.has_license:
        console.print("\n  [dim]No license key configured.[/dim]")
        console.print("  Run [cyan bold]sunset auth <key>[/cyan bold] to activate.\n")
        return

    result = check_license()
    key = config.sunset_license_key
    redacted = key[:8] + "..." + key[-4:] if len(key) > 12 else key[:4] + "..."

    console.print(f"\n  Key:    [cyan]{redacted}[/cyan]")

    if result.valid:
        email_str = result.email or "unknown"
        console.print(f"  Email:  [green]{email_str}[/green]")
        console.print(f"  Status: [green bold]ACTIVE[/green bold]")
        if result.expires_at:
            console.print(f"  Expires: {result.expires_at}")
        if result.cached:
            console.print(f"  [dim](cached validation)[/dim]")
    else:
        msg = ERROR_MESSAGES.get(result.error, result.error)
        console.print(f"  Status: [red bold]INVALID[/red bold] — {msg}")

    console.print()


def _logout() -> None:
    """Remove license key and clear cache."""
    config = get_config()

    if not config.has_license:
        console.print("\n  [dim]No license key to remove.[/dim]\n")
        return

    save_env_file({"SUNSET_LICENSE_KEY": ""})
    clear_cache()
    reset_and_reload()

    console.print("\n  [yellow]License key removed.[/yellow]\n")
