"""sunset update — check for and install the latest version."""

from __future__ import annotations

import subprocess
import sys
from typing import Optional

import httpx

from netmind import __version__

PYPI_PACKAGE = "sunset-cli"


def _get_latest_version() -> Optional[str]:
    """Fetch the latest version from PyPI."""
    try:
        resp = httpx.get(
            f"https://pypi.org/pypi/{PYPI_PACKAGE}/json",
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()["info"]["version"]
    except Exception:
        pass
    return None


def run_update(force: bool = False) -> None:
    print(f"Current version: {__version__}")
    print("Checking for updates...")

    latest = _get_latest_version()

    if latest is None:
        print("Could not reach PyPI. Check your internet connection.")
        sys.exit(1)

    if latest == __version__ and not force:
        print(f"Already up to date (v{__version__}).")
        return

    if latest != __version__:
        print(f"New version available: {latest}")

    print(f"Updating sunset-cli...")

    # Detect install method and update accordingly
    cmd = _build_update_cmd()
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print(f"Updated to v{latest}.")
    except subprocess.CalledProcessError as e:
        print(f"Update failed: {e.stderr.strip()}")
        sys.exit(1)


def _build_update_cmd() -> "list[str]":
    """Pick the right update command based on how sunset was installed."""
    # Check if running under pipx
    exe = sys.executable
    if ".local/pipx" in exe or "pipx" in exe:
        return ["pipx", "upgrade", PYPI_PACKAGE]

    # Default: pip
    return [sys.executable, "-m", "pip", "install", "--upgrade", PYPI_PACKAGE]
