"""Approval request models for config change safety flow."""

import uuid
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ApprovalStatus(str, Enum):
    """Status of an approval request."""

    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


class ApprovalRequest(BaseModel):
    """A request for user approval before applying config changes."""

    request_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    device_id: str
    commands: list[str]
    description: str
    checkpoint_name: Optional[str] = None
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = Field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[str] = None  # 'user' or 'timeout'

    @property
    def is_pending(self) -> bool:
        return self.status == ApprovalStatus.PENDING

    @property
    def is_approved(self) -> bool:
        return self.status == ApprovalStatus.APPROVED

    def approve(self) -> None:
        """Mark this request as approved."""
        self.status = ApprovalStatus.APPROVED
        self.resolved_at = datetime.now()
        self.resolved_by = "user"

    def reject(self) -> None:
        """Mark this request as rejected."""
        self.status = ApprovalStatus.REJECTED
        self.resolved_at = datetime.now()
        self.resolved_by = "user"

    @property
    def commands_display(self) -> str:
        """Format commands for display in approval screen."""
        return "\n".join(self.commands)


class Checkpoint(BaseModel):
    """A configuration checkpoint for rollback."""

    name: str
    device_id: str
    config_snapshot: str = Field(repr=False)
    created_at: datetime = Field(default_factory=datetime.now)
    description: str = ""
