"""Allow running as python -m netmind."""

from netmind.cli import main

if __name__ == "__main__":
    main()
