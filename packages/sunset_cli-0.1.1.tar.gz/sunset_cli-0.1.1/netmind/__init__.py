"""Sunset - LLM-powered network automation agent."""

__version__ = "0.1.1"
