# NetMind

**LLM-powered network automation agent** -- connect to Cisco IOS routers, talk to an AI that configures them for you.

NetMind uses Claude as the orchestration brain. You describe what you want ("Configure OSPF area 0 between these three routers"), and it discovers the topology, generates the right commands, asks for your approval, applies them, and verifies everything works.

---

## Quick Start

```bash
# Clone and enter the project
cd netmind

# Create a virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Set your API key
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY

# Run
python main.py
```

## What It Does

1. **You add routers** via the Device Manager (Ctrl+D) -- IP, username, password.
2. **You ask NetMind** to configure something: "Set up OSPF area 0 on all routers."
3. **Claude discovers** the current state by running show commands over SSH.
4. **Claude generates** the exact IOS config commands needed.
5. **You review and approve** in the approval screen.
6. **Claude applies** the config, then verifies the result (neighbors up, routes learned).
7. **If something breaks**, there's a checkpoint to roll back.

## TUI Controls

| Key | Action |
|----------|-------------------------------|
| Ctrl+D | Open Device Manager |
| Ctrl+R | Toggle Read-Only / Interactive |
| Ctrl+L | Clear Chat |
| Ctrl+C | Quit |
| Escape | Back (from sub-screens) |

## Architecture

```
User (TUI)
    |
    v
ClaudeAgent  <---->  Claude API (tool calling)
    |
    v
ToolRegistry  --->  DeviceManager  --->  DeviceConnection (Netmiko/SSH)
    |                                         |
    v                                         v
SafetyGuard                              Cisco IOS Router
ApprovalManager
CheckpointManager
```

**Key principles:**
- Claude is the brain -- it decides what commands to run and in what order
- Every config change requires user approval (ApprovalScreen)
- Checkpoints are created before changes for rollback
- Read-only mode is on by default

## Project Structure

```
netmind/
├── main.py                         # Entry point
├── netmind/
│   ├── ui/                         # Textual TUI
│   │   ├── app.py                  # Main app class
│   │   ├── screens/                # Main, DeviceManager, Approval screens
│   │   └── widgets/                # ChatPanel, DeviceList, StatusBar
│   ├── core/                       # Device connectivity & safety
│   │   ├── device_connection.py    # Netmiko SSH wrapper
│   │   ├── device_manager.py       # Multi-device management
│   │   └── safety.py               # Approval flow, checkpoints, guard rails
│   ├── agent/                      # Claude integration
│   │   ├── claude_agent.py         # Main agent loop
│   │   ├── tool_registry.py        # Tool definitions
│   │   ├── conversation.py         # Message history management
│   │   ├── system_prompt.py        # Claude's persona and rules
│   │   └── tools/                  # Tool handler implementations
│   ├── protocols/                  # Protocol-specific helpers
│   │   └── ospf.py                 # OSPF verification
│   ├── models/                     # Pydantic data models
│   └── utils/                      # Config, logging, parsers
└── tests/
```

## Safety Model

NetMind starts in **read-only mode**. Claude can run any show command but cannot make changes.

When you switch to **interactive mode** (Ctrl+R):
- Config commands still require explicit approval
- A config checkpoint is taken before every change
- Dangerous commands (reload, erase, no ip address) are blocked or flagged
- Rollback is available if something goes wrong

## Testing

```bash
# Run all tests
python -m pytest tests/ -v

# Run parser tests only
python -m pytest tests/test_parsers.py -v
```

## Requirements

- Python 3.10+
- Access to Cisco IOS devices (GNS3, EVE-NG, or real hardware)
- Anthropic API key (Claude Sonnet 4.5)

## Current Protocol Support

- **OSPF** (MVP) -- full configure + verify + troubleshoot
- BGP, EIGRP, VLANs -- planned

## License

MIT
