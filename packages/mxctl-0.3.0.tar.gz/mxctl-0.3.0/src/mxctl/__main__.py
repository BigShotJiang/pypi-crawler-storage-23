"""Allow running as `python -m mxctl`."""

from mxctl.main import main

main()
