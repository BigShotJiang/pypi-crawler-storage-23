import{w as s}from"./svelte-CC-1DJjl.js";const o=s(null);export{o as s};
