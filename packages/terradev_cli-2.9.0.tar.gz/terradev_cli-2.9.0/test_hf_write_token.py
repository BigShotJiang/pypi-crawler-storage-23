import logging

#!/usr/bin/env python3
"""
Test HF Write Token for Ultimate Circumvention
"""

from huggingface_hub import HfApi
import os

def test_write_token():
    """Test if we have proper write token access"""
    
    # Get token from environment
    token = os.getenv('HF_TOKEN')
    if not token:
        logging.info("❌ No HF_TOKEN found. Set it with:")
        logging.info("export HF_TOKEN='hf_YOUR_WRITE_TOKEN_HERE'")
        return False
    
    try:
        api = HfApi(token=token)
        
        # Test 1: Whoami (basic auth)
        logging.info("🔍 Testing basic authentication...")
        user_info = api.whoami()
        logging.info(f"✅ Authenticated as: {user_info.username}")
        
        # Test 2: Create repo (write access)
        logging.info("🔍 Testing write access...")
        repo_url = api.create_repo(
            repo_id=f"{user_info.username}/test-ultimate-circumvention",
            repo_type="model",
            private=False,
            exist_ok=True
        )
        logging.info(f"✅ Write access confirmed: {repo_url.url}")
        
        # Test 3: List models (read access)
        logging.info("🔍 Testing model access...")
        models = api.list_models(filter="inference:warm", sort="downloads", limit=3)
        logging.info(f"✅ Model access: {[m.id for m in models]}")
        
        logging.info("\n🎉 WRITE TOKEN WORKING! Ready for ultimate circumvention!")
        return True
        
    except Exception as e:
        logging.info(f"❌ Write token failed: {e}")
        logging.info("\n💡 Troubleshooting:")
        logging.info("1. Make sure it's a WRITE token (not read token)
        logging.info("2. Check token has repo.write permission")
        logging.info("3. Verify token hasn't expired")
        logging.info("4. Ensure you're logged into HF CLI: hf login")
        return False

if __name__ == "__main__":
    test_write_token()
