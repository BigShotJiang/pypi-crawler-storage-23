#!/usr/bin/env python3
"""
Advanced Latency and Jitter Scoring System
Multi-provider, multi-region network performance analysis
"""

import asyncio
import aiohttp
import statistics
import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path
import subprocess
import socket
import ping3
import requests
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from scipy import stats

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class LatencyMetrics:
    """Latency measurement metrics"""
    provider: str
    region: str
    endpoint: str
    latency_ms: float
    jitter_ms: float
    packet_loss: float
    bandwidth_mbps: float
    timestamp: datetime
    test_duration: float
    success_rate: float

@dataclass
class JitterMetrics:
    """Jitter and variability metrics"""
    provider: str
    region: str
    jitter_std: float
    jitter_cv: float  # Coefficient of variation
    latency_variance: float
    latency_range: float
    stability_score: float
    consistency_score: float

@dataclass
class NetworkScore:
    """Comprehensive network performance score"""
    provider: str
    region: str
    latency_score: float
    jitter_score: float
    reliability_score: float
    bandwidth_score: float
    overall_score: float
    grade: str  # A+, A, B+, B, C+, C, D, F
    recommendation: str

class LatencyJitterAnalyzer:
    """Advanced latency and jitter analysis system"""
    
    def __init__(self):
        self.session = None
        self.executor = ThreadPoolExecutor(max_workers=20)
        self.metrics_history = []
        self.provider_endpoints = {
            "vast": {
                "us-east-1": ["https://console.vast.ai", "https://api.vast.ai"],
                "us-west-1": ["https://us-west.vast.ai"],
                "eu-west-1": ["https://eu.vast.ai"],
                "asia-east-1": ["https://asia.vast.ai"]
            },
            "runpod": {
                "us-east-1": ["https://api.runpod.io", "https://runpod.io"],
                "us-west-1": ["https://us-west.runpod.io"],
                "eu-west-1": ["https://eu.runpod.io"],
                "asia-east-1": ["https://asia.runpod.io"]
            },
            "aws": {
                "us-east-1": ["https://ec2.amazonaws.com", "https://aws.amazon.com"],
                "us-west-1": ["https://us-west-1.ec2.amazonaws.com"],
                "eu-west-1": ["https://eu-west-1.ec2.amazonaws.com"],
                "asia-east-1": ["https://ap-northeast-1.ec2.amazonaws.com"]
            },
            "gcp": {
                "us-east1": ["https://compute.googleapis.com", "https://cloud.google.com"],
                "us-west1": ["https://us-west1-compute.googleapis.com"],
                "europe-west1": ["https://europe-west1-compute.googleapis.com"],
                "asia-east1": ["https://asia-east1-compute.googleapis.com"]
            }
        }
        self.test_config = {
            "ping_count": 10,
            "http_timeout": 5.0,
            "bandwidth_test_size": 1024 * 1024,  # 1MB
            "concurrent_tests": 5,
            "retry_count": 3
        }
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.test_config["http_timeout"])
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
        self.executor.shutdown(wait=True)
    
    async def measure_ping_latency(self, host: str, count: int = None) -> Tuple[float, float, float]:
        """Measure ping latency and jitter"""
        count = count or self.test_config["ping_count"]
        latencies = []
        
        for _ in range(count):
            try:
                latency = ping3.ping(host, timeout=2.0)
                if latency is not None:
                    latencies.append(latency * 1000)  # Convert to ms
            except Exception as e:
                logger.warning(f"Ping failed for {host}: {e}")
        
        if not latencies:
            return 0.0, 0.0, 100.0  # No response
        
        avg_latency = statistics.mean(latencies)
        jitter = statistics.stdev(latencies) if len(latencies) > 1 else 0.0
        packet_loss = (count - len(latencies)) / count * 100
        
        return avg_latency, jitter, packet_loss
    
    async def measure_http_latency(self, url: str) -> Tuple[float, float, bool]:
        """Measure HTTP request latency"""
        start_time = time.time()
        
        try:
            async with self.session.get(url) as response:
                if response.status == 200:
                    end_time = time.time()
                    latency = (end_time - start_time) * 1000
                    return latency, 0.0, True
                else:
                    return 0.0, 0.0, False
        except Exception as e:
            logger.warning(f"HTTP request failed for {url}: {e}")
            return 0.0, 0.0, False
    
    async def measure_bandwidth(self, url: str) -> float:
        """Measure bandwidth to endpoint"""
        try:
            # Use a small file for bandwidth test
            test_url = f"{url}/test-file.bin" if not url.endswith('/') else f"{url}test-file.bin"
            
            start_time = time.time()
            async with self.session.get(test_url) as response:
                if response.status == 200:
                    data = await response.read()
                    end_time = time.time()
                    
                    duration = end_time - start_time
                    if duration > 0:
                        bandwidth_bps = len(data) / duration
                        bandwidth_mbps = bandwidth_bps / (1024 * 1024)
                        return bandwidth_mbps
            return 0.0
        except Exception as e:
            logger.warning(f"Bandwidth test failed for {url}: {e}")
            return 0.0
    
    async def test_endpoint(self, provider: str, region: str, endpoint: str) -> LatencyMetrics:
        """Comprehensive endpoint testing"""
        logger.info(f"Testing {provider} {region} - {endpoint}")
        
        start_time = time.time()
        
        # Extract hostname from URL
        hostname = endpoint.replace("https://", "").replace("http://", "").split("/")[0]
        
        # Measure ping latency
        ping_latency, ping_jitter, packet_loss = await self.measure_ping_latency(hostname)
        
        # Measure HTTP latency
        http_latency, http_jitter, http_success = await self.measure_http_latency(endpoint)
        
        # Measure bandwidth
        bandwidth = await self.measure_bandwidth(endpoint)
        
        # Use the best available latency measurement
        latency = http_latency if http_success else ping_latency
        jitter = ping_jitter  # Ping jitter is more reliable
        
        end_time = time.time()
        test_duration = end_time - start_time
        
        # Calculate success rate
        success_rate = 100.0 if http_success else (100.0 - packet_loss)
        
        return LatencyMetrics(
            provider=provider,
            region=region,
            endpoint=endpoint,
            latency_ms=latency,
            jitter_ms=jitter,
            packet_loss=packet_loss,
            bandwidth_mbps=bandwidth,
            timestamp=datetime.now(),
            test_duration=test_duration,
            success_rate=success_rate
        )
    
    async def test_provider_region(self, provider: str, region: str) -> List[LatencyMetrics]:
        """Test all endpoints for a provider/region"""
        endpoints = self.provider_endpoints.get(provider, {}).get(region, [])
        
        tasks = [
            self.test_endpoint(provider, region, endpoint)
            for endpoint in endpoints
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions
        valid_results = [
            result for result in results
            if isinstance(result, LatencyMetrics)
        ]
        
        return valid_results
    
    async def run_comprehensive_test(self) -> List[LatencyMetrics]:
        """Run comprehensive latency tests across all providers/regions"""
        all_metrics = []
        
        for provider, regions in self.provider_endpoints.items():
            for region in regions:
                logger.info(f"Testing {provider} in {region}")
                metrics = await self.test_provider_region(provider, region)
                all_metrics.extend(metrics)
                
                # Small delay between regions to avoid rate limiting
                await asyncio.sleep(0.1)
        
        self.metrics_history.extend(all_metrics)
        return all_metrics
    
    def calculate_jitter_metrics(self, provider_metrics: List[LatencyMetrics]) -> JitterMetrics:
        """Calculate jitter and variability metrics"""
        if not provider_metrics:
            return JitterMetrics("", "", 0, 0, 0, 0, 0, 0)
        
        latencies = [m.latency_ms for m in provider_metrics if m.latency_ms > 0]
        jitters = [m.jitter_ms for m in provider_metrics if m.jitter_ms > 0]
        
        if not latencies:
            return JitterMetrics(provider_metrics[0].provider, provider_metrics[0].region, 0, 0, 0, 0, 0, 0)
        
        # Calculate jitter statistics
        jitter_std = statistics.stdev(jitters) if len(jitters) > 1 else 0.0
        jitter_cv = jitter_std / statistics.mean(jitters) if statistics.mean(jitters) > 0 else 0.0
        
        # Calculate latency variability
        latency_variance = statistics.variance(latencies) if len(latencies) > 1 else 0.0
        latency_range = max(latencies) - min(latencies)
        
        # Calculate stability and consistency scores
        stability_score = max(0, 100 - jitter_cv * 100)  # Lower CV = higher stability
        consistency_score = max(0, 100 - (latency_range / statistics.mean(latencies)) * 100)
        
        return JitterMetrics(
            provider=provider_metrics[0].provider,
            region=provider_metrics[0].region,
            jitter_std=jitter_std,
            jitter_cv=jitter_cv,
            latency_variance=latency_variance,
            latency_range=latency_range,
            stability_score=stability_score,
            consistency_score=consistency_score
        )
    
    def calculate_network_score(self, metrics: LatencyMetrics, jitter_metrics: JitterMetrics) -> NetworkScore:
        """Calculate comprehensive network performance score"""
        
        # Latency scoring (lower is better)
        if metrics.latency_ms <= 50:
            latency_score = 100
        elif metrics.latency_ms <= 100:
            latency_score = 90
        elif metrics.latency_ms <= 200:
            latency_score = 80
        elif metrics.latency_ms <= 500:
            latency_score = 70
        else:
            latency_score = 50
        
        # Jitter scoring (lower is better)
        if jitter_metrics.jitter_std <= 5:
            jitter_score = 100
        elif jitter_metrics.jitter_std <= 10:
            jitter_score = 90
        elif jitter_metrics.jitter_std <= 20:
            jitter_score = 80
        elif jitter_metrics.jitter_std <= 50:
            jitter_score = 70
        else:
            jitter_score = 50
        
        # Reliability scoring (higher is better)
        reliability_score = metrics.success_rate
        
        # Bandwidth scoring (higher is better)
        if metrics.bandwidth_mbps >= 100:
            bandwidth_score = 100
        elif metrics.bandwidth_mbps >= 50:
            bandwidth_score = 90
        elif metrics.bandwidth_mbps >= 20:
            bandwidth_score = 80
        elif metrics.bandwidth_mbps >= 10:
            bandwidth_score = 70
        elif metrics.bandwidth_mbps > 0:
            bandwidth_score = 60
        else:
            bandwidth_score = 30
        
        # Overall weighted score
        weights = {
            "latency": 0.3,
            "jitter": 0.25,
            "reliability": 0.3,
            "bandwidth": 0.15
        }
        
        overall_score = (
            latency_score * weights["latency"] +
            jitter_score * weights["jitter"] +
            reliability_score * weights["reliability"] +
            bandwidth_score * weights["bandwidth"]
        )
        
        # Grade assignment
        if overall_score >= 95:
            grade = "A+"
        elif overall_score >= 90:
            grade = "A"
        elif overall_score >= 85:
            grade = "B+"
        elif overall_score >= 80:
            grade = "B"
        elif overall_score >= 75:
            grade = "C+"
        elif overall_score >= 70:
            grade = "C"
        elif overall_score >= 60:
            grade = "D"
        else:
            grade = "F"
        
        # Recommendation
        if grade in ["A+", "A"]:
            recommendation = "Excellent choice for latency-sensitive workloads"
        elif grade in ["B+", "B"]:
            recommendation = "Good choice for most workloads"
        elif grade in ["C+", "C"]:
            recommendation = "Acceptable for non-critical workloads"
        else:
            recommendation = "Not recommended for production workloads"
        
        return NetworkScore(
            provider=metrics.provider,
            region=metrics.region,
            latency_score=latency_score,
            jitter_score=jitter_score,
            reliability_score=reliability_score,
            bandwidth_score=bandwidth_score,
            overall_score=overall_score,
            grade=grade,
            recommendation=recommendation
        )
    
    async def generate_provider_rankings(self) -> List[NetworkScore]:
        """Generate ranked list of providers by network performance"""
        # Group metrics by provider and region
        provider_region_metrics = {}
        
        for metric in self.metrics_history:
            key = (metric.provider, metric.region)
            if key not in provider_region_metrics:
                provider_region_metrics[key] = []
            provider_region_metrics[key].append(metric)
        
        # Calculate scores for each provider/region
        scores = []
        for (provider, region), metrics in provider_region_metrics.items():
            if metrics:
                # Use the best metrics for this provider/region
                best_metric = min(metrics, key=lambda m: m.latency_ms)
                jitter_metrics = self.calculate_jitter_metrics(metrics)
                score = self.calculate_network_score(best_metric, jitter_metrics)
                scores.append(score)
        
        # Sort by overall score
        return sorted(scores, key=lambda s: s.overall_score, reverse=True)
    
    def save_metrics(self, filename: str = None):
        """Save metrics to file"""
        if filename is None:
            filename = f"latency_metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        data = {
            "timestamp": datetime.now().isoformat(),
            "metrics": [asdict(m) for m in self.metrics_history],
            "config": self.test_config
        }
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        
        logger.info(f"Metrics saved to {filename}")
    
    def load_metrics(self, filename: str):
        """Load metrics from file"""
        with open(filename, 'r') as f:
            data = json.load(f)
        
        # Convert back to dataclass objects
        for metric_data in data["metrics"]:
            metric_data["timestamp"] = datetime.fromisoformat(metric_data["timestamp"])
            self.metrics_history.append(LatencyMetrics(**metric_data))
        
        logger.info(f"Loaded {len(self.metrics_history)} metrics from {filename}")

async def main():
    """Main test function"""
    logging.info("🔧 Advanced Latency and Jitter Analysis")
    logging.info("=" * 50)
    
    async with LatencyJitterAnalyzer() as analyzer:
        logging.info(f"\n📊 Running comprehensive network tests...")
        metrics = await analyzer.run_comprehensive_test()
        
        logging.info(f"\n✅ Completed {len(metrics)
        
        # Generate rankings
        rankings = await analyzer.generate_provider_rankings()
        
        logging.info(f"\n🏆 Provider Rankings:")
        for i, score in enumerate(rankings, 1):
            logging.info(f"{i}. {score.provider} ({score.region})
            logging.info(f"   {score.recommendation}")
        
        # Save results
        analyzer.save_metrics()
        
        logging.info(f"\n🎯 Analysis completed!")

if __name__ == "__main__":
    asyncio.run(main())
