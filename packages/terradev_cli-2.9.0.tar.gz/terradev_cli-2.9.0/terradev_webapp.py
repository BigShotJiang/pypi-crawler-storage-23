#!/usr/bin/env python3
"""
Terradev WebApp - ML Training Platform
Integration hub for compute providers, HuggingFace, Kubernetes, and GitHub
"""

import asyncio
import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path
import subprocess
import yaml

# Web framework imports
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# Existing integrations
from vast_ai_integration import VastArbitrageIntegration
from enhanced_arbitrage_engine import EnhancedArbitrageEngine
from kubernetes_connect_card import KubernetesConnectCard
from kubernetes_terminal_dashboard import KubernetesTerminalDashboard
from github_api_integration import GitHubAPIIntegration

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Data models
@dataclass
class ComputeProvider:
    """Compute provider configuration"""
    name: str
    api_key: str
    endpoint: str
    region: str
    enabled: bool
    gpu_types: List[str]
    pricing_model: str

@dataclass
class HuggingFaceConfig:
    """HuggingFace configuration"""
    api_token: str
    models_cache: Dict[str, Any]
    datasets_cache: Dict[str, Any]
    enabled: bool

@dataclass
class KubernetesConfig:
    """Kubernetes configuration"""
    kubeconfig_path: str
    namespace: str
    gpu_nodes: bool
    enabled: bool

@dataclass
class GitHubConfig:
    """GitHub configuration"""
    token: str
    repository: str
    branch: str
    enabled: bool

@dataclass
class TrainingJob:
    """Training job configuration"""
    job_id: str
    model_name: str
    dataset_name: str
    provider: str
    instance_type: str
    gpu_type: str
    gpu_count: int
    framework: str
    status: str
    created_at: datetime
    progress: float
    logs: List[str]

# Pydantic models for API
class ProviderConfig(BaseModel):
    name: str
    api_key: str
    endpoint: str
    region: str
    enabled: bool

class TrainingRequest(BaseModel):
    model_name: str
    dataset_name: str
    gpu_type: str
    gpu_count: int
    framework: str
    hours: int
    budget: float

class GitHubRepo(BaseModel):
    repository: str
    branch: str
    token: str

class TerradevWebApp:
    """Terradev WebApp - ML Training Platform"""
    
    def __init__(self):
        self.app = FastAPI(title="Terradev WebApp", version="1.0.0")
        self.setup_middleware()
        self.setup_routes()
        
        # Initialize integrations
        self.compute_providers = {}
        self.huggingface_config = None
        self.kubernetes_config = None
        self.github_config = None
        self.training_jobs = {}
        self.terminal_sessions = {}
        
        # Initialize engines
        self.vast_engine = None
        self.enhanced_engine = None
        self.k8s_card = None
        self.k8s_dashboard = None
        self.github_integration = None
        
        # Load configurations
        self.load_configurations()
    
    def setup_middleware(self):
        """Setup CORS and other middleware"""
        _allowed_origins = os.getenv("CORS_ORIGINS", "https://terradev.com,https://app.terradev.com").split(",")
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=[o.strip() for o in _allowed_origins],
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            allow_headers=["Authorization", "Content-Type", "Accept"],
        )
    
# TODO: REFACTOR - setup_routes() is 116 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def setup_routes(self):
        """Setup API routes"""
        
        @self.app.get("/", response_class=HTMLResponse)
        async def dashboard():
            """Main dashboard page"""
            return self.get_dashboard_html()
        
        @self.app.get("/api/status")
        async def get_status():
            """Get system status"""
            return {
                "status": "running",
                "providers": list(self.compute_providers.keys()),
                "huggingface": self.huggingface_config.enabled if self.huggingface_config else False,
                "kubernetes": self.kubernetes_config.enabled if self.kubernetes_config else False,
                "github": self.github_config.enabled if self.github_config else False,
                "active_jobs": len(self.training_jobs)
            }
        
        # Compute Provider endpoints
        @self.app.post("/api/providers/connect")
        async def connect_provider(config: ProviderConfig):
            """Connect to compute provider"""
            return await self.connect_compute_provider(config)
        
        @self.app.get("/api/providers/{provider}/instances")
        async def get_instances(provider: str):
            """Get available instances from provider"""
            return await self.get_provider_instances(provider)
        
        @self.app.get("/api/providers/scan")
        async def scan_all_providers(gpu_type: str, budget: float):
            """Scan all providers for best options"""
            return await self.scan_providers(gpu_type, budget)
        
        # HuggingFace endpoints
        @self.app.post("/api/huggingface/connect")
        async def connect_huggingface(api_token: str):
            """Connect to HuggingFace"""
            return await self.connect_huggingface(api_token)
        
        @self.app.get("/api/huggingface/models")
        async def get_models():
            """Get available models"""
            return await self.get_huggingface_models()
        
        @self.app.get("/api/huggingface/datasets")
        async def get_datasets():
            """Get available datasets"""
            return await self.get_huggingface_datasets()
        
        # Kubernetes endpoints
        @self.app.post("/api/kubernetes/connect")
        async def connect_kubernetes(kubeconfig_path: str):
            """Connect to Kubernetes cluster"""
            return await self.connect_kubernetes(kubeconfig_path)
        
        @self.app.get("/api/kubernetes/nodes")
        async def get_nodes():
            """Get Kubernetes nodes"""
            return await self.get_kubernetes_nodes()
        
        @self.app.post("/api/kubernetes/deploy")
        async def deploy_job(request: TrainingRequest):
            """Deploy training job"""
            return await self.deploy_training_job(request)
        
        # GitHub endpoints
        @self.app.post("/api/github/connect")
        async def connect_github(repo: GitHubRepo):
            """Connect to GitHub repository"""
            return await self.connect_github_integration(repo)
        
        @self.app.get("/api/github/repos")
        async def get_repos():
            """Get GitHub repositories"""
            return await self.get_github_repositories()
        
        @self.app.post("/api/github/import")
        async def import_from_github(repo_url: str):
            """Import configuration from GitHub"""
            return await self.import_github_configs(repo_url)
        
        @self.app.post("/api/github/export")
        async def export_to_github(repo_url: str, configs: Dict[str, Any]):
            """Export configuration to GitHub"""
            return await self.export_github_configs(repo_url, configs)
        
        @self.app.post("/api/github/sync")
        async def sync_with_github(repo_url: str):
            """Synchronize configurations with GitHub"""
            return await self.sync_github_configs(repo_url)
        
        # Training job endpoints
        @self.app.get("/api/jobs")
        async def get_jobs():
            """Get all training jobs"""
            return {"jobs": [asdict(job) for job in self.training_jobs.values()]}
        
        @self.app.get("/api/jobs/{job_id}")
        async def get_job(job_id: str):
            """Get specific job details"""
            if job_id not in self.training_jobs:
                raise HTTPException(status_code=404, detail="Job not found")
            return asdict(self.training_jobs[job_id])
        
        @self.app.delete("/api/jobs/{job_id}")
        async def delete_job(job_id: str):
            """Delete training job"""
            return await self.delete_training_job(job_id)
        
        # Terminal WebSocket
        @self.app.websocket("/ws/terminal/{session_id}")
        async def terminal_websocket(websocket: WebSocket, session_id: str):
            """Terminal WebSocket connection"""
            await self.handle_terminal_websocket(websocket, session_id)
    
    def load_configurations(self):
        """Load configurations from files or environment"""
        
        # Load compute providers
        config_file = Path("terradev_config.json")
        if config_file.exists():
            with open(config_file, 'r') as f:
                config = json.load(f)
                
                # Load compute providers
                for provider_name, provider_config in config.get("providers", {}).items():
                    self.compute_providers[provider_name] = ComputeProvider(
                        name=provider_name,
                        api_key=provider_config.get("api_key", ""),
                        endpoint=provider_config.get("endpoint", ""),
                        region=provider_config.get("region", "us-east-1"),
                        enabled=provider_config.get("enabled", False),
                        gpu_types=provider_config.get("gpu_types", []),
                        pricing_model=provider_config.get("pricing_model", "hourly")
                    )
                
                # Load HuggingFace config
                hf_config = config.get("huggingface", {})
                if hf_config:
                    self.huggingface_config = HuggingFaceConfig(
                        api_token=hf_config.get("api_token", ""),
                        models_cache={},
                        datasets_cache={},
                        enabled=hf_config.get("enabled", False)
                    )
                
                # Load Kubernetes config
                k8s_config = config.get("kubernetes", {})
                if k8s_config:
                    self.kubernetes_config = KubernetesConfig(
                        kubeconfig_path=k8s_config.get("kubeconfig_path", "~/.kube/config"),
                        namespace=k8s_config.get("namespace", "default"),
                        gpu_nodes=k8s_config.get("gpu_nodes", False),
                        enabled=k8s_config.get("enabled", False)
                    )
                
                # Load GitHub config
                gh_config = config.get("github", {})
                if gh_config:
                    self.github_config = GitHubConfig(
                        token=gh_config.get("token", ""),
                        repository=gh_config.get("repository", ""),
                        branch=gh_config.get("branch", "main"),
                        enabled=gh_config.get("enabled", False)
                    )
    
    async def connect_compute_provider(self, config: ProviderConfig):
        """Connect to compute provider"""
        try:
            if config.name == "vast":
                self.vast_engine = VastArbitrageIntegration(config.api_key)
                self.compute_providers[config.name] = ComputeProvider(
                    name=config.name,
                    api_key=config.api_key,
                    endpoint=config.endpoint,
                    region=config.region,
                    enabled=True,
                    gpu_types=["A100", "V100", "A10G", "T4"],
                    pricing_model="hourly"
                )
            elif config.name == "enhanced":
                self.enhanced_engine = EnhancedArbitrageEngine()
                self.compute_providers[config.name] = ComputeProvider(
                    name=config.name,
                    api_key=config.api_key,
                    endpoint=config.endpoint,
                    region=config.region,
                    enabled=True,
                    gpu_types=["A100", "V100", "A10G", "T4"],
                    pricing_model="hourly"
                )
            
            return {"status": "connected", "provider": config.name}
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
    
    async def get_provider_instances(self, provider: str):
        """Get available instances from provider"""
        if provider not in self.compute_providers:
            raise HTTPException(status_code=404, detail="Provider not found")
        
        try:
            if provider == "vast" and self.vast_engine:
                # Get Vast.ai instances
                offers = await self.vast_engine.search_offers("A100")
                return {"instances": offers[:10]}  # Return first 10
            elif provider == "enhanced" and self.enhanced_engine:
                # Get enhanced engine instances
                opportunities = await self.enhanced_engine.find_enhanced_arbitrage_opportunities("A100")
                return {"instances": [asdict(opp) for opp in opportunities[:10]]}
            else:
                return {"instances": []}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def scan_providers(self, gpu_type: str, budget: float):
        """Scan all providers for best options"""
        try:
            if self.enhanced_engine:
                opportunities = await self.enhanced_engine.scan_all_providers(gpu_type, budget)
                return {"opportunities": opportunities}
            else:
                return {"opportunities": []}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def connect_huggingface(self, api_token: str):
        """Connect to HuggingFace"""
        try:
            self.huggingface_config = HuggingFaceConfig(
                api_token=api_token,
                models_cache={},
                datasets_cache={},
                enabled=True
            )
            
            # Test connection by fetching popular models
            from huggingface_integration import HuggingFaceIntegration
            hf_integration = HuggingFaceIntegration(api_token)
            models = await hf_integration.search_models("", limit=10)
            
            self.huggingface_config.models_cache = {model.model_id: asdict(model) for model in models}
            
            return {"status": "connected", "models_loaded": len(models)}
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
    
    async def get_huggingface_models(self):
        """Get available HuggingFace models"""
        if not self.huggingface_config or not self.huggingface_config.enabled:
            raise HTTPException(status_code=400, detail="HuggingFace not connected")
        
        return {"models": list(self.huggingface_config.models_cache.values())}
    
    async def get_huggingface_datasets(self):
        """Get available HuggingFace datasets"""
        if not self.huggingface_config or not self.huggingface_config.enabled:
            raise HTTPException(status_code=400, detail="HuggingFace not connected")
        
        return {"datasets": list(self.huggingface_config.datasets_cache.values())}
    
    async def connect_kubernetes(self, kubeconfig_path: str):
        """Connect to Kubernetes cluster"""
        try:
            self.k8s_card = KubernetesConnectCard()
            self.k8s_card.kubeconfig_path = kubeconfig_path
            
            connection = self.k8s_card.connect_to_cluster()
            if "error" in connection:
                raise HTTPException(status_code=400, detail=connection["error"])
            
            self.kubernetes_config = KubernetesConfig(
                kubeconfig_path=kubeconfig_path,
                namespace="default",
                gpu_nodes=len(self.k8s_card.gpu_nodes) > 0,
                enabled=True
            )
            
            return {
                "status": "connected",
                "nodes": len(self.k8s_card.available_nodes),
                "gpu_nodes": len(self.k8s_card.gpu_nodes)
            }
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
    
    async def get_kubernetes_nodes(self):
        """Get Kubernetes nodes"""
        if not self.kubernetes_config or not self.kubernetes_config.enabled:
            raise HTTPException(status_code=400, detail="Kubernetes not connected")
        
        return {
            "nodes": self.k8s_card.available_nodes,
            "gpu_nodes": self.k8s_card.gpu_nodes
        }
    
    async def deploy_training_job(self, request: TrainingRequest):
        """Deploy training job"""
        if not self.kubernetes_config or not self.kubernetes_config.enabled:
            raise HTTPException(status_code=400, detail="Kubernetes not connected")
        
        try:
            job_id = f"training-{int(datetime.now().timestamp())}"
            
            job_config = {
                "name": job_id,
                "image": f"{request.framework}/{request.framework}:latest",
                "command": ["python", "train.py"],
                "env": {
                    "MODEL_NAME": request.model_name,
                    "DATASET_NAME": request.dataset_name,
                    "GPU_TYPE": request.gpu_type,
                    "TRAINING_HOURS": str(request.hours)
                },
                "cpu": "4",
                "memory": "16Gi",
                "gpu": request.gpu_count,
                "ttl": request.hours * 3600
            }
            
            deployment = self.k8s_card.deploy_training_job(job_config)
            
            if "error" in deployment:
                raise HTTPException(status_code=400, detail=deployment["error"])
            
            # Create job record
            job = TrainingJob(
                job_id=job_id,
                model_name=request.model_name,
                dataset_name=request.dataset_name,
                provider="kubernetes",
                instance_type=f"{request.gpu_type}x{request.gpu_count}",
                gpu_type=request.gpu_type,
                gpu_count=request.gpu_count,
                framework=request.framework,
                status="running",
                created_at=datetime.now(),
                progress=0.0,
                logs=[]
            )
            
            self.training_jobs[job_id] = job
            
            return {"status": "deployed", "job_id": job_id}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def connect_github_integration(self, repo: GitHubRepo):
        """Connect to GitHub repository"""
        try:
            self.github_integration = GitHubAPIIntegration(repo.token)
            auth_result = await self.github_integration.authenticate(repo.token)
            
            if auth_result["status"] == "authenticated":
                self.github_config = GitHubConfig(
                    token=repo.token,
                    repository=repo.repository,
                    branch=repo.branch,
                    enabled=True
                )
                
                return {
                    "status": "connected",
                    "repository": repo.repository,
                    "username": auth_result["username"]
                }
            else:
                raise HTTPException(status_code=400, detail=auth_result.get("message", "Authentication failed"))
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
    
    async def get_github_repositories(self):
        """Get GitHub repositories"""
        if not self.github_integration or not self.github_config.enabled:
            raise HTTPException(status_code=400, detail="GitHub not connected")
        
        try:
            repos = await self.github_integration.get_user_repositories()
            return {"repositories": [asdict(repo) for repo in repos]}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def import_github_configs(self, repo_url: str):
        """Import configuration from GitHub"""
        if not self.github_integration or not self.github_config.enabled:
            raise HTTPException(status_code=400, detail="GitHub not connected")
        
        try:
            # Extract repo full name from URL
            if "github.com" in repo_url:
                repo_full_name = repo_url.split("github.com/")[-1].replace(".git", "")
            else:
                repo_full_name = repo_url
            
            result = await self.github_integration.import_terradev_configs(repo_full_name)
            return result
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def export_github_configs(self, repo_url: str, configs: Dict[str, Any]):
        """Export configuration to GitHub"""
        if not self.github_integration or not self.github_config.enabled:
            raise HTTPException(status_code=400, detail="GitHub not connected")
        
        try:
            # Extract repo full name from URL
            if "github.com" in repo_url:
                repo_full_name = repo_url.split("github.com/")[-1].replace(".git", "")
            else:
                repo_full_name = repo_url
            
            result = await self.github_integration.export_terradev_configs(repo_full_name, configs)
            return result
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def sync_github_configs(self, repo_url: str):
        """Synchronize configurations with GitHub"""
        if not self.github_integration or not self.github_config.enabled:
            raise HTTPException(status_code=400, detail="GitHub not connected")
        
        try:
            # Extract repo full name from URL
            if "github.com" in repo_url:
                repo_full_name = repo_url.split("github.com/")[-1].replace(".git", "")
            else:
                repo_full_name = repo_url
            
            # Get current local configs
            local_configs = {
                "terradev_config.json": json.dumps({
                    "providers": {name: asdict(provider) for name, provider in self.compute_providers.items()},
                    "huggingface": asdict(self.huggingface_config) if self.huggingface_config else {},
                    "kubernetes": asdict(self.kubernetes_config) if self.kubernetes_config else {},
                    "github": asdict(self.github_config) if self.github_config else {}
                }, indent=2)
            }
            
            result = await self.github_integration.sync_with_github(repo_full_name, local_configs)
            return result
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def delete_training_job(self, job_id: str):
        """Delete training job"""
        if job_id not in self.training_jobs:
            raise HTTPException(status_code=404, detail="Job not found")
        
        try:
            if self.k8s_card:
                cleanup = self.k8s_card.cleanup_job(job_id)
                if "error" in cleanup:
                    raise HTTPException(status_code=400, detail=cleanup["error"])
            
            del self.training_jobs[job_id]
            return {"status": "deleted"}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def handle_terminal_websocket(self, websocket: WebSocket, session_id: str):
        """Handle terminal WebSocket connection"""
        await websocket.accept()
        
        try:
            # Initialize terminal session
            self.terminal_sessions[session_id] = {
                "websocket": websocket,
                "connected": True
            }
            
            # Send welcome message
            await websocket.send_text("🚀 Terradev Terminal Connected\n")
            await websocket.send_text("Type 'help' for available commands\n")
            
            # Handle messages
            while True:
                data = await websocket.receive_text()
                
                if data == "help":
                    await websocket.send_text("Available commands:\n")
                    await websocket.send_text("  status - Show system status\n")
                    await websocket.send_text("  providers - List connected providers\n")
                    await websocket.send_text("  jobs - List training jobs\n")
                    await websocket.send_text("  connect <provider> - Connect to provider\n")
                    await websocket.send_text("  deploy <config> - Deploy training job\n")
                elif data == "status":
                    status = await self.get_system_status()
                    await websocket.send_text(f"System Status: {status}\n")
                elif data == "providers":
                    providers = list(self.compute_providers.keys())
                    await websocket.send_text(f"Connected Providers: {providers}\n")
                elif data == "jobs":
                    jobs = list(self.training_jobs.keys())
                    await websocket.send_text(f"Active Jobs: {jobs}\n")
                else:
                    await websocket.send_text(f"Unknown command: {data}\n")
        
        except WebSocketDisconnect:
            if session_id in self.terminal_sessions:
                del self.terminal_sessions[session_id]
    
    async def get_system_status(self):
        """Get system status"""
        return {
            "providers": len(self.compute_providers),
            "jobs": len(self.training_jobs),
            "huggingface": self.huggingface_config.enabled if self.huggingface_config else False,
            "kubernetes": self.kubernetes_config.enabled if self.kubernetes_config else False,
            "github": self.github_config.enabled if self.github_config else False
        }
    
    async def create_terradev_repo(self, repo_name: str = "terradev-configs"):
        """Create Terradev configuration repository"""
        if not self.github_integration or not self.github_config.enabled:
            raise HTTPException(status_code=400, detail="GitHub not connected")
        
        try:
            result = await self.github_integration.create_terradev_repository(repo_name)
            return result
        except Exception as e:
# TODO: REFACTOR - get_dashboard_html() is 411 lines long (should be <50)
# Consider breaking into smaller, focused functions
            raise HTTPException(status_code=500, detail=str(e))
    
    def get_dashboard_html(self):
        """Get dashboard HTML"""
        return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terradev - ML Training Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
</head>
<body class="bg-gray-900 text-white">
    <div class="container mx-auto p-4">
        <header class="mb-8">
            <h1 class="text-4xl font-bold text-blue-400">🚀 Terradev</h1>
            <p class="text-gray-400">ML Training Platform - Compute, Models, Kubernetes, GitHub</p>
        </header>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <!-- Status Cards -->
            <div class="bg-gray-800 p-4 rounded-lg">
                <h3 class="text-lg font-semibold text-blue-400">Compute Providers</h3>
                <p class="text-2xl font-bold" id="provider-count">0</p>
            </div>
            <div class="bg-gray-800 p-4 rounded-lg">
                <h3 class="text-lg font-semibold text-green-400">Active Jobs</h3>
                <p class="text-2xl font-bold" id="job-count">0</p>
            </div>
            <div class="bg-gray-800 p-4 rounded-lg">
                <h3 class="text-lg font-semibold text-yellow-400">HuggingFace</h3>
                <p class="text-2xl font-bold" id="hf-status">❌</p>
            </div>
            <div class="bg-gray-800 p-4 rounded-lg">
                <h3 class="text-lg font-semibold text-purple-400">Kubernetes</h3>
                <p class="text-2xl font-bold" id="k8s-status">❌</p>
            </div>
        </div>
        
        <!-- Connection Section -->
        <div class="bg-gray-800 p-6 rounded-lg mb-8">
            <h2 class="text-2xl font-bold mb-4">🔌 Connections</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- Compute Providers -->
                <div>
                    <h3 class="text-lg font-semibold mb-2">Compute Providers</h3>
                    <button onclick="connectProvider('vast')" class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded mr-2">Connect Vast.ai</button>
                    <button onclick="connectProvider('enhanced')" class="bg-green-600 hover:bg-green-700 px-4 py-2 rounded">Connect Enhanced Engine</button>
                </div>
                
                <!-- HuggingFace -->
                <div>
                    <h3 class="text-lg font-semibold mb-2">HuggingFace</h3>
                    <input type="text" id="hf-token" placeholder="API Token" class="bg-gray-700 px-3 py-2 rounded mr-2">
                    <button onclick="connectHuggingFace()" class="bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded">Connect</button>
                </div>
                
                <!-- Kubernetes -->
                <div>
                    <h3 class="text-lg font-semibold mb-2">Kubernetes</h3>
                    <input type="text" id="k8s-config" placeholder="Kubeconfig Path" class="bg-gray-700 px-3 py-2 rounded mr-2">
                    <button onclick="connectKubernetes()" class="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded">Connect</button>
                </div>
                
                <!-- GitHub -->
                <div>
                    <h3 class="text-lg font-semibold mb-2">GitHub</h3>
                    <input type="text" id="gh-repo" placeholder="repo/user" class="bg-gray-700 px-3 py-2 rounded mr-2">
                    <input type="text" id="gh-token" placeholder="GitHub Token" class="bg-gray-700 px-3 py-2 rounded mr-2">
                    <button onclick="connectGitHub()" class="bg-gray-600 hover:bg-gray-700 px-4 py-2 rounded">Connect</button>
                </div>
                
                <!-- GitHub Actions -->
                <div>
                    <h3 class="text-lg font-semibold mb-2">GitHub Actions</h3>
                    <button onclick="createTerradevRepo()" class="bg-green-600 hover:bg-green-700 px-4 py-2 rounded mr-2">Create Repo</button>
                    <button onclick="importConfigs()" class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded mr-2">Import</button>
                    <button onclick="exportConfigs()" class="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded mr-2">Export</button>
                    <button onclick="syncConfigs()" class="bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded">Sync</button>
                </div>
            </div>
        </div>
        
        <!-- Training Section -->
        <div class="bg-gray-800 p-6 rounded-lg mb-8">
            <h2 class="text-2xl font-bold mb-4">🎯 Training Configuration</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Model</label>
                    <input type="text" id="model-name" placeholder="resnet50" class="bg-gray-700 px-3 py-2 rounded w-full">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Dataset</label>
                    <input type="text" id="dataset-name" placeholder="imagenet" class="bg-gray-700 px-3 py-2 rounded w-full">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">GPU Type</label>
                    <select id="gpu-type" class="bg-gray-700 px-3 py-2 rounded w-full">
                        <option value="A100">A100</option>
                        <option value="V100">V100</option>
                        <option value="A10G">A10G</option>
                        <option value="T4">T4</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Framework</label>
                    <select id="framework" class="bg-gray-700 px-3 py-2 rounded w-full">
                        <option value="pytorch">PyTorch</option>
                        <option value="tensorflow">TensorFlow</option>
                        <option value="jax">JAX</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">GPU Count</label>
                    <input type="number" id="gpu-count" value="1" class="bg-gray-700 px-3 py-2 rounded w-full">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Hours</label>
                    <input type="number" id="training-hours" value="4" class="bg-gray-700 px-3 py-2 rounded w-full">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Budget ($)</label>
                    <input type="number" id="budget" value="100" class="bg-gray-700 px-3 py-2 rounded w-full">
                </div>
                <div class="flex items-end">
                    <button onclick="deployTrainingJob()" class="bg-green-600 hover:bg-green-700 px-6 py-2 rounded w-full">Deploy Job</button>
                </div>
            </div>
        </div>
        
        <!-- Terminal Section -->
        <div class="bg-gray-800 p-6 rounded-lg mb-8">
            <h2 class="text-2xl font-bold mb-4">💻 Terminal</h2>
            <div class="bg-black p-4 rounded-lg h-64 overflow-y-auto mb-4" id="terminal-output">
                <div class="text-green-400">$ Welcome to Terradev Terminal</div>
            </div>
            <div class="flex">
                <input type="text" id="terminal-input" placeholder="Enter command..." class="bg-gray-700 px-3 py-2 rounded flex-1 mr-2">
                <button onclick="sendTerminalCommand()" class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded">Send</button>
            </div>
        </div>
        
        <!-- Jobs Section -->
        <div class="bg-gray-800 p-6 rounded-lg">
            <h2 class="text-2xl font-bold mb-4">📋 Training Jobs</h2>
            <div id="jobs-list" class="space-y-2">
                <p class="text-gray-400">No active jobs</p>
            </div>
        </div>
    </div>
    
    <script>
        // WebSocket connection for terminal
        let terminalSocket = null;
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            updateStatus();
            setInterval(updateStatus, 5000);
        });
        
        // Update status
        async function updateStatus() {
            try {
                const response = await axios.get('/api/status');
                const data = response.data;
                
                document.getElementById('provider-count').textContent = data.providers.length;
                document.getElementById('job-count').textContent = data.active_jobs;
                document.getElementById('hf-status').textContent = data.huggingface ? '✅' : '❌';
                document.getElementById('k8s-status').textContent = data.kubernetes ? '✅' : '❌';
                
                updateJobsList();
            } catch (error) {
                console.error('Error updating status:', error);
            }
        }
        
        // Update jobs list
        async function updateJobsList() {
            try {
                const response = await axios.get('/api/jobs');
                const jobs = response.data.jobs;
                
                const jobsList = document.getElementById('jobs-list');
                if (jobs.length === 0) {
                    jobsList.innerHTML = '<p class="text-gray-400">No active jobs</p>';
                } else {
                    jobsList.innerHTML = jobs.map(job => `
                        <div class="bg-gray-700 p-3 rounded">
                            <div class="flex justify-between items-center">
                                <div>
                                    <span class="font-semibold">${job.job_id}</span>
                                    <span class="text-gray-400 ml-2">${job.model_name} on ${job.gpu_type}</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <span class="text-${job.status === 'running' ? 'green' : 'yellow'}-400">${job.status}</span>
                                    <button onclick="deleteJob('${job.job_id}')" class="bg-red-600 hover:bg-red-700 px-2 py-1 rounded text-sm">Delete</button>
                                </div>
                            </div>
                        </div>
                    `).join('');
                }
            } catch (error) {
                console.error('Error updating jobs:', error);
            }
        }
        
        // Connect provider
        async function connectProvider(provider) {
            try {
                const config = {
                    name: provider,
                    api_key: prompt('Enter API key:'),
                    endpoint: 'https://api.example.com',
                    region: 'us-east-1',
                    enabled: true
                };
                
                await axios.post('/api/providers/connect', config);
                alert('Provider connected successfully!');
                updateStatus();
            } catch (error) {
                alert('Error connecting provider: ' + error.response.data.detail);
            }
        }
        
        // Connect HuggingFace
        async function connectHuggingFace() {
            try {
                const token = document.getElementById('hf-token').value;
                await axios.post('/api/huggingface/connect', null, {
                    params: { api_token: token }
                });
                alert('HuggingFace connected successfully!');
                updateStatus();
            } catch (error) {
                alert('Error connecting HuggingFace: ' + error.response.data.detail);
            }
        }
        
        // Connect Kubernetes
        async function connectKubernetes() {
            try {
                const kubeconfig = document.getElementById('k8s-config').value;
                await axios.post('/api/kubernetes/connect', null, {
                    params: { kubeconfig_path: kubeconfig }
                });
                alert('Kubernetes connected successfully!');
                updateStatus();
            } catch (error) {
                alert('Error connecting Kubernetes: ' + error.response.data.detail);
            }
        }
        
        // Connect GitHub
        async function connectGitHub() {
            try {
                const repo = document.getElementById('gh-repo').value;
                const token = document.getElementById('gh-token').value;
                
                await axios.post('/api/github/connect', {
                    repository: repo,
                    branch: 'main',
                    token: token
                });
                alert('GitHub connected successfully!');
                updateStatus();
            } catch (error) {
                alert('Error connecting GitHub: ' + error.response.data.detail);
            }
        }
        
        // Create Terradev Repository
        async function createTerradevRepo() {
            try {
                const repoName = prompt('Enter repository name:', 'terradev-configs');
                await axios.post('/api/github/create-repo', null, {
                    params: { repo_name: repoName }
                });
                alert('Terradev repository created successfully!');
            } catch (error) {
                alert('Error creating repository: ' + error.response.data.detail);
            }
        }
        
        // Import Configurations
        async function importConfigs() {
            try {
                const repoUrl = prompt('Enter repository URL:');
                const response = await axios.post('/api/github/import', null, {
                    params: { repo_url: repoUrl }
                });
                alert('Configurations imported: ' + response.data.count + ' files');
            } catch (error) {
                alert('Error importing configs: ' + error.response.data.detail);
            }
        }
        
        // Export Configurations
        async function exportConfigs() {
            try {
                const repoUrl = prompt('Enter repository URL:');
                const configs = {
                    'terradev_config.json': '{"providers": {"vast": {"enabled": true}}}'
                };
                
                await axios.post('/api/github/export', configs, {
                    params: { repo_url: repoUrl }
                });
                alert('Configurations exported successfully!');
            } catch (error) {
                alert('Error exporting configs: ' + error.response.data.detail);
            }
        }
        
        // Sync Configurations
        async function syncConfigs() {
            try {
                const repoUrl = prompt('Enter repository URL:');
                const response = await axios.post('/api/github/sync', null, {
                    params: { repo_url: repoUrl }
                });
                alert('Configurations synced: ' + JSON.stringify(response.data, null, 2));
            } catch (error) {
                alert('Error syncing configs: ' + error.response.data.detail);
            }
        }
        
        // Deploy training job
        async function deployTrainingJob() {
            try {
                const request = {
                    model_name: document.getElementById('model-name').value,
                    dataset_name: document.getElementById('dataset-name').value,
                    gpu_type: document.getElementById('gpu-type').value,
                    gpu_count: parseInt(document.getElementById('gpu-count').value),
                    framework: document.getElementById('framework').value,
                    hours: parseInt(document.getElementById('training-hours').value),
                    budget: parseFloat(document.getElementById('budget').value)
                };
                
                await axios.post('/api/kubernetes/deploy', request);
                alert('Training job deployed successfully!');
                updateStatus();
            } catch (error) {
                alert('Error deploying job: ' + error.response.data.detail);
            }
        }
        
        // Delete job
        async function deleteJob(jobId) {
            try {
                await axios.delete(`/api/jobs/${jobId}`);
                alert('Job deleted successfully!');
                updateStatus();
            } catch (error) {
                alert('Error deleting job: ' + error.response.data.detail);
            }
        }
        
        // Terminal functions
        function connectTerminal() {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/ws/terminal/${Date.now()}`;
            
            terminalSocket = new WebSocket(wsUrl);
            
            terminalSocket.onmessage = function(event) {
                const output = document.getElementById('terminal-output');
                output.innerHTML += `<div class="text-green-400">${event.data}</div>`;
                output.scrollTop = output.scrollHeight;
            };
            
            terminalSocket.onopen = function() {
                const output = document.getElementById('terminal-output');
                output.innerHTML += '<div class="text-blue-400">Connected to terminal</div>';
            };
            
            terminalSocket.onclose = function() {
                const output = document.getElementById('terminal-output');
                output.innerHTML += '<div class="text-red-400">Disconnected from terminal</div>';
            };
        }
        
        function sendTerminalCommand() {
            const input = document.getElementById('terminal-input');
            const output = document.getElementById('terminal-output');
            
            if (terminalSocket && terminalSocket.readyState === WebSocket.OPEN) {
                terminalSocket.send(input.value);
                output.innerHTML += `<div class="text-white">$ ${input.value}</div>`;
                input.value = '';
            } else {
                connectTerminal();
                setTimeout(() => sendTerminalCommand(), 1000);
            }
        }
        
        // Handle Enter key in terminal
        document.getElementById('terminal-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendTerminalCommand();
            }
        });
        
        // Connect terminal on load
        connectTerminal();
    </script>
</body>
</html>
        """
    
    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """Run the web application"""
        uvicorn.run(self.app, host=host, port=port)

# Main execution
def main():
    """Main function"""
    app = TerradevWebApp()
    app.run()

if __name__ == "__main__":
    main()
