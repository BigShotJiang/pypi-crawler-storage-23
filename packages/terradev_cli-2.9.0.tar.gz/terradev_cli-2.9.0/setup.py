from setuptools import setup, find_packages
from pathlib import Path

long_description = ""
readme = Path(__file__).parent / "README.md"
if readme.exists():
    long_description = readme.read_text(encoding="utf-8")

setup(
    name="terradev-cli",
    version="2.9.0",
    author="Terradev Team",
    author_email="team@terradev.com",
    description="BYOAPI Parallel provisioning and orchestration for cross-cloud cost optimization with HuggingFace Spaces integration",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://terradev.cloud",
    project_urls={
        "Bug Tracker": "https://github.com/terradev/terradev-cli/issues",
        "Documentation": "https://docs.terradev.com",
        "Source Code": "https://github.com/terradev/terradev-cli",
        "Analytics": "https://api.terradev.cloud/dashboard",
    },
    packages=find_packages(include=["terradev_cli", "terradev_cli.*"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: System :: Systems Administration",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    install_requires=[
        "click>=8.0.0",
        "aiohttp>=3.9.0",
        "pyyaml>=6.0",
        "cryptography>=41.0.0",
        "requests>=2.31.0",  # Added for telemetry
        "gradio>=4.0.0",  # HF Spaces integration
        "streamlit>=1.28.0",  # HF Spaces integration
        "transformers>=4.0.0",  # HF model support
        "torch>=2.0.0",  # PyTorch for ML models
        "sentence-transformers>=2.0.0",  # Embedding models
        "plotly>=5.0.0",  # Visualization for embedding templates
        "pandas>=1.0.0",  # Data processing for templates
        "numpy>=1.0.0",  # Numerical operations
        "huggingface-hub>=0.19.0",  # HF Hub integration
    ],
    extras_require={
        "all": [
            "boto3>=1.34.0",
            "google-cloud-compute>=1.8.0",
            "azure-mgmt-compute>=29.0.0",
            "azure-identity>=1.12.0",
            "langchain>=0.1.0",
            "langgraph>=0.0.20",
            "sglang>=0.3.0",
            "wandb>=0.16.0",
            "mlflow>=2.8.0",
            "huggingface-hub>=0.19.0",
            "prometheus-client>=0.17.0",
            "grafana-api>=1.0.3",
        ],
        "hf": [
            "aiohttp>=3.9.0",
            "huggingface-hub>=0.19.0",
            "gradio>=4.0.0",
            "streamlit>=1.28.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "build>=0.10.0",
            "twine>=4.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "terradev=terradev_cli.entry_point:main",
        ],
    },
    include_package_data=True,
    package_data={
        "terradev_cli": [
            "templates/*.yaml",
            "templates/*.json",
            "config/*.json",
            "ml_services/*.py",
        ],
    },
    zip_safe=False,
    keywords=[
        "cloud", "gpu", "provisioning", "multi-cloud", "arbitrage",
        "aws", "gcp", "azure", "runpod", "vastai", "machine-learning",
        "cost-optimization", "parallel", "langchain", "langgraph", "sglang",
        "wandb", "mlflow", "analytics", "setup", "conversion",
        "telemetry", "real-time", "monitoring", "dashboard",
        "huggingface", "huggingface-spaces", "gradio", "streamlit",
        "llm", "transformers", "pytorch", "sentence-transformers",
        "smart-templates", "hardware-optimization", "model-deployment",
        "ai", "ml", "deep-learning", "mlops", "model-serving",
    ],
)
