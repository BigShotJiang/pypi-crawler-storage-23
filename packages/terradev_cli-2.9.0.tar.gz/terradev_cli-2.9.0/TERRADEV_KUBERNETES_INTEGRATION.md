# ☸️ Terradev Kubernetes Integration

Cross-cloud node provisioner compatible with Karpenter + standalone Docker container support.

---

## 🎯 **Kubernetes Integration Overview**

### **☸️ Architecture Overview**
```python
kubernetes_architecture = {
    "kubernetes_teams": {
        "integration_type": "Cross-cloud node provisioner",
        "compatibility": "Karpenter compatible",
        "function": "Dynamic node provisioning across cloud providers",
        "benefits": ["Cost optimization", "Multi-cloud flexibility", "Auto-scaling"]
    },
    "standalone_users": {
        "integration_type": "Docker container orchestration",
        "compatibility": "Docker Swarm / Compose",
        "function": "Container management without Kubernetes",
        "benefits": ["Simplicity", "Portability", "Lower complexity"]
    },
    "hybrid_approach": {
        "integration_type": "Flexible deployment",
        "compatibility": "Both Kubernetes and Docker",
        "function": "Adaptable to user infrastructure",
        "benefits": ["Gradual adoption", "Migration path", "Flexibility"]
    }
}
```

---

## 🚀 **Kubernetes + Karpenter Integration**

### **🎯 Karpenter Compatibility**
```yaml
# karpenter-provisioner.yaml
apiVersion: karpenter.sh/v1beta1
kind: Provisioner
metadata:
  name: terradev-provisioner
spec:
  provider:
    name: terradev
  requirements:
    - key: karpenter.k8s.aws/instance-category
      operator: In
      values: ["c", "m", "r", "i", "d"]
  limits:
    resources:
      cpu: 1000
      memory: 4000Gi
  providerRef:
    name: terradev-provider
  ttlSecondsAfterEmpty: 30
---
apiVersion: karpenter.k8s.aws/v1beta1
kind: EC2NodeClass
metadata:
  name: terradev-nodeclass
spec:
  amiFamily: AL2
  subnetSelectorTerms:
    - tags:
        karpenter.sh/managed-by: terradev
  securityGroupSelectorTerms:
    - tags:
        karpenter.sh/managed-by: terradev
  tags:
    karpenter.sh/managed-by: terradev
    terradev.io/node-pool: optimized
```

### **🔧 Terradev Provider Configuration**
```python
# terradev_karpenter_provider.py
class TerradevKarpenterProvider:
    """Terradev provider for Karpenter integration"""
    
    def __init__(self, config: TerradevConfig):
        self.config = config
        self.orchestrator = TerradevEngine(config)
        self.node_registry = NodeRegistry()
    
    async def create_nodes(self, node_request: NodeRequest) -> NodeResponse:
        """Create nodes based on Karpenter request"""
        
        # Step 1: Analyze node requirements
        requirements = self._analyze_requirements(node_request)
        
        # Step 2: Get optimal cloud providers
        provider_options = await self._get_provider_options(requirements)
        
        # Step 3: Select best option based on cost and performance
        optimal_provider = self._select_optimal_provider(provider_options)
        
        # Step 4: Provision nodes
        nodes = await self._provision_nodes(optimal_provider, requirements)
        
        # Step 5: Register with Kubernetes
        registered_nodes = await self._register_nodes(nodes)
        
        return NodeResponse(
            nodes=registered_nodes,
            provider=optimal_provider.name,
            cost_per_hour=optimal_provider.cost_per_hour,
            estimated_savings=optimal_provider.savings_percentage
        )
    
    def _analyze_requirements(self, node_request: NodeRequest) -> NodeRequirements:
        """Analyze Karpenter node requirements"""
        
        return NodeRequirements(
            cpu_required=node_request.resources.requests.get("cpu", 0),
            memory_required=node_request.resources.requests.get("memory", 0),
            gpu_required=self._extract_gpu_requirements(node_request),
            instance_types=node_request.instance_types,
            zones=node_request.zones,
            arch=node_request.arch,
            labels=node_request.labels,
            taints=node_request.taints
        )
    
    async def _get_provider_options(self, requirements: NodeRequirements) -> List[ProviderOption]:
        """Get options from all cloud providers"""
        
        tasks = []
        for provider_name in self.config.get_providers():
            provider = ProviderFactory.create_provider(provider_name)
            task = self._get_provider_quotes(provider, requirements)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter successful results
        provider_options = []
        for result in results:
            if isinstance(result, ProviderOption):
                provider_options.append(result)
        
        return provider_options
    
    def _select_optimal_provider(self, options: List[ProviderOption]) -> ProviderOption:
        """Select optimal provider based on cost and performance"""
        
        # Score each option
        scored_options = []
        for option in options:
            score = self._calculate_provider_score(option)
            scored_options.append((option, score))
        
        # Sort by score (highest first)
        scored_options.sort(key=lambda x: x[1], reverse=True)
        
        return scored_options[0][0]
    
    def _calculate_provider_score(self, option: ProviderOption) -> float:
        """Calculate provider score based on multiple factors"""
        
        scores = {
            "cost_score": (1.0 / option.cost_per_hour) * 100,  # Lower cost = higher score
            "performance_score": option.performance_score,
            "reliability_score": option.reliability_score,
            "availability_score": option.availability_score
        }
        
        # Weighted scoring
        weights = {
            "cost_score": 0.4,
            "performance_score": 0.3,
            "reliability_score": 0.2,
            "availability_score": 0.1
        }
        
        total_score = sum(scores[factor] * weights[factor] for factor in scores)
        
        return total_score
```

### **📊 Kubernetes Deployment Manifests**
```yaml
# terradev-karpenter-controller.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: terradev-karpenter-controller
  namespace: kube-system
  labels:
    app: terradev-karpenter
spec:
  replicas: 2
  selector:
    matchLabels:
      app: terradev-karpenter
  template:
    metadata:
      labels:
        app: terradev-karpenter
    spec:
      serviceAccountName: terradev-karpenter
      containers:
      - name: controller
        image: terradev/karpenter-provider:latest
        args:
        - --config=/etc/terradev/config.yaml
        - --log-level=info
        env:
        - name: TERRADEV_CONFIG_PATH
          value: "/etc/terradev/config.yaml"
        - name: TERRADEV_AUTH_PATH
          value: "/etc/terradev/auth.json"
        volumeMounts:
        - name: config
          mountPath: /etc/terradev
          readOnly: true
        resources:
          requests:
            cpu: 100m
            memory: 128Mi
          limits:
            cpu: 500m
            memory: 512Mi
      volumes:
      - name: config
        secret:
          secretName: terradev-config
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: terradev-karpenter
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: terradev-karpenter
rules:
- apiGroups: [""]
  resources: ["nodes", "pods"]
  verbs: ["get", "list", "watch", "create", "delete", "update"]
- apiGroups: ["karpenter.sh"]
  resources: ["provisioners", "provisioners/status"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["karpenter.k8s.aws"]
  resources: ["ec2nodeclasses", "ec2nodeclasses/status"]
  verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: terradev-karpenter
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: terradev-karpenter
subjects:
- kind: ServiceAccount
  name: terradev-karpenter
  namespace: kube-system
```

---

## 🐳 **Standalone Docker Integration**

### **🎯 Docker Container Orchestration**
```python
# terradev_docker_orchestrator.py
class TerradevDockerOrchestrator:
    """Terradev orchestrator for Docker environments"""
    
    def __init__(self, config: TerradevConfig):
        self.config = config
        self.docker_client = docker.from_env()
        self.terradev_engine = TerradevEngine(config)
        self.container_registry = ContainerRegistry()
    
    async def deploy_workload(self, workload: DockerWorkload) -> DeploymentResult:
        """Deploy workload using Docker containers"""
        
        # Step 1: Analyze workload requirements
        requirements = self._analyze_workload_requirements(workload)
        
        # Step 2: Get optimal cloud instances
        instance_options = await self._get_instance_options(requirements)
        
        # Step 3: Select best instances
        selected_instances = self._select_instances(instance_options, requirements)
        
        # Step 4: Provision instances
        provisioned_instances = await self._provision_instances(selected_instances)
        
        # Step 5: Deploy containers
        deployed_containers = await self._deploy_containers(
            provisioned_instances, 
            workload
        )
        
        # Step 6: Setup networking
        network_config = await self._setup_networking(deployed_containers)
        
        return DeploymentResult(
            containers=deployed_containers,
            instances=provisioned_instances,
            network=network_config,
            total_cost_per_hour=sum(instance.cost_per_hour for instance in provisioned_instances),
            estimated_savings=self._calculate_savings(instance_options, selected_instances)
        )
    
    def _analyze_workload_requirements(self, workload: DockerWorkload) -> WorkloadRequirements:
        """Analyze Docker workload requirements"""
        
        # Calculate total resources needed
        total_cpu = sum(container.resources.cpu for container in workload.containers)
        total_memory = sum(container.resources.memory for container in workload.containers)
        total_gpu = sum(container.resources.gpu for container in workload.containers)
        
        return WorkloadRequirements(
            total_cpu=total_cpu,
            total_memory=total_memory,
            total_gpu=total_gpu,
            container_count=len(workload.containers),
            network_requirements=workload.network_requirements,
            storage_requirements=workload.storage_requirements,
            placement_constraints=workload.placement_constraints
        )
    
    async def _deploy_containers(self, instances: List[CloudInstance], workload: DockerWorkload) -> List[Container]:
        """Deploy containers on provisioned instances"""
        
        deployed_containers = []
        
        for instance in instances:
            # Create Docker client for remote instance
            remote_docker = self._create_remote_docker_client(instance)
            
            for container_spec in workload.containers:
                # Pull image
                image = remote_docker.images.pull(container_spec.image)
                
                # Create container
                container = remote_docker.containers.create(
                    image=image.id,
                    name=container_spec.name,
                    environment=container_spec.environment,
                    ports=container_spec.ports,
                    volumes=container_spec.volumes,
                    restart_policy=container_spec.restart_policy,
                    labels=container_spec.labels
                )
                
                # Start container
                container.start()
                
                deployed_containers.append(Container(
                    id=container.id,
                    name=container_spec.name,
                    instance_id=instance.id,
                    status=container.status,
                    image=container_spec.image,
                    resources=container_spec.resources
                ))
        
        return deployed_containers
```

### **📋 Docker Compose Integration**
```yaml
# docker-compose.terradev.yml
version: '3.8'
services:
  terradev-orchestrator:
    build: .
    image: terradev/orchestrator:latest
    environment:
      - TERRADEV_CONFIG_PATH=/config/config.yaml
      - TERRADEV_AUTH_PATH=/config/auth.json
      - DOCKER_HOST=unix:///var/run/docker.sock
    volumes:
      - ./config:/config:ro
      - /var/run/docker.sock:/var/run/docker.sock:ro
    ports:
      - "8080:8080"
    restart: unless-stopped
    
  terradev-monitor:
    image: terradev/monitor:latest
    environment:
      - TERRADEV_API_URL=http://terradev-orchestrator:8080
    ports:
      - "9090:9090"
    depends_on:
      - terradev-orchestrator
    restart: unless-stopped

  # Example workload services
  ml-training:
    image: pytorch/pytorch:latest
    environment:
      - TERRADEV_MANAGED=true
      - TERRADEV_GPU_REQUIRED=true
    volumes:
      - ./data:/data
      - ./models:/models
    labels:
      - "terradev.managed=true"
      - "terradev.gpu.required=true"
      - "terradev.cost.optimization=aggressive"
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
```

---

## 🔄 **Hybrid Deployment Strategy**

### **🎯 Unified Interface**
```python
# terradev_unified_orchestrator.py
class TerradevUnifiedOrchestrator:
    """Unified orchestrator for both Kubernetes and Docker"""
    
    def __init__(self, config: TerradevConfig):
        self.config = config
        self.kubernetes_orchestrator = None
        self.docker_orchestrator = None
        self.deployment_mode = self._detect_deployment_mode()
    
    def _detect_deployment_mode(self) -> str:
        """Auto-detect deployment environment"""
        
        # Check for Kubernetes
        try:
            kubernetes.config.load_kube_config()
            kubernetes.config.load_incluster_config()
            kubernetes.core_api().list_namespace()
            return "kubernetes"
        except:
            pass
        
        # Check for Docker
        try:
            docker.from_env()
            return "docker"
        except:
            pass
        
        # Fallback to standalone mode
        return "standalone"
    
    async def deploy_workload(self, workload: Union[KubernetesWorkload, DockerWorkload]) -> DeploymentResult:
        """Deploy workload using appropriate orchestrator"""
        
        if self.deployment_mode == "kubernetes":
            return await self._deploy_kubernetes_workload(workload)
        elif self.deployment_mode == "docker":
            return await self._deploy_docker_workload(workload)
        else:
            return await self._deploy_standalone_workload(workload)
    
    async def _deploy_kubernetes_workload(self, workload: KubernetesWorkload) -> DeploymentResult:
        """Deploy workload on Kubernetes"""
        
        if not self.kubernetes_orchestrator:
            self.kubernetes_orchestrator = TerradevKarpenterProvider(self.config)
        
        return await self.kubernetes_orchestrator.create_nodes(workload.node_request)
    
    async def _deploy_docker_workload(self, workload: DockerWorkload) -> DeploymentResult:
        """Deploy workload on Docker"""
        
        if not self.docker_orchestrator:
            self.docker_orchestrator = TerradevDockerOrchestrator(self.config)
        
        return await self.docker_orchestrator.deploy_workload(workload)
```

---

## 📊 **Cost Optimization Features**

### **💰 Cross-Cloud Cost Arbitrage**
```python
class CostOptimizationEngine:
    """Advanced cost optimization for both Kubernetes and Docker"""
    
    def __init__(self):
        self.pricing_data = self._load_pricing_data()
        self.performance_data = self._load_performance_data()
    
    def optimize_deployment(self, deployment_request: DeploymentRequest) -> OptimizationPlan:
        """Optimize deployment for maximum cost savings"""
        
        # Step 1: Analyze current deployment costs
        current_costs = self._calculate_current_costs(deployment_request)
        
        # Step 2: Find optimization opportunities
        opportunities = self._find_optimization_opportunities(deployment_request)
        
        # Step 3: Generate optimization plan
        optimization_plan = self._generate_optimization_plan(opportunities)
        
        return optimization_plan
    
    def _find_optimization_opportunities(self, request: DeploymentRequest) -> List[Opportunity]:
        """Find cost optimization opportunities"""
        
        opportunities = []
        
        # Opportunity 1: Provider switching
        for provider in self.pricing_data:
            potential_savings = self._calculate_provider_switch_savings(
                request.current_provider, 
                provider, 
                request.resources
            )
            if potential_savings > 0.1:  # 10% minimum savings
                opportunities.append(Opportunity(
                    type="provider_switch",
                    description=f"Switch from {request.current_provider} to {provider}",
                    potential_savings=potential_savings,
                    implementation_effort="low"
                ))
        
        # Opportunity 2: Instance type optimization
        optimal_instance = self._find_optimal_instance_type(request.resources)
        if optimal_instance.cost_per_hour < request.current_instance_cost:
            savings = (request.current_instance_cost - optimal_instance.cost_per_hour) * 24 * 30
            opportunities.append(Opportunity(
                type="instance_optimization",
                description=f"Switch to {optimal_instance.instance_type}",
                potential_savings=savings,
                implementation_effort="medium"
            ))
        
        # Opportunity 3: Spot instance usage
        if request.workload tolerate_interruptions:
            spot_savings = self._calculate_spot_savings(request.resources)
            opportunities.append(Opportunity(
                type="spot_instances",
                description="Use spot instances for interruptible workloads",
                potential_savings=spot_savings,
                implementation_effort="low"
            ))
        
        return opportunities
```

---

## 🎯 **Usage Examples**

### **☸️ Kubernetes Team Usage**
```bash
# Install Terradev Karpenter provider
kubectl apply -f terradev-karpenter-provider.yaml

# Create node pool with cost optimization
kubectl apply -f - <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: ml-training-pod
  labels:
    app: ml-training
spec:
  containers:
  - name: trainer
    image: pytorch/pytorch:latest
    resources:
      requests:
        cpu: "4"
        memory: "16Gi"
        nvidia.com/gpu: "1"
  nodeSelector:
    terradev.io/cost-optimized: "true"
  tolerations:
  - key: terradev.io/spot-instance
    operator: Exists
    effect: NoSchedule
EOF

# Monitor cost optimization
terradev k8s monitor --namespace default --cost-optimization
```

### **🐳 Docker Team Usage**
```bash
# Deploy with Terradev optimization
docker-compose -f docker-compose.terradev.yml up -d

# Check cost optimization
terradev docker optimize --project my-app

# Monitor container costs
terradev docker monitor --real-time

# Scale with cost optimization
terradev docker scale --service ml-training --replicas 4 --cost-optimize
```

### **🔄 CLI Integration**
```bash
# Unified CLI for both environments
terradev deploy --platform kubernetes --workload ml-training.yaml
terradev deploy --platform docker --workload web-app.yaml
terradev optimize --platform all --aggressive
terradev monitor --cost-breakdown --savings-report
```

---

## 🎯 **Benefits Summary**

### **☸️ Kubernetes Teams**
- **Karpenter Compatibility**: Seamless integration with existing Karpenter setups
- **Multi-Cloud Node Provisioning**: Automatic cross-cloud node optimization
- **Cost-Driven Scheduling**: Schedule pods based on optimal cloud costs
- **Auto-Scaling**: Intelligent scaling based on cost and performance
- **Cluster Optimization**: Whole-cluster cost optimization strategies

### **🐳 Docker Teams**
- **Simplified Deployment**: No Kubernetes complexity required
- **Container Orchestration**: Intelligent container placement and scaling
- **Cost Optimization**: Per-container cost tracking and optimization
- **Easy Migration**: Path to Kubernetes when ready
- **Development Friendly**: Perfect for development and testing

### **🔄 Hybrid Benefits**
- **Unified Interface**: Same CLI and API for both environments
- **Gradual Migration**: Easy path from Docker to Kubernetes
- **Consistent Optimization**: Same cost optimization across platforms
- **Flexibility**: Choose the right tool for each use case
- **Future-Proof**: Architecture scales with team growth

---

## 🚀 **Getting Started**

### **☸️ Kubernetes Setup**
```bash
# Step 1: Install Terradev CLI
pip install terradev-cli

# Step 2: Configure cloud providers
terradev setup

# Step 3: Install Karpenter provider
kubectl apply -f https://github.com/terradev/karpenter-provider/releases/latest/install.yaml

# Step 4: Configure node pools
kubectl apply -f terradev-nodepool.yaml

# Step 5: Deploy workloads
kubectl apply -f your-workloads.yaml
```

### **🐳 Docker Setup**
```bash
# Step 1: Install Terradev CLI
pip install terradev-cli

# Step 2: Configure cloud providers
terradev setup

# Step 3: Deploy with Docker Compose
docker-compose -f docker-compose.terradev.yml up -d

# Step 4: Monitor and optimize
terradev docker monitor --optimize
```

---

**☸️ Terradev Kubernetes Integration: Cross-cloud node provisioner for Karpenter teams + standalone Docker support for everyone else!**
