#!/usr/bin/env python3
"""
Enhanced Ray Service with Deep Dashboard Integration
Integrates Ray Dashboard, Prometheus, Grafana, and Terradev monitoring
"""

import os
import json
import asyncio
import aiohttp
import subprocess
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from pathlib import Path


@dataclass
class RayConfig:
    """Enhanced Ray configuration"""
    dashboard_uri: Optional[str] = None
    cluster_name: Optional[str] = None
    auth_token: Optional[str] = None
    head_node_ip: Optional[str] = None
    head_node_port: int = 6379
    namespace: str = "default"
    monitoring_enabled: bool = False
    prometheus_enabled: bool = False
    grafana_enabled: bool = False
    metrics_export_port: int = 8080


class EnhancedRayService:
    """Enhanced Ray service with deep monitoring integration"""
    
    def __init__(self, config: RayConfig):
        self.config = config
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def __aenter__(self):
        if self.config.auth_token:
            headers = {"Authorization": f"Bearer {self.config.auth_token}"}
            self.session = aiohttp.ClientSession(headers=headers)
        else:
            self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def install_monitoring_stack(self) -> Dict[str, Any]:
        """Install Prometheus and Grafana with Ray dashboards"""
        if not self.config.monitoring_enabled:
            return {
                "status": "failed",
                "ray": "Monitoring not enabled in configuration"
            }
        
        try:
            # Install Ray with monitoring
            ray_start_cmd = [
                "ray", "start", "--head",
                "--dashboard-host=0.0.0.0",
                "--dashboard-port=8265",
                "--metrics-export-port=8080",
                "--dashboard-host=0.0.0.0"
            ]
            
            result = subprocess.run(
                ray_start_cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode != 0:
                raise Exception(f"Ray start failed: {result.stderr}")
            
            # Install Prometheus for Ray metrics
            prometheus_config = f"""
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'ray'
    kubernetes_sd_configs:
      - role: endpoints
        namespaces:
          - default
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_name__]
        target_label: __meta_kubernetes_pod_label_name__
    metric_relabel_configs:
      - source_label: __name__
        target_label: __name__
    static_configs:
      - targets: ['localhost:8080']

rule_files:
  - "/etc/prometheus/rules/*.yml"

alerting:
  alertmanagers:
    - static_configs:
      - "/etc/prometheus/alertmanager.yml"
"""
            
            # Write Prometheus config
            with open('/tmp/prometheus-ray.yaml', 'w') as f:
                f.write(prometheus_config)
            
            # Start Prometheus with Ray metrics
            prometheus_cmd = [
                "prometheus", "--config.file=/tmp/prometheus-ray.yaml"
            ]
            
            subprocess.Popen(prometheus_cmd, env=os.environ)
            
            # Install Grafana with Ray dashboards
            grafana_config = f"""
apiVersion: 1
servers:
  - name: 'Default'
    url: http://localhost:3000
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    allowUiUpdates: false
    editable: true
    options:
      path: /var/lib/grafana/dashboards

datasources:
  datasources.yaml:
    apiVersion: 1
    datasources:
      - name: 'Ray'
        type: prometheus
        access: proxy
        url: http://localhost:8080
        isDefault: true
        editable: true
        jsonData: |
          {{
            "uid": "ray",
            "type": "prometheus",
            "url": "http://localhost:8080",
            "access": "proxy",
            "editable": true
          }}

dashboardProviders:
  dashboardproviders.yaml:
    apiVersion: 1
    providers:
      - name: 'default'
        orgId: 1
        folder: ''
        type: 'file'
        disableDevision: false
        allowUiUpdates: false
        options:
          path: /var/lib/grafana/dashboards
"""
            
            # Write Grafana config
            with open('/tmp/grafana-ray.yaml', 'w') as f:
                f.write(grafana_config)
            
            # Start Grafana
            grafana_cmd = [
                "grafana", "server", "--config", "/tmp/grafana-ray.yaml"
            ]
            
            subprocess.Popen(grafana_cmd, env=os.environ)
            
            # Import Ray dashboards
            await self._import_ray_dashboards()
            
            return {
                "status": "installed",
                "ray": "http://localhost:8265",
                "prometheus": "http://localhost:8080",
                "grafana": "http://localhost:3000",
                "dashboards": "Ray dashboards imported"
            }
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    async def _import_ray_dashboards(self) -> Dict[str, Any]:
        """Import Ray-specific dashboards into Grafana"""
        try:
            # Ray dashboard configuration
            dashboard_config = {
                "dashboard": {
                    "id": "ray-overview",
                    "title": "Ray Overview",
                    "tags": ["ray", "distributed", "ml", "training"],
                    "timezone": "browser",
                    "panels": [
                        {
                            "title": "Active Workers",
                            "type": "stat",
                            "targets": [
                                {
                                    "expr": "ray_cluster_total_workers",
                                    "legendFormat": "{{instance}} workers"
                                }
                            ],
                            "fieldConfig": {
                                "defaults": {
                                    "min": 0
                                }
                            }
                        },
                        {
                            "title": "CPU Utilization",
                            "type": "graph",
                            "targets": [
                                {
                                    "expr": "ray_cluster_cpu_total * 100 / ray_cluster_cpu_total",
                                    "legendFormat": "{{instance}}%"
                                }
                            ],
                            "yAxes": [
                                {
                                    "max": 100,
                                    "min": 0
                                }
                            ]
                        },
                        {
                            "title": "Memory Utilization",
                            "type": "graph",
                            "targets": [
                                {
                                    "expr": "ray_cluster_memory_used * 100 / ray_cluster_memory_total",
                                    "legendFormat": "{{instance}}%"
                                }
                            ],
                            "yAxes": [
                                {
                                    "max": 100,
                                    "min": 0
                                }
                            ]
                        },
                        {
                            "title": "GPU Utilization",
                            "type": "graph",
                            "targets": [
                                {
                                    "expr": "ray_cluster_gpu_total * 100 / ray_cluster_gpu_total",
                                    "legendFormat": "{{instance}}%"
                                }
                            ],
                            "yAxes": [
                                {
                                    "max": 100,
                                    "min": 0
                                }
                            ]
                        },
                        {
                            "title": "Task Throughput",
                            "type": "stat",
                            "targets": [
                                {
                                    "expr": "rate(ray_task_succeeded_total[5m])",
                                    "legendFormat": "{{instance}} tasks/min"
                                }
                            ]
                        },
                        {
                            "title": "Failed Tasks",
                            "type": "stat",
                            "targets": [
                                {
                                    "expr": "rate(ray_task_failed_total[5m])",
                                    "legendFormat": "{{instance}} tasks/min"
                                }
                            ]
                        }
                    ],
                    "templating": {
                        "list": [
                            "all_variables",
                            [
                                "datasource",
                                "prometheus"
                            ],
                            [
                                "dashboard",
                                "ray"
                            ]
                        ]
                    }
                }
            }
            
            # Import dashboard via Grafana API
            grafana_url = "http://localhost:3000/api"
            
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            async with self.session.post(f"{grafana_url}/api/dashboards/db", json=dashboard_config) as response:
                if response.status == 200:
                    return {
                        "status": "imported",
                        "dashboard_id": "ray-overview"
                    }
                else:
                    error_text = await response.text()
                    raise Exception(f"Failed to import dashboard: {response.status} - {error_text}")
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    async def get_monitoring_status(self) -> Dict[str, Any]:
        """Get comprehensive monitoring status"""
        try:
            status = {
                "ray": await self._get_ray_status(),
                "monitoring": {
                    "prometheus": await self._check_prometheus_health(),
                    "grafana": await self._check_grafana_health()
                },
                "metrics": await self._get_ray_metrics()
            }
            
            return status
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    async def _get_ray_status(self) -> Dict[str, Any]:
        """Get Ray cluster status"""
        try:
            result = subprocess.run(
                ["ray", "status"],
                capture_output=True,
                text=True,
                timeout=15
            )
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                
                status = {
                    "status": "running",
                    "version": "unknown",
                    "dashboard_uri": self.config.dashboard_uri,
                    "output": result.stdout
                }
                
                # Extract version info
                for line in lines:
                    if "Ray version" in line:
                        status["version"] = line.split("Ray version")[-1].strip()
                        break
                
                # Extract cluster info
                for line in lines:
                    if "cluster name:" in line:
                        status["cluster_name"] = line.split("cluster name:")[-1].strip()
                        break
                
                return status
            else:
                return {
                    "status": "not_running",
                    "error": "Ray cluster not running. Start with 'ray start --head'"
                }
                
        except FileNotFoundError:
            return {
                "status": "failed",
                "error": "Ray not installed. Run: pip install ray[default]"
            }
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    async def _check_prometheus_health(self) -> Dict[str, Any]:
        """Check Prometheus health"""
        try:
            result = subprocess.run(
                ["curl", "-s", "http://localhost:8080/api/v1/query?query=up"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0 and result.stdout:
                return {"status": "healthy", "details": "Prometheus is running"}
            else:
                return {"status": "unhealthy", "error": "Prometheus not accessible"}
                
        except Exception as e:
            return {"status": "failed", "error": str(e)}
    
    async def _check_grafana_health(self) -> Dict[str, Any]:
        """Check Grafana health"""
        try:
            result = subprocess.run(
                ["curl", "-s", "http://localhost:3000/api/health"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0 and "ok" in result.stdout:
                return {"status": "healthy", "details": "Grafana is running"}
            else:
                return {"status": "unhealthy", "error": "Grafana not accessible"}
                
        except Exception as e:
            return {"status": "failed", "error": str(e)}
    
    async def _get_ray_metrics(self) -> Dict[str, Any]:
        """Get Ray metrics from Prometheus"""
        try:
            if not self.config.prometheus_enabled:
                return {"status": "disabled", "error": "Prometheus not enabled"}
            
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            # Get cluster metrics
            url = "http://localhost:8080/api/v1/query"
            
            metrics_queries = {
                "total_workers": "ray_cluster_total_workers",
                "cpu_total": "ray_cluster_cpu_total",
                "cpu_used": "ray_cluster_cpu_used",
                "memory_total": "ray_cluster_memory_total",
                "memory_used": "ray_cluster_memory_used",
                "gpu_total": "ray_cluster_gpu_total",
                "gpu_used": "ray_cluster_gpu_used",
                "task_succeeded": "ray_task_succeeded_total",
                "task_failed": "ray_task_failed_total",
                "object_store_total": "ray_object_store_memory_total",
                "object_store_used": "ray_object_store_memory_used"
            }
            
            metrics = {}
            for name, query in metrics_queries.items():
                try:
                    async with self.session.get(f"{url}?query={query}") as response:
                        if response.status == 200:
                            data = await response.json()
                            metrics[name] = data.get("data", {}).get("result", [{}])[0].get("value", 0)
                except:
                    metrics[name] = 0
            
            return metrics
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    async def get_enhanced_config(self) -> Dict[str, str]:
        """Get enhanced Ray configuration for environment variables"""
        config = self.get_ray_config()
        
        # Add monitoring configuration
        if self.config.monitoring_enabled:
            config["RAY_MONITORING_ENABLED"] = "true"
        
        if self.config.prometheus_enabled:
            config["RAY_PROMETHEUS_ENABLED"] = "true"
            config["RAY_PROMETHEUS_URL"] = "http://localhost:8080"
        
        if self.config.grafana_enabled:
            config["RAY_GRAFANA_ENABLED"] = "true"
            config["RAY_GRAFANA_URL"] = "http://localhost:3000"
        
        if self.config.metrics_export_port:
            config["RAY_METRICS_EXPORT_PORT"] = str(self.config.metrics_export_port)
        
        return config
    
    def get_ray_dashboard_url(self) -> Optional[str]:
        """Get Ray dashboard URL with fallback"""
        if self.config.dashboard_uri:
            return self.config.dashboard_uri
        
        # Try to get from Ray status
        try:
            result = subprocess.run(
                ["ray", "status"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                # Extract dashboard URL from status output
                for line in result.stdout.strip().split('\n'):
                    if "Dashboard URL:" in line:
                        return line.split("Dashboard URL:")[-1].strip()
            
        except:
            pass
        
        return None
    
    def generate_monitoring_script(self) -> str:
        """Generate monitoring setup script"""
        script_lines = [
            "# Ray Monitoring Setup Script (generated by Terradev)",
            "",
            "# Install Ray with monitoring",
            "ray start --head --dashboard-host=0.0.0.0 --dashboard-port=8265 --metrics-export-port=8080",
            "",
            "# Start Prometheus for Ray metrics",
            "prometheus --config=prometheus-ray.yaml",
            "",
            "# Start Grafana with Ray dashboards",
            "grafana server --config=grafana-ray.yaml",
            "",
            "# Access dashboards",
            "echo 'Ray Dashboard: http://localhost:8265'",
            "echo 'Prometheus: http://localhost:9090'",
            "echo 'Grafana: http://localhost:3000'",
            "",
            "# Environment variables for Ray monitoring",
            "export RAY_PROMETHEUS_ENABLED=true",
            "export RAY_GRAFANA_ENABLED=true",
            "export RAY_METRICS_EXPORT_PORT=8080",
            "",
            "# Test Ray connection",
            "ray status",
            "ray status --metrics"
        ]
        
        return "\n".join(script_lines)


def create_enhanced_ray_service_from_credentials(credentials: Dict[str, str]) -> EnhancedRayService:
    """Create enhanced RayService from credential dictionary"""
    config = RayConfig(
        dashboard_uri=credentials.get("dashboard_uri"),
        cluster_name=credentials.get("cluster_name"),
        auth_token=credentials.get("auth_token"),
        head_node_ip=credentials.get("head_node_ip"),
        head_node_port=int(credentials.get("head_node_port", 6379)),
        namespace=credentials.get("namespace", "default"),
        monitoring_enabled=credentials.get("monitoring_enabled", "false").lower() == "true",
        prometheus_enabled=credentials.get("prometheus_enabled", "false").lower() == "true",
        grafana_enabled=credentials.get("grafana_enabled", "false").lower() == "true",
        metrics_export_port=int(credentials.get("metrics_export_port", 8080))
    )
    
    return EnhancedRayService(config)


def get_enhanced_ray_setup_instructions() -> str:
    """Get enhanced setup instructions for Ray with monitoring"""
    return """
🚀 Enhanced Ray Setup Instructions:

1. Install Ray with monitoring support:
   # Basic installation
   pip install ray[default]
   
   # With monitoring and visualization
   pip install ray[default,monitoring]
   
   # For distributed training and ML workloads
   pip install ray[default,train,tune]

2. Configure Terradev with enhanced Ray:
   terradev configure --provider ray \\
     --dashboard-uri http://localhost:8265 \\
     --monitoring-enabled true \\
     --prometheus-enabled true \\
     --grafana-enabled true

3. Install monitoring stack:
   terradev ml ray --install-monitoring

4. Access dashboards:
   # Ray Dashboard
   terradev ml ray --dashboard
   
   # Grafana Dashboard
   terradev ml ray --grafana

   # Prometheus metrics
   terradev ml ray --prometheus

5. Test monitoring integration:
   terradev ml ray --test
   
   # Get comprehensive metrics
   terradev ml ray --metrics-summary

📋 Enhanced Credentials:
- dashboard_uri: Ray dashboard URI (optional)
- cluster_name: Ray cluster name (optional)
- auth_token: Authentication token (optional)
- head_node_ip: Head node IP address (optional)
- head_node_port: Head node port (default: 6379)
- namespace: Kubernetes namespace (default: "default")
- monitoring_enabled: Enable monitoring stack (default: "false")
- prometheus_enabled: Enable Prometheus (default: "false")
- grafana_enabled: Enable Grafana (default: "false")
- metrics_export_port: Metrics export port (default: 8080)

💡 Enhanced Usage Examples:
# Test Ray connection
terradev ml ray --test

# Install complete monitoring stack
terradev ml ray --install-monitoring

# Get comprehensive status
terradev ml ray --metrics-summary

# Get cluster resources
terradev ml ray --resources

# Access dashboards
terradev ml ray --dashboard
terradev ml ray --grafana
terradev ml ray --prometheus

# Start Ray with monitoring
ray start --head --dashboard-host=0.0.0.0 --metrics-export-port=8080

🔗 Monitoring Integration:
- **Ray Dashboard**: Built-in Ray dashboard with metrics visualization
- **Prometheus**: Metrics collection from Ray cluster
- **Grafana**: Pre-configured Ray dashboards
- **Ray Metrics**: Cluster, worker, task, and resource metrics
- **Dashboard Templates**: Ready-to-use Ray dashboards

🎯 Dashboard Features:
- **Cluster Overview**: Total workers, CPU/memory/GPU utilization
- **Task Monitoring**: Task throughput and failure rates
- **Resource Utilization**: Real-time resource usage trends
- **Performance Metrics**: Throughput and latency tracking
- **Job Monitoring**: Distributed job status and progress

🔧 Integration with Terradev:
- **Provisioning Integration**: Terradev GPU provisioning + Ray cluster management
- **Cost Tracking**: Monitor infrastructure costs via dashboards
- **Performance Optimization**: Optimize based on monitoring data
- **Resource Scaling**: Auto-scaling based on metrics

📊 Dashboard URLs:
- Ray Dashboard: http://localhost:8265
- Grafana: http://localhost:3000 (admin/prom-operator)
- Prometheus: http://localhost:9090

🎯 Advanced Features:
- **Alerting**: Configure alerts for cluster failures
- **Auto-scaling**: Ray autoscaler + Kubernetes HPA
- **Multi-cloud**: Support for AWS, GCP, Azure providers
- **Security**: Authentication and authorization
- **Persistence**: Long-term metrics storage
- **Visualization**: Advanced dashboards and visualizations

📊 Ray Metrics Available:
- ray_cluster_total_workers: Total number of workers
- ray_cluster_cpu_total: Total CPU cores in cluster
- ray_cluster_cpu_used: CPU cores currently used
- ray_cluster_memory_total: Total memory available
- ray_cluster_memory_used: Memory currently used
- ray_cluster_gpu_total: Total GPUs available
- ray_cluster_gpu_used: GPUs currently used
- ray_task_succeeded_total: Successful task completions
- ray_task_failed_total: Failed task completions
- ray_object_store_total: Object store memory total
- ray_object_store_used: Object store memory used

🔧 Integration with Terradev:
- **GPU Provisioning**: terradev provision -g A100 -n 4
- **Ray Cluster**: terradev ml ray --start
- **Monitoring**: terradev ml ray --metrics-summary
- **Optimization**: Use metrics to optimize cluster configuration
"""
