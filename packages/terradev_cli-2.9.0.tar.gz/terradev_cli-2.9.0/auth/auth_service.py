#!/usr/bin/env python3
"""
Terradev Authentication and Authorization Service
JWT-based authentication with RBAC, rate limiting, and audit logging
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import jwt
import bcrypt
import redis
from fastapi import FastAPI, HTTPException, Depends, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import pydantic
from pydantic import BaseModel, EmailStr, validator
import aioredis
import asyncpg
from cryptography.fernet import Fernet
import hashlib
import secrets
import uuid

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class UserRole(str, Enum):
    """User roles with escalating permissions"""
    ADMIN = "admin"
    OPERATOR = "operator"
    DEVELOPER = "developer"
    ANALYST = "analyst"
    VIEWER = "viewer"

class Permission(str, Enum):
    """System permissions"""
    # GPU Arbitrage
    GPU_ARBITRAGE_READ = "gpu_arbitrage:read"
    GPU_ARBITRAGE_WRITE = "gpu_arbitrage:write"
    GPU_ARBITRAGE_DELETE = "gpu_arbitrage:delete"
    
    # Cost Management
    COST_READ = "cost:read"
    COST_WRITE = "cost:write"
    COST_ANALYZE = "cost:analyze"
    
    # User Management
    USER_READ = "user:read"
    USER_WRITE = "user:write"
    USER_DELETE = "user:delete"
    
    # System Administration
    SYSTEM_ADMIN = "system:admin"
    SYSTEM_MONITOR = "system:monitor"
    
    # API Management
    API_READ = "api:read"
    API_WRITE = "api:write"
    API_DELETE = "api:delete"

# Role-Permission Mapping
ROLE_PERMISSIONS = {
    UserRole.ADMIN: [
        Permission.GPU_ARBITRAGE_READ, Permission.GPU_ARBITRAGE_WRITE, Permission.GPU_ARBITRAGE_DELETE,
        Permission.COST_READ, Permission.COST_WRITE, Permission.COST_ANALYZE,
        Permission.USER_READ, Permission.USER_WRITE, Permission.USER_DELETE,
        Permission.SYSTEM_ADMIN, Permission.SYSTEM_MONITOR,
        Permission.API_READ, Permission.API_WRITE, Permission.API_DELETE
    ],
    UserRole.OPERATOR: [
        Permission.GPU_ARBITRAGE_READ, Permission.GPU_ARBITRAGE_WRITE,
        Permission.COST_READ, Permission.COST_WRITE, Permission.COST_ANALYZE,
        Permission.USER_READ,
        Permission.SYSTEM_MONITOR,
        Permission.API_READ, Permission.API_WRITE
    ],
    UserRole.DEVELOPER: [
        Permission.GPU_ARBITRAGE_READ, Permission.GPU_ARBITRAGE_WRITE,
        Permission.COST_READ, Permission.COST_ANALYZE,
        Permission.API_READ, Permission.API_WRITE
    ],
    UserRole.ANALYST: [
        Permission.GPU_ARBITRAGE_READ,
        Permission.COST_READ, Permission.COST_ANALYZE,
        Permission.API_READ
    ],
    UserRole.VIEWER: [
        Permission.GPU_ARBITRAGE_READ,
        Permission.COST_READ,
        Permission.API_READ
    ]
}

@dataclass
class User:
    """User model"""
    id: str
    email: str
    username: str
    role: UserRole
    permissions: List[Permission]
    created_at: datetime
    last_login: Optional[datetime]
    is_active: bool
    failed_login_attempts: int
    locked_until: Optional[datetime]
    mfa_enabled: bool
    api_keys: List[str]

@dataclass
class APIToken:
    """API Token model"""
    id: str
    user_id: str
    name: str
    token_hash: str
    permissions: List[Permission]
    created_at: datetime
    expires_at: datetime
    last_used: Optional[datetime]
    usage_count: int
    is_active: bool

@dataclass
class AuditLog:
    """Audit log entry"""
    id: str
    user_id: str
    action: str
    resource: str
    resource_id: Optional[str]
    ip_address: str
    user_agent: str
    timestamp: datetime
    success: bool
    error_message: Optional[str]

# Pydantic Models
class UserCreate(BaseModel):
    email: EmailStr
    username: str
    password: str
    role: UserRole = UserRole.VIEWER
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v

class UserLogin(BaseModel):
    email: EmailStr
    password: str
    mfa_code: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    permissions: List[str]

class APITokenCreate(BaseModel):
    name: str
    permissions: List[Permission]
    expires_in_days: int = 30

class RateLimitConfig:
    """Rate limiting configuration"""
    def __init__(self):
        self.requests_per_minute = {
            UserRole.ADMIN: 1000,
            UserRole.OPERATOR: 500,
            UserRole.DEVELOPER: 200,
            UserRole.ANALYST: 100,
            UserRole.VIEWER: 50
        }
        self.burst_limit = 200
        self.window_size = 60  # seconds

class AuthService:
    """Main authentication service"""
    
    def __init__(self, database_url: str, redis_url: str, jwt_secret: str):
        self.database_url = database_url
        self.redis_url = redis_url
        self.jwt_secret = jwt_secret
        self.jwt_algorithm = "HS256"
        self.jwt_expiration = timedelta(hours=1)
        self.refresh_expiration = timedelta(days=7)
        
        # Rate limiting
        self.rate_limit_config = RateLimitConfig()
        
        # Security settings
        self.max_failed_attempts = 5
        self.lockout_duration = timedelta(minutes=15)
        self.password_min_length = 8
        
        # Initialize connections
        self.db_pool = None
        self.redis_client = None
        
        # Encryption for sensitive data
        self.encryption_key = Fernet.generate_key()
        self.cipher_suite = Fernet(self.encryption_key)
    
    async def initialize(self):
        """Initialize database and Redis connections"""
        
        # Initialize database connection pool
        self.db_pool = await asyncpg.create_pool(
            self.database_url,
            min_size=5,
            max_size=20,
            command_timeout=60
        )
        
        # Initialize Redis connection
        self.redis_client = await aioredis.from_url(self.redis_url)
        
        # Create database tables
        await self._create_tables()
        
        logger.info("Authentication service initialized")
    
    async def _create_tables(self):
        """Create database tables"""
        
        async with self.db_pool.acquire() as conn:
            # Users table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    email VARCHAR(255) UNIQUE NOT NULL,
                    username VARCHAR(100) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    role VARCHAR(50) NOT NULL,
                    is_active BOOLEAN DEFAULT true,
                    failed_login_attempts INTEGER DEFAULT 0,
                    locked_until TIMESTAMP,
                    mfa_enabled BOOLEAN DEFAULT false,
                    mfa_secret VARCHAR(255),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login TIMESTAMP
                )
            """)
            
            # API tokens table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS api_tokens (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
                    name VARCHAR(255) NOT NULL,
                    token_hash VARCHAR(255) UNIQUE NOT NULL,
                    permissions JSONB NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL,
                    last_used TIMESTAMP,
                    usage_count INTEGER DEFAULT 0,
                    is_active BOOLEAN DEFAULT true
                )
            """)
            
            # Audit log table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    user_id UUID REFERENCES users(id),
                    action VARCHAR(255) NOT NULL,
                    resource VARCHAR(255) NOT NULL,
                    resource_id VARCHAR(255),
                    ip_address INET NOT NULL,
                    user_agent TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    success BOOLEAN NOT NULL,
                    error_message TEXT
                )
            """)
            
            # Create indexes
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_api_tokens_user_id ON api_tokens(user_id)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp)")
    
    def _hash_password(self, password: str) -> str:
        """Hash password using bcrypt"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    
    def _verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def _generate_jwt_token(self, user_id: str, permissions: List[str], 
                           expiration: timedelta) -> str:
        """Generate JWT token"""
        
        payload = {
            "user_id": user_id,
            "permissions": permissions,
            "exp": datetime.utcnow() + expiration,
            "iat": datetime.utcnow(),
            "jti": str(uuid.uuid4())
        }
        
        return jwt.encode(payload, self.jwt_secret, algorithm=self.jwt_algorithm)
    
    async def _check_rate_limit(self, user_id: str, role: UserRole) -> bool:
        """Check if user exceeds rate limit"""
        
        key = f"rate_limit:{user_id}"
        current_requests = await self.redis_client.get(key)
        
        if current_requests is None:
            # First request in window
            await self.redis_client.setex(
                key, 
                self.rate_limit_config.window_size, 
                1
            )
            return True
        
        requests_count = int(current_requests)
        max_requests = self.rate_limit_config.requests_per_minute[role]
        
        if requests_count >= max_requests:
            return False
        
        # Increment counter
        await self.redis_client.incr(key)
        return True
    
    async def _log_audit_event(self, user_id: str, action: str, resource: str,
                             resource_id: Optional[str], ip_address: str,
                             user_agent: str, success: bool, 
                             error_message: Optional[str] = None):
        """Log audit event"""
        
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO audit_logs (user_id, action, resource, resource_id, 
                                      ip_address, user_agent, success, error_message)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            """, user_id, action, resource, resource_id, ip_address, 
                  user_agent, success, error_message)
    
    async def create_user(self, user_data: UserCreate) -> User:
        """Create new user"""
        
        async with self.db_pool.acquire() as conn:
            # Check if user already exists
            existing = await conn.fetchrow(
                "SELECT id FROM users WHERE email = $1 OR username = $2",
                user_data.email, user_data.username
            )
            
            if existing:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="User already exists"
                )
            
            # Hash password
            password_hash = self._hash_password(user_data.password)
            
            # Get permissions for role
            permissions = ROLE_PERMISSIONS[user_data.role]
            
            # Create user
            user_id = str(uuid.uuid4())
            await conn.execute("""
                INSERT INTO users (id, email, username, password_hash, role)
                VALUES ($1, $2, $3, $4, $5)
            """, user_id, user_data.email, user_data.username, 
                  password_hash, user_data.role.value)
            
            # Create and return user object
            user = User(
                id=user_id,
                email=user_data.email,
                username=user_data.username,
                role=user_data.role,
                permissions=permissions,
                created_at=datetime.utcnow(),
                last_login=None,
                is_active=True,
                failed_login_attempts=0,
                locked_until=None,
                mfa_enabled=False,
                api_keys=[]
            )
            
            logger.info(f"Created user: {user.email}")
            return user
    
    async def authenticate_user(self, login_data: UserLogin, ip_address: str,
                              user_agent: str) -> TokenResponse:
        """Authenticate user and return tokens"""
        
        async with self.db_pool.acquire() as conn:
            # Get user
            user_row = await conn.fetchrow(
                "SELECT * FROM users WHERE email = $1",
                login_data.email
            )
            
            if not user_row:
                await self._log_audit_event(
                    None, "login", "user", None, ip_address, user_agent, False,
                    "User not found"
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid credentials"
                )
            
            # Check if user is locked
            if user_row['locked_until'] and user_row['locked_until'] > datetime.utcnow():
                await self._log_audit_event(
                    str(user_row['id']), "login", "user", None, ip_address, user_agent, False,
                    "Account locked"
                )
                raise HTTPException(
                    status_code=status.HTTP_423_LOCKED,
                    detail="Account is locked"
                )
            
            # Verify password
            if not self._verify_password(login_data.password, user_row['password_hash']):
                # Increment failed attempts
                failed_attempts = user_row['failed_login_attempts'] + 1
                locked_until = None
                
                if failed_attempts >= self.max_failed_attempts:
                    locked_until = datetime.utcnow() + self.lockout_duration
                
                await conn.execute("""
                    UPDATE users 
                    SET failed_login_attempts = $1, locked_until = $2
                    WHERE id = $3
                """, failed_attempts, locked_until, user_row['id'])
                
                await self._log_audit_event(
                    str(user_row['id']), "login", "user", None, ip_address, user_agent, False,
                    "Invalid password"
                )
                
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid credentials"
                )
            
            # Check rate limit
            user_role = UserRole(user_row['role'])
            if not await self._check_rate_limit(str(user_row['id']), user_role):
                await self._log_audit_event(
                    str(user_row['id']), "login", "user", None, ip_address, user_agent, False,
                    "Rate limit exceeded"
                )
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="Rate limit exceeded"
                )
            
            # Reset failed attempts
            await conn.execute("""
                UPDATE users 
                SET failed_login_attempts = 0, locked_until = NULL, last_login = $1
                WHERE id = $2
            """, datetime.utcnow(), user_row['id'])
            
            # Get permissions
            permissions = ROLE_PERMISSIONS[user_role]
            permission_strings = [p.value for p in permissions]
            
            # Generate tokens
            access_token = self._generate_jwt_token(
                str(user_row['id']), permission_strings, self.jwt_expiration
            )
            refresh_token = self._generate_jwt_token(
                str(user_row['id']), ["refresh"], self.refresh_expiration
            )
            
            # Log successful login
            await self._log_audit_event(
                str(user_row['id']), "login", "user", None, ip_address, user_agent, True
            )
            
            logger.info(f"User authenticated: {user_row['email']}")
            
            return TokenResponse(
                access_token=access_token,
                refresh_token=refresh_token,
                expires_in=int(self.jwt_expiration.total_seconds()),
                permissions=permission_strings
            )
    
    async def refresh_token(self, refresh_token: str) -> TokenResponse:
        """Refresh access token"""
        
        try:
            payload = jwt.decode(
                refresh_token, self.jwt_secret, algorithms=[self.jwt_algorithm]
            )
            
            if "refresh" not in payload.get("permissions", []):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid refresh token"
                )
            
            user_id = payload["user_id"]
            
            # Get user and permissions
            async with self.db_pool.acquire() as conn:
                user_row = await conn.fetchrow(
                    "SELECT * FROM users WHERE id = $1 AND is_active = true",
                    user_id
                )
                
                if not user_row:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found or inactive"
                    )
                
                user_role = UserRole(user_row['role'])
                permissions = ROLE_PERMISSIONS[user_role]
                permission_strings = [p.value for p in permissions]
                
                # Generate new access token
                access_token = self._generate_jwt_token(
                    user_id, permission_strings, self.jwt_expiration
                )
                
                return TokenResponse(
                    access_token=access_token,
                    refresh_token=refresh_token,
                    expires_in=int(self.jwt_expiration.total_seconds()),
                    permissions=permission_strings
                )
                
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Refresh token expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid refresh token"
            )
    
    async def create_api_token(self, user_id: str, token_data: APITokenCreate) -> str:
        """Create API token for user"""
        
        async with self.db_pool.acquire() as conn:
            # Verify user exists and has permissions
            user_row = await conn.fetchrow(
                "SELECT * FROM users WHERE id = $1 AND is_active = true",
                user_id
            )
            
            if not user_row:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found"
                )
            
            # Generate token
            token_value = secrets.token_urlsafe(32)
            token_hash = hashlib.sha256(token_value.encode()).hexdigest()
            
            # Calculate expiration
            expires_at = datetime.utcnow() + timedelta(days=token_data.expires_in_days)
            
            # Store token
            token_id = str(uuid.uuid4())
            await conn.execute("""
                INSERT INTO api_tokens (id, user_id, name, token_hash, permissions, expires_at)
                VALUES ($1, $2, $3, $4, $5, $6)
            """, token_id, user_id, token_data.name, token_hash,
                  json.dumps([p.value for p in token_data.permissions]), expires_at)
            
            logger.info(f"Created API token {token_data.name} for user {user_id}")
            return token_value
    
    async def validate_api_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Validate API token and return user info"""
        
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        
        async with self.db_pool.acquire() as conn:
            token_row = await conn.fetchrow("""
                SELECT t.*, u.email, u.username, u.role
                FROM api_tokens t
                JOIN users u ON t.user_id = u.id
                WHERE t.token_hash = $1 AND t.is_active = true 
                  AND t.expires_at > CURRENT_TIMESTAMP
                  AND u.is_active = true
            """, token_hash)
            
            if not token_row:
                return None
            
            # Update last used and usage count
            await conn.execute("""
                UPDATE api_tokens 
                SET last_used = CURRENT_TIMESTAMP, usage_count = usage_count + 1
                WHERE id = $1
            """, token_row['id'])
            
            return {
                "user_id": str(token_row['user_id']),
                "email": token_row['email'],
                "username": token_row['username'],
                "role": token_row['role'],
                "permissions": json.loads(token_row['permissions']),
                "token_name": token_row['name']
            }
    
    async def get_user_permissions(self, user_id: str) -> List[Permission]:
        """Get user permissions"""
        
        async with self.db_pool.acquire() as conn:
            user_row = await conn.fetchrow(
                "SELECT role FROM users WHERE id = $1 AND is_active = true",
                user_id
            )
            
            if not user_row:
                return []
            
            user_role = UserRole(user_row['role'])
            return ROLE_PERMISSIONS[user_role]
    
    async def check_permission(self, user_id: str, required_permission: Permission) -> bool:
        """Check if user has specific permission"""
        
        user_permissions = await self.get_user_permissions(user_id)
        return required_permission in user_permissions
    
    async def revoke_api_token(self, user_id: str, token_id: str) -> bool:
        """Revoke API token"""
        
        async with self.db_pool.acquire() as conn:
            result = await conn.execute("""
                UPDATE api_tokens 
                SET is_active = false 
                WHERE id = $1 AND user_id = $2
            """, token_id, user_id)
            
            return result == "UPDATE 1"
    
    async def get_audit_logs(self, user_id: Optional[str] = None, 
                           limit: int = 100) -> List[AuditLog]:
        """Get audit logs"""
        
        async with self.db_pool.acquire() as conn:
            if user_id:
                rows = await conn.fetch("""
                    SELECT * FROM audit_logs 
                    WHERE user_id = $1
                    ORDER BY timestamp DESC 
                    LIMIT $2
                """, user_id, limit)
            else:
                rows = await conn.fetch("""
                    SELECT * FROM audit_logs 
                    ORDER BY timestamp DESC 
                    LIMIT $1
                """, limit)
            
            logs = []
            for row in rows:
                log = AuditLog(
                    id=str(row['id']),
                    user_id=str(row['user_id']) if row['user_id'] else None,
                    action=row['action'],
                    resource=row['resource'],
                    resource_id=row['resource_id'],
                    ip_address=row['ip_address'],
                    user_agent=row['user_agent'],
                    timestamp=row['timestamp'],
                    success=row['success'],
                    error_message=row['error_message']
                )
                logs.append(log)
            
            return logs

# FastAPI Application
app = FastAPI(
    title="Terradev Auth Service",
    description="Authentication and Authorization for Terradev Platform",
    version="1.0.0"
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://api.terradev.io", "https://app.terradev.io"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["api.terradev.io", "localhost", "127.0.0.1"]
)

# Security
security = HTTPBearer()

# Global auth service
auth_service = None

# Dependency injection
async def get_auth_service() -> AuthService:
    global auth_service
    if auth_service is None:
        auth_service = AuthService(
            database_url=os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost/terradev"),
            redis_url=os.getenv("REDIS_URL", "redis://localhost:6379/0"),
            jwt_secret=os.getenv("JWT_SECRET", "your-secret-key")
        )
        await auth_service.initialize()
    return auth_service

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security),
                         auth_service: AuthService = Depends(get_auth_service)) -> Dict[str, Any]:
    """Get current user from JWT token"""
    
    try:
        payload = jwt.decode(
            credentials.credentials, 
            auth_service.jwt_secret, 
            algorithms=[auth_service.jwt_algorithm]
        )
        
        user_id = payload["user_id"]
        
        # Get user from database
        async with auth_service.db_pool.acquire() as conn:
            user_row = await conn.fetchrow(
                "SELECT * FROM users WHERE id = $1 AND is_active = true",
                user_id
            )
            
            if not user_row:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found or inactive"
                )
            
            return {
                "user_id": user_id,
                "email": user_row["email"],
                "username": user_row["username"],
                "role": user_row["role"],
                "permissions": payload.get("permissions", [])
            }
            
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired"
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

# API Routes
@app.post("/auth/register", response_model=dict)
async def register(user_data: UserCreate,
                   auth_service: AuthService = Depends(get_auth_service)):
    """Register new user"""
    
    user = await auth_service.create_user(user_data)
    return {"message": "User created successfully", "user_id": user.id}

@app.post("/auth/login", response_model=TokenResponse)
async def login(login_data: UserLogin,
               request: Request,
               auth_service: AuthService = Depends(get_auth_service)):
    """User login"""
    
    ip_address = request.client.host
    user_agent = request.headers.get("user-agent", "")
    
    return await auth_service.authenticate_user(login_data, ip_address, user_agent)

@app.post("/auth/refresh", response_model=TokenResponse)
async def refresh_token(refresh_token: str,
                       auth_service: AuthService = Depends(get_auth_service)):
    """Refresh access token"""
    
    return await auth_service.refresh_token(refresh_token)

@app.post("/auth/api-tokens")
async def create_api_token(token_data: APITokenCreate,
                          current_user: Dict = Depends(get_current_user),
                          auth_service: AuthService = Depends(get_auth_service)):
    """Create API token"""
    
    token_value = await auth_service.create_api_token(
        current_user["user_id"], token_data
    )
    
    return {"token": token_value, "message": "API token created successfully"}

@app.get("/auth/me")
async def get_current_user_info(current_user: Dict = Depends(get_current_user)):
    """Get current user information"""
    
    return current_user

@app.get("/auth/permissions")
async def get_user_permissions(current_user: Dict = Depends(get_current_user),
                              auth_service: AuthService = Depends(get_auth_service)):
    """Get user permissions"""
    
    permissions = await auth_service.get_user_permissions(current_user["user_id"])
    return {"permissions": [p.value for p in permissions]}

@app.delete("/auth/api-tokens/{token_id}")
async def revoke_api_token(token_id: str,
                          current_user: Dict = Depends(get_current_user),
                          auth_service: AuthService = Depends(get_auth_service)):
    """Revoke API token"""
    
    success = await auth_service.revoke_api_token(current_user["user_id"], token_id)
    
    if success:
        return {"message": "API token revoked successfully"}
    else:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="API token not found"
        )

@app.get("/auth/audit-logs")
async def get_audit_logs(current_user: Dict = Depends(get_current_user),
                        auth_service: AuthService = Depends(get_auth_service),
                        limit: int = 100):
    """Get audit logs"""
    
    # Only admins can view all logs, others can only see their own
    user_id = current_user["user_id"] if current_user["role"] != "admin" else None
    
    logs = await auth_service.get_audit_logs(user_id, limit)
    
    return {
        "logs": [
            {
                "id": log.id,
                "user_id": log.user_id,
                "action": log.action,
                "resource": log.resource,
                "resource_id": log.resource_id,
                "ip_address": log.ip_address,
                "timestamp": log.timestamp.isoformat(),
                "success": log.success,
                "error_message": log.error_message
            }
            for log in logs
        ]
    }

# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

# Startup event
@app.on_event("startup")
async def startup_event():
    """Initialize auth service on startup"""
    
    await get_auth_service()

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "auth_service:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
