import os

import logging

#!/usr/bin/env python3
"""
TensorDock Demo and Testing Script
Demonstrates TensorDock integration functionality
"""

import asyncio
import json
from pathlib import Path

from tensordock_integration import TensorDockManager, TensorDockCredentials
from tensordock_provider import TensorDockProvider
from tensordock_deployment import TensorDockDeploymentManager

async def demo_tensordock_integration():
    """Demonstrate TensorDock integration features"""
    
    logging.info("🚀 TensorDock Integration Demo")
    logging.info("=" * 50)
    
    # Initialize credentials
    credentials = TensorDockCredentials(
        client_id="6f71b631-5a32-42f1-94a5-d089adffdb24",
        api_token = os.environ.get("TOKEN_API_TOKEN", "rxOI1pnIZ9UL3J8MZmMmYBkKk7EwPdyS")
    )
    
    logging.info(f"✅ Initialized credentials for client: {credentials.client_id}")
    
    # Test provider connection
    logging.info("\n🔍 Testing Provider Connection...")
    provider = TensorDockProvider(
        client_id=credentials.client_id,
        api_token=credentials.api_token
    )
    
    try:
        async with provider:
            # Test connection (will fail with demo credentials)
            logging.info("📡 Testing API connection...")
            # connection_ok = await provider.test_connection()
            # print(f"Connection status: {'✅ Success' if connection_ok else '❌ Failed'}")
            
            # Get available instance types
            instance_types = await provider.get_instance_types()
            logging.info(f"📋 Available instance types: {list(instance_types.keys()
            
            # Show instance type details
            for instance_type, config in instance_types.items():
                logging.info(f"   {instance_type}: {config['cpu']} CPU, {config['memory']}GB RAM, {config['gpu']} GPU")
            
            # Get pricing
            logging.info("\n💰 Pricing Information:")
            # TODO: OPTIMIZATION - Use more efficient pattern for .keys() iteration
# ('instance_type', 'instance_types'):
                pricing = await provider.get_pricing(instance_type)
                logging.info(f"   {instance_type}: ${pricing['hourly']}/hour, ${pricing['monthly']}/month")
    
    except Exception as e:
        logging.info(f"❌ Provider demo failed: {e}")
    
    # Test deployment manager
    logging.info("\n🏗️ Testing Deployment Manager...")
    deployment_manager = TensorDockDeploymentManager()
    
    try:
        # Show available deployment configurations
        logging.info("📋 Available deployment configurations:")
        for config_name, config in deployment_manager.deployment_configs.items():
            logging.info(f"   {config_name}: {config.node_count} nodes, {config.instance_type}, environment: {config.environment}")
        
        # Generate Kubernetes config
        logging.info("\n☸️ Generating Kubernetes configuration...")
        k8s_config = deployment_manager.generate_kubernetes_config("ml-development")
        logging.info("Kubernetes config generated successfully")
        logging.info("Sample config:")
        logging.info(k8s_config[:300] + "..." if len(k8s_config)
        
        # Save demo config
        k8s_file = Path("demo_k8s_config.yaml")
        with open(k8s_file, 'w') as f:
            f.write(k8s_config)
        logging.info(f"✅ Kubernetes config saved to {k8s_file}")
        
    except Exception as e:
        logging.info(f"❌ Deployment manager demo failed: {e}")
    
    # Test instance configuration
    logging.info("\n⚙️ Testing Instance Configuration...")
    
    try:
        from tensordock_integration import InstanceResources, GPUResource, CloudInit, InstanceConfig
        
        # Create GPU resource
        gpu = GPUResource(model="geforcertx4090-pcie-24gb", count=2)
        logging.info(f"✅ Created GPU resource: {gpu.model} x{gpu.count}")
        
        # Create instance resources
        resources = InstanceResources(
            vcpu_count=16,
            ram_gb=64,
            storage_gb=500,
            gpus={"geforcertx4090-pcie-24gb": gpu}
        )
        logging.info(f"✅ Created instance resources: {resources.vcpu_count} CPU, {resources.ram_gb}GB RAM, {resources.storage_gb}GB storage")
        
        # Create cloud-init configuration
        cloud_init = CloudInit(
            package_update=True,
            package_upgrade=True,
            packages=["python3", "git", "docker.io"],
            runcmd=[
                "systemctl enable docker",
                "usermod -aG docker ubuntu",
                "echo 'TensorDock instance ready!' > /etc/motd"
            ]
        )
        logging.info(f"✅ Created cloud-init config with {len(cloud_init.packages)
        
        # Create instance configuration
        config = InstanceConfig(
            name="demo-instance",
            resources=resources,
            cloud_init=cloud_init
        )
        logging.info(f"✅ Created instance configuration: {config.name}")
        
    except Exception as e:
        logging.info(f"❌ Instance configuration demo failed: {e}")
    
    logging.info("\n🎯 Demo Summary:")
    logging.info("✅ TensorDock integration components initialized")
    logging.info("✅ Provider configuration and instance types available")
    logging.info("✅ Deployment manager with pre-configured environments")
    logging.info("✅ Kubernetes configuration generation")
    logging.info("✅ Instance configuration and cloud-init setup")
    logging.info("\n📝 Note: Actual API calls require valid TensorDock credentials")
    logging.info("🚀 Ready for production deployment with real credentials!")

async def test_mock_functionality():
    """Test functionality with mocked responses"""
    
    logging.info("\n🧪 Testing Mock Functionality")
    logging.info("=" * 50)
    
    # Test data models
    try:
        from tensordock_integration import (
            TensorDockCredentials, GPUResource, InstanceResources, 
            CloudInit, InstanceConfig
        )
        
        # Test credentials
        creds = TensorDockCredentials(
            client_id="test-client",
            api_token = os.environ.get("TOKEN_API_TOKEN", "test-token")
        )
        logging.info("✅ Credentials model works")
        
        # Test GPU resource
        gpu = GPUResource(model="rtx4090", count=2)
        logging.info(f"✅ GPU resource: {gpu.model} x{gpu.count}")
        
        # Test instance resources
        resources = InstanceResources(
            vcpu_count=8,
            ram_gb=32,
            storage_gb=200,
            gpus={"rtx4090": gpu}
        )
        logging.info(f"✅ Instance resources: {resources.vcpu_count} CPU, {resources.ram_gb}GB RAM")
        
        # Test cloud-init
        cloud_init = CloudInit(
            packages=["nginx", "git"],
            runcmd=["echo 'Hello World'"]
        )
        logging.info(f"✅ Cloud-init: {len(cloud_init.packages)
        
        # Test instance config
        config = InstanceConfig(
            name="test-instance",
            resources=resources,
            cloud_init=cloud_init
        )
        logging.info(f"✅ Instance config: {config.name}")
        
    except Exception as e:
        logging.info(f"❌ Model testing failed: {e}")
    
    # Test provider without API calls
    try:
        from tensordock_provider import TensorDockProvider
        
        provider = TensorDockProvider(
            client_id="test-client",
            api_token = os.environ.get("TOKEN_API_TOKEN", "test-token")
        )
        
        # Test instance types
        instance_types = await provider.get_instance_types()
        logging.info(f"✅ Instance types: {list(instance_types.keys()
        
        # Test pricing
        pricing = await provider.get_pricing("ml-medium")
        logging.info(f"✅ Pricing for ml-medium: ${pricing['hourly']}/hour")
        
    except Exception as e:
        logging.info(f"❌ Provider testing failed: {e}")
    
    # Test deployment manager
    try:
        from tensordock_deployment import TensorDockDeploymentManager
        
        manager = TensorDockDeploymentManager()
        
        # Test deployment configs
        configs = list(manager.deployment_configs.keys())
        logging.info(f"✅ Deployment configs: {configs}")
        
        # Test Kubernetes config generation
        k8s_config = manager.generate_kubernetes_config("ml-development")
        logging.info(f"✅ K8s config generated: {len(k8s_config)
        
    except Exception as e:
        logging.info(f"❌ Deployment manager testing failed: {e}")

async def main():
    """Main demo function"""
    await demo_tensordock_integration()
    await test_mock_functionality()

if __name__ == "__main__":
    asyncio.run(main())
