import os

#!/usr/bin/env python3
"""
TensorDock Battle Test Script
Comprehensive testing with rate limiting and throttling protection
"""

import asyncio
import aiohttp
import time
import json
import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import random
import statistics

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class TestMetrics:
    """Test metrics collection"""
    total_requests: int
    successful_requests: int
    failed_requests: int
    average_response_time: float
    max_response_time: float
    min_response_time: float
    throttled_requests: int
    errors: List[str]

class TensorDockBattleTester:
    """Comprehensive TensorDock testing with throttling protection"""
    
    def __init__(self, client_id: str, api_token: str, base_url: str = "https://api.tensordock.com"):
        self.client_id = client_id
        self.api_token = api_token
        self.base_url = base_url
        self.session: Optional[aiohttp.ClientSession] = None
        
        # Rate limiting configuration
        self.requests_per_second = 5  # Conservative rate limit
        self.burst_capacity = 10
        self.retry_attempts = 3
        self.retry_delay = 2.0  # seconds
        
        # Request queue for rate limiting
        self.request_times: List[float] = []
        self.request_semaphore = asyncio.Semaphore(self.burst_capacity)
        
    async def __aenter__(self):
        """Async context manager entry"""
        connector = aiohttp.TCPConnector(
            limit=20,  # Connection pool limit
            limit_per_host=10,  # Per-host connection limit
            ttl_dns_cache=300,  # DNS cache TTL
            use_dns_cache=True,
        )
        
        timeout = aiohttp.ClientTimeout(
            total=30,  # Total timeout
            connect=10,  # Connect timeout
            sock_read=20  # Read timeout
        )
        
        self.session = aiohttp.ClientSession(
            headers={
                "Authorization": f"Bearer {self.api_token}",
                "X-Client-ID": self.client_id,
                "Content-Type": "application/json",
                "User-Agent": "Terradev-Battle-Tester/1.0"
            },
            connector=connector,
            timeout=timeout
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def _rate_limit(self):
        """Implement rate limiting with token bucket algorithm"""
        now = time.time()
        
        # Remove old request times (older than 1 second)
        self.request_times = [t for t in self.request_times if now - t < 1.0]
        
        # Check if we can make a request
        if len(self.request_times) >= self.requests_per_second:
            # Calculate sleep time
            oldest_request = min(self.request_times)
            sleep_time = 1.0 - (now - oldest_request)
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)
        
        # Add current request time
        self.request_times.append(now)
    
    async def _make_request_with_retry(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make request with retry logic and rate limiting"""
        
        async with self.request_semaphore:
            await self._rate_limit()
            
            for attempt in range(self.retry_attempts):
                try:
                    start_time = time.time()
                    
                    async with self.session.request(method, f"{self.base_url}{endpoint}", json=data) as response:
                        response_time = time.time() - start_time
                        
                        if response.status == 200:
                            return await response.json()
                        elif response.status == 201:
                            return await response.json()
                        elif response.status == 429:
                            # Rate limited - wait and retry
                            logger.warning(f"Rate limited (attempt {attempt + 1}/{self.retry_attempts})")
                            if attempt < self.retry_attempts - 1:
                                await asyncio.sleep(self.retry_delay * (2 ** attempt))  # Exponential backoff
                                continue
                            else:
                                raise Exception("Rate limit exceeded after all retries")
                        elif response.status >= 500:
                            # Server error - retry
                            logger.warning(f"Server error {response.status} (attempt {attempt + 1}/{self.retry_attempts})")
                            if attempt < self.retry_attempts - 1:
                                await asyncio.sleep(self.retry_delay * (2 ** attempt))
                                continue
                            else:
                                raise Exception(f"Server error {response.status} after all retries")
                        else:
                            # Client error - don't retry
                            error_text = await response.text()
                            raise Exception(f"Client error {response.status}: {error_text}")
                
                except aiohttp.ClientError as e:
                    logger.warning(f"Network error (attempt {attempt + 1}/{self.retry_attempts}): {e}")
                    if attempt < self.retry_attempts - 1:
                        await asyncio.sleep(self.retry_delay * (2 ** attempt))
                        continue
                    else:
                        raise
                except Exception as e:
                    if attempt < self.retry_attempts - 1:
                        await asyncio.sleep(self.retry_delay * (2 ** attempt))
                        continue
                    else:
                        raise
    
    async def test_connection(self) -> TestMetrics:
        """Test basic connection"""
        logger.info("🔍 Testing basic connection...")
        
        start_time = time.time()
        successful = 0
        failed = 0
        response_times = []
        errors = []
        throttled = 0
        
        try:
            result = await self._make_request_with_retry("GET", "/api/v2/instances")
            response_time = time.time() - start_time
            successful += 1
            response_times.append(response_time)
            logger.info(f"✅ Connection test successful: {response_time:.2f}s")
            
        except Exception as e:
            failed += 1
            errors.append(str(e))
            logger.error(f"❌ Connection test failed: {e}")
        
        return TestMetrics(
            total_requests=1,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def test_list_instances(self, concurrent_requests: int = 5) -> TestMetrics:
        """Test listing instances with concurrent requests"""
        logger.info(f"📋 Testing list instances with {concurrent_requests} concurrent requests...")
        
        tasks = []
        for i in range(concurrent_requests):
            task = asyncio.create_task(self._single_list_instances_request())
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Aggregate results
        total_requests = len(results)
        successful = sum(1 for r in results if isinstance(r, dict) and r.get("success", False))
        failed = total_requests - successful
        
        response_times = [r.get("response_time", 0) for r in results if isinstance(r, dict)]
        errors = [str(r) for r in results if isinstance(r, Exception)]
        throttled = sum(1 for r in results if isinstance(r, dict) and r.get("throttled", False))
        
        return TestMetrics(
            total_requests=total_requests,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def _single_list_instances_request(self) -> Dict[str, Any]:
        """Single list instances request"""
        start_time = time.time()
        
        try:
            result = await self._make_request_with_retry("GET", "/api/v2/instances")
            response_time = time.time() - start_time
            
            return {
                "success": True,
                "response_time": response_time,
                "result": result
            }
            
        except Exception as e:
            response_time = time.time() - start_time
            return {
                "success": False,
                "response_time": response_time,
                "error": str(e)
            }
    
    async def test_instance_lifecycle(self, instance_count: int = 2) -> TestMetrics:
        """Test complete instance lifecycle"""
        logger.info(f"🔄 Testing instance lifecycle with {instance_count} instances...")
        
        total_requests = 0
        successful = 0
        failed = 0
        response_times = []
        errors = []
        throttled = 0
        created_instances = []
        
        try:
            # Create instances
            logger.info("📦 Creating instances...")
            for i in range(instance_count):
                try:
                    instance_data = await self._create_test_instance(f"battle-test-{i}")
                    created_instances.append(instance_data.get("id"))
                    successful += 1
                    logger.info(f"✅ Created instance: battle-test-{i}")
                except Exception as e:
                    failed += 1
                    errors.append(f"Create instance {i}: {str(e)}")
                    logger.error(f"❌ Failed to create instance {i}: {e}")
                
                total_requests += 1
            
            # Wait for instances to be ready
            if created_instances:
                logger.info("⏳ Waiting for instances to be ready...")
                await asyncio.sleep(30)  # Wait for instances to initialize
                
                # List instances
                logger.info("📋 Listing instances...")
                try:
                    instances = await self._make_request_with_retry("GET", "/api/v2/instances")
                    successful += 1
                    logger.info(f"✅ Listed {len(instances.get('data', {}).get('instances', []))} instances")
                except Exception as e:
                    failed += 1
                    errors.append(f"List instances: {str(e)}")
                    logger.error(f"❌ Failed to list instances: {e}")
                
                total_requests += 1
                
                # Get instance details
                for instance_id in created_instances:
                    try:
                        await self._make_request_with_retry("GET", f"/api/v2/instances/{instance_id}")
                        successful += 1
                    except Exception as e:
                        failed += 1
                        errors.append(f"Get instance {instance_id}: {str(e)}")
                    
                    total_requests += 1
                
                # Clean up instances
                logger.info("🗑️ Cleaning up instances...")
                for instance_id in created_instances:
                    try:
                        await self._make_request_with_retry("DELETE", f"/api/v2/instances/{instance_id}")
                        successful += 1
                        logger.info(f"✅ Deleted instance: {instance_id}")
                    except Exception as e:
                        failed += 1
                        errors.append(f"Delete instance {instance_id}: {str(e)}")
                        logger.error(f"❌ Failed to delete instance {instance_id}: {e}")
                    
                    total_requests += 1
        
        except Exception as e:
            failed += 1
            errors.append(f"Lifecycle test: {str(e)}")
            logger.error(f"❌ Lifecycle test failed: {e}")
        
        return TestMetrics(
            total_requests=total_requests,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def _create_test_instance(self, name: str) -> Dict[str, Any]:
        """Create a test instance"""
        request_data = {
            "data": {
                "type": "virtualmachine",
                "attributes": {
                    "name": name,
                    "type": "virtualmachine",
                    "image": "ubuntu2404",
                    "resources": {
                        "vcpu_count": 4,
                        "ram_gb": 16,
                        "storage_gb": 100,
                        "gpus": {
                            "geforcertx4090-pcie-24gb": {
                                "count": 1
                            }
                        }
                    },
                    "useDedicatedIp": True
                }
            }
        }
        
        return await self._make_request_with_retry("POST", "/api/v2/instances", request_data)
    
    async def test_load(self, duration_seconds: int = 60, requests_per_second: int = 3) -> TestMetrics:
        """Test sustained load"""
        logger.info(f"⚡ Testing sustained load: {requests_per_second} req/s for {duration_seconds}s...")
        
        start_time = time.time()
        end_time = start_time + duration_seconds
        
        total_requests = 0
        successful = 0
        failed = 0
        response_times = []
        errors = []
        throttled = 0
        
        while time.time() < end_time:
            try:
                # Make a request
                request_start = time.time()
                await self._make_request_with_retry("GET", "/api/v2/instances")
                request_time = time.time() - request_start
                
                successful += 1
                response_times.append(request_time)
                total_requests += 1
                
                # Wait to maintain rate
                await asyncio.sleep(1.0 / requests_per_second)
                
            except Exception as e:
                failed += 1
                errors.append(str(e))
                total_requests += 1
                
                # Still wait to maintain rate
                await asyncio.sleep(1.0 / requests_per_second)
        
        actual_duration = time.time() - start_time
        actual_rps = total_requests / actual_duration
        
        logger.info(f"📊 Load test completed: {actual_rps:.2f} req/s over {actual_duration:.1f}s")
        
        return TestMetrics(
            total_requests=total_requests,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def run_battle_test(self) -> Dict[str, Any]:
        """Run comprehensive battle test"""
        logger.info("🚀 Starting TensorDock Battle Test")
        logger.info("=" * 50)
        
        results = {}
        
        # Test 1: Basic Connection
        logger.info("\n🔍 Test 1: Basic Connection")
        results["connection"] = await self.test_connection()
        
        # Test 2: List Instances (Concurrent)
        logger.info("\n📋 Test 2: List Instances (Concurrent)")
        results["list_instances"] = await self.test_list_instances(concurrent_requests=5)
        
        # Test 3: Instance Lifecycle
        logger.info("\n🔄 Test 3: Instance Lifecycle")
        results["lifecycle"] = await self.test_instance_lifecycle(instance_count=2)
        
        # Test 4: Sustained Load
        logger.info("\n⚡ Test 4: Sustained Load")
        results["load"] = await self.test_load(duration_seconds=30, requests_per_second=3)
        
        # Generate summary
        logger.info("\n📊 Battle Test Results Summary")
        logger.info("=" * 50)
        
        total_requests = sum(r.total_requests for r in results.values())
        total_successful = sum(r.successful_requests for r in results.values())
        total_failed = sum(r.failed_requests for r in results.values())
        total_throttled = sum(r.throttled_requests for r in results.values())
        
        success_rate = (total_successful / total_requests * 100) if total_requests > 0 else 0
        throttle_rate = (total_throttled / total_requests * 100) if total_requests > 0 else 0
        
        logger.info(f"📈 Total Requests: {total_requests}")
        logger.info(f"✅ Successful: {total_successful} ({success_rate:.1f}%)")
        logger.info(f"❌ Failed: {total_failed} ({100-success_rate:.1f}%)")
        logger.info(f"⚠️ Throttled: {total_throttled} ({throttle_rate:.1f}%)")
        
        # Detailed results
        for test_name, metrics in results.items():
            logger.info(f"\n📋 {test_name.replace('_', ' ').title()}:")
            logger.info(f"   Requests: {metrics.total_requests}")
            logger.info(f"   Success: {metrics.successful_requests}")
            logger.info(f"   Failed: {metrics.failed_requests}")
            logger.info(f"   Avg Response: {metrics.average_response_time:.2f}s")
            logger.info(f"   Max Response: {metrics.max_response_time:.2f}s")
            logger.info(f"   Min Response: {metrics.min_response_time:.2f}s")
            
            if metrics.errors:
                logger.info(f"   Errors: {len(metrics.errors)}")
                for error in metrics.errors[:3]:  # Show first 3 errors
                    logger.info(f"     - {error}")
        
        # Overall assessment
        logger.info(f"\n🎯 Overall Assessment:")
        if success_rate >= 95:
            logger.info("✅ EXCELLENT - System performing very well")
        elif success_rate >= 90:
            logger.info("✅ GOOD - System performing well")
        elif success_rate >= 80:
            logger.info("⚠️ FAIR - System has some issues")
        else:
            logger.info("❌ POOR - System has significant issues")
        
        if throttle_rate > 10:
            logger.info("⚠️ High throttling detected - consider reducing request rate")
        elif throttle_rate > 5:
            logger.info("ℹ️ Moderate throttling - rate limiting is working")
        else:
            logger.info("✅ Low throttling - rate limiting is effective")
        
        return {
            "summary": {
                "total_requests": total_requests,
                "successful_requests": total_successful,
                "failed_requests": total_failed,
                "throttled_requests": total_throttled,
                "success_rate": success_rate,
                "throttle_rate": throttle_rate
            },
            "detailed_results": results
        }

async def main():
    """Main battle test function"""
    # Initialize tester with provided credentials
    tester = TensorDockBattleTester(
        client_id="6f71b631-5a32-42f1-94a5-d089adffdb24",
        api_token = os.environ.get("TOKEN_API_TOKEN", "rxOI1pnIZ9UL3J8MZmMmYBkKk7EwPdyS")
    )
    
    async with tester:
        results = await tester.run_battle_test()
        
        # Save results to file
        results_file = "tensordock_battle_test_results.json"
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"\n💾 Results saved to {results_file}")
        
        # Return summary
        return results["summary"]

if __name__ == "__main__":
    asyncio.run(main())
