#!/usr/bin/env python3
"""
Terradev Credits System
Honest abstraction mapping credits to compute classes, duration, and volatility bands
Avoids cloud reseller liability while providing clean UX
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ComputeClass(Enum):
    """Compute classes for honest abstraction"""
    GPU_PREMIUM = "gpu_premium"      # A100, H100, etc.
    GPU_STANDARD = "gpu_standard"    # A10G, V100, etc.
    GPU_ECONOMY = "gpu_economy"      # T4, etc.
    CPU_PREMIUM = "cpu_premium"      # High-memory, high-cpu
    CPU_STANDARD = "cpu_standard"    # Standard compute
    CPU_ECONOMY = "cpu_economy"      # Basic compute
    INFERENCE = "inference"          # Specialized inference
    TRAINING = "training"            # Specialized training

class VolatilityBand(Enum):
    """Volatility bands for pricing and availability"""
    ULTRA_STABLE = "ultra_stable"    # 99.9% availability, premium pricing
    STABLE = "stable"                # 99% availability, standard pricing
    VARIABLE = "variable"            # 95% availability, discounted pricing
    SPOT = "spot"                    # 80% availability, deep discount

@dataclass
class CreditMapping:
    """Internal mapping of Terradev Credits to actual resources"""
    credit_amount: float
    compute_class: ComputeClass
    duration_seconds: int
    volatility_band: VolatilityBand
    provider: str
    actual_cost_usd: float
    effective_rate: float
    interruption_rate: float

@dataclass
class UserCreditBalance:
    """User's credit balance and usage"""
    user_id: str
    total_credits: float
    available_credits: float
    used_credits: float
    credit_history: List[Dict]
    billing_cycle_start: datetime
    billing_cycle_end: datetime

@dataclass
class CostAnalysis:
    """Cost analysis for user transparency"""
    effective_dollar_per_gpu_hour: float
    savings_vs_single_cloud: float
    baseline_single_cloud_cost: float
    terradev_cost: float
    interruption_rate: float
    volatility_adjustment: float

class TerradevCreditsEngine:
    """
    Terradev Credits Engine
    Honest abstraction without cloud reseller liability
    """
    
    def __init__(self):
        self.credit_mappings = self._initialize_credit_mappings()
        self.user_balances = {}
        self.pricing_cache = {}
        
        # Provider configurations
        self.providers = {
            'aws': {'name': 'AWS', 'margin': 0.15},
            'gcp': {'name': 'GCP', 'margin': 0.12},
            'azure': {'name': 'Azure', 'margin': 0.18},
            'runpod': {'name': 'RunPod', 'margin': 0.08},
            'lambda': {'name': 'Lambda Labs', 'margin': 0.10},
            'coreweave': {'name': 'CoreWeave', 'margin': 0.07},
            'huggingface': {'name': 'HuggingFace', 'margin': 0.05}
        }
    
    def _initialize_credit_mappings(self) -> Dict[str, CreditMapping]:
        """Initialize credit mappings for compute classes"""
        
        mappings = {}
        
        # GPU Premium mappings
        mappings['gpu_premium_aws'] = CreditMapping(
            credit_amount=1.0,
            compute_class=ComputeClass.GPU_PREMIUM,
            duration_seconds=3600,  # 1 hour
            volatility_band=VolatilityBand.STABLE,
            provider='aws',
            actual_cost_usd=3.20,  # A100 on AWS
            effective_rate=3.20,
            interruption_rate=0.01
        )
        
        mappings['gpu_premium_runpod'] = CreditMapping(
            credit_amount=1.0,
            compute_class=ComputeClass.GPU_PREMIUM,
            duration_seconds=3600,
            volatility_band=VolatilityBand.VARIABLE,
            provider='runpod',
            actual_cost_usd=2.80,  # A100 on RunPod
            effective_rate=2.80,
            interruption_rate=0.05
        )
        
        mappings['gpu_standard_hf'] = CreditMapping(
            credit_amount=1.0,
            compute_class=ComputeClass.GPU_STANDARD,
            duration_seconds=3600,
            volatility_band=VolatilityBand.ULTRA_STABLE,
            provider='huggingface',
            actual_cost_usd=0.60,  # A10G on HF
            effective_rate=0.60,
            interruption_rate=0.001
        )
        
        mappings['gpu_standard_aws'] = CreditMapping(
            credit_amount=1.0,
            compute_class=ComputeClass.GPU_STANDARD,
            duration_seconds=3600,
            volatility_band=VolatilityBand.STABLE,
            provider='aws',
            actual_cost_usd=1.20,  # A10G on AWS
            effective_rate=1.20,
            interruption_rate=0.02
        )
        
        mappings['gpu_economy_spot'] = CreditMapping(
            credit_amount=1.0,
            compute_class=ComputeClass.GPU_ECONOMY,
            duration_seconds=3600,
            volatility_band=VolatilityBand.SPOT,
            provider='aws',
            actual_cost_usd=0.20,  # T4 spot
            effective_rate=0.20,
            interruption_rate=0.20
        )
        
        mappings['cpu_standard_aws'] = CreditMapping(
            credit_amount=1.0,
            compute_class=ComputeClass.CPU_STANDARD,
            duration_seconds=3600,
            volatility_band=VolatilityBand.STABLE,
            provider='aws',
            actual_cost_usd=0.10,
            effective_rate=0.10,
            interruption_rate=0.001
        )
        
        mappings['inference_hf'] = CreditMapping(
            credit_amount=1.0,
            compute_class=ComputeClass.INFERENCE,
            duration_seconds=3600,
            volatility_band=VolatilityBand.ULTRA_STABLE,
            provider='huggingface',
            actual_cost_usd=0.20,
            effective_rate=0.20,
            interruption_rate=0.001
        )
        
        return mappings
    
    async def calculate_credits_needed(self, 
                                       compute_class: ComputeClass,
                                       duration_seconds: int,
                                       volatility_band: VolatilityBand,
                                       user_preferences: Dict = None) -> Tuple[float, List[CreditMapping]]:
        """
        Calculate credits needed for a compute request
        Returns (total_credits, recommended_mappings)
        """
        
        # Find suitable mappings
        suitable_mappings = []
        
        for mapping_id, mapping in self.credit_mappings.items():
            if (mapping.compute_class == compute_class and 
                mapping.volatility_band == volatility_band):
                suitable_mappings.append(mapping)
        
        if not suitable_mappings:
            # Find closest match
            for mapping in self.credit_mappings.values():
                if (mapping.compute_class == compute_class and
                    mapping.duration_seconds <= duration_seconds):
                    suitable_mappings.append(mapping)
        
        if not suitable_mappings:
            raise ValueError(f"No suitable mapping found for {compute_class.value}")
        
        # Sort by effective rate (lowest first)
        suitable_mappings.sort(key=lambda m: m.effective_rate)
        
        # Calculate credits needed
        best_mapping = suitable_mappings[0]
        credits_needed = (duration_seconds / best_mapping.duration_seconds) * best_mapping.credit_amount
        
        return credits_needed, [best_mapping]
    
    async def get_cost_analysis(self, 
                               compute_class: ComputeClass,
                               duration_seconds: int,
                               volatility_band: VolatilityBand) -> CostAnalysis:
        """
        Get cost analysis for user transparency
        """
        
        credits_needed, mappings = await self.calculate_credits_needed(
            compute_class, duration_seconds, volatility_band
        )
        
        if not mappings:
            raise ValueError("No mappings available")
        
        best_mapping = mappings[0]
        
        # Calculate effective $/GPU-hour
        if compute_class.value.startswith('gpu'):
            effective_gpu_hour_rate = best_mapping.effective_rate
        else:
            effective_gpu_hour_rate = best_mapping.effective_rate * 0.1  # CPU equivalent
        
        # Calculate baseline single-cloud cost (AWS as baseline)
        baseline_mapping = None
        for mapping in self.credit_mappings.values():
            if (mapping.compute_class == compute_class and 
                mapping.provider == 'aws' and
                mapping.volatility_band == VolatilityBand.STABLE):
                baseline_mapping = mapping
                break
        
        baseline_cost = baseline_mapping.actual_cost_usd if baseline_mapping else best_mapping.actual_cost_usd * 1.5
        terradev_cost = best_mapping.actual_cost_usd
        
        savings_vs_baseline = ((baseline_cost - terradev_cost) / baseline_cost) * 100
        
        return CostAnalysis(
            effective_dollar_per_gpu_hour=effective_gpu_hour_rate,
            savings_vs_single_cloud=savings_vs_baseline,
            baseline_single_cloud_cost=baseline_cost,
            terradev_cost=terradev_cost,
            interruption_rate=best_mapping.interruption_rate,
            volatility_adjustment=self._get_volatility_adjustment(volatility_band)
        )
    
    def _get_volatility_adjustment(self, band: VolatilityBand) -> float:
        """Get volatility adjustment factor"""
        adjustments = {
            VolatilityBand.ULTRA_STABLE: 1.0,
            VolatilityBand.STABLE: 0.95,
            VolatilityBand.VARIABLE: 0.85,
            VolatilityBand.SPOT: 0.70
        }
        return adjustments.get(band, 1.0)
    
    async def consume_credits(self, 
                            user_id: str,
                            compute_class: ComputeClass,
                            duration_seconds: int,
                            volatility_band: VolatilityBand) -> Dict:
        """
        Consume credits for a compute request
        """
        
        # Ensure user balance exists
        if user_id not in self.user_balances:
            self.user_balances[user_id] = UserCreditBalance(
                user_id=user_id,
                total_credits=1000.0,  # Start with 1000 credits
                available_credits=1000.0,
                used_credits=0.0,
                credit_history=[],
                billing_cycle_start=datetime.now(),
                billing_cycle_end=datetime.now() + timedelta(days=30)
            )
        
        # Calculate credits needed
        credits_needed, mappings = await self.calculate_credits_needed(
            compute_class, duration_seconds, volatility_band
        )
        
        user_balance = self.user_balances[user_id]
        
        # Check if user has enough credits
        if user_balance.available_credits < credits_needed:
            raise ValueError(f"Insufficient credits. Need {credits_needed}, have {user_balance.available_credits}")
        
        # Consume credits
        user_balance.available_credits -= credits_needed
        user_balance.used_credits += credits_needed
        
        # Record transaction
        transaction = {
            'timestamp': datetime.now().isoformat(),
            'credits_consumed': credits_needed,
            'compute_class': compute_class.value,
            'duration_seconds': duration_seconds,
            'volatility_band': volatility_band.value,
            'provider': mappings[0].provider,
            'effective_rate': mappings[0].effective_rate,
            'interruption_rate': mappings[0].interruption_rate
        }
        
        user_balance.credit_history.append(transaction)
        
        return {
            'success': True,
            'credits_consumed': credits_needed,
            'remaining_credits': user_balance.available_credits,
            'provider': mappings[0].provider,
            'effective_rate': mappings[0].effective_rate,
            'interruption_rate': mappings[0].interruption_rate
        }
    
    def get_user_credit_summary(self, user_id: str) -> Dict:
        """Get user credit summary"""
        
        if user_id not in self.user_balances:
            return {'error': 'User not found'}
        
        balance = self.user_balances[user_id]
        
        # Calculate usage statistics
        total_transactions = len(balance.credit_history)
        gpu_transactions = [t for t in balance.credit_history if 'gpu' in t['compute_class']]
        
        avg_interruption_rate = sum(t['interruption_rate'] for t in balance.credit_history) / total_transactions if total_transactions > 0 else 0
        
        return {
            'user_id': user_id,
            'total_credits': balance.total_credits,
            'available_credits': balance.available_credits,
            'used_credits': balance.used_credits,
            'usage_percentage': (balance.used_credits / balance.total_credits) * 100,
            'total_transactions': total_transactions,
            'gpu_transactions': len(gpu_transactions),
            'average_interruption_rate': avg_interruption_rate,
            'billing_cycle_start': balance.billing_cycle_start.isoformat(),
            'billing_cycle_end': balance.billing_cycle_end.isoformat(),
            'recent_transactions': balance.credit_history[-5:]  # Last 5 transactions
        }
    
    def get_marketplace_rates(self) -> Dict:
        """Get current marketplace rates for transparency"""
        
        rates = {}
        
        for class_type in ComputeClass:
            class_rates = {}
            
            for band in VolatilityBand:
                # Find best rate for this class/band combination
                best_mapping = None
                best_rate = float('inf')
                
                for mapping in self.credit_mappings.values():
                    if (mapping.compute_class == class_type and 
                        mapping.volatility_band == band):
                        if mapping.effective_rate < best_rate:
                            best_rate = mapping.effective_rate
                            best_mapping = mapping
                
                if best_mapping:
                    class_rates[band.value] = {
                        'credits_per_hour': best_mapping.credit_amount,
                        'effective_rate_usd': best_mapping.effective_rate,
                        'provider': best_mapping.provider,
                        'interruption_rate': best_mapping.interruption_rate,
                        'volatility_adjustment': self._get_volatility_adjustment(band)
                    }
            
            if class_rates:
                rates[class_type.value] = class_rates
        
        return rates

# CLI interface
async def main():
    """CLI interface for Terradev Credits"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Terradev Credits Engine')
    parser.add_argument('--user-id', default='demo-user', help='User ID')
    parser.add_argument('--check-balance', action='store_true', help='Check user balance')
    parser.add_argument('--get-rates', action='store_true', help='Get marketplace rates')
    parser.add_argument('--consume', action='store_true', help='Consume credits')
    parser.add_argument('--compute-class', choices=['gpu_premium', 'gpu_standard', 'gpu_economy', 'cpu_standard', 'inference'], help='Compute class')
    parser.add_argument('--duration', type=int, default=3600, help='Duration in seconds')
    parser.add_argument('--volatility', choices=['ultra_stable', 'stable', 'variable', 'spot'], default='stable', help='Volatility band')
    parser.add_argument('--cost-analysis', action='store_true', help='Get cost analysis')
    
    args = parser.parse_args()
    
    engine = TerradevCreditsEngine()
    
    if args.check_balance:
        summary = engine.get_user_credit_summary(args.user_id)
        logging.info("💰 User Credit Summary:")
        logging.info(f"Available Credits: {summary['available_credits']:.1f}")
        logging.info(f"Used Credits: {summary['used_credits']:.1f}")
        logging.info(f"Usage Percentage: {summary['usage_percentage']:.1f}%")
        logging.info(f"Average Interruption Rate: {summary['average_interruption_rate']:.2%}")
    
    elif args.get_rates:
        rates = engine.get_marketplace_rates()
        logging.info("📊 Marketplace Rates:")
        for class_type, class_rates in rates.items():
            logging.info(f"\n{class_type.upper()
            for band, rate_info in class_rates.items():
                logging.info(f"  {band}: ${rate_info['effective_rate_usd']:.2f}/hr ({rate_info['provider']})
    
    elif args.consume:
        if not args.compute_class:
            logging.info("❌ --compute-class required for credit consumption")
            return
        
        compute_class = ComputeClass(args.compute_class)
        volatility_band = VolatilityBand(args.volatility)
        
        try:
            result = await engine.consume_credits(
                args.user_id, compute_class, args.duration, volatility_band
            )
            logging.info("✅ Credits Consumed:")
            logging.info(f"Credits Used: {result['credits_consumed']:.2f}")
            logging.info(f"Remaining Credits: {result['remaining_credits']:.2f}")
            logging.info(f"Provider: {result['provider']}")
            logging.info(f"Effective Rate: ${result['effective_rate']:.2f}/hr")
            logging.info(f"Interruption Rate: {result['interruption_rate']:.1%}")
        except Exception as e:
            logging.info(f"❌ Credit consumption failed: {e}")
    
    elif args.cost_analysis:
        if not args.compute_class:
            logging.info("❌ --compute-class required for cost analysis")
            return
        
        compute_class = ComputeClass(args.compute_class)
        volatility_band = VolatilityBand(args.volatility)
        
        analysis = await engine.get_cost_analysis(compute_class, args.duration, volatility_band)
        
        logging.info("💰 Cost Analysis:")
        logging.info(f"Effective $/GPU-hour: ${analysis.effective_dollar_per_gpu_hour:.2f}")
        logging.info(f"Savings vs Single Cloud: {analysis.savings_vs_single_cloud:.1f}%")
        logging.info(f"Baseline Single Cloud Cost: ${analysis.baseline_single_cloud_cost:.2f}")
        logging.info(f"Terradev Cost: ${analysis.terradev_cost:.2f}")
        logging.info(f"Interruption Rate: {analysis.interruption_rate:.1%}")
        logging.info(f"Volatility Adjustment: {analysis.volatility_adjustment:.1%}")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    asyncio.run(main())
