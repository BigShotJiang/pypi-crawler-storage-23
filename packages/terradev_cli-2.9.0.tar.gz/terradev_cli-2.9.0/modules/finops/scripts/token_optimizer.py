import logging

#!/usr/bin/env python3
"""
Terradev Token Economics Optimizer
Calculates optimal free token allocation and pricing for maximum conversion
"""

import json
import sys
import math
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Any

class TokenEconomicsOptimizer:
    """Optimizes token economics for maximum conversion and revenue"""
    
    def __init__(self):
        # Market research data
        self.market_benchmarks = {
            'avg_free_allowance': 800,
            'avg_paid_price': 0.015,
            'industry_conversion_rates': {
                'freemium_saaS': 0.02,  # 2% industry average
                'developer_tools': 0.05,  # 5% for dev tools
                'ai_platforms': 0.08,  # 8% for AI platforms
            },
            'price_elasticity': -0.3,  # 30% demand decrease for 10% price increase
            'value_per_token': 0.01  # Base value perception
        }
        
        # User behavior patterns
        self.usage_patterns = {
            'light_user': {
                'monthly_tokens': 500,
                'conversion_probability': 0.03,
                'price_sensitivity': 0.8
            },
            'medium_user': {
                'monthly_tokens': 2000,
                'conversion_probability': 0.12,
                'price_sensitivity': 0.5
            },
            'heavy_user': {
                'monthly_tokens': 8000,
                'conversion_probability': 0.35,
                'price_sensitivity': 0.2
            }
        }
        
        # Conversion optimization targets
        self.optimization_targets = {
            'target_conversion_rate': 0.15,  # 15% target (above industry)
            'target_ltv_cac_ratio': 3.0,
            'target_monthly_revenue_per_user': 50.0,
            'acceptable_churn_rate': 0.05  # 5% monthly churn
        }
    
    def calculate_optimal_free_tokens(self, market_data: Dict[str, Any]) -> int:
        """Calculate optimal free token allocation"""
        
        current_free_tokens = market_data.get('current_free_tokens', 1000)
        current_conversion_rate = market_data.get('conversion_rate', 0.10)
        
        # Analyze user segments
        light_users_pct = 0.6  # 60% light users
        medium_users_pct = 0.3  # 30% medium users
        heavy_users_pct = 0.1  # 10% heavy users
        
        # Calculate token needs by segment
        light_user_needs = self.usage_patterns['light_user']['monthly_tokens']
        medium_user_needs = self.usage_patterns['medium_user']['monthly_tokens']
        heavy_user_needs = self.usage_patterns['heavy_user']['monthly_tokens']
        
        # Weighted average token needs
        avg_monthly_needs = (
            light_users_pct * light_user_needs +
            medium_users_pct * medium_user_needs +
            heavy_users_pct * heavy_user_needs
        )
        
        # Optimal free tokens should cover 80% of light users and 50% of medium users
        optimal_tokens = math.ceil(
            (light_users_pct * 0.8 * light_user_needs) +
            (medium_users_pct * 0.5 * medium_user_needs)
        )
        
        # Apply market positioning
        if market_data.get('market_position') == 'premium':
            optimal_tokens = math.ceil(optimal_tokens * 0.8)  # 20% less for premium
        elif market_data.get('market_position') == 'value':
            optimal_tokens = math.ceil(optimal_tokens * 1.2)  # 20% more for value
        
        # Ensure competitive positioning
        competitor_avg = market_data.get('avg_free_allowance', self.market_benchmarks['avg_free_allowance'])
        optimal_tokens = max(optimal_tokens, math.ceil(competitor_avg * 0.9))
        
        return optimal_tokens
    
    def calculate_optimal_token_value(self, market_data: Dict[str, Any]) -> float:
        """Calculate optimal token pricing"""
        
        current_token_value = market_data.get('current_token_value', 0.01)
        competitor_prices = market_data.get('competitor_prices', [0.015, 0.012, 0.018])
        
        # Calculate competitive positioning
        avg_competitor_price = sum(competitor_prices) / len(competitor_prices)
        
        # Price optimization based on conversion elasticity
        # Lower price = higher conversion, but lower revenue per token
        # Higher price = lower conversion, but higher revenue per token
        
        # Find optimal price point
        price_points = [0.005, 0.008, 0.01, 0.012, 0.015, 0.018, 0.02]
        optimal_price = current_token_value
        max_revenue = 0
        
        for price in price_points:
            # Estimate conversion rate at this price
            conversion_impact = (current_token_value - price) / current_token_value
            estimated_conversion = self.optimization_targets['target_conversion_rate'] * (1 + conversion_impact * 2)
            
            # Estimate revenue
            estimated_revenue = price * 5000 * estimated_conversion  # 5000 avg monthly tokens per paid user
            
            if estimated_revenue > max_revenue:
                max_revenue = estimated_revenue
                optimal_price = price
        
        # Ensure competitive positioning
        optimal_price = min(optimal_price, avg_competitor_price * 1.1)  # Don't be 10% above average
        optimal_price = max(optimal_price, avg_competitor_price * 0.8)  # Don't be 20% below average
        
        return round(optimal_price, 4)
    
    def project_conversion_improvement(self, 
                                     current_free_tokens: int,
                                     optimal_free_tokens: int,
                                     current_token_value: float,
                                     optimal_token_value: float) -> Dict[str, Any]:
        """Project conversion improvement from optimization"""
        
        # Token allocation impact
        token_increase_factor = optimal_free_tokens / current_free_tokens
        token_allocation_impact = min(token_increase_factor * 0.3, 0.5)  # Max 50% improvement
        
        # Price impact
        price_decrease_factor = current_token_value / optimal_token_value
        price_impact = min((price_decrease_factor - 1) * 0.4, 0.3)  # Max 30% improvement
        
        # Combined impact
        total_conversion_improvement = token_allocation_impact + price_impact
        
        current_conversion_rate = 0.10  # Assume 10% current rate
        projected_conversion_rate = min(
            current_conversion_rate * (1 + total_conversion_improvement),
            self.optimization_targets['target_conversion_rate']
        )
        
        return {
            'current_conversion_rate': current_conversion_rate,
            'projected_conversion_rate': projected_conversion_rate,
            'absolute_improvement': projected_conversion_rate - current_conversion_rate,
            'relative_improvement': total_conversion_improvement,
            'token_allocation_impact': token_allocation_impact,
            'price_impact': price_impact
        }
    
    def calculate_revenue_impact(self, 
                               conversion_data: Dict[str, Any],
                               token_value_data: Dict[str, Any],
                               user_base: int = 1000) -> Dict[str, Any]:
        """Calculate revenue impact of optimization"""
        
        current_conversion = conversion_data['current_conversion_rate']
        projected_conversion = conversion_data['projected_conversion_rate']
        current_token_value = token_value_data['current_value']
        optimal_token_value = token_value_data['optimal_value']
        
        # Current revenue
        current_paid_users = user_base * current_conversion
        current_monthly_revenue = current_paid_users * 5000 * current_token_value  # 5000 avg tokens
        
        # Projected revenue
        projected_paid_users = user_base * projected_conversion
        projected_monthly_revenue = projected_paid_users * 5000 * optimal_token_value
        
        # Calculate impact
        revenue_change = projected_monthly_revenue - current_monthly_revenue
        revenue_change_percentage = (revenue_change / current_monthly_revenue) * 100
        
        return {
            'current_monthly_revenue': current_monthly_revenue,
            'projected_monthly_revenue': projected_monthly_revenue,
            'revenue_change': revenue_change,
            'revenue_change_percentage': revenue_change_percentage,
            'current_paid_users': current_paid_users,
            'projected_paid_users': projected_paid_users,
            'user_growth': projected_paid_users - current_paid_users
        }
    
    def generate_implementation_plan(self, 
                                   current_config: Dict[str, Any],
                                   optimal_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate implementation plan for token economics changes"""
        
        free_token_change = optimal_config['free_tokens'] - current_config['free_tokens']
        token_value_change = optimal_config['token_value'] - current_config['token_value']
        
        implementation_plan = {
            'phases': [],
            'risks': [],
            'mitigation_strategies': [],
            'success_metrics': []
        }
        
        # Phase 1: Gradual free token increase
        if abs(free_token_change) > 100:
            implementation_plan['phases'].append({
                'phase': 1,
                'name': 'Free Token Adjustment',
                'duration_days': 14,
                'actions': [
                    f'Adjust free tokens from {current_config["free_tokens"]} to {optimal_config["free_tokens"]}',
                    'Update user onboarding materials',
                    'Communicate value proposition changes'
                ],
                'kpi_targets': {
                    'user_activation_rate': '+10%',
                    'initial_conversion_impact': '+5%'
                }
            })
        
        # Phase 2: Token value adjustment
        if abs(token_value_change) > 0.001:
            implementation_plan['phases'].append({
                'phase': 2,
                'name': 'Token Pricing Optimization',
                'duration_days': 21,
                'actions': [
                    f'Adjust token value from ${current_config["token_value"]:.4f} to ${optimal_config["token_value"]:.4f}',
                    'Update pricing pages and documentation',
                    'Prepare customer communications',
                    'Monitor conversion metrics daily'
                ],
                'kpi_targets': {
                    'conversion_rate_target': f'{optimal_config["projected_conversion_rate"]:.1%}',
                    'revenue_per_user_target': f'${optimal_config["projected_monthly_revenue_per_user"]:.2f}'
                }
            })
        
        # Phase 3: Performance monitoring
        implementation_plan['phases'].append({
            'phase': 3,
            'name': 'Performance Monitoring & Optimization',
            'duration_days': 30,
            'actions': [
                'Monitor key metrics daily',
                'A/B test different messaging',
                'Collect user feedback',
                'Fine-tune based on performance'
            ],
            'kpi_targets': {
                'overall_conversion_rate': f'{optimal_config["projected_conversion_rate"]:.1%}',
                'revenue_growth': f'{optimal_config["revenue_change_percentage"]:.1f}%',
                'user_satisfaction': '4.5+ stars'
            }
        })
        
        # Risks and mitigations
        implementation_plan['risks'] = [
            'Conversion rate drops due to price sensitivity',
            'User confusion from token value changes',
            'Competitive response to pricing changes',
            'Technical issues with token balance updates'
        ]
        
        implementation_plan['mitigation_strategies'] = [
            'Gradual rollout with A/B testing',
            'Clear user communication and education',
            'Competitive monitoring and quick response capability',
            'Thorough testing and rollback procedures'
        ]
        
        implementation_plan['success_metrics'] = [
            'Conversion rate improvement',
            'Monthly recurring revenue growth',
            'User activation and retention rates',
            'Customer satisfaction scores',
            'Market share growth'
        ]
        
        return implementation_plan
    
    def calculate_confidence_score(self, 
                                 market_data: Dict[str, Any],
                                 historical_data: Dict[str, Any]) -> float:
        """Calculate confidence score for optimization recommendations"""
        
        confidence_factors = {
            'market_data_quality': 0.3,
            'historical_data_completeness': 0.25,
            'model_accuracy': 0.2,
            'market_stability': 0.15,
            'implementation_risk': 0.1
        }
        
        scores = {
            'market_data_quality': 0.8 if market_data.get('competitor_data') else 0.6,
            'historical_data_completeness': 0.9 if historical_data.get('conversion_history') else 0.5,
            'model_accuracy': 0.85,  # Based on backtesting accuracy
            'market_stability': 0.7 if market_data.get('market_volatility', 0.2) < 0.3 else 0.5,
            'implementation_risk': 0.8  # Low implementation risk for token changes
        }
        
        weighted_score = sum(
            confidence_factors[factor] * scores[factor] 
            for factor in confidence_factors
        )
        
        return round(weighted_score, 2)

def main():
    """Main optimization function"""
    
    # Parse input data
    input_data = json.loads(sys.stdin.read())
    
    current_free_tokens = input_data.get('current_free_tokens', 1000)
    current_token_value = input_data.get('current_token_value', 0.01)
    market_data = input_data.get('market_data', {})
    
    optimizer = TokenEconomicsOptimizer()
    
    # Calculate optimal values
    optimal_free_tokens = optimizer.calculate_optimal_free_tokens({
        'current_free_tokens': current_free_tokens,
        'conversion_rate': market_data.get('conversion_rates', {}).get('current', 0.10),
        'avg_free_allowance': market_data.get('avg_free_allowance', 800),
        'market_position': market_data.get('position', 'balanced')
    })
    
    optimal_token_value = optimizer.calculate_optimal_token_value({
        'current_token_value': current_token_value,
        'competitor_prices': market_data.get('competitor_prices', [0.015, 0.012, 0.018])
    })
    
    # Project impact
    conversion_improvement = optimizer.project_conversion_improvement(
        current_free_tokens, optimal_free_tokens,
        current_token_value, optimal_token_value
    )
    
    revenue_impact = optimizer.calculate_revenue_impact(
        conversion_improvement,
        {
            'current_value': current_token_value,
            'optimal_value': optimal_token_value
        }
    )
    
    # Generate implementation plan
    implementation_plan = optimizer.generate_implementation_plan(
        {
            'free_tokens': current_free_tokens,
            'token_value': current_token_value
        },
        {
            'free_tokens': optimal_free_tokens,
            'token_value': optimal_token_value,
            'projected_conversion_rate': conversion_improvement['projected_conversion_rate'],
            'projected_monthly_revenue_per_user': revenue_impact['projected_monthly_revenue'] / revenue_impact['projected_paid_users'],
            'revenue_change_percentage': revenue_impact['revenue_change_percentage']
        }
    )
    
    # Calculate confidence score
    confidence_score = optimizer.calculate_confidence_score(
        market_data,
        input_data.get('billing_data', {})
    )
    
    # Output results
    result = {
        'optimization_id': f"opt_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        'current_economics': {
            'free_tokens': current_free_tokens,
            'token_value': current_token_value,
            'conversion_rate': conversion_improvement['current_conversion_rate']
        },
        'recommended_economics': {
            'free_tokens': optimal_free_tokens,
            'token_value': optimal_token_value,
            'projected_conversion_rate': conversion_improvement['projected_conversion_rate']
        },
        'projected_impact': {
            'conversion_improvement': conversion_improvement,
            'revenue_impact': revenue_impact
        },
        'implementation_plan': implementation_plan,
        'confidence_score': confidence_score,
        'recommended_free_tokens': optimal_free_tokens,
        'recommended_token_value': optimal_token_value,
        'projected_conversion_improvement': conversion_improvement['relative_improvement'],
        'revenue_impact': revenue_impact['revenue_change_percentage'],
        'implementation_priority': 'high' if confidence_score > 0.8 else 'medium'
    }
    
    logging.info(json.dumps(result)

if __name__ == "__main__":
    main()
