import logging

#!/usr/bin/env python3
"""
Terradev Granular Cost Tracker
Tracks GPU costs by team, project, business unit with real-time attribution
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Set
from enum import Enum
import sqlite3
from contextlib import asynccontextmanager
import threading

class CostCenterType(Enum):
    TEAM = "team"
    PROJECT = "project"
    BUSINESS_UNIT = "business_unit"
    USER = "user"
    WORKLOAD = "workload"

class GranularityLevel(Enum):
    REALTIME = "realtime"
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"

@dataclass
class CostCenter:
    """Cost center definition"""
    cost_center_id: str
    cost_center_type: CostCenterType
    name: str
    parent_id: Optional[str]  # For hierarchical cost centers
    budget_limit: Optional[float]
    alert_threshold: float  # Percentage of budget to trigger alerts
    owners: List[str]  # User IDs responsible for this cost center
    tags: Dict[str, str]

@dataclass
class CostAllocation:
    """Individual cost allocation"""
    allocation_id: str
    cost_center_id: str
    provider: str
    resource_id: str
    resource_type: str
    usage_start: datetime
    usage_end: datetime
    usage_quantity: float
    unit_cost: float
    total_cost: float
    currency: str
    allocation_percentage: float  # If cost is split across cost centers
    metadata: Dict[str, Any]

@dataclass
class BudgetAlert:
    """Budget alert notification"""
    alert_id: str
    cost_center_id: str
    alert_type: str  # budget_warning, budget_exceeded, forecast_exceeded
    current_spend: float
    budget_limit: float
    percentage_used: float
    forecast_spend: Optional[float]
    message: str
    timestamp: datetime
    recipients: List[str]

class GranularCostTracker:
    """Tracks costs with granular attribution to teams, projects, business units"""
    
    def __init__(self, db_path: str = "cost_tracker.db"):
        self.db_path = db_path
        self.cost_centers: Dict[str, CostCenter] = {}
        self.active_allocations: Dict[str, CostAllocation] = {}
        self.alert_handlers: List[callable] = []
        self._init_database()
        
    def _init_database(self):
        """Initialize SQLite database for cost tracking"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Cost centers table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cost_centers (
                    cost_center_id TEXT PRIMARY KEY,
                    cost_center_type TEXT NOT NULL,
                    name TEXT NOT NULL,
                    parent_id TEXT,
                    budget_limit REAL,
                    alert_threshold REAL DEFAULT 80.0,
                    owners TEXT,  -- JSON array
                    tags TEXT,    -- JSON object
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Cost allocations table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cost_allocations (
                    allocation_id TEXT PRIMARY KEY,
                    cost_center_id TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    resource_id TEXT NOT NULL,
                    resource_type TEXT NOT NULL,
                    usage_start TIMESTAMP NOT NULL,
                    usage_end TIMESTAMP NOT NULL,
                    usage_quantity REAL NOT NULL,
                    unit_cost REAL NOT NULL,
                    total_cost REAL NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    allocation_percentage REAL DEFAULT 100.0,
                    metadata TEXT,  -- JSON object
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (cost_center_id) REFERENCES cost_centers (cost_center_id)
                )
            ''')
            
            # Budget alerts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS budget_alerts (
                    alert_id TEXT PRIMARY KEY,
                    cost_center_id TEXT NOT NULL,
                    alert_type TEXT NOT NULL,
                    current_spend REAL NOT NULL,
                    budget_limit REAL NOT NULL,
                    percentage_used REAL NOT NULL,
                    forecast_spend REAL,
                    message TEXT NOT NULL,
                    timestamp TIMESTAMP NOT NULL,
                    recipients TEXT,  -- JSON array
                    acknowledged BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY (cost_center_id) REFERENCES cost_centers (cost_center_id)
                )
            ''')
            
            conn.commit()
    
    def create_cost_center(self, 
                          cost_center_type: CostCenterType,
                          name: str,
                          parent_id: Optional[str] = None,
                          budget_limit: Optional[float] = None,
                          alert_threshold: float = 80.0,
                          owners: List[str] = None,
                          tags: Dict[str, str] = None) -> str:
        """Create a new cost center"""
        
        cost_center_id = f"{cost_center_type.value}_{name.lower().replace(' ', '_')}"
        
        cost_center = CostCenter(
            cost_center_id=cost_center_id,
            cost_center_type=cost_center_type,
            name=name,
            parent_id=parent_id,
            budget_limit=budget_limit,
            alert_threshold=alert_threshold,
            owners=owners or [],
            tags=tags or {}
        )
        
        # Store in memory
        self.cost_centers[cost_center_id] = cost_center
        
        # Store in database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO cost_centers 
                (cost_center_id, cost_center_type, name, parent_id, budget_limit, 
                 alert_threshold, owners, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                cost_center_id, cost_center_type.value, name, parent_id,
                budget_limit, alert_threshold, json.dumps(owners), json.dumps(tags)
            ))
            conn.commit()
        
        return cost_center_id
    
    async def allocate_cost(self,
                           cost_center_id: str,
                           provider: str,
                           resource_id: str,
                           resource_type: str,
                           usage_start: datetime,
                           usage_end: datetime,
                           usage_quantity: float,
                           unit_cost: float,
                           allocation_percentage: float = 100.0,
                           metadata: Dict[str, Any] = None) -> str:
        """Allocate cost to a specific cost center"""
        
        if cost_center_id not in self.cost_centers:
            raise ValueError(f"Cost center {cost_center_id} not found")
        
        allocation_id = f"alloc_{int(time.time())}_{resource_id}"
        total_cost = usage_quantity * unit_cost * (allocation_percentage / 100.0)
        
        allocation = CostAllocation(
            allocation_id=allocation_id,
            cost_center_id=cost_center_id,
            provider=provider,
            resource_id=resource_id,
            resource_type=resource_type,
            usage_start=usage_start,
            usage_end=usage_end,
            usage_quantity=usage_quantity,
            unit_cost=unit_cost,
            total_cost=total_cost,
            currency='USD',
            allocation_percentage=allocation_percentage,
            metadata=metadata or {}
        )
        
        # Store in memory
        self.active_allocations[allocation_id] = allocation
        
        # Store in database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO cost_allocations 
                (allocation_id, cost_center_id, provider, resource_id, resource_type,
                 usage_start, usage_end, usage_quantity, unit_cost, total_cost,
                 allocation_percentage, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                allocation_id, cost_center_id, provider, resource_id, resource_type,
                usage_start, usage_end, usage_quantity, unit_cost, total_cost,
                allocation_percentage, json.dumps(metadata)
            ))
            conn.commit()
        
        # Check budget alerts
        await self._check_budget_alerts(cost_center_id)
        
        return allocation_id
    
    async def split_cost_allocation(self,
                                   cost_center_ids: List[str],
                                   percentages: List[float],
                                   provider: str,
                                   resource_id: str,
                                   resource_type: str,
                                   usage_start: datetime,
                                   usage_end: datetime,
                                   usage_quantity: float,
                                   unit_cost: float,
                                   metadata: Dict[str, Any] = None) -> List[str]:
        """Split cost allocation across multiple cost centers"""
        
        if len(cost_center_ids) != len(percentages):
            raise ValueError("Cost centers and percentages must have same length")
        
        if sum(percentages) != 100.0:
            raise ValueError("Percentages must sum to 100")
        
        allocation_ids = []
        
        for cost_center_id, percentage in zip(cost_center_ids, percentages):
            allocation_id = await self.allocate_cost(
                cost_center_id=cost_center_id,
                provider=provider,
                resource_id=resource_id,
                resource_type=resource_type,
                usage_start=usage_start,
                usage_end=usage_end,
                usage_quantity=usage_quantity,
                unit_cost=unit_cost,
                allocation_percentage=percentage,
                metadata=metadata
            )
            allocation_ids.append(allocation_id)
        
        return allocation_ids
    
    def get_cost_center_spend(self, 
                             cost_center_id: str,
                             start_date: datetime,
                             end_date: datetime) -> Dict[str, Any]:
        """Get total spend for a cost center in date range"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    SUM(total_cost) as total_spend,
                    COUNT(*) as allocation_count,
                    provider,
                    resource_type,
                    SUM(usage_quantity) as total_usage
                FROM cost_allocations 
                WHERE cost_center_id = ? 
                AND usage_start >= ? 
                AND usage_end <= ?
                GROUP BY provider, resource_type
            ''', (cost_center_id, start_date, end_date))
            
            results = cursor.fetchall()
            
            total_spend = sum(row[0] for row in results)
            allocation_count = sum(row[1] for row in results)
            
            breakdown = {}
            for row in results:
                provider, resource_type, total_usage = row[2], row[3], row[4]
                key = f"{provider}:{resource_type}"
                if key not in breakdown:
                    breakdown[key] = {'usage': 0, 'cost': 0}
                breakdown[key]['usage'] += total_usage
                breakdown[key]['cost'] += row[0]
            
            return {
                'cost_center_id': cost_center_id,
                'period': {
                    'start': start_date.isoformat(),
                    'end': end_date.isoformat()
                },
                'total_spend': total_spend,
                'allocation_count': allocation_count,
                'breakdown': breakdown
            }
    
    def get_hierarchy_spend(self,
                           cost_center_id: str,
                           start_date: datetime,
                           end_date: datetime) -> Dict[str, Any]:
        """Get spend for cost center and all its children"""
        
        # Get all child cost centers
        child_ids = self._get_child_cost_centers(cost_center_id)
        all_ids = [cost_center_id] + child_ids
        
        total_spend = 0
        breakdown = {}
        
        for cc_id in all_ids:
            spend_data = self.get_cost_center_spend(cc_id, start_date, end_date)
            total_spend += spend_data['total_spend']
            breakdown[cc_id] = spend_data
        
        return {
            'root_cost_center': cost_center_id,
            'total_spend': total_spend,
            'cost_center_breakdown': breakdown,
            'period': {
                'start': start_date.isoformat(),
                'end': end_date.isoformat()
            }
        }
    
    def _get_child_cost_centers(self, parent_id: str) -> List[str]:
        """Get all child cost centers recursively"""
        
        children = []
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT cost_center_id FROM cost_centers 
                WHERE parent_id = ?
            ''', (parent_id,))
            
            direct_children = [row[0] for row in cursor.fetchall()]
            
            for child_id in direct_children:
                children.append(child_id)
                children.extend(self._get_child_cost_centers(child_id))
        
        return children
    
    async def _check_budget_alerts(self, cost_center_id: str):
        """Check if cost center has exceeded budget thresholds"""
        
        cost_center = self.cost_centers[cost_center_id]
        
        if not cost_center.budget_limit:
            return  # No budget set
        
        # Get current month spend
        now = datetime.utcnow()
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        spend_data = self.get_cost_center_spend(cost_center_id, month_start, now)
        current_spend = spend_data['total_spend']
        
        percentage_used = (current_spend / cost_center.budget_limit) * 100
        
        # Check alert thresholds
        if percentage_used >= 100:
            alert_type = "budget_exceeded"
            message = f"Budget exceeded for {cost_center.name}: ${current_spend:.2f} / ${cost_center.budget_limit:.2f} ({percentage_used:.1f}%)"
        elif percentage_used >= cost_center.alert_threshold:
            alert_type = "budget_warning"
            message = f"Budget warning for {cost_center.name}: ${current_spend:.2f} / ${cost_center.budget_limit:.2f} ({percentage_used:.1f}%)"
        else:
            return  # No alert needed
        
        # Create alert
        alert_id = f"alert_{int(time.time())}_{cost_center_id}"
        
        alert = BudgetAlert(
            alert_id=alert_id,
            cost_center_id=cost_center_id,
            alert_type=alert_type,
            current_spend=current_spend,
            budget_limit=cost_center.budget_limit,
            percentage_used=percentage_used,
            forecast_spend=None,  # Could add forecasting logic
            message=message,
            timestamp=now,
            recipients=cost_center.owners
        )
        
        # Store alert
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO budget_alerts 
                (alert_id, cost_center_id, alert_type, current_spend, budget_limit,
                 percentage_used, forecast_spend, message, timestamp, recipients)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                alert_id, cost_center_id, alert_type, current_spend, cost_center.budget_limit,
                percentage_used, alert.forecast_spend, message, now, json.dumps(cost_center.owners)
            ))
            conn.commit()
        
        # Trigger alert handlers
        for handler in self.alert_handlers:
            await handler(alert)
    
    def add_alert_handler(self, handler: callable):
        """Add custom alert handler (e.g., Slack, email)"""
        self.alert_handlers.append(handler)
    
    def get_cost_center_hierarchy(self) -> Dict[str, Any]:
        """Get hierarchical view of all cost centers"""
        
        hierarchy = {}
        
        for cost_center in self.cost_centers.values():
            if cost_center.parent_id is None:
                # Root level cost center
                hierarchy[cost_center.cost_center_id] = {
                    'name': cost_center.name,
                    'type': cost_center.cost_center_type.value,
                    'budget_limit': cost_center.budget_limit,
                    'children': {}
                }
        
        # Add children to their parents
        for cost_center in self.cost_centers.values():
            if cost_center.parent_id and cost_center.parent_id in hierarchy:
                hierarchy[cost_center.parent_id]['children'][cost_center.cost_center_id] = {
                    'name': cost_center.name,
                    'type': cost_center.cost_center_type.value,
                    'budget_limit': cost_center.budget_limit
                }
        
        return hierarchy
    
    def generate_finops_report(self,
                              start_date: datetime,
                              end_date: datetime) -> Dict[str, Any]:
        """Generate comprehensive FinOps report"""
        
        report = {
            'period': {
                'start': start_date.isoformat(),
                'end': end_date.isoformat()
            },
            'summary': {
                'total_cost_centers': len(self.cost_centers),
                'total_allocations': len(self.active_allocations)
            },
            'cost_centers': {},
            'top_spenders': [],
            'budget_utilization': {},
            'alerts_summary': {}
        }
        
        # Get spend for each cost center
        total_spend = 0
        spend_by_cost_center = []
        
        for cost_center_id in self.cost_centers:
            spend_data = self.get_cost_center_spend(cost_center_id, start_date, end_date)
            report['cost_centers'][cost_center_id] = spend_data
            total_spend += spend_data['total_spend']
            
            if spend_data['total_spend'] > 0:
                spend_by_cost_center.append((cost_center_id, spend_data['total_spend']))
        
        # Top spenders
        spend_by_cost_center.sort(key=lambda x: x[1], reverse=True)
        report['top_spenders'] = spend_by_cost_center[:10]
        
        # Budget utilization
        for cost_center_id, cost_center in self.cost_centers.items():
            if cost_center.budget_limit:
                spend_data = self.get_cost_center_spend(cost_center_id, start_date, end_date)
                utilization = (spend_data['total_spend'] / cost_center.budget_limit) * 100
                report['budget_utilization'][cost_center_id] = {
                    'budget': cost_center.budget_limit,
                    'spent': spend_data['total_spend'],
                    'utilization_percent': utilization,
                    'remaining': cost_center.budget_limit - spend_data['total_spend']
                }
        
        # Recent alerts
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT alert_type, COUNT(*) as count
                FROM budget_alerts 
                WHERE timestamp >= ? AND timestamp <= ?
                GROUP BY alert_type
            ''', (start_date, end_date))
            
            report['alerts_summary'] = dict(cursor.fetchall())
        
        report['summary']['total_spend'] = total_spend
        
        return report

# Alert handlers
async def slack_alert_handler(alert: BudgetAlert):
    """Send budget alerts to Slack"""
    
    webhook_url = os.getenv('SLACK_WEBHOOK_URL')
    if not webhook_url:
        return
    
    payload = {
        'text': f"🚨 {alert.alert_type.upper()}: {alert.message}",
        'attachments': [{
            'color': 'danger' if alert.alert_type == 'budget_exceeded' else 'warning',
            'fields': [
                {'title': 'Cost Center', 'value': alert.cost_center_id, 'short': True},
                {'title': 'Current Spend', 'value': f"${alert.current_spend:.2f}", 'short': True},
                {'title': 'Budget Limit', 'value': f"${alert.budget_limit:.2f}", 'short': True},
                {'title': 'Percentage Used', 'value': f"{alert.percentage_used:.1f}%", 'short': True}
            ],
            'timestamp': int(alert.timestamp.timestamp())
        }]
    }
    
    async with aiohttp.ClientSession() as session:
        await session.post(webhook_url, json=payload)

async def email_alert_handler(alert: BudgetAlert):
    """Send budget alerts via email"""
    
    # Implementation would depend on email service provider
    logging.info(f"Email Alert: {alert.message}")

# Example usage
async def main():
    """Example of granular cost tracking"""
    
    tracker = GranularCostTracker()
    
    # Add alert handlers
    tracker.add_alert_handler(slack_alert_handler)
    tracker.add_alert_handler(email_alert_handler)
    
    # Create cost centers
    ml_team_id = tracker.create_cost_center(
        cost_center_type=CostCenterType.TEAM,
        name="ML Team",
        budget_limit=10000.0,
        alert_threshold=80.0,
        owners=["alice@company.com", "bob@company.com"]
    )
    
    inference_project_id = tracker.create_cost_center(
        cost_center_type=CostCenterType.PROJECT,
        name="Chatbot Inference",
        parent_id=ml_team_id,
        budget_limit=5000.0,
        owners=["charlie@company.com"]
    )
    
    # Allocate costs
    await tracker.allocate_cost(
        cost_center_id=inference_project_id,
        provider="runpod",
        resource_id="pod-123",
        resource_type="A100-40GB",
        usage_start=datetime.utcnow() - timedelta(hours=2),
        usage_end=datetime.utcnow(),
        usage_quantity=2.0,
        unit_cost=2.50
    )
    
    # Generate report
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=30)
    
    report = tracker.generate_finops_report(start_date, end_date)
    logging.info(f"FinOps Report: {json.dumps(report, indent=2)

if __name__ == "__main__":
    asyncio.run(main())
