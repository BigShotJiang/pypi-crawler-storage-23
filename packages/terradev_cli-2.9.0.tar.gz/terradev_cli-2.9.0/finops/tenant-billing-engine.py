import logging

#!/usr/bin/env python3
"""
Terradev Tenant Billing Engine
Advanced billing system for multi-tenant scenarios with complex pricing models
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Set, Tuple
from enum import Enum
import sqlite3
from decimal import Decimal, ROUND_HALF_UP
import uuid
import math
from collections import defaultdict

class PricingModel(Enum):
    PAY_AS_YOU_GO = "pay_as_you_go"
    TIERED_VOLUME = "tiered_volume"
    COMMITMENT_BASED = "commitment_based"
    SPEND_BASED = "spend_based"
    HYBRID = "hybrid"

class BillingCycle(Enum):
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    ANNUAL = "annual"
    CUSTOM = "custom"

class InvoiceStatus(Enum):
    DRAFT = "draft"
    PENDING = "pending"
    SENT = "sent"
    PAID = "paid"
    OVERDUE = "overdue"
    CANCELLED = "cancelled"

@dataclass
class PricingTier:
    """Pricing tier for volume-based pricing"""
    tier_id: str
    tier_name: str
    min_quantity: float
    max_quantity: Optional[float]
    unit_price: float
    currency: str
    discount_percentage: Optional[float] = 0.0

@dataclass
class CommitmentContract:
    """Commitment-based pricing contract"""
    contract_id: str
    tenant_id: str
    commitment_type: str  # spend, usage, capacity
    commitment_amount: float
    commitment_unit: str
    billing_period: str
    start_date: datetime
    end_date: datetime
    overage_rate: float
    currency: str
    active: bool

@dataclass
class TenantPricingPlan:
    """Pricing plan configuration for tenant"""
    plan_id: str
    tenant_id: str
    pricing_model: PricingModel
    billing_cycle: BillingCycle
    currency: str
    pricing_tiers: List[PricingTier]
    commitments: List[CommitmentContract]
    custom_rates: Dict[str, float]  # Custom rates for specific resources
    discounts: Dict[str, float]  # Discount rules
    billing_rules: Dict[str, Any]
    created_at: datetime
    active: bool

@dataclass
class InvoiceLineItem:
    """Individual line item in tenant invoice"""
    line_item_id: str
    invoice_id: str
    resource_type: str
    resource_id: str
    description: str
    quantity: float
    unit_price: float
    discount_amount: float
    tax_amount: float
    total_amount: float
    currency: str
    period_start: datetime
    period_end: datetime
    metadata: Dict[str, Any]

@dataclass
class TenantInvoice:
    """Complete tenant invoice"""
    invoice_id: str
    tenant_id: str
    invoice_number: str
    billing_period: str
    status: InvoiceStatus
    currency: str
    line_items: List[InvoiceLineItem]
    subtotal: float
    discount_total: float
    tax_total: float
    total_amount: float
    due_date: datetime
    created_at: datetime
    sent_at: Optional[datetime]
    paid_at: Optional[datetime]
    billing_address: Dict[str, str]
    payment_terms: str
    notes: Optional[str]

class TenantBillingEngine:
    """Advanced billing engine for multi-tenant scenarios"""
    
    def __init__(self, db_path: str = "tenant_billing.db"):
        self.db_path = db_path
        self.pricing_plans: Dict[str, TenantPricingPlan] = {}
        self.tax_rates = {
            'US': 0.08,  # 8% US tax
            'EU': 0.21,  # 21% EU VAT
            'APAC': 0.10,  # 10% APAC tax
            'default': 0.0
        }
        self._init_database()
    
    def _init_database(self):
        """Initialize SQLite database for tenant billing"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Pricing plans table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tenant_pricing_plans (
                    plan_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    pricing_model TEXT NOT NULL,
                    billing_cycle TEXT NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    pricing_tiers TEXT,  -- JSON array
                    commitments TEXT,  -- JSON array
                    custom_rates TEXT,  -- JSON object
                    discounts TEXT,  -- JSON object
                    billing_rules TEXT,  -- JSON object
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    active BOOLEAN DEFAULT TRUE
                )
            ''')
            
            # Invoices table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tenant_invoices (
                    invoice_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    invoice_number TEXT NOT NULL,
                    billing_period TEXT NOT NULL,
                    status TEXT NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    subtotal REAL NOT NULL,
                    discount_total REAL DEFAULT 0.0,
                    tax_total REAL DEFAULT 0.0,
                    total_amount REAL NOT NULL,
                    due_date TIMESTAMP NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    sent_at TIMESTAMP,
                    paid_at TIMESTAMP,
                    billing_address TEXT,  -- JSON object
                    payment_terms TEXT,
                    notes TEXT
                )
            ''')
            
            # Invoice line items table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS invoice_line_items (
                    line_item_id TEXT PRIMARY KEY,
                    invoice_id TEXT NOT NULL,
                    resource_type TEXT NOT NULL,
                    resource_id TEXT NOT NULL,
                    description TEXT NOT NULL,
                    quantity REAL NOT NULL,
                    unit_price REAL NOT NULL,
                    discount_amount REAL DEFAULT 0.0,
                    tax_amount REAL DEFAULT 0.0,
                    total_amount REAL NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    period_start TIMESTAMP NOT NULL,
                    period_end TIMESTAMP NOT NULL,
                    metadata TEXT,  -- JSON object
                    FOREIGN KEY (invoice_id) REFERENCES tenant_invoices (invoice_id)
                )
            ''')
            
            # Commitment contracts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS commitment_contracts (
                    contract_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    commitment_type TEXT NOT NULL,
                    commitment_amount REAL NOT NULL,
                    commitment_unit TEXT NOT NULL,
                    billing_period TEXT NOT NULL,
                    start_date TIMESTAMP NOT NULL,
                    end_date TIMESTAMP NOT NULL,
                    overage_rate REAL NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    active BOOLEAN DEFAULT TRUE
                )
            ''')
            
            # Billing metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS billing_metrics (
                    metric_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    billing_period TEXT NOT NULL,
                    total_usage REAL NOT NULL,
                    total_cost REAL NOT NULL,
                    total_discount REAL DEFAULT 0.0,
                    total_tax REAL DEFAULT 0.0,
                    net_revenue REAL NOT NULL,
                    metrics_data TEXT,  -- JSON object
                    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
    
    def create_pricing_plan(self,
                           tenant_id: str,
                           pricing_model: PricingModel,
                           billing_cycle: BillingCycle,
                           currency: str = "USD",
                           pricing_tiers: List[PricingTier] = None,
                           commitments: List[CommitmentContract] = None,
                           custom_rates: Dict[str, float] = None,
                           discounts: Dict[str, float] = None,
                           billing_rules: Dict[str, Any] = None) -> str:
        """Create pricing plan for tenant"""
        
        plan_id = f"plan_{uuid.uuid4().hex[:8]}"
        
        pricing_plan = TenantPricingPlan(
            plan_id=plan_id,
            tenant_id=tenant_id,
            pricing_model=pricing_model,
            billing_cycle=billing_cycle,
            currency=currency,
            pricing_tiers=pricing_tiers or [],
            commitments=commitments or [],
            custom_rates=custom_rates or {},
            discounts=discounts or {},
            billing_rules=billing_rules or {},
            created_at=datetime.utcnow(),
            active=True
        )
        
        # Store in memory
        self.pricing_plans[plan_id] = pricing_plan
        
        # Store in database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO tenant_pricing_plans 
                (plan_id, tenant_id, pricing_model, billing_cycle, currency,
                 pricing_tiers, commitments, custom_rates, discounts, billing_rules)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                plan_id, tenant_id, pricing_model.value, billing_cycle.value, currency,
                json.dumps([asdict(tier) for tier in pricing_tiers]) if pricing_tiers else None,
                json.dumps([asdict(commit) for commit in commitments]) if commitments else None,
                json.dumps(custom_rates), json.dumps(discounts), json.dumps(billing_rules)
            ))
            conn.commit()
        
        return plan_id
    
    async def generate_tenant_invoice(self,
                                     tenant_id: str,
                                     billing_period: str,
                                     usage_data: List[Dict[str, Any]]) -> TenantInvoice:
        """Generate invoice for tenant based on usage data and pricing plan"""
        
        # Get tenant's pricing plan
        pricing_plan = self._get_active_pricing_plan(tenant_id)
        if not pricing_plan:
            raise ValueError(f"No active pricing plan found for tenant {tenant_id}")
        
        # Calculate billing based on pricing model
        if pricing_plan.pricing_model == PricingModel.PAY_AS_YOU_GO:
            line_items = await self._calculate_pay_as_you_go(
                usage_data, pricing_plan, billing_period
            )
        elif pricing_plan.pricing_model == PricingModel.TIERED_VOLUME:
            line_items = await self._calculate_tiered_volume(
                usage_data, pricing_plan, billing_period
            )
        elif pricing_plan.pricing_model == PricingModel.COMMITMENT_BASED:
            line_items = await self._calculate_commitment_based(
                usage_data, pricing_plan, billing_period
            )
        elif pricing_plan.pricing_model == PricingModel.SPEND_BASED:
            line_items = await self._calculate_spend_based(
                usage_data, pricing_plan, billing_period
            )
        elif pricing_plan.pricing_model == PricingModel.HYBRID:
            line_items = await self._calculate_hybrid(
                usage_data, pricing_plan, billing_period
            )
        else:
            raise ValueError(f"Unsupported pricing model: {pricing_plan.pricing_model}")
        
        # Calculate totals
        subtotal = sum(item.total_amount for item in line_items)
        discount_total = sum(item.discount_amount for item in line_items)
        tax_total = sum(item.tax_amount for item in line_items)
        total_amount = subtotal - discount_total + tax_total
        
        # Create invoice
        invoice_id = f"inv_{uuid.uuid4().hex[:8]}"
        invoice_number = f"INV-{tenant_id[:8].upper()}-{billing_period.replace('-', '')}"
        
        # Calculate due date based on billing cycle
        if pricing_plan.billing_cycle == BillingCycle.MONTHLY:
            due_date = datetime.utcnow() + timedelta(days=30)
        elif pricing_plan.billing_cycle == BillingCycle.QUARTERLY:
            due_date = datetime.utcnow() + timedelta(days=90)
        elif pricing_plan.billing_cycle == BillingCycle.ANNUAL:
            due_date = datetime.utcnow() + timedelta(days=365)
        else:
            due_date = datetime.utcnow() + timedelta(days=30)
        
        invoice = TenantInvoice(
            invoice_id=invoice_id,
            tenant_id=tenant_id,
            invoice_number=invoice_number,
            billing_period=billing_period,
            status=InvoiceStatus.DRAFT,
            currency=pricing_plan.currency,
            line_items=line_items,
            subtotal=subtotal,
            discount_total=discount_total,
            tax_total=tax_total,
            total_amount=total_amount,
            due_date=due_date,
            created_at=datetime.utcnow(),
            sent_at=None,
            paid_at=None,
            billing_address=self._get_tenant_billing_address(tenant_id),
            payment_terms="Net 30",
            notes=None
        )
        
        # Store invoice
        self._store_invoice(invoice)
        
        return invoice
    
    async def _calculate_pay_as_you_go(self,
                                     usage_data: List[Dict[str, Any]],
                                     pricing_plan: TenantPricingPlan,
                                     billing_period: str) -> List[InvoiceLineItem]:
        """Calculate pay-as-you-go billing"""
        
        line_items = []
        
        for usage_item in usage_data:
            resource_type = usage_item.get('resource_type', 'unknown')
            quantity = usage_item.get('quantity', 0)
            
            # Get unit price (custom rate or default)
            unit_price = pricing_plan.custom_rates.get(resource_type, 0.01)  # Default $0.01/unit
            
            # Apply discounts
            discount_percentage = pricing_plan.discounts.get(resource_type, 0.0)
            discount_amount = (unit_price * quantity) * (discount_percentage / 100.0)
            
            # Calculate tax
            tax_rate = self.tax_rates.get(pricing_plan.currency, 0.0)
            tax_amount = (unit_price * quantity - discount_amount) * tax_rate
            
            # Calculate total
            total_amount = (unit_price * quantity) - discount_amount + tax_amount
            
            line_item = InvoiceLineItem(
                line_item_id=f"line_{uuid.uuid4().hex[:8]}",
                invoice_id="",  # Will be set when invoice is created
                resource_type=resource_type,
                resource_id=usage_item.get('resource_id', 'unknown'),
                description=f"{resource_type} usage - {quantity} units",
                quantity=quantity,
                unit_price=unit_price,
                discount_amount=discount_amount,
                tax_amount=tax_amount,
                total_amount=total_amount,
                currency=pricing_plan.currency,
                period_start=usage_item.get('period_start', datetime.utcnow()),
                period_end=usage_item.get('period_end', datetime.utcnow()),
                metadata={
                    'pricing_model': 'pay_as_you_go',
                    'usage_data': usage_item
                }
            )
            
            line_items.append(line_item)
        
        return line_items
    
    async def _calculate_tiered_volume(self,
                                     usage_data: List[Dict[str, Any]],
                                     pricing_plan: TenantPricingPlan,
                                     billing_period: str) -> List[InvoiceLineItem]:
        """Calculate tiered volume billing"""
        
        line_items = []
        
        # Group usage by resource type
        usage_by_resource = defaultdict(lambda: {'quantity': 0, 'items': []})
        for usage_item in usage_data:
            resource_type = usage_item.get('resource_type', 'unknown')
            quantity = usage_item.get('quantity', 0)
            usage_by_resource[resource_type]['quantity'] += quantity
            usage_by_resource[resource_type]['items'].append(usage_item)
        
        # Calculate pricing for each resource type
        for resource_type, usage_info in usage_by_resource.items():
            total_quantity = usage_info['quantity']
            
            # Find applicable pricing tier
            applicable_tier = self._find_pricing_tier(pricing_plan.pricing_tiers, total_quantity)
            
            if not applicable_tier:
                # Use default pricing
                unit_price = pricing_plan.custom_rates.get(resource_type, 0.01)
            else:
                unit_price = applicable_tier.unit_price
            
            # Calculate discounts
            discount_percentage = applicable_tier.discount_percentage if applicable_tier else 0.0
            discount_amount = (unit_price * total_quantity) * (discount_percentage / 100.0)
            
            # Calculate tax
            tax_rate = self.tax_rates.get(pricing_plan.currency, 0.0)
            tax_amount = (unit_price * total_quantity - discount_amount) * tax_rate
            
            # Calculate total
            total_amount = (unit_price * total_quantity) - discount_amount + tax_amount
            
            line_item = InvoiceLineItem(
                line_item_id=f"line_{uuid.uuid4().hex[:8]}",
                invoice_id="",
                resource_type=resource_type,
                resource_id=f"volume_{resource_type}",
                description=f"{resource_type} volume usage - {total_quantity} units (Tier: {applicable_tier.tier_name if applicable_tier else 'Default'})",
                quantity=total_quantity,
                unit_price=unit_price,
                discount_amount=discount_amount,
                tax_amount=tax_amount,
                total_amount=total_amount,
                currency=pricing_plan.currency,
                period_start=datetime.utcnow(),
                period_end=datetime.utcnow(),
                metadata={
                    'pricing_model': 'tiered_volume',
                    'tier_applied': applicable_tier.tier_name if applicable_tier else 'default',
                    'usage_items': usage_info['items']
                }
            )
            
            line_items.append(line_item)
        
        return line_items
    
    async def _calculate_commitment_based(self,
                                        usage_data: List[Dict[str, Any]],
                                        pricing_plan: TenantPricingPlan,
                                        billing_period: str) -> List[InvoiceLineItem]:
        """Calculate commitment-based billing"""
        
        line_items = []
        
        # Get active commitments for billing period
        active_commitments = self._get_active_commitments(pricing_plan.tenant_id, billing_period)
        
        # Calculate usage by resource type
        usage_by_resource = defaultdict(float)
        for usage_item in usage_data:
            resource_type = usage_item.get('resource_type', 'unknown')
            quantity = usage_item.get('quantity', 0)
            usage_by_resource[resource_type] += quantity
        
        # Process each commitment
        for commitment in active_commitments:
            commitment_usage = usage_by_resource.get(commitment.commitment_unit, 0)
            
            # Calculate commitment fee (base commitment amount)
            commitment_fee = commitment.commitment_amount
            
            # Calculate overage
            overage_quantity = max(0, commitment_usage - commitment.commitment_amount)
            overage_cost = overage_quantity * commitment.overage_rate
            
            # Total for this commitment
            total_commitment_cost = commitment_fee + overage_cost
            
            # Calculate tax
            tax_rate = self.tax_rates.get(pricing_plan.currency, 0.0)
            tax_amount = total_commitment_cost * tax_rate
            
            line_item = InvoiceLineItem(
                line_item_id=f"line_{uuid.uuid4().hex[:8]}",
                invoice_id="",
                resource_type="commitment",
                resource_id=commitment.contract_id,
                description=f"Commitment: {commitment.commitment_type} - {commitment.commitment_amount} {commitment.commitment_unit}",
                quantity=commitment_amount,
                unit_price=commitment.commitment_amount / commitment.commitment_amount if commitment.commitment_amount > 0 else 0,
                discount_amount=0.0,
                tax_amount=tax_amount,
                total_amount=total_commitment_cost + tax_amount,
                currency=pricing_plan.currency,
                period_start=commitment.start_date,
                period_end=commitment.end_date,
                metadata={
                    'pricing_model': 'commitment_based',
                    'commitment_id': commitment.contract_id,
                    'commitment_usage': commitment_usage,
                    'overage_quantity': overage_quantity,
                    'overage_cost': overage_cost
                }
            )
            
            line_items.append(line_item)
        
        return line_items
    
    async def _calculate_spend_based(self,
                                   usage_data: List[Dict[str, Any]],
                                   pricing_plan: TenantPricingPlan,
                                   billing_period: str) -> List[InvoiceLineItem]:
        """Calculate spend-based billing with discounts based on total spend"""
        
        line_items = []
        
        # Calculate total spend
        total_spend = 0.0
        for usage_item in usage_data:
            resource_type = usage_item.get('resource_type', 'unknown')
            quantity = usage_item.get('quantity', 0)
            unit_price = pricing_plan.custom_rates.get(resource_type, 0.01)
            total_spend += unit_price * quantity
        
        # Apply spend-based discounts
        spend_discount = self._calculate_spend_discount(total_spend, pricing_plan.discounts)
        
        # Create line items
        for usage_item in usage_data:
            resource_type = usage_item.get('resource_type', 'unknown')
            quantity = usage_item.get('quantity', 0)
            unit_price = pricing_plan.custom_rates.get(resource_type, 0.01)
            
            # Apply spend discount proportionally
            item_discount = (unit_price * quantity) * (spend_discount / 100.0)
            
            # Calculate tax
            tax_rate = self.tax_rates.get(pricing_plan.currency, 0.0)
            tax_amount = (unit_price * quantity - item_discount) * tax_rate
            
            # Calculate total
            total_amount = (unit_price * quantity) - item_discount + tax_amount
            
            line_item = InvoiceLineItem(
                line_item_id=f"line_{uuid.uuid4().hex[:8]}",
                invoice_id="",
                resource_type=resource_type,
                resource_id=usage_item.get('resource_id', 'unknown'),
                description=f"{resource_type} usage - {quantity} units (Spend discount applied)",
                quantity=quantity,
                unit_price=unit_price,
                discount_amount=item_discount,
                tax_amount=tax_amount,
                total_amount=total_amount,
                currency=pricing_plan.currency,
                period_start=usage_item.get('period_start', datetime.utcnow()),
                period_end=usage_item.get('period_end', datetime.utcnow()),
                metadata={
                    'pricing_model': 'spend_based',
                    'total_spend': total_spend,
                    'spend_discount_applied': spend_discount
                }
            )
            
            line_items.append(line_item)
        
        return line_items
    
    async def _calculate_hybrid(self,
                              usage_data: List[Dict[str, Any]],
                              pricing_plan: TenantPricingPlan,
                              billing_period: str) -> List[InvoiceLineItem]:
        """Calculate hybrid billing (combination of multiple models)"""
        
        line_items = []
        
        # For hybrid, we combine commitment-based with pay-as-you-go for overages
        commitment_items = await self._calculate_commitment_based(usage_data, pricing_plan, billing_period)
        payg_items = await self._calculate_pay_as_you_go(usage_data, pricing_plan, billing_period)
        
        # Combine and deduplicate
        line_items.extend(commitment_items)
        
        # Add pay-as-you-go for items not covered by commitments
        covered_resources = set()
        for item in commitment_items:
            if item.resource_type != "commitment":
                covered_resources.add(item.resource_type)
        
        for item in payg_items:
            if item.resource_type not in covered_resources:
                item.metadata['pricing_model'] = 'hybrid_payg'
                line_items.append(item)
        
        return line_items
    
    def _find_pricing_tier(self, tiers: List[PricingTier], quantity: float) -> Optional[PricingTier]:
        """Find applicable pricing tier for quantity"""
        
        applicable_tier = None
        
        for tier in tiers:
            if quantity >= tier.min_quantity:
                if tier.max_quantity is None or quantity <= tier.max_quantity:
                    applicable_tier = tier
                elif applicable_tier is None or tier.min_quantity > applicable_tier.min_quantity:
                    applicable_tier = tier
        
        return applicable_tier
    
    def _calculate_spend_discount(self, total_spend: float, discounts: Dict[str, float]) -> float:
        """Calculate spend-based discount percentage"""
        
        discount_percentage = 0.0
        
        # Check spend thresholds
        if total_spend >= 10000:  # $10,000+
            discount_percentage = max(discount_percentage, discounts.get('spend_10k', 0.0))
        if total_spend >= 50000:  # $50,000+
            discount_percentage = max(discount_percentage, discounts.get('spend_50k', 0.0))
        if total_spend >= 100000:  # $100,000+
            discount_percentage = max(discount_percentage, discounts.get('spend_100k', 0.0))
        if total_spend >= 500000:  # $500,000+
            discount_percentage = max(discount_percentage, discounts.get('spend_500k', 0.0))
        
        return discount_percentage
    
    def _get_active_pricing_plan(self, tenant_id: str) -> Optional[TenantPricingPlan]:
        """Get active pricing plan for tenant"""
        
        for plan in self.pricing_plans.values():
            if plan.tenant_id == tenant_id and plan.active:
                return plan
        
        # Try to load from database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM tenant_pricing_plans 
                WHERE tenant_id = ? AND active = TRUE
                ORDER BY created_at DESC
                LIMIT 1
            ''', (tenant_id,))
            
            row = cursor.fetchone()
            if row:
                # Reconstruct pricing plan
                pricing_tiers = []
                if row[5]:  # pricing_tiers
                    tiers_data = json.loads(row[5])
                    pricing_tiers = [PricingTier(**tier) for tier in tiers_data]
                
                commitments = []
                if row[6]:  # commitments
                    commitments_data = json.loads(row[6])
                    commitments = [CommitmentContract(**commit) for commit in commitments_data]
                
                plan = TenantPricingPlan(
                    plan_id=row[0],
                    tenant_id=row[1],
                    pricing_model=PricingModel(row[2]),
                    billing_cycle=BillingCycle(row[3]),
                    currency=row[4],
                    pricing_tiers=pricing_tiers,
                    commitments=commitments,
                    custom_rates=json.loads(row[7]) if row[7] else {},
                    discounts=json.loads(row[8]) if row[8] else {},
                    billing_rules=json.loads(row[9]) if row[9] else {},
                    created_at=datetime.fromisoformat(row[10]),
                    active=row[11]
                )
                
                self.pricing_plans[plan.plan_id] = plan
                return plan
        
        return None
    
    def _get_active_commitments(self, tenant_id: str, billing_period: str) -> List[CommitmentContract]:
        """Get active commitments for tenant and billing period"""
        
        # Parse billing period to get date range
        year, month = billing_period.split('-')
        period_start = datetime(int(year), int(month), 1)
        if month == '12':
            period_end = datetime(int(year) + 1, 1, 1) - timedelta(days=1)
        else:
            period_end = datetime(int(year), int(month) + 1, 1) - timedelta(days=1)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM commitment_contracts 
                WHERE tenant_id = ? AND active = TRUE
                AND start_date <= ? AND end_date >= ?
            ''', (tenant_id, period_end, period_start))
            
            commitments = []
            for row in cursor.fetchall():
                commitment = CommitmentContract(
                    contract_id=row[0],
                    tenant_id=row[1],
                    commitment_type=row[2],
                    commitment_amount=row[3],
                    commitment_unit=row[4],
                    billing_period=row[5],
                    start_date=datetime.fromisoformat(row[6]),
                    end_date=datetime.fromisoformat(row[7]),
                    overage_rate=row[8],
                    currency=row[9],
                    active=row[10]
                )
                commitments.append(commitment)
            
            return commitments
    
    def _get_tenant_billing_address(self, tenant_id: str) -> Dict[str, str]:
        """Get tenant billing address"""
        
        # This would typically come from tenant management system
        return {
            'company_name': f'Tenant {tenant_id}',
            'address_line_1': '123 Billing Street',
            'city': 'San Francisco',
            'state': 'CA',
            'postal_code': '94105',
            'country': 'US',
            'email': f'billing@tenant{tenant_id}.com'
        }
    
    def _store_invoice(self, invoice: TenantInvoice):
        """Store invoice in database"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Store main invoice
            cursor.execute('''
                INSERT INTO tenant_invoices 
                (invoice_id, tenant_id, invoice_number, billing_period, status,
                 currency, subtotal, discount_total, tax_total, total_amount,
                 due_date, created_at, billing_address, payment_terms, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                invoice.invoice_id, invoice.tenant_id, invoice.invoice_number,
                invoice.billing_period, invoice.status.value, invoice.currency,
                invoice.subtotal, invoice.discount_total, invoice.tax_total,
                invoice.total_amount, invoice.due_date, invoice.created_at,
                json.dumps(invoice.billing_address), invoice.payment_terms, invoice.notes
            ))
            
            # Store line items
            for line_item in invoice.line_items:
                line_item.invoice_id = invoice.invoice_id  # Set invoice ID
                cursor.execute('''
                    INSERT INTO invoice_line_items 
                    (line_item_id, invoice_id, resource_type, resource_id, description,
                     quantity, unit_price, discount_amount, tax_amount, total_amount,
                     currency, period_start, period_end, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    line_item.line_item_id, line_item.invoice_id, line_item.resource_type,
                    line_item.resource_id, line_item.description, line_item.quantity,
                    line_item.unit_price, line_item.discount_amount, line_item.tax_amount,
                    line_item.total_amount, line_item.currency, line_item.period_start,
                    line_item.period_end, json.dumps(line_item.metadata)
                ))
            
            conn.commit()
    
    def get_tenant_invoice(self, invoice_id: str) -> Optional[Dict[str, Any]]:
        """Get tenant invoice details"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get invoice
            cursor.execute('''
                SELECT * FROM tenant_invoices WHERE invoice_id = ?
            ''', (invoice_id,))
            
            invoice_row = cursor.fetchone()
            if not invoice_row:
                return None
            
            # Get line items
            cursor.execute('''
                SELECT * FROM invoice_line_items WHERE invoice_id = ?
            ''', (invoice_id,))
            
            line_items_rows = cursor.fetchall()
            
            # Build invoice data
            invoice_data = {
                'invoice_id': invoice_row[0],
                'tenant_id': invoice_row[1],
                'invoice_number': invoice_row[2],
                'billing_period': invoice_row[3],
                'status': invoice_row[4],
                'currency': invoice_row[5],
                'subtotal': invoice_row[6],
                'discount_total': invoice_row[7],
                'tax_total': invoice_row[8],
                'total_amount': invoice_row[9],
                'due_date': invoice_row[10],
                'created_at': invoice_row[11],
                'sent_at': invoice_row[12],
                'paid_at': invoice_row[13],
                'billing_address': json.loads(invoice_row[14]) if invoice_row[14] else {},
                'payment_terms': invoice_row[15],
                'notes': invoice_row[16],
                'line_items': []
            }
            
            for line_row in line_items_rows:
                line_item = {
                    'line_item_id': line_row[0],
                    'resource_type': line_row[2],
                    'resource_id': line_row[3],
                    'description': line_row[4],
                    'quantity': line_row[5],
                    'unit_price': line_row[6],
                    'discount_amount': line_row[7],
                    'tax_amount': line_row[8],
                    'total_amount': line_row[9],
                    'currency': line_row[10],
                    'period_start': line_row[11],
                    'period_end': line_row[12],
                    'metadata': json.loads(line_row[13]) if line_row[13] else {}
                }
                invoice_data['line_items'].append(line_item)
            
            return invoice_data

# Example usage
async def main():
    """Example of tenant billing"""
    
    billing_engine = TenantBillingEngine()
    
    # Create pricing plan with tiered volume pricing
    pricing_tiers = [
        PricingTier(
            tier_id="tier_1",
            tier_name="Basic",
            min_quantity=0,
            max_quantity=1000,
            unit_price=0.02,
            currency="USD"
        ),
        PricingTier(
            tier_id="tier_2", 
            tier_name="Professional",
            min_quantity=1001,
            max_quantity=10000,
            unit_price=0.015,
            currency="USD",
            discount_percentage=10.0
        ),
        PricingTier(
            tier_id="tier_3",
            tier_name="Enterprise",
            min_quantity=10001,
            max_quantity=None,
            unit_price=0.01,
            currency="USD",
            discount_percentage=20.0
        )
    ]
    
    plan_id = billing_engine.create_pricing_plan(
        tenant_id="tenant_123",
        pricing_model=PricingModel.TIERED_VOLUME,
        billing_cycle=BillingCycle.MONTHLY,
        pricing_tiers=pricing_tiers,
        custom_rates={
            'gpu_compute': 0.025,
            'storage': 0.001,
            'network': 0.005
        }
    )
    
    # Generate invoice for usage
    usage_data = [
        {'resource_type': 'gpu_compute', 'resource_id': 'gpu-1', 'quantity': 1500},
        {'resource_type': 'storage', 'resource_id': 'storage-1', 'quantity': 5000},
        {'resource_type': 'network', 'resource_id': 'network-1', 'quantity': 2000}
    ]
    
    invoice = await billing_engine.generate_tenant_invoice(
        tenant_id="tenant_123",
        billing_period="2026-02",
        usage_data=usage_data
    )
    
    logging.info(f"Generated invoice: {invoice.invoice_number}")
    logging.info(f"Total amount: ${invoice.total_amount:.2f}")
    logging.info(f"Line items: {len(invoice.line_items)

if __name__ == "__main__":
    asyncio.run(main())
