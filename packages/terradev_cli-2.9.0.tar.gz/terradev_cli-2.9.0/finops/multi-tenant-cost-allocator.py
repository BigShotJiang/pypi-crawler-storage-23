import logging

#!/usr/bin/env python3
"""
Terradev Multi-Tenant Cost Allocator
Automated cost allocation for departments, projects, customers with complex multi-tenant scenarios
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Set, Tuple
from enum import Enum
import sqlite3
from contextlib import asynccontextmanager
import uuid
import math
from collections import defaultdict

class TenantType(Enum):
    ENTERPRISE = "enterprise"
    SMB = "smb"
    STARTUP = "startup"
    INDIVIDUAL = "individual"
    INTERNAL = "internal"

class AllocationMethod(Enum):
    FIXED = "fixed"  # Fixed percentage allocation
    USAGE_BASED = "usage_based"  # Based on actual usage metrics
    TIME_BASED = "time_based"  # Based on time allocation
    PRIORITY_BASED = "priority_based"  # Priority-weighted allocation
    HYBRID = "hybrid"  # Combination of methods

class CostCategory(Enum):
    COMPUTE = "compute"
    STORAGE = "storage"
    NETWORK = "network"
    LICENSE = "license"
    SUPPORT = "support"
    OVERHEAD = "overhead"

@dataclass
class Tenant:
    """Multi-tenant customer definition"""
    tenant_id: str
    tenant_name: str
    tenant_type: TenantType
    parent_tenant_id: Optional[str]  # For hierarchical tenants
    billing_contact: str
    technical_contact: str
    cost_allocation_method: AllocationMethod
    allocation_rules: Dict[str, Any]
    billing_cycle: str  # monthly, quarterly, annual
    currency: str
    cost_centers: List[str]  # Associated cost centers
    custom_tags: Dict[str, str]
    created_at: datetime
    active: bool

@dataclass
class CostAllocationRule:
    """Rule for allocating costs to tenants"""
    rule_id: str
    tenant_id: str
    cost_category: CostCategory
    allocation_method: AllocationMethod
    allocation_percentage: Optional[float]
    allocation_basis: Optional[str]  # Usage metric for allocation
    priority_weight: Optional[float]
    conditions: Dict[str, Any]  # Conditions for rule application
    effective_start: datetime
    effective_end: Optional[datetime]
    created_at: datetime

@dataclass
class TenantCostAllocation:
    """Individual cost allocation to tenant"""
    allocation_id: str
    tenant_id: str
    billing_period: str
    cost_category: CostCategory
    provider: str
    resource_id: str
    total_cost: float
    allocated_cost: float
    allocation_percentage: float
    allocation_basis_value: float
    allocation_method: AllocationMethod
    rule_id: str
    currency: str
    period_start: datetime
    period_end: datetime
    metadata: Dict[str, Any]

@dataclass
class MultiTenantAllocation:
    """Complete multi-tenant allocation for billing period"""
    allocation_id: str
    billing_period: str
    period_start: datetime
    period_end: datetime
    total_cost: float
    currency: str
    tenant_allocations: List[TenantCostAllocation]
    unallocated_cost: float
    allocation_summary: Dict[str, Any]
    generated_at: datetime

class MultiTenantCostAllocator:
    """Advanced multi-tenant cost allocation engine"""
    
    def __init__(self, db_path: str = "multi_tenant_allocator.db"):
        self.db_path = db_path
        self.tenants: Dict[str, Tenant] = {}
        self.allocation_rules: Dict[str, CostAllocationRule] = {}
        self.usage_metrics: Dict[str, Dict[str, float]] = {}
        self._init_database()
        
    def _init_database(self):
        """Initialize SQLite database for multi-tenant allocation"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Tenants table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tenants (
                    tenant_id TEXT PRIMARY KEY,
                    tenant_name TEXT NOT NULL,
                    tenant_type TEXT NOT NULL,
                    parent_tenant_id TEXT,
                    billing_contact TEXT,
                    technical_contact TEXT,
                    cost_allocation_method TEXT NOT NULL,
                    allocation_rules TEXT,  -- JSON
                    billing_cycle TEXT,
                    currency TEXT DEFAULT 'USD',
                    cost_centers TEXT,  -- JSON array
                    custom_tags TEXT,  -- JSON object
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    active BOOLEAN DEFAULT TRUE
                )
            ''')
            
            # Cost allocation rules table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cost_allocation_rules (
                    rule_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    cost_category TEXT NOT NULL,
                    allocation_method TEXT NOT NULL,
                    allocation_percentage REAL,
                    allocation_basis TEXT,
                    priority_weight REAL,
                    conditions TEXT,  -- JSON object
                    effective_start TIMESTAMP NOT NULL,
                    effective_end TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (tenant_id) REFERENCES tenants (tenant_id)
                )
            ''')
            
            # Tenant cost allocations table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tenant_cost_allocations (
                    allocation_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    billing_period TEXT NOT NULL,
                    cost_category TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    resource_id TEXT NOT NULL,
                    total_cost REAL NOT NULL,
                    allocated_cost REAL NOT NULL,
                    allocation_percentage REAL NOT NULL,
                    allocation_basis_value REAL,
                    allocation_method TEXT NOT NULL,
                    rule_id TEXT NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    period_start TIMESTAMP NOT NULL,
                    period_end TIMESTAMP NOT NULL,
                    metadata TEXT,  -- JSON object
                    FOREIGN KEY (tenant_id) REFERENCES tenants (tenant_id),
                    FOREIGN KEY (rule_id) REFERENCES cost_allocation_rules (rule_id)
                )
            ''')
            
            # Multi-tenant allocations table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS multi_tenant_allocations (
                    allocation_id TEXT PRIMARY KEY,
                    billing_period TEXT NOT NULL,
                    period_start TIMESTAMP NOT NULL,
                    period_end TIMESTAMP NOT NULL,
                    total_cost REAL NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    unallocated_cost REAL DEFAULT 0.0,
                    allocation_summary TEXT,  -- JSON object
                    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Usage metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS usage_metrics (
                    metric_id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    metric_name TEXT NOT NULL,
                    metric_value REAL NOT NULL,
                    metric_unit TEXT,
                    period_start TIMESTAMP NOT NULL,
                    period_end TIMESTAMP NOT NULL,
                    provider TEXT,
                    resource_id TEXT,
                    metadata TEXT,  -- JSON object
                    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (tenant_id) REFERENCES tenants (tenant_id)
                )
            ''')
            
            conn.commit()
    
    def create_tenant(self,
                     tenant_name: str,
                     tenant_type: TenantType,
                     parent_tenant_id: Optional[str] = None,
                     billing_contact: str = "",
                     technical_contact: str = "",
                     cost_allocation_method: AllocationMethod = AllocationMethod.USAGE_BASED,
                     allocation_rules: Dict[str, Any] = None,
                     billing_cycle: str = "monthly",
                     currency: str = "USD",
                     cost_centers: List[str] = None,
                     custom_tags: Dict[str, str] = None) -> str:
        """Create a new tenant"""
        
        tenant_id = f"tenant_{uuid.uuid4().hex[:8]}"
        
        tenant = Tenant(
            tenant_id=tenant_id,
            tenant_name=tenant_name,
            tenant_type=tenant_type,
            parent_tenant_id=parent_tenant_id,
            billing_contact=billing_contact,
            technical_contact=technical_contact,
            cost_allocation_method=cost_allocation_method,
            allocation_rules=allocation_rules or {},
            billing_cycle=billing_cycle,
            currency=currency,
            cost_centers=cost_centers or [],
            custom_tags=custom_tags or {},
            created_at=datetime.utcnow(),
            active=True
        )
        
        # Store in memory
        self.tenants[tenant_id] = tenant
        
        # Store in database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO tenants 
                (tenant_id, tenant_name, tenant_type, parent_tenant_id, billing_contact,
                 technical_contact, cost_allocation_method, allocation_rules, billing_cycle,
                 currency, cost_centers, custom_tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                tenant_id, tenant_name, tenant_type.value, parent_tenant_id, billing_contact,
                technical_contact, cost_allocation_method.value, json.dumps(allocation_rules),
                billing_cycle, currency, json.dumps(cost_centers), json.dumps(custom_tags)
            ))
            conn.commit()
        
        return tenant_id
    
    def create_allocation_rule(self,
                             tenant_id: str,
                             cost_category: CostCategory,
                             allocation_method: AllocationMethod,
                             allocation_percentage: Optional[float] = None,
                             allocation_basis: Optional[str] = None,
                             priority_weight: Optional[float] = None,
                             conditions: Dict[str, Any] = None,
                             effective_start: Optional[datetime] = None,
                             effective_end: Optional[datetime] = None) -> str:
        """Create cost allocation rule for tenant"""
        
        if tenant_id not in self.tenants:
            raise ValueError(f"Tenant {tenant_id} not found")
        
        rule_id = f"rule_{uuid.uuid4().hex[:8]}"
        
        rule = CostAllocationRule(
            rule_id=rule_id,
            tenant_id=tenant_id,
            cost_category=cost_category,
            allocation_method=allocation_method,
            allocation_percentage=allocation_percentage,
            allocation_basis=allocation_basis,
            priority_weight=priority_weight,
            conditions=conditions or {},
            effective_start=effective_start or datetime.utcnow(),
            effective_end=effective_end,
            created_at=datetime.utcnow()
        )
        
        # Store in memory
        self.allocation_rules[rule_id] = rule
        
        # Store in database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO cost_allocation_rules 
                (rule_id, tenant_id, cost_category, allocation_method, allocation_percentage,
                 allocation_basis, priority_weight, conditions, effective_start, effective_end)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                rule_id, tenant_id, cost_category.value, allocation_method.value,
                allocation_percentage, allocation_basis, priority_weight, json.dumps(conditions),
                rule.effective_start, effective_end
            ))
            conn.commit()
        
        return rule_id
    
    def record_usage_metric(self,
                          tenant_id: str,
                          metric_name: str,
                          metric_value: float,
                          metric_unit: str,
                          period_start: datetime,
                          period_end: datetime,
                          provider: Optional[str] = None,
                          resource_id: Optional[str] = None,
                          metadata: Dict[str, Any] = None) -> str:
        """Record usage metric for allocation basis"""
        
        metric_id = f"metric_{uuid.uuid4().hex[:8]}"
        
        # Store in memory
        if tenant_id not in self.usage_metrics:
            self.usage_metrics[tenant_id] = {}
        
        self.usage_metrics[tenant_id][metric_name] = metric_value
        
        # Store in database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO usage_metrics 
                (metric_id, tenant_id, metric_name, metric_value, metric_unit,
                 period_start, period_end, provider, resource_id, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                metric_id, tenant_id, metric_name, metric_value, metric_unit,
                period_start, period_end, provider, resource_id, json.dumps(metadata)
            ))
            conn.commit()
        
        return metric_id
    
    async def allocate_costs_to_tenants(self,
                                      billing_period: str,
                                      period_start: datetime,
                                      period_end: datetime,
                                      cost_data: List[Dict[str, Any]]) -> MultiTenantAllocation:
        """Allocate costs to tenants based on rules and usage metrics"""
        
        allocation_id = f"alloc_{uuid.uuid4().hex[:8]}"
        total_cost = sum(item['cost'] for item in cost_data)
        
        # Group costs by category and provider
        cost_groups = defaultdict(list)
        for item in cost_data:
            key = f"{item.get('category', 'compute')}:{item.get('provider', 'unknown')}"
            cost_groups[key].append(item)
        
        tenant_allocations = []
        unallocated_cost = 0.0
        
        # Process each cost group
        for cost_group_key, group_items in cost_groups.items():
            category, provider = cost_group_key.split(':')
            group_total_cost = sum(item['cost'] for item in group_items)
            
            # Find applicable allocation rules
            applicable_rules = self._find_applicable_rules(category, period_start, period_end)
            
            if not applicable_rules:
                unallocated_cost += group_total_cost
                continue
            
            # Allocate costs based on rules
            group_allocations = await self._allocate_cost_group(
                group_items, applicable_rules, period_start, period_end
            )
            
            tenant_allocations.extend(group_allocations)
        
        # Create allocation summary
        allocation_summary = self._generate_allocation_summary(tenant_allocations, total_cost)
        
        # Create multi-tenant allocation
        multi_tenant_allocation = MultiTenantAllocation(
            allocation_id=allocation_id,
            billing_period=billing_period,
            period_start=period_start,
            period_end=period_end,
            total_cost=total_cost,
            currency="USD",
            tenant_allocations=tenant_allocations,
            unallocated_cost=unallocated_cost,
            allocation_summary=allocation_summary,
            generated_at=datetime.utcnow()
        )
        
        # Store allocation
        self._store_multi_tenant_allocation(multi_tenant_allocation)
        
        return multi_tenant_allocation
    
    def _find_applicable_rules(self, 
                             cost_category: str, 
                             period_start: datetime, 
                             period_end: datetime) -> List[CostAllocationRule]:
        """Find allocation rules applicable to cost category and period"""
        
        applicable_rules = []
        
        for rule in self.allocation_rules.values():
            # Check cost category
            if rule.cost_category.value != cost_category:
                continue
            
            # Check effective period
            if rule.effective_start > period_end:
                continue
            if rule.effective_end and rule.effective_end < period_start:
                continue
            
            applicable_rules.append(rule)
        
        return applicable_rules
    
    async def _allocate_cost_group(self,
                                 cost_items: List[Dict[str, Any]],
                                 rules: List[CostAllocationRule],
                                 period_start: datetime,
                                 period_end: datetime) -> List[TenantCostAllocation]:
        """Allocate a group of costs to tenants based on rules"""
        
        allocations = []
        total_cost = sum(item['cost'] for item in cost_items)
        
        # Group rules by allocation method
        rules_by_method = defaultdict(list)
        for rule in rules:
            rules_by_method[rule.allocation_method].append(rule)
        
        # Process each allocation method
        for method, method_rules in rules_by_method.items():
            if method == AllocationMethod.FIXED:
                method_allocations = self._allocate_fixed_percentage(
                    cost_items, method_rules, total_cost, period_start, period_end
                )
            elif method == AllocationMethod.USAGE_BASED:
                method_allocations = await self._allocate_usage_based(
                    cost_items, method_rules, total_cost, period_start, period_end
                )
            elif method == AllocationMethod.PRIORITY_BASED:
                method_allocations = self._allocate_priority_based(
                    cost_items, method_rules, total_cost, period_start, period_end
                )
            elif method == AllocationMethod.HYBRID:
                method_allocations = await self._allocate_hybrid(
                    cost_items, method_rules, total_cost, period_start, period_end
                )
            else:
                continue
            
            allocations.extend(method_allocations)
        
        return allocations
    
    def _allocate_fixed_percentage(self,
                                 cost_items: List[Dict[str, Any]],
                                 rules: List[CostAllocationRule],
                                 total_cost: float,
                                 period_start: datetime,
                                 period_end: datetime) -> List[TenantCostAllocation]:
        """Allocate costs based on fixed percentages"""
        
        allocations = []
        
        for rule in rules:
            if not rule.allocation_percentage:
                continue
            
            allocated_cost = total_cost * (rule.allocation_percentage / 100.0)
            
            for item in cost_items:
                item_allocated_cost = item['cost'] * (rule.allocation_percentage / 100.0)
                
                allocation = TenantCostAllocation(
                    allocation_id=f"alloc_{uuid.uuid4().hex[:8]}",
                    tenant_id=rule.tenant_id,
                    billing_period=self._get_billing_period(period_start),
                    cost_category=rule.cost_category,
                    provider=item.get('provider', 'unknown'),
                    resource_id=item.get('resource_id', 'unknown'),
                    total_cost=item['cost'],
                    allocated_cost=item_allocated_cost,
                    allocation_percentage=rule.allocation_percentage,
                    allocation_basis_value=0.0,
                    allocation_method=rule.allocation_method,
                    rule_id=rule.rule_id,
                    currency="USD",
                    period_start=period_start,
                    period_end=period_end,
                    metadata={
                        'allocation_type': 'fixed_percentage',
                        'rule_name': f"{rule.tenant_id}_{rule.cost_category.value}"
                    }
                )
                
                allocations.append(allocation)
        
        return allocations
    
    async def _allocate_usage_based(self,
                                   cost_items: List[Dict[str, Any]],
                                   rules: List[CostAllocationRule],
                                   total_cost: float,
                                   period_start: datetime,
                                   period_end: datetime) -> List[TenantCostAllocation]:
        """Allocate costs based on usage metrics"""
        
        allocations = []
        
        # Collect usage metrics for all tenants with usage-based rules
        tenant_usage = {}
        total_usage = 0.0
        
        for rule in rules:
            if not rule.allocation_basis:
                continue
            
            tenant_id = rule.tenant_id
            usage_metric = self.usage_metrics.get(tenant_id, {}).get(rule.allocation_basis, 0.0)
            tenant_usage[tenant_id] = usage_metric
            total_usage += usage_metric
        
        if total_usage == 0:
            return allocations
        
        # Allocate based on usage proportions
        for rule in rules:
            if not rule.allocation_basis:
                continue
            
            tenant_id = rule.tenant_id
            usage_value = tenant_usage.get(tenant_id, 0.0)
            usage_percentage = (usage_value / total_usage) * 100.0
            
            for item in cost_items:
                item_allocated_cost = item['cost'] * (usage_percentage / 100.0)
                
                allocation = TenantCostAllocation(
                    allocation_id=f"alloc_{uuid.uuid4().hex[:8]}",
                    tenant_id=tenant_id,
                    billing_period=self._get_billing_period(period_start),
                    cost_category=rule.cost_category,
                    provider=item.get('provider', 'unknown'),
                    resource_id=item.get('resource_id', 'unknown'),
                    total_cost=item['cost'],
                    allocated_cost=item_allocated_cost,
                    allocation_percentage=usage_percentage,
                    allocation_basis_value=usage_value,
                    allocation_method=rule.allocation_method,
                    rule_id=rule.rule_id,
                    currency="USD",
                    period_start=period_start,
                    period_end=period_end,
                    metadata={
                        'allocation_type': 'usage_based',
                        'usage_metric': rule.allocation_basis,
                        'usage_value': usage_value,
                        'total_usage': total_usage
                    }
                )
                
                allocations.append(allocation)
        
        return allocations
    
    def _allocate_priority_based(self,
                                cost_items: List[Dict[str, Any]],
                                rules: List[CostAllocationRule],
                                total_cost: float,
                                period_start: datetime,
                                period_end: datetime) -> List[TenantCostAllocation]:
        """Allocate costs based on priority weights"""
        
        allocations = []
        
        # Sort rules by priority (higher priority gets allocation first)
        sorted_rules = sorted(rules, key=lambda r: r.priority_weight or 0, reverse=True)
        
        remaining_cost = total_cost
        
        for i, rule in enumerate(sorted_rules):
            if remaining_cost <= 0:
                break
            
            # Calculate allocation based on priority
            if i == len(sorted_rules) - 1:
                # Last rule gets remaining cost
                allocation_percentage = (remaining_cost / total_cost) * 100.0
            else:
                # Allocate based on priority weight
                total_priority = sum(r.priority_weight or 1.0 for r in sorted_rules[i:])
                rule_priority = rule.priority_weight or 1.0
                allocation_percentage = (rule_priority / total_priority) * 100.0
                allocated_cost = total_cost * (allocation_percentage / 100.0)
                
                if allocated_cost > remaining_cost:
                    allocation_percentage = (remaining_cost / total_cost) * 100.0
            
            for item in cost_items:
                item_allocated_cost = item['cost'] * (allocation_percentage / 100.0)
                
                allocation = TenantCostAllocation(
                    allocation_id=f"alloc_{uuid.uuid4().hex[:8]}",
                    tenant_id=rule.tenant_id,
                    billing_period=self._get_billing_period(period_start),
                    cost_category=rule.cost_category,
                    provider=item.get('provider', 'unknown'),
                    resource_id=item.get('resource_id', 'unknown'),
                    total_cost=item['cost'],
                    allocated_cost=item_allocated_cost,
                    allocation_percentage=allocation_percentage,
                    allocation_basis_value=rule.priority_weight or 1.0,
                    allocation_method=rule.allocation_method,
                    rule_id=rule.rule_id,
                    currency="USD",
                    period_start=period_start,
                    period_end=period_end,
                    metadata={
                        'allocation_type': 'priority_based',
                        'priority_weight': rule.priority_weight,
                        'allocation_order': i + 1
                    }
                )
                
                allocations.append(allocation)
            
            remaining_cost -= total_cost * (allocation_percentage / 100.0)
        
        return allocations
    
    async def _allocate_hybrid(self,
                              cost_items: List[Dict[str, Any]],
                              rules: List[CostAllocationRule],
                              total_cost: float,
                              period_start: datetime,
                              period_end: datetime) -> List[TenantCostAllocation]:
        """Allocate costs using hybrid method (combination of multiple methods)"""
        
        allocations = []
        
        # For hybrid, we combine fixed percentage with usage-based
        # First allocate fixed portions, then allocate remaining based on usage
        
        fixed_rules = [r for r in rules if r.allocation_percentage is not None]
        usage_rules = [r for r in rules if r.allocation_basis is not None]
        
        # Allocate fixed portions first
        fixed_allocations = self._allocate_fixed_percentage(
            cost_items, fixed_rules, total_cost, period_start, period_end
        )
        allocations.extend(fixed_allocations)
        
        # Calculate remaining cost after fixed allocations
        total_fixed_allocation = sum(a.allocated_cost for a in fixed_allocations)
        remaining_cost = total_cost - total_fixed_allocation
        
        if remaining_cost > 0 and usage_rules:
            # Allocate remaining based on usage
            usage_allocations = await self._allocate_usage_based(
                cost_items, usage_rules, remaining_cost, period_start, period_end
            )
            allocations.extend(usage_allocations)
        
        return allocations
    
    def _get_billing_period(self, date: datetime) -> str:
        """Get billing period string from date"""
        return date.strftime("%Y-%m")
    
    def _generate_allocation_summary(self, 
                                   allocations: List[TenantCostAllocation],
                                   total_cost: float) -> Dict[str, Any]:
        """Generate summary of allocation results"""
        
        # Group allocations by tenant
        tenant_summary = defaultdict(lambda: {
            'total_allocated': 0.0,
            'by_category': defaultdict(float),
            'by_provider': defaultdict(float),
            'allocation_count': 0
        })
        
        for allocation in allocations:
            tenant_id = allocation.tenant_id
            tenant_summary[tenant_id]['total_allocated'] += allocation.allocated_cost
            tenant_summary[tenant_id]['by_category'][allocation.cost_category.value] += allocation.allocated_cost
            tenant_summary[tenant_id]['by_provider'][allocation.provider] += allocation.allocated_cost
            tenant_summary[tenant_id]['allocation_count'] += 1
        
        # Convert to regular dict
        summary = {
            'total_cost': total_cost,
            'total_allocated': sum(a.allocated_cost for a in allocations),
            'allocation_coverage': (sum(a.allocated_cost for a in allocations) / total_cost * 100) if total_cost > 0 else 0,
            'tenant_count': len(tenant_summary),
            'tenant_breakdown': dict(tenant_summary),
            'allocation_methods': list(set(a.allocation_method.value for a in allocations)),
            'cost_categories': list(set(a.cost_category.value for a in allocations)),
            'providers': list(set(a.provider for a in allocations))
        }
        
        return summary
    
    def _store_multi_tenant_allocation(self, allocation: MultiTenantAllocation):
        """Store multi-tenant allocation in database"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Store main allocation record
            cursor.execute('''
                INSERT INTO multi_tenant_allocations 
                (allocation_id, billing_period, period_start, period_end, total_cost,
                 currency, unallocated_cost, allocation_summary, generated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                allocation.allocation_id, allocation.billing_period,
                allocation.period_start, allocation.period_end, allocation.total_cost,
                allocation.currency, allocation.unallocated_cost,
                json.dumps(allocation.allocation_summary), allocation.generated_at
            ))
            
            # Store tenant allocations
            for tenant_alloc in allocation.tenant_allocations:
                cursor.execute('''
                    INSERT INTO tenant_cost_allocations 
                    (allocation_id, tenant_id, billing_period, cost_category, provider,
                     resource_id, total_cost, allocated_cost, allocation_percentage,
                     allocation_basis_value, allocation_method, rule_id, currency,
                     period_start, period_end, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    tenant_alloc.allocation_id, tenant_alloc.tenant_id,
                    tenant_alloc.billing_period, tenant_alloc.cost_category.value,
                    tenant_alloc.provider, tenant_alloc.resource_id, tenant_alloc.total_cost,
                    tenant_alloc.allocated_cost, tenant_alloc.allocation_percentage,
                    tenant_alloc.allocation_basis_value, tenant_alloc.allocation_method.value,
                    tenant_alloc.rule_id, tenant_alloc.currency, tenant_alloc.period_start,
                    tenant_alloc.period_end, json.dumps(tenant_alloc.metadata)
                ))
            
            conn.commit()
    
    def generate_tenant_invoice(self,
                              tenant_id: str,
                              billing_period: str) -> Dict[str, Any]:
        """Generate invoice data for specific tenant"""
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get tenant allocations for period
            cursor.execute('''
                SELECT * FROM tenant_cost_allocations 
                WHERE tenant_id = ? AND billing_period = ?
                ORDER BY cost_category, provider
            ''', (tenant_id, billing_period))
            
            rows = cursor.fetchall()
            
            if not rows:
                return {'error': f'No allocations found for tenant {tenant_id} in period {billing_period}'}
            
            # Get tenant information
            cursor.execute('SELECT * FROM tenants WHERE tenant_id = ?', (tenant_id,))
            tenant_row = cursor.fetchone()
            
            if not tenant_row:
                return {'error': f'Tenant {tenant_id} not found'}
            
            # Build invoice data
            invoice_data = {
                'invoice_id': f"inv_{tenant_id}_{billing_period}_{int(time.time())}",
                'tenant_id': tenant_id,
                'tenant_name': tenant_row[1],
                'tenant_type': tenant_row[2],
                'billing_period': billing_period,
                'currency': tenant_row[8],
                'billing_contact': tenant_row[4],
                'technical_contact': tenant_row[5],
                'generated_at': datetime.utcnow().isoformat(),
                'line_items': [],
                'summary': {
                    'total_amount': 0.0,
                    'total_allocations': len(rows),
                    'cost_categories': set(),
                    'providers': set()
                }
            }
            
            # Process allocations
            for row in rows:
                line_item = {
                    'allocation_id': row[0],
                    'cost_category': row[3],
                    'provider': row[5],
                    'resource_id': row[6],
                    'total_cost': row[7],
                    'allocated_cost': row[8],
                    'allocation_percentage': row[9],
                    'allocation_method': row[11],
                    'period_start': row[14],
                    'period_end': row[15],
                    'metadata': json.loads(row[16]) if row[16] else {}
                }
                
                invoice_data['line_items'].append(line_item)
                invoice_data['summary']['total_amount'] += row[8]
                invoice_data['summary']['cost_categories'].add(row[3])
                invoice_data['summary']['providers'].add(row[5])
            
            # Convert sets to lists
            invoice_data['summary']['cost_categories'] = list(invoice_data['summary']['cost_categories'])
            invoice_data['summary']['providers'] = list(invoice_data['summary']['providers'])
            
            return invoice_data
    
    def get_tenant_hierarchy_costs(self,
                                  tenant_id: str,
                                  billing_period: str) -> Dict[str, Any]:
        """Get costs for tenant and all its children"""
        
        # Find all child tenants
        child_tenants = self._get_child_tenants(tenant_id)
        all_tenant_ids = [tenant_id] + child_tenants
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get allocations for all tenants in hierarchy
            placeholders = ','.join(['?' for _ in all_tenant_ids])
            cursor.execute(f'''
                SELECT tenant_id, SUM(allocated_cost) as total_cost,
                       COUNT(*) as allocation_count
                FROM tenant_cost_allocations 
                WHERE tenant_id IN ({placeholders}) AND billing_period = ?
                GROUP BY tenant_id
            ''', all_tenant_ids + [billing_period])
            
            results = cursor.fetchall()
            
            hierarchy_costs = {
                'root_tenant_id': tenant_id,
                'billing_period': billing_period,
                'total_hierarchy_cost': 0.0,
                'tenant_breakdown': {},
                'child_tenants': child_tenants
            }
            
            for row in results:
                tenant_id_result, total_cost, allocation_count = row
                hierarchy_costs['tenant_breakdown'][tenant_id_result] = {
                    'total_cost': total_cost,
                    'allocation_count': allocation_count
                }
                hierarchy_costs['total_hierarchy_cost'] += total_cost
            
            return hierarchy_costs
    
    def _get_child_tenants(self, parent_tenant_id: str) -> List[str]:
        """Get all child tenants recursively"""
        
        child_tenants = []
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT tenant_id FROM tenants 
                WHERE parent_tenant_id = ? AND active = TRUE
            ''', (parent_tenant_id,))
            
            direct_children = [row[0] for row in cursor.fetchall()]
            
            for child_id in direct_children:
                child_tenants.append(child_id)
                child_tenants.extend(self._get_child_tenants(child_id))
        
        return child_tenants

# Example usage
async def main():
    """Example of multi-tenant cost allocation"""
    
    allocator = MultiTenantCostAllocator()
    
    # Create tenants
    enterprise_tenant = allocator.create_tenant(
        tenant_name="Acme Corp",
        tenant_type=TenantType.ENTERPRISE,
        billing_contact="finance@acme.com",
        cost_allocation_method=AllocationMethod.HYBRID
    )
    
    startup_tenant = allocator.create_tenant(
        tenant_name="TechStartup Inc",
        tenant_type=TenantType.STARTUP,
        billing_contact="ceo@techstartup.com",
        cost_allocation_method=AllocationMethod.USAGE_BASED
    )
    
    # Create allocation rules
    allocator.create_allocation_rule(
        tenant_id=enterprise_tenant,
        cost_category=CostCategory.COMPUTE,
        allocation_method=AllocationMethod.FIXED,
        allocation_percentage=60.0
    )
    
    allocator.create_allocation_rule(
        tenant_id=startup_tenant,
        cost_category=CostCategory.COMPUTE,
        allocation_method=AllocationMethod.USAGE_BASED,
        allocation_basis="gpu_hours"
    )
    
    # Record usage metrics
    allocator.record_usage_metric(
        tenant_id=startup_tenant,
        metric_name="gpu_hours",
        metric_value=1000.0,
        metric_unit="hours",
        period_start=datetime.utcnow() - timedelta(days=30),
        period_end=datetime.utcnow()
    )
    
    # Allocate costs
    cost_data = [
        {'category': 'compute', 'provider': 'aws', 'resource_id': 'p4d-1', 'cost': 1000.0},
        {'category': 'compute', 'provider': 'runpod', 'resource_id': 'a100-1', 'cost': 500.0},
        {'category': 'storage', 'provider': 'aws', 'resource_id': 's3-bucket', 'cost': 100.0}
    ]
    
    allocation = await allocator.allocate_costs_to_tenants(
        billing_period="2026-02",
        period_start=datetime.utcnow() - timedelta(days=30),
        period_end=datetime.utcnow(),
        cost_data=cost_data
    )
    
    logging.info(f"Multi-tenant allocation completed: {allocation.allocation_id}")
    logging.info(f"Total cost: ${allocation.total_cost:.2f}")
    logging.info(f"Tenant allocations: {len(allocation.tenant_allocations)
    
    # Generate invoice for enterprise tenant
    invoice = allocator.generate_tenant_invoice(enterprise_tenant, "2026-02")
    logging.info(f"Enterprise invoice: ${invoice['summary']['total_amount']:.2f}")

if __name__ == "__main__":
    asyncio.run(main())
