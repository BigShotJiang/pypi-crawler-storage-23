import logging

#!/usr/bin/env python3
"""
Terradev FinOps Attribution & Provenance Engine
Tracks GPU usage by team, project, business unit across all compute providers
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any
from enum import Enum
import hashlib
import uuid

class ProviderType(Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    RUNPOD = "runpod"
    LAMBDA = "lambda"
    COREWEAVE = "coreweave"

class WorkloadType(Enum):
    TRAINING = "training"
    INFERENCE = "inference"
    BATCH = "batch"
    REALTIME = "realtime"

@dataclass
class CostAttribution:
    """Granular cost attribution record"""
    attribution_id: str
    team_id: str
    project_id: str
    business_unit: str
    user_id: str
    workload_type: WorkloadType
    provider: ProviderType
    region: str
    instance_type: str
    gpu_count: int
    start_time: datetime
    end_time: Optional[datetime]
    duration_hours: float
    cost_per_hour: float
    total_cost: float
    tags: Dict[str, str]
    provenance_hash: str

@dataclass
class UnifiedBillingRecord:
    """Unified billing across all providers"""
    billing_id: str
    provider: ProviderType
    billing_period: str
    total_cost: float
    gpu_costs: float
    network_costs: float
    storage_costs: float
    other_costs: float
    currency: str
    attribution_records: List[str]  # IDs of attributed costs
    raw_invoice_data: Dict[str, Any]

class FinOpsAttributionEngine:
    """Core engine for GPU usage attribution and provenance tracking"""
    
    def __init__(self):
        self.attribution_records: Dict[str, CostAttribution] = {}
        self.billing_records: Dict[str, UnifiedBillingRecord] = {}
        self.team_hierarchy: Dict[str, Dict] = {}
        self.cost_centers: Dict[str, str] = {}
        
    async def track_gpu_usage(self, 
                            team_id: str,
                            project_id: str, 
                            business_unit: str,
                            user_id: str,
                            workload_type: WorkloadType,
                            provider: ProviderType,
                            region: str,
                            instance_type: str,
                            gpu_count: int,
                            cost_per_hour: float,
                            tags: Dict[str, str] = None) -> str:
        """Track new GPU usage with full attribution"""
        
        attribution_id = str(uuid.uuid4())
        start_time = datetime.utcnow()
        
        # Create provenance hash for audit trail
        provenance_data = {
            'attribution_id': attribution_id,
            'team_id': team_id,
            'project_id': project_id,
            'user_id': user_id,
            'provider': provider.value,
            'instance_type': instance_type,
            'start_time': start_time.isoformat(),
            'cost_per_hour': cost_per_hour
        }
        provenance_hash = hashlib.sha256(
            json.dumps(provenance_data, sort_keys=True).encode()
        ).hexdigest()
        
        attribution = CostAttribution(
            attribution_id=attribution_id,
            team_id=team_id,
            project_id=project_id,
            business_unit=business_unit,
            user_id=user_id,
            workload_type=workload_type,
            provider=provider,
            region=region,
            instance_type=instance_type,
            gpu_count=gpu_count,
            start_time=start_time,
            end_time=None,
            duration_hours=0.0,
            cost_per_hour=cost_per_hour,
            total_cost=0.0,
            tags=tags or {},
            provenance_hash=provenance_hash
        )
        
        self.attribution_records[attribution_id] = attribution
        return attribution_id
    
    async def end_gpu_usage(self, attribution_id: str) -> CostAttribution:
        """End GPU usage and calculate final costs"""
        
        if attribution_id not in self.attribution_records:
            raise ValueError(f"Attribution ID {attribution_id} not found")
            
        attribution = self.attribution_records[attribution_id]
        attribution.end_time = datetime.utcnow()
        
        # Calculate duration and cost
        duration = attribution.end_time - attribution.start_time
        attribution.duration_hours = duration.total_seconds() / 3600
        attribution.total_cost = attribution.duration_hours * attribution.cost_per_hour
        
        return attribution
    
    async def aggregate_costs_by_team(self, 
                                    start_date: datetime, 
                                    end_date: datetime) -> Dict[str, Dict]:
        """Aggregate costs by team for date range"""
        
        team_costs = {}
        
        for attribution in self.attribution_records.values():
            if attribution.start_time >= start_date and attribution.start_time <= end_date:
                team_id = attribution.team_id
                
                if team_id not in team_costs:
                    team_costs[team_id] = {
                        'total_cost': 0.0,
                        'training_cost': 0.0,
                        'inference_cost': 0.0,
                        'providers': {},
                        'projects': {},
                        'users': {},
                        'gpu_hours': 0.0
                    }
                
                team_data = team_costs[team_id]
                team_data['total_cost'] += attribution.total_cost
                team_data['gpu_hours'] += attribution.duration_hours * attribution.gpu_count
                
                # By workload type
                if attribution.workload_type == WorkloadType.TRAINING:
                    team_data['training_cost'] += attribution.total_cost
                elif attribution.workload_type == WorkloadType.INFERENCE:
                    team_data['inference_cost'] += attribution.total_cost
                
                # By provider
                provider = attribution.provider.value
                if provider not in team_data['providers']:
                    team_data['providers'][provider] = 0.0
                team_data['providers'][provider] += attribution.total_cost
                
                # By project
                if attribution.project_id not in team_data['projects']:
                    team_data['projects'][attribution.project_id] = 0.0
                team_data['projects'][attribution.project_id] += attribution.total_cost
                
                # By user
                if attribution.user_id not in team_data['users']:
                    team_data['users'][attribution.user_id] = 0.0
                team_data['users'][attribution.user_id] += attribution.total_cost
        
        return team_costs
    
    async def aggregate_costs_by_business_unit(self,
                                             start_date: datetime,
                                             end_date: datetime) -> Dict[str, Dict]:
        """Aggregate costs by business unit"""
        
        bu_costs = {}
        
        for attribution in self.attribution_records.values():
            if attribution.start_time >= start_date and attribution.start_time <= end_date:
                bu = attribution.business_unit
                
                if bu not in bu_costs:
                    bu_costs[bu] = {
                        'total_cost': 0.0,
                        'teams': {},
                        'providers': {},
                        'workload_types': {},
                        'gpu_hours': 0.0
                    }
                
                bu_data = bu_costs[bu]
                bu_data['total_cost'] += attribution.total_cost
                bu_data['gpu_hours'] += attribution.duration_hours * attribution.gpu_count
                
                # By team
                if attribution.team_id not in bu_data['teams']:
                    bu_data['teams'][attribution.team_id] = 0.0
                bu_data['teams'][attribution.team_id] += attribution.total_cost
                
                # By provider
                provider = attribution.provider.value
                if provider not in bu_data['providers']:
                    bu_data['providers'][provider] = 0.0
                bu_data['providers'][provider] += attribution.total_cost
                
                # By workload type
                workload = attribution.workload_type.value
                if workload not in bu_data['workload_types']:
                    bu_data['workload_types'][workload] = 0.0
                bu_data['workload_types'][workload] += attribution.total_cost
        
        return bu_costs
    
    async def create_unified_bill(self, 
                                 billing_period: str,
                                 provider: ProviderType) -> str:
        """Create unified billing record from provider data"""
        
        # This would integrate with actual provider billing APIs
        # For now, we'll simulate based on attribution records
        
        billing_id = str(uuid.uuid4())
        
        # Calculate costs from attribution records
        gpu_costs = 0.0
        network_costs = 0.0
        storage_costs = 0.0
        other_costs = 0.0
        attribution_ids = []
        
        for attribution in self.attribution_records.values():
            if attribution.provider == provider:
                gpu_costs += attribution.total_cost
                attribution_ids.append(attribution.attribution_id)
        
        # Simulate other costs (would come from actual billing data)
        network_costs = gpu_costs * 0.1  # 10% of GPU costs
        storage_costs = gpu_costs * 0.05  # 5% of GPU costs
        other_costs = gpu_costs * 0.02   # 2% of GPU costs
        
        total_cost = gpu_costs + network_costs + storage_costs + other_costs
        
        billing_record = UnifiedBillingRecord(
            billing_id=billing_id,
            provider=provider,
            billing_period=billing_period,
            total_cost=total_cost,
            gpu_costs=gpu_costs,
            network_costs=network_costs,
            storage_costs=storage_costs,
            other_costs=other_costs,
            currency="USD",
            attribution_records=attribution_ids,
            raw_invoice_data={}  # Would contain actual invoice data
        )
        
        self.billing_records[billing_id] = billing_record
        return billing_id
    
    async def generate_cost_report(self, 
                                 start_date: datetime,
                                 end_date: datetime,
                                 group_by: str = "team") -> Dict[str, Any]:
        """Generate comprehensive cost report"""
        
        if group_by == "team":
            costs = await self.aggregate_costs_by_team(start_date, end_date)
        elif group_by == "business_unit":
            costs = await self.aggregate_costs_by_business_unit(start_date, end_date)
        else:
            raise ValueError(f"Unsupported group_by: {group_by}")
        
        # Calculate totals and insights
        total_cost = sum(data['total_cost'] for data in costs.values())
        total_gpu_hours = sum(data['gpu_hours'] for data in costs.values())
        
        # Find top cost centers
        top_teams = sorted(costs.items(), key=lambda x: x[1]['total_cost'], reverse=True)[:5]
        
        # Provider breakdown
        provider_costs = {}
        for data in costs.values():
            for provider, cost in data['providers'].items():
                provider_costs[provider] = provider_costs.get(provider, 0) + cost
        
        report = {
            'period': {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat()
            },
            'summary': {
                'total_cost': total_cost,
                'total_gpu_hours': total_gpu_hours,
                'average_cost_per_gpu_hour': total_cost / total_gpu_hours if total_gpu_hours > 0 else 0,
                'group_by': group_by,
                'num_entities': len(costs)
            },
            'top_cost_centers': [{'entity': entity, **data} for entity, data in top_teams],
            'provider_breakdown': provider_costs,
            'detailed_costs': costs
        }
        
        return report
    
    async def audit_attribution_trail(self, attribution_id: str) -> Dict[str, Any]:
        """Generate audit trail for specific attribution"""
        
        if attribution_id not in self.attribution_records:
            raise ValueError(f"Attribution ID {attribution_id} not found")
        
        attribution = self.attribution_records[attribution_id]
        
        audit_trail = {
            'attribution': asdict(attribution),
            'provenance_verified': self._verify_provenance_hash(attribution),
            'cost_breakdown': {
                'gpu_cost': attribution.total_cost,
                'estimated_network_cost': attribution.total_cost * 0.1,
                'estimated_storage_cost': attribution.total_cost * 0.05,
                'total_estimated_cost': attribution.total_cost * 1.15
            },
            'efficiency_metrics': {
                'cost_per_gpu_hour': attribution.cost_per_hour,
                'gpu_utilization': 'unknown',  # Would come from monitoring
                'workload_efficiency': 'unknown'  # Would come from performance metrics
            }
        }
        
        return audit_trail
    
    def _verify_provenance_hash(self, attribution: CostAttribution) -> bool:
        """Verify the provenance hash for audit trail"""
        
        provenance_data = {
            'attribution_id': attribution.attribution_id,
            'team_id': attribution.team_id,
            'project_id': attribution.project_id,
            'user_id': attribution.user_id,
            'provider': attribution.provider.value,
            'instance_type': attribution.instance_type,
            'start_time': attribution.start_time.isoformat(),
            'cost_per_hour': attribution.cost_per_hour
        }
        
        calculated_hash = hashlib.sha256(
            json.dumps(provenance_data, sort_keys=True).encode()
        ).hexdigest()
        
        return calculated_hash == attribution.provenance_hash

# API Integration Layer
class FinOpsAPI:
    """REST API for FinOps attribution and reporting"""
    
    def __init__(self, engine: FinOpsAttributionEngine):
        self.engine = engine
    
    async def start_tracking(self, request_data: Dict[str, Any]) -> Dict[str, str]:
        """Start tracking GPU usage"""
        
        attribution_id = await self.engine.track_gpu_usage(
            team_id=request_data['team_id'],
            project_id=request_data['project_id'],
            business_unit=request_data['business_unit'],
            user_id=request_data['user_id'],
            workload_type=WorkloadType(request_data['workload_type']),
            provider=ProviderType(request_data['provider']),
            region=request_data['region'],
            instance_type=request_data['instance_type'],
            gpu_count=request_data['gpu_count'],
            cost_per_hour=request_data['cost_per_hour'],
            tags=request_data.get('tags', {})
        )
        
        return {'attribution_id': attribution_id, 'status': 'tracking_started'}
    
    async def stop_tracking(self, attribution_id: str) -> Dict[str, Any]:
        """Stop tracking and calculate final costs"""
        
        attribution = await self.engine.end_gpu_usage(attribution_id)
        
        return {
            'attribution_id': attribution_id,
            'status': 'tracking_completed',
            'duration_hours': attribution.duration_hours,
            'total_cost': attribution.total_cost
        }
    
    async def get_cost_report(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate cost report"""
        
        start_date = datetime.fromisoformat(request_data['start_date'])
        end_date = datetime.fromisoformat(request_data['end_date'])
        group_by = request_data.get('group_by', 'team')
        
        report = await self.engine.generate_cost_report(start_date, end_date, group_by)
        
        return report
    
    async def get_audit_trail(self, attribution_id: str) -> Dict[str, Any]:
        """Get audit trail for attribution"""
        
        audit_trail = await self.engine.audit_attribution_trail(attribution_id)
        
        return audit_trail

# Example usage
async def main():
    """Example of FinOps attribution in action"""
    
    engine = FinOpsAttributionEngine()
    api = FinOpsAPI(engine)
    
    # Start tracking inference workload
    tracking_response = await api.start_tracking({
        'team_id': 'ml-team-alpha',
        'project_id': 'chatbot-inference',
        'business_unit': 'ai-division',
        'user_id': 'user-123',
        'workload_type': 'inference',
        'provider': 'runpod',
        'region': 'us-east-1',
        'instance_type': 'A100-40GB',
        'gpu_count': 2,
        'cost_per_hour': 2.50,
        'tags': {'environment': 'production', 'model': 'llama-2-7b'}
    })
    
    attribution_id = tracking_response['attribution_id']
    logging.info(f"Started tracking: {attribution_id}")
    
    # Simulate workload running
    await asyncio.sleep(2)
    
    # Stop tracking
    completion_response = await api.stop_tracking(attribution_id)
    logging.info(f"Completed tracking: {completion_response}")
    
    # Generate cost report
    report = await api.get_cost_report({
        'start_date': (datetime.utcnow() - timedelta(days=30)).isoformat(),
        'end_date': datetime.utcnow().isoformat(),
        'group_by': 'team'
    })
    
    logging.info(f"Cost Report: {json.dumps(report, indent=2)

if __name__ == "__main__":
    asyncio.run(main())
