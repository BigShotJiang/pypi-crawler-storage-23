import logging

#!/usr/bin/env python3
"""
Terradev Unified Billing Aggregator
Consolidates billing across AWS, Azure, GCP, RunPod, Lambda, CoreWeave
"""

import asyncio
import aiohttp
import json
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any
from enum import Enum
import os

class CloudProvider(Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    RUNPOD = "runpod"
    LAMBDA = "lambda"
    COREWEAVE = "coreweave"

@dataclass
class BillingLineItem:
    """Individual billing line item"""
    provider: CloudProvider
    service_type: str  # compute, storage, network, etc.
    resource_id: str
    resource_type: str  # GPU instance, storage, etc.
    region: str
    usage_quantity: float
    usage_unit: str  # hours, GB, GB-months, etc.
    unit_price: float
    total_cost: float
    currency: str
    billing_period_start: datetime
    billing_period_end: datetime
    tags: Dict[str, str]
    team_attribution: Optional[str]
    project_attribution: Optional[str]

@dataclass
class UnifiedBill:
    """Consolidated bill across all providers"""
    billing_period: str
    period_start: datetime
    period_end: datetime
    total_cost: float
    currency: str
    line_items: List[BillingLineItem]
    provider_breakdown: Dict[str, float]
    service_breakdown: Dict[str, float]
    team_breakdown: Dict[str, float]
    project_breakdown: Dict[str, float]

class UnifiedBillingAggregator:
    """Aggregates billing data across all cloud providers"""
    
    def __init__(self):
        self.api_keys = {
            CloudProvider.AWS: os.getenv('AWS_ACCESS_KEY_ID'),
            CloudProvider.AZURE: os.getenv('AZURE_CLIENT_ID'),
            CloudProvider.GCP: os.getenv('GCP_SERVICE_ACCOUNT_KEY'),
            CloudProvider.RUNPOD: os.getenv('RUNPOD_API_KEY'),
            CloudProvider.LAMBDA: os.getenv('LAMBDA_API_KEY'),
            CloudProvider.COREWEAVE: os.getenv('COREWEAVE_API_KEY')
        }
        
    async def fetch_aws_billing(self, 
                               start_date: datetime, 
                               end_date: datetime) -> List[BillingLineItem]:
        """Fetch billing data from AWS Cost Explorer API"""
        
        # AWS Cost Explorer API integration
        # This would use boto3 and AWS Cost Explorer
        
        line_items = []
        
        # Simulate AWS billing data
        aws_costs = [
            {
                'service': 'Amazon EC2',
                'resource_type': 'p4d.24xlarge',
                'region': 'us-east-1',
                'usage_hours': 100,
                'rate': 32.77,
                'total': 3277.00,
                'tags': {'Team': 'ml-team', 'Project': 'training-v1'}
            },
            {
                'service': 'Amazon SageMaker',
                'resource_type': 'ml.p4d.24xlarge',
                'region': 'us-west-2',
                'usage_hours': 50,
                'rate': 35.00,
                'total': 1750.00,
                'tags': {'Team': 'inference-team', 'Project': 'prod-api'}
            }
        ]
        
        for cost in aws_costs:
            line_item = BillingLineItem(
                provider=CloudProvider.AWS,
                service_type='compute',
                resource_id=f"aws-{cost['resource_type']}-{cost['region']}",
                resource_type=cost['resource_type'],
                region=cost['region'],
                usage_quantity=cost['usage_hours'],
                usage_unit='hours',
                unit_price=cost['rate'],
                total_cost=cost['total'],
                currency='USD',
                billing_period_start=start_date,
                billing_period_end=end_date,
                tags=cost['tags'],
                team_attribution=cost['tags'].get('Team'),
                project_attribution=cost['tags'].get('Project')
            )
            line_items.append(line_item)
        
        return line_items
    
    async def fetch_azure_billing(self, 
                                 start_date: datetime, 
                                 end_date: datetime) -> List[BillingLineItem]:
        """Fetch billing data from Azure Cost Management API"""
        
        line_items = []
        
        # Simulate Azure billing data
        azure_costs = [
            {
                'service': 'Virtual Machines',
                'resource_type': 'Standard_ND96asr_v4',
                'region': 'eastus',
                'usage_hours': 80,
                'rate': 25.00,
                'total': 2000.00,
                'tags': {'Team': 'ml-team', 'Project': 'training-v1'}
            },
            {
                'service': 'Azure Machine Learning',
                'resource_type': 'Standard_NC6s_v3',
                'region': 'westus2',
                'usage_hours': 120,
                'rate': 3.06,
                'total': 367.20,
                'tags': {'Team': 'inference-team', 'Project': 'prod-api'}
            }
        ]
        
        for cost in azure_costs:
            line_item = BillingLineItem(
                provider=CloudProvider.AZURE,
                service_type='compute',
                resource_id=f"azure-{cost['resource_type']}-{cost['region']}",
                resource_type=cost['resource_type'],
                region=cost['region'],
                usage_quantity=cost['usage_hours'],
                usage_unit='hours',
                unit_price=cost['rate'],
                total_cost=cost['total'],
                currency='USD',
                billing_period_start=start_date,
                billing_period_end=end_date,
                tags=cost['tags'],
                team_attribution=cost['tags'].get('Team'),
                project_attribution=cost['tags'].get('Project')
            )
            line_items.append(line_item)
        
        return line_items
    
    async def fetch_gcp_billing(self, 
                               start_date: datetime, 
                               end_date: datetime) -> List[BillingLineItem]:
        """Fetch billing data from Google Cloud Billing API"""
        
        line_items = []
        
        # Simulate GCP billing data
        gcp_costs = [
            {
                'service': 'Compute Engine',
                'resource_type': 'a2-highgpu-8g',
                'region': 'us-central1',
                'usage_hours': 60,
                'rate': 28.00,
                'total': 1680.00,
                'tags': {'Team': 'ml-team', 'Project': 'training-v1'}
            },
            {
                'service': 'Vertex AI',
                'resource_type': 'a2-megagpu-16g',
                'region': 'us-west1',
                'usage_hours': 40,
                'rate': 45.00,
                'total': 1800.00,
                'tags': {'Team': 'inference-team', 'Project': 'prod-api'}
            }
        ]
        
        for cost in gcp_costs:
            line_item = BillingLineItem(
                provider=CloudProvider.GCP,
                service_type='compute',
                resource_id=f"gcp-{cost['resource_type']}-{cost['region']}",
                resource_type=cost['resource_type'],
                region=cost['region'],
                usage_quantity=cost['usage_hours'],
                usage_unit='hours',
                unit_price=cost['rate'],
                total_cost=cost['total'],
                currency='USD',
                billing_period_start=start_date,
                billing_period_end=end_date,
                tags=cost['tags'],
                team_attribution=cost['tags'].get('Team'),
                project_attribution=cost['tags'].get('Project')
            )
            line_items.append(line_item)
        
        return line_items
    
    async def fetch_runpod_billing(self, 
                                 start_date: datetime, 
                                 end_date: datetime) -> List[BillingLineItem]:
        """Fetch billing data from RunPod API"""
        
        line_items = []
        
        # RunPod API integration
        async with aiohttp.ClientSession() as session:
            headers = {'Authorization': f"Bearer {self.api_keys[CloudProvider.RUNPOD]}"}
            
            # Fetch pods and billing data
            async with session.get('https://api.runpod.io/pods', headers=headers) as response:
                if response.status == 200:
                    pods_data = await response.json()
                    
                    for pod in pods_data:
                        if pod.get('gpuType') and pod.get('costPerHour'):
                            # Calculate usage for the billing period
                            usage_hours = min(24, (end_date - start_date).total_seconds() / 3600)
                            
                            line_item = BillingLineItem(
                                provider=CloudProvider.RUNPOD,
                                service_type='compute',
                                resource_id=f"runpod-{pod['id']}",
                                resource_type=pod['gpuType'],
                                region=pod.get('region', 'unknown'),
                                usage_quantity=usage_hours,
                                usage_unit='hours',
                                unit_price=pod['costPerHour'],
                                total_cost=usage_hours * pod['costPerHour'],
                                currency='USD',
                                billing_period_start=start_date,
                                billing_period_end=end_date,
                                tags=pod.get('tags', {}),
                                team_attribution=pod.get('tags', {}).get('Team'),
                                project_attribution=pod.get('tags', {}).get('Project')
                            )
                            line_items.append(line_item)
        
        return line_items
    
    async def fetch_lambda_billing(self, 
                                  start_date: datetime, 
                                  end_date: datetime) -> List[BillingLineItem]:
        """Fetch billing data from Lambda Labs API"""
        
        line_items = []
        
        # Lambda Labs API integration
        async with aiohttp.ClientSession() as session:
            headers = {'Authorization': f"Bearer {self.api_keys[CloudProvider.LAMBDA]}"}
            
            # Fetch instances and billing data
            async with session.get('https://api.lambdalabs.com/v1/instances', headers=headers) as response:
                if response.status == 200:
                    instances_data = await response.json()
                    
                    for instance in instances_data.get('data', []):
                        if instance.get('gpu_type') and instance.get('price_per_hour'):
                            usage_hours = min(24, (end_date - start_date).total_seconds() / 3600)
                            
                            line_item = BillingLineItem(
                                provider=CloudProvider.LAMBDA,
                                service_type='compute',
                                resource_id=f"lambda-{instance['id']}",
                                resource_type=instance['gpu_type'],
                                region=instance.get('region', 'unknown'),
                                usage_quantity=usage_hours,
                                usage_unit='hours',
                                unit_price=instance['price_per_hour'],
                                total_cost=usage_hours * instance['price_per_hour'],
                                currency='USD',
                                billing_period_start=start_date,
                                billing_period_end=end_date,
                                tags=instance.get('tags', {}),
                                team_attribution=instance.get('tags', {}).get('Team'),
                                project_attribution=instance.get('tags', {}).get('Project')
                            )
                            line_items.append(line_item)
        
        return line_items
    
    async def fetch_coreweave_billing(self, 
                                     start_date: datetime, 
                                     end_date: datetime) -> List[BillingLineItem]:
        """Fetch billing data from CoreWeave API"""
        
        line_items = []
        
        # CoreWeave API integration
        async with aiohttp.ClientSession() as session:
            headers = {'Authorization': f"Bearer {self.api_keys[CloudProvider.COREWEAVE]}"}
            
            # Fetch virtual servers and billing data
            async with session.get('https://api.coreweave.com/v1/virtual-servers', headers=headers) as response:
                if response.status == 200:
                    servers_data = await response.json()
                    
                    for server in servers_data:
                        if server.get('spec', {}).get('gpu', {}).get('type'):
                            usage_hours = min(24, (end_date - start_date).total_seconds() / 3600)
                            gpu_type = server['spec']['gpu']['type']
                            
                            # CoreWeave pricing (would come from actual API)
                            pricing = {
                                'A40': 2.50,
                                'A100': 3.50,
                                'RTX-4090': 1.50
                            }
                            
                            unit_price = pricing.get(gpu_type, 2.00)
                            
                            line_item = BillingLineItem(
                                provider=CloudProvider.COREWEAVE,
                                service_type='compute',
                                resource_id=f"coreweave-{server['metadata']['name']}",
                                resource_type=gpu_type,
                                region=server.get('metadata', {}).get('namespace', 'unknown'),
                                usage_quantity=usage_hours,
                                usage_unit='hours',
                                unit_price=unit_price,
                                total_cost=usage_hours * unit_price,
                                currency='USD',
                                billing_period_start=start_date,
                                billing_period_end=end_date,
                                tags=server.get('metadata', {}).get('labels', {}),
                                team_attribution=server.get('metadata', {}).get('labels', {}).get('Team'),
                                project_attribution=server.get('metadata', {}).get('labels', {}).get('Project')
                            )
                            line_items.append(line_item)
        
        return line_items
    
    async def create_unified_bill(self, 
                                 start_date: datetime, 
                                 end_date: datetime) -> UnifiedBill:
        """Create unified bill from all providers"""
        
        # Fetch billing data from all providers
        billing_tasks = [
            self.fetch_aws_billing(start_date, end_date),
            self.fetch_azure_billing(start_date, end_date),
            self.fetch_gcp_billing(start_date, end_date),
            self.fetch_runpod_billing(start_date, end_date),
            self.fetch_lambda_billing(start_date, end_date),
            self.fetch_coreweave_billing(start_date, end_date)
        ]
        
        all_line_items = await asyncio.gather(*billing_tasks)
        
        # Flatten all line items
        line_items = []
        for items in all_line_items:
            line_items.extend(items)
        
        # Calculate breakdowns
        total_cost = sum(item.total_cost for item in line_items)
        
        provider_breakdown = {}
        service_breakdown = {}
        team_breakdown = {}
        project_breakdown = {}
        
        for item in line_items:
            # Provider breakdown
            provider = item.provider.value
            provider_breakdown[provider] = provider_breakdown.get(provider, 0) + item.total_cost
            
            # Service breakdown
            service = item.service_type
            service_breakdown[service] = service_breakdown.get(service, 0) + item.total_cost
            
            # Team breakdown
            if item.team_attribution:
                team = item.team_attribution
                team_breakdown[team] = team_breakdown.get(team, 0) + item.total_cost
            
            # Project breakdown
            if item.project_attribution:
                project = item.project_attribution
                project_breakdown[project] = project_breakdown.get(project, 0) + item.total_cost
        
        unified_bill = UnifiedBill(
            billing_period=f"{start_date.strftime('%Y-%m')}",
            period_start=start_date,
            period_end=end_date,
            total_cost=total_cost,
            currency='USD',
            line_items=line_items,
            provider_breakdown=provider_breakdown,
            service_breakdown=service_breakdown,
            team_breakdown=team_breakdown,
            project_breakdown=project_breakdown
        )
        
        return unified_bill
    
    def export_to_csv(self, unified_bill: UnifiedBill, filename: str):
        """Export unified bill to CSV"""
        
        data = []
        for item in unified_bill.line_items:
            data.append({
                'Provider': item.provider.value,
                'Service': item.service_type,
                'Resource_Type': item.resource_type,
                'Region': item.region,
                'Usage_Quantity': item.usage_quantity,
                'Usage_Unit': item.usage_unit,
                'Unit_Price': item.unit_price,
                'Total_Cost': item.total_cost,
                'Currency': item.currency,
                'Team': item.team_attribution or 'Unattributed',
                'Project': item.project_attribution or 'Unattributed',
                'Tags': json.dumps(item.tags)
            })
        
        df = pd.DataFrame(data)
        df.to_csv(filename, index=False)
    
    def generate_summary_report(self, unified_bill: UnifiedBill) -> Dict[str, Any]:
        """Generate summary report of unified bill"""
        
        report = {
            'billing_period': unified_bill.billing_period,
            'total_cost': unified_bill.total_cost,
            'currency': unified_bill.currency,
            'total_line_items': len(unified_bill.line_items),
            'provider_breakdown': unified_bill.provider_breakdown,
            'service_breakdown': unified_bill.service_breakdown,
            'team_breakdown': unified_bill.team_breakdown,
            'project_breakdown': unified_bill.project_breakdown,
            'cost_insights': {
                'most_expensive_provider': max(unified_bill.provider_breakdown.items(), key=lambda x: x[1])[0],
                'most_expensive_service': max(unified_bill.service_breakdown.items(), key=lambda x: x[1])[0],
                'most_expensive_team': max(unified_bill.team_breakdown.items(), key=lambda x: x[1])[0] if unified_bill.team_breakdown else 'None',
                'attribution_coverage': len([item for item in unified_bill.line_items if item.team_attribution]) / len(unified_bill.line_items) * 100
            }
        }
        
        return report

# Example usage
async def main():
    """Example of unified billing aggregation"""
    
    aggregator = UnifiedBillingAggregator()
    
    # Create unified bill for last month
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=30)
    
    unified_bill = await aggregator.create_unified_bill(start_date, end_date)
    
    # Generate summary report
    summary = aggregator.generate_summary_report(unified_bill)
    logging.info(f"Unified Bill Summary: {json.dumps(summary, indent=2)
    
    # Export to CSV
    aggregator.export_to_csv(unified_bill, 'unified_bill.csv')
    logging.info(f"Exported unified bill to CSV")

if __name__ == "__main__":
    asyncio.run(main())
