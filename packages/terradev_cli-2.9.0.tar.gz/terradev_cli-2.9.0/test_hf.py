import logging

#!/usr/bin/env python3
import asyncio
from hf_limiting_circumvention import HFLimitingOrchestrator
from ultimate_circumvention import UltimateCircumventionOrchestrator

async def test_hf():
    orchestrator = HFLimitingOrchestrator()
    await orchestrator.authenticate('hf_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
    models = await orchestrator.get_available_models()
    logging.info(f'Available models: {[m["id"] for m in models[:5]}')

if __name__ == "__main__":
    asyncio.run(test_hf())
