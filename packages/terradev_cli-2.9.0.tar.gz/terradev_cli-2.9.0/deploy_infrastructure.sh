#!/bin/bash
# Terradev Infrastructure Deployment Script
# Deploys microservices using Terraform and Kubernetes

set -e

# Configuration
ENVIRONMENT=${1:-dev}
AWS_REGION=${2:-us-east-1}
CLUSTER_NAME="terradev-${ENVIRONMENT}"

echo "🚀 Deploying Terradev Infrastructure"
echo "Environment: $ENVIRONMENT"
echo "AWS Region: $AWS_REGION"
echo "Cluster Name: $CLUSTER_NAME"
echo "=================================="

# Check prerequisites
echo "📋 Checking prerequisites..."

if ! command -v terraform &> /dev/null; then
    echo "❌ Terraform not found. Please install Terraform."
    exit 1
fi

if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl not found. Please install kubectl."
    exit 1
fi

if ! command -v helm &> /dev/null; then
    echo "❌ Helm not found. Please install Helm."
    exit 1
fi

# Check AWS credentials
if ! aws sts get-caller-identity &> /dev/null; then
    echo "❌ AWS credentials not configured. Please run 'aws configure'."
    exit 1
fi

echo "✅ Prerequisites check passed"

# Deploy infrastructure with Terraform
echo "🏗️ Deploying infrastructure with Terraform..."

cd infrastructure/terraform

# Initialize Terraform
terraform init

# Plan deployment
terraform plan \
  -var="environment=$ENVIRONMENT" \
  -var="aws_region=$AWS_REGION" \
  -var="cluster_name=$CLUSTER_NAME" \
  -out="terradev.plan"

# Apply infrastructure
echo "📦 Applying Terraform configuration..."
terraform apply terradev.plan

# Get outputs
CLUSTER_ENDPOINT=$(terraform output -raw cluster_endpoint)
DATABASE_ENDPOINT=$(terraform output -raw database_endpoint)
REDIS_ENDPOINT=$(terraform output -raw redis_endpoint)
STORAGE_BUCKET=$(terraform output -raw storage_bucket)

echo "✅ Infrastructure deployed successfully"
echo "📊 Cluster Endpoint: $CLUSTER_ENDPOINT"
echo "🗄️ Database Endpoint: $DATABASE_ENDPOINT"
echo "🔴 Redis Endpoint: $REDIS_ENDPOINT"
echo "📦 Storage Bucket: $STORAGE_BUCKET"

# Configure kubectl
echo "🔧 Configuring kubectl..."
aws eks update-kubeconfig --region $AWS_REGION --name $CLUSTER_NAME

# Wait for cluster to be ready
echo "⏳ Waiting for cluster to be ready..."
kubectl wait --for=condition=Ready nodes --all --timeout=300s

# Deploy microservices
echo "🚀 Deploying microservices..."

cd ../kubernetes

# Create namespaces
kubectl apply -f namespaces.yaml

# Apply ConfigMaps and Secrets
kubectl apply -f configmaps.yaml
kubectl apply -f secrets.yaml

# Deploy microservices
kubectl apply -f microservices.yaml

# Wait for deployments to be ready
echo "⏳ Waiting for microservices to be ready..."
kubectl wait --for=condition=available --timeout=300s deployment --all -n terradev-system

# Get service URLs
echo "🔗 Getting service URLs..."

# Get LoadBalancer IP for ingress
INGRESS_IP=""
while [ -z "$INGRESS_IP" ]; do
    echo "Waiting for Ingress LoadBalancer IP..."
    INGRESS_IP=$(kubectl get service nginx-ingress-ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
    if [ -z "$INGRESS_IP" ]; then
        INGRESS_IP=$(kubectl get service nginx-ingress-ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    fi
    sleep 10
done

echo "✅ Ingress available at: $INGRESS_IP"

# Setup DNS (manual step required)
echo "🌐 DNS Setup Required:"
echo "   Please create DNS records:"
echo "   api.terradev.com -> $INGRESS_IP"
echo "   app.terradev.com -> $INGRESS_IP"

# Get Grafana credentials
GRAFANA_PASSWORD=$(kubectl get secret prometheus-grafana -n monitoring -o jsonpath='{.data.admin-password}' | base64 --decode)
echo "📊 Grafana Credentials:"
echo "   URL: http://$INGRESS_IP/grafana"
echo "   Username: admin"
echo "   Password: $GRAFANA_PASSWORD"

# Verify deployment
echo "🔍 Verifying deployment..."

# Check all pods are running
kubectl get pods -n terradev-system

# Check services
kubectl get services -n terradev-system

# Check ingress
kubectl get ingress -n terradev-system

# Test API Gateway
echo "🧪 Testing API Gateway..."
API_URL="http://$INGRESS_IP/api/status"
if curl -s $API_URL | grep -q "healthy"; then
    echo "✅ API Gateway is healthy"
else
    echo "❌ API Gateway health check failed"
fi

# Cleanup Terraform plan
rm -f terradev.plan

echo ""
echo "🎉 Terradev Infrastructure Deployment Complete!"
echo "=================================="
echo "📊 Cluster: $CLUSTER_ENDPOINT"
echo "🌐 API Gateway: http://$INGRESS_IP/api/status"
echo "📱 Web App: http://$INGRESS_IP"
echo "📊 Grafana: http://$INGRESS_IP/grafana"
echo "🗄️ Database: $DATABASE_ENDPOINT"
echo "🔴 Redis: $REDIS_ENDPOINT"
echo "📦 Storage: $STORAGE_BUCKET"
echo ""
echo "📋 Next Steps:"
echo "1. Configure DNS records for api.terradev.com and app.terradev.com"
echo "2. Update application configuration with database and Redis endpoints"
echo "3. Deploy your application containers"
echo "4. Configure monitoring and alerting"
echo ""
echo "🔧 Management Commands:"
echo "   kubectl get pods -n terradev-system"
echo "   kubectl logs -f deployment/terradev-api-gateway -n terradev-system"
echo "   terraform destroy -var='environment=$ENVIRONMENT' -var='aws_region=$AWS_REGION' -var='cluster_name=$CLUSTER_NAME'"
