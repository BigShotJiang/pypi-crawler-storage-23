# Latency Arbitrage Integration Engine
# Tying together all free APIs for real-time inference optimization

resource "local_file" "latency_arbitrage_integration" {
  filename = "${path.module}/integration/latency-arbitrage-engine.py"
  content = <<-EOT
  """
  Latency Arbitrage Integration Engine
  Integrates multiple free APIs for real-time inference optimization
  """

  import asyncio
  import aiohttp
  import json
  import time
  import logging
  from datetime import datetime, timedelta
  from typing import Dict, List, Optional, Any, Tuple
  from dataclasses import dataclass, field
  from enum import Enum
  import statistics
  import math
  from collections import defaultdict, deque
  import sqlite3
  import pickle
  import os

  logger = logging.getLogger(__name__)

  @dataclass
  class LatencyMeasurement:
      """Latency measurement for a provider"""
      provider: str
      region: str
      user_location: str
      edge_location: str
      actual_latency_ms: float
      network_distance_km: float
      cost_per_request: float
      reliability_score: float
      timestamp: datetime = field(default_factory=datetime.now)

  @dataclass
  class ArbitrageDecision:
      """Arbitrage decision for routing"""
      request_id: str
      user_location: str
      selected_provider: str
      selected_region: str
      edge_location: str
      estimated_latency_ms: float
      estimated_cost: float
      confidence_score: float
      reasoning: List[str]
      alternatives: List[Dict[str, Any]]

  class FreeAPIIntegrator:
      """Integrates all free APIs for latency arbitrage"""
      
      def __init__(self):
          self.session = None
          self.cache = {}
          self.cache_ttl = 300  # 5 minutes cache
          self.db_path = "latency_cache.db"
          self.init_database()
          
      def init_database(self):
          """Initialize SQLite cache database"""
          conn = sqlite3.connect(self.db_path)
          cursor = conn.cursor()
          
          cursor.execute('''
              CREATE TABLE IF NOT EXISTS latency_cache (
                  provider TEXT,
                  region TEXT,
                  user_location TEXT,
                  edge_location TEXT,
                  latency_ms REAL,
                  network_distance_km REAL,
                  cost_per_request REAL,
                  reliability_score REAL,
                  timestamp DATETIME,
                  PRIMARY KEY (provider, region, user_location)
              )
          ''')
          
          cursor.execute('''
              CREATE TABLE IF NOT EXISTS provider_cache (
                  provider TEXT PRIMARY KEY,
                  data TEXT,
                  timestamp DATETIME
              )
          ''')
          
          conn.commit()
          conn.close()
      
      async def __aenter__(self):
          self.session = aiohttp.ClientSession()
          return self
      
      async def __aexit__(self, exc_type, exc_val, exc_tb):
          if self.session:
              await self.session.close()
      
      def get_cache_key(self, category: str, *args) -> str:
          """Generate cache key"""
          return f"{category}:{':'.join(str(arg) for arg in args)}"
      
      def get_cached_data(self, cache_key: str) -> Optional[Any]:
          """Get cached data"""
          if cache_key in self.cache:
              data, timestamp = self.cache[cache_key]
              if time.time() - timestamp < self.cache_ttl:
                  return data
              else:
                  del self.cache[cache_key]
          return None
      
      def set_cached_data(self, cache_key: str, data: Any):
          """Set cached data"""
          self.cache[cache_key] = (data, time.time())
      
      # Geolocation APIs
      async def get_user_geolocation(self, ip_address: str) -> Dict[str, Any]:
          """Get user geolocation using free APIs"""
          cache_key = self.get_cache_key("geo", ip_address)
          cached = self.get_cached_data(cache_key)
          if cached:
              return cached
          
          # Try IPapi.co first
          try:
              url = f"https://ipapi.co/{ip_address}/json/"
              async with self.session.get(url) as response:
                  if response.status == 200:
                      data = await response.json()
                      result = {
                          'ip': data.get('ip'),
                          'city': data.get('city'),
                          'region': data.get('region'),
                          'country': data.get('country_name'),
                          'latitude': data.get('latitude'),
                          'longitude': data.get('longitude'),
                          'timezone': data.get('timezone'),
                          'asn': data.get('asn'),
                          'org': data.get('org')
                      }
                      self.set_cached_data(cache_key, result)
                      return result
          except Exception as e:
              logger.warning(f"IPapi.co failed: {e}")
          
          # Fallback to ip-api.com
          try:
              url = f"http://ip-api.com/json/{ip_address}"
              async with self.session.get(url) as response:
                  if response.status == 200:
                      data = await response.json()
                      result = {
                          'ip': data.get('query'),
                          'city': data.get('city'),
                          'region': data.get('regionName'),
                          'country': data.get('country'),
                          'latitude': data.get('lat'),
                          'longitude': data.get('lon'),
                          'timezone': data.get('timezone'),
                          'org': data.get('org', data.get('isp'))
                      }
                      self.set_cached_data(cache_key, result)
                      return result
          except Exception as e:
              logger.warning(f"ip-api.com failed: {e}")
          
          # Return default if all fail
          return {
              'ip': ip_address,
              'city': 'Unknown',
              'region': 'Unknown',
              'country': 'Unknown',
              'latitude': 0.0,
              'longitude': 0.0,
              'timezone': 'UTC',
              'org': 'Unknown'
          }
      
      # Network Distance Calculation
      def calculate_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
          """Calculate distance between two coordinates in kilometers"""
          R = 6371.0  # Earth radius in kilometers
          
          lat1_rad = math.radians(lat1)
          lon1_rad = math.radians(lon1)
          lat2_rad = math.radians(lat2)
          lon2_rad = math.radians(lon2)
          
          dlat = lat2_rad - lat1_rad
          dlon = lon2_rad - lon1_rad
          
          a = math.sin(dlat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2
          c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
          
          return R * c
      
      # Edge Location APIs
      async def get_edge_locations(self, provider: str) -> List[Dict[str, Any]]:
          """Get edge locations for providers"""
          cache_key = self.get_cache_key("edge", provider)
          cached = self.get_cached_data(cache_key)
          if cached:
              return cached
          
          locations = []
          
          if provider in ['aws', 'cloudflare', 'fastly']:
              # Cloudflare edge locations
              try:
                  url = "https://api.cloudflare.com/client/v4/ips"
                  async with self.session.get(url) as response:
                      if response.status == 200:
                          data = await response.json()
                          # Cloudflare doesn't provide detailed locations in this API
                          # Use known major edge locations
                          locations = [
                              {'code': 'SFO', 'name': 'San Francisco', 'lat': 37.7749, 'lon': -122.4194},
                              {'code': 'LAX', 'name': 'Los Angeles', 'lat': 34.0522, 'lon': -118.2437},
                              {'code': 'NYC', 'name': 'New York', 'lat': 40.7128, 'lon': -74.0060},
                              {'code': 'LON', 'name': 'London', 'lat': 51.5074, 'lon': -0.1278},
                              {'code': 'FRA', 'name': 'Frankfurt', 'lat': 50.1109, 'lon': 8.6821},
                              {'code': 'SIN', 'name': 'Singapore', 'lat': 1.3521, 'lon': 103.8198},
                              {'code': 'TOK', 'name': 'Tokyo', 'lat': 35.6762, 'lon': 139.6503}
                          ]
                          self.set_cached_data(cache_key, locations)
                          return locations
              except Exception as e:
                  logger.warning(f"Cloudflare API failed: {e}")
          
          # Default edge locations
          locations = [
              {'code': 'US-EAST', 'name': 'US East', 'lat': 40.7128, 'lon': -74.0060},
              {'code': 'US-WEST', 'name': 'US West', 'lat': 37.7749, 'lon': -122.4194},
              {'code': 'EU-WEST', 'name': 'EU West', 'lat': 51.5074, 'lon': -0.1278},
              {'code': 'ASIA-PAC', 'name': 'Asia Pacific', 'lat': 1.3521, 'lon': 103.8198}
          ]
          
          self.set_cached_data(cache_key, locations)
          return locations
      
      # Provider Pricing APIs
      async def get_provider_pricing(self, provider: str) -> Dict[str, Any]:
          """Get provider pricing using free APIs"""
          cache_key = self.get_cache_key("pricing", provider)
          cached = self.get_cached_data(cache_key)
          if cached:
              return cached
          
          pricing = {}
          
          if provider == 'runpod':
              try:
                  url = "https://api.runpod.io/v1/serverless/llama-2-7b-chat"
                  async with self.session.get(url) as response:
                      if response.status == 200:
                          data = await response.json()
                          pricing = {
                              'input_price_per_token': data.get('input_price', 0.0001),
                              'output_price_per_token': data.get('output_price', 0.0002),
                              'unit': 'token'
                          }
              except Exception as e:
                  logger.warning(f"RunPod API failed: {e}")
                  # Fallback pricing
                  pricing = {
                      'input_price_per_token': 0.0001,
                      'output_price_per_token': 0.0002,
                      'unit': 'token'
                  }
          
          elif provider == 'lambda':
              try:
                  url = "https://api.labs.lambda.cloud/instance-types"
                  async with self.session.get(url) as response:
                      if response.status == 200:
                          data = await response.json()
                          for instance in data.get('data', []):
                              if 'a100' in instance.get('name', '').lower():
                                  pricing = {
                                      'price_per_hour': float(instance.get('price', '1.60')),
                                      'unit': 'hour'
                                  }
                                  break
              except Exception as e:
                  logger.warning(f"Lambda API failed: {e}")
                  pricing = {'price_per_hour': 1.60, 'unit': 'hour'}
          
          elif provider == 'coreweave':
              try:
                  url = "https://api.coreweave.com/v1/gpu-inventory"
                  async with self.session.get(url) as response:
                      if response.status == 200:
                          data = await response.json()
                          nvidia_gpus = data.get('nvidia', {})
                          for gpu_type, info in nvidia_gpus.items():
                              if 'a100' in gpu_type.lower():
                                  # Estimate pricing based on typical rates
                                  pricing = {
                                      'price_per_hour': 2.79,  # Typical A100 price
                                      'unit': 'hour'
                                  }
                                  break
              except Exception as e:
                  logger.warning(f"CoreWeave API failed: {e}")
                  pricing = {'price_per_hour': 2.79, 'unit': 'hour'}
          
          else:
              # Default pricing for unknown providers
              pricing = {
                  'price_per_request': 0.002,
                  'unit': 'request'
              }
          
          self.set_cached_data(cache_key, pricing)
          return pricing
      
      # Performance Measurement APIs
      async def measure_latency(self, endpoint: str, timeout: int = 5) -> float:
          """Measure actual latency to an endpoint"""
          cache_key = self.get_cache_key("latency", endpoint)
          cached = self.get_cached_data(cache_key)
          if cached:
              return cached
          
          start_time = time.time()
          try:
              async with self.session.get(endpoint, timeout=timeout) as response:
                  if response.status == 200:
                      latency_ms = (time.time() - start_time) * 1000
                      self.set_cached_data(cache_key, latency_ms)
                      return latency_ms
          except Exception as e:
              logger.warning(f"Latency measurement failed for {endpoint}: {e}")
          
          # Return default latency if measurement fails
          return 100.0  # 100ms default
      
      # Network Quality APIs
      async def get_network_quality(self, asn: str) -> Dict[str, Any]:
          """Get network quality metrics"""
          cache_key = self.get_cache_key("network", asn)
          cached = self.get_cached_data(cache_key)
          if cached:
              return cached
          
          # Cloudflare Radar API (free tier)
          try:
              url = "https://api.cloudflare.com/client/v4/radar/quality"
              async with self.session.get(url) as response:
                  if response.status == 200:
                      data = await response.json()
                      networks = data.get('result', {}).get('networks', [])
                      
                      for network in networks:
                          if network.get('asn') == int(asn):
                              quality = {
                                  'latency': network.get('latency', 50.0),
                                  'packet_loss': network.get('packetLoss', 0.0),
                                  'jitter': network.get('jitter', 0.0),
                                  'quality_score': network.get('quality', 0.9)
                              }
                              self.set_cached_data(cache_key, quality)
                              return quality
          except Exception as e:
              logger.warning(f"Cloudflare Radar API failed: {e}")
          
          # Default network quality
          quality = {
              'latency': 50.0,
              'packet_loss': 0.0,
              'jitter': 0.0,
              'quality_score': 0.9
          }
          
          self.set_cached_data(cache_key, quality)
          return quality
      
      # Database operations
      def save_latency_measurement(self, measurement: LatencyMeasurement):
          """Save latency measurement to database"""
          conn = sqlite3.connect(self.db_path)
          cursor = conn.cursor()
          
          cursor.execute('''
              INSERT OR REPLACE INTO latency_cache
              (provider, region, user_location, edge_location, latency_ms, 
               network_distance_km, cost_per_request, reliability_score, timestamp)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          ''', (
              measurement.provider,
              measurement.region,
              measurement.user_location,
              measurement.edge_location,
              measurement.actual_latency_ms,
              measurement.network_distance_km,
              measurement.cost_per_request,
              measurement.reliability_score,
              measurement.timestamp
          ))
          
          conn.commit()
          conn.close()
      
      def get_cached_latency(self, provider: str, user_location: str) -> Optional[LatencyMeasurement]:
          """Get cached latency measurement"""
          conn = sqlite3.connect(self.db_path)
          cursor = conn.cursor()
          
          cursor.execute('''
              SELECT provider, region, user_location, edge_location, latency_ms,
                     network_distance_km, cost_per_request, reliability_score, timestamp
              FROM latency_cache
              WHERE provider = ? AND user_location = ?
              ORDER BY timestamp DESC
              LIMIT 1
          ''', (provider, user_location))
          
          row = cursor.fetchone()
          conn.close()
          
          if row:
              return LatencyMeasurement(
                  provider=row[0],
                  region=row[1],
                  user_location=row[2],
                  edge_location=row[3],
                  actual_latency_ms=row[4],
                  network_distance_km=row[5],
                  cost_per_request=row[6],
                  reliability_score=row[7],
                  timestamp=datetime.fromisoformat(row[8])
              )
          
          return None

  class LatencyArbitrageEngine:
      """Main latency arbitrage engine"""
      
      def __init__(self):
          self.providers = ['aws', 'runpod', 'lambda', 'coreweave', 'cloudflare']
          self.integrator = FreeAPIIntegrator()
          self.decision_history = deque(maxlen=1000)
          
      async def analyze_request_arbitrage(self, 
                                        user_ip: str,
                                        model_name: str = "llama-2-7b",
                                        max_latency_ms: float = 200.0,
                                        max_cost_per_request: float = 0.01) -> ArbitrageDecision:
          """Analyze arbitrage opportunities for a request"""
          
          request_id = f"req_{int(time.time() * 1000000)}"
          
          # 1. Get user geolocation
          user_geo = await self.integrator.get_user_geolocation(user_ip)
          user_location = f"{user_geo['city']}, {user_geo['country']}"
          
          # 2. Get network quality
          network_quality = await self.integrator.get_network_quality(user_geo.get('asn', '0'))
          
          # 3. Analyze all providers
          provider_analysis = []
          
          for provider in self.providers:
              try:
                  # Get edge locations
                  edge_locations = await self.integrator.get_edge_locations(provider)
                  
                  # Find nearest edge location
                  nearest_edge = min(edge_locations, 
                                  key=lambda loc: self.integrator.calculate_distance(
                                      user_geo['latitude'], user_geo['longitude'],
                                      loc['lat'], loc['lon']
                                  ))
                  
                  # Calculate network distance
                  network_distance = self.integrator.calculate_distance(
                      user_geo['latitude'], user_geo['longitude'],
                      nearest_edge['lat'], nearest_edge['lon']
                  )
                  
                  # Get provider pricing
                  pricing = await self.integrator.get_provider_pricing(provider)
                  
                  # Estimate cost per request (simplified)
                  if 'price_per_request' in pricing:
                      cost_per_request = pricing['price_per_request']
                  elif 'price_per_hour' in pricing:
                      # Estimate requests per hour
                      requests_per_hour = 3600 / 0.1  # 100ms per request
                      cost_per_request = pricing['price_per_hour'] / requests_per_hour
                  elif 'input_price_per_token' in pricing:
                      # Estimate 100 tokens per request
                      cost_per_request = pricing['input_price_per_token'] * 100
                  else:
                      cost_per_request = 0.002  # Default
                  
                  # Estimate latency based on network distance
                  base_latency = network_distance * 0.01  # 0.01ms per km
                  network_latency = network_quality.get('latency', 50.0)
                  estimated_latency = base_latency + network_latency
                  
                  # Calculate reliability score
                  reliability = network_quality.get('quality_score', 0.9)
                  
                  provider_analysis.append({
                      'provider': provider,
                      'region': nearest_edge['code'],
                      'edge_location': nearest_edge['name'],
                      'network_distance_km': network_distance,
                      'estimated_latency_ms': estimated_latency,
                      'cost_per_request': cost_per_request,
                      'reliability_score': reliability
                  })
                  
              except Exception as e:
                  logger.error(f"Error analyzing provider {provider}: {e}")
                  continue
          
          # 4. Filter by constraints
          viable_providers = [
              p for p in provider_analysis 
              if p['estimated_latency_ms'] <= max_latency_ms 
              and p['cost_per_request'] <= max_cost_per_request
          ]
          
          if not viable_providers:
              # No viable providers, return best effort
              viable_providers = sorted(provider_analysis, key=lambda x: x['estimated_latency_ms'])[:1]
          
          # 5. Select optimal provider
          # Optimize for latency first, then cost
          optimal = min(viable_providers, 
                       key=lambda x: (x['estimated_latency_ms'], x['cost_per_request']))
          
          # 6. Calculate confidence score
          confidence = self._calculate_confidence_score(optimal, viable_providers)
          
          # 7. Generate reasoning
          reasoning = [
              f"Selected {optimal['provider']} for lowest latency ({optimal['estimated_latency_ms']:.1f}ms)",
              f"Network distance: {optimal['network_distance_km']:.0f}km",
              f"Cost: ${optimal['cost_per_request']:.4f} per request",
              f"Reliability: {optimal['reliability_score']:.1%}",
              f"User location: {user_location}"
          ]
          
          # 8. Prepare alternatives
          alternatives = []
          for provider in sorted(viable_providers, key=lambda x: x['estimated_latency_ms'])[1:4]:
              alternatives.append({
                  'provider': provider['provider'],
                  'latency_ms': provider['estimated_latency_ms'],
                  'cost_per_request': provider['cost_per_request'],
                  'reason': f"Alternative: {provider['network_distance_km']:.0f}km away"
              })
          
          # 9. Create decision
          decision = ArbitrageDecision(
              request_id=request_id,
              user_location=user_location,
              selected_provider=optimal['provider'],
              selected_region=optimal['region'],
              edge_location=optimal['edge_location'],
              estimated_latency_ms=optimal['estimated_latency_ms'],
              estimated_cost=optimal['cost_per_request'],
              confidence_score=confidence,
              reasoning=reasoning,
              alternatives=alternatives
          )
          
          # 10. Save decision
          self.decision_history.append(decision)
          
          # 11. Save measurement for learning
          measurement = LatencyMeasurement(
              provider=optimal['provider'],
              region=optimal['region'],
              user_location=user_location,
              edge_location=optimal['edge_location'],
              actual_latency_ms=optimal['estimated_latency_ms'],
              network_distance_km=optimal['network_distance_km'],
              cost_per_request=optimal['cost_per_request'],
              reliability_score=optimal['reliability_score']
          )
          self.integrator.save_latency_measurement(measurement)
          
          return decision
      
      def _calculate_confidence_score(self, optimal: Dict, viable: List[Dict]) -> float:
          """Calculate confidence score for the decision"""
          confidence = 0.0
          
          # Latency confidence (40%)
          if optimal['estimated_latency_ms'] < 50:
              confidence += 0.4
          elif optimal['estimated_latency_ms'] < 100:
              confidence += 0.3
          elif optimal['estimated_latency_ms'] < 200:
              confidence += 0.2
          
          # Cost confidence (20%)
          if optimal['cost_per_request'] < 0.001:
              confidence += 0.2
          elif optimal['cost_per_request'] < 0.005:
              confidence += 0.15
          elif optimal['cost_per_request'] < 0.01:
              confidence += 0.1
          
          # Reliability confidence (20%)
          confidence += optimal['reliability_score'] * 0.2
          
          # Network distance confidence (10%)
          if optimal['network_distance_km'] < 1000:
              confidence += 0.1
          elif optimal['network_distance_km'] < 5000:
              confidence += 0.05
          
          # Provider diversity confidence (10%)
          if len(viable) >= 3:
              confidence += 0.1
          elif len(viable) >= 2:
              confidence += 0.05
          
          return min(confidence, 1.0)
      
      def get_arbitrage_stats(self) -> Dict[str, Any]:
          """Get arbitrage statistics"""
          if not self.decision_history:
              return {}
          
          # Provider distribution
          provider_counts = defaultdict(int)
          latency_savings = []
          cost_savings = []
          
          for decision in self.decision_history:
              provider_counts[decision.selected_provider] += 1
              
              # Calculate savings vs worst alternative
              if decision.alternatives:
                  worst_alt = max(decision.alternatives, key=lambda x: x['latency_ms'])
                  latency_saving = worst_alt['latency_ms'] - decision.estimated_latency_ms
                  latency_savings.append(latency_saving)
                  
                  worst_cost = max(decision.alternatives, key=lambda x: x['cost_per_request'])
                  cost_saving = worst_cost['cost_per_request'] - decision.estimated_cost
                  cost_savings.append(cost_saving)
          
          return {
              'total_requests': len(self.decision_history),
              'provider_distribution': dict(provider_counts),
              'avg_latency_savings_ms': statistics.mean(latency_savings) if latency_savings else 0,
              'avg_cost_savings': statistics.mean(cost_savings) if cost_savings else 0,
              'avg_confidence_score': statistics.mean([d.confidence_score for d in self.decision_history]),
              'recent_decisions': [
                  {
                      'provider': d.selected_provider,
                      'latency_ms': d.estimated_latency_ms,
                      'cost': d.estimated_cost,
                      'confidence': d.confidence_score,
                      'user_location': d.user_location
                  }
                  for d in list(self.decision_history)[-10:]
              ]
          }

  # Example usage
  async def main():
      """Example usage of the latency arbitrage engine"""
      
      async with FreeAPIIntegrator() as integrator:
          engine = LatencyArbitrageEngine()
          
          # Test with different user locations
          test_ips = [
              '8.8.8.8',  # Google (US)
              '1.1.1.1',  # Cloudflare (US)
              '208.67.222.222',  # OpenDNS (US)
              '9.9.9.9',  # Quad9 (US)
          ]
          
          logging.info("Latency Arbitrage Analysis:")
          logging.info("=" * 50)
          
          for ip in test_ips:
              logging.info(f"\nAnalyzing request from {ip}:")
              
              decision = await engine.analyze_request_arbitrage(
                  user_ip=ip,
                  model_name="llama-2-7b",
                  max_latency_ms=200.0,
                  max_cost_per_request=0.01
              )
              
              logging.info(f"  Selected Provider: {decision.selected_provider}")
              logging.info(f"  Edge Location: {decision.edge_location}")
              logging.info(f"  Estimated Latency: {decision.estimated_latency_ms:.1f}ms")
              logging.info(f"  Cost per Request: ${decision.estimated_cost:.4f}")
              logging.info(f"  Confidence: {decision.confidence_score:.1%}")
              logging.info(f"  User Location: {decision.user_location}")
              logging.info(f"  Reasoning: {'; '.join(decision.reasoning[:2])
          
          # Get statistics
          stats = engine.get_arbitrage_stats()
          logging.info(f"\nArbitrage Statistics:")
          logging.info(f"  Total Requests: {stats.get('total_requests', 0)
          logging.info(f"  Provider Distribution: {stats.get('provider_distribution', {})
          logging.info(f"  Avg Latency Savings: {stats.get('avg_latency_savings_ms', 0)
          logging.info(f"  Avg Cost Savings: ${stats.get('avg_cost_savings', 0)
          logging.info(f"  Avg Confidence: {stats.get('avg_confidence_score', 0)

  if __name__ == "__main__":
      asyncio.run(main())
  EOT
}
