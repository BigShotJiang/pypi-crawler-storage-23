#!/usr/bin/env python3
"""
Enhanced Arbitrage Engine with Price Volatility Modeling
Real-time volatility tracking, prediction, and risk-adjusted pricing
"""

import asyncio
import aiohttp
import json
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, NamedTuple
from dataclasses import dataclass
from enum import Enum
import statistics
import numpy as np
from collections import deque

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class PricePoint:
    """Historical price point for volatility calculation"""
    timestamp: datetime
    price: float
    provider: str
    instance_type: str
    volume: int  # Available capacity
    market_conditions: str  # "high_demand", "low_demand", "normal"

@dataclass
class VolatilityMetrics:
    """Volatility metrics for pricing decisions"""
    current_volatility: float  # Current volatility index (0-1)
    historical_volatility: float  # 30-day average
    volatility_trend: str  # "increasing", "decreasing", "stable"
    price_momentum: float  # Price change momentum
    demand_pressure: float  # Current demand pressure (0-1)
    forecast_volatility: float  # Predicted near-term volatility
    confidence_interval: Tuple[float, float]  # 95% confidence interval

@dataclass
class VolatilityAdjustedOpportunity:
    """Arbitrage opportunity with volatility adjustments"""
    provider: str
    instance_type: str
    current_price: float
    expected_price_range: Tuple[float, float]  # Min/max expected price
    volatility_adjusted_savings: float
    volatility_risk_score: float  # 0-1, higher = more risky
    optimal_timing_score: float  # 0-1, when to execute
    holding_period_recommendation: str  # "immediate", "wait", "avoid"
    volatility_reasoning: List[str]

class PriceVolatilityEngine:
    """
    Price volatility modeling engine
    Tracks, predicts, and factors volatility into arbitrage decisions
    """
    
# TODO: REFACTOR - __init__() is 54 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def __init__(self):
        self.price_history = {}  # (provider, instance_type) -> deque[PricePoint]
        self.volatility_cache = {}
        self.market_sentiment = {}
        
        # Volatility calculation parameters
        self.volatility_window = 30  # days
        self.min_data_points = 10  # minimum points for calculation
        self.update_frequency = 300  # seconds (5 minutes)
        
        # Provider-specific volatility characteristics
        self.provider_volatility_profiles = {
            'aws': {
                'base_volatility': 0.15,  # 15% base volatility
                'demand_sensitivity': 0.8,  # High sensitivity to demand
                'price_momentum_factor': 0.7,
                'forecast_accuracy': 0.75
            },
            'gcp': {
                'base_volatility': 0.12,
                'demand_sensitivity': 0.7,
                'price_momentum_factor': 0.6,
                'forecast_accuracy': 0.80
            },
            'azure': {
                'base_volatility': 0.18,
                'demand_sensitivity': 0.85,
                'price_momentum_factor': 0.8,
                'forecast_accuracy': 0.70
            },
            'runpod': {
                'base_volatility': 0.25,  # Higher volatility for specialist providers
                'demand_sensitivity': 0.9,
                'price_momentum_factor': 0.85,
                'forecast_accuracy': 0.65
            },
            'lambda': {
                'base_volatility': 0.22,
                'demand_sensitivity': 0.85,
                'price_momentum_factor': 0.8,
                'forecast_accuracy': 0.68
            },
            'coreweave': {
                'base_volatility': 0.20,
                'demand_sensitivity': 0.8,
                'price_momentum_factor': 0.75,
                'forecast_accuracy': 0.72
            },
            'huggingface': {
                'base_volatility': 0.05,  # Very stable pricing
                'demand_sensitivity': 0.3,
                'price_momentum_factor': 0.2,
                'forecast_accuracy': 0.90
            }
        }
    
    async def update_price_data(self, provider: str, instance_type: str, 
                              current_price: float, volume: int, 
                              market_conditions: str = "normal"):
        """Update price data for volatility calculation"""
        
        key = (provider, instance_type)
        
        if key not in self.price_history:
            self.price_history[key] = deque(maxlen=self.volatility_window * 24)  # Hourly data
        
        price_point = PricePoint(
            timestamp=datetime.now(),
            price=current_price,
            provider=provider,
            instance_type=instance_type,
            volume=volume,
            market_conditions=market_conditions
        )
        
        self.price_history[key].append(price_point)
        
        # Update volatility metrics
        if len(self.price_history[key]) >= self.min_data_points:
# TODO: REFACTOR - _calculate_volatility_metrics() is 84 lines long (should be <50)
# Consider breaking into smaller, focused functions
            self.volatility_cache[key] = self._calculate_volatility_metrics(key)
    
    def _calculate_volatility_metrics(self, key: Tuple[str, str]) -> VolatilityMetrics:
        """Calculate comprehensive volatility metrics"""
        
        price_points = list(self.price_history[key])
        provider = key[0]
        
        # Extract price series
        prices = [p.price for p in price_points]
        timestamps = [p.timestamp for p in price_points]
        
        # Calculate historical volatility (standard deviation of returns)
        returns = []
        for i in range(1, len(prices)):
            return_rate = (prices[i] - prices[i-1]) / prices[i-1]
            returns.append(return_rate)
        
        historical_volatility = statistics.stdev(returns) if returns else 0.0
        
        # Calculate current volatility (recent 24h)
        recent_prices = prices[-24:] if len(prices) >= 24 else prices
        recent_returns = []
        for i in range(1, len(recent_prices)):
            return_rate = (recent_prices[i] - recent_prices[i-1]) / recent_prices[i-1]
            recent_returns.append(return_rate)
        
        current_volatility = statistics.stdev(recent_returns) if recent_returns else historical_volatility
        
        # Calculate volatility trend
        if len(recent_returns) >= 10:
            recent_vol = statistics.stdev(recent_returns[-10:])
            older_vol = statistics.stdev(recent_returns[-20:-10]) if len(recent_returns) >= 20 else recent_vol
            
            if recent_vol > older_vol * 1.2:
                volatility_trend = "increasing"
            elif recent_vol < older_vol * 0.8:
                volatility_trend = "decreasing"
            else:
                volatility_trend = "stable"
        else:
            volatility_trend = "stable"
        
        # Calculate price momentum
        if len(prices) >= 5:
            price_momentum = (prices[-1] - prices[-5]) / prices[-5]
        else:
            price_momentum = 0.0
        
        # Calculate demand pressure (inverse of volume trend)
        volumes = [p.volume for p in price_points[-24:]] if len(price_points) >= 24 else [p.volume for p in price_points]
        if len(volumes) >= 2:
            volume_trend = (volumes[-1] - volumes[0]) / volumes[0]
            demand_pressure = max(0.0, min(1.0, -volume_trend))  # Inverse: decreasing volume = higher demand
        else:
            demand_pressure = 0.5
        
        # Forecast near-term volatility
        profile = self.provider_volatility_profiles.get(provider, self.provider_volatility_profiles['aws'])
        
        # Combine factors for forecast
        forecast_volatility = (
            profile['base_volatility'] * 0.3 +
            current_volatility * 0.4 +
            demand_pressure * 0.2 +
            abs(price_momentum) * 0.1
        )
        
        # Calculate confidence interval (95% CI)
        mean_price = statistics.mean(prices)
        std_error = statistics.stdev(prices) / len(prices) ** 0.5
        margin_of_error = 1.96 * std_error  # 95% CI
        
        confidence_interval = (
            max(0.01, mean_price - margin_of_error),
            mean_price + margin_of_error
        )
        
        return VolatilityMetrics(
            current_volatility=current_volatility,
            historical_volatility=historical_volatility,
            volatility_trend=volatility_trend,
            price_momentum=price_momentum,
            demand_pressure=demand_pressure,
# TODO: REFACTOR - calculate_volatility_adjusted_opportunity() is 62 lines long (should be <50)
# Consider breaking into smaller, focused functions
            forecast_volatility=forecast_volatility,
            confidence_interval=confidence_interval
        )
    
    def calculate_volatility_adjusted_opportunity(self, 
                                                provider: str,
                                                instance_type: str,
                                                current_price: float,
                                                baseline_price: float,
                                                job_duration_hours: float) -> VolatilityAdjustedOpportunity:
        """Calculate arbitrage opportunity with volatility adjustments"""
        
        key = (provider, instance_type)
        
        # Get volatility metrics
        if key in self.volatility_cache:
            volatility_metrics = self.volatility_cache[key]
        else:
            # Use provider defaults if no historical data
            profile = self.provider_volatility_profiles.get(provider, self.provider_volatility_profiles['aws'])
            volatility_metrics = VolatilityMetrics(
                current_volatility=profile['base_volatility'],
                historical_volatility=profile['base_volatility'],
                volatility_trend="stable",
                price_momentum=0.0,
                demand_pressure=0.5,
                forecast_volatility=profile['base_volatility'],
                confidence_interval=(current_price * 0.9, current_price * 1.1)
            )
        
        # Calculate expected price range
        price_range_volatility = volatility_metrics.forecast_volatility
        expected_min = current_price * (1 - price_range_volatility)
        expected_max = current_price * (1 + price_range_volatility)
        
        # Calculate volatility risk score (0-1, higher = more risky)
        volatility_risk = min(1.0, volatility_metrics.forecast_volatility * 2)
        
        # Adjust savings for volatility
        nominal_savings = baseline_price - current_price
        volatility_adjustment_factor = 1.0 - (volatility_risk * 0.5)  # Reduce savings by up to 50% for high volatility
        volatility_adjusted_savings = nominal_savings * volatility_adjustment_factor
        
        # Calculate optimal timing score
        timing_score = self._calculate_timing_score(volatility_metrics, job_duration_hours)
        
        # Determine holding period recommendation
        holding_recommendation = self._calculate_holding_recommendation(
            volatility_metrics, timing_score, job_duration_hours
        )
        
        # Generate volatility reasoning
        reasoning = self._generate_volatility_reasoning(
            volatility_metrics, volatility_risk, timing_score, holding_recommendation
        )
        
        return VolatilityAdjustedOpportunity(
            provider=provider,
            instance_type=instance_type,
            current_price=current_price,
            expected_price_range=(expected_min, expected_max),
            volatility_adjusted_savings=volatility_adjusted_savings,
            volatility_risk_score=volatility_risk,
            optimal_timing_score=timing_score,
            holding_period_recommendation=holding_recommendation,
            volatility_reasoning=reasoning
        )
    
    def _calculate_timing_score(self, metrics: VolatilityMetrics, job_duration_hours: float) -> float:
        """Calculate optimal timing score (0-1, higher = better timing)"""
        
        score = 0.5  # Base score
        
        # Adjust for volatility trend
        if metrics.volatility_trend == "decreasing":
            score += 0.3  # Good timing - prices stabilizing
        elif metrics.volatility_trend == "stable":
            score += 0.1  # Neutral timing
        else:  # increasing
            score -= 0.2  # Poor timing - prices volatile
        
        # Adjust for price momentum
        if metrics.price_momentum < -0.05:  # Prices dropping
            score += 0.2  # Good timing
        elif metrics.price_momentum > 0.05:  # Prices rising
            score -= 0.2  # Poor timing
        
        # Adjust for demand pressure
        if metrics.demand_pressure < 0.3:  # Low demand
            score += 0.1  # Good timing
        elif metrics.demand_pressure > 0.7:  # High demand
            score -= 0.1  # Poor timing
        
        # Adjust for job duration
        if job_duration_hours < 2:  # Short jobs
            score += 0.1  # Can tolerate more volatility
        elif job_duration_hours > 8:  # Long jobs
            score -= 0.1  # Need stability
        
        return max(0.0, min(1.0, score))
    
    def _calculate_holding_recommendation(self, 
                                         metrics: VolatilityMetrics,
                                         timing_score: float,
                                         job_duration_hours: float) -> str:
        """Calculate when to execute the arbitrage"""
        
        # High volatility + poor timing = wait
        if metrics.forecast_volatility > 0.3 and timing_score < 0.3:
            return "wait"
        
        # Low volatility + good timing = immediate
        if metrics.forecast_volatility < 0.1 and timing_score > 0.7:
            return "immediate"
        
        # Extreme volatility = avoid
# TODO: REFACTOR - _generate_volatility_reasoning() is 53 lines long (should be <50)
# Consider breaking into smaller, focused functions
        if metrics.forecast_volatility > 0.5:
            return "avoid"
        
        # Moderate conditions = immediate with caution
        return "immediate"
    
    def _generate_volatility_reasoning(self, 
                                       metrics: VolatilityMetrics,
                                       risk_score: float,
                                       timing_score: float,
                                       recommendation: str) -> List[str]:
        """Generate human-readable volatility reasoning"""
        
        reasoning = []
        
        # Volatility level
        if metrics.forecast_volatility < 0.1:
            reasoning.append("Very low volatility - prices are stable")
        elif metrics.forecast_volatility < 0.2:
            reasoning.append("Low volatility - minimal price fluctuation expected")
        elif metrics.forecast_volatility < 0.3:
            reasoning.append("Moderate volatility - some price fluctuation expected")
        else:
            reasoning.append("High volatility - significant price fluctuation expected")
        
        # Trend analysis
        if metrics.volatility_trend == "decreasing":
            reasoning.append("Volatility is decreasing - market stabilizing")
        elif metrics.volatility_trend == "increasing":
            reasoning.append("Volatility is increasing - market becoming more uncertain")
        
        # Price momentum
        if metrics.price_momentum < -0.05:
            reasoning.append("Negative price momentum - prices trending downward")
        elif metrics.price_momentum > 0.05:
            reasoning.append("Positive price momentum - prices trending upward")
        
        # Demand pressure
        if metrics.demand_pressure > 0.7:
            reasoning.append("High demand pressure - prices may increase")
        elif metrics.demand_pressure < 0.3:
            reasoning.append("Low demand pressure - prices may decrease")
        
        # Risk assessment
        if risk_score < 0.3:
            reasoning.append("Low volatility risk - safe for arbitrage")
        elif risk_score < 0.7:
            reasoning.append("Moderate volatility risk - proceed with caution")
        else:
            reasoning.append("High volatility risk - consider waiting")
        
        # Recommendation reasoning
        if recommendation == "immediate":
            reasoning.append("Good timing for immediate execution")
        elif recommendation == "wait":
            reasoning.append("Consider waiting for more stable conditions")
        else:
            reasoning.append("Avoid due to high volatility risk")
        
        return reasoning
    
    def get_market_volatility_summary(self) -> Dict:
        """Get overall market volatility summary"""
        
        if not self.volatility_cache:
            return {"error": "No volatility data available"}
        
        # Aggregate volatility across all providers
        all_volatilities = [m.forecast_volatility for m in self.volatility_cache.values()]
        
        # Calculate market-wide metrics
        market_volatility = statistics.mean(all_volatilities)
        volatility_spread = max(all_volatilities) - min(all_volatilities)
        
        # Count providers by volatility level
        low_vol_providers = len([v for v in all_volatilities if v < 0.1])
        moderate_vol_providers = len([v for v in all_volatilities if 0.1 <= v < 0.3])
        high_vol_providers = len([v for v in all_volatilities if v >= 0.3])
        
        return {
            "market_volatility": market_volatility,
            "volatility_spread": volatility_spread,
            "low_volatility_providers": low_vol_providers,
            "moderate_volatility_providers": moderate_vol_providers,
            "high_volatility_providers": high_vol_providers,
            "total_providers_tracked": len(all_volatilities),
            "last_updated": datetime.now().isoformat()
        }

# CLI interface for volatility testing
async def main():
    """CLI interface for price volatility engine"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Price Volatility Engine')
    parser.add_argument('--simulate', action='store_true', help='Simulate price volatility')
    parser.add_argument('--analyze', action='store_true', help='Analyze volatility-adjusted opportunity')
    parser.add_argument('--provider', default='runpod', help='Provider to analyze')
    parser.add_argument('--instance', default='A100 40GB', help='Instance type')
    parser.add_argument('--current-price', type=float, default=2.20, help='Current price')
    parser.add_argument('--baseline-price', type=float, default=3.50, help='Baseline price')
    parser.add_argument('--job-duration', type=float, default=4.0, help='Job duration in hours')
    parser.add_argument('--market-summary', action='store_true', help='Get market volatility summary')
    
    args = parser.parse_args()
    
    engine = PriceVolatilityEngine()
    
    if args.simulate:
        # Simulate price volatility over time
        logging.info("🔄 Simulating price volatility...")
        
        provider = args.provider
        instance = args.instance
        base_price = args.current_price
        
        # Simulate 30 days of price data
        for day in range(30):
            # Add some randomness to simulate real volatility
            volatility_factor = 0.1 * (1 + 0.5 * np.sin(day * 0.5))  # Sinusoidal volatility
            price_change = np.random.normal(0, volatility_factor)
            current_price = base_price * (1 + price_change)
            
            # Simulate volume changes
            volume = int(100 + 50 * np.sin(day * 0.3))
            
            # Determine market conditions
            if price_change > 0.05:
                market_conditions = "high_demand"
            elif price_change < -0.05:
                market_conditions = "low_demand"
            else:
                market_conditions = "normal"
            
            await engine.update_price_data(provider, instance, current_price, volume, market_conditions)
        
        logging.info(f"✅ Simulated 30 days of price data for {provider}/{instance}")
        
        # Show volatility metrics
        key = (provider, instance)
        if key in engine.volatility_cache:
            metrics = engine.volatility_cache[key]
            logging.info(f"\n📊 Volatility Metrics for {provider}/{instance}:")
            logging.info(f"Current Volatility: {metrics.current_volatility:.3f}")
            logging.info(f"Historical Volatility: {metrics.historical_volatility:.3f}")
            logging.info(f"Volatility Trend: {metrics.volatility_trend}")
            logging.info(f"Price Momentum: {metrics.price_momentum:.3f}")
            logging.info(f"Demand Pressure: {metrics.demand_pressure:.3f}")
            logging.info(f"Forecast Volatility: {metrics.forecast_volatility:.3f}")
            logging.info(f"95% Confidence Interval: ${metrics.confidence_interval[0]:.2f} - ${metrics.confidence_interval[1]:.2f}")
    
    elif args.analyze:
        # Analyze volatility-adjusted opportunity
        opportunity = engine.calculate_volatility_adjusted_opportunity(
            args.provider, args.instance, args.current_price, args.baseline_price, args.job_duration
        )
        
        logging.info("🎯 VOLATILITY-ADJUSTED ARBITRAGE ANALYSIS:")
        logging.info(f"Provider: {opportunity.provider}")
        logging.info(f"Instance: {opportunity.instance_type}")
        logging.info(f"Current Price: ${opportunity.current_price:.2f}")
        logging.info(f"Expected Price Range: ${opportunity.expected_price_range[0]:.2f} - ${opportunity.expected_price_range[1]:.2f}")
        logging.info(f"Nominal Savings: ${args.baseline_price - args.current_price:.2f}")
        logging.info(f"Volatility-Adjusted Savings: ${opportunity.volatility_adjusted_savings:.2f}")
        logging.info(f"Volatility Risk Score: {opportunity.volatility_risk_score:.3f}")
        logging.info(f"Optimal Timing Score: {opportunity.optimal_timing_score:.3f}")
        logging.info(f"Recommendation: {opportunity.holding_period_recommendation}")
        
        logging.info(f"\n📊 Volatility Reasoning:")
        for reason in opportunity.volatility_reasoning:
            logging.info(f"• {reason}")
    
    elif args.market_summary:
        # Get market volatility summary
        summary = engine.get_market_volatility_summary()
        
        logging.info("🌍 MARKET VOLATILITY SUMMARY:")
        logging.info(f"Market Volatility: {summary['market_volatility']:.3f}")
        logging.info(f"Volatility Spread: {summary['volatility_spread']:.3f}")
        logging.info(f"Low Volatility Providers: {summary['low_volatility_providers']}")
        logging.info(f"Moderate Volatility Providers: {summary['moderate_volatility_providers']}")
        logging.info(f"High Volatility Providers: {summary['high_volatility_providers']}")
        logging.info(f"Total Providers Tracked: {summary['total_providers_tracked']}")
        logging.info(f"Last Updated: {summary['last_updated']}")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    asyncio.run(main())
