# 🛡️ Terradev Data Governance Framework

Comprehensive data governance system with explicit consent, comprehensive logging, and OPA policy enforcement for data movement.

---

## 🎯 **Overview**

Terradev's data governance framework ensures **compliance, transparency, and control** over all data movement operations through:

- **🔐 Explicit User Consent** - Required for all data movements
- **📊 Comprehensive Logging** - Complete audit trail of all operations
- **🛡️ OPA Policy Enforcement** - Automated policy compliance
- **🌍 Residency Constraints** - Geographic data residency rules
- **📋 Classification Controls** - Data sensitivity-based restrictions

---

## 🔐 **Explicit User Consent System**

### **Consent Types**
```python
class ConsentType(Enum):
    DATASET_STAGING = "dataset_staging"
    CROSS_REGION = "cross_region"
    CROSS_PROVIDER = "cross_provider"
    AUTOMATED_OPTIMIZATION = "automated_optimization"
    EMERGENCY_MIGRATION = "emergency_migration"
```

### **Consent Workflow**
1. **Request Generation** - System creates detailed consent request
2. **User Notification** - User receives consent request via email/push
3. **Explicit Approval** - User must explicitly approve data movement
4. **Location Selection** - User can approve specific target locations
5. **Conditional Approval** - User can set conditions on movement
6. **Expiration Management** - Consent expires after specified time

### **Consent Request Structure**
```python
@dataclass
class ConsentRequest:
    request_id: str
    user_id: str
    consent_type: ConsentType
    movement_type: DataMovementType
    dataset_name: str
    dataset_hash: str
    source_location: str
    target_locations: List[str]
    reason: str
    urgency: str  # low, medium, high, emergency
    expires_at: datetime
    metadata: Dict[str, Any]
```

### **Usage Example**
```python
# Request consent for dataset staging
consent_id = await governance_manager.request_consent(
    user_id="user_123",
    consent_type=ConsentType.DATASET_STAGING,
    movement_type=DataMovementType.INITIAL_STAGING,
    dataset_name="ml_training_data",
    source_location="s3://source-bucket/data",
    target_locations=["s3://us-east-1-target/data", "s3://eu-west-1-target/data"],
    reason="Optimize for ML training regions",
    urgency="medium",
    expires_hours=24
)

# User approves consent (via UI/API)
await governance_manager.record_consent_response(
    request_id=consent_id,
    user_id="user_123",
    status=ConsentStatus.APPROVED,
    approved_locations=["s3://us-east-1-target/data"],
    conditions=["Only for ML training workloads"]
)
```

---

## 📊 **Comprehensive Logging System**

### **Logging Categories**

#### **1. 📋 Consent Logging**
- **Consent Requests**: All consent requests with full metadata
- **Consent Responses**: User approvals/denials with reasons
- **Consent Expiration**: Automatic expiration notifications
- **Consent Revocation**: User-initiated consent withdrawals

#### **2. 🚚 Data Movement Logging**
```python
@dataclass
class DataMovementLog:
    movement_id: str
    request_id: str
    user_id: str
    timestamp: datetime
    movement_type: DataMovementType
    dataset_name: str
    dataset_hash: str
    source_location: str
    target_location: str
    file_count: int
    total_size_bytes: int
    transfer_time_seconds: float
    transfer_cost_usd: float
    reason: str
    consent_id: str
    opa_policy_id: str
    policy_result: str
    success: bool
    error_message: Optional[str]
    metadata: Dict[str, Any]
```

#### **3. 🛡️ Policy Evaluation Logging**
- **OPA Evaluations**: All policy decisions with input data
- **Policy Results**: Allow/deny decisions with reasons
- **Policy Conditions**: Any conditional requirements
- **Policy Exceptions**: Emergency or override situations

### **Log Structure**
```json
{
  "type": "data_movement",
  "timestamp": "2026-02-09T16:30:00Z",
  "data": {
    "movement_id": "mov_123456",
    "user_id": "user_123",
    "dataset_name": "ml_training_data",
    "source_location": "s3://source-bucket/data",
    "target_location": "s3://us-east-1-target/data",
    "reason": "Region optimization for ML training",
    "consent_id": "consent_789",
    "policy_result": "allowed",
    "success": true,
    "transfer_cost_usd": 12.50
  }
}
```

### **Audit Trail Features**
- **Immutable Records**: Once logged, records cannot be modified
- **Complete Chain**: From consent request to completion
- **Retention Policy**: 7-year retention for compliance
- **Export Capability**: JSON/CSV export for audits
- **Search and Filter**: By user, dataset, date range, location

---

## 🛡️ **OPA Policy Enforcement**

### **Policy Categories**

#### **1. 🌍 Region Allowlist Policy**
```rego
package data.governance

allow {
    input.movement.type != "emergency_migration"
    is_region_allowed(input.dataset.target_location)
}

is_region_allowed(target_location) {
    region := extract_region(target_location)
    allowed_regions := data.terradev.config.allowed_regions
    region in allowed_regions
}
```

**Configuration:**
```json
{
  "allowed_regions": [
    "us-east-1", "us-west-2", "eu-west-1", "eu-central-1"
  ],
  "exceptions": ["emergency_migration"]
}
```

#### **2. ☁️ Provider Allowlist Policy**
```rego
allow {
    input.movement.type != "compliance_migration"
    is_provider_allowed(input.dataset.target_location)
}

is_provider_allowed(target_location) {
    provider := extract_provider(target_location)
    allowed_providers := data.terradev.config.allowed_providers
    provider in allowed_providers
}
```

**Configuration:**
```json
{
  "allowed_providers": [
    "aws", "gcp", "azure", "runpod", "vastai"
  ],
  "exceptions": ["compliance_migration"]
}
```

#### **3. 🏛️ Residency Constraints Policy**
```rego
allow {
    input.movement.type != "emergency_relocation"
    satisfies_residency(input.user.location, input.dataset.target_location)
}

satisfies_residency(user_location, target_location) {
    target_region := extract_region(target_location)
    residency_rules := data.terradev.config.residency_rules
    rule := residency_rules[user_location]
    target_region in rule.allowed_regions
}
```

**Configuration:**
```json
{
  "residency_rules": {
    "US": {
      "allowed_regions": ["us-east-1", "us-west-2", "us-central-1"],
      "description": "US data must remain in US regions"
    },
    "EU": {
      "allowed_regions": ["eu-west-1", "eu-central-1", "eu-north-1"],
      "description": "EU data must remain in EU regions"
    }
  }
}
```

#### **4. 📊 Data Classification Policy**
```rego
allow {
    classification := input.dataset.classification
    classification_rules := data.terradev.config.classification_rules
    rule := classification_rules[classification]
    
    input.movement.type in rule.allowed_movement_types
    is_location_allowed_for_classification(input.dataset.target_location, rule)
}
```

**Configuration:**
```json
{
  "classification_rules": {
    "public": {
      "allowed_movement_types": ["all"],
      "allowed_providers": ["aws", "gcp", "azure", "runpod", "vastai"],
      "allowed_regions": ["all"]
    },
    "confidential": {
      "allowed_movement_types": ["initial_staging", "region_optimization"],
      "allowed_providers": ["aws", "gcp", "azure"],
      "allowed_regions": ["us-east-1", "us-west-2", "eu-west-1"]
    },
    "restricted": {
      "allowed_movement_types": ["compliance_migration"],
      "allowed_providers": ["aws", "gcp"],
      "allowed_regions": ["us-east-1", "eu-west-1"]
    }
  }
}
```

---

## 🔄 **Complete Data Movement Workflow**

### **Step-by-Step Process**

#### **1. 📋 Consent Request**
```python
# User initiates data movement
consent_id = await governance_manager.request_consent(
    user_id="user_123",
    consent_type=ConsentType.CROSS_REGION,
    movement_type=DataMovementType.REGION_OPTIMIZATION,
    dataset_name="customer_data",
    source_location="s3://us-east-1-data/customers",
    target_locations=["s3://eu-west-1-data/customers"],
    reason="Optimize for European users",
    urgency="medium"
)
```

#### **2. 🔐 User Approval**
```python
# User receives notification and approves
await governance_manager.record_consent_response(
    request_id=consent_id,
    user_id="user_123",
    status=ConsentStatus.APPROVED,
    approved_locations=["s3://eu-west-1-data/customers"],
    conditions=["Only for EU customer queries"]
)
```

#### **3. 🛡️ Policy Evaluation**
```python
# System evaluates OPA policies
opa_result = await governance_manager.evaluate_opa_policies(
    user_id="user_123",
    dataset_name="customer_data",
    source_location="s3://us-east-1-data/customers",
    target_location="s3://eu-west-1-data/customers",
    movement_type=DataMovementType.REGION_OPTIMIZATION
)
```

#### **4. 🚚 Data Movement**
```python
# Execute data movement with governance
movement_log = await governance_manager.move_data_with_governance(
    user_id="user_123",
    consent_request_id=consent_id,
    dataset_name="customer_data",
    source_location="s3://us-east-1-data/customers",
    target_location="s3://eu-west-1-data/customers",
    movement_type=DataMovementType.REGION_OPTIMIZATION
)
```

#### **5. 📊 Logging and Audit**
```python
# Complete audit trail created automatically
# - Consent request and response logged
# - OPA policy evaluation logged
# - Data movement details logged
# - Success/failure status logged
# - Cost and performance metrics logged
```

---

## 📈 **Compliance Reporting**

### **Automated Reports**
```python
# Generate compliance report
report = await governance_manager.generate_compliance_report(
    start_date=datetime(2026, 1, 1),
    end_date=datetime(2026, 2, 1)
)
```

### **Report Contents**
- **Summary Statistics**: Total movements, success rates, costs
- **Movement by Type**: Breakdown by movement type
- **Movement by User**: Per-user activity summary
- **Policy Compliance**: OPA evaluation results
- **Consent Coverage**: Consent request/response metrics
- **Geographic Distribution**: Data movement by region
- **Cost Analysis**: Transfer costs and optimization savings

### **Sample Report Output**
```json
{
  "report_period": {
    "start_date": "2026-01-01T00:00:00Z",
    "end_date": "2026-02-01T00:00:00Z"
  },
  "summary": {
    "total_movements": 156,
    "successful_movements": 148,
    "failed_movements": 8,
    "success_rate": 0.949,
    "total_size_gb": 2450.7,
    "total_cost_usd": 1225.35
  },
  "opa_policy_evaluations": {
    "total_evaluations": 156,
    "allowed_evaluations": 148,
    "denied_evaluations": 8,
    "allowance_rate": 0.949
  },
  "compliance_metrics": {
    "consent_coverage": 156,
    "policy_compliance_rate": 0.949,
    "audit_trail_complete": true
  }
}
```

---

## 🚨 **Emergency Handling**

### **Emergency Exceptions**
- **Emergency Migration**: Bypass region restrictions
- **Emergency Relocation**: Bypass residency constraints
- **Compliance Migration**: Bypass provider restrictions
- **Required Permissions**: User must have emergency permissions

### **Emergency Workflow**
```python
# Emergency data movement (requires special permissions)
if urgency == "emergency" and "emergency_data_movement" in user_permissions:
    # Bypass normal policy checks
    # Log emergency reason
    # Require post-emergency audit
    pass
```

---

## 🔧 **Configuration and Setup**

### **Governance Configuration**
```python
# Initialize governance manager
governance_manager = DataGovernanceManager(config, auth)

# Configure OPA policies
governance_manager.configure_opa_policies({
    "allowed_regions": ["us-east-1", "us-west-2", "eu-west-1"],
    "allowed_providers": ["aws", "gcp", "azure"],
    "residency_rules": {
        "US": {"allowed_regions": ["us-east-1", "us-west-2"]},
        "EU": {"allowed_regions": ["eu-west-1", "eu-central-1"]}
    },
    "classification_rules": {
        "public": {"allowed_movement_types": ["all"]},
        "confidential": {"allowed_movement_types": ["initial_staging"]}
    }
})
```

### **Integration with CLI**
```bash
# Request consent for data staging
terradev stage --dataset customer_data \
  --source s3://us-east-1-data \
  --target-regions eu-west-1 us-west-2 \
  --require-consent

# Check consent status
terradev governance consent-status --request-id consent_123

# View movement history
terradev governance history --user user_123 --days 30

# Generate compliance report
terradev governance report --start-date 2026-01-01 --end-date 2026-02-01
```

---

## 🎯 **Key Benefits**

### **🛡️ Compliance Assurance**
- **GDPR Compliance**: Data residency and consent requirements
- **SOC2 Compliance**: Complete audit trail and access controls
- **HIPAA Compliance**: Data classification and movement restrictions
- **Industry Standards**: Follows data governance best practices

### **🔐 Security Enhancement**
- **Explicit Consent**: No data movement without user approval
- **Policy Enforcement**: Automated compliance checking
- **Complete Audit Trail**: Immutable logging of all operations
- **Access Control**: Role-based permissions for data operations

### **📊 Transparency and Control**
- **User Visibility**: Clear view of all data movements
- **Granular Control**: Approve specific locations and conditions
- **Real-time Monitoring**: Live tracking of data movements
- **Detailed Reporting**: Comprehensive compliance reports

---

## 🎉 **Summary**

Terradev's data governance framework provides:

- **🔐 Explicit Consent**: Required for all data movements
- **📊 Comprehensive Logging**: Complete audit trail with full context
- **🛡️ OPA Policy Enforcement**: Automated compliance checking
- **🌍 Residency Constraints**: Geographic data residency rules
- **📋 Classification Controls**: Sensitivity-based restrictions
- **🚨 Emergency Handling**: Controlled exceptions for urgent situations
- **📈 Compliance Reporting**: Automated audit and compliance reports

**Result**: Complete control and visibility over data movement with regulatory compliance and user trust.

---

**🛡️ Terradev Data Governance - Ensuring compliance, transparency, and control for all data operations!**
