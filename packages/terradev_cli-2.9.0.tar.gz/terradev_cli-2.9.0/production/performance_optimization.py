#!/usr/bin/env python3
"""
Production Performance Optimization
Async HTTP clients, connection pooling, and performance monitoring
"""

import asyncio
import aiohttp
import asyncpg
import redis
import time
import logging
import json
import psutil
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from contextlib import asynccontextmanager
import statistics
import weakref
from functools import wraps
import hashlib
import threading
from concurrent.futures import ThreadPoolExecutor
import uvloop

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class PerformanceMetrics:
    """Performance metrics tracking"""
    endpoint: str
    method: str
    response_time: float
    status_code: int
    timestamp: datetime
    request_size: int
    response_size: int
    error: Optional[str] = None

@dataclass
class ConnectionPoolMetrics:
    """Connection pool metrics"""
    pool_name: str
    total_connections: int
    active_connections: int
    idle_connections: int
    waiting_connections: int
    timestamp: datetime

class AsyncHTTPClient:
    """Production-ready async HTTP client with connection pooling"""
    
    def __init__(self, base_url: str = None, timeout: int = 30, max_connections: int = 100):
        self.base_url = base_url
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.max_connections = max_connections
        self.session = None
        self.metrics: List[PerformanceMetrics] = []
        self._lock = threading.Lock()
        
        # Connection pool configuration
        self.connector = aiohttp.TCPConnector(
            limit=max_connections,
            limit_per_host=max_connections // 4,
            ttl_dns_cache=300,
            use_dns_cache=True,
            keepalive_timeout=30,
            enable_cleanup_closed=True
        )
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self._ensure_session()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()
    
    async def _ensure_session(self):
        """Ensure session is created"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                connector=self.connector,
                timeout=self.timeout,
                headers={
                    "User-Agent": "Terradev/1.0 (Production)",
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                }
            )
    
    async def close(self):
        """Close HTTP session"""
        if self.session and not self.session.closed:
            await self.session.close()
    
    async def get(self, url: str, **kwargs) -> Dict[str, Any]:
        """GET request with performance tracking"""
        return await self._request("GET", url, **kwargs)
    
    async def post(self, url: str, **kwargs) -> Dict[str, Any]:
        """POST request with performance tracking"""
        return await self._request("POST", url, **kwargs)
    
    async def put(self, url: str, **kwargs) -> Dict[str, Any]:
        """PUT request with performance tracking"""
        return await self._request("PUT", url, **kwargs)
    
    async def delete(self, url: str, **kwargs) -> Dict[str, Any]:
        """DELETE request with performance tracking"""
        return await self._request("DELETE", url, **kwargs)
    
    async def _request(self, method: str, url: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request with performance tracking"""
        await self._ensure_session()
        
        # Full URL construction
        if self.base_url and not url.startswith('http'):
            url = f"{self.base_url.rstrip('/')}/{url.lstrip('/')}"
        
        start_time = time.time()
        request_size = len(str(kwargs.get('json', {})).encode())
        
        try:
            async with self.session.request(method, url, **kwargs) as response:
                response_time = time.time() - start_time
                response_size = len(await response.read())
                status_code = response.status
                
                # Track metrics
                self._track_metrics(
                    endpoint=url,
                    method=method,
                    response_time=response_time,
                    status_code=status_code,
                    request_size=request_size,
                    response_size=response_size
                )
                
                # Raise for error status codes
                response.raise_for_status()
                
                return {
                    "status": status_code,
                    "data": await response.json(),
                    "headers": dict(response.headers),
                    "response_time": response_time
                }
                
        except Exception as e:
            response_time = time.time() - start_time
            
            # Track error metrics
            self._track_metrics(
                endpoint=url,
                method=method,
                response_time=response_time,
                status_code=500,
                request_size=request_size,
                response_size=0,
                error=str(e)
            )
            
            raise
    
    def _track_metrics(self, endpoint: str, method: str, response_time: float, 
                       status_code: int, request_size: int, response_size: int, 
                       error: Optional[str] = None):
        """Track performance metrics"""
        metric = PerformanceMetrics(
            endpoint=endpoint,
            method=method,
            response_time=response_time,
            status_code=status_code,
            timestamp=datetime.now(),
            request_size=request_size,
            response_size=response_size,
            error=error
        )
        
        with self._lock:
            self.metrics.append(metric)
            # Keep only last 1000 metrics
            if len(self.metrics) > 1000:
                self.metrics = self.metrics[-1000:]
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        with self._lock:
            if not self.metrics:
                return {"message": "No metrics available"}
            
            response_times = [m.response_time for m in self.metrics]
            status_codes = [m.status_code for m in self.metrics]
            
            return {
                "total_requests": len(self.metrics),
                "avg_response_time": statistics.mean(response_times),
                "min_response_time": min(response_times),
                "max_response_time": max(response_times),
                "median_response_time": statistics.median(response_times),
                "p95_response_time": self._percentile(response_times, 95),
                "p99_response_time": self._percentile(response_times, 99),
                "success_rate": len([s for s in status_codes if 200 <= s < 300]) / len(status_codes),
                "error_rate": len([s for s in status_codes if s >= 400]) / len(status_codes),
                "requests_per_second": self._calculate_rps(),
                "avg_request_size": statistics.mean([m.request_size for m in self.metrics]),
                "avg_response_size": statistics.mean([m.response_size for m in self.metrics])
            }
    
    def _percentile(self, data: List[float], percentile: int) -> float:
        """Calculate percentile"""
        sorted_data = sorted(data)
        index = int((percentile / 100) * len(sorted_data))
        return sorted_data[min(index, len(sorted_data) - 1)]
    
    def _calculate_rps(self) -> float:
        """Calculate requests per second"""
        if len(self.metrics) < 2:
            return 0.0
        
        time_span = (self.metrics[-1].timestamp - self.metrics[0].timestamp).total_seconds()
        if time_span == 0:
            return 0.0
        
        return len(self.metrics) / time_span

class DatabaseManager:
    """Production database manager with connection pooling"""
    
    def __init__(self, database_url: str, min_size: int = 5, max_size: int = 20, 
                 max_overflow: int = 30, command_timeout: int = 60):
        self.database_url = database_url
        self.min_size = min_size
        self.max_size = max_size
        self.max_overflow = max_overflow
        self.command_timeout = command_timeout
        self.pool = None
        self.metrics: List[ConnectionPoolMetrics] = []
        self._lock = threading.Lock()
    
    async def initialize(self):
        """Initialize database connection pool"""
        try:
            self.pool = await asyncpg.create_pool(
                self.database_url,
                min_size=self.min_size,
                max_size=self.max_size,
                max_overflow=self.max_overflow,
                command_timeout=self.command_timeout,
                server_settings={
                    'application_name': 'terradev_production',
                    'timezone': 'UTC'
                }
            )
            logger.info(f"Database connection pool initialized: min={self.min_size}, max={self.max_size}")
        except Exception as e:
            logger.error(f"Failed to initialize database pool: {e}")
            raise
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            await self.pool.close()
            logger.info("Database connection pool closed")
    
    @asynccontextmanager
    async def get_connection(self):
        """Get database connection from pool"""
        if not self.pool:
            raise RuntimeError("Database pool not initialized")
        
        async with self.pool.acquire() as connection:
            yield connection
    
    async def execute_query(self, query: str, *args) -> List[dict]:
        """Execute query with connection from pool"""
        async with self.get_connection() as conn:
            try:
                start_time = time.time()
                result = await conn.fetch(query, *args)
                execution_time = time.time() - start_time
                
                # Track metrics
                self._track_pool_metrics()
                
                return [dict(row) for row in result]
            except Exception as e:
                logger.error(f"Query execution failed: {e}")
                raise
    
    async def execute_command(self, command: str, *args) -> str:
        """Execute command with connection from pool"""
        async with self.get_connection() as conn:
            try:
                start_time = time.time()
                result = await conn.execute(command, *args)
                execution_time = time.time() - start_time
                
                # Track metrics
                self._track_pool_metrics()
                
                return result
            except Exception as e:
                logger.error(f"Command execution failed: {e}")
                raise
    
    def _track_pool_metrics(self):
        """Track connection pool metrics"""
        if self.pool:
            metrics = ConnectionPoolMetrics(
                pool_name="database",
                total_connections=self.pool.get_size(),
                active_connections=self.pool.get_idle_size(),
                idle_connections=self.pool.get_idle_size(),
                waiting_connections=self.pool.get_size() - self.pool.get_idle_size(),
                timestamp=datetime.now()
            )
            
            with self._lock:
                self.metrics.append(metrics)
                if len(self.metrics) > 1000:
                    self.metrics = self.metrics[-1000:]
    
    def get_pool_stats(self) -> Dict[str, Any]:
        """Get connection pool statistics"""
        if not self.pool:
            return {"message": "Database pool not initialized"}
        
        return {
            "pool_size": self.pool.get_size(),
            "idle_connections": self.pool.get_idle_size(),
            "active_connections": self.pool.get_size() - self.pool.get_idle_size(),
            "min_size": self.min_size,
            "max_size": self.max_size,
            "max_overflow": self.max_overflow
        }

class RedisManager:
    """Production Redis manager with connection pooling"""
    
    def __init__(self, redis_url: str, max_connections: int = 100, retry_on_timeout: bool = True):
        self.redis_url = redis_url
        self.max_connections = max_connections
        self.retry_on_timeout = retry_on_timeout
        self.pool = None
        self.metrics: List[ConnectionPoolMetrics] = []
        self._lock = threading.Lock()
    
    async def initialize(self):
        """Initialize Redis connection pool"""
        try:
            self.pool = redis.ConnectionPool.from_url(
                self.redis_url,
                max_connections=self.max_connections,
                retry_on_timeout=self.retry_on_timeout,
                socket_connect_timeout=5,
                socket_timeout=5,
                socket_keepalive=True,
                socket_keepalive_options={},
                health_check_interval=30
            )
            logger.info(f"Redis connection pool initialized: max_connections={self.max_connections}")
        except Exception as e:
            logger.error(f"Failed to initialize Redis pool: {e}")
            raise
    
    def close(self):
        """Close Redis connection pool"""
        if self.pool:
            self.pool.disconnect()
            logger.info("Redis connection pool closed")
    
    @asynccontextmanager
    async def get_connection(self):
        """Get Redis connection from pool"""
        if not self.pool:
            raise RuntimeError("Redis pool not initialized")
        
        conn = redis.Redis(connection_pool=self.pool)
        try:
            yield conn
        finally:
            pass  # Connection is returned to pool automatically
    
    async def get(self, key: str) -> Optional[str]:
        """Get value from Redis"""
        async with self.get_connection() as conn:
            try:
                start_time = time.time()
                result = conn.get(key)
                execution_time = time.time() - start_time
                
                # Track metrics
                self._track_pool_metrics()
                
                return result
            except Exception as e:
                logger.error(f"Redis GET failed: {e}")
                raise
    
    async def set(self, key: str, value: str, ex: Optional[int] = None) -> bool:
        """Set value in Redis"""
        async with self.get_connection() as conn:
            try:
                start_time = time.time()
                result = conn.set(key, value, ex=ex)
                execution_time = time.time() - start_time
                
                # Track metrics
                self._track_pool_metrics()
                
                return result
            except Exception as e:
                logger.error(f"Redis SET failed: {e}")
                raise
    
    def _track_pool_metrics(self):
        """Track connection pool metrics"""
        if self.pool:
            metrics = ConnectionPoolMetrics(
                pool_name="redis",
                total_connections=self.pool.max_connections,
                active_connections=self.pool.max_connections - self.pool.idle,
                idle_connections=self.pool.idle,
                waiting_connections=0,  # Redis doesn't expose waiting connections
                timestamp=datetime.now()
            )
            
            with self._lock:
                self.metrics.append(metrics)
                if len(self.metrics) > 1000:
                    self.metrics = self.metrics[-1000:]

class PerformanceMonitor:
    """System performance monitoring"""
    
    def __init__(self):
        self.metrics_history = []
        self._lock = threading.Lock()
    
# TODO: REFACTOR - get_system_metrics() is 80 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def get_system_metrics(self) -> Dict[str, Any]:
        """Get system performance metrics"""
        try:
            # CPU metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            cpu_freq = psutil.cpu_freq()
            
            # Memory metrics
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            # Disk metrics
            disk = psutil.disk_usage('/')
            disk_io = psutil.disk_io_counters()
            
            # Network metrics
            network = psutil.net_io_counters()
            
            # Process metrics
            process = psutil.Process()
            process_memory = process.memory_info()
            process_cpu = process.cpu_percent()
            
            metrics = {
                "timestamp": datetime.now().isoformat(),
                "cpu": {
                    "percent": cpu_percent,
                    "count": cpu_count,
                    "frequency": cpu_freq.current if cpu_freq else None
                },
                "memory": {
                    "total": memory.total,
                    "available": memory.available,
                    "percent": memory.percent,
                    "used": memory.used,
                    "free": memory.free
                },
                "swap": {
                    "total": swap.total,
                    "used": swap.used,
                    "free": swap.free,
                    "percent": swap.percent
                },
                "disk": {
                    "total": disk.total,
                    "used": disk.used,
                    "free": disk.free,
                    "percent": (disk.used / disk.total) * 100
                },
                "disk_io": {
                    "read_count": disk_io.read_count,
                    "write_count": disk_io.write_count,
                    "read_bytes": disk_io.read_bytes,
                    "write_bytes": disk_io.write_bytes
                },
                "network": {
                    "bytes_sent": network.bytes_sent,
                    "bytes_recv": network.bytes_recv,
                    "packets_sent": network.packets_sent,
                    "packets_recv": network.packets_recv
                },
                "process": {
                    "pid": process.pid,
                    "memory_rss": process_memory.rss,
                    "memory_vms": process_memory.vms,
                    "cpu_percent": process_cpu
                }
            }
            
            # Store metrics history
            with self._lock:
                self.metrics_history.append(metrics)
                if len(self.metrics_history) > 1000:
                    self.metrics_history = self.metrics_history[-1000:]
            
            return metrics
            
        except Exception as e:
            logger.error(f"Failed to get system metrics: {e}")
            return {"error": str(e)}
    
    def get_metrics_history(self, minutes: int = 5) -> List[Dict[str, Any]]:
        """Get metrics history for specified time period"""
        cutoff_time = datetime.now() - timedelta(minutes=minutes)
        
        with self._lock:
            return [
                metric for metric in self.metrics_history
                if datetime.fromisoformat(metric["timestamp"]) > cutoff_time
            ]

# Global performance monitor
performance_monitor = PerformanceMonitor()

# Performance optimization decorators
def monitor_performance(func):
    """Decorator to monitor function performance"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss
        
        try:
            result = await func(*args, **kwargs)
            execution_time = time.time() - start_time
            end_memory = psutil.Process().memory_info().rss
            
            logger.info(f"Performance: {func.__name__} took {execution_time:.3f}s, "
                       f"memory delta: {(end_memory - start_memory) / 1024 / 1024:.2f}MB")
            
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Performance: {func.__name__} failed after {execution_time:.3f}s: {e}")
            raise
    
    return wrapper

def cache_result(ttl: int = 300, key_prefix: str = "cache"):
    """Decorator to cache function results"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Generate cache key
            cache_key = f"{key_prefix}:{func.__name__}:{hash(str(args) + str(kwargs))}"
            
            # Try to get from cache (mock implementation)
            # In production, this would use Redis
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator

if __name__ == "__main__":
    # Test performance optimization
    logging.info("⚡ Testing Production Performance Optimization")
    logging.info("=" * 50)
    
    # Test system metrics
    system_metrics = performance_monitor.get_system_metrics()
    logging.info(f"\n📊 System Metrics:")
    logging.info(f"   CPU: {system_metrics['cpu']['percent']:.1f}%")
    logging.info(f"   Memory: {system_metrics['memory']['percent']:.1f}%")
    logging.info(f"   Disk: {system_metrics['disk']['percent']:.1f}%")
    logging.info(f"   Process Memory: {system_metrics['process']['memory_rss'] / 1024 / 1024:.2f}MB")
    
    # Test HTTP client
    async def test_http_client():
        async with AsyncHTTPClient() as client:
            try:
                result = await client.get("https://httpbin.org/get")
                logging.info(f"\n🌐 HTTP Client Test:")
                logging.info(f"   Status: {result['status']}")
                logging.info(f"   Response Time: {result['response_time']:.3f}s")
                return result
            except Exception as e:
                logging.info(f"   HTTP Client Error: {e}")
                return None
    
    # Run HTTP client test
    asyncio.run(test_http_client())
    
    logging.info(f"\n✅ Performance optimization test completed!")
