#!/usr/bin/env python3
"""
Production Error Handling & Reliability
Retry logic, circuit breakers, proper logging, and error tracking
"""

import asyncio
import logging
import time
import traceback
import json
from typing import Dict, Any, Optional, List, Callable, Union
from datetime import datetime, timedelta
from functools import wraps
from enum import Enum
import aiohttp
import redis
from dataclasses import dataclass, asdict
import random
import hashlib
import uuid
from pathlib import Path
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/log/terradev/production.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ErrorSeverity(Enum):
    """Error severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class CircuitState(Enum):
    """Circuit breaker states"""
    CLOSED = "closed"  # Normal operation
    OPEN = "open"      # Circuit is open, fail fast
    HALF_OPEN = "half_open"  # Testing if service has recovered

@dataclass
class ErrorContext:
    """Error context for tracking"""
    error_id: str
    timestamp: datetime
    error_type: str
    severity: ErrorSeverity
    message: str
    stack_trace: str
    user_id: Optional[str] = None
    request_id: Optional[str] = None
    service_name: Optional[str] = None
    endpoint: Optional[str] = None
    additional_data: Optional[Dict[str, Any]] = None

@dataclass
class RetryConfig:
    """Retry configuration"""
    max_attempts: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: bool = True
    retry_on_exceptions: List[Exception] = None
    
    def __post_init__(self):
        if self.retry_on_exceptions is None:
            self.retry_on_exceptions = [
                aiohttp.ClientError,
                asyncio.TimeoutError,
                ConnectionError,
                OSError
            ]

@dataclass
class CircuitBreakerConfig:
    """Circuit breaker configuration"""
    failure_threshold: int = 5
    recovery_timeout: float = 60.0
    expected_exception: type = Exception
    success_threshold: int = 2  # Successes needed to close circuit

class CircuitBreaker:
    """Circuit breaker for external service calls"""
    
    def __init__(self, name: str, config: CircuitBreakerConfig):
        self.name = name
        self.config = config
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time = None
        self.success_count = 0
        self.logger = logging.getLogger(f"circuit_breaker.{name}")
    
    def __call__(self, func):
        """Decorator for circuit breaker"""
        @wraps(func)
        async def wrapper(*args, **kwargs):
            if self.state == CircuitState.OPEN:
                if self._should_attempt_reset():
                    self.state = CircuitState.HALF_OPEN
                    self.logger.info(f"Circuit breaker {self.name} transitioning to HALF_OPEN")
                else:
                    raise Exception(f"Circuit breaker {self.name} is OPEN")
            
            try:
                result = await func(*args, **kwargs)
                self._on_success()
                return result
            except self.config.expected_exception as e:
                self._on_failure()
                raise
        return wrapper
    
    def _should_attempt_reset(self) -> bool:
        """Check if circuit breaker should attempt reset"""
        if self.last_failure_time is None:
            return True
        return time.time() - self.last_failure_time >= self.config.recovery_timeout
    
    def _on_success(self):
        """Handle successful call"""
        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= self.config.success_threshold:
                self._reset()
        elif self.state == CircuitState.CLOSED:
            self.success_count = max(0, self.success_count + 1)
    
    def _on_failure(self):
        """Handle failed call"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.OPEN
            self.logger.warning(f"Circuit breaker {self.name} transitioning to OPEN")
        elif (self.state == CircuitState.CLOSED and 
              self.failure_count >= self.config.failure_threshold):
            self.state = CircuitState.OPEN
            self.logger.warning(f"Circuit breaker {self.name} transitioning to OPEN")
    
    def _reset(self):
        """Reset circuit breaker to closed state"""
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
        self.logger.info(f"Circuit breaker {self.name} reset to CLOSED")

class RetryManager:
    """Retry manager with exponential backoff"""
    
    def __init__(self, config: RetryConfig):
        self.config = config
        self.logger = logging.getLogger("retry_manager")
    
    def __call__(self, func):
        """Decorator for retry logic"""
        @wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(self.config.max_attempts):
                try:
                    return await func(*args, **kwargs)
                except tuple(self.config.retry_on_exceptions) as e:
                    last_exception = e
                    
                    if attempt == self.config.max_attempts - 1:
                        self.logger.error(f"Final attempt failed for {func.__name__}: {e}")
                        raise
                    
                    delay = self._calculate_delay(attempt)
                    self.logger.warning(f"Attempt {attempt + 1} failed for {func.__name__}: {e}. Retrying in {delay:.2f}s")
                    await asyncio.sleep(delay)
            
            raise last_exception
        return wrapper
    
    def _calculate_delay(self, attempt: int) -> float:
        """Calculate delay with exponential backoff and jitter"""
        delay = self.config.base_delay * (self.config.exponential_base ** attempt)
        delay = min(delay, self.config.max_delay)
        
        if self.config.jitter:
            # Add jitter to prevent thundering herd
            jitter_amount = delay * 0.1
            delay += random.uniform(-jitter_amount, jitter_amount)
        
        return max(0, delay)

class ErrorTracker:
    """Error tracking and reporting"""
    
    def __init__(self):
        self.redis_client = None
        self.error_log_file = Path("/var/log/terradev/errors.json")
        self._init_redis()
        self._init_error_log()
    
    def _init_redis(self):
        """Initialize Redis for error tracking"""
        try:
            self.redis_client = redis.Redis(
                host=os.getenv("REDIS_HOST", "localhost"),
                port=int(os.getenv("REDIS_PORT", "6379")),
                password=os.getenv("REDIS_PASSWORD"),
                decode_responses=True
            )
            self.redis_client.ping()
            logger.info("Redis connection established for error tracking")
        except Exception as e:
            logger.error(f"Failed to connect to Redis for error tracking: {e}")
            self.redis_client = None
    
    def _init_error_log(self):
        """Initialize error log file"""
        try:
            self.error_log_file.parent.mkdir(parents=True, exist_ok=True)
            if not self.error_log_file.exists():
                with open(self.error_log_file, 'w') as f:
                    json.dump([], f)
        except Exception as e:
            logger.error(f"Failed to initialize error log: {e}")
    
    def track_error(self, error: Exception, context: Dict[str, Any] = None) -> str:
        """Track error with context"""
        error_id = str(uuid.uuid4())
        
        error_context = ErrorContext(
            error_id=error_id,
            timestamp=datetime.now(),
            error_type=type(error).__name__,
            severity=self._determine_severity(error),
            message=str(error),
            stack_trace=traceback.format_exc(),
            user_id=context.get("user_id") if context else None,
            request_id=context.get("request_id") if context else None,
            service_name=context.get("service_name") if context else None,
            endpoint=context.get("endpoint") if context else None,
            additional_data=context
        )
        
        # Store in Redis
        if self.redis_client:
            try:
                self._store_error_in_redis(error_context)
            except Exception as e:
                logger.error(f"Failed to store error in Redis: {e}")
        
        # Store in file
        try:
            self._store_error_in_file(error_context)
        except Exception as e:
            logger.error(f"Failed to store error in file: {e}")
        
        # Log error
        self._log_error(error_context)
        
        return error_id
    
    def _determine_severity(self, error: Exception) -> ErrorSeverity:
        """Determine error severity based on type and message"""
        error_message = str(error).lower()
        error_type = type(error).__name__.lower()
        
        # Critical errors
        if any(keyword in error_message or keyword in error_type for keyword in [
            "database", "connection", "timeout", "memory", "disk", "security",
            "authentication", "authorization", "critical", "fatal"
        ]):
            return ErrorSeverity.CRITICAL
        
        # High severity errors
        if any(keyword in error_message or keyword in error_type for keyword in [
            "http", "api", "network", "service", "provider", "deployment",
            "validation", "permission", "access"
        ]):
            return ErrorSeverity.HIGH
        
        # Medium severity errors
        if any(keyword in error_message or keyword in error_type for keyword in [
            "not found", "invalid", "format", "parse", "syntax", "type"
        ]):
            return ErrorSeverity.MEDIUM
        
        # Low severity errors
        return ErrorSeverity.LOW
    
    def _store_error_in_redis(self, error_context: ErrorContext):
        """Store error in Redis"""
        error_key = f"error:{error_context.error_id}"
        error_data = asdict(error_context)
        error_data["timestamp"] = error_context.timestamp.isoformat()
        
        # Store individual error
        self.redis_client.setex(error_key, 86400, json.dumps(error_data))  # 24 hours TTL
        
        # Store in error list for recent errors
        recent_errors_key = "errors:recent"
        self.redis_client.lpush(recent_errors_key, json.dumps(error_data))
        self.redis_client.ltrim(recent_errors_key, 0, 999)  # Keep last 1000 errors
        
        # Store in error counts
        error_type_key = f"error_counts:{error_context.error_type}"
        self.redis_client.incr(error_type_key)
        self.redis_client.expire(error_type_key, 86400)
        
        # Store in severity counts
        severity_key = f"error_counts:severity:{error_context.severity.value}"
        self.redis_client.incr(severity_key)
        self.redis_client.expire(severity_key, 86400)
    
    def _store_error_in_file(self, error_context: ErrorContext):
        """Store error in file"""
        try:
            with open(self.error_log_file, 'r') as f:
                errors = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            errors = []
        
        error_data = asdict(error_context)
        error_data["timestamp"] = error_context.timestamp.isoformat()
        
        errors.append(error_data)
        
        # Keep only last 1000 errors
        if len(errors) > 1000:
            errors = errors[-1000:]
        
        with open(self.error_log_file, 'w') as f:
            json.dump(errors, f, indent=2)
    
    def _log_error(self, error_context: ErrorContext):
        """Log error with appropriate level"""
        log_message = f"[{error_context.error_id}] {error_context.error_type}: {error_context.message}"
        
        if error_context.severity == ErrorSeverity.CRITICAL:
            logger.critical(log_message)
        elif error_context.severity == ErrorSeverity.HIGH:
            logger.error(log_message)
        elif error_context.severity == ErrorSeverity.MEDIUM:
            logger.warning(log_message)
        else:
            logger.info(log_message)
    
    def get_error_stats(self) -> Dict[str, Any]:
        """Get error statistics"""
        stats = {
            "total_errors": 0,
            "by_type": {},
            "by_severity": {},
            "recent_errors": []
        }
        
        if self.redis_client:
            try:
                # Get recent errors
                recent_errors = self.redis_client.lrange("errors:recent", 0, 9)
                stats["recent_errors"] = [json.loads(error) for error in recent_errors]
                
                # Get error counts by type
                for key in self.redis_client.scan_iter(match="error_counts:*"):
                    count = self.redis_client.get(key)
                    error_type = key.split(":")[-1]
                    stats["by_type"][error_type] = int(count)
                
                # Calculate total
                stats["total_errors"] = sum(stats["by_type"].values())
                
                # Get severity counts
                severity_counts = {}
                for key in self.redis_client.scan_iter(match="error_counts:severity:*"):
                    count = self.redis_client.get(key)
                    severity = key.split(":")[-1]
                    severity_counts[severity] = int(count)
                stats["by_severity"] = severity_counts
                
            except Exception as e:
                logger.error(f"Failed to get error stats from Redis: {e}")
        
        return stats

class ProductionErrorHandler:
    """Production error handler with comprehensive features"""
    
    def __init__(self):
        self.error_tracker = ErrorTracker()
        self.circuit_breakers = {}
        self.retry_managers = {}
        self.logger = logging.getLogger("production_error_handler")
    
    def get_circuit_breaker(self, name: str, config: CircuitBreakerConfig = None) -> CircuitBreaker:
        """Get or create circuit breaker"""
        if name not in self.circuit_breakers:
            if config is None:
                config = CircuitBreakerConfig()
            self.circuit_breakers[name] = CircuitBreaker(name, config)
        return self.circuit_breakers[name]
    
    def get_retry_manager(self, name: str, config: RetryConfig = None) -> RetryManager:
        """Get or create retry manager"""
        if name not in self.retry_managers:
            if config is None:
                config = RetryConfig()
            self.retry_managers[name] = RetryManager(config)
        return self.retry_managers[name]
    
    def handle_error(self, error: Exception, context: Dict[str, Any] = None) -> str:
        """Handle error with tracking and reporting"""
        error_id = self.error_tracker.track_error(error, context)
        
        # Send alert for critical errors
        if self.error_tracker._determine_severity(error) == ErrorSeverity.CRITICAL:
            self._send_critical_alert(error_id, error, context)
        
        return error_id
    
    def _send_critical_alert(self, error_id: str, error: Exception, context: Dict[str, Any]):
        """Send critical alert (mock implementation)"""
        alert_data = {
            "error_id": error_id,
            "error_type": type(error).__name__,
            "message": str(error),
            "context": context,
            "timestamp": datetime.now().isoformat()
        }
        
        # In production, this would send to monitoring service
        self.logger.critical(f"CRITICAL ALERT: {json.dumps(alert_data)}")

# Global error handler
error_handler = ProductionErrorHandler()

# Decorators for common use cases
def handle_errors(service_name: str = None):
    """Decorator for error handling"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                context = {
                    "service_name": service_name or func.__module__,
                    "endpoint": func.__name__,
                    "args": str(args)[:100],  # Truncate for logging
                    "kwargs": str(kwargs)[:100]  # Truncate for logging
                }
                error_handler.handle_error(e, context)
                raise
        return wrapper
    return decorator

def with_retry(name: str, max_attempts: int = 3, base_delay: float = 1.0):
    """Decorator for retry logic"""
    config = RetryConfig(max_attempts=max_attempts, base_delay=base_delay)
    retry_manager = error_handler.get_retry_manager(name, config)
    return retry_manager

def with_circuit_breaker(name: str, failure_threshold: int = 5, recovery_timeout: float = 60.0):
    """Decorator for circuit breaker"""
    config = CircuitBreakerConfig(
        failure_threshold=failure_threshold,
        recovery_timeout=recovery_timeout
    )
    circuit_breaker = error_handler.get_circuit_breaker(name, config)
    return circuit_breaker

# Example usage
class ProductionAPI:
    """Example production API with error handling"""
    
    def __init__(self):
        self.session = None
        self.base_url = "https://api.example.com"
    
    @handle_errors("production_api")
    @with_retry("api_calls", max_attempts=3, base_delay=1.0)
    @with_circuit_breaker("api_service", failure_threshold=5, recovery_timeout=60.0)
    async def call_external_api(self, endpoint: str, data: Dict[str, Any] = None):
        """Example API call with all error handling"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        url = f"{self.base_url}/{endpoint}"
        
        async with self.session.post(url, json=data) as response:
            response.raise_for_status()
            return await response.json()

if __name__ == "__main__":
    # Test error handling
    logging.info("🛡️ Testing Production Error Handling")
    logging.info("=" * 50)
    
    # Test error tracking
    try:
        raise ValueError("Test error for tracking")
    except Exception as e:
        error_id = error_handler.handle_error(e, {"service_name": "test", "endpoint": "test_endpoint"})
        logging.info(f"\n🚨 Error tracked with ID: {error_id}")
    
    # Test error statistics
    stats = error_handler.error_tracker.get_error_stats()
    logging.info(f"\n📊 Error Statistics:")
    logging.info(f"   Total Errors: {stats['total_errors']}")
    logging.info(f"   By Type: {stats['by_type']}")
    logging.info(f"   By Severity: {stats['by_severity']}")
    
    # Test circuit breaker
    @with_circuit_breaker("test_service", failure_threshold=2, recovery_timeout=5.0)
    async def failing_service():
        raise ConnectionError("Service unavailable")
    
    logging.info(f"\n🔧 Circuit Breaker Test:")
    try:
        await failing_service()
    except Exception as e:
        logging.info(f"   Expected failure: {e}")
    
    logging.info(f"\n✅ Error handling test completed!")
