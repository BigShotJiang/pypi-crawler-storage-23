# 🔐 Terradev Storage Architecture Deep Dive

Enterprise-grade encrypted storage solution for secure credential management.

---

## 🏗️ **Storage Architecture Overview**

### **📁 Directory Structure**
```bash
~/.terradev/
├── auth.json          # Encrypted credentials (600 permissions)
├── config.json        # Configuration settings (644 permissions)
├── logs/              # Application logs (755 permissions)
│   ├── terradev.log   # Main application log
│   └── errors.log     # Error log file
└── backups/           # Automatic backups (700 permissions)
    ├── auth_backup_20260209.json
    └── config_backup_20260209.json
```

### **🔒 Security Permissions**
```bash
# File permissions set automatically
~/.terradev/              # 700 (drwx------) - User only
~/.terradev/auth.json     # 600 (rw-------) - User read/write only
~/.terradev/config.json   # 644 (rw-r--r--) - User read/write, others read
~/.terradev/logs/         # 755 (rwxr-xr-x) - User full, group/others read/execute
~/.terradev/backups/      # 700 (drwx------) - User only
```

---

## 🔐 **Encryption System**

### **🔑 Fernet Encryption (AES-128)**
```python
# Encryption process flow
1. User enters API keys/tokens
2. Generate Fernet key (32-byte URL-safe base64-encoded)
3. Encrypt credentials with Fernet
4. Store encrypted data + key in auth.json
5. Decrypt on-the-fly when needed

# Key generation
from cryptography.fernet import Fernet
key = Fernet.generate_key()  # b'base64-encoded-key=='
fernet = Fernet(key)

# Encryption
encrypted_data = fernet.encrypt(api_key.encode())
# Decrypt
decrypted_data = fernet.decrypt(encrypted_data).decode()
```

### **🛡️ Encryption Details**
- **Algorithm**: Fernet (AES-128-CBC + HMAC-SHA256)
- **Key Size**: 256-bit (32 bytes)
- **Encoding**: URL-safe base64
- **Security**: Cryptographically signed, tamper-proof
- **Rotation**: Built-in key rotation capability

---

## 📊 **Data Storage Format**

### **🔐 auth.json Structure**
```json
{
    "version": "1.0",
    "encryption_key": "gAAAAABjZKq8h7Q2vXy9TmN3pL5rS8tW1vY4xZ6aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVw==",
    "credentials": {
        "runpod": {
            "encrypted_api_key": "gAAAAABjZKq8h7Q2vXy9TmN3pL5rS8tW1vY4xZ6aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVw==",
            "created_at": "2026-02-09T12:00:00Z",
            "last_updated": "2026-02-09T12:00:00Z",
            "key_version": 1
        },
        "huggingface": {
            "encrypted_api_token": "gAAAAABjZKq8h7Q2vXy9TmN3pL5rS8tW1vY4xZ6aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVw==",
            "created_at": "2026-02-09T12:00:00Z",
            "last_updated": "2026-02-09T12:00:00Z",
            "key_version": 1
        },
        "aws": {
            "encrypted_access_key": "gAAAAABjZKq8h7Q2vXy9TmN3pL5rS8tW1vY4xZ6aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVw==",
            "encrypted_secret_key": "gAAAAABjZKq8h7Q2vXy9TmN3pL5rS8tW1vY4xZ6aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVw==",
            "created_at": "2026-02-09T12:00:00Z",
            "last_updated": "2026-02-09T12:00:00Z",
            "key_version": 1
        }
    },
    "metadata": {
        "total_providers": 3,
        "last_backup": "2026-02-09T12:00:00Z",
        "backup_count": 5,
        "encryption_version": "fernet-v1"
    }
}
```

### **📋 config.json Structure**
```json
{
    "version": "1.0",
    "providers": {
        "runpod": {
            "region": "us-east-1",
            "enabled": true,
            "last_tested": "2026-02-09T12:00:00Z",
            "test_status": "success",
            "preferences": {
                "max_price": 3.00,
                "preferred_instance_types": ["A100-80GB"]
            }
        },
        "huggingface": {
            "region": "us-east-1",
            "enabled": true,
            "last_tested": "2026-02-09T12:00:00Z",
            "test_status": "success",
            "preferences": {
                "default_models": ["stable-diffusion-v1-5", "whisper-large-v2"]
            }
        },
        "aws": {
            "region": "us-east-1",
            "enabled": false,
            "last_tested": "2026-02-09T12:00:00Z",
            "test_status": "failed",
            "error": "Invalid credentials"
        }
    },
    "global_settings": {
        "default_parallel_queries": 6,
        "default_region": "us-east-1",
        "auto_optimize": true,
        "show_savings_comparison": true,
        "backup_enabled": true,
        "log_level": "INFO"
    },
    "user_preferences": {
        "favorite_providers": ["runpod", "huggingface"],
        "cost_threshold": 5.00,
        "notification_settings": {
            "price_alerts": true,
            "job_completion": true,
            "error_notifications": true
        }
    }
}
```

---

## 🔄 **Key Management System**

### **🔑 Key Generation**
```python
class KeyManager:
    def __init__(self):
        self.current_key_version = 1
        self.key_rotation_interval = 90  # days
    
    def generate_key(self) -> str:
        """Generate new Fernet key"""
        return Fernet.generate_key().decode()
    
    def rotate_key(self, old_key: str, encrypted_data: str) -> tuple:
        """Rotate encryption key"""
        # Decrypt with old key
        old_fernet = Fernet(old_key.encode())
        decrypted_data = old_fernet.decrypt(encrypted_data.encode())
        
        # Encrypt with new key
        new_key = self.generate_key()
        new_fernet = Fernet(new_key.encode())
        new_encrypted_data = new_fernet.encrypt(decrypted_data).decode()
        
        return new_key, new_encrypted_data
```

### **🔄 Key Rotation Process**
```python
# Automatic key rotation workflow
1. Check key age (every 90 days)
2. Generate new encryption key
3. Decrypt all credentials with old key
4. Re-encrypt with new key
5. Update key_version in auth.json
6. Create backup before rotation
7. Verify decryption works
8. Clean up old key
```

---

## 💾 **Backup System**

### **📦 Automatic Backups**
```python
class BackupManager:
    def __init__(self):
        self.backup_dir = Path.home() / '.terradev' / 'backups'
        self.max_backups = 10
        self.backup_interval = 24  # hours
    
    def create_backup(self, file_path: str) -> str:
        """Create timestamped backup"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = f"{Path(file_path).stem}_backup_{timestamp}.json"
        backup_path = self.backup_dir / backup_name
        
        # Copy file with encryption
        shutil.copy2(file_path, backup_path)
        
        # Set secure permissions
        os.chmod(backup_path, 0o600)
        
        # Clean up old backups
        self._cleanup_old_backups()
        
        return str(backup_path)
    
    def restore_backup(self, backup_path: str, target_path: str):
        """Restore from backup"""
        shutil.copy2(backup_path, target_path)
        os.chmod(target_path, 0o600)
```

### **📊 Backup Strategy**
```python
backup_schedule = {
    "frequency": "Daily",
    "retention": "10 days",
    "compression": "gzip",
    "encryption": "Same as main file",
    "location": "Local ~/.terradev/backups/",
    "enterprise_cloud": "Optional S3 backup"
}
```

---

## 🛡️ **Security Features**

### **🔒 Access Control**
```python
# Permission validation on startup
def validate_permissions():
    required_permissions = {
        '~/.terradev/': 0o700,      # drwx------
        '~/.terradev/auth.json': 0o600,  # rw-------
        '~/.terradev/config.json': 0o644, # rw-r--r--
        '~/.terradev/backups/': 0o700     # drwx------
    }
    
    for path, expected_perm in required_permissions.items():
        actual_perm = oct(Path(path).stat().st_mode)[-3:]
        if actual_perm != oct(expected_perm)[-3:]:
            fix_permissions(path, expected_perm)
```

### **🔍 Integrity Checks**
```python
def verify_file_integrity(file_path: str) -> bool:
    """Verify file hasn't been tampered with"""
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        # Check required fields
        if file_path.endswith('auth.json'):
            required = ['version', 'encryption_key', 'credentials']
        else:
            required = ['version', 'providers']
        
        return all(field in data for field in required)
    
    except (json.JSONDecodeError, FileNotFoundError):
        return False
```

### **🚨 Security Monitoring**
```python
# Security event logging
security_events = [
    "File access attempt",
    "Permission change", 
    "Failed decryption",
    "Key rotation",
    "Backup creation",
    "Configuration change"
]

# Log format
{
    "timestamp": "2026-02-09T12:00:00Z",
    "event": "file_access",
    "file": "~/.terradev/auth.json",
    "user": "current_user",
    "success": true,
    "details": "Normal credential access"
}
```

---

## ☁️ **Cloud Storage Integration (Enterprise)**

### **🏢 Enterprise Cloud Backup**
```python
class CloudBackup:
    def __init__(self, provider: str, credentials: dict):
        self.provider = provider
        self.credentials = credentials
    
    def upload_backup(self, file_path: str) -> str:
        """Upload encrypted backup to cloud"""
        if self.provider == "aws_s3":
            return self._upload_to_s3(file_path)
        elif self.provider == "gcs":
            return self._upload_to_gcs(file_path)
    
    def _upload_to_s3(self, file_path: str) -> str:
        """Upload to AWS S3 with server-side encryption"""
        import boto3
        
        s3 = boto3.client('s3', **self.credentials)
        
        # Upload with AES-256 encryption
        s3.upload_file(
            file_path,
            'terradev-user-backups',
            f"backups/{Path(file_path).name}",
            ExtraArgs={
                'ServerSideEncryption': 'AES256',
                'StorageClass': 'STANDARD_IA'
            }
        )
        
        return f"s3://terradev-user-backups/backups/{Path(file_path).name}"
```

### **📊 Cloud Storage Features**
```python
enterprise_features = {
    "backup_providers": ["AWS S3", "Google Cloud Storage", "Azure Blob"],
    "encryption": "AES-256 server-side + client-side",
    "retention": "90 days",
    "compression": "gzip",
    "access_control": "IAM roles + bucket policies",
    "audit_logging": "CloudTrail + custom logs",
    "cross_region": "Multi-region replication",
    "compliance": "SOC2, GDPR, HIPAA eligible"
}
```

---

## 🔧 **Storage Operations**

### **📝 Credential Storage**
```python
class CredentialStorage:
    def __init__(self):
        self.auth_file = Path.home() / '.terradev' / 'auth.json'
        self.config_file = Path.home() / '.terradev' / 'config.json'
        self.fernet = None
    
    def store_credentials(self, provider: str, credentials: dict):
        """Store encrypted credentials"""
        # Initialize encryption if needed
        if not self.fernet:
            self._initialize_encryption()
        
        # Encrypt credentials
        encrypted_creds = {}
        for key, value in credentials.items():
            encrypted_creds[f"encrypted_{key}"] = self.fernet.encrypt(value.encode()).decode()
        
        # Load existing data
        auth_data = self._load_auth_file()
        
        # Update provider credentials
        auth_data['credentials'][provider] = {
            **encrypted_creds,
            'created_at': datetime.now().isoformat(),
            'last_updated': datetime.now().isoformat(),
            'key_version': auth_data.get('current_key_version', 1)
        }
        
        # Save with backup
        self._save_auth_file(auth_data)
    
    def retrieve_credentials(self, provider: str) -> dict:
        """Retrieve decrypted credentials"""
        auth_data = self._load_auth_file()
        provider_data = auth_data['credentials'].get(provider)
        
        if not provider_data:
            return {}
        
        # Initialize encryption
        if not self.fernet:
            self._initialize_encryption()
        
        # Decrypt credentials
        decrypted_creds = {}
        for key, value in provider_data.items():
            if key.startswith('encrypted_'):
                original_key = key.replace('encrypted_', '')
                decrypted_creds[original_key] = self.fernet.decrypt(value.encode()).decode()
        
        return decrypted_creds
```

### **🔄 Configuration Management**
```python
class ConfigurationManager:
    def __init__(self):
        self.config_file = Path.home() / '.terradev' / 'config.json'
    
    def update_provider_config(self, provider: str, config: dict):
        """Update provider configuration"""
        config_data = self._load_config_file()
        
        if provider not in config_data['providers']:
            config_data['providers'][provider] = {}
        
        config_data['providers'][provider].update(config)
        config_data['providers'][provider]['last_updated'] = datetime.now().isoformat()
        
        self._save_config_file(config_data)
    
    def get_provider_config(self, provider: str) -> dict:
        """Get provider configuration"""
        config_data = self._load_config_file()
        return config_data['providers'].get(provider, {})
```

---

## 🔍 **Storage Monitoring**

### **📊 Storage Analytics**
```python
class StorageAnalytics:
    def get_storage_stats(self) -> dict:
        """Get storage usage statistics"""
        stats = {
            'total_size': 0,
            'file_count': 0,
            'backup_count': 0,
            'last_modified': None,
            'security_status': 'secure'
        }
        
        terradev_dir = Path.home() / '.terradev'
        
        for file_path in terradev_dir.rglob('*'):
            if file_path.is_file():
                stats['total_size'] += file_path.stat().st_size
                stats['file_count'] += 1
                
                if 'backup' in file_path.name:
                    stats['backup_count'] += 1
                
                if not stats['last_modified'] or file_path.stat().st_mtime > stats['last_modified']:
                    stats['last_modified'] = file_path.stat().st_mtime
        
        return stats
```

### **🚨 Health Checks**
```python
def run_health_checks() -> dict:
    """Run comprehensive storage health checks"""
    checks = {
        'permissions_valid': validate_permissions(),
        'files_intact': verify_file_integrity(),
        'encryption_working': test_encryption(),
        'backups_available': check_backups(),
        'disk_space': check_disk_space(),
        'security_events': check_security_events()
    }
    
    return {
        'overall_health': 'healthy' if all(checks.values()) else 'issues_found',
        'checks': checks,
        'timestamp': datetime.now().isoformat()
    }
```

---

## 🎯 **Storage Benefits Summary**

### **🔐 Security Benefits**
- **AES-128 encryption** for all sensitive data
- **Fernet signing** prevents tampering
- **Key rotation** every 90 days
- **Secure permissions** (600 for auth files)
- **Integrity checks** on every access

### **💾 Reliability Benefits**
- **Automatic backups** with 10-day retention
- **Local storage** ensures offline access
- **Cloud backup** option for enterprise
- **Version control** for configuration changes
- **Health monitoring** with alerts

### **🚀 Performance Benefits**
- **Local file access** (fast startup)
- **On-the-fly decryption** (minimal overhead)
- **Efficient storage** (JSON format)
- **Parallel access** support
- **Caching** for frequently used data

### **🎮 User Experience Benefits**
- **Transparent encryption** (user sees nothing)
- **Automatic management** (no manual setup)
- **Seamless backup** (automatic)
- **Easy migration** (portable format)
- **Zero configuration** (works out of box)

---

## 🎉 **Storage Architecture Summary**

### **🏗️ What We're Using**
1. **Local JSON files** with Fernet encryption
2. **AES-128 symmetric encryption** for all credentials
3. **Secure file permissions** (600 for auth, 644 for config)
4. **Automatic backups** with 10-day retention
5. **Optional cloud backup** for enterprise customers
6. **Key rotation** every 90 days
7. **Integrity checks** on every access

### **🔐 Why This Approach**
- **Security**: Enterprise-grade encryption protects user data
- **Simplicity**: No external dependencies, works offline
- **Performance**: Fast local access with minimal overhead
- **Reliability**: Automatic backups and health monitoring
- **Scalability**: Supports from individual to enterprise users
- **Compliance**: Meets security standards for sensitive data

### **🎯 Key Advantages**
- **Zero user friction** - encryption is transparent
- **Enterprise security** - AES-128 + Fernet signing
- **Automatic management** - no manual setup required
- **Disaster recovery** - automatic backups + cloud option
- **Audit trail** - security event logging
- **Cross-platform** - works on all operating systems

---

**🔐 Terradev Storage: Enterprise-grade security with zero user friction!**
