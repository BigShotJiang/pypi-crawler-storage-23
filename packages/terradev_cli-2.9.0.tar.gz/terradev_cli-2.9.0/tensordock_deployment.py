#!/usr/bin/env python3
"""
TensorDock Configuration and Deployment Scripts
Production-ready deployment configurations for TensorDock
"""

import os
import json
import yaml
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path

from tensordock_integration import TensorDockManager, TensorDockCredentials, InstanceResources, GPUResource, CloudInit
from tensordock_provider import TensorDockProvider, TensorDockInstanceConfig

# Configure logging
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DeploymentConfig:
    """Deployment configuration"""
    name: str
    environment: str  # dev, staging, prod
    instance_type: str
    node_count: int
    gpu_per_node: int
    cpu_per_node: int
    memory_per_node: int
    storage_per_node: int
    auto_scaling: bool = False
    min_nodes: int = 1
    max_nodes: int = 10
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

class TensorDockDeploymentManager:
    """Production deployment manager for TensorDock"""
    
    def __init__(self, credentials_file: str = "tensordock_credentials.json"):
        self.credentials_file = credentials_file
        self.credentials = self._load_credentials()
        self.manager = TensorDockManager(self.credentials)
        self.provider = TensorDockProvider(
            client_id=self.credentials.client_id,
            api_token=self.credentials.api_token
        )
        
        # Predefined deployment configurations
        self.deployment_configs = {
            "ml-development": DeploymentConfig(
                name="ml-dev",
                environment="dev",
                instance_type="ml-small",
                node_count=1,
                gpu_per_node=1,
                cpu_per_node=4,
                memory_per_node=16,
                storage_per_node=100
            ),
            "ml-staging": DeploymentConfig(
                name="ml-staging",
                environment="staging",
                instance_type="ml-medium",
                node_count=2,
                gpu_per_node=1,
                cpu_per_node=8,
                memory_per_node=32,
                storage_per_node=200
            ),
            "ml-production": DeploymentConfig(
                name="ml-prod",
                environment="prod",
                instance_type="ml-large",
                node_count=3,
                gpu_per_node=2,
                cpu_per_node=16,
                memory_per_node=64,
                storage_per_node=500,
                auto_scaling=True,
                min_nodes=2,
                max_nodes=10
            ),
            "training-cluster": DeploymentConfig(
                name="training-cluster",
                environment="prod",
                instance_type="training",
                node_count=4,
                gpu_per_node=4,
                cpu_per_node=32,
                memory_per_node=128,
                storage_per_node=1000,
                auto_scaling=True,
                min_nodes=2,
                max_nodes=8
            )
        }
    
    def _load_credentials(self) -> TensorDockCredentials:
        """Load credentials from file or environment"""
        # Try environment variables first
        client_id = os.getenv("TENSORDOCK_CLIENT_ID")
        api_token = os.getenv("TENSORDOCK_API_TOKEN")
        
        if client_id and api_token:
            return TensorDockCredentials(client_id=client_id, api_token=api_token)
        
        # Try file
        if Path(self.credentials_file).exists():
            with open(self.credentials_file, 'r') as f:
                data = json.load(f)
                return TensorDockCredentials(
                    client_id=data["client_id"],
                    api_token=data["api_token"]
                )
        
        # Use hardcoded credentials for demo
        return TensorDockCredentials(
            client_id="6f71b631-5a32-42f1-94a5-d089adffdb24",
            api_token = os.environ.get("TOKEN_API_TOKEN", "rxOI1pnIZ9UL3J8MZmMmYBkKk7EwPdyS")
        )
    
    async def deploy_environment(self, config_name: str) -> List[str]:
        """Deploy a complete environment"""
        if config_name not in self.deployment_configs:
            raise ValueError(f"Unknown deployment config: {config_name}")
        
        config = self.deployment_configs[config_name]
        logger.info(f"Deploying {config_name} environment: {config.name}")
        
        instances = []
        
        async with self.provider:
            for i in range(config.node_count):
                node_name = f"{config.name}-node-{i+1}"
                
                try:
                    instance = await self.provider.create_ml_instance(
                        name=node_name,
                        instance_type=config.instance_type
                    )
                    instances.append(instance.id)
                    logger.info(f"Created node: {node_name} ({instance.id})")
                    
                except Exception as e:
                    logger.error(f"Failed to create node {node_name}: {e}")
                    # Clean up created instances
                    for instance_id in instances:
                        await self.provider.delete_instance(instance_id)
                    raise
        
        # Save deployment info
        await self._save_deployment_info(config_name, config, instances)
        
        return instances
    
    async def _save_deployment_info(self, config_name: str, config: DeploymentConfig, instances: List[str]):
        """Save deployment information"""
        deployment_info = {
            "config_name": config_name,
            "config": config.to_dict(),
            "instances": instances,
            "deployed_at": str(asyncio.get_event_loop().time()),
            "status": "deployed"
        }
        
        deployments_dir = Path("deployments")
        deployments_dir.mkdir(exist_ok=True)
        
        deployment_file = deployments_dir / f"{config_name}_deployment.json"
        with open(deployment_file, 'w') as f:
            json.dump(deployment_info, f, indent=2)
        
        logger.info(f"Saved deployment info to {deployment_file}")
    
    async def get_deployment_status(self, config_name: str) -> Dict[str, Any]:
        """Get deployment status"""
        deployment_file = Path(f"deployments/{config_name}_deployment.json")
        
        if not deployment_file.exists():
            return {"status": "not_found"}
        
        with open(deployment_file, 'r') as f:
            deployment_info = json.load(f)
        
        # Get current instance status
        async with self.provider:
            instances = []
            total_cost = 0.0
            
            for instance_id in deployment_info["instances"]:
                instance = await self.provider.get_instance(instance_id)
                if instance:
                    instances.append({
                        "id": instance.id,
                        "name": instance.name,
                        "status": instance.status.value,
                        "ip": instance.ip_address,
                        "hourly_cost": instance.hourly_cost
                    })
                    total_cost += instance.hourly_cost
        
        return {
            "config": deployment_info["config"],
            "instances": instances,
            "total_hourly_cost": total_cost,
            "deployed_at": deployment_info["deployed_at"],
            "node_count": len(instances),
            "running_nodes": len([i for i in instances if i["status"] == "running"])
        }
    
    async def scale_deployment(self, config_name: str, target_nodes: int) -> List[str]:
        """Scale deployment up or down"""
        deployment_file = Path(f"deployments/{config_name}_deployment.json")
        
        if not deployment_file.exists():
            raise ValueError(f"Deployment not found: {config_name}")
        
        with open(deployment_file, 'r') as f:
            deployment_info = json.load(f)
        
        config = DeploymentConfig(**deployment_info["config"])
        current_instances = deployment_info["instances"]
        
        if target_nodes > len(current_instances):
            # Scale up
            return await self._scale_up(config_name, config, current_instances, target_nodes)
        elif target_nodes < len(current_instances):
            # Scale down
            return await self._scale_down(config_name, config, current_instances, target_nodes)
        else:
            return current_instances
    
    async def _scale_up(self, config_name: str, config: DeploymentConfig, 
                       current_instances: List[str], target_nodes: int) -> List[str]:
        """Scale deployment up"""
        logger.info(f"Scaling up {config_name} from {len(current_instances)} to {target_nodes} nodes")
        
        new_instances = []
        
        async with self.provider:
            for i in range(len(current_instances), target_nodes):
                node_name = f"{config.name}-node-{i+1}"
                
                try:
                    instance = await self.provider.create_ml_instance(
                        name=node_name,
                        instance_type=config.instance_type
                    )
                    new_instances.append(instance.id)
                    logger.info(f"Created new node: {node_name} ({instance.id})")
                    
                except Exception as e:
                    logger.error(f"Failed to create node {node_name}: {e}")
                    # Clean up new instances
                    for instance_id in new_instances:
                        await self.provider.delete_instance(instance_id)
                    raise
        
        # Update deployment info
        updated_instances = current_instances + new_instances
        await self._save_deployment_info(config_name, config, updated_instances)
        
        return updated_instances
    
    async def _scale_down(self, config_name: str, config: DeploymentConfig,
                         current_instances: List[str], target_nodes: int) -> List[str]:
        """Scale deployment down"""
        logger.info(f"Scaling down {config_name} from {len(current_instances)} to {target_nodes} nodes")
        
        instances_to_remove = current_instances[target_nodes:]
        remaining_instances = current_instances[:target_nodes]
        
        async with self.provider:
            for instance_id in instances_to_remove:
                try:
                    await self.provider.delete_instance(instance_id)
                    logger.info(f"Deleted instance: {instance_id}")
                except Exception as e:
                    logger.error(f"Failed to delete instance {instance_id}: {e}")
        
        # Update deployment info
        await self._save_deployment_info(config_name, config, remaining_instances)
        
        return remaining_instances
    
    async def destroy_deployment(self, config_name: str) -> bool:
        """Destroy entire deployment"""
        deployment_file = Path(f"deployments/{config_name}_deployment.json")
        
        if not deployment_file.exists():
            logger.warning(f"Deployment not found: {config_name}")
            return True
        
        with open(deployment_file, 'r') as f:
            deployment_info = json.load(f)
        
        instances = deployment_info["instances"]
        
        async with self.provider:
            for instance_id in instances:
                try:
                    await self.provider.delete_instance(instance_id)
                    logger.info(f"Deleted instance: {instance_id}")
                except Exception as e:
                    logger.error(f"Failed to delete instance {instance_id}: {e}")
        
        # Remove deployment file
        deployment_file.unlink()
        logger.info(f"Destroyed deployment: {config_name}")
        
        return True
    
    async def get_cost_report(self, config_name: str, hours: int = 24) -> Dict[str, Any]:
        """Get cost report for deployment"""
        status = await self.get_deployment_status(config_name)
        
        if status["status"] == "not_found":
            return {"error": "Deployment not found"}
        
        total_hourly_cost = status["total_hourly_cost"]
        total_cost = total_hourly_cost * hours
        
        return {
            "deployment": config_name,
            "hourly_cost": total_hourly_cost,
            f"{hours}_hour_cost": total_cost,
            "daily_cost": total_hourly_cost * 24,
            "monthly_cost": total_hourly_cost * 24 * 30,
            "node_count": status["node_count"],
            "cost_per_node": total_hourly_cost / status["node_count"] if status["node_count"] > 0 else 0
        }
    
    def generate_kubernetes_config(self, config_name: str) -> str:
        """Generate Kubernetes configuration for deployment"""
        config = self.deployment_configs.get(config_name)
        if not config:
            raise ValueError(f"Unknown deployment config: {config_name}")
        
        # Generate Kubernetes manifest
        k8s_config = {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "name": config.name,
                "labels": {
                    "app": config.name,
                    "environment": config.environment
                }
            },
            "spec": {
                "replicas": config.node_count,
                "selector": {
                    "matchLabels": {
                        "app": config.name
                    }
                },
                "template": {
                    "metadata": {
                        "labels": {
                            "app": config.name,
                            "environment": config.environment
                        }
                    },
                    "spec": {
                        "containers": [{
                            "name": "ml-worker",
                            "image": "terradev/ml-worker:latest",
                            "resources": {
                                "requests": {
                                    "cpu": f"{config.cpu_per_node}",
                                    "memory": f"{config.memory_per_node}Gi",
                                    "nvidia.com/gpu": str(config.gpu_per_node)
                                },
                                "limits": {
                                    "cpu": f"{config.cpu_per_node}",
                                    "memory": f"{config.memory_per_node}Gi",
                                    "nvidia.com/gpu": str(config.gpu_per_node)
                                }
                            },
                            "env": [
                                {"name": "ENVIRONMENT", "value": config.environment},
                                {"name": "INSTANCE_TYPE", "value": config.instance_type}
                            ]
                        }]
                    }
                }
            }
        }
        
        if config.auto_scaling:
            # Add HPA configuration
            hpa_config = {
                "apiVersion": "autoscaling/v2",
                "kind": "HorizontalPodAutoscaler",
                "metadata": {
                    "name": f"{config.name}-hpa"
                },
                "spec": {
                    "scaleTargetRef": {
                        "apiVersion": "apps/v1",
                        "kind": "Deployment",
                        "name": config.name
                    },
                    "minReplicas": config.min_nodes,
                    "maxReplicas": config.max_nodes,
                    "metrics": [{
                        "type": "Resource",
                        "resource": {
                            "name": "cpu",
                            "target": {
                                "type": "Utilization",
                                "averageUtilization": 70
                            }
                        }
                    }]
                }
            }
            
            return yaml.dump(k8s_config) + "\n---\n" + yaml.dump(hpa_config)
        
        return yaml.dump(k8s_config)
    
    async def health_check(self, config_name: str) -> Dict[str, Any]:
        """Perform health check on deployment"""
        status = await self.get_deployment_status(config_name)
        
        if status["status"] == "not_found":
            return {"healthy": False, "reason": "Deployment not found"}
        
        healthy_nodes = 0
        unhealthy_nodes = []
        
        for instance in status["instances"]:
            if instance["status"] == "running":
                healthy_nodes += 1
            else:
                unhealthy_nodes.append(instance["id"])
        
        is_healthy = healthy_nodes == status["node_count"]
        
        return {
            "healthy": is_healthy,
            "healthy_nodes": healthy_nodes,
            "unhealthy_nodes": unhealthy_nodes,
            "total_nodes": status["node_count"],
            "health_percentage": (healthy_nodes / status["node_count"]) * 100 if status["node_count"] > 0 else 0
        }

# CLI interface
async def main():
    """CLI interface for deployment management"""
    import sys
    
    manager = TensorDockDeploymentManager()
    
    if len(sys.argv) < 2:
        logging.info("Usage: python tensordock_deployment.py <command> [args]")
        logging.info("Commands:")
        logging.info("  deploy <config_name> - Deploy environment")
        logging.info("  status <config_name> - Get deployment status")
        logging.info("  scale <config_name> <nodes> - Scale deployment")
        logging.info("  destroy <config_name> - Destroy deployment")
        logging.info("  cost <config_name> [hours] - Get cost report")
        logging.info("  health <config_name> - Health check")
        logging.info("  k8s <config_name> - Generate Kubernetes config")
        logging.info("  list - List available configurations")
        return
    
    command = sys.argv[1]
    
    if command == "list":
        logging.info("Available configurations:")
        # TODO: OPTIMIZATION - Use more efficient pattern for .keys() iteration
# ('config_name', 'manager.deployment_configs'):
            config = manager.deployment_configs[config_name]
            logging.info(f"  {config_name}: {config.node_count} nodes, {config.instance_type}")
    
    elif command == "deploy":
        if len(sys.argv) < 3:
            logging.info("Usage: python tensordock_deployment.py deploy <config_name>")
            return
        
        config_name = sys.argv[2]
        try:
            instances = await manager.deploy_environment(config_name)
            logging.info(f"Deployed {config_name} with {len(instances)
            logging.info(f"Instance IDs: {instances}")
        except Exception as e:
            logging.info(f"Deployment failed: {e}")
    
    elif command == "status":
        if len(sys.argv) < 3:
            logging.info("Usage: python tensordock_deployment.py status <config_name>")
            return
        
        config_name = sys.argv[2]
        status = await manager.get_deployment_status(config_name)
        logging.info(json.dumps(status, indent=2)
    
    elif command == "scale":
        if len(sys.argv) < 4:
            logging.info("Usage: python tensordock_deployment.py scale <config_name> <nodes>")
            return
        
        config_name = sys.argv[2]
        target_nodes = int(sys.argv[3])
        
        try:
            instances = await manager.scale_deployment(config_name, target_nodes)
            logging.info(f"Scaled {config_name} to {len(instances)
        except Exception as e:
            logging.info(f"Scaling failed: {e}")
    
    elif command == "destroy":
        if len(sys.argv) < 3:
            logging.info("Usage: python tensordock_deployment.py destroy <config_name>")
            return
        
        config_name = sys.argv[2]
        
        try:
            success = await manager.destroy_deployment(config_name)
            if success:
                logging.info(f"Destroyed deployment: {config_name}")
            else:
                logging.info(f"Failed to destroy deployment: {config_name}")
        except Exception as e:
            logging.info(f"Destruction failed: {e}")
    
    elif command == "cost":
        if len(sys.argv) < 3:
            logging.info("Usage: python tensordock_deployment.py cost <config_name> [hours]")
            return
        
        config_name = sys.argv[2]
        hours = int(sys.argv[3]) if len(sys.argv) > 3 else 24
        
        try:
            report = await manager.get_cost_report(config_name, hours)
            logging.info(json.dumps(report, indent=2)
        except Exception as e:
            logging.info(f"Cost report failed: {e}")
    
    elif command == "health":
        if len(sys.argv) < 3:
            logging.info("Usage: python tensordock_deployment.py health <config_name>")
            return
        
        config_name = sys.argv[2]
        
        try:
            health = await manager.health_check(config_name)
            logging.info(json.dumps(health, indent=2)
        except Exception as e:
            logging.info(f"Health check failed: {e}")
    
    elif command == "k8s":
        if len(sys.argv) < 3:
            logging.info("Usage: python tensordock_deployment.py k8s <config_name>")
            return
        
        config_name = sys.argv[2]
        
        try:
            k8s_config = manager.generate_kubernetes_config(config_name)
            logging.info(k8s_config)
        except Exception as e:
            logging.info(f"Kubernetes config generation failed: {e}")
    
    else:
        logging.info(f"Unknown command: {command}")

if __name__ == "__main__":
    asyncio.run(main())
