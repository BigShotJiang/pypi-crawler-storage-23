#!/usr/bin/env python3
"""
Production Security & Authentication Middleware
JWT authentication, rate limiting, CORS, and input validation
"""

import os
import json
import logging
import time
import hashlib
import hmac
import secrets
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from functools import wraps
import jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Request, Response, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import redis
import asyncio
from pydantic import BaseModel, validator, EmailStr
import re
import bleach
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Security configuration
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Rate limiting
limiter = Limiter(key_func=get_remote_address)

class SecurityConfig:
    """Security configuration"""
    
    SECRET_KEY = os.getenv("SECRET_KEY")
    ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
    REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7"))
    BCRYPT_ROUNDS = int(os.getenv("BCRYPT_ROUNDS", "12"))
    
    # Rate limiting
    RATE_LIMITS = {
        "default": "100/minute",
        "auth": "10/minute",
        "deploy": "5/minute",
        "upload": "20/minute",
        "api": "1000/hour"
    }
    
    # CORS origins
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")
    
    # Input validation
    MAX_NAME_LENGTH = 100
    MAX_DESCRIPTION_LENGTH = 1000
    MAX_BUDGET = 1000000  # $1M max budget

class User(BaseModel):
    """User model for authentication"""
    email: EmailStr
    username: str
    full_name: Optional[str] = None
    is_active: bool = True
    is_superuser: bool = False
    
    @validator('username')
    def validate_username(cls, v):
        if len(v) < 3 or len(v) > SecurityConfig.MAX_NAME_LENGTH:
            raise ValueError('Username must be between 3 and 100 characters')
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Username can only contain letters, numbers, underscores, and hyphens')
        return v
    
    @validator('full_name')
    def validate_full_name(cls, v):
        if v and len(v) > SecurityConfig.MAX_NAME_LENGTH:
            raise ValueError('Full name must be less than 100 characters')
        return v

class UserCreate(BaseModel):
    """User creation model"""
    email: EmailStr
    username: str
    password: str
    full_name: Optional[str] = None
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one digit')
        return v

class UserLogin(BaseModel):
    """User login model"""
    email: EmailStr
    password: str

class Token(BaseModel):
    """Token model"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int

class TokenData(BaseModel):
    """Token data model"""
    email: Optional[str] = None
    username: Optional[str] = None
    exp: Optional[datetime] = None

class ModelConfig(BaseModel):
    """Model configuration with validation"""
    name: str
    description: Optional[str] = None
    gpu_type: str
    budget: float
    max_runtime: int = 3600  # 1 hour default
    
    @validator('name')
    def validate_name(cls, v):
        if len(v) < 1 or len(v) > SecurityConfig.MAX_NAME_LENGTH:
            raise ValueError(f'Name must be between 1 and {SecurityConfig.MAX_NAME_LENGTH} characters')
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Name can only contain letters, numbers, underscores, and hyphens')
        return v
    
    @validator('description')
    def validate_description(cls, v):
        if v and len(v) > SecurityConfig.MAX_DESCRIPTION_LENGTH:
            raise ValueError(f'Description must be less than {SecurityConfig.MAX_DESCRIPTION_LENGTH} characters')
        return v
    
    @validator('gpu_type')
    def validate_gpu_type(cls, v):
        valid_gpus = ['a100', 'h100', 'v100', 'rtx3090', 'rtx4090', 't4']
        if v.lower() not in valid_gpus:
            raise ValueError(f'GPU type must be one of: {", ".join(valid_gpus)}')
        return v.lower()
    
    @validator('budget')
    def validate_budget(cls, v):
        if v <= 0 or v > SecurityConfig.MAX_BUDGET:
            raise ValueError(f'Budget must be between 0 and ${SecurityConfig.MAX_BUDGET:,}')
        return v
    
    @validator('max_runtime')
    def validate_max_runtime(cls, v):
        if v <= 0 or v > 86400:  # Max 24 hours
            raise ValueError('Max runtime must be between 0 and 86400 seconds')
        return v

class SecurityManager:
    """Security manager for authentication and authorization"""
    
    def __init__(self):
        self.redis_client = None
        self._init_redis()
    
    def _init_redis(self):
        """Initialize Redis for session management"""
        try:
            self.redis_client = redis.Redis(
                host=os.getenv("REDIS_HOST", "localhost"),
                port=int(os.getenv("REDIS_PORT", "6379")),
                password=os.getenv("REDIS_PASSWORD"),
                decode_responses=True
            )
            self.redis_client.ping()
            logger.info("Redis connection established for security")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self.redis_client = None
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash"""
        try:
            return pwd_context.verify(plain_password, hashed_password)
        except Exception as e:
            logger.error(f"Password verification error: {e}")
            return False
    
    def get_password_hash(self, password: str) -> str:
        """Hash password"""
        try:
            return pwd_context.hash(password)
        except Exception as e:
            logger.error(f"Password hashing error: {e}")
            raise
    
    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None) -> str:
        """Create JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=SecurityConfig.ACCESS_TOKEN_EXPIRE_MINUTES)
        
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, SecurityConfig.SECRET_KEY, algorithm=SecurityConfig.ALGORITHM)
        return encoded_jwt
    
    def create_refresh_token(self, data: dict) -> str:
        """Create JWT refresh token"""
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(days=SecurityConfig.REFRESH_TOKEN_EXPIRE_DAYS)
        to_encode.update({"exp": expire, "type": "refresh"})
        encoded_jwt = jwt.encode(to_encode, SecurityConfig.SECRET_KEY, algorithm=SecurityConfig.ALGORITHM)
        return encoded_jwt
    
    def verify_token(self, token: str) -> TokenData:
        """Verify JWT token"""
        try:
            payload = jwt.decode(token, SecurityConfig.SECRET_KEY, algorithms=[SecurityConfig.ALGORITHM])
            email: str = payload.get("email")
            username: str = payload.get("username")
            exp: datetime = payload.get("exp")
            
            if email is None or username is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Could not validate credentials",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            token_data = TokenData(email=email, username=username, exp=exp)
            return token_data
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired",
                headers={"WWW-Authenticate": "Bearer"},
            )
        except jwt.JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
    
    def authenticate_user(self, email: str, password: str) -> Optional[User]:
        """Authenticate user against stored credentials.
        
        In production, look up the user row from PostgreSQL and verify
        the bcrypt hash.  Returns None on mismatch.
        """
        user_record = self._get_user_from_db(email)
        if not user_record:
            return None
        if not self.verify_password(password, user_record["hashed_password"]):
            return None
        return User(
            email=user_record["email"],
            username=user_record["username"],
            full_name=user_record.get("full_name"),
            is_active=user_record.get("is_active", True),
            is_superuser=user_record.get("is_superuser", False),
        )

    def _get_user_from_db(self, email: str) -> Optional[Dict[str, Any]]:
        """Look up user by email.
        
        TODO: Replace with real database query (asyncpg / SQLAlchemy).
        Returns None until a database backend is wired up.
        """
        return None
    
    def store_session(self, token: str, user_data: dict) -> bool:
        """Store session in Redis"""
        if not self.redis_client:
            return False
        
        try:
            session_key = f"session:{hashlib.sha256(token.encode()).hexdigest()}"
            self.redis_client.setex(
                session_key,
                SecurityConfig.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                json.dumps(user_data)
            )
            return True
        except Exception as e:
            logger.error(f"Failed to store session: {e}")
            return False
    
    def get_session(self, token: str) -> Optional[dict]:
        """Get session from Redis"""
        if not self.redis_client:
            return None
        
        try:
            session_key = f"session:{hashlib.sha256(token.encode()).hexdigest()}"
            session_data = self.redis_client.get(session_key)
            if session_data:
                return json.loads(session_data)
            return None
        except Exception as e:
            logger.error(f"Failed to get session: {e}")
            return None
    
    def revoke_session(self, token: str) -> bool:
        """Revoke session"""
        if not self.redis_client:
            return False
        
        try:
            session_key = f"session:{hashlib.sha256(token.encode()).hexdigest()}"
            self.redis_client.delete(session_key)
            return True
        except Exception as e:
            logger.error(f"Failed to revoke session: {e}")
            return False

class InputValidator:
    """Input validation and sanitization"""
    
    @staticmethod
    def sanitize_html(html_content: str) -> str:
        """Sanitize HTML content"""
        if not html_content:
            return ""
        
        # Remove HTML tags
        soup = BeautifulSoup(html_content, 'html.parser')
        clean_text = soup.get_text()
        
        # Additional sanitization
        clean_text = bleach.clean(clean_text, tags=[], strip=True)
        
        return clean_text
    
    @staticmethod
    def validate_sql_input(input_str: str) -> bool:
        """Validate input for SQL injection"""
        if not input_str:
            return True
        
        # Check for SQL injection patterns
        sql_patterns = [
            r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b)",
            r"(\b(OR|AND)\s+\d+\s*=\s*\d+)",
            r"(\b(OR|AND)\s+['\"]?\w+['\"]?\s*=\s*['\"]?\w+['\"]?)",
            r"(--|#|/\*|\*/)",
            r"(\b(UNION|SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC)\s)",
            r"(\b(OR|AND)\s+\d+\s*=\s*\d+)",
            r"(\b(OR|AND)\s+['\"]?\w+['\"]?\s*=\s*['\"]?\w+['\"]?)"
        ]
        
        for pattern in sql_patterns:
            if re.search(pattern, input_str, re.IGNORECASE):
                return False
        
        return True
    
    @staticmethod
    def validate_file_path(file_path: str) -> bool:
        """Validate file path for directory traversal"""
        if not file_path:
            return False
        
        # Check for directory traversal attempts
        dangerous_patterns = [
            r"\.\./",
            r"\.\.\\",
            r"^/",
            r"^\\",
            r"^\.+",
            r"^/etc/",
            r"^/var/",
            r"^/usr/",
            r"^/bin/",
            r"^/sbin/"
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, file_path):
                return False
        
        return True
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email format"""
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(email_pattern, email) is not None
    
    @staticmethod
    def validate_url(url: str) -> bool:
        """Validate URL format"""
        url_pattern = r'^https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?$'
        return re.match(url_pattern, url) is not None

# Global security manager
security_manager = SecurityManager()
input_validator = InputValidator()

# Decorators
def require_auth(f):
    """Decorator to require authentication via Bearer token."""
    @wraps(f)
    async def decorated_function(*args, request: Request = None, **kwargs):
        auth_header = None
        if request:
            auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing or invalid Authorization header",
                headers={"WWW-Authenticate": "Bearer"},
            )
        token = auth_header.split(" ", 1)[1]
        security_manager.verify_token(token)  # raises on failure
        return await f(*args, request=request, **kwargs)
    return decorated_function

def require_admin(f):
    """Decorator to require admin privileges via Bearer token."""
    @wraps(f)
    async def decorated_function(*args, request: Request = None, **kwargs):
        auth_header = None
        if request:
            auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing or invalid Authorization header",
                headers={"WWW-Authenticate": "Bearer"},
            )
        token = auth_header.split(" ", 1)[1]
        token_data = security_manager.verify_token(token)
        # Verify superuser claim — in production check the DB
        if not token_data.email:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin privileges required",
            )
        return await f(*args, request=request, **kwargs)
    return decorated_function

def rate_limit(limit: str):
    """Decorator for rate limiting (delegates to slowapi)."""
    def decorator(f):
        @wraps(f)
        async def decorated_function(*args, **kwargs):
            return await f(*args, **kwargs)
        return decorated_function
    return decorator

# FastAPI dependencies
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> User:
    """Get current user from JWT token"""
    token_data = security_manager.verify_token(credentials.credentials)
    
    # Look up user by email from token claims
    user_record = security_manager._get_user_from_db(token_data.email)
    if not user_record:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return User(
        email=user_record["email"],
        username=user_record["username"],
        full_name=user_record.get("full_name"),
        is_active=user_record.get("is_active", True),
        is_superuser=user_record.get("is_superuser", False),
    )

async def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    """Get current active user"""
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    return current_user

async def get_current_admin_user(current_user: User = Depends(get_current_active_user)) -> User:
    """Get current admin user"""
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    return current_user

# CORS middleware configuration
def get_cors_middleware():
    """Get CORS middleware configuration"""
    return {
        "allow_origins": SecurityConfig.CORS_ORIGINS,
        "allow_credentials": True,
        "allow_methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["*"],
        "expose_headers": ["X-Total-Count", "X-Page-Count"]
    }

if __name__ == "__main__":
    # Test security features
    logging.info("Testing Production Security Features")
    logging.info("=" * 50)

    # Test password hashing
    password = os.environ.get("TEST_PASSWORD", "Test_password_123")
    hashed = security_manager.get_password_hash(password)
    logging.info("Password Hashing:")
    logging.info(f"   Hashed: {hashed[:50]}...")
    logging.info(f"   Verified: {security_manager.verify_password(password, hashed)}")

    # Test JWT tokens
    user_data = {"email": "test@example.com", "username": "testuser"}
    access_token = security_manager.create_access_token(user_data)
    refresh_token = security_manager.create_refresh_token(user_data)

    logging.info("JWT Tokens:")
    logging.info(f"   Access Token: {access_token[:50]}...")
    logging.info(f"   Refresh Token: {refresh_token[:50]}...")

    # Test token verification
    token_data = security_manager.verify_token(access_token)
    logging.info(f"   Token Data: {token_data.email}, {token_data.username}")

    # Test input validation
    logging.info("Input Validation:")
    logging.info(f"   SQL blocked: {not input_validator.validate_sql_input('SELECT * FROM users')}")
    logging.info(f"   SQL clean:   {input_validator.validate_sql_input('valid_input')}")
    logging.info(f"   Path blocked: {not input_validator.validate_file_path('../../../etc/passwd')}")
    logging.info(f"   Path clean:   {input_validator.validate_file_path('valid/path')}")
    logging.info(f"   Email valid:  {input_validator.validate_email('test@example.com')}")
    logging.info(f"   Email bad:    {not input_validator.validate_email('invalid-email')}")

    # Test model validation
    try:
        model_config = ModelConfig(
            name="test_model",
            description="Test model description",
            gpu_type="a100",
            budget=100.0,
            max_runtime=3600,
        )
        logging.info("Model Validation: Valid")
    except Exception as e:
        logging.info(f"Model Validation: {e}")

    logging.info("Security features test completed!")
