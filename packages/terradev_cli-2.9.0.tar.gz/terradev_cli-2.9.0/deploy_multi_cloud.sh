#!/bin/bash
# Enhanced Terradev Infrastructure Deployment Script
# Deploys multi-cloud infrastructure with AWS and OCI integration

set -e

# Configuration
ENVIRONMENT=${1:-dev}
AWS_REGION=${2:-us-east-1}
OCI_REGION=${3:-us-ashburn-1}
CLUSTER_NAME="terradev-${ENVIRONMENT}"

echo "🚀 Deploying Enhanced Terradev Multi-Cloud Infrastructure"
echo "Environment: $ENVIRONMENT"
echo "AWS Region: $AWS_REGION"
echo "OCI Region: $OCI_REGION"
echo "Cluster Name: $CLUSTER_NAME"
echo "=================================="

# Check prerequisites
echo "📋 Checking prerequisites..."

# Check for Terraform
if ! command -v terraform &> /dev/null; then
    echo "❌ Terraform not found. Please install Terraform."
    exit 1
fi

# Check for kubectl
if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl not found. Please install kubectl."
    exit 1
fi

# Check for Helm
if ! command -v helm &> /dev/null; then
    echo "❌ Helm not found. Please install Helm."
    exit 1
fi

# Check for OCI CLI
if ! command -v oci &> /dev/null; then
    echo "❌ OCI CLI not found. Please install OCI CLI."
    echo "   Install with: bash -c \"\$(curl -L https://raw.githubusercontent.com/oracle/oci-cli/master/scripts/install/install.sh)\""
    exit 1
fi

# Check AWS credentials
if ! aws sts get-caller-identity &> /dev/null; then
    echo "❌ AWS credentials not configured. Please run 'aws configure'."
    exit 1
fi

# Check OCI credentials
if ! oci setup validate &> /dev/null; then
    echo "❌ OCI credentials not configured. Please run 'oci setup config'."
    exit 1
fi

echo "✅ Prerequisites check passed"

# Get OCI credentials for Terraform
echo "🔧 Getting OCI credentials..."
OCI_TENANCY_OCID=$(oci iam tenancy get --query data.id --raw-output 2>/dev/null || echo "")
OCI_USER_OCID=$(oci iam user get --query data.id --raw-output 2>/dev/null || echo "")
OCI_FINGERPRINT=$(oci setup config get --section DEFAULT --key fingerprint 2>/dev/null || echo "")
OCI_PRIVATE_KEY_PATH=$(oci setup config get --section DEFAULT --key key_file 2>/dev/null || echo "~/.oci/oci_api_key.pem")

if [ -z "$OCI_TENANCY_OCID" ] || [ -z "$OCI_USER_OCID" ]; then
    echo "❌ Could not retrieve OCI credentials. Please check OCI CLI configuration."
    exit 1
fi

echo "✅ OCI credentials retrieved"

# Deploy infrastructure with Terraform
echo "🏗️ Deploying multi-cloud infrastructure with Terraform..."

cd infrastructure/terraform

# Create terraform.tfvars with actual values
cat > terraform.tfvars << EOF
# OCI Configuration
oci_tenancy_ocid = "$OCI_TENANCY_OCID"
oci_user_ocid = "$OCI_USER_OCID"
oci_fingerprint = "$OCI_FINGERPRINT"
oci_private_key_path = "$OCI_PRIVATE_KEY_PATH"
oci_region = "$OCI_REGION"

# AWS Configuration
aws_region = "$AWS_REGION"

# Common Configuration
cluster_name = "$CLUSTER_NAME"
environment = "$ENVIRONMENT"
EOF

# Initialize Terraform
echo "🔧 Initializing Terraform..."
terraform init

# Plan deployment
echo "📋 Planning Terraform deployment..."
terraform plan \
  -var="environment=$ENVIRONMENT" \
  -var="aws_region=$AWS_REGION" \
  -var="oci_region=$OCI_REGION" \
  -var="oci_tenancy_ocid=$OCI_TENANCY_OCID" \
  -var="oci_user_ocid=$OCI_USER_OCID" \
  -var="oci_fingerprint=$OCI_FINGERPRINT" \
  -var="oci_private_key_path=$OCI_PRIVATE_KEY_PATH" \
  -var="cluster_name=$CLUSTER_NAME" \
  -out="terradev.plan"

# Apply infrastructure
echo "📦 Applying Terraform configuration..."
terraform apply terradev.plan

# Get outputs
CLUSTER_ENDPOINT=$(terraform output -raw cluster_endpoint)
DATABASE_ENDPOINT=$(terraform output -raw database_endpoint)
REDIS_ENDPOINT=$(terraform output -raw redis_endpoint)
STORAGE_BUCKET=$(terraform output -raw storage_bucket)
OCI_VCN_ID=$(terraform output -raw oci_vcn_id)
OCI_INSTANCE_ID=$(terraform output -raw oci_instance_id)
OCI_BUDGET_ID=$(terraform output -raw oci_budget_id)

echo "✅ Multi-cloud infrastructure deployed successfully"
echo "📊 AWS Resources:"
echo "   Cluster Endpoint: $CLUSTER_ENDPOINT"
echo "   Database Endpoint: $DATABASE_ENDPOINT"
echo "   Redis Endpoint: $REDIS_ENDPOINT"
echo "   Storage Bucket: $STORAGE_BUCKET"
echo ""
echo "🏢 OCI Resources:"
echo "   VCN ID: $OCI_VCN_ID"
echo "   Instance ID: $OCI_INSTANCE_ID"
echo "   Budget ID: $OCI_BUDGET_ID"

# Configure kubectl for AWS EKS
echo "🔧 Configuring kubectl for AWS EKS..."
aws eks update-kubeconfig --region $AWS_REGION --name $CLUSTER_NAME

# Wait for cluster to be ready
echo "⏳ Waiting for EKS cluster to be ready..."
kubectl wait --for=condition=Ready nodes --all --timeout=300s

# Deploy microservices
echo "🚀 Deploying microservices..."

cd ../kubernetes

# Create namespaces
kubectl apply -f namespaces.yaml

# Apply ConfigMaps and Secrets
kubectl apply -f configmaps.yaml
kubectl apply -f secrets.yaml

# Deploy microservices
kubectl apply -f microservices.yaml

# Wait for deployments to be ready
echo "⏳ Waiting for microservices to be ready..."
kubectl wait --for=condition=available --timeout=300s deployment --all -n terradev-system

# Get service URLs
echo "🔗 Getting service URLs..."

# Get LoadBalancer IP for ingress
INGRESS_IP=""
while [ -z "$INGRESS_IP" ]; do
    echo "Waiting for Ingress LoadBalancer IP..."
    INGRESS_IP=$(kubectl get service nginx-ingress-ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
    if [ -z "$INGRESS_IP" ]; then
        INGRESS_IP=$(kubectl get service nginx-ingress-ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    fi
    sleep 10
done

echo "✅ Ingress available at: $INGRESS_IP"

# Setup DNS (manual step required)
echo "🌐 DNS Setup Required:"
echo "   Please create DNS records:"
echo "   api.terradev.com -> $INGRESS_IP"
echo "   app.terradev.com -> $INGRESS_IP"

# Get Grafana credentials
GRAFANA_PASSWORD=$(kubectl get secret prometheus-grafana -n monitoring -o jsonpath='{.data.admin-password}' | base64 --decode)
echo "📊 Grafana Credentials:"
echo "   URL: http://$INGRESS_IP/grafana"
echo "   Username: admin"
echo "   Password: $GRAFANA_PASSWORD"

# Get OCI Cloud Advisor recommendations
echo "📊 Getting OCI Cloud Advisor recommendations..."
if command -v python3 &> /dev/null; then
    cd ../../
    python3 cloud_advisor_integration.py
    cd infrastructure/terraform
fi

# Verify deployment
echo "🔍 Verifying deployment..."

# Check all pods are running
kubectl get pods -n terradev-system

# Check services
kubectl get services -n terradev-system

# Check ingress
kubectl get ingress -n terradev-system

# Test API Gateway
echo "🧪 Testing API Gateway..."
API_URL="http://$INGRESS_IP/api/status"
if curl -s $API_URL | grep -q "healthy"; then
    echo "✅ API Gateway is healthy"
else
    echo "❌ API Gateway health check failed"
fi

# Test OCI connectivity
echo "🧪 Testing OCI connectivity..."
if oci compute instance get --instance-id $OCI_INSTANCE_ID &> /dev/null; then
    echo "✅ OCI instance is accessible"
else
    echo "❌ OCI instance connectivity failed"
fi

# Cleanup Terraform plan
rm -f terradev.plan

echo ""
echo "🎉 Enhanced Terradev Multi-Cloud Infrastructure Deployment Complete!"
echo "=================================="
echo "📊 AWS Resources:"
echo "   Cluster: $CLUSTER_ENDPOINT"
echo "   API Gateway: http://$INGRESS_IP/api/status"
echo "   Web App: http://$INGRESS_IP"
echo "   Grafana: http://$INGRESS_IP/grafana"
echo "   Database: $DATABASE_ENDPOINT"
echo "   Redis: $REDIS_ENDPOINT"
echo "   Storage: $STORAGE_BUCKET"
echo ""
echo "🏢 OCI Resources:"
echo "   VCN: $OCI_VCN_ID"
echo "   Instance: $OCI_INSTANCE_ID"
echo "   Budget: $OCI_BUDGET_ID"
echo "   Region: $OCI_REGION"
echo ""
echo "📋 Next Steps:"
echo "1. Configure DNS records for api.terradev.com and app.terradev.com"
echo "2. Update application configuration with database and Redis endpoints"
echo "3. Deploy your application containers"
echo "4. Configure monitoring and alerting"
echo "5. Review OCI Cloud Advisor recommendations"
echo "6. Set up cost optimization profiles"
echo ""
echo "🔧 Management Commands:"
echo "   kubectl get pods -n terradev-system"
echo "   kubectl logs -f deployment/terradev-api-gateway -n terradev-system"
echo "   oci compute instance list --compartment-id $OCI_TENANCY_OCID"
echo "   oci optimizer recommendation list --compartment-id $OCI_TENANCY_OCID"
echo "   terraform destroy -var='environment=$ENVIRONMENT' -var='aws_region=$AWS_REGION' -var='oci_region=$OCI_REGION' -var='cluster_name=$CLUSTER_NAME'"
