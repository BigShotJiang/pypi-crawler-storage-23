#!/usr/bin/env python3
"""
Advanced Spot Instance Risk Management & Checkpoint Strategy
Tunable policies for job failure risk and interruption handling
"""

import asyncio
import json
import logging
import time
import statistics
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Callable
from dataclasses import dataclass, asdict
from enum import Enum
import numpy as np
from scipy import stats
import requests
import aiohttp
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class InterruptionRisk(Enum):
    """Interruption risk levels"""
    VERY_LOW = "very_low"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    VERY_HIGH = "very_high"

class CheckpointStrategy(Enum):
    """Checkpoint strategies"""
    NONE = "none"
    PERIODIC = "periodic"
    ADAPTIVE = "adaptive"
    RISK_BASED = "risk_based"
    HYBRID = "hybrid"

@dataclass
class SpotInstanceMetrics:
    """Spot instance performance metrics"""
    provider: str
    instance_type: str
    region: str
    price_history: List[float]
    interruption_history: List[datetime]
    current_price: float
    on_demand_price: float
    discount_percentage: float
    availability_score: float
    last_updated: datetime

@dataclass
class RiskPolicy:
    """Risk management policy configuration"""
    name: str
    max_failure_risk: float  # 0.0 to 1.0
    max_stall_minutes: int
    checkpoint_strategy: CheckpointStrategy
    checkpoint_interval_minutes: int
    backup_regions: List[str]
    failover_enabled: bool
    cost_sensitivity: float  # 0.0 to 1.0
    performance_sensitivity: float  # 0.0 to 1.0

@dataclass
class JobConfiguration:
    """Training job configuration"""
    job_id: str
    provider: str
    instance_type: str
    region: str
    risk_policy: RiskPolicy
    estimated_duration_hours: float
    checkpoint_size_gb: float
    checkpoint_time_minutes: float
    resume_time_minutes: float
    cost_tolerance: float
    deadline: Optional[datetime]

@dataclass
class InterruptionRisk:
    """Interruption risk assessment"""
    provider: str
    instance_type: str
    region: str
    risk_level: InterruptionRisk
    probability_1h: float
    probability_6h: float
    probability_24h: float
    confidence_score: float
    factors: Dict[str, float]
    recommendation: str

@dataclass
class CheckpointPlan:
    """Checkpoint execution plan"""
    job_id: str
    strategy: CheckpointStrategy
    intervals: List[int]  # minutes
    estimated_checkpoints: int
    total_checkpoint_time: float  # minutes
    total_checkpoint_cost: float
    risk_mitigation: float
    cost_overhead: float

class SpotRiskAnalyzer:
    """Advanced spot instance risk analysis"""
    
    def __init__(self):
        self.session = None
        self.instance_metrics = {}
        self.historical_data = {}
        self.risk_models = {}
        self.provider_apis = {
            "aws": {
                "pricing": "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEC2/current/index.json",
                "spot": "https://spot-price.s3.amazonaws.com/spot.js"
            },
            "gcp": {
                "pricing": "https://cloudpricingcalculator.appspot.com/static/data/pricelist.json",
                "preemptible": "https://www.googleapis.com/compute/v1/zones"
            },
            "azure": {
                "pricing": "https://prices.azure.com/api/retail/prices",
                "spot": "https://management.azure.com/subscriptions"
            }
        }
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def fetch_aws_spot_prices(self, region: str = "us-east-1") -> Dict[str, List[float]]:
        """Fetch AWS spot price history"""
        try:
            url = f"https://spot-price.s3.amazonaws.com/spot.js"
            async with self.session.get(url) as response:
                if response.status == 200:
                    data = await response.text()
                    # Parse JavaScript response (simplified)
                    # In production, use AWS API instead
                    return {"mock": [0.1, 0.12, 0.08, 0.15, 0.09]}
        except Exception as e:
            logger.warning(f"Failed to fetch AWS spot prices: {e}")
        
        return {}
    
    async def fetch_gcp_preemptible_prices(self, region: str = "us-central1") -> Dict[str, List[float]]:
        """Fetch GCP preemptible instance prices"""
        try:
            # Mock implementation - use GCP Pricing API in production
            return {"mock": [0.08, 0.10, 0.07, 0.12, 0.08]}
        except Exception as e:
            logger.warning(f"Failed to fetch GCP preemptible prices: {e}")
        
        return {}
    
    async def fetch_azure_spot_prices(self, region: str = "eastus") -> Dict[str, List[float]]:
        """Fetch Azure spot instance prices"""
        try:
            # Mock implementation - use Azure Pricing API in production
            return {"mock": [0.09, 0.11, 0.08, 0.13, 0.09]}
        except Exception as e:
            logger.warning(f"Failed to fetch Azure spot prices: {e}")
        
        return {}
    
    async def collect_provider_data(self, providers: List[str]) -> Dict[str, Dict[str, List[float]]]:
        """Collect pricing data from multiple providers"""
        tasks = []
        
        for provider in providers:
            if provider == "aws":
                tasks.append(self.fetch_aws_spot_prices())
            elif provider == "gcp":
                tasks.append(self.fetch_gcp_preemptible_prices())
            elif provider == "azure":
                tasks.append(self.fetch_azure_spot_prices())
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        provider_data = {}
        for i, provider in enumerate(providers):
            if isinstance(results[i], dict):
                provider_data[provider] = results[i]
        
        return provider_data
    
    def calculate_price_volatility(self, price_history: List[float]) -> float:
        """Calculate price volatility coefficient"""
        if len(price_history) < 2:
            return 0.0
        
        returns = []
        for i in range(1, len(price_history)):
            if price_history[i-1] > 0:
                returns.append((price_history[i] - price_history[i-1]) / price_history[i-1])
        
        if not returns:
            return 0.0
        
        return statistics.stdev(returns) if len(returns) > 1 else 0.0
    
    def calculate_interruption_probability(self, price_history: List[float], 
                                         interruption_history: List[datetime],
                                         time_horizon_hours: int) -> float:
        """Calculate interruption probability for given time horizon"""
        if not price_history or not interruption_history:
            return 0.1  # Default 10% risk
        
        # Historical interruption rate
        now = datetime.now()
        recent_interruptions = [
            intr for intr in interruption_history
            if (now - intr).days <= 30
        ]
        
        if not recent_interruptions:
            historical_rate = 0.05  # 5% base rate
        else:
            historical_rate = len(recent_interruptions) / 30  # Daily rate
        
        # Price volatility factor
        volatility = self.calculate_price_volatility(price_history)
        volatility_factor = min(2.0, 1.0 + volatility * 10)
        
        # Time horizon scaling
        time_factor = min(1.0, time_horizon_hours / 24)
        
        # Combined probability
        probability = historical_rate * volatility_factor * time_factor
        return min(1.0, probability)
    
    def assess_interruption_risk(self, provider: str, instance_type: str, 
                                region: str, price_history: List[float],
                                interruption_history: List[datetime]) -> InterruptionRisk:
        """Comprehensive interruption risk assessment"""
        
        # Calculate probabilities for different time horizons
        prob_1h = self.calculate_interruption_probability(price_history, interruption_history, 1)
        prob_6h = self.calculate_interruption_probability(price_history, interruption_history, 6)
        prob_24h = self.calculate_interruption_probability(price_history, interruption_history, 24)
        
        # Determine risk level
        avg_probability = (prob_1h + prob_6h + prob_24h) / 3
        
        if avg_probability <= 0.05:
            risk_level = InterruptionRisk.VERY_LOW
        elif avg_probability <= 0.10:
            risk_level = InterruptionRisk.LOW
        elif avg_probability <= 0.20:
            risk_level = InterruptionRisk.MEDIUM
        elif avg_probability <= 0.40:
            risk_level = InterruptionRisk.HIGH
        else:
            risk_level = InterruptionRisk.VERY_HIGH
        
        # Calculate confidence score
        volatility = self.calculate_price_volatility(price_history)
        confidence_score = max(0.5, 1.0 - volatility)
        
        # Risk factors
        factors = {
            "price_volatility": volatility,
            "historical_interruptions": len(interruption_history),
            "price_trend": np.polyfit(range(len(price_history)), price_history, 1)[0] if len(price_history) > 1 else 0,
            "recent_activity": len([i for i in interruption_history if (datetime.now() - i).hours <= 24])
        }
        
        # Recommendation
        if risk_level in [InterruptionRisk.VERY_LOW, InterruptionRisk.LOW]:
            recommendation = "Safe for long-running jobs with minimal checkpointing"
        elif risk_level == InterruptionRisk.MEDIUM:
            recommendation = "Moderate risk - use periodic checkpointing"
        elif risk_level == InterruptionRisk.HIGH:
            recommendation = "High risk - use frequent checkpointing and failover"
        else:
            recommendation = "Very high risk - avoid or use on-demand instances"
        
        return InterruptionRisk(
            provider=provider,
            instance_type=instance_type,
            region=region,
            risk_level=risk_level,
            probability_1h=prob_1h,
            probability_6h=prob_6h,
            probability_24h=prob_24h,
            confidence_score=confidence_score,
            factors=factors,
            recommendation=recommendation
        )

class CheckpointManager:
    """Advanced checkpoint strategy management"""
    
    def __init__(self):
        self.strategies = {
            CheckpointStrategy.NONE: self._no_checkpoint_strategy,
            CheckpointStrategy.PERIODIC: self._periodic_checkpoint_strategy,
            CheckpointStrategy.ADAPTIVE: self._adaptive_checkpoint_strategy,
            CheckpointStrategy.RISK_BASED: self._risk_based_checkpoint_strategy,
            CheckpointStrategy.HYBRID: self._hybrid_checkpoint_strategy
        }
    
    def _no_checkpoint_strategy(self, job_config: JobConfiguration) -> CheckpointPlan:
        """No checkpointing strategy"""
        return CheckpointPlan(
            job_id=job_config.job_id,
            strategy=CheckpointStrategy.NONE,
            intervals=[],
            estimated_checkpoints=0,
            total_checkpoint_time=0.0,
            total_checkpoint_cost=0.0,
            risk_mitigation=0.0,
            cost_overhead=0.0
        )
    
    def _periodic_checkpoint_strategy(self, job_config: JobConfiguration) -> CheckpointPlan:
        """Fixed interval checkpointing"""
        interval = job_config.risk_policy.checkpoint_interval_minutes
        duration_minutes = job_config.estimated_duration_hours * 60
        
        checkpoints = int(duration_minutes / interval)
        intervals = [i * interval for i in range(1, checkpoints + 1)]
        
        total_time = checkpoints * job_config.checkpoint_time_minutes
        # Estimate cost based on instance price and checkpoint time
        hourly_cost = 0.5  # Mock hourly cost
        total_cost = (total_time / 60) * hourly_cost
        
        return CheckpointPlan(
            job_id=job_config.job_id,
            strategy=CheckpointStrategy.PERIODIC,
            intervals=intervals,
            estimated_checkpoints=checkpoints,
            total_checkpoint_time=total_time,
            total_checkpoint_cost=total_cost,
            risk_mitigation=0.7,  # 70% risk reduction
            cost_overhead=total_cost / (duration_minutes / 60 * hourly_cost)
        )
    
    def _adaptive_checkpoint_strategy(self, job_config: JobConfiguration) -> CheckpointPlan:
        """Adaptive checkpointing based on job progress"""
        duration_minutes = job_config.estimated_duration_hours * 60
        
        # Adaptive intervals: more frequent at beginning, less at end
        base_interval = job_config.risk_policy.checkpoint_interval_minutes
        intervals = []
        
        # First 25%: more frequent
        for i in range(1, int(duration_minutes * 0.25 / base_interval) + 1):
            intervals.append(i * base_interval)
        
        # Middle 50%: normal frequency
        for i in range(int(duration_minutes * 0.25 / base_interval) + 1, 
                      int(duration_minutes * 0.75 / base_interval) + 1):
            intervals.append(i * base_interval * 2)
        
        # Last 25%: less frequent
        for i in range(int(duration_minutes * 0.75 / base_interval) + 1,
                      int(duration_minutes / base_interval) + 1):
            intervals.append(i * base_interval * 3)
        
        checkpoints = len(intervals)
        total_time = checkpoints * job_config.checkpoint_time_minutes
        hourly_cost = 0.5
        total_cost = (total_time / 60) * hourly_cost
        
        return CheckpointPlan(
            job_id=job_config.job_id,
            strategy=CheckpointStrategy.ADAPTIVE,
            intervals=intervals,
            estimated_checkpoints=checkpoints,
            total_checkpoint_time=total_time,
            total_checkpoint_cost=total_cost,
            risk_mitigation=0.8,  # 80% risk reduction
            cost_overhead=total_cost / (duration_minutes / 60 * hourly_cost)
        )
    
    def _risk_based_checkpoint_strategy(self, job_config: JobConfiguration, 
                                      risk_assessment: InterruptionRisk) -> CheckpointPlan:
        """Risk-based checkpointing"""
        duration_minutes = job_config.estimated_duration_hours * 60
        
        # Adjust checkpoint frequency based on risk
        base_interval = job_config.risk_policy.checkpoint_interval_minutes
        
        if risk_assessment.risk_level == InterruptionRisk.VERY_LOW:
            interval_multiplier = 3.0
        elif risk_assessment.risk_level == InterruptionRisk.LOW:
            interval_multiplier = 2.0
        elif risk_assessment.risk_level == InterruptionRisk.MEDIUM:
            interval_multiplier = 1.0
        elif risk_assessment.risk_level == InterruptionRisk.HIGH:
            interval_multiplier = 0.5
        else:  # VERY_HIGH
            interval_multiplier = 0.25
        
        adjusted_interval = int(base_interval * interval_multiplier)
        checkpoints = int(duration_minutes / adjusted_interval)
        intervals = [i * adjusted_interval for i in range(1, checkpoints + 1)]
        
        total_time = checkpoints * job_config.checkpoint_time_minutes
        hourly_cost = 0.5
        total_cost = (total_time / 60) * hourly_cost
        
        # Risk mitigation based on frequency
        risk_mitigation = min(0.95, 0.5 + (1.0 / interval_multiplier) * 0.45)
        
        return CheckpointPlan(
            job_id=job_config.job_id,
            strategy=CheckpointStrategy.RISK_BASED,
            intervals=intervals,
            estimated_checkpoints=checkpoints,
            total_checkpoint_time=total_time,
            total_checkpoint_cost=total_cost,
            risk_mitigation=risk_mitigation,
            cost_overhead=total_cost / (duration_minutes / 60 * hourly_cost)
        )
    
    def _hybrid_checkpoint_strategy(self, job_config: JobConfiguration, 
                                  risk_assessment: InterruptionRisk) -> CheckpointPlan:
        """Hybrid strategy combining multiple approaches"""
        duration_minutes = job_config.estimated_duration_hours * 60
        
        # Combine periodic and risk-based approaches
        periodic_plan = self._periodic_checkpoint_strategy(job_config)
        risk_based_plan = self._risk_based_checkpoint_strategy(job_config, risk_assessment)
        
        # Take the more conservative (frequent) checkpointing
        if periodic_plan.estimated_checkpoints > risk_based_plan.estimated_checkpoints:
            return periodic_plan
        else:
            return risk_based_plan
    
    def create_checkpoint_plan(self, job_config: JobConfiguration, 
                             risk_assessment: Optional[InterruptionRisk] = None) -> CheckpointPlan:
        """Create optimal checkpoint plan"""
        strategy = job_config.risk_policy.checkpoint_strategy
        
        if strategy == CheckpointStrategy.RISK_BASED and risk_assessment:
            return self._risk_based_checkpoint_strategy(job_config, risk_assessment)
        elif strategy == CheckpointStrategy.HYBRID and risk_assessment:
            return self._hybrid_checkpoint_strategy(job_config, risk_assessment)
        else:
            return self.strategies[strategy](job_config)

class SpotJobOptimizer:
    """Main spot instance job optimization system"""
    
    def __init__(self):
        self.risk_analyzer = SpotRiskAnalyzer()
        self.checkpoint_manager = CheckpointManager()
        self.job_configs = {}
        self.active_jobs = {}
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self.risk_analyzer.__aenter__()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.risk_analyzer.__aexit__(exc_type, exc_val, exc_tb)
    
    def create_risk_policy(self, name: str, max_failure_risk: float = 0.1,
                          max_stall_minutes: int = 10,
                          checkpoint_strategy: CheckpointStrategy = CheckpointStrategy.PERIODIC,
                          checkpoint_interval_minutes: int = 30,
                          backup_regions: List[str] = None,
                          failover_enabled: bool = True,
                          cost_sensitivity: float = 0.5,
                          performance_sensitivity: float = 0.5) -> RiskPolicy:
        """Create a risk management policy"""
        return RiskPolicy(
            name=name,
            max_failure_risk=max_failure_risk,
            max_stall_minutes=max_stall_minutes,
            checkpoint_strategy=checkpoint_strategy,
            checkpoint_interval_minutes=checkpoint_interval_minutes,
            backup_regions=backup_regions or [],
            failover_enabled=failover_enabled,
            cost_sensitivity=cost_sensitivity,
            performance_sensitivity=performance_sensitivity
        )
    
    async def assess_job_risk(self, job_config: JobConfiguration) -> InterruptionRisk:
        """Assess interruption risk for a specific job"""
        # Mock price history and interruption history
        price_history = [0.1, 0.12, 0.08, 0.15, 0.09, 0.11, 0.13]
        interruption_history = [
            datetime.now() - timedelta(hours=48),
            datetime.now() - timedelta(hours=72),
            datetime.now() - timedelta(days=5)
        ]
        
        return self.risk_analyzer.assess_interruption_risk(
            job_config.provider,
            job_config.instance_type,
            job_config.region,
            price_history,
            interruption_history
        )
    
    def optimize_job_placement(self, job_config: JobConfiguration,
                             risk_assessment: InterruptionRisk,
                             provider_options: List[Tuple[str, str, str]]) -> Dict[str, Any]:
        """Optimize job placement across providers and regions"""
        best_options = []
        
        for provider, instance_type, region in provider_options:
            # Calculate cost-effectiveness
            hourly_cost = 0.5  # Mock cost
            estimated_cost = hourly_cost * job_config.estimated_duration_hours
            
            # Calculate risk-adjusted cost
            risk_multiplier = 1.0 + risk_assessment.probability_24h
            risk_adjusted_cost = estimated_cost * risk_multiplier
            
            # Check if meets policy requirements
            meets_risk_requirements = risk_assessment.probability_24h <= job_config.risk_policy.max_failure_risk
            meets_stall_requirements = risk_assessment.probability_1h * 60 <= job_config.risk_policy.max_stall_minutes
            
            if meets_risk_requirements and meets_stall_requirements:
                best_options.append({
                    "provider": provider,
                    "instance_type": instance_type,
                    "region": region,
                    "estimated_cost": estimated_cost,
                    "risk_adjusted_cost": risk_adjusted_cost,
                    "risk_assessment": risk_assessment,
                    "meets_requirements": True
                })
        
        # Sort by risk-adjusted cost
        best_options.sort(key=lambda x: x["risk_adjusted_cost"])
        
        return {
            "recommended_option": best_options[0] if best_options else None,
            "all_options": best_options,
            "recommendation": "Use recommended option for optimal cost-risk balance" if best_options else "No suitable options found"
        }
    
    async def create_job_plan(self, job_config: JobConfiguration) -> Dict[str, Any]:
        """Create comprehensive job execution plan"""
        # Assess risk
        risk_assessment = await self.assess_job_risk(job_config)
        
        # Create checkpoint plan
        checkpoint_plan = self.checkpoint_manager.create_checkpoint_plan(job_config, risk_assessment)
        
        # Mock provider options
        provider_options = [
            (job_config.provider, job_config.instance_type, job_config.region),
            ("aws", "p3.2xlarge", "us-west-2"),
            ("gcp", "n1-standard-4", "us-central1"),
            ("azure", "Standard_NC6", "eastus")
        ]
        
        # Optimize placement
        placement_optimization = self.optimize_job_placement(job_config, risk_assessment, provider_options)
        
        return {
            "job_config": job_config,
            "risk_assessment": risk_assessment,
            "checkpoint_plan": checkpoint_plan,
            "placement_optimization": placement_optimization,
            "total_estimated_cost": placement_optimization["recommended_option"]["risk_adjusted_cost"] if placement_optimization["recommended_option"] else 0,
            "estimated_completion_time": job_config.estimated_duration_hours + (checkpoint_plan.total_checkpoint_time / 60),
            "success_probability": 1.0 - risk_assessment.probability_24h
        }

async def main():
    """Main demonstration"""
    logging.info("🔧 Advanced Spot Instance Risk Management")
    logging.info("=" * 50)
    
    async with SpotJobOptimizer() as optimizer:
        # Create risk policies
        conservative_policy = optimizer.create_risk_policy(
            name="conservative",
            max_failure_risk=0.05,
            max_stall_minutes=5,
            checkpoint_strategy=CheckpointStrategy.RISK_BASED,
            checkpoint_interval_minutes=15
        )
        
        balanced_policy = optimizer.create_risk_policy(
            name="balanced",
            max_failure_risk=0.15,
            max_stall_minutes=15,
            checkpoint_strategy=CheckpointStrategy.ADAPTIVE,
            checkpoint_interval_minutes=30
        )
        
        aggressive_policy = optimizer.create_risk_policy(
            name="aggressive",
            max_failure_risk=0.25,
            max_stall_minutes=30,
            checkpoint_strategy=CheckpointStrategy.PERIODIC,
            checkpoint_interval_minutes=60
        )
        
        # Create job configuration
        job_config = JobConfiguration(
            job_id="ml-training-001",
            provider="aws",
            instance_type="p3.2xlarge",
            region="us-east-1",
            risk_policy=balanced_policy,
            estimated_duration_hours=8.0,
            checkpoint_size_gb=2.0,
            checkpoint_time_minutes=5.0,
            resume_time_minutes=10.0,
            cost_tolerance=0.2,
            deadline=datetime.now() + timedelta(hours=12)
        )
        
        logging.info(f"\n📋 Job Configuration:")
        logging.info(f"   Job ID: {job_config.job_id}")
        logging.info(f"   Provider: {job_config.provider}")
        logging.info(f"   Instance: {job_config.instance_type}")
        logging.info(f"   Duration: {job_config.estimated_duration_hours} hours")
        logging.info(f"   Risk Policy: {job_config.risk_policy.name}")
        
        # Create comprehensive plan
        plan = await optimizer.create_job_plan(job_config)
        
        logging.info(f"\n🎯 Risk Assessment:")
        risk = plan["risk_assessment"]
        logging.info(f"   Risk Level: {risk.risk_level.value}")
        logging.info(f"   1H Probability: {risk.probability_1h:.1%}")
        logging.info(f"   6H Probability: {risk.probability_6h:.1%}")
        logging.info(f"   24H Probability: {risk.probability_24h:.1%}")
        logging.info(f"   Recommendation: {risk.recommendation}")
        
        logging.info(f"\n💾 Checkpoint Plan:")
        cp = plan["checkpoint_plan"]
        logging.info(f"   Strategy: {cp.strategy.value}")
        logging.info(f"   Checkpoints: {cp.estimated_checkpoints}")
        logging.info(f"   Total Time: {cp.total_checkpoint_time:.1f} minutes")
        logging.info(f"   Cost Overhead: {cp.cost_overhead:.1%}")
        logging.info(f"   Risk Mitigation: {cp.risk_mitigation:.1%}")
        
        logging.info(f"\n🏆 Placement Optimization:")
        opt = plan["placement_optimization"]
        if opt["recommended_option"]:
            rec = opt["recommended_option"]
            logging.info(f"   Recommended: {rec['provider']} {rec['instance_type']} in {rec['region']}")
            logging.info(f"   Risk-Adjusted Cost: ${rec['risk_adjusted_cost']:.2f}")
        logging.info(f"   Options Found: {len(opt['all_options'])
        
        logging.info(f"\n📊 Overall Plan:")
        logging.info(f"   Total Estimated Cost: ${plan['total_estimated_cost']:.2f}")
        logging.info(f"   Estimated Completion: {plan['estimated_completion_time']:.1f} hours")
        logging.info(f"   Success Probability: {plan['success_probability']:.1%}")
        
        logging.info(f"\n🎯 Risk Management Plan Completed!")

if __name__ == "__main__":
    asyncio.run(main())
