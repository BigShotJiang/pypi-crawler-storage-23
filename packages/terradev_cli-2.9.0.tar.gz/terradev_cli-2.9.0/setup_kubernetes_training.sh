#!/bin/bash
# Kubernetes Training Infrastructure Setup Script

set -e

echo "🚀 Setting up Kubernetes Training Infrastructure"
echo "=============================================="

# Check prerequisites
echo "🔍 Checking prerequisites..."

# Check kubectl
if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl is not installed. Please install kubectl first."
    exit 1
fi

# Check helm
if ! command -v helm &> /dev/null; then
    echo "❌ Helm is not installed. Please install Helm first."
    exit 1
fi

# Check cluster connectivity
echo "🔍 Checking cluster connectivity..."
if ! kubectl cluster-info &> /dev/null; then
    echo "❌ Cannot connect to Kubernetes cluster. Please check your kubeconfig."
    exit 1
fi

echo "✅ Prerequisites check passed"

# Create namespace
echo "📝 Creating training namespace..."
kubectl create namespace training --dry-run=client -o yaml | kubectl apply -f -

# Add Helm repositories
echo "📦 Adding Helm repositories..."
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo add nvidia https://nvidia.github.io/gpu-operator
helm repo update

# Install NVIDIA GPU Operator
echo "🖥️ Installing NVIDIA GPU Operator..."
helm upgrade --install gpu-operator nvidia/gpu-operator \
    --namespace gpu-operator \
    --create-namespace \
    --set operator.defaultRuntime=nvidia-container-runtime \
    --set toolkit.version=v1.13.5 \
    --set driver.version=525.85.05 \
    --set mig.strategy=mixed

# Install Prometheus
echo "📊 Installing Prometheus..."
helm upgrade --install prometheus prometheus-community/kube-prometheus-stack \
    --namespace monitoring \
    --create-namespace \
    --set prometheus.prometheusSpec.storageSpec.volumeClaimTemplate.spec.resources.requests.storage=50Gi \
    --set prometheus.prometheusSpec.retention=30d \
    --set grafana.adminPassword=admin123 \
    --set grafana.sidecar.dashboards.enabled=true \
    --set grafana.sidecar.dashboards.searchNamespace=training \
    --set grafana.sidecar.datasources.enabled=true \
    --set grafana.sidecar.datasources.searchNamespace=training

# Wait for Prometheus to be ready
echo "⏳ Waiting for Prometheus to be ready..."
kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=prometheus -n monitoring --timeout=300s

# Install NVIDIA GPU Exporter
echo "📈 Installing NVIDIA GPU Exporter..."
helm upgrade --install nvidia-gpu-exporter prometheus-community/nvidia-gpu-exporter \
    --namespace monitoring \
    --set config.nvidia.dcgm.enabled=true \
    --set config.nvidia.dcgm.port=9400

# Create GPU monitoring ConfigMap
echo "📝 Creating GPU monitoring configuration..."
kubectl apply -f - <<EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: gpu-monitoring-config
  namespace: monitoring
data:
  gpu-metrics.yml: |
    - name: gpu_utilization
      query: 'rate(nvidia_gpu_utilization_gpu[5m])'
      labels:
        component: gpu
    - name: gpu_memory_usage
      query: 'nvidia_gpu_memory_used_bytes / nvidia_gpu_memory_total_bytes'
      labels:
        component: gpu
    - name: gpu_temperature
      query: 'nvidia_gpu_temperature_gpu'
      labels:
        component: gpu
EOF

# Create training service account
echo "👤 Creating training service account..."
kubectl apply -f - <<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  name: training-sa
  namespace: training
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: training-role
  namespace: training
rules:
- apiGroups: [""]
  resources: ["pods", "services", "configmaps", "secrets"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
- apiGroups: ["batch"]
  resources: ["jobs"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
- apiGroups: ["apps"]
  resources: ["deployments"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: training-rolebinding
  namespace: training
subjects:
- kind: ServiceAccount
  name: training-sa
  namespace: training
roleRef:
  kind: Role
  name: training-role
  apiGroup: rbac.authorization.k8s.io
EOF

# Create storage classes for training workloads
echo "💾 Creating storage classes..."
kubectl apply -f - <<EOF
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: training-ssd
provisioner: kubernetes.io/aws-ebs
parameters:
  type: gp3
  iops: "3000"
  throughput: "125"
  fsType: ext4
allowVolumeExpansion: true
volumeBindingMode: WaitForFirstConsumer
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: training-hdd
provisioner: kubernetes.io/aws-ebs
parameters:
  type: st1
  fsType: ext4
allowVolumeExpansion: true
volumeBindingMode: WaitForFirstUser
EOF

# Create training PVCs
echo "💾 Creating training persistent volumes..."
kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: training-workspace
  namespace: training
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: training-ssd
  resources:
    requests:
      storage: 100Gi
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: training-datasets
  namespace: training
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: training-hdd
  resources:
    requests:
      storage: 500Gi
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: training-models
  namespace: training
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: training-ssd
  resources:
    requests:
      storage: 50Gi
EOF

# Deploy training infrastructure
echo "🚀 Deploying training infrastructure..."
kubectl apply -f kubernetes_training_deployment.yaml

# Create monitoring dashboards
echo "📊 Creating Grafana dashboards..."
kubectl create configmap training-dashboards \
    --from-file=grafana_training_dashboard.json \
    --namespace=monitoring \
    --dry-run=client -o yaml | kubectl apply -f -

# Update Prometheus configuration
echo "📊 Updating Prometheus configuration..."
kubectl create configmap prometheus-config \
    --from-file=prometheus_training_config.yml \
    --namespace=monitoring \
    --dry-run=client -o yaml | kubectl apply -f -

# Restart Prometheus to apply new configuration
echo "🔄 Restarting Prometheus..."
kubectl rollout restart deployment/prometheus -n monitoring

# Wait for training deployment to be ready
echo "⏳ Waiting for training deployment to be ready..."
kubectl wait --for=condition=ready pod -l app=training -n training --timeout=300s

# Get Grafana URL
echo "🔗 Getting Grafana URL..."
GRAFANA_URL=$(kubectl get svc grafana -n monitoring -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
if [ -z "$GRAFANA_URL" ]; then
    GRAFANA_URL=$(kubectl get svc grafana -n monitoring -o jsonpath='{.spec.clusterIP}')
    GRAFANA_URL="http://$GRAFANA_URL:3000"
fi

# Get Prometheus URL
echo "🔗 Getting Prometheus URL..."
PROMETHEUS_URL=$(kubectl get svc prometheus -n monitoring -o jsonpath='{.spec.clusterIP}')
PROMETHEUS_URL="http://$PROMETHEUS_URL:9090"

echo ""
echo "✅ Kubernetes Training Infrastructure Setup Complete!"
echo "=================================================="
echo ""
echo "🎯 Access URLs:"
echo "   Grafana: $GRAFANA_URL (admin/admin123)"
echo "   Prometheus: $PROMETHEUS_URL"
echo ""
echo "📊 Monitoring Features:"
echo "   ✅ GPU utilization monitoring"
echo "   ✅ Training job metrics"
echo "   ✅ Resource usage tracking"
echo "   ✅ Custom dashboards"
echo "   ✅ Alert rules"
echo ""
echo "🚀 Training Features:"
echo "   ✅ GPU-enabled pods"
echo "   ✅ Persistent storage"
echo "   ✅ Auto-scaling"
echo "   ✅ Service accounts"
echo "   ✅ Network policies"
echo ""
echo "🔧 Next Steps:"
echo "   1. Access Grafana to view dashboards"
echo "   2. Deploy training jobs using kubectl"
echo "   3. Monitor GPU utilization"
echo "   4. Set up alerts for training failures"
echo ""
echo "📚 Example Commands:"
echo "   kubectl get pods -n training"
echo "   kubectl logs -f deployment/training-deployment -n training"
echo "   kubectl top pods -n training"
echo "   kubectl exec -it deployment/training-deployment -n training -- bash"
echo ""
echo "🎉 Happy Training!"
