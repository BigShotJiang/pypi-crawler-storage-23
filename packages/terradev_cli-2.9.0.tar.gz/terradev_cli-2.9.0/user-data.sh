#!/bin/bash
# User data script for AWS GPU instances

set -e

echo "Starting GPU instance setup..."

# Update system
apt-get update -y
apt-get upgrade -y

# Install NVIDIA drivers
echo "Installing NVIDIA drivers..."
wget -O /tmp/NVIDIA-Linux-x86_64-525.60.13.run https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-ubuntu2204.pin
mv /tmp/NVIDIA-Linux-x86_64-525.60.13.run /etc/apt/preferences.d/cuda-repository-pin-600
apt-key adv --fetch-keys https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_7b/3bf863cc.pub
add-apt-repository "deb https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/ /"
apt-get update -y

# Install CUDA toolkit
echo "Installing CUDA toolkit..."
apt-get -y install cuda-toolkit-12-2

# Install Docker
echo "Installing Docker..."
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
usermod -aG docker ubuntu

# Install NVIDIA Container Toolkit
echo "Installing NVIDIA Container Toolkit..."
distribution=$(. /etc/os-release;echo $ID$VERSION_ID)
curl -s -L https://nvidia.github.io/nvidia-docker/gpgkey | apt-key add -
curl -s -L https://nvidia.github.io/nvidia-docker/$distribution/nvidia-docker.list | tee /etc/apt/sources.list.d/nvidia-docker.list
apt-get update -y
apt-get install -y nvidia-docker2
systemctl restart docker

# Install Python and required packages
echo "Installing Python and packages..."
apt-get install -y python3 python3-pip python3-venv
pip3 install --upgrade pip

# Create monitoring script
cat > /home/ubuntu/monitor_gpu.sh << 'EOF'
#!/bin/bash
# GPU monitoring script

echo "=== GPU Status ==="
nvidia-smi

echo "=== System Info ==="
free -h
df -h

echo "=== Network ==="
ip addr show

echo "=== Docker Status ==="
docker --version
docker ps

echo "=== Job Duration ==="
echo "Job started at: $(date)"
echo "Expected duration: ${1} hours"
echo "Time remaining: $((${1} * 3600 - $(date +%s) % (${1} * 3600))) seconds"
EOF

chmod +x /home/ubuntu/monitor_gpu.sh

# Create auto-shutdown script
cat > /home/ubuntu/auto_shutdown.sh << 'EOF'
#!/bin/bash
# Auto-shutdown script after job completion

JOB_DURATION_HOURS=${1}
START_TIME=$(date +%s)
END_TIME=$((START_TIME + JOB_DURATION_HOURS * 3600))

echo "Job will run for ${job_duration_hours} hours"
echo "Auto-shutdown scheduled at: $(date -d "+${job_duration_hours} hours" -Iseconds)"

# Monitor and shutdown
while [ $(date +%s) -lt $END_TIME ]; do
    sleep 60
    REMAINING=$((END_TIME - $(date +%s)))
    echo "Time remaining: $((REMAINING / 3600))h $(((REMAINING % 3600) / 60))m"
done

echo "Job completed. Shutting down instance..."
shutdown -h now
EOF

chmod +x /home/ubuntu/auto_shutdown.sh

# Start auto-shutdown in background
echo "Starting auto-shutdown monitor..."
nohup /home/ubuntu/auto_shutdown.sh ${1} > /var/log/auto_shutdown.log 2>&1 &

# Create status file
cat > /home/ubuntu/instance_status.json << EOF
{
  "instance_id": "$(curl -s http://169.254.169.254/latest/meta-data/instance-id)",
  "instance_type": "$(curl -s http://169.254.169.254/latest/meta-data/instance-type)",
  "region": "$(curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone | sed 's/.$//')",
  "gpu_type": "${1}",
  "job_duration_hours": ${2},
  "start_time": "$(date -Iseconds)",
  "end_time": "$(date -d "+${2} hours" -Iseconds)",
  "status": "running",
  "nvidia_driver_version": "$(nvidia-smi --query-gpu=driver_version --format=csv,noheader,nounits | head -1)",
  "cuda_version": "$(nvcc --version | grep 'release' | awk '{print $6}' | cut -c2-)"
}
EOF

# Setup complete
echo "GPU instance setup completed successfully!"
echo "Instance is ready for use."
echo "Run /home/ubuntu/monitor_gpu.sh to check status."
echo "Auto-shutdown is scheduled for ${2} hours from now."
