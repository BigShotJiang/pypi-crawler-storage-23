import logging

#!/usr/bin/env python3
"""
B2B ROI Calculator for Terradev
Calculate potential savings for enterprise clients
"""

import json
from typing import Dict, List, Tuple
from dataclasses import dataclass

@dataclass
class GPUPricing:
    on_demand_a100: float = 4.06
    spot_a100: float = 0.84
    on_demand_h100: float = 7.20
    spot_h100: float = 1.50
    on_demand_a10g: float = 1.21
    spot_a10g: float = 0.25

class B2BROICalculator:
    def __init__(self):
        self.pricing = GPUPricing()
        self.operational_overhead_hourly = 0.15  # $15/hour for DevOps time
    
    def calculate_savings(self, company_size: str, gpu_hours: int, 
                         gpu_mix: Dict[str, float], current_approach: str) -> Dict:
        """
        Calculate savings for a B2B client
        
        Args:
            company_size: 'startup', 'smb', 'enterprise', 'ai_lab'
            gpu_hours: Total GPU hours per month
            gpu_mix: Dict with percentages for each GPU type
            current_approach: 'single_provider', 'multi_provider_manual', 'optimized'
        """
        
        # Calculate current costs
        current_costs = self._calculate_current_costs(gpu_hours, gpu_mix, current_approach)
        
        # Calculate Terradev costs
        terradev_costs = self._calculate_terradev_costs(gpu_hours, gpu_mix, company_size)
        
        # Calculate operational savings
        operational_savings = self._calculate_operational_savings(company_size, current_approach)
        
        # Total savings
        total_monthly_savings = current_costs['total'] - terradev_costs['total'] + operational_savings
        annual_savings = total_monthly_savings * 12
        
        # ROI calculations
        terradev_subscription = self._get_subscription_cost(company_size)
        roi_months = terradev_subscription / total_monthly_savings if total_monthly_savings > 0 else float('inf')
        
        return {
            'company_size': company_size,
            'current_costs': current_costs,
            'terradev_costs': terradev_costs,
            'operational_savings': operational_savings,
            'monthly_savings': {
                'infrastructure': current_costs['total'] - terradev_costs['total'],
                'operational': operational_savings,
                'total': total_monthly_savings,
                'percentage': round((total_monthly_savings / current_costs['total']) * 100, 1)
            },
            'annual_savings': annual_savings,
            'roi': {
                'subscription_cost': terradev_subscription,
                'payback_period_months': round(roi_months, 1),
                'annual_roi_percentage': round((annual_savings / terradev_subscription) * 100, 1)
            }
        }
    
    def _calculate_current_costs(self, gpu_hours: int, gpu_mix: Dict[str, float], approach: str) -> Dict:
        """Calculate current infrastructure costs"""
        costs = {}
        
        # Base GPU costs
        for gpu_type, percentage in gpu_mix.items():
            hours = gpu_hours * (percentage / 100)
            
            if gpu_type == 'a100':
                if approach == 'optimized':
                    # Assume 30% spot usage
                    spot_hours = hours * 0.3
                    on_demand_hours = hours * 0.7
                    costs[gpu_type] = (spot_hours * self.pricing.spot_a100 + 
                                    on_demand_hours * self.pricing.on_demand_a100)
                else:
                    # All on-demand
                    costs[gpu_type] = hours * self.pricing.on_demand_a100
                    
            elif gpu_type == 'h100':
                if approach == 'optimized':
                    spot_hours = hours * 0.3
                    on_demand_hours = hours * 0.7
                    costs[gpu_type] = (spot_hours * self.pricing.spot_h100 + 
                                    on_demand_hours * self.pricing.on_demand_h100)
                else:
                    costs[gpu_type] = hours * self.pricing.on_demand_h100
                    
            elif gpu_type == 'a10g':
                if approach == 'optimized':
                    spot_hours = hours * 0.3
                    on_demand_hours = hours * 0.7
                    costs[gpu_type] = (spot_hours * self.pricing.spot_a10g + 
                                    on_demand_hours * self.pricing.on_demand_a10g)
                else:
                    costs[gpu_type] = hours * self.pricing.on_demand_a10g
        
        # Add overhead for manual management
        overhead_multiplier = {
            'single_provider': 1.0,
            'multi_provider_manual': 1.15,  # 15% overhead
            'optimized': 1.05  # 5% overhead
        }
        
        total = sum(costs.values()) * overhead_multiplier[approach]
        
        return {
            'breakdown': costs,
            'overhead_multiplier': overhead_multiplier[approach],
            'total': round(total, 2)
        }
    
    def _calculate_terradev_costs(self, gpu_hours: int, gpu_mix: Dict[str, float], company_size: str) -> Dict:
        """Calculate Terradev costs (assuming 80% spot usage)"""
        costs = {}
        
        for gpu_type, percentage in gpu_mix.items():
            hours = gpu_hours * (percentage / 100)
            
            # Terradev achieves 80% spot usage through arbitrage
            spot_hours = hours * 0.8
            on_demand_hours = hours * 0.2
            
            if gpu_type == 'a100':
                costs[gpu_type] = (spot_hours * self.pricing.spot_a100 + 
                                 on_demand_hours * self.pricing.on_demand_a100)
            elif gpu_type == 'h100':
                costs[gpu_type] = (spot_hours * self.pricing.spot_h100 + 
                                 on_demand_hours * self.pricing.on_demand_h100)
            elif gpu_type == 'a10g':
                costs[gpu_type] = (spot_hours * self.pricing.spot_a10g + 
                                 on_demand_hours * self.pricing.on_demand_a10g)
        
        # Minimal overhead with Terradev automation
        total = sum(costs.values()) * 1.02  # 2% overhead
        
        return {
            'breakdown': costs,
            'spot_usage_percentage': 80,
            'overhead_multiplier': 1.02,
            'total': round(total, 2)
        }
    
    def _calculate_operational_savings(self, company_size: str, current_approach: str) -> float:
        """Calculate operational savings from automation"""
        devops_hours_per_month = {
            'startup': 40,
            'smb': 80,
            'enterprise': 160,
            'ai_lab': 320
        }
        
        # Terradev reduces DevOps effort by 80%
        current_hours = devops_hours_per_month[company_size]
        terradev_hours = current_hours * 0.2
        
        return (current_hours - terradev_hours) * self.operational_overhead_hourly
    
    def _get_subscription_cost(self, company_size: str) -> float:
        """Get Terradev subscription cost"""
        subscription_costs = {
            'startup': 499,
            'smb': 1999,
            'enterprise': 7999,
            'ai_lab': 19999
        }
        return subscription_costs[company_size]
    
    def generate_report(self, scenarios: List[Dict]) -> str:
        """Generate comprehensive B2B savings report"""
        report = []
        report.append("# Terradev B2B ROI Analysis\n")
        
        for scenario in scenarios:
            result = self.calculate_savings(**scenario)
            
            report.append(f"## {result['company_size'].title()} Client")
            report.append(f"- **Current Monthly Cost**: ${result['current_costs']['total']:,.2f}")
            report.append(f"- **Terradev Monthly Cost**: ${result['terradev_costs']['total']:,.2f}")
            report.append(f"- **Monthly Savings**: ${result['monthly_savings']['total']:,.2f} ({result['monthly_savings']['percentage']}%)")
            report.append(f"- **Annual Savings**: ${result['annual_savings']:,.2f}")
            report.append(f"- **ROI**: {result['roi']['annual_roi_percentage']:.0f}% annual return")
            report.append(f"- **Payback Period**: {result['roi']['payback_period_months']} months\n")
        
        return "\n".join(report)

def main():
    calculator = B2BROICalculator()
    
    # Define typical B2B scenarios
    scenarios = [
        {
            'company_size': 'startup',
            'gpu_hours': 500,
            'gpu_mix': {'a100': 60, 'h100': 20, 'a10g': 20},
            'current_approach': 'single_provider'
        },
        {
            'company_size': 'smb',
            'gpu_hours': 2000,
            'gpu_mix': {'a100': 40, 'h100': 40, 'a10g': 20},
            'current_approach': 'multi_provider_manual'
        },
        {
            'company_size': 'enterprise',
            'gpu_hours': 10000,
            'gpu_mix': {'a100': 30, 'h100': 60, 'a10g': 10},
            'current_approach': 'multi_provider_manual'
        },
        {
            'company_size': 'ai_lab',
            'gpu_hours': 50000,
            'gpu_mix': {'a100': 20, 'h100': 75, 'a10g': 5},
            'current_approach': 'optimized'
        }
    ]
    
    # Generate and print report
    report = calculator.generate_report(scenarios)
    logging.info(report)
    
    # Export detailed analysis
    detailed_results = []
    for scenario in scenarios:
        result = calculator.calculate_savings(**scenario)
        detailed_results.append(result)
    
    with open('b2b_roi_analysis.json', 'w') as f:
        json.dump(detailed_results, f, indent=2)
    
    logging.info("\nDetailed analysis exported to 'b2b_roi_analysis.json'")

if __name__ == '__main__':
    main()
