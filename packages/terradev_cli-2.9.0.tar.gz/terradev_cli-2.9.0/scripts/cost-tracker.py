#!/usr/bin/env python3
"""
Terradev Cost Tracking and Usage Monitoring

This script provides comprehensive cost tracking and usage monitoring
for GPU deployments across all cloud providers.
"""

import json
import logging
import sqlite3
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class UsageRecord:
    user_id: str
    deployment_id: str
    provider: str
    gpu_type: str
    start_time: datetime
    end_time: Optional[datetime]
    hourly_cost: float
    total_cost: float
    status: str  # active, completed, failed

@dataclass
class BudgetAlert:
    user_id: str
    budget_limit: float
    current_spend: float
    alert_threshold: float
    alert_type: str  # warning, critical, exceeded

class CostTracker:
    """Cost tracking and usage monitoring system."""
    
    def __init__(self, db_path: str = "cost_tracking.db"):
        """Initialize the cost tracker."""
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the SQLite database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create usage records table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usage_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                deployment_id TEXT NOT NULL,
                provider TEXT NOT NULL,
                gpu_type TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT,
                hourly_cost REAL NOT NULL,
                total_cost REAL DEFAULT 0.0,
                status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create budget alerts table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS budget_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                budget_limit REAL NOT NULL,
                current_spend REAL NOT NULL,
                alert_threshold REAL NOT NULL,
                alert_type TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create user budgets table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_budgets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL UNIQUE,
                tier TEXT NOT NULL,
                monthly_budget REAL,
                alert_threshold REAL DEFAULT 0.8,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def start_usage_tracking(self, user_id: str, deployment_id: str, provider: str, 
                            gpu_type: str, hourly_cost: float) -> str:
        """Start tracking a new GPU deployment."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        start_time = datetime.now().isoformat()
        
        cursor.execute('''
            INSERT INTO usage_records 
            (user_id, deployment_id, provider, gpu_type, start_time, hourly_cost, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, deployment_id, provider, gpu_type, start_time, hourly_cost, 'active'))
        
        record_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        logger.info(f"Started tracking usage for deployment {deployment_id} (ID: {record_id})")
        return str(record_id)
    
    def end_usage_tracking(self, record_id: str) -> float:
        """End tracking and calculate total cost."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        end_time = datetime.now().isoformat()
        
        # Get the record
        cursor.execute('''
            SELECT start_time, hourly_cost FROM usage_records 
            WHERE id = ? AND status = 'active'
        ''', (record_id,))
        
        result = cursor.fetchone()
        if not result:
            conn.close()
            raise ValueError(f"Active usage record not found: {record_id}")
        
        start_time_str, hourly_cost = result
        start_time = datetime.fromisoformat(start_time_str)
        end_time_dt = datetime.fromisoformat(end_time)
        
        # Calculate duration and cost
        duration_hours = (end_time_dt - start_time).total_seconds() / 3600
        total_cost = duration_hours * hourly_cost
        
        # Update record
        cursor.execute('''
            UPDATE usage_records 
            SET end_time = ?, total_cost = ?, status = 'completed'
            WHERE id = ?
        ''', (end_time, total_cost, record_id))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Ended tracking for record {record_id}. Duration: {duration_hours:.2f}h, Cost: ${total_cost:.2f}")
        return total_cost
    
    def get_monthly_usage(self, user_id: str, year: Optional[int] = None, month: Optional[int] = None) -> Dict[str, Any]:
        """Get monthly usage statistics for a user."""
        if year is None:
            year = datetime.now().year
        if month is None:
            month = datetime.now().month
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get usage records for the month
        cursor.execute('''
            SELECT provider, gpu_type, start_time, end_time, hourly_cost, total_cost, status
            FROM usage_records
            WHERE user_id = ? 
            AND strftime('%Y', start_time) = ?
            AND strftime('%m', start_time) = ?
        ''', (user_id, str(year), f"{month:02d}"))
        
        records = cursor.fetchall()
        
        # Calculate statistics
        total_cost = 0.0
        total_hours = 0.0
        provider_breakdown = {}
        gpu_type_breakdown = {}
        
        for record in records:
            provider, gpu_type, start_time, end_time, hourly_cost, total_cost_record, status = record
            
            if status == 'completed' and total_cost_record > 0:
                total_cost += total_cost_record
                duration = total_cost_record / hourly_cost if hourly_cost > 0 else 0
                total_hours += duration
            elif status == 'active':
                # Calculate current cost for active deployments
                start_dt = datetime.fromisoformat(start_time)
                now = datetime.now()
                duration = (now - start_dt).total_seconds() / 3600
                current_cost = duration * hourly_cost
                total_cost += current_cost
                total_hours += duration
            
            # Breakdown by provider
            if provider not in provider_breakdown:
                provider_breakdown[provider] = {'cost': 0.0, 'hours': 0.0}
            provider_breakdown[provider]['cost'] += total_cost_record if status == 'completed' else 0
            provider_breakdown[provider]['hours'] += total_cost_record / hourly_cost if status == 'completed' and hourly_cost > 0 else 0
            
            # Breakdown by GPU type
            if gpu_type not in gpu_type_breakdown:
                gpu_type_breakdown[gpu_type] = {'cost': 0.0, 'hours': 0.0}
            gpu_type_breakdown[gpu_type]['cost'] += total_cost_record if status == 'completed' else 0
            gpu_type_breakdown[gpu_type]['hours'] += total_cost_record / hourly_cost if status == 'completed' and hourly_cost > 0 else 0
        
        conn.close()
        
        return {
            'user_id': user_id,
            'year': year,
            'month': month,
            'total_cost': round(total_cost, 2),
            'total_hours': round(total_hours, 2),
            'average_hourly_cost': round(total_cost / total_hours, 2) if total_hours > 0 else 0,
            'provider_breakdown': provider_breakdown,
            'gpu_type_breakdown': gpu_type_breakdown,
            'active_deployments': len([r for r in records if r[6] == 'active'])
        }
    
    def set_user_budget(self, user_id: str, tier: str, monthly_budget: Optional[float] = None, 
                       alert_threshold: float = 0.8):
        """Set or update user budget."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO user_budgets 
            (user_id, tier, monthly_budget, alert_threshold, updated_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, tier, monthly_budget, alert_threshold, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Set budget for user {user_id}: ${monthly_budget}/month" if monthly_budget else f"Unlimited budget for user {user_id}")
    
    def check_budget_alerts(self, user_id: str) -> List[BudgetAlert]:
        """Check for budget alerts and return any that should be triggered."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get user budget
        cursor.execute('''
            SELECT tier, monthly_budget, alert_threshold FROM user_budgets
            WHERE user_id = ?
        ''', (user_id,))
        
        budget_result = cursor.fetchone()
        if not budget_result or budget_result[1] is None:
            conn.close()
            return []  # No budget set
        
        tier, monthly_budget, alert_threshold = budget_result
        
        # Get current month usage
        current_usage = self.get_monthly_usage(user_id)
        current_spend = current_usage['total_cost']
        
        alerts = []
        
        # Check different alert levels
        if current_spend >= monthly_budget:
            alerts.append(BudgetAlert(
                user_id=user_id,
                budget_limit=monthly_budget,
                current_spend=current_spend,
                alert_threshold=alert_threshold,
                alert_type="exceeded",
                message=f"Budget exceeded! Current spend: ${current_spend:.2f}, Budget: ${monthly_budget:.2f}"
            ))
        elif current_spend >= monthly_budget * alert_threshold:
            alerts.append(BudgetAlert(
                user_id=user_id,
                budget_limit=monthly_budget,
                current_spend=current_spend,
                alert_threshold=alert_threshold,
                alert_type="critical",
                message=f"Budget warning! Current spend: ${current_spend:.2f} ({(current_spend/monthly_budget)*100:.1f}% of budget)"
            ))
        elif current_spend >= monthly_budget * 0.6:
            alerts.append(BudgetAlert(
                user_id=user_id,
                budget_limit=monthly_budget,
                current_spend=current_spend,
                alert_threshold=alert_threshold,
                alert_type="warning",
                message=f"Budget notice: Current spend: ${current_spend:.2f} ({(current_spend/monthly_budget)*100:.1f}% of budget)"
            ))
        
        # Store alerts in database
        for alert in alerts:
            cursor.execute('''
                INSERT INTO budget_alerts 
                (user_id, budget_limit, current_spend, alert_threshold, alert_type, message)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (alert.user_id, alert.budget_limit, alert.current_spend, 
                  alert.alert_threshold, alert.alert_type, alert.message))
        
        conn.commit()
        conn.close()
        
        return alerts
    
    def get_cost_savings_analysis(self, user_id: str, days: int = 30) -> Dict[str, Any]:
        """Analyze cost savings from using spot instances."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get usage records for the period
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        cursor.execute('''
            SELECT provider, gpu_type, hourly_cost, total_cost, status
            FROM usage_records
            WHERE user_id = ? AND start_time >= ?
        ''', (user_id, start_date))
        
        records = cursor.fetchall()
        
        # Calculate savings (simplified - in production would compare with on-demand prices)
        on_demand_prices = {
            'a100': 4.06,
            'h100': 7.20,
            'a10g': 1.21
        }
        
        total_spot_cost = sum(r[3] for r in records if r[4] == 'completed')
        total_on_demand_cost = 0
        savings_breakdown = {}
        
        for record in records:
            provider, gpu_type, hourly_cost, total_cost, status = record
            if status == 'completed' and gpu_type in on_demand_prices:
                on_demand_hourly = on_demand_prices[gpu_type]
                on_demand_total = (total_cost / hourly_cost) * on_demand_hourly
                total_on_demand_cost += on_demand_total
                
                if provider not in savings_breakdown:
                    savings_breakdown[provider] = {
                        'spot_cost': 0,
                        'on_demand_cost': 0,
                        'savings': 0
                    }
                
                savings_breakdown[provider]['spot_cost'] += total_cost
                savings_breakdown[provider]['on_demand_cost'] += on_demand_total
                savings_breakdown[provider]['savings'] += on_demand_total - total_cost
        
        total_savings = total_on_demand_cost - total_spot_cost
        savings_percentage = (total_savings / total_on_demand_cost * 100) if total_on_demand_cost > 0 else 0
        
        conn.close()
        
        return {
            'period_days': days,
            'total_spot_cost': round(total_spot_cost, 2),
            'estimated_on_demand_cost': round(total_on_demand_cost, 2),
            'total_savings': round(total_savings, 2),
            'savings_percentage': round(savings_percentage, 1),
            'provider_breakdown': savings_breakdown
        }
    
    def export_usage_report(self, user_id: str, output_path: str, format: str = "json"):
        """Export usage report to file."""
        # Get comprehensive usage data
        monthly_usage = self.get_monthly_usage(user_id)
        savings_analysis = self.get_cost_savings_analysis(user_id)
        alerts = self.check_budget_alerts(user_id)
        
        report_data = {
            'user_id': user_id,
            'generated_at': datetime.now().isoformat(),
            'monthly_usage': monthly_usage,
            'savings_analysis': savings_analysis,
            'budget_alerts': [asdict(alert) for alert in alerts]
        }
        
        if format.lower() == "json":
            with open(output_path, 'w') as f:
                json.dump(report_data, f, indent=2)
        elif format.lower() == "csv":
            # Simple CSV export (would need more sophisticated CSV handling in production)
            import csv
            with open(output_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Metric', 'Value'])
                writer.writerow(['Total Cost', monthly_usage['total_cost']])
                writer.writerow(['Total Hours', monthly_usage['total_hours']])
                writer.writerow(['Savings', savings_analysis['total_savings']])
                writer.writerow(['Savings %', savings_analysis['savings_percentage']])
        
        logger.info(f"Exported usage report for {user_id} to {output_path}")

def main():
    """Main function for CLI usage."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Terradev Cost Tracker')
    parser.add_argument('--user-id', required=True, help='User ID')
    parser.add_argument('--action', choices=['usage', 'budget', 'alerts', 'savings', 'export'], 
                       required=True, help='Action to perform')
    parser.add_argument('--budget', type=float, help='Monthly budget amount')
    parser.add_argument('--threshold', type=float, default=0.8, help='Alert threshold (percentage)')
    parser.add_argument('--tier', choices=['freemium', 'paid'], default='freemium', help='User tier')
    parser.add_argument('--output', help='Output file for export')
    parser.add_argument('--format', choices=['json', 'csv'], default='json', help='Export format')
    parser.add_argument('--days', type=int, default=30, help='Days for savings analysis')
    
    args = parser.parse_args()
    
    tracker = CostTracker()
    
    if args.action == 'usage':
        usage = tracker.get_monthly_usage(args.user_id)
        logging.info(json.dumps(usage, indent=2, default=str)
    
    elif args.action == 'budget':
        if args.budget:
            tracker.set_user_budget(args.user_id, args.tier, args.budget, args.threshold)
            logging.info(f"Budget set: ${args.budget}/month for {args.user_id}")
        else:
            logging.info("Budget amount required with --budget")
    
    elif args.action == 'alerts':
        alerts = tracker.check_budget_alerts(args.user_id)
        if alerts:
            logging.info(f"Budget Alerts for {args.user_id}:")
            for alert in alerts:
                logging.info(f"  {alert.alert_type.upper()
        else:
            logging.info(f"No budget alerts for {args.user_id}")
    
    elif args.action == 'savings':
        savings = tracker.get_cost_savings_analysis(args.user_id, args.days)
        logging.info(json.dumps(savings, indent=2)
    
    elif args.action == 'export':
        if not args.output:
            logging.info("Output file required with --output")
        else:
            tracker.export_usage_report(args.user_id, args.output, args.format)
            logging.info(f"Report exported to {args.output}")

if __name__ == '__main__':
    main()
