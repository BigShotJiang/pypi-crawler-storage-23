#!/usr/bin/env python3
"""
Terradev GPU Arbitrage Engine

This script provides real-time GPU price arbitrage across multiple cloud providers,
automatically finding and deploying to the cheapest available GPU instances.
"""

import asyncio
import aiohttp
import json
import logging
import os
import sys
import time
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from enum import Enum

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class Provider(Enum):
    AWS = "aws"
    GCP = "gcp"
    AZURE = "azure"
    RUNPOD = "runpod"
    LAMBDA = "lambda"
    COREWEAVE = "coreweave"

class Tier(Enum):
    FREEMIUM = "freemium"
    PAID = "paid"

@dataclass
class GPUOffer:
    provider: str
    gpu_type: str
    price_per_hour: float
    spot_price: Optional[float]
    region: str
    availability: str
    provider_instance_id: Optional[str] = None

@dataclass
class UserUsage:
    user_id: str
    tier: str
    gpu_hours_used: float
    monthly_limit: float
    last_updated: datetime

class GPUArbitrageEngine:
    """Main arbitrage engine for GPU price comparison and deployment."""
    
    def __init__(self, config_path: str = "config.json"):
        """Initialize the arbitrage engine."""
        self.config = self._load_config(config_path)
        self.session = None
        self.usage_tracker = {}
        
        # Advanced financial components
        self.options_pricer = None
        self.volatility_index = None
        self.market_analyzer = None
        self.analytics_engine = None
        
        # Initialize financial modules
        self._initialize_financial_modules()
        
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from file."""
        default_config = {
            "providers": ["aws", "gcp", "azure", "runpod", "lambda", "coreweave"],
            "gpu_types": ["a100", "h100", "a10g", "rtx4090", "rtx3090"],
            "api_keys": {},
            "pricing_apis": {
                "aws": "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEC2/current/index.json",
                "gcp": "https://cloudbilling.googleapis.com/v1/services/6F81-5844-456A/skus",
                "azure": "https://prices.azure.com/api/retail/prices",
                "runpod": "https://api.runpod.io/v1/gpu/pricing",
                "lambda": "https://api.labs.lambda.cloud/v1/gpu/pricing",
                "coreweave": "https://api.coreweave.com/v1/gpu/pricing"
            },
            "preferred_regions": ["us-west-2", "us-east-1", "europe-west1"],
            "spot_only": True,
            "max_price_per_hour": 10.0
        }
        
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        
        return default_config
    
    def _initialize_financial_modules(self):
        """Initialize advanced financial modules"""
        try:
            # Import financial modules
            from gpu_volatility_index import GPUVolatilityIndex
            
            # Initialize modules
            self.volatility_index = GPUVolatilityIndex()
            
            logger.info("Market analysis modules initialized successfully")
            
        except ImportError as e:
            logger.warning(f"Market analysis modules not available: {e}")
            logger.info("Running in basic arbitrage mode")
        except Exception as e:
            logger.error(f"Error initializing financial modules: {e}")
    
    async def calculate_advanced_arbitrage_opportunities(self, offers: List[GPUOffer]) -> Dict[str, Any]:
        """Calculate advanced arbitrage opportunities using market indicators"""
        if not self.volatility_index:
            return {"error": "Market analysis modules not initialized"}
        
        opportunities = {}
        
        for offer in offers:
            # Calculate volatility metrics
            historical_vol = await self._get_historical_volatility(offer.gpu_type, offer.provider)
            
            # Analyze market conditions for timing
            timing_analysis = await self._analyze_market_timing(offer, historical_vol)
            
            if timing_analysis["confidence_score"] > 0.7:  # High confidence threshold
                opportunities[f"{offer.provider}-{offer.gpu_type}"] = timing_analysis
        
        return opportunities
    
    async def _get_historical_volatility(self, gpu_type: str, provider: str) -> float:
        """Get historical volatility for GPU pricing"""
        # In production, would fetch from database
        return 0.35  # 35% annual volatility
    
    async def _analyze_market_timing(self, offer: GPUOffer, volatility: float) -> Dict[str, Any]:
        """Analyze market timing for optimal deployment"""
        
        # Use volatility index for timing analysis
        volatility_regime = self.volatility_index.detect_volatility_regime([volatility])
        
        # Calculate arbitrage confidence
        price_stability = 1.0 - volatility  # Higher stability = better confidence
        provider_reliability = self._get_provider_reliability(offer.provider)
        
        confidence_score = (price_stability * 0.6) + (provider_reliability * 0.4)
        
        # Determine timing recommendation
        if volatility_regime == "low_volatility":
            timing_recommendation = "deploy_now"
        elif volatility_regime == "high_volatility":
            timing_recommendation = "wait_for_stability"
        else:
            timing_recommendation = "proceed_with_caution"
        
        return {
            "offer": offer,
            "volatility_regime": volatility_regime,
            "price_stability": price_stability,
            "provider_reliability": provider_reliability,
            "confidence_score": confidence_score,
            "timing_recommendation": timing_recommendation,
            "expected_savings": offer.price_per_hour * 0.3,  # 30% expected savings
            "risk_assessment": "low" if volatility < 0.3 else "medium" if volatility < 0.5 else "high"
        }
        # Create synthetic forward contract
        forward_price = offer.spot_price if offer.spot_price else offer.price_per_hour
        
        # Calculate arbitrage potential across providers
        cross_provider_arbitrage = await self._calculate_cross_provider_arbitrage(offer)
        
        # Calculate time-based arbitrage (spot vs forward)
        time_arbitrage = await self._calculate_time_arbitrage(offer, volatility)
        
        # Calculate volatility arbitrage
        volatility_arbitrage = await self._calculate_volatility_arbitrage(offer, volatility)
        
        total_expected_pnl = (cross_provider_arbitrage["pnl"] + 
                             time_arbitrage["pnl"] + 
                             volatility_arbitrage["pnl"])
        
        return {
            "expected_pnl": total_expected_pnl,
            "cross_provider_arbitrage": cross_provider_arbitrage,
            "time_arbitrage": time_arbitrage,
            "volatility_arbitrage": volatility_arbitrage,
            "confidence_score": min(0.95, total_expected_pnl * 10),
            "execution_strategy": self._determine_execution_strategy(total_expected_pnl)
        }
    
    async def _calculate_cross_provider_arbitrage(self, offer: GPUOffer) -> Dict[str, float]:
        """Calculate cross-provider arbitrage opportunity"""
        # Get prices from other providers for same GPU type
        other_offers = await self._get_competing_offers(offer.gpu_type, offer.provider)
        
        if not other_offers:
            return {"pnl": 0.0, "opportunity": "no_competition"}
        
        # Find cheapest competitor
        cheapest_competitor = min(other_offers, key=lambda x: x.spot_price if x.spot_price else x.price_per_hour)
        competitor_price = cheapest_competitor.spot_price if cheapest_competitor.spot_price else cheapest_competitor.price_per_hour
        current_price = offer.spot_price if offer.spot_price else offer.price_per_hour
        
        price_diff = abs(current_price - competitor_price)
        arbitrage_pnl = price_diff * 0.8  # 80% of price difference after costs
        
        return {
            "pnl": arbitrage_pnl,
            "opportunity": "price_discrepancy",
            "price_difference": price_diff,
            "competitor": cheapest_competitor.provider
        }
    
    async def _calculate_time_arbitrage(self, offer: GPUOffer, volatility: float) -> Dict[str, float]:
        """Calculate time-based arbitrage (spot vs forward)"""
        current_price = offer.spot_price if offer.spot_price else offer.price_per_hour
        
        # Calculate forward price using cost of carry model
        risk_free_rate = 0.05  # 5%
        convenience_yield = 0.02  # 2%
        time_to_expiry = 0.25  # 3 months
        
        forward_price = current_price * np.exp((risk_free_rate - convenience_yield) * time_to_expiry)
        
        # Calculate arbitrage if forward price differs significantly
        forward_premium = forward_price - current_price
        arbitrage_pnl = abs(forward_premium) * 0.5  # 50% after costs
        
        return {
            "pnl": arbitrage_pnl,
            "opportunity": "time_arbitrage",
            "forward_price": forward_price,
            "forward_premium": forward_premium
        }
    
    async def _calculate_volatility_arbitrage(self, offer: GPUOffer, volatility: float) -> Dict[str, float]:
        """Calculate volatility arbitrage opportunity"""
        # Calculate implied volatility from option prices
        implied_vol = await self._get_implied_volatility(offer.gpu_type, offer.provider)
        
        if not implied_vol:
            return {"pnl": 0.0, "opportunity": "no_options_market"}
        
        vol_diff = abs(implied_vol - volatility)
        arbitrage_pnl = vol_diff * 0.1  # Scale factor for volatility arbitrage
        
        return {
            "pnl": arbitrage_pnl,
            "opportunity": "volatility_arbitrage",
            "implied_volatility": implied_vol,
            "historical_volatility": volatility,
            "volatility_spread": vol_diff
        }
    
    async def _get_competing_offers(self, gpu_type: str, exclude_provider: str) -> List[GPUOffer]:
        """Get competing offers from other providers"""
        all_offers = await self.get_all_prices()
        return [offer for offer in all_offers 
                if offer.gpu_type == gpu_type and offer.provider != exclude_provider]
    
    async def _get_implied_volatility(self, gpu_type: str, provider: str) -> Optional[float]:
        """Get implied volatility from options market"""
        # In production, would calculate from option prices
        return 0.40  # 40% implied volatility
    
    def _determine_execution_strategy(self, expected_pnl: float) -> str:
        """Determine optimal execution strategy"""
        if expected_pnl > 0.10:
            return "aggressive_market_order"
        elif expected_pnl > 0.05:
            return "limit_order_with_partial_fills"
        elif expected_pnl > 0.02:
            return "passive_limit_order"
        else:
            return "no_execution"
    
    def calculate_portfolio_greeks(self, positions: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate portfolio Greeks for risk management"""
        if not self.options_pricer:
            return {"error": "Options pricer not initialized"}
        
        total_delta = 0.0
        total_gamma = 0.0
        total_vega = 0.0
        total_theta = 0.0
        total_rho = 0.0
        
        for position in positions:
            # Calculate Greeks for each position
            position_greeks = self._calculate_position_greeks(position)
            
            total_delta += position_greeks.get("delta", 0.0)
            total_gamma += position_greeks.get("gamma", 0.0)
            total_vega += position_greeks.get("vega", 0.0)
            total_theta += position_greeks.get("theta", 0.0)
            total_rho += position_greeks.get("rho", 0.0)
        
        return {
            "total_delta": total_delta,
            "total_gamma": total_gamma,
            "total_vega": total_vega,
            "total_theta": total_theta,
            "total_rho": total_rho,
            "risk_metrics": self._calculate_risk_metrics(total_delta, total_gamma, total_vega)
        }
    
    def _calculate_position_greeks(self, position: Dict[str, Any]) -> Dict[str, float]:
        """Calculate Greeks for individual position"""
        # Simplified Greek calculation
        # In production, would use full options pricing model
        
        quantity = position.get("quantity", 0.0)
        underlying_price = position.get("underlying_price", 1.0)
        volatility = position.get("volatility", 0.3)
        
        # Approximate Greeks
        delta = quantity * 0.5  # At-the-money approximation
        gamma = quantity * 0.1 / underlying_price
        vega = quantity * volatility * 0.2
        theta = -quantity * 0.05 / 365  # Daily theta decay
        rho = quantity * 0.1
        
        return {
            "delta": delta,
            "gamma": gamma,
            "vega": vega,
            "theta": theta,
            "rho": rho
        }
    
    def _calculate_risk_metrics(self, delta: float, gamma: float, vega: float) -> Dict[str, float]:
        """Calculate portfolio risk metrics"""
        # Calculate VaR using delta-gamma approximation
        portfolio_value = abs(delta) * 100  # Approximate portfolio value
        volatility = 0.3  # 30% volatility
        
        # Delta-normal VaR
        delta_var = abs(delta) * volatility * 2.33  # 99% VaR
        
        # Gamma adjustment
        gamma_var = 0.5 * gamma * (volatility ** 2) * 100  # Simplified
        
        # Total VaR
        total_var = delta_var + gamma_var
        
        # Greeks exposure limits
        delta_exposure = abs(delta) / 1000  # Normalize
        gamma_exposure = abs(gamma) / 100
        vega_exposure = abs(vega) / 1000
        
        return {
            "portfolio_var": total_var,
            "delta_exposure": delta_exposure,
            "gamma_exposure": gamma_exposure,
            "vega_exposure": vega_exposure,
            "risk_score": (delta_exposure + gamma_exposure + vega_exposure) / 3
        }
    
    async def _predict_price_movements(self, cheapest_offer: GPUOffer, all_offers: List[GPUOffer]) -> Dict[str, Any]:
        """Simple price prediction for optimal deployment timing"""
        # Calculate price volatility for this GPU type
        gpu_offers = [o for o in all_offers if o.gpu_type == cheapest_offer.gpu_type]
        
        if len(gpu_offers) < 3:
            return {"stability_score": 0.8, "optimal_deployment_time": "now"}
        
        prices = [o.spot_price if o.spot_price else o.price_per_hour for o in gpu_offers]
        price_std = np.std(prices)
        price_mean = np.mean(prices)
        
        # Price stability (lower std = more stable)
        stability_score = max(0.3, 1.0 - (price_std / price_mean))
        
        # Simple timing recommendation
        if stability_score > 0.8:
            optimal_timing = "now"
        elif stability_score > 0.6:
            optimal_timing = "within_1_hour"
        else:
            optimal_timing = "wait_for_stability"
        
        return {
            "stability_score": stability_score,
            "optimal_deployment_time": optimal_timing,
            "price_volatility": price_std / price_mean,
            "market_depth": len(gpu_offers)
        }
    
    def _calculate_arbitrage_confidence(self, cheapest: GPUOffer, all_offers: List[GPUOffer], price_prediction: Dict[str, Any]) -> float:
        """Calculate confidence in arbitrage opportunity"""
        # Base confidence from price spread
        gpu_offers = [o for o in all_offers if o.gpu_type == cheapest.gpu_type]
        if len(gpu_offers) < 2:
            return 0.5
        
        prices = [o.spot_price if o.spot_price else o.price_per_hour for o in gpu_offers]
        price_spread = (max(prices) - min(prices)) / min(prices)
        
        # Higher spread = higher confidence
        spread_confidence = min(1.0, price_spread * 10)  # Scale to 0-1
        
        # Adjust for price stability
        stability_factor = price_prediction.get("stability_score", 0.8)
        
        # Overall confidence
        confidence = (spread_confidence * 0.7) + (stability_factor * 0.3)
        
        return round(confidence, 2)
    
    def _calculate_market_efficiency(self, all_offers: List[GPUOffer]) -> float:
        """Calculate how efficiently priced the market is"""
        if len(all_offers) < 3:
            return 0.5
        
        # Group by GPU type
        gpu_groups = {}
        for offer in all_offers:
            if offer.gpu_type not in gpu_groups:
                gpu_groups[offer.gpu_type] = []
            gpu_groups[offer.gpu_type].append(offer)
        
        efficiency_scores = []
        
        for gpu_type, offers in gpu_groups.items():
            if len(offers) < 2:
                continue
            
            prices = [o.spot_price if o.spot_price else o.price_per_hour for o in offers]
            price_cv = np.std(prices) / np.mean(prices)  # Coefficient of variation
            
            # Lower variation = more efficient
            efficiency = max(0.2, 1.0 - price_cv)
            efficiency_scores.append(efficiency)
        
        return np.mean(efficiency_scores) if efficiency_scores else 0.5
    
    def _calculate_simple_risk_score(self, cheapest: GPUOffer, all_offers: List[GPUOffer]) -> float:
        """Simple risk assessment for the chosen GPU"""
        # Provider reliability (simplified scoring)
        provider_scores = {
            "aws": 0.9,
            "gcp": 0.85,
            "azure": 0.85,
            "runpod": 0.7,
            "lambda": 0.65,
            "coreweave": 0.6
        }
        
        provider_risk = 1.0 - provider_scores.get(cheapest.provider, 0.7)
        
        # Price volatility risk
        gpu_offers = [o for o in all_offers if o.gpu_type == cheapest.gpu_type]
        if len(gpu_offers) > 1:
            prices = [o.spot_price if o.spot_price else o.price_per_hour for o in gpu_offers]
            price_volatility = np.std(prices) / np.mean(prices)
        else:
            price_volatility = 0.1  # Default low volatility
        
        # Spot vs on-demand risk
        if cheapest.spot_price:
            spot_discount = (cheapest.price_per_hour - cheapest.spot_price) / cheapest.price_per_hour
            interruption_risk = spot_discount * 0.5  # Higher discount = higher risk
        else:
            interruption_risk = 0.0
        
        # Overall risk score (0 = low risk, 1 = high risk)
        risk_score = (provider_risk * 0.4) + (price_volatility * 0.3) + (interruption_risk * 0.3)
        
        return round(risk_score, 2)
    
    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self.session:
            await self.session.close()
    
    async def fetch_gpu_prices(self, provider: str) -> List[GPUOffer]:
        """Fetch GPU prices from a specific provider."""
        try:
            url = self.config["pricing_apis"][provider]
            headers = {"Accept": "application/json"}
            
            # Add authentication for providers that require it
            if provider in ["runpod", "lambda", "coreweave"] and provider in self.config["api_keys"]:
                headers["Authorization"] = f"Bearer {self.config['api_keys'][provider]}"
            
            async with self.session.get(url, headers=headers) as response:
                if response.status != 200:
                    logger.error(f"Failed to fetch prices from {provider}: {response.status}")
                    return []
                
                data = await response.json()
                return self._parse_pricing_data(provider, data)
        
        except Exception as e:
            logger.error(f"Error fetching prices from {provider}: {e}")
            return []
    
    def _parse_pricing_data(self, provider: str, data: Dict[str, Any]) -> List[GPUOffer]:
        """Parse pricing data from provider response."""
        offers = []
        
        if provider == "aws":
            offers = self._parse_aws_pricing(data)
        elif provider == "gcp":
            offers = self._parse_gcp_pricing(data)
        elif provider == "azure":
            offers = self._parse_azure_pricing(data)
        elif provider in ["runpod", "lambda", "coreweave"]:
            offers = self._parse_provider_pricing(provider, data)
        
        return offers
    
    def _parse_aws_pricing(self, data: Dict[str, Any]) -> List[GPUOffer]:
        """Parse AWS pricing data."""
        offers = []
        gpu_types = self.config["gpu_types"]
        
        # AWS pricing format is complex - simplified for demo
        # In production, would parse the actual AWS pricing JSON structure
        aws_prices = {
            "a100": {"on_demand": 4.06, "spot": 1.22},
            "h100": {"on_demand": 7.20, "spot": 2.16},
            "a10g": {"on_demand": 1.21, "spot": 0.36}
        }
        
        for gpu_type in gpu_types:
            if gpu_type in aws_prices:
                offers.append(GPUOffer(
                    provider=Provider.AWS.value,
                    gpu_type=gpu_type,
                    price_per_hour=aws_prices[gpu_type]["on_demand"],
                    spot_price=aws_prices[gpu_type]["spot"],
                    region="us-west-2",
                    availability="available"
                ))
        
        return offers
    
    def _parse_gcp_pricing(self, data: Dict[str, Any]) -> List[GPUOffer]:
        """Parse GCP pricing data."""
        offers = []
        gpu_types = self.config["gpu_types"]
        
        # Simplified GCP pricing
        gcp_prices = {
            "a100": {"on_demand": 3.67, "spot": 1.10},
            "h100": {"on_demand": 6.50, "spot": 1.95},
            "a10g": {"on_demand": 1.08, "spot": 0.32}
        }
        
        for gpu_type in gpu_types:
            if gpu_type in gcp_prices:
                offers.append(GPUOffer(
                    provider=Provider.GCP.value,
                    gpu_type=gpu_type,
                    price_per_hour=gcp_prices[gpu_type]["on_demand"],
                    spot_price=gcp_prices[gpu_type]["spot"],
                    region="us-central1",
                    availability="available"
                ))
        
        return offers
    
    def _parse_azure_pricing(self, data: Dict[str, Any]) -> List[GPUOffer]:
        """Parse Azure pricing data."""
        offers = []
        gpu_types = self.config["gpu_types"]
        
        # Simplified Azure pricing
        azure_prices = {
            "a100": {"on_demand": 4.29, "spot": 1.29},
            "h100": {"on_demand": 7.62, "spot": 2.29},
            "a10g": {"on_demand": 1.27, "spot": 0.38}
        }
        
        for gpu_type in gpu_types:
            if gpu_type in azure_prices:
                offers.append(GPUOffer(
                    provider=Provider.AZURE.value,
                    gpu_type=gpu_type,
                    price_per_hour=azure_prices[gpu_type]["on_demand"],
                    spot_price=azure_prices[gpu_type]["spot"],
                    region="eastus",
                    availability="available"
                ))
        
        return offers
    
    def _parse_provider_pricing(self, provider: str, data: Dict[str, Any]) -> List[GPUOffer]:
        """Parse pricing data from specialized GPU providers."""
        offers = []
        gpu_types = self.config["gpu_types"]
        
        # Simplified pricing for specialized providers
        provider_prices = {
            "runpod": {
                "a100": {"on_demand": 2.99, "spot": 0.89},
                "h100": {"on_demand": 5.29, "spot": 1.59},
                "a10g": {"on_demand": 0.89, "spot": 0.27}
            },
            "lambda": {
                "a100": {"on_demand": 3.49, "spot": 1.05},
                "h100": {"on_demand": 6.19, "spot": 1.86},
                "a10g": {"on_demand": 1.04, "spot": 0.31}
            },
            "coreweave": {
                "a100": {"on_demand": 2.79, "spot": 0.84},
                "h100": {"on_demand": 4.99, "spot": 1.50},
                "a10g": {"on_demand": 0.84, "spot": 0.25}
            }
        }
        
        if provider in provider_prices:
            for gpu_type in gpu_types:
                if gpu_type in provider_prices[provider]:
                    offers.append(GPUOffer(
                        provider=provider,
                        gpu_type=gpu_type,
                        price_per_hour=provider_prices[provider][gpu_type]["on_demand"],
                        spot_price=provider_prices[provider][gpu_type]["spot"],
                        region="default",
                        availability="available"
                    ))
        
        return offers
    
    async def get_all_prices(self) -> List[GPUOffer]:
        """Fetch GPU prices from all providers."""
        tasks = []
        for provider in self.config["providers"]:
            tasks.append(self.fetch_gpu_prices(provider))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        all_offers = []
        for result in results:
            if isinstance(result, list):
                all_offers.extend(result)
            else:
                logger.error(f"Error in price fetching: {result}")
        
        return all_offers
    
    def find_cheapest_gpu(self, offers: List[GPUOffer], gpu_type: Optional[str] = None) -> GPUOffer:
        """Find the cheapest GPU offer."""
        filtered_offers = offers
        
        if gpu_type:
            filtered_offers = [o for o in offers if o.gpu_type == gpu_type]
        
        if self.config["spot_only"]:
            filtered_offers = [o for o in filtered_offers if o.spot_price is not None]
        
        # Filter by max price
        if self.config["spot_only"]:
            filtered_offers = [o for o in filtered_offers if o.spot_price <= self.config["max_price_per_hour"]]
        else:
            filtered_offers = [o for o in filtered_offers if o.price_per_hour <= self.config["max_price_per_hour"]]
        
        if not filtered_offers:
            raise ValueError("No GPU offers found matching criteria")
        
        # Sort by price (spot price if available, otherwise on-demand)
        sorted_offers = sorted(
            filtered_offers, 
            key=lambda x: x.spot_price if x.spot_price else x.price_per_hour
        )
        
        return sorted_offers[0]
    
    def calculate_savings(self, offer: GPUOffer) -> Dict[str, float]:
        """Calculate potential savings."""
        if not offer.spot_price:
            return {"savings_pct": 0, "hourly_savings": 0}
        
        hourly_savings = offer.price_per_hour - offer.spot_price
        savings_pct = (hourly_savings / offer.price_per_hour) * 100
        
        return {
            "savings_pct": round(savings_pct, 1),
            "hourly_savings": round(hourly_savings, 3),
            "monthly_savings": round(hourly_savings * 24 * 30, 2)
        }
    
    def check_usage_limits(self, user_id: str, tier: str, hours_requested: float) -> Tuple[bool, str]:
        """Check if user has sufficient GPU hours remaining."""
        if tier == Tier.PAID.value:
            return True, "Unlimited usage for paid tier"
        
        # Get current usage (simplified - in production would use database)
        current_usage = self.usage_tracker.get(user_id, {}).get("hours_used", 0.0)
        monthly_limit = 10.0  # Freemium limit
        
        if current_usage + hours_requested > monthly_limit:
            remaining = monthly_limit - current_usage
            return False, f"Insufficient GPU hours. {remaining:.1f} hours remaining this month."
        
        return True, f"Usage approved. {monthly_limit - current_usage - hours_requested:.1f} hours will remain."
    
    def update_usage(self, user_id: str, hours: float):
        """Update user usage tracking."""
        if user_id not in self.usage_tracker:
            self.usage_tracker[user_id] = {
                "hours_used": 0.0,
                "last_updated": datetime.now()
            }
        
        self.usage_tracker[user_id]["hours_used"] += hours
        self.usage_tracker[user_id]["last_updated"] = datetime.now()
    
    async def deploy_gpu(self, offer: GPUOffer, user_config: Dict[str, Any]) -> Dict[str, Any]:
        """Deploy GPU instance (simplified for demo)."""
        # In production, this would integrate with actual cloud provider APIs
        deployment_info = {
            "deployment_id": f"deploy-{int(time.time())}",
            "provider": offer.provider,
            "gpu_type": offer.gpu_type,
            "region": offer.region,
            "price_per_hour": offer.spot_price if offer.spot_price else offer.price_per_hour,
            "status": "deploying",
            "estimated_ready_time": (datetime.now() + timedelta(minutes=5)).isoformat(),
            "user_config": user_config
        }
        
        logger.info(f"Deploying {offer.gpu_type} on {offer.provider} for ${deployment_info['price_per_hour']}/hour")
        
        return deployment_info
    
    async def run_arbitrage(self, user_id: str, tier: str, gpu_type: Optional[str] = None, hours: float = 1.0) -> Dict[str, Any]:
        """Run the complete arbitrage process with enhanced financial intelligence."""
        logger.info(f"Starting arbitrage for user {user_id}, tier {tier}")
        
        # Check usage limits
        can_deploy, message = self.check_usage_limits(user_id, tier, hours)
        if not can_deploy:
            return {
                "success": False,
                "message": message,
                "usage_status": self.usage_tracker.get(user_id, {})
            }
        
        # Fetch all prices
        all_offers = await self.get_all_prices()
        
        if not all_offers:
            return {
                "success": False,
                "message": "No GPU offers available from any provider"
            }
        
        # Find cheapest option (core arbitrage)
        cheapest = self.find_cheapest_gpu(all_offers, gpu_type)
        savings = self.calculate_savings(cheapest)
        
        # Enhanced: Predict future price movements for optimal timing
        price_prediction = await self._predict_price_movements(cheapest, all_offers)
        
        # Enhanced: Calculate arbitrage confidence score
        arbitrage_confidence = self._calculate_arbitrage_confidence(cheapest, all_offers, price_prediction)
        
        # Deploy GPU (core functionality)
        deployment = await self.deploy_gpu(cheapest, {
            "user_id": user_id,
            "tier": tier,
            "hours_requested": hours,
            "arbitrage_confidence": arbitrage_confidence,
            "price_prediction": price_prediction
        })
        
        # Update usage
        self.update_usage(user_id, hours)
        
        return {
            "success": True,
            "cheapest_gpu": asdict(cheapest),
            "savings": savings,
            "deployment": deployment,
            "usage_status": self.usage_tracker.get(user_id, {}),
            "alternatives": [
                asdict(offer) for offer in sorted(
                    [o for o in all_offers if o != cheapest],
                    key=lambda x: x.spot_price if x.spot_price else x.price_per_hour
                )[:3]
            ],
            # Enhanced financial insights (simple, actionable)
            "financial_insights": {
                "arbitrage_confidence": arbitrage_confidence,
                "price_stability": price_prediction.get("stability_score", 0.8),
                "optimal_timing": price_prediction.get("optimal_deployment_time", "now"),
                "market_efficiency": self._calculate_market_efficiency(all_offers),
                "risk_score": self._calculate_simple_risk_score(cheapest, all_offers)
            }
        }

async def main():
    """Main function for CLI usage."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Terradev GPU Arbitrage Engine')
    parser.add_argument('--user-id', required=True, help='User ID')
    parser.add_argument('--tier', choices=['freemium', 'paid'], default='freemium', help='Subscription tier')
    parser.add_argument('--gpu-type', help='Specific GPU type to search for')
    parser.add_argument('--hours', type=float, default=1.0, help='Number of GPU hours needed')
    parser.add_argument('--config', default='config.json', help='Configuration file path')
    
    args = parser.parse_args()
    
    async with GPUArbitrageEngine(args.config) as engine:
        result = await engine.run_arbitrage(
            user_id=args.user_id,
            tier=args.tier,
            gpu_type=args.gpu_type,
            hours=args.hours
        )
        
        logging.info(json.dumps(result, indent=2, default=str)

if __name__ == '__main__':
    asyncio.run(main())
