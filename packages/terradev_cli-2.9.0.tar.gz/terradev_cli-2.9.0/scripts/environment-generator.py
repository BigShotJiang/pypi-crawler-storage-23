import logging

#!/usr/bin/env python3
"""
Terradev Environment Generator

This script generates complete ML environments based on user selections:
- Model selection from open source repositories
- Dataset configuration
- Compute requirements
- Environment setup
"""

import argparse
import boto3
import json
import sys
import os
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class Framework(Enum):
    TENSORFLOW = "tensorflow"
    PYTORCH = "pytorch"
    HUGGINGFACE = "huggingface"
    SKLEARN = "sklearn"
    XGBOOST = "xgboost"

class TaskType(Enum):
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
    NLP = "nlp"
    COMPUTER_VISION = "computer_vision"
    REINFORCEMENT_LEARNING = "reinforcement_learning"
    TIME_SERIES = "time_series"

@dataclass
class ModelConfig:
    """Configuration for a selected model."""
    name: str
    framework: Framework
    task_type: TaskType
    model_id: str
    repository_url: str
    requirements: List[str]
    gpu_memory_required: int
    compute_requirements: Dict[str, Any]
    popularity_score: float

@dataclass
class DatasetConfig:
    """Configuration for dataset selection."""
    name: str
    source_url: str
    format: str
    size_gb: float
    preprocessing_required: bool
    task_type: TaskType

@dataclass
class ComputeConfig:
    """Configuration for compute resources."""
    instance_type: str
    gpu_count: int
    gpu_memory_gb: int
    ram_gb: int
    storage_gb: int
    estimated_cost_per_hour: float

@dataclass
class EnvironmentConfig:
    """Complete environment configuration."""
    name: str
    model: ModelConfig
    dataset: DatasetConfig
    compute: ComputeConfig
    framework_requirements: Dict[str, str]
    environment_variables: Dict[str, str]

class ModelRegistry:
    """Registry for discovering and managing open source models."""
    
    def __init__(self, region: str = 'us-west-2'):
        self.region = region
        self.session = boto3.Session(region_name=region)
        self.dynamodb = self.session.client('dynamodb')
        self.s3 = self.session.client('s3')
        
    def discover_models(self, task_type: TaskType, framework: Optional[Framework] = None) -> List[ModelConfig]:
        """Discover models based on task type and framework."""
        models = []
        
        # Query popular models from Hugging Face, TensorFlow Hub, PyTorch Hub
        if framework == Framework.HUGGINGFACE or framework is None:
            models.extend(self._get_huggingface_models(task_type))
        
        if framework == Framework.TENSORFLOW or framework is None:
            models.extend(self._get_tensorflow_models(task_type))
        
        if framework == Framework.PYTORCH or framework is None:
            models.extend(self._get_pytorch_models(task_type))
        
        return sorted(models, key=lambda x: x.popularity_score, reverse=True)
    
    def _get_huggingface_models(self, task_type: TaskType) -> List[ModelConfig]:
        """Get models from Hugging Face Hub."""
        # Popular models by task type
        model_mappings = {
            TaskType.NLP: [
                ModelConfig(
                    name="BERT Base",
                    framework=Framework.HUGGINGFACE,
                    task_type=TaskType.NLP,
                    model_id="bert-base-uncased",
                    repository_url="https://huggingface.co/bert-base-uncased",
                    requirements=["transformers>=4.21.0", "torch>=1.12.0"],
                    gpu_memory_required=8,
                    compute_requirements={"min_vram": 8, "recommended_vram": 16},
                    popularity_score=0.95
                ),
                ModelConfig(
                    name="GPT-2",
                    framework=Framework.HUGGINGFACE,
                    task_type=TaskType.NLP,
                    model_id="gpt2",
                    repository_url="https://huggingface.co/gpt2",
                    requirements=["transformers>=4.21.0", "torch>=1.12.0"],
                    gpu_memory_required=12,
                    compute_requirements={"min_vram": 12, "recommended_vram": 24},
                    popularity_score=0.90
                ),
                ModelConfig(
                    name="T5 Base",
                    framework=Framework.HUGGINGFACE,
                    task_type=TaskType.NLP,
                    model_id="t5-base",
                    repository_url="https://huggingface.co/t5-base",
                    requirements=["transformers>=4.21.0", "torch>=1.12.0"],
                    gpu_memory_required=16,
                    compute_requirements={"min_vram": 16, "recommended_vram": 32},
                    popularity_score=0.85
                )
            ],
            TaskType.COMPUTER_VISION: [
                ModelConfig(
                    name="ResNet-50",
                    framework=Framework.HUGGINGFACE,
                    task_type=TaskType.COMPUTER_VISION,
                    model_id="resnet-50",
                    repository_url="https://huggingface.co/microsoft/resnet-50",
                    requirements=["transformers>=4.21.0", "torch>=1.12.0", "Pillow>=8.3.0"],
                    gpu_memory_required=8,
                    compute_requirements={"min_vram": 8, "recommended_vram": 16},
                    popularity_score=0.90
                ),
                ModelConfig(
                    name="CLIP",
                    framework=Framework.HUGGINGFACE,
                    task_type=TaskType.COMPUTER_VISION,
                    model_id="openai/clip-vit-base-patch32",
                    repository_url="https://huggingface.co/openai/clip-vit-base-patch32",
                    requirements=["transformers>=4.21.0", "torch>=1.12.0", "Pillow>=8.3.0"],
                    gpu_memory_required=16,
                    compute_requirements={"min_vram": 16, "recommended_vram": 24},
                    popularity_score=0.88
                )
            ]
        }
        
        return model_mappings.get(task_type, [])
    
    def _get_tensorflow_models(self, task_type: TaskType) -> List[ModelConfig]:
        """Get models from TensorFlow Hub."""
        model_mappings = {
            TaskType.COMPUTER_VISION: [
                ModelConfig(
                    name="EfficientNet B0",
                    framework=Framework.TENSORFLOW,
                    task_type=TaskType.COMPUTER_VISION,
                    model_id="efficientnet_b0",
                    repository_url="https://tfhub.dev/tensorflow/efficientnet/b0/classification/1",
                    requirements=["tensorflow>=2.9.0", "tensorflow-hub>=0.12.0"],
                    gpu_memory_required=4,
                    compute_requirements={"min_vram": 4, "recommended_vram": 8},
                    popularity_score=0.85
                )
            ],
            TaskType.NLP: [
                ModelConfig(
                    name="Universal Sentence Encoder",
                    framework=Framework.TENSORFLOW,
                    task_type=TaskType.NLP,
                    model_id="universal-sentence-encoder",
                    repository_url="https://tfhub.dev/google/universal-sentence-encoder/4",
                    requirements=["tensorflow>=2.9.0", "tensorflow-hub>=0.12.0"],
                    gpu_memory_required=2,
                    compute_requirements={"min_vram": 2, "recommended_vram": 4},
                    popularity_score=0.80
                )
            ]
        }
        
        return model_mappings.get(task_type, [])
    
    def _get_pytorch_models(self, task_type: TaskType) -> List[ModelConfig]:
        """Get models from PyTorch Hub."""
        model_mappings = {
            TaskType.COMPUTER_VISION: [
                ModelConfig(
                    name="ResNet-50 (PyTorch)",
                    framework=Framework.PYTORCH,
                    task_type=TaskType.COMPUTER_VISION,
                    model_id="resnet50",
                    repository_url="https://pytorch.org/vision/main/models/generated/torchvision.models.resnet50.html",
                    requirements=["torch>=1.12.0", "torchvision>=0.13.0"],
                    gpu_memory_required=8,
                    compute_requirements={"min_vram": 8, "recommended_vram": 16},
                    popularity_score=0.85
                )
            ],
            TaskType.REINFORCEMENT_LEARNING: [
                ModelConfig(
                    name="PPO",
                    framework=Framework.PYTORCH,
                    task_type=TaskType.REINFORCEMENT_LEARNING,
                    model_id="ppo",
                    repository_url="https://stable-baselines3.readthedocs.io/en/master/modules/ppo.html",
                    requirements=["torch>=1.12.0", "stable-baselines3>=1.6.0", "gymnasium>=0.26.0"],
                    gpu_memory_required=4,
                    compute_requirements={"min_vram": 4, "recommended_vram": 8},
                    popularity_score=0.75
                )
            ]
        }
        
        return model_mappings.get(task_type, [])

class DatasetRegistry:
    """Registry for discovering and managing datasets."""
    
    def __init__(self):
        self.datasets = self._load_datasets()
    
    def _load_datasets(self) -> Dict[TaskType, List[DatasetConfig]]:
        """Load available datasets by task type."""
        return {
            TaskType.COMPUTER_VISION: [
                DatasetConfig(
                    name="ImageNet",
                    source_url="http://image-net.org/",
                    format="tfrecords",
                    size_gb=150.0,
                    preprocessing_required=True,
                    task_type=TaskType.COMPUTER_VISION
                ),
                DatasetConfig(
                    name="CIFAR-10",
                    source_url="https://www.cs.toronto.edu/~kriz/cifar.html",
                    format="numpy",
                    size_gb=0.2,
                    preprocessing_required=False,
                    task_type=TaskType.COMPUTER_VISION
                ),
                DatasetConfig(
                    name="COCO",
                    source_url="https://cocodataset.org/",
                    format="json",
                    size_gb=25.0,
                    preprocessing_required=True,
                    task_type=TaskType.COMPUTER_VISION
                )
            ],
            TaskType.NLP: [
                DatasetConfig(
                    name="GLUE",
                    source_url="https://gluebenchmark.com/",
                    format="csv",
                    size_gb=0.5,
                    preprocessing_required=True,
                    task_type=TaskType.NLP
                ),
                DatasetConfig(
                    name="SQuAD",
                    source_url="https://rajpurkar.github.io/SQuAD-explorer/",
                    format="json",
                    size_gb=0.1,
                    preprocessing_required=True,
                    task_type=TaskType.NLP
                )
            ],
            TaskType.REINFORCEMENT_LEARNING: [
                DatasetConfig(
                    name="OpenAI Gym Environments",
                    source_url="https://gym.openai.com/",
                    format="environment",
                    size_gb=0.0,
                    preprocessing_required=False,
                    task_type=TaskType.REINFORCEMENT_LEARNING
                )
            ]
        }
    
    def get_datasets(self, task_type: TaskType) -> List[DatasetConfig]:
        """Get datasets for a specific task type."""
        return self.datasets.get(task_type, [])

class ComputeOptimizer:
    """Optimize compute resources based on model and dataset requirements."""
    
    def __init__(self, region: str = 'us-west-2'):
        self.region = region
        self.pricing_data = self._load_pricing_data()
    
    def _load_pricing_data(self) -> Dict[str, Dict[str, float]]:
        """Load GPU instance pricing data."""
        return {
            "p3.2xlarge": {"on_demand": 3.06, "spot": 0.92, "gpu_memory": 16, "ram": 61},
            "p3.8xlarge": {"on_demand": 12.24, "spot": 3.68, "gpu_memory": 64, "ram": 244},
            "p3.16xlarge": {"on_demand": 24.48, "spot": 7.36, "gpu_memory": 128, "ram": 488},
            "p4d.24xlarge": {"on_demand": 32.77, "spot": 9.83, "gpu_memory": 320, "ram": 1152},
            "g4dn.xlarge": {"on_demand": 0.526, "spot": 0.158, "gpu_memory": 16, "ram": 16},
            "g4dn.2xlarge": {"on_demand": 1.052, "spot": 0.316, "gpu_memory": 16, "ram": 32},
            "g5.xlarge": {"on_demand": 1.006, "spot": 0.302, "gpu_memory": 24, "ram": 16},
            "g5.2xlarge": {"on_demand": 2.012, "spot": 0.604, "gpu_memory": 24, "ram": 32},
            "g5.4xlarge": {"on_demand": 4.024, "spot": 1.207, "gpu_memory": 24, "ram": 64},
            "g5.8xlarge": {"on_demand": 8.048, "spot": 2.414, "gpu_memory": 48, "ram": 128},
            "g5.16xlarge": {"on_demand": 16.096, "spot": 4.829, "gpu_memory": 48, "ram": 256}
        }
    
    def recommend_instance(self, model: ModelConfig, dataset: DatasetConfig, 
                          budget_constraint: Optional[float] = None) -> ComputeConfig:
        """Recommend optimal instance type based on requirements."""
        required_gpu_memory = model.gpu_memory_required
        required_ram = max(16, model.compute_requirements.get("min_ram", 16))
        
        # Filter instances that meet requirements
        suitable_instances = []
        for instance_type, specs in self.pricing_data.items():
            if specs["gpu_memory"] >= required_gpu_memory and specs["ram"] >= required_ram:
                if budget_constraint is None or specs["on_demand"] <= budget_constraint:
                    suitable_instances.append((instance_type, specs))
        
        if not suitable_instances:
            raise ValueError("No suitable instance found for requirements")
        
        # Select the most cost-effective option
        best_instance = min(suitable_instances, key=lambda x: x[1]["on_demand"])
        instance_type, specs = best_instance
        
        return ComputeConfig(
            instance_type=instance_type,
            gpu_count=1 if "xlarge" in instance_type else 4 if "8xlarge" in instance_type else 8,
            gpu_memory_gb=specs["gpu_memory"],
            ram_gb=specs["ram"],
            storage_gb=max(100, int(dataset.size_gb * 2)),  # Double dataset size for processing
            estimated_cost_per_hour=specs["on_demand"]
        )

class EnvironmentGenerator:
    """Main environment generator class."""
    
    def __init__(self, region: str = 'us-west-2'):
        self.model_registry = ModelRegistry(region)
        self.dataset_registry = DatasetRegistry()
        self.compute_optimizer = ComputeOptimizer(region)
    
    def interactive_setup(self) -> EnvironmentConfig:
        """Interactive environment setup."""
        logging.info("🚀 Terradev Environment Generator")
        logging.info("=" * 50)
        
        # Step 1: Choose task type
        task_type = self._choose_task_type()
        
        # Step 2: Choose framework
        framework = self._choose_framework()
        
        # Step 3: Choose model
        model = self._choose_model(task_type, framework)
        
        # Step 4: Choose dataset
        dataset = self._choose_dataset(task_type)
        
        # Step 5: Compute requirements
        compute = self._choose_compute(model, dataset)
        
        # Step 6: Environment name
        env_name = self._choose_environment_name()
        
        # Generate configuration
        config = self._generate_environment_config(env_name, model, dataset, compute)
        
        return config
    
    def _choose_task_type(self) -> TaskType:
        """Let user choose task type."""
        logging.info("\n📋 Choose your task type:")
        for i, task_type in enumerate(TaskType, 1):
            logging.info(f"{i}. {task_type.value.replace('_', ' ')
        
        while True:
            try:
                choice = int(input("\nEnter your choice (1-6): ")) - 1
                return list(TaskType)[choice]
            except (ValueError, IndexError):
                logging.info("Invalid choice. Please try again.")
    
    def _choose_framework(self) -> Framework:
        """Let user choose framework."""
        logging.info("\n🔧 Choose your ML framework:")
        for i, framework in enumerate(Framework, 1):
            logging.info(f"{i}. {framework.value.title()
        
        while True:
            try:
                choice = int(input("\nEnter your choice (1-5): ")) - 1
                return list(Framework)[choice]
            except (ValueError, IndexError):
                logging.info("Invalid choice. Please try again.")
    
    def _choose_model(self, task_type: TaskType, framework: Framework) -> ModelConfig:
        """Let user choose a model."""
        models = self.model_registry.discover_models(task_type, framework)
        
        if not models:
            logging.info(f"\n❌ No models found for {task_type.value} with {framework.value}")
            logging.info("Try a different framework or task type.")
            return self._choose_model(task_type, self._choose_framework())
        
        logging.info(f"\n🤖 Available models for {task_type.value} ({framework.value})
        for i, model in enumerate(models, 1):
            logging.info(f"{i}. {model.name}")
            logging.info(f"   GPU Memory: {model.gpu_memory_required}GB")
            logging.info(f"   Popularity: {'⭐' * int(model.popularity_score * 5)
        
        while True:
            try:
                choice = int(input(f"\nEnter your choice (1-{len(models)}): ")) - 1
                return models[choice]
            except (ValueError, IndexError):
                logging.info("Invalid choice. Please try again.")
    
    def _choose_dataset(self, task_type: TaskType) -> DatasetConfig:
        """Let user choose a dataset."""
        datasets = self.dataset_registry.get_datasets(task_type)
        
        if not datasets:
            logging.info(f"\n❌ No datasets found for {task_type.value}")
            return DatasetConfig(
                name="Custom Dataset",
                source_url="",
                format="custom",
                size_gb=0,
                preprocessing_required=False,
                task_type=task_type
            )
        
        logging.info(f"\n📊 Available datasets for {task_type.value}:")
        for i, dataset in enumerate(datasets, 1):
            logging.info(f"{i}. {dataset.name}")
            logging.info(f"   Size: {dataset.size_gb}GB")
            logging.info(f"   Format: {dataset.format}")
        
        while True:
            try:
                choice = int(input(f"\nEnter your choice (1-{len(datasets)}): ")) - 1
                return datasets[choice]
            except (ValueError, IndexError):
                logging.info("Invalid choice. Please try again.")
    
    def _choose_compute(self, model: ModelConfig, dataset: DatasetConfig) -> ComputeConfig:
        """Let user choose compute configuration."""
        logging.info(f"\n💻 Computing optimal instance for {model.name}...")
        
        try:
            compute = self.compute_optimizer.recommend_instance(model, dataset)
            
            logging.info(f"\nRecommended configuration:")
            logging.info(f"Instance Type: {compute.instance_type}")
            logging.info(f"GPU Count: {compute.gpu_count}")
            logging.info(f"GPU Memory: {compute.gpu_memory_gb}GB")
            logging.info(f"RAM: {compute.ram_gb}GB")
            logging.info(f"Storage: {compute.storage_gb}GB")
            logging.info(f"Estimated Cost: ${compute.estimated_cost_per_hour:.2f}/hour")
            
            if input("\nUse this configuration? (y/n): ").lower() == 'y':
                return compute
            
            # Let user choose budget constraint
            budget = float(input("Enter maximum hourly budget ($): "))
            return self.compute_optimizer.recommend_instance(model, dataset, budget)
            
        except ValueError as e:
            logging.info(f"❌ {e}")
            return self._choose_compute(model, dataset)
    
    def _choose_environment_name(self) -> str:
        """Let user choose environment name."""
        default_name = f"terradev-env-{int(time.time())}"
        name = input(f"\n🏷️  Environment name (default: {default_name}): ").strip()
        return name if name else default_name
    
    def _generate_environment_config(self, env_name: str, model: ModelConfig, 
                                  dataset: DatasetConfig, compute: ComputeConfig) -> EnvironmentConfig:
        """Generate complete environment configuration."""
        
        # Framework-specific requirements
        framework_requirements = {
            "python": ">=3.8"
        }
        
        if model.framework == Framework.TENSORFLOW:
            framework_requirements.update({
                "tensorflow": ">=2.9.0",
                "tensorflow-hub": ">=0.12.0"
            })
        elif model.framework == Framework.PYTORCH:
            framework_requirements.update({
                "torch": ">=1.12.0",
                "torchvision": ">=0.13.0"
            })
        elif model.framework == Framework.HUGGINGFACE:
            framework_requirements.update({
                "transformers": ">=4.21.0",
                "torch": ">=1.12.0",
                "datasets": ">=2.0.0"
            })
        
        # Add model-specific requirements
        framework_requirements.update({req.split(">=")[0]: req.split(">=")[1] if ">=" in req else "" 
                                     for req in model.requirements})
        
        # Environment variables
        environment_variables = {
            "MODEL_NAME": model.name,
            "MODEL_ID": model.model_id,
            "DATASET_NAME": dataset.name,
            "FRAMEWORK": model.framework.value,
            "TASK_TYPE": model.task_type.value,
            "GPU_MEMORY_REQUIRED": str(model.gpu_memory_required)
        }
        
        return EnvironmentConfig(
            name=env_name,
            model=model,
            dataset=dataset,
            compute=compute,
            framework_requirements=framework_requirements,
            environment_variables=environment_variables
        )
    
    def generate_terraform(self, config: EnvironmentConfig, output_dir: str = "./generated-environments") -> str:
        """Generate Terraform configuration for the environment."""
        os.makedirs(output_dir, exist_ok=True)
        
        env_dir = os.path.join(output_dir, config.name)
        os.makedirs(env_dir, exist_ok=True)
        
        # Generate main.tf
        main_tf_content = self._generate_main_tf(config)
        with open(os.path.join(env_dir, "main.tf"), "w") as f:
            f.write(main_tf_content)
        
        # Generate variables.tf
        variables_tf_content = self._generate_variables_tf(config)
        with open(os.path.join(env_dir, "variables.tf"), "w") as f:
            f.write(variables_tf_content)
        
        # Generate outputs.tf
        outputs_tf_content = self._generate_outputs_tf(config)
        with open(os.path.join(env_dir, "outputs.tf"), "w") as f:
            f.write(outputs_tf_content)
        
        # Generate requirements.txt
        requirements_content = self._generate_requirements(config)
        with open(os.path.join(env_dir, "requirements.txt"), "w") as f:
            f.write(requirements_content)
        
        # Generate user data script
        user_data_content = self._generate_user_data(config)
        with open(os.path.join(env_dir, "user-data.sh"), "w") as f:
            f.write(user_data_content)
        
        logging.info(f"\n✅ Environment generated successfully!")
        logging.info(f"📁 Location: {env_dir}")
        logging.info(f"\nTo deploy:")
        logging.info(f"cd {env_dir}")
        logging.info(f"terraform init")
        logging.info(f"terraform plan")
        logging.info(f"terraform apply")
        
        return env_dir
    
    def _generate_main_tf(self, config: EnvironmentConfig) -> str:
        """Generate main.tf content."""
        return f'''
# Generated Terradev Environment: {config.name}
# Model: {config.model.name}
# Framework: {config.model.framework.value}
# Task: {config.model.task_type.value}

terraform {{
  required_version = ">= 1.0"
  required_providers {{
    aws = {{
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }}
  }}
}}

provider "aws" {{
  region = var.aws_region
}}

# GPU Instance for {config.model.name}
module "gpu_instance" {{
  source = "../../modules/gpu-compute"

  name_prefix = "{config.name}"
  instance_count = 1
  instance_type = "{config.compute.instance_type}"
  ami_id = data.aws_ami.deep_learning.id
  
  subnet_id = aws_subnet.main.id
  security_group_ids = [aws_security_group.main.id]
  assign_public_ip = true
  
  root_volume_size = {config.compute.storage_gb}
  
  enable_monitoring = true
  
  tags = {{
    Project = "Terradev"
    Environment = "{config.name}"
    Model = "{config.model.name}"
    Framework = "{config.model.framework.value}"
  }}
  
  user_data = base64encode(file("{path.module}/user-data.sh"))
}}

# Storage for model and dataset
module "storage" {{
  source = "../../modules/storage"

  name_prefix = "{config.name}"
  enable_versioning = true
  enable_efs = true
  subnet_ids = [aws_subnet.main.id]
  efs_security_groups = [aws_security_group.main.id]
  
  tags = {{
    Project = "Terradev"
    Environment = "{config.name}"
  }}
}}

# Data feed for dataset
module "data_feeds" {{
  source = "../../modules/data-feeds"

  name_prefix = "{config.name}"
  
  data_feeds = [
    {{
      name = "{config.dataset.name}"
      type = "http"
      source_url = "{config.dataset.source_url}"
      update_freq = "daily"
      enabled = true
      format = "{config.dataset.format}"
    }}
  ]
  
  enable_processing = true
  
  tags = {{
    Project = "Terradev"
    Environment = "{config.name}"
  }}
}}

# Networking
resource "aws_vpc" "main" {{
  cidr_block = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support = true

  tags = {{
    Name = "{config.name}-vpc"
    Project = "Terradev"
  }}
}}

resource "aws_subnet" "main" {{
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.1.0/24"
  availability_zone = "{self.compute_optimizer.region}a"

  tags = {{
    Name = "{config.name}-subnet"
    Project = "Terradev"
  }}
}}

resource "aws_internet_gateway" "main" {{
  vpc_id = aws_vpc.main.id

  tags = {{
    Name = "{config.name}-igw"
    Project = "Terradev"
  }}
}}

resource "aws_route_table" "main" {{
  vpc_id = aws_vpc.main.id

  route {{
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }}

  tags = {{
    Name = "{config.name}-rt"
    Project = "Terradev"
  }}
}}

resource "aws_route_table_association" "main" {{
  subnet_id      = aws_subnet.main.id
  route_table_id = aws_route_table.main.id
}}

# Security Group
resource "aws_security_group" "main" {{
  name        = "{config.name}-sg"
  description = "Security group for {config.name}"
  vpc_id      = aws_vpc.main.id

  ingress {{
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }}

  ingress {{
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }}

  ingress {{
    from_port   = 6006
    to_port     = 6006
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }}

  egress {{
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }}

  tags = {{
    Name = "{config.name}-sg"
    Project = "Terradev"
  }}
}}

# Deep Learning AMI
data "aws_ami" "deep_learning" {{
  most_recent = true
  owners      = ["amazon"]

  filter {{
    name   = "name"
    values = ["Deep Learning AMI GPU {config.model.framework.value.title()}*"]
  }}

  filter {{
    name   = "virtualization-type"
    values = ["hvm"]
  }}
}}
'''
    
    def _generate_variables_tf(self, config: EnvironmentConfig) -> str:
        """Generate variables.tf content."""
        return f'''
# Variables for {config.name} environment

variable "aws_region" {{
  description = "AWS region"
  type        = string
  default     = "{self.compute_optimizer.region}"
}}

variable "environment" {{
  description = "Environment name"
  type        = string
  default     = "{config.name}"
}}

variable "model_name" {{
  description = "Model name"
  type        = string
  default     = "{config.model.name}"
}}

variable "framework" {{
  description = "ML framework"
  type        = string
  default     = "{config.model.framework.value}"
}}

variable "task_type" {{
  description = "Task type"
  type        = string
  default     = "{config.model.task_type.value}"
}}

variable "instance_type" {{
  description = "GPU instance type"
  type        = string
  default     = "{config.compute.instance_type}"
}}

variable "budget_per_hour" {{
  description = "Maximum budget per hour"
  type        = number
  default     = {config.compute.estimated_cost_per_hour}
}}
'''
    
    def _generate_outputs_tf(self, config: EnvironmentConfig) -> str:
        """Generate outputs.tf content."""
        return f'''
# Outputs for {config.name} environment

output "instance_id" {{
  description = "GPU instance ID"
  value       = module.gpu_instance.instance_ids[0]
}}

output "instance_public_ip" {{
  description = "GPU instance public IP"
  value       = module.gpu_instance.instance_public_ips[0]
}}

output "storage_bucket" {{
  description = "S3 bucket for storage"
  value       = module.storage.s3_bucket_name
}}

output "efs_filesystem_id" {{
  description = "EFS filesystem ID"
  value       = module.storage.efs_file_system_id
}}

output "model_info" {{
  description = "Model information"
  value = {{
    name      = "{config.model.name}"
    framework = "{config.model.framework.value}"
    task_type = "{config.model.task_type.value}"
    model_id  = "{config.model.model_id}"
  }}
}}

output "dataset_info" {{
  description = "Dataset information"
  value = {{
    name       = "{config.dataset.name}"
    source_url = "{config.dataset.source_url}"
    format     = "{config.dataset.format}"
    size_gb    = {config.dataset.size_gb}
  }}
}}

output "connection_info" {{
  description = "Connection information"
  value = {{
    ssh_command = "ssh -i ~/.ssh/your-key.pem ec2-user@${{module.gpu_instance.instance_public_ips[0]}}"
    tensorboard_url = "http://${{module.gpu_instance.instance_public_ips[0]}}:6006"
  }}
}}
'''
    
    def _generate_requirements(self, config: EnvironmentConfig) -> str:
        """Generate requirements.txt content."""
        requirements = ["boto3>=1.29.0", "requests>=2.28.0"]
        
        for package, version in config.framework_requirements.items():
            if version:
                requirements.append(f"{package}{version}")
            else:
                requirements.append(package)
        
        return "\n".join(sorted(requirements))
    
    def _generate_user_data(self, config: EnvironmentConfig) -> str:
        """Generate user-data.sh content."""
        env_vars = "\n".join([f'export {k}="{v}"' for k, v in config.environment_variables.items()])
        
        return f'''#!/bin/bash
# User data script for {config.name} environment

set -e

# Environment variables
{env_vars}

# Logging
LOG_FILE="/var/log/setup.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "Setting up {config.name} environment..."
echo "Model: {config.model.name}"
echo "Framework: {config.model.framework.value}"
echo "Task: {config.model.task_type.value}"

# Update system
yum update -y

# Install Python and tools
yum install -y python3 python3-pip git htop

# Create virtual environment
python3 -m venv /opt/venv
source /opt/venv/bin/activate

# Install requirements
pip install --upgrade pip
pip install -r /tmp/requirements.txt

# Install model-specific dependencies
if [ "$FRAMEWORK" = "tensorflow" ]; then
    pip install tensorflow>=2.9.0
elif [ "$FRAMEWORK" = "pytorch" ]; then
    pip install torch>=1.12.0 torchvision>=0.13.0
elif [ "$FRAMEWORK" = "huggingface" ]; then
    pip install transformers>=4.21.0 datasets>=2.0.0 torch>=1.12.0
fi

# Setup directories
mkdir -p /opt/models
mkdir -p /opt/data
mkdir -p /opt/logs

# Download model
echo "Downloading model: {config.model.name}..."
cd /opt/models

# Model download logic would go here
# This is a placeholder for actual model download

# Setup TensorBoard
pip install tensorboard
mkdir -p /opt/logs/tensorboard
nohup tensorboard --logdir=/opt/logs/tensorboard --host=0.0.0.0 --port=6006 &

echo "Environment setup completed!"
echo "TensorBoard: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):6006"
'''

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="Terradev Environment Generator")
    parser.add_argument("--region", default="us-west-2", help="AWS region")
    parser.add_argument("--output-dir", default="./generated-environments", help="Output directory")
    
    args = parser.parse_args()
    
    generator = EnvironmentGenerator(args.region)
    
    try:
        # Interactive setup
        config = generator.interactive_setup()
        
        # Generate Terraform
        env_dir = generator.generate_terraform(config, args.output_dir)
        
        logging.info(f"\n🎉 Environment '{config.name}' is ready to deploy!")
        logging.info(f"📂 Generated files are in: {env_dir}")
        
    except KeyboardInterrupt:
        logging.info("\n\n❌ Setup cancelled by user.")
        sys.exit(1)
    except Exception as e:
        logging.info(f"\n❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    import time
    main()
