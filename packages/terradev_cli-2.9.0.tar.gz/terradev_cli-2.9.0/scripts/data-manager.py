import logging

#!/usr/bin/env python3
"""
Terradev Data Feed Manager

This script manages data feed integrations, including ingestion,
processing, and distribution of open source data feeds.
"""

import argparse
import boto3
import json
import requests
import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import hashlib
import os

class DataManager:
    """Manager for data feed operations."""
    
    def __init__(self, region: str = 'us-west-2', profile: Optional[str] = None):
        """Initialize the data manager."""
        session = boto3.Session(profile_name=profile) if profile else boto3.Session()
        self.s3 = session.client('s3', region_name=region)
        self.lambda_client = session.client('lambda', region_name=region)
        self.dynamodb = session.client('dynamodb', region_name=region)
        self.region = region
    
    def list_data_feeds(self, bucket_name: str) -> List[Dict[str, Any]]:
        """List all available data feeds."""
        try:
            response = self.s3.list_objects_v2(Bucket=bucket_name)
            
            feeds = []
            for obj in response.get('Contents', []):
                key = obj['Key']
                if key.endswith('/'):
                    feed_name = key.rstrip('/')
                    feeds.append({
                        'name': feed_name,
                        'path': f"s3://{bucket_name}/{feed_name}/",
                        'last_modified': obj['LastModified'].isoformat(),
                        'size': obj['Size']
                    })
            
            return sorted(feeds, key=lambda x: x['name'])
        except Exception as e:
            logging.info(f"Error listing data feeds: {e}")
            return []
    
    def add_data_feed(self, bucket_name: str, feed_config: Dict[str, Any]) -> bool:
        """Add a new data feed configuration."""
        try:
            feed_name = feed_config['name']
            feed_path = f"{feed_name}/"
            
            # Create feed metadata
            metadata = {
                'name': feed_name,
                'type': feed_config['type'],
                'source_url': feed_config['source_url'],
                'update_freq': feed_config['update_freq'],
                'enabled': feed_config['enabled'],
                'format': feed_config.get('format', 'json'),
                'compression': feed_config.get('compression', False),
                'created_at': datetime.utcnow().isoformat(),
                'last_updated': None,
                'status': 'pending'
            }
            
            # Upload metadata to S3
            metadata_key = f"{feed_path}metadata.json"
            self.s3.put_object(
                Bucket=bucket_name,
                Key=metadata_key,
                Body=json.dumps(metadata, indent=2),
                ContentType='application/json'
            )
            
            # Create initial data file
            initial_data = {
                'feed_info': metadata,
                'data': [],
                'version': '1.0.0'
            }
            
            data_key = f"{feed_path}data.json"
            self.s3.put_object(
                Bucket=bucket_name,
                Key=data_key,
                Body=json.dumps(initial_data, indent=2),
                ContentType='application/json'
            )
            
            logging.info(f"Added data feed: {feed_name}")
            return True
        except Exception as e:
            logging.info(f"Error adding data feed: {e}")
            return False
    
    def fetch_data_feed(self, feed_config: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch data from a data feed source."""
        try:
            source_url = feed_config['source_url']
            feed_type = feed_config['type']
            
            if feed_type == 'http' or feed_type == 'api':
                return self._fetch_http_data(source_url, feed_config)
            elif feed_type == 'ftp':
                return self._fetch_ftp_data(source_url, feed_config)
            elif feed_type == 'rss':
                return self._fetch_rss_data(source_url, feed_config)
            else:
                return {'error': f'Unsupported feed type: {feed_type}'}
        except Exception as e:
            return {'error': f'Error fetching data: {e}'}
    
    def _fetch_http_data(self, url: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch data from HTTP/HTTPS endpoint."""
        try:
            headers = config.get('headers', {})
            params = config.get('params', {})
            timeout = config.get('timeout', 30)
            
            response = # TODO: PERFORMANCE - Consider async/await for requests HTTP call
# geturl, headers=headers, params=params, timeout=timeout)
            response.raise_for_status()
            
            content_type = response.headers.get('content-type', '').lower()
            
            if 'application/json' in content_type:
                data = response.json()
            elif 'text/csv' in content_type or 'csv' in content_type:
                # Handle CSV data
                import csv
                import io
                reader = csv.DictReader(io.StringIO(response.text))
                data = list(reader)
            else:
                # Return raw text for other formats
                data = {'raw_data': response.text}
            
            return {
                'data': data,
                'status_code': response.status_code,
                'content_type': content_type,
                'fetched_at': datetime.utcnow().isoformat(),
                'size': len(response.content)
            }
        except Exception as e:
            return {'error': f'HTTP fetch error: {e}'}
    
    def _fetch_ftp_data(self, url: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch data from FTP server."""
        # Placeholder for FTP implementation
        return {'error': 'FTP fetching not implemented yet'}
    
    def _fetch_rss_data(self, url: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch data from RSS feed."""
        try:
            import feedparser
            
            feed = feedparser.parse(url)
            
            entries = []
            for entry in feed.entries:
                entries.append({
                    'title': entry.get('title', ''),
                    'link': entry.get('link', ''),
                    'description': entry.get('description', ''),
                    'published': entry.get('published', ''),
                    'id': entry.get('id', '')
                })
            
            return {
                'data': entries,
                'feed_title': feed.feed.get('title', ''),
                'feed_description': feed.feed.get('description', ''),
                'entries_count': len(entries),
                'fetched_at': datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {'error': f'RSS fetch error: {e}'}
    
# TODO: REFACTOR - update_data_feed() is 58 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def update_data_feed(self, bucket_name: str, feed_name: str) -> bool:
        """Update a specific data feed."""
        try:
            # Fetch feed metadata
            metadata_key = f"{feed_name}/metadata.json"
            response = self.s3.get_object(Bucket=bucket_name, Key=metadata_key)
            metadata = json.loads(response['Body'].read().decode('utf-8'))
            
            if not metadata.get('enabled', False):
                logging.info(f"Feed {feed_name} is disabled, skipping update")
                return False
            
            # Fetch new data
            fetched_data = self.fetch_data_feed(metadata)
            if 'error' in fetched_data:
                logging.info(f"Error fetching data for {feed_name}: {fetched_data['error']}")
                return False
            
            # Update metadata
            metadata['last_updated'] = datetime.utcnow().isoformat()
            metadata['status'] = 'updated'
            metadata['last_fetch_size'] = fetched_data.get('size', 0)
            
            # Create new data version
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            data_key = f"{feed_name}/data_{timestamp}.json"
            
            data_payload = {
                'feed_info': metadata,
                'data': fetched_data['data'],
                'fetch_metadata': {
                    'fetched_at': fetched_data['fetched_at'],
                    'content_type': fetched_data.get('content_type', ''),
                    'size': fetched_data.get('size', 0)
                },
                'version': timestamp
            }
            
            # Upload new data
            self.s3.put_object(
                Bucket=bucket_name,
                Key=data_key,
                Body=json.dumps(data_payload, indent=2),
                ContentType='application/json'
            )
            
            # Update metadata
            self.s3.put_object(
                Bucket=bucket_name,
                Key=metadata_key,
                Body=json.dumps(metadata, indent=2),
                ContentType='application/json'
            )
            
            logging.info(f"Updated data feed: {feed_name}")
            return True
        except Exception as e:
            logging.info(f"Error updating data feed {feed_name}: {e}")
            return False
    
    def process_data_feed(self, bucket_name: str, feed_name: str, processor_config: Dict[str, Any]) -> bool:
        """Process a data feed with custom processing logic."""
        try:
            # Get latest data
            data_key = f"{feed_name}/data.json"
            response = self.s3.get_object(Bucket=bucket_name, Key=data_key)
            data = json.loads(response['Body'].read().decode('utf-8'))
            
            # Apply processing based on configuration
            processed_data = self._apply_processing(data, processor_config)
            
            # Save processed data
            processed_key = f"{feed_name}/processed_data.json"
            self.s3.put_object(
                Bucket=bucket_name,
                Key=processed_key,
                Body=json.dumps(processed_data, indent=2),
                ContentType='application/json'
            )
            
            logging.info(f"Processed data feed: {feed_name}")
            return True
        except Exception as e:
            logging.info(f"Error processing data feed {feed_name}: {e}")
            return False
    
    def _apply_processing(self, data: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        """Apply data processing transformations."""
        processed_data = data.copy()
        
        # Apply filters
        if 'filters' in config:
            for filter_config in config['filters']:
                processed_data['data'] = self._apply_filter(processed_data['data'], filter_config)
        
        # Apply transformations
        if 'transformations' in config:
            for transform_config in config['transformations']:
                processed_data['data'] = self._apply_transformation(processed_data['data'], transform_config)
        
        # Apply aggregations
        if 'aggregations' in config:
            for agg_config in config['aggregations']:
                processed_data['data'] = self._apply_aggregation(processed_data['data'], agg_config)
        
        processed_data['processed_at'] = datetime.utcnow().isoformat()
        processed_data['processing_config'] = config
        
        return processed_data
    
    def _apply_filter(self, data: List[Dict], filter_config: Dict[str, Any]) -> List[Dict]:
        """Apply filter to data."""
        field = filter_config['field']
        operator = filter_config['operator']
        value = filter_config['value']
        
        filtered_data = []
        for item in data:
            item_value = item.get(field)
            if self._evaluate_condition(item_value, operator, value):
                filtered_data.append(item)
        
        return filtered_data
    
    def _apply_transformation(self, data: List[Dict], transform_config: Dict[str, Any]) -> List[Dict]:
        """Apply transformation to data."""
        transform_type = transform_config['type']
        
        if transform_type == 'rename_field':
            old_field = transform_config['old_field']
            new_field = transform_config['new_field']
            for item in data:
                if old_field in item:
                    item[new_field] = item.pop(old_field)
        
        elif transform_type == 'add_field':
            field = transform_config['field']
            value = transform_config['value']
            for item in data:
                item[field] = value
        
        elif transform_type == 'convert_type':
            field = transform_config['field']
            target_type = transform_config['target_type']
            for item in data:
                if field in item:
                    item[field] = self._convert_type(item[field], target_type)
        
        return data
    
    def _apply_aggregation(self, data: List[Dict], agg_config: Dict[str, Any]) -> List[Dict]:
        """Apply aggregation to data."""
        agg_type = agg_config['type']
        group_by = agg_config.get('group_by')
        field = agg_config['field']
        
        if group_by:
            # Group by aggregation
            groups = {}
            for item in data:
                key = item.get(group_by)
                if key not in groups:
                    groups[key] = []
                groups[key].append(item.get(field))
            
            result = []
            for key, values in groups.items():
                agg_value = self._calculate_aggregation(values, agg_type)
                result.append({
                    group_by: key,
                    f'{field}_{agg_type}': agg_value,
                    'count': len(values)
                })
            return result
        else:
            # Simple aggregation
            values = [item.get(field) for item in data if field in item]
            agg_value = self._calculate_aggregation(values, agg_type)
            return [{
                f'{field}_{agg_type}': agg_value,
                'count': len(values)
            }]
    
    def _evaluate_condition(self, item_value: Any, operator: str, value: Any) -> bool:
        """Evaluate filter condition."""
        if operator == 'equals':
            return item_value == value
        elif operator == 'not_equals':
            return item_value != value
        elif operator == 'greater_than':
            return item_value > value
        elif operator == 'less_than':
            return item_value < value
        elif operator == 'contains':
            return value in str(item_value)
        elif operator == 'not_contains':
            return value not in str(item_value)
        else:
            return True
    
    def _convert_type(self, value: Any, target_type: str) -> Any:
        """Convert data type."""
        try:
            if target_type == 'int':
                return int(value)
            elif target_type == 'float':
                return float(value)
            elif target_type == 'str':
                return str(value)
            elif target_type == 'bool':
                return bool(value)
            else:
                return value
        except (ValueError, TypeError):
            return value
    
    def _calculate_aggregation(self, values: List[Any], agg_type: str) -> Any:
        """Calculate aggregation value."""
        if not values:
            return None
        
        if agg_type == 'sum':
            return sum(values)
        elif agg_type == 'avg':
            return sum(values) / len(values)
        elif agg_type == 'min':
            return min(values)
        elif agg_type == 'max':
            return max(values)
        elif agg_type == 'count':
            return len(values)
        else:
            return None

# TODO: REFACTOR - main() is 82 lines long (should be <50)
# Consider breaking into smaller, focused functions
def main():
    """Main function for the data manager CLI."""
    parser = argparse.ArgumentParser(description='Terradev Data Feed Manager')
    parser.add_argument('--region', default='us-west-2', help='AWS region')
    parser.add_argument('--profile', help='AWS profile name')
    parser.add_argument('--bucket', required=True, help='S3 bucket name')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # List feeds command
    list_parser = subparsers.add_parser('list', help='List data feeds')
    
    # Add feed command
    add_parser = subparsers.add_parser('add', help='Add a new data feed')
    add_parser.add_argument('--name', required=True, help='Feed name')
    add_parser.add_argument('--type', required=True, choices=['http', 'api', 'ftp', 'rss'], help='Feed type')
    add_parser.add_argument('--url', required=True, help='Source URL')
    add_parser.add_argument('--freq', default='daily', help='Update frequency')
    add_parser.add_argument('--format', default='json', help='Data format')
    add_parser.add_argument('--enabled', action='store_true', default=True, help='Enable feed')
    
    # Update feed command
    update_parser = subparsers.add_parser('update', help='Update a data feed')
    update_parser.add_argument('feed_name', help='Feed name to update')
    
    # Process feed command
    process_parser = subparsers.add_parser('process', help='Process a data feed')
    process_parser.add_argument('feed_name', help='Feed name to process')
    process_parser.add_argument('--config', help='Processing configuration file')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    manager = DataManager(region=args.region, profile=args.profile)
    
    if args.command == 'list':
        feeds = manager.list_data_feeds(args.bucket)
        logging.info(f"\nData Feeds in bucket '{args.bucket}':")
        logging.info("-" * 60)
        for feed in feeds:
            logging.info(f"Name: {feed['name']}")
            logging.info(f"Path: {feed['path']}")
            logging.info(f"Last Modified: {feed['last_modified']}")
            logging.info(f"Size: {feed['size']} bytes")
            logging.info("-" * 30)
    
    elif args.command == 'add':
        feed_config = {
            'name': args.name,
            'type': args.type,
            'source_url': args.url,
            'update_freq': args.freq,
            'format': args.format,
            'enabled': args.enabled
        }
        
        success = manager.add_data_feed(args.bucket, feed_config)
        if success:
            logging.info(f"Successfully added data feed: {args.name}")
        else:
            logging.info(f"Failed to add data feed: {args.name}")
    
    elif args.command == 'update':
        success = manager.update_data_feed(args.bucket, args.feed_name)
        if success:
            logging.info(f"Successfully updated data feed: {args.feed_name}")
        else:
            logging.info(f"Failed to update data feed: {args.feed_name}")
    
    elif args.command == 'process':
        processor_config = {}
        if args.config and os.path.exists(args.config):
            with open(args.config, 'r') as f:
                processor_config = json.load(f)
        
        success = manager.process_data_feed(args.bucket, args.feed_name, processor_config)
        if success:
            logging.info(f"Successfully processed data feed: {args.feed_name}")
        else:
            logging.info(f"Failed to process data feed: {args.feed_name}")

if __name__ == '__main__':
    main()
