import logging

#!/usr/bin/env python3
"""
Terradev GPU Query Interface

This script provides a command-line interface for querying and managing
GPU compute resources provisioned through Terradev.
"""

import argparse
import boto3
import json
import sys
import time
from datetime import datetime
from typing import Dict, List, Optional, Any

class GPUQueryClient:
    """Client for querying GPU compute resources."""
    
    def __init__(self, region: str = 'us-west-2', profile: Optional[str] = None):
        """Initialize the GPU query client."""
        session = boto3.Session(profile_name=profile) if profile else boto3.Session()
        self.ec2 = session.client('ec2', region_name=region)
        self.cloudwatch = session.client('cloudwatch', region_name=region)
        self.region = region
    
    def get_gpu_instances(self, project_name: str = 'terradev') -> List[Dict[str, Any]]:
        """Get all GPU instances for the project."""
        try:
            response = self.ec2.describe_instances(
                Filters=[
                    {'Name': 'tag:Project', 'Values': [project_name]},
                    {'Name': 'tag:Type', 'Values': ['GPU-Instance']},
                    {'Name': 'instance-state-name', 'Values': ['pending', 'running', 'stopping', 'stopped']}
                ]
            )
            
            instances = []
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    instances.append(self._format_instance(instance))
            
            return instances
        except Exception as e:
            logging.info(f"Error fetching GPU instances: {e}")
            return []
    
    def _format_instance(self, instance: Dict[str, Any]) -> Dict[str, Any]:
        """Format instance data for display."""
        tags = {tag['Key']: tag['Value'] for tag in instance.get('Tags', [])}
        
        return {
            'id': instance['InstanceId'],
            'name': tags.get('Name', 'N/A'),
            'type': instance['InstanceType'],
            'state': instance['State']['Name'],
            'public_ip': instance.get('PublicIpAddress', 'N/A'),
            'private_ip': instance.get('PrivateIpAddress', 'N/A'),
            'launch_time': instance['LaunchTime'].isoformat(),
            'availability_zone': instance['Placement']['AvailabilityZone'],
            'tags': tags
        }
    
    def get_gpu_metrics(self, instance_id: str, hours: int = 1) -> Dict[str, Any]:
        """Get GPU utilization metrics for an instance."""
        try:
            end_time = datetime.utcnow()
            start_time = datetime.fromtimestamp(end_time.timestamp() - (hours * 3600))
            
            response = self.cloudwatch.get_metric_statistics(
                Namespace='AWS/EC2',
                MetricName='GPUUtilization',
                Dimensions=[
                    {'Name': 'InstanceID', 'Value': instance_id}
                ],
                StartTime=start_time,
                EndTime=end_time,
                Period=300,  # 5-minute intervals
                Statistics=['Average', 'Maximum', 'Minimum']
            )
            
            datapoints = response['Datapoints']
            if not datapoints:
                return {'error': 'No GPU metrics available'}
            
            # Sort by timestamp and get latest
            latest = sorted(datapoints, key=lambda x: x['Timestamp'])[-1]
            
            return {
                'instance_id': instance_id,
                'average_utilization': latest['Average'],
                'max_utilization': latest['Maximum'],
                'min_utilization': latest['Minimum'],
                'timestamp': latest['Timestamp'].isoformat(),
                'datapoints_count': len(datapoints)
            }
        except Exception as e:
            return {'error': f'Error fetching metrics: {e}'}
    
    def get_instance_types(self) -> List[Dict[str, Any]]:
        """Get available GPU instance types."""
        try:
            response = self.ec2.describe_instance_types(
                Filters=[
                    {'Name': 'instance-type', 'Values': [
                        'p3.*', 'p4.*', 'g4dn.*', 'g5.*'
                    ]}
                ]
            )
            
            instance_types = []
            for instance_type in response['InstanceTypes']:
                gpu_info = self._extract_gpu_info(instance_type)
                if gpu_info:
                    instance_types.append({
                        'type': instance_type['InstanceType'],
                        'vcpus': instance_type['VCpuInfo']['DefaultVCpus'],
                        'memory': instance_type['MemoryInfo']['SizeInMiB'],
                        'gpu': gpu_info,
                        'pricing': self._get_pricing(instance_type['InstanceType'])
                    })
            
            return sorted(instance_types, key=lambda x: x['type'])
        except Exception as e:
            logging.info(f"Error fetching instance types: {e}")
            return []
    
    def _extract_gpu_info(self, instance_type: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Extract GPU information from instance type."""
        for gpu in instance_type.get('GpuInfo', {}).get('Gpus', []):
            return {
                'count': instance_type['GpuInfo']['TotalGpuMemoryInMiB'] // gpu['GpuMemoryInfo']['SizeInMiB'],
                'memory': gpu['GpuMemoryInfo']['SizeInMiB'],
                'manufacturer': gpu['GpuMemoryInfo'].get('Manufacturer', 'N/A')
            }
        return None
    
    def _get_pricing(self, instance_type: str) -> Dict[str, Any]:
        """Get pricing information for instance type."""
        # This would typically integrate with AWS Pricing API
        # For now, return placeholder data
        return {
            'on_demand': 'N/A',
            'spot': 'N/A',
            'currency': 'USD'
        }
    
    def start_instance(self, instance_id: str) -> bool:
        """Start a GPU instance."""
        try:
            response = self.ec2.start_instances(InstanceIds=[instance_id])
            return response['StartingInstances'][0]['CurrentState']['Name'] == 'pending'
        except Exception as e:
            logging.info(f"Error starting instance {instance_id}: {e}")
            return False
    
    def stop_instance(self, instance_id: str) -> bool:
        """Stop a GPU instance."""
        try:
            response = self.ec2.stop_instances(InstanceIds=[instance_id])
            return response['StoppingInstances'][0]['CurrentState']['Name'] == 'stopping'
        except Exception as e:
            logging.info(f"Error stopping instance {instance_id}: {e}")
            return False
    
    def estimate_cost(self, instance_type: str, hours: int = 1) -> Dict[str, Any]:
        """Estimate cost for running an instance."""
        # Placeholder for cost estimation
        # In production, this would integrate with AWS Pricing API
        return {
            'instance_type': instance_type,
            'hours': hours,
            'estimated_cost': 'N/A',
            'currency': 'USD',
            'note': 'Cost estimation requires AWS Pricing API integration'
        }

# TODO: REFACTOR - main() is 106 lines long (should be <50)
# Consider breaking into smaller, focused functions
def main():
    """Main function for the GPU query CLI."""
    parser = argparse.ArgumentParser(description='Terradev GPU Query Interface')
    parser.add_argument('--region', default='us-west-2', help='AWS region')
    parser.add_argument('--profile', help='AWS profile name')
    parser.add_argument('--project', default='terradev', help='Project name')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # List instances command
    list_parser = subparsers.add_parser('list', help='List GPU instances')
    list_parser.add_argument('--state', help='Filter by instance state')
    
    # Metrics command
    metrics_parser = subparsers.add_parser('metrics', help='Get GPU metrics')
    metrics_parser.add_argument('instance_id', help='Instance ID')
    metrics_parser.add_argument('--hours', type=int, default=1, help='Hours of data to fetch')
    
    # Instance types command
    types_parser = subparsers.add_parser('types', help='List available GPU instance types')
    
    # Start/stop commands
    start_parser = subparsers.add_parser('start', help='Start an instance')
    start_parser.add_argument('instance_id', help='Instance ID')
    
    stop_parser = subparsers.add_parser('stop', help='Stop an instance')
    stop_parser.add_argument('instance_id', help='Instance ID')
    
    # Cost estimation
    cost_parser = subparsers.add_parser('cost', help='Estimate costs')
    cost_parser.add_argument('instance_type', help='Instance type')
    cost_parser.add_argument('--hours', type=int, default=1, help='Number of hours')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    client = GPUQueryClient(region=args.region, profile=args.profile)
    
    if args.command == 'list':
        instances = client.get_gpu_instances(args.project)
        if args.state:
            instances = [i for i in instances if i['state'] == args.state]
        
        logging.info(f"\nGPU Instances for project '{args.project}':")
        logging.info("-" * 80)
        for instance in instances:
            logging.info(f"ID: {instance['id']}")
            logging.info(f"Name: {instance['name']}")
            logging.info(f"Type: {instance['type']}")
            logging.info(f"State: {instance['state']}")
            logging.info(f"Public IP: {instance['public_ip']}")
            logging.info(f"Private IP: {instance['private_ip']}")
            logging.info(f"AZ: {instance['availability_zone']}")
            logging.info(f"Launched: {instance['launch_time']}")
            logging.info("-" * 40)
    
    elif args.command == 'metrics':
        metrics = client.get_gpu_metrics(args.instance_id, args.hours)
        logging.info(f"\nGPU Metrics for {args.instance_id}:")
        logging.info("-" * 50)
        if 'error' in metrics:
            logging.info(f"Error: {metrics['error']}")
        else:
            logging.info(f"Average Utilization: {metrics['average_utilization']:.2f}%")
            logging.info(f"Max Utilization: {metrics['max_utilization']:.2f}%")
            logging.info(f"Min Utilization: {metrics['min_utilization']:.2f}%")
            logging.info(f"Timestamp: {metrics['timestamp']}")
            logging.info(f"Data Points: {metrics['datapoints_count']}")
    
    elif args.command == 'types':
        types = client.get_instance_types()
        logging.info(f"\nAvailable GPU Instance Types in {args.region}:")
        logging.info("-" * 80)
        for instance_type in types:
            logging.info(f"Type: {instance_type['type']}")
            logging.info(f"vCPUs: {instance_type['vcpus']}")
            logging.info(f"Memory: {instance_type['memory']} MiB")
            if instance_type['gpu']:
                logging.info(f"GPU Count: {instance_type['gpu']['count']}")
                logging.info(f"GPU Memory: {instance_type['gpu']['memory']} MiB")
            logging.info("-" * 40)
    
    elif args.command == 'start':
        success = client.start_instance(args.instance_id)
        if success:
            logging.info(f"Instance {args.instance_id} is starting...")
        else:
            logging.info(f"Failed to start instance {args.instance_id}")
    
    elif args.command == 'stop':
        success = client.stop_instance(args.instance_id)
        if success:
            logging.info(f"Instance {args.instance_id} is stopping...")
        else:
            logging.info(f"Failed to stop instance {args.instance_id}")
    
    elif args.command == 'cost':
        cost = client.estimate_cost(args.instance_type, args.hours)
        logging.info(f"\nCost Estimation:")
        logging.info("-" * 30)
        logging.info(f"Instance Type: {cost['instance_type']}")
        logging.info(f"Duration: {cost['hours']} hours")
        logging.info(f"Estimated Cost: {cost['estimated_cost']}")
        logging.info(f"Note: {cost['note']}")

if __name__ == '__main__':
    main()
