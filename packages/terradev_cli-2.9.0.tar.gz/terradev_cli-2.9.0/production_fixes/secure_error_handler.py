#!/usr/bin/env python3
"""
Production-Grade Error Handler
Fixes poor error handling with proper exception types, logging, and user responses
"""

import logging
import traceback
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional, Union, List
from fastapi import HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import json
from enum import Enum

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ErrorSeverity(Enum):
    """Error severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class TerradevException(Exception):
    """Base exception for Terradev application"""
    
    def __init__(self, message: str, severity: ErrorSeverity = ErrorSeverity.MEDIUM, 
                 error_code: str = None, context: Dict[str, Any] = None):
        super().__init__(message)
        self.message = message
        self.severity = severity
        self.error_code = error_code or self.__class__.__name__
        self.context = context or {}
        self.timestamp = datetime.now()

class AuthenticationError(TerradevException):
    """Authentication failed"""
    
    def __init__(self, message: str = "Authentication failed", context: Dict[str, Any] = None):
        super().__init__(message, ErrorSeverity.HIGH, "AUTH_ERROR", context)

class ConfigurationError(TerradevException):
    """Configuration error"""
    
    def __init__(self, message: str = "Configuration error", context: Dict[str, Any] = None):
        super().__init__(message, ErrorSeverity.CRITICAL, "CONFIG_ERROR", context)

class ValidationError(TerradevException):
    """Input validation error"""
    
    def __init__(self, message: str = "Validation failed", context: Dict[str, Any] = None):
        super().__init__(message, ErrorSeverity.MEDIUM, "VALIDATION_ERROR", context)

class ExternalServiceError(TerradevException):
    """External service error"""
    
    def __init__(self, service: str, message: str = "External service error", context: Dict[str, Any] = None):
        context = context or {}
        context["service"] = service
        super().__init__(message, ErrorSeverity.HIGH, "EXTERNAL_ERROR", context)

class ResourceNotFoundError(TerradevException):
    """Resource not found error"""
    
    def __init__(self, resource: str, identifier: str = None, context: Dict[str, Any] = None):
        message = f"{resource} not found"
        if identifier:
            message += f": {identifier}"
        context = context or {}
        context["resource"] = resource
        context["identifier"] = identifier
        super().__init__(message, ErrorSeverity.LOW, "NOT_FOUND", context)

class RateLimitError(TerradevException):
    """Rate limit exceeded error"""
    
    def __init__(self, message: str = "Rate limit exceeded", context: Dict[str, Any] = None):
        super().__init__(message, ErrorSeverity.MEDIUM, "RATE_LIMIT", context)

class DatabaseError(TerradevException):
    """Database operation error"""
    
    def __init__(self, operation: str, message: str = "Database error", context: Dict[str, Any] = None):
        context = context or {}
        context["operation"] = operation
        super().__init__(message, ErrorSeverity.HIGH, "DATABASE_ERROR", context)

class ErrorResponse(BaseModel):
    """Standardized error response model"""
    error_code: str
    message: str
    severity: str
    timestamp: str
    request_id: Optional[str] = None
    context: Optional[Dict[str, Any]] = None

class SecureErrorHandler:
    """Production-grade error handler with proper logging and responses"""
    
    def __init__(self, log_errors: bool = True, include_traceback: bool = False):
        self.log_errors = log_errors
        self.include_traceback = include_traceback
        self.error_stats = {
            "total_errors": 0,
            "errors_by_type": {},
            "errors_by_severity": {},
            "recent_errors": []
        }
    
    def handle_exception(self, request: Request, exception: Exception) -> JSONResponse:
        """Handle exception with proper logging and response"""
        error_id = self._generate_error_id()
        
        # Log the error
        if self.log_errors:
            self._log_error(request, exception, error_id)
        
        # Update error statistics
        self._update_error_stats(exception)
        
        # Create appropriate response
        response = self._create_error_response(exception, error_id)
        
        return response
    
    def _generate_error_id(self) -> str:
        """Generate unique error ID"""
        import uuid
        return str(uuid.uuid4())[:8]
    
    def _log_error(self, request: Request, exception: Exception, error_id: str):
        """Log error with structured information"""
        try:
            error_info = {
                "error_id": error_id,
                "timestamp": datetime.now().isoformat(),
                "exception_type": type(exception).__name__,
                "message": str(exception),
                "request_method": request.method,
                "request_url": str(request.url),
                "client_ip": request.client.host if request.client else "unknown",
                "user_agent": request.headers.get("user-agent", "unknown")
            }
            
            # Add context if TerradevException
            if isinstance(exception, TerradevException):
                error_info.update({
                    "error_code": exception.error_code,
                    "severity": exception.severity.value,
                    "context": exception.context
                })
            
            # Add traceback if enabled
            if self.include_traceback:
                error_info["traceback"] = traceback.format_exc()
            
            # Log based on severity
            if isinstance(exception, TerradevException):
                if exception.severity == ErrorSeverity.CRITICAL:
                    logger.critical(f"CRITICAL ERROR [{error_id}]: {json.dumps(error_info)}")
                elif exception.severity == ErrorSeverity.HIGH:
                    logger.error(f"HIGH ERROR [{error_id}]: {json.dumps(error_info)}")
                elif exception.severity == ErrorSeverity.MEDIUM:
                    logger.warning(f"MEDIUM ERROR [{error_id}]: {json.dumps(error_info)}")
                else:
                    logger.info(f"LOW ERROR [{error_id}]: {json.dumps(error_info)}")
            else:
                logger.error(f"UNHANDLED ERROR [{error_id}]: {json.dumps(error_info)}")
                
        except Exception as log_error:
            # Fallback logging if structured logging fails
            logger.error(f"Failed to log error: {log_error}")
            logger.error(f"Original error: {exception}")
    
    def _update_error_stats(self, exception: Exception):
        """Update error statistics"""
        self.error_stats["total_errors"] += 1
        
        error_type = type(exception).__name__
        self.error_stats["errors_by_type"][error_type] = self.error_stats["errors_by_type"].get(error_type, 0) + 1
        
        if isinstance(exception, TerradevException):
            severity = exception.severity.value
        else:
            severity = "unknown"
        
        self.error_stats["errors_by_severity"][severity] = self.error_stats["errors_by_severity"].get(severity, 0) + 1
        
        # Keep recent errors (last 100)
        recent_error = {
            "timestamp": datetime.now().isoformat(),
            "type": error_type,
            "message": str(exception)[:200]  # Truncate long messages
        }
        
        self.error_stats["recent_errors"].append(recent_error)
        if len(self.error_stats["recent_errors"]) > 100:
            self.error_stats["recent_errors"] = self.error_stats["recent_errors"][-100:]
    
    def _create_error_response(self, exception: Exception, error_id: str) -> JSONResponse:
        """Create appropriate error response based on exception type"""
        if isinstance(exception, TerradevException):
            # Handle custom Terradev exceptions
            status_code = self._get_status_code(exception)
            error_response = ErrorResponse(
                error_code=exception.error_code,
                message=self._sanitize_message(exception.message),
                severity=exception.severity.value,
                timestamp=exception.timestamp.isoformat(),
                request_id=error_id,
                context=exception.context if exception.context else None
            )
        else:
            # Handle unexpected exceptions
            status_code = 500
            error_response = ErrorResponse(
                error_code="INTERNAL_ERROR",
                message="An unexpected error occurred",
                severity="high",
                timestamp=datetime.now().isoformat(),
                request_id=error_id,
                context=None
            )
        
        return JSONResponse(
            status_code=status_code,
            content=error_response.dict(exclude_none=True)
        )
    
    def _get_status_code(self, exception: TerradevException) -> int:
        """Get appropriate HTTP status code for exception"""
        status_codes = {
            AuthenticationError: 401,
            ValidationError: 400,
            ResourceNotFoundError: 404,
            RateLimitError: 429,
            ConfigurationError: 500,
            ExternalServiceError: 502,
            DatabaseError: 500,
        }
        
        return status_codes.get(type(exception), 500)
    
    def _sanitize_message(self, message: str) -> str:
        """Sanitize error message for user consumption"""
        # Remove sensitive information
        sensitive_patterns = [
            "password", "token", "key", "secret", "credential",
            "authorization", "auth", "bearer"
        ]
        
        message_lower = message.lower()
        for pattern in sensitive_patterns:
            if pattern in message_lower:
                return "Authentication or configuration error occurred"
        
        # Remove file paths and internal details
        if "/" in message or "\\" in message:
            return "An internal error occurred"
        
        return message
    
    def get_error_stats(self) -> Dict[str, Any]:
        """Get error statistics"""
        return self.error_stats.copy()
    
    def reset_error_stats(self):
        """Reset error statistics"""
        self.error_stats = {
            "total_errors": 0,
            "errors_by_type": {},
            "errors_by_severity": {},
            "recent_errors": []
        }

# Decorator for automatic error handling
def handle_errors(operation_name: str = None):
    """Decorator for automatic error handling"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except TerradevException:
                # Re-raise custom exceptions (they'll be handled by middleware)
                raise
            except Exception as e:
                # Convert unexpected exceptions to TerradevException
                op_name = operation_name or func.__name__
                raise ExternalServiceError(
                    service="internal",
                    message=f"Error in {op_name}: {str(e)}",
                    context={"function": func.__name__, "args": str(args)[:100]}
                )
        return wrapper
    return decorator

# Retry decorator for external service calls
def retry_on_failure(max_attempts: int = 3, base_delay: float = 1.0, backoff_factor: float = 2.0):
    """Decorator for retrying failed operations"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except (ExternalServiceError, DatabaseError) as e:
                    last_exception = e
                    if attempt < max_attempts - 1:
                        delay = base_delay * (backoff_factor ** attempt)
                        logger.warning(f"Retrying {func.__name__} in {delay}s (attempt {attempt + 1}/{max_attempts})")
                        await asyncio.sleep(delay)
                    else:
                        logger.error(f"Max retries exceeded for {func.__name__}")
                        raise
                except TerradevException:
                    # Don't retry authentication or validation errors
                    raise
                except Exception as e:
                    # Convert unexpected errors
                    raise ExternalServiceError(
                        service="internal",
                        message=f"Unexpected error in {func.__name__}: {str(e)}",
                        context={"attempt": attempt + 1, "max_attempts": max_attempts}
                    )
            
            raise last_exception
        return wrapper
    return decorator

# Global error handler instance
secure_error_handler = SecureErrorHandler()

# Example usage functions
@handle_errors("user_authentication")
@retry_on_failure(max_attempts=3)
async def authenticate_user(username: str, password: str) -> Dict[str, Any]:
    """Example function with error handling and retry"""
    # This would contain actual authentication logic
    if not username or not password:
        raise ValidationError("Username and password are required")
    
    # Simulate external service call
    await asyncio.sleep(0.1)
    
    # Simulate success
    return {"user_id": "123", "username": username, "authenticated": True}

@handle_errors("database_query")
@retry_on_failure(max_attempts=2)
async def execute_database_query(query: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Example database function with error handling"""
    if not query.strip():
        raise ValidationError("Query cannot be empty")
    
    # Simulate database operation
    await asyncio.sleep(0.05)
    
    # Simulate success
    return [{"id": 1, "data": "sample"}]

if __name__ == "__main__":
    # Test the error handler
    print("🧪 Testing Secure Error Handler...")
    
    async def test_error_handling():
        try:
            # Test authentication error
            await authenticate_user("", "")
        except Exception as e:
            print(f"✅ Authentication error handled: {type(e).__name__}")
        
        try:
            # Test database error
            await execute_database_query("", {})
        except Exception as e:
            print(f"✅ Database error handled: {type(e).__name__}")
        
        # Show error stats
        stats = secure_error_handler.get_error_stats()
        print(f"📊 Error stats: {stats}")
    
    asyncio.run(test_error_handling())
    print("✅ Secure Error Handler working correctly!")
