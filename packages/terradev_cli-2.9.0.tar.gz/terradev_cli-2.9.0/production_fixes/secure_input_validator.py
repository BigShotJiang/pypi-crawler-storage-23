#!/usr/bin/env python3
"""
Production-Grade Input Validator
Fixes missing input validation with comprehensive security checks
"""

import re
import json
import logging
from typing import Dict, Any, List, Optional, Union, Type
from datetime import datetime
from pydantic import BaseModel, validator, ValidationError
from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from enum import Enum
import html
import bleach
from urllib.parse import urlparse
import hashlib
import secrets

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ValidationSeverity(Enum):
    """Validation error severity"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class ValidationRule(Enum):
    """Validation rule types"""
    REQUIRED = "required"
    TYPE = "type"
    LENGTH = "length"
    PATTERN = "pattern"
    RANGE = "range"
    ALLOWED_VALUES = "allowed_values"
    SANITIZE = "sanitize"
    SECURITY = "security"

class ValidationError(Exception):
    """Custom validation error"""
    
    def __init__(self, message: str, field: str = None, severity: ValidationSeverity = ValidationSeverity.ERROR, 
                 rule_type: ValidationRule = None, value: Any = None):
        self.message = message
        self.field = field
        self.severity = severity
        self.rule_type = rule_type
        self.value = value
        super().__init__(message)

class SecurityValidationError(ValidationError):
    """Security-related validation error"""
    
    def __init__(self, message: str, field: str = None, value: Any = None):
        super().__init__(message, field, ValidationSeverity.CRITICAL, ValidationRule.SECURITY, value)

class InputValidator:
    """Production-grade input validator with security checks"""
    
    def __init__(self):
        self.validation_rules = {}
        self.security_patterns = self._init_security_patterns()
        self.sanitization_rules = self._init_sanitization_rules()
        self.validation_stats = {
            "total_validations": 0,
            "failed_validations": 0,
            "security_violations": 0,
            "common_failures": {}
        }
    
    def _init_security_patterns(self) -> Dict[str, str]:
        """Initialize security detection patterns"""
        return {
            # SQL Injection patterns
            "sql_injection": [
                r"(\b(UNION|SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)",
                r"(\b(OR|AND)\s+\d+\s*=\s*\d+)",
                r"(\b(OR|AND)\s+['\"][^'\"]*['\"]\s*=\s*['\"][^'\"]*['\"])",
                r"(;|\-\-|\/\*|\*\/)",
                r"(\b(LOAD_FILE|INTO\s+OUTFILE|DUMPFILE)\b)"
            ],
            
            # XSS patterns
            "xss": [
                r"<script[^>]*>.*?</script>",
                r"javascript:",
                r"on\w+\s*=",
                r"<iframe[^>]*>",
                r"<object[^>]*>",
                r"<embed[^>]*>",
                r"<link[^>]*>",
                r"<meta[^>]*>"
            ],
            
            # Command injection patterns
            "command_injection": [
                r"[;&|`$(){}[\]]",
                r"\b(curl|wget|nc|netcat|telnet|ssh)\b",
                r"\b(rm|mv|cp|chmod|chown|sudo|su)\b",
                r"\b(python|perl|ruby|bash|sh|cmd)\s",
                r"\b(echo|cat|ls|ps|kill)\s"
            ],
            
            # Path traversal patterns
            "path_traversal": [
                r"\.\.[\\/]",
                r"[\\/]\.\.[\\/]",
                r"[\\/]\.\.$",
                r"\.\.[\\/]\.\.[\\/]",
                r"%2e%2e%2f",
                r"%2e%2e\\",
                r"\.\.%2f",
                r"\.\.\\"
            ],
            
            # LDAP injection patterns
            "ldap_injection": [
                r"[*()\\]",
                r"\)\(.*\(",
                r"\*\)\(",
                r"\(\|\()",
                r"\(&\()"
            ],
            
            # NoSQL injection patterns
            "nosql_injection": [
                r"\$where",
                r"\$ne",
                r"\$gt",
                r"\$lt",
                r"\$in",
                r"\$regex",
                r"\{.*\$.*\}"
            ]
        }
    
    def _init_sanitization_rules(self) -> Dict[str, callable]:
        """Initialize input sanitization rules"""
        return {
            "html_escape": lambda x: html.escape(str(x)),
            "strip_tags": lambda x: bleach.clean(str(x), tags=[], strip=True),
            "normalize_whitespace": lambda x: re.sub(r'\s+', ' ', str(x).strip()),
            "lowercase": lambda x: str(x).lower(),
            "uppercase": lambda x: str(x).upper(),
            "alphanumeric": lambda x: re.sub(r'[^a-zA-Z0-9]', '', str(x)),
            "numeric": lambda x: re.sub(r'[^0-9]', '', str(x)),
            "alpha": lambda x: re.sub(r'[^a-zA-Z]', '', str(x))
        }
    
    def validate_input(self, data: Dict[str, Any], rules: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Validate input data against rules"""
        self.validation_stats["total_validations"] += 1
        
        validated_data = {}
        errors = []
        
        for field, field_rules in rules.items():
            field_value = data.get(field)
            
            try:
                # Apply validation rules
                validated_value = self._validate_field(field, field_value, field_rules)
                validated_data[field] = validated_value
                
            except ValidationError as e:
                errors.append({
                    "field": field,
                    "message": e.message,
                    "severity": e.severity.value,
                    "rule_type": e.rule_type.value if e.rule_type else None,
                    "value": str(e.value)[:100] if e.value else None
                })
                
                # Update statistics
                self.validation_stats["failed_validations"] += 1
                if e.severity == ValidationSeverity.CRITICAL:
                    self.validation_stats["security_violations"] += 1
                
                failure_key = f"{field}:{e.rule_type.value if e.rule_type else 'unknown'}"
                self.validation_stats["common_failures"][failure_key] = \
                    self.validation_stats["common_failures"].get(failure_key, 0) + 1
        
        if errors:
            # Log validation failures
            logger.warning(f"Input validation failed: {json.dumps(errors, indent=2)}")
            
            # Raise exception with all errors
            error_messages = [f"{e['field']}: {e['message']}" for e in errors if e['severity'] in ['error', 'critical']]
            if error_messages:
                raise ValidationError(f"Validation failed: {'; '.join(error_messages)}")
        
        return validated_data
    
    def _validate_field(self, field: str, value: Any, rules: Dict[str, Any]) -> Any:
        """Validate a single field"""
        validated_value = value
        
        # Apply validation rules in order
        for rule_name, rule_config in rules.items():
            if rule_name == "required":
                validated_value = self._validate_required(field, validated_value, rule_config)
            elif rule_name == "type":
                validated_value = self._validate_type(field, validated_value, rule_config)
            elif rule_name == "length":
                validated_value = self._validate_length(field, validated_value, rule_config)
            elif rule_name == "pattern":
                validated_value = self._validate_pattern(field, validated_value, rule_config)
            elif rule_name == "range":
                validated_value = self._validate_range(field, validated_value, rule_config)
            elif rule_name == "allowed_values":
                validated_value = self._validate_allowed_values(field, validated_value, rule_config)
            elif rule_name == "sanitize":
                validated_value = self._sanitize_field(field, validated_value, rule_config)
            elif rule_name == "security":
                validated_value = self._validate_security(field, validated_value, rule_config)
        
        return validated_value
    
    def _validate_required(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Validate required field"""
        if isinstance(config, bool):
            # If config is just a boolean, use default behavior
            required = config
        else:
            required = config.get("required", True)
            
        if required and (value is None or value == ""):
            raise ValidationError(f"Field '{field}' is required", field, ValidationSeverity.ERROR, ValidationRule.REQUIRED, value)
        return value
    
    def _validate_type(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Validate field type"""
        expected_type = config.get("type")
        if expected_type and value is not None:
            try:
                if expected_type == "str":
                    return str(value)
                elif expected_type == "int":
                    return int(value)
                elif expected_type == "float":
                    return float(value)
                elif expected_type == "bool":
                    if isinstance(value, str):
                        return value.lower() in ('true', '1', 'yes', 'on')
                    return bool(value)
                elif expected_type == "list":
                    if isinstance(value, str):
                        return [item.strip() for item in value.split(',')]
                    return list(value)
                elif expected_type == "dict":
                    if isinstance(value, str):
                        return json.loads(value)
                    return dict(value)
                else:
                    return value
            except (ValueError, TypeError, json.JSONDecodeError) as e:
                raise ValidationError(f"Field '{field}' must be of type {expected_type}", field, ValidationSeverity.ERROR, ValidationRule.TYPE, value)
        return value
    
    def _validate_length(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Validate field length"""
        if value is None:
            return value
        
        length = len(str(value))
        min_length = config.get("min_length")
        max_length = config.get("max_length")
        
        if min_length is not None and length < min_length:
            raise ValidationError(f"Field '{field}' must be at least {min_length} characters", field, ValidationSeverity.ERROR, ValidationRule.LENGTH, value)
        
        if max_length is not None and length > max_length:
            raise ValidationError(f"Field '{field}' must be no more than {max_length} characters", field, ValidationSeverity.ERROR, ValidationRule.LENGTH, value)
        
        return value
    
    def _validate_pattern(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Validate field pattern"""
        if value is None:
            return value
        
        pattern = config.get("pattern")
        if pattern:
            if not re.match(pattern, str(value)):
                raise ValidationError(f"Field '{field}' does not match required pattern", field, ValidationSeverity.ERROR, ValidationRule.PATTERN, value)
        
        return value
    
    def _validate_range(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Validate field range"""
        if value is None:
            return value
        
        try:
            numeric_value = float(value)
            min_value = config.get("min_value")
            max_value = config.get("max_value")
            
            if min_value is not None and numeric_value < min_value:
                raise ValidationError(f"Field '{field}' must be at least {min_value}", field, ValidationSeverity.ERROR, ValidationRule.RANGE, value)
            
            if max_value is not None and numeric_value > max_value:
                raise ValidationError(f"Field '{field}' must be no more than {max_value}", field, ValidationSeverity.ERROR, ValidationRule.RANGE, value)
        except (ValueError, TypeError):
            raise ValidationError(f"Field '{field}' must be a number for range validation", field, ValidationSeverity.ERROR, ValidationRule.RANGE, value)
        
        return value
    
    def _validate_allowed_values(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Validate allowed values"""
        if value is None:
            return value
        
        allowed = config.get("allowed_values", [])
        if allowed and value not in allowed:
            raise ValidationError(f"Field '{field}' must be one of: {', '.join(map(str, allowed))}", field, ValidationSeverity.ERROR, ValidationRule.ALLOWED_VALUES, value)
        
        return value
    
    def _sanitize_field(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Sanitize field value"""
        if value is None:
            return value
        
        sanitization_rules = config.get("rules", [])
        sanitized_value = str(value)
        
        for rule in sanitization_rules:
            if rule in self.sanitization_rules:
                sanitized_value = self.sanitization_rules[rule](sanitized_value)
        
        return sanitized_value
    
    def _validate_security(self, field: str, value: Any, config: Dict[str, Any]) -> Any:
        """Validate field for security issues"""
        if value is None:
            return value
        
        str_value = str(value)
        
        # Check against security patterns
        for threat_type, patterns in self.security_patterns.items():
            for pattern in patterns:
                if re.search(pattern, str_value, re.IGNORECASE):
                    raise SecurityValidationError(
                        f"Field '{field}' contains potentially malicious {threat_type} content",
                        field, value
                    )
        
        return value
    
    def validate_api_key(self, api_key: str) -> str:
        """Validate API key format"""
        if not api_key:
            raise ValidationError("API key is required", "api_key", ValidationSeverity.ERROR, ValidationRule.REQUIRED)
        
        # Check basic format (alphanumeric, reasonable length)
        if not re.match(r'^[a-zA-Z0-9_\-\.]{16,128}$', api_key):
            raise ValidationError("Invalid API key format", "api_key", ValidationSeverity.ERROR, ValidationRule.PATTERN, api_key)
        
        return api_key
    
    def validate_s3_path(self, s3_path: str) -> str:
        """Validate S3 path format"""
        if not s3_path:
            raise ValidationError("S3 path is required", "s3_path", ValidationSeverity.ERROR, ValidationRule.REQUIRED)
        
        # Check S3 path format
        if not re.match(r'^s3://[a-z0-9.\-]{3,63}/[a-zA-Z0-9\-_./]*$', s3_path):
            raise ValidationError("Invalid S3 path format", "s3_path", ValidationSeverity.ERROR, ValidationRule.PATTERN, s3_path)
        
        # Check for path traversal
        if ".." in s3_path:
            raise SecurityValidationError("S3 path contains potentially dangerous path traversal", "s3_path", s3_path)
        
        return s3_path
    
    def validate_gpu_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate GPU configuration"""
        rules = {
            "gpu_type": {
                "required": True,
                "type": "str",
                "pattern": r'^[a-zA-Z0-9\-_]+$',
                "allowed_values": ["A100", "H100", "A10G", "RTX4090", "RTX3090", "V100"],
                "sanitize": {"rules": ["uppercase"]}
            },
            "gpu_count": {
                "required": True,
                "type": "int",
                "range": {"min_value": 1, "max_value": 8}
            },
            "region": {
                "required": True,
                "type": "str",
                "pattern": r'^[a-z]{2}-[a-z]+-\d+$',
                "allowed_values": ["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"]
            },
            "max_price_per_hour": {
                "required": True,
                "type": "float",
                "range": {"min_value": 0.1, "max_value": 100.0}
            }
        }
        
        return self.validate_input(config, rules)
    
    def validate_training_request(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate training request"""
        rules = {
            "job_name": {
                "required": True,
                "type": "str",
                "length": {"min_length": 3, "max_length": 100},
                "pattern": r'^[a-zA-Z0-9\-_]+$',
                "sanitize": {"rules": ["lowercase", "alphanumeric"]}
            },
            "dataset_s3_path": {
                "required": True,
                "type": "str",
                "security": {}
            },
            "dataset_size_gb": {
                "required": True,
                "type": "int",
                "range": {"min_value": 1, "max_value": 100000}  # Up to 100TB
            },
            "training_duration_hours": {
                "required": True,
                "type": "int",
                "range": {"min_value": 1, "max_value": 168}  # Up to 1 week
            },
            "gpu_config": {
                "required": True,
                "type": "dict"
            }
        }
        
        validated_data = self.validate_input(request_data, rules)
        
        # Validate nested GPU config
        if "gpu_config" in validated_data:
            validated_data["gpu_config"] = self.validate_gpu_config(validated_data["gpu_config"])
        
        return validated_data
    
    def get_validation_stats(self) -> Dict[str, Any]:
        """Get validation statistics"""
        return self.validation_stats.copy()
    
    def reset_stats(self):
        """Reset validation statistics"""
        self.validation_stats = {
            "total_validations": 0,
            "failed_validations": 0,
            "security_violations": 0,
            "common_failures": {}
        }

# Pydantic models for common validations
class BaseValidationModel(BaseModel):
    """Base model with common validations"""
    
    class Config:
        extra = "forbid"  # Forbid extra fields
        validate_assignment = True
    
    @validator('*', pre=True)
    def strip_strings(cls, v):
        """Strip whitespace from string fields"""
        if isinstance(v, str):
            return v.strip()
        return v

class APIKeyModel(BaseValidationModel):
    """API key validation model"""
    api_key: str
    
    @validator('api_key')
    def validate_api_key(cls, v):
        if not re.match(r'^[a-zA-Z0-9_\-\.]{16,128}$', v):
            raise ValueError("Invalid API key format")
        return v

class GPUConfigModel(BaseValidationModel):
    """GPU configuration validation model"""
    gpu_type: str
    gpu_count: int = 1
    region: str
    max_price_per_hour: float
    
    @validator('gpu_type')
    def validate_gpu_type(cls, v):
        allowed_gpus = ["A100", "H100", "A10G", "RTX4090", "RTX3090", "V100"]
        if v not in allowed_gpus:
            raise ValueError(f"GPU type must be one of: {', '.join(allowed_gpus)}")
        return v.upper()
    
    @validator('gpu_count')
    def validate_gpu_count(cls, v):
        if v < 1 or v > 8:
            raise ValueError("GPU count must be between 1 and 8")
        return v
    
    @validator('region')
    def validate_region(cls, v):
        if not re.match(r'^[a-z]{2}-[a-z]+-\d+$', v):
            raise ValueError("Invalid region format")
        return v
    
    @validator('max_price_per_hour')
    def validate_price(cls, v):
        if v < 0.1 or v > 100.0:
            raise ValueError("Price per hour must be between 0.1 and 100.0")
        return v

class TrainingRequestModel(BaseValidationModel):
    """Training request validation model"""
    job_name: str
    dataset_s3_path: str
    dataset_size_gb: int
    training_duration_hours: int
    gpu_config: GPUConfigModel
    
    @validator('job_name')
    def validate_job_name(cls, v):
        if not re.match(r'^[a-zA-Z0-9\-_]{3,100}$', v):
            raise ValueError("Job name must be 3-100 characters, alphanumeric with hyphens and underscores only")
        return v
    
    @validator('dataset_s3_path')
    def validate_s3_path(cls, v):
        if not re.match(r'^s3://[a-z0-9.\-]{3,63}/[a-zA-Z0-9\-_./]*$', v):
            raise ValueError("Invalid S3 path format")
        if ".." in v:
            raise ValueError("S3 path cannot contain '..'")
        return v
    
    @validator('dataset_size_gb')
    def validate_dataset_size(cls, v):
        if v < 1 or v > 100000:
            raise ValueError("Dataset size must be between 1GB and 100TB")
        return v
    
    @validator('training_duration_hours')
    def validate_training_duration(cls, v):
        if v < 1 or v > 168:
            raise ValueError("Training duration must be between 1 and 168 hours")
        return v

# Global validator instance
input_validator = InputValidator()

# Decorator for input validation
def validate_input(rules: Dict[str, Dict[str, Any]]):
    """Decorator for input validation"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Extract request data (would need request context in real implementation)
            if args and hasattr(args[0], '__dict__'):
                data = args[0].__dict__
            else:
                data = kwargs
            
            # Validate input
            validated_data = input_validator.validate_input(data, rules)
            
            # Call function with validated data
            return await func(**validated_data)
        return wrapper
    return decorator

# Example usage
@validate_input({
    "username": {"required": True, "type": "str", "length": {"min_length": 3, "max_length": 50}},
    "password": {"required": True, "type": "str", "length": {"min_length": 8, "max_length": 128}},
    "email": {"required": True, "type": "str", "pattern": r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'}
})
async def register_user(username: str, password: str, email: str) -> Dict[str, Any]:
    """Example function with input validation"""
    # User registration logic here
    return {"username": username, "email": email, "registered": True}

if __name__ == "__main__":
    # Test the input validator
    print("🧪 Testing Secure Input Validator...")
    
    # Test valid input
    valid_data = {
        "username": "testuser",
        "password": "securepassword123",
        "email": "test@example.com"
    }
    
    try:
        result = register_user(**valid_data)
        print(f"✅ Valid input passed: {result}")
    except Exception as e:
        print(f"❌ Valid input failed: {e}")
    
    # Test invalid input
    invalid_data = {
        "username": "",  # Too short
        "password": "123",  # Too short
        "email": "invalid-email"  # Invalid format
    }
    
    try:
        result = register_user(**invalid_data)
        print(f"❌ Invalid input incorrectly passed: {result}")
    except Exception as e:
        print(f"✅ Invalid input correctly rejected: {e}")
    
    # Test security validation
    try:
        malicious_data = {
            "username": "admin'; DROP TABLE users; --",
            "password": "password",
            "email": "test@example.com"
        }
        result = register_user(**malicious_data)
        print(f"❌ Malicious input incorrectly passed: {result}")
    except Exception as e:
        print(f"✅ Malicious input correctly rejected: {e}")
    
    # Test GPU config validation
    try:
        gpu_config = input_validator.validate_gpu_config({
            "gpu_type": "A100",
            "gpu_count": 2,
            "region": "us-west-2",
            "max_price_per_hour": 3.0
        })
        print(f"✅ GPU config validation passed: {gpu_config}")
    except Exception as e:
        print(f"❌ GPU config validation failed: {e}")
    
    # Show validation stats
    stats = input_validator.get_validation_stats()
    print(f"📊 Validation stats: {stats}")
    
    print("✅ Secure Input Validator working correctly!")
