#!/usr/bin/env python3
"""
Test Individual Free Mitigation Components
Test each component separately to verify functionality
"""

import sys
import os
import asyncio
import time
from pathlib import Path

# Add current directory to path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

def test_cache_manager():
    """Test the cache manager"""
    print("🧪 Testing Cache Manager...")
    
    try:
        from free_cache_manager import FreeCacheManager
        
        cache = FreeCacheManager("test_cache.db")
        
        # Test caching
        test_data = {"gpu_type": "A100", "price": 4.06, "provider": "aws"}
        cache.cache_result("aws", "pricing", {"gpu_type": "A100"}, test_data)
        
        # Test retrieval
        cached = cache.get_cached_result("aws", "pricing", {"gpu_type": "A100"})
        
        if cached and cached["price"] == 4.06:
            print("✅ Cache Manager working correctly")
            return True
        else:
            print("❌ Cache Manager test failed")
            return False
            
    except Exception as e:
        print(f"❌ Cache Manager error: {e}")
        return False

def test_memory_cache():
    """Test the memory cache"""
    print("🧪 Testing Memory Cache...")
    
    try:
        from free_memory_cache import FreeMemoryCache
        
        cache = FreeMemoryCache(max_size=10, ttl_seconds=5)
        
        # Test set/get
        cache.set("test_key", "test_value")
        result = cache.get("test_key")
        
        if result == "test_value":
            print("✅ Memory Cache working correctly")
            return True
        else:
            print("❌ Memory Cache test failed")
            return False
            
    except Exception as e:
        print(f"❌ Memory Cache error: {e}")
        return False

def test_database_manager():
    """Test the database manager"""
    print("🧪 Testing Database Manager...")
    
    try:
        from free_database_manager import FreeDatabaseManager, GPUGricingRecord
        from datetime import datetime
        
        db = FreeDatabaseManager("test_database.db")
        
        # Test GPU pricing
        gpu_data = GPUGricingRecord(
            provider="aws",
            gpu_type="A100",
            region="us-west-2",
            spot_price=4.06,
            on_demand_price=4.86,
            timestamp=datetime.now().isoformat()
        )
        
        db.cache_gpu_pricing("aws", [gpu_data])
        
        # Test retrieval
        pricing = db.get_cached_pricing("aws", "A100")
        
        if pricing and len(pricing) > 0 and pricing[0].spot_price == 4.06:
            print("✅ Database Manager working correctly")
            return True
        else:
            print("❌ Database Manager test failed")
            return False
            
    except Exception as e:
        print(f"❌ Database Manager error: {e}")
        return False

async def test_batch_manager():
    """Test the batch manager"""
    print("🧪 Testing Batch Manager...")
    
    try:
        from free_batch_manager import FreeBatchManager
        
        batch = FreeBatchManager(max_batch_size=5, batch_timeout=10)
        await batch.start()
        
        # Add some requests
        tasks = []
        for i in range(3):
            task = batch.add_request("aws", "pricing", {"gpu_type": f"A100", "request_id": i})
            tasks.append(task)
        
        # Wait for results
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Check if we got results (even mock ones)
        success_count = sum(1 for r in results if not isinstance(r, Exception))
        
        await batch.stop()
        
        if success_count >= 2:  # Allow for some test failures
            print("✅ Batch Manager working correctly")
            return True
        else:
            print("❌ Batch Manager test failed")
            return False
            
    except Exception as e:
        print(f"❌ Batch Manager error: {e}")
        return False

async def test_rate_limit_manager():
    """Test the rate limit manager"""
    print("🧪 Testing Rate Limit Manager...")
    
    try:
        from free_rate_limit_manager import FreeRateLimitManager
        
        manager = FreeRateLimitManager()
        
        # Mock API call
        async def mock_api_call():
            await asyncio.sleep(0.1)
            return {"result": "success"}
        
        # Test rate-limited request
        result = await manager.make_request("aws", mock_api_call)
        
        if result and result.get("result") == "success":
            print("✅ Rate Limit Manager working correctly")
            return True
        else:
            print("❌ Rate Limit Manager test failed")
            return False
            
    except Exception as e:
        print(f"❌ Rate Limit Manager error: {e}")
        return False

async def test_task_scheduler():
    """Test the task scheduler"""
    print("🧪 Testing Task Scheduler...")
    
    try:
        from free_task_scheduler import FreeTaskScheduler, TaskPriority
        
        scheduler = FreeTaskScheduler()
        await scheduler.start()
        
        # Mock task
        test_results = []
        
        async def mock_task():
            test_results.append("task_executed")
        
        # Schedule task
        scheduler.schedule_task("test_task", mock_task, interval_seconds=1, priority=TaskPriority.HIGH)
        
        # Wait for execution
        await asyncio.sleep(2)
        
        await scheduler.stop()
        
        if len(test_results) > 0:
            print("✅ Task Scheduler working correctly")
            return True
        else:
            print("❌ Task Scheduler test failed")
            return False
            
    except Exception as e:
        print(f"❌ Task Scheduler error: {e}")
        return False

async def main():
    """Run all tests"""
    print("🆓 Free Mitigation Suite - Component Tests")
    print("=" * 50)
    
    tests = [
        ("Cache Manager", test_cache_manager),
        ("Memory Cache", test_memory_cache),
        ("Database Manager", test_database_manager),
        ("Batch Manager", test_batch_manager),
        ("Rate Limit Manager", test_rate_limit_manager),
        ("Task Scheduler", test_task_scheduler)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        try:
            if asyncio.iscoroutinefunction(test_func):
                result = await test_func()
            else:
                result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    print("=" * 50)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:<20} {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{total} tests passed ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("🎉 All components working perfectly!")
        print("\n🚀 Ready to use the Free Mitigation Suite!")
        print("\nNext steps:")
        print("1. Import components in your main application")
        print("2. Replace direct API calls with optimized requests")
        print("3. Monitor cache hit rates and performance")
        print("4. Adjust settings based on your usage patterns")
    else:
        print("⚠️  Some components need attention")
        print("Check the error messages above for details")
    
    # Cleanup test files
    try:
        import os
        test_files = ["test_cache.db", "test_database.db"]
        for file in test_files:
            if os.path.exists(file):
                os.remove(file)
    except:
        pass

if __name__ == "__main__":
    asyncio.run(main())
