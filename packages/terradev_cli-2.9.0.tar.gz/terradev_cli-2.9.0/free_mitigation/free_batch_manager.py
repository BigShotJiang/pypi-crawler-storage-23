#!/usr/bin/env python3
"""
Free Batch Manager - Smart Request Batching for 95% API Call Reduction
Combine 50 individual requests into 1 batch API call
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from collections import defaultdict
import hashlib

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class BatchRequest:
    """Individual request within a batch"""
    request_id: str
    params: dict
    timestamp: datetime
    future: asyncio.Future
    
@dataclass
class BatchResult:
    """Result of a batch operation"""
    batch_id: str
    results: List[dict]
    errors: List[dict]
    processing_time: float
    request_count: int

class FreeBatchManager:
    """Free batch request manager for 95% API call reduction"""
    
    def __init__(self, max_batch_size: int = 50, batch_timeout: int = 60):
        self.max_batch_size = max_batch_size
        self.batch_timeout = batch_timeout
        self.pending_requests: Dict[str, List[BatchRequest]] = defaultdict(list)
        self.batch_stats = {
            "total_requests": 0,
            "total_batches": 0,
            "avg_batch_size": 0,
            "api_calls_saved": 0
        }
        self.running = False
        self.batch_processor_task = None
        
    async def start(self):
        """Start the batch processor"""
        if not self.running:
            self.running = True
            self.batch_processor_task = asyncio.create_task(self._batch_processor_loop())
            logger.info("Batch manager started")
    
    async def stop(self):
        """Stop the batch processor"""
        self.running = False
        if self.batch_processor_task:
            self.batch_processor_task.cancel()
            try:
                await self.batch_processor_task
            except asyncio.CancelledError:
                pass
        logger.info("Batch manager stopped")
    
    async def add_request(self, provider: str, request_type: str, params: dict) -> Any:
        """Add request to batch queue and return result"""
        if not self.running:
            await self.start()
        
        # Generate unique request ID
        request_id = self._generate_request_id(provider, request_type, params)
        
        # Create future for result
        future = asyncio.Future()
        
        # Create batch request
        batch_request = BatchRequest(
            request_id=request_id,
            params=params,
            timestamp=datetime.now(),
            future=future
        )
        
        # Add to appropriate batch queue
        batch_key = f"{provider}:{request_type}"
        self.pending_requests[batch_key].append(batch_request)
        self.batch_stats["total_requests"] += 1
        
        logger.debug(f"Added request {request_id} to batch {batch_key}")
        
        # Process batch immediately if full
        if len(self.pending_requests[batch_key]) >= self.max_batch_size:
            await self._process_batch(batch_key)
        
        # Wait for result
        try:
            result = await future
            return result
        except Exception as e:
            logger.error(f"Request {request_id} failed: {e}")
            raise e
    
    async def _batch_processor_loop(self):
        """Main batch processor loop"""
        while self.running:
            try:
                # Check all batch queues for timeout
                current_time = datetime.now()
                
                for batch_key, requests in list(self.pending_requests.items()):
                    if requests:
                        oldest_request = min(requests, key=lambda r: r.timestamp)
                        if (current_time - oldest_request.timestamp).total_seconds() >= self.batch_timeout:
                            await self._process_batch(batch_key)
                
                # Sleep before next check
                await asyncio.sleep(1)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Batch processor error: {e}")
                await asyncio.sleep(5)
    
    async def _process_batch(self, batch_key: str):
        """Process a batch of requests"""
        if batch_key not in self.pending_requests or not self.pending_requests[batch_key]:
            return
        
        requests = self.pending_requests.pop(batch_key, [])
        if not requests:
            return
        
        start_time = time.time()
        batch_id = self._generate_batch_id(batch_key)
        
        logger.info(f"Processing batch {batch_id} with {len(requests)} requests")
        
        try:
            # Combine parameters for batch API call
            combined_params = self._combine_batch_params(requests)
            
            # Make batch API call
            batch_result = await self._make_batch_api_call(batch_key, combined_params)
            
            # Distribute results to individual requests
            await self._distribute_batch_results(requests, batch_result)
            
            # Update statistics
            processing_time = time.time() - start_time
            self._update_batch_stats(len(requests), processing_time)
            
            logger.info(f"Batch {batch_id} completed in {processing_time:.2f}s")
            
        except Exception as e:
            logger.error(f"Batch {batch_key} failed: {e}")
            # Handle batch failure
            await self._handle_batch_failure(requests, e)
    
    def _combine_batch_params(self, requests: List[BatchRequest]) -> dict:
        """Combine individual request parameters for batch API call"""
        # Extract unique parameters
        gpu_types = set()
        regions = set()
        instance_types = set()
        
        for request in requests:
            params = request.params
            if "gpu_type" in params:
                gpu_types.add(params["gpu_type"])
            if "region" in params:
                regions.add(params["region"])
            if "instance_type" in params:
                instance_types.add(params["instance_type"])
        
        combined_params = {
            "batch_size": len(requests),
            "request_ids": [req.request_id for req in requests],
        }
        
        if gpu_types:
            combined_params["gpu_types"] = list(gpu_types)
        if regions:
            combined_params["regions"] = list(regions)
        if instance_types:
            combined_params["instance_types"] = list(instance_types)
        
        return combined_params
    
    async def _make_batch_api_call(self, batch_key: str, combined_params: dict) -> dict:
        """Make the actual batch API call"""
        provider, request_type = batch_key.split(":")
        
        # Simulate batch API call (replace with actual implementation)
        logger.debug(f"Making batch API call to {provider}:{request_type}")
        
        # This would be replaced with actual provider-specific batch API calls
        await asyncio.sleep(0.5)  # Simulate API latency
        
        # Mock batch response
        batch_response = {
            "batch_id": self._generate_batch_id(batch_key),
            "results": [],
            "success": True
        }
        
        # Generate individual results based on combined params
        for request_id in combined_params.get("request_ids", []):
            result = {
                "request_id": request_id,
                "data": {
                    "gpu_type": "A100",
                    "price": 4.06,
                    "availability": True,
                    "region": "us-west-2"
                },
                "success": True
            }
            batch_response["results"].append(result)
        
        return batch_response
    
    async def _distribute_batch_results(self, requests: List[BatchRequest], batch_result: dict):
        """Distribute batch results to individual request futures"""
        results_map = {result["request_id"]: result for result in batch_result.get("results", [])}
        
        for request in requests:
            if request.request_id in results_map:
                result = results_map[request.request_id]
                if result.get("success", False):
                    request.future.set_result(result.get("data", {}))
                else:
                    request.future.set_exception(Exception(result.get("error", "Unknown error")))
            else:
                request.future.set_exception(Exception(f"Request {request.request_id} not found in batch results"))
    
    async def _handle_batch_failure(self, requests: List[BatchRequest], error: Exception):
        """Handle batch failure by failing all individual requests"""
        for request in requests:
            request.future.set_exception(error)
    
    def _generate_request_id(self, provider: str, request_type: str, params: dict) -> str:
        """Generate unique request ID"""
        params_str = json.dumps(sorted(params.items()), sort_keys=True)
        key_data = f"{provider}:{request_type}:{params_str}:{time.time()}"
        return hashlib.md5(key_data.encode()).hexdigest()[:16]
    
    def _generate_batch_id(self, batch_key: str) -> str:
        """Generate unique batch ID"""
        key_data = f"{batch_key}:{datetime.now().isoformat()}"
        return hashlib.md5(key_data.encode()).hexdigest()[:16]
    
    def _update_batch_stats(self, batch_size: int, processing_time: float):
        """Update batch processing statistics"""
        self.batch_stats["total_batches"] += 1
        
        # Update average batch size
        total_requests = self.batch_stats["total_requests"]
        total_batches = self.batch_stats["total_batches"]
        self.batch_stats["avg_batch_size"] = total_requests / total_batches
        
        # Calculate API calls saved
        api_calls_saved = batch_size - 1  # 1 batch call instead of N individual calls
        self.batch_stats["api_calls_saved"] += api_calls_saved
    
    def get_batch_stats(self) -> Dict[str, Any]:
        """Get batch processing statistics"""
        return {
            "total_requests": self.batch_stats["total_requests"],
            "total_batches": self.batch_stats["total_batches"],
            "avg_batch_size": round(self.batch_stats["avg_batch_size"], 2),
            "api_calls_saved": self.batch_stats["api_calls_saved"],
            "reduction_percentage": round((self.batch_stats["api_calls_saved"] / max(1, self.batch_stats["total_requests"])) * 100, 2),
            "pending_batches": len(self.pending_requests)
        }
    
    async def flush_all_batches(self):
        """Process all pending batches immediately"""
        for batch_key in list(self.pending_requests.keys()):
            if self.pending_requests[batch_key]:
                await self._process_batch(batch_key)
        logger.info("All pending batches flushed")

# Decorator for automatic batching
def batch_request(provider: str, request_type: str):
    """Decorator for automatic request batching"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Extract parameters for batching
            params = kwargs if kwargs else {}
            
            # Add to batch queue
            batch_manager = FreeBatchManager()
            return await batch_manager.add_request(provider, request_type, params)
        return wrapper
    return decorator

# Global batch manager instance
batch_manager = FreeBatchManager()

# Example usage functions
async def get_gpu_pricing_batched(provider: str, gpu_type: str, region: str = "us-west-2") -> dict:
    """Example batched GPU pricing function"""
    params = {"gpu_type": gpu_type, "region": region}
    return await batch_manager.add_request(provider, "pricing", params)

async def get_instance_availability_batched(provider: str, instance_type: str, region: str = "us-west-2") -> dict:
    """Example batched instance availability function"""
    params = {"instance_type": instance_type, "region": region}
    return await batch_manager.add_request(provider, "availability", params)

if __name__ == "__main__":
    # Test the batch manager
    print("Testing Free Batch Manager...")
    
    async def test_batching():
        await batch_manager.start()
        
        # Add multiple requests (they will be batched)
        tasks = []
        for i in range(10):
            task = get_gpu_pricing_batched("aws", f"A100", f"us-west-{i%3+1}")
            tasks.append(task)
        
        # Wait for all results
        results = await asyncio.gather(*tasks)
        
        print(f"Got {len(results)} results from batched requests")
        
        # Show stats
        stats = batch_manager.get_batch_stats()
        print(f"Batch stats: {stats}")
        
        await batch_manager.stop()
    
    asyncio.run(test_batching())
    print("✅ Free Batch Manager working correctly!")
