#!/usr/bin/env python3
"""
Free Database Manager - Local SQLite Database for $0/month
Replace PostgreSQL/Redis with SQLite for GPU pricing cache, usage tracking, rate limit logging
"""

import sqlite3
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import threading

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class GPUPricingRecord:
    """GPU pricing record"""
    provider: str
    gpu_type: str
    region: str
    spot_price: float
    on_demand_price: float
    currency: str = "USD"
    availability: bool = True
    timestamp: str = ""

@dataclass
class UsageRecord:
    """Usage tracking record"""
    user_id: str
    provider: str
    gpu_type: str
    hours_used: float
    cost_saved: float
    timestamp: str = ""

@dataclass
class RateLimitLog:
    """Rate limit logging record"""
    provider: str
    endpoint: str
    response_time: float
    status_code: int
    success: bool
    error_message: Optional[str] = None
    timestamp: str = ""

class FreeDatabaseManager:
    """Free database manager using SQLite for $0/month storage"""
    
    def __init__(self, db_path: str = "terradev_free.db"):
        self.db_path = db_path
        self.lock = threading.Lock()
        self.init_database()
        
    def init_database(self):
        """Initialize all required tables"""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # GPU pricing cache table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS gpu_pricing (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    provider TEXT NOT NULL,
                    gpu_type TEXT NOT NULL,
                    region TEXT NOT NULL,
                    spot_price REAL NOT NULL,
                    on_demand_price REAL NOT NULL,
                    currency TEXT DEFAULT 'USD',
                    availability BOOLEAN DEFAULT 1,
                    timestamp TEXT NOT NULL,
                    UNIQUE(provider, gpu_type, region)
                )
            ''')
            
            # Usage tracking table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS usage_tracking (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    gpu_type TEXT NOT NULL,
                    hours_used REAL NOT NULL,
                    cost_saved REAL NOT NULL,
                    timestamp TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Rate limit logging table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS rate_limit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    provider TEXT NOT NULL,
                    endpoint TEXT NOT NULL,
                    response_time REAL NOT NULL,
                    status_code INTEGER NOT NULL,
                    success BOOLEAN NOT NULL,
                    error_message TEXT,
                    timestamp TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # User budgets table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_budgets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL UNIQUE,
                    tier TEXT NOT NULL,
                    monthly_budget REAL,
                    current_spend REAL DEFAULT 0.0,
                    alert_threshold REAL DEFAULT 0.8,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Performance metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS performance_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    provider TEXT NOT NULL,
                    metric_type TEXT NOT NULL,
                    metric_value REAL NOT NULL,
                    timestamp TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create indexes for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_gpu_pricing_provider ON gpu_pricing(provider)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_gpu_pricing_timestamp ON gpu_pricing(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_usage_user_id ON usage_tracking(user_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_usage_timestamp ON usage_tracking(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_rate_limit_provider ON rate_limit_log(provider)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_rate_limit_timestamp ON rate_limit_log(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_metrics_provider ON performance_metrics(provider)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_metrics_timestamp ON performance_metrics(timestamp)')
            
            conn.commit()
            conn.close()
            
        logger.info(f"Database initialized: {self.db_path}")
    
    # GPU Pricing Methods
    def cache_gpu_pricing(self, provider: str, gpu_data: List[GPUPricingRecord]):
        """Cache GPU pricing data"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            for gpu in gpu_data:
                cursor.execute('''
                    INSERT OR REPLACE INTO gpu_pricing 
                    (provider, gpu_type, region, spot_price, on_demand_price, currency, availability, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    gpu.provider,
                    gpu.gpu_type,
                    gpu.region,
                    gpu.spot_price,
                    gpu.on_demand_price,
                    gpu.currency,
                    gpu.availability,
                    gpu.timestamp or datetime.now().isoformat()
                ))
            
            conn.commit()
            conn.close()
            
        logger.debug(f"Cached {len(gpu_data)} GPU pricing records for {provider}")
    
    def get_cached_pricing(self, provider: str, gpu_type: str = None, region: str = None, 
                          hours_old: int = 1) -> List[GPUPricingRecord]:
        """Get cached pricing data with optional filters"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = "SELECT * FROM gpu_pricing WHERE provider = ?"
            params = [provider]
            
            if gpu_type:
                query += " AND gpu_type = ?"
                params.append(gpu_type)
            
            if region:
                query += " AND region = ?"
                params.append(region)
            
            # Only return data from specified hours
            query += " AND timestamp > datetime('now', '-{} hours')".format(hours_old)
            query += " ORDER BY timestamp DESC"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            conn.close()
            
            return [
                GPUPricingRecord(
                    provider=row[1],
                    gpu_type=row[2],
                    region=row[3],
                    spot_price=row[4],
                    on_demand_price=row[5],
                    currency=row[6],
                    availability=bool(row[7]),
                    timestamp=row[8]
                )
                for row in rows
            ]
    
    def get_cheapest_gpu(self, gpu_type: str, providers: List[str] = None) -> Optional[GPUPricingRecord]:
        """Get cheapest GPU across providers"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = '''
                SELECT * FROM gpu_pricing 
                WHERE gpu_type = ? AND availability = 1
                AND timestamp > datetime('now', '-1 hours')
            '''
            params = [gpu_type]
            
            if providers:
                placeholders = ','.join(['?' for _ in providers])
                query += f' AND provider IN ({placeholders})'
                params.extend(providers)
            
            query += ' ORDER BY spot_price ASC LIMIT 1'
            
            cursor.execute(query, params)
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return GPUPricingRecord(
                    provider=row[1],
                    gpu_type=row[2],
                    region=row[3],
                    spot_price=row[4],
                    on_demand_price=row[5],
                    currency=row[6],
                    availability=bool(row[7]),
                    timestamp=row[8]
                )
            
            return None
    
    # Usage Tracking Methods
    def track_usage(self, user_id: str, provider: str, gpu_type: str, hours_used: float, cost_saved: float):
        """Track GPU usage and cost savings"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO usage_tracking 
                (user_id, provider, gpu_type, hours_used, cost_saved, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                user_id, provider, gpu_type, hours_used, cost_saved, datetime.now().isoformat()
            ))
            
            conn.commit()
            conn.close()
            
        logger.debug(f"Tracked usage: {user_id} used {gpu_type} on {provider} for {hours_used}h")
    
    def get_user_usage(self, user_id: str, days: int = 30) -> List[UsageRecord]:
        """Get usage history for a user"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT user_id, provider, gpu_type, hours_used, cost_saved, timestamp
                FROM usage_tracking 
                WHERE user_id = ? AND timestamp > datetime('now', '-{} days')
                ORDER BY timestamp DESC
            '''.format(days), (user_id,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [
                UsageRecord(
                    user_id=row[0],
                    provider=row[1],
                    gpu_type=row[2],
                    hours_used=row[3],
                    cost_saved=row[4],
                    timestamp=row[5]
                )
                for row in rows
            ]
    
    def get_usage_summary(self, user_id: str = None, days: int = 30) -> Dict[str, Any]:
        """Get usage summary statistics"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = '''
                SELECT 
                    COUNT(*) as total_requests,
                    SUM(hours_used) as total_hours,
                    SUM(cost_saved) as total_savings,
                    AVG(cost_saved) as avg_savings,
                    COUNT(DISTINCT provider) as providers_used
                FROM usage_tracking 
                WHERE timestamp > datetime('now', '-{} days')
            '''.format(days)
            
            params = []
            if user_id:
                query += ' AND user_id = ?'
                params.append(user_id)
            
            cursor.execute(query, params)
            result = cursor.fetchone()
            conn.close()
            
            if result and result[0] > 0:
                return {
                    "total_requests": result[0],
                    "total_hours": result[1] or 0.0,
                    "total_savings": result[2] or 0.0,
                    "avg_savings_per_request": result[3] or 0.0,
                    "providers_used": result[4] or 0,
                    "period_days": days
                }
            
            return {
                "total_requests": 0,
                "total_hours": 0.0,
                "total_savings": 0.0,
                "avg_savings_per_request": 0.0,
                "providers_used": 0,
                "period_days": days
            }
    
    # Rate Limit Logging Methods
    def log_rate_limit(self, provider: str, endpoint: str, response_time: float, 
                       status_code: int, success: bool, error_message: str = None):
        """Log rate limit events"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO rate_limit_log 
                (provider, endpoint, response_time, status_code, success, error_message, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                provider, endpoint, response_time, status_code, 
                success, error_message, datetime.now().isoformat()
            ))
            
            conn.commit()
            conn.close()
    
    def get_rate_limit_stats(self, provider: str = None, hours: int = 24) -> Dict[str, Any]:
        """Get rate limit statistics"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = '''
                SELECT 
                    COUNT(*) as total_requests,
                    COUNT(CASE WHEN success = 1 THEN 1 END) as successful_requests,
                    AVG(response_time) as avg_response_time,
                    MIN(response_time) as min_response_time,
                    MAX(response_time) as max_response_time
                FROM rate_limit_log 
                WHERE timestamp > datetime('now', '-{} hours')
            '''.format(hours)
            
            params = []
            if provider:
                query += ' AND provider = ?'
                params.append(provider)
            
            cursor.execute(query, params)
            result = cursor.fetchone()
            conn.close()
            
            if result and result[0] > 0:
                success_rate = (result[1] / result[0]) * 100
                return {
                    "total_requests": result[0],
                    "successful_requests": result[1],
                    "success_rate_percent": round(success_rate, 2),
                    "avg_response_time": round(result[2] or 0, 3),
                    "min_response_time": round(result[3] or 0, 3),
                    "max_response_time": round(result[4] or 0, 3),
                    "period_hours": hours
                }
            
            return {
                "total_requests": 0,
                "successful_requests": 0,
                "success_rate_percent": 0.0,
                "avg_response_time": 0.0,
                "min_response_time": 0.0,
                "max_response_time": 0.0,
                "period_hours": hours
            }
    
    # Performance Metrics Methods
    def store_metric(self, provider: str, metric_type: str, metric_value: float):
        """Store performance metric"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO performance_metrics 
                (provider, metric_type, metric_value, timestamp)
                VALUES (?, ?, ?, ?)
            ''', (provider, metric_type, metric_value, datetime.now().isoformat()))
            
            conn.commit()
            conn.close()
    
    def get_metrics(self, provider: str, metric_type: str = None, hours: int = 24) -> List[dict]:
        """Get performance metrics"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = '''
                SELECT provider, metric_type, metric_value, timestamp
                FROM performance_metrics 
                WHERE provider = ? AND timestamp > datetime('now', '-{} hours')
            '''.format(hours)
            
            params = [provider]
            if metric_type:
                query += ' AND metric_type = ?'
                params.append(metric_type)
            
            query += ' ORDER BY timestamp DESC'
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    "provider": row[0],
                    "metric_type": row[1],
                    "metric_value": row[2],
                    "timestamp": row[3]
                }
                for row in rows
            ]
    
    # Maintenance Methods
    def cleanup_old_data(self, days_to_keep: int = 30):
        """Clean up old data to save space"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            cutoff_str = cutoff_date.isoformat()
            
            # Clean up old rate limit logs
            cursor.execute("DELETE FROM rate_limit_log WHERE timestamp < ?", (cutoff_str,))
            rate_limit_deleted = cursor.rowcount
            
            # Clean up old performance metrics
            cursor.execute("DELETE FROM performance_metrics WHERE timestamp < ?", (cutoff_str,))
            metrics_deleted = cursor.rowcount
            
            # Clean up old usage tracking (keep longer)
            usage_cutoff = datetime.now() - timedelta(days=days_to_keep * 3)
            usage_cutoff_str = usage_cutoff.isoformat()
            cursor.execute("DELETE FROM usage_tracking WHERE timestamp < ?", (usage_cutoff_str,))
            usage_deleted = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            logger.info(f"Cleaned up old data: {rate_limit_deleted} rate limit logs, {metrics_deleted} metrics, {usage_deleted} usage records")
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            stats = {}
            
            # Table sizes
            tables = ["gpu_pricing", "usage_tracking", "rate_limit_log", "user_budgets", "performance_metrics"]
            for table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                stats[f"{table}_count"] = cursor.fetchone()[0]
            
            # Database size
            cursor.execute("SELECT page_count * page_size as size FROM pragma_page_count(), pragma_page_size()")
            db_size = cursor.fetchone()[0]
            stats["database_size_bytes"] = db_size
            stats["database_size_mb"] = round(db_size / (1024 * 1024), 2)
            
            conn.close()
            return stats

# Global database manager instance
database_manager = FreeDatabaseManager()

if __name__ == "__main__":
    # Test the database manager
    print("Testing Free Database Manager...")
    
    # Test GPU pricing
    test_gpu_data = [
        GPUPricingRecord(
            provider="aws",
            gpu_type="A100",
            region="us-west-2",
            spot_price=4.06,
            on_demand_price=4.86,
            timestamp=datetime.now().isoformat()
        ),
        GPUPricingRecord(
            provider="gcp",
            gpu_type="A100",
            region="us-west1",
            spot_price=3.95,
            on_demand_price=4.75,
            timestamp=datetime.now().isoformat()
        )
    ]
    
    database_manager.cache_gpu_pricing("aws", [test_gpu_data[0]])
    database_manager.cache_gpu_pricing("gcp", [test_gpu_data[1]])
    
    # Test retrieval
    aws_pricing = database_manager.get_cached_pricing("aws", "A100")
    print(f"AWS pricing: {len(aws_pricing)} records")
    
    cheapest = database_manager.get_cheapest_gpu("A100")
    print(f"Cheapest A100: {cheapest}")
    
    # Test usage tracking
    database_manager.track_usage("user123", "aws", "A100", 2.5, 15.75)
    usage_summary = database_manager.get_usage_summary("user123")
    print(f"Usage summary: {usage_summary}")
    
    # Test stats
    db_stats = database_manager.get_database_stats()
    print(f"Database stats: {db_stats}")
    
    print("✅ Free Database Manager working correctly!")
