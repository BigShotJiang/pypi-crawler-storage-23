#!/usr/bin/env python3
"""
Free Rate Limit Manager - Exponential Backoff with Jitter for 100% Compliance
Respect rate limits automatically with conservative limits and smart retry logic
"""

import asyncio
import random
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Callable, Optional
from dataclasses import dataclass
from collections import defaultdict
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class RateLimitConfig:
    """Configuration for rate limiting per provider"""
    min_interval_seconds: float
    max_retries: int
    base_delay: float
    max_delay: float
    backoff_multiplier: float
    jitter_factor: float

class FreeRateLimitManager:
    """Free rate limit management with intelligent backoff and 100% compliance"""
    
    def __init__(self):
        # Conservative rate limits (free tier friendly)
        self.provider_configs = {
            "aws": RateLimitConfig(
                min_interval_seconds=2.0,      # 1 request every 2 seconds
                max_retries=3,
                base_delay=1.0,
                max_delay=60.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            ),
            "gcp": RateLimitConfig(
                min_interval_seconds=1.5,      # 1 request every 1.5 seconds
                max_retries=3,
                base_delay=1.0,
                max_delay=45.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            ),
            "azure": RateLimitConfig(
                min_interval_seconds=2.5,      # 1 request every 2.5 seconds
                max_retries=3,
                base_delay=1.5,
                max_delay=60.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            ),
            "runpod": RateLimitConfig(
                min_interval_seconds=1.0,      # 1 request per second
                max_retries=3,
                base_delay=0.5,
                max_delay=30.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            ),
            "lambda": RateLimitConfig(
                min_interval_seconds=1.2,      # 1 request every 1.2 seconds
                max_retries=3,
                base_delay=0.8,
                max_delay=30.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            ),
            "coreweave": RateLimitConfig(
                min_interval_seconds=1.8,      # 1 request every 1.8 seconds
                max_retries=3,
                base_delay=1.0,
                max_delay=45.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            ),
            "vast_ai": RateLimitConfig(
                min_interval_seconds=1.0,      # 1 request per second
                max_retries=3,
                base_delay=0.5,
                max_delay=30.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            ),
            "tensordock": RateLimitConfig(
                min_interval_seconds=1.5,      # 1 request every 1.5 seconds
                max_retries=3,
                base_delay=0.8,
                max_delay=30.0,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            )
        }
        
        self.last_request_time: Dict[str, float] = {}
        self.rate_limit_tracker: Dict[str, Dict] = defaultdict(lambda: {
            "attempts": 0,
            "last_backoff": 0.0,
            "rate_limited_until": 0.0,
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0
        })
        self.request_history: Dict[str, List[dict]] = defaultdict(list)
        
    async def make_request(self, provider: str, api_call: Callable, *args, **kwargs) -> Any:
        """Make API call with intelligent rate limiting and retry logic"""
        
        # Validate provider
        if provider not in self.provider_configs:
            logger.warning(f"Unknown provider {provider}, using default config")
            provider = "aws"  # Use conservative default
        
        config = self.provider_configs[provider]
        tracker = self.rate_limit_tracker[provider]
        
        # Check if we're currently rate limited
        await self._check_rate_limit_status(provider)
        
        # Respect minimum interval between requests
        await self._respect_minimum_interval(provider)
        
        # Attempt the request with retry logic
        return await self._attempt_request_with_retry(provider, api_call, config, *args, **kwargs)
    
    async def _check_rate_limit_status(self, provider: str):
        """Check if we need to wait due to rate limiting"""
        tracker = self.rate_limit_tracker[provider]
        now = time.time()
        
        if now < tracker["rate_limited_until"]:
            wait_time = tracker["rate_limited_until"] - now
            logger.warning(f"Rate limited by {provider}. Waiting {wait_time:.2f}s")
            await asyncio.sleep(wait_time)
    
    async def _respect_minimum_interval(self, provider: str):
        """Respect minimum interval between requests"""
        config = self.provider_configs[provider]
        now = time.time()
        last_request = self.last_request_time.get(provider, 0)
        
        time_since_last = now - last_request
        if time_since_last < config.min_interval_seconds:
            wait_time = config.min_interval_seconds - time_since_last
            if wait_time > 0:
                logger.debug(f"Respecting rate limit for {provider}. Waiting {wait_time:.2f}s")
                await asyncio.sleep(wait_time)
        
        self.last_request_time[provider] = time.time()
    
    async def _attempt_request_with_retry(self, provider: str, api_call: Callable, config: RateLimitConfig, *args, **kwargs) -> Any:
        """Attempt API call with retry logic"""
        tracker = self.rate_limit_tracker[provider]
        
        for attempt in range(config.max_retries + 1):
            try:
                # Record attempt
                tracker["total_requests"] += 1
                
                # Make the request
                start_time = time.time()
                result = await api_call(*args, **kwargs)
                response_time = time.time() - start_time
                
                # Record success
                tracker["successful_requests"] += 1
                tracker["attempts"] = 0  # Reset attempts on success
                
                # Record request history
                self._record_request_history(provider, True, response_time, None, attempt + 1)
                
                logger.debug(f"Request to {provider} succeeded in {response_time:.2f}s (attempt {attempt + 1})")
                return result
                
            except Exception as e:
                # Record failure
                tracker["failed_requests"] += 1
                
                # Check if this is a rate limit error
                if self._is_rate_limit_error(e):
                    await self._handle_rate_limit(provider, config, attempt)
                else:
                    # Non-rate-limit error, retry with backoff
                    if attempt < config.max_retries:
                        delay = self._calculate_retry_delay(config, attempt)
                        logger.warning(f"Request to {provider} failed (attempt {attempt + 1}): {e}. Retrying in {delay:.2f}s")
                        await asyncio.sleep(delay)
                    else:
                        # Record final failure
                        self._record_request_history(provider, False, 0, str(e), attempt + 1)
                        raise e
        
        # This should not be reached
        raise Exception(f"Max retries exceeded for {provider}")
    
    async def _handle_rate_limit(self, provider: str, config: RateLimitConfig, attempt: int):
        """Handle rate limit with exponential backoff"""
        tracker = self.rate_limit_tracker[provider]
        tracker["attempts"] += 1
        
        # Calculate backoff delay
        backoff = self._calculate_retry_delay(config, tracker["attempts"] - 1)
        
        # Set rate limit expiration
        tracker["rate_limited_until"] = time.time() + backoff
        tracker["last_backoff"] = backoff
        
        logger.warning(f"Rate limited by {provider}. Waiting {backoff:.2f}s (attempt {attempt + 1})")
        await asyncio.sleep(backoff)
    
    def _calculate_retry_delay(self, config: RateLimitConfig, attempt: int) -> float:
        """Calculate delay with exponential backoff and jitter"""
        # Exponential backoff: base_delay * (backoff_multiplier ^ attempt)
        delay = config.base_delay * (config.backoff_multiplier ** attempt)
        delay = min(delay, config.max_delay)
        
        # Add jitter to avoid thundering herd
        jitter = random.uniform(0, delay * config.jitter_factor)
        total_delay = delay + jitter
        
        return total_delay
    
    def _is_rate_limit_error(self, error: Exception) -> bool:
        """Check if error is rate limit related"""
        error_str = str(error).lower()
        rate_limit_indicators = [
            "rate limit", "too many requests", "quota exceeded",
            "throttled", "429", "retry later", "rate limited",
            "request limit", "api limit", "frequency limit"
        ]
        return any(indicator in error_str for indicator in rate_limit_indicators)
    
    def _record_request_history(self, provider: str, success: bool, response_time: float, error: Optional[str], attempt: int):
        """Record request history for analytics"""
        history_entry = {
            "timestamp": datetime.now().isoformat(),
            "success": success,
            "response_time": response_time,
            "error": error,
            "attempt": attempt
        }
        
        self.request_history[provider].append(history_entry)
        
        # Keep only last 1000 entries per provider
        if len(self.request_history[provider]) > 1000:
            self.request_history[provider] = self.request_history[provider][-1000:]
    
    def get_provider_stats(self, provider: str) -> Dict[str, Any]:
        """Get statistics for a specific provider"""
        if provider not in self.rate_limit_tracker:
            return {}
        
        tracker = self.rate_limit_tracker[provider]
        config = self.provider_configs.get(provider, self.provider_configs["aws"])
        
        # Calculate success rate
        total_requests = tracker["total_requests"]
        success_rate = 0
        if total_requests > 0:
            success_rate = (tracker["successful_requests"] / total_requests) * 100
        
        # Calculate average response time from history
        avg_response_time = 0
        if provider in self.request_history:
            successful_requests = [r for r in self.request_history[provider] if r["success"] and r["response_time"] > 0]
            if successful_requests:
                avg_response_time = sum(r["response_time"] for r in successful_requests) / len(successful_requests)
        
        return {
            "provider": provider,
            "total_requests": total_requests,
            "successful_requests": tracker["successful_requests"],
            "failed_requests": tracker["failed_requests"],
            "success_rate_percent": round(success_rate, 2),
            "current_attempts": tracker["attempts"],
            "rate_limited_until": datetime.fromtimestamp(tracker["rate_limited_until"]).isoformat() if tracker["rate_limited_until"] > time.time() else None,
            "avg_response_time": round(avg_response_time, 3),
            "min_interval_seconds": config.min_interval_seconds,
            "max_retries": config.max_retries
        }
    
    def get_all_stats(self) -> Dict[str, Any]:
        """Get statistics for all providers"""
        all_stats = {}
        for provider in self.provider_configs:
            all_stats[provider] = self.get_provider_stats(provider)
        
        # Calculate overall stats
        total_requests = sum(stats["total_requests"] for stats in all_stats.values())
        total_successful = sum(stats["successful_requests"] for stats in all_stats.values())
        overall_success_rate = 0
        if total_requests > 0:
            overall_success_rate = (total_successful / total_requests) * 100
        
        return {
            "overall": {
                "total_requests": total_requests,
                "successful_requests": total_successful,
                "failed_requests": total_requests - total_successful,
                "overall_success_rate_percent": round(overall_success_rate, 2),
                "providers_tracked": len(self.provider_configs)
            },
            "by_provider": all_stats
        }
    
    def reset_provider_stats(self, provider: str):
        """Reset statistics for a specific provider"""
        if provider in self.rate_limit_tracker:
            self.rate_limit_tracker[provider] = {
                "attempts": 0,
                "last_backoff": 0.0,
                "rate_limited_until": 0.0,
                "total_requests": 0,
                "successful_requests": 0,
                "failed_requests": 0
            }
        
        if provider in self.request_history:
            self.request_history[provider].clear()
        
        if provider in self.last_request_time:
            del self.last_request_time[provider]
        
        logger.info(f"Reset statistics for provider: {provider}")
    
    def add_provider_config(self, provider: str, config: RateLimitConfig):
        """Add or update provider configuration"""
        self.provider_configs[provider] = config
        logger.info(f"Added/updated configuration for provider: {provider}")

# Decorator for automatic rate limiting
def rate_limited(provider: str):
    """Decorator for automatic rate limiting"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            rate_manager = FreeRateLimitManager()
            return await rate_manager.make_request(provider, func, *args, **kwargs)
        return wrapper
    return decorator

# Global rate limit manager instance
rate_limit_manager = FreeRateLimitManager()

# Example usage functions
@rate_limited("aws")
async def get_aws_gpu_pricing(gpu_type: str, region: str) -> dict:
    """Example rate-limited AWS GPU pricing function"""
    # This would be the actual AWS API call
    await asyncio.sleep(0.1)  # Simulate API call
    return {"gpu_type": gpu_type, "price": 4.06, "region": region, "provider": "aws"}

@rate_limited("gcp")
async def get_gcp_gpu_pricing(gpu_type: str, region: str) -> dict:
    """Example rate-limited GCP GPU pricing function"""
    # This would be the actual GCP API call
    await asyncio.sleep(0.1)  # Simulate API call
    return {"gpu_type": gpu_type, "price": 3.95, "region": region, "provider": "gcp"}

if __name__ == "__main__":
    # Test the rate limit manager
    print("Testing Free Rate Limit Manager...")
    
    async def test_rate_limiting():
        # Test multiple requests to the same provider
        tasks = []
        for i in range(5):
            task = get_aws_gpu_pricing("A100", "us-west-2")
            tasks.append(task)
        
        # Wait for all results
        results = await asyncio.gather(*tasks)
        
        print(f"Got {len(results)} results with rate limiting")
        
        # Show stats
        stats = rate_limit_manager.get_all_stats()
        print(f"Rate limit stats: {json.dumps(stats, indent=2)}")
    
    asyncio.run(test_rate_limiting())
    print("✅ Free Rate Limit Manager working correctly!")
