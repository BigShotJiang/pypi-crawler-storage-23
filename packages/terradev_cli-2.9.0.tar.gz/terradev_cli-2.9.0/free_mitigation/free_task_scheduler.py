#!/usr/bin/env python3
"""
Free Task Scheduler - Background task scheduler using asyncio
Automated maintenance without external services
"""

import asyncio
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Callable, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
import threading
import json
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    """Task priority levels"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

@dataclass
class ScheduledTask:
    """Scheduled task definition"""
    name: str
    func: Callable
    interval_seconds: int
    priority: TaskPriority = TaskPriority.NORMAL
    enabled: bool = True
    max_retries: int = 3
    timeout_seconds: int = 300
    last_run: datetime = field(default_factory=datetime.min)
    next_run: datetime = field(default_factory=lambda: datetime.now())
    run_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    last_result: Optional[Any] = None
    last_error: Optional[str] = None
    status: TaskStatus = TaskStatus.PENDING

@dataclass
class TaskResult:
    """Result of a task execution"""
    task_name: str
    success: bool
    start_time: datetime
    end_time: datetime
    duration: float
    result: Optional[Any] = None
    error: Optional[str] = None
    retry_attempt: int = 0

class FreeTaskScheduler:
    """Free background task scheduler using asyncio"""
    
    def __init__(self, max_concurrent_tasks: int = 10):
        self.max_concurrent_tasks = max_concurrent_tasks
        self.tasks: Dict[str, ScheduledTask] = {}
        self.running_tasks: Dict[str, asyncio.Task] = {}
        self.task_history: List[TaskResult] = []
        self.max_history = 1000
        
        self.running = False
        self.scheduler_task: Optional[asyncio.Task] = None
        self.semaphore = asyncio.Semaphore(max_concurrent_tasks)
        
        # Statistics
        self.stats = {
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "total_runtime": 0.0,
            "avg_runtime": 0.0,
            "scheduler_start_time": None
        }
        
        logger.info(f"Task scheduler initialized: max_concurrent={max_concurrent_tasks}")
    
    async def start(self):
        """Start the task scheduler"""
        if self.running:
            logger.warning("Scheduler is already running")
            return
        
        self.running = True
        self.stats["scheduler_start_time"] = datetime.now()
        self.scheduler_task = asyncio.create_task(self._scheduler_loop())
        logger.info("Task scheduler started")
    
    async def stop(self):
        """Stop the task scheduler"""
        if not self.running:
            return
        
        self.running = False
        
        # Cancel scheduler task
        if self.scheduler_task:
            self.scheduler_task.cancel()
            try:
                await self.scheduler_task
            except asyncio.CancelledError:
                pass
        
        # Wait for running tasks to complete or timeout
        if self.running_tasks:
            logger.info(f"Waiting for {len(self.running_tasks)} tasks to complete...")
            try:
                await asyncio.wait_for(
                    asyncio.gather(*self.running_tasks.values(), return_exceptions=True),
                    timeout=30.0
                )
            except asyncio.TimeoutError:
                logger.warning("Some tasks didn't complete in time")
        
        self.running_tasks.clear()
        logger.info("Task scheduler stopped")
    
    def schedule_task(self, name: str, func: Callable, interval_seconds: int, 
                     priority: TaskPriority = TaskPriority.NORMAL, 
                     enabled: bool = True, max_retries: int = 3, 
                     timeout_seconds: int = 300) -> bool:
        """Schedule a recurring task"""
        if name in self.tasks:
            logger.warning(f"Task {name} already exists, updating...")
        
        task = ScheduledTask(
            name=name,
            func=func,
            interval_seconds=interval_seconds,
            priority=priority,
            enabled=enabled,
            max_retries=max_retries,
            timeout_seconds=timeout_seconds,
            next_run=datetime.now() + timedelta(seconds=interval_seconds)
        )
        
        self.tasks[name] = task
        logger.info(f"Scheduled task: {name} (interval: {interval_seconds}s, priority: {priority.name})")
        return True
    
    def remove_task(self, name: str) -> bool:
        """Remove a scheduled task"""
        if name in self.tasks:
            # Cancel if currently running
            if name in self.running_tasks:
                self.running_tasks[name].cancel()
                del self.running_tasks[name]
            
            del self.tasks[name]
            logger.info(f"Removed task: {name}")
            return True
        return False
    
    def enable_task(self, name: str, enabled: bool = True) -> bool:
        """Enable or disable a task"""
        if name in self.tasks:
            self.tasks[name].enabled = enabled
            logger.info(f"Task {name} {'enabled' if enabled else 'disabled'}")
            return True
        return False
    
    async def _scheduler_loop(self):
        """Main scheduler loop"""
        while self.running:
            try:
                # Find tasks ready to run
                ready_tasks = self._get_ready_tasks()
                
                # Sort by priority (critical first)
                ready_tasks.sort(key=lambda t: t.priority.value, reverse=True)
                
                # Execute ready tasks
                for task in ready_tasks:
                    if self.running and task.enabled:
                        asyncio.create_task(self._execute_task(task))
                
                # Sleep before next check
                await asyncio.sleep(1)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Scheduler loop error: {e}")
                await asyncio.sleep(5)
    
    def _get_ready_tasks(self) -> List[ScheduledTask]:
        """Get tasks that are ready to run"""
        now = datetime.now()
        ready_tasks = []
        
        for task in self.tasks.values():
            if (task.enabled and 
                task.status != TaskStatus.RUNNING and 
                now >= task.next_run and
                task.name not in self.running_tasks):
                ready_tasks.append(task)
        
        return ready_tasks
    
    async def _execute_task(self, task: ScheduledTask):
        """Execute a single task"""
        async with self.semaphore:  # Limit concurrent tasks
            self.running_tasks[task.name] = asyncio.current_task()
            
            start_time = datetime.now()
            task.status = TaskStatus.RUNNING
            task.last_run = start_time
            
            logger.debug(f"Executing task: {task.name}")
            
            try:
                # Execute with timeout
                result = await asyncio.wait_for(
                    self._run_task_func(task),
                    timeout=task.timeout_seconds
                )
                
                # Success
                end_time = datetime.now()
                duration = (end_time - start_time).total_seconds()
                
                task.status = TaskStatus.COMPLETED
                task.success_count += 1
                task.last_result = result
                task.last_error = None
                task.run_count += 1
                
                # Schedule next run
                task.next_run = datetime.now() + timedelta(seconds=task.interval_seconds)
                
                # Record result
                task_result = TaskResult(
                    task_name=task.name,
                    success=True,
                    start_time=start_time,
                    end_time=end_time,
                    duration=duration,
                    result=result
                )
                
                self._record_task_result(task_result)
                self._update_stats(task_result, True)
                
                logger.debug(f"Task {task.name} completed in {duration:.2f}s")
                
            except asyncio.TimeoutError:
                # Timeout
                end_time = datetime.now()
                duration = (end_time - start_time).total_seconds()
                
                task.status = TaskStatus.FAILED
                task.failure_count += 1
                task.last_error = f"Task timed out after {task.timeout_seconds}s"
                
                # Schedule retry if retries available
                if task.failure_count <= task.max_retries:
                    task.next_run = datetime.now() + timedelta(seconds=task.interval_seconds)
                else:
                    task.enabled = False  # Disable after max retries
                    logger.error(f"Task {task.name} disabled after max retries")
                
                task_result = TaskResult(
                    task_name=task.name,
                    success=False,
                    start_time=start_time,
                    end_time=end_time,
                    duration=duration,
                    error=task.last_error
                )
                
                self._record_task_result(task_result)
                self._update_stats(task_result, False)
                
                logger.warning(f"Task {task.name} timed out after {duration:.2f}s")
                
            except Exception as e:
                # Other error
                end_time = datetime.now()
                duration = (end_time - start_time).total_seconds()
                
                task.status = TaskStatus.FAILED
                task.failure_count += 1
                task.last_error = str(e)
                
                # Schedule retry if retries available
                if task.failure_count <= task.max_retries:
                    task.next_run = datetime.now() + timedelta(seconds=task.interval_seconds)
                else:
                    task.enabled = False
                    logger.error(f"Task {task.name} disabled after max retries")
                
                task_result = TaskResult(
                    task_name=task.name,
                    success=False,
                    start_time=start_time,
                    end_time=end_time,
                    duration=duration,
                    error=str(e)
                )
                
                self._record_task_result(task_result)
                self._update_stats(task_result, False)
                
                logger.error(f"Task {task.name} failed: {e}")
            
            finally:
                # Clean up running tasks
                if task.name in self.running_tasks:
                    del self.running_tasks[task.name]
    
    async def _run_task_func(self, task: ScheduledTask) -> Any:
        """Run the task function (sync or async)"""
        if asyncio.iscoroutinefunction(task.func):
            return await task.func()
        else:
            # Run sync function in thread pool
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, task.func)
    
    def _record_task_result(self, result: TaskResult):
        """Record task execution result"""
        self.task_history.append(result)
        
        # Keep only recent history
        if len(self.task_history) > self.max_history:
            self.task_history = self.task_history[-self.max_history:]
    
    def _update_stats(self, result: TaskResult, success: bool):
        """Update execution statistics"""
        self.stats["total_executions"] += 1
        
        if success:
            self.stats["successful_executions"] += 1
        else:
            self.stats["failed_executions"] += 1
        
        self.stats["total_runtime"] += result.duration
        
        total_executions = self.stats["total_executions"]
        if total_executions > 0:
            self.stats["avg_runtime"] = self.stats["total_runtime"] / total_executions
    
    def get_task_info(self, name: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific task"""
        if name not in self.tasks:
            return None
        
        task = self.tasks[name]
        return {
            "name": task.name,
            "enabled": task.enabled,
            "status": task.status.value,
            "priority": task.priority.name,
            "interval_seconds": task.interval_seconds,
            "last_run": task.last_run.isoformat() if task.last_run != datetime.min else None,
            "next_run": task.next_run.isoformat(),
            "run_count": task.run_count,
            "success_count": task.success_count,
            "failure_count": task.failure_count,
            "success_rate": (task.success_count / max(1, task.run_count)) * 100,
            "last_result": task.last_result,
            "last_error": task.last_error,
            "is_running": task.name in self.running_tasks
        }
    
    def get_all_tasks(self) -> Dict[str, Dict[str, Any]]:
        """Get information about all tasks"""
        return {name: self.get_task_info(name) for name in self.tasks.keys()}
    
    def get_scheduler_stats(self) -> Dict[str, Any]:
        """Get scheduler statistics"""
        uptime_seconds = 0
        if self.stats["scheduler_start_time"]:
            uptime_seconds = (datetime.now() - self.stats["scheduler_start_time"]).total_seconds()
        
        return {
            "running": self.running,
            "total_tasks": len(self.tasks),
            "enabled_tasks": len([t for t in self.tasks.values() if t.enabled]),
            "running_tasks": len(self.running_tasks),
            "uptime_seconds": uptime_seconds,
            "total_executions": self.stats["total_executions"],
            "successful_executions": self.stats["successful_executions"],
            "failed_executions": self.stats["failed_executions"],
            "success_rate_percent": (self.stats["successful_executions"] / max(1, self.stats["total_executions"])) * 100,
            "avg_runtime_seconds": round(self.stats["avg_runtime"], 3),
            "total_runtime_seconds": round(self.stats["total_runtime"], 3)
        }
    
    def get_task_history(self, task_name: str = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Get task execution history"""
        history = self.task_history
        
        if task_name:
            history = [h for h in history if h.task_name == task_name]
        
        # Return most recent
        history = history[-limit:]
        
        return [
            {
                "task_name": h.task_name,
                "success": h.success,
                "start_time": h.start_time.isoformat(),
                "end_time": h.end_time.isoformat(),
                "duration": round(h.duration, 3),
                "result": h.result,
                "error": h.error
            }
            for h in history
        ]

# Global scheduler instance
task_scheduler = FreeTaskScheduler()

# Example task functions
async def update_gpu_pricing_cache():
    """Background task to update GPU pricing cache"""
    logger.info("Updating GPU pricing cache...")
    
    # This would call actual provider APIs
    await asyncio.sleep(2)  # Simulate API calls
    
    # Update cache with mock data
    from free_cache_manager import cache_manager
    mock_data = {
        "aws": {"A100": 4.06, "H100": 7.20, "A10G": 1.21},
        "gcp": {"A100": 3.95, "H100": 7.05, "A10G": 1.15},
        "azure": {"A100": 4.10, "H100": 7.25, "A10G": 1.25}
    }
    
    for provider, prices in mock_data.items():
        for gpu_type, price in prices.items():
            cache_manager.cache_result(provider, "pricing", {"gpu_type": gpu_type}, {"price": price})
    
    logger.info("GPU pricing cache updated")

async def cleanup_expired_cache():
    """Background task to clean up expired cache entries"""
    logger.info("Cleaning up expired cache entries...")
    
    from free_cache_manager import cache_manager
    cache_manager.cleanup_expired()
    
    from free_memory_cache import cache_manager as memory_cache_manager
    memory_cache_manager.cleanup_all()
    
    logger.info("Cache cleanup completed")

def update_usage_statistics():
    """Background task to update usage statistics"""
    logger.info("Updating usage statistics...")
    
    # This would analyze usage patterns and update metrics
    time.sleep(1)  # Simulate processing
    
    logger.info("Usage statistics updated")

async def health_check_providers():
    """Background task to check provider health"""
    logger.info("Checking provider health...")
    
    # This would ping provider APIs
    await asyncio.sleep(1)
    
    # Mock health check results
    health_status = {
        "aws": "healthy",
        "gcp": "healthy", 
        "azure": "degraded",
        "runpod": "healthy"
    }
    
    for provider, status in health_status.items():
        from free_memory_cache import provider_status_cache
        provider_status_cache.set(provider, {"status": status, "last_check": datetime.now().isoformat()})
    
    logger.info(f"Provider health check completed: {health_status}")

if __name__ == "__main__":
    # Test the task scheduler
    print("Testing Free Task Scheduler...")
    
    async def test_scheduler():
        # Start scheduler
        await task_scheduler.start()
        
        # Schedule some test tasks
        task_scheduler.schedule_task(
            "update_gpu_pricing", 
            update_gpu_pricing_cache, 
            interval_seconds=10,  # Every 10 seconds for testing
            priority=TaskPriority.HIGH
        )
        
        task_scheduler.schedule_task(
            "cleanup_cache",
            cleanup_expired_cache,
            interval_seconds=30,
            priority=TaskPriority.NORMAL
        )
        
        task_scheduler.schedule_task(
            "update_stats",
            update_usage_statistics,
            interval_seconds=15,
            priority=TaskPriority.LOW
        )
        
        task_scheduler.schedule_task(
            "health_check",
            health_check_providers,
            interval_seconds=20,
            priority=TaskPriority.CRITICAL
        )
        
        # Run for a while
        print("Scheduler running for 60 seconds...")
        await asyncio.sleep(60)
        
        # Show stats
        stats = task_scheduler.get_scheduler_stats()
        print(f"Scheduler stats: {json.dumps(stats, indent=2, default=str)}")
        
        # Show task info
        tasks = task_scheduler.get_all_tasks()
        print(f"Tasks: {json.dumps(tasks, indent=2, default=str)}")
        
        # Stop scheduler
        await task_scheduler.stop()
    
    asyncio.run(test_scheduler())
    print("✅ Free Task Scheduler working correctly!")
