#!/usr/bin/env python3
"""
Free Memory Cache - Thread-safe in-memory cache with TTL for microsecond latency
LRU cache with automatic cleanup and performance monitoring
"""

import time
import threading
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Callable, List
from functools import lru_cache, wraps
import weakref
from collections import OrderedDict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FreeMemoryCache:
    """Thread-safe in-memory cache with TTL and LRU eviction"""
    
    def __init__(self, max_size: int = 1000, ttl_seconds: int = 3600, cleanup_interval: int = 300):
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self.cleanup_interval = cleanup_interval
        
        # Use OrderedDict for LRU functionality
        self.cache: OrderedDict[str, tuple] = OrderedDict()
        self.access_times: Dict[str, datetime] = {}
        self.lock = threading.RLock()
        
        # Statistics
        self.stats = {
            "hits": 0,
            "misses": 0,
            "evictions": 0,
            "expirations": 0,
            "total_requests": 0,
            "cleanup_runs": 0
        }
        
        # Start cleanup thread
        self.cleanup_thread = threading.Thread(target=self._cleanup_loop, daemon=True)
        self.cleanup_thread.start()
        
        logger.info(f"Memory cache initialized: max_size={max_size}, ttl={ttl_seconds}s")
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        with self.lock:
            self.stats["total_requests"] += 1
            
            if key in self.cache:
                data, timestamp = self.cache[key]
                
                # Check TTL
                if datetime.now() - timestamp < timedelta(seconds=self.ttl_seconds):
                    # Move to end (most recently used)
                    self.cache.move_to_end(key)
                    self.access_times[key] = datetime.now()
                    self.stats["hits"] += 1
                    return data
                else:
                    # Expired, remove
                    del self.cache[key]
                    if key in self.access_times:
                        del self.access_times[key]
                    self.stats["expirations"] += 1
            
            self.stats["misses"] += 1
            return None
    
    def set(self, key: str, value: Any, custom_ttl: Optional[int] = None):
        """Set value in cache with optional custom TTL"""
        with self.lock:
            # Remove oldest if at capacity
            if len(self.cache) >= self.max_size and key not in self.cache:
                self._evict_oldest()
            
            # Store with timestamp
            timestamp = datetime.now()
            if custom_ttl:
                # Store custom TTL in the tuple
                self.cache[key] = (value, timestamp, custom_ttl)
            else:
                self.cache[key] = (value, timestamp)
            
            self.access_times[key] = timestamp
            self.cache.move_to_end(key)  # Mark as most recently used
    
    def delete(self, key: str) -> bool:
        """Delete key from cache"""
        with self.lock:
            if key in self.cache:
                del self.cache[key]
                if key in self.access_times:
                    del self.access_times[key]
                return True
            return False
    
    def clear(self):
        """Clear all cache entries"""
        with self.lock:
            self.cache.clear()
            self.access_times.clear()
            logger.info("Cache cleared")
    
    def _evict_oldest(self):
        """Remove least recently used item"""
        if not self.cache:
            return
        
        oldest_key = next(iter(self.cache))
        del self.cache[oldest_key]
        if oldest_key in self.access_times:
            del self.access_times[oldest_key]
        
        self.stats["evictions"] += 1
        logger.debug(f"Evicted cache key: {oldest_key}")
    
    def _cleanup_loop(self):
        """Background cleanup loop"""
        while True:
            try:
                self._cleanup_expired()
                time.sleep(self.cleanup_interval)
            except Exception as e:
                logger.error(f"Cache cleanup error: {e}")
                time.sleep(self.cleanup_interval)
    
    def _cleanup_expired(self):
        """Clean up expired entries"""
        with self.lock:
            now = datetime.now()
            expired_keys = []
            
            for key, (data, timestamp, *rest) in self.cache.items():
                # Check for custom TTL
                if rest and isinstance(rest[0], int):
                    ttl_seconds = rest[0]
                else:
                    ttl_seconds = self.ttl_seconds
                
                if now - timestamp >= timedelta(seconds=ttl_seconds):
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.cache[key]
                if key in self.access_times:
                    del self.access_times[key]
                self.stats["expirations"] += 1
            
            if expired_keys:
                logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")
            
            self.stats["cleanup_runs"] += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        with self.lock:
            total_requests = self.stats["total_requests"]
            hit_rate = 0
            if total_requests > 0:
                hit_rate = (self.stats["hits"] / total_requests) * 100
            
            return {
                "size": len(self.cache),
                "max_size": self.max_size,
                "hit_rate_percent": round(hit_rate, 2),
                "total_requests": total_requests,
                "cache_hits": self.stats["hits"],
                "cache_misses": self.stats["misses"],
                "evictions": self.stats["evictions"],
                "expirations": self.stats["expirations"],
                "cleanup_runs": self.stats["cleanup_runs"],
                "ttl_seconds": self.ttl_seconds
            }
    
    def get_keys(self) -> List[str]:
        """Get all cache keys"""
        with self.lock:
            return list(self.cache.keys())
    
    def get_size_info(self) -> Dict[str, Any]:
        """Get detailed size information"""
        with self.lock:
            return {
                "current_size": len(self.cache),
                "max_size": self.max_size,
                "utilization_percent": round((len(self.cache) / self.max_size) * 100, 2),
                "available_slots": self.max_size - len(self.cache)
            }

# Specialized cache instances for different data types
gpu_pricing_cache = FreeMemoryCache(max_size=500, ttl_seconds=1800)  # 30 minutes
provider_status_cache = FreeMemoryCache(max_size=100, ttl_seconds=300)  # 5 minutes
user_quota_cache = FreeMemoryCache(max_size=1000, ttl_seconds=3600)  # 1 hour
api_response_cache = FreeMemoryCache(max_size=200, ttl_seconds=600)   # 10 minutes

# Decorator for automatic memory caching
def memory_cache(ttl_seconds: int = 3600, max_size: int = 128):
    """Decorator for automatic memory caching"""
    def decorator(func):
        # Create a cache for this function
        cache = FreeMemoryCache(max_size=max_size, ttl_seconds=ttl_seconds)
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Generate cache key
            key_parts = [func.__name__]
            key_parts.extend(str(arg) for arg in args)
            key_parts.extend(f"{k}={v}" for k, v in sorted(kwargs.items()))
            cache_key = ":".join(key_parts)
            
            # Try to get from cache
            cached_result = cache.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Not in cache, compute result
            result = func(*args, **kwargs)
            
            # Cache the result
            cache.set(cache_key, result)
            
            return result
        
        # Add cache management methods
        wrapper.cache_clear = cache.clear
        wrapper.cache_info = cache.get_stats
        wrapper.cache_keys = cache.get_keys
        
        return wrapper
    return decorator

# LRU cache decorator for functions
@lru_cache(maxsize=500)
def get_gpu_prices_memory_cache(provider: str, gpu_type: str, region: str) -> Optional[dict]:
    """Memory cache for frequently accessed GPU pricing data"""
    # This function will be automatically cached by lru_cache
    return None

# Thread-safe function cache
class FunctionCache:
    """Thread-safe function result cache"""
    
    def __init__(self, max_size: int = 128, ttl_seconds: int = 3600):
        self.cache = FreeMemoryCache(max_size=max_size, ttl_seconds=ttl_seconds)
    
    def cached_function(self, ttl_seconds: Optional[int] = None):
        """Decorator for caching function results"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Generate cache key
                key = f"{func.__name__}:{hash((args, tuple(sorted(kwargs.items())))}"
                
                # Try cache
                result = self.cache.get(key)
                if result is not None:
                    return result
                
                # Compute and cache
                result = func(*args, **kwargs)
                self.cache.set(key, result, ttl_seconds)
                
                return result
            
            return wrapper
        return decorator

# Global function cache instance
function_cache = FunctionCache()

# Example usage decorators
@function_cache.cached_function(ttl_seconds=1800)
def get_gpu_pricing_cached(provider: str, gpu_type: str, region: str) -> dict:
    """Example cached GPU pricing function"""
    # This would make an actual API call
    return {"provider": provider, "gpu_type": gpu_type, "price": 4.06, "region": region}

@memory_cache(ttl_seconds=300, max_size=100)
def get_provider_status_cached(provider: str) -> dict:
    """Example cached provider status function"""
    # This would check provider status
    return {"provider": provider, "status": "healthy", "last_check": datetime.now().isoformat()}

class CacheManager:
    """Central cache manager for all cache instances"""
    
    def __init__(self):
        self.caches = {
            "gpu_pricing": gpu_pricing_cache,
            "provider_status": provider_status_cache,
            "user_quota": user_quota_cache,
            "api_response": api_response_cache
        }
    
    def get_cache(self, cache_name: str) -> Optional[FreeMemoryCache]:
        """Get cache instance by name"""
        return self.caches.get(cache_name)
    
    def get_all_stats(self) -> Dict[str, Any]:
        """Get statistics for all caches"""
        stats = {}
        for name, cache in self.caches.items():
            stats[name] = cache.get_stats()
        return stats
    
    def clear_all(self):
        """Clear all caches"""
        for cache in self.caches.values():
            cache.clear()
        logger.info("All caches cleared")
    
    def cleanup_all(self):
        """Force cleanup of all caches"""
        for cache in self.caches.values():
            cache._cleanup_expired()
        logger.info("All caches cleaned up")

# Global cache manager
cache_manager = CacheManager()

if __name__ == "__main__":
    # Test the memory cache
    print("Testing Free Memory Cache...")
    
    # Test basic operations
    cache = FreeMemoryCache(max_size=10, ttl_seconds=5)
    
    # Test set/get
    cache.set("key1", "value1")
    assert cache.get("key1") == "value1"
    print("✅ Basic set/get works")
    
    # Test TTL
    cache.set("key2", "value2", ttl_seconds=1)
    time.sleep(2)
    assert cache.get("key2") is None
    print("✅ TTL expiration works")
    
    # Test LRU eviction
    for i in range(15):
        cache.set(f"key{i}", f"value{i}")
    
    assert len(cache.cache) <= 10
    print("✅ LRU eviction works")
    
    # Test stats
    stats = cache.get_stats()
    print(f"Cache stats: {stats}")
    
    # Test function cache
    @function_cache.cached_function(ttl_seconds=10)
    def expensive_function(x: int) -> int:
        time.sleep(0.1)  # Simulate expensive operation
        return x * 2
    
    # First call (slow)
    start = time.time()
    result1 = expensive_function(5)
    first_call_time = time.time() - start
    
    # Second call (fast, from cache)
    start = time.time()
    result2 = expensive_function(5)
    second_call_time = time.time() - start
    
    assert result1 == result2 == 10
    assert second_call_time < first_call_time / 10  # Should be much faster
    print("✅ Function caching works")
    
    # Test cache manager
    all_stats = cache_manager.get_all_stats()
    print(f"All cache stats: {all_stats}")
    
    print("✅ Free Memory Cache working correctly!")
