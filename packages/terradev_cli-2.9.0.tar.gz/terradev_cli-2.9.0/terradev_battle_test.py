#!/usr/bin/env python3
"""
Terradev Complete Battle Test
Comprehensive testing of the entire Terradev platform
"""

import asyncio
import json
import time
import logging
import subprocess
import sys
import os
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import statistics
import random
import aiohttp
import yaml

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class BattleTestResult:
    """Battle test result"""
    component: str
    status: str  # PASS, FAIL, WARNING
    score: float  # 0-100
    issues_found: int
    issues_fixed: int
    response_time: float
    errors: List[str]
    details: Dict[str, Any]

class TerradevBattleTester:
    """Comprehensive Terradev platform battle tester"""
    
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        self.results: List[BattleTestResult] = []
        self.start_time = datetime.utcnow()
        
        # Test configurations
        self.test_configs = {
            "arbitrage_engine": {
                "file": "complete_arbitrage_engine_all_providers.py",
                "timeout": 30,
                "memory_limit": "512m"
            },
            "vast_ai_integration": {
                "file": "vast_ai_integration.py",
                "timeout": 30,
                "memory_limit": "256m"
            },
            "tensordock_integration": {
                "file": "tensordock_integration.py",
                "timeout": 30,
                "memory_limit": "256m"
            },
            "enhanced_arbitrage": {
                "file": "enhanced_arbitrage_engine.py",
                "timeout": 45,
                "memory_limit": "1g"
            },
            "kubernetes_connect": {
                "file": "kubernetes_connect_card.py",
                "timeout": 30,
                "memory_limit": "256m"
            }
        }
    
    async def run_complete_battle_test(self) -> Dict[str, Any]:
        """Run complete battle test of all components"""
        logger.info("🚀 STARTING TERRADEV COMPLETE BATTLE TEST")
        logger.info("=" * 80)
        logger.info(f"Project Root: {self.project_root}")
        logger.info(f"Test Start Time: {self.start_time}")
        
        # Test 1: Code Quality and Syntax
        await self._test_code_quality()
        
        # Test 2: Import Testing
        await self._test_imports()
        
        # Test 3: Component Functionality
        await self._test_component_functionality()
        
        # Test 4: Integration Testing
        await self._test_integrations()
        
        # Test 5: Performance Testing
        await self._test_performance()
        
        # Test 6: Security Testing
        await self._test_security()
        
        # Test 7: Configuration Testing
        await self._test_configurations()
        
        # Test 8: Terraform Testing
        await self._test_terraform()
        
        # Generate final report
        return await self._generate_final_report()
    
    async def _test_code_quality(self) -> None:
        """Test code quality and syntax"""
        logger.info("\n🔍 TEST 1: Code Quality and Syntax")
        logger.info("-" * 50)
        
        python_files = list(self.project_root.rglob("*.py"))
        
        syntax_errors = []
        style_issues = []
        complexity_issues = []
        
        for file_path in python_files[:20]:  # Test first 20 files
            try:
                # Test syntax
                result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# subprocess.run([
                    sys.executable, "-m", "py_compile", str(file_path)
                ], capture_output=True, text=True, timeout=10)
                
                if result.returncode != 0:
                    syntax_errors.append(f"{file_path}: {result.stderr}")
                
                # Test style (basic)
                with open(file_path, 'r') as f:
                    content = f.read()
                    
                    # Check for common issues
                    line_count = len(content.split('\n'))
                    if line_count > 500:
                        complexity_issues.append(f"{file_path}: Too many lines ({line_count})")
                    
                    if content.count('import *') > 0:
                        style_issues.append(f"{file_path}: Uses wildcard imports")
                    
                    if content.count('print(') > 10:
                        style_issues.append(f"{file_path}: Too many print statements")
                
            except Exception as e:
                syntax_errors.append(f"{file_path}: {str(e)}")
        
        score = max(0, 100 - (len(syntax_errors) * 10) - (len(style_issues) * 2) - (len(complexity_issues) * 1))
        
        result = BattleTestResult(
            component="Code Quality",
            status="PASS" if score >= 80 else "FAIL",
            score=score,
            issues_found=len(syntax_errors) + len(style_issues) + len(complexity_issues),
            issues_fixed=0,
            response_time=0.0,
            errors=syntax_errors + style_issues + complexity_issues,
            details={
                "files_tested": len(python_files[:20]),
                "syntax_errors": len(syntax_errors),
                "style_issues": len(style_issues),
                "complexity_issues": len(complexity_issues)
            }
        )
        
        self.results.append(result)
        
        logger.info(f"📊 Code Quality Score: {score:.1f}/100")
        logger.info(f"   Files Tested: {len(python_files[:20])}")
        logger.info(f"   Syntax Errors: {len(syntax_errors)}")
        logger.info(f"   Style Issues: {len(style_issues)}")
        logger.info(f"   Complexity Issues: {len(complexity_issues)}")
    
    async def _test_imports(self) -> None:
        """Test module imports"""
        logger.info("\n📦 TEST 2: Import Testing")
        logger.info("-" * 50)
        
        import_errors = []
        import_success = []
        
        test_modules = [
            "complete_arbitrage_engine_all_providers",
            "vast_ai_integration", 
            "tensordock_integration",
            "enhanced_arbitrage_engine",
            "kubernetes_connect_card"
        ]
        
        for module_name in test_modules:
            try:
                # Try to import the module
                sys.path.insert(0, str(self.project_root))
                
                if module_name == "complete_arbitrage_engine_all_providers":
                    import complete_arbitrage_engine_all_providers
                    import_success.append(module_name)
                elif module_name == "vast_ai_integration":
                    import vast_ai_integration
                    import_success.append(module_name)
                elif module_name == "tensordock_integration":
                    import tensordock_integration
                    import_success.append(module_name)
                elif module_name == "enhanced_arbitrage_engine":
                    import enhanced_arbitrage_engine
                    import_success.append(module_name)
                elif module_name == "kubernetes_connect_card":
                    import kubernetes_connect_card
                    import_success.append(module_name)
                
                logger.info(f"✅ Successfully imported: {module_name}")
                
            except Exception as e:
                import_errors.append(f"{module_name}: {str(e)}")
                logger.error(f"❌ Import failed: {module_name} - {e}")
        
        score = (len(import_success) / len(test_modules)) * 100
        
        result = BattleTestResult(
            component="Import Testing",
            status="PASS" if score >= 80 else "FAIL",
            score=score,
            issues_found=len(import_errors),
            issues_fixed=0,
            response_time=0.0,
            errors=import_errors,
            details={
                "modules_tested": len(test_modules),
                "successful_imports": len(import_success),
                "failed_imports": len(import_errors)
            }
        )
        
        self.results.append(result)
        
        logger.info(f"📊 Import Testing Score: {score:.1f}/100")
        logger.info(f"   Modules Tested: {len(test_modules)}")
        logger.info(f"   Successful: {len(import_success)}")
        logger.info(f"   Failed: {len(import_errors)}")
    
    async def _test_component_functionality(self) -> None:
        """Test individual component functionality"""
        logger.info("\n⚙️ TEST 3: Component Functionality")
        logger.info("-" * 50)
        
        for component, config in self.test_configs.items():
            logger.info(f"🔧 Testing {component}...")
            
            start_time = time.time()
            errors = []
            
            try:
                # Test component execution
                file_path = self.project_root / config["file"]
                
                if not file_path.exists():
                    errors.append(f"File not found: {config['file']}")
                    continue
                
                # Run component with timeout
                process = await asyncio.create_subprocess_exec(
                    sys.executable, str(file_path),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(self.project_root)
                )
                
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(), 
                        timeout=config["timeout"]
                    )
                    
                    response_time = time.time() - start_time
                    
                    if process.returncode == 0:
                        logger.info(f"✅ {component}: PASSED ({response_time:.2f}s)")
                        score = 100
                    else:
                        errors.append(f"Exit code {process.returncode}: {stderr.decode()}")
                        score = max(0, 50 - len(errors) * 10)
                        logger.warning(f"⚠️ {component}: ISSUES ({response_time:.2f}s)")
                
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
                    errors.append(f"Timeout after {config['timeout']}s")
                    score = 25
                    logger.error(f"❌ {component}: TIMEOUT")
                
            except Exception as e:
                errors.append(str(e))
                score = 0
                logger.error(f"❌ {component}: ERROR - {e}")
            
            result = BattleTestResult(
                component=component,
                status="PASS" if score >= 80 else "FAIL",
                score=score,
                issues_found=len(errors),
                issues_fixed=0,
                response_time=response_time,
                errors=errors,
                details={"timeout": config["timeout"], "memory_limit": config["memory_limit"]}
            )
            
            self.results.append(result)
    
    async def _test_integrations(self) -> None:
        """Test integrations between components"""
        logger.info("\n🔗 TEST 4: Integration Testing")
        logger.info("-" * 50)
        
        integration_tests = [
            {
                "name": "Arbitrage Engine + Vast.AI",
                "test": self._test_arbitrage_vast_integration
            },
            {
                "name": "Arbitrage Engine + TensorDock", 
                "test": self._test_arbitrage_tensordock_integration
            },
        ]
        
        for integration_test in integration_tests:
            logger.info(f"🔗 Testing {integration_test['name']}...")
            
            start_time = time.time()
            
            try:
                score, errors = await integration_test["test"]()
                response_time = time.time() - start_time
                
                if score >= 80:
                    logger.info(f"✅ {integration_test['name']}: PASSED ({response_time:.2f}s)")
                else:
                    logger.warning(f"⚠️ {integration_test['name']}: ISSUES ({response_time:.2f}s)")
                
            except Exception as e:
                score = 0
                errors = [str(e)]
                response_time = time.time() - start_time
                logger.error(f"❌ {integration_test['name']}: ERROR - {e}")
            
            result = BattleTestResult(
                component=integration_test["name"],
                status="PASS" if score >= 80 else "FAIL",
                score=score,
                issues_found=len(errors),
                issues_fixed=0,
                response_time=response_time,
                errors=errors,
                details={}
            )
            
            self.results.append(result)
    
    async def _test_arbitrage_vast_integration(self) -> tuple[float, List[str]]:
        """Test arbitrage engine + Vast.AI integration"""
        errors = []
        
        try:
            # Test if both modules can be imported together
            sys.path.insert(0, str(self.project_root))
            import complete_arbitrage_engine_all_providers
            import vast_ai_integration
            
            # Test basic functionality
            if hasattr(complete_arbitrage_engine_all_providers, 'ArbitrageEngine'):
                if hasattr(vast_ai_integration, 'VastArbitrageIntegration'):
                    return 90, []
                else:
                    errors.append("VastArbitrageIntegration class not found")
            else:
                errors.append("ArbitrageEngine class not found")
                
        except Exception as e:
            errors.append(str(e))
        
        return max(0, 90 - len(errors) * 10), errors
    
    async def _test_arbitrage_tensordock_integration(self) -> tuple[float, List[str]]:
        """Test arbitrage engine + TensorDock integration"""
        errors = []
        
        try:
            # Test if both modules can be imported together
            sys.path.insert(0, str(self.project_root))
            import complete_arbitrage_engine_all_providers
            import tensordock_integration
            
            # Test basic functionality
            if hasattr(complete_arbitrage_engine_all_providers, 'ArbitrageEngine'):
                if hasattr(tensordock_integration, 'TensorDockManager'):
                    return 90, []
                else:
                    errors.append("TensorDockManager class not found")
            else:
                errors.append("ArbitrageEngine class not found")
                
        except Exception as e:
            errors.append(str(e))
        
        return max(0, 90 - len(errors) * 10), errors
    
    async def _test_performance(self) -> None:
        """Test performance characteristics"""
        logger.info("\n⚡ TEST 5: Performance Testing")
        logger.info("-" * 50)
        
        performance_tests = [
            {
                "name": "Import Speed",
                "test": self._test_import_speed
            },
            {
                "name": "Memory Usage",
                "test": self._test_memory_usage
            },
            {
                "name": "Response Time",
                "test": self._test_response_time
            }
        ]
        
        for perf_test in performance_tests:
            logger.info(f"⚡ Testing {perf_test['name']}...")
            
            start_time = time.time()
            
            try:
                score, errors = await perf_test["test"]()
                response_time = time.time() - start_time
                
                if score >= 80:
                    logger.info(f"✅ {perf_test['name']}: PASSED ({response_time:.2f}s)")
                else:
                    logger.warning(f"⚠️ {perf_test['name']}: ISSUES ({response_time:.2f}s)")
                
            except Exception as e:
                score = 0
                errors = [str(e)]
                response_time = time.time() - start_time
                logger.error(f"❌ {perf_test['name']}: ERROR - {e}")
            
            result = BattleTestResult(
                component=perf_test["name"],
                status="PASS" if score >= 80 else "FAIL",
                score=score,
                issues_found=len(errors),
                issues_fixed=0,
                response_time=response_time,
                errors=errors,
                details={}
            )
            
            self.results.append(result)
    
    async def _test_import_speed(self) -> tuple[float, List[str]]:
        """Test import speed"""
        errors = []
        
        try:
            start_time = time.time()
            
            # Test importing main modules
            sys.path.insert(0, str(self.project_root))
            
            modules_to_import = [
                "complete_arbitrage_engine_all_providers",
                "vast_ai_integration",
                "tensordock_integration"
            ]
            
            for module_name in modules_to_import:
                if module_name == "complete_arbitrage_engine_all_providers":
                    import complete_arbitrage_engine_all_providers
                elif module_name == "vast_ai_integration":
                    import vast_ai_integration
                elif module_name == "tensordock_integration":
                    import tensordock_integration
            
            import_time = time.time() - start_time
            
            if import_time < 5.0:
                return 100, []
            elif import_time < 10.0:
                return 80, []
            else:
                errors.append(f"Import too slow: {import_time:.2f}s")
                return max(0, 80 - (import_time - 10) * 5), errors
                
        except Exception as e:
            errors.append(str(e))
            return 0, errors
    
    async def _test_memory_usage(self) -> tuple[float, List[str]]:
        """Test memory usage"""
        errors = []
        
        try:
            import psutil
            import os
            
            process = psutil.Process(os.getpid())
            memory_before = process.memory_info().rss / 1024 / 1024  # MB
            
            # Import and instantiate some classes
            sys.path.insert(0, str(self.project_root))
            
            try:
                import complete_arbitrage_engine_all_providers
                # Try to create an instance (if possible)
                memory_after = process.memory_info().rss / 1024 / 1024  # MB
                memory_increase = memory_after - memory_before
                
                if memory_increase < 100:  # Less than 100MB increase
                    return 100, []
                elif memory_increase < 200:
                    return 80, []
                else:
                    errors.append(f"High memory usage: {memory_increase:.1f}MB")
                    return max(0, 80 - (memory_increase - 200) * 0.5), errors
                    
            except Exception as e:
                # If we can't instantiate, just check import memory
                return 90, []
                
        except ImportError:
            # psutil not available, skip test
            return 85, ["psutil not available for memory testing"]
        except Exception as e:
            errors.append(str(e))
            return 0, errors
    
    async def _test_response_time(self) -> tuple[float, List[str]]:
        """Test response time of key operations"""
        errors = []
        
        try:
            # Test file reading speed
            start_time = time.time()
            
            test_files = [
                "complete_arbitrage_engine_all_providers.py",
                "vast_ai_integration.py",
                "tensordock_integration.py"
            ]
            
            for file_name in test_files:
                file_path = self.project_root / file_name
                if file_path.exists():
                    with open(file_path, 'r') as f:
                        content = f.read()
                        # Simulate some processing
                        len(content)
            
            read_time = time.time() - start_time
            
            if read_time < 1.0:
                return 100, []
            elif read_time < 2.0:
                return 80, []
            else:
                errors.append(f"Slow file reading: {read_time:.2f}s")
                return max(0, 80 - (read_time - 2) * 20), errors
                
        except Exception as e:
            errors.append(str(e))
            return 0, errors
    
    async def _test_security(self) -> None:
        """Test security aspects"""
        logger.info("\n🔒 TEST 6: Security Testing")
        logger.info("-" * 50)
        
        security_issues = []
        
        # Check for hardcoded secrets
        python_files = list(self.project_root.rglob("*.py"))
        
        for file_path in python_files[:10]:  # Check first 10 files
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                
                # Check for potential secrets
                secret_patterns = [
                    "password",
                    "api_key",
                    "secret",
                    "token",
                    "credential"
                ]
                
                for pattern in secret_patterns:
                    if pattern in content.lower() and "=" in content:
                        # Check if it's a hardcoded value
                        lines = content.split('\n')
                        for line_num, line in enumerate(lines, 1):
                            if pattern in line.lower() and "=" in line and not line.strip().startswith("#"):
                                if any(char in line for char in ['"', "'"]):
                                    security_issues.append(f"{file_path}:{line_num} - Potential hardcoded {pattern}")
                
            except Exception as e:
                security_issues.append(f"Error checking {file_path}: {str(e)}")
        
        # Check for insecure imports
        insecure_imports = ["pickle", "eval", "exec"]
        for file_path in python_files[:10]:
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                
                for insecure in insecure_imports:
                    if f"import {insecure}" in content or f"from {insecure}" in content:
                        security_issues.append(f"{file_path} - Uses insecure import: {insecure}")
                
            except Exception as e:
                pass
        
        score = max(0, 100 - len(security_issues) * 10)
        
        result = BattleTestResult(
            component="Security",
            status="PASS" if score >= 80 else "FAIL",
            score=score,
            issues_found=len(security_issues),
            issues_fixed=0,
            response_time=0.0,
            errors=security_issues,
            details={"files_checked": len(python_files[:10])}
        )
        
        self.results.append(result)
        
        logger.info(f"📊 Security Score: {score:.1f}/100")
        logger.info(f"   Security Issues: {len(security_issues)}")
    
    async def _test_configurations(self) -> None:
        """Test configuration files"""
        logger.info("\n⚙️ TEST 7: Configuration Testing")
        logger.info("-" * 50)
        
        config_files = [
            "terraform/main.tf",
            "terraform/outputs.tf",
            "terraform/variables.tf",
            "requirements.txt",
            ".env.template"
        ]
        
        config_issues = []
        config_success = []
        
        for config_file in config_files:
            file_path = self.project_root / config_file
            
            if file_path.exists():
                try:
                    if config_file.endswith(".tf"):
                        # Test Terraform syntax
                        result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# subprocess.run([
                            "terraform", "fmt", "-check", str(file_path)
                        ], capture_output=True, text=True, timeout=10, cwd=str(file_path.parent))
                        
                        if result.returncode == 0:
                            config_success.append(config_file)
                        else:
                            config_issues.append(f"{config_file}: Terraform syntax error")
                    
                    elif config_file.endswith(".txt"):
                        # Test requirements format
                        with open(file_path, 'r') as f:
                            content = f.read()
                        
                        if content.strip():
                            config_success.append(config_file)
                        else:
                            config_issues.append(f"{config_file}: Empty file")
                    
                    elif config_file.endswith(".template"):
                        # Check template structure
                        with open(file_path, 'r') as f:
                            content = f.read()
                        
                        if "VARIABLE" in content or "CONFIG" in content:
                            config_success.append(config_file)
                        else:
                            config_issues.append(f"{config_file}: Invalid template")
                
                except Exception as e:
                    config_issues.append(f"{config_file}: {str(e)}")
            else:
                config_issues.append(f"{config_file}: File not found")
        
        score = (len(config_success) / len(config_files)) * 100
        
        result = BattleTestResult(
            component="Configuration",
            status="PASS" if score >= 80 else "FAIL",
            score=score,
            issues_found=len(config_issues),
            issues_fixed=0,
            response_time=0.0,
            errors=config_issues,
            details={
                "files_tested": len(config_files),
                "valid_configs": len(config_success),
                "invalid_configs": len(config_issues)
            }
        )
        
        self.results.append(result)
        
        logger.info(f"📊 Configuration Score: {score:.1f}/100")
        logger.info(f"   Files Tested: {len(config_files)}")
        logger.info(f"   Valid: {len(config_success)}")
        logger.info(f"   Invalid: {len(config_issues)}")
    
    async def _test_terraform(self) -> None:
        """Test Terraform configuration"""
        logger.info("\n🏗️ TEST 8: Terraform Testing")
        logger.info("-" * 50)
        
        terraform_dir = self.project_root / "infrastructure" / "terraform"
        
        if not terraform_dir.exists():
            result = BattleTestResult(
                component="Terraform",
                status="FAIL",
                score=0,
                issues_found=1,
                issues_fixed=0,
                response_time=0.0,
                errors=["Terraform directory not found"],
                details={}
            )
            self.results.append(result)
            return
        
        terraform_issues = []
        
        try:
            # Test terraform init
            logger.info("🔧 Testing terraform init...")
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# subprocess.run([
                "terraform", "init"
            ], capture_output=True, text=True, timeout=60, cwd=str(terraform_dir))
            
            if result.returncode != 0:
                terraform_issues.append(f"terraform init failed: {result.stderr}")
            else:
                logger.info("✅ terraform init: PASSED")
                
                # Test terraform validate
                logger.info("🔧 Testing terraform validate...")
                result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# subprocess.run([
                    "terraform", "validate"
                ], capture_output=True, text=True, timeout=30, cwd=str(terraform_dir))
                
                if result.returncode != 0:
                    terraform_issues.append(f"terraform validate failed: {result.stderr}")
                else:
                    logger.info("✅ terraform validate: PASSED")
                    
                    # Test terraform plan (dry run)
                    logger.info("🔧 Testing terraform plan...")
                    result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# subprocess.run([
                        "terraform", "plan", "-detailed-exitcode"
                    ], capture_output=True, text=True, timeout=120, cwd=str(terraform_dir))
                    
                    if result.returncode not in [0, 2]:  # 0 = no changes, 2 = changes detected
                        terraform_issues.append(f"terraform plan failed: {result.stderr}")
                    else:
                        logger.info("✅ terraform plan: PASSED")
        
        except subprocess.TimeoutExpired:
            terraform_issues.append("Terraform command timeout")
        except Exception as e:
            terraform_issues.append(f"Terraform testing error: {str(e)}")
        
        score = max(0, 100 - len(terraform_issues) * 20)
        
        result = BattleTestResult(
            component="Terraform",
            status="PASS" if score >= 80 else "FAIL",
            score=score,
            issues_found=len(terraform_issues),
            issues_fixed=0,
            response_time=0.0,
            errors=terraform_issues,
            details={}
        )
        
        self.results.append(result)
        
        logger.info(f"📊 Terraform Score: {score:.1f}/100")
        logger.info(f"   Issues: {len(terraform_issues)}")
    
    async def _generate_final_report(self) -> Dict[str, Any]:
        """Generate final battle test report"""
        end_time = datetime.utcnow()
        total_duration = (end_time - self.start_time).total_seconds()
        
        # Calculate overall metrics
        total_tests = len(self.results)
        passed_tests = sum(1 for r in self.results if r.status == "PASS")
        failed_tests = total_tests - passed_tests
        
        total_score = sum(r.score for r in self.results) / total_tests if total_tests > 0 else 0
        total_issues = sum(r.issues_found for r in self.results)
        total_errors = sum(len(r.errors) for r in self.results)
        
        # Determine overall status
        if total_score >= 90:
            overall_status = "EXCELLENT"
        elif total_score >= 80:
            overall_status = "GOOD"
        elif total_score >= 70:
            overall_status = "FAIR"
        else:
            overall_status = "POOR"
        
        # Generate detailed results
        detailed_results = []
        for result in self.results:
            detailed_results.append({
                "component": result.component,
                "status": result.status,
                "score": result.score,
                "issues_found": result.issues_found,
                "response_time": result.response_time,
                "errors": result.errors[:5]  # Limit errors shown
            })
        
        # Create summary
        summary = {
            "overall_status": overall_status,
            "total_score": total_score,
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "total_issues": total_issues,
            "total_errors": total_errors,
            "duration_seconds": total_duration,
            "start_time": self.start_time.isoformat(),
            "end_time": end_time.isoformat()
        }
        
        # Save results
        report_data = {
            "summary": summary,
            "detailed_results": detailed_results
        }
        
        report_file = self.project_root / "terradev_battle_test_report.json"
        with open(report_file, 'w') as f:
            json.dump(report_data, f, indent=2, default=str)
        
        # Log summary
        logger.info("\n" + "=" * 80)
        logger.info("🏁 TERRADEV BATTLE TEST COMPLETE")
        logger.info("=" * 80)
        logger.info(f"📊 Overall Status: {overall_status}")
        logger.info(f"🎯 Total Score: {total_score:.1f}/100")
        logger.info(f"📋 Tests Run: {total_tests}")
        logger.info(f"✅ Passed: {passed_tests}")
        logger.info(f"❌ Failed: {failed_tests}")
        logger.info(f"⚠️ Issues Found: {total_issues}")
        logger.info(f"🐛 Total Errors: {total_errors}")
        logger.info(f"⏱️ Duration: {total_duration:.1f}s")
        logger.info(f"📄 Report saved to: {report_file}")
        
        # Component breakdown
        logger.info("\n📈 Component Breakdown:")
        for result in self.results:
            status_emoji = "✅" if result.status == "PASS" else "❌"
            logger.info(f"   {status_emoji} {result.component}: {result.score:.1f}/100 ({result.issues_found} issues)")
        
        # Recommendations
        logger.info(f"\n💡 Recommendations:")
        if overall_status == "EXCELLENT":
            logger.info("   🎉 Excellent! System is production-ready")
        elif overall_status == "GOOD":
            logger.info("   👍 Good! Minor improvements needed")
        elif overall_status == "FAIR":
            logger.info("   ⚠️ Fair! Significant improvements needed")
        else:
            logger.info("   🚨 Poor! Major issues must be addressed")
        
        # Priority issues
        failed_components = [r for r in self.results if r.status == "FAIL"]
        if failed_components:
            logger.info(f"\n🚨 Priority Issues:")
            for component in failed_components[:3]:
                logger.info(f"   - {component.component}: {len(component.errors)} issues")
                for error in component.errors[:2]:
                    logger.info(f"     * {error}")
        
        return report_data

async def main():
    """Main battle test function"""
    project_root = "/Users/theowolfenden/CascadeProjects/Terradev"
    
    tester = TerradevBattleTester(project_root)
    results = await tester.run_complete_battle_test()
    
    return results

if __name__ == "__main__":
    asyncio.run(main())
