import logging

#!/usr/bin/env python3
"""
Smart Cancellation with Explicit Cost Accounting
Prevents waste by calculating exact costs of cache misses and warm pools
"""

import json
import sys
import os
from datetime import datetime

# TODO: REFACTOR - execute_smart_cancellation() is 117 lines long (should be <50)
# Consider breaking into smaller, focused functions
def execute_smart_cancellation():
    """Execute smart cancellation with cost accounting"""
    
    content_hash = os.getenv('CONTENT_HASH')
    race_result_json = os.getenv('RACE_RESULT')
    cost_config_json = os.getenv('COST_CONFIG')
    
    if not all([content_hash, race_result_json, cost_config_json]):
        logging.info("❌ Missing required environment variables")
        return
    
    try:
        race_result = json.loads(race_result_json)
        cost_config = json.loads(cost_config_json)
        
        logging.info(f"🚀 Smart Cancellation with Cost Accounting")
        logging.info(f"Content Hash: {content_hash}")
        logging.info(f"Winner: {race_result['winner']}")
        
        # Calculate cancellation costs for losers
        losers = [p # TODO: OPTIMIZATION - Use more efficient pattern for .keys() iteration
# ('p', "race_result['all_providers']") if p != race_result['winner']]
        
        cancellation_decisions = {}
        total_waste_prevented = 0.0
        
        for loser in losers:
            loser_info = race_result['all_providers'][loser]
            costs = cost_config[loser]
            
            # Calculate waste if we keep this loser running
            hourly_waste = costs['storage_cost_per_gb'] * 100  # 100GB baseline
            monthly_waste = hourly_waste * 24 * 30
            
            # Calculate cancellation cost (minimum billing periods)
            if loser in ['aws', 'gcp', 'azure']:
                # Traditional clouds: 60s minimum billing
                cancellation_cost = costs['storage_cost_per_gb'] * 100 * (60/3600)
            else:
                # Specialist providers: 1s minimum billing
                cancellation_cost = costs['storage_cost_per_gb'] * 100 * (1/3600)
            
            # Decision: cancel if waste > cancellation cost
            should_cancel = monthly_waste > cancellation_cost * 100  # 100x threshold
            
            if should_cancel:
                waste_prevented = monthly_waste - cancellation_cost
                total_waste_prevented += waste_prevented
                
                cancellation_decisions[loser] = {
                    'action': 'CANCEL',
                    'reason': f'Monthly waste ${monthly_waste:.2f} > cancellation cost ${cancellation_cost:.2f}',
                    'waste_prevented': waste_prevented,
                    'cancellation_cost': cancellation_cost,
                    'billing_period': '60s' if loser in ['aws', 'gcp', 'azure'] else '1s'
                }
            else:
                # Keep as backup - too close to winner
                cancellation_decisions[loser] = {
                    'action': 'KEEP_AS_BACKUP',
                    'reason': f'Waste ${monthly_waste:.2f} not significant enough',
                    'waste_prevented': 0.0,
                    'cancellation_cost': cancellation_cost,
                    'billing_period': '60s' if loser in ['aws', 'gcp', 'azure'] else '1s'
                }
        
        # Execute cancellations
        executed_cancellations = []
        
        for loser, decision in cancellation_decisions.items():
            if decision['action'] == 'CANCEL':
                logging.info(f"🗑️  Cancelling {loser}: {decision['reason']}")
                
                # Simulate cancellation API call
                cancellation_result = {
                    'provider': loser,
                    'status': 'cancelled',
                    'timestamp': datetime.now().isoformat(),
                    'waste_prevented': decision['waste_prevented'],
                    'cancellation_cost': decision['cancellation_cost']
                }
                
                executed_cancellations.append(cancellation_result)
            else:
                logging.info(f"✅ Keeping {loser} as backup: {decision['reason']}")
        
        # Summary
        summary = {
            'timestamp': datetime.now().isoformat(),
            'content_hash': content_hash,
            'winner': race_result['winner'],
            'cancellation_decisions': cancellation_decisions,
            'executed_cancellations': executed_cancellations,
            'total_waste_prevented': total_waste_prevented,
            'total_cancellation_costs': sum(d['cancellation_cost'] for d in executed_cancellations),
            'net_savings': total_waste_prevented - sum(d['cancellation_cost'] for d in executed_cancellations),
            'cost_accounting_summary': {
                'providers_evaluated': len(losers) + 1,
                'providers_cancelled': len(executed_cancellations),
                'providers_kept': len([d for d in cancellation_decisions.values() if d['action'] == 'KEEP_AS_BACKUP']),
                'average_waste_prevented': total_waste_prevented / len(executed_cancellations) if executed_cancellations else 0,
                'roi_percent': (total_waste_prevented / sum(d['cancellation_cost'] for d in executed_cancellations) * 100) if executed_cancellations else 0
            }
        }
        
        logging.info(f"\n🏆 Smart Cancellation Summary:")
        logging.info(f"✅ Waste Prevented: ${summary['total_waste_prevented']:.2f}/month")
        logging.info(f"💰 Cancellation Costs: ${summary['total_cancellation_costs']:.2f}")
        logging.info(f"🚀 Net Savings: ${summary['net_savings']:.2f}/month")
        logging.info(f"📊 ROI: {summary['cost_accounting_summary']['roi_percent']:.1f}%")
        
        # Save summary to file
        with open(f'/tmp/cancellation_summary_{content_hash[:8]}.json', 'w') as f:
            json.dump(summary, f, indent=2)
        
        logging.info(f"💾 Summary saved to: /tmp/cancellation_summary_{content_hash[:8]}.json")
        
    except Exception as e:
        logging.info(f"❌ Smart cancellation failed: {e}")

if __name__ == "__main__":
    execute_smart_cancellation()
