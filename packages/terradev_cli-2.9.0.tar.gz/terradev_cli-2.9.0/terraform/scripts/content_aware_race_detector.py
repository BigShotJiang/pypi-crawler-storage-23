import logging

#!/usr/bin/env python3
"""
Content-Aware Race Detector with Cost Accounting
Selects optimal provider based on content hash, warm pools, and explicit costs
"""

import json
import sys
import hashlib
import time
from datetime import datetime

def detect_content_aware_winner():
    """Detect winner with content-aware optimization"""
    
    # Parse input
    config = json.loads(sys.stdin.read())
    
    content_hash = config['content_hash']
    provider_mirrors = config['provider_mirrors']
    cost_accounting = config['cost_accounting']
    popular_models = config['popular_models']
    request_config = config['request_config']
    
    logging.info(f"🚀 Content-Aware Race Detection")
    logging.info(f"Content Hash: {content_hash}")
    logging.info(f"Popular Models: {len(popular_models)
    logging.info(f"Providers: {len(provider_mirrors)
    
    # Calculate scores for each provider
    provider_scores = {}
    
    for provider, mirror_config in provider_mirrors.items():
        costs = cost_accounting[provider]
        
        # Base score calculation
        score = 0.0
        
        # Cost factor (lower is better)
        total_cost = (costs['storage_cost_per_gb'] + 
                     costs['cdn_cost_per_gb'] + 
                     costs['cache_miss_cost'] + 
                     costs['warm_pool_cost'])
        score += total_cost * 10  # Weight cost heavily
        
        # Warm pool bonus
        warm_pool_bonus = mirror_config['warm_pool_size'] * 0.1
        score -= warm_pool_bonus  # Lower score is better
        
        # Content hash optimization
        if provider == 'huggingface':
            # HF: FREE storage + massive warm pools
            score -= 100  # Huge advantage
            cache_hit_rate = 0.95
        elif provider in ['runpod', 'lambda', 'coreweave']:
            # Specialist providers: good performance
            score -= 50
            cache_hit_rate = 0.85
        else:
            # Traditional clouds: higher costs
            cache_hit_rate = 0.75
        
        # Replication factor bonus
        if mirror_config['replication'] in ['multi-region', 'geo-redundant', 'global']:
            score -= 20
        
        # CDN performance
        if mirror_config['cdn_endpoint'] in ['cloudfront', 'cloudcdn', 'hf-cdn']:
            score -= 15
        
        provider_scores[provider] = {
            'score': score,
            'total_cost_per_gb': total_cost,
            'cache_hit_rate': cache_hit_rate,
            'warm_pool_size': mirror_config['warm_pool_size'],
            'replication': mirror_config['replication'],
            'cdn_endpoint': mirror_config['cdn_endpoint']
        }
    
    # Select winner (lowest score)
    winner = min(provider_scores.keys(), key=lambda p: provider_scores[p]['score'])
    winner_info = provider_scores[winner]
    
    # Calculate competitive advantage
    if winner == 'huggingface':
        competitive_advantage = "FREE unlimited storage + global CDN + 95% cache hit rate"
    elif winner in ['runpod', 'lambda', 'coreweave']:
        competitive_advantage = "Specialist GPU provider with optimized warm pools"
    else:
        competitive_advantage = "Traditional cloud with content optimization"
    
    # Calculate cost savings
    traditional_cost = sum([
        cost_accounting[p]['storage_cost_per_gb'] * 100  # 100GB baseline
        # TODO: OPTIMIZATION - Use more efficient pattern for .keys() iteration
# ('p', 'provider_mirrors')
        if p not in ['huggingface']
    ])
    
    optimized_cost = winner_info['total_cost_per_gb'] * 100
    savings_percent = ((traditional_cost - optimized_cost) / traditional_cost) * 100
    
    result = {
        'timestamp': datetime.now().isoformat(),
        'content_hash': content_hash,
        'winner': winner,
        'winner_details': winner_info,
        'all_providers': provider_scores,
        'competitive_advantage': competitive_advantage,
        'cost_analysis': {
            'traditional_monthly_cost': traditional_cost * 24 * 30,  # Monthly
            'optimized_monthly_cost': optimized_cost * 24 * 30,
            'monthly_savings': (traditional_cost - optimized_cost) * 24 * 30,
            'savings_percent': savings_percent
        },
        'content_optimization': {
            'popular_models_warmed': len(popular_models),
            'average_cache_hit_rate': winner_info['cache_hit_rate'],
            'warm_pool_efficiency': winner_info['warm_pool_size'] / 1000,
            'replication_coverage': winner_info['replication']
        },
        'race_metrics': {
            'detection_time_ms': 50,  # Simulated
            'providers_evaluated': len(provider_mirrors),
            'content_hash_matches': 1,
            'cache_hit_probability': winner_info['cache_hit_rate']
        }
    }
    
    logging.info(f"🏆 Winner: {winner}")
    logging.info(f"💰 Monthly Savings: ${result['cost_analysis']['monthly_savings']:.2f}")
    logging.info(f"🔥 Cache Hit Rate: {winner_info['cache_hit_rate']:.1%}")
    logging.info(f"🚀 Competitive Advantage: {competitive_advantage}")
    
    # Output result for Terraform
    logging.info(json.dumps(result)

if __name__ == "__main__":
    detect_content_aware_winner()
