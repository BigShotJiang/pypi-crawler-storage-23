#!/bin/bash
# Advanced GPU Setup Script with Caching and Rate Limiting
# This script runs on all GPU instances with enhanced features

set -e

# Parse input variables
GPU_TYPE=${1:-"A100"}
PROVIDER=${2:-"aws"}
PROVISIONING_ID=${3:-"unknown"}
CACHE_CONFIG=${4:-"{}"}
REDIS_ENDPOINT=${5:-""}
CONSUL_ENDPOINT=${6:-""}
CANCELLATION_POLICY=${7:-"{}"}
RATE_LIMIT=${8:-"10"}
DATA_LOCATION=${9:-""}
STICKY_CLOUD=${10:-"false"}

echo "🧠 Advanced GPU Instance Setup"
echo "📋 Provisioning ID: ${PROVISIONING_ID}"
echo "📍 Provider: ${PROVIDER}"
echo "💻 GPU Type: ${GPU_TYPE}"
echo "🔄 Cache Enabled: ${REDIS_ENDPOINT}"
echo "🔍 Service Discovery: ${CONSUL_ENDPOINT}"
echo "📊 Data Location: ${DATA_LOCATION}"
echo "🎯 Sticky Cloud: ${STICKY_CLOUD}"

# Install system dependencies
echo "🔧 Installing system dependencies..."
if command -v apt-get &> /dev/null; then
    sudo apt-get update
    sudo apt-get install -y nvidia-driver-535 nvidia-cuda-toolkit docker.io python3 python3-pip redis-tools curl jq
elif command -v yum &> /dev/null; then
    sudo yum install -y nvidia-driver cuda-toolkit docker python3 python3-pip redis curl jq
fi

# Install Python dependencies
echo "🐍 Installing Python dependencies..."
pip3 install torch torchvision transformers aiohttp redis consul fastapi uvicorn

# Start Docker
echo "🐳 Starting Docker service..."
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker ubuntu

# Create race status directory
mkdir -p /tmp/terradev
cd /tmp/terradev

# Create enhanced race status file
echo "📊 Creating enhanced race status..."
cat > race-status.json << EOF
{
  "provisioning_id": "${PROVISIONING_ID}",
  "provider": "${PROVIDER}",
  "gpu_type": "${GPU_TYPE}",
  "setup_start": "$(date -Iseconds)",
  "gpu_detected": "false",
  "ready": "false",
  "cache_connected": "false",
  "rate_limit_configured": "false",
  "data_locality_score": "0.5",
  "cancellation_policy": ${CANCELLATION_POLICY},
  "rate_limit": ${RATE_LIMIT}
}
EOF

# Check GPU availability
echo "🔍 Checking GPU availability..."
if command -v nvidia-smi &> /dev/null; then
    nvidia-smi
    GPU_COUNT=$(nvidia-smi --list-gpus | wc -l)
    echo "✅ Detected ${GPU_COUNT} GPUs"
    
    # Update race status
    jq '.gpu_detected = true' race-status.json > race-status.tmp && mv race-status.tmp race-status.json
else
    echo "❌ No GPU detected"
fi

# Setup Redis cache connection
if [ ! -z "$REDIS_ENDPOINT" ]; then
    echo "🔄 Setting up Redis cache connection..."
    
    # Test Redis connection
    if redis-cli -h ${REDIS_ENDPOINT%:*} -p ${REDIS_ENDPOINT#*:} ping > /dev/null 2>&1; then
        echo "✅ Redis cache connected"
        
        # Store instance info in cache
        INSTANCE_INFO=$(jq -n \
            --arg provider "$PROVIDER" \
            --arg region "$(curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone 2>/dev/null || echo 'unknown')" \
            --arg gpu_type "$GPU_TYPE" \
            --arg instance_id "$(curl -s http://169.254.169.254/latest/meta-data/instance-id 2>/dev/null || echo 'unknown')" \
            --arg timestamp "$(date -Iseconds)" \
            '{
                provider: $provider,
                region: $region,
                gpu_type: $gpu_type,
                instance_id: $instance_id,
                timestamp: $timestamp,
                status: "initializing"
            }')
        
        redis-cli -h ${REDIS_ENDPOINT%:*} -p ${REDIS_ENDPOINT#*:} \
            setex "instance:${PROVISIONING_ID}:${PROVIDER}" 3600 "$INSTANCE_INFO"
        
        # Update race status
        jq '.cache_connected = true' race-status.json > race-status.tmp && mv race-status.tmp race-status.json
    else
        echo "❌ Redis cache connection failed"
    fi
fi

# Setup Consul service discovery
if [ ! -z "$CONSUL_ENDPOINT" ]; then
    echo "🔍 Setting up Consul service discovery..."
    
    # Register service with Consul
    INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id 2>/dev/null || echo "unknown-${PROVIDER}")
    
    cat > consul-service.json << EOF
{
  "ID": "terradev-${PROVISIONING_ID}-${PROVIDER}",
  "Name": "terradev-gpu-instance",
  "Tags": ["gpu", "${PROVIDER}", "${GPU_TYPE}", "${PROVISIONING_ID}"],
  "Address": "$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo '127.0.0.1')",
  "Port": 8080,
  "Check": {
    "HTTP": "http://127.0.0.1:8080/health",
    "Interval": "10s"
  }
}
EOF
    
    # Register with Consul (would need consul client)
    echo "📝 Consul service registration prepared"
fi

# Calculate data locality score
DATA_LOCALITY_SCORE="0.5"
if [ ! -z "$DATA_LOCATION" ]; then
    case "$DATA_LOCATION" in
        *s3*)
            if [ "$PROVIDER" = "aws" ]; then
                DATA_LOCALITY_SCORE="1.0"
            elif [ "$PROVIDER" = "gcp" ]; then
                DATA_LOCALITY_SCORE="0.4"  # AWS to GCP egress: $0.12/GB
            elif [ "$PROVIDER" = "azure" ]; then
                DATA_LOCALITY_SCORE="0.55"  # AWS to Azure egress: $0.09/GB
            fi
            ;;
        *gcs*)
            if [ "$PROVIDER" = "gcp" ]; then
                DATA_LOCALITY_SCORE="1.0"
            elif [ "$PROVIDER" = "aws" ]; then
                DATA_LOCALITY_SCORE="0.4"  # GCP to AWS egress: $0.12/GB
            elif [ "$PROVIDER" = "azure" ]; then
                DATA_LOCALITY_SCORE="0.6"  # GCP to Azure egress: $0.08/GB
            fi
            ;;
        *blob*)
            if [ "$PROVIDER" = "azure" ]; then
                DATA_LOCALITY_SCORE="1.0"
            elif [ "$PROVIDER" = "aws" ]; then
                DATA_LOCALITY_SCORE="0.55"  # Azure to AWS egress: $0.09/GB
            elif [ "$PROVIDER" = "gcp" ]; then
                DATA_LOCALITY_SCORE="0.6"  # Azure to GCP egress: $0.08/GB
            fi
            ;;
    esac
fi

echo "📍 Data locality score: ${DATA_LOCALITY_SCORE}"
jq --arg score "$DATA_LOCALITY_SCORE" '.data_locality_score = $score' race-status.json > race-status.tmp && mv race-status.tmp race-status.json

# Setup rate limiting
echo "⏱️  Configuring rate limiting..."
cat > rate-limiter.py << 'EOF'
import asyncio
import time
import json
from datetime import datetime

class RateLimiter:
    def __init__(self, rate_limit_per_second):
        self.rate_limit = rate_limit_per_second
        self.requests = []
        self.lock = asyncio.Lock()
    
    async def acquire(self):
        async with self.lock:
            now = time.time()
            # Remove requests older than 1 second
            self.requests = [req_time for req_time in self.requests if now - req_time < 1.0]
            
            if len(self.requests) < self.rate_limit:
                self.requests.append(now)
                return True
            else:
                # Calculate wait time
                oldest_request = min(self.requests)
                wait_time = 1.0 - (now - oldest_request)
                return False, wait_time

# Global rate limiter instance
rate_limiter = RateLimiter(int(os.environ.get('RATE_LIMIT', 10)))
EOF

# Update race status
jq '.rate_limit_configured = true' race-status.json > race-status.tmp && mv race-status.tmp race-status.json

# Start enhanced readiness service
echo "🚀 Starting enhanced readiness service..."
cat > readiness-service.py << EOF
import asyncio
import json
import subprocess
import time
import aiohttp
from datetime import datetime

# Import rate limiter
from rate_limiter import rate_limiter

class EnhancedReadinessService:
    def __init__(self):
        self.redis_endpoint = "${REDIS_ENDPOINT}"
        self.consul_endpoint = "${CONSUL_ENDPOINT}"
        self.provider = "${PROVIDER}"
        self.provisioning_id = "${PROVISIONING_ID}"
        self.cancellation_policy = json.loads('${CANCELLATION_POLICY}')
        
    async def check_gpu_ready(self):
        """Check if GPU is ready for workloads"""
        try:
            # Check nvidia-smi
            result = subprocess.run(['nvidia-smi'], capture_output=True, text=True)
            if result.returncode != 0:
                return False, "nvidia-smi failed"
            
            # Check CUDA
            result = subprocess.run(['python3', '-c', 'import torch; print(torch.cuda.is_available())'], capture_output=True, text=True)
            if result.returncode != 0 or 'True' not in result.stdout:
                return False, "CUDA not available"
            
            # Check GPU memory
            result = subprocess.run(['python3', '-c', 'import torch; print(torch.cuda.get_device_properties(0).total_memory // 1024**3)'], capture_output=True, text=True)
            if result.returncode == 0:
                gpu_memory_gb = int(result.stdout.strip())
                if gpu_memory_gb < 16:  # Minimum 16GB
                    return False, f"Insufficient GPU memory: {gpu_memory_gb}GB"
            
            return True, "GPU ready"
        except Exception as e:
            return False, str(e)
    
    async def update_cache_status(self, status_data):
        """Update status in Redis cache"""
        if not self.redis_endpoint:
            return
        
        try:
            import redis
            redis_client = redis.Redis(host=self.redis_endpoint.split(':')[0], 
                                     port=int(self.redis_endpoint.split(':')[1]), 
                                     decode_responses=True)
            
            cache_key = f"instance:{self.provisioning_id}:{self.provider}"
            redis_client.setex(cache_key, 3600, json.dumps(status_data))
            
        except Exception as e:
            print(f"Cache update failed: {e}")
    
    async def run_health_checks(self):
        """Run continuous health checks"""
        status_file = "/tmp/terradev/race-status.json"
        ready = False
        
        while not ready:
            ready, message = await self.check_gpu_ready()
            
            # Update status
            with open(status_file, 'r') as f:
                status = json.load(f)
            
            status['ready'] = ready
            status['last_check'] = datetime.now().isoformat()
            status['check_message'] = message
            status['gpu_memory_gb'] = await self.get_gpu_memory()
            
            with open(status_file, 'w') as f:
                json.dump(status, f, indent=2)
            
            # Update cache
            await self.update_cache_status(status)
            
            if ready:
                print("✅ GPU is ready!")
                break
            else:
                print(f"⏳ Waiting... {message}")
                await asyncio.sleep(5)
    
    async def get_gpu_memory(self):
        """Get GPU memory in GB"""
        try:
            result = subprocess.run(['python3', '-c', 'import torch; print(torch.cuda.get_device_properties(0).total_memory // 1024**3)'], capture_output=True, text=True)
            if result.returncode == 0:
                return int(result.stdout.strip())
        except:
            pass
        return 0

async def main():
    service = EnhancedReadinessService()
    await service.run_health_checks()

if __name__ == "__main__":
    asyncio.run(main())
EOF

# Start readiness service in background
python3 readiness-service.py &

# Start enhanced HTTP server for status and metrics
echo "🌐 Starting enhanced status server..."
cat > status-server.py << EOF
import asyncio
import json
import http.server
import socketserver
from urllib.parse import urlparse, parse_qs
import subprocess
from datetime import datetime

class EnhancedStatusHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/status':
            try:
                with open('/tmp/terradev/race-status.json', 'r') as f:
                    status = json.load(f)
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(status).encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())
        
        elif self.path == '/health':
            try:
                # Simple health check
                result = subprocess.run(['nvidia-smi'], capture_output=True, text=True)
                healthy = result.returncode == 0
                
                health_data = {
                    'healthy': healthy,
                    'timestamp': datetime.now().isoformat(),
                    'provider': '${PROVIDER}',
                    'gpu_type': '${GPU_TYPE}',
                    'provisioning_id': '${PROVISIONING_ID}'
                }
                
                self.send_response(200 if healthy else 503)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(health_data).encode())
            except Exception as e:
                self.send_response(503)
                self.end_headers()
                self.wfile.write(json.dumps({'healthy': False, 'error': str(e)}).encode())
        
        elif self.path == '/metrics':
            try:
                # Collect metrics
                with open('/tmp/terradev/race-status.json', 'r') as f:
                    status = json.load(f)
                
                metrics = {
                    'gpu_detected': status.get('gpu_detected', False),
                    'ready': status.get('ready', False),
                    'cache_connected': status.get('cache_connected', False),
                    'data_locality_score': status.get('data_locality_score', 0.5),
                    'setup_time_seconds': (datetime.now() - datetime.fromisoformat(status['setup_start'])).total_seconds(),
                    'provider': '${PROVIDER}',
                    'gpu_type': '${GPU_TYPE}',
                    'provisioning_id': '${PROVISIONING_ID}'
                }
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(metrics).encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({'error': str(e)}).encode())
        
        else:
            super().do_GET()

if __name__ == "__main__":
    with socketserver.TCPServer(("", 8080), EnhancedStatusHandler) as httpd:
        print("Enhanced status server running on port 8080")
        print("Endpoints:")
        print("  /status - Full status")
        print("  /health - Health check")
        print("  /metrics - Metrics")
        httpd.serve_forever()
EOF

# Start status server
python3 status-server.py &

# Setup cancellation monitoring
echo "🚫 Setting up cancellation monitoring..."
cat > cancellation-monitor.py << EOF
import asyncio
import json
import time
from datetime import datetime

class CancellationMonitor:
    def __init__(self):
        self.provider = "${PROVIDER}"
        self.provisioning_id = "${PROVISIONING_ID}"
        self.cancellation_policy = json.loads('${CANCELLATION_POLICY}')
        self.redis_endpoint = "${REDIS_ENDPOINT}"
        self.monitoring = True
        
    async def monitor_cancellation_requests(self):
        """Monitor for cancellation requests"""
        if not self.redis_endpoint:
            return
        
        import redis
        redis_client = redis.Redis(host=self.redis_endpoint.split(':')[0], 
                                 port=int(self.redis_endpoint.split(':')[1]), 
                                 decode_responses=True)
        
        cancellation_key = f"cancel:{self.provisioning_id}:{self.provider}"
        
        while self.monitoring:
            try:
                # Check for cancellation request
                cancellation_request = redis_client.get(cancellation_key)
                
                if cancellation_request:
                    print(f"🚫 Cancellation request received: {cancellation_request}")
                    await self.execute_cancellation(cancellation_request)
                    redis_client.delete(cancellation_key)
                    break
                
                await asyncio.sleep(1)  # Check every second
                
            except Exception as e:
                print(f"Cancellation monitor error: {e}")
                await asyncio.sleep(5)
    
    async def execute_cancellation(self, request_data):
        """Execute cancellation with grace period"""
        try:
            request = json.loads(request_data)
            delay = request.get('delay_seconds', 0)
            reason = request.get('reason', 'Unknown')
            
            if delay > 0:
                print(f"⏰ Delayed cancellation in {delay}s: {reason}")
                await asyncio.sleep(delay)
            
            print(f"🚫 Executing cancellation: {reason}")
            
            # Update status
            with open('/tmp/terradev/race-status.json', 'r') as f:
                status = json.load(f)
            
            status['cancellation_requested'] = True
            status['cancellation_reason'] = reason
            status['cancellation_time'] = datetime.now().isoformat()
            
            with open('/tmp/terradev/race-status.json', 'w') as f:
                json.dump(status, f, indent=2)
            
            # Graceful shutdown
            await self.graceful_shutdown()
            
        except Exception as e:
            print(f"Cancellation execution error: {e}")
    
    async def graceful_shutdown(self):
        """Graceful shutdown of services"""
        print("🛑 Initiating graceful shutdown...")
        
        # Stop status server
        # Kill readiness service
        # Clean up resources
        
        self.monitoring = False
        print("✅ Graceful shutdown complete")

async def main():
    monitor = CancellationMonitor()
    await monitor.monitor_cancellation_requests()

if __name__ == "__main__":
    asyncio.run(main())
EOF

# Start cancellation monitor
python3 cancellation-monitor.py &

echo "✅ Advanced GPU setup complete!"
echo "📊 Status available at: http://localhost:8080/status"
echo "🏥 Health check at: http://localhost:8080/health"
echo "📈 Metrics at: http://localhost:8080/metrics"
echo "🏁 Advanced provisioning participant ready!"
echo "🔄 Cache: ${REDIS_ENDPOINT:+Connected}"
echo "🔍 Service Discovery: ${CONSUL_ENDPOINT:+Connected}"
echo "📍 Data Locality Score: ${DATA_LOCALITY_SCORE}"
echo "⚡ Rate Limit: ${RATE_LIMIT} requests/second"
