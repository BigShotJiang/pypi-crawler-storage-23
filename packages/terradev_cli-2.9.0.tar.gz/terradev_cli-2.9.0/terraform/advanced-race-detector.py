#!/usr/bin/env python3
"""
Advanced Race Detector with Caching and Rate Limiting
Handles smart winner selection, cancellation strategies, and optimization
"""

import json
import sys
import time
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
import aiohttp
import redis
import consul

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ProviderResponse:
    """Enhanced provider response with caching and rate limiting"""
    provider: str
    region: str
    gpu_type: str
    spot_price: float
    on_demand_price: float
    availability: bool
    estimated_launch_time: float
    response_time: float
    instance_id: Optional[str]
    api_name: str
    data_locality_score: float
    cache_hit: bool
    rate_limited: bool
    timestamp: datetime

@dataclass
class CancellationStrategy:
    """Intelligent cancellation strategy"""
    immediate_cancellations: List[Dict]
    delayed_cancellations: List[Dict]
    no_cancellations: List[Dict]
    cost_analysis: Dict
    waste_prevented: float

class AdvancedRaceDetector:
    """Advanced race detector with caching and rate limiting"""
    
    def __init__(self):
        self.provisioning_id = sys.argv[1] if len(sys.argv) > 1 else "unknown"
        self.gpu_type = sys.argv[2] if len(sys.argv) > 2 else "A100"
        self.timeout = int(sys.argv[7]) if len(sys.argv) > 7 else 300
        self.mode = sys.argv[8] if len(sys.argv) > 8 else "sticky_cloud"
        self.cache_enabled = sys.argv[9] == "true" if len(sys.argv) > 9 else False
        self.redis_endpoint = sys.argv[10] if len(sys.argv) > 10 else None
        self.consul_endpoint = sys.argv[11] if len(sys.argv) > 11 else None
        self.data_location = sys.argv[12] if len(sys.argv) > 12 else None
        self.sticky_cloud = sys.argv[13] == "true" if len(sys.argv) > 13 else False
        
        # Parse configuration
        self.rate_limits = json.loads(sys.argv[14]) if len(sys.argv) > 14 else {}
        self.cancellation_policies = json.loads(sys.argv[15]) if len(sys.argv) > 15 else {}
        self.egress_costs = json.loads(sys.argv[16]) if len(sys.argv) > 16 else {}
        
        # Initialize cache and service discovery
        self.redis_client = None
        self.consul_client = None
        
        if self.cache_enabled and self.redis_endpoint:
            try:
                self.redis_client = redis.Redis(host=self.redis_endpoint.split(':')[0], 
                                             port=int(self.redis_endpoint.split(':')[1]), 
                                             decode_responses=True)
                logger.info(f"✅ Connected to Redis cache")
            except Exception as e:
                logger.warning(f"⚠️  Redis connection failed: {e}")
        
        if self.consul_endpoint:
            try:
                self.consul_client = consul.Consul(host=self.consul_endpoint.split(':')[0],
                                                port=int(self.consul_endpoint.split(':')[1]))
                logger.info(f"✅ Connected to Consul service discovery")
            except Exception as e:
                logger.warning(f"⚠️  Consul connection failed: {e}")
        
        self.start_time = time.time()
        self.results = {}
        
    async def detect_advanced_race_winner(self) -> Dict:
        """Advanced race detection with caching and rate limiting"""
        logger.info(f"🧠 Starting advanced race detection for {self.provisioning_id}")
        logger.info(f"📋 Mode: {self.mode}, Cache: {self.cache_enabled}, Sticky: {self.sticky_cloud}")
        
        # Check cache first
        cache_key = f"race:{self.provisioning_id}:{self.gpu_type}:{self.mode}"
        cached_result = await self._check_cache(cache_key)
        
        if cached_result:
            logger.info(f"💾 Cache hit for {cache_key}")
            return cached_result
        
        # Provider selection based on mode
        providers = self._get_providers_for_mode()
        
        # Rate-limited parallel monitoring
        monitoring_tasks = []
        for provider in providers:
            task = asyncio.create_task(
                self._rate_limited_monitor_provider(provider)
            )
            monitoring_tasks.append(task)
        
        # Wait for first provider to be ready
        winner = None
        all_responses = []
        start_time = time.time()
        
        try:
            # Wait for first successful response
            done, pending = await asyncio.wait(
                monitoring_tasks,
                return_when=asyncio.FIRST_COMPLETED,
                timeout=self.timeout
            )
            
            # Find the winner (first completed with availability)
            for task in done:
                if not task.cancelled():
                    try:
                        response = task.result()
                        if response and response.availability:
                            winner = response
                            logger.info(f"🏆 Winner detected: {response.provider}-{response.region}")
                            break
                    except Exception as e:
                        logger.warning(f"Task failed: {e}")
            
            # Collect all responses
            for task in done:
                if not task.cancelled():
                    try:
                        response = task.result()
                        if response:
                            all_responses.append(response)
                    except Exception as e:
                        pass
            
            # Cancel remaining tasks
            for task in pending:
                task.cancel()
            
            # Wait for cancellation to complete
            await asyncio.gather(pending, return_exceptions=True)
            
        except asyncio.TimeoutError:
            logger.error("⏰ Race timeout")
        
        if not winner:
            logger.warning("❌ No winner detected")
            winner = self._get_default_winner()
            all_responses = [winner] if winner else []
        
        # Calculate smart cancellation strategy
        losers = [r for r in all_responses if r.provider != winner.provider] if winner else []
        cancellation_strategy = await self._calculate_cancellation_strategy(winner, losers)
        
        # Calculate optimization metrics
        cost_optimization = self._calculate_cost_optimization(winner, all_responses)
        waste_prevention = self._calculate_waste_prevention(cancellation_strategy)
        cache_utilization = self._calculate_cache_utilization()
        
        # Calculate final results
        total_time = (time.time() - start_time) * 1000
        
        final_results = {
            'provisioning_id': self.provisioning_id,
            'timestamp': datetime.now().isoformat(),
            'gpu_type': self.gpu_type,
            'mode': self.mode,
            
            'winner': {
                'provider': winner.provider if winner else None,
                'region': winner.region if winner else None,
                'time_to_ready': winner.estimated_launch_time if winner else 999,
                'price_per_hour': winner.spot_price if winner else 0,
                'instance_id': winner.instance_id if winner else None,
                'api': winner.api_name if winner else None,
                'data_locality_score': winner.data_locality_score if winner else 0,
                'cache_hit': winner.cache_hit if winner else False
            },
            
            'all_responses': [asdict(r) for r in all_responses],
            'total_query_time': total_time,
            'available_providers': len([r for r in all_responses if r.availability]),
            'cache_hit_rate': cache_utilization['cache_hit_rate'],
            'rate_limit_success_rate': self._calculate_rate_limit_success_rate(all_responses),
            
            'cancellation_strategy': json.dumps(cancellation_strategy.__dict__, indent=2),
            'cost_optimization': cost_optimization,
            'waste_prevention': waste_prevention,
            'cache_utilization': cache_utilization,
            
            'performance_metrics': {
                'parallel_time': winner.estimated_launch_time if winner else 999,
                'sequential_estimated': winner.estimated_launch_time * 3 + 120 if winner else 999,
                'speedup_factor': (winner.estimated_launch_time * 3 + 120) / winner.estimated_launch_time if winner else 1,
                'time_saved': ((winner.estimated_launch_time * 3 + 120) - winner.estimated_launch_time) if winner else 0
            }
        }
        
        # Store in cache
        await self._store_in_cache(cache_key, final_results)
        
        return final_results
    
    def _get_providers_for_mode(self) -> List[str]:
        """Get providers based on provisioning mode"""
        all_providers = ['aws', 'gcp', 'azure', 'runpod', 'lambda', 'coreweave']
        
        if self.mode == "sticky_cloud" and self.data_location:
            # Prioritize provider with data locality
            if 's3' in self.data_location.lower():
                return ['aws'] + [p for p in all_providers if p != 'aws']
            elif 'gcs' in self.data_location.lower():
                return ['gcp'] + [p for p in all_providers if p != 'gcp']
            elif 'blob' in self.data_location.lower():
                return ['azure'] + [p for p in all_providers if p != 'azure']
        
        elif self.mode == "data_mesh":
            # All providers for maximum arbitrage
            return all_providers
        
        elif self.mode == "hybrid_dedicated":
            # Prioritize specialized providers
            return ['runpod', 'lambda', 'coreweave'] + [p for p in all_providers if p not in ['runpod', 'lambda', 'coreweave']]
        
        return all_providers
    
    async def _rate_limited_monitor_provider(self, provider: str) -> Optional[ProviderResponse]:
        """Monitor provider with rate limiting"""
        
        # Check rate limit
        rate_limit = self.rate_limits.get(provider, 5)
        rate_limit_key = f"rate_limit:{provider}"
        
        if self.redis_client:
            current_requests = self.redis_client.get(rate_limit_key) or 0
            if int(current_requests) >= rate_limit:
                logger.warning(f"⏳ Rate limited for {provider}")
                await asyncio.sleep(1.0)  # Wait and retry
                return await self._rate_limited_monitor_provider(provider)
            
            # Increment rate limit counter
            self.redis_client.incr(rate_limit_key)
            self.redis_client.expire(rate_limit_key, 1)  # 1 second window
        
        # Simulate provider monitoring with realistic timing
        response_times = {
            'aws': 0.5, 'gcp': 0.8, 'azure': 1.0,
            'runpod': 0.4, 'lambda': 0.5, 'coreweave': 0.3
        }
        
        await asyncio.sleep(response_times.get(provider, 0.6))
        
        # Calculate data locality score
        data_locality_score = self._calculate_data_locality_score(provider)
        
        # Check cache for provider response
        cache_key = f"provider:{provider}:{self.gpu_type}"
        cached_response = await self._check_cache(cache_key)
        
        if cached_response and self.cache_enabled:
            logger.info(f"💾 Provider cache hit for {provider}")
            return ProviderResponse(
                provider=cached_response['provider'],
                region=cached_response['region'],
                gpu_type=cached_response['gpu_type'],
                spot_price=cached_response['spot_price'],
                on_demand_price=cached_response['on_demand_price'],
                availability=cached_response['availability'],
                estimated_launch_time=cached_response['estimated_launch_time'],
                response_time=cached_response['response_time'],
                instance_id=cached_response['instance_id'],
                api_name=cached_response['api_name'],
                data_locality_score=data_locality_score,
                cache_hit=True,
                rate_limited=False,
                timestamp=datetime.now()
            )
        
        # Simulate provider response
        import random
        availability = random.random() > 0.2  # 80% availability
        
        response = ProviderResponse(
            provider=provider,
            region=self._get_default_region(provider),
            gpu_type=self.gpu_type,
            spot_price=self._get_spot_price(provider),
            on_demand_price=self._get_on_demand_price(provider),
            availability=availability,
            estimated_launch_time=self._estimate_launch_time(provider),
            response_time=response_times.get(provider, 0.6) * 1000,
            instance_id=f"{provider}-instance-{int(time.time())}" if availability else None,
            api_name=self._get_api_name(provider),
            data_locality_score=data_locality_score,
            cache_hit=False,
            rate_limited=False,
            timestamp=datetime.now()
        )
        
        # Store in cache
        if self.cache_enabled:
            await self._store_in_cache(cache_key, asdict(response))
        
        return response
    
    def _calculate_data_locality_score(self, provider: str) -> float:
        """Calculate data locality score"""
        if not self.data_location:
            return 0.5  # Neutral score
        
        data_location_lower = self.data_location.lower()
        
        if 's3' in data_location_lower and provider == 'aws':
            return 1.0  # Perfect locality
        elif 'gcs' in data_location_lower and provider == 'gcp':
            return 1.0  # Perfect locality
        elif 'blob' in data_location_lower and provider == 'azure':
            return 1.0  # Perfect locality
        
        # Calculate egress cost penalty
        egress_key = f"{provider}_to_"
        if 's3' in data_location_lower:
            egress_key += 'aws'
        elif 'gcs' in data_location_lower:
            egress_key += 'gcp'
        elif 'blob' in data_location_lower:
            egress_key += 'azure'
        else:
            return 0.3  # Poor locality
        
        egress_cost = self.egress_costs.get(egress_key, 0.15)
        return max(0.0, 1.0 - (egress_cost / 0.20))  # Normalize to 0-1
    
    async def _calculate_cancellation_strategy(self, winner: Optional[ProviderResponse], 
                                             losers: List[ProviderResponse]) -> CancellationStrategy:
        """Calculate intelligent cancellation strategy"""
        
        immediate_cancellations = []
        delayed_cancellations = []
        no_cancellations = []
        
        total_waste_prevented = 0.0
        
        for loser in losers:
            if not winner:
                no_cancellations.append({
                    'provider': loser.provider,
                    'reason': 'No winner available',
                    'waste_cost': 0.0
                })
                continue
            
            time_diff = loser.estimated_launch_time - winner.estimated_launch_time
            loser_cost_per_second = loser.spot_price / 3600
            min_billing = self.cancellation_policies.get(loser.provider, {}).get('minimum_billing_seconds', 60)
            minimum_billing_cost = loser_cost_per_second * min_billing
            
            # Decision logic
            if time_diff > 30:  # Much slower
                immediate_cancellations.append({
                    'provider': loser.provider,
                    'instance_id': loser.instance_id,
                    'reason': 'Much slower than winner',
                    'savings': minimum_billing_cost
                })
                total_waste_prevented += minimum_billing_cost
                
            elif time_diff < 10:  # Too close
                no_cancellations.append({
                    'provider': loser.provider,
                    'reason': 'Too close to winner, keep as backup',
                    'waste_cost': minimum_billing_cost * 0.5
                })
                
            else:  # Moderately slower
                delayed_cancellations.append({
                    'provider': loser.provider,
                    'instance_id': loser.instance_id,
                    'delay_seconds': 15,
                    'reason': 'Moderately slower, delayed cancellation',
                    'savings': minimum_billing_cost * 0.8
                })
                total_waste_prevented += minimum_billing_cost * 0.8
        
        return CancellationStrategy(
            immediate_cancellations=immediate_cancellations,
            delayed_cancellations=delayed_cancellations,
            no_cancellations=no_cancellations,
            cost_analysis={},
            waste_prevented=total_waste_prevented
        )
    
    def _calculate_cost_optimization(self, winner: Optional[ProviderResponse], 
                                   responses: List[ProviderResponse]) -> Dict:
        """Calculate cost optimization metrics"""
        
        if not winner:
            return {'optimization_applied': False}
        
        available_prices = [r.spot_price for r in responses if r.availability]
        if available_prices:
            avg_price = sum(available_prices) / len(available_prices)
            savings_percent = ((avg_price - winner.spot_price) / avg_price) * 100
        else:
            avg_price = 0.0
            savings_percent = 0.0
        
        # Calculate egress savings
        egress_savings = winner.data_locality_score * 5.0  # Max $5/hr egress savings
        
        return {
            'optimization_applied': True,
            'winner_price': winner.spot_price,
            'average_price': avg_price,
            'savings_percent': savings_percent,
            'egress_savings_per_hour': egress_savings,
            'total_savings_per_hour': (avg_price - winner.spot_price) + egress_savings if available_prices else 0.0,
            'data_locality_bonus': winner.data_locality_score
        }
    
    def _calculate_waste_prevention(self, strategy: CancellationStrategy) -> Dict:
        """Calculate waste prevention metrics"""
        
        immediate_savings = sum(c['savings'] for c in strategy.immediate_cancellations)
        delayed_savings = sum(c['savings'] for c in strategy.delayed_cancellations)
        waste_cost = sum(nc['waste_cost'] for nc in strategy.no_cancellations)
        
        total_savings = immediate_savings + delayed_savings
        net_savings = total_savings - waste_cost
        
        return {
            'immediate_cancellations': len(strategy.immediate_cancellations),
            'delayed_cancellations': len(strategy.delayed_cancellations),
            'no_cancellations': len(strategy.no_cancellations),
            'immediate_savings': immediate_savings,
            'delayed_savings': delayed_savings,
            'waste_cost': waste_cost,
            'total_savings': total_savings,
            'net_savings': net_savings,
            'waste_prevented_percent': (net_savings / (total_savings + 0.01)) * 100
        }
    
    def _calculate_cache_utilization(self) -> Dict:
        """Calculate cache utilization metrics"""
        
        if not self.redis_client:
            return {
                'cache_enabled': False,
                'cache_hits': 0,
                'cache_misses': 0,
                'cache_hit_rate': 0.0,
                'cache_size_gb': 0.0,
                'cache_evictions': 0
            }
        
        try:
            info = self.redis_client.info()
            hits = info.get('keyspace_hits', 0)
            misses = info.get('keyspace_misses', 0)
            total_requests = hits + misses
            
            return {
                'cache_enabled': True,
                'cache_hits': hits,
                'cache_misses': misses,
                'cache_hit_rate': hits / total_requests if total_requests > 0 else 0.0,
                'cache_size_gb': info.get('used_memory', 0) / (1024**3),
                'cache_evictions': info.get('evicted_keys', 0)
            }
        except Exception as e:
            logger.warning(f"⚠️  Could not get cache stats: {e}")
            return {
                'cache_enabled': True,
                'cache_hits': 0,
                'cache_misses': 0,
                'cache_hit_rate': 0.0,
                'cache_size_gb': 0.0,
                'cache_evictions': 0
            }
    
    def _calculate_rate_limit_success_rate(self, responses: List[ProviderResponse]) -> float:
        """Calculate rate limit success rate"""
        if not responses:
            return 0.0
        
        successful = len([r for r in responses if not r.rate_limited])
        return successful / len(responses)
    
    async def _check_cache(self, cache_key: str) -> Optional[Dict]:
        """Check cache for data"""
        if not self.redis_client:
            return None
        
        try:
            cached_data = self.redis_client.get(cache_key)
            if cached_data:
                return json.loads(cached_data)
        except Exception as e:
            logger.warning(f"⚠️  Cache check failed: {e}")
        
        return None
    
    async def _store_in_cache(self, cache_key: str, data: Dict):
        """Store data in cache"""
        if not self.redis_client:
            return
        
        try:
            self.redis_client.setex(cache_key, 86400, json.dumps(data))  # 24 hour TTL
        except Exception as e:
            logger.warning(f"⚠️  Cache store failed: {e}")
    
    def _get_default_winner(self) -> Optional[ProviderResponse]:
        """Get default winner"""
        return ProviderResponse(
            provider="aws",
            region="us-east-1",
            gpu_type=self.gpu_type,
            spot_price=2.50,
            on_demand_price=3.25,
            availability=True,
            estimated_launch_time=60,
            response_time=500,
            instance_id="aws-default-instance",
            api_name="EC2 API",
            data_locality_score=0.5,
            cache_hit=False,
            rate_limited=False,
            timestamp=datetime.now()
        )
    
    # Helper methods
    def _get_default_region(self, provider: str) -> str:
        regions = {
            'aws': 'us-east-1',
            'gcp': 'us-central1-a',
            'azure': 'eastus',
            'runpod': 'us-east',
            'lambda': 'us-east',
            'coreweave': 'us-east-1'
        }
        return regions.get(provider, 'us-east-1')
    
    def _get_spot_price(self, provider: str) -> float:
        prices = {
            'aws': 2.50, 'gcp': 2.45, 'azure': 2.60,
            'runpod': 2.20, 'lambda': 2.15, 'coreweave': 2.10
        }
        return prices.get(provider, 2.0)
    
    def _get_on_demand_price(self, provider: str) -> float:
        return self._get_spot_price(provider) * 1.3
    
    def _estimate_launch_time(self, provider: str) -> float:
        times = {
            'aws': 45, 'gcp': 38, 'azure': 52,
            'runpod': 30, 'lambda': 35, 'coreweave': 25
        }
        return times.get(provider, 45)
    
    def _get_api_name(self, provider: str) -> str:
        apis = {
            'aws': 'EC2 API',
            'gcp': 'Compute Engine API',
            'azure': 'Microsoft.Compute API',
            'runpod': 'RunPod API',
            'lambda': 'Lambda Labs API',
            'coreweave': 'CoreWeave API'
        }
        return apis.get(provider, 'Unknown API')

def main():
    """Main entry point"""
    detector = AdvancedRaceDetector()
    results = asyncio.run(detector.detect_advanced_race_winner())
    
    # Output results for Terraform
    logging.info(json.dumps(results, indent=2)

if __name__ == "__main__":
    main()
