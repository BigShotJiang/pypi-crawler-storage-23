#!/usr/bin/env python3
"""
Execute Smart Cancellation Script
Implements intelligent cancellation strategies to prevent waste
"""

import json
import sys
import asyncio
import logging
from datetime import datetime
from typing import Dict, List

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SmartCancellationExecutor:
    """Executes smart cancellation strategies"""
    
    def __init__(self, provisioning_id: str, race_results: Dict):
        self.provisioning_id = provisioning_id
        self.race_results = race_results
        self.cancellation_strategy = json.loads(race_results.get('cancellation_strategy', '{}'))
        
    async def execute_cancellations(self):
        """Execute the cancellation strategy"""
        logger.info(f"🚫 Executing smart cancellation for {self.provisioning_id}")
        
        # Execute immediate cancellations
        await self._execute_immediate_cancellations()
        
        # Schedule delayed cancellations
        await self._schedule_delayed_cancellations()
        
        # Log no-cancellations
        self._log_no_cancellations()
        
        # Calculate and report waste prevention
        await self._report_waste_prevention()
    
    async def _execute_immediate_cancellations(self):
        """Execute immediate cancellations"""
        immediate = self.cancellation_strategy.get('immediate_cancellations', [])
        
        for cancellation in immediate:
            provider = cancellation['provider']
            instance_id = cancellation['instance_id']
            reason = cancellation['reason']
            savings = cancellation['savings']
            
            logger.info(f"🚫 Immediate cancellation: {provider} ({instance_id})")
            logger.info(f"   Reason: {reason}")
            logger.info(f"   Savings: ${savings:.4f}")
            
            # Execute cancellation (would call provider APIs)
            await self._cancel_instance(provider, instance_id, reason)
    
    async def _schedule_delayed_cancellations(self):
        """Schedule delayed cancellations"""
        delayed = self.cancellation_strategy.get('delayed_cancellations', [])
        
        for cancellation in delayed:
            provider = cancellation['provider']
            instance_id = cancellation['instance_id']
            delay = cancellation['delay_seconds']
            reason = cancellation['reason']
            savings = cancellation['savings']
            
            logger.info(f"⏰ Delayed cancellation: {provider} ({instance_id}) in {delay}s")
            logger.info(f"   Reason: {reason}")
            logger.info(f"   Savings: ${savings:.4f}")
            
            # Schedule delayed cancellation
            asyncio.create_task(
                self._delayed_cancel(provider, instance_id, delay, reason, savings)
            )
    
    def _log_no_cancellations(self):
        """Log instances that won't be cancelled"""
        no_cancel = self.cancellation_strategy.get('no_cancellations', [])
        
        for nc in no_cancel:
            provider = nc['provider']
            reason = nc['reason']
            waste_cost = nc['waste_cost']
            
            logger.info(f"✅ No cancellation: {provider}")
            logger.info(f"   Reason: {reason}")
            logger.info(f"   Waste cost: ${waste_cost:.4f}")
    
    async def _delayed_cancel(self, provider: str, instance_id: str, delay: int, 
                             reason: str, savings: float):
        """Execute delayed cancellation"""
        await asyncio.sleep(delay)
        
        logger.info(f"🚫 Executing delayed cancellation: {provider} ({instance_id})")
        logger.info(f"   Reason: {reason}")
        logger.info(f"   Savings: ${savings:.4f}")
        
        await self._cancel_instance(provider, instance_id, reason)
    
    async def _cancel_instance(self, provider: str, instance_id: str, reason: str):
        """Cancel instance on specific provider"""
        # Implementation would call provider-specific APIs
        
        # For demonstration, we'll simulate the cancellation
        logger.info(f"🚫 Cancelling {provider} instance {instance_id}")
        logger.info(f"   Reason: {reason}")
        
        # In real implementation:
        # AWS: aws ec2 terminate-instances --instance-ids $instance_id
        # GCP: gcloud compute instances delete $instance_id --zone=$zone
        # Azure: az vm delete --ids $instance_id --yes
        # RunPod: DELETE /api/v2/instances/$instance_id
        # Lambda: DELETE /api/v1/instances/$instance_id
        # CoreWeave: DELETE /api/v1/virtual-machines/$instance_id
        
        # Log cancellation
        await self._log_cancellation(provider, instance_id, reason)
    
    async def _log_cancellation(self, provider: str, instance_id: str, reason: str):
        """Log cancellation for audit trail"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'provisioning_id': self.provisioning_id,
            'provider': provider,
            'instance_id': instance_id,
            'reason': reason,
            'action': 'cancelled'
        }
        
        # In real implementation, would store in database or logging system
        logger.info(f"📝 Cancellation logged: {json.dumps(log_entry)}")
    
    async def _report_waste_prevention(self):
        """Report waste prevention metrics"""
        waste_prevention = self.race_results.get('waste_prevention', {})
        
        immediate_savings = waste_prevention.get('immediate_savings', 0)
        delayed_savings = waste_prevention.get('delayed_savings', 0)
        waste_cost = waste_prevention.get('waste_cost', 0)
        net_savings = waste_prevention.get('net_savings', 0)
        prevented_percent = waste_prevention.get('waste_prevented_percent', 0)
        
        logger.info("💰 WASTE PREVENTION REPORT:")
        logger.info(f"   Immediate savings: ${immediate_savings:.4f}")
        logger.info(f"   Delayed savings: ${delayed_savings:.4f}")
        logger.info(f"   Waste cost: ${waste_cost:.4f}")
        logger.info(f"   Net savings: ${net_savings:.4f}")
        logger.info(f"   Waste prevented: {prevented_percent:.1f}%")
        
        # Calculate monthly savings
        monthly_savings = net_savings * 30 * 24  # Assuming 1 provision/hour
        logger.info(f"   Estimated monthly savings: ${monthly_savings:.2f}")

async def main():
    """Main entry point"""
    if len(sys.argv) < 3:
        logger.error("Usage: python3 execute-smart-cancellation.py <provisioning_id> <race_results_json>")
        return
    
    provisioning_id = sys.argv[1]
    race_results_json = sys.argv[2]
    
    try:
        race_results = json.loads(race_results_json)
    except json.JSONDecodeError as e:
        logger.error(f"Invalid race results JSON: {e}")
        return
    
    executor = SmartCancellationExecutor(provisioning_id, race_results)
    await executor.execute_cancellations()

if __name__ == "__main__":
    asyncio.run(main())
