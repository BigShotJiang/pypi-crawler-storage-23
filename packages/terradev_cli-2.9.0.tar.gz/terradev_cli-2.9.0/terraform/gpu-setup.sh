#!/bin/bash
# GPU Setup Script for Parallel Race
# This script runs on all GPU instances to prepare them for use

set -e

# Parse input variables
GPU_TYPE=${1:-"A100"}
PROVIDER=${2:-"aws"}
RACE_ID=${3:-"unknown"}

echo "🚀 Setting up GPU instance for race ${RACE_ID}"
echo "📍 Provider: ${PROVIDER}"
echo "💻 GPU Type: ${GPU_TYPE}"

# Install NVIDIA drivers and CUDA
echo "🔧 Installing NVIDIA drivers..."
if command -v apt-get &> /dev/null; then
    # Ubuntu/Debian
    sudo apt-get update
    sudo apt-get install -y nvidia-driver-535 nvidia-cuda-toolkit
elif command -v yum &> /dev/null; then
    # CentOS/RHEL
    sudo yum install -y nvidia-driver cuda-toolkit
fi

# Install Docker
echo "🐳 Installing Docker..."
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker ubuntu

# Install Python and ML libraries
echo "🐍 Installing Python ML libraries..."
sudo apt-get install -y python3 python3-pip
pip3 install torch torchvision transformers

# Create race status file
echo "📊 Creating race status..."
cat > /tmp/race-status.json << EOF
{
  "race_id": "${RACE_ID}",
  "provider": "${PROVIDER}",
  "gpu_type": "${GPU_TYPE}",
  "setup_start": "$(date -Iseconds)",
  "gpu_detected": "false",
  "ready": "false"
}
EOF

# Check GPU availability
echo "🔍 Checking GPU availability..."
if command -v nvidia-smi &> /dev/null; then
    nvidia-smi
    GPU_COUNT=$(nvidia-smi --list-gpus | wc -l)
    echo "✅ Detected ${GPU_COUNT} GPUs"
    
    # Update race status
    jq '.gpu_detected = true' /tmp/race-status.json > /tmp/race-status.tmp && mv /tmp/race-status.tmp /tmp/race-status.json
else
    echo "❌ No GPU detected"
fi

# Start readiness check service
echo "🚀 Starting readiness service..."
cat > /tmp/readiness-service.py << 'EOF'
import json
import time
import subprocess
from datetime import datetime

def check_gpu_ready():
    """Check if GPU is ready for workloads"""
    try:
        # Check nvidia-smi
        result = subprocess.run(['nvidia-smi'], capture_output=True, text=True)
        if result.returncode != 0:
            return False, "nvidia-smi failed"
        
        # Check CUDA
        result = subprocess.run(['python3', '-c', 'import torch; print(torch.cuda.is_available())'], capture_output=True, text=True)
        if result.returncode != 0 or 'True' not in result.stdout:
            return False, "CUDA not available"
        
        return True, "GPU ready"
    except Exception as e:
        return False, str(e)

def main():
    status_file = "/tmp/race-status.json"
    ready = False
    
    while not ready:
        ready, message = check_gpu_ready()
        
        # Update status
        with open(status_file, 'r') as f:
            status = json.load(f)
        
        status['ready'] = ready
        status['last_check'] = datetime.now().isoformat()
        status['check_message'] = message
        
        with open(status_file, 'w') as f:
            json.dump(status, f, indent=2)
        
        if ready:
            print("✅ GPU is ready!")
            break
        else:
            print(f"⏳ Waiting... {message}")
            time.sleep(5)

if __name__ == "__main__":
    main()
EOF

# Start readiness service in background
python3 /tmp/readiness-service.py &

# Create HTTP server for status checking
echo "🌐 Starting status server..."
cat > /tmp/status-server.py << 'EOF'
import json
import http.server
import socketserver
from urllib.parse import urlparse

class StatusHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/status':
            try:
                with open('/tmp/race-status.json', 'r') as f:
                    status = json.load(f)
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(status).encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())
        else:
            super().do_GET()

if __name__ == "__main__":
    with socketserver.TCPServer(("", 8080), StatusHandler) as httpd:
        print("Status server running on port 8080")
        httpd.serve_forever()
EOF

# Start status server
python3 /tmp/status-server.py &

echo "✅ Setup complete! GPU instance is preparing..."
echo "📊 Status available at http://localhost:8080/status"
echo "🏁 Race ${RACE_ID} participant ready!"
