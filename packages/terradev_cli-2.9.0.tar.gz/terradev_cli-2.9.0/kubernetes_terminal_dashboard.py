#!/usr/bin/env python3
"""
Kubernetes Training Terminal Dashboard
Interactive terminal interface for ML training orchestration
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import subprocess
import yaml

# Terminal UI imports
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.live import Live
    from rich.text import Text
    from rich.prompt import Prompt, Confirm
    from rich.tree import Tree
    from rich.columns import Columns
    from rich.align import Align
    from rich.rule import Rule
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    logging.info("⚠️  Rich library not installed. Install with: pip install rich")
    sys.exit(1)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class TrainingRequirement:
    """User training requirements"""
    model_name: str
    dataset_name: str
    gpu_type: str
    gpu_count: int
    cpu_cores: int
    memory_gb: int
    storage_gb: int
    training_hours: int
    budget_max: float
    priority: str  # low, medium, high
    framework: str  # pytorch, tensorflow, jax

@dataclass
class TrainingOption:
    """Available training option"""
    provider: str
    instance_type: str
    gpu_type: str
    gpu_count: int
    hourly_cost: float
    total_cost: float
    availability: str
    location: str
    reliability: float
    estimated_time: str
    score: float

# TODO: Consider refactoring KubernetesTerminalDashboard - 23 methods (God Class)
# TODO: REFACTOR GOD CLASS - KubernetesTerminalDashboard has 23 methods (>20)
# Consider splitting into smaller, focused classes
# Apply Single Responsibility Principle
# TODO: REFACTOR GOD CLASS - KubernetesTerminalDashboard has 23 methods (>20)
# Consider splitting into smaller, focused classes
# Apply Single Responsibility Principle
# Extract related functionality into separate classes
class KubernetesTerminalDashboard:
    """Interactive terminal dashboard for Kubernetes training"""
    
    def __init__(self):
        self.console = Console()
        self.layout = Layout()
        self.training_engine = None
        self.current_requirements = None
        self.available_options = []
        self.selected_option = None
        self.active_jobs = []
        self.connected = False
        
        # Initialize layout
        self._setup_layout()
        
        # Import connect card
        try:
            from kubernetes_connect_card import KubernetesConnectCard
            self.k8s_card = KubernetesConnectCard()
        except ImportError:
            self.console.print("❌ Kubernetes connect card not available")
            self.k8s_card = None
    
    def _setup_layout(self):
        """Setup terminal layout"""
        self.layout.split(
            Layout(name="header", size=3),
            Layout(name="main"),
            Layout(name="footer", size=3)
        )
        
        self.layout["main"].split_row(
            Layout(name="sidebar", size=30),
            Layout(name="content")
        )
        
        self.layout["sidebar"].split_column(
            Layout(name="status", size=10),
            Layout(name="requirements", size=15),
            Layout(name="jobs")
        )
    
    def render_header(self):
        """Render header panel"""
        header_text = Text("🚀 Kubernetes Training Terminal Dashboard", style="bold blue")
        header_text.append(" | ", style="white")
        header_text.append(f"Connected: {'✅' if self.connected else '❌'}", style="green" if self.connected else "red")
        
        return Panel(
            Align.center(header_text),
            border_style="blue"
        )
    
    def render_status(self):
        """Render status panel"""
        if not self.k8s_card:
            return Panel("❌ Kubernetes not available", border_style="red")
        
        if not self.connected:
            return Panel("❌ Not connected to cluster", border_style="red")
        
        summary = self.k8s_card.get_connection_summary()
        
        status_text = Text()
        status_text.append("📊 Cluster Status\n\n", style="bold")
        status_text.append(f"Nodes: {summary['total_nodes']}\n", style="white")
        status_text.append(f"GPU Nodes: {summary['gpu_nodes']}\n", style="white")
        status_text.append(f"Namespace: {summary['namespace']}\n", style="white")
        status_text.append(f"Active Jobs: {len(self.active_jobs)}\n", style="white")
        
        return Panel(status_text, title="📊 Status", border_style="green")
    
    def render_requirements(self):
        """Render requirements panel"""
        if not self.current_requirements:
            return Panel("⚙️  No requirements set", title="⚙️  Requirements", border_style="yellow")
        
        req = self.current_requirements
        req_text = Text()
        req_text.append("🎯 Training Requirements\n\n", style="bold")
        req_text.append(f"Model: {req.model_name}\n", style="white")
        req_text.append(f"Dataset: {req.dataset_name}\n", style="white")
        req_text.append(f"GPU: {req.gpu_type} x{req.gpu_count}\n", style="white")
        req_text.append(f"CPU: {req.cpu_cores} cores\n", style="white")
        req_text.append(f"Memory: {req.memory_gb}GB\n", style="white")
        req_text.append(f"Storage: {req.storage_gb}GB\n", style="white")
        req_text.append(f"Hours: {req.training_hours}\n", style="white")
        req_text.append(f"Budget: ${req.budget_max}\n", style="white")
        req_text.append(f"Priority: {req.priority}\n", style="white")
        req_text.append(f"Framework: {req.framework}\n", style="white")
        
        return Panel(req_text, title="⚙️  Requirements", border_style="blue")
    
    def render_jobs(self):
        """Render active jobs panel"""
        if not self.active_jobs:
            return Panel("📋 No active jobs", title="📋 Active Jobs", border_style="yellow")
        
        jobs_table = Table(show_header=True, header_style="bold blue")
        jobs_table.add_column("Job", style="cyan")
        jobs_table.add_column("Status", style="green")
        jobs_table.add_column("Progress", style="yellow")
        
        for job in self.active_jobs:
            status = job.get("status", "Unknown")
            progress = job.get("progress", "0%")
            jobs_table.add_row(job["name"], status, progress)
        
        return Panel(jobs_table, title="📋 Active Jobs", border_style="green")
    
    def render_content(self):
        """Render main content area"""
        if not self.available_options:
            return self.render_welcome()
        
        return self.render_options()
    
    def render_welcome(self):
        """Render welcome screen"""
        welcome_text = Text()
        welcome_text.append("🎯 Welcome to Kubernetes Training Dashboard\n\n", style="bold blue")
        welcome_text.append("This terminal helps you:\n\n", style="white")
        welcome_text.append("1. Set training requirements\n", style="white")
        welcome_text.append("2. Find optimal cloud resources\n", style="white")
        welcome_text.append("3. Choose and deploy training jobs\n", style="white")
        welcome_text.append("4. Monitor progress in real-time\n\n", style="white")
        welcome_text.append("Press 'r' to set requirements\n", style="yellow")
        welcome_text.append("Press 'c' to connect to cluster\n", style="yellow")
        welcome_text.append("Press 'q' to quit\n", style="yellow")
        
        return Panel(
            Align.center(welcome_text),
            title="🎯 Welcome",
            border_style="blue"
        )
    
    def render_options(self):
        """Render training options"""
        options_table = Table(show_header=True, header_style="bold blue")
        options_table.add_column("Provider", style="cyan")
        options_table.add_column("Instance", style="white")
        options_table.add_column("GPU", style="green")
        options_table.add_column("Cost/hr", style="yellow")
        options_table.add_column("Total", style="red")
        options_table.add_column("Score", style="magenta")
        options_table.add_column("Select", style="blue")
        
        for i, option in enumerate(self.available_options):
            select_marker = "👉" if i == 0 else "  "
            options_table.add_row(
                option.provider,
                option.instance_type,
                f"{option.gpu_type}x{option.gpu_count}",
                f"${option.hourly_cost:.4f}",
                f"${option.total_cost:.2f}",
                f"{option.score:.3f}",
                select_marker
            )
        
        help_text = Text()
        help_text.append("↑↓ Navigate | Enter Select | r Requirements | q Quit", style="yellow")
        
        return Panel(
            Columns([
                options_table,
                Panel(help_text, border_style="yellow")
            ]),
            title="🎯 Training Options",
            border_style="green"
        )
    
    def render_footer(self):
        """Render footer panel"""
        footer_text = Text()
        footer_text.append("🎯 Kubernetes Training Dashboard", style="bold blue")
        footer_text.append(" | ", style="white")
        footer_text.append("Press 'h' for help", style="yellow")
        
        return Panel(
            Align.center(footer_text),
            border_style="blue"
        )
    
    def update_layout(self):
        """Update all layout panels"""
        self.layout["header"].update(self.render_header())
        self.layout["sidebar"]["status"].update(self.render_status())
        self.layout["sidebar"]["requirements"].update(self.render_requirements())
        self.layout["sidebar"]["jobs"].update(self.render_jobs())
        self.layout["content"].update(self.render_content())
        self.layout["footer"].update(self.render_footer())
    
    def connect_to_cluster(self):
        """Connect to Kubernetes cluster"""
        if not self.k8s_card:
            self.console.print("❌ Kubernetes connect card not available")
            return False
        
        with self.console.status("[bold green]Connecting to cluster..."):
            connection = self.k8s_card.connect_to_cluster()
        
        if "error" in connection:
            self.console.print(f"❌ Connection failed: {connection['error']}")
            return False
        
        self.connected = True
        self.console.print("✅ Connected to Kubernetes cluster!")
        return True
    
    def get_training_requirements(self):
        """Get training requirements from user"""
        self.console.print("\n🎯 Set Training Requirements", style="bold blue")
        
        # Model selection
        models = ["resnet50", "bert-base", "gpt2", "stable-diffusion", "custom"]
        model_name = Prompt.ask("Model name", choices=models, default="resnet50")
        
        # Dataset selection
        datasets = ["imagenet", "coco", "wikipedia", "custom", "huggingface"]
        dataset_name = Prompt.ask("Dataset name", choices=datasets, default="imagenet")
        
        # GPU requirements
        gpu_types = ["A100", "V100", "A10G", "T4", "RTX3090"]
        gpu_type = Prompt.ask("GPU type", choices=gpu_types, default="A100")
        gpu_count = int(Prompt.ask("GPU count", default="1"))
        
        # Resource requirements
        cpu_cores = int(Prompt.ask("CPU cores", default="8"))
        memory_gb = int(Prompt.ask("Memory (GB)", default="32"))
        storage_gb = int(Prompt.ask("Storage (GB)", default="100"))
        
        # Training parameters
        training_hours = int(Prompt.ask("Training hours", default="4"))
        budget_max = float(Prompt.ask("Maximum budget ($)", default="100.00"))
        
        priority = Prompt.ask("Priority", choices=["low", "medium", "high"], default="medium")
        framework = Prompt.ask("Framework", choices=["pytorch", "tensorflow", "jax"], default="pytorch")
        
        self.current_requirements = TrainingRequirement(
            model_name=model_name,
            dataset_name=dataset_name,
            gpu_type=gpu_type,
            gpu_count=gpu_count,
            cpu_cores=cpu_cores,
            memory_gb=memory_gb,
            storage_gb=storage_gb,
            training_hours=training_hours,
            budget_max=budget_max,
            priority=priority,
            framework=framework
        )
        
        self.console.print("✅ Requirements set successfully!")
        return True
    
    def find_training_options(self):
        """Find training options based on requirements"""
        if not self.current_requirements:
            self.console.print("❌ No requirements set")
            return
        
        if not self.connected:
            self.console.print("❌ Not connected to cluster")
            return
        
        self.console.print("🔍 Finding optimal training options...")
        
        # Simulate finding options (in real implementation, this would call the arbitrage engine)
        self.available_options = self._generate_mock_options()
        
        # Sort by score
        self.available_options.sort(key=lambda x: x.score, reverse=True)
        
        self.console.print(f"✅ Found {len(self.available_options)} training options")
    
# TODO: REFACTOR - _generate_mock_options() is 69 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def _generate_mock_options(self) -> List[TrainingOption]:
        """Generate mock training options"""
        req = self.current_requirements
        
        options = []
        
        # AWS options
        options.append(TrainingOption(
            provider="AWS",
            instance_type="p4d.24xlarge",
            gpu_type="A100",
            gpu_count=req.gpu_count,
            hourly_cost=32.77,
            total_cost=32.77 * req.training_hours,
            availability="Available",
            location="us-east-1",
            reliability=0.95,
            estimated_time=f"{req.training_hours}h",
            score=0.92
        ))
        
        # RunPod options
        options.append(TrainingOption(
            provider="RunPod",
            instance_type="A100-80GB",
            gpu_type="A100",
            gpu_count=req.gpu_count,
            hourly_cost=2.49,
            total_cost=2.49 * req.training_hours,
            availability="Available",
            location="us-east-1",
            reliability=0.88,
            estimated_time=f"{req.training_hours}h",
            score=0.89
        ))
        
        # GCP options
        options.append(TrainingOption(
            provider="GCP",
            instance_type="a2-highgpu-8g",
            gpu_type="A100",
            gpu_count=req.gpu_count,
            hourly_cost=4.08,
            total_cost=4.08 * req.training_hours,
            availability="Available",
            location="us-central1",
            reliability=0.93,
            estimated_time=f"{req.training_hours}h",
            score=0.87
        ))
        
        # Vast.ai options
        options.append(TrainingOption(
            provider="Vast.ai",
            instance_type="A100-40GB",
            gpu_type="A100",
            gpu_count=req.gpu_count,
            hourly_cost=1.25,
            total_cost=1.25 * req.training_hours,
            availability="Limited",
            location="us-west-2",
            reliability=0.75,
            estimated_time=f"{req.training_hours}h",
            score=0.78
        ))
        
        # Filter by budget
        filtered_options = [opt for opt in options if opt.total_cost <= req.budget_max]
        
        return filtered_options if filtered_options else options[:2]
    
    def select_option(self, index: int):
        """Select a training option"""
        if 0 <= index < len(self.available_options):
            self.selected_option = self.available_options[index]
            self.console.print(f"✅ Selected: {self.selected_option.provider} - {self.selected_option.instance_type}")
            return True
# TODO: REFACTOR - deploy_training_job() is 53 lines long (should be <50)
# Consider breaking into smaller, focused functions
        return False
    
    def deploy_training_job(self):
        """Deploy selected training job"""
        if not self.selected_option:
            self.console.print("❌ No option selected")
            return
        
        if not self.connected:
            self.console.print("❌ Not connected to cluster")
            return
        
        req = self.current_requirements
        option = self.selected_option
        
        job_name = f"{req.model_name}-{req.framework}-{int(time.time())}"
        
        # Create job configuration
        job_config = {
            "name": job_name,
            "image": self._get_docker_image(req.framework),
            "command": self._get_training_command(req),
            "env": {
                "MODEL_NAME": req.model_name,
                "DATASET_NAME": req.dataset_name,
                "GPU_TYPE": req.gpu_type,
                "TRAINING_HOURS": str(req.training_hours),
                "FRAMEWORK": req.framework
            },
            "cpu": str(req.cpu_cores),
            "memory": f"{req.memory_gb}Gi",
            "gpu": req.gpu_count,
            "node_selector": self._get_node_selector(option),
            "tolerations": self._get_tolerations(),
            "ttl": req.training_hours * 3600 + 3600  # Training time + 1 hour cleanup
        }
        
        self.console.print(f"🚀 Deploying training job: {job_name}")
        
        # Deploy job
        if self.k8s_card:
            deployment = self.k8s_card.deploy_training_job(job_config)
            
            if "error" in deployment:
                self.console.print(f"❌ Deployment failed: {deployment['error']}")
            else:
                self.console.print("✅ Training job deployed successfully!")
                
                # Add to active jobs
                self.active_jobs.append({
                    "name": job_name,
                    "status": "Running",
                    "progress": "0%",
                    "option": option,
                    "requirements": req
                })
    
    def _get_docker_image(self, framework: str) -> str:
        """Get Docker image for framework"""
        images = {
            "pytorch": "pytorch/pytorch:latest",
            "tensorflow": "tensorflow/tensorflow:latest-gpu",
            "jax": "python:3.9"
        }
        return images.get(framework, "python:3.9")
    
    def _get_training_command(self, req: TrainingRequirement) -> List[str]:
        """Get training command"""
        if req.framework == "pytorch":
            return ["python", "train.py", "--model", req.model_name, "--dataset", req.dataset_name]
        elif req.framework == "tensorflow":
            return ["python", "train.py", "--model", req.model_name, "--dataset", req.dataset_name]
        else:
            return ["python", "train.py"]
    
    def _get_node_selector(self, option: TrainingOption) -> Dict:
        """Get node selector for option"""
        selectors = {
            "A100": {"accelerator": "nvidia-tesla-a100"},
            "V100": {"accelerator": "nvidia-tesla-v100"},
            "A10G": {"accelerator": "nvidia-tesla-a10g"},
            "T4": {"accelerator": "nvidia-tesla-t4"}
        }
        return selectors.get(option.gpu_type, {})
    
    def _get_tolerations(self) -> List[Dict]:
        """Get GPU tolerations"""
        return [
            {
                "key": "nvidia.com/gpu",
                "operator": "Exists",
                "effect": "NoSchedule"
            }
        ]
    
    def show_help(self):
        """Show help information"""
        help_text = """
🎯 Kubernetes Training Dashboard - Help

Commands:
  h     - Show this help
  c     - Connect to Kubernetes cluster
  r     - Set training requirements
  f     - Find training options
  ↑↓    - Navigate options
  Enter - Select option
  d     - Deploy selected job
  q     - Quit dashboard

Workflow:
  1. Connect to cluster (c)
  2. Set requirements (r)
  3. Find options (f)
  4. Select option (↑↓ + Enter)
  5. Deploy job (d)
        """
        
        self.console.print(Panel(help_text, title="📖 Help", border_style="blue"))
    
    def run_interactive(self):
        """Run interactive dashboard"""
        self.console.print("🚀 Starting Kubernetes Training Dashboard...", style="bold blue")
        
        # Main loop
        selected_index = 0
        
        # TODO: Add proper exit condition to prevent infinite loop
while True:
            self.update_layout()
            
            # Clear screen and render
            self.console.clear()
            self.console.print(self.layout)
            
            # Get user input
            try:
                key = self.console.input("[bold yellow]Command:[/bold yellow] ").strip().lower()
                
                if key == 'q':
                    self.console.print("👋 Goodbye!")
                    break
                elif key == 'h':
                    self.show_help()
                elif key == 'c':
                    self.connect_to_cluster()
                elif key == 'r':
                    self.get_training_requirements()
                elif key == 'f':
                    self.find_training_options()
                elif key == 'd':
                    self.deploy_training_job()
                elif key == 'up' and self.available_options:
                    selected_index = max(0, selected_index - 1)
                    self.select_option(selected_index)
                elif key == 'down' and self.available_options:
                    selected_index = min(len(self.available_options) - 1, selected_index + 1)
                    self.select_option(selected_index)
                elif key == '' and self.available_options:  # Enter key
                    self.select_option(selected_index)
                else:
                    self.console.print(f"❌ Unknown command: {key}")
                    self.show_help()
                
            except KeyboardInterrupt:
                self.console.print("\n👋 Goodbye!")
                break
            except Exception as e:
                self.console.print(f"❌ Error: {e}")

# Main execution
def main():
    """Main function"""
    if not RICH_AVAILABLE:
        logging.info("❌ Rich library required. Install with: pip install rich")
        return
    
    dashboard = KubernetesTerminalDashboard()
    dashboard.run_interactive()

if __name__ == "__main__":
    main()
