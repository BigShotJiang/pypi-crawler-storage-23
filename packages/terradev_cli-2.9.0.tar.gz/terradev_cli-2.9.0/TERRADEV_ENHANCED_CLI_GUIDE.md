# 🚀 Terradev Enhanced CLI Guide

Interactive setup wizard with HuggingFace integration and improved user experience.

---

## 🌟 **New Enhanced Features**

### **🎮 Interactive Setup Wizard**
```bash
terradev setup
```

**Welcome Experience:**
```
🌟 Welcome to Terradev CLI!
Let's get you set up for cloud cost optimization.

📋 Select cloud providers to configure:

  [aws] Amazon Web Services
       Largest cloud provider with extensive GPU offerings
       Difficulty: Medium | Savings: 15-25%

  [runpod] RunPod
       Specialized GPU cloud with competitive pricing
       Difficulty: Easy | Savings: 60-70%

  [vastai] VastAI
       GPU marketplace with variable pricing
       Difficulty: Easy | Savings: 40-60%

  [huggingface] HuggingFace
       ML Model Hub and Inference API
       Difficulty: Easy | Savings: 50-80%

Enter provider keys (comma-separated) [runpod,vastai]: runpod,huggingface
```

### **🤖 HuggingFace Integration**
```bash
# Configure HuggingFace with your token
terradev setup
# Select huggingface provider
# Enter your HF token: hf_tYNrUApGxAkMTxIIzvDOxBlKpxkLeMMfu

# Get ML model quotes
terradev quote --gpu-type T4

# Provision ML inference endpoint
terradev provision --gpu-type T4 --provider huggingface
```

### **📊 Enhanced Configuration Management**
```bash
terradev config-status

📊 Terradev Configuration Status:

🔧 Configured Providers:
   ✅ runpod (us-east-1)
   ✅ huggingface (us-east-1)
   ❌ aws (us-east-1)

📁 Configuration Files:
   Config: /Users/user/.terradev/config.json
   Auth: /Users/user/.terradev/auth.json
   Config exists: True
   Auth exists: True

⚡ Next Steps:
   terradev quote          # Get price quotes
   terradev provision      # Provision instances
```

---

## 🔐 **HuggingFace Configuration**

### **🤖 Setup Process**
```bash
🔧 Configuring HUGGINGFACE:
📖 Help: https://huggingface.co/settings/tokens
📋 Instructions:
   1. Go to HuggingFace Settings
   2. Go to Access Tokens
   3. Create new token
   4. Copy the token (starts with hf_)

Enter Api Token: ******
Confirm Api Token: ******
✅ huggingface configured successfully
```

### **🎯 Available HuggingFace Models**
```bash
terradev quote --provider huggingface

✅ Retrieved 5 quotes
┌─────────────┬─────────────────┬──────┬─────────────┬───────────┬──────────┐
│ Provider    │ Instance Type   │ GPU  │ Price/Hour  │ Region    │ Available│
├─────────────┼─────────────────┼──────┼─────────────┼───────────┼──────────┤
│ huggingface│ inference-T4     │ T4   │ $0.5000     │ us-east-1 │ Yes      │
│ huggingface│ inference-T4     │ T4   │ $0.3000     │ us-east-1 │ Yes      │
│ huggingface│ inference-A10G   │ A10G │ $2.0000     │ us-east-1 │ Yes      │
│ huggingface│ inference-T4     │ T4   │ $0.8000     │ us-east-1 │ Yes      │
│ huggingface│ inference-T4     │ T4   │ $0.2500     │ us-east-1 │ Yes      │
└─────────────┴─────────────────┴──────┴─────────────┴───────────┴──────────┘
```

### **🤖 Supported HuggingFace Tasks**
- **Text Generation**: DialoGPT, GPT models
- **Feature Extraction**: DistilBERT, BERT variants
- **Text-to-Image**: Stable Diffusion models
- **Speech Recognition**: Whisper models
- **Sentence Similarity**: Sentence transformers
- **Question Answering**: QA models
- **Translation**: Translation models
- **Classification**: Text classification models

---

## 🎮 **Enhanced User Experience**

### **📋 Provider Selection with Savings Info**
```
📋 Select cloud providers to configure:

  [runpod] RunPod
       Specialized GPU cloud with competitive pricing
       Difficulty: Easy | Savings: 60-70%

  [vastai] VastAI
       GPU marketplace with variable pricing
       Difficulty: Easy | Savings: 40-60%

  [huggingface] HuggingFace
       ML Model Hub and Inference API
       Difficulty: Easy | Savings: 50-80%
```

### **🔐 Step-by-Step Credential Setup**
```
🔧 Configuring RUNPOD:
📖 Help: https://runpod.io/console/user
📋 Instructions:
   1. Go to RunPod Console
   2. Go to Settings > API Keys
   3. Generate new API key
   4. Copy the API key

Enter Api Key: ******
Confirm Api Key: ******
✅ runpod configured successfully
```

### **✅ Automatic Credential Validation**
```
🔍 Validating credentials...

📊 Credential Validation Results:
   ✅ runpod: Connection successful
   ✅ huggingface: Connection successful
   ❌ aws: Connection failed
```

### **🎯 First Quote Demonstration**
```
🎯 Let's get your first quote to see the savings!

✅ Found 3 quotes for A100 GPUs:
┌───────────┬─────────────────┬─────────────┬───────────┐
│ Provider  │ Instance Type   │ Price/Hour  │ Region    │
├───────────┼─────────────────┼─────────────┼───────────┤
│ runpod    │ A100-80GB       │ $2.4000     │ us-east-1 │
│ vastai    │ A100-80GB       │ $2.1000     │ us-west-2 │
│ huggingface│ inference-A100  │ $3.5000     │ us-east-1 │
└───────────┴─────────────────┴─────────────┴───────────┘

💰 Potential savings: 93.6% vs AWS
   Monthly savings: $22,418.10
```

---

## 🛠️ **New CLI Commands**

### **🌟 Setup Wizard**
```bash
# Interactive setup with guidance
terradev setup

# Quick setup for advanced users
terradev setup --quick

# Guided setup (default)
terradev setup --guided
```

### **📊 Configuration Status**
```bash
terradev config-status
```

**Shows:**
- Configured providers with status
- Configuration file locations
- Quick next steps
- Credential validation results

### **🔐 Enhanced Configure**
```bash
# Original configure still works
terradev configure --provider runpod --api-key your_key

# But setup wizard is recommended for new users
terradev setup
```

---

## 🤖 **HuggingFace Provider Features**

### **📋 Available Models**
```python
# Popular inference models with pricing
models = [
    {
        "model_id": "microsoft/DialoGPT-medium",
        "name": "DialoGPT Medium",
        "task": "text-generation",
        "gpu_type": "T4",
        "price_per_hour": 0.50,
        "memory_gb": 8
    },
    {
        "model_id": "stable-diffusion-v1-5",
        "name": "Stable Diffusion v1.5",
        "task": "text-to-image",
        "gpu_type": "A10G",
        "price_per_hour": 2.00,
        "memory_gb": 24
    },
    {
        "model_id": "whisper-large-v2",
        "name": "Whisper Large v2",
        "task": "automatic-speech-recognition",
        "gpu_type": "T4",
        "price_per_hour": 0.80,
        "memory_gb": 8
    }
]
```

### **🚀 Provisioning ML Endpoints**
```bash
# Provision Stable Diffusion endpoint
terradev provision --gpu-type A10G --provider huggingface --count 1

🚀 Starting parallel provisioning for A10G x1
✅ Found 1 optimal instance
┌─────────────┬─────────────────┬──────┬─────────────┬───────────┐
│ Provider    │ Instance Type   │ GPU  │ Price/Hour  │ Region    │
├─────────────┼─────────────────┼──────┼─────────────┼───────────┤
│ huggingface│ inference-A10G   │ A10G │ $2.0000     │ us-east-1 │
└─────────────┴─────────────────┴──────┴─────────────┴───────────┘

💰 Cost Analysis:
   Total Cost/Hour: $2.0000
   Estimated Savings: 93.9%
   Monthly Savings: $22,418.10
```

### **🔍 Model Discovery**
```python
# List available models
await huggingface_provider.list_models(task="text-generation", limit=50)

# Run inference
result = await huggingface_provider.run_inference(
    model_id="microsoft/DialoGPT-medium",
    inputs={"inputs": "Hello, how are you?"}
)
```

---

## 💰 **Cost Analysis with HuggingFace**

### **🤖 ML Model Pricing**
| Model Type | GPU | Price/Hour | AWS Equivalent | Savings |
|------------|-----|------------|----------------|---------|
| **Text Generation** | T4 | $0.50 | $3.06 | 83.7% |
| **Feature Extraction** | T4 | $0.30 | $3.06 | 90.2% |
| **Text-to-Image** | A10G | $2.00 | $12.98 | 84.6% |
| **Speech Recognition** | T4 | $0.80 | $3.06 | 73.9% |
| **Sentence Similarity** | T4 | $0.25 | $3.06 | 91.8% |

### **📈 ML Workload Savings**
```bash
# ML Training Setup
terradev quote --gpu-type A100 --providers runpod,huggingface,aws

✅ Retrieved 12 quotes
┌─────────────┬─────────────────┬──────┬─────────────┬───────────┐
│ Provider    │ Instance Type   │ GPU  │ Price/Hour  │ Region    │
├─────────────┼─────────────────┼──────┼─────────────┼───────────┤
│ runpod      │ A100-80GB       │ A100 │ $2.4000     │ us-east-1 │
│ huggingface│ inference-A100  │ A100 │ $3.5000     │ us-east-1 │
│ aws         │ p4d.24xlarge    │ A100 │ $32.7700    │ us-east-1 │
└─────────────┴─────────────────┴──────┴─────────────┴───────────┘

💰 Best Value: runpod at $2.40/hour (92.7% savings vs AWS)
💰 Monthly Savings: $22,046.10 for 24/7 operation
```

---

## 🎯 **Usage Examples**

### **🚀 Quick Start with HuggingFace**
```bash
# 1. Setup with HuggingFace
terradev setup
# Select: runpod, huggingface
# Enter tokens when prompted

# 2. Get ML model quotes
terradev quote --gpu-type T4 --provider huggingface

# 3. Provision ML endpoint
terradev provision --gpu-type T4 --provider huggingface --count 1

# 4. Check status
terradev status

# 5. Run inference (future feature)
terradev inference --model-id "microsoft/DialoGPT-medium" --text "Hello!"
```

### **🔧 Multi-Provider Setup**
```bash
# Setup multiple providers
terradev setup
# Select: runpod, vastai, huggingface

# Compare prices across all
terradev quote --gpu-type A100

# Provision cheapest option
terradev provision --gpu-type A100 --max-price 3.00
```

### **📊 Configuration Management**
```bash
# Check current setup
terradev config-status

# Add new provider
terradev configure --provider lambda_labs

# Remove provider (edit config file)
nano ~/.terradev/config.json
```

---

## 🎉 **Benefits of Enhanced CLI**

### **🎮 Better User Experience**
- **Interactive setup wizard** for non-technical users
- **Step-by-step guidance** with help links
- **Automatic credential validation**
- **Clear savings visualization**

### **🤖 ML/AI Integration**
- **HuggingFace model hub** access
- **ML inference endpoints** provisioning
- **Cost-optimized ML workloads**
- **50-80% savings** on ML models

### **📊 Enhanced Visibility**
- **Configuration status dashboard**
- **Provider health monitoring**
- **Real-time validation results**
- **Clear next steps guidance**

### **💰 Improved Cost Optimization**
- **Multi-provider comparison** including ML providers
- **Automatic savings calculation**
- **ROI visualization**
- **Budget-friendly recommendations**

---

## 🚀 **Getting Started**

### **📦 Installation**
```bash
pip install terradev-cli-enhanced
```

### **🌟 First Time Setup**
```bash
# Interactive setup wizard
terradev setup

# Follow the prompts to configure providers
# Enter your API keys when prompted
# See your first quote with savings calculation
```

### **🎯 Typical Workflow**
```bash
# 1. Setup providers
terradev setup

# 2. Compare prices
terradev quote --gpu-type A100

# 3. Provision optimal instance
terradev provision --gpu-type A100 --count 2

# 4. Monitor usage
terradev status

# 5. Clean up when done
terradev cleanup
```

---

## 🎯 **Summary**

The enhanced Terradev CLI provides:

- **🌟 Interactive setup wizard** for easy configuration
- **🤖 HuggingFace integration** for ML workloads
- **📊 Enhanced configuration management** with status dashboard
- **💰 Clear savings visualization** and ROI analysis
- **🔐 Automatic credential validation** and health checks
- **🎮 Improved user experience** for non-technical users

**Result**: Much easier onboarding, clearer value proposition, and expanded ML/AI capabilities with HuggingFace integration.

---

**🚀 Terradev Enhanced CLI - Making cloud cost optimization accessible to everyone!**
