import asyncio
import logging

#!/usr/bin/env python3
"""
GCP OAuth 2.0 Authentication Setup for Terradev
Uses OAuth 2.0 Client ID instead of service account keys (more secure)
"""

import os
import json
import subprocess
from pathlib import Path

def setup_oauth2_gcp_auth():
    """Setup GCP authentication using OAuth 2.0 Client ID"""
    
    logging.info("🔐 GCP OAuth 2.0 Authentication Setup")
    logging.info("=" * 50)
    logging.info("📋 OAuth 2.0 Client ID: 112009677560035284778")
    logging.info("✅ This is the secure approach your organization requires!")
    logging.info()
    
    logging.info("🔧 Step 1: Install Google Cloud CLI")
    logging.info("-" * 40)
    
    # Check if gcloud is installed
    try:
        result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        if result.returncode == 0:
            logging.info("✅ Google Cloud CLI already installed")
            gcloud_path = result.stdout.strip()
            logging.info(f"📍 Location: {gcloud_path}")
        else:
            logging.info("❌ Google Cloud CLI not found")
            logging.info("📦 Installing with Homebrew...")
            install_result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            if install_result.returncode == 0:
                logging.info("✅ Google Cloud CLI installed successfully")
                
                # Add to PATH
                shell_profile = Path.home() / ".zshrc"
                with open(shell_profile, 'a') as f:
                    f.write("\n# Google Cloud CLI\n")
                    f.write("if [ -f '/usr/local/Caskroom/google-cloud-sdk/latest/google-cloud-sdk/path.zsh.inc' ]; then\n")
                    f.write("  source '/usr/local/Caskroom/google-cloud-sdk/latest/google-cloud-sdk/path.zsh.inc'\n")
                    f.write("fi\n")
                
                logging.info("✅ Added to shell profile")
                logging.info("🔄 Please restart your terminal or run: source ~/.zshrc")
            else:
                logging.info(f"❌ Installation failed: {install_result.stderr}")
                return False
    
    except Exception as e:
        logging.info(f"❌ Error checking gcloud: {e}")
        return False
    
    logging.info("\n🔧 Step 2: Configure OAuth 2.0 Authentication")
    logging.info("-" * 50)
    
    # Initialize gcloud
    logging.info("🚀 Initializing gcloud...")
    try:
        # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        logging.info("✅ gcloud initialized")
    except subprocess.CalledProcessError as e:
        logging.info(f"❌ gcloud init failed: {e}")
        return False
    
    # Set up OAuth 2.0 authentication
    logging.info("\n🔑 Setting up OAuth 2.0 authentication...")
    logging.info("📋 This will use your OAuth 2.0 Client ID: 112009677560035284778")
    logging.info("🌐 This will open a browser window for authentication")
    
    try:
        # Use OAuth 2.0 flow instead of service account keys
        # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        logging.info("✅ OAuth 2.0 authentication successful")
        
        # Set up Application Default Credentials with OAuth 2.0
        # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        logging.info("✅ Application Default Credentials configured with OAuth 2.0")
        
    except subprocess.CalledProcessError as e:
        logging.info(f"❌ OAuth 2.0 authentication failed: {e}")
        return False
    
    # Get project information
    try:
        result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        if result.returncode == 0 and result.stdout.strip():
            project_id = result.stdout.strip()
            logging.info(f"📋 Project ID: {project_id}")
            
            # Set environment variable
            os.environ['GOOGLE_CLOUD_PROJECT'] = project_id
            logging.info(f"🔧 Set GOOGLE_CLOUD_PROJECT={project_id}")
            
        else:
            logging.info("⚠️  Could not get project ID - you may need to set it manually")
            project_id = input("📋 Enter your GCP Project ID: ").strip()
            if project_id:
                os.environ['GOOGLE_CLOUD_PROJECT'] = project_id
                # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
                logging.info(f"✅ Set project to: {project_id}")
            
    except Exception as e:
        logging.info(f"⚠️  Error getting project ID: {e}")
    
    return True

def enable_compute_api():
    """Enable Compute Engine API"""
    logging.info("\n🔧 Step 3: Enable Compute Engine API")
    logging.info("-" * 40)
    
    try:
        project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
        if not project_id:
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            if result.returncode == 0:
                project_id = result.stdout.strip()
        
        if project_id:
            logging.info(f"📋 Enabling Compute Engine API for project: {project_id}")
            # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            logging.info("✅ Compute Engine API enabled successfully")
            return True
        else:
            logging.info("❌ Could not determine project ID")
            return False
            
    except subprocess.CalledProcessError as e:
        logging.info(f"❌ Failed to enable Compute Engine API: {e}")
        logging.info("💡 You may need to ask your organization admin to enable this API")
        return False

def test_oauth2_connection():
    """Test GCP connection with OAuth 2.0 authentication"""
    logging.info("\n🧪 Step 4: Test OAuth 2.0 Connection")
    logging.info("-" * 40)
    
    try:
        from google.cloud import compute_v1
        from google.auth import default
        
        # Test OAuth 2.0 authentication
        credentials, project_id = default()
        logging.info(f"✅ OAuth 2.0 authentication successful!")
        logging.info(f"📋 Project ID: {project_id}")
        logging.info(f"🔑 Auth Type: {type(credentials)
        
        # Test Compute Engine API
        client = compute_v1.InstancesClient()
        zones = client.list_zones(project=project_id)
        zone_count = len(list(zones))
        
        logging.info(f"✅ Compute Engine API working with OAuth 2.0!")
        logging.info(f"📊 Found {zone_count} zones")
        
        # Test GPU availability
        logging.info("\n🔍 Testing GPU availability...")
        try:
            machine_types = client.list_aggregated_items(project=project_id)
            gpu_types_found = 0
            
            for item in machine_types:
                if item.machine_type and 'gpu' in item.machine_type.name.lower():
                    gpu_types_found += 1
                    if gpu_types_found <= 3:  # Show first 3
                        logging.info(f"   📊 Found: {item.machine_type.name}")
            
            logging.info(f"✅ Found {gpu_types_found} GPU-enabled machine types")
            
        except Exception as e:
            logging.info(f"⚠️  Could not check GPU types: {e}")
        
        return True
        
    except Exception as e:
        logging.info(f"❌ OAuth 2.0 connection failed: {e}")
        logging.info("💡 Make sure your OAuth 2.0 Client ID has the right permissions")
        return False

def create_oauth2_config():
    """Create OAuth 2.0 configuration file"""
    logging.info("\n📄 Step 5: Create OAuth 2.0 Configuration")
    logging.info("-" * 40)
    
    config = {
        "oauth2_client_id": "112009677560035284778",
        "auth_method": "oauth2",
        "project_id": os.environ.get('GOOGLE_CLOUD_PROJECT', 'your-project-id'),
        "setup_date": # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...).strip(),
        "authentication_type": "OAuth 2.0 (No Service Account Keys)",
        "security_level": "High",
        "organization_policy": "iam.disableServiceAccountKeyCreation (Compliant)"
    }
    
    config_path = Path.home() / ".google" / "terradev-oauth2-config.json"
    config_path.parent.mkdir(exist_ok=True)
    
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    
    logging.info(f"✅ OAuth 2.0 configuration saved to: {config_path}")
    logging.info("🔐 This configuration is secure and compliant with your organization policy")

def main():
    """Main OAuth 2.0 setup function"""
    
    logging.info("🔐 Secure GCP OAuth 2.0 Setup for Terradev")
    logging.info("=" * 60)
    logging.info("📋 OAuth 2.0 Client ID: 112009677560035284778")
    logging.info("🔒 Organization Policy: iam.disableServiceAccountKeyCreation")
    logging.info("✅ Using OAuth 2.0 instead of service account keys")
    logging.info()
    
    # Step 1: Setup OAuth 2.0 authentication
    if not setup_oauth2_gcp_auth():
        logging.info("❌ Failed to setup OAuth 2.0 authentication")
        return
    
    # Step 2: Enable Compute Engine API
    if not enable_compute_api():
        logging.info("❌ Failed to enable Compute Engine API")
        logging.info("💡 You may need to ask your organization admin to enable this")
        return
    
    # Step 3: Test OAuth 2.0 connection
    if not test_oauth2_connection():
        logging.info("❌ OAuth 2.0 connection test failed")
        return
    
    # Step 4: Create configuration
    create_oauth2_config()
    
    logging.info("\n🎉 OAuth 2.0 GCP Setup Complete!")
    logging.info("=" * 60)
    logging.info("✅ Secure authentication configured")
    logging.info("✅ No service account keys used")
    logging.info("✅ Organization policy compliant")
    logging.info("✅ Compute Engine API enabled")
    logging.info()
    
    logging.info("🚀 Next Steps:")
    logging.info("1. Test the parallel race with OAuth 2.0:")
    logging.info("   python3 real_parallel_provisioning.py --race --gpu-type A100")
    logging.info("2. Add RunPod and Lambda Labs for 5-provider race:")
    logging.info("   export RUNPOD_API_KEY='your-runpod-key'")
    logging.info("   export LAMBDA_API_KEY='your-lambda-key'")
    logging.info("3. Run Terraform with OAuth 2.0:")
    logging.info("   cd terraform && terraform apply")
    logging.info()
    
    logging.info("🏁 Ready for secure parallel GPU provisioning!")

if __name__ == "__main__":
    main()
