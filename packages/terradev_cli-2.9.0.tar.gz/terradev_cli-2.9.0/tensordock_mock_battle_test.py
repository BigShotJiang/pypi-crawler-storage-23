#!/usr/bin/env python3
"""
TensorDock Mock Battle Test
Simulates TensorDock API responses for testing without hitting real API
"""

import asyncio
import json
import time
import logging
import random
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import statistics

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class TestMetrics:
    """Test metrics collection"""
    total_requests: int
    successful_requests: int
    failed_requests: int
    average_response_time: float
    max_response_time: float
    min_response_time: float
    throttled_requests: int
    errors: List[str]

class MockTensorDockAPI:
    """Mock TensorDock API for testing"""
    
    def __init__(self):
        self.instances = {}
        self.request_count = 0
        self.rate_limit_threshold = 10  # Allow 10 requests per minute
        self.request_times = []
    
    def _check_rate_limit(self) -> bool:
        """Check if request should be rate limited"""
        now = time.time()
        # Remove requests older than 1 minute
        self.request_times = [t for t in self.request_times if now - t < 60]
        
        if len(self.request_times) >= self.rate_limit_threshold:
            return True  # Rate limited
        
        self.request_times.append(now)
        return False
    
    def _simulate_response_time(self) -> float:
        """Simulate realistic response times"""
        base_time = 0.5  # Base response time
        variation = random.uniform(0.1, 2.0)  # Random variation
        return base_time + variation
    
    async def list_instances(self) -> Dict[str, Any]:
        """Mock list instances"""
        if self._check_rate_limit():
            raise Exception("429: Rate limit exceeded")
        
        await asyncio.sleep(self._simulate_response_time())
        
        return {
            "data": {
                "instances": [
                    {
                        "id": instance_id,
                        "name": instance_data["name"],
                        "status": instance_data["status"],
                        "resources": instance_data["resources"],
                        "rateHourly": instance_data["hourly_cost"]
                    }
                    for instance_id, instance_data in self.instances.items()
                ]
            }
        }
    
    async def get_instance(self, instance_id: str) -> Dict[str, Any]:
        """Mock get instance"""
        if self._check_rate_limit():
            raise Exception("429: Rate limit exceeded")
        
        await asyncio.sleep(self._simulate_response_time())
        
        if instance_id not in self.instances:
            raise Exception("404: Instance not found")
        
        instance_data = self.instances[instance_id]
        return {
            "id": instance_id,
            "name": instance_data["name"],
            "status": instance_data["status"],
            "resources": instance_data["resources"],
            "rateHourly": instance_data["hourly_cost"],
            "ipAddress": instance_data.get("ip_address")
        }
    
    async def create_instance(self, name: str, resources: Dict[str, Any]) -> Dict[str, Any]:
        """Mock create instance"""
        if self._check_rate_limit():
            raise Exception("429: Rate limit exceeded")
        
        await asyncio.sleep(self._simulate_response_time())
        
        instance_id = f"instance-{random.randint(1000, 9999)}"
        
        self.instances[instance_id] = {
            "name": name,
            "status": "running",
            "resources": resources,
            "hourly_cost": 1.0,
            "ip_address": f"192.168.1.{random.randint(100, 200)}"
        }
        
        return {
            "data": {
                "id": instance_id,
                "name": name,
                "status": "running"
            }
        }
    
    async def delete_instance(self, instance_id: str) -> Dict[str, Any]:
        """Mock delete instance"""
        if self._check_rate_limit():
            raise Exception("429: Rate limit exceeded")
        
        await asyncio.sleep(self._simulate_response_time())
        
        if instance_id not in self.instances:
            raise Exception("404: Instance not found")
        
        del self.instances[instance_id]
        
        return {
            "data": {
                "type": "success",
                "attributes": {
                    "message": "Instance deleted successfully"
                }
            }
        }

class TensorDockMockBattleTester:
    """Comprehensive TensorDock testing with mock API"""
    
    def __init__(self):
        self.api = MockTensorDockAPI()
        self.request_semaphore = asyncio.Semaphore(5)  # Limit concurrent requests
        
    async def _make_request(self, operation: str, *args, **kwargs) -> Dict[str, Any]:
        """Make request with rate limiting protection"""
        async with self.request_semaphore:
            start_time = time.time()
            
            try:
                if operation == "list_instances":
                    result = await self.api.list_instances()
                elif operation == "get_instance":
                    result = await self.api.get_instance(*args)
                elif operation == "create_instance":
                    result = await self.api.create_instance(*args)
                elif operation == "delete_instance":
                    result = await self.api.delete_instance(*args)
                else:
                    raise Exception(f"Unknown operation: {operation}")
                
                response_time = time.time() - start_time
                
                return {
                    "success": True,
                    "response_time": response_time,
                    "result": result
                }
                
            except Exception as e:
                response_time = time.time() - start_time
                
                return {
                    "success": False,
                    "response_time": response_time,
                    "error": str(e),
                    "throttled": "429" in str(e)
                }
    
    async def test_connection(self) -> TestMetrics:
        """Test basic connection"""
        logger.info("🔍 Testing basic connection...")
        
        start_time = time.time()
        result = await self._make_request("list_instances")
        response_time = time.time() - start_time
        
        successful = 1 if result["success"] else 0
        failed = 1 - successful
        throttled = 1 if result.get("throttled", False) else 0
        
        return TestMetrics(
            total_requests=1,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=response_time,
            max_response_time=response_time,
            min_response_time=response_time,
            throttled_requests=throttled,
            errors=[result["error"]] if not result["success"] else []
        )
    
    async def test_list_instances(self, concurrent_requests: int = 5) -> TestMetrics:
        """Test listing instances with concurrent requests"""
        logger.info(f"📋 Testing list instances with {concurrent_requests} concurrent requests...")
        
        tasks = []
        for i in range(concurrent_requests):
            task = asyncio.create_task(self._make_request("list_instances"))
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Aggregate results
        total_requests = len(results)
        successful = sum(1 for r in results if isinstance(r, dict) and r.get("success", False))
        failed = total_requests - successful
        
        response_times = [r.get("response_time", 0) for r in results if isinstance(r, dict)]
        errors = [r.get("error", "Unknown error") for r in results if isinstance(r, dict) and not r.get("success", False)]
        throttled = sum(1 for r in results if isinstance(r, dict) and r.get("throttled", False))
        
        return TestMetrics(
            total_requests=total_requests,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def test_instance_lifecycle(self, instance_count: int = 2) -> TestMetrics:
        """Test complete instance lifecycle"""
        logger.info(f"🔄 Testing instance lifecycle with {instance_count} instances...")
        
        total_requests = 0
        successful = 0
        failed = 0
        response_times = []
        errors = []
        throttled = 0
        created_instances = []
        
        try:
            # Create instances
            logger.info("📦 Creating instances...")
            for i in range(instance_count):
                result = await self._make_request(
                    "create_instance",
                    f"battle-test-{i}",
                    {
                        "vcpu_count": 4,
                        "ram_gb": 16,
                        "storage_gb": 100,
                        "gpus": {"geforcertx4090-pcie-24gb": {"count": 1}}
                    }
                )
                
                total_requests += 1
                response_times.append(result["response_time"])
                
                if result["success"]:
                    successful += 1
                    instance_id = result["result"]["data"]["id"]
                    created_instances.append(instance_id)
                    logger.info(f"✅ Created instance: battle-test-{i}")
                else:
                    failed += 1
                    errors.append(f"Create instance {i}: {result['error']}")
                    if result.get("throttled", False):
                        throttled += 1
                    logger.error(f"❌ Failed to create instance {i}: {result['error']}")
            
            # Wait for instances to be ready
            if created_instances:
                logger.info("⏳ Waiting for instances to be ready...")
                await asyncio.sleep(2)  # Simulate initialization
                
                # List instances
                logger.info("📋 Listing instances...")
                result = await self._make_request("list_instances")
                total_requests += 1
                response_times.append(result["response_time"])
                
                if result["success"]:
                    successful += 1
                    instances = result["result"]["data"]["instances"]
                    logger.info(f"✅ Listed {len(instances)} instances")
                else:
                    failed += 1
                    errors.append(f"List instances: {result['error']}")
                    if result.get("throttled", False):
                        throttled += 1
                
                # Get instance details
                for instance_id in created_instances:
                    result = await self._make_request("get_instance", instance_id)
                    total_requests += 1
                    response_times.append(result["response_time"])
                    
                    if result["success"]:
                        successful += 1
                    else:
                        failed += 1
                        errors.append(f"Get instance {instance_id}: {result['error']}")
                        if result.get("throttled", False):
                            throttled += 1
                
                # Clean up instances
                logger.info("🗑️ Cleaning up instances...")
                for instance_id in created_instances:
                    result = await self._make_request("delete_instance", instance_id)
                    total_requests += 1
                    response_times.append(result["response_time"])
                    
                    if result["success"]:
                        successful += 1
                        logger.info(f"✅ Deleted instance: {instance_id}")
                    else:
                        failed += 1
                        errors.append(f"Delete instance {instance_id}: {result['error']}")
                        if result.get("throttled", False):
                            throttled += 1
        
        except Exception as e:
            failed += 1
            errors.append(f"Lifecycle test: {str(e)}")
            logger.error(f"❌ Lifecycle test failed: {e}")
        
        return TestMetrics(
            total_requests=total_requests,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def test_load(self, duration_seconds: int = 30, requests_per_second: int = 3) -> TestMetrics:
        """Test sustained load"""
        logger.info(f"⚡ Testing sustained load: {requests_per_second} req/s for {duration_seconds}s...")
        
        start_time = time.time()
        end_time = start_time + duration_seconds
        
        total_requests = 0
        successful = 0
        failed = 0
        response_times = []
        errors = []
        throttled = 0
        
        while time.time() < end_time:
            try:
                # Make a request
                result = await self._make_request("list_instances")
                
                total_requests += 1
                response_times.append(result["response_time"])
                
                if result["success"]:
                    successful += 1
                else:
                    failed += 1
                    errors.append(result["error"])
                    if result.get("throttled", False):
                        throttled += 1
                
                # Wait to maintain rate
                await asyncio.sleep(1.0 / requests_per_second)
                
            except Exception as e:
                failed += 1
                errors.append(str(e))
                total_requests += 1
                
                # Still wait to maintain rate
                await asyncio.sleep(1.0 / requests_per_second)
        
        actual_duration = time.time() - start_time
        actual_rps = total_requests / actual_duration
        
        logger.info(f"📊 Load test completed: {actual_rps:.2f} req/s over {actual_duration:.1f}s")
        
        return TestMetrics(
            total_requests=total_requests,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def test_rate_limiting(self) -> TestMetrics:
        """Test rate limiting behavior"""
        logger.info("🚦 Testing rate limiting...")
        
        total_requests = 15  # More than the rate limit threshold
        successful = 0
        failed = 0
        response_times = []
        errors = []
        throttled = 0
        
        # Make rapid requests to trigger rate limiting
        tasks = []
        for i in range(total_requests):
            task = asyncio.create_task(self._make_request("list_instances"))
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for result in results:
            if isinstance(result, dict):
                total_requests += 1
                response_times.append(result.get("response_time", 0))
                
                if result.get("success", False):
                    successful += 1
                else:
                    failed += 1
                    errors.append(result.get("error", "Unknown error"))
                    if result.get("throttled", False):
                        throttled += 1
        
        return TestMetrics(
            total_requests=total_requests,
            successful_requests=successful,
            failed_requests=failed,
            average_response_time=statistics.mean(response_times) if response_times else 0,
            max_response_time=max(response_times) if response_times else 0,
            min_response_time=min(response_times) if response_times else 0,
            throttled_requests=throttled,
            errors=errors
        )
    
    async def run_battle_test(self) -> Dict[str, Any]:
        """Run comprehensive battle test"""
        logger.info("🚀 Starting TensorDock Mock Battle Test")
        logger.info("=" * 50)
        
        results = {}
        
        # Test 1: Basic Connection
        logger.info("\n🔍 Test 1: Basic Connection")
        results["connection"] = await self.test_connection()
        
        # Test 2: List Instances (Concurrent)
        logger.info("\n📋 Test 2: List Instances (Concurrent)")
        results["list_instances"] = await self.test_list_instances(concurrent_requests=5)
        
        # Test 3: Instance Lifecycle
        logger.info("\n🔄 Test 3: Instance Lifecycle")
        results["lifecycle"] = await self.test_instance_lifecycle(instance_count=2)
        
        # Test 4: Rate Limiting
        logger.info("\n🚦 Test 4: Rate Limiting")
        results["rate_limiting"] = await self.test_rate_limiting()
        
        # Test 5: Sustained Load
        logger.info("\n⚡ Test 5: Sustained Load")
        results["load"] = await self.test_load(duration_seconds=20, requests_per_second=3)
        
        # Generate summary
        logger.info("\n📊 Mock Battle Test Results Summary")
        logger.info("=" * 50)
        
        total_requests = sum(r.total_requests for r in results.values())
        total_successful = sum(r.successful_requests for r in results.values())
        total_failed = sum(r.failed_requests for r in results.values())
        total_throttled = sum(r.throttled_requests for r in results.values())
        
        success_rate = (total_successful / total_requests * 100) if total_requests > 0 else 0
        throttle_rate = (total_throttled / total_requests * 100) if total_requests > 0 else 0
        
        logger.info(f"📈 Total Requests: {total_requests}")
        logger.info(f"✅ Successful: {total_successful} ({success_rate:.1f}%)")
        logger.info(f"❌ Failed: {total_failed} ({100-success_rate:.1f}%)")
        logger.info(f"⚠️ Throttled: {total_throttled} ({throttle_rate:.1f}%)")
        
        # Detailed results
        for test_name, metrics in results.items():
            logger.info(f"\n📋 {test_name.replace('_', ' ').title()}:")
            logger.info(f"   Requests: {metrics.total_requests}")
            logger.info(f"   Success: {metrics.successful_requests}")
            logger.info(f"   Failed: {metrics.failed_requests}")
            logger.info(f"   Avg Response: {metrics.average_response_time:.2f}s")
            logger.info(f"   Max Response: {metrics.max_response_time:.2f}s")
            logger.info(f"   Min Response: {metrics.min_response_time:.2f}s")
            
            if metrics.errors:
                logger.info(f"   Errors: {len(metrics.errors)}")
                for error in metrics.errors[:3]:  # Show first 3 errors
                    logger.info(f"     - {error}")
        
        # Overall assessment
        logger.info(f"\n🎯 Overall Assessment:")
        if success_rate >= 95:
            logger.info("✅ EXCELLENT - System performing very well")
        elif success_rate >= 90:
            logger.info("✅ GOOD - System performing well")
        elif success_rate >= 80:
            logger.info("⚠️ FAIR - System has some issues")
        else:
            logger.info("❌ POOR - System has significant issues")
        
        if throttle_rate > 20:
            logger.info("⚠️ High throttling detected - rate limiting is working")
        elif throttle_rate > 10:
            logger.info("ℹ️ Moderate throttling - rate limiting is working")
        else:
            logger.info("✅ Low throttling - rate limiting is effective")
        
        return {
            "summary": {
                "total_requests": total_requests,
                "successful_requests": total_successful,
                "failed_requests": total_failed,
                "throttled_requests": total_throttled,
                "success_rate": success_rate,
                "throttle_rate": throttle_rate
            },
            "detailed_results": results
        }

async def main():
    """Main mock battle test function"""
    tester = TensorDockMockBattleTester()
    
    results = await tester.run_battle_test()
    
    # Save results to file
    results_file = "tensordock_mock_battle_test_results.json"
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    logger.info(f"\n💾 Results saved to {results_file}")
    
    # Return summary
    return results["summary"]

if __name__ == "__main__":
    asyncio.run(main())
