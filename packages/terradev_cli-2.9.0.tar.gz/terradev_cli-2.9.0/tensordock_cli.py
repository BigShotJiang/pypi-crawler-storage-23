import logging

#!/usr/bin/env python3
"""
TensorDock CLI Tool
Command-line interface for TensorDock GPU cloud management
"""

import asyncio
import argparse
import json
import sys
from pathlib import Path
from typing import Optional

from tensordock_integration import TensorDockManager, TensorDockCredentials
from tensordock_provider import TensorDockProvider
from tensordock_deployment import TensorDockDeploymentManager

class TensorDockCLI:
    """TensorDock command-line interface"""
    
    def __init__(self):
        self.credentials = self._load_credentials()
        self.manager = TensorDockManager(self.credentials)
        self.provider = TensorDockProvider(
            client_id=self.credentials.client_id,
            api_token=self.credentials.api_token
        )
        self.deployment_manager = TensorDockDeploymentManager()
    
    def _load_credentials(self) -> TensorDockCredentials:
        """Load credentials from environment or file"""
        import os
        
        # Try environment variables first
        client_id = os.getenv("TENSORDOCK_CLIENT_ID")
        api_token = os.getenv("TENSORDOCK_API_TOKEN")
        
        if client_id and api_token:
            return TensorDockCredentials(client_id=client_id, api_token=api_token)
        
        # Try credentials file
        creds_file = Path("tensordock_credentials.json")
        if creds_file.exists():
            with open(creds_file, 'r') as f:
                data = json.load(f)
                return TensorDockCredentials(
                    client_id=data["client_id"],
                    api_token=data["api_token"]
                )
        
        # Use demo credentials
        return TensorDockCredentials(
            client_id="6f71b631-5a32-42f1-94a5-d089adffdb24",
            api_token = os.environ.get("TOKEN_API_TOKEN", "rxOI1pnIZ9UL3J8MZmMmYBkKk7EwPdyS")
        )
    
    async def list_instances(self, format_type: str = "table") -> None:
        """List all instances"""
        logging.info("📋 Listing TensorDock instances...")
        
        try:
            async with self.provider:
                instances = await self.provider.list_instances()
                
                if not instances:
                    logging.info("No instances found.")
                    return
                
                if format_type == "json":
                    instance_data = []
                    for instance in instances:
                        instance_data.append({
                            "id": instance.id,
                            "name": instance.name,
                            "status": instance.status.value,
                            "cpu": instance.cpu_count,
                            "memory": instance.memory_gb,
                            "gpu_model": instance.gpu_model,
                            "gpu_count": instance.gpu_count,
                            "hourly_cost": instance.hourly_cost,
                            "ip": instance.ip_address
                        })
                    logging.info(json.dumps(instance_data, indent=2)
                
                elif format_type == "table":
                    logging.info(f"{'ID':<20} {'Name':<20} {'Status':<12} {'CPU':<4} {'RAM':<6} {'GPU':<15} {'Cost/hr':<8} {'IP':<15}")
                    logging.info("-" * 110)
                    
                    for instance in instances:
                        gpu_info = f"{instance.gpu_model}x{instance.gpu_count}"
                        print(f"{instance.id:<20} {instance.name:<20} {instance.status.value:<12} "
                              f"{instance.cpu_count:<4} {instance.memory_gb:<6}GB {gpu_info:<15} "
                              f"${instance.hourly_cost:<7.2f} {instance.ip_address or 'N/A':<15}")
                
        except Exception as e:
            logging.info(f"❌ Error listing instances: {e}")
    
    async def create_instance(self, name: str, instance_type: str, region: Optional[str] = None) -> None:
        """Create a new instance"""
        logging.info(f"🚀 Creating instance: {name} (type: {instance_type})
        
        try:
            async with self.provider:
                instance = await self.provider.create_ml_instance(
                    name=name,
                    instance_type=instance_type,
                    region=region
                )
                
                logging.info(f"✅ Instance created successfully!")
                logging.info(f"   ID: {instance.id}")
                logging.info(f"   Name: {instance.name}")
                logging.info(f"   Status: {instance.status.value}")
                logging.info(f"   Type: {instance.instance_type}")
                logging.info(f"   Hourly Cost: ${instance.hourly_cost}")
                
        except Exception as e:
            logging.info(f"❌ Error creating instance: {e}")
    
    async def get_instance(self, instance_id: str) -> None:
        """Get instance details"""
        logging.info(f"🔍 Getting instance details: {instance_id}")
        
        try:
            async with self.provider:
                instance = await self.provider.get_instance(instance_id)
                
                if not instance:
                    logging.info("Instance not found.")
                    return
                
                logging.info(f"📊 Instance Details:")
                logging.info(f"   ID: {instance.id}")
                logging.info(f"   Name: {instance.name}")
                logging.info(f"   Status: {instance.status.value}")
                logging.info(f"   Provider: {instance.provider}")
                logging.info(f"   Region: {instance.region}")
                logging.info(f"   Type: {instance.instance_type}")
                logging.info(f"   CPU: {instance.cpu_count} cores")
                logging.info(f"   Memory: {instance.memory_gb} GB")
                logging.info(f"   Storage: {instance.storage_gb} GB")
                logging.info(f"   GPU: {instance.gpu_model} x{instance.gpu_count}")
                logging.info(f"   Hourly Cost: ${instance.hourly_cost}")
                logging.info(f"   IP Address: {instance.ip_address or 'N/A'}")
                
        except Exception as e:
            logging.info(f"❌ Error getting instance: {e}")
    
    async def start_instance(self, instance_id: str) -> None:
        """Start an instance"""
        logging.info(f"▶️ Starting instance: {instance_id}")
        
        try:
            async with self.provider:
                success = await self.provider.start_instance(instance_id)
                
                if success:
                    logging.info(f"✅ Instance started successfully!")
                else:
                    logging.info(f"❌ Failed to start instance")
                    
        except Exception as e:
            logging.info(f"❌ Error starting instance: {e}")
    
    async def stop_instance(self, instance_id: str) -> None:
        """Stop an instance"""
        logging.info(f"⏹️ Stopping instance: {instance_id}")
        
        try:
            async with self.provider:
                success = await self.provider.stop_instance(instance_id)
                
                if success:
                    logging.info(f"✅ Instance stopped successfully!")
                else:
                    logging.info(f"❌ Failed to stop instance")
                    
        except Exception as e:
            logging.info(f"❌ Error stopping instance: {e}")
    
    async def delete_instance(self, instance_id: str) -> None:
        """Delete an instance"""
        logging.info(f"🗑️ Deleting instance: {instance_id}")
        
        try:
            async with self.provider:
                success = await self.provider.delete_instance(instance_id)
                
                if success:
                    logging.info(f"✅ Instance deleted successfully!")
                else:
                    logging.info(f"❌ Failed to delete instance")
                    
        except Exception as e:
            logging.info(f"❌ Error deleting instance: {e}")
    
    async def get_instance_types(self) -> None:
        """Get available instance types"""
        logging.info("📋 Available Instance Types:")
        
        try:
            instance_types = await self.provider.get_instance_types()
            
            logging.info(f"{'Type':<15} {'CPU':<4} {'RAM':<6} {'Storage':<8} {'GPU':<15} {'Hourly':<8} {'Monthly':<9}")
            logging.info("-" * 75)
            
            for instance_type, config in instance_types.items():
                pricing = await self.provider.get_pricing(instance_type)
                gpu_info = f"{config['gpu']}x{config['gpu_count']}"
                print(f"{instance_type:<15} {config['cpu']:<4} {config['memory']:<6}GB "
                      f"{config['storage']:<8}GB {gpu_info:<15} ${pricing['hourly']:<7.2f} ${pricing['monthly']:<8.0f}")
                
        except Exception as e:
            logging.info(f"❌ Error getting instance types: {e}")
    
    async def deploy_environment(self, config_name: str) -> None:
        """Deploy a complete environment"""
        logging.info(f"🏗️ Deploying environment: {config_name}")
        
        try:
            instances = await self.deployment_manager.deploy_environment(config_name)
            
            logging.info(f"✅ Environment deployed successfully!")
            logging.info(f"   Configuration: {config_name}")
            logging.info(f"   Instances created: {len(instances)
            logging.info(f"   Instance IDs: {instances}")
            
        except Exception as e:
            logging.info(f"❌ Error deploying environment: {e}")
    
    async def get_deployment_status(self, config_name: str) -> None:
        """Get deployment status"""
        logging.info(f"📊 Deployment status: {config_name}")
        
        try:
            status = await self.deployment_manager.get_deployment_status(config_name)
            
            if status.get("status") == "not_found":
                logging.info("Deployment not found.")
                return
            
            logging.info(f"📈 Deployment Overview:")
            logging.info(f"   Configuration: {status['config']['name']}")
            logging.info(f"   Environment: {status['config']['environment']}")
            logging.info(f"   Total nodes: {status['node_count']}")
            logging.info(f"   Running nodes: {status['running_nodes']}")
            logging.info(f"   Total hourly cost: ${status['total_hourly_cost']:.2f}")
            
            logging.info(f"\n🖥️ Instance Details:")
            for instance in status["instances"]:
                logging.info(f"   {instance['name']} ({instance['id']})
                logging.info(f"     Status: {instance['status']}")
                logging.info(f"     IP: {instance['ip'] or 'N/A'}")
                logging.info(f"     Cost: ${instance['hourly_cost']}/hour")
                
        except Exception as e:
            logging.info(f"❌ Error getting deployment status: {e}")
    
    async def scale_deployment(self, config_name: str, target_nodes: int) -> None:
        """Scale deployment"""
        logging.info(f"📈 Scaling deployment: {config_name} to {target_nodes} nodes")
        
        try:
            instances = await self.deployment_manager.scale_deployment(config_name, target_nodes)
            
            logging.info(f"✅ Deployment scaled successfully!")
            logging.info(f"   Target nodes: {target_nodes}")
            logging.info(f"   Current instances: {len(instances)
            
        except Exception as e:
            logging.info(f"❌ Error scaling deployment: {e}")
    
    async def destroy_deployment(self, config_name: str) -> None:
        """Destroy deployment"""
        logging.info(f"💥 Destroying deployment: {config_name}")
        
        try:
            success = await self.deployment_manager.destroy_deployment(config_name)
            
            if success:
                logging.info(f"✅ Deployment destroyed successfully!")
            else:
                logging.info(f"❌ Failed to destroy deployment")
                
        except Exception as e:
            logging.info(f"❌ Error destroying deployment: {e}")
    
    async def get_cost_report(self, config_name: str, hours: int = 24) -> None:
        """Get cost report"""
        logging.info(f"💰 Cost report for {config_name} ({hours} hours)
        
        try:
            report = await self.deployment_manager.get_cost_report(config_name, hours)
            
            if "error" in report:
                logging.info(f"❌ {report['error']}")
                return
            
            logging.info(f"💸 Cost Analysis:")
            logging.info(f"   Deployment: {report['deployment']}")
            logging.info(f"   Hourly cost: ${report['hourly_cost']:.2f}")
            logging.info(f"   {hours}-hour cost: ${report[f'{hours}_hour_cost']:.2f}")
            logging.info(f"   Daily cost: ${report['daily_cost']:.2f}")
            logging.info(f"   Monthly cost: ${report['monthly_cost']:.2f}")
            logging.info(f"   Node count: {report['node_count']}")
            logging.info(f"   Cost per node: ${report['cost_per_node']:.2f}")
            
        except Exception as e:
            logging.info(f"❌ Error generating cost report: {e}")

def create_parser() -> argparse.ArgumentParser:
    """Create command-line argument parser"""
    parser = argparse.ArgumentParser(
        description="TensorDock CLI - GPU Cloud Management",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s list-instances                          # List all instances
  %(prog)s create-instance my-ml ml-medium         # Create ML instance
  %(prog)s get-instance abc123                     # Get instance details
  %(prog)s start-instance abc123                   # Start instance
  %(prog)s deploy ml-development                   # Deploy environment
  %(prog)s scale ml-development 5                  # Scale to 5 nodes
  %(prog)s cost ml-development 24                  # 24-hour cost report
        """
    )
    
    # Subcommands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Instance management
    list_parser = subparsers.add_parser("list-instances", help="List all instances")
    list_parser.add_argument("--format", choices=["table", "json"], default="table", help="Output format")
    
    create_parser = subparsers.add_parser("create-instance", help="Create a new instance")
    create_parser.add_argument("name", help="Instance name")
    create_parser.add_argument("type", help="Instance type (ml-small, ml-medium, ml-large, training)")
    create_parser.add_argument("--region", help="Region/Location")
    
    get_parser = subparsers.add_parser("get-instance", help="Get instance details")
    get_parser.add_argument("id", help="Instance ID")
    
    start_parser = subparsers.add_parser("start-instance", help="Start an instance")
    start_parser.add_argument("id", help="Instance ID")
    
    stop_parser = subparsers.add_parser("stop-instance", help="Stop an instance")
    stop_parser.add_argument("id", help="Instance ID")
    
    delete_parser = subparsers.add_parser("delete-instance", help="Delete an instance")
    delete_parser.add_argument("id", help="Instance ID")
    
    types_parser = subparsers.add_parser("instance-types", help="Get available instance types")
    
    # Deployment management
    deploy_parser = subparsers.add_parser("deploy", help="Deploy environment")
    deploy_parser.add_argument("config", help="Deployment configuration name")
    
    status_parser = subparsers.add_parser("deployment-status", help="Get deployment status")
    status_parser.add_argument("config", help="Deployment configuration name")
    
    scale_parser = subparsers.add_parser("scale", help="Scale deployment")
    scale_parser.add_argument("config", help="Deployment configuration name")
    scale_parser.add_argument("nodes", type=int, help="Target number of nodes")
    
    destroy_parser = subparsers.add_parser("destroy", help="Destroy deployment")
    destroy_parser.add_argument("config", help="Deployment configuration name")
    
    cost_parser = subparsers.add_parser("cost", help="Get cost report")
    cost_parser.add_argument("config", help="Deployment configuration name")
    cost_parser.add_argument("--hours", type=int, default=24, help="Number of hours for cost calculation")
    
    return parser

async def main():
    """Main CLI function"""
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    cli = TensorDockCLI()
    
    try:
        if args.command == "list-instances":
            await cli.list_instances(args.format)
        
        elif args.command == "create-instance":
            await cli.create_instance(args.name, args.type, args.region)
        
        elif args.command == "get-instance":
            await cli.get_instance(args.id)
        
        elif args.command == "start-instance":
            await cli.start_instance(args.id)
        
        elif args.command == "stop-instance":
            await cli.stop_instance(args.id)
        
        elif args.command == "delete-instance":
            await cli.delete_instance(args.id)
        
        elif args.command == "instance-types":
            await cli.get_instance_types()
        
        elif args.command == "deploy":
            await cli.deploy_environment(args.config)
        
        elif args.command == "deployment-status":
            await cli.get_deployment_status(args.config)
        
        elif args.command == "scale":
            await cli.scale_deployment(args.config, args.nodes)
        
        elif args.command == "destroy":
            await cli.destroy_deployment(args.config)
        
        elif args.command == "cost":
            await cli.get_cost_report(args.config, args.hours)
        
        else:
            logging.info(f"Unknown command: {args.command}")
            parser.print_help()
    
    except KeyboardInterrupt:
        logging.info("\n⚠️ Operation cancelled by user")
    except Exception as e:
        logging.info(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
