import os

#!/usr/bin/env python3
"""
Vast.ai Specialized Gamma-Optimized Arbitrage Engine
Focus on host quality, interruption probability, and latency variance
"""

import asyncio
import aiohttp
import json
import logging
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import statistics
import time

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class VastHost:
    """Vast.ai host with quality metrics"""
    host_id: str
    machine_id: str
    gpu_name: str
    gpu_ram: int
    cpu_cores: int
    cpu_ram: int
    disk_space: int
    min_bid: float
    reliability: float
    geolocation: str
    datacenter: str
    cuda_max: float
    driver_version: str
    external: bool
    rentable: bool
    
    # Host quality metrics
    churn_rate: float = 0.0
    mean_time_to_failure: float = 0.0
    mean_startup_latency: float = 0.0
    interruption_probability: float = 0.0
    host_reputation: float = 0.5  # 0-1 scale
    offer_lifetime: float = 0.0
    
    # Performance metrics
    actual_performance: float = 0.0
    expected_performance: float = 0.0
    performance_variance: float = 0.0

@dataclass
class SyntheticJobProbe:
    """Synthetic job probe results"""
    host_id: str
    probe_time: datetime
    startup_latency: float
    job_duration: float
    success: bool
    error_message: str = ""
    
@dataclass
class WebPageTestProbe:
    """WebPageTest TTFB probe results"""
    host_id: str
    probe_time: datetime
    ttfb_ms: float
    success: bool
    error_message: str = ""

@dataclass
class VastGammaOpportunity:
    """Vast.ai gamma-optimized arbitrage opportunity"""
    host: VastHost
    expected_cost: float
    expected_runtime: float
    interrupt_penalty: float
    gamma_score: float
    interruption_probability: float
    host_reputation_score: float
    latency_variance_penalty: float
    total_score: float

class VastGammaEngine:
    """
    Vast.ai specialized gamma-optimized arbitrage engine
    Focus on host quality, interruption probability, and latency variance
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://console.vast.ai/api/v0"
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        # Host reputation tracking
        self.host_reputation = {}  # host_id -> reputation score
        self.host_metrics = {}  # host_id -> performance metrics
        
        # Probe results
        self.synthetic_probes = []  # List of SyntheticJobProbe
        self.webpage_probes = []  # List of WebPageTestProbe
        
        # Interruption probability model (simple histogram)
        self.interruption_histogram = {}  # host_id -> [success, failure] counts
        
        # Performance tracking
        self.performance_history = {}  # host_id -> list of performance metrics
        
        # Gamma sensitivity parameters
        self.gamma_sensitivity = 0.3  # How sensitive we are to convexity
        self.latency_weight = 0.4  # Weight for latency variance
        self.reputation_weight = 0.3  # Weight for host reputation
        
        # Probe intervals
        self.synthetic_probe_interval = timedelta(minutes=5)
        self.webpage_probe_interval = timedelta(minutes=10)
        
        # Host quality thresholds
        self.max_churn_rate = 0.2  # 20% churn rate threshold
        self.min_reputation = 0.3  # Minimum reputation score
        self.max_interruption_prob = 0.1  # 10% interruption probability threshold
    
    async def search_vast_offers(self, gpu_type: str = None, min_reliability: float = 0.8) -> List[VastHost]:
        """Search for Vast.ai offers with host quality filtering"""
        
        try:
            # Build search filters
            filters = {
                "rentable": {"eq": True},
                "reliability": {"gte": min_reliability}
            }
            
            if gpu_type:
                filters["gpu_name"] = {"eq": gpu_type}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.base_url}/asks/",
                    headers=self.headers,
                    params={"select_filters": json.dumps(filters)}
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        hosts = []
                        
                        for offer_data in data.get("asks", []):
                            host = VastHost(
                                host_id=f"{offer_data.get('machine_id', '')}_{offer_data.get('id', '')}",
                                machine_id=offer_data.get("machine_id", ""),
                                gpu_name=offer_data.get("gpu_name", ""),
                                gpu_ram=offer_data.get("gpu_ram", 0),
                                cpu_cores=offer_data.get("cpu_cores", 0),
                                cpu_ram=offer_data.get("cpu_ram", 0),
                                disk_space=offer_data.get("disk_space", 0),
                                min_bid=offer_data.get("min_bid", 0),
                                reliability=offer_data.get("reliability", 0),
                                geolocation=offer_data.get("geolocation", ""),
                                datacenter=offer_data.get("datacenter", ""),
                                cuda_max=offer_data.get("cuda_max", 0),
                                driver_version=offer_data.get("driver_version", ""),
                                external=offer_data.get("external", False),
                                rentable=offer_data.get("rentable", False),
                                host_reputation=self.host_reputation.get(
                                    f"{offer_data.get('machine_id', '')}_{offer_data.get('id', '')}", 
                                    0.5
                                )
                            )
                            hosts.append(host)
                        
                        return hosts
                    else:
                        logger.error(f"Vast.ai search failed: {response.status}")
                        return []
        except Exception as e:
            logger.error(f"Vast.ai search error: {e}")
            return []
    
    async def run_synthetic_job_probe(self, host: VastHost) -> Optional[SyntheticJobProbe]:
        """Run synthetic job probe to measure startup latency and job performance"""
        
        try:
            # Simulate synthetic job probe
            # In production, this would be an actual job submission
            probe_start = time.time()
            
            # Simulate job startup latency (based on host quality)
            base_latency = 30.0  # 30 seconds base startup
            quality_factor = host.host_reputation * host.reliability
            startup_latency = base_latency / quality_factor
            
            # Simulate job duration
            job_duration = 60.0  # 1 minute synthetic job
            
            # Simulate success based on host quality
            success_probability = host.host_reputation * host.reliability
            success = np.random.random() < success_probability
            
            probe = SyntheticJobProbe(
                host_id=host.host_id,
                probe_time=datetime.now(),
                startup_latency=startup_latency,
                job_duration=job_duration,
                success=success,
                error_message="Simulated probe" if not success else ""
            )
            
            # Update host metrics
            self._update_host_metrics(host, probe)
            
            return probe
            
        except Exception as e:
            logger.error(f"Synthetic job probe error for {host.host_id}: {e}")
            return None
    
    async def run_webpage_test_probe(self, host: VastHost) -> Optional[WebPageTestProbe]:
        """Run WebPageTest TTFB probe to measure network latency"""
        
        try:
            # Simulate WebPageTest TTFB probe
            # In production, this would use actual WebPageTest API
            probe_start = time.time()
            
            # Simulate TTFB based on host quality and geolocation
            base_ttfb = 100.0  # 100ms base TTFB
            quality_factor = host.host_reputation * host.reliability
            
            # Geographic penalty
            geo_penalty = 1.0
            if host.geolocation.lower() in ["asia", "australia"]:
                geo_penalty = 2.0
            elif host.geolocation.lower() in ["europe"]:
                geo_penalty = 1.5
            
            ttfb_ms = (base_ttfb / quality_factor) * geo_penalty
            
            # Simulate success
            success = np.random.random() < (host.host_reputation * host.reliability)
            
            probe = WebPageTestProbe(
                host_id=host.host_id,
                probe_time=datetime.now(),
                ttfb_ms=ttfb_ms,
                success=success,
                error_message="Simulated probe" if not success else ""
            )
            
            return probe
            
        except Exception as e:
            logger.error(f"WebPageTest probe error for {host.host_id}: {e}")
            return None
    
    def _update_host_metrics(self, host: VastHost, probe: SyntheticJobProbe):
        """Update host metrics based on probe results"""
        
        host_id = host.host_id
        
        # Update interruption probability
        if host_id not in self.interruption_histogram:
            self.interruption_histogram[host_id] = [0, 0]  # [success, failure]
        
        if probe.success:
            self.interruption_histogram[host_id][0] += 1
        else:
            self.interruption_histogram[host_id][1] += 1
        
        # Calculate interruption probability
        total_probes = sum(self.interruption_histogram[host_id])
        if total_probes > 0:
            host.interruption_probability = self.interruption_histogram[host_id][1] / total_probes
        
        # Update performance metrics
        if host_id not in self.performance_history:
            self.performance_history[host_id] = []
        
        performance_score = 1.0 / (probe.startup_latency + probe.job_duration)
        self.performance_history[host_id].append(performance_score)
        
        # Keep only last 10 probes
        if len(self.performance_history[host_id]) > 10:
            self.performance_history[host_id] = self.performance_history[host_id][-10:]
        
        # Update host performance metrics
        if len(self.performance_history[host_id]) > 0:
            host.actual_performance = statistics.mean(self.performance_history[host_id])
            host.expected_performance = host.reliability * host.host_reputation
            host.performance_variance = statistics.stdev(self.performance_history[host_id]) if len(self.performance_history[host_id]) > 1 else 0.0
        
        # Update host reputation
        self._update_host_reputation(host, probe)
    
    def _update_host_reputation(self, host: VastHost, probe: SyntheticJobProbe):
        """Update host reputation based on probe results"""
        
        host_id = host.host_id
        
        # Initialize reputation if not exists
        if host_id not in self.host_reputation:
            self.host_reputation[host_id] = 0.5
        
        # Update reputation based on probe success
        if probe.success:
            # Increase reputation for successful probes
            self.host_reputation[host_id] = min(1.0, self.host_reputation[host_id] + 0.05)
        else:
            # Decrease reputation for failed probes
            self.host_reputation[host_id] = max(0.0, self.host_reputation[host_id] - 0.1)
        
        # Update host reputation score
        host.host_reputation = self.host_reputation[host_id]
    
    def calculate_gamma_optimized_opportunity(self, host: VastHost, 
                                            job_runtime: float = 3600.0) -> VastGammaOpportunity:
        """Calculate gamma-optimized arbitrage opportunity"""
        
        # Expected runtime = job_runtime + expected_startup_latency
        expected_startup_latency = host.mean_startup_latency if host.mean_startup_latency > 0 else 60.0
        expected_runtime = job_runtime + expected_startup_latency
        
        # Interrupt penalty based on interruption probability
        interrupt_penalty = host.interruption_probability * 2.0  # 2x penalty for interruptions
        
        # Expected cost = price * expected_runtime * (1 + interrupt_penalty)
        expected_cost = host.min_bid * expected_runtime * (1 + interrupt_penalty)
        
        # Gamma score (convexity sensitivity)
        gamma_score = 1.0 - (host.performance_variance * self.gamma_sensitivity)
        
        # Host reputation score
        reputation_score = host.host_reputation
        
        # Latency variance penalty
        latency_variance_penalty = host.performance_variance * self.latency_weight
        
        # Total score
        total_score = (
            gamma_score * 0.3 +
            reputation_score * self.reputation_weight +
            (1.0 - latency_variance_penalty) * self.latency_weight +
            (1.0 - host.interruption_probability) * 0.2
        )
        
        return VastGammaOpportunity(
            host=host,
            expected_cost=expected_cost,
            expected_runtime=expected_runtime,
            interrupt_penalty=interrupt_penalty,
            gamma_score=gamma_score,
            interruption_probability=host.interruption_probability,
            host_reputation_score=reputation_score,
            latency_variance_penalty=latency_variance_penalty,
            total_score=total_score
        )
    
    async def analyze_vast_gamma_opportunities(self, gpu_type: str = "A100", 
                                              job_runtime: float = 3600.0) -> List[VastGammaOpportunity]:
        """Analyze Vast.ai gamma-optimized arbitrage opportunities"""
        
        logger.info(f"🎯 Analyzing Vast.ai gamma opportunities for {gpu_type}")
        
        # Search for offers
        hosts = await self.search_vast_offers(gpu_type)
        
        if not hosts:
            logger.warning(f"No Vast.ai offers found for {gpu_type}")
            return []
        
        # Filter hosts by quality criteria
        quality_hosts = []
        for host in hosts:
            if (host.host_reputation >= self.min_reputation and
                host.interruption_probability <= self.max_interruption_prob):
                quality_hosts.append(host)
        
        logger.info(f"✅ Found {len(quality_hosts)} quality hosts out of {len(hosts)} total")
        
        # Calculate gamma-optimized opportunities
        opportunities = []
        for host in quality_hosts:
            opportunity = self.calculate_gamma_optimized_opportunity(host, job_runtime)
            opportunities.append(opportunity)
        
        # Sort by total score (descending)
        opportunities.sort(key=lambda x: x.total_score, reverse=True)
        
        return opportunities
    
    async def run_probes_for_hosts(self, hosts: List[VastHost], 
                                 synthetic_count: int = 3, 
                                 webpage_count: int = 2):
        """Run probes for a list of hosts"""
        
        logger.info(f"🔍 Running probes for {len(hosts)} hosts")
        
        # Run synthetic job probes
        synthetic_tasks = []
        for host in hosts[:synthetic_count]:
            task = asyncio.create_task(self.run_synthetic_job_probe(host))
            synthetic_tasks.append(task)
        
        # Run WebPageTest probes
        webpage_tasks = []
        for host in hosts[:webpage_count]:
            task = asyncio.create_task(self.run_webpage_test_probe(host))
            webpage_tasks.append(task)
        
        # Wait for all probes to complete
        if synthetic_tasks:
            synthetic_results = await asyncio.gather(*synthetic_tasks, return_exceptions=True)
            for result in synthetic_results:
                if isinstance(result, SyntheticJobProbe):
                    self.synthetic_probes.append(result)
                elif isinstance(result, Exception):
                    logger.error(f"Synthetic probe error: {result}")
        
        if webpage_tasks:
            webpage_results = await asyncio.gather(*webpage_tasks, return_exceptions=True)
            for result in webpage_results:
                if isinstance(result, WebPageTestProbe):
                    self.webpage_probes.append(result)
                elif isinstance(result, Exception):
                    logger.error(f"WebPageTest probe error: {result}")
        
        logger.info(f"✅ Completed {len(synthetic_tasks)} synthetic probes and {len(webpage_tasks)} webpage probes")
    
    def get_host_quality_summary(self) -> Dict:
        """Get summary of host quality metrics"""
        
        if not self.host_reputation:
            return {"error": "No host data available"}
        
        reputations = list(self.host_reputation.values())
        interruptions = [host.interruption_probability # TODO: OPTIMIZATION - Use more efficient pattern for .keys() iteration
# ('host', 'self.host_reputation')]
        
        return {
            "total_hosts": len(self.host_reputation),
            "avg_reputation": statistics.mean(reputations),
            "reputation_std": statistics.stdev(reputations) if len(reputations) > 1 else 0,
            "avg_interruption_prob": statistics.mean(interruptions),
            "interruption_std": statistics.stdev(interruptions) if len(interruptions) > 1 else 0,
            "high_quality_hosts": len([r for r in reputations if r >= 0.8]),
            "low_quality_hosts": len([r for r in reputations if r < 0.3]),
            "total_synthetic_probes": len(self.synthetic_probes),
            "total_webpage_probes": len(self.webpage_probes),
            "probe_success_rate": (
                len([p for p in self.synthetic_probes if p.success]) / len(self.synthetic_probes)
                if self.synthetic_probes else 0
            )
        }

# Test Vast.ai gamma engine
async def test_vast_gamma_engine():
    """Test Vast.ai gamma-optimized arbitrage engine"""
    
    logging.info("🚀 Testing Vast.ai Gamma-Optimized Arbitrage Engine")
    logging.info("=" * 60)
    
    api_key = os.environ.get("API_KEY_API_KEY", "49bc6b3b9d019ec3fcd731a60be4bb13c98f3ff8721615a2e3b4ad12cf079ea4")
    engine = VastGammaEngine(api_key)
    
    # Test 1: Search for A100 offers
    logging.info("\n🔍 Searching for A100 offers...")
    hosts = await engine.search_vast_offers("A100")
    logging.info(f"✅ Found {len(hosts)
    
    # Test 2: Run probes for top hosts
    if hosts:
        logging.info(f"\n🔍 Running probes for top 5 hosts...")
        await engine.run_probes_for_hosts(hosts[:5], synthetic_count=3, webpage_count=2)
    
    # Test 3: Analyze gamma opportunities
    logging.info(f"\n🎯 Analyzing gamma-optimized opportunities...")
    opportunities = await engine.analyze_vast_gamma_opportunities("A100")
    
    if opportunities:
        logging.info(f"✅ Found {len(opportunities)
        
        # Show top 3 opportunities
        logging.info(f"\n🏆 Top 3 Gamma-Optimized Opportunities:")
        for i, opp in enumerate(opportunities[:3], 1):
            logging.info(f"\n{i}. {opp.host.host_id}")
            logging.info(f"   GPU: {opp.host.gpu_name}")
            logging.info(f"   Price: ${opp.host.min_bid:.4f}/hr")
            logging.info(f"   Expected Cost: ${opp.expected_cost:.2f}")
            logging.info(f"   Expected Runtime: {opp.expected_runtime:.1f}s")
            logging.info(f"   Interrupt Penalty: {opp.interrupt_penalty:.2f}")
            logging.info(f"   Gamma Score: {opp.gamma_score:.3f}")
            logging.info(f"   Interruption Prob: {opp.interruption_probability:.1%}")
            logging.info(f"   Host Reputation: {opp.host_reputation_score:.3f}")
            logging.info(f"   Latency Variance: {opp.latency_variance_penalty:.3f}")
            logging.info(f"   Total Score: {opp.total_score:.3f}")
            logging.info(f"   Location: {opp.host.geolocation}")
            logging.info(f"   Datacenter: {opp.host.datacenter}")
    else:
        logging.info("❌ No gamma-optimized opportunities found")
    
    # Test 4: Host quality summary
    logging.info(f"\n📊 Host Quality Summary:")
    summary = engine.get_host_quality_summary()
    
    if "error" not in summary:
        logging.info(f"   Total Hosts: {summary['total_hosts']}")
        logging.info(f"   Avg Reputation: {summary['avg_reputation']:.3f}")
        logging.info(f"   Reputation Std: {summary['reputation_std']:.3f}")
        logging.info(f"   Avg Interruption Prob: {summary['avg_interruption_prob']:.1%}")
        logging.info(f"   High Quality Hosts: {summary['high_quality_hosts']}")
        logging.info(f"   Low Quality Hosts: {summary['low_quality_hosts']}")
        logging.info(f"   Synthetic Probes: {summary['total_synthetic_probes']}")
        logging.info(f"   WebPageTest Probes: {summary['total_webpage_probes']}")
        logging.info(f"   Probe Success Rate: {summary['probe_success_rate']:.1%}")
    else:
        logging.info(f"❌ Error: {summary['error']}")
    
    logging.info("\n🎯 Vast.ai Gamma Engine Test Completed!")
    logging.info("✅ Host quality filtering working")
    logging.info("✅ Synthetic job probing working")
    logging.info("✅ WebPageTest TTFB probing working")
    logging.info("✅ Interruption probability modeling working")
    logging.info("✅ Gamma-optimized opportunity scoring working")
    logging.info("✅ Host reputation tracking working")
    logging.info("✅ Latency variance penalty calculation working")

if __name__ == "__main__":
    asyncio.run(test_vast_gamma_engine())
