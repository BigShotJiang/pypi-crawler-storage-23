#!/usr/bin/env python3
"""
TensorDock Integration Tests
Comprehensive test suite for TensorDock integration
"""

import asyncio
import pytest
import json
from unittest.mock import AsyncMock, MagicMock, patch
from pathlib import Path
import tempfile
import os

from tensordock_integration import (
    TensorDockAPI, TensorDockManager, TensorDockCredentials,
    InstanceResources, GPUResource, CloudInit, InstanceConfig
)
from tensordock_provider import TensorDockProvider, TensorDockInstanceConfig
from tensordock_deployment import TensorDockDeploymentManager, DeploymentConfig

# Test credentials
TEST_CREDENTIALS = TensorDockCredentials(
    client_id="test-client-id",
    api_token = os.environ.get("TOKEN_API_TOKEN", "test-api-token")
)

class TestTensorDockCredentials:
    """Test TensorDock credentials"""
    
    def test_valid_credentials(self):
        """Test valid credentials"""
        creds = TensorDockCredentials(
            client_id="test-id",
            api_token = os.environ.get("TOKEN_API_TOKEN", "test-token")
        )
        assert creds.client_id == "test-id"
        assert creds.api_token == "test-token"
    
    def test_invalid_credentials(self):
        """Test invalid credentials"""
        with pytest.raises(ValueError):
            TensorDockCredentials(client_id="", api_token = os.environ.get("TOKEN_API_TOKEN", "test-token"))
        
        with pytest.raises(ValueError):
            TensorDockCredentials(client_id="test-id", api_token="")

class TestGPUResource:
    """Test GPU resource specification"""
    
    def test_valid_gpu_resource(self):
        """Test valid GPU resource"""
        gpu = GPUResource(model="rtx4090", count=2)
        assert gpu.model == "rtx4090"
        assert gpu.count == 2
    
    def test_invalid_gpu_count(self):
        """Test invalid GPU count"""
        with pytest.raises(ValueError):
            GPUResource(model="rtx4090", count=0)
        
        with pytest.raises(ValueError):
            GPUResource(model="rtx4090", count=-1)

class TestInstanceResources:
    """Test instance resources"""
    
    def test_valid_resources(self):
        """Test valid resources"""
        gpus = {"rtx4090": GPUResource(model="rtx4090", count=1)}
        resources = InstanceResources(
            vcpu_count=8,
            ram_gb=32,
            storage_gb=200,
            gpus=gpus
        )
        assert resources.vcpu_count == 8
        assert resources.ram_gb == 32
        assert resources.storage_gb == 200
        assert len(resources.gpus) == 1
    
    def test_invalid_storage(self):
        """Test invalid storage size"""
        gpus = {"rtx4090": GPUResource(model="rtx4090", count=1)}
        with pytest.raises(ValueError):
            InstanceResources(
                vcpu_count=8,
                ram_gb=32,
                storage_gb=50,  # Too small
                gpus=gpus
            )

class TestTensorDockAPI:
    """Test TensorDock API client"""
    
    @pytest.fixture
    def api(self):
        """Create API client fixture"""
        return TensorDockAPI(TEST_CREDENTIALS)
    
    @pytest.fixture
    def mock_session(self):
        """Create mock session fixture"""
        session = AsyncMock()
        response = AsyncMock()
        response.status = 200
        response.json = AsyncMock(return_value={"data": {"id": "test-id"}})
        session.request.return_value.__aenter__.return_value = response
        return session
    
    @pytest.mark.asyncio
    async def test_context_manager(self, api):
        """Test async context manager"""
        async with api as api_client:
            assert api_client.session is not None
    
    @pytest.mark.asyncio
    async def test_make_request_success(self, api, mock_session):
        """Test successful API request"""
        api.session = mock_session
        
        result = await api._make_request("GET", "/test")
        
        assert result == {"data": {"id": "test-id"}}
        mock_session.request.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_make_request_error(self, api, mock_session):
        """Test API request error"""
        response = AsyncMock()
        response.status = 400
        response.json = AsyncMock(return_value={"message": "Bad request"})
        mock_session.request.return_value.__aenter__.return_value = response
        api.session = mock_session
        
        with pytest.raises(ValueError, match="Bad request"):
            await api._make_request("POST", "/test")
    
    @pytest.mark.asyncio
    async def test_create_instance(self, api, mock_session):
        """Test instance creation"""
        # Mock successful response
        response_data = {
            "data": {
                "id": "instance-123",
                "name": "test-instance",
                "status": "running"
            }
        }
        
        response = AsyncMock()
        response.status = 201
        response.json = AsyncMock(return_value=response_data)
        mock_session.request.return_value.__aenter__.return_value = response
        api.session = mock_session
        
        # Create config
        gpus = {"rtx4090": GPUResource(model="rtx4090", count=1)}
        resources = InstanceResources(
            vcpu_count=8,
            ram_gb=32,
            storage_gb=200,
            gpus=gpus
        )
        config = InstanceConfig(
            name="test-instance",
            resources=resources
        )
        
        # Create instance
        instance = await api.create_instance(config)
        
        assert instance.id == "instance-123"
        assert instance.name == "test-instance"
        assert instance.status == "running"
    
    @pytest.mark.asyncio
    async def test_list_instances(self, api, mock_session):
        """Test listing instances"""
        response_data = {
            "data": {
                "instances": [
                    {
                        "id": "instance-1",
                        "name": "test-instance-1",
                        "status": "running",
                        "resources": {
                            "vcpu_count": 8,
                            "ram_gb": 32,
                            "storage_gb": 200,
                            "gpus": {
                                "rtx4090": {"count": 1}
                            }
                        },
                        "rateHourly": 1.0
                    }
                ]
            }
        }
        
        response = AsyncMock()
        response.status = 200
        response.json = AsyncMock(return_value=response_data)
        mock_session.request.return_value.__aenter__.return_value = response
        api.session = mock_session
        
        instances = await api.list_instances()
        
        assert len(instances) == 1
        assert instances[0].id == "instance-1"
        assert instances[0].name == "test-instance-1"

class TestTensorDockProvider:
    """Test TensorDock provider"""
    
    @pytest.fixture
    def provider(self):
        """Create provider fixture"""
        return TensorDockProvider(
            client_id="test-client-id",
            api_token = os.environ.get("TOKEN_API_TOKEN", "test-api-token")
        )
    
    @pytest.mark.asyncio
    async def test_connection_test(self, provider):
        """Test connection test"""
        with patch.object(provider, '_make_request', new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"data": {}}
            
            result = await provider.test_connection()
            
            assert result is True
            mock_request.assert_called_once_with("GET", "/api/v2/instances")
    
    @pytest.mark.asyncio
    async def test_get_instance_types(self, provider):
        """Test getting instance types"""
        types = await provider.get_instance_types()
        
        assert "ml-small" in types
        assert "ml-medium" in types
        assert "ml-large" in types
        assert "training" in types
    
    @pytest.mark.asyncio
    async def test_create_instance(self, provider):
        """Test creating instance"""
        config = TensorDockInstanceConfig(
            name="test-instance",
            cpu_count=8,
            memory_gb=32,
            storage_gb=200,
            gpu_model="rtx4090",
            gpu_count=1
        )
        
        with patch.object(provider, '_make_request', new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "data": {
                    "id": "instance-123",
                    "name": "test-instance",
                    "status": "running"
                }
            }
            
            instance = await provider.create_instance(config)
            
            assert instance.id == "instance-123"
            assert instance.name == "test-instance"
            assert instance.provider == "TensorDock"
    
    @pytest.mark.asyncio
    async def test_create_ml_instance(self, provider):
        """Test creating ML instance"""
        with patch.object(provider, 'create_instance', new_callable=AsyncMock) as mock_create:
            mock_instance = AsyncMock()
            mock_instance.id = "ml-instance-123"
            mock_create.return_value = mock_instance
            
            instance = await provider.create_ml_instance(
                name="ml-test",
                instance_type="ml-medium"
            )
            
            assert instance.id == "ml-instance-123"
            mock_create.assert_called_once()

class TestTensorDockManager:
    """Test TensorDock manager"""
    
    @pytest.fixture
    def manager(self):
        """Create manager fixture"""
        return TensorDockManager(TEST_CREDENTIALS)
    
    @pytest.mark.asyncio
    async def test_create_ml_instance(self, manager):
        """Test creating ML instance"""
        with patch.object(manager.api, 'create_instance', new_callable=AsyncMock) as mock_create:
            mock_instance = AsyncMock()
            mock_instance.id = "ml-instance-123"
            mock_create.return_value = mock_instance
            
            instance = await manager.create_ml_instance(
                name="ml-instance",
                gpu_model="rtx4090",
                gpu_count=1,
                cpu_cores=8,
                ram_gb=32,
                storage_gb=200
            )
            
            assert instance.id == "ml-instance-123"
            mock_create.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_create_training_cluster(self, manager):
        """Test creating training cluster"""
        with patch.object(manager, 'create_ml_instance', new_callable=AsyncMock) as mock_create:
            mock_instance = AsyncMock()
            mock_instance.id = "cluster-node-1"
            mock_create.return_value = mock_instance
            
            cluster = await manager.create_training_cluster(
                cluster_name="test-cluster",
                node_count=2,
                gpu_per_node=1
            )
            
            assert len(cluster) == 2
            assert mock_create.call_count == 2
    
    @pytest.mark.asyncio
    async def test_get_cluster_status(self, manager):
        """Test getting cluster status"""
        with patch.object(manager.api, 'list_instances', new_callable=AsyncMock) as mock_list:
            mock_instances = [
                AsyncMock(
                    id="node-1",
                    name="test-cluster-node-1",
                    status="running",
                    resources=AsyncMock(
                        gpus={"rtx4090": AsyncMock(count=1)}
                    ),
                    rate_hourly=1.0
                ),
                AsyncMock(
                    id="node-2",
                    name="test-cluster-node-2",
                    status="running",
                    resources=AsyncMock(
                        gpus={"rtx4090": AsyncMock(count=1)}
                    ),
                    rate_hourly=1.0
                )
            ]
            mock_list.return_value = mock_instances
            
            status = await manager.get_cluster_status("test-cluster")
            
            assert status["cluster_name"] == "test-cluster"
            assert status["total_nodes"] == 2
            assert status["running_nodes"] == 2
            assert status["total_gpus"] == 2
            assert status["hourly_cost"] == 2.0

class TestTensorDockDeploymentManager:
    """Test TensorDock deployment manager"""
    
    @pytest.fixture
    def temp_credentials_file(self):
        """Create temporary credentials file"""
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.json') as f:
            json.dump({
                "client_id": "test-client-id",
                "api_token": "test-api-token"
            }, f)
            temp_file = f.name
        
        yield temp_file
        
        os.unlink(temp_file)
    
    @pytest.fixture
    def deployment_manager(self, temp_credentials_file):
        """Create deployment manager fixture"""
        return TensorDockDeploymentManager(credentials_file=temp_credentials_file)
    
    def test_load_credentials_from_file(self, temp_credentials_file):
        """Test loading credentials from file"""
        manager = TensorDockDeploymentManager(credentials_file=temp_credentials_file)
        
        assert manager.credentials.client_id == "test-client-id"
        assert manager.credentials.api_token == "test-api-token"
    
    def test_deployment_configs(self, deployment_manager):
        """Test deployment configurations"""
        assert "ml-development" in deployment_manager.deployment_configs
        assert "ml-staging" in deployment_manager.deployment_configs
        assert "ml-production" in deployment_manager.deployment_configs
        assert "training-cluster" in deployment_manager.deployment_configs
        
        dev_config = deployment_manager.deployment_configs["ml-development"]
        assert dev_config.name == "ml-dev"
        assert dev_config.environment == "dev"
        assert dev_config.node_count == 1
    
    @pytest.mark.asyncio
    async def test_deploy_environment(self, deployment_manager):
        """Test deploying environment"""
        with patch.object(deployment_manager.provider, 'create_ml_instance', new_callable=AsyncMock) as mock_create:
            mock_instance = AsyncMock()
            mock_instance.id = "instance-123"
            mock_create.return_value = mock_instance
            
            instances = await deployment_manager.deploy_environment("ml-development")
            
            assert len(instances) == 1
            assert instances[0] == "instance-123"
            mock_create.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_get_deployment_status(self, deployment_manager):
        """Test getting deployment status"""
        # Create mock deployment file
        deployments_dir = Path("deployments")
        deployments_dir.mkdir(exist_ok=True)
        
        deployment_file = deployments_dir / "ml-development_deployment.json"
        deployment_data = {
            "config_name": "ml-development",
            "config": deployment_manager.deployment_configs["ml-development"].to_dict(),
            "instances": ["instance-123"],
            "deployed_at": "2024-01-01T00:00:00Z",
            "status": "deployed"
        }
        
        with open(deployment_file, 'w') as f:
            json.dump(deployment_data, f)
        
        with patch.object(deployment_manager.provider, 'get_instance', new_callable=AsyncMock) as mock_get:
            mock_instance = AsyncMock()
            mock_instance.id = "instance-123"
            mock_instance.name = "ml-dev-node-1"
            mock_instance.status.value = "running"
            mock_instance.ip_address = "192.168.1.100"
            mock_instance.hourly_cost = 0.5
            mock_get.return_value = mock_instance
            
            status = await deployment_manager.get_deployment_status("ml-development")
            
            assert status["config"]["name"] == "ml-dev"
            assert len(status["instances"]) == 1
            assert status["instances"][0]["id"] == "instance-123"
            assert status["total_hourly_cost"] == 0.5
        
        # Cleanup
        deployment_file.unlink()
    
    @pytest.mark.asyncio
    async def test_scale_deployment_up(self, deployment_manager):
        """Test scaling deployment up"""
        # Create mock deployment file
        deployments_dir = Path("deployments")
        deployments_dir.mkdir(exist_ok=True)
        
        deployment_file = deployments_dir / "ml-development_deployment.json"
        deployment_data = {
            "config_name": "ml-development",
            "config": deployment_manager.deployment_configs["ml-development"].to_dict(),
            "instances": ["instance-123"],
            "deployed_at": "2024-01-01T00:00:00Z",
            "status": "deployed"
        }
        
        with open(deployment_file, 'w') as f:
            json.dump(deployment_data, f)
        
        with patch.object(deployment_manager.provider, 'create_ml_instance', new_callable=AsyncMock) as mock_create:
            mock_instance = AsyncMock()
            mock_instance.id = "instance-456"
            mock_create.return_value = mock_instance
            
            instances = await deployment_manager.scale_deployment("ml-development", 2)
            
            assert len(instances) == 2
            assert "instance-456" in instances
            mock_create.assert_called_once()
        
        # Cleanup
        deployment_file.unlink()
    
    @pytest.mark.asyncio
    async def test_destroy_deployment(self, deployment_manager):
        """Test destroying deployment"""
        # Create mock deployment file
        deployments_dir = Path("deployments")
        deployments_dir.mkdir(exist_ok=True)
        
        deployment_file = deployments_dir / "ml-development_deployment.json"
        deployment_data = {
            "config_name": "ml-development",
            "config": deployment_manager.deployment_configs["ml-development"].to_dict(),
            "instances": ["instance-123"],
            "deployed_at": "2024-01-01T00:00:00Z",
            "status": "deployed"
        }
        
        with open(deployment_file, 'w') as f:
            json.dump(deployment_data, f)
        
        with patch.object(deployment_manager.provider, 'delete_instance', new_callable=AsyncMock) as mock_delete:
            mock_delete.return_value = True
            
            success = await deployment_manager.destroy_deployment("ml-development")
            
            assert success is True
            mock_delete.assert_called_once_with("instance-123")
        
        # Verify file is deleted
        assert not deployment_file.exists()
    
    def test_generate_kubernetes_config(self, deployment_manager):
        """Test generating Kubernetes configuration"""
        config = deployment_manager.generate_kubernetes_config("ml-development")
        
        assert "apiVersion: apps/v1" in config
        assert "kind: Deployment" in config
        assert "ml-dev" in config
        assert "nvidia.com/gpu: 1" in config
    
    @pytest.mark.asyncio
    async def test_health_check(self, deployment_manager):
        """Test health check"""
        # Create mock deployment file
        deployments_dir = Path("deployments")
        deployments_dir.mkdir(exist_ok=True)
        
        deployment_file = deployments_dir / "ml-development_deployment.json"
        deployment_data = {
            "config_name": "ml-development",
            "config": deployment_manager.deployment_configs["ml-development"].to_dict(),
            "instances": ["instance-123"],
            "deployed_at": "2024-01-01T00:00:00Z",
            "status": "deployed"
        }
        
        with open(deployment_file, 'w') as f:
            json.dump(deployment_data, f)
        
        with patch.object(deployment_manager.provider, 'get_instance', new_callable=AsyncMock) as mock_get:
            mock_instance = AsyncMock()
            mock_instance.id = "instance-123"
            mock_instance.status.value = "running"
            mock_get.return_value = mock_instance
            
            health = await deployment_manager.health_check("ml-development")
            
            assert health["healthy"] is True
            assert health["healthy_nodes"] == 1
            assert health["total_nodes"] == 1
            assert health["health_percentage"] == 100.0
        
        # Cleanup
        deployment_file.unlink()

class TestIntegration:
    """Integration tests"""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self):
        """Test full workflow integration"""
        # This would be a comprehensive integration test
        # In a real scenario, this would use actual TensorDock API
        # For now, we'll mock the entire workflow
        
        credentials = TensorDockCredentials(
            client_id="test-client-id",
            api_token = os.environ.get("TOKEN_API_TOKEN", "test-api-token")
        )
        
        manager = TensorDockManager(credentials)
        
        with patch.object(manager.api, 'create_instance', new_callable=AsyncMock) as mock_create:
            mock_instance = AsyncMock()
            mock_instance.id = "integration-test-123"
            mock_create.return_value = mock_instance
            
            # Create instance
            instance = await manager.create_ml_instance(
                name="integration-test",
                gpu_model="rtx4090",
                gpu_count=1
            )
            
            assert instance.id == "integration-test-123"
            
            # Get instance costs
            with patch.object(manager, 'get_instance_costs', new_callable=AsyncMock) as mock_cost:
                mock_cost.return_value = 24.0
                
                cost = await manager.get_instance_costs(instance.id, 24)
                assert cost == 24.0

# Performance tests
class TestPerformance:
    """Performance tests"""
    
    @pytest.mark.asyncio
    async def test_concurrent_instance_creation(self):
        """Test concurrent instance creation"""
        credentials = TensorDockCredentials(
            client_id="test-client-id",
            api_token = os.environ.get("TOKEN_API_TOKEN", "test-api-token")
        )
        
        manager = TensorDockManager(credentials)
        
        with patch.object(manager.api, 'create_instance', new_callable=AsyncMock) as mock_create:
            mock_instance = AsyncMock()
            mock_instance.id = "perf-test-123"
            mock_create.return_value = mock_instance
            
            # Create multiple instances concurrently
            tasks = [
                manager.create_ml_instance(
                    name=f"perf-test-{i}",
                    gpu_model="rtx4090",
                    gpu_count=1
                )
                for i in range(5)
            ]
            
            instances = await asyncio.gather(*tasks)
            
            assert len(instances) == 5
            assert mock_create.call_count == 5

# Error handling tests
class TestErrorHandling:
    """Error handling tests"""
    
    @pytest.mark.asyncio
    async def test_authentication_error(self):
        """Test authentication error handling"""
        credentials = TensorDockCredentials(
            client_id="invalid-client-id",
            api_token = os.environ.get("TOKEN_API_TOKEN", "invalid-api-token")
        )
        
        api = TensorDockAPI(credentials)
        
        with patch.object(api, '_make_request', new_callable=AsyncMock) as mock_request:
            mock_request.side_effect = ValueError("Unauthorized: Invalid credentials")
            
            with pytest.raises(ValueError, match="Unauthorized"):
                await api.list_instances()
    
    @pytest.mark.asyncio
    async def test_instance_creation_failure(self):
        """Test instance creation failure"""
        credentials = TensorDockCredentials(
            client_id="test-client-id",
            api_token = os.environ.get("TOKEN_API_TOKEN", "test-api-token")
        )
        
        manager = TensorDockManager(credentials)
        
        with patch.object(manager.api, 'create_instance', new_callable=AsyncMock) as mock_create:
            mock_create.side_effect = ValueError("Insufficient balance")
            
            with pytest.raises(ValueError, match="Insufficient balance"):
                await manager.create_ml_instance(
                    name="test-instance",
                    gpu_model="rtx4090",
                    gpu_count=1
                )

if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])
