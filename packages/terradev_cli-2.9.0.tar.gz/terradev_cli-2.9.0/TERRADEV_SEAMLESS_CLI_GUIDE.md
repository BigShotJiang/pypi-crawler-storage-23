# 🚀 Terradev Seamless CLI Experience

Automatic credential detection and setup prompts for effortless user onboarding.

---

## 🎯 **Seamless User Experience**

### **🔍 Automatic Setup Detection**
The CLI now automatically detects when you need to set up providers and guides you through the process:

```bash
$ terradev quote

🌟 Welcome to Terradev CLI!
It looks like you haven't set up any cloud providers yet.

Would you like to set up cloud providers now? [Y/n]: y
```

### **📋 Smart Credential Management**
- **Auto-detects missing credentials** and prompts for setup
- **Saves credentials automatically** to encrypted storage
- **Validates credentials** after configuration
- **Shows configuration status** at any time

---

## 🎮 **Complete User Journey**

### **🚀 First Time User Experience**

#### **Step 1: Run Any Command**
```bash
$ terradev quote

🌟 Welcome to Terradev CLI!
It looks like you haven't set up any cloud providers yet.

Would you like to set up cloud providers now? [Y/n]: y
```

#### **Step 2: Interactive Provider Selection**
```
📋 Select cloud providers to configure:

  [runpod] RunPod
       Specialized GPU cloud with competitive pricing
       Difficulty: Easy | Savings: 60-70%

  [vastai] VastAI
       GPU marketplace with variable pricing
       Difficulty: Easy | Savings: 40-60%

  [huggingface] HuggingFace
       ML Model Hub and Inference API
       Difficulty: Easy | Savings: 50-80%

Enter provider keys (comma-separated) [runpod,vastai]: runpod,huggingface
```

#### **Step 3: Credential Configuration**
```
🔧 Configuring RUNPOD:
📖 Help: https://runpod.io/console/user
📋 Instructions:
   1. Go to RunPod Console
   2. Go to Settings > API Keys
   3. Generate new API key
   4. Copy the API key

Enter Api Key: ******
Confirm Api Key: ******
✅ runpod configured successfully

🔧 Configuring HUGGINGFACE:
📖 Help: https://huggingface.co/settings/tokens
📋 Instructions:
   1. Go to HuggingFace Settings
   2. Go to Access Tokens
   3. Create new token
   4. Copy the token (starts with hf_)

Enter Api Token: ******
Confirm Api Token: ******
✅ huggingface configured successfully
```

#### **Step 4: Automatic Validation**
```
🔍 Validating credentials...

📊 Credential Validation Results:
   ✅ runpod: Connection successful
   ✅ huggingface: Connection successful
```

#### **Step 5: First Quote Demo**
```
🎯 Let's get your first quote to see the savings!

✅ Found 3 quotes for A100 GPUs:
┌─────────────┬─────────────────┬─────────────┬───────────┐
│ Provider    │ Instance Type   │ Price/Hour  │ Region    │
├─────────────┼─────────────────┼─────────────┼───────────┤
│ runpod      │ A100-80GB       │ $2.4000     │ us-east-1 │
│ huggingface│ inference-A100  │ $3.5000     │ us-east-1 │
│ aws         │ p4d.24xlarge    │ $32.7700    │ us-east-1 │
└─────────────┴─────────────────┴─────────────┴───────────┘

💰 Potential savings: 92.7% vs AWS
   Monthly savings: $22,418.10

🎉 Setup complete! You're ready to start saving on cloud costs.
```

#### **Step 6: Continue with Original Command**
```
🔍 Getting real-time quotes...

✅ Retrieved 6 quotes
┌─────────────┬─────────────────┬──────┬─────────────┬───────────┬──────────┐
│ Provider    │ Instance Type   │ GPU  │ Price/Hour  │ Region    │ Available│
├─────────────┼─────────────────┼──────┼─────────────┼───────────┼──────────┤
│ runpod      │ A100-80GB       │ A100 │ $2.4000     │ us-east-1 │ Yes      │
│ huggingface│ inference-A100  │ A100 │ $3.5000     │ us-east-1 │ Yes      │
│ vastai      │ A100-80GB       │ A100 │ $2.1000     │ us-west-2 │ Yes      │
└─────────────┴─────────────────┴──────┴─────────────┴───────────┴──────────┘
```

---

### **🔄 Returning User Experience**

#### **Missing Credentials Detection**
```bash
$ terradev quote

⚠️  Found 1 provider(s) without credentials:
   - aws

Would you like to configure aws now? [Y/n]: y

🔧 Configuring AWS:
📖 Help: https://console.aws.amazon.com/iam/home
📋 Instructions:
   1. Go to AWS IAM Console
   2. Create a new user or use existing one
   3. Generate access keys
   4. Copy Access Key ID and Secret Access Key

Enter Access Key: ******
Enter Secret Key: ******
✅ aws configured successfully

🔍 Getting real-time quotes...
```

#### **Complete Configuration**
```bash
$ terradev quote

🔍 Getting real-time quotes...

✅ Retrieved 8 quotes
┌─────────────┬─────────────────┬──────┬─────────────┬───────────┬──────────┐
│ Provider    │ Instance Type   │ GPU  │ Price/Hour  │ Region    │ Available│
├─────────────┼─────────────────┼──────┼─────────────┼───────────┼──────────┤
│ runpod      │ A100-80GB       │ A100 │ $2.4000     │ us-east-1 │ Yes      │
│ vastai      │ A100-80GB       │ A100 │ $2.1000     │ us-west-2 │ Yes      │
│ huggingface│ inference-A100  │ A100 │ $3.5000     │ us-east-1 │ Yes      │
│ aws         │ p4d.24xlarge    │ A100 │ $32.7700    │ us-east-1 │ Yes      │
└─────────────┴─────────────────┴──────┴─────────────┴───────────┴──────────┘
```

---

## 🛠️ **Automatic Features**

### **🔍 Smart Detection**
- **No providers configured** → Runs setup wizard
- **Missing credentials** → Prompts for specific provider
- **Valid configuration** → Executes command normally

### **💾 Automatic Saving**
- **Credentials encrypted** and saved to `~/.terradev/auth.json`
- **Configuration saved** to `~/.terradev/config.json`
- **No manual file editing** required

### **✅ Automatic Validation**
- **Tests connections** after configuration
- **Shows health status** for each provider
- **Provides feedback** on setup success

### **🎯 Contextual Help**
- **Provider-specific instructions** for each service
- **Direct links** to provider consoles
- **Step-by-step guidance** for API key generation

---

## 📊 **Configuration Management**

### **🔍 Check Current Status**
```bash
$ terradev config-status

📊 Terradev Configuration Status:

🔧 Configured Providers:
   ✅ runpod (us-east-1) - Connection successful
   ✅ huggingface (us-east-1) - Connection successful
   ✅ aws (us-east-1) - Connection successful

📁 Configuration Files:
   Config: /Users/user/.terradev/config.json
   Auth: /Users/user/.terradev/auth.json
   Config exists: True
   Auth exists: True

⚡ Next Steps:
   terradev quote          # Get price quotes
   terradev provision      # Provision instances
```

### **🔧 Manual Configuration (Still Available)**
```bash
# Quick configure single provider
terradev configure --provider runpod --api-key your_key

# Configure AWS with both keys
terradev configure --provider aws --api-key your_key --secret-key your_secret

# Show current configuration
terradev configure
```

---

## 🎮 **Command Flow Examples**

### **📊 Quote Command Flow**
```bash
# User runs quote command
terradev quote --gpu-type A100

# System checks configuration
# → No providers found → Setup wizard
# → Missing credentials → Prompt for setup
# → Valid config → Execute quote

# Result: Seamless experience from setup to results
```

### **🚀 Provision Command Flow**
```bash
# User runs provision command
terradev provision --gpu-type A100 --count 2

# System validates setup
# → Auto-setup if needed
# → Validate credentials
# → Execute provisioning

# Result: Instant provisioning with optimal pricing
```

### **📈 Status Command Flow**
```bash
# User checks status
terradev status

# System ensures configuration
# → Auto-setup if needed
# → Show instance status across all providers

# Result: Complete visibility of all resources
```

---

## 🔐 **Security Features**

### **🔒 Encrypted Storage**
- **Fernet encryption** for all API keys
- **Secure key generation** and management
- **Hidden input prompts** for sensitive data
- **Confirmation prompts** for credential entry

### **🛡️ Validation**
- **Token format validation** (e.g., HuggingFace hf_ prefix)
- **Connection testing** after configuration
- **Error handling** for invalid credentials
- **Retry mechanisms** for failed connections

### **📁 File Permissions**
- **Restricted file access** (user read/write only)
- **Secure directory structure** in user home
- **Automatic cleanup** of temporary files
- **Backup creation** before changes

---

## 🎯 **User Benefits**

### **🎮 Zero Friction Onboarding**
- **Run any command** → auto-setup if needed
- **No prior configuration** required
- **Step-by-step guidance** for each provider
- **Instant results** after setup

### **💾 Automatic Persistence**
- **Credentials saved** automatically after entry
- **Configuration remembered** across sessions
- **No manual file editing** required
- **Encrypted storage** for security

### **🔍 Smart Detection**
- **Knows when setup is needed**
- **Identifies missing credentials**
- **Provides contextual help**
- **Validates configuration automatically**

### **📊 Clear Visibility**
- **Configuration status** at any time
- **Provider health monitoring**
- **Connection validation results**
- **Next steps guidance**

---

## 🚀 **Usage Examples**

### **👤 Complete Beginner**
```bash
# First time using Terradev
terradev quote
# → Auto-setup wizard runs
# → Select providers
# → Enter credentials
# → See quotes immediately
```

### **🔄 Adding New Provider**
```bash
# Add HuggingFace to existing setup
terradev quote --provider huggingface
# → Detects missing HF credentials
# → Prompts for HF token
# → Shows HF quotes immediately
```

### **📊 Checking Setup**
```bash
# See current configuration status
terradev config-status
# → Shows all configured providers
# → Displays connection health
# → Provides next steps
```

### **🔧 Manual Override**
```bash
# Skip auto-setup for manual configuration
terradev configure --provider runpod --api-key your_key
# → Manual configuration still available
# → Auto-validation still applies
```

---

## 🎉 **Summary**

The seamless Terradev CLI provides:

- **🔍 Automatic setup detection** - No manual setup required
- **💾 Automatic credential saving** - Keys stored securely
- **🎮 Zero-friction onboarding** - Run any command to start
- **🔐 Smart validation** - Tests connections automatically
- **📊 Clear visibility** - Always know your configuration status
- **🛡️ Enterprise security** - Encrypted credential storage
- **🎯 Contextual help** - Step-by-step guidance for each provider

**Result**: Users can run any Terradev command and get automatically guided through setup if needed, with credentials saved securely and validated automatically.

---

**🚀 Terradev Seamless CLI - Just run a command and we'll handle the rest!**
