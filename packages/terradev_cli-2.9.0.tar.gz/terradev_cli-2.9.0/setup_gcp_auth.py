import logging

#!/usr/bin/env python3
"""
Simple GCP Authentication Setup without gcloud CLI
Uses service account JSON file directly
"""

import json
import os
from pathlib import Path

# TODO: REFACTOR - setup_gcp_auth() is 68 lines long (should be <50)
# Consider breaking into smaller, focused functions
def setup_gcp_auth():
    """Setup GCP authentication for Terradev"""
    
    logging.info("🔧 GCP Authentication Setup for Terradev")
    logging.info("=" * 50)
    
    # Create credentials directory
    cred_dir = Path.home() / ".google"
    cred_dir.mkdir(exist_ok=True)
    
    logging.info("📁 Created credentials directory:", cred_dir)
    
    # Instructions for service account
    logging.info("\n🔑 Service Account Setup Instructions:")
    logging.info("1. Go to Google Cloud Console: https://console.cloud.google.com/")
    logging.info("2. Select your project or create a new one")
    logging.info("3. Go to IAM & Admin > Service Accounts")
    logging.info("4. Click 'Create Service Account'")
    logging.info("5. Name: 'terradev-parallel'")
    logging.info("6. Click 'Create and Continue'")
    logging.info("7. Role: 'Compute Instance Admin'")
    logging.info("8. Click 'Continue' then 'Done'")
    logging.info("9. Click on the service account name")
    logging.info("10. Go to 'Keys' tab")
    logging.info("11. Click 'Add Key' > 'Create new key'")
    logging.info("12. Select 'JSON' and click 'Create'")
    logging.info("13. Download the JSON file")
    
    # Get the JSON file path
    json_path = input("\n📄 Enter the path to your downloaded JSON file: ").strip()
    
    if not os.path.exists(json_path):
        logging.info("❌ File not found. Please check the path.")
        return False
    
    # Copy to expected location
    target_path = cred_dir / "terradev-parallel.json"
    
    try:
        with open(json_path, 'r') as f:
            service_account = json.load(f)
        
        with open(target_path, 'w') as f:
            json.dump(service_account, f, indent=2)
        
        logging.info(f"✅ Service account copied to: {target_path}")
        
        # Extract project ID
        project_id = service_account.get('project_id')
        if project_id:
            logging.info(f"📋 Project ID: {project_id}")
        
        # Set environment variable
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = str(target_path)
        logging.info(f"🔧 Set GOOGLE_APPLICATION_CREDENTIALS={target_path}")
        
        # Add to shell profile
        shell_profile = Path.home() / ".zshrc"
        if shell_profile.exists():
            with open(shell_profile, 'a') as f:
                f.write(f"\n# Terradev GCP Authentication\n")
                f.write(f"export GOOGLE_APPLICATION_CREDENTIALS='{target_path}'\n")
            logging.info(f"✅ Added to {shell_profile}")
        
        return True
        
    except Exception as e:
        logging.info(f"❌ Error processing JSON file: {e}")
        return False

def test_gcp_connection():
    """Test GCP connection"""
    logging.info("\n🧪 Testing GCP Connection...")
    
    try:
        from google.cloud import compute_v1
        
        client = compute_v1.InstancesClient()
        
        # Try to list zones (simple test)
        project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
        if not project_id:
            # Extract from credentials
            cred_path = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
            if cred_path and os.path.exists(cred_path):
                with open(cred_path, 'r') as f:
                    service_account = json.load(f)
                project_id = service_account.get('project_id')
        
        if project_id:
            zones = client.list_zones(project=project_id)
            zone_count = len(list(zones))
            logging.info(f"✅ Successfully connected to GCP!")
            logging.info(f"📊 Found {zone_count} zones in project {project_id}")
            return True
        else:
            logging.info("❌ Could not determine project ID")
            return False
            
    except Exception as e:
        logging.info(f"❌ GCP connection failed: {e}")
        return False

def main():
    """Main setup function"""
    
    # Check if we already have credentials
    cred_path = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
    if cred_path and os.path.exists(cred_path):
        logging.info(f"✅ GCP credentials already configured: {cred_path}")
        test_gcp_connection()
        return
    
    # Setup new credentials
    if setup_gcp_auth():
        test_gcp_connection()
        
        logging.info("\n🎯 Next Steps:")
        logging.info("1. Enable Compute Engine API:")
        logging.info("   gcloud services enable compute.googleapis.com --project=YOUR_PROJECT_ID")
        logging.info("2. Test the parallel race:")
        logging.info("   python3 real_parallel_provisioning.py --race --gpu-type A100")
        logging.info("3. Run Terraform:")
        logging.info("   cd terraform && terraform apply")
    else:
        logging.info("❌ Setup failed. Please try again.")

if __name__ == "__main__":
    main()
