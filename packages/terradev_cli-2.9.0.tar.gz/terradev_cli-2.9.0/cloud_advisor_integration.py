import os

#!/usr/bin/env python3
"""
Enhanced OCI Cloud Advisor Integration for Terradev
Real-time cost optimization and efficiency recommendations
"""

import asyncio
import aiohttp
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from oci_integration import OCICredentials, OCIAPIClient

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class CloudAdvisorRecommendation:
    """Cloud Advisor recommendation data structure"""
    category: str
    level: str
    status: str
    resource_id: str
    resource_type: str
    recommendation: str
    estimated_savings: float
    estimated_savings_currency: str
    confidence: float
    created_at: datetime
    action_required: bool
    implementation_complexity: str

@dataclass
class CostOptimizationProfile:
    """Cost optimization profile configuration"""
    name: str
    target_reduction_percentage: float
    max_acceptable_risk: str
    optimization_categories: List[str]
    auto_apply_recommendations: bool
    approval_required: bool

class CloudAdvisorClient:
    """OCI Cloud Advisor API client"""
    
    def __init__(self, credentials: OCICredentials):
        self.credentials = credentials
        self.base_url = f"https://optimizer.{credentials.region}.oci.oraclecloud.com/20200606"
        self.session = None
        self.oci_client = OCIAPIClient(credentials)
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def get_recommendations(self, compartment_id: str, 
                                 category: str = "COST_OPTIMIZATION",
                                 level: str = "HIGH",
                                 status: str = "ACTIVE") -> List[CloudAdvisorRecommendation]:
        """Get Cloud Advisor recommendations"""
        try:
            url = f"{self.base_url}/recommendations"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            params = {
                "compartmentId": compartment_id,
                "category": category,
                "level": level,
                "status": status
            }
            
            # Sign request using OCI client
            headers = self.oci_client._sign_request("GET", url, headers)
            
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return self._parse_recommendations(data)
                else:
                    logger.error(f"Failed to get recommendations: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error getting recommendations: {e}")
            return []
    
    def _parse_recommendations(self, data: Dict[str, Any]) -> List[CloudAdvisorRecommendation]:
        """Parse Cloud Advisor recommendations response"""
        recommendations = []
        
        for item in data.get("items", []):
            recommendation = CloudAdvisorRecommendation(
                category=item.get("category", ""),
                level=item.get("level", ""),
                status=item.get("status", ""),
                resource_id=item.get("resourceId", ""),
                resource_type=item.get("resourceType", ""),
                recommendation=item.get("recommendation", ""),
                estimated_savings=item.get("estimatedSavings", 0.0),
                estimated_savings_currency=item.get("estimatedSavingsCurrency", "USD"),
                confidence=item.get("confidence", 0.0),
                created_at=datetime.fromisoformat(item.get("timeCreated", "").replace("Z", "+00:00")),
                action_required=item.get("actionRequired", False),
                implementation_complexity=item.get("implementationComplexity", "MEDIUM")
            )
            recommendations.append(recommendation)
        
        return recommendations
    
    async def create_optimization_profile(self, compartment_id: str, 
                                        profile: CostOptimizationProfile) -> Dict[str, Any]:
        """Create cost optimization profile"""
        try:
            url = f"{self.base_url}/profiles"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            profile_data = {
                "compartmentId": compartment_id,
                "name": profile.name,
                "description": f"Terradev optimization profile targeting {profile.target_reduction_percentage}% cost reduction",
                "costAnalysisTarget": {
                    "type": "ABSOLUTE",
                    "targetType": "REDUCE_COST",
                    "value": profile.target_reduction_percentage
                },
                "levels": ["HIGH", "MEDIUM", "LOW"],
                "categories": profile.optimization_categories,
                "autoApplyRecommendations": profile.auto_apply_recommendations,
                "approvalRequired": profile.approval_required
            }
            
            # Sign request
            headers = self.oci_client._sign_request("POST", url, headers, json.dumps(profile_data))
            
            async with self.session.post(url, headers=headers, json=profile_data) as response:
                if response.status == 200:
                    data = await response.json()
                    return {"status": "created", "profile_id": data.get("id")}
                else:
                    error_data = await response.json()
                    return {"status": "error", "message": error_data.get("message", "Unknown error")}
        except Exception as e:
            logger.error(f"Error creating optimization profile: {e}")
            return {"status": "error", "message": str(e)}
    
    async def get_cost_analysis(self, compartment_id: str, 
                              start_time: datetime, 
                              end_time: datetime) -> Dict[str, Any]:
        """Get cost analysis data"""
        try:
            url = f"{self.base_url}/costAnalysis"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            params = {
                "compartmentId": compartment_id,
                "timeStart": start_time.isoformat(),
                "timeEnd": end_time.isoformat(),
                "granularity": "MONTHLY"
            }
            
            # Sign request
            headers = self.oci_client._sign_request("GET", url, headers)
            
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return data
                else:
                    logger.error(f"Failed to get cost analysis: {response.status}")
                    return {}
        except Exception as e:
            logger.error(f"Error getting cost analysis: {e}")
            return {}
    
    async def apply_recommendation(self, recommendation_id: str) -> Dict[str, Any]:
        """Apply a specific recommendation"""
        try:
            url = f"{self.base_url}/recommendations/{recommendation_id}/actions"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            action_data = {
                "actionType": "APPLY"
            }
            
            # Sign request
            headers = self.oci_client._sign_request("POST", url, headers, json.dumps(action_data))
            
            async with self.session.post(url, headers=headers, json=action_data) as response:
                if response.status == 200:
                    data = await response.json()
                    return {"status": "applied", "work_request_id": data.get("workRequestId")}
                else:
                    error_data = await response.json()
                    return {"status": "error", "message": error_data.get("message", "Unknown error")}
        except Exception as e:
            logger.error(f"Error applying recommendation: {e}")
            return {"status": "error", "message": str(e)}

class EnhancedOCIArbitrageEngine:
    """Enhanced OCI arbitrage engine with Cloud Advisor integration"""
    
    def __init__(self, credentials: OCICredentials):
        self.credentials = credentials
        self.cloud_advisor = CloudAdvisorClient(credentials)
        self.recommendations = []
        self.optimization_profile = None
    
    async def initialize(self):
        """Initialize the enhanced OCI engine"""
        # Create cost optimization profile
        self.optimization_profile = CostOptimizationProfile(
            name="terradev-optimization",
            target_reduction_percentage=30.0,
            max_acceptable_risk="MEDIUM",
            optimization_categories=["COST_OPTIMIZATION", "PERFORMANCE", "SECURITY"],
            auto_apply_recommendations=False,
            approval_required=True
        )
        
        logger.info("Enhanced OCI arbitrage engine initialized")
    
    async def get_cost_optimization_recommendations(self, compartment_id: str) -> List[CloudAdvisorRecommendation]:
        """Get cost optimization recommendations from Cloud Advisor"""
        recommendations = await self.cloud_advisor.get_recommendations(
            compartment_id=compartment_id,
            category="COST_OPTIMIZATION",
            level="HIGH",
            status="ACTIVE"
        )
        
        # Sort by estimated savings
        recommendations.sort(key=lambda r: r.estimated_savings, reverse=True)
        
        self.recommendations = recommendations
        return recommendations
    
    async def analyze_savings_potential(self, compartment_id: str) -> Dict[str, Any]:
        """Analyze total savings potential"""
        recommendations = await self.get_cost_optimization_recommendations(compartment_id)
        
        total_savings = sum(r.estimated_savings for r in recommendations)
        high_confidence_savings = sum(r.estimated_savings for r in recommendations if r.confidence >= 0.8)
        easy_implementations = sum(r.estimated_savings for r in recommendations if r.implementation_complexity == "LOW")
        
        return {
            "total_recommendations": len(recommendations),
            "total_savings_potential": total_savings,
            "high_confidence_savings": high_confidence_savings,
            "easy_implementation_savings": easy_implementations,
            "average_confidence": sum(r.confidence for r in recommendations) / len(recommendations) if recommendations else 0,
            "categories": list(set(r.category for r in recommendations)),
            "resource_types": list(set(r.resource_type for r in recommendations))
        }
    
    async def create_optimization_profile(self, compartment_id: str) -> Dict[str, Any]:
        """Create cost optimization profile"""
        return await self.cloud_advisor.create_optimization_profile(compartment_id, self.optimization_profile)
    
    async def get_monthly_cost_trend(self, compartment_id: str, months: int = 6) -> Dict[str, Any]:
        """Get monthly cost trend analysis"""
        end_time = datetime.now()
        start_time = end_time - timedelta(days=30 * months)
        
        cost_data = await self.cloud_advisor.get_cost_analysis(compartment_id, start_time, end_time)
        
        return {
            "period": f"{months} months",
            "cost_data": cost_data,
            "trend_analysis": self._analyze_cost_trend(cost_data)
        }
    
    def _analyze_cost_trend(self, cost_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze cost trend from data"""
        # Mock trend analysis - would analyze actual cost data
        return {
            "trend": "INCREASING",
            "monthly_growth_rate": 5.2,
            "projected_annual_cost": 12000.0,
            "optimization_needed": True
        }
    
    async def get_top_recommendations(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top recommendations for implementation"""
        if not self.recommendations:
            return []
        
        top_recommendations = []
        for rec in self.recommendations[:limit]:
            recommendation_data = {
                "category": rec.category,
                "level": rec.level,
                "resource_type": rec.resource_type,
                "recommendation": rec.recommendation,
                "estimated_savings": rec.estimated_savings,
                "confidence": rec.confidence,
                "implementation_complexity": rec.implementation_complexity,
                "action_required": rec.action_required,
                "priority_score": self._calculate_priority_score(rec)
            }
            top_recommendations.append(recommendation_data)
        
        # Sort by priority score
        top_recommendations.sort(key=lambda r: r["priority_score"], reverse=True)
        
        return top_recommendations
    
    def _calculate_priority_score(self, recommendation: CloudAdvisorRecommendation) -> float:
        """Calculate priority score for recommendation"""
        # Base score from estimated savings
        savings_score = min(100, recommendation.estimated_savings / 10)  # $10 = 100 points
        
        # Confidence bonus
        confidence_bonus = recommendation.confidence * 30  # 0-30 points
        
        # Implementation complexity penalty
        complexity_penalty = {
            "LOW": 0,
            "MEDIUM": -10,
            "HIGH": -20
        }.get(recommendation.implementation_complexity, -10)
        
        # Level bonus
        level_bonus = {
            "HIGH": 20,
            "MEDIUM": 10,
            "LOW": 0
        }.get(recommendation.level, 0)
        
        return savings_score + confidence_bonus + complexity_penalty + level_bonus

async def main():
    """Main demonstration function"""
    logging.info("🔧 Enhanced OCI Cloud Advisor Integration")
    logging.info("=" * 50)
    
    # Mock credentials - would get from environment or config
    credentials = OCICredentials(
        user_ocid="ocid1.user.oc1..example",
        tenancy_ocid="ocid1.tenancy.oc1..example",
        private_key = os.environ.get("PRIVATE_KEY_PRIVATE_KEY", "-----BEGIN PRIVATE KEY-----
...
-----END PRIVATE KEY-----"),
        fingerprint="00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00",
        region="us-ashburn-1",
        compartment_ocid="ocid1.compartment.oc1..example"
    )
    
    # Initialize enhanced OCI engine
    engine = EnhancedOCIArbitrageEngine(credentials)
    await engine.initialize()
    
    async with engine.cloud_advisor:
        logging.info(f"\n📊 Analyzing cost optimization potential...")
        
        # Get savings analysis
        savings_analysis = await engine.analyze_savings_potential(credentials.compartment_ocid)
        
        logging.info(f"\n💰 Savings Analysis:")
        logging.info(f"   Total Recommendations: {savings_analysis['total_recommendations']}")
        logging.info(f"   Total Savings Potential: ${savings_analysis['total_savings_potential']:.2f}")
        logging.info(f"   High Confidence Savings: ${savings_analysis['high_confidence_savings']:.2f}")
        logging.info(f"   Easy Implementation Savings: ${savings_analysis['easy_implementation_savings']:.2f}")
        logging.info(f"   Average Confidence: {savings_analysis['average_confidence']:.1%}")
        
        # Get cost trend
        cost_trend = await engine.get_monthly_cost_trend(credentials.compartment_ocid, months=6)
        
        logging.info(f"\n📈 Cost Trend Analysis:")
        logging.info(f"   Trend: {cost_trend['trend_analysis']['trend']}")
        logging.info(f"   Monthly Growth: {cost_trend['trend_analysis']['monthly_growth_rate']:.1f}%")
        logging.info(f"   Projected Annual Cost: ${cost_trend['trend_analysis']['projected_annual_cost']:,.2f}")
        
        # Get top recommendations
        top_recommendations = await engine.get_top_recommendations(limit=5)
        
        logging.info(f"\n🎯 Top 5 Recommendations:")
        for i, rec in enumerate(top_recommendations, 1):
            logging.info(f"{i}. {rec['recommendation']}")
            logging.info(f"   Savings: ${rec['estimated_savings']:.2f}")
            logging.info(f"   Confidence: {rec['confidence']:.1%}")
            logging.info(f"   Complexity: {rec['implementation_complexity']}")
            logging.info(f"   Priority Score: {rec['priority_score']:.1f}")
            logging.info()
        
        # Create optimization profile
        profile_result = await engine.create_optimization_profile(credentials.compartment_ocid)
        
        logging.info(f"🔧 Optimization Profile:")
        logging.info(f"   Status: {profile_result['status']}")
        if profile_result['status'] == 'created':
            logging.info(f"   Profile ID: {profile_result['profile_id']}")
        
        logging.info(f"\n🎯 Enhanced OCI Cloud Advisor Integration Completed!")

if __name__ == "__main__":
    asyncio.run(main())
