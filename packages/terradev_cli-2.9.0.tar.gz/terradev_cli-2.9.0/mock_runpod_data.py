import logging

#!/usr/bin/env python3
"""
Mock RunPod Data for Testing
Simulates RunPod API responses for development and testing
"""

import json
from datetime import datetime
from typing import Dict, List

class MockRunPodData:
    """Mock RunPod data for testing"""
    
    def __init__(self):
        self.pods = self._create_mock_pods()
        self.gpu_types = self._create_mock_gpu_types()
        self.templates = self._create_mock_templates()
    
    def _create_mock_pods(self) -> List[Dict]:
        """Create mock pod data"""
        
        return [
            {
                "id": "pod-1",
                "name": "A100 Training Pod",
                "description": "High-performance training instance",
                "machine": {
                    "gpuType": "A100 40GB",
                    "gpuDisplayName": "NVIDIA A100 40GB",
                    "gpuCount": 1,
                    "gpuMemoryInGb": 40,
                    "cpuCores": 8,
                    "cpuArchitecture": "x86_64",
                    "memoryInGb": 64,
                    "storageInGb": 200,
                    "diskType": "SSD"
                },
                "runtime": {
                    "status": "running",
                    "hourlyCost": 2.20,
                    "uptimeSeconds": 3600,
                    "createdAt": datetime.now().isoformat()
                },
                "dataCenter": {
                    "id": "us-east-1",
                    "name": "US East",
                    "country": "United States",
                    "continent": "North America"
                },
                "networkVolume": {
                    "id": "vol-1",
                    "sizeGb": 100,
                    "mountPoint": "/data"
                },
                "env": [
                    {"key": "CUDA_VISIBLE_DEVICES", "value": "0"},
                    {"key": "PYTHONPATH", "value": "/usr/local/lib/python3.8"}
                ],
                "ports": [
                    {"ip": "192.168.1.100", "containerPort": 22, "protocol": "tcp"},
                    {"ip": "192.168.1.100", "containerPort": 8080, "protocol": "tcp"}
                ]
            },
            {
                "id": "pod-2",
                "name": "A10G Inference Pod",
                "description": "Optimized for inference workloads",
                "machine": {
                    "gpuType": "A10G",
                    "gpuDisplayName": "NVIDIA A10G",
                    "gpuCount": 1,
                    "gpuMemoryInGb": 24,
                    "cpuCores": 4,
                    "cpuArchitecture": "x86_64",
                    "memoryInGb": 32,
                    "storageInGb": 100,
                    "diskType": "SSD"
                },
                "runtime": {
                    "status": "running",
                    "hourlyCost": 0.60,
                    "uptimeSeconds": 7200,
                    "createdAt": datetime.now().isoformat()
                },
                "dataCenter": {
                    "id": "us-west-1",
                    "name": "US West",
                    "country": "United States",
                    "continent": "North America"
                },
                "networkVolume": {
                    "id": "vol-2",
                    "sizeGb": 50,
                    "mountPoint": "/data"
                },
                "env": [
                    {"key": "CUDA_VISIBLE_DEVICES", "value": "0"},
                    {"key": "MODEL_PATH", "value": "/models"}
                ],
                "ports": [
                    {"ip": "192.168.1.101", "containerPort": 22, "protocol": "tcp"},
                    {"ip": "192.168.1.101", "containerPort": 8000, "protocol": "tcp"}
                ]
            },
            {
                "id": "pod-3",
                "name": "RTX A6000 Development Pod",
                "description": "Development and testing instance",
                "machine": {
                    "gpuType": "RTX A6000",
                    "gpuDisplayName": "NVIDIA RTX A6000",
                    "gpuCount": 1,
                    "gpuMemoryInGb": 48,
                    "cpuCores": 12,
                    "cpuArchitecture": "x86_64",
                    "memoryInGb": 96,
                    "storageInGb": 500,
                    "diskType": "SSD"
                },
                "runtime": {
                    "status": "running",
                    "hourlyCost": 0.89,
                    "uptimeSeconds": 1800,
                    "createdAt": datetime.now().isoformat()
                },
                "dataCenter": {
                    "id": "eu-west-1",
                    "name": "Europe West",
                    "country": "Ireland",
                    "continent": "Europe"
                },
                "networkVolume": {
                    "id": "vol-3",
                    "sizeGb": 200,
                    "mountPoint": "/data"
                },
                "env": [
                    {"key": "CUDA_VISIBLE_DEVICES", "value": "0"},
                    {"key": "DEV_MODE", "value": "true"}
                ],
                "ports": [
                    {"ip": "192.168.1.102", "containerPort": 22, "protocol": "tcp"},
                    {"ip": "192.168.1.102", "containerPort": 8888, "protocol": "tcp"}
                ]
            }
        ]
    
    def _create_mock_gpu_types(self) -> List[Dict]:
        """Create mock GPU type data"""
        
        return [
            {
                "id": "a100-40gb",
                "name": "A100 40GB",
                "displayName": "NVIDIA A100 40GB",
                "description": "High-performance GPU for training and inference",
                "memoryInGb": 40,
                "cudaVersion": "11.8",
                "driverVersion": "525.60.13",
                "architecture": "Ampere",
                "computeCapability": "8.0",
                "pricePerHour": {
                    "onDemand": 2.20,
                    "spot": 1.80
                },
                "availability": {
                    "us-east-1": True,
                    "us-west-1": True,
                    "eu-west-1": True
                }
            },
            {
                "id": "a10g",
                "name": "A10G",
                "displayName": "NVIDIA A10G",
                "description": "Optimized for inference workloads",
                "memoryInGb": 24,
                "cudaVersion": "11.8",
                "driverVersion": "525.60.13",
                "architecture": "Ampere",
                "computeCapability": "8.6",
                "pricePerHour": {
                    "onDemand": 0.60,
                    "spot": 0.45
                },
                "availability": {
                    "us-east-1": True,
                    "us-west-1": True,
                    "eu-west-1": True
                }
            },
            {
                "id": "rtx-a6000",
                "name": "RTX A6000",
                "displayName": "NVIDIA RTX A6000",
                "description": "Professional workstation GPU",
                "memoryInGb": 48,
                "cudaVersion": "11.8",
                "driverVersion": "525.60.13",
                "architecture": "Ampere",
                "computeCapability": "8.6",
                "pricePerHour": {
                    "onDemand": 0.89,
                    "spot": 0.75
                },
                "availability": {
                    "us-east-1": True,
                    "us-west-1": True,
                    "eu-west-1": True
                }
            }
        ]
    
    def _create_mock_templates(self) -> List[Dict]:
        """Create mock template data"""
        
        return [
            {
                "id": "template-1",
                "name": "PyTorch Training Template",
                "description": "Pre-configured PyTorch training environment",
                "image": "pytorch/pytorch:latest",
                "machine": {
                    "gpuType": "A100 40GB",
                    "gpuCount": 1,
                    "cpuCores": 8,
                    "memoryInGb": 64,
                    "storageInGb": 200
                },
                "env": [
                    {"key": "CUDA_VISIBLE_DEVICES", "value": "0"},
                    {"key": "PYTHONPATH", "value": "/usr/local/lib/python3.8"}
                ],
                "ports": [
                    {"containerPort": 22, "protocol": "tcp"},
                    {"containerPort": 8888, "protocol": "tcp"}
                ],
                "networkVolume": {
                    "sizeGb": 100,
                    "mountPoint": "/data"
                }
            },
            {
                "id": "template-2",
                "name": "TensorFlow Inference Template",
                "description": "Optimized TensorFlow inference setup",
                "image": "tensorflow/tensorflow:latest",
                "machine": {
                    "gpuType": "A10G",
                    "gpuCount": 1,
                    "cpuCores": 4,
                    "memoryInGb": 32,
                    "storageInGb": 100
                },
                "env": [
                    {"key": "CUDA_VISIBLE_DEVICES", "value": "0"},
                    {"key": "MODEL_PATH", "value": "/models"}
                ],
                "ports": [
                    {"containerPort": 22, "protocol": "tcp"},
                    {"containerPort": 8000, "protocol": "tcp"}
                ],
                "networkVolume": {
                    "sizeGb": 50,
                    "mountPoint": "/models"
                }
            }
        ]
    
    def get_pods(self) -> List[Dict]:
        """Get all pods"""
        return self.pods
    
    def get_gpu_types(self) -> List[Dict]:
        """Get all GPU types"""
        return self.gpu_types
    
    def get_templates(self) -> List[Dict]:
        """Get all templates"""
        return self.templates
    
    def get_pods_by_gpu_type(self, gpu_type: str) -> List[Dict]:
        """Get pods filtered by GPU type"""
        return [pod for pod in self.pods if pod["machine"]["gpuType"] == gpu_type]
    
    def get_pricing_summary(self) -> Dict:
        """Get pricing summary"""
        
        summary = {}
        
        for pod in self.pods:
            gpu_type = pod["machine"]["gpuType"]
            hourly_cost = pod["runtime"]["hourlyCost"]
            
            if gpu_type not in summary:
                summary[gpu_type] = {
                    "min_price": hourly_cost,
                    "max_price": hourly_cost,
                    "avg_price": hourly_cost,
                    "pod_count": 1
                }
            else:
                summary[gpu_type]["pod_count"] += 1
                summary[gpu_type]["min_price"] = min(summary[gpu_type]["min_price"], hourly_cost)
                summary[gpu_type]["max_price"] = max(summary[gpu_type]["max_price"], hourly_cost)
                summary[gpu_type]["avg_price"] = (summary[gpu_type]["avg_price"] * (summary[gpu_type]["pod_count"] - 1) + hourly_cost) / summary[gpu_type]["pod_count"]
        
        return summary

# Test the mock data
def test_mock_data():
    """Test mock RunPod data"""
    
    mock_data = MockRunPodData()
    
    logging.info("🚀 Testing Mock RunPod Data")
    logging.info("=" * 50)
    
    # Test 1: Get all pods
    logging.info("\n📊 Getting All Pods...")
    pods = mock_data.get_pods()
    logging.info(f"✅ Found {len(pods)
    
    for pod in pods:
        logging.info(f"   • {pod['name']}: ${pod['runtime']['hourlyCost']:.2f}/hr")
        logging.info(f"     GPU: {pod['machine']['gpuType']}")
        logging.info(f"     Status: {pod['runtime']['status']}")
    
    # Test 2: Get GPU types
    logging.info("\n🔥 Getting GPU Types...")
    gpu_types = mock_data.get_gpu_types()
    logging.info(f"✅ Found {len(gpu_types)
    
    for gpu_type in gpu_types:
        logging.info(f"   • {gpu_type['displayName']}: ${gpu_type['pricePerHour']['onDemand']:.2f}/hr")
        logging.info(f"     Memory: {gpu_type['memoryInGb']}GB")
        logging.info(f"     Architecture: {gpu_type['architecture']}")
    
    # Test 3: Get pricing summary
    logging.info("\n💰 Getting Pricing Summary...")
    pricing = mock_data.get_pricing_summary()
    
    for gpu_type, info in pricing.items():
        logging.info(f"   • {gpu_type}:")
        logging.info(f"     Price Range: ${info['min_price']:.2f} - ${info['max_price']:.2f}/hr")
        logging.info(f"     Average: ${info['avg_price']:.2f}/hr")
        logging.info(f"     Pod Count: {info['pod_count']}")
    
    # Test 4: Get pods by GPU type
    logging.info("\n🔍 Getting A100 Pods...")
    a100_pods = mock_data.get_pods_by_gpu_type("A100 40GB")
    logging.info(f"✅ Found {len(a100_pods)
    
    for pod in a100_pods:
        logging.info(f"   • {pod['name']}: ${pod['runtime']['hourlyCost']:.2f}/hr")
        logging.info(f"     Location: {pod['dataCenter']['name']}")

if __name__ == "__main__":
    test_mock_data()
