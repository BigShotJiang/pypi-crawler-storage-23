#!/usr/bin/env python3
"""
Terradev SaaS Optimization Platform
Model 2: Software License - Safest Legal Approach
Users pay monthly subscription for optimization software
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import stripe
from cryptography.fernet import Fernet

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SubscriptionTier(Enum):
    """Subscription tiers for SaaS model"""
    STARTER = "starter"          # $49/month
    PROFESSIONAL = "professional"  # $199/month
    ENTERPRISE = "enterprise"     # $999/month
    CUSTOM = "custom"             # Custom pricing

class CloudProvider(Enum):
    """Supported cloud providers"""
    AWS = "aws"
    GCP = "gcp"
    AZURE = "azure"
    RUNPOD = "runpod"
    LAMBDA = "lambda"
    COREWEAVE = "coreweave"
    HUGGINGFACE = "huggingface"

@dataclass
class UserAccount:
    """User account with cloud credentials"""
    user_id: str
    email: str
    subscription_tier: SubscriptionTier
    subscription_active: bool
    billing_cycle_start: datetime
    billing_cycle_end: datetime
    cloud_credentials: Dict[str, Dict]  # Encrypted credentials
    optimization_settings: Dict
    usage_analytics: Dict
    created_at: datetime

@dataclass
class OptimizationResult:
    """Result of cloud optimization analysis"""
    recommended_provider: CloudProvider
    recommended_instance_type: str
    estimated_savings_percent: float
    estimated_monthly_savings: float
    current_monthly_cost: float
    optimized_monthly_cost: float
    reliability_score: float
    performance_score: float
    optimization_reasoning: List[str]

@dataclass
class CloudCredentials:
    """Encrypted cloud credentials"""
    provider: CloudProvider
    credential_type: str  # api_key, service_account, etc.
    encrypted_data: bytes
    permissions: List[str]
    last_verified: datetime
    expires_at: Optional[datetime]

class TerradevSaaSPlatform:
    """
    Terradev SaaS Optimization Platform
    Software License Model - Legally Safe
    """
    
    def __init__(self):
        self.users = {}
        self.encryption_key = Fernet.generate_key()
        self.cipher_suite = Fernet(self.encryption_key)
        
        # Subscription pricing
        self.pricing = {
            SubscriptionTier.STARTER: 49,
            SubscriptionTier.PROFESSIONAL: 199,
            SubscriptionTier.ENTERPRISE: 999,
            SubscriptionTier.CUSTOM: 0  # Custom pricing
        }
        
        # Feature limits per tier
        self.feature_limits = {
            SubscriptionTier.STARTER: {
                'cloud_providers': 2,
                'optimizations_per_month': 10,
                'analytics_retention_days': 30,
                'api_calls_per_day': 100,
                'support_level': 'community'
            },
            SubscriptionTier.PROFESSIONAL: {
                'cloud_providers': 5,
                'optimizations_per_month': 100,
                'analytics_retention_days': 90,
                'api_calls_per_day': 1000,
                'support_level': 'email'
            },
            SubscriptionTier.ENTERPRISE: {
                'cloud_providers': 10,
                'optimizations_per_month': 1000,
                'analytics_retention_days': 365,
                'api_calls_per_day': 10000,
                'support_level': 'priority'
            },
            SubscriptionTier.CUSTOM: {
                'cloud_providers': 20,
                'optimizations_per_month': -1,  # Unlimited
                'analytics_retention_days': -1,  # Unlimited
                'api_calls_per_day': -1,  # Unlimited
                'support_level': 'dedicated'
            }
        }
        
        # Cloud provider configurations
        self.provider_configs = {
            CloudProvider.AWS: {
                'name': 'Amazon Web Services',
                'regions': ['us-east-1', 'us-west-2', 'eu-west-1'],
                'instance_types': {
                    'gpu': ['p3.2xlarge', 'p3.8xlarge', 'p4d.24xlarge', 'g5.xlarge', 'g5.12xlarge'],
                    'cpu': ['t3.medium', 't3.large', 'm5.large', 'm5.xlarge', 'c5.large']
                },
                'pricing_per_hour': {
                    'p3.2xlarge': 3.06,
                    'p3.8xlarge': 12.24,
                    'p4d.24xlarge': 32.77,
                    'g5.xlarge': 1.006,
                    'g5.12xlarge': 12.07,
                    't3.medium': 0.0416,
                    't3.large': 0.0832,
                    'm5.large': 0.096,
                    'm5.xlarge': 0.192,
                    'c5.large': 0.085
                }
            },
            CloudProvider.GCP: {
                'name': 'Google Cloud Platform',
                'regions': ['us-central1', 'us-west1', 'europe-west1'],
                'instance_types': {
                    'gpu': ['n1-standard-4-k80-1', 'n1-standard-8-v100-1', 'a2-highgpu-1g', 'a2-highgpu-4g'],
                    'cpu': ['e2-medium', 'e2-standard-2', 'n1-standard-1', 'n1-standard-2', 'c2-standard-4']
                },
                'pricing_per_hour': {
                    'n1-standard-4-k80-1': 2.60,
                    'n1-standard-8-v100-1': 5.20,
                    'a2-highgpu-1g': 4.36,
                    'a2-highgpu-4g': 17.44,
                    'e2-medium': 0.041,
                    'e2-standard-2': 0.082,
                    'n1-standard-1': 0.047,
                    'n1-standard-2': 0.094,
                    'c2-standard-4': 0.132
                }
            },
            CloudProvider.AZURE: {
                'name': 'Microsoft Azure',
                'regions': ['eastus', 'westus2', 'westeurope'],
                'instance_types': {
                    'gpu': ['Standard_NC6s_v3', 'Standard_NC12s_v3', 'Standard_ND40rs_v2'],
                    'cpu': ['Standard_B2s', 'Standard_D2s_v3', 'Standard_F4s_v2', 'Standard_D4s_v3']
                },
                'pricing_per_hour': {
                    'Standard_NC6s_v3': 3.06,
                    'Standard_NC12s_v3': 6.12,
                    'Standard_ND40rs_v2': 24.48,
                    'Standard_B2s': 0.07,
                    'Standard_D2s_v3': 0.096,
                    'Standard_F4s_v2': 0.08,
                    'Standard_D4s_v3': 0.192
                }
            },
            CloudProvider.RUNPOD: {
                'name': 'RunPod',
                'instance_types': {
                    'gpu': ['A100 40GB', 'A100 80GB', 'RTX A4000', 'RTX A5000', 'RTX A6000'],
                    'cpu': ['CPU 4 cores', 'CPU 8 cores', 'CPU 16 cores']
                },
                'pricing_per_hour': {
                    'A100 40GB': 2.20,
                    'A100 80GB': 3.50,
                    'RTX A4000': 0.45,
                    'RTX A5000': 0.65,
                    'RTX A6000': 0.89,
                    'CPU 4 cores': 0.07,
                    'CPU 8 cores': 0.14,
                    'CPU 16 cores': 0.28
                }
            },
            CloudProvider.LAMBDA: {
                'name': 'Lambda Labs',
                'instance_types': {
                    'gpu': ['A100 40GB', 'A100 80GB', 'RTX A6000', 'RTX 3090'],
                    'cpu': ['CPU 4 cores', 'CPU 8 cores', 'CPU 16 cores']
                },
                'pricing_per_hour': {
                    'A100 40GB': 2.15,
                    'A100 80GB': 3.40,
                    'RTX A6000': 0.85,
                    'RTX 3090': 0.35,
                    'CPU 4 cores': 0.06,
                    'CPU 8 cores': 0.12,
                    'CPU 16 cores': 0.24
                }
            },
            CloudProvider.COREWEAVE: {
                'name': 'CoreWeave',
                'instance_types': {
                    'gpu': ['RTX A6000', 'RTX A5000', 'RTX A4000', 'A100 40GB'],
                    'cpu': ['CPU 4 cores', 'CPU 8 cores', 'CPU 16 cores']
                },
                'pricing_per_hour': {
                    'RTX A6000': 0.80,
                    'RTX A5000': 0.60,
                    'RTX A4000': 0.40,
                    'A100 40GB': 2.10,
                    'CPU 4 cores': 0.05,
                    'CPU 8 cores': 0.10,
                    'CPU 16 cores': 0.20
                }
            },
            CloudProvider.HUGGINGFACE: {
                'name': 'HuggingFace',
                'instance_types': {
                    'gpu': ['A10G', 'A10G-Large', 'A100'],
                    'cpu': ['CPU Basic', 'CPU Upgrade', 'CPU Large']
                },
                'pricing_per_hour': {
                    'A10G': 0.60,
                    'A10G-Large': 1.20,
                    'A100': 3.00,
                    'CPU Basic': 0.10,
                    'CPU Upgrade': 0.20,
                    'CPU Large': 0.40
                }
            }
        }
    
    def encrypt_credentials(self, credentials: Dict) -> bytes:
        """Encrypt cloud credentials"""
        credentials_json = json.dumps(credentials)
        encrypted_data = self.cipher_suite.encrypt(credentials_json.encode())
        return encrypted_data
    
    def decrypt_credentials(self, encrypted_data: bytes) -> Dict:
        """Decrypt cloud credentials"""
        decrypted_data = self.cipher_suite.decrypt(encrypted_data)
        return json.loads(decrypted_data.decode())
    
    async def create_user_account(self, 
                                 email: str,
                                 subscription_tier: SubscriptionTier,
                                 payment_method_id: str) -> UserAccount:
        """Create new user account with subscription"""
        
        # Create Stripe customer and subscription
        # In production, integrate with actual Stripe API
        
        user_id = f"user_{int(datetime.now().timestamp())}"
        
        # Calculate billing cycle
        now = datetime.now()
        billing_cycle_end = now + timedelta(days=30)
        
        user = UserAccount(
            user_id=user_id,
            email=email,
            subscription_tier=subscription_tier,
            subscription_active=True,
            billing_cycle_start=now,
            billing_cycle_end=billing_cycle_end,
            cloud_credentials={},
            optimization_settings={
                'preferred_providers': [],
                'cost_optimization_level': 'balanced',
                'performance_priority': 'medium',
                'notification_preferences': {
                    'email_alerts': True,
                    'cost_alerts': True,
                    'optimization_alerts': True
                }
            },
            usage_analytics={
                'optimizations_run': 0,
                'total_savings': 0.0,
                'last_optimization': None,
                'api_calls_today': 0,
                'api_calls_this_month': 0
            },
            created_at=now
        )
        
        self.users[user_id] = user
        
        logger.info(f"✅ Created user account: {user_id} ({subscription_tier.value})")
        
        return user
    
    async def add_cloud_credentials(self,
                                   user_id: str,
                                   provider: CloudProvider,
                                   credentials: Dict,
                                   credential_type: str = 'api_key') -> bool:
        """Add encrypted cloud credentials for user"""
        
        if user_id not in self.users:
            logger.error(f"❌ User {user_id} not found")
            return False
        
        user = self.users[user_id]
        
        # Check subscription limits
        limits = self.feature_limits[user.subscription_tier]
        current_providers = len(user.cloud_credentials)
        
        if current_providers >= limits['cloud_providers']:
            logger.error(f"❌ Cloud provider limit reached for {user.subscription_tier.value}")
            return False
        
        # Encrypt and store credentials
        encrypted_data = self.encrypt_credentials(credentials)
        
        cloud_creds = CloudCredentials(
            provider=provider,
            credential_type=credential_type,
            encrypted_data=encrypted_data,
            permissions=['read', 'optimize'],
            last_verified=datetime.now(),
            expires_at=None
        )
        
        user.cloud_credentials[provider.value] = asdict(cloud_creds)
        
        logger.info(f"✅ Added {provider.value} credentials for user {user_id}")
        
        return True
    
    async def run_optimization_analysis(self,
                                       user_id: str,
                                       requirements: Dict) -> OptimizationResult:
        """Run cloud optimization analysis for user"""
        
        if user_id not in self.users:
            raise ValueError(f"User {user_id} not found")
        
        user = self.users[user_id]
        
        # Check usage limits
        limits = self.feature_limits[user.subscription_tier]
        
        if user.usage_analytics['optimizations_run'] >= limits['optimizations_per_month']:
            if limits['optimizations_per_month'] != -1:  # Not unlimited
                raise ValueError(f"Optimization limit reached for {user.subscription_tier.value}")
        
        # Analyze requirements and find best provider
        best_result = await self._analyze_providers(requirements, user)
        
        # Update usage analytics
        user.usage_analytics['optimizations_run'] += 1
        user.usage_analytics['total_savings'] += best_result.estimated_monthly_savings
        user.usage_analytics['last_optimization'] = datetime.now().isoformat()
        
        logger.info(f"✅ Optimization completed for user {user_id}")
        logger.info(f"🏆 Recommended: {best_result.recommended_provider.value}")
        logger.info(f"💰 Estimated savings: ${best_result.estimated_monthly_savings:.2f}/month")
        
        return best_result
    
    async def _analyze_providers(self, 
                               requirements: Dict,
                               user: UserAccount) -> OptimizationResult:
        """Analyze all available providers for best optimization"""
        
        # Extract requirements
        compute_type = requirements.get('compute_type', 'gpu')
        performance_requirement = requirements.get('performance', 'medium')
        budget_limit = requirements.get('budget_limit', float('inf'))
        reliability_requirement = requirements.get('reliability', 'high')
        
        # Analyze each provider the user has credentials for
        provider_scores = {}
        
        for provider_name, creds_data in user.cloud_credentials.items():
            provider = CloudProvider(provider_name)
            config = self.provider_configs[provider]
            
            # Find suitable instance types
            suitable_instances = []
            for instance_type in config['instance_types'].get(compute_type, []):
                hourly_rate = config['pricing_per_hour'].get(instance_type, float('inf'))
                
                if hourly_rate <= budget_limit:
                    # Calculate score based on cost, performance, reliability
                    cost_score = 1.0 / (hourly_rate + 0.01)  # Lower cost = higher score
                    
                    # Performance score based on instance type
                    if 'A100' in instance_type or 'p4' in instance_type:
                        performance_score = 1.0
                    elif 'A10G' in instance_type or 'p3' in instance_type:
                        performance_score = 0.8
                    elif 'RTX A6000' in instance_type:
                        performance_score = 0.7
                    else:
                        performance_score = 0.5
                    
                    # Reliability score based on provider
                    if provider in [CloudProvider.AWS, CloudProvider.GCP, CloudProvider.AZURE]:
                        reliability_score = 0.95
                    elif provider == CloudProvider.HUGGINGFACE:
                        reliability_score = 0.99
                    else:
                        reliability_score = 0.85
                    
                    # Combined score
                    total_score = (cost_score * 0.4 + 
                                 performance_score * 0.3 + 
                                 reliability_score * 0.3)
                    
                    suitable_instances.append({
                        'instance_type': instance_type,
                        'hourly_rate': hourly_rate,
                        'cost_score': cost_score,
                        'performance_score': performance_score,
                        'reliability_score': reliability_score,
                        'total_score': total_score
                    })
            
            if suitable_instances:
                # Sort by total score
                suitable_instances.sort(key=lambda x: x['total_score'], reverse=True)
                best_instance = suitable_instances[0]
                
                provider_scores[provider] = {
                    'instance_type': best_instance['instance_type'],
                    'hourly_rate': best_instance['hourly_rate'],
                    'total_score': best_instance['total_score'],
                    'cost_score': best_instance['cost_score'],
                    'performance_score': best_instance['performance_score'],
                    'reliability_score': best_instance['reliability_score']
                }
        
        if not provider_scores:
            raise ValueError("No suitable providers found for requirements")
        
        # Select best provider
        best_provider = max(provider_scores.keys(), key=lambda p: provider_scores[p]['total_score'])
        best_config = provider_scores[best_provider]
        
        # Calculate savings vs baseline (AWS as baseline)
        baseline_hourly_rate = 3.06  # AWS p3.2xlarge
        estimated_monthly_usage = requirements.get('monthly_hours', 730)  # 24/7 for month
        
        current_monthly_cost = baseline_hourly_rate * estimated_monthly_usage
        optimized_monthly_cost = best_config['hourly_rate'] * estimated_monthly_usage
        estimated_savings = current_monthly_cost - optimized_monthly_cost
        savings_percent = (estimated_savings / current_monthly_cost) * 100
        
        # Generate reasoning
        reasoning = [
            f"Selected {best_provider.value} for best cost-performance ratio",
            f"Instance {best_config['instance_type']} offers ${best_config['hourly_rate']:.2f}/hour",
            f"Reliability score: {best_config['reliability_score']:.1%}",
            f"Performance score: {best_config['performance_score']:.1%}",
            f"Estimated {savings_percent:.1f}% cost savings vs baseline"
        ]
        
        return OptimizationResult(
            recommended_provider=best_provider,
            recommended_instance_type=best_config['instance_type'],
            estimated_savings_percent=savings_percent,
            estimated_monthly_savings=estimated_savings,
            current_monthly_cost=current_monthly_cost,
            optimized_monthly_cost=optimized_monthly_cost,
            reliability_score=best_config['reliability_score'],
            performance_score=best_config['performance_score'],
            optimization_reasoning=reasoning
        )
    
    def get_user_analytics(self, user_id: str) -> Dict:
        """Get comprehensive user analytics"""
        
        if user_id not in self.users:
            raise ValueError(f"User {user_id} not found")
        
        user = self.users[user_id]
        limits = self.feature_limits[user.subscription_tier]
        
        return {
            'user_id': user_id,
            'email': user.email,
            'subscription_tier': user.subscription_tier.value,
            'subscription_active': user.subscription_active,
            'billing_cycle': {
                'start': user.billing_cycle_start.isoformat(),
                'end': user.billing_cycle_end.isoformat(),
                'days_remaining': (user.billing_cycle_end - datetime.now()).days
            },
            'usage_analytics': user.usage_analytics,
            'feature_limits': limits,
            'usage_percentage': {
                'optimizations': (user.usage_analytics['optimizations_run'] / limits['optimizations_per_month'] * 100) if limits['optimizations_per_month'] != -1 else 0,
                'cloud_providers': (len(user.cloud_credentials) / limits['cloud_providers'] * 100),
                'api_calls': (user.usage_analytics['api_calls_today'] / limits['api_calls_per_day'] * 100) if limits['api_calls_per_day'] != -1 else 0
            },
            'connected_providers': list(user.cloud_credentials.keys()),
            'total_savings_to_date': user.usage_analytics['total_savings']
        }
    
    def get_marketplace_comparison(self) -> Dict:
        """Get marketplace comparison for all providers"""
        
        comparison = {}
        
        for provider, config in self.provider_configs.items():
            # Calculate average pricing
            gpu_prices = [price for instance, price in config['pricing_per_hour'].items() 
                          if any(gpu_type in instance.lower() for gpu_type in ['a100', 'a10g', 'rtx', 'p3', 'p4'])]
            cpu_prices = [price for instance, price in config['pricing_per_hour'].items() 
                          if any(cpu_type in instance.lower() for cpu_type in ['cpu', 't3', 'm5', 'c5', 'e2', 'n1'])]
            
            comparison[provider.value] = {
                'name': config['name'],
                'regions': config['regions'],
                'gpu_instance_count': len([i for i in config['instance_types'].get('gpu', [])]),
                'cpu_instance_count': len([i for i in config['instance_types'].get('cpu', [])]),
                'average_gpu_price': sum(gpu_prices) / len(gpu_prices) if gpu_prices else 0,
                'average_cpu_price': sum(cpu_prices) / len(cpu_prices) if cpu_prices else 0,
                'price_range': {
                    'gpu_min': min(gpu_prices) if gpu_prices else 0,
                    'gpu_max': max(gpu_prices) if gpu_prices else 0,
                    'cpu_min': min(cpu_prices) if cpu_prices else 0,
                    'cpu_max': max(cpu_prices) if cpu_prices else 0
                }
            }
        
        return comparison

# CLI interface
async def main():
    """CLI interface for Terradev SaaS Platform"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Terradev SaaS Optimization Platform')
    parser.add_argument('--create-user', help='Create new user account')
    parser.add_argument('--email', help='User email')
    parser.add_argument('--tier', choices=['starter', 'professional', 'enterprise'], help='Subscription tier')
    parser.add_argument('--add-credentials', help='Add cloud credentials')
    parser.add_argument('--provider', choices=['aws', 'gcp', 'azure', 'runpod', 'lambda', 'coreweave', 'huggingface'], help='Cloud provider')
    parser.add_argument('--optimize', action='store_true', help='Run optimization analysis')
    parser.add_argument('--compute-type', choices=['gpu', 'cpu'], default='gpu', help='Compute type')
    parser.add_argument('--budget', type=float, help='Budget limit per hour')
    parser.add_argument('--monthly-hours', type=int, default=730, help='Monthly usage hours')
    parser.add_argument('--analytics', help='Get user analytics')
    parser.add_argument('--marketplace', action='store_true', help='Get marketplace comparison')
    
    args = parser.parse_args()
    
    platform = TerradevSaaSPlatform()
    
    if args.create_user and args.email and args.tier:
        # Create user account
        tier = SubscriptionTier(args.tier)
        user = await platform.create_user_account(args.email, tier, "pm_test_123")
        logging.info(f"✅ Created user account: {user.user_id}")
        logging.info(f"📧 Email: {user.email}")
        logging.info(f"💳 Tier: {user.subscription_tier.value}")
        logging.info(f"💰 Monthly cost: ${platform.pricing[tier]}")
    
    elif args.add_credentials and args.provider:
        # Add cloud credentials (demo)
        demo_credentials = {
            'api_key': 'demo_key_12345',
            'region': 'us-east-1',
            'project_id': 'demo-project'
        }
        
        success = await platform.add_cloud_credentials(
            "demo_user", CloudProvider(args.provider), demo_credentials
        )
        
        if success:
            logging.info(f"✅ Added {args.provider} credentials")
        else:
            logging.info(f"❌ Failed to add {args.provider} credentials")
    
    elif args.optimize:
        # Run optimization analysis
        requirements = {
            'compute_type': args.compute_type,
            'budget_limit': args.budget or float('inf'),
            'monthly_hours': args.monthly_hours,
            'performance': 'medium',
            'reliability': 'high'
        }
        
        try:
            result = await platform.run_optimization_analysis("demo_user", requirements)
            
            logging.info("🏆 OPTIMIZATION RESULTS:")
            logging.info(f"Recommended Provider: {result.recommended_provider.value}")
            logging.info(f"Instance Type: {result.recommended_instance_type}")
            logging.info(f"Estimated Savings: {result.estimated_savings_percent:.1f}%")
            logging.info(f"Monthly Savings: ${result.estimated_monthly_savings:.2f}")
            logging.info(f"Current Cost: ${result.current_monthly_cost:.2f}/month")
            logging.info(f"Optimized Cost: ${result.optimized_monthly_cost:.2f}/month")
            logging.info(f"Reliability Score: {result.reliability_score:.1%}")
            logging.info(f"Performance Score: {result.performance_score:.1%}")
            
            logging.info("\n📊 Reasoning:")
            for reason in result.optimization_reasoning:
                logging.info(f"• {reason}")
                
        except Exception as e:
            logging.info(f"❌ Optimization failed: {e}")
    
    elif args.analytics:
        # Get user analytics
        try:
            analytics = platform.get_user_analytics(args.analytics)
            
            logging.info("📊 USER ANALYTICS:")
            logging.info(f"User ID: {analytics['user_id']}")
            logging.info(f"Email: {analytics['email']}")
            logging.info(f"Tier: {analytics['subscription_tier']}")
            logging.info(f"Active: {analytics['subscription_active']}")
            logging.info(f"Total Savings: ${analytics['total_savings_to_date']:.2f}")
            logging.info(f"Optimizations Run: {analytics['usage_analytics']['optimizations_run']}")
            logging.info(f"Connected Providers: {analytics['connected_providers']}")
            
            logging.info(f"\n📈 Usage Limits:")
            for feature, usage in analytics['usage_percentage'].items():
                logging.info(f"{feature}: {usage:.1f}%")
                
        except Exception as e:
            logging.info(f"❌ Analytics failed: {e}")
    
    elif args.marketplace:
        # Get marketplace comparison
        comparison = platform.get_marketplace_comparison()
        
        logging.info("🏪 MARKETPLACE COMPARISON:")
        for provider, info in comparison.items():
            logging.info(f"\n{provider.upper()
            logging.info(f"  Regions: {', '.join(info['regions'])
            logging.info(f"  GPU Instances: {info['gpu_instance_count']}")
            logging.info(f"  CPU Instances: {info['cpu_instance_count']}")
            logging.info(f"  Avg GPU Price: ${info['average_gpu_price']:.2f}/hour")
            logging.info(f"  Avg CPU Price: ${info['average_cpu_price']:.2f}/hour")
            logging.info(f"  GPU Range: ${info['price_range']['gpu_min']:.2f} - ${info['price_range']['gpu_max']:.2f}")
            logging.info(f"  CPU Range: ${info['price_range']['cpu_min']:.2f} - ${info['price_range']['cpu_max']:.2f}")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    asyncio.run(main())
