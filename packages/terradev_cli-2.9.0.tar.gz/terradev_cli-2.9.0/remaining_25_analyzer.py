#!/usr/bin/env python3
"""
Terradev Remaining 25% Analysis
Comprehensive review of remaining issues to achieve 95% production readiness
"""

import os
import re
import json
import ast
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class RemainingIssuesAnalyzer:
    """Analyze remaining 25% of issues for 95% production readiness"""
    
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        self.remaining_issues = []
        self.prioritized_fixes = []
        
    def analyze_remaining_issues(self) -> Dict[str, Any]:
        """Analyze remaining issues for final 25% improvement"""
        logger.info("🔍 STARTING REMAINING 25% ANALYSIS")
        logger.info("=" * 80)
        
        # Current status: 75% readiness, need 20% more to reach 95%
        
        # Phase 1: Deep Security Analysis
        logger.info("\n🔒 PHASE 1: DEEP SECURITY ANALYSIS")
        self._analyze_remaining_security_issues()
        
        # Phase 2: Performance Bottleneck Analysis
        logger.info("\n⚡ PHASE 2: PERFORMANCE BOTTLENECK ANALYSIS")
        self._analyze_performance_bottlenecks()
        
        # Phase 3: Architecture Refactoring Analysis
        logger.info("\n🏗️ PHASE 3: ARCHITECTURE REFACTORING ANALYSIS")
        self._analyze_architecture_refactoring()
        
        # Phase 4: Code Quality Deep Dive
        logger.info("\n📝 PHASE 4: CODE QUALITY DEEP DIVE")
        self._analyze_code_quality_remaining()
        
        # Phase 5: Production Readiness Gaps
        logger.info("\n🏭 PHASE 5: PRODUCTION READINESS GAPS")
        self._analyze_production_readiness_gaps()
        
        # Generate comprehensive report
        return self._generate_remaining_analysis_report()
    
    def _analyze_remaining_security_issues(self) -> None:
        """Analyze remaining security vulnerabilities"""
        
        python_files = list(self.project_root.rglob("*.py"))
        remaining_security = []
        
        for file_path in python_files[:50]:  # Focus on high-risk files
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Check for remaining hardcoded secrets
                secret_patterns = [
                    r'password\s*=\s*["\'][^"\']+["\']',
                    r'api_key\s*=\s*["\'][^"\']+["\']',
                    r'secret\s*=\s*["\'][^"\']+["\']',
                    r'token\s*=\s*["\'][^"\']+["\']'
                ]
                
                for pattern in secret_patterns:
                    matches = re.findall(pattern, content, re.IGNORECASE)
                    if matches:
                        remaining_security.append({
                            'file': str(file_path),
                            'type': 'Hardcoded Secret',
                            'count': len(matches),
                            'severity': 'CRITICAL',
                            'pattern': pattern
                        })
                
                # Check for SQL injection vulnerabilities
                sql_patterns = [
                    r'execute\s*\(\s*["\'][^"\']*["\']\s*\+',
                    r'cursor\.execute\s*\(\s*["\'][^"\']*["\']\s*\+',
                    r'f["\'][^"\']*SELECT[^"\']*\{[^}]*\}[^"\']*["\']'
                ]
                
                for pattern in sql_patterns:
                    matches = re.findall(pattern, content, re.IGNORECASE)
                    if matches:
                        remaining_security.append({
                            'file': str(file_path),
                            'type': 'SQL Injection',
                            'count': len(matches),
                            'severity': 'HIGH',
                            'pattern': pattern
                        })
                
                # Check for command injection
                cmd_patterns = [
                    r'subprocess\.run\s*\(\s*[^)]*\+[^)]*\)',
                    r'os\.system\s*\(\s*[^)]*\+[^)]*\)',
                    r'eval\s*\(\s*[^)]*\+[^)]*\)'
                ]
                
                for pattern in cmd_patterns:
                    matches = re.findall(pattern, content)
                    if matches:
                        remaining_security.append({
                            'file': str(file_path),
                            'type': 'Command Injection',
                            'count': len(matches),
                            'severity': 'HIGH',
                            'pattern': pattern
                        })
                
                # Check for weak cryptography
                crypto_patterns = [
                    r'md5\s*\(',
                    r'sha1\s*\(',
                    r'hashlib\.md5',
                    r'hashlib\.sha1',
                    r'Crypto\.Cipher\.DES',
                    r'Crypto\.Cipher\.RC4'
                ]
                
                for pattern in crypto_patterns:
                    matches = re.findall(pattern, content)
                    if matches:
                        remaining_security.append({
                            'file': str(file_path),
                            'type': 'Weak Cryptography',
                            'count': len(matches),
                            'severity': 'MEDIUM',
                            'pattern': pattern
                        })
            
            except Exception as e:
                logger.error(f"Error analyzing {file_path}: {e}")
        
        self.remaining_issues.extend(remaining_security)
        logger.info(f"🔒 Found {len(remaining_security)} remaining security issues")
    
    def _analyze_performance_bottlenecks(self) -> None:
        """Analyze remaining performance bottlenecks"""
        
        python_files = list(self.project_root.rglob("*.py"))
        performance_issues = []
        
        for file_path in python_files[:30]:  # Focus on performance-critical files
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Check for blocking I/O patterns
                blocking_patterns = [
                    (r'requests\.(get|post|put|delete)\s*\(', 'Blocking HTTP'),
                    (r'urllib\.request\.urlopen\s*\(', 'Blocking HTTP'),
                    (r'subprocess\.run\s*\(', 'Blocking subprocess'),
                    (r'time\.sleep\s*\(', 'Blocking sleep'),
                    (r'socket\.socket\s*\(', 'Blocking socket')
                ]
                
                for pattern, issue_type in blocking_patterns:
                    matches = re.findall(pattern, content)
                    if matches:
                        performance_issues.append({
                            'file': str(file_path),
                            'type': issue_type,
                            'count': len(matches),
                            'severity': 'HIGH',
                            'recommendation': 'Convert to async/await'
                        })
                
                # Check for inefficient loops
                loop_patterns = [
                    (r'for\s+\w+\s+in\s+range\s*\(\s*len\s*\(', 'range(len()) loop'),
                    (r'while\s+True\s*:', 'Infinite loop'),
                    (r'for\s+\w+\s+in\s+.*\.keys\s*\(\s*\)', '.keys() iteration')
                ]
                
                for pattern, issue_type in loop_patterns:
                    matches = re.findall(pattern, content, re.MULTILINE)
                    if matches:
                        performance_issues.append({
                            'file': str(file_path),
                            'type': issue_type,
                            'count': len(matches),
                            'severity': 'MEDIUM',
                            'recommendation': 'Optimize loop pattern'
                        })
                
                # Check for memory issues
                memory_patterns = [
                    (r'\[\s*x\s+for\s+x\s+in\s+range\s*\([^)]+\)\s*\]', 'Large list comprehension'),
                    (r'dict\s*\(\s*\[\s*\([^)]+\)\s+for\s+[^)]+\s+in\s+[^)]+\]\s*\)', 'Large dict creation')
                ]
                
                for pattern, issue_type in memory_patterns:
                    matches = re.findall(pattern, content)
                    if matches:
                        performance_issues.append({
                            'file': str(file_path),
                            'type': issue_type,
                            'count': len(matches),
                            'severity': 'MEDIUM',
                            'recommendation': 'Use generators'
                        })
            
            except Exception as e:
                logger.error(f"Error analyzing {file_path}: {e}")
        
        self.remaining_issues.extend(performance_issues)
        logger.info(f"⚡ Found {len(performance_issues)} performance bottlenecks")
    
    def _analyze_architecture_refactoring(self) -> None:
        """Analyze architecture refactoring needs"""
        
        python_files = list(self.project_root.rglob("*.py"))
        architecture_issues = []
        
        for file_path in python_files[:20]:  # Focus on architecture files
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Parse AST for architecture analysis
                try:
                    tree = ast.parse(content)
                    
                    for node in ast.walk(tree):
                        if isinstance(node, ast.ClassDef):
                            # Check for god classes
                            methods = [n for n in node.body if isinstance(n, ast.FunctionDef)]
                            if len(methods) > 20:
                                architecture_issues.append({
                                    'file': str(file_path),
                                    'type': 'God Class',
                                    'class_name': node.name,
                                    'method_count': len(methods),
                                    'severity': 'HIGH',
                                    'recommendation': 'Split into smaller classes'
                                })
                            
                            # Check for long parameter lists
                            for method in methods:
                                args = len(method.args.args) - (1 if method.args.vararg else 0) - (len(method.args.defaults) if method.args.defaults else 0)
                                if args > 7:
                                    architecture_issues.append({
                                        'file': str(file_path),
                                        'type': 'Long Parameter List',
                                        'method_name': method.name,
                                        'parameter_count': args,
                                        'severity': 'MEDIUM',
                                        'recommendation': 'Use parameter object'
                                    })
                        
                        elif isinstance(node, ast.FunctionDef):
                            # Check for long functions
                            if hasattr(node, 'end_lineno') and node.end_lineno:
                                func_length = node.end_lineno - node.lineno
                                if func_length > 100:
                                    architecture_issues.append({
                                        'file': str(file_path),
                                        'type': 'Very Long Function',
                                        'function_name': node.name,
                                        'line_count': func_length,
                                        'severity': 'HIGH',
                                        'recommendation': 'Break into smaller functions'
                                    })
                
                except SyntaxError:
                    # Skip files with syntax errors
                    continue
            
            except Exception as e:
                logger.error(f"Error analyzing {file_path}: {e}")
        
        self.remaining_issues.extend(architecture_issues)
        logger.info(f"🏗️ Found {len(architecture_issues)} architecture issues")
    
    def _analyze_code_quality_remaining(self) -> None:
        """Analyze remaining code quality issues"""
        
        python_files = list(self.project_root.rglob("*.py"))
        quality_issues = []
        
        for file_path in python_files[:40]:  # Focus on quality files
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                lines = content.split('\n')
                
                # Check for remaining print statements
                print_count = sum(1 for line in lines if re.match(r'^\s*print\s*\(', line))
                if print_count > 5:
                    quality_issues.append({
                        'file': str(file_path),
                        'type': 'Remaining Print Statements',
                        'count': print_count,
                        'severity': 'MEDIUM',
                        'recommendation': 'Convert to logging'
                    })
                
                # Check for TODO comments
                todo_count = sum(1 for line in lines if re.search(r'#\s*TODO', line, re.IGNORECASE))
                if todo_count > 10:
                    quality_issues.append({
                        'file': str(file_path),
                        'type': 'Excessive TODOs',
                        'count': todo_count,
                        'severity': 'MEDIUM',
                        'recommendation': 'Address or reduce TODOs'
                    })
                
                # Check for duplicate code patterns
                duplicate_patterns = [
                    r'def\s+\w+\s*\([^)]*\)\s*:\s*\n\s*"""[^"]*"""\s*\n\s*return\s+',
                    r'if\s+__name__\s*==\s*["\']__main__["\']',
                    r'try\s*:\s*\n\s+.*\s*\n\s*except\s+Exception\s+as\s+e:\s*\n\s+print'
                ]
                
                for pattern in duplicate_patterns:
                    matches = re.findall(pattern, content, re.MULTILINE)
                    if len(matches) > 3:
                        quality_issues.append({
                            'file': str(file_path),
                            'type': 'Duplicate Code Pattern',
                            'count': len(matches),
                            'severity': 'LOW',
                            'recommendation': 'Extract to function'
                        })
            
            except Exception as e:
                logger.error(f"Error analyzing {file_path}: {e}")
        
        self.remaining_issues.extend(quality_issues)
        logger.info(f"📝 Found {len(quality_issues)} code quality issues")
    
    def _analyze_production_readiness_gaps(self) -> None:
        """Analyze production readiness gaps"""
        
        production_gaps = []
        
        # Check for missing production files
        required_files = [
            'requirements.txt',
            '.env.example',
            'README.md',
            'LICENSE',
            'CHANGELOG.md',
            'CONTRIBUTING.md'
        ]
        
        for file_name in required_files:
            file_path = self.project_root / file_name
            if not file_path.exists():
                production_gaps.append({
                    'file': file_name,
                    'type': 'Missing Production File',
                    'severity': 'HIGH',
                    'recommendation': f'Create {file_name}'
                })
        
        # Check for testing infrastructure
        test_files = list(self.project_root.rglob("test_*.py")) + list(self.project_root.rglob("*_test.py"))
        if len(test_files) < 10:
            production_gaps.append({
                'file': 'test_infrastructure',
                'type': 'Insufficient Testing',
                'count': len(test_files),
                'severity': 'HIGH',
                'recommendation': 'Add comprehensive test suite'
            })
        
        # Check for monitoring configuration
        monitoring_files = ['prometheus.yml', 'grafana.ini', 'alertmanager.yml']
        for file_name in monitoring_files:
            file_path = self.project_root / file_name
            if not file_path.exists():
                production_gaps.append({
                    'file': file_name,
                    'type': 'Missing Monitoring Config',
                    'severity': 'MEDIUM',
                    'recommendation': f'Create {file_name}'
                })
        
        # Check for CI/CD configuration
        cicd_files = ['.github/workflows/main.yml', '.gitlab-ci.yml', 'Jenkinsfile']
        cicd_found = any((self.project_root / file).exists() for file in cicd_files)
        if not cicd_found:
            production_gaps.append({
                'file': 'CI/CD',
                'type': 'Missing CI/CD Pipeline',
                'severity': 'HIGH',
                'recommendation': 'Set up CI/CD pipeline'
            })
        
        # Check for documentation
        doc_files = list(self.project_root.rglob("*.md"))
        if len(doc_files) < 5:
            production_gaps.append({
                'file': 'documentation',
                'type': 'Insufficient Documentation',
                'count': len(doc_files),
                'severity': 'MEDIUM',
                'recommendation': 'Add comprehensive documentation'
            })
        
        self.remaining_issues.extend(production_gaps)
        logger.info(f"🏭 Found {len(production_gaps)} production readiness gaps")
    
    def _generate_remaining_analysis_report(self) -> Dict[str, Any]:
        """Generate comprehensive remaining analysis report"""
        
        # Categorize remaining issues
        issues_by_type = {}
        issues_by_severity = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        
        for issue in self.remaining_issues:
            issue_type = issue['type']
            if issue_type not in issues_by_type:
                issues_by_type[issue_type] = []
            issues_by_type[issue_type].append(issue)
            
            severity = issue.get('severity', 'MEDIUM')
            issues_by_severity[severity] += 1
        
        # Prioritize fixes for maximum impact
        prioritized_fixes = self._prioritize_fixes()
        
        # Calculate effort estimates
        effort_estimates = self._calculate_effort_estimates()
        
        # Generate report
        report = {
            'summary': {
                'total_remaining_issues': len(self.remaining_issues),
                'current_readiness': 75.0,
                'target_readiness': 95.0,
                'improvement_needed': 20.0,
                'timestamp': datetime.utcnow().isoformat()
            },
            'issues_by_type': {
                issue_type: len(issues) for issue_type, issues in issues_by_type.items()
            },
            'issues_by_severity': issues_by_severity,
            'prioritized_fixes': prioritized_fixes,
            'effort_estimates': effort_estimates,
            'detailed_issues': self.remaining_issues
        }
        
        # Save report
        with open(self.project_root / 'remaining_25_analysis_report.json', 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        # Print summary
        logger.info("\n🎯 REMAINING 25% ANALYSIS COMPLETE")
        logger.info("=" * 80)
        logger.info(f"📊 Total Remaining Issues: {len(self.remaining_issues)}")
        logger.info(f"🎯 Current Readiness: 75.0%")
        logger.info(f"🎯 Target Readiness: 95.0%")
        logger.info(f"📈 Improvement Needed: 20.0%")
        
        logger.info(f"\n📊 Issues by Type:")
        for issue_type, count in report['issues_by_type'].items():
            logger.info(f"   🔧 {issue_type}: {count}")
        
        logger.info(f"\n📊 Issues by Severity:")
        for severity, count in issues_by_severity.items():
            emoji = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢"}[severity]
            logger.info(f"   {emoji} {severity}: {count}")
        
        return report
    
    def _prioritize_fixes(self) -> List[Dict[str, Any]]:
        """Prioritize fixes for maximum impact on production readiness"""
        
        # Sort issues by severity and impact
        critical_issues = [i for i in self.remaining_issues if i.get('severity') == 'CRITICAL']
        high_issues = [i for i in self.remaining_issues if i.get('severity') == 'HIGH']
        medium_issues = [i for i in self.remaining_issues if i.get('severity') == 'MEDIUM']
        low_issues = [i for i in self.remaining_issues if i.get('severity') == 'LOW']
        
        prioritized = []
        
        # Phase 1: Critical Security (Immediate - 24 hours)
        prioritized.append({
            'phase': 1,
            'title': 'Critical Security Fixes',
            'timeline': '24 hours',
            'issues': critical_issues,
            'impact': 8,
            'effort': 'High'
        })
        
        # Phase 2: High Priority Issues (1 week)
        prioritized.append({
            'phase': 2,
            'title': 'High Priority Issues',
            'timeline': '1 week',
            'issues': high_issues,
            'impact': 6,
            'effort': 'Medium'
        })
        
        # Phase 3: Architecture Refactoring (2 weeks)
        architecture_high = [i for i in high_issues if 'God Class' in i.get('type', '') or 'Very Long Function' in i.get('type', '')]
        prioritized.append({
            'phase': 3,
            'title': 'Architecture Refactoring',
            'timeline': '2 weeks',
            'issues': architecture_high,
            'impact': 5,
            'effort': 'High'
        })
        
        # Phase 4: Performance Optimization (1 week)
        performance_high = [i for i in high_issues if 'Blocking' in i.get('type', '')]
        prioritized.append({
            'phase': 4,
            'title': 'Performance Optimization',
            'timeline': '1 week',
            'issues': performance_high,
            'impact': 4,
            'effort': 'Medium'
        })
        
        # Phase 5: Production Infrastructure (1 week)
        production_high = [i for i in high_issues if 'Missing' in i.get('type', '')]
        prioritized.append({
            'phase': 5,
            'title': 'Production Infrastructure',
            'timeline': '1 week',
            'issues': production_high,
            'impact': 7,
            'effort': 'Medium'
        })
        
        # Phase 6: Code Quality Polish (1 week)
        prioritized.append({
            'phase': 6,
            'title': 'Code Quality Polish',
            'timeline': '1 week',
            'issues': medium_issues[:20],  # Top 20 medium issues
            'impact': 3,
            'effort': 'Low'
        })
        
        return prioritized
    
    def _calculate_effort_estimates(self) -> Dict[str, Any]:
        """Calculate effort estimates for remaining fixes"""
        
        effort_by_type = {}
        total_hours = 0
        
        for issue in self.remaining_issues:
            issue_type = issue['type']
            severity = issue.get('severity', 'MEDIUM')
            
            # Estimate hours per issue
            if severity == 'CRITICAL':
                hours_per_issue = 4
            elif severity == 'HIGH':
                hours_per_issue = 2
            elif severity == 'MEDIUM':
                hours_per_issue = 1
            else:
                hours_per_issue = 0.5
            
            if issue_type not in effort_by_type:
                effort_by_type[issue_type] = 0
            effort_by_type[issue_type] += hours_per_issue
            total_hours += hours_per_issue
        
        return {
            'total_hours': total_hours,
            'total_days': total_hours / 8,
            'effort_by_type': effort_by_type,
            'team_size_needed': max(2, min(5, total_hours / 160))  # 2-5 developers
        }

def main():
    """Main analysis function"""
    project_root = "/Users/theowolfenden/CascadeProjects/Terradev"
    
    analyzer = RemainingIssuesAnalyzer(project_root)
    results = analyzer.analyze_remaining_issues()
    
    return results

if __name__ == "__main__":
    main()
