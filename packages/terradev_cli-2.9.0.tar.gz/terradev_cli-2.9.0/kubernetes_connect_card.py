#!/usr/bin/env python3
"""
Kubernetes Training Connect Card
Simple connection and deployment interface for Kubernetes training
"""

import asyncio
import json
import logging
import os
import subprocess
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass
from pathlib import Path
import yaml

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class KubernetesConnectCard:
    """Simple Kubernetes connection and deployment interface"""
    
    def __init__(self):
        self.kubeconfig_path = os.path.expanduser("~/.kube/config")
        self.namespace = "training"
        self.connected = False
        self.cluster_info = {}
        self.available_nodes = []
        self.gpu_nodes = []
        
    def check_prerequisites(self) -> Dict[str, bool]:
        """Check if prerequisites are installed"""
        
        checks = {
            "kubectl": self._check_command("kubectl"),
            "helm": self._check_command("helm"),
            "docker": self._check_command("docker"),
            "kubeconfig": self._check_kubeconfig(),
            "cluster_access": self._check_cluster_access()
        }
        
        return checks
    
    def _check_command(self, command: str) -> bool:
        """Check if command is available"""
        try:
            # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            return False
    
    def _check_kubeconfig(self) -> bool:
        """Check if kubeconfig exists"""
        return os.path.exists(self.kubeconfig_path)
    
    def _check_cluster_access(self) -> bool:
        """Check if cluster is accessible"""
        try:
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            return result.returncode == 0
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            return False
    
    def connect_to_cluster(self) -> Dict[str, str]:
        """Connect to Kubernetes cluster and get basic info"""
        
        if not self.check_prerequisites()["cluster_access"]:
            return {"error": "Cannot connect to cluster. Check prerequisites."}
        
        try:
            # Get cluster info
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            if result.returncode == 0:
                self.connected = True
                self.cluster_info = {
                    "status": "connected",
                    "timestamp": datetime.now().isoformat(),
                    "cluster_info": result.stdout
                }
                
                # Get nodes
                self._get_nodes()
                
                return self.cluster_info
            else:
                return {"error": result.stderr}
                
        except Exception as e:
            return {"error": f"Connection failed: {e}"}
    
    def _get_nodes(self):
        """Get available nodes"""
        try:
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                self.available_nodes = []
                self.gpu_nodes = []
                
                for item in data.get("items", []):
                    node_info = {
                        "name": item.get("metadata", {}).get("name", ""),
                        "status": item.get("status", {}).get("phase", ""),
                        "roles": self._get_node_roles(item),
                        "version": item.get("status", {}).get("nodeInfo", {}).get("kubeletVersion", ""),
                        "os": item.get("status", {}).get("nodeInfo", {}).get("osImage", ""),
                        "kernel": item.get("status", {}).get("nodeInfo", {}).get("kernelVersion", ""),
                        "container_runtime": item.get("status", {}).get("nodeInfo", {}).get("containerRuntimeVersion", ""),
                        "cpu": item.get("status", {}).get("capacity", {}).get("cpu", ""),
                        "memory": item.get("status", {}).get("capacity", {}).get("memory", ""),
                        "storage": item.get("status", {}).get("capacity", {}).get("ephemeral-storage", ""),
                        "gpu": self._get_gpu_info(item),
                        "labels": item.get("metadata", {}).get("labels", {}),
                        "conditions": self._get_node_conditions(item)
                    }
                    
                    self.available_nodes.append(node_info)
                    
                    if node_info["gpu"]["count"] > 0:
                        self.gpu_nodes.append(node_info)
                
        except Exception as e:
            logger.error(f"Error getting nodes: {e}")
    
    def _get_node_roles(self, node_data: Dict) -> List[str]:
        """Get node roles from labels"""
        labels = node_data.get("metadata", {}).get("labels", {})
        roles = []
        
        if "node-role.kubernetes.io/master" in labels:
            roles.append("master")
        if "node-role.kubernetes.io/control-plane" in labels:
            roles.append("control-plane")
        if "node-role.kubernetes.io/worker" in labels:
            roles.append("worker")
        
        return roles if roles else ["worker"]
    
    def _get_gpu_info(self, node_data: Dict) -> Dict:
        """Get GPU information from node"""
        capacity = node_data.get("status", {}).get("capacity", {})
        labels = node_data.get("metadata", {}).get("labels", {})
        
        gpu_info = {
            "count": 0,
            "type": "none",
            "memory": "0"
        }
        
        # Check for nvidia.com/gpu
        if "nvidia.com/gpu" in capacity:
            gpu_info["count"] = int(capacity["nvidia.com/gpu"])
            gpu_info["type"] = "nvidia"
        
        # Check for GPU labels
        if "accelerator" in labels:
            gpu_info["type"] = labels["accelerator"]
        
        # Check for GPU memory
        if "nvidia.com/gpu.memory" in capacity:
            gpu_info["memory"] = capacity["nvidia.com/gpu.memory"]
        
        return gpu_info
    
    def _get_node_conditions(self, node_data: Dict) -> Dict:
        """Get node conditions"""
        conditions = {}
        for condition in node_data.get("status", {}).get("conditions", []):
            conditions[condition.get("type", "")] = condition.get("status", "")
        
        return conditions
    
    def deploy_training_job(self, job_config: Dict) -> Dict:
        """Deploy a simple training job"""
        
        if not self.connected:
            return {"error": "Not connected to cluster"}
        
        try:
            # Create namespace if it doesn't exist
            # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            # Generate job manifest
            job_manifest = self._generate_simple_job_manifest(job_config)
            
            # Write to temporary file
            temp_file = f"/tmp/training-job-{job_config.get('name', 'job')}.yaml"
            with open(temp_file, 'w') as f:
                f.write(job_manifest)
            
            # Apply to cluster
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            # Clean up
            os.remove(temp_file)
            
            if result.returncode == 0:
                return {
                    "status": "deployed",
                    "job_name": job_config.get("name"),
                    "namespace": self.namespace,
                    "output": result.stdout
                }
            else:
                return {"error": result.stderr}
                
        except Exception as e:
            return {"error": f"Deployment failed: {e}"}
    
    def _generate_simple_job_manifest(self, job_config: Dict) -> str:
        """Generate simple Kubernetes job manifest"""
        
        manifest = {
            "apiVersion": "batch/v1",
            "kind": "Job",
            "metadata": {
                "name": job_config.get("name", "training-job"),
                "namespace": self.namespace,
                "labels": {
                    "app": "training",
                    "job-type": job_config.get("type", "ml-training")
                }
            },
            "spec": {
                "template": {
                    "spec": {
                        "restartPolicy": "OnFailure",
                        "containers": [{
                            "name": job_config.get("name", "training-container"),
                            "image": job_config.get("image", "python:3.9"),
                            "command": job_config.get("command", ["python", "train.py"]),
                            "env": [{"name": k, "value": v} for k, v in job_config.get("env", {}).items()],
                            "resources": {
                                "requests": {
                                    "cpu": job_config.get("cpu", "2"),
                                    "memory": job_config.get("memory", "4Gi")
                                },
                                "limits": {
                                    "cpu": job_config.get("cpu_limit", "4"),
                                    "memory": job_config.get("memory_limit", "8Gi")
                                }
                            }
                        }],
                        "nodeSelector": job_config.get("node_selector", {}),
                        "tolerations": job_config.get("tolerations", [])
                    }
                },
                "ttlSecondsAfterFinished": job_config.get("ttl", 3600)
            }
        }
        
        # Add GPU resources if requested
        if job_config.get("gpu", 0) > 0:
            manifest["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["nvidia.com/gpu"] = str(job_config.get("gpu"))
            manifest["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["nvidia.com/gpu"] = str(job_config.get("gpu"))
        
        return yaml.dump(manifest, default_flow_style=False)
    
    def get_job_status(self, job_name: str) -> Dict:
        """Get job status"""
        
        if not self.connected:
            return {"error": "Not connected to cluster"}
        
        try:
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                return {
                    "status": "success",
                    "job_data": data
                }
            else:
                return {"error": result.stderr}
                
        except Exception as e:
            return {"error": f"Failed to get job status: {e}"}
    
    def get_pod_logs(self, pod_name: str, tail_lines: int = 50) -> str:
        """Get pod logs"""
        
        if not self.connected:
            return "Not connected to cluster"
        
        try:
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)],
                capture_output=True,
                text=True,
                timeout=30,
                env={"KUBECONFIG": self.kubeconfig_path}
            )
            
            return result.stdout if result.returncode == 0 else result.stderr
            
        except Exception as e:
            return f"Failed to get logs: {e}"
    
    def cleanup_job(self, job_name: str) -> Dict:
        """Clean up job"""
        
        if not self.connected:
            return {"error": "Not connected to cluster"}
        
        try:
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            if result.returncode == 0:
                return {"status": "deleted", "output": result.stdout}
            else:
                return {"error": result.stderr}
                
        except Exception as e:
            return {"error": f"Cleanup failed: {e}"}
    
    def get_connection_summary(self) -> Dict:
        """Get connection summary"""
        
        return {
            "connected": self.connected,
            "cluster_info": self.cluster_info,
            "total_nodes": len(self.available_nodes),
            "gpu_nodes": len(self.gpu_nodes),
            "namespace": self.namespace,
            "prerequisites": self.check_prerequisites(),
            "available_nodes": self.available_nodes,
            "gpu_nodes": self.gpu_nodes
        }

# Test the connect card
# TODO: REFACTOR - test_connect_card() is 86 lines long (should be <50)
# Consider breaking into smaller, focused functions
def test_connect_card():
    """Test the Kubernetes connect card"""
    
    logging.info("🚀 Testing Kubernetes Connect Card")
    logging.info("=" * 50)
    
    card = KubernetesConnectCard()
    
    # Test prerequisites
    logging.info("\n🔍 Checking prerequisites...")
    prereqs = card.check_prerequisites()
    
    for tool, status in prereqs.items():
        status_icon = "✅" if status else "❌"
        logging.info(f"   {status_icon} {tool}")
    
    # Test connection
    logging.info(f"\n🔌 Connecting to cluster...")
    connection = card.connect_to_cluster()
    
    if "error" in connection:
        logging.info(f"❌ Connection failed: {connection['error']}")
        return
    
    logging.info("✅ Connected to cluster!")
    
    # Show cluster summary
    summary = card.get_connection_summary()
    logging.info(f"\n📊 Cluster Summary:")
    logging.info(f"   Total Nodes: {summary['total_nodes']}")
    logging.info(f"   GPU Nodes: {summary['gpu_nodes']}")
    logging.info(f"   Namespace: {summary['namespace']}")
    
    # Show GPU nodes
    if summary['gpu_nodes']:
        logging.info(f"\n🖥️  GPU Nodes:")
        for node in summary['gpu_nodes']:
            logging.info(f"   • {node['name']}")
            logging.info(f"     GPU: {node['gpu']['type']} x{node['gpu']['count']}")
            logging.info(f"     CPU: {node['cpu']}")
            logging.info(f"     Memory: {node['memory']}")
            logging.info(f"     Status: {node['status']}")
    
    # Test job deployment
    logging.info(f"\n🚀 Testing job deployment...")
    job_config = {
        "name": "test-training-job",
        "image": "python:3.9",
        "command": ["python", "-c", "print('Hello Kubernetes Training!')"],
        "env": {"JOB_NAME": "test-training-job"},
        "cpu": "1",
        "memory": "2Gi",
        "gpu": 0,  # No GPU for test
        "ttl": 300
    }
    
    deployment = card.deploy_training_job(job_config)
    
    if "error" in deployment:
        logging.info(f"❌ Deployment failed: {deployment['error']}")
    else:
        logging.info(f"✅ Job deployed: {deployment['job_name']}")
        
        # Wait a bit and check status
        import time
        # TODO: PERFORMANCE - Consider async/await for blocking sleep
# time.sleep(5)
        
        status = card.get_job_status("test-training-job")
        if "error" in status:
            logging.info(f"❌ Status check failed: {status['error']}")
        else:
            logging.info(f"✅ Job status retrieved")
        
        # Clean up
        cleanup = card.cleanup_job("test-training-job")
        if "error" in cleanup:
            logging.info(f"❌ Cleanup failed: {cleanup['error']}")
        else:
            logging.info(f"✅ Job cleaned up")
    
    logging.info(f"\n🎯 Connect Card Test Completed!")
    logging.info("✅ Prerequisites check working")
    logging.info("✅ Cluster connection working")
    logging.info("✅ Node discovery working")
    logging.info("✅ Job deployment working")
    logging.info("✅ Job monitoring working")
    logging.info("✅ Job cleanup working")

if __name__ == "__main__":
    test_connect_card()
