#!/bin/bash
# User data script for ML training instances

set -e

# Configuration
TRAINING_SCRIPT="/opt/training-script.py"
DATASET_URL="${dataset_url}"
MODEL_TYPE="${model_type}"
S3_BUCKET="${s3_bucket}"
TRAINING_SCRIPT_BASE64="${training_script}"

# Logging
LOG_FILE="/var/log/training-setup.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "Starting ML training instance setup..."
echo "Model Type: $MODEL_TYPE"
echo "Dataset URL: $DATASET_URL"
echo "S3 Bucket: $S3_BUCKET"

# Update system packages
echo "Updating system packages..."
yum update -y

# Install additional packages
echo "Installing additional packages..."
yum install -y git htop screen tmux

# Create directories
echo "Creating directories..."
mkdir -p /opt/training
mkdir -p /data/datasets
mkdir -p /data/models
mkdir -p /data/logs
mkdir -p /data/checkpoints

# Mount EFS if available
if [ -n "${efs_filesystem_id}" ]; then
    echo "Mounting EFS filesystem..."
    yum install -y amazon-efs-utils
    mkdir -p /mnt/efs
    echo "${efs_filesystem_id}:/ /mnt/efs efs defaults,_netdev 0 0" >> /etc/fstab
    mount -a -t efs
    mkdir -p /mnt/efs/training
    mkdir -p /mnt/efs/datasets
    mkdir -p /mnt/efs/models
fi

# Setup Python environment
echo "Setting up Python environment..."
cd /opt/training

# Create virtual environment
python3 -m venv training_env
source training_env/bin/activate

# Install ML libraries based on model type
echo "Installing ML libraries for $MODEL_TYPE..."

if [ "$MODEL_TYPE" = "image-classification" ]; then
    pip install tensorflow==2.13.0
    pip install keras==2.13.1
    pip install opencv-python==4.8.0.76
    pip install pillow==10.0.0
    pip install scikit-learn==1.3.0
    pip install matplotlib==3.7.2
    pip install pandas==2.0.3
elif [ "$MODEL_TYPE" = "nlp" ]; then
    pip install transformers==4.33.2
    pip install torch==2.0.1
    pip install datasets==2.14.4
    pip install tokenizers==0.13.3
    pip install scikit-learn==1.3.0
    pip install matplotlib==3.7.2
elif [ "$MODEL_TYPE" = "reinforcement-learning" ]; then
    pip install gymnasium==0.28.1
    pip install stable-baselines3==2.1.0
    pip install torch==2.0.1
    pip install numpy==1.24.3
    pip install matplotlib==3.7.2
elif [ "$MODEL_TYPE" = "time-series" ]; then
    pip install tensorflow==2.13.0
    pip install statsmodels==0.14.0
    pip install scikit-learn==1.3.0
    pip install pandas==2.0.3
    pip install matplotlib==3.7.2
else
    # Default ML stack
    pip install tensorflow==2.13.0
    pip install scikit-learn==1.3.0
    pip install pandas==2.0.3
    pip install matplotlib==3.7.2
fi

# Install monitoring tools
echo "Installing monitoring tools..."
pip install psutil==5.9.5
pip install gpustat==1.1.1

# Setup AWS CLI
echo "Setting up AWS CLI..."
pip install awscli==1.29.57

# Create training script
echo "Creating training script..."
echo "$TRAINING_SCRIPT_BASE64" | base64 -d > "$TRAINING_SCRIPT"
chmod +x "$TRAINING_SCRIPT"

# Download dataset
echo "Downloading dataset from $DATASET_URL..."
cd /data/datasets

if [[ "$DATASET_URL" == *.zip ]]; then
    wget -O dataset.zip "$DATASET_URL"
    unzip dataset.zip
    rm dataset.zip
elif [[ "$DATASET_URL" == *.tar.gz ]]; then
    wget -O dataset.tar.gz "$DATASET_URL"
    tar -xzf dataset.tar.gz
    rm dataset.tar.gz
else
    wget -O dataset "$DATASET_URL"
fi

# Sync dataset to S3
echo "Syncing dataset to S3..."
aws s3 sync /data/datasets/ "s3://$S3_BUCKET/datasets/"

# Setup TensorBoard if enabled
if [ "$enable_tensorboard" = "true" ]; then
    echo "Setting up TensorBoard..."
    pip install tensorboard==2.13.0
    
    # Create TensorBoard service
    cat > /etc/systemd/system/tensorboard.service << EOF
[Unit]
Description=TensorBoard
After=network.target

[Service]
Type=simple
User=ec2-user
WorkingDirectory=/opt/training
Environment=PATH=/opt/training/training_env/bin
ExecStart=/opt/training/training_env/bin/tensorboard --logdir=/data/logs --host=0.0.0.0 --port=6006
Restart=always

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable tensorboard
    systemctl start tensorboard
fi

# Setup monitoring script
echo "Setting up monitoring script..."
cat > /opt/monitor-training.sh << 'EOF'
#!/bin/bash
# Monitoring script for ML training

LOG_FILE="/var/log/training-monitor.log"
METRICS_FILE="/data/metrics.json"

while true; do
    TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    
    # Get GPU metrics
    GPU_METRICS=$(nvidia-smi --query-gpu=utilization.gpu,utilization.memory,temperature.gpu --format=csv,noheader,nounits 2>/dev/null || echo "0,0,0")
    
    # Get system metrics
    CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
    MEMORY_USAGE=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100.0}')
    
    # Get disk usage
    DISK_USAGE=$(df /data | tail -1 | awk '{print $5}' | cut -d'%' -f1)
    
    # Create metrics JSON
    cat > "$METRICS_FILE" << METRICS_EOF
{
    "timestamp": "$TIMESTAMP",
    "gpu_utilization": $(echo $GPU_METRICS | cut -d',' -f1),
    "gpu_memory_utilization": $(echo $GPU_METRICS | cut -d',' -f2),
    "gpu_temperature": $(echo $GPU_METRICS | cut -d',' -f3),
    "cpu_usage": $CPU_USAGE,
    "memory_usage": $MEMORY_USAGE,
    "disk_usage": $DISK_USAGE
}
METRICS_EOF
    
    # Log metrics
    echo "[$TIMESTAMP] GPU: $(echo $GPU_METRICS | cut -d',' -f1)% CPU: ${CPU_USAGE}% MEM: ${MEMORY_USAGE}% DISK: ${DISK_USAGE}%" >> "$LOG_FILE"
    
    sleep 60
done
EOF

chmod +x /opt/monitor-training.sh

# Create monitoring service
cat > /etc/systemd/system/training-monitor.service << EOF
[Unit]
Description=Training Monitor
After=network.target

[Service]
Type=simple
User=root
ExecStart=/opt/monitor-training.sh
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable training-monitor
systemctl start training-monitor

# Setup automatic backup to S3
echo "Setting up automatic backup..."
cat > /opt/backup-to-s3.sh << 'EOF'
#!/bin/bash
# Backup script for training artifacts

S3_BUCKET="$1"
BACKUP_DIR="/data"

# Backup models
if [ -d "$BACKUP_DIR/models" ] && [ "$(ls -A $BACKUP_DIR/models)" ]; then
    echo "Backing up models to S3..."
    aws s3 sync "$BACKUP_DIR/models/" "s3://$S3_BUCKET/models/" --exclude "*" --include "*.h5" --include "*.pth" --include "*.pkl"
fi

# Backup checkpoints
if [ -d "$BACKUP_DIR/checkpoints" ] && [ "$(ls -A $BACKUP_DIR/checkpoints)" ]; then
    echo "Backing up checkpoints to S3..."
    aws s3 sync "$BACKUP_DIR/checkpoints/" "s3://$S3_BUCKET/checkpoints/"
fi

# Backup logs
if [ -d "$BACKUP_DIR/logs" ] && [ "$(ls -A $BACKUP_DIR/logs)" ]; then
    echo "Backing up logs to S3..."
    aws s3 sync "$BACKUP_DIR/logs/" "s3://$S3_BUCKET/logs/"
fi

echo "Backup completed at $(date)"
EOF

chmod +x /opt/backup-to-s3.sh

# Create cron job for backup
echo "0 */6 * * * /opt/backup-to-s3.sh $S3_BUCKET" | crontab -

# Start training
echo "Starting training..."
cd /opt/training
source training_env/bin/activate

# Run training script
python "$TRAINING_SCRIPT" \
    --dataset-path /data/datasets \
    --output-path /data/models \
    --log-path /data/logs \
    --checkpoint-path /data/checkpoints \
    --model-type "$MODEL_TYPE" \
    --s3-bucket "$S3_BUCKET"

echo "Training completed!"

# Final backup
echo "Running final backup..."
/opt/backup-to-s3.sh "$S3_BUCKET"

# Send completion notification
if [ -n "$notification_email" ]; then
    echo "Training job completed successfully on $(hostname)" | mail -s "ML Training Completed: $MODEL_TYPE" "$notification_email"
fi

echo "Setup completed successfully!"
echo "Instance is ready for ML training."
echo "TensorBoard URL: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):6006"
