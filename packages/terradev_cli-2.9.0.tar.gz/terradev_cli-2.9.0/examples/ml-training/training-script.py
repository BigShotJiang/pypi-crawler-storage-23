#!/usr/bin/env python3
"""
ML Training Script Template

This is a template training script that can be customized for different
machine learning tasks. It supports various model types and includes
features like checkpointing, logging, and cloud integration.
"""

import argparse
import json
import os
import sys
import time
import logging
from datetime import datetime
from pathlib import Path

# ML imports (will be installed based on model type)
try:
    import tensorflow as tf
    from tensorflow import keras
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import numpy as np
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, classification_report
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

import boto3
import matplotlib.pyplot as plt

# TODO: Consider refactoring MLTrainer - 22 methods (God Class)
# TODO: REFACTOR GOD CLASS - MLTrainer has 22 methods (>20)
# Consider splitting into smaller, focused classes
# Apply Single Responsibility Principle
class MLTrainer:
    """Generic ML training class."""
    
    def __init__(self, args):
        self.args = args
        self.model_type = args.model_type
        self.dataset_path = Path(args.dataset_path)
        self.output_path = Path(args.output_path)
        self.log_path = Path(args.log_path)
        self.checkpoint_path = Path(args.checkpoint_path)
        
        # Create directories
        self.output_path.mkdir(parents=True, exist_ok=True)
        self.log_path.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        self.setup_logging()
        
        # Setup S3 client
        self.s3_client = boto3.client('s3') if args.s3_bucket else None
        
        # Training state
        self.model = None
        self.history = {'loss': [], 'accuracy': [], 'val_loss': [], 'val_accuracy': []}
        self.epoch = 0
        self.best_val_loss = float('inf')
        
    def setup_logging(self):
        """Setup logging configuration."""
        log_file = self.log_path / f"training_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Starting ML training for {self.model_type}")
        self.logger.info(f"Dataset path: {self.dataset_path}")
        self.logger.info(f"Output path: {self.output_path}")
    
    def load_data(self):
        """Load and preprocess data based on model type."""
        self.logger.info("Loading and preprocessing data...")
        
        if self.model_type == "image-classification":
            return self.load_image_data()
        elif self.model_type == "nlp":
            return self.load_text_data()
        elif self.model_type == "reinforcement-learning":
            return self.load_rl_data()
        elif self.model_type == "time-series":
            return self.load_time_series_data()
        else:
            raise ValueError(f"Unsupported model type: {self.model_type}")
    
# TODO: REFACTOR - load_image_data() is 54 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def load_image_data(self):
        """Load image classification data."""
        if not TF_AVAILABLE:
            raise ImportError("TensorFlow is required for image classification")
        
        # Look for common image dataset structures
        data_dir = self.dataset_path
        
        # Try to find train/validation splits
        train_dir = data_dir / "train"
        val_dir = data_dir / "val"
        
        if train_dir.exists() and val_dir.exists():
            # Use existing splits
            train_dataset = tf.keras.utils.image_dataset_from_directory(
                train_dir,
                image_size=(224, 224),
                batch_size=32,
                label_mode='categorical'
            )
            
            val_dataset = tf.keras.utils.image_dataset_from_directory(
                val_dir,
                image_size=(224, 224),
                batch_size=32,
                label_mode='categorical'
            )
        else:
            # Create splits from single directory
            dataset = tf.keras.utils.image_dataset_from_directory(
                data_dir,
                image_size=(224, 224),
                batch_size=32,
                label_mode='categorical',
                validation_split=0.2,
                subset='training',
                seed=42
            )
            
            val_dataset = tf.keras.utils.image_dataset_from_directory(
                data_dir,
                image_size=(224, 224),
                batch_size=32,
                label_mode='categorical',
                validation_split=0.2,
                subset='validation',
                seed=42
            )
        
        # Optimize datasets
        AUTOTUNE = tf.data.AUTOTUNE
        train_dataset = train_dataset.cache().shuffle(1000).prefetch(buffer_size=AUTOTUNE)
        val_dataset = val_dataset.cache().prefetch(buffer_size=AUTOTUNE)
        
        return train_dataset, val_dataset
    
    def load_text_data(self):
        """Load NLP data."""
        # Placeholder for text data loading
        # This would typically involve loading CSV/JSON files and tokenization
        self.logger.info("Loading text data (placeholder implementation)")
        
        # Create dummy data for demonstration
        texts = ["sample text 1", "sample text 2"] * 100
        labels = [0, 1] * 100
        
        return texts, labels
    
    def load_rl_data(self):
        """Load reinforcement learning environment."""
        # Placeholder for RL environment setup
        self.logger.info("Setting up RL environment")
        
        try:
            import gymnasium as gym
            env = gym.make('CartPole-v1')
            return env
        except ImportError:
            raise ImportError("Gymnasium is required for reinforcement learning")
    
    def load_time_series_data(self):
        """Load time series data."""
        # Look for CSV files
        csv_files = list(self.dataset_path.glob("*.csv"))
        
        if not csv_files:
            raise FileNotFoundError("No CSV files found for time series data")
        
        data_file = csv_files[0]
        df = pd.read_csv(data_file)
        
        self.logger.info(f"Loaded time series data from {data_file}")
        self.logger.info(f"Data shape: {df.shape}")
        
        return df
    
    def build_model(self):
        """Build model based on model type."""
        self.logger.info(f"Building {self.model_type} model...")
        
        if self.model_type == "image-classification":
            return self.build_image_classifier()
        elif self.model_type == "nlp":
            return self.build_nlp_model()
        elif self.model_type == "reinforcement-learning":
            return self.build_rl_model()
        elif self.model_type == "time-series":
            return self.build_time_series_model()
        else:
            raise ValueError(f"Unsupported model type: {self.model_type}")
    
    def build_image_classifier(self):
        """Build image classification model."""
        if not TF_AVAILABLE:
            raise ImportError("TensorFlow is required for image classification")
        
        # Use a pre-trained model with transfer learning
        base_model = tf.keras.applications.ResNet50(
            weights='imagenet',
            include_top=False,
            input_shape=(224, 224, 3)
        )
        
        # Freeze the base model
        base_model.trainable = False
        
        # Add custom layers
        model = tf.keras.Sequential([
            base_model,
            tf.keras.layers.GlobalAveragePooling2D(),
            tf.keras.layers.Dense(128, activation='relu'),
            tf.keras.layers.Dropout(0.2),
            tf.keras.layers.Dense(10, activation='softmax')  # Assuming 10 classes
        ])
        
        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def build_nlp_model(self):
        """Build NLP model."""
        # Placeholder for NLP model
        self.logger.info("Building NLP model (placeholder)")
        
        if TF_AVAILABLE:
            # Simple text classification model
            model = tf.keras.Sequential([
                tf.keras.layers.Embedding(10000, 16),
                tf.keras.layers.GlobalAveragePooling1D(),
                tf.keras.layers.Dense(16, activation='relu'),
                tf.keras.layers.Dense(1, activation='sigmoid')
            ])
            
            model.compile(
                optimizer='adam',
                loss='binary_crossentropy',
                metrics=['accuracy']
            )
            
            return model
        else:
            raise ImportError("TensorFlow is required for NLP model")
    
    def build_rl_model(self):
        """Build reinforcement learning model."""
        # Placeholder for RL model
        self.logger.info("Building RL model (placeholder)")
        return None
    
    def build_time_series_model(self):
        """Build time series model."""
        if not TF_AVAILABLE:
            raise ImportError("TensorFlow is required for time series model")
        
        # Simple LSTM model for time series
        model = tf.keras.Sequential([
            tf.keras.layers.LSTM(50, return_sequences=True, input_shape=(None, 1)),
            tf.keras.layers.LSTM(50),
            tf.keras.layers.Dense(1)
        ])
        
        model.compile(
            optimizer='adam',
            loss='mse',
            metrics=['mae']
        )
        
        return model
    
    def train(self):
        """Main training loop."""
        self.logger.info("Starting training...")
        
        # Load data
        data = self.load_data()
        
        # Build model
        self.model = self.build_model()
        
        if self.model:
            self.logger.info(f"Model built with {self.model.count_params():,} parameters")
        
        # Train based on model type
        if self.model_type == "image-classification":
            self.train_image_classifier(data)
        elif self.model_type == "nlp":
            self.train_nlp_model(data)
        elif self.model_type == "reinforcement-learning":
            self.train_rl_model(data)
        elif self.model_type == "time-series":
            self.train_time_series_model(data)
        
        self.logger.info("Training completed!")
    
    def train_image_classifier(self, data):
        """Train image classifier."""
        train_dataset, val_dataset = data
        
        # Callbacks
        callbacks = [
            tf.keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True),
            tf.keras.callbacks.ReduceLROnPlateau(factor=0.1, patience=5),
            self.create_checkpoint_callback(),
            self.create_tensorboard_callback()
        ]
        
        # Train
        history = self.model.fit(
            train_dataset,
            validation_data=val_dataset,
            epochs=100,
            callbacks=callbacks
        )
        
        self.history = history.history
        self.save_model()
        self.plot_training_history()
    
    def train_nlp_model(self, data):
        """Train NLP model."""
        # Placeholder for NLP training
        self.logger.info("Training NLP model (placeholder)")
    
    def train_rl_model(self, data):
        """Train reinforcement learning model."""
        # Placeholder for RL training
        self.logger.info("Training RL model (placeholder)")
    
    def train_time_series_model(self, data):
        """Train time series model."""
        # Placeholder for time series training
        self.logger.info("Training time series model (placeholder)")
    
    def create_checkpoint_callback(self):
        """Create model checkpoint callback."""
        return tf.keras.callbacks.ModelCheckpoint(
            filepath=str(self.checkpoint_path / "model_{epoch:02d}_{val_loss:.2f}.h5"),
            save_best_only=True,
            monitor='val_loss',
            mode='min'
        )
    
    def create_tensorboard_callback(self):
        """Create TensorBoard callback."""
        return tf.keras.callbacks.TensorBoard(
            log_dir=str(self.log_path / "tensorboard"),
            histogram_freq=1
        )
    
    def save_model(self):
        """Save the trained model."""
        if self.model:
            model_path = self.output_path / f"model_{self.model_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            if TF_AVAILABLE and hasattr(self.model, 'save'):
                self.model.save(model_path)
                self.logger.info(f"Model saved to {model_path}")
                
                # Save to S3 if bucket provided
                if self.s3_client:
                    self.save_to_s3(model_path)
            else:
                self.logger.warning("Model saving not implemented for this framework")
    
    def save_to_s3(self, local_path):
        """Save model to S3."""
        try:
            s3_prefix = f"models/{self.model_type}/{local_path.name}"
            
            # Upload model files
            for file_path in local_path.rglob('*'):
                if file_path.is_file():
                    s3_key = f"{s3_prefix}/{file_path.relative_to(local_path)}"
                    self.s3_client.upload_file(str(file_path), self.args.s3_bucket, s3_key)
            
            self.logger.info(f"Model uploaded to s3://{self.args.s3_bucket}/{s3_prefix}")
        except Exception as e:
            self.logger.error(f"Failed to upload model to S3: {e}")
    
    def plot_training_history(self):
        """Plot and save training history."""
        if not self.history:
            return
        
        # Plot training history
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        
        # Loss plot
        ax1.plot(self.history['loss'], label='Training Loss')
        if 'val_loss' in self.history:
            ax1.plot(self.history['val_loss'], label='Validation Loss')
        ax1.set_title('Model Loss')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Loss')
        ax1.legend()
        
        # Accuracy plot
        if 'accuracy' in self.history:
            ax2.plot(self.history['accuracy'], label='Training Accuracy')
        if 'val_accuracy' in self.history:
            ax2.plot(self.history['val_accuracy'], label='Validation Accuracy')
        ax2.set_title('Model Accuracy')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Accuracy')
        ax2.legend()
        
        plt.tight_layout()
        
        # Save plot
        plot_path = self.output_path / f"training_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        plt.savefig(plot_path)
        self.logger.info(f"Training history plot saved to {plot_path}")
        
        # Upload to S3 if available
        if self.s3_client:
            try:
                s3_key = f"logs/{plot_path.name}"
                self.s3_client.upload_file(str(plot_path), self.args.s3_bucket, s3_key)
            except Exception as e:
                self.logger.error(f"Failed to upload plot to S3: {e}")

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="ML Training Script")
    
    parser.add_argument("--dataset-path", required=True, help="Path to training dataset")
    parser.add_argument("--output-path", required=True, help="Path to save model outputs")
    parser.add_argument("--log-path", required=True, help="Path to save logs")
    parser.add_argument("--checkpoint-path", required=True, help="Path to save checkpoints")
    parser.add_argument("--model-type", required=True, 
                       choices=["image-classification", "nlp", "reinforcement-learning", "time-series"],
                       help="Type of model to train")
    parser.add_argument("--s3-bucket", help="S3 bucket for backup")
    parser.add_argument("--epochs", type=int, default=100, help="Number of training epochs")
    parser.add_argument("--batch-size", type=int, default=32, help="Batch size")
    parser.add_argument("--learning-rate", type=float, default=0.001, help="Learning rate")
    
    args = parser.parse_args()
    
    # Create trainer and start training
    trainer = MLTrainer(args)
    trainer.train()

if __name__ == "__main__":
    main()
