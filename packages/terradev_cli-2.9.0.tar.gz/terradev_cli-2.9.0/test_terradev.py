import logging

#!/usr/bin/env python3
"""
Example usage and test script for Terradev SkyPilot Wrapper
"""

import asyncio
import json
from datetime import datetime
from terradev_wrapper import TerradevWrapper

async def test_smart_launch():
    """Test smart launch with derivative analysis"""
    
    wrapper = TerradevWrapper()
    
    # Example task YAML (simplified)
    task_yaml = """
resources:
  accelerators: A100:1
  cloud: any  # Let SkyPilot decide
  instance_type: any
  
setup: |
  echo "Setting up ML environment"
  pip install torch torchvision
  
run: |
  echo "Running ML training"
  python train.py --epochs 10
"""
    
    logging.info("🚀 Testing Terradev Smart Launch")
    logging.info("=" * 50)
    
    # Test deployment with team attribution
    result = await wrapper.smart_launch(
        task_yaml=task_yaml,
        team_id="ml-team",
        project_id="image-classification",
        user_id="alice@company.com",
        latency_threshold=500.0
    )
    
    logging.info("📊 Deployment Result:")
    # Convert datetime objects to strings for JSON serialization
    def json_serialize(obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")
    
    logging.info(json.dumps(result, indent=2, default=json_serialize)
    
    # Get team analytics
    logging.info("\n📈 Team Analytics:")
    team_report = wrapper.get_team_analytics("ml-team")
    logging.info(json.dumps(team_report, indent=2)
    
    # Get project analytics
    logging.info("\n📊 Project Analytics:")
    project_report = wrapper.get_project_analytics("image-classification")
    logging.info(json.dumps(project_report, indent=2)

async def test_latency_triggers():
    """Test latency trigger functionality"""
    
    wrapper = TerradevWrapper()
    
    logging.info("\n🌐 Testing Latency Triggers")
    logging.info("=" * 30)
    
    # Measure latency for all providers
    latency_tasks = []
    for provider in ["aws", "gcp", "azure", "runpod", "lambda", "coreweave"]:
        latency_tasks.append(
            wrapper.latency_engine.measure_provider_latency(provider)
        )
    
    latency_results = await asyncio.gather(*latency_tasks)
    
    logging.info("📊 Latency Results:")
    for provider, metrics in zip(["aws", "gcp", "azure", "runpod", "lambda", "coreweave"], latency_results):
        print(f"{provider:12} | {metrics.total_score:6.1f}ms | "
              f"Network: {metrics.network_latency_ms:5.1f}ms | "
              f"API: {metrics.api_response_time_ms:5.1f}ms | "
              f"Transfer: {metrics.data_transfer_speed_mbps:5.1f}Mbps")

async def test_derivative_analysis():
    """Test derivative analysis on SkyPilot recommendations"""
    
    wrapper = TerradevWrapper()
    
    logging.info("\n📈 Testing Derivative Analysis")
    logging.info("=" * 35)
    
    # Get sample recommendations
    recommendations = await wrapper._get_skyplot_recommendations("dummy.yaml")
    
    # Apply derivative analysis
    enhanced = wrapper.derivative_analyzer.analyze_skyplot_recommendations(recommendations)
    
    logging.info("📊 Enhanced Recommendations:")
    for rec in enhanced:
        analysis = rec['derivative_analysis']
        print(f"{rec['provider']:12} | Confidence: {analysis['arbitrage_confidence']:4.2f} | "
              f"Delta: {analysis['delta']:4.2f} | Gamma: {analysis['gamma']:5.3f} | "
              f"Volatility: {analysis['volatility']:4.2f} | "
              f"Timing: {analysis['timing_recommendation']:20} | "
              f"Risk: {analysis['risk_assessment']:6}")

async def main():
    """Run all tests"""
    logging.info("🧪 Terradev SkyPilot Wrapper Test Suite")
    logging.info("=" * 50)
    
    await test_smart_launch()
    await test_latency_triggers()
    await test_derivative_analysis()
    
    logging.info("\n✅ All tests completed!")

if __name__ == "__main__":
    asyncio.run(main())
