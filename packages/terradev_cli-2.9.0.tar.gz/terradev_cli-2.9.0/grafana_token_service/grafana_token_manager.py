#!/usr/bin/env python3
"""
Grafana Service Account Token Manager
Comprehensive token management for Grafana-kubernetes adjacent products
"""

import json
import logging
import requests
import base64
import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import os

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TokenType(Enum):
    """Types of Grafana tokens"""
    SERVICE_ACCOUNT = "service_account"
    API_KEY = "api_key"
    DASHBOARD = "dashboard"
    DATASOURCE = "datasource"
    ADMIN = "admin"
    READ_ONLY = "read_only"

class TokenStatus(Enum):
    """Token status"""
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"
    DISABLED = "disabled"

@dataclass
class GrafanaToken:
    """Grafana service account token"""
    token_id: str
    name: str
    token_type: TokenType
    service_account_id: str
    service_account_name: str
    token_value: str
    hashed_token: str
    created_at: datetime
    expires_at: Optional[datetime]
    last_used_at: Optional[datetime]
    status: TokenStatus
    permissions: List[str]
    scopes: List[str]
    metadata: Dict[str, Any]
    rotation_enabled: bool
    rotation_interval_days: int
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'token_id': self.token_id,
            'name': self.name,
            'token_type': self.token_type.value,
            'service_account_id': self.service_account_id,
            'service_account_name': self.service_account_name,
            'hashed_token': self.hasheded_token,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'last_used_at': self.last_used_at.isoformat() if self.last_used_at else None,
            'status': self.status.value,
            'permissions': self.permissions,
            'scopes': self.scopes,
            'metadata': self.metadata,
            'rotation_enabled': self.rotation_enabled,
            'rotation_interval_days': self.rotation_interval_days
        }

@dataclass
class ServiceAccount:
    """Grafana service account"""
    service_account_id: str
    name: str
    display_name: str
    email: str
    role: str
    is_disabled: bool
    tokens: List[str]  # token IDs
    created_at: datetime
    updated_at: datetime
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'service_account_id': self.service_account_id,
            'name': self.name,
            'display_name': self.display_name,
            'email': self.email,
            'role': self.role,
            'is_disabled': self.is_disabled,
            'tokens': self.tokens,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'metadata': self.metadata
        }

class GrafanaTokenManager:
    """Comprehensive Grafana token management"""
    
    def __init__(self, grafana_url: str, admin_token: str):
        self.grafana_url = grafana_url.rstrip('/')
        self.admin_token = admin_token
        self.tokens: Dict[str, GrafanaToken] = {}
        self.service_accounts: Dict[str, ServiceAccount] = {}
        
        # Headers for API requests
        self.headers = {
            'Authorization': f'Bearer {admin_token}',
            'Content-Type': 'application/json'
        }
        
        logger.info(f"Grafana Token Manager initialized for {grafana_url}")
    
    def create_service_account_token(self, 
                                    name: str,
                                    service_account_name: str,
                                    token_type: TokenType = TokenType.SERVICE_ACCOUNT,
                                    permissions: List[str] = None,
                                    scopes: List[str] = None,
                                    expires_in_days: Optional[int] = None,
                                    rotation_enabled: bool = True,
                                    rotation_interval_days: int = 90) -> GrafanaToken:
        """Create a new Grafana service account token"""
        logger.info(f"Creating service account token: {name}")
        
        # Get or create service account
        service_account = self._get_or_create_service_account(service_account_name)
        
        # Generate token
        token_value = self._generate_secure_token()
        
        # Create token in Grafana
        grafana_token_id = self._create_grafana_token(
            service_account.service_account_id,
            name,
            token_value,
            expires_in_days
        )
        
        # Hash token for storage
        hashed_token = self._hash_token(token_value)
        
        # Create token object
        token = GrafanaToken(
            token_id=self._generate_token_id(),
            name=name,
            token_type=token_type,
            service_account_id=service_account.service_account_id,
            service_account_name=service_account_name,
            token_value=token_value,
            hashed_token=hashed_token,
            created_at=datetime.now(),
            expires_at=datetime.now() + timedelta(days=expires_in_days) if expires_in_days else None,
            last_used_at=None,
            status=TokenStatus.ACTIVE,
            permissions=permissions or [],
            scopes=scopes or [],
            metadata={
                'grafana_token_id': grafana_token_id,
                'created_by': 'grafana_token_manager'
            },
            rotation_enabled=rotation_enabled,
            rotation_interval_days=rotation_interval_days
        )
        
        # Store token
        self.tokens[token.token_id] = token
        
        # Update service account
        service_account.tokens.append(token.token_id)
        
        logger.info(f"Service account token created: {token.token_id}")
        return token
    
    def get_token(self, token_id: str) -> Optional[GrafanaToken]:
        """Get token by ID"""
        return self.tokens.get(token_id)
    
    def list_tokens(self, service_account_name: Optional[str] = None,
                   token_type: Optional[TokenType] = None,
                   status: Optional[TokenStatus] = None) -> List[GrafanaToken]:
        """List tokens with optional filtering"""
        tokens = list(self.tokens.values())
        
        if service_account_name:
            tokens = [t for t in tokens if t.service_account_name == service_account_name]
        
        if token_type:
            tokens = [t for t in tokens if t.token_type == token_type]
        
        if status:
            tokens = [t for t in tokens if t.status == status]
        
        return tokens
    
    def revoke_token(self, token_id: str) -> bool:
        """Revoke a token"""
        token = self.tokens.get(token_id)
        if not token:
            logger.error(f"Token not found: {token_id}")
            return False
        
        try:
            # Revoke token in Grafana
            self._revoke_grafana_token(token.metadata['grafana_token_id'])
            
            # Update status
            token.status = TokenStatus.REVOKED
            token.last_used_at = datetime.now()
            
            logger.info(f"Token revoked: {token_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to revoke token {token_id}: {e}")
            return False
    
    def rotate_token(self, token_id: str) -> Optional[GrafanaToken]:
        """Rotate a token"""
        old_token = self.tokens.get(token_id)
        if not old_token:
            logger.error(f"Token not found: {token_id}")
            return None
        
        if not old_token.rotation_enabled:
            logger.error(f"Token rotation not enabled: {token_id}")
            return None
        
        logger.info(f"Rotating token: {token_id}")
        
        # Create new token
        new_token = self.create_service_account_token(
            name=f"{old_token.name}_rotated",
            service_account_name=old_token.service_account_name,
            token_type=old_token.token_type,
            permissions=old_token.permissions,
            scopes=old_token.scopes,
            expires_in_days=old_token.rotation_interval_days,
            rotation_enabled=old_token.rotation_enabled,
            rotation_interval_days=old_token.rotation_interval_days
        )
        
        # Revoke old token
        self.revoke_token(token_id)
        
        logger.info(f"Token rotated: {token_id} -> {new_token.token_id}")
        return new_token
    
    def validate_token(self, token_value: str) -> bool:
        """Validate a token"""
        hashed_token = self._hash_token(token_value)
        
        for token in self.tokens.values():
            if token.hashed_token == hashed_token and token.status == TokenStatus.ACTIVE:
                # Check expiration
                if token.expires_at and token.expires_at < datetime.now():
                    token.status = TokenStatus.EXPIRED
                    return False
                
                # Update last used
                token.last_used_at = datetime.now()
                return True
        
        return False
    
    def cleanup_expired_tokens(self) -> int:
        """Clean up expired tokens"""
        expired_count = 0
        now = datetime.now()
        
        for token in self.tokens.values():
            if token.expires_at and token.expires_at < now and token.status == TokenStatus.ACTIVE:
                token.status = TokenStatus.EXPIRED
                expired_count += 1
                logger.info(f"Token expired: {token.token_id}")
        
        logger.info(f"Cleaned up {expired_count} expired tokens")
        return expired_count
    
    def get_service_account(self, service_account_name: str) -> Optional[ServiceAccount]:
        """Get service account by name"""
        for sa in self.service_accounts.values():
            if sa.name == service_account_name:
                return sa
        return None
    
    def list_service_accounts(self) -> List[ServiceAccount]:
        """List all service accounts"""
        return list(self.service_accounts.values())
    
    def _get_or_create_service_account(self, name: str) -> ServiceAccount:
        """Get or create service account"""
        # Check if exists
        existing = self.get_service_account(name)
        if existing:
            return existing
        
        # Create new service account
        service_account_id = self._create_grafana_service_account(name)
        
        service_account = ServiceAccount(
            service_account_id=service_account_id,
            name=name,
            display_name=name,
            email=f"{name}@terradev.local",
            role="Admin",
            is_disabled=False,
            tokens=[],
            created_at=datetime.now(),
            updated_at=datetime.now(),
            metadata={
                'created_by': 'grafana_token_manager',
                'environment': 'production'
            }
        )
        
        self.service_accounts[service_account.service_account_id] = service_account
        logger.info(f"Service account created: {name}")
        
        return service_account
    
    def _create_grafana_service_account(self, name: str) -> str:
        """Create service account in Grafana"""
        url = f"{self.grafana_url}/api/serviceaccounts"
        
        data = {
            "name": name,
            "role": "Admin"
        }
        
        response = requests.post(url, json=data, headers=self.headers)
        response.raise_for_status()
        
        result = response.json()
        return result.get('id')
    
    def _create_grafana_token(self, service_account_id: str, name: str, 
                            token_value: str, expires_in_days: Optional[int]) -> str:
        """Create token in Grafana"""
        url = f"{self.grafana_url}/api/serviceaccounts/{service_account_id}/tokens"
        
        data = {
            "name": name,
            "secondsToLive": expires_in_days * 24 * 3600 if expires_in_days else 0
        }
        
        response = requests.post(url, json=data, headers=self.headers)
        response.raise_for_status()
        
        result = response.json()
        return result.get('key')
    
    def _revoke_grafana_token(self, grafana_token_id: str) -> None:
        """Revoke token in Grafana"""
        url = f"{self.grafana_url}/api/serviceaccounts/tokens/{grafana_token_id}"
        
        response = requests.delete(url, headers=self.headers)
        response.raise_for_status()
    
    def _generate_secure_token(self) -> str:
        """Generate secure token"""
        return f"glsa_{secrets.token_urlsafe(32)}"
    
    def _hash_token(self, token: str) -> str:
        """Hash token for storage"""
        return hashlib.sha256(token.encode()).hexdigest()
    
    def _generate_token_id(self) -> str:
        """Generate unique token ID"""
        return f"token_{secrets.token_hex(16)}"
    
    def export_tokens(self, filename: str, include_sensitive: bool = False) -> None:
        """Export tokens to file"""
        tokens_data = []
        
        for token in self.tokens.values():
            token_dict = token.to_dict()
            
            # Include sensitive data only if requested
            if include_sensitive:
                token_dict['token_value'] = token.token_value
            else:
                token_dict['token_value'] = "***REDACTED***"
            
            tokens_data.append(token_dict)
        
        with open(filename, 'w') as f:
            json.dump(tokens_data, f, indent=2)
        
        logger.info(f"Tokens exported to: {filename}")
    
    def export_service_accounts(self, filename: str) -> None:
        """Export service accounts to file"""
        service_accounts_data = [sa.to_dict() for sa in self.service_accounts.values()]
        
        with open(filename, 'w') as f:
            json.dump(service_accounts_data, f, indent=2)
        
        logger.info(f"Service accounts exported to: {filename}")

# Example usage
if __name__ == "__main__":
    # Initialize with your Grafana instance
    grafana_url = os.environ.get('GRAFANA_URL', 'http://localhost:3000')
    admin_token = os.environ.get('GRAFANA_ADMIN_TOKEN', 'your_admin_token_here')
    
    manager = GrafanaTokenManager(grafana_url, admin_token)
    
    print("🔑 GRAFANA TOKEN MANAGER DEMO")
    print("=" * 50)
    
    # Create service account token
    token = manager.create_service_account_token(
        name="terradev-k8s-integration",
        service_account_name="terradev-service",
        token_type=TokenType.SERVICE_ACCOUNT,
        permissions=["read", "write", "admin"],
        scopes=["api", "dashboards", "datasources"],
        expires_in_days=365,
        rotation_enabled=True,
        rotation_interval_days=90
    )
    
    print(f"✅ Token Created:")
    print(f"   Token ID: {token.token_id}")
    print(f"   Name: {token.name}")
    print(f"   Type: {token.token_type.value}")
    print(f"   Service Account: {token.service_account_name}")
    print(f"   Status: {token.status.value}")
    print(f"   Expires: {token.expires_at}")
    print(f"   Token: {token.token_value}")
    print(f"   Permissions: {', '.join(token.permissions)}")
    print(f"   Scopes: {', '.join(token.scopes)}")
    
    # Validate token
    is_valid = manager.validate_token(token.token_value)
    print(f"\n🔍 Token Validation: {'✅ Valid' if is_valid else '❌ Invalid'}")
    
    # List tokens
    tokens = manager.list_tokens()
    print(f"\n📋 Total Tokens: {len(tokens)}")
    
    # Export tokens
    manager.export_tokens('tokens.json', include_sensitive=True)
    manager.export_service_accounts('service_accounts.json')
    
    print(f"\n💾 Exported to: tokens.json, service_accounts.json")
    
    print(f"\n🎯 Token Management Features:")
    print("   ✅ Service account creation")
    print("   ✅ Token generation and management")
    print("   ✅ Token validation and authentication")
    print("   ✅ Token rotation and expiration")
    print("   ✅ Permission and scope management")
    print("   ✅ Secure token storage")
    print("   ✅ Token revocation")
    print("   ✅ Export and backup")
    
    print(f"\n🚀 Ready for Kubernetes Integration!")
