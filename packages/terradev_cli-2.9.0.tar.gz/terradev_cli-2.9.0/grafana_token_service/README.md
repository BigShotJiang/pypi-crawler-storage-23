# 🔑 Grafana Token Service

Comprehensive Grafana service account token management for Kubernetes-adjacent products.

## 🎯 Overview

This service provides secure token management for Grafana integration with Kubernetes applications. It handles token creation, rotation, validation, and secure storage with complete audit trails.

## 🚀 Features

### 🔐 Token Management
- **Service Account Tokens**: Create and manage service account tokens
- **Token Rotation**: Automatic token rotation with configurable intervals
- **Token Validation**: Secure token validation and authentication
- **Token Revocation**: Secure token revocation when needed
- **Expiration Management**: Automatic token expiration handling

### 🐳 Kubernetes Integration
- **Native Kubernetes Deployment**: Complete manifests for K8s deployment
- **RBAC Integration**: Proper role-based access control
- **Secret Management**: Secure token storage in Kubernetes secrets
- **ConfigMap Integration**: Configuration management
- **Health Checks**: Liveness and readiness probes
- **Ingress Support**: External access with TLS

### 🌐 REST API
- **RESTful API**: Complete REST API for token operations
- **Authentication**: Token-based authentication for API access
- **Error Handling**: Comprehensive error handling and logging
- **Validation**: Input validation and sanitization
- **Export/Import**: Token export and import capabilities

### 📊 Monitoring & Analytics
- **Token Statistics**: Comprehensive token usage statistics
- **Audit Trails**: Complete audit trail for all operations
- **Health Monitoring**: Service health and readiness checks
- **Metrics**: Token lifecycle metrics and monitoring

## 📁 Project Structure

```
grafana_token_service/
├── grafana_token_manager.py      # Core token management logic
├── kubernetes_integration.py     # Kubernetes manifests and integration
├── token_service_api.py          # REST API server
├── README.md                      # This file
├── requirements.txt               # Python dependencies
├── Dockerfile                    # Docker configuration
├── docker-compose.yml           # Docker Compose configuration
└── examples/                     # Usage examples
    ├── token_creation.py
    ├── kubernetes_deployment.py
    └── api_usage.py
```

## 🛠️ Installation

### Prerequisites
- Python 3.9+
- Grafana instance with admin access
- Kubernetes cluster (optional, for K8s deployment)
- Docker (optional, for containerized deployment)

### Local Installation

```bash
# Clone the repository
git clone <repository-url>
cd grafana_token_service

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export GRAFANA_URL="http://your-grafana:3000"
export GRAFANA_ADMIN_TOKEN="your_admin_token"

# Run the service
python token_service_api.py
```

### Docker Installation

```bash
# Build Docker image
docker build -t grafana-token-service .

# Run with environment variables
docker run -d \
  -p 8080:8080 \
  -e GRAFANA_URL="http://your-grafana:3000" \
  -e GRAFANA_ADMIN_TOKEN="your_admin_token" \
  grafana-token-service
```

### Kubernetes Deployment

```bash
# Generate manifests
python kubernetes_integration.py

# Apply manifests
kubectl apply -f k8s-manifests/namespace.yaml
kubectl apply -f k8s-manifests/rbac.yaml
kubectl apply -f k8s-manifests/secret.yaml
kubectl apply -f k8s-manifests/configmap.yaml
kubectl apply -f k8s-manifests/deployment.yaml
kubectl apply -f k8s-manifests/service.yaml
kubectl apply -f k8s-manifests/ingress.yaml
```

## 🔑 Token Creation

### Basic Token Creation

```python
from grafana_token_manager import GrafanaTokenManager, TokenType

# Initialize manager
manager = GrafanaTokenManager(
    grafana_url="http://your-grafana:3000",
    admin_token="your_admin_token"
)

# Create service account token
token = manager.create_service_account_token(
    name="my-service-token",
    service_account_name="my-service",
    token_type=TokenType.SERVICE_ACCOUNT,
    permissions=["read", "write"],
    scopes=["api", "dashboards"],
    expires_in_days=365,
    rotation_enabled=True,
    rotation_interval_days=90
)

print(f"Token created: {token.token_value}")
```

### Kubernetes Service Token

```python
from kubernetes_integration import GrafanaKubernetesIntegration, KubernetesConfig

# Configure
config = KubernetesConfig(
    namespace="grafana-token-service",
    service_account_name="grafana-token-service",
    configmap_name="grafana-token-config",
    secret_name="grafana-token-secrets",
    deployment_name="grafana-token-service",
    service_name="grafana-token-service",
    ingress_name="grafana-token-ingress"
)

# Initialize integration
integration = GrafanaKubernetesIntegration(
    grafana_url="http://your-grafana:3000",
    admin_token="your_admin_token",
    config=config
)

# Create token for service
service_token = integration.create_token_for_service(
    service_name="ml-training-service",
    permissions=["read", "write", "admin"],
    scopes=["api", "dashboards", "datasources"],
    expires_in_days=365
)

print(f"Service token: {service_token['token'].token_value}")
```

## 🌐 API Usage

### Authentication

All API endpoints require authentication using a valid token:

```bash
# Get token first
curl -X POST http://localhost:8080/api/tokens \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-service-token",
    "service_account_name": "api-service",
    "permissions": ["read", "write"],
    "scopes": ["api"]
  }'
```

### Create Token

```bash
curl -X POST http://localhost:8080/api/tokens \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "new-service-token",
    "service_account_name": "my-service",
    "token_type": "service_account",
    "permissions": ["read", "write"],
    "scopes": ["api", "dashboards"],
    "expires_in_days": 365
  }'
```

### List Tokens

```bash
curl -X GET http://localhost:8080/api/tokens \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Validate Token

```bash
curl -X POST http://localhost:8080/api/tokens/validate \
  -H "Content-Type: application/json" \
  -d '{
    "token": "glsa_YourTokenHere"
  }'
```

### Revoke Token

```bash
curl -X DELETE http://localhost:8080/api/tokens/TOKEN_ID \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 📊 API Endpoints

### Token Management
- `POST /api/tokens` - Create new token
- `GET /api/tokens` - List tokens (with filtering)
- `GET /api/tokens/{token_id}` - Get specific token
- `DELETE /api/tokens/{token_id}` - Revoke token
- `POST /api/tokens/{token_id}/rotate` - Rotate token

### Token Operations
- `POST /api/tokens/validate` - Validate token
- `POST /api/tokens/cleanup` - Clean up expired tokens
- `GET /api/tokens/export` - Export tokens

### Service Accounts
- `GET /api/service-accounts` - List service accounts
- `GET /api/service-accounts/{name}` - Get specific service account

### Monitoring
- `GET /health` - Health check
- `GET /ready` - Readiness check
- `GET /api/stats` - Service statistics

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `GRAFANA_URL` | Grafana instance URL | `http://localhost:3000` |
| `GRAFANA_ADMIN_TOKEN` | Grafana admin token | Required |
| `FLASK_DEBUG` | Flask debug mode | `false` |
| `LOG_LEVEL` | Logging level | `INFO` |

### Token Configuration

```python
# Token rotation settings
rotation_enabled = True
rotation_interval_days = 90

# Token expiration
default_expiry_days = 365

# Token permissions
default_permissions = ["read", "write"]
default_scopes = ["api"]

# Token limits
max_tokens_per_service_account = 10
```

## 🔒 Security Features

### Token Security
- **Secure Token Generation**: Cryptographically secure token generation
- **Token Hashing**: Tokens are hashed for secure storage
- **Token Validation**: Comprehensive token validation
- **Token Rotation**: Automatic token rotation to prevent token compromise
- **Token Expiration**: Automatic token expiration handling

### API Security
- **Authentication**: Token-based API authentication
- **Authorization**: Role-based access control
- **Input Validation**: Comprehensive input validation and sanitization
- **Error Handling**: Secure error handling without information leakage
- **Rate Limiting**: Rate limiting to prevent abuse

### Kubernetes Security
- **RBAC**: Proper role-based access control
- **Secret Management**: Secure token storage in Kubernetes secrets
- **Network Policies**: Network policies for secure communication
- **Pod Security**: Pod security policies and contexts

## 📈 Monitoring

### Health Checks
- **Health Check**: `/health` endpoint for service health
- **Readiness Check**: `/ready` endpoint for service readiness
- **Liveness Probe**: Container liveness probe
- **Readiness Probe**: Container readiness probe

### Metrics
- **Token Metrics**: Token creation, rotation, and revocation metrics
- **API Metrics**: API request and response metrics
- **Service Metrics**: Service performance and availability metrics
- **Error Metrics**: Error rates and types

### Logging
- **Structured Logging**: JSON-structured logging
- **Audit Logging**: Complete audit trail for all operations
- **Error Logging**: Comprehensive error logging
- **Performance Logging**: Performance and timing logs

## 🚀 Deployment

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
export GRAFANA_URL="http://localhost:3000"
export GRAFANA_ADMIN_TOKEN="your_admin_token"

# Run the service
python token_service_api.py
```

### Docker Deployment

```bash
# Build image
docker build -t grafana-token-service .

# Run container
docker run -d \
  -p 8080:8080 \
  -e GRAFANA_URL="http://your-grafana:3000" \
  -e GRAFANA_ADMIN_TOKEN="your_admin_token" \
  grafana-token-service
```

### Kubernetes Deployment

```bash
# Generate manifests
python kubernetes_integration.py

# Deploy to Kubernetes
kubectl apply -f k8s-manifests/

# Check deployment
kubectl get pods -n grafana-token-service
kubectl get services -n grafana-token-service
```

## 🧪 Testing

### Unit Tests

```bash
# Run unit tests
python -m pytest tests/
```

### Integration Tests

```bash
# Run integration tests
python -m pytest tests/integration/
```

### API Tests

```bash
# Run API tests
python -m pytest tests/api/
```

## 📝 Examples

### Basic Usage

```python
# examples/token_creation.py
from grafana_token_manager import GrafanaTokenManager, TokenType

manager = GrafanaTokenManager(
    grafana_url="http://localhost:3000",
    admin_token="your_admin_token"
)

token = manager.create_service_account_token(
    name="example-token",
    service_account_name="example-service",
    token_type=TokenType.SERVICE_ACCOUNT,
    permissions=["read", "write"],
    scopes=["api", "dashboards"]
)

print(f"Token: {token.token_value}")
```

### Kubernetes Integration

```python
# examples/kubernetes_deployment.py
from kubernetes_integration import GrafanaKubernetesIntegration, KubernetesConfig

config = KubernetesConfig(
    namespace="grafana-token-service",
    service_account_name="grafana-token-service"
)

integration = GrafanaKubernetesIntegration(
    grafana_url="http://localhost:3000",
    admin_token="your_admin_token",
    config=config
)

# Generate manifests
manifests = integration.generate_kubernetes_manifests()

# Save manifests
integration.save_manifests("k8s-manifests")
```

### API Usage

```python
# examples/api_usage.py
import requests

# Create token
response = requests.post(
    "http://localhost:8080/api/tokens",
    headers={"Authorization": "Bearer YOUR_TOKEN"},
    json={
        "name": "api-token",
        "service_account_name": "api-service",
        "permissions": ["read", "write"],
        "scopes": ["api"]
    }
)

token = response.json()
print(f"Token: {token['token_value']}")
```

## 🔧 Troubleshooting

### Common Issues

#### Token Creation Fails
- Check Grafana URL and admin token
- Verify admin permissions in Grafana
- Check network connectivity to Grafana

#### Kubernetes Deployment Fails
- Verify RBAC permissions
- Check namespace creation
- Validate secret and configmap data

#### API Authentication Fails
- Verify token is valid and not expired
- Check token permissions
- Ensure token is properly formatted

### Debug Mode

```bash
# Enable debug mode
export FLASK_DEBUG=true
export LOG_LEVEL=DEBUG

# Run with debug
python token_service_api.py
```

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📞 Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the examples

## 🔗 Related Projects

- [Terradev ML Training Platform](../)
- [Grafana Documentation](https://grafana.com/docs/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)

---

**🔑 Secure Token Management for Grafana-Kubernetes Adjacent Products**
