#!/usr/bin/env python3
"""
Grafana Token Service API
REST API for managing Grafana tokens in Kubernetes environment
"""

from flask import Flask, request, jsonify, g
from flask_cors import CORS
import logging
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from functools import wraps

from grafana_token_manager import GrafanaTokenManager, TokenType, TokenStatus

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Initialize token manager
grafana_url = os.environ.get('GRAFANA_URL', 'http://localhost:3000')
admin_token = os.environ.get('GRAFANA_ADMIN_TOKEN', 'your_admin_token_here')
token_manager = GrafanaTokenManager(grafana_url, admin_token)

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Missing or invalid authorization header'}), 401
        
        token = auth_header.split(' ')[1]
        if not token_manager.validate_token(token):
            return jsonify({'error': 'Invalid or expired token'}), 401
        
        g.token = token
        return f(*args, **kwargs)
    
    return decorated_function

def handle_error(error: Exception, status_code: int = 500):
    """Handle errors consistently"""
    logger.error(f"API Error: {str(error)}")
    return jsonify({
        'error': str(error),
        'timestamp': datetime.now().isoformat(),
        'status_code': status_code
    }), status_code

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0',
        'service': 'grafana-token-service'
    })

@app.route('/ready', methods=['GET'])
def readiness_check():
    """Readiness check endpoint"""
    try:
        # Check if we can connect to Grafana
        tokens = token_manager.list_tokens(limit=1)
        return jsonify({
            'status': 'ready',
            'timestamp': datetime.now().isoformat(),
            'grafana_connected': True
        })
    except Exception as e:
        return jsonify({
            'status': 'not_ready',
            'timestamp': datetime.now().isoformat(),
            'grafana_connected': False,
            'error': str(e)
        }), 503

@app.route('/api/tokens', methods=['POST'])
@require_auth
def create_token():
    """Create a new token"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'service_account_name']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create token
        token = token_manager.create_service_account_token(
            name=data['name'],
            service_account_name=data['service_account_name'],
            token_type=TokenType(data.get('token_type', 'service_account')),
            permissions=data.get('permissions', []),
            scopes=data.get('scopes', []),
            expires_in_days=data.get('expires_in_days'),
            rotation_enabled=data.get('rotation_enabled', True),
            rotation_interval_days=data.get('rotation_interval_days', 90)
        )
        
        return jsonify({
            'token_id': token.token_id,
            'name': token.name,
            'token_type': token.token_type.value,
            'service_account_name': token.service_account_name,
            'token_value': token.token_value,
            'permissions': token.permissions,
            'scopes': token.scopes,
            'created_at': token.created_at.isoformat(),
            'expires_at': token.expires_at.isoformat() if token.expires_at else None,
            'status': token.status.value,
            'rotation_enabled': token.rotation_enabled,
            'rotation_interval_days': token.rotation_interval_days
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/tokens', methods=['GET'])
@require_auth
def list_tokens():
    """List tokens with optional filtering"""
    try:
        # Parse query parameters
        service_account_name = request.args.get('service_account_name')
        token_type = request.args.get('token_type')
        status = request.args.get('status')
        limit = request.args.get('limit', type=int)
        
        # Convert string parameters to enums
        token_type_enum = TokenType(token_type) if token_type else None
        status_enum = TokenStatus(status) if status else None
        
        # Get tokens
        tokens = token_manager.list_tokens(
            service_account_name=service_account_name,
            token_type=token_type_enum,
            status=status_enum
        )
        
        # Apply limit if specified
        if limit:
            tokens = tokens[:limit]
        
        return jsonify({
            'tokens': [
                {
                    'token_id': token.token_id,
                    'name': token.name,
                    'token_type': token.token_type.value,
                    'service_account_name': token.service_account_name,
                    'created_at': token.created_at.isoformat(),
                    'expires_at': token.expires_at.isoformat() if token.expires_at else None,
                    'last_used_at': token.last_used_at.isoformat() if token.last_used_at else None,
                    'status': token.status.value,
                    'permissions': token.permissions,
                    'scopes': token.scopes,
                    'rotation_enabled': token.rotation_enabled,
                    'rotation_interval_days': token.rotation_interval_days
                }
                for token in tokens
            ],
            'total': len(tokens),
            'filters': {
                'service_account_name': service_account_name,
                'token_type': token_type,
                'status': status,
                'limit': limit
            }
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/tokens/<token_id>', methods=['GET'])
@require_auth
def get_token(token_id: str):
    """Get specific token details"""
    try:
        token = token_manager.get_token(token_id)
        if not token:
            return jsonify({'error': 'Token not found'}), 404
        
        return jsonify({
            'token_id': token.token_id,
            'name': token.name,
            'token_type': token.token_type.value,
            'service_account_name': token.service_account_name,
            'created_at': token.created_at.isoformat(),
            'expires_at': token.expires_at.isoformat() if token.expires_at else None,
            'last_used_at': token.last_used_at.isoformat() if token.last_used_at else None,
            'status': token.status.value,
            'permissions': token.permissions,
            'scopes': token.scopes,
            'metadata': token.metadata,
            'rotation_enabled': token.rotation_enabled,
            'rotation_interval_days': token.rotation_interval_days
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/tokens/<token_id>', methods=['DELETE'])
@require_auth
def revoke_token(token_id: str):
    """Revoke a token"""
    try:
        success = token_manager.revoke_token(token_id)
        if not success:
            return jsonify({'error': 'Failed to revoke token'}), 400
        
        return jsonify({
            'message': 'Token revoked successfully',
            'token_id': token_id,
            'revoked_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/tokens/<token_id>/rotate', methods=['POST'])
@require_auth
def rotate_token(token_id: str):
    """Rotate a token"""
    try:
        new_token = token_manager.rotate_token(token_id)
        if not new_token:
            return jsonify({'error': 'Failed to rotate token'}), 400
        
        return jsonify({
            'message': 'Token rotated successfully',
            'old_token_id': token_id,
            'new_token': {
                'token_id': new_token.token_id,
                'name': new_token.name,
                'token_value': new_token.token_value,
                'created_at': new_token.created_at.isoformat(),
                'expires_at': new_token.expires_at.isoformat() if new_token.expires_at else None,
                'status': new_token.status.value
            },
            'rotated_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/tokens/validate', methods=['POST'])
def validate_token():
    """Validate a token"""
    try:
        data = request.get_json()
        token_value = data.get('token')
        
        if not token_value:
            return jsonify({'error': 'Missing token'}), 400
        
        is_valid = token_manager.validate_token(token_value)
        
        return jsonify({
            'valid': is_valid,
            'validated_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/tokens/cleanup', methods=['POST'])
@require_auth
def cleanup_expired_tokens():
    """Clean up expired tokens"""
    try:
        expired_count = token_manager.cleanup_expired_tokens()
        
        return jsonify({
            'message': 'Expired tokens cleaned up successfully',
            'expired_count': expired_count,
            'cleaned_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/service-accounts', methods=['GET'])
@require_auth
def list_service_accounts():
    """List service accounts"""
    try:
        service_accounts = token_manager.list_service_accounts()
        
        return jsonify({
            'service_accounts': [
                {
                    'service_account_id': sa.service_account_id,
                    'name': sa.name,
                    'display_name': sa.display_name,
                    'email': sa.email,
                    'role': sa.role,
                    'is_disabled': sa.is_disabled,
                    'tokens': sa.tokens,
                    'created_at': sa.created_at.isoformat(),
                    'updated_at': sa.updated_at.isoformat(),
                    'metadata': sa.metadata
                }
                for sa in service_accounts
            ],
            'total': len(service_accounts)
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/service-accounts/<service_account_name>', methods=['GET'])
@require_auth
def get_service_account(service_account_name: str):
    """Get specific service account"""
    try:
        service_account = token_manager.get_service_account(service_account_name)
        if not service_account:
            return jsonify({'error': 'Service account not found'}), 404
        
        return jsonify({
            'service_account_id': service_account.service_account_id,
            'name': service_account.name,
            'display_name': service_account.display_name,
            'email': service_account.email,
            'role': service_account.role,
            'is_disabled': service_account.is_disabled,
            'tokens': service_account.tokens,
            'created_at': service_account.created_at.isoformat(),
            'updated_at': service_account.updated_at.isoformat(),
            'metadata': service_account.metadata
        })
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/tokens/export', methods=['GET'])
@require_auth
def export_tokens():
    """Export tokens"""
    try:
        include_sensitive = request.args.get('include_sensitive', 'false').lower() == 'true'
        
        # Get all tokens
        tokens = token_manager.list_tokens()
        
        export_data = {
            'exported_at': datetime.now().isoformat(),
            'total_tokens': len(tokens),
            'tokens': []
        }
        
        for token in tokens:
            token_data = {
                'token_id': token.token_id,
                'name': token.name,
                'token_type': token.token_type.value,
                'service_account_name': token.service_account_name,
                'created_at': token.created_at.isoformat(),
                'expires_at': token.expires_at.isoformat() if token.expires_at else None,
                'last_used_at': token.last_used_at.isoformat() if token.last_used_at else None,
                'status': token.status.value,
                'permissions': token.permissions,
                'scopes': token.scopes,
                'metadata': token.metadata,
                'rotation_enabled': token.rotation_enabled,
                'rotation_interval_days': token.rotation_interval_days
            }
            
            if include_sensitive:
                token_data['token_value'] = token.token_value
            else:
                token_data['token_value'] = '***REDACTED***'
            
            export_data['tokens'].append(token_data)
        
        return jsonify(export_data)
        
    except Exception as e:
        return handle_error(e)

@app.route('/api/stats', methods=['GET'])
@require_auth
def get_stats():
    """Get service statistics"""
    try:
        tokens = token_manager.list_tokens()
        service_accounts = token_manager.list_service_accounts()
        
        # Calculate statistics
        total_tokens = len(tokens)
        active_tokens = len([t for t in tokens if t.status == TokenStatus.ACTIVE])
        expired_tokens = len([t for t in tokens if t.status == TokenStatus.EXPIRED])
        revoked_tokens = len([t for t in tokens if t.status == TokenStatus.REVOKED])
        
        # Token type breakdown
        token_types = {}
        for token in tokens:
            token_type = token.token_type.value
            token_types[token_type] = token_types.get(token_type, 0) + 1
        
        # Service account breakdown
        total_service_accounts = len(service_accounts)
        disabled_service_accounts = len([sa for sa in service_accounts if sa.is_disabled])
        
        return jsonify({
            'timestamp': datetime.now().isoformat(),
            'tokens': {
                'total': total_tokens,
                'active': active_tokens,
                'expired': expired_tokens,
                'revoked': revoked_tokens,
                'by_type': token_types
            },
            'service_accounts': {
                'total': total_service_accounts,
                'active': total_service_accounts - disabled_service_accounts,
                'disabled': disabled_service_accounts
            },
            'grafana': {
                'url': grafana_url,
                'connected': True
            }
        })
        
    except Exception as e:
        return handle_error(e)

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("🔑 GRAFANA TOKEN SERVICE API")
    print("=" * 50)
    
    # Run the Flask app
    app.run(
        host='0.0.0.0',
        port=8080,
        debug=os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    )
