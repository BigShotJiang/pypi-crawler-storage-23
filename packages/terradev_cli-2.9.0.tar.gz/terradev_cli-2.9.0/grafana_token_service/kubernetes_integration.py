#!/usr/bin/env python3
"""
Kubernetes Integration for Grafana Token Service
Deploy and manage Grafana tokens in Kubernetes environment
"""

import yaml
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

from grafana_token_manager import GrafanaTokenManager, TokenType, TokenStatus

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class KubernetesConfig:
    """Kubernetes deployment configuration"""
    namespace: str
    service_account_name: str
    configmap_name: str
    secret_name: str
    deployment_name: str
    service_name: str
    ingress_name: str
    
class GrafanaKubernetesIntegration:
    """Kubernetes integration for Grafana token service"""
    
    def __init__(self, grafana_url: str, admin_token: str, config: KubernetesConfig):
        self.grafana_url = grafana_url
        self.admin_token = admin_token
        self.config = config
        self.token_manager = GrafanaTokenManager(grafana_url, admin_token)
        
        logger.info(f"Grafana Kubernetes Integration initialized for namespace: {config.namespace}")
    
    def generate_kubernetes_manifests(self) -> Dict[str, Any]:
        """Generate complete Kubernetes manifests"""
        manifests = {
            'namespace': self._generate_namespace(),
            'service_account': self._generate_service_account(),
            'configmap': self._generate_configmap(),
            'secret': self._generate_secret(),
            'deployment': self._generate_deployment(),
            'service': self._generate_service(),
            'ingress': self._generate_ingress(),
            'rbac': self._generate_rbac()
        }
        
        return manifests
    
    def _generate_namespace(self) -> Dict[str, Any]:
        """Generate namespace manifest"""
        return {
            'apiVersion': 'v1',
            'kind': 'Namespace',
            'metadata': {
                'name': self.config.namespace,
                'labels': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                }
            }
        }
    
    def _generate_service_account(self) -> Dict[str, Any]:
        """Generate service account manifest"""
        return {
            'apiVersion': 'v1',
            'kind': 'ServiceAccount',
            'metadata': {
                'name': self.config.service_account_name,
                'namespace': self.config.namespace,
                'labels': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                },
                'annotations': {
                    'kubectl.kubernetes.io/last-applied-configuration': json.dumps({
                        'created': datetime.now().isoformat(),
                        'managed-by': 'grafana-token-service'
                    })
                }
            }
        }
    
    def _generate_configmap(self) -> Dict[str, Any]:
        """Generate configmap manifest"""
        # Create token for service
        token = self.token_manager.create_service_account_token(
            name="k8s-service-token",
            service_account_name="grafana-k8s-service",
            token_type=TokenType.SERVICE_ACCOUNT,
            permissions=["read", "write"],
            scopes=["api", "dashboards"],
            expires_in_days=365,
            rotation_enabled=True,
            rotation_interval_days=90
        )
        
        config_data = {
            'grafana_url': self.grafana_url,
            'service_name': 'grafana-token-service',
            'log_level': 'INFO',
            'token_rotation_interval': '90d',
            'cleanup_interval': '24h',
            'max_tokens_per_service_account': 10,
            'default_token_expiry': '365d'
        }
        
        return {
            'apiVersion': 'v1',
            'kind': 'ConfigMap',
            'metadata': {
                'name': self.config.configmap_name,
                'namespace': self.config.namespace,
                'labels': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                }
            },
            'data': {
                'config.json': json.dumps(config_data, indent=2),
                'token.json': json.dumps({
                    'token_id': token.token_id,
                    'token_value': token.token_value,
                    'service_account': token.service_account_name,
                    'permissions': token.permissions,
                    'scopes': token.scopes,
                    'expires_at': token.expires_at.isoformat() if token.expires_at else None
                }, indent=2)
            }
        }
    
    def _generate_secret(self) -> Dict[str, Any]:
        """Generate secret manifest"""
        return {
            'apiVersion': 'v1',
            'kind': 'Secret',
            'metadata': {
                'name': self.config.secret_name,
                'namespace': self.config.namespace,
                'labels': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                }
            },
            'type': 'Opaque',
            'data': {
                'admin-token': self._encode_base64(self.admin_token),
                'grafana-url': self._encode_base64(self.grafana_url)
            }
        }
    
    def _generate_deployment(self) -> Dict[str, Any]:
        """Generate deployment manifest"""
        return {
            'apiVersion': 'apps/v1',
            'kind': 'Deployment',
            'metadata': {
                'name': self.config.deployment_name,
                'namespace': self.config.namespace,
                'labels': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                }
            },
            'spec': {
                'replicas': 2,
                'selector': {
                    'matchLabels': {
                        'app': 'grafana-token-service',
                        'component': 'token-management'
                    }
                },
                'template': {
                    'metadata': {
                        'labels': {
                            'app': 'grafana-token-service',
                            'component': 'token-management'
                        }
                    },
                    'spec': {
                        'serviceAccountName': self.config.service_account_name,
                        'containers': [
                            {
                                'name': 'grafana-token-service',
                                'image': 'python:3.9-slim',
                                'command': ['python', '-c'],
                                'args': [
                                    '''
import os
import json
import time
from datetime import datetime
from kubernetes import client, config

# Load configuration
with open('/app/config/config.json', 'r') as f:
    config = json.load(f)

# Load token
with open('/app/config/token.json', 'r') as f:
    token = json.load(f)

# Initialize Kubernetes client
try:
    config.load_incluster_config()
except:
    config.load_kube_config()

v1 = client.CoreV1Api()

print(f"Grafana Token Service Started")
print(f"Grafana URL: {config['grafana_url']}")
print(f"Token ID: {token['token_id']}")
print(f"Service Account: {token['service_account']}")

# Health check loop
while True:
    try:
        # Update token status
        print(f"Service healthy - {datetime.now().isoformat()}")
        time.sleep(60)
    except Exception as e:
        print(f"Service error: {e}")
        time.sleep(30)
'''
                                ],
                                'env': [
                                    {
                                        'name': 'GRAFANA_URL',
                                        'valueFrom': {
                                            'configMapKeyRef': {
                                                'name': self.config.configmap_name,
                                                'key': 'config.json'
                                            }
                                        }
                                    },
                                    {
                                        'name': 'TOKEN_ID',
                                        'valueFrom': {
                                            'configMapKeyRef': {
                                                'name': self.config.configmap_name,
                                                'key': 'token.json'
                                            }
                                        }
                                    },
                                    {
                                        'name': 'ADMIN_TOKEN',
                                        'valueFrom': {
                                            'secretKeyRef': {
                                                'name': self.config.secret_name,
                                                'key': 'admin-token'
                                            }
                                        }
                                    }
                                ],
                                'volumeMounts': [
                                    {
                                        'name': 'config-volume',
                                        'mountPath': '/app/config',
                                        'readOnly': True
                                    }
                                ],
                                'resources': {
                                    'requests': {
                                        'cpu': '100m',
                                        'memory': '128Mi'
                                    },
                                    'limits': {
                                        'cpu': '500m',
                                        'memory': '512Mi'
                                    }
                                },
                                'livenessProbe': {
                                    'httpGet': {
                                        'path': '/health',
                                        'port': 8080
                                    },
                                    'initialDelaySeconds': 30,
                                    'periodSeconds': 10
                                },
                                'readinessProbe': {
                                    'httpGet': {
                                        'path': '/ready',
                                        'port': 8080
                                    },
                                    'initialDelaySeconds': 5,
                                    'periodSeconds': 5
                                }
                            }
                        ],
                        'volumes': [
                            {
                                'name': 'config-volume',
                                'configMap': {
                                    'name': self.config.configmap_name
                                }
                            }
                        ],
                        'restartPolicy': 'Always'
                    }
                }
            }
        }
    
    def _generate_service(self) -> Dict[str, Any]:
        """Generate service manifest"""
        return {
            'apiVersion': 'v1',
            'kind': 'Service',
            'metadata': {
                'name': self.config.service_name,
                'namespace': self.config.namespace,
                'labels': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                }
            },
            'spec': {
                'selector': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                },
                'ports': [
                    {
                        'port': 8080,
                        'targetPort': 8080,
                        'protocol': 'TCP',
                        'name': 'http'
                    }
                ],
                'type': 'ClusterIP',
                'sessionAffinity': 'None'
            }
        }
    
    def _generate_ingress(self) -> Dict[str, Any]:
        """Generate ingress manifest"""
        return {
            'apiVersion': 'networking.k8s.io/v1',
            'kind': 'Ingress',
            'metadata': {
                'name': self.config.ingress_name,
                'namespace': self.config.namespace,
                'labels': {
                    'app': 'grafana-token-service',
                    'component': 'token-management'
                },
                'annotations': {
                    'nginx.ingress.kubernetes.io/rewrite-target': '/',
                    'nginx.ingress.kubernetes.io/ssl-redirect': 'true',
                    'cert-manager.io/cluster-issuer': 'letsencrypt-prod'
                }
            },
            'spec': {
                'tls': [
                    {
                        'hosts': ['grafana-tokens.terradev.local'],
                        'secretName': 'grafana-tokens-tls'
                    }
                ],
                'rules': [
                    {
                        'host': 'grafana-tokens.terradev.local',
                        'http': {
                            'paths': [
                                {
                                    'path': '/api/tokens',
                                    'pathType': 'Prefix',
                                    'backend': {
                                        'service': {
                                            'name': self.config.service_name,
                                            'port': {
                                                'number': 8080
                                            }
                                        }
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    
    def _generate_rbac(self) -> Dict[str, Any]:
        """Generate RBAC manifests"""
        return {
            'role': {
                'apiVersion': 'rbac.authorization.k8s.io/v1',
                'kind': 'Role',
                'metadata': {
                    'name': 'grafana-token-service-role',
                    'namespace': self.config.namespace
                },
                'rules': [
                    {
                        'apiGroups': [''],
                        'resources': ['configmaps', 'secrets', 'pods', 'services'],
                        'verbs': ['get', 'list', 'watch', 'create', 'update', 'patch', 'delete']
                    },
                    {
                        'apiGroups': ['apps'],
                        'resources': ['deployments'],
                        'verbs': ['get', 'list', 'watch', 'create', 'update', 'patch', 'delete']
                    }
                ]
            },
            'role_binding': {
                'apiVersion': 'rbac.authorization.k8s.io/v1',
                'kind': 'RoleBinding',
                'metadata': {
                    'name': 'grafana-token-service-rolebinding',
                    'namespace': self.config.namespace
                },
                'subjects': [
                    {
                        'kind': 'ServiceAccount',
                        'name': self.config.service_account_name,
                        'namespace': self.config.namespace
                    }
                ],
                'roleRef': {
                    'kind': 'Role',
                    'name': 'grafana-token-service-role',
                    'apiGroup': 'rbac.authorization.k8s.io'
                }
            }
        }
    
    def _encode_base64(self, value: str) -> str:
        """Encode string to base64"""
        import base64
        return base64.b64encode(value.encode()).decode()
    
    def save_manifests(self, output_dir: str) -> None:
        """Save all manifests to files"""
        import os
        
        os.makedirs(output_dir, exist_ok=True)
        
        manifests = self.generate_kubernetes_manifests()
        
        for name, manifest in manifests.items():
            filename = f"{name}.yaml"
            filepath = os.path.join(output_dir, filename)
            
            with open(filepath, 'w') as f:
                if name == 'rbac':
                    # RBAC has multiple resources
                    for resource_name, resource_manifest in manifest.items():
                        f.write(f"---\n")
                        yaml.dump(resource_manifest, f, default_flow_style=False)
                        f.write("\n")
                else:
                    yaml.dump(manifest, f, default_flow_style=False)
            
            logger.info(f"Manifest saved: {filepath}")
    
    def create_token_for_service(self, service_name: str, 
                                 permissions: List[str] = None,
                                 scopes: List[str] = None,
                                 expires_in_days: int = 365) -> Dict[str, Any]:
        """Create token for specific Kubernetes service"""
        token = self.token_manager.create_service_account_token(
            name=f"k8s-{service_name}-token",
            service_account_name=f"k8s-{service_name}",
            token_type=TokenType.SERVICE_ACCOUNT,
            permissions=permissions or ["read", "write"],
            scopes=scopes or ["api"],
            expires_in_days=expires_in_days,
            rotation_enabled=True,
            rotation_interval_days=90
        )
        
        # Create Kubernetes secret for the service
        secret_data = {
            'apiVersion': 'v1',
            'kind': 'Secret',
            'metadata': {
                'name': f"{service_name}-grafana-token",
                'namespace': self.config.namespace,
                'labels': {
                    'app': service_name,
                    'component': 'grafana-token'
                },
                'annotations': {
                    'grafana-token-id': token.token_id,
                    'created-by': 'grafana-token-service'
                }
            },
            'type': 'Opaque',
            'data': {
                'token': self._encode_base64(token.token_value),
                'token-id': self._encode_base64(token.token_id),
                'service-account': self._encode_base64(token.service_account_name),
                'permissions': self._encode_base64(json.dumps(token.permissions)),
                'scopes': self._encode_base64(json.dumps(token.scopes)),
                'expires-at': self._encode_base64(token.expires_at.isoformat() if token.expires_at else '')
            }
        }
        
        return {
            'token': token,
            'secret': secret_data
        }

# Example usage
if __name__ == "__main__":
    # Configuration
    config = KubernetesConfig(
        namespace="grafana-token-service",
        service_account_name="grafana-token-service",
        configmap_name="grafana-token-config",
        secret_name="grafana-token-secrets",
        deployment_name="grafana-token-service",
        service_name="grafana-token-service",
        ingress_name="grafana-token-ingress"
    )
    
    # Initialize integration
    grafana_url = os.environ.get('GRAFANA_URL', 'http://localhost:3000')
    admin_token = os.environ.get('GRAFANA_ADMIN_TOKEN', 'your_admin_token_here')
    
    integration = GrafanaKubernetesIntegration(grafana_url, admin_token, config)
    
    print("🚀 GRAFANA KUBERNETES INTEGRATION")
    print("=" * 50)
    
    # Generate manifests
    manifests = integration.generate_kubernetes_manifests()
    
    print(f"📋 Generated {len(manifests)} Kubernetes manifests:")
    for name in manifests.keys():
        print(f"   • {name}")
    
    # Save manifests
    integration.save_manifests('k8s-manifests')
    
    # Create token for service
    service_token = integration.create_token_for_service(
        service_name="ml-training-service",
        permissions=["read", "write", "admin"],
        scopes=["api", "dashboards", "datasources"],
        expires_in_days=365
    )
    
    print(f"\n🔑 Service Token Created:")
    print(f"   Token ID: {service_token['token'].token_id}")
    print(f"   Service: ml-training-service")
    print(f"   Permissions: {', '.join(service_token['token'].permissions)}")
    print(f"   Scopes: {', '.join(service_token['token'].scopes)}")
    print(f"   Token: {service_token['token'].token_value}")
    
    print(f"\n📁 Kubernetes manifests saved to: k8s-manifests/")
    print(f"\n🚀 Ready for Kubernetes deployment!")
    print(f"\n📋 Deployment Steps:")
    print(f"   1. kubectl apply -f k8s-manifests/namespace.yaml")
    print(f"   2. kubectl apply -f k8s-manifests/rbac.yaml")
    print(f"   3. kubectl apply -f k8s-manifests/secret.yaml")
    print(f"   4. kubectl apply -f k8s-manifests/configmap.yaml")
    print(f"   5. kubectl apply -f k8s-manifests/deployment.yaml")
    print(f"   6. kubectl apply -f k8s-manifests/service.yaml")
    print(f"   7. kubectl apply -f k8s-manifests/ingress.yaml")
    
    print(f"\n🎯 Kubernetes Integration Features:")
    print("   ✅ Complete Kubernetes manifests")
    print("   ✅ Service account and RBAC")
    print("   ✅ ConfigMap and Secret management")
    print("   ✅ Deployment with health checks")
    print("   ✅ Service and Ingress configuration")
    print("   ✅ Token creation for services")
    print("   ✅ Secure token storage")
    print("   ✅ Automated token rotation")
    print("   ✅ Kubernetes-native deployment")
