#!/usr/bin/env python3
"""
TensorDock Integration for Terradev
Complete API integration for TensorDock GPU cloud services
"""

import os
import json
import asyncio
import aiohttp
import logging
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
import hashlib
import base64
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class TensorDockCredentials:
    """TensorDock API credentials"""
    client_id: str
    api_token: str
    
    def __post_init__(self):
        """Validate credentials"""
        if not self.client_id or not self.api_token:
            raise ValueError("Client ID and API token are required")

@dataclass
class GPUResource:
    """GPU resource specification"""
    model: str
    count: int
    
    def __post_init__(self):
        """Validate GPU resource"""
        if self.count <= 0:
            raise ValueError("GPU count must be positive")

@dataclass
class InstanceResources:
    """Instance resource specification"""
    vcpu_count: int
    ram_gb: int
    storage_gb: int
    gpus: Dict[str, GPUResource]
    
    def __post_init__(self):
        """Validate resources"""
        if self.vcpu_count <= 0:
            raise ValueError("CPU count must be positive")
        if self.ram_gb <= 0:
            raise ValueError("RAM must be positive")
        if self.storage_gb < 100:
            raise ValueError("Storage must be at least 100GB")

@dataclass
class CloudInit:
    """Cloud-init configuration"""
    runcmd: Optional[List[str]] = None
    packages: Optional[List[str]] = None
    package_update: bool = False
    package_upgrade: bool = False
    write_files: Optional[List[Dict[str, Any]]] = None

@dataclass
class InstanceConfig:
    """Instance configuration"""
    name: str
    image: str = "ubuntu2404"
    resources: InstanceResources = None
    location_id: Optional[str] = None
    use_dedicated_ip: bool = True
    ssh_key: Optional[str] = None
    cloud_init: Optional[CloudInit] = None
    
    def __post_init__(self):
        """Validate configuration"""
        if not self.name:
            raise ValueError("Instance name is required")
        if self.resources and not isinstance(self.resources, InstanceResources):
            raise ValueError("Resources must be InstanceResources instance")

@dataclass
class Instance:
    """TensorDock instance"""
    id: str
    name: str
    status: str
    ip_address: Optional[str] = None
    port_forwards: Optional[List[Dict[str, int]]] = None
    resources: Optional[InstanceResources] = None
    rate_hourly: Optional[float] = None
    created_at: Optional[datetime] = None

class TensorDockAPI:
    """TensorDock API client"""
    
    def __init__(self, credentials: TensorDockCredentials, base_url: str = "https://api.tensordock.com"):
        self.credentials = credentials
        self.base_url = base_url.rstrip('/')
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession(
            headers={
                "Authorization": f"Bearer {self.credentials.api_token}",
                "X-Client-ID": self.credentials.client_id,
                "Content-Type": "application/json"
            },
            timeout=aiohttp.ClientTimeout(total=300)
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make API request with error handling"""
        if not self.session:
            raise RuntimeError("Session not initialized. Use async context manager.")
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            async with self.session.request(method, url, json=data) as response:
                if response.status == 200:
                    return await response.json()
                elif response.status == 201:
                    return await response.json()
                elif response.status == 400:
                    error_data = await response.json()
                    raise ValueError(f"Bad request: {error_data.get('message', 'Unknown error')}")
                elif response.status == 401:
                    raise ValueError("Unauthorized: Invalid credentials")
                elif response.status == 403:
                    raise ValueError("Forbidden: Insufficient permissions")
                elif response.status == 404:
                    raise ValueError("Not found: Resource does not exist")
                elif response.status == 429:
                    raise ValueError("Rate limit exceeded")
                elif response.status >= 500:
                    raise ValueError(f"Server error: {response.status}")
                else:
                    error_text = await response.text()
                    raise ValueError(f"Unexpected status {response.status}: {error_text}")
                    
        except aiohttp.ClientError as e:
            logger.error(f"Network error: {e}")
            raise
        except Exception as e:
            logger.error(f"API request failed: {e}")
            raise
    
    async def create_instance(self, config: InstanceConfig) -> Instance:
        """Create a new virtual machine instance"""
        logger.info(f"Creating instance: {config.name}")
        
        # Prepare request data
        request_data = {
            "data": {
                "type": "virtualmachine",
                "attributes": {
                    "name": config.name,
                    "type": "virtualmachine",
                    "image": config.image,
                    "resources": {
                        "vcpu_count": config.resources.vcpu_count,
                        "ram_gb": config.resources.ram_gb,
                        "storage_gb": config.resources.storage_gb,
                        "gpus": {
                            gpu_model: {"count": gpu.count}
                            for gpu_model, gpu in config.resources.gpus.items()
                        }
                    },
                    "useDedicatedIp": config.use_dedicated_ip
                }
            }
        }
        
        # Add optional fields
        if config.location_id:
            request_data["data"]["attributes"]["location_id"] = config.location_id
        
        if config.ssh_key:
            request_data["data"]["attributes"]["ssh_key"] = config.ssh_key
        
        if config.cloud_init:
            cloud_init_data = {}
            if config.cloud_init.runcmd:
                cloud_init_data["runcmd"] = config.cloud_init.runcmd
            if config.cloud_init.packages:
                cloud_init_data["packages"] = config.cloud_init.packages
            if config.cloud_init.package_update:
                cloud_init_data["package_update"] = config.cloud_init.package_update
            if config.cloud_init.package_upgrade:
                cloud_init_data["package_upgrade"] = config.cloud_init.package_upgrade
            if config.cloud_init.write_files:
                cloud_init_data["write_files"] = config.cloud_init.write_files
            
            if cloud_init_data:
                request_data["data"]["attributes"]["cloud_init"] = cloud_init_data
        
        # Make API request
        response_data = await self._make_request("POST", "/api/v2/instances", request_data)
        
        # Parse response
        instance_data = response_data.get("data", {})
        
        return Instance(
            id=instance_data.get("id", ""),
            name=instance_data.get("name", config.name),
            status=instance_data.get("status", "unknown"),
            created_at=datetime.utcnow()
        )
    
    async def list_instances(self) -> List[Instance]:
        """List all virtual machine instances"""
        logger.info("Listing instances")
        
        response_data = await self._make_request("GET", "/api/v2/instances")
        
        instances = []
        for instance_data in response_data.get("data", {}).get("instances", []):
            # Parse resources
            resources_data = instance_data.get("resources", {})
            gpus = {}
            for gpu_model, gpu_info in resources_data.get("gpus", {}).items():
                gpus[gpu_model] = GPUResource(
                    model=gpu_model,
                    count=gpu_info.get("count", 1)
                )
            
            resources = InstanceResources(
                vcpu_count=resources_data.get("vcpu_count", 0),
                ram_gb=resources_data.get("ram_gb", 0),
                storage_gb=resources_data.get("storage_gb", 0),
                gpus=gpus
            )
            
            instance = Instance(
                id=instance_data.get("id", ""),
                name=instance_data.get("name", ""),
                status=instance_data.get("status", "unknown"),
                ip_address=instance_data.get("ipAddress"),
                port_forwards=instance_data.get("portForwards", []),
                resources=resources,
                rate_hourly=instance_data.get("rateHourly")
            )
            instances.append(instance)
        
        return instances
    
    async def get_instance(self, instance_id: str) -> Instance:
        """Get details about a specific instance"""
        logger.info(f"Getting instance: {instance_id}")
        
        response_data = await self._make_request("GET", f"/api/v2/instances/{instance_id}")
        
        # Parse response (similar to list_instances)
        instance_data = response_data
        
        resources_data = instance_data.get("resources", {})
        gpus = {}
        for gpu_model, gpu_info in resources_data.get("gpus", {}).items():
            gpus[gpu_model] = GPUResource(
                model=gpu_model,
                count=gpu_info.get("count", 1)
            )
        
        resources = InstanceResources(
            vcpu_count=resources_data.get("vcpu_count", 0),
            ram_gb=resources_data.get("ram_gb", 0),
            storage_gb=resources_data.get("storage_gb", 0),
            gpus=gpus
        )
        
        return Instance(
            id=instance_data.get("id", instance_id),
            name=instance_data.get("name", ""),
            status=instance_data.get("status", "unknown"),
            ip_address=instance_data.get("ipAddress"),
            port_forwards=instance_data.get("portForwards", []),
            resources=resources,
            rate_hourly=instance_data.get("rateHourly")
        )
    
    async def start_instance(self, instance_id: str) -> bool:
        """Start a stopped instance"""
        logger.info(f"Starting instance: {instance_id}")
        
        try:
            await self._make_request("POST", f"/api/v2/instances/{instance_id}/start")
            return True
        except Exception as e:
            logger.error(f"Failed to start instance {instance_id}: {e}")
            return False
    
    async def stop_instance(self, instance_id: str) -> bool:
        """Stop a running instance"""
        logger.info(f"Stopping instance: {instance_id}")
        
        try:
            await self._make_request("POST", f"/api/v2/instances/{instance_id}/stop")
            return True
        except Exception as e:
            logger.error(f"Failed to stop instance {instance_id}: {e}")
            return False
    
    async def delete_instance(self, instance_id: str) -> bool:
        """Delete an instance"""
        logger.info(f"Deleting instance: {instance_id}")
        
        try:
            await self._make_request("DELETE", f"/api/v2/instances/{instance_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete instance {instance_id}: {e}")
            return False
    
    async def modify_instance(self, instance_id: str, resources: InstanceResources) -> bool:
        """Modify instance resources"""
        logger.info(f"Modifying instance: {instance_id}")
        
        request_data = {
            "cpuCores": resources.vcpu_count,
            "ramGb": resources.ram_gb,
            "diskGb": resources.storage_gb,
            "gpus": {
                gpu_model: {
                    "gpuV0Name": gpu_model,
                    "count": gpu.count
                }
                for gpu_model, gpu in resources.gpus.items()
            }
        }
        
        try:
            await self._make_request("PUT", f"/api/v2/instances/{instance_id}/modify", request_data)
            return True
        except Exception as e:
            logger.error(f"Failed to modify instance {instance_id}: {e}")
            return False

class TensorDockManager:
    """High-level TensorDock management for Terradev"""
    
    def __init__(self, credentials: TensorDockCredentials):
        self.credentials = credentials
        self.api = TensorDockAPI(credentials)
        
    async def create_ml_instance(self, name: str, gpu_model: str = "geforcertx4090-pcie-24gb", 
                                gpu_count: int = 1, cpu_cores: int = 8, ram_gb: int = 32, 
                                storage_gb: int = 200) -> Instance:
        """Create a machine learning instance with optimized configuration"""
        
        # Configure resources
        gpus = {
            gpu_model: GPUResource(model=gpu_model, count=gpu_count)
        }
        
        resources = InstanceResources(
            vcpu_count=cpu_cores,
            ram_gb=ram_gb,
            storage_gb=storage_gb,
            gpus=gpus
        )
        
        # Configure cloud-init for ML setup
        cloud_init = CloudInit(
            package_update=True,
            package_upgrade=True,
            packages=[
                "python3", "python3-pip", "python3-venv", "git", "curl", "wget",
                "build-essential", "cuda-toolkit", "nvidia-driver-535",
                "docker.io", "docker-compose", "nginx", "htop"
            ],
            runcmd=[
                "systemctl enable docker",
                "usermod -aG docker ubuntu",
                "pip3 install --upgrade pip",
                "pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118",
                "pip3 install tensorflow-gpu==2.13.0",
                "pip3 install jupyterlab pandas numpy scikit-learn matplotlib seaborn"
            ],
            write_files=[
                {
                    "path": "/home/ubuntu/.bashrc",
                    "content": 'export PATH=$PATH:/usr/local/cuda/bin\nexport LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda/lib64\n',
                    "owner": "ubuntu:ubuntu",
                    "permissions": "0644"
                },
                {
                    "path": "/etc/motd",
                    "content": "🚀 Welcome to your Terradev ML Instance!\n🔥 GPU Accelerated Machine Learning Ready\n💡 JupyterLab: http://<IP>:8888",
                    "owner": "root:root",
                    "permissions": "0644"
                }
            ]
        )
        
        # Create instance configuration
        config = InstanceConfig(
            name=name,
            image="ubuntu2404",
            resources=resources,
            use_dedicated_ip=True,
            cloud_init=cloud_init
        )
        
        # Create instance
        async with self.api as api:
            instance = await api.create_instance(config)
            logger.info(f"Created ML instance: {instance.id}")
            return instance
    
    async def create_training_cluster(self, cluster_name: str, node_count: int = 3, 
                                   gpu_per_node: int = 2) -> List[Instance]:
        """Create a distributed training cluster"""
        
        instances = []
        
        for i in range(node_count):
            node_name = f"{cluster_name}-node-{i+1}"
            
            try:
                instance = await self.create_ml_instance(
                    name=node_name,
                    gpu_count=gpu_per_node,
                    cpu_cores=16,
                    ram_gb=64,
                    storage_gb=500
                )
                instances.append(instance)
                logger.info(f"Created cluster node: {node_name}")
                
            except Exception as e:
                logger.error(f"Failed to create cluster node {node_name}: {e}")
                # Clean up created instances
                for instance in instances:
                    await self.delete_instance(instance.id)
                raise
        
        return instances
    
    async def get_instance_costs(self, instance_id: str, hours: int = 24) -> float:
        """Calculate instance costs for specified hours"""
        
        async with self.api as api:
            instance = await api.get_instance(instance_id)
            if instance.rate_hourly:
                return instance.rate_hourly * hours
            return 0.0
    
    async def cleanup_expired_instances(self, max_age_hours: int = 24) -> List[str]:
        """Clean up instances older than specified hours"""
        
        cutoff_time = datetime.utcnow() - timedelta(hours=max_age_hours)
        cleaned_instances = []
        
        async with self.api as api:
            instances = await api.list_instances()
            
            for instance in instances:
                if instance.created_at and instance.created_at < cutoff_time:
                    if await api.delete_instance(instance.id):
                        cleaned_instances.append(instance.id)
                        logger.info(f"Cleaned up expired instance: {instance.id}")
        
        return cleaned_instances
    
    async def get_cluster_status(self, cluster_name: str) -> Dict[str, Any]:
        """Get status of all instances in a cluster"""
        
        async with self.api as api:
            instances = await api.list_instances()
            
            cluster_instances = [
                instance for instance in instances 
                if instance.name.startswith(cluster_name)
            ]
            
            status = {
                "cluster_name": cluster_name,
                "total_nodes": len(cluster_instances),
                "running_nodes": len([i for i in cluster_instances if i.status == "running"]),
                "stopped_nodes": len([i for i in cluster_instances if i.status == "stopped"]),
                "total_gpus": sum(
                    sum(gpu.count for gpu in instance.resources.gpus.values()) 
                    for instance in cluster_instances 
                    if instance.resources
                ),
                "hourly_cost": sum(
                    instance.rate_hourly or 0 
                    for instance in cluster_instances
                ),
                "instances": [
                    {
                        "id": instance.id,
                        "name": instance.name,
                        "status": instance.status,
                        "ip": instance.ip_address,
                        "gpus": instance.resources.gpus if instance.resources else {}
                    }
                    for instance in cluster_instances
                ]
            }
            
            return status

# Example usage and testing
async def main():
    """Example usage of TensorDock integration"""
    
    # Initialize credentials (use environment variables in production)
    credentials = TensorDockCredentials(
        client_id="6f71b631-5a32-42f1-94a5-d089adffdb24",
        api_token = os.environ.get("TOKEN_API_TOKEN", "rxOI1pnIZ9UL3J8MZmMmYBkKk7EwPdyS")
    )
    
    # Initialize manager
    manager = TensorDockManager(credentials)
    
    try:
        # Create a single ML instance
        logging.info("Creating ML instance...")
        instance = await manager.create_ml_instance(
            name="terradev-ml-instance",
            gpu_model="geforcertx4090-pcie-24gb",
            gpu_count=1,
            cpu_cores=8,
            ram_gb=32,
            storage_gb=200
        )
        logging.info(f"Created instance: {instance.id}")
        
        # List all instances
        logging.info("\nListing instances...")
        instances = await manager.api.list_instances()
        for instance in instances:
            logging.info(f"Instance: {instance.name} ({instance.id})
        
        # Get instance details
        if instances:
            logging.info(f"\nGetting details for instance: {instances[0].id}")
            details = await manager.api.get_instance(instances[0].id)
            logging.info(f"Details: {details.name} - IP: {details.ip_address} - Cost: ${details.rate_hourly}/hour")
        
        # Calculate costs
        if instances:
            cost = await manager.get_instance_costs(instances[0].id, 24)
            logging.info(f"\n24-hour cost: ${cost:.2f}")
        
        # Clean up (comment out in production)
        # print("\nCleaning up test instance...")
        # await manager.api.delete_instance(instance.id)
        # print("Instance deleted")
        
    except Exception as e:
        logger.error(f"Example failed: {e}")

if __name__ == "__main__":
    asyncio.run(main())
