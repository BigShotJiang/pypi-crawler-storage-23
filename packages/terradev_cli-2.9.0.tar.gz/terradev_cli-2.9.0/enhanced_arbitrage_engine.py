#!/usr/bin/env python3
"""
Enhanced Arbitrage Engine with Advanced Risk Factors
Integrates Greeks, volatility, TOU, and sophisticated risk modeling
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import statistics

# Import existing components
from complete_arbitrage_engine import ArbitrageEngine, ArbitrageOpportunity, InstanceInfo, Provider, GPUType
from advanced_risk_engine import AdvancedRiskEngine, AdvancedRiskMetrics
from vast_ai_integration import VastArbitrageIntegration

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class EnhancedArbitrageOpportunity:
    """Enhanced arbitrage opportunity with advanced risk factors"""
    provider: Provider
    instance_type: str
    gpu_type: GPUType
    base_price: float
    risk_adjusted_price: float
    volatility_adjusted_price: float
    tou_adjusted_price: float
    final_adjusted_price: float
    success_probability: float
    confidence_score: float
    latency_score: float
    total_score: float
    greeks: Dict[str, float]
    volatility_metrics: Dict[str, float]
    risk_metrics: Dict[str, float]
    tou_multiplier: float
    var_95: float
    expected_shortfall: float
    liquidity_risk: float
    correlation_risk: float
    reasoning: List[str]
    instance_info: InstanceInfo

class EnhancedArbitrageEngine:
    """
    Enhanced arbitrage engine with advanced risk factors
    Integrates Greeks, volatility, TOU, and sophisticated risk modeling
    """
    
    def __init__(self):
        # Initialize base arbitrage engine
        self.base_engine = ArbitrageEngine()
        
        # Initialize advanced risk engine
        self.advanced_risk_engine = AdvancedRiskEngine()
        
        # Initialize Vast.ai integration
        self.vast_integration = VastArbitrageIntegration(
            "49bc6b3b9d019ec3fcd731a60be4bb13c98f3ff8721615a2e3b4ad12cf079ea4"
        )
        
        # Risk factor weights
        self.risk_weights = {
            "base_price": 0.25,
            "volatility": 0.20,
            "greeks": 0.15,
            "tou": 0.10,
            "liquidity": 0.10,
            "correlation": 0.10,
            "var": 0.05,
            "expected_shortfall": 0.05
        }
        
        # Risk thresholds
        self.risk_thresholds = {
            "max_volatility": 2.0,  # 200% annualized volatility
            "max_var_ratio": 0.1,  # VaR should not exceed 10% of price
            "max_liquidity_risk": 0.8,  # Maximum acceptable liquidity risk
            "min_confidence": 0.6,  # Minimum confidence score
            "max_gamma": 0.1,  # Maximum acceptable gamma (convexity)
            "max_theta_abs": 0.1  # Maximum absolute theta (time decay)
        }
    
    async def scan_all_providers_with_risk(self, force_refresh: bool = False) -> Dict[Provider, List[InstanceInfo]]:
        """Scan all providers and update risk data"""
        
        # Get base instances
        instances = await self.base_engine.scan_all_providers(force_refresh)
        
        # Update price data for risk calculations
        for provider, provider_instances in instances.items():
            for instance in provider_instances:
                # Simulate some price history for demonstration
                # In production, this would come from real historical data
                self.advanced_risk_engine.update_price_data(
                    provider.value,
                    instance.instance_type,
                    instance.hourly_cost,
                    volume=100  # Default volume
                )
        
        return instances
    
    async def calculate_enhanced_opportunity(self, instance: InstanceInfo) -> EnhancedArbitrageOpportunity:
        """Calculate enhanced arbitrage opportunity with advanced risk factors"""
        
        # Get advanced risk metrics
        risk_metrics = self.advanced_risk_engine.calculate_advanced_risk_metrics(
            instance.provider.value,
            instance.instance_type,
            instance.region,
            datetime.now()
        )
        
        # Calculate base score
        base_score = self._calculate_base_score(instance)
        
        # Calculate volatility penalty
        volatility_penalty = self._calculate_volatility_penalty(risk_metrics.volatility)
        
        # Calculate Greeks penalty
        greeks_penalty = self._calculate_greeks_penalty(risk_metrics)
        
        # Calculate TOU adjustment
        tou_adjustment = risk_metrics.tou_adjustment
        
        # Calculate liquidity penalty
        liquidity_penalty = risk_metrics.liquidity_risk * 0.2
        
        # Calculate correlation penalty
        correlation_penalty = risk_metrics.correlation_risk * 0.1
        
        # Calculate VaR penalty
        var_penalty = self._calculate_var_penalty(risk_metrics.var_95, risk_metrics.base_price)
        
        # Calculate expected shortfall penalty
        es_penalty = self._calculate_expected_shortfall_penalty(
            risk_metrics.expected_shortfall, risk_metrics.base_price
        )
        
        # Calculate final adjusted price
        volatility_adjusted_price = risk_metrics.base_price * (1 + volatility_penalty)
        tou_adjusted_price = volatility_adjusted_price * tou_adjustment
        final_adjusted_price = tou_adjusted_price * (1 + liquidity_penalty + correlation_penalty + var_penalty + es_penalty)
        
        # Calculate enhanced success probability
        base_success_prob = 0.85  # Base success probability
        volatility_factor = max(0.5, 1 - risk_metrics.volatility / 2.0)  # Volatility reduces success
        liquidity_factor = max(0.7, 1 - risk_metrics.liquidity_risk)  # Liquidity affects success
        correlation_factor = max(0.8, 1 - risk_metrics.correlation_risk * 0.5)  # Correlation affects success
        
        enhanced_success_probability = base_success_prob * volatility_factor * liquidity_factor * correlation_factor
        
        # Calculate enhanced confidence score
        confidence_factors = {
            "base": base_score,
            "volatility": max(0, 1 - volatility_penalty),
            "greeks": max(0, 1 - greeks_penalty),
            "liquidity": max(0, 1 - liquidity_penalty),
            "correlation": max(0, 1 - correlation_penalty),
            "var": max(0, 1 - var_penalty),
            "es": max(0, 1 - es_penalty)
        }
        
        confidence_score = (
            confidence_factors["base"] * 0.4 +
            confidence_factors["volatility"] * 0.2 +
            confidence_factors["greeks"] * 0.15 +
            confidence_factors["liquidity"] * 0.1 +
            confidence_factors["correlation"] * 0.1 +
            confidence_factors["var"] * 0.05 +
            confidence_factors["es"] * 0.05
        )
        
        # Calculate total score
        total_score = (
            confidence_score * 0.4 +
            (1 - volatility_penalty) * 0.2 +
            (1 - greeks_penalty) * 0.15 +
            (1 - liquidity_penalty) * 0.1 +
            (1 - correlation_penalty) * 0.1 +
            (1 - var_penalty) * 0.05 +
            (1 - es_penalty) * 0.05
        )
        
        # Generate enhanced reasoning
        reasoning = [
            f"Base Price: ${risk_metrics.base_price:.2f}",
            f"Volatility: {risk_metrics.volatility:.1%} (Penalty: {volatility_penalty:.1%})",
            f"Delta: {risk_metrics.delta:.3f}, Gamma: {risk_metrics.gamma:.3f}",
            f"TOU Multiplier: {tou_adjustment:.2f}x",
            f"Liquidity Risk: {risk_metrics.liquidity_risk:.1%}",
            f"Correlation Risk: {risk_metrics.correlation_risk:.1%}",
            f"VaR (95%): ${risk_metrics.var_95:.2f}",
            f"Expected Shortfall: ${risk_metrics.expected_shortfall:.2f}",
            f"Final Adjusted Price: ${final_adjusted_price:.2f}",
            f"Enhanced Success Probability: {enhanced_success_probability:.1%}"
        ]
        
        return EnhancedArbitrageOpportunity(
            provider=instance.provider,
            instance_type=instance.instance_type,
            gpu_type=instance.gpu_type,
            base_price=risk_metrics.base_price,
            risk_adjusted_price=risk_metrics.risk_adjusted_price,
            volatility_adjusted_price=volatility_adjusted_price,
            tou_adjusted_price=tou_adjusted_price,
            final_adjusted_price=final_adjusted_price,
            success_probability=enhanced_success_probability,
            confidence_score=enhanced_confidence_score,
            latency_score=0.8,  # Default latency score
            total_score=total_score,
            greeks={
                "delta": risk_metrics.delta,
                "gamma": risk_metrics.gamma,
                "theta": risk_metrics.theta,
                "vega": risk_metrics.vega
            },
            volatility_metrics={
                "current_volatility": risk_metrics.volatility,
                "confidence_interval": risk_metrics.confidence_interval
            },
            risk_metrics={
                "var_95": risk_metrics.var_95,
                "expected_shortfall": risk_metrics.expected_shortfall,
                "liquidity_risk": risk_metrics.liquidity_risk,
                "correlation_risk": risk_metrics.correlation_risk
            },
            tou_multiplier=tou_adjustment,
            var_95=risk_metrics.var_95,
            expected_shortfall=risk_metrics.expected_shortfall,
            liquidity_risk=risk_metrics.liquidity_risk,
            correlation_risk=risk_metrics.correlation_risk,
            reasoning=reasoning,
            instance_info=instance
        )
    
    def _calculate_base_score(self, instance: InstanceInfo) -> float:
        """Calculate base score from instance attributes"""
        
        # Provider reliability score
        provider_scores = {
            Provider.AWS: 0.95,
            Provider.GCP: 0.90,
            Provider.RUNPOD: 0.85,
            Provider.VAST: 0.80
        }
        
        provider_score = provider_scores.get(instance.provider, 0.8)
        
        # Cost score (lower is better)
        max_cost = 10.0
        cost_score = max(0, 1 - (instance.hourly_cost / max_cost))
        
        # Performance score (based on GPU type)
        gpu_scores = {
            GPUType.A100: 0.95,
            GPUType.V100: 0.85,
            GPUType.A10G: 0.75,
            GPUType.T4: 0.65,
            GPUType.RTXA6000: 0.80
        }
        
        gpu_score = gpu_scores.get(instance.gpu_type, 0.7)
        
        # Combine scores
        base_score = (provider_score * 0.4 + cost_score * 0.3 + gpu_score * 0.3)
        
        return base_score
    
    def _calculate_volatility_penalty(self, volatility: float) -> float:
        """Calculate penalty based on volatility"""
        
        if volatility <= self.risk_thresholds["max_volatility"]:
            return 0.0
        else:
            # Exponential penalty for high volatility
            excess_volatility = volatility - self.risk_thresholds["max_volatility"]
            return min(0.5, excess_volatility / self.risk_thresholds["max_volatility"])
    
    def _calculate_greeks_penalty(self, risk_metrics: AdvancedRiskMetrics) -> float:
        """Calculate penalty based on Greeks"""
        
        penalties = []
        
        # Gamma penalty (convexity risk)
        if abs(risk_metrics.gamma) > self.risk_thresholds["max_gamma"]:
            gamma_penalty = (abs(risk_metrics.gamma) - self.risk_thresholds["max_gamma"]) * 2
            penalties.append(gamma_penalty)
        
        # Theta penalty (time decay)
        if abs(risk_metrics.theta) > self.risk_thresholds["max_theta_abs"]:
            theta_penalty = (abs(risk_metrics.theta) - self.risk_thresholds["max_theta_abs"]) * 2
            penalties.append(theta_penalty)
        
        # Vega penalty (volatility sensitivity)
        if risk_metrics.vega > 0.01:  # High vega sensitivity
            vega_penalty = risk_metrics.vega * 10
            penalties.append(vega_penalty)
        
        return min(0.5, sum(penalties))
    
    def _calculate_var_penalty(self, var_95: float, base_price: float) -> float:
        """Calculate penalty based on Value at Risk"""
        
        var_ratio = var_95 / base_price if base_price > 0 else 0
        
        if var_ratio <= self.risk_thresholds["max_var_ratio"]:
            return 0.0
        else:
            return min(0.3, (var_ratio - self.risk_thresholds["max_var_ratio"]) * 3)
    
    def _calculate_expected_shortfall_penalty(self, expected_shortfall: float, base_price: float) -> float:
        """Calculate penalty based on Expected Shortfall"""
        
        es_ratio = expected_shortfall / base_price if base_price > 0 else 0
        
        # Expected shortfall should be small relative to price
        if es_ratio <= 0.05:  # 5% threshold
            return 0.0
        else:
            return min(0.2, (es_ratio - 0.05) * 2)
    
    async def find_enhanced_arbitrage_opportunities(self, 
                                                      gpu_type: GPUType,
                                                      max_results: int = 5) -> List[EnhancedArbitrageOpportunity]:
        """Find enhanced arbitrage opportunities with advanced risk factors"""
        
        logger.info(f"🔍 Finding enhanced arbitrage opportunities for {gpu_type.value}")
        
        # Scan all providers with risk data
        all_instances = await self.scan_all_providers_with_risk()
        
        # Filter by GPU type
        matching_instances = []
        for provider, instances in all_instances.items():
            for instance in instances:
                if instance.gpu_type == gpu_type and instance.availability:
                    matching_instances.append(instance)
        
        logger.info(f"📊 Found {len(matching_instances)} matching instances")
        
        # Calculate enhanced opportunities
        opportunities = []
        
        for instance in matching_instances:
            opportunity = await self.calculate_enhanced_opportunity(instance)
            
            # Filter out high-risk opportunities
            if (opportunity.confidence_score >= self.risk_thresholds["min_confidence"] and
                opportunity.liquidity_risk <= self.risk_thresholds["max_liquidity_risk"]):
                opportunities.append(opportunity)
        
        # Sort by total score (descending)
        opportunities.sort(key=lambda x: x.total_score, reverse=True)
        
        return opportunities[:max_results]
    
    async def execute_enhanced_arbitrage_decision(self, 
                                                   gpu_type: GPUType,
                                                   max_budget: float = 5.0) -> Optional[EnhancedArbitrageOpportunity]:
        """Execute enhanced arbitrage decision with advanced risk factors"""
        
        logger.info(f"🚀 Executing enhanced arbitrage decision for {gpu_type.value}")
        logger.info(f"💰 Maximum budget: ${max_budget:.2f}/hour")
        
        # Find enhanced opportunities
        opportunities = await self.find_enhanced_arbitrage_opportunities(gpu_type)
        
        # Filter by budget
        affordable_opportunities = [
            opp for opp in opportunities 
            if opp.final_adjusted_price <= max_budget
        ]
        
        if not affordable_opportunities:
            logger.warning(f"❌ No affordable opportunities found for {gpu_type.value}")
            return None
        
        # Select best opportunity
        best_opportunity = affordable_opportunities[0]
        
        logger.info(f"🏆 Best enhanced opportunity selected:")
        logger.info(f"   Provider: {best_opportunity.provider.value}")
        logger.info(f"   Instance: {best_opportunity.instance_type}")
        logger.info(f"   Base Price: ${best_opportunity.base_price:.2f}/hour")
        logger.info(f"   Final Adjusted Price: ${best_opportunity.final_adjusted_price:.2f}/hour")
        logger.info(f"   Enhanced Score: {best_opportunity.total_score:.1%}")
        logger.info(f"   Success Probability: {best_opportunity.success_probability:.1%}")
        
        return best_opportunity

# Test the enhanced arbitrage engine
async def test_enhanced_arbitrage_engine():
    """Test the enhanced arbitrage engine with advanced risk factors"""
    
    logging.info("🚀 Testing Enhanced Arbitrage Engine")
    logging.info("=" * 60)
    
    engine = EnhancedArbitrageEngine()
    
    # Test 1: Scan all providers with risk data
    logging.info("\n📊 Scanning All Providers with Risk Data...")
    all_instances = await engine.scan_all_providers_with_risk()
    
    total_instances = sum(len(instances) for instances in all_instances.values())
    logging.info(f"✅ Total instances found: {total_instances}")
    
    for provider, instances in all_instances.items():
        logging.info(f"   {provider.value}: {len(instances)
    
    # Test 2: Find enhanced arbitrage opportunities for A100
    logging.info("\n🔍 Finding Enhanced A100 Arbitrage Opportunities...")
    opportunities = await engine.find_enhanced_arbitrage_opportunities(GPUType.A100)
    
    logging.info(f"✅ Found {len(opportunities)
    
    for i, opp in enumerate(opportunities, 1):
        logging.info(f"\n{i}. {opp.provider.value} - {opp.instance_type}")
        logging.info(f"   Base Price: ${opp.base_price:.2f}/hour")
        logging.info(f"   Final Adjusted Price: ${opp.final_adjusted_price:.2f}/hour")
        logging.info(f"   Success Probability: {opp.success_probability:.1%}")
        logging.info(f"   Confidence Score: {opp.confidence_score:.1%}")
        logging.info(f"   Total Score: {opp.total_score:.1%}")
        logging.info(f"   Volatility: {opp.volatility_metrics['current_volatility']:.1%}")
        logging.info(f"   VaR (95%)
        logging.info(f"   Liquidity Risk: {opp.liquidity_risk:.1%}")
        logging.info(f"   TOU Multiplier: {opp.tou_multiplier:.2f}x")
        
        logging.info(f"   Greeks:")
        for greek, value in opp.greeks.items():
            logging.info(f"     {greek}: {value:.3f}")
        
        logging.info(f"   Risk Reasoning:")
        for reason in opp.reasoning[:5]:  # Show first 5 reasons
            logging.info(f"     • {reason}")
    
    # Test 3: Execute enhanced arbitrage decision
    logging.info("\n🚀 Executing Enhanced Arbitrage Decision...")
    decision = await engine.execute_enhanced_arbitrage_decision(GPUType.A100, max_budget=10.0)
    
    if decision:
        logging.info(f"🏆 Enhanced Decision Made:")
        logging.info(f"   Provider: {decision.provider.value}")
        logging.info(f"   Instance: {decision.instance_type}")
        logging.info(f"   Base Price: ${decision.base_price:.2f}/hour")
        logging.info(f"   Final Adjusted Price: ${decision.final_adjusted_price:.2f}/hour")
        logging.info(f"   Confidence: {decision.confidence_score:.1%}")
        logging.info(f"   Success Probability: {decision.success_probability:.1%}")
        logging.info(f"   Total Score: {decision.total_score:.1%}")
        
        logging.info(f"\n📊 Risk Analysis:")
        logging.info(f"   Volatility: {decision.volatility_metrics['current_volatility']:.1%}")
        logging.info(f"   VaR (95%)
        logging.info(f"   Expected Shortfall: ${decision.expected_shortfall:.2f}")
        logging.info(f"   Liquidity Risk: {decision.liquidity_risk:.1%}")
        logging.info(f"   Correlation Risk: {decision.correlation_risk:.1%}")
        
        logging.info(f"\n📈 Greeks Analysis:")
        for greek, value in decision.greeks.items():
            logging.info(f"   {greek}: {value:.3f}")
        
        logging.info(f"\n🎯 This is the optimal choice based on advanced risk modeling:")
        for reason in decision.reasoning:
            logging.info(f"   • {reason}")
    else:
        logging.info("❌ No suitable opportunity found")
    
    logging.info("\n🎯 Enhanced Arbitrage Engine Test Completed!")
    logging.info("✅ All advanced risk factors integrated")
    logging.info("✅ Greeks (Delta, Gamma, Theta, Vega, Rho)
    logging.info("✅ Volatility modeling implemented")
    logging.info("✅ TOU pricing adjustments applied")
    logging.info("✅ VaR and Expected Shortfall calculated")
    logging.info("✅ Liquidity and correlation risk modeled")

if __name__ == "__main__":
    asyncio.run(test_enhanced_arbitrage_engine())
