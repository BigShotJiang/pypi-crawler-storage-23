#!/usr/bin/env python3
"""
Terradev Cost Management and Optimization System
Advanced cost analysis, anomaly detection, and optimization recommendations
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import dataclass, asdict
from enum import Enum
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
import sqlalchemy
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
import redis
import aioredis
import prometheus_client
from prometheus_client import Counter, Histogram, Gauge
import structlog

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = structlog.get_logger()

class CostAnomalyType(str, Enum):
    """Cost anomaly types"""
    SPIKE = "spike"
    DRIFT = "drift"
    UNUSUAL_PATTERN = "unusual_pattern"
    BUDGET_BREACH = "budget_breach"
    EFFICIENCY_DROP = "efficiency_drop"

class OptimizationType(str, Enum):
    """Optimization recommendation types"""
    SPOT_MIGRATION = "spot_migration"
    PROVIDER_SWITCH = "provider_switch"
    RIGHT_SIZING = "right_sizing"
    SCHEDULED_SHUTDOWN = "scheduled_shutdown"
    RESERVATION_PURCHASE = "reservation_purchase"
    REGION_OPTIMIZATION = "region_optimization"

@dataclass
class CostMetrics:
    """Cost metrics for analysis"""
    timestamp: datetime
    user_id: str
    provider: str
    gpu_type: str
    instance_type: str
    hourly_cost: float
    runtime_hours: float
    total_cost: float
    utilization: float
    region: str
    deployment_id: Optional[str] = None

@dataclass
class CostAnomaly:
    """Cost anomaly detection result"""
    anomaly_id: str
    user_id: str
    anomaly_type: CostAnomalyType
    severity: str  # low, medium, high, critical
    detected_at: datetime
    description: str
    affected_metrics: Dict[str, float]
    baseline_values: Dict[str, float]
    confidence_score: float
    recommended_actions: List[str]

@dataclass
class OptimizationRecommendation:
    """Cost optimization recommendation"""
    recommendation_id: str
    user_id: str
    optimization_type: OptimizationType
    priority: str  # low, medium, high, urgent
    potential_savings: float
    confidence_score: float
    implementation_effort: str  # low, medium, high
    description: str
    current_configuration: Dict[str, Any]
    recommended_configuration: Dict[str, Any]
    risk_assessment: str
    time_to_implement: str

@dataclass
class BudgetAlert:
    """Budget alert configuration"""
    budget_id: str
    user_id: str
    budget_amount: float
    current_spend: float
    alert_thresholds: List[float]  # [50, 75, 90, 100]
    notification_channels: List[str]
    alert_frequency: str
    forecast_enabled: bool
    created_at: datetime

class CostAnomalyDetector:
    """Advanced cost anomaly detection using machine learning"""
    
    def __init__(self):
        self.isolation_forest = IsolationForest(
            contamination=0.1,
            random_state=42,
            n_estimators=100
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        
        # Anomaly thresholds
        self.thresholds = {
            "cost_spike_factor": 2.0,  # 2x increase
            "utilization_drop_threshold": 0.3,  # 30% drop
            "efficiency_decline_threshold": 0.2,  # 20% decline
            "budget_breach_threshold": 0.9  # 90% of budget
        }
    
    def train_model(self, historical_data: List[CostMetrics]) -> bool:
        """Train anomaly detection model"""
        
        if len(historical_data) < 100:
            logger.warning("Insufficient data for training anomaly detection")
            return False
        
        # Prepare features
        features = []
        for metric in historical_data:
            feature_vector = [
                metric.hourly_cost,
                metric.runtime_hours,
                metric.utilization,
                self._encode_categorical(metric.provider),
                self._encode_categorical(metric.gpu_type),
                self._encode_categorical(metric.region)
            ]
            features.append(feature_vector)
        
        # Scale features
        features_scaled = self.scaler.fit_transform(features)
        
        # Train model
        self.isolation_forest.fit(features_scaled)
        self.is_trained = True
        
        logger.info(f"Anomaly detection model trained on {len(historical_data)} data points")
        return True
    
    def detect_anomalies(self, current_metrics: List[CostMetrics]) -> List[CostAnomaly]:
        """Detect cost anomalies in current metrics"""
        
        if not self.is_trained:
            logger.warning("Anomaly detection model not trained")
            return []
        
        anomalies = []
        
        for metric in current_metrics:
            # Prepare feature vector
            features = [
                metric.hourly_cost,
                metric.runtime_hours,
                metric.utilization,
                self._encode_categorical(metric.provider),
                self._encode_categorical(metric.gpu_type),
                self._encode_categorical(metric.region)
            ]
            
            features_scaled = self.scaler.transform([features])
            
            # Get anomaly score
            anomaly_score = self.isolation_forest.decision_function(features_scaled)[0]
            
            if anomaly_score < 0:  # Anomaly detected
                anomaly = self._classify_anomaly(metric, anomaly_score)
                anomalies.append(anomaly)
        
        return anomalies
    
    def _encode_categorical(self, value: str) -> float:
        """Encode categorical values"""
        # Simple hash-based encoding for demonstration
        return float(hash(value) % 1000) / 1000.0
    
    def _classify_anomaly(self, metric: CostMetrics, anomaly_score: float) -> CostAnomaly:
        """Classify the type of anomaly"""
        
        anomaly_id = f"anomaly_{int(time.time())}_{metric.user_id}"
        
        # Determine anomaly type based on metric characteristics
        if metric.hourly_cost > self.thresholds["cost_spike_factor"] * 10.0:  # Assuming base cost ~$10
            anomaly_type = CostAnomalyType.SPIKE
            description = f"Unusual cost spike detected: ${metric.hourly_cost:.2f}/hour"
            severity = "high" if anomaly_score < -0.5 else "medium"
            
        elif metric.utilization < self.thresholds["utilization_drop_threshold"]:
            anomaly_type = CostAnomalyType.EFFICIENCY_DROP
            description = f"Low GPU utilization: {metric.utilization:.1%}"
            severity = "medium"
            
        else:
            anomaly_type = CostAnomalyType.UNUSUAL_PATTERN
            description = "Unusual spending pattern detected"
            severity = "low"
        
        return CostAnomaly(
            anomaly_id=anomaly_id,
            user_id=metric.user_id,
            anomaly_type=anomaly_type,
            severity=severity,
            detected_at=datetime.utcnow(),
            description=description,
            affected_metrics={
                "hourly_cost": metric.hourly_cost,
                "utilization": metric.utilization,
                "runtime_hours": metric.runtime_hours
            },
            baseline_values={
                "typical_hourly_cost": 10.0,  # Would be calculated from historical data
                "typical_utilization": 0.7,
                "typical_runtime": 4.0
            },
            confidence_score=abs(anomaly_score),
            recommended_actions=self._get_recommended_actions(anomaly_type)
        )
    
    def _get_recommended_actions(self, anomaly_type: CostAnomalyType) -> List[str]:
        """Get recommended actions for anomaly type"""
        
        actions = {
            CostAnomalyType.SPIKE: [
                "Review recent deployments for cost increases",
                "Check for spot price volatility",
                "Consider switching to cheaper provider",
                "Implement cost alerts"
            ],
            CostAnomalyType.EFFICIENCY_DROP: [
                "Optimize batch sizes",
                "Review model architecture",
                "Consider right-sizing instances",
                "Implement utilization monitoring"
            ],
            CostAnomalyType.UNUSUAL_PATTERN: [
                "Investigate deployment patterns",
                "Review automation scripts",
                "Check for configuration errors",
                "Audit recent changes"
            ],
            CostAnomalyType.BUDGET_BREACH: [
                "Immediate cost review",
                "Pause non-critical deployments",
                "Implement emergency cost controls",
                "Notify stakeholders"
            ],
            CostAnomalyType.DRIFT: [
                "Monitor trend continuation",
                "Adjust budget forecasts",
                "Review optimization opportunities",
                "Consider strategic changes"
            ]
        }
        
        return actions.get(anomaly_type, ["Investigate further"])

class CostOptimizer:
    """Advanced cost optimization engine"""
    
    def __init__(self):
        self.optimization_algorithms = {
            OptimizationType.SPOT_MIGRATION: self._optimize_spot_migration,
            OptimizationType.PROVIDER_SWITCH: self._optimize_provider_switch,
            OptimizationType.RIGHT_SIZING: self._optimize_right_sizing,
            OptimizationType.SCHEDULED_SHUTDOWN: self._optimize_scheduled_shutdown,
            OptimizationType.RESERVATION_PURCHASE: self._optimize_reservation_purchase,
            OptimizationType.REGION_OPTIMIZATION: self._optimize_region_optimization
        }
        
        # Market data for optimization
        self.market_data = {
            "spot_discounts": {
                "aws": 0.7,  # 70% discount on average
                "gcp": 0.65,
                "azure": 0.68,
                "runpod": 0.6,
                "lambda": 0.55
            },
            "provider_reliability": {
                "aws": 0.95,
                "gcp": 0.93,
                "azure": 0.90,
                "runpod": 0.85,
                "lambda": 0.80
            }
        }
    
    def generate_recommendations(self, user_metrics: List[CostMetrics], 
                               user_preferences: Dict[str, Any]) -> List[OptimizationRecommendation]:
        """Generate cost optimization recommendations"""
        
        recommendations = []
        
        # Analyze each metric for optimization opportunities
        for metric in user_metrics:
            # Spot migration optimization
            if self._should_migrate_to_spot(metric):
                recommendation = self.optimization_algorithms[OptimizationType.SPOT_MIGRATION](
                    metric, user_preferences
                )
                recommendations.append(recommendation)
            
            # Provider switch optimization
            if self._should_switch_provider(metric):
                recommendation = self.optimization_algorithms[OptimizationType.PROVIDER_SWITCH](
                    metric, user_preferences
                )
                recommendations.append(recommendation)
            
            # Right-sizing optimization
            if self._should_right_size(metric):
                recommendation = self.optimization_algorithms[OptimizationType.RIGHT_SIZING](
                    metric, user_preferences
                )
                recommendations.append(recommendation)
            
            # Scheduled shutdown optimization
            if self._should_schedule_shutdown(metric):
                recommendation = self.optimization_algorithms[OptimizationType.SCHEDULED_SHUTDOWN](
                    metric, user_preferences
                )
                recommendations.append(recommendation)
        
        # Sort recommendations by potential savings
        recommendations.sort(key=lambda x: x.potential_savings, reverse=True)
        
        return recommendations
    
    def _should_migrate_to_spot(self, metric: CostMetrics) -> bool:
        """Check if instance should be migrated to spot pricing"""
        
        # Simple heuristic: if not using spot and utilization is moderate
        return (metric.hourly_cost > 5.0 and 
                metric.utilization > 0.3 and 
                metric.utilization < 0.9)
    
    def _should_switch_provider(self, metric: CostMetrics) -> bool:
        """Check if provider switch is beneficial"""
        
        # Simple heuristic: if cost is high and reliability is acceptable
        return (metric.hourly_cost > 3.0 and 
                self.market_data["provider_reliability"].get(metric.provider, 0.9) > 0.8)
    
    def _should_right_size(self, metric: CostMetrics) -> bool:
        """Check if instance should be right-sized"""
        
        # Simple heuristic: low utilization suggests over-provisioning
        return metric.utilization < 0.4
    
    def _should_schedule_shutdown(self, metric: CostMetrics) -> bool:
        """Check if instance should be scheduled for shutdown"""
        
        # Simple heuristic: very low utilization or long runtime
        return (metric.utilization < 0.1 or metric.runtime_hours > 24)
    
    def _optimize_spot_migration(self, metric: CostMetrics, 
                               preferences: Dict[str, Any]) -> OptimizationRecommendation:
        """Generate spot migration recommendation"""
        
        provider = metric.provider
        spot_discount = self.market_data["spot_discounts"].get(provider, 0.7)
        
        potential_savings = metric.hourly_cost * spot_discount * metric.runtime_hours
        confidence = 0.85 if metric.utilization < 0.7 else 0.75
        
        return OptimizationRecommendation(
            recommendation_id=f"spot_migration_{int(time.time())}",
            user_id=metric.user_id,
            optimization_type=OptimizationType.SPOT_MIGRATION,
            priority="high" if potential_savings > 50 else "medium",
            potential_savings=potential_savings,
            confidence_score=confidence,
            implementation_effort="medium",
            description=f"Migrate {metric.instance_type} to spot pricing for {spot_discount:.0%} savings",
            current_configuration={
                "pricing_type": "on_demand",
                "instance_type": metric.instance_type,
                "hourly_cost": metric.hourly_cost
            },
            recommended_configuration={
                "pricing_type": "spot",
                "instance_type": metric.instance_type,
                "hourly_cost": metric.hourly_cost * (1 - spot_discount),
                "interruption_policy": "checkpoint"
            },
            risk_assessment="medium" if metric.utilization > 0.5 else "low",
            time_to_implement="2-4 hours"
        )
    
    def _optimize_provider_switch(self, metric: CostMetrics, 
                                preferences: Dict[str, Any]) -> OptimizationRecommendation:
        """Generate provider switch recommendation"""
        
        # Find cheapest alternative provider
        current_cost = metric.hourly_cost
        cheapest_cost = current_cost
        best_provider = metric.provider
        
        for provider, discount in self.market_data["spot_discounts"].items():
            estimated_cost = current_cost * (1 - discount)
            if estimated_cost < cheapest_cost:
                cheapest_cost = estimated_cost
                best_provider = provider
        
        potential_savings = (current_cost - cheapest_cost) * metric.runtime_hours
        
        return OptimizationRecommendation(
            recommendation_id=f"provider_switch_{int(time.time())}",
            user_id=metric.user_id,
            optimization_type=OptimizationType.PROVIDER_SWITCH,
            priority="medium",
            potential_savings=potential_savings,
            confidence_score=0.8,
            implementation_effort="high",
            description=f"Switch from {metric.provider} to {best_provider} for better pricing",
            current_configuration={
                "provider": metric.provider,
                "instance_type": metric.instance_type,
                "hourly_cost": current_cost
            },
            recommended_configuration={
                "provider": best_provider,
                "instance_type": metric.instance_type,  # Assuming same instance type
                "hourly_cost": cheapest_cost
            },
            risk_assessment="medium",
            time_to_implement="4-8 hours"
        )
    
    def _optimize_right_sizing(self, metric: CostMetrics, 
                              preferences: Dict[str, Any]) -> OptimizationRecommendation:
        """Generate right-sizing recommendation"""
        
        # Simple right-sizing logic
        current_cost = metric.hourly_cost
        utilization = metric.utilization
        
        if utilization < 0.2:
            # Suggest downsizing by 50%
            new_cost = current_cost * 0.5
            potential_savings = (current_cost - new_cost) * metric.runtime_hours
            new_instance = f"{metric.instance_type.replace('xlarge', 'large')}"  # Simplified
        elif utilization < 0.4:
            # Suggest downsizing by 25%
            new_cost = current_cost * 0.75
            potential_savings = (current_cost - new_cost) * metric.runtime_hours
            new_instance = metric.instance_type  # Keep same for simplicity
        else:
            return None
        
        return OptimizationRecommendation(
            recommendation_id=f"right_size_{int(time.time())}",
            user_id=metric.user_id,
            optimization_type=OptimizationType.RIGHT_SIZING,
            priority="medium",
            potential_savings=potential_savings,
            confidence_score=0.75,
            implementation_effort="low",
            description=f"Right-size instance based on {utilization:.1%} utilization",
            current_configuration={
                "instance_type": metric.instance_type,
                "hourly_cost": current_cost,
                "utilization": utilization
            },
            recommended_configuration={
                "instance_type": new_instance,
                "hourly_cost": new_cost,
                "expected_utilization": min(utilization * 1.5, 0.8)
            },
            risk_assessment="low",
            time_to_implement="1-2 hours"
        )
    
    def _optimize_scheduled_shutdown(self, metric: CostMetrics, 
                                   preferences: Dict[str, Any]) -> OptimizationRecommendation:
        """Generate scheduled shutdown recommendation"""
        
        potential_savings = metric.hourly_cost * 8  # Assume 8 hours shutdown
        confidence = 0.9 if metric.utilization < 0.05 else 0.7
        
        return OptimizationRecommendation(
            recommendation_id=f"scheduled_shutdown_{int(time.time())}",
            user_id=metric.user_id,
            optimization_type=OptimizationType.SCHEDULED_SHUTDOWN,
            priority="low",
            potential_savings=potential_savings,
            confidence_score=confidence,
            implementation_effort="low",
            description=f"Schedule shutdown during low utilization periods",
            current_configuration={
                "instance_type": metric.instance_type,
                "runtime_hours": metric.runtime_hours,
                "utilization": metric.utilization
            },
            recommended_configuration={
                "schedule": "22:00-06:00 daily",
                "estimated_savings": potential_savings,
                "implementation": "cron job or auto-scaling"
            },
            risk_assessment="low",
            time_to_implement="30 minutes"
        )
    
    def _optimize_reservation_purchase(self, metric: CostMetrics, 
                                     preferences: Dict[str, Any]) -> OptimizationRecommendation:
        """Generate reservation purchase recommendation"""
        
        # Simplified reservation analysis
        current_cost = metric.hourly_cost
        reservation_discount = 0.3  # 30% discount for 1-year reservation
        
        potential_savings = current_cost * reservation_discount * 365 * 24  # Annual savings
        
        return OptimizationRecommendation(
            recommendation_id=f"reservation_{int(time.time())}",
            user_id=metric.user_id,
            optimization_type=OptimizationType.RESERVATION_PURCHASE,
            priority="low",
            potential_savings=potential_savings,
            confidence_score=0.6,
            implementation_effort="medium",
            description="Purchase 1-year reservation for consistent workloads",
            current_configuration={
                "pricing_type": "on_demand",
                "hourly_cost": current_cost
            },
            recommended_configuration={
                "pricing_type": "reservation",
                "term": "1_year",
                "hourly_cost": current_cost * (1 - reservation_discount),
                "upfront_cost": current_cost * 365 * 24 * 0.4  # 40% upfront
            },
            risk_assessment="medium",
            time_to_implement="1-2 days"
        )
    
    def _optimize_region_optimization(self, metric: CostMetrics, 
                                    preferences: Dict[str, Any]) -> OptimizationRecommendation:
        """Generate region optimization recommendation"""
        
        # Simplified region optimization
        potential_savings = metric.hourly_cost * 0.1 * metric.runtime_hours  # 10% savings
        
        return OptimizationRecommendation(
            recommendation_id=f"region_opt_{int(time.time())}",
            user_id=metric.user_id,
            optimization_type=OptimizationType.REGION_OPTIMIZATION,
            priority="low",
            potential_savings=potential_savings,
            confidence_score=0.5,
            implementation_effort="high",
            description="Optimize region selection for better pricing",
            current_configuration={
                "region": metric.region,
                "hourly_cost": metric.hourly_cost
            },
            recommended_configuration={
                "region": "us-east-1",  # Example optimal region
                "hourly_cost": metric.hourly_cost * 0.9,
                "migration_complexity": "high"
            },
            risk_assessment="medium",
            time_to_implement="1-2 weeks"
        )

class BudgetManager:
    """Advanced budget management and alerting"""
    
    def __init__(self, redis_client: aioredis.Redis):
        self.redis_client = redis_client
        self.budgets: Dict[str, BudgetAlert] = {}
        
        # Alert thresholds
        self.default_thresholds = [50, 75, 90, 100]
        
        # Notification channels
        self.notification_channels = {
            "email": self._send_email_alert,
            "slack": self._send_slack_alert,
            "webhook": self._send_webhook_alert
        }
    
    async def create_budget(self, user_id: str, budget_amount: float, 
                           alert_thresholds: List[float] = None,
                           notification_channels: List[str] = None) -> BudgetAlert:
        """Create budget alert configuration"""
        
        budget_id = f"budget_{user_id}_{int(time.time())}"
        
        budget = BudgetAlert(
            budget_id=budget_id,
            user_id=user_id,
            budget_amount=budget_amount,
            current_spend=0.0,
            alert_thresholds=alert_thresholds or self.default_thresholds,
            notification_channels=notification_channels or ["email"],
            alert_frequency="daily",
            forecast_enabled=True,
            created_at=datetime.utcnow()
        )
        
        self.budgets[budget_id] = budget
        
        # Store in Redis
        await self._store_budget(budget)
        
        logger.info(f"Created budget {budget_id} for user {user_id}")
        return budget
    
    async def update_budget_spend(self, user_id: str, current_spend: float):
        """Update current spending and check alerts"""
        
        # Find user's budget
        user_budget = None
        for budget in self.budgets.values():
            if budget.user_id == user_id:
                user_budget = budget
                break
        
        if not user_budget:
            return
        
        # Update current spend
        user_budget.current_spend = current_spend
        await self._store_budget(user_budget)
        
        # Check alert thresholds
        spend_percentage = (current_spend / user_budget.budget_amount) * 100
        
        for threshold in user_budget.alert_thresholds:
            if spend_percentage >= threshold:
                await self._trigger_budget_alert(user_budget, threshold, spend_percentage)
                break  # Only trigger highest threshold
    
    async def _store_budget(self, budget: BudgetAlert):
        """Store budget in Redis"""
        
        budget_key = f"budget:{budget.budget_id}"
        budget_data = asdict(budget)
        
        # Convert datetime to string for JSON serialization
        budget_data["created_at"] = budget.created_at.isoformat()
        
        await self.redis_client.set(budget_key, json.dumps(budget_data), ex=86400 * 30)  # 30 days
    
    async def _trigger_budget_alert(self, budget: BudgetAlert, threshold: float, 
                                  spend_percentage: float):
        """Trigger budget alert"""
        
        alert_key = f"budget_alert:{budget.budget_id}:{threshold}"
        
        # Check if alert was recently sent (avoid spam)
        last_alert = await self.redis_client.get(alert_key)
        if last_alert:
            return
        
        # Send alerts through configured channels
        for channel in budget.notification_channels:
            if channel in self.notification_channels:
                try:
                    await self.notification_channels[channel](
                        budget, threshold, spend_percentage
                    )
                except Exception as e:
                    logger.error(f"Failed to send {channel} alert: {e}")
        
        # Mark alert as sent
        await self.redis_client.set(alert_key, "1", ex=3600)  # 1 hour
    
    async def _send_email_alert(self, budget: BudgetAlert, threshold: float, 
                               spend_percentage: float):
        """Send email alert"""
        
        # Implementation would integrate with email service
        logger.info(f"Email alert sent to {budget.user_id}: {spend_percentage:.1f}% of budget used")
    
    async def _send_slack_alert(self, budget: BudgetAlert, threshold: float, 
                               spend_percentage: float):
        """Send Slack alert"""
        
        # Implementation would integrate with Slack API
        logger.info(f"Slack alert sent for {budget.user_id}: {spend_percentage:.1f}% of budget used")
    
    async def _send_webhook_alert(self, budget: BudgetAlert, threshold: float, 
                                 spend_percentage: float):
        """Send webhook alert"""
        
        # Implementation would send to configured webhook URL
        logger.info(f"Webhook alert sent for {budget.user_id}: {spend_percentage:.1f}% of budget used")

class CostManagementSystem:
    """Main cost management system"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.anomaly_detector = CostAnomalyDetector()
        self.cost_optimizer = CostOptimizer()
        
        # Database connection
        self.db_engine = None
        self.redis_client = None
        
        # Initialize metrics
        self._setup_metrics()
        
        # Budget manager
        self.budget_manager = None
        
        logger.info("Cost management system initialized")
    
    def _setup_metrics(self):
        """Setup Prometheus metrics"""
        
        self.metrics = {
            "cost_anomalies_detected": Counter(
                "terradev_cost_anomalies_detected_total",
                "Total number of cost anomalies detected",
                ["anomaly_type", "severity"]
            ),
            "optimization_recommendations": Counter(
                "terradev_optimization_recommendations_total",
                "Total number of optimization recommendations",
                ["recommendation_type", "priority"]
            ),
            "potential_savings": Gauge(
                "terradev_potential_savings_usd",
                "Total potential savings from recommendations",
                ["user_id", "recommendation_type"]
            ),
            "budget_alerts": Counter(
                "terradev_budget_alerts_total",
                "Total number of budget alerts triggered",
                ["threshold", "user_id"]
            )
        }
    
    async def initialize(self):
        """Initialize database connections"""
        
        # Database connection
        db_url = self.config.get("database_url")
        if db_url:
            self.db_engine = create_async_engine(db_url, echo=False)
        
        # Redis connection
        redis_url = self.config.get("redis_url")
        if redis_url:
            self.redis_client = await aioredis.from_url(redis_url)
            self.budget_manager = BudgetManager(self.redis_client)
        
        logger.info("Cost management system connections initialized")
    
    async def analyze_costs(self, user_id: str, time_period: str = "30d") -> Dict[str, Any]:
        """Perform comprehensive cost analysis"""
        
        # Get cost metrics from database
        cost_metrics = await self._get_cost_metrics(user_id, time_period)
        
        if not cost_metrics:
            return {"error": "No cost data available"}
        
        # Train anomaly detection model
        self.anomaly_detector.train_model(cost_metrics)
        
        # Detect anomalies
        anomalies = self.anomaly_detector.detect_anomalies(cost_metrics)
        
        # Generate optimization recommendations
        user_preferences = await self._get_user_preferences(user_id)
        recommendations = self.cost_optimizer.generate_recommendations(cost_metrics, user_preferences)
        
        # Calculate summary statistics
        summary = self._calculate_cost_summary(cost_metrics)
        
        # Update metrics
        for anomaly in anomalies:
            self.metrics["cost_anomalies_detected"].labels(
                anomaly_type=anomaly.anomaly_type.value,
                severity=anomaly.severity
            ).inc()
        
        for rec in recommendations:
            self.metrics["optimization_recommendations"].labels(
                recommendation_type=rec.optimization_type.value,
                priority=rec.priority
            ).inc()
            
            self.metrics["potential_savings"].labels(
                user_id=user_id,
                recommendation_type=rec.optimization_type.value
            ).set(rec.potential_savings)
        
        return {
            "user_id": user_id,
            "time_period": time_period,
            "summary": summary,
            "anomalies": [asdict(anomaly) for anomaly in anomalies],
            "recommendations": [asdict(rec) for rec in recommendations],
            "analysis_timestamp": datetime.utcnow().isoformat()
        }
    
    async def _get_cost_metrics(self, user_id: str, time_period: str) -> List[CostMetrics]:
        """Get cost metrics from database"""
        
        # Implementation would query database for user's cost metrics
        # For now, return sample data
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=30)
        
        sample_metrics = [
            CostMetrics(
                timestamp=start_time + timedelta(hours=i),
                user_id=user_id,
                provider="aws",
                gpu_type="a100",
                instance_type="p4d.24xlarge",
                hourly_cost=1.22,
                runtime_hours=4.0,
                total_cost=4.88,
                utilization=0.75,
                region="us-west-2",
                deployment_id=f"deploy_{i}"
            )
            for i in range(100)
        ]
        
        return sample_metrics
    
    async def _get_user_preferences(self, user_id: str) -> Dict[str, Any]:
        """Get user optimization preferences"""
        
        # Implementation would query user preferences
        return {
            "risk_tolerance": "medium",
            "preferred_providers": ["aws", "gcp"],
            "spot_pricing_preference": True,
            "optimization_aggressiveness": "moderate"
        }
    
    def _calculate_cost_summary(self, metrics: List[CostMetrics]) -> Dict[str, Any]:
        """Calculate cost summary statistics"""
        
        if not metrics:
            return {}
        
        total_cost = sum(m.total_cost for m in metrics)
        total_hours = sum(m.runtime_hours for m in metrics)
        avg_hourly_cost = total_cost / total_hours if total_hours > 0 else 0
        avg_utilization = sum(m.utilization for m in metrics) / len(metrics)
        
        # Cost breakdown by provider
        provider_costs = {}
        for metric in metrics:
            provider_costs[metric.provider] = provider_costs.get(metric.provider, 0) + metric.total_cost
        
        # Cost breakdown by GPU type
        gpu_costs = {}
        for metric in metrics:
            gpu_costs[metric.gpu_type] = gpu_costs.get(metric.gpu_type, 0) + metric.total_cost
        
        return {
            "total_cost": total_cost,
            "total_runtime_hours": total_hours,
            "average_hourly_cost": avg_hourly_cost,
            "average_utilization": avg_utilization,
            "cost_by_provider": provider_costs,
            "cost_by_gpu_type": gpu_costs,
            "total_deployments": len(set(m.deployment_id for m in metrics if m.deployment_id))
        }
    
    async def create_budget_alert(self, user_id: str, budget_amount: float,
                                alert_thresholds: List[float] = None,
                                notification_channels: List[str] = None) -> BudgetAlert:
        """Create budget alert for user"""
        
        if not self.budget_manager:
            raise ValueError("Budget manager not initialized")
        
        return await self.budget_manager.create_budget(
            user_id, budget_amount, alert_thresholds, notification_channels
        )
    
    async def update_spending(self, user_id: str, current_spend: float):
        """Update user spending and check budget alerts"""
        
        if self.budget_manager:
            await self.budget_manager.update_budget_spend(user_id, current_spend)
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary for monitoring"""
        
        return {
            "anomalies_detected": dict(self.metrics["cost_anomalies_detected"]._value.get()),
            "recommendations_generated": dict(self.metrics["optimization_recommendations"]._value.get()),
            "potential_savings": dict(self.metrics["potential_savings"]._value.get()),
            "budget_alerts": dict(self.metrics["budget_alerts"]._value.get())
        }

# Example usage
if __name__ == "__main__":
    async def main():
        # Initialize cost management system
        config = {
            "database_url": "postgresql+asyncpg://user:pass@localhost/costdb",
            "redis_url": "redis://localhost:6379/0"
        }
        
        cost_system = CostManagementSystem(config)
        await cost_system.initialize()
        
        # Analyze costs for a user
        analysis = await cost_system.analyze_costs("user_123", "30d")
        
        logging.info("Cost Analysis Results:")
        logging.info(f"Total Cost: ${analysis['summary']['total_cost']:.2f}")
        logging.info(f"Anomalies Detected: {len(analysis['anomalies'])
        logging.info(f"Recommendations: {len(analysis['recommendations'])
        logging.info(f"Potential Savings: ${sum(r['potential_savings'] for r in analysis['recommendations'])
        
        # Create budget alert
        budget = await cost_system.create_budget_alert(
            "user_123", 
            1000.0, 
            [50, 75, 90, 100], 
            ["email", "slack"]
        )
        
        logging.info(f"Created budget alert: {budget.budget_id}")
    
    asyncio.run(main())
