# TensorDock Integration for Terradev

This directory contains the complete TensorDock GPU cloud integration for the Terradev platform.

## Files Overview

### Core Integration
- **`tensordock_integration.py`** - Low-level TensorDock API client with full API coverage
- **`tensordock_provider.py`** - High-level provider implementation compatible with Terradev's provider system
- **`tensordock_deployment.py`** - Production deployment management and orchestration

### Key Features

#### 🚀 Instance Management
- Create GPU-accelerated virtual machines
- Support for RTX 4090, RTX 3090, A100, H100 GPUs
- Automatic instance configuration and cloud-init setup
- Instance lifecycle management (start, stop, delete)

#### 🏗️ Deployment Automation
- Pre-configured deployment templates (dev, staging, prod)
- Auto-scaling support with Kubernetes integration
- Cluster management for distributed training
- Health monitoring and cost tracking

#### 🔧 Production Features
- Environment-based configuration
- SSH key management
- Dedicated IP assignment
- Custom cloud-init scripts for ML environments
- GPU driver and CUDA toolkit installation

## Quick Start

### 1. Setup Credentials

```bash
# Environment variables (recommended)
export TENSORDOCK_CLIENT_ID="your-client-id"
export TENSORDOCK_API_TOKEN="your-api-token"

# Or create credentials file
echo '{"client_id": "your-client-id", "api_token": "your-api-token"}' > tensordock_credentials.json
```

### 2. Basic Usage

```python
import asyncio
from tensordock_integration import TensorDockManager, TensorDockCredentials

async def main():
    # Initialize manager
    credentials = TensorDockCredentials(
        client_id="6f71b631-5a32-42f1-94a5-d089adffdb24",
        api_token="rxOI1pnIZ9UL3J8MZmMmYBkKk7EwPdyS"
    )
    manager = TensorDockManager(credentials)
    
    # Create ML instance
    instance = await manager.create_ml_instance(
        name="my-ml-instance",
        gpu_model="geforcertx4090-pcie-24gb",
        gpu_count=1,
        cpu_cores=8,
        ram_gb=32,
        storage_gb=200
    )
    
    print(f"Created instance: {instance.id}")

asyncio.run(main())
```

### 3. Deployment Management

```bash
# Deploy development environment
python tensordock_deployment.py deploy ml-development

# Check deployment status
python tensordock_deployment.py status ml-development

# Scale deployment
python tensordock_deployment.py scale ml-development 3

# Get cost report
python tensordock_deployment.py cost ml-development 24

# Health check
python tensordock_deployment.py health ml-development

# Generate Kubernetes config
python tensordock_deployment.py k8s ml-production

# Destroy deployment
python tensordock_deployment.py destroy ml-development
```

## API Reference

### TensorDockManager

#### Instance Creation
```python
# Create ML instance with optimized configuration
instance = await manager.create_ml_instance(
    name="ml-instance",
    gpu_model="geforcertx4090-pcie-24gb",
    gpu_count=1,
    cpu_cores=8,
    ram_gb=32,
    storage_gb=200
)

# Create training cluster
cluster = await manager.create_training_cluster(
    cluster_name="training-cluster",
    node_count=3,
    gpu_per_node=2
)
```

#### Instance Management
```python
# List instances
instances = await manager.api.list_instances()

# Get instance details
instance = await manager.api.get_instance(instance_id)

# Start/stop instance
await manager.api.start_instance(instance_id)
await manager.api.stop_instance(instance_id)

# Delete instance
await manager.api.delete_instance(instance_id)
```

### TensorDockProvider

#### Provider Integration
```python
from tensordock_provider import TensorDockProvider

provider = TensorDockProvider(
    client_id="your-client-id",
    api_token="your-api-token"
)

async with provider:
    # Test connection
    await provider.test_connection()
    
    # Create instance
    instance = await provider.create_ml_instance(
        name="test-instance",
        instance_type="ml-medium"
    )
    
    # List instances
    instances = await provider.list_instances()
```

## Instance Types

| Type | CPU | Memory | Storage | GPU | Use Case |
|------|-----|---------|---------|-----|----------|
| ml-small | 4 | 16GB | 100GB | 1x RTX4090 | Development |
| ml-medium | 8 | 32GB | 200GB | 1x RTX4090 | Testing |
| ml-large | 16 | 64GB | 500GB | 2x RTX4090 | Production |
| training | 32 | 128GB | 1000GB | 4x A100 | Training |

## Cloud-Init Configuration

Instances are automatically configured with:

- **System Updates**: Package update and upgrade
- **GPU Drivers**: NVIDIA drivers and CUDA toolkit
- **ML Frameworks**: PyTorch, TensorFlow, JupyterLab
- **Docker**: Container runtime and Docker Compose
- **Security**: SSH key authentication and firewall setup
- **Monitoring**: Performance monitoring and logging

### Custom Cloud-Init

```python
from tensordock_integration import CloudInit

cloud_init = CloudInit(
    package_update=True,
    package_upgrade=True,
    packages=["nginx", "redis-server"],
    runcmd=[
        "systemctl enable nginx",
        "ufw allow 80/tcp",
        "ufw allow 443/tcp"
    ],
    write_files=[
        {
            "path": "/var/www/html/index.html",
            "content": "<h1>Welcome to TensorDock!</h1>",
            "permissions": "0644"
        }
    ]
)
```

## Cost Management

### Pricing (per hour)
- ml-small: $0.50
- ml-medium: $1.00
- ml-large: $2.00
- training: $8.00

### Cost Tracking
```python
# Get instance costs
cost = await manager.get_instance_costs(instance_id, hours=24)

# Get deployment cost report
report = await deployment_manager.get_cost_report("ml-production", hours=24)
```

## Auto-Scaling

TensorDock integration supports automatic scaling based on:

- CPU utilization
- Memory usage
- GPU utilization
- Custom metrics

### Kubernetes Integration
```yaml
# Auto-generated HPA configuration
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ml-prod-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ml-prod
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

## Security

### Authentication
- API token-based authentication
- Client ID verification
- Request signing and validation

### Network Security
- Dedicated IP addresses
- SSH key authentication
- Firewall configuration
- SSL/TLS encryption

### Data Protection
- Encrypted storage
- Secure key management
- Access logging and auditing

## Monitoring

### Instance Monitoring
- CPU, memory, GPU utilization
- Network I/O and disk usage
- Instance health checks
- Performance metrics

### Cost Monitoring
- Real-time cost tracking
- Budget alerts
- Usage analytics
- Cost optimization recommendations

## Troubleshooting

### Common Issues

1. **Authentication Failed**
   - Check API token and client ID
   - Verify token permissions
   - Ensure token is not expired

2. **Instance Creation Failed**
   - Check GPU availability
   - Verify resource limits
   - Check account balance

3. **Instance Not Starting**
   - Check instance logs
   - Verify cloud-init configuration
   - Check SSH key configuration

### Debug Mode
```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Enable debug logging
manager = TensorDockManager(credentials)
```

## Support

- **Documentation**: Full API documentation
- **Examples**: Complete code examples
- **Support**: 24/7 technical support
- **Community**: Active developer community

## License

This integration is part of the Terradev platform and follows the same licensing terms.

---

**Note**: This integration requires valid TensorDock credentials and sufficient account balance for instance creation.
