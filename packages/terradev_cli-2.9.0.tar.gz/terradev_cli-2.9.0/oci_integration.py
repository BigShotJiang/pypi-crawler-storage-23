import os

#!/usr/bin/env python3
"""
Oracle Cloud Infrastructure (OCI) Integration for Terradev
Compute instance pricing, availability, and arbitrage analysis
"""

import asyncio
import aiohttp
import json
import logging
import time
import hashlib
import hmac
import base64
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from urllib.parse import urlencode, quote
import requests
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.backends import default_backend

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class OCIInstance:
    """OCI instance information"""
    shape: str
    ocpus: float
    memory_in_gbs: float
    gpus: int
    gpu_description: str
    local_disks: int
    local_disk_size_in_gbs: float
    price_per_hour: float
    spot_price_per_hour: float
    availability_domain: str
    region: str
    is_spot_available: bool

@dataclass
class OCIPricing:
    """OCI pricing information"""
    product_sku: str
    product_name: str
    unit: str
    price_per_unit: float
    currency: str
    region: str
    tier: str  # Standard, Spot, etc.
    effective_date: datetime

@dataclass
class OCICredentials:
    """OCI authentication credentials"""
    user_ocid: str
    tenancy_ocid: str
    private_key: str
    fingerprint: str
    region: str
    compartment_ocid: str

class OCIAPIClient:
    """Oracle Cloud Infrastructure API client"""
    
    def __init__(self, credentials: OCICredentials):
        self.credentials = credentials
        self.base_url = f"https://iaas.{credentials.region}.oraclecloud.com"
        self.pricing_url = "https://pricing.oracle.com/api"
        self.session = None
        
        # Load private key with error handling
        try:
            self.private_key = load_pem_private_key(
                credentials.private_key.encode(),
                password=None,
                backend=default_backend()
            )
        except Exception as e:
            logger.warning(f"Failed to load private key: {e}")
            # For demo purposes, create a mock key
            self.private_key = None
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    def _sign_request(self, method: str, url: str, headers: Dict[str, str], body: str = "") -> Dict[str, str]:
        """Sign OCI API request"""
        if not self.private_key:
            # For demo purposes, return headers without signature
            logger.warning("Using mock authentication - please provide valid OCI credentials")
            return headers
        
        # Get current timestamp
        now = datetime.utcnow()
        request_date = now.strftime("%d%m%y")
        request_time = now.strftime("%H%M%S") + "Z"
        
        # Create signing string
        canonical_url = url.split(self.base_url)[-1]
        canonical_method = method.upper()
        canonical_headers = "\n".join([f"{k.lower()}:{v.lower()}" for k, v in sorted(headers.items())])
        signed_headers = ";".join([k.lower() # TODO: OPTIMIZATION - Use more efficient pattern for .keys() iteration
# ('k', 'sorted(headers'))])
        
        # Create canonical request
        canonical_request = f"{canonical_method}\n{canonical_url}\n\n{canonical_headers}\n\n{signed_headers}\n{hashlib.sha256(body.encode()).hexdigest()}"
        
        # Create string to sign
        string_to_sign = f"OCI4-HMAC-SHA256\n{request_date}T{request_time}\n{hashlib.sha256(canonical_request.encode()).hexdigest()}"
        
        # Calculate signature
        signing_key = self._get_signing_key(request_date)
        signature = hmac.new(signing_key, string_to_sign.encode(), hashlib.sha256).digest()
        signature_b64 = base64.b64encode(signature).decode()
        
        # Add authorization header
        headers["authorization"] = f'OCI4-HMAC-SHA256 Credentials={self.credentials.tenancy_ocid}/{request_date}/{self.credentials.region}/oci_request, SignedHeaders={signed_headers}, Signature={signature_b64}'
        headers["x-date"] = f"{request_date}T{request_time}"
        
        return headers
    
    def _get_signing_key(self, date: str) -> bytes:
        """Get signing key for OCI authentication"""
        def sign(key: bytes, msg: str) -> bytes:
            return hmac.new(key, msg.encode(), hashlib.sha256).digest()
        
        api_key = b"oci4_request"
        date_key = sign(api_key, date)
        region_key = sign(date_key, self.credentials.region)
        service_key = sign(region_key, "iaas")
        return sign(service_key, "oci4_request")
    
    async def get_compute_shapes(self) -> List[OCIInstance]:
        """Get available compute shapes with GPU"""
        try:
            url = f"{self.base_url}/20160918/computeShapes"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            # Sign request
            headers = self._sign_request("GET", url, headers)
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    return self._parse_compute_shapes(data)
                else:
                    logger.error(f"Failed to get compute shapes: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error getting compute shapes: {e}")
            return []
    
    def _parse_compute_shapes(self, data: Dict[str, Any]) -> List[OCIInstance]:
        """Parse compute shapes response"""
        instances = []
        
        for shape in data.get("items", []):
            # Filter for GPU instances
            if "gpu" in shape.get("shape", "").lower() or shape.get("gpuDescription"):
                # Mock pricing - would get from pricing API
                hourly_price = self._estimate_hourly_price(shape)
                spot_price = hourly_price * 0.7  # 30% discount for spot
                
                instance = OCIInstance(
                    shape=shape.get("shape"),
                    ocpus=shape.get("ocpus", 0),
                    memory_in_gbs=shape.get("memoryInGBs", 0),
                    gpus=shape.get("gpus", 0),
                    gpu_description=shape.get("gpuDescription", ""),
                    local_disks=shape.get("localDisks", 0),
                    local_disk_size_in_gbs=shape.get("localDiskSizeInGBs", 0),
                    price_per_hour=hourly_price,
                    spot_price_per_hour=spot_price,
                    availability_domain="",  # Would be populated from availability API
                    region=self.credentials.region,
                    is_spot_available=True  # Would check from availability API
                )
                instances.append(instance)
        
        return instances
    
    def _estimate_hourly_price(self, shape: Dict[str, Any]) -> float:
        """Estimate hourly price based on shape specifications"""
        # Mock pricing logic - would use actual pricing API
        ocpus = shape.get("ocpus", 0)
        memory = shape.get("memoryInGBs", 0)
        gpus = shape.get("gpus", 0)
        
        # Base pricing
        cpu_price = ocpus * 0.01  # $0.01 per OCPU
        memory_price = memory * 0.0015  # $0.0015 per GB
        gpu_price = gpus * 2.0  # $2.0 per GPU
        
        return cpu_price + memory_price + gpu_price
    
    async def get_pricing_data(self, product_family: str = "Compute") -> List[OCIPricing]:
        """Get pricing data from OCI pricing API"""
        try:
            url = f"{self.pricing_url}/priceList"
            params = {
                "productFamily": product_family,
                "region": self.credentials.region,
                "currency": "USD"
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return self._parse_pricing_data(data)
                else:
                    logger.error(f"Failed to get pricing data: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error getting pricing data: {e}")
            return []
    
    def _parse_pricing_data(self, data: Dict[str, Any]) -> List[OCIPricing]:
        """Parse pricing data response"""
        pricing_list = []
        
        for item in data.get("items", []):
            pricing = OCIPricing(
                product_sku=item.get("productSKU", ""),
                product_name=item.get("productName", ""),
                unit=item.get("unit", ""),
                price_per_unit=item.get("pricePerUnit", 0.0),
                currency=item.get("currency", "USD"),
                region=item.get("region", self.credentials.region),
                tier=item.get("tier", "Standard"),
                effective_date=datetime.now()
            )
            pricing_list.append(pricing)
        
        return pricing_list
    
    async def get_spot_price_history(self, shape: str, availability_domain: str = None) -> List[Dict[str, Any]]:
        """Get spot price history for a specific shape"""
        try:
            url = f"{self.base_url}/20160918/spotPriceHistory"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            params = {
                "shape": shape,
                "limit": 100
            }
            
            if availability_domain:
                params["availabilityDomain"] = availability_domain
            
            # Sign request
            headers = self._sign_request("GET", url, headers)
            
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("items", [])
                else:
                    logger.error(f"Failed to get spot price history: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error getting spot price history: {e}")
            return []
    
    async def get_marketplace_listings(self, category: str = "Compute") -> List[Dict[str, Any]]:
        """Get marketplace listings for compute instances"""
        try:
            url = f"{self.base_url}/20160918/marketplaceListings"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            params = {
                "category": category,
                "limit": 50
            }
            
            # Sign request
            headers = self._sign_request("GET", url, headers)
            
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("items", [])
                else:
                    logger.error(f"Failed to get marketplace listings: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error getting marketplace listings: {e}")
            return []
    
    async def launch_instance(self, shape: str, compartment_id: str, 
                            display_name: str, subnet_id: str,
                            is_spot: bool = False) -> Dict[str, Any]:
        """Launch a compute instance"""
        try:
            url = f"{self.base_url}/20160918/instances"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            instance_config = {
                "compartmentId": compartment_id,
                "shape": shape,
                "displayName": display_name,
                "subnetId": subnet_id,
                "sourceDetails": {
                    "sourceType": "image",
                    "imageId": "ocid1.image.oc1.phx.aaaaaaaalk..."  # Would get from image catalog
                },
                "shapeConfig": {
                    "ocpus": 2,  # Default OCPUs
                    "memoryInGBs": 16  # Default memory
                }
            }
            
            if is_spot:
                instance_config["instanceOptions"] = {
                    "isSpot": True
                }
            
            # Sign request
            headers = self._sign_request("POST", url, headers, json.dumps(instance_config))
            
            async with self.session.post(url, headers=headers, json=instance_config) as response:
                if response.status == 200:
                    data = await response.json()
                    return {"status": "launched", "instance_id": data.get("id")}
                else:
                    error_data = await response.json()
                    return {"status": "error", "message": error_data.get("message", "Unknown error")}
        except Exception as e:
            logger.error(f"Error launching instance: {e}")
            return {"status": "error", "message": str(e)}

class OCIArbitrageEngine:
    """OCI arbitrage engine for Terradev"""
    
    def __init__(self, credentials: OCICredentials):
        self.client = OCIAPIClient(credentials)
        self.instances = []
        self.pricing_data = []
    
    async def initialize(self):
        """Initialize the OCI arbitrage engine"""
        async with self.client:
            # Get compute shapes
            self.instances = await self.client.get_compute_shapes()
            logger.info(f"Found {len(self.instances)} OCI GPU instances")
            
            # Get pricing data
            self.pricing_data = await self.client.get_pricing_data()
            logger.info(f"Found {len(self.pricing_data)} pricing items")
    
    async def get_arbitrage_opportunities(self, max_price: float = 5.0) -> List[Dict[str, Any]]:
        """Get arbitrage opportunities for OCI instances"""
        opportunities = []
        
        for instance in self.instances:
            if instance.spot_price_per_hour <= max_price:
                # Calculate potential savings
                savings_percentage = ((instance.price_per_hour - instance.spot_price_per_hour) / instance.price_per_hour) * 100
                
                # Get spot price history for volatility analysis
                price_history = await self.client.get_spot_price_history(instance.shape)
                volatility = self._calculate_price_volatility(price_history)
                
                opportunity = {
                    "provider": "oci",
                    "instance_type": instance.shape,
                    "region": instance.region,
                    "on_demand_price": instance.price_per_hour,
                    "spot_price": instance.spot_price_per_hour,
                    "savings_percentage": savings_percentage,
                    "ocpus": instance.ocpus,
                    "memory_gb": instance.memory_in_gbs,
                    "gpus": instance.gpus,
                    "gpu_description": instance.gpu_description,
                    "volatility": volatility,
                    "availability": instance.is_spot_available,
                    "confidence_score": self._calculate_confidence_score(instance, volatility),
                    "timestamp": datetime.now().isoformat()
                }
                
                opportunities.append(opportunity)
        
        # Sort by savings percentage
        opportunities.sort(key=lambda x: x["savings_percentage"], reverse=True)
        
        return opportunities
    
    def _calculate_price_volatility(self, price_history: List[Dict[str, Any]]) -> float:
        """Calculate price volatility from history"""
        if not price_history:
            return 0.0
        
        prices = [item.get("price", 0) for item in price_history if item.get("price")]
        
        if len(prices) < 2:
            return 0.0
        
        # Calculate coefficient of variation
        mean_price = sum(prices) / len(prices)
        variance = sum((price - mean_price) ** 2 for price in prices) / len(prices)
        std_dev = variance ** 0.5
        
        return (std_dev / mean_price) * 100 if mean_price > 0 else 0.0
    
    def _calculate_confidence_score(self, instance: OCIInstance, volatility: float) -> float:
        """Calculate confidence score for arbitrage opportunity"""
        # Base score from savings
        savings_score = min(100, ((instance.price_per_hour - instance.spot_price_per_hour) / instance.price_per_hour) * 100)
        
        # Volatility penalty
        volatility_penalty = min(50, volatility)
        
        # Availability bonus
        availability_bonus = 20 if instance.is_spot_available else 0
        
        # GPU bonus
        gpu_bonus = min(30, instance.gpus * 10)
        
        confidence = savings_score - volatility_penalty + availability_bonus + gpu_bonus
        return max(0, min(100, confidence))
    
    async def get_optimal_instances(self, requirements: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Get optimal instances based on requirements"""
        min_ocpus = requirements.get("min_ocpus", 0)
        min_memory = requirements.get("min_memory_gb", 0)
        min_gpus = requirements.get("min_gpus", 0)
        max_price = requirements.get("max_price_per_hour", 5.0)
        
        optimal_instances = []
        
        for instance in self.instances:
            if (instance.ocpus >= min_ocpus and 
                instance.memory_in_gbs >= min_memory and 
                instance.gpus >= min_gpus and
                instance.spot_price_per_hour <= max_price):
                
                optimal_instances.append({
                    "shape": instance.shape,
                    "ocpus": instance.ocpus,
                    "memory_gb": instance.memory_in_gbs,
                    "gpus": instance.gpus,
                    "gpu_description": instance.gpu_description,
                    "spot_price": instance.spot_price_per_hour,
                    "on_demand_price": instance.price_per_hour,
                    "savings": ((instance.price_per_hour - instance.spot_price_per_hour) / instance.price_per_hour) * 100,
                    "region": instance.region
                })
        
        # Sort by price
        optimal_instances.sort(key=lambda x: x["spot_price"])
        
        return optimal_instances

async def main():
    """Main demonstration function"""
    logging.info("🔧 Oracle Cloud Infrastructure Integration")
    logging.info("=" * 50)
    
    # Mock credentials - would get from environment or config
    credentials = OCICredentials(
        user_ocid="ocid1.user.oc1..example",
        tenancy_ocid="ocid1.tenancy.oc1..example",
        private_key = os.environ.get("PRIVATE_KEY_PRIVATE_KEY", "-----BEGIN PRIVATE KEY-----
...
-----END PRIVATE KEY-----"),
        fingerprint="00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00",
        region="us-ashburn-1",
        compartment_ocid="ocid1.compartment.oc1..example"
    )
    
    # Initialize arbitrage engine
    engine = OCIArbitrageEngine(credentials)
    await engine.initialize()
    
    logging.info(f"\n📊 Found {len(engine.instances)
    
    # Get arbitrage opportunities
    opportunities = await engine.get_arbitrage_opportunities(max_price=3.0)
    
    logging.info(f"\n🎯 Top 5 Arbitrage Opportunities:")
    for i, opp in enumerate(opportunities[:5], 1):
        logging.info(f"{i}. {opp['instance_type']} ({opp['region']})
        logging.info(f"   On-Demand: ${opp['on_demand_price']:.3f}/hr")
        logging.info(f"   Spot: ${opp['spot_price']:.3f}/hr")
        logging.info(f"   Savings: {opp['savings_percentage']:.1f}%")
        logging.info(f"   GPUs: {opp['gpus']} ({opp['gpu_description']})
        logging.info(f"   Confidence: {opp['confidence_score']:.1f}")
        logging.info()
    
    # Get optimal instances for specific requirements
    requirements = {
        "min_ocpus": 4,
        "min_memory_gb": 32,
        "min_gpus": 1,
        "max_price_per_hour": 2.0
    }
    
    optimal = await engine.get_optimal_instances(requirements)
    
    logging.info(f"🎯 Optimal Instances for Requirements:")
    for instance in optimal[:3]:
        logging.info(f"   {instance['shape']}: ${instance['spot_price']:.3f}/hr, {instance['gpus']} GPUs")
    
    logging.info(f"\n🎯 OCI Integration Demo Completed!")

if __name__ == "__main__":
    asyncio.run(main())
