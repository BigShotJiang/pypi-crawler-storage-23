#!/usr/bin/env python3
"""
HuggingFace API Limiting Circumvention Engine
Bypasses traditional cloud provider limitations by leveraging HF's infrastructure
"""

import asyncio
import json
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum

# Hugging Face Hub API
try:
    from huggingface_hub import HfApi, list_models, list_datasets, list_spaces
    from huggingface_hub import create_repo, upload_file, upload_folder
    from huggingface_hub import create_inference_endpoint, create_scheduled_job
    from huggingface_hub import whoami, auth_check
    from huggingface_hub import CommitOperationAdd
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False
    logging.info("⚠️  HuggingFace Hub not available. Install with: pip install huggingface_hub")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HFLimitingStrategy(Enum):
    """Different strategies to circumvent limitations"""
    INFERENCE_ENDPOINTS = "inference_endpoints"
    SCHEDULED_JOBS = "scheduled_jobs"
    MODEL_UPLOADS = "model_uploads"
    DATASET_UPLOADS = "dataset_uploads"
    SPACE_DEPLOYMENT = "space_deployment"
    MULTI_REGION = "multi_region"

@dataclass
class HFCircumventionResult:
    """Result of HF API circumvention"""
    strategy: HFLimitingStrategy
    success: bool
    resource_url: Optional[str]
    resource_id: Optional[str]
    deployment_time: float
    cost_per_hour: float
    limitations_bypassed: List[str]
    hf_infrastructure_used: bool
    timestamp: datetime

class HFLimitingCircumventer:
    """
    Circumvent cloud provider limitations using Hugging Face infrastructure
    """
    
    def __init__(self):
        self.hf_api = None
        self.user_info = None
        self.available_endpoints = []
        self.cached_resources = {}
        
        if HF_AVAILABLE:
            self.hf_api = HfApi()
            logger.info("✅ HuggingFace Hub API client initialized")
        else:
            logger.warning("⚠️  HuggingFace Hub not available")
    
    async def authenticate(self, token: Optional[str] = None) -> bool:
        """Authenticate with Hugging Face Hub"""
        if not HF_AVAILABLE:
            return False
        
        try:
            # Test authentication
            self.user_info = self.hf_api.whoami(token=token)
            logger.info(f"✅ Authenticated as: {self.user_info.username}")
            
            # Check available resources
            await self._scan_available_resources()
            
            return True
            
        except Exception as e:
            logger.error(f"❌ HF authentication failed: {e}")
            return False
    
    async def _scan_available_resources(self):
        """Scan available HF resources and endpoints"""
        try:
            # Check inference endpoints availability
            # This would require checking HF's internal API
            self.available_endpoints = ["inference", "spaces", "models", "datasets"]
            
            # Cache popular models for quick deployment
            popular_models = ["gpt2", "bert-base-uncased", "stable-diffusion-xl"]
            for model_id in popular_models:
                try:
                    model_info = self.hf_api.model_info(model_id)
                    if model_info:
                        self.cached_resources[f"model:{model_id}"] = {
                            'id': model_info.id,
                            'downloads': model_info.downloads,
                            'inference': model_info.inference,
                            'tags': model_info.tags
                        }
                except Exception as e:
                    pass  # Model not found or no access
            
            logger.info(f"📊 Cached {len(self.cached_resources)} popular models")
            
        except Exception as e:
            logger.warning(f"⚠️  Resource scan failed: {e}")
    
    async def circumvent_with_inference_endpoints(self, 
                                                model_id: str,
                                                task: str = "text-generation",
                                                accelerator: str = "gpu",
                                                vendor: str = "aws",
                                                region: str = "us-east-1") -> HFCircumventionResult:
        """
        Circumvent GPU limitations using HF Inference Endpoints
        """
        logger.info(f"🚀 Circumventing GPU limits with HF Inference Endpoints for {model_id}")
        start_time = time.time()
        
        try:
            # Create inference endpoint on HF infrastructure
            endpoint = self.hf_api.create_inference_endpoint(
                name=f"terradev-{model_id.replace('/', '-')}-{int(time.time())}",
                repository=model_id,
                framework="pytorch",
                task=task,
                accelerator=accelerator,
                vendor=vendor,
                region=region,
                type="protected",
                instance_size="x1",
                instance_type="nvidia-a10g",
                min_replica=0,
                scale_to_zero_timeout=15,
                env={
                    "MAX_BATCH_PREFILL_TOKENS": "2048",
                    "MAX_INPUT_LENGTH": "1024",
                    "MAX_TOTAL_TOKENS": "1512",
                    "MODEL_ID": f"/repository"
                }
            )
            
            # Wait for endpoint to be ready
            deployment_time = await self._wait_for_endpoint_ready(endpoint.name, timeout=300)
            
            result = HFCircumventionResult(
                strategy=HFLimitingStrategy.INFERENCE_ENDPOINTS,
                success=True,
                resource_url=endpoint.url,
                resource_id=endpoint.name,
                deployment_time=deployment_time,
                cost_per_hour=self._calculate_inference_cost(accelerator, instance_size, vendor),
                limitations_bypassed=[
                    "No GPU quota limits",
                    "No regional restrictions", 
                    "No provider rate limits",
                    "No hardware availability issues",
                    "No credit card requirements"
                ],
                hf_infrastructure_used=True,
                timestamp=datetime.now()
            )
            
            logger.info(f"✅ Inference endpoint created: {endpoint.name}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Inference endpoint creation failed: {e}")
            
            return HFCircumventionResult(
                strategy=HFLimitingStrategy.INFERENCE_ENDPOINTS,
                success=False,
                resource_url=None,
                resource_id=None,
                deployment_time=0.0,
                cost_per_hour=0.0,
                limitations_bypassed=[],
                hf_infrastructure_used=False,
                timestamp=datetime.now()
            )
    
    async def circumvent_with_scheduled_jobs(self,
                                          script_or_command: str,
                                          schedule: str = "@hourly",
                                          flavor: str = "a10g-small",
                                          dependencies: List[str] = None,
                                          env_vars: Dict = None) -> HFCircumventionResult:
        """
        Circumvent compute limitations using HF Scheduled Jobs
        """
        logger.info(f"🚀 Circumventing compute limits with HF Scheduled Jobs")
        start_time = time.time()
        
        try:
            # Create scheduled job on HF infrastructure
            job = self.hf_api.create_scheduled_job(
                image="python:3.12",
                command=[script_or_command] if isinstance(script_or_command, list) else [script_or_command],
                schedule=schedule,
                flavor=flavor,
                dependencies=dependencies or [],
                env=env_vars or {},
                timeout="1h"
            )
            
            result = HFCircumventionResult(
                strategy=HFLimitingStrategy.SCHEDULED_JOBS,
                success=True,
                resource_url=f"https://huggingface.co/jobs/{job.id}",
                resource_id=job.id,
                deployment_time=0.0,  # Scheduled jobs start immediately
                cost_per_hour=self._calculate_job_cost(flavor),
                limitations_bypassed=[
                    "No compute quota limits",
                    "No regional restrictions",
                    "No hardware availability issues",
                    "No credit card requirements",
                    "No manual setup required"
                ],
                hf_infrastructure_used=True,
                timestamp=datetime.now()
            )
            
            logger.info(f"✅ Scheduled job created: {job.id}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Scheduled job creation failed: {e}")
            
            return HFCircumventionResult(
                strategy=HFLimitingStrategy.SCHEDULED_JOBS,
                success=False,
                resource_url=None,
                resource_id=None,
                deployment_time=0.0,
                cost_per_hour=0.0,
                limitations_bypassed=[],
                hf_infrastructure_used=False,
                timestamp=datetime.now()
            )
    
    async def circumvent_with_model_uploads(self,
                                         model_files: Dict[str, str],
                                         model_name: str,
                                         description: str = "Terradev optimized model") -> HFCircumventionResult:
        """
        Circumvent storage limitations using HF Model Hub
        """
        logger.info(f"🚀 Circumventing storage limits with HF Model Hub for {model_name}")
        start_time = time.time()
        
        try:
            # Create repo if it doesn't exist
            repo_id = f"{self.user_info.username}/{model_name}"
            repo_url = self.hf_api.create_repo(
                repo_id=repo_id,
                repo_type="model",
                private=False,
                exist_ok=True
            )
            
            # Upload model files
            operations = []
            for file_path, content in model_files.items():
                operations.append(
                    CommitOperationAdd(
                        path_in_repo=file_path,
                        path_or_fileobj=content.encode() if isinstance(content, str) else content
                    )
                )
            
            commit_info = self.hf_api.create_commit(
                repo_id=repo_id,
                operations=operations,
                commit_message=f"Upload {model_name} - {description}",
                repo_type="model"
            )
            
            result = HFCircumventionResult(
                strategy=HFLimitingStrategy.MODEL_UPLOADS,
                success=True,
                resource_url=repo_url.url,
                resource_id=repo_id,
                deployment_time=time.time() - start_time,
                cost_per_hour=0.0,  # HF Hub storage is free
                limitations_bypassed=[
                    "No storage quota limits",
                    "No bandwidth limitations",
                    "No regional restrictions",
                    "No egress costs",
                    "Free hosting"
                ],
                hf_infrastructure_used=True,
                timestamp=datetime.now()
            )
            
            logger.info(f"✅ Model uploaded to HF Hub: {repo_id}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Model upload failed: {e}")
            
            return HFCircumventionResult(
                strategy=HFLimitingStrategy.MODEL_UPLOADS,
                success=False,
                resource_url=None,
                resource_id=None,
                deployment_time=0.0,
                cost_per_hour=0.0,
                limitations_bypassed=[],
                hf_infrastructure_used=False,
                timestamp=datetime.now()
            )
    
    async def circumvent_with_dataset_uploads(self,
                                           dataset_files: Dict[str, str],
                                           dataset_name: str,
                                           description: str = "Terradev dataset") -> HFCircumventionResult:
        """
        Circumvent data limitations using HF Dataset Hub
        """
        logger.info(f"🚀 Circumventing data limits with HF Dataset Hub for {dataset_name}")
        start_time = time.time()
        
        try:
            # Create dataset repo if it doesn't exist
            repo_id = f"{self.user_info.username}/{dataset_name}"
            repo_url = self.hf_api.create_repo(
                repo_id=repo_id,
                repo_type="dataset",
                private=False,
                exist_ok=True
            )
            
            # Upload dataset files
            operations = []
            for file_path, content in dataset_files.items():
                operations.append(
                    CommitOperationAdd(
                        path_in_repo=file_path,
                        path_or_fileobj=content.encode() if isinstance(content, str) else content
                    )
                )
            
            commit_info = self.hf_api.create_commit(
                repo_id=repo_id,
                operations=operations,
                commit_message=f"Upload {dataset_name} - {description}",
                repo_type="dataset"
            )
            
            result = HFCircumventionResult(
                strategy=HFLimitingStrategy.DATASET_UPLOADS,
                success=True,
                resource_url=repo_url.url,
                resource_id=repo_id,
                deployment_time=time.time() - start_time,
                cost_per_hour=0.0,  # HF Hub storage is free
                limitations_bypassed=[
                    "No storage quota limits",
                    "No bandwidth limitations",
                    "No regional restrictions",
                    "No egress costs",
                    "Free hosting"
                ],
                hf_infrastructure_used=True,
                timestamp=datetime.now()
            )
            
            logger.info(f"✅ Dataset uploaded to HF Hub: {repo_id}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Dataset upload failed: {e}")
            
            return HFCircumventionResult(
                strategy=HFLimitingStrategy.DATASET_UPLOADS,
                success=False,
                resource_url=None,
                resource_id=None,
                deployment_time=0.0,
                cost_per_hour=0.0,
                limitations_bypassed=[],
                hf_infrastructure_used=False,
                timestamp=datetime.now()
            )
    
    async def circumvent_with_space_deployment(self,
                                         app_code: str,
                                         space_name: str,
                                         sdk: str = "gradio",
                                         hardware: str = "cpu-basic") -> HFCircumventionResult:
        """
        Circumvent deployment limitations using HF Spaces
        """
        logger.info(f"🚀 Circumventing deployment limits with HF Spaces for {space_name}")
        start_time = time.time()
        
        try:
            # Create Space
            space_url = self.hf_api.create_repo(
                repo_id=f"{self.user_info.username}/{space_name}",
                repo_type="space",
                space_sdk=sdk,
                space_hardware=hardware,
                private=False,
                exist_ok=True
            )
            
            # Upload app code
            app_file = CommitOperationAdd(
                path_in_repo="app.py",
                path_or_fileobj=app_code.encode()
            )
            
            commit_info = self.hf_api.create_commit(
                repo_id=f"{self.user_info.username}/{space_name}",
                operations=[app_file],
                commit_message=f"Deploy {space_name} app",
                repo_type="space"
            )
            
            result = HFCircumventionResult(
                strategy=HFLimitingStrategy.SPACE_DEPLOYMENT,
                success=True,
                resource_url=space_url.url,
                resource_id=f"{self.user_info.username}/{space_name}",
                deployment_time=time.time() - start_time,
                cost_per_hour=self._calculate_space_cost(hardware),
                limitations_bypassed=[
                    "No deployment restrictions",
                    "No hardware limitations",
                    "No regional restrictions",
                    "Free tier available",
                    "Custom domains supported"
                ],
                hf_infrastructure_used=True,
                timestamp=datetime.now()
            )
            
            logger.info(f"✅ Space deployed: {space_name}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Space deployment failed: {e}")
            
            return HFCircumventionResult(
                strategy=HFLimitingStrategy.SPACE_DEPLOYMENT,
                success=False,
                resource_url=None,
                resource_id=None,
                deployment_time=0.0,
                cost_per_hour=0.0,
                limitations_bypassed=[],
                hf_infrastructure_used=False,
                timestamp=datetime.now()
            )
    
    async def _wait_for_endpoint_ready(self, endpoint_name: str, timeout: int = 300) -> float:
        """Wait for inference endpoint to be ready"""
        start_time = time.time()
        
        try:
            # Check endpoint status periodically
            while time.time() - start_time < timeout:
                endpoint = self.hf_api.get_inference_endpoint(endpoint_name)
                
                if endpoint.status == "ready":
                    return time.time() - start_time
                elif endpoint.status == "failed":
                    raise Exception(f"Endpoint failed: {endpoint.error_message}")
                
                await asyncio.sleep(10)  # Check every 10 seconds
            
            raise TimeoutError(f"Endpoint not ready within {timeout}s")
            
        except Exception as e:
            logger.error(f"⚠️  Endpoint status check failed: {e}")
            return timeout
    
    def _calculate_inference_cost(self, accelerator: str, instance_size: str, vendor: str) -> float:
        """Calculate inference endpoint cost per hour"""
        # HF pricing (approximate)
        pricing = {
            ("cpu", "basic"): 0.10,
            ("cpu", "x2"): 0.20,
            ("cpu", "x4"): 0.40,
            ("gpu", "a10g"): 0.60,
            ("gpu", "a10g-large"): 1.20,
            ("gpu", "a100"): 3.00,
            ("gpu", "a100-large"): 6.00,
        }
        
        key = f"{accelerator}_{instance_size}"
        return pricing.get(key, 1.0)
    
    def _calculate_job_cost(self, flavor: str) -> float:
        """Calculate scheduled job cost per hour"""
        # HF pricing (approximate)
        pricing = {
            "cpu-basic": 0.10,
            "cpu-upgrade": 0.20,
            "cpu-large": 0.40,
            "a10g-small": 0.60,
            "a10g-large": 1.20,
            "a100-small": 3.00,
            "a100-large": 6.00,
        }
        
        return pricing.get(flavor, 0.10)
    
    def _calculate_space_cost(self, hardware: str) -> float:
        """Calculate Space cost per hour"""
        # HF pricing (approximate)
        pricing = {
            "cpu-basic": 0.10,
            "cpu-upgrade": 0.20,
            "cpu-large": 0.40,
            "a10g-small": 0.60,
            "a10g-large": 1.20,
            "a100-small": 3.00,
            "a100-large": 6.00,
        }
        
        return pricing.get(hardware, 0.10)
    
    async def get_available_models(self) -> List[Dict]:
        """Get list of available models for quick deployment"""
        models = []
        
        try:
            # Get popular models with inference support
            model_list = self.hf_api.list_models(
                filter="inference:warm",
                sort="downloads",
                limit=10,
                full=False
            )
            
            for model in model_list:
                models.append({
                    'id': model.id,
                    'modelId': model.modelId,
                    'downloads': model.downloads,
                    'tags': model.tags,
                    'pipeline_tag': model.pipeline_tag,
                    'inference': model.inference
                })
            
        except Exception as e:
            logger.warning(f"⚠️  Failed to get models: {e}")
        
        return models
    
    async def get_optimal_strategy(self, requirements: Dict) -> HFLimitingStrategy:
        """
        Determine optimal HF circumvention strategy based on requirements
        """
        gpu_required = requirements.get('gpu_required', False)
        storage_required = requirements.get('storage_required', False)
        deployment_required = requirements.get('deployment_required', False)
        compute_required = requirements.get('compute_required', False)
        
        if gpu_required and deployment_required:
            return HFLimitingStrategy.INFERENCE_ENDPOINTS
        elif compute_required:
            return HFLimitingStrategy.SCHEDULED_JOBS
        elif storage_required:
            return HFLimitingStrategy.MODEL_UPLOADS
        elif deployment_required:
            return HFLimitingStrategy.SPACE_DEPLOYMENT
        else:
            return HFLimitingStrategy.MODEL_UPLOADS  # Default

class HFLimitingOrchestrator:
    """
    Orchestrates HF-based circumvention strategies
    """
    
    def __init__(self):
        self.circumventer = HFLimitingCircumventer()
        self.active_circumventions = {}
        self.cost_tracker = {
            'hourly_costs': 0.0,
            'total_savings': 0.0,
            'limitations_bypassed': []
        }
    
    async def orchestrate_circumvention(self, requirements: Dict) -> List[HFCircumventionResult]:
        """
        Orchestrate multiple HF circumvention strategies
        """
        logger.info("🚀 Starting HF Limiting Circumvention Orchestration")
        
        # Authenticate first
        if not await self.circumventer.authenticate():
            return []
        
        # Determine optimal strategy
        strategy = await self.circumventer.get_optimal_strategy(requirements)
        logger.info(f"🎯 Optimal strategy: {strategy.value}")
        
        results = []
        
        # Execute circumvention based on strategy
        if strategy == HFLimitingStrategy.INFERENCE_ENDPOINTS:
            result = await self._execute_inference_circumvention(requirements)
            if result.success:
                results.append(result)
        
        elif strategy == HFLimitingStrategy.SCHEDULED_JOBS:
            result = await self._execute_scheduled_job_circumvention(requirements)
            if result.success:
                results.append(result)
        
        elif strategy == HFLimitingStrategy.MODEL_UPLOADS:
            result = await self._execute_model_upload_circumvention(requirements)
            if result.success:
                results.append(result)
        
        elif strategy == HFLimitingStrategy.DATASET_UPLOADS:
            result = await self._execute_dataset_upload_circumvention(requirements)
            if result.success:
                results.append(result)
        
        elif strategy == HFLimitingStrategy.SPACE_DEPLOYMENT:
            result = await self._execute_space_circumvention(requirements)
            if result.success:
                results.append(result)
        
        # Update cost tracking
        self._update_cost_tracking(results)
        
        return results
    
    async def _execute_inference_circumvention(self, requirements: Dict) -> HFCircumventionResult:
        """Execute inference endpoint circumvention"""
        model_id = requirements.get('model_id', 'gpt2')
        task = requirements.get('task', 'text-generation')
        accelerator = requirements.get('accelerator', 'gpu')
        vendor = requirements.get('vendor', 'aws')
        region = requirements.get('region', 'us-east-1')
        
        return await self.circumventer.circumvent_with_inference_endpoints(
            model_id, task, accelerator, vendor, region
        )
    
    async def _execute_scheduled_job_circumvention(self, requirements: Dict) -> HFCircumventionResult:
        """Execute scheduled job circumvention"""
        script = requirements.get('script', 'print("Hello from HF compute!")')
        schedule = requirements.get('schedule', '@hourly')
        flavor = requirements.get('flavor', 'cpu-basic')
        
        return await self.circumventer.circumvent_with_scheduled_jobs(
            script, schedule, flavor
        )
    
    async def _execute_model_upload_circumvention(self, requirements: Dict) -> HFCircumventionResult:
        """Execute model upload circumvention"""
        model_files = requirements.get('model_files', {})
        model_name = requirements.get('model_name', 'terradev-model')
        description = requirements.get('description', 'Terradev optimized model')
        
        return await self.circumventer.circumvent_with_model_uploads(
            model_files, model_name, description
        )
    
    async def _execute_dataset_upload_circumvention(self, requirements: Dict) -> HFCircumventionResult:
        """Execute dataset upload circumvention"""
        dataset_files = requirements.get('dataset_files', {})
        dataset_name = requirements.get('dataset_name', 'terradev-dataset')
        description = requirements.get('description', 'Terradev dataset')
        
        return await self.circumventer.circumvent_with_dataset_uploads(
            dataset_files, dataset_name, description
        )
    
    async def _execute_space_circumvention(self, requirements: Dict) -> HFCircumventionResult:
        """Execute space deployment circumvention"""
        app_code = requirements.get('app_code', 'print("Hello World")')
        space_name = requirements.get('space_name', 'terradev-app')
        sdk = requirements.get('sdk', 'gradio')
        hardware = requirements.get('hardware', 'cpu-basic')
        
        return await self.circumventer.circumvent_with_space_deployment(
            app_code, space_name, sdk, hardware
        )
    
    def _update_cost_tracking(self, results: List[HFCircumventionResult]):
        """Update cost tracking"""
        for result in results:
            if result.success:
                self.cost_tracker['hourly_costs'] += result.cost_per_hour
                self.cost_tracker['total_savings'] += result.cost_per_hour * 24 * 30  # Monthly estimate
                self.cost_tracker['limitations_bypassed'].extend(result.limitations_bypassed)
    
    def get_cost_summary(self) -> Dict:
        """Get cost summary"""
        return {
            'hourly_costs': self.cost_tracker['hourly_costs'],
            'monthly_savings': self.cost_tracker['total_savings'],
            'limitations_bypassed': list(set(self.cost_tracker['limitations_bypassed'])),
            'active_circumventions': len(self.active_circumventions),
            'timestamp': datetime.now().isoformat()
        }

# CLI interface
async def main():
    """CLI interface for HF limiting circumvention"""
    import argparse
    
    parser = argparse.ArgumentParser(description='HF Limiting Circumvention Engine')
    parser.add_argument('--circumvent', action='store_true', help='Run HF limiting circumvention')
    parser.add_argument('--token', help='HF Hub token')
    parser.add_argument('--model-id', default='gpt2', help='Model ID for inference endpoints')
    parser.add_argument('--task', default='text-generation', help='Task for inference')
    parser.add_argument('--gpu', action='store_true', help='GPU required')
    parser.add_argument('--compute', action='store_true', help='Compute required')
    parser.add_argument('--storage', action='store_true', help='Storage required')
    parser.add_argument('--deployment', action='store_true', help='Deployment required')
    
    args = parser.parse_args()
    
    if args.circumvent:
        logging.info("🚀 HF Limiting Circumvention Engine")
        logging.info("=" * 50)
        logging.info("🔥 Bypassing traditional cloud limitations with Hugging Face infrastructure")
        logging.info()
        
        orchestrator = HFLimitingOrchestrator()
        
        # Define requirements
        requirements = {
            'gpu_required': args.gpu,
            'compute_required': args.compute,
            'storage_required': args.storage,
            'deployment_required': args.deployment,
            'model_id': args.model_id,
            'task': args.task
        }
        
        logging.info(f"📋 Requirements: {requirements}")
        logging.info()
        
        # Authenticate
        if not await orchestrator.circumventer.authenticate(args.token):
            logging.info("❌ Authentication failed. Please check your HF token.")
            return
        
        # Get available models
        models = await orchestrator.circumventer.get_available_models()
        logging.info(f"📊 Available models: {[m["id"] for m in models[:5]]}")
        logging.info()
        
        # Orchestrate circumvention
        results = await orchestrator.orchestrate_circumvention(requirements)
        
        logging.info("🏆 CIRCUMVENTION RESULTS:")
        logging.info("=" * 50)
        
        for i, result in enumerate(results, 1):
            logging.info(f"{i}. Strategy: {result.strategy.value}")
            logging.info(f"   Success: {'✅' if result.success else '❌'}")
            if result.success:
                logging.info(f"   Resource: {result.resource_id}")
                logging.info(f"   URL: {result.resource_url}")
                logging.info(f"   Deployment Time: {result.deployment_time:.1f}s")
                logging.info(f"   Cost/Hour: ${result.cost_per_hour:.2f}")
                logging.info(f"   Limitations Bypassed: {len(result.limitations_bypassed)
            else:
                logging.info(f"   Error: Circumvention failed")
            logging.info()
        
        # Cost summary
        cost_summary = orchestrator.get_cost_summary()
        logging.info("💰 COST SUMMARY:")
        logging.info(f"   Hourly Costs: ${cost_summary['hourly_costs']:.2f}")
        logging.info(f"   Monthly Savings: ${cost_summary['monthly_savings']:.2f}")
        logging.info(f"   Limitations Bypassed: {len(cost_summary['limitations_bypassed'])
        logging.info(f"   Active Circumventions: {cost_summary['active_circumventions']}")
        
    else:
        parser.print_help()

if __name__ == "__main__":
    asyncio.run(main())
