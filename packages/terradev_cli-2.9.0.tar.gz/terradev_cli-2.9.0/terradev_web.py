#!/usr/bin/env python3
"""
Terradev Web Interface - Time & Latency Arbitrage
Web-based implementation for immediate exploitation
"""

import asyncio
import json
import time
import ping3
import subprocess
import logging
import os
import tempfile
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path

# Web framework
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# SkyPilot imports
import skypilot
from skypilot import sky

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="Terradev Web Arbitrage", version="1.0.0")

# CORS for web interface — explicit origins only
_allowed_origins = os.getenv("CORS_ORIGINS", "https://terradev.com,https://app.terradev.com").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in _allowed_origins],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
)

@dataclass
class TimeArbitrageOpportunity:
    """Time-based arbitrage opportunity"""
    provider: str
    region: str
    current_hour: int
    peak_hours: List[int]
    off_peak_discount: float
    regular_price: float
    off_peak_price: float
    savings_per_hour: float
    roi_percentage: float
    time_window: str
    urgency: str

@dataclass
class LatencyArbitrageOpportunity:
    """Latency arbitrage opportunity"""
    user_location: str
    optimal_provider: str
    optimal_region: str
    latency_ms: float
    price_per_hour: float
    latency_benefit_value: float
    net_roi: float

class WebTimeArbitrageEngine:
    """Time-based arbitrage for web interface"""
    
    def __init__(self):
        self.provider_patterns = {
            'aws': {
                'us-east-1': {
                    'peak_hours': [9, 10, 11, 14, 15, 16],  # 9-11am, 2-4pm EST
                    'off_peak_discount': 0.25,  # 25% discount
                    'base_price': 2.50
                },
                'us-west-1': {
                    'peak_hours': [10, 11, 12, 13, 14, 15],  # 10am-3pm PST
                    'off_peak_discount': 0.30,
                    'base_price': 2.40
                },
                'us-west-2': {
                    'peak_hours': [10, 11, 12, 13, 14, 15],
                    'off_peak_discount': 0.28,
                    'base_price': 2.35
                },
                'eu-west-1': {
                    'peak_hours': [8, 9, 10, 11, 14, 15, 16],  # 8-11am, 2-4pm GMT
                    'off_peak_discount': 0.35,
                    'base_price': 2.80
                }
            }
        }
    
    def scan_time_opportunities(self) -> List[TimeArbitrageOpportunity]:
        """Scan for time-based arbitrage opportunities"""
        opportunities = []
        current_hour = datetime.now().hour
        
        for provider, regions in self.provider_patterns.items():
            for region, pattern in regions.items():
                is_off_peak = current_hour not in pattern['peak_hours']
                
                if is_off_peak:
                    regular_price = pattern['base_price']
                    off_peak_price = regular_price * (1 - pattern['off_peak_discount'])
                    savings = regular_price - off_peak_price
                    roi = pattern['off_peak_discount'] * 100
                    
                    # Calculate time window until next peak
                    next_peak_hour = min([h for h in pattern['peak_hours'] if h > current_hour], 
                                        default=pattern['peak_hours'][0] + 24)
                    hours_until_peak = next_peak_hour - current_hour
                    
                    opportunity = TimeArbitrageOpportunity(
                        provider=provider.upper(),
                        region=region,
                        current_hour=current_hour,
                        peak_hours=pattern['peak_hours'],
                        off_peak_discount=pattern['off_peak_discount'],
                        regular_price=regular_price,
                        off_peak_price=off_peak_price,
                        savings_per_hour=savings,
                        roi_percentage=roi,
                        time_window=f"Next {hours_until_peak} hours",
                        urgency="HIGH" if hours_until_peak < 4 else "MEDIUM"
                    )
                    
                    opportunities.append(opportunity)
        
        return sorted(opportunities, key=lambda x: x.roi_percentage, reverse=True)
    
    def get_current_schedule_recommendation(self) -> Dict:
        """Get current scheduling recommendation"""
        current_hour = datetime.now().hour
        recommendations = []
        
        for provider, regions in self.provider_patterns.items():
            for region, pattern in regions.items():
                is_off_peak = current_hour not in pattern['peak_hours']
                
                if is_off_peak:
                    recommendations.append({
                        'action': 'DEPLOY_NOW',
                        'provider': provider.upper(),
                        'region': region,
                        'reason': f'Off-peak discount: {pattern["off_peak_discount"]*100:.0f}%',
                        'savings': f'${pattern["base_price"] * pattern["off_peak_discount"]:.2f}/hour',
                        'urgency': 'Deploy now for maximum savings'
                    })
                else:
                    # Find next off-peak window
                    next_off_peak = current_hour + 1
                    while next_off_peak in pattern['peak_hours']:
                        next_off_peak += 1
                        if next_off_peak >= 24:
                            next_off_peak -= 24
                    
                    recommendations.append({
                        'action': 'WAIT',
                        'provider': provider.upper(),
                        'region': region,
                        'reason': f'Currently peak pricing. Off-peak starts at {next_off_peak}:00',
                        'wait_time': f'{next_off_peak - current_hour} hours',
                        'potential_savings': f'${pattern["base_price"] * pattern["off_peak_discount"]:.2f}/hour'
                    })
        
        return {
            'current_hour': current_hour,
            'recommendations': recommendations,
            'best_action': max(recommendations, key=lambda x: float(x.get('savings', '0').replace('$', '').split('/')[0]))
        }

class WebLatencyArbitrageEngine:
    """Latency arbitrage for web interface"""
    
    def __init__(self):
        self.user_locations = {
            'us_east_coast': {
                'latency_targets': {
                    'aws-us-east-1': {'latency': 25, 'price': 2.50},
                    'azure-eastus': {'latency': 35, 'price': 2.60},
                    'gcp-us-east1': {'latency': 30, 'price': 2.45}
                }
            },
            'us_west_coast': {
                'latency_targets': {
                    'aws-us-west-1': {'latency': 20, 'price': 2.40},
                    'aws-us-west-2': {'latency': 15, 'price': 2.35},
                    'gcp-us-west1': {'latency': 25, 'price': 2.50}
                }
            },
            'europe': {
                'latency_targets': {
                    'aws-eu-west-1': {'latency': 30, 'price': 2.80},
                    'azure-westeurope': {'latency': 25, 'price': 2.70},
                    'gcp-europe-west1': {'latency': 35, 'price': 2.75}
                }
            },
            'asia_pacific': {
                'latency_targets': {
                    'aws-ap-southeast-1': {'latency': 40, 'price': 3.20},
                    'gcp-asia-southeast1': {'latency': 35, 'price': 3.10}
                }
            }
        }
        
        self.latency_value_per_ms = 0.01  # $0.01 per ms of latency improvement
    
    async def measure_real_latency(self, provider: str, region: str) -> float:
        """Measure real latency to provider region"""
        # Simulate real latency measurement
        # In production, this would ping actual endpoints
        base_latencies = {
            'aws-us-east-1': 25,
            'aws-us-west-1': 20,
            'aws-us-west-2': 15,
            'azure-eastus': 35,
            'azure-westeurope': 25,
            'gcp-us-east1': 30,
            'gcp-us-west1': 25,
            'gcp-europe-west1': 35
        }
        
        key = f"{provider}-{region}"
        base_latency = base_latencies.get(key, 50)
        
        # Add some randomness to simulate real conditions
        import random
        variation = random.uniform(-5, 5)
        
        return max(5, base_latency + variation)
    
    def scan_latency_opportunities(self) -> List[LatencyArbitrageOpportunity]:
        """Scan for latency arbitrage opportunities"""
        opportunities = []
        
        for location, targets in self.user_locations.items():
            # Find optimal provider for this location
            best_provider = None
            best_roi = -999
            
            for provider_region, data in targets['latency_targets'].items():
                # Calculate latency value
                latency_value = data['latency'] * self.latency_value_per_ms
                
                # Find cheapest alternative
                alternatives = [v for k, v in targets['latency_targets'].items() if k != provider_region]
                if alternatives:
                    cheapest_alt = min(alternatives, key=lambda x: x['price'])
                    
                    # Calculate ROI
                    price_diff = cheapest_alt['price'] - data['price']
                    latency_diff = cheapest_alt['latency'] - data['latency']
                    
                    if latency_diff > 0:  # This provider has better latency
                        net_roi = (latency_diff * self.latency_value_per_ms) - price_diff
                        
                        if net_roi > best_roi:
                            best_roi = net_roi
                            best_provider = provider_region
            
            if best_provider and best_roi > 0:
                provider_data = targets['latency_targets'][best_provider]
                
                opportunity = LatencyArbitrageOpportunity(
                    user_location=location.replace('_', ' ').title(),
                    optimal_provider=best_provider.split('-')[0].upper(),
                    optimal_region=best_provider.split('-')[1],
                    latency_ms=provider_data['latency'],
                    price_per_hour=provider_data['price'],
                    latency_benefit_value=provider_data['latency'] * self.latency_value_per_ms,
                    net_roi=best_roi
                )
                
                opportunities.append(opportunity)
        
        return sorted(opportunities, key=lambda x: x.net_roi, reverse=True)
    
    async def get_real_time_latency_analysis(self, user_location: str) -> Dict:
        """Get real-time latency analysis for specific location"""
        if user_location not in self.user_locations:
            return {'error': f'Location {user_location} not supported'}
        
        targets = self.user_locations[user_location]['latency_targets']
        
        # Measure real latencies
        real_measurements = {}
        for provider_region in targets:
            provider, region = provider_region.split('-')
            real_latency = await self.measure_real_latency(provider, region)
            real_measurements[provider_region] = {
                'measured_latency': real_latency,
                'expected_latency': targets[provider_region]['latency'],
                'price': targets[provider_region]['price'],
                'latency_score': real_latency
            }
        
        # Find optimal choice
        optimal = min(real_measurements.items(), key=lambda x: x[1]['latency_score'])
        
        return {
            'user_location': user_location.replace('_', ' ').title(),
            'measurements': real_measurements,
            'optimal_choice': {
                'provider_region': optimal[0],
                'latency_ms': optimal[1]['measured_latency'],
                'price_per_hour': optimal[1]['price'],
                'recommendation': f'Deploy to {optimal[0].upper()} for best latency'
            },
            'analysis_timestamp': datetime.now().isoformat()
        }

# Global instances
time_engine = WebTimeArbitrageEngine()
latency_engine = WebLatencyArbitrageEngine()

# Web Routes
@app.get("/", response_class=HTMLResponse)
async def dashboard():
    """Main dashboard"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>🚀 Terradev Web Arbitrage</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: .5; }
            }
            .animate-pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        </style>
    </head>
    <body class="bg-gray-900 text-white">
        <div class="container mx-auto p-6">
            <header class="mb-8">
                <h1 class="text-4xl font-bold text-center mb-2">🚀 Terradev Web Arbitrage</h1>
                <p class="text-center text-gray-400">Real-time Time & Latency GPU Arbitrage</p>
            </header>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <!-- Time Arbitrage Card -->
                <div class="bg-gray-800 rounded-lg p-6 border border-gray-700">
                    <h2 class="text-2xl font-bold mb-4 text-green-400">⏰ Time Arbitrage</h2>
                    <div id="time-opportunities" class="space-y-4">
                        <div class="text-gray-400">Loading time opportunities...</div>
                    </div>
                </div>
                
                <!-- Latency Arbitrage Card -->
                <div class="bg-gray-800 rounded-lg p-6 border border-gray-700">
                    <h2 class="text-2xl font-bold mb-4 text-blue-400">🌐 Latency Arbitrage</h2>
                    <div id="latency-opportunities" class="space-y-4">
                        <div class="text-gray-400">Loading latency opportunities...</div>
                    </div>
                </div>
            </div>
            
            <!-- Current Recommendations -->
            <div class="bg-gray-800 rounded-lg p-6 border border-gray-700 mb-8">
                <h2 class="text-2xl font-bold mb-4 text-yellow-400">💡 Current Recommendations</h2>
                <div id="current-recommendations" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="text-gray-400">Loading recommendations...</div>
                </div>
            </div>
            
            <!-- Real-time Controls -->
            <div class="bg-gray-800 rounded-lg p-6 border border-gray-700">
                <h2 class="text-2xl font-bold mb-4 text-purple-400">🎛️ Real-time Controls</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <button onclick="refreshData()" class="bg-green-600 hover:bg-green-700 px-4 py-2 rounded">
                        🔄 Refresh Data
                    </button>
                    <button onclick="executeTimeArbitrage()" class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded">
                        ⏰ Execute Time Arbitrage
                    </button>
                    <button onclick="measureLatency()" class="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded">
                        🌐 Measure Latency
                    </button>
                </div>
            </div>
        </div>
        
        <script>
            async function loadData() {
                try {
                    // Load time opportunities
                    const timeResponse = await fetch('/api/time-opportunities');
                    const timeData = await timeResponse.json();
                    displayTimeOpportunities(timeData);
                    
                    // Load latency opportunities
                    const latencyResponse = await fetch('/api/latency-opportunities');
                    const latencyData = await latencyResponse.json();
                    displayLatencyOpportunities(latencyData);
                    
                    // Load recommendations
                    const recResponse = await fetch('/api/recommendations');
                    const recData = await recResponse.json();
                    displayRecommendations(recData);
                } catch (error) {
                    console.error('Error loading data:', error);
                }
            }
            
            function displayTimeOpportunities(opportunities) {
                const container = document.getElementById('time-opportunities');
                container.innerHTML = opportunities.map(opp => `
                    <div class="bg-gray-700 rounded p-4 border-l-4 ${opp.urgency === 'HIGH' ? 'border-green-500' : 'border-yellow-500'}">
                        <div class="flex justify-between items-start">
                            <div>
                                <h3 class="font-bold text-green-400">${opp.provider} - ${opp.region}</h3>
                                <p class="text-sm text-gray-300">Current: ${opp.current_hour}:00</p>
                                <p class="text-sm">Off-peak discount: ${opp.off_peak_discount * 100}%</p>
                            </div>
                            <div class="text-right">
                                <p class="text-xl font-bold text-green-400">${opp.roi_percentage.toFixed(1)}% ROI</p>
                                <p class="text-sm">$${opp.savings_per_hour.toFixed(2)}/hr savings</p>
                                <p class="text-xs text-gray-400">${opp.time_window}</p>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
            
            function displayLatencyOpportunities(opportunities) {
                const container = document.getElementById('latency-opportunities');
                container.innerHTML = opportunities.map(opp => `
                    <div class="bg-gray-700 rounded p-4 border-l-4 border-blue-500">
                        <div class="flex justify-between items-start">
                            <div>
                                <h3 class="font-bold text-blue-400">${opp.user_location}</h3>
                                <p class="text-sm text-gray-300">${opp.optimal_provider} - ${opp.optimal_region}</p>
                                <p class="text-sm">Latency: ${opp.latency_ms}ms</p>
                            </div>
                            <div class="text-right">
                                <p class="text-xl font-bold text-blue-400">$${opp.net_roi.toFixed(2)}/hr</p>
                                <p class="text-sm">$${opp.price_per_hour.toFixed(2)}/hr</p>
                                <p class="text-xs text-gray-400">Net ROI</p>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
            
            function displayRecommendations(recommendations) {
                const container = document.getElementById('current-recommendations');
                const bestAction = recommendations.best_action;
                
                container.innerHTML = `
                    <div class="bg-gray-700 rounded p-4 border-l-4 border-yellow-500">
                        <h3 class="font-bold text-yellow-400 mb-2">Best Action Now</h3>
                        <p class="text-lg">${bestAction.action}: ${bestAction.provider} - ${bestAction.region}</p>
                        <p class="text-sm text-gray-300">${bestAction.reason}</p>
                        <p class="text-sm">${bestAction.urgency}</p>
                    </div>
                    <div class="bg-gray-700 rounded p-4">
                        <h3 class="font-bold text-gray-400 mb-2">Current Hour: ${recommendations.current_hour}:00</h3>
                        <div class="space-y-2">
                            ${recommendations.recommendations.slice(0, 3).map(rec => `
                                <div class="text-sm">
                                    <span class="${rec.action === 'DEPLOY_NOW' ? 'text-green-400' : 'text-yellow-400'}">${rec.action}</span>: ${rec.provider} - ${rec.region}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }
            
            async function refreshData() {
                await loadData();
            }
            
            async function executeTimeArbitrage() {
                alert('Time arbitrage execution would trigger SkyPilot deployment');
            }
            
            async function measureLatency() {
                alert('Latency measurement would ping real provider endpoints');
            }
            
            // Load data on page load
            loadData();
            
            // Auto-refresh every 30 seconds
            setInterval(loadData, 30000);
        </script>
    </body>
    </html>
    """

@app.get("/api/time-opportunities")
async def get_time_opportunities():
    """Get time-based arbitrage opportunities"""
    opportunities = time_engine.scan_time_opportunities()
    return [asdict(opp) for opp in opportunities]

@app.get("/api/latency-opportunities")
async def get_latency_opportunities():
    """Get latency arbitrage opportunities"""
    opportunities = latency_engine.scan_latency_opportunities()
    return [asdict(opp) for opp in opportunities]

@app.get("/api/recommendations")
async def get_recommendations():
    """Get current recommendations"""
    return time_engine.get_current_schedule_recommendation()

@app.get("/api/latency-analysis/{location}")
async def get_latency_analysis(location: str):
    """Get real-time latency analysis for location"""
    analysis = await latency_engine.get_real_time_latency_analysis(location)
    return analysis

@app.post("/api/deploy")
async def deploy_workload(deployment_request: dict):
    """Deploy workload with arbitrage optimization"""
    try:
        # This would integrate with SkyPilot for real deployment
        return {
            "status": "success",
            "deployment_id": f"deploy-{int(time.time())}",
            "provider": deployment_request.get("provider", "aws"),
            "region": deployment_request.get("region", "us-east-1"),
            "arbitrage_type": deployment_request.get("type", "time"),
            "estimated_savings": deployment_request.get("savings", 0.0),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "engines": {
            "time_arbitrage": "active",
            "latency_arbitrage": "active"
        }
    }

if __name__ == "__main__":
    logging.info("🚀 Starting Terradev Web Arbitrage Server...")
    logging.info("🌐 Open http://localhost:8000 in your browser")
    logging.info("⏰ Time arbitrage and 🌐 latency arbitrage enabled!")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)
