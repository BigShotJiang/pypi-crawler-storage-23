# 🚀 Terradev CLI Commands Documentation

Complete list of all Terradev CLI commands with examples and usage instructions.

---

## 📋 **Command Overview**

Terradev CLI provides a comprehensive set of commands for cross-cloud compute optimization, parallel provisioning, cost analysis, and resource management.

---

## 🔧 **Configuration Commands**

### **`terradev configure`**
Configure cloud provider credentials and settings.

#### **Syntax**
```bash
terradev configure [OPTIONS]
```

#### **Options**
- `-p, --provider TEXT` - Cloud providers to configure (multiple allowed)
- `--api-key TEXT` - API key for provider
- `--secret-key TEXT` - Secret key for provider
- `-r, --region TEXT` - Default region

#### **Examples**

**Show current configuration:**
```bash
terradev configure
```

**Configure AWS:**
```bash
terradev configure --provider aws --region us-east-1
# Prompts for API key and secret key
```

**Configure multiple providers:**
```bash
terradev configure --provider aws --provider gcp --provider runpod --region us-east-1
```

**Configure with explicit keys:**
```bash
terradev configure --provider aws --api-key AKIAIOSFODNN7EXAMPLE --secret-key wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY --region us-west-2
```

---

## 🚀 **Provisioning Commands**

### **`terradev provision`**
Provision compute instances with parallel optimization.

#### **Syntax**
```bash
terradev provision [OPTIONS]
```

#### **Required Options**
- `-g, --gpu-type TEXT` - GPU type (e.g., A100, V100, RTX4090)

#### **Optional Options**
- `-n, --count INTEGER` - Number of instances (default: 1)
- `--max-price FLOAT` - Maximum price per hour
- `-r, --region TEXT` - Target region
- `-p, --providers TEXT` - Specific providers to use (multiple allowed)
- `--parallel INTEGER` - Number of parallel queries (default: 6)
- `--dry-run` - Dry run (no actual provisioning)

#### **Examples**

**Basic provisioning:**
```bash
terradev provision --gpu-type A100
```

**Provision multiple instances:**
```bash
terradev provision --gpu-type A100 --count 4
```

**Provision with price limit:**
```bash
terradev provision --gpu-type A100 --max-price 3.0
```

**Provision specific providers:**
```bash
terradev provision --gpu-type A100 --providers aws --providers runpod
```

**Dry run to test:**
```bash
terradev provision --gpu-type A100 --dry-run
```

**Full example:**
```bash
terradev provision --gpu-type A100 --count 2 --max-price 2.5 --region us-east-1 --providers aws gcp runpod --parallel 8
```

---

## 💰 **Quoting Commands**

### **`terradev quote`**
Get real-time quotes from all providers.

#### **Syntax**
```bash
terradev quote [OPTIONS]
```

#### **Options**
- `-p, --providers TEXT` - Specific providers to query (multiple allowed)
- `--parallel INTEGER` - Number of parallel queries (default: 6)
- `-g, --gpu-type TEXT` - Filter by GPU type
- `-r, --region TEXT` - Filter by region

#### **Examples**

**Get all quotes:**
```bash
terradev quote
```

**Quote specific GPU type:**
```bash
terradev quote --gpu-type A100
```

**Quote specific providers:**
```bash
terradev quote --providers aws --providers runpod
```

**Quote with filters:**
```bash
terradev quote --gpu-type A100 --region us-east-1 --providers aws gcp azure
```

**Increase parallel queries:**
```bash
terradev quote --parallel 10
```

---

## 📊 **Management Commands**

### **`terradev manage`**
Manage provisioned instances.

#### **Syntax**
```bash
terradev manage [OPTIONS]
```

#### **Required Options**
- `-i, --instance-id TEXT` - Instance ID to manage

#### **Options**
- `-a, --action [status|stop|start|terminate]` - Action to perform (default: status)

#### **Examples**

**Check instance status:**
```bash
terradev manage --instance-id aws_inst_123456
```

**Stop instance:**
```bash
terradev manage --instance-id aws_inst_123456 --action stop
```

**Start instance:**
```bash
terradev manage --instance-id aws_inst_123456 --action start
```

**Terminate instance:**
```bash
terradev manage --instance-id aws_inst_123456 --action terminate
```

---

### **`terradev status`**
Show current status of all instances.

#### **Syntax**
```bash
terradev status [OPTIONS]
```

#### **Options**
- `-f, --format [table|json]` - Output format (default: table)

#### **Examples**

**Show status in table format:**
```bash
terradev status
```

**Show status in JSON format:**
```bash
terradev status --format json
```

---

## 📦 **Dataset Commands**

### **`terradev stage`**
Stage datasets across multiple regions for optimal access.

#### **Syntax**
```bash
terradev stage [OPTIONS]
```

#### **Required Options**
- `-d, --dataset TEXT` - Dataset name or URL

#### **Options**
- `--target-regions TEXT` - Target regions for staging (multiple allowed)
- `--compression TEXT` - Compression level (default: auto)

#### **Examples**

**Stage dataset to default regions:**
```bash
terradev stage --dataset s3://my-bucket/training-data
```

**Stage to specific regions:**
```bash
terradev stage --dataset s3://my-bucket/training-data --target-regions us-east-1 --target-regions us-west-2
```

**Stage with compression:**
```bash
terradev stage --dataset s3://my-bucket/training-data --compression high
```

**Full example:**
```bash
terradev stage --dataset https://example.com/dataset.zip --target-regions us-east-1 us-west-2 eu-west-1 --compression auto
```

---

## 🔧 **Execution Commands**

### **`terradev execute`**
Execute commands on provisioned instances.

#### **Syntax**
```bash
terradev execute [OPTIONS]
```

#### **Required Options**
- `-i, --instance-id TEXT` - Instance ID
- `-c, --command TEXT` - Command to execute

#### **Options**
- `--async-exec` - Run asynchronously

#### **Examples**

**Execute command:**
```bash
terradev execute --instance-id aws_inst_123456 --command "nvidia-smi"
```

**Execute multiple commands:**
```bash
terradev execute --instance-id aws_inst_123456 --command "python train.py --epochs 100"
```

**Execute asynchronously:**
```bash
terradev execute --instance-id aws_inst_123456 --command "long_running_task.sh" --async-exec
```

**Check GPU status:**
```bash
terradev execute --instance-id aws_inst_123456 --command "nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv"
```

---

## 📈 **Analytics Commands**

### **`terradev analytics`**
Show cost analytics and optimization insights.

#### **Syntax**
```bash
terradev analytics [OPTIONS]
```

#### **Options**
- `-d, --days INTEGER` - Number of days to analyze (default: 7)
- `-f, --format [table|json]` - Output format (default: table)

#### **Examples**

**Show 7-day analytics:**
```bash
terradev analytics
```

**Show 30-day analytics:**
```bash
terradev analytics --days 30
```

**Show analytics in JSON:**
```bash
terradev analytics --format json
```

**Show 90-day analytics:**
```bash
terradev analytics --days 90 --format json
```

---

## 🔧 **Optimization Commands**

### **`terradev optimize`**
Run automatic cost optimization.

#### **Syntax**
```bash
terradev optimize
```

#### **Examples**

**Run optimization:**
```bash
terradev optimize
```

---

## 🧹 **Cleanup Commands**

### **`terradev cleanup`**
Clean up unused resources and temporary files.

#### **Syntax**
```bash
terradev cleanup
```

#### **Examples**

**Clean up resources:**
```bash
terradev cleanup
```

---

## 🔧 **Global Options**

These options are available with all commands:

- `-c, --config TEXT` - Configuration file path (default: ~/.terradev/config.json)
- `-v, --verbose` - Verbose output
- `--help` - Show help message
- `--version` - Show version and exit

#### **Examples**

**Use custom config:**
```bash
terradev --config /path/to/custom/config.json provision --gpu-type A100
```

**Verbose output:**
```bash
terradev --verbose quote --gpu-type A100
```

**Show version:**
```bash
terradev --version
```

---

## 📋 **Command Categories**

### **🔧 Configuration**
- `terradev configure` - Setup cloud providers

### **🚀 Provisioning**
- `terradev provision` - Provision instances
- `terradev quote` - Get price quotes

### **📊 Management**
- `terradev manage` - Manage instances
- `terradev status` - Show status

### **📦 Data Management**
- `terradev stage` - Stage datasets

### **🔧 Operations**
- `terradev execute` - Run commands
- `terradev cleanup` - Clean up resources

### **📈 Analytics**
- `terradev analytics` - Cost analytics
- `terradev optimize` - Cost optimization

---

## 🎯 **Common Workflows**

### **🚀 Quick Start Workflow**
```bash
# 1. Configure providers
terradev configure --provider aws --provider runpod

# 2. Get quotes
terradev quote --gpu-type A100

# 3. Provision instances
terradev provision --gpu-type A100 --count 2

# 4. Check status
terradev status

# 5. Execute commands
terradev execute --instance-id aws_inst_123456 --command "nvidia-smi"
```

### **💰 Cost Optimization Workflow**
```bash
# 1. Analyze current costs
terradev analytics --days 30

# 2. Run optimization
terradev optimize

# 3. Get new quotes
terradev quote --gpu-type A100

# 4. Re-provision if needed
terradev provision --gpu-type A100 --max-price 2.0
```

### **📦 ML Training Workflow**
```bash
# 1. Stage datasets
terradev stage --dataset s3://my-bucket/training-data --target-regions us-east-1 us-west-2

# 2. Provision GPU instances
terradev provision --gpu-type A100 --count 4 --max-price 3.0

# 3. Execute training
terradev execute --instance-id aws_inst_123456 --command "python train.py --epochs 100" --async-exec

# 4. Monitor progress
terradev status

# 5. Check analytics
terradev analytics --days 7
```

### **🧹 Cleanup Workflow**
```bash
# 1. Check current status
terradev status

# 2. Stop unused instances
terradev manage --instance-id aws_inst_123456 --action stop

# 3. Terminate if needed
terradev manage --instance-id aws_inst_123456 --action terminate

# 4. Clean up resources
terradev cleanup
```

---

## 🔧 **Advanced Usage**

### **📊 JSON Output**
```bash
# Get quotes in JSON format
terradev quote --gpu-type A100 | jq '.[] | select(.price_per_hour < 3.0)'

# Get status in JSON format
terradev status --format json | jq '.[] | select(.status == "running")'
```

### **🔄 Parallel Operations**
```bash
# Increase parallel queries for faster results
terradev quote --parallel 10 --gpu-type A100

# Provision with high parallelism
terradev provision --gpu-type A100 --count 4 --parallel 8
```

### **🎯 Filtering and Selection**
```bash
# Quote specific regions
terradev quote --region us-east-1 --region us-west-2

# Use specific providers
terradev provision --gpu-type A100 --providers aws --providers runpod

# Set price limits
terradev provision --gpu-type A100 --max-price 2.5
```

---

## 🚨 **Error Handling**

### **Common Errors and Solutions**

**❌ No credentials configured:**
```bash
# Solution: Configure providers first
terradev configure --provider aws
```

**❌ Instance not found:**
```bash
# Solution: Check instance ID in status
terradev status
terradev manage --instance-id correct_instance_id --action status
```

**❌ Permission denied:**
```bash
# Solution: Check credentials and permissions
terradev configure --provider aws --api-key new_key --secret-key new_secret
```

**❌ Region not available:**
```bash
# Solution: Use available regions
terradev quote --region us-east-1
```

---

## 📞 **Help and Support**

### **Getting Help**
```bash
# Show main help
terradev --help

# Show command help
terradev provision --help
terradev quote --help
terradev configure --help
```

### **Verbose Mode**
```bash
# Enable verbose output for debugging
terradev --verbose provision --gpu-type A100
```

### **Configuration Files**
```bash
# Default config location
~/.terradev/config.json

# Default auth location
~/.terradev/auth.json

# Use custom config
terradev --config /path/to/config.json provision --gpu-type A100
```

---

## 🎉 **Summary**

The Terradev CLI provides **12 main commands** organized into **6 categories**:

- **🔧 Configuration**: `configure`
- **🚀 Provisioning**: `provision`, `quote`
- **📊 Management**: `manage`, `status`
- **📦 Data**: `stage`
- **🔧 Operations**: `execute`, `cleanup`
- **📈 Analytics**: `analytics`, `optimize`

Each command supports multiple options for customization and can be combined into powerful workflows for cross-cloud compute optimization.

---

**🚀 Terradev CLI - Your complete solution for cross-cloud compute optimization!**
