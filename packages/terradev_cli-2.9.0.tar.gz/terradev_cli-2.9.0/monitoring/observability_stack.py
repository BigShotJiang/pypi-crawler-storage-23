#!/usr/bin/env python3
"""
Terradev Observability Stack
Comprehensive monitoring, tracing, and alerting system
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import prometheus_client
from prometheus_client import Counter, Histogram, Gauge, CollectorRegistry, generate_latest
import opentelemetry
from opentelemetry import trace, metrics, baggage
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.prometheus import PrometheusMetricReader
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.instrumentation.asyncpg import AsyncPGInstrumentor
from opentelemetry.instrumentation.redis import RedisInstrumentor
import structlog
from structlog.stdlib import LoggerFactory
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.redis import RedisIntegration
from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration
import grafana_api
import requests

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class AlertSeverity(str, Enum):
    """Alert severity levels"""
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"
    DEBUG = "debug"

class MetricType(str, Enum):
    """Metric types"""
    COUNTER = "counter"
    HISTOGRAM = "histogram"
    GAUGE = "gauge"
    SUMMARY = "summary"

@dataclass
class Alert:
    """Alert definition"""
    name: str
    severity: AlertSeverity
    condition: str
    threshold: float
    duration: int  # seconds
    message: str
    labels: Dict[str, str]
    annotations: Dict[str, str]
    enabled: bool = True

@dataclass
class Dashboard:
    """Dashboard configuration"""
    name: str
    title: str
    tags: List[str]
    panels: List[Dict[str, Any]]
    variables: List[Dict[str, Any]]
    time: Dict[str, str]
    refresh: str

class ObservabilityStack:
    """Comprehensive observability stack for Terradev"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.registry = CollectorRegistry()
        
        # Initialize components
        self.metrics_collector = MetricsCollector(self.registry)
        self.tracing_provider = TracingProvider()
        self.logger = self._setup_structured_logging()
        self.alert_manager = AlertManager(config.get('alerts', {}))
        self.dashboard_manager = DashboardManager(config.get('dashboards', {}))
        
        # Initialize monitoring backends
        self.prometheus_gateway = config.get('prometheus', {}).get('gateway_url')
        self.jaeger_endpoint = config.get('jaeger', {}).get('endpoint')
        self.grafana_url = config.get('grafana', {}).get('url')
        self.sentry_dsn = config.get('sentry', {}).get('dsn')
        
        # Setup integrations
        self._setup_opentelemetry()
        self._setup_sentry()
        self._setup_grafana()
        
        logger.info("Observability stack initialized")
    
    def _setup_structured_logging(self):
        """Setup structured logging with structlog"""
        
        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.stdlib.add_logger_name,
                structlog.stdlib.add_log_level,
                structlog.stdlib.PositionalArgumentsFormatter(),
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.processors.StackInfoRenderer(),
                structlog.processors.format_exc_info,
                structlog.processors.UnicodeDecoder(),
                structlog.processors.JSONRenderer()
            ],
            context_class=dict,
            logger_factory=LoggerFactory(),
            wrapper_class=structlog.stdlib.BoundLogger,
            cache_logger_on_first_use=True,
        )
        
        return structlog.get_logger()
    
    def _setup_opentelemetry(self):
        """Setup OpenTelemetry for metrics and tracing"""
        
        # Setup tracing
        if self.jaeger_endpoint:
            jaeger_exporter = JaegerExporter(
                endpoint=self.jaeger_endpoint,
                insecure=True
            )
            
            span_processor = BatchSpanProcessor(jaeger_exporter)
            self.tracing_provider.add_span_processor(span_processor)
            
            trace.set_tracer_provider(self.tracing_provider)
            
            # Instrument libraries
            FastAPIInstrumentor.instrument()
            HTTPXClientInstrumentor.instrument()
            AsyncPGInstrumentor.instrument()
            RedisInstrumentor.instrument()
            
            logger.info(f"OpenTelemetry tracing configured with Jaeger endpoint: {self.jaeger_endpoint}")
        
        # Setup metrics
        if self.prometheus_gateway:
            metric_reader = PrometheusMetricReader()
            
            meter_provider = MeterProvider(metric_readers=[metric_reader])
            metrics.set_meter_provider(meter_provider)
            
            logger.info(f"OpenTelemetry metrics configured with Prometheus gateway: {self.prometheus_gateway}")
    
    def _setup_sentry(self):
        """Setup Sentry for error tracking"""
        
        if self.sentry_dsn:
            sentry_sdk.init(
                dsn=self.sentry_dsn,
                integrations=[
                    FastApiIntegration(),
                    RedisIntegration(),
                    SqlalchemyIntegration(),
                ],
                traces_sample_rate=self.config.get('sentry', {}).get('traces_sample_rate', 0.1),
                environment=self.config.get('environment', 'development'),
                release=self.config.get('version', '1.0.0')
            )
            
            logger.info(f"Sentry error tracking configured")
    
    def _setup_grafana(self):
        """Setup Grafana dashboard management"""
        
        if self.grafana_url:
            grafana_config = self.config.get('grafana', {})
            self.dashboard_manager.grafana_client = grafana_api.GrafanaFace(
                auth=grafana_config.get('auth'),
                host=self.grafana_url
            )
            
            logger.info(f"Grafana dashboard management configured: {self.grafana_url}")
    
    def get_tracer(self, name: str) -> trace.Tracer:
        """Get tracer for specific component"""
        
        return trace.get_tracer(name)
    
    def get_meter(self, name: str) -> metrics.Meter:
        """Get meter for specific component"""
        
        return metrics.get_meter(name)
    
    def create_counter(self, name: str, description: str, labels: List[str] = None) -> Counter:
        """Create Prometheus counter"""
        
        return self.metrics_collector.create_counter(name, description, labels)
    
    def create_histogram(self, name: str, description: str, buckets: List[float] = None, 
                        labels: List[str] = None) -> Histogram:
        """Create Prometheus histogram"""
        
        return self.metrics_collector.create_histogram(name, description, buckets, labels)
    
    def create_gauge(self, name: str, description: str, labels: List[str] = None) -> Gauge:
        """Create Prometheus gauge"""
        
        return self.metrics_collector.create_gauge(name, description, labels)
    
    def record_metric(self, metric_type: MetricType, name: str, value: float, 
                     labels: Dict[str, str] = None):
        """Record metric value"""
        
        self.metrics_collector.record_metric(metric_type, name, value, labels)
    
    def create_span(self, name: str, kind: trace.SpanKind = trace.SpanKind.INTERNAL) -> trace.Span:
        """Create tracing span"""
        
        tracer = self.get_tracer("terradev")
        return tracer.start_span(name, kind=kind)
    
    def log_event(self, event: str, level: str = "info", **kwargs):
        """Log structured event"""
        
        log_method = getattr(self.logger, level.lower(), self.logger.info)
        log_method(event, **kwargs)
    
    def capture_exception(self, exception: Exception, **kwargs):
        """Capture exception in Sentry"""
        
        if self.sentry_dsn:
            sentry_sdk.capture_exception(exception)
        
        self.logger.error("Exception captured", exc_info=exception, **kwargs)
    
    def create_alert(self, alert: Alert):
        """Create alert rule"""
        
        self.alert_manager.create_alert(alert)
    
    def create_dashboard(self, dashboard: Dashboard):
        """Create Grafana dashboard"""
        
        self.dashboard_manager.create_dashboard(dashboard)
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary"""
        
        return self.metrics_collector.get_summary()
    
    def export_metrics(self) -> str:
        """Export metrics in Prometheus format"""
        
        return generate_latest(self.registry).decode('utf-8')

class MetricsCollector:
    """Prometheus metrics collector"""
    
    def __init__(self, registry: CollectorRegistry):
        self.registry = registry
        self.counters: Dict[str, Counter] = {}
        self.histograms: Dict[str, Histogram] = {}
        self.gauges: Dict[str, Gauge] = {}
        
        # Default metrics for Terradev
        self._setup_default_metrics()
    
    def _setup_default_metrics(self):
        """Setup default Terradev metrics"""
        
        # API metrics
        self.create_counter(
            "terradev_api_requests_total",
            "Total number of API requests",
            ["method", "endpoint", "status"]
        )
        
        self.create_histogram(
            "terradev_api_request_duration_seconds",
            "API request duration in seconds",
            [0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
            ["method", "endpoint"]
        )
        
        # GPU arbitrage metrics
        self.create_counter(
            "terradev_arbitrage_scans_total",
            "Total number of arbitrage scans",
            ["provider", "gpu_type"]
        )
        
        self.create_histogram(
            "terradev_arbitrage_scan_duration_seconds",
            "Arbitrage scan duration in seconds",
            [1.0, 5.0, 10.0, 30.0, 60.0],
            ["provider"]
        )
        
        self.create_gauge(
            "terradev_gpu_price_usd",
            "Current GPU price in USD",
            ["provider", "gpu_type", "instance_type", "region"]
        )
        
        self.create_gauge(
            "terradev_arbitrage_opportunities_count",
            "Number of available arbitrage opportunities",
            ["provider", "risk_level"]
        )
        
        # Cost metrics
        self.create_gauge(
            "terradev_hourly_cost_usd",
            "Current hourly cost in USD",
            ["provider", "user_id"]
        )
        
        self.create_counter(
            "terradev_cost_savings_usd_total",
            "Total cost savings in USD",
            ["provider", "savings_type"]
        )
        
        # Risk metrics
        self.create_gauge(
            "terradev_risk_score",
            "Current risk score",
            ["provider", "risk_type"]
        )
        
        self.create_gauge(
            "terradev_volatility",
            "Current volatility",
            ["provider", "gpu_type"]
        )
        
        # System metrics
        self.create_gauge(
            "terradev_active_users",
            "Number of active users",
            ["tier"]
        )
        
        self.create_counter(
            "terradev_deployments_total",
            "Total number of deployments",
            ["provider", "status"]
        )
    
    def create_counter(self, name: str, description: str, labels: List[str] = None) -> Counter:
        """Create Prometheus counter"""
        
        counter = Counter(name, description, labelnames=labels or [], registry=self.registry)
        self.counters[name] = counter
        return counter
    
    def create_histogram(self, name: str, description: str, buckets: List[float] = None, 
                        labels: List[str] = None) -> Histogram:
        """Create Prometheus histogram"""
        
        histogram = Histogram(
            name, description, buckets=buckets or [],
            labelnames=labels or [], registry=self.registry
        )
        self.histograms[name] = histogram
        return histogram
    
    def create_gauge(self, name: str, description: str, labels: List[str] = None) -> Gauge:
        """Create Prometheus gauge"""
        
        gauge = Gauge(name, description, labelnames=labels or [], registry=self.registry)
        self.gauges[name] = gauge
        return gauge
    
    def record_metric(self, metric_type: MetricType, name: str, value: float, 
                     labels: Dict[str, str] = None):
        """Record metric value"""
        
        labels = labels or {}
        
        if metric_type == MetricType.COUNTER and name in self.counters:
            self.counters[name].labels(**labels).inc(value)
        elif metric_type == MetricType.GAUGE and name in self.gauges:
            self.gauges[name].labels(**labels).set(value)
        elif metric_type == MetricType.HISTOGRAM and name in self.histograms:
            self.histograms[name].labels(**labels).observe(value)
        else:
            logger.warning(f"Metric {name} of type {metric_type} not found")
    
    def get_summary(self) -> Dict[str, Any]:
        """Get metrics summary"""
        
        summary = {
            "counters": {},
            "gauges": {},
            "histograms": {}
        }
        
        for name, counter in self.counters.items():
            try:
                summary["counters"][name] = {
                    "value": counter._value.get(),
                    "labels": counter._labelnames
                }
            except Exception as e:
                pass
        
        for name, gauge in self.gauges.items():
            try:
                summary["gauges"][name] = {
                    "value": gauge._value.get(),
                    "labels": gauge._labelnames
                }
            except Exception as e:
                pass
        
        return summary

class AlertManager:
    """Alert management system"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.alerts: Dict[str, Alert] = {}
        self.alert_rules: List[Dict[str, Any]] = []
        
        # Setup default alerts
        self._setup_default_alerts()
    
    def _setup_default_alerts(self):
        """Setup default alert rules"""
        
        default_alerts = [
            Alert(
                name="HighAPIErrorRate",
                severity=AlertSeverity.WARNING,
                condition="rate(terradev_api_requests_total{status=~'5..'}[5m]) / rate(terradev_api_requests_total[5m])",
                threshold=0.05,
                duration=300,
                message="API error rate is above 5%",
                labels={"team": "backend", "service": "terradev-api"},
                annotations={"description": "API error rate is {{ $value | humanizePercentage }}"}
            ),
            Alert(
                name="SlowAPIResponse",
                severity=AlertSeverity.WARNING,
                condition="histogram_quantile(0.95, rate(terradev_api_request_duration_seconds_bucket[5m]))",
                threshold=2.0,
                duration=300,
                message="95th percentile API response time is above 2 seconds",
                labels={"team": "backend", "service": "terradev-api"},
                annotations={"description": "P95 response time is {{ $value }} seconds"}
            ),
            Alert(
                name="HighGPUPrice",
                severity=AlertSeverity.INFO,
                condition="terradev_gpu_price_usd",
                threshold=5.0,
                duration=600,
                message="GPU price is above $5.00/hour",
                labels={"team": "arbitrage", "service": "terradev-arbitrage"},
                annotations={"description": "GPU price for {{ $labels.provider }} {{ $labels.gpu_type }} is ${{ $value }}/hour"}
            ),
            Alert(
                name="LowArbitrageOpportunities",
                severity=AlertSeverity.WARNING,
                condition="sum(terradev_arbitrage_opportunities_count)",
                threshold=5.0,
                duration=300,
                message="Less than 5 arbitrage opportunities available",
                labels={"team": "arbitrage", "service": "terradev-arbitrage"},
                annotations={"description": "Only {{ $value }} opportunities available"}
            ),
            Alert(
                name="HighCostAnomaly",
                severity=AlertSeverity.CRITICAL,
                condition="rate(terradev_hourly_cost_usd[1h])",
                threshold=100.0,
                duration=600,
                message="Hourly cost is above $100",
                labels={"team": "cost", "service": "terradev-cost"},
                annotations={"description": "Current hourly cost is ${{ $value }}"}
            ),
            Alert(
                name="HighRiskScore",
                severity=AlertSeverity.WARNING,
                condition="terradev_risk_score",
                threshold=0.8,
                duration=300,
                message="Risk score is above 0.8",
                labels={"team": "risk", "service": "terradev-risk"},
                annotations={"description": "Risk score for {{ $labels.provider }} is {{ $value }}"}
            )
        ]
        
        for alert in default_alerts:
            self.create_alert(alert)
    
    def create_alert(self, alert: Alert):
        """Create alert rule"""
        
        self.alerts[alert.name] = alert
        
        # Convert to Prometheus alert rule format
        alert_rule = {
            "alert": alert.name,
            "expr": alert.condition,
            "for": f"{alert.duration}s",
            "labels": {
                "severity": alert.severity.value,
                **alert.labels
            },
            "annotations": {
                "summary": alert.message,
                **alert.annotations
            }
        }
        
        self.alert_rules.append(alert_rule)
        logger.info(f"Created alert rule: {alert.name}")
    
    def get_alert_rules(self) -> List[Dict[str, Any]]:
        """Get all alert rules"""
        
        return self.alert_rules
    
    def export_alert_rules(self, filename: str):
        """Export alert rules to file"""
        
        alert_groups = [{
            "name": "terradev",
            "rules": self.alert_rules
        }]
        
        alert_config = {
            "groups": alert_groups
        }
        
        with open(filename, 'w') as f:
            json.dump(alert_config, f, indent=2)
        
        logger.info(f"Alert rules exported to {filename}")

class DashboardManager:
    """Grafana dashboard management"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.dashboards: Dict[str, Dashboard] = {}
        self.grafana_client = None
        
        # Setup default dashboards
        self._setup_default_dashboards()
    
    def _setup_default_dashboards(self):
        """Setup default Grafana dashboards"""
        
        # API Performance Dashboard
        api_dashboard = Dashboard(
            name="api-performance",
            title="Terradev API Performance",
            tags=["terradev", "api", "performance"],
            panels=[
                {
                    "title": "Request Rate",
                    "type": "graph",
                    "targets": [
                        {
                            "expr": "rate(terradev_api_requests_total[5m])",
                            "legendFormat": "{{method}} {{endpoint}}"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 0}
                },
                {
                    "title": "Response Time",
                    "type": "graph",
                    "targets": [
                        {
                            "expr": "histogram_quantile(0.95, rate(terradev_api_request_duration_seconds_bucket[5m]))",
                            "legendFormat": "95th percentile"
                        },
                        {
                            "expr": "histogram_quantile(0.50, rate(terradev_api_request_duration_seconds_bucket[5m]))",
                            "legendFormat": "50th percentile"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 12, "y": 0}
                },
                {
                    "title": "Error Rate",
                    "type": "singlestat",
                    "targets": [
                        {
                            "expr": "rate(terradev_api_requests_total{status=~'5..'}[5m]) / rate(terradev_api_requests_total[5m])",
                            "legendFormat": "Error Rate"
                        }
                    ],
                    "gridPos": {"h": 4, "w": 6, "x": 0, "y": 8}
                }
            ],
            variables=[
                {
                    "name": "instance",
                    "type": "query",
                    "query": "label_values(terradev_api_requests_total, instance)"
                }
            ],
            time={"from": "now-1h", "to": "now"},
            refresh="30s"
        )
        
        # GPU Arbitrage Dashboard
        arbitrage_dashboard = Dashboard(
            name="gpu-arbitrage",
            title="Terradev GPU Arbitrage",
            tags=["terradev", "gpu", "arbitrage"],
            panels=[
                {
                    "title": "GPU Prices",
                    "type": "graph",
                    "targets": [
                        {
                            "expr": "terradev_gpu_price_usd",
                            "legendFormat": "{{provider}} {{gpu_type}}"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 0}
                },
                {
                    "title": "Arbitrage Opportunities",
                    "type": "stat",
                    "targets": [
                        {
                            "expr": "sum(terradev_arbitrage_opportunities_count)",
                            "legendFormat": "Total Opportunities"
                        }
                    ],
                    "gridPos": {"h": 4, "w": 6, "x": 12, "y": 0}
                },
                {
                    "title": "Cost Savings",
                    "type": "graph",
                    "targets": [
                        {
                            "expr": "rate(terradev_cost_savings_usd_total[1h])",
                            "legendFormat": "Hourly Savings"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 8}
                },
                {
                    "title": "Risk Scores",
                    "type": "heatmap",
                    "targets": [
                        {
                            "expr": "terradev_risk_score",
                            "legendFormat": "{{provider}} {{risk_type}}"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 12, "y": 8}
                }
            ],
            variables=[
                {
                    "name": "gpu_type",
                    "type": "query",
                    "query": "label_values(terradev_gpu_price_usd, gpu_type)"
                },
                {
                    "name": "provider",
                    "type": "query",
                    "query": "label_values(terradev_gpu_price_usd, provider)"
                }
            ],
            time={"from": "now-6h", "to": "now"},
            refresh="1m"
        )
        
        # Cost Management Dashboard
        cost_dashboard = Dashboard(
            name="cost-management",
            title="Terradev Cost Management",
            tags=["terradev", "cost", "management"],
            panels=[
                {
                    "title": "Hourly Cost",
                    "type": "graph",
                    "targets": [
                        {
                            "expr": "sum(terradev_hourly_cost_usd) by (provider)",
                            "legendFormat": "{{provider}}"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 0}
                },
                {
                    "title": "Total Savings",
                    "type": "singlestat",
                    "targets": [
                        {
                            "expr": "sum(terradev_cost_savings_usd_total)",
                            "legendFormat": "Total Savings"
                        }
                    ],
                    "gridPos": {"h": 4, "w": 6, "x": 12, "y": 0}
                },
                {
                    "title": "Cost by User",
                    "type": "piechart",
                    "targets": [
                        {
                            "expr": "sum(terradev_hourly_cost_usd) by (user_id)",
                            "legendFormat": "{{user_id}}"
                        }
                    ],
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 8}
                }
            ],
            variables=[
                {
                    "name": "user_id",
                    "type": "query",
                    "query": "label_values(terradev_hourly_cost_usd, user_id)"
                }
            ],
            time={"from": "now-24h", "to": "now"},
            refresh="5m"
        )
        
        for dashboard in [api_dashboard, arbitrage_dashboard, cost_dashboard]:
            self.create_dashboard(dashboard)
    
    def create_dashboard(self, dashboard: Dashboard):
        """Create Grafana dashboard"""
        
        self.dashboards[dashboard.name] = dashboard
        
        if self.grafana_client:
            try:
                # Convert to Grafana dashboard format
                grafana_dashboard = {
                    "dashboard": {
                        "title": dashboard.title,
                        "tags": dashboard.tags,
                        "panels": dashboard.panels,
                        "templating": {
                            "list": dashboard.variables
                        },
                        "time": dashboard.time,
                        "refresh": dashboard.refresh
                    },
                    "overwrite": True
                }
                
                # Create dashboard in Grafana
                self.grafana_client.dashboard.create(grafana_dashboard)
                logger.info(f"Created Grafana dashboard: {dashboard.title}")
                
            except Exception as e:
                logger.error(f"Failed to create Grafana dashboard {dashboard.title}: {e}")
    
    def get_dashboard(self, name: str) -> Optional[Dashboard]:
        """Get dashboard by name"""
        
        return self.dashboards.get(name)
    
    def export_dashboards(self, directory: str):
        """Export all dashboards to directory"""
        
        os.makedirs(directory, exist_ok=True)
        
        for name, dashboard in self.dashboards.items():
            dashboard_data = {
                "dashboard": {
                    "title": dashboard.title,
                    "tags": dashboard.tags,
                    "panels": dashboard.panels,
                    "templating": {
                        "list": dashboard.variables
                    },
                    "time": dashboard.time,
                    "refresh": dashboard.refresh
                }
            }
            
            filename = os.path.join(directory, f"{name}.json")
            with open(filename, 'w') as f:
                json.dump(dashboard_data, f, indent=2)
            
            logger.info(f"Exported dashboard {name} to {filename}")

# Decorators for automatic instrumentation
def monitor_performance(metric_name: str = None, labels: Dict[str, str] = None):
    """Decorator to monitor function performance"""
    
    def decorator(func):
        def wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                success = True
                error = None
            except Exception as e:
                result = None
                success = False
                error = e
                raise
            finally:
                duration = time.time() - start_time
                
                # Record metrics (this would be done through the observability stack)
                if metric_name:
                    # Record duration
                    pass
                
                # Log performance
                logger.info(
                    "Function performance",
                    function=func.__name__,
                    duration=duration,
                    success=success,
                    error=str(error) if error else None
                )
            
            return result
        
        return wrapper
    return decorator

def trace_operation(operation_name: str = None):
    """Decorator to trace function execution"""
    
    def decorator(func):
        def wrapper(*args, **kwargs):
            tracer = trace.get_tracer("terradev")
            span_name = operation_name or f"{func.__module__}.{func.__name__}"
            
            with tracer.start_as_current_span(span_name) as span:
                try:
                    result = func(*args, **kwargs)
                    span.set_status(trace.Status(trace.StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise
        
        return wrapper
    return decorator

# Usage example
if __name__ == "__main__":
    # Initialize observability stack
    config = {
        "environment": "development",
        "version": "1.0.0",
        "prometheus": {
            "gateway_url": "http://localhost:9091"
        },
        "jaeger": {
            "endpoint": "http://localhost:14268/api/traces"
        },
        "grafana": {
            "url": "http://localhost:3000",
            "auth": ("admin", "admin")
        },
        "sentry": {
            "dsn": "https://your-sentry-dsn",
            "traces_sample_rate": 0.1
        }
    }
    
    observability = ObservabilityStack(config)
    
    # Example usage
    @monitor_performance("test_function", {"component": "test"})
    @trace_operation("test_operation")
    def test_function():
        # TODO: PERFORMANCE - Consider async/await for blocking sleep
# time.sleep(0.1)
        return "test result"
    
    # Test the function
    result = test_function()
    logging.info(f"Result: {result}")
    
    # Export metrics and alerts
    logging.info("Metrics:")
    logging.info(observability.export_metrics()
    
    observability.alert_manager.export_alert_rules("alerts.yml")
    observability.dashboard_manager.export_dashboards("dashboards")
