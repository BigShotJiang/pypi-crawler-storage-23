#!/usr/bin/env python3
"""
GitHub API Integration for Terradev WebApp
Handles repository management, code import/export, and configuration sync
"""

import asyncio
import json
import logging
import os
import subprocess
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path
import requests
from urllib.parse import urljoin

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class GitHubRepository:
    """GitHub repository information"""
    name: str
    full_name: str
    description: str
    clone_url: str
    ssh_url: str
    default_branch: str
    private: bool
    size: int
    language: str
    updated_at: datetime
    created_at: datetime
    topics: List[str]

@dataclass
class GitHubFile:
    """GitHub file information"""
    path: str
    name: str
    type: str
    size: int
    sha: str
    content: Optional[str]
    download_url: str

@dataclass
class GitHubConfig:
    """GitHub configuration"""
    token: str
    username: str
    default_branch: str
    repositories: List[GitHubRepository]
    enabled: bool

class GitHubAPIIntegration:
    """GitHub API integration for Terradev"""
    
    def __init__(self, token: Optional[str] = None):
        self.token = token or os.getenv("GITHUB_TOKEN")
        self.base_url = "https://api.github.com"
        self.headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        }
        
        if self.token:
            self.headers["Authorization"] = f"Bearer {self.token}"
        
        self.config = None
        self.session = requests.Session()
        self.session.headers.update(self.headers)
    
    async def authenticate(self, token: str) -> Dict[str, Any]:
        """Authenticate with GitHub token"""
        try:
            self.token = token
            self.headers["Authorization"] = f"Bearer {token}"
            self.session.headers.update(self.headers)
            
            # Test authentication
            user_info = await self.get_user_info()
            
            self.config = GitHubConfig(
                token=token,
                username=user_info["login"],
                default_branch="main",
                repositories=[],
                enabled=True
            )
            
            return {
                "status": "authenticated",
                "username": user_info["login"],
                "name": user_info.get("name", ""),
                "email": user_info.get("email", "")
            }
        except Exception as e:
            logger.error(f"GitHub authentication failed: {e}")
            return {"status": "error", "message": str(e)}
    
    async def get_user_info(self) -> Dict[str, Any]:
        """Get authenticated user information"""
        try:
            response = self.session.get(f"{self.base_url}/user")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Failed to get user info: {e}")
            raise
    
    async def get_user_repositories(self) -> List[GitHubRepository]:
        """Get user repositories"""
        try:
            response = self.session.get(f"{self.base_url}/user/repos", params={"per_page": 100})
            response.raise_for_status()
            
            repos = []
            for repo_data in response.json():
                repo = GitHubRepository(
                    name=repo_data["name"],
                    full_name=repo_data["full_name"],
                    description=repo_data.get("description", ""),
                    clone_url=repo_data["clone_url"],
                    ssh_url=repo_data["ssh_url"],
                    default_branch=repo_data["default_branch"],
                    private=repo_data["private"],
                    size=repo_data["size"],
                    language=repo_data.get("language", ""),
                    updated_at=datetime.fromisoformat(repo_data["updated_at"].replace("Z", "+00:00")),
                    created_at=datetime.fromisoformat(repo_data["created_at"].replace("Z", "+00:00")),
                    topics=repo_data.get("topics", [])
                )
                repos.append(repo)
            
            return repos
        except Exception as e:
            logger.error(f"Failed to get repositories: {e}")
            raise
    
    async def get_repository_contents(self, repo_full_name: str, path: str = "") -> List[GitHubFile]:
        """Get repository contents"""
        try:
            url = f"{self.base_url}/repos/{repo_full_name}/contents/{path}"
            response = self.session.get(url)
            response.raise_for_status()
            
            contents = []
            for item in response.json():
                file_info = GitHubFile(
                    path=item["path"],
                    name=item["name"],
                    type=item["type"],
                    size=item["size"],
                    sha=item["sha"],
                    content=item.get("content"),
                    download_url=item.get("download_url", "")
                )
                contents.append(file_info)
            
            return contents
        except Exception as e:
            logger.error(f"Failed to get repository contents: {e}")
            raise
    
    async def get_file_content(self, repo_full_name: str, file_path: str) -> str:
        """Get file content"""
        try:
            url = f"{self.base_url}/repos/{repo_full_name}/contents/{file_path}"
            response = self.session.get(url)
            response.raise_for_status()
            
            content_data = response.json()
            if content_data["content"]:
                import base64
                return base64.b64decode(content_data["content"]).decode('utf-8')
            return ""
        except Exception as e:
            logger.error(f"Failed to get file content: {e}")
            raise
    
    async def create_repository(self, name: str, description: str = "", private: bool = False) -> Dict[str, Any]:
        """Create a new repository"""
        try:
            data = {
                "name": name,
                "description": description,
                "private": private,
                "auto_init": True
            }
            
            response = self.session.post(f"{self.base_url}/user/repos", json=data)
            response.raise_for_status()
            
            return response.json()
        except Exception as e:
            logger.error(f"Failed to create repository: {e}")
            raise
    
    async def update_file(self, repo_full_name: str, file_path: str, content: str, message: str = "Update file") -> Dict[str, Any]:
        """Update or create file in repository"""
        try:
            # Get current file info if it exists
            try:
                current_file = await self.get_repository_contents(repo_full_name, file_path)
                sha = current_file[0].sha if current_file else None
            except Exception as e:
                sha = None
            
            import base64
            data = {
                "message": message,
                "content": base64.b64encode(content.encode()).decode(),
                "branch": self.config.default_branch if self.config else "main"
            }
            
            if sha:
                data["sha"] = sha
            
            url = f"{self.base_url}/repos/{repo_full_name}/contents/{file_path}"
            response = self.session.put(url, json=data)
            response.raise_for_status()
            
            return response.json()
        except Exception as e:
            logger.error(f"Failed to update file: {e}")
            raise
    
    async def create_issue(self, repo_full_name: str, title: str, body: str = "", labels: List[str] = None) -> Dict[str, Any]:
        """Create an issue in repository"""
        try:
            data = {
                "title": title,
                "body": body
            }
            
            if labels:
                data["labels"] = labels
            
            response = self.session.post(f"{self.base_url}/repos/{repo_full_name}/issues", json=data)
            response.raise_for_status()
            
            return response.json()
        except Exception as e:
            logger.error(f"Failed to create issue: {e}")
            raise
    
    async def clone_repository(self, repo_full_name: str, target_dir: str) -> bool:
        """Clone repository locally"""
        try:
            if not self.token:
                raise ValueError("No GitHub token available")
            
            # Use token for authentication
            clone_url = f"https://{self.token}@github.com/{repo_full_name}.git"
            
            result = # TODO: Consider using asyncio.subprocess for async operations
# # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Failed to clone repository: {e}")
            return False
    
    async def push_to_repository(self, repo_dir: str, commit_message: str = "Terradev update") -> bool:
        """Push changes to repository"""
        try:
            os.chdir(repo_dir)
            
            # Add all changes
            # TODO: Consider using asyncio.subprocess for async operations
# # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            # Commit changes
            # TODO: Consider using asyncio.subprocess for async operations
# # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            # Push to remote
            # TODO: Consider using asyncio.subprocess for async operations
# # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            return True
        except Exception as e:
            logger.error(f"Failed to push to repository: {e}")
            return False
    
    async def import_terradev_configs(self, repo_full_name: str) -> Dict[str, Any]:
        """Import Terradev configurations from repository"""
        try:
            configs = {}
            
            # Look for configuration files
            config_files = [
                "terradev_config.json",
                "training_configs/",
                "kubernetes/",
                "docker/",
                "scripts/"
            ]
            
            for config_path in config_files:
                try:
                    if config_path.endswith("/"):
                        # Directory - get all files
                        contents = await self.get_repository_contents(repo_full_name, config_path)
                        for file_info in contents:
                            if file_info.type == "file" and file_info.name.endswith(('.json', '.yaml', '.yml', '.py')):
                                content = await self.get_file_content(repo_full_name, file_info.path)
                                configs[file_info.path] = content
                    else:
                        # Single file
                        content = await self.get_file_content(repo_full_name, config_path)
                        configs[config_path] = content
                except Exception as e:
                    # File or directory doesn't exist
                    continue
            
            return {
                "status": "imported",
                "configs": configs,
                "count": len(configs)
            }
        except Exception as e:
            logger.error(f"Failed to import configs: {e}")
            return {"status": "error", "message": str(e)}
    
    async def export_terradev_configs(self, repo_full_name: str, configs: Dict[str, Any]) -> Dict[str, Any]:
        """Export Terradev configurations to repository"""
        try:
            results = []
            
            for file_path, content in configs.items():
                try:
                    if isinstance(content, dict):
                        content = json.dumps(content, indent=2)
                    
                    result = await self.update_file(repo_full_name, file_path, content, f"Terradev config: {file_path}")
                    results.append({"file": file_path, "status": "success"})
                except Exception as e:
                    results.append({"file": file_path, "status": "error", "message": str(e)})
            
            return {
                "status": "exported",
                "results": results,
                "success_count": sum(1 for r in results if r["status"] == "success")
            }
        except Exception as e:
            logger.error(f"Failed to export configs: {e}")
            return {"status": "error", "message": str(e)}
    
    async def sync_with_github(self, repo_full_name: str, local_configs: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronize configurations with GitHub repository"""
        try:
            # Import remote configs
            remote_configs = await self.import_terradev_configs(repo_full_name)
            
            # Merge configurations (local takes precedence)
            merged_configs = remote_configs.get("configs", {})
            merged_configs.update(local_configs)
            
            # Export merged configs
            export_result = await self.export_terradev_configs(repo_full_name, merged_configs)
            
            return {
                "status": "synced",
                "remote_configs": remote_configs.get("count", 0),
                "local_configs": len(local_configs),
                "merged_configs": len(merged_configs),
                "export_result": export_result
            }
        except Exception as e:
            logger.error(f"Failed to sync with GitHub: {e}")
            return {"status": "error", "message": str(e)}
    
    async def create_terradev_repository(self, name: str = "terradev-configs") -> Dict[str, Any]:
        """Create a Terradev configuration repository"""
        try:
            # Create repository
            repo_data = await self.create_repository(
                name=name,
                description="Terradev ML Training Platform Configurations",
                private=False
            )
            
            # Add initial configuration files
            initial_configs = {
                "README.md": """# Terradev Configurations

This repository contains configuration files for the Terradev ML Training Platform.

## Structure

- `terradev_config.json` - Main platform configuration
- `training_configs/` - Training job configurations
- `kubernetes/` - Kubernetes deployment manifests
- `docker/` - Docker configurations
- `scripts/` - Utility scripts

## Usage

These configurations are automatically synchronized with the Terradev platform.
""",
                "terradev_config.json": json.dumps({
                    "providers": {
                        "vast": {"enabled": False},
                        "enhanced": {"enabled": False},
                        "aws": {"enabled": False},
                        "runpod": {"enabled": False},
                        "gcp": {"enabled": False}
                    },
                    "huggingface": {"enabled": False},
                    "kubernetes": {"enabled": False},
                    "github": {"enabled": True},
                    "webapp": {"host": "0.0.0.0", "port": 8000}
                }, indent=2)
            }
            
            export_result = await self.export_terradev_configs(repo_data["full_name"], initial_configs)
            
            return {
                "status": "created",
                "repository": repo_data,
                "initial_configs": export_result
            }
        except Exception as e:
            logger.error(f"Failed to create Terradev repository: {e}")
            return {"status": "error", "message": str(e)}
    
    async def get_repository_commits(self, repo_full_name: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get repository commits"""
        try:
            response = self.session.get(
                f"{self.base_url}/repos/{repo_full_name}/commits",
                params={"per_page": limit}
            )
            response.raise_for_status()
            
            commits = []
            for commit_data in response.json():
                commits.append({
                    "sha": commit_data["sha"],
                    "message": commit_data["commit"]["message"],
                    "author": commit_data["commit"]["author"]["name"],
                    "date": commit_data["commit"]["author"]["date"],
                    "url": commit_data["html_url"]
                })
            
            return commits
        except Exception as e:
            logger.error(f"Failed to get commits: {e}")
            raise
    
    def get_github_cli_commands(self) -> Dict[str, str]:
        """Get GitHub CLI commands for reference"""
        return {
            "authenticate": "gh auth login",
            "get_user": "gh api user",
            "list_repos": "gh api user/repos",
            "create_repo": "gh api user/repos -f name='repo-name' -f description='description'",
            "get_file": "gh api repos/owner/repo/contents/path/to/file",
            "update_file": "gh api repos/owner/repo/contents/path/to/file -X PUT -f message='commit message' -f content='base64-encoded-content'",
            "create_issue": "gh api repos/owner/repo/issues -X POST -f title='issue title' -f body='issue body'"
        }

# Test function
async def test_github_integration():
    """Test GitHub integration"""
    logging.info("🔧 Testing GitHub API Integration")
    logging.info("=" * 50)
    
    # Initialize integration
    github = GitHubAPIIntegration()
    
    # Test authentication (requires token)
    token = os.getenv("GITHUB_TOKEN")
    if token:
        logging.info(f"\n🔑 Testing authentication...")
        auth_result = await github.authenticate(token)
        logging.info(f"✅ Auth result: {auth_result}")
        
        if auth_result["status"] == "authenticated":
            logging.info(f"\n📊 Getting user repositories...")
            repos = await github.get_user_repositories()
            logging.info(f"✅ Found {len(repos)
            
            if repos:
                logging.info(f"\n📁 First repository: {repos[0].full_name}")
                
                logging.info(f"\n📄 Getting repository contents...")
                try:
                    contents = await github.get_repository_contents(repos[0].full_name)
                    logging.info(f"✅ Found {len(contents)
                except Exception as e:
                    logging.info(f"❌ Failed to get contents: {e}")
            
            logging.info(f"\n📋 GitHub CLI commands:")
            commands = github.get_github_cli_commands()
            for cmd, desc in commands.items():
                logging.info(f"   {cmd}: {desc}")
    else:
        logging.info("❌ No GITHUB_TOKEN found in environment")
        logging.info("Set GITHUB_TOKEN to test authentication")
    
    logging.info(f"\n🎯 GitHub Integration Test Completed!")

if __name__ == "__main__":
    asyncio.run(test_github_integration())
