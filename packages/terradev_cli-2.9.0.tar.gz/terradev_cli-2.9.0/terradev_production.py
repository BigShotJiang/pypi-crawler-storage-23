#!/usr/bin/env python3
"""
Terradev SkyPilot Wrapper - REAL Integration
Connects to actual SkyPilot API for production deployment
"""

import asyncio
import json
import time
import ping3
import subprocess
import logging
import os
import tempfile
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path

# REAL SkyPilot imports
import skypilot
from skypilot import sky
from skypilot.core import task

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class RealDeploymentMetrics:
    """Real deployment metrics from SkyPilot"""
    cluster_name: str
    provider: str
    region: str
    instance_type: str
    price_per_hour: float
    spot_price: float
    actual_launch_time: float
    gpu_utilization: float
    network_latency_to_user: float
    data_transfer_costs: float

class RealSkyPilotIntegration:
    """REAL SkyPilot integration for production deployment"""
    
    def __init__(self):
        self.sky_client = sky
        self.active_deployments = {}
        
    def get_real_clusters(self) -> List[Dict]:
        """Get REAL clusters from SkyPilot"""
        try:
            clusters = self.sky_client.status()
            logger.info(f"🔍 Found {len(clusters)} real SkyPilot clusters")
            
            real_clusters = []
            for cluster in clusters:
                if hasattr(cluster, 'name') and hasattr(cluster, 'region'):
                    real_clusters.append({
                        'name': cluster.name,
                        'region': getattr(cluster, 'region', 'unknown'),
                        'provider': getattr(cluster, 'cloud', 'unknown'),
                        'status': getattr(cluster, 'status', 'unknown'),
                        'resources': getattr(cluster, 'resources', {}),
                        'price_per_hour': self._extract_price(cluster)
                    })
            
            return real_clusters
            
        except Exception as e:
            logger.error(f"❌ Error getting SkyPilot clusters: {e}")
            return []
    
    def _extract_price(self, cluster) -> float:
        """Extract price from cluster object"""
        try:
            # Try different attribute names for price
            price_attrs = ['price_per_hour', 'hourly_price', 'cost', 'price']
            for attr in price_attrs:
                if hasattr(cluster, attr):
                    return float(getattr(cluster, attr))
            
            # Try from resources
            if hasattr(cluster, 'resources'):
                resources = cluster.resources
                if isinstance(resources, dict):
                    for key in ['price', 'cost', 'hourly_price']:
                        if key in resources:
                            return float(resources[key])
            
            return 0.0  # Default if no price found
            
        except Exception as e:
            return 0.0
    
    def launch_real_task(self, task_yaml: str, cluster_name: str = None) -> Dict:
        """Launch REAL task on SkyPilot"""
        try:
            # Create temporary YAML file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                f.write(task_yaml)
                yaml_file = f.name
            
            # Launch with SkyPilot
            start_time = time.time()
            
            if cluster_name:
                # Launch on specific cluster
                result = self.sky_client.launch(yaml_file, cluster=cluster_name)
            else:
                # Let SkyPilot choose best cluster
                result = self.sky_client.launch(yaml_file)
            
            launch_time = time.time() - start_time
            
            # Extract deployment info
            deployment_info = {
                'launch_time': launch_time,
                'cluster_name': getattr(result, 'cluster_name', 'unknown'),
                'job_id': getattr(result, 'job_id', 'unknown'),
                'status': getattr(result, 'status', 'unknown'),
                'timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"✅ Real SkyPilot deployment: {deployment_info}")
            return deployment_info
            
        except Exception as e:
            logger.error(f"❌ Real deployment failed: {e}")
            return {'error': str(e), 'timestamp': datetime.now().isoformat()}
        finally:
            # Clean up temporary file
            try:
                os.unlink(yaml_file)
            except Exception as e:
                pass

class ExploitableOpportunityFinder:
    """Finds HIGH-ROI exploitable opportunities in the GPU market"""
    
    def __init__(self):
        self.opportunities = []
        
    def find_arbitrage_opportunities(self, clusters: List[Dict]) -> List[Dict]:
        """Find REAL arbitrage opportunities"""
        opportunities = []
        
        # 1. Price arbitrage across providers
        price_opportunities = self._find_price_arbitrage(clusters)
        opportunities.extend(price_opportunities)
        
        # 2. Latency arbitrage (geographic)
        latency_opportunities = self._find_latency_arbitrage(clusters)
        opportunities.extend(latency_opportunities)
        
        # 3. Capacity arbitrage (availability)
        capacity_opportunities = self._find_capacity_arbitrage(clusters)
        opportunities.extend(capacity_opportunities)
        
        # 4. Time arbitrage (spot vs on-demand)
        time_opportunities = self._find_time_arbitrage(clusters)
        opportunities.extend(time_opportunities)
        
        return sorted(opportunities, key=lambda x: x['roi_score'], reverse=True)
    
    def _find_price_arbitrage(self, clusters: List[Dict]) -> List[Dict]:
        """Find price differences between providers"""
        opportunities = []
        
        # Group by GPU type
        gpu_groups = {}
        for cluster in clusters:
            gpu_type = self._extract_gpu_type(cluster)
            if gpu_type not in gpu_groups:
                gpu_groups[gpu_type] = []
            gpu_groups[gpu_type].append(cluster)
        
        # Find price differences within each GPU type
        for gpu_type, cluster_list in gpu_groups.items():
            if len(cluster_list) < 2:
                continue
                
            # Sort by price
            sorted_clusters = sorted(cluster_list, key=lambda x: x.get('price_per_hour', 999999))
            
            cheapest = sorted_clusters[0]
            most_expensive = sorted_clusters[-1]
            
            price_diff = most_expensive.get('price_per_hour', 0) - cheapest.get('price_per_hour', 0)
            
            if price_diff > 0.5:  # Significant price difference
                roi_score = (price_diff / most_expensive.get('price_per_hour', 1)) * 100
                
                opportunities.append({
                    'type': 'price_arbitrage',
                    'gpu_type': gpu_type,
                    'cheapest_provider': cheapest.get('provider'),
                    'cheapest_price': cheapest.get('price_per_hour'),
                    'expensive_provider': most_expensive.get('provider'),
                    'expensive_price': most_expensive.get('price_per_hour'),
                    'price_difference': price_diff,
                    'roi_score': roi_score,
                    'action': f'Switch from {most_expensive.get("provider")} to {cheapest.get("provider")}',
                    'potential_savings_per_hour': price_diff
                })
        
        return opportunities
    
    def _find_latency_arbitrage(self, clusters: List[Dict]) -> List[Dict]:
        """Find latency advantages for geographic optimization"""
        opportunities = []
        
        # Simulate user locations and their proximity to clusters
        user_locations = {
            'us_east': ['us-east-1', 'eastus', 'us-central1'],
            'us_west': ['us-west-1', 'us-west-2', 'westus'],
            'europe': ['eu-west-1', 'europe-west1', 'westeurope'],
            'asia': ['ap-southeast-1', 'asia-southeast1', 'japaneast']
        }
        
        for user_region, preferred_regions in user_locations.items():
            # Find clusters in preferred regions
            nearby_clusters = [
                cluster for cluster in clusters 
                if any(region in cluster.get('region', '').lower() for region in preferred_regions)
            ]
            
            if nearby_clusters:
                # Find cheapest among nearby clusters
                cheapest_nearby = min(nearby_clusters, key=lambda x: x.get('price_per_hour', 999999))
                
                # Compare with global cheapest
                global_cheapest = min(clusters, key=lambda x: x.get('price_per_hour', 999999))
                
                if cheapest_nearby.get('price_per_hour', 0) > global_cheapest.get('price_per_hour', 0):
                    latency_premium = cheapest_nearby.get('price_per_hour', 0) - global_cheapest.get('price_per_hour', 0)
                    
                    # Calculate if latency premium is worth it
                    latency_savings = 50  # Estimated latency savings in ms worth $X
                    if latency_premium < latency_savings / 10:  # If premium < latency value
                        opportunities.append({
                            'type': 'latency_arbitrage',
                            'user_region': user_region,
                            'recommended_cluster': cheapest_nearby.get('name'),
                            'recommended_provider': cheapest_nearby.get('provider'),
                            'recommended_price': cheapest_nearby.get('price_per_hour'),
                            'global_cheapest': global_cheapest.get('price_per_hour'),
                            'latency_premium': latency_premium,
                            'roi_score': latency_savings / 10 - latency_premium,
                            'action': f'Use {cheapest_nearby.get("provider")} for {user_region} users',
                            'benefit': f'Latency advantage worth ${latency_savings/10:.2f}/hr'
                        })
        
        return opportunities
    
    def _find_capacity_arbitrage(self, clusters: List[Dict]) -> List[Dict]:
        """Find capacity availability opportunities"""
        opportunities = []
        
        # Look for underutilized clusters
        for cluster in clusters:
            if cluster.get('status') == 'ready' and cluster.get('resources'):
                resources = cluster.get('resources', {})
                
                # Check if cluster has available capacity
                if isinstance(resources, dict):
                    gpu_count = resources.get('accelerators', 0)
                    if gpu_count > 0:
                        # This cluster has available GPU capacity
                        price = cluster.get('price_per_hour', 0)
                        
                        # Compare with average price
                        avg_price = sum(c.get('price_per_hour', 0) for c in clusters) / len(clusters)
                        
                        if price < avg_price * 0.8:  # 20% cheaper than average
                            roi_score = (avg_price - price) / avg_price * 100
                            
                            opportunities.append({
                                'type': 'capacity_arbitrage',
                                'cluster_name': cluster.get('name'),
                                'provider': cluster.get('provider'),
                                'available_gpus': gpu_count,
                                'price': price,
                                'avg_market_price': avg_price,
                                'discount_percentage': (avg_price - price) / avg_price * 100,
                                'roi_score': roi_score,
                                'action': f'Deploy on {cluster.get("name")} immediately',
                                'urgency': 'HIGH - Capacity available now'
                            })
        
        return opportunities
    
    def _find_time_arbitrage(self, clusters: List[Dict]) -> List[Dict]:
        """Find time-based arbitrage opportunities"""
        opportunities = []
        
        current_hour = datetime.now().hour
        
        # Different regions have different pricing patterns
        regional_patterns = {
            'us-east-1': {'peak_hours': [9, 10, 11, 14, 15, 16], 'off_peak_discount': 0.3},
            'us-west-1': {'peak_hours': [10, 11, 12, 13, 14, 15], 'off_peak_discount': 0.25},
            'europe-west1': {'peak_hours': [8, 9, 10, 11, 14, 15, 16], 'off_peak_discount': 0.35},
            'asia-southeast1': {'peak_hours': [9, 10, 11, 12, 13, 14], 'off_peak_discount': 0.4}
        }
        
        for cluster in clusters:
            region = cluster.get('region', '')
            
            for pattern_region, pattern in regional_patterns.items():
                if pattern_region in region.lower():
                    is_off_peak = current_hour not in pattern['peak_hours']
                    
                    if is_off_peak:
                        off_peak_price = cluster.get('price_per_hour', 0) * (1 - pattern['off_peak_discount'])
                        savings = cluster.get('price_per_hour', 0) - off_peak_price
                        
                        opportunities.append({
                            'type': 'time_arbitrage',
                            'cluster_name': cluster.get('name'),
                            'provider': cluster.get('provider'),
                            'region': region,
                            'current_hour': current_hour,
                            'is_off_peak': True,
                            'regular_price': cluster.get('price_per_hour'),
                            'off_peak_price': off_peak_price,
                            'savings_per_hour': savings,
                            'off_peak_discount': pattern['off_peak_discount'],
                            'roi_score': pattern['off_peak_discount'] * 100,
                            'action': f'Deploy now during off-peak hours',
                            'time_window': f'Next {len(pattern["peak_hours"])} hours available'
                        })
        
        return opportunities
    
    def _extract_gpu_type(self, cluster: Dict) -> str:
        """Extract GPU type from cluster"""
        resources = cluster.get('resources', {})
        if isinstance(resources, dict):
            return resources.get('accelerators', 'unknown')
        return 'unknown'

class HighROIStrategy:
    """HIGH-ROI strategies for GPU arbitrage"""
    
    def __init__(self):
        self.strategies = {
            'immediate_savings': self._immediate_savings_strategy,
            'capacity_capture': self._capacity_capture_strategy,
            'geographic_optimization': self._geographic_optimization_strategy,
            'timing_optimization': self._timing_optimization_strategy
        }
    
    def get_top_opportunities(self, opportunities: List[Dict], limit: int = 5) -> List[Dict]:
        """Get top HIGH-ROI opportunities"""
        return opportunities[:limit]
    
    def _immediate_savings_strategy(self, opportunities: List[Dict]) -> Dict:
        """Strategy 1: Immediate price arbitrage"""
        price_opps = [opp for opp in opportunities if opp.get('type') == 'price_arbitrage']
        
        if price_opps:
            best = max(price_opps, key=lambda x: x.get('roi_score', 0))
            
            return {
                'strategy': 'immediate_savings',
                'description': 'Switch to cheapest provider for immediate savings',
                'opportunity': best,
                'action_items': [
                    f"Move workloads from {best.get('expensive_provider')} to {best.get('cheapest_provider')}",
                    f"Expected savings: ${best.get('potential_savings_per_hour', 0):.2f}/hour",
                    f"ROI: {best.get('roi_score', 0):.1f}%"
                ],
                'implementation_difficulty': 'LOW',
                'time_to_value': 'IMMEDIATE',
                'risk_level': 'LOW'
            }
        
        return None
    
    def _capacity_capture_strategy(self, opportunities: List[Dict]) -> Dict:
        """Strategy 2: Capture available capacity"""
        capacity_opps = [opp for opp in opportunities if opp.get('type') == 'capacity_arbitrage']
        
        if capacity_opps:
            best = max(capacity_opps, key=lambda x: x.get('roi_score', 0))
            
            return {
                'strategy': 'capacity_capture',
                'description': 'Deploy on underutilized clusters with discounted pricing',
                'opportunity': best,
                'action_items': [
                    f"Deploy immediately on {best.get('cluster_name')}",
                    f"Available GPUs: {best.get('available_gpus')}",
                    f"Discount: {best.get('discount_percentage', 0):.1f}%",
                    f"Urgency: {best.get('urgency', 'MEDIUM')}"
                ],
                'implementation_difficulty': 'LOW',
                'time_to_value': 'IMMEDIATE',
                'risk_level': 'LOW'
            }
        
        return None
    
    def _geographic_optimization_strategy(self, opportunities: List[Dict]) -> Dict:
        """Strategy 3: Geographic latency optimization"""
        geo_opps = [opp for opp in opportunities if opp.get('type') == 'latency_arbitrage']
        
        if geo_opps:
            best = max(geo_opps, key=lambda x: x.get('roi_score', 0))
            
            return {
                'strategy': 'geographic_optimization',
                'description': 'Optimize for user latency while managing costs',
                'opportunity': best,
                'action_items': [
                    f"Route {best.get('user_region')} users to {best.get('recommended_provider')}",
                    f"Latency benefit: {best.get('benefit', 'Unknown')}",
                    f"Cost premium: ${best.get('latency_premium', 0):.2f}/hour"
                ],
                'implementation_difficulty': 'MEDIUM',
                'time_to_value': '1-2 days',
                'risk_level': 'LOW'
            }
        
        return None
    
    def _timing_optimization_strategy(self, opportunities: List[Dict]) -> Dict:
        """Strategy 4: Time-based optimization"""
        time_opps = [opp for opp in opportunities if opp.get('type') == 'time_arbitrage']
        
        if time_opps:
            best = max(time_opps, key=lambda x: x.get('roi_score', 0))
            
            return {
                'strategy': 'timing_optimization',
                'description': 'Leverage off-peak pricing for batch workloads',
                'opportunity': best,
                'action_items': [
                    f"Schedule batch jobs during off-peak hours",
                    f"Current hour: {best.get('current_hour')}",
                    f"Savings: {best.get('off_peak_discount', 0):.1%}",
                    f"Time window: {best.get('time_window', 'Unknown')}"
                ],
                'implementation_difficulty': 'MEDIUM',
                'time_to_value': 'IMMEDIATE',
                'risk_level': 'LOW'
            }
        
        return None

# Main production class
class TerradevProduction:
    """Production-ready Terradev with REAL SkyPilot integration"""
    
    def __init__(self):
        self.sky_integration = RealSkyPilotIntegration()
        self.opportunity_finder = ExploitableOpportunityFinder()
        self.roi_strategy = HighROIStrategy()
        
    async def scan_market_opportunities(self) -> Dict:
        """Scan for REAL exploitable opportunities"""
        logger.info("🔍 Scanning market for HIGH-ROI opportunities...")
        
        # 1. Get real clusters from SkyPilot
        clusters = self.sky_integration.get_real_clusters()
        
        if not clusters:
            logger.warning("❌ No clusters found. Check SkyPilot configuration.")
            return {'error': 'No clusters available'}
        
        # 2. Find arbitrage opportunities
        opportunities = self.opportunity_finder.find_arbitrage_opportunities(clusters)
        
        # 3. Generate ROI strategies
        strategies = []
        for strategy_name, strategy_func in self.roi_strategy.strategies.items():
            strategy = strategy_func(opportunities)
            if strategy:
                strategies.append(strategy)
        
        # 4. Compile results
        result = {
            'scan_timestamp': datetime.now().isoformat(),
            'total_clusters': len(clusters),
            'opportunities_found': len(opportunities),
            'top_opportunities': self.opportunity_finder.get_top_opportunities(opportunities, 3),
            'roi_strategies': strategies,
            'market_summary': {
                'providers': list(set(c.get('provider') for c in clusters)),
                'regions': list(set(c.get('region') for c in clusters)),
                'avg_price': sum(c.get('price_per_hour', 0) for c in clusters) / len(clusters),
                'price_range': {
                    'min': min(c.get('price_per_hour', 999999) for c in clusters),
                    'max': max(c.get('price_per_hour', 0) for c in clusters)
                }
            }
        }
        
        logger.info(f"✅ Found {len(opportunities)} opportunities with {len(strategies)} ROI strategies")
        return result
    
    async def execute_strategy(self, strategy_name: str, task_yaml: str) -> Dict:
        """Execute a specific ROI strategy"""
        logger.info(f"🚀 Executing strategy: {strategy_name}")
        
        # Get current opportunities
        scan_result = await self.scan_market_opportunities()
        
        if 'error' in scan_result:
            return scan_result
        
        # Find the strategy
        strategy = None
        for s in scan_result['roi_strategies']:
            if s['strategy'] == strategy_name:
                strategy = s
                break
        
        if not strategy:
            return {'error': f'Strategy {strategy_name} not found'}
        
        # Execute the strategy
        if strategy['strategy'] == 'immediate_savings':
            return await self._execute_immediate_savings(strategy, task_yaml)
        elif strategy['strategy'] == 'capacity_capture':
            return await self._execute_capacity_capture(strategy, task_yaml)
        else:
            return {'error': f'Strategy execution not implemented for {strategy_name}'}
    
    async def _execute_immediate_savings(self, strategy: Dict, task_yaml: str) -> Dict:
        """Execute immediate savings strategy"""
        opportunity = strategy['opportunity']
        
        # Deploy to cheapest provider
        cheapest_cluster = opportunity.get('cheapest_provider', 'auto')
        
        deployment = self.sky_integration.launch_real_task(task_yaml, cheapest_cluster)
        
        return {
            'strategy_executed': 'immediate_savings',
            'deployment': deployment,
            'expected_savings': opportunity.get('potential_savings_per_hour', 0),
            'roi_percentage': opportunity.get('roi_score', 0),
            'message': f"Deployed to {cheapest_cluster} for immediate savings"
        }
    
    async def _execute_capacity_capture(self, strategy: Dict, task_yaml: str) -> Dict:
        """Execute capacity capture strategy"""
        opportunity = strategy['opportunity']
        
        # Deploy to specific cluster
        cluster_name = opportunity.get('cluster_name')
        
        deployment = self.sky_integration.launch_real_task(task_yaml, cluster_name)
        
        return {
            'strategy_executed': 'capacity_capture',
            'deployment': deployment,
            'discount_percentage': opportunity.get('discount_percentage', 0),
            'roi_percentage': opportunity.get('roi_score', 0),
            'message': f"Captured capacity on {cluster_name} with discount"
        }

# CLI interface
async def main():
    """Production CLI interface"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Terradev Production - HIGH-ROI GPU Arbitrage')
    parser.add_argument('--scan', action='store_true', help='Scan for market opportunities')
    parser.add_argument('--execute', help='Execute specific strategy')
    parser.add_argument('--task-yaml', help='Task YAML file for deployment')
    parser.add_argument('--clusters', action='store_true', help='Show available clusters')
    
    args = parser.parse_args()
    
    terradev = TerradevProduction()
    
    if args.clusters:
        clusters = terradev.sky_integration.get_real_clusters()
        logging.info("🔍 Available SkyPilot Clusters:")
        logging.info(json.dumps(clusters, indent=2)
    
    elif args.scan:
        opportunities = await terradev.scan_market_opportunities()
        logging.info("🎯 HIGH-ROI Market Opportunities:")
        logging.info(json.dumps(opportunities, indent=2)
    
    elif args.execute and args.task_yaml:
        # Read task YAML
        with open(args.task_yaml, 'r') as f:
            task_yaml_content = f.read()
        
        result = await terradev.execute_strategy(args.execute, task_yaml_content)
        logging.info("🚀 Strategy Execution Result:")
        logging.info(json.dumps(result, indent=2)
    
    else:
        parser.print_help()

if __name__ == "__main__":
    asyncio.run(main())
