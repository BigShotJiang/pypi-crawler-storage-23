#!/usr/bin/env python3
"""
TensorDock Provider Integration for Terradev
Complete provider implementation with GPU instance management
"""

import os
import json
import asyncio
import aiohttp
import logging
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
import hashlib
import base64
from pathlib import Path

# Import base provider classes (create minimal base classes for now)
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict, Any
from datetime import datetime

class ProviderType(Enum):
    GPU_CLOUD = "gpu_cloud"
    BARE_METAL = "bare_metal"
    CONTAINER = "container"

class InstanceStatus(Enum):
    RUNNING = "running"
    STOPPED = "stopped"
    STARTING = "starting"
    STOPPING = "stopping"
    ERROR = "error"
    UNKNOWN = "unknown"

@dataclass
class GPUInstance:
    """GPU instance base class"""
    id: str
    name: str
    provider: str
    region: str
    instance_type: str
    status: InstanceStatus
    cpu_count: int
    memory_gb: int
    storage_gb: int
    gpu_model: str
    gpu_count: int
    hourly_cost: float
    ip_address: Optional[str] = None
    created_at: Optional[datetime] = None

@dataclass
class InstanceConfig:
    """Instance configuration base class"""
    name: str
    instance_type: str
    cpu_count: int
    memory_gb: int
    storage_gb: int
    gpu_model: str
    gpu_count: int
    region: Optional[str] = None
    image: Optional[str] = None

class BaseProvider:
    """Base provider class"""
    def __init__(self, name: str, provider_type: ProviderType, base_url: str, 
                 api_key: str, region: str):
        self.name = name
        self.provider_type = provider_type
        self.base_url = base_url
        self.api_key = api_key
        self.region = region

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class TensorDockInstanceConfig(InstanceConfig):
    """TensorDock-specific instance configuration"""
    location_id: Optional[str] = None
    ssh_key: Optional[str] = None
    use_dedicated_ip: bool = True
    
    def to_tensordock_dict(self) -> Dict[str, Any]:
        """Convert to TensorDock API format"""
        return {
            "name": self.name,
            "image": self.image or "ubuntu2404",
            "resources": {
                "vcpu_count": self.cpu_count,
                "ram_gb": self.memory_gb,
                "storage_gb": self.storage_gb,
                "gpus": {
                    self.gpu_model: {"count": self.gpu_count}
                }
            },
            "useDedicatedIp": self.use_dedicated_ip,
            "location_id": self.location_id,
            "ssh_key": self.ssh_key
        }

class TensorDockProvider(BaseProvider):
    """TensorDock GPU cloud provider implementation"""
    
    def __init__(self, client_id: str, api_token: str, base_url: str = "https://api.tensordock.com"):
        super().__init__(
            name="TensorDock",
            provider_type=ProviderType.GPU_CLOUD,
            base_url=base_url,
            api_key=api_token,
            region="auto"  # TensorDock uses location-based deployment
        )
        
        self.client_id = client_id
        self.session: Optional[aiohttp.ClientSession] = None
        
        # GPU model mappings
        self.gpu_mappings = {
            "rtx4090": "geforcertx4090-pcie-24gb",
            "rtx3090": "geforcertx3090-pcie-24gb",
            "a100": "a100-pcie-40gb",
            "h100": "h100-pcie-80gb"
        }
        
        # Instance type configurations
        self.instance_types = {
            "ml-small": {"cpu": 4, "memory": 16, "storage": 100, "gpu": "rtx4090", "gpu_count": 1},
            "ml-medium": {"cpu": 8, "memory": 32, "storage": 200, "gpu": "rtx4090", "gpu_count": 1},
            "ml-large": {"cpu": 16, "memory": 64, "storage": 500, "gpu": "rtx4090", "gpu_count": 2},
            "training": {"cpu": 32, "memory": 128, "storage": 1000, "gpu": "a100", "gpu_count": 4}
        }
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession(
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "X-Client-ID": self.client_id,
                "Content-Type": "application/json"
            },
            timeout=aiohttp.ClientTimeout(total=300)
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make API request with error handling"""
        if not self.session:
            raise RuntimeError("Session not initialized. Use async context manager.")
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            async with self.session.request(method, url, json=data) as response:
                if response.status in [200, 201]:
                    return await response.json()
                elif response.status == 400:
                    error_data = await response.json()
                    raise ValueError(f"Bad request: {error_data.get('message', 'Unknown error')}")
                elif response.status == 401:
                    raise ValueError("Unauthorized: Invalid credentials")
                elif response.status == 403:
                    raise ValueError("Forbidden: Insufficient permissions")
                elif response.status == 404:
                    raise ValueError("Not found: Resource does not exist")
                elif response.status == 429:
                    raise ValueError("Rate limit exceeded")
                elif response.status >= 500:
                    raise ValueError(f"Server error: {response.status}")
                else:
                    error_text = await response.text()
                    raise ValueError(f"Unexpected status {response.status}: {error_text}")
                    
        except aiohttp.ClientError as e:
            logger.error(f"Network error: {e}")
            raise
        except Exception as e:
            logger.error(f"API request failed: {e}")
            raise
    
    async def test_connection(self) -> bool:
        """Test API connection"""
        try:
            await self._make_request("GET", "/api/v2/instances")
            return True
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False
    
    async def get_available_regions(self) -> List[str]:
        """Get available regions/locations"""
        # TensorDock uses location-based deployment
        # For now, return common locations
        return ["us-east", "us-west", "eu-west", "asia-pacific"]
    
    async def get_instance_types(self) -> Dict[str, Dict[str, Any]]:
        """Get available instance types"""
        return self.instance_types
    
    async def get_pricing(self, instance_type: str, region: str = None) -> Dict[str, float]:
        """Get pricing for instance type"""
        # Mock pricing - in production, fetch from API
        pricing = {
            "ml-small": {"hourly": 0.50, "monthly": 360.0},
            "ml-medium": {"hourly": 1.00, "monthly": 720.0},
            "ml-large": {"hourly": 2.00, "monthly": 1440.0},
            "training": {"hourly": 8.00, "monthly": 5760.0}
        }
        
        return pricing.get(instance_type, {"hourly": 0.0, "monthly": 0.0})
    
    async def create_instance(self, config: InstanceConfig) -> GPUInstance:
        """Create a new GPU instance"""
        logger.info(f"Creating TensorDock instance: {config.name}")
        
        # Convert to TensorDock config
        if isinstance(config, TensorDockInstanceConfig):
            tensordock_config = config.to_tensordock_dict()
        else:
            # Map standard config to TensorDock
            gpu_model = self.gpu_mappings.get(config.gpu_model, config.gpu_model)
            
            tensordock_config = {
                "name": config.name,
                "image": config.image or "ubuntu2404",
                "resources": {
                    "vcpu_count": config.cpu_count,
                    "ram_gb": config.memory_gb,
                    "storage_gb": config.storage_gb,
                    "gpus": {
                        gpu_model: {"count": config.gpu_count}
                    }
                },
                "useDedicatedIp": True
            }
        
        # Prepare request data
        request_data = {
            "data": {
                "type": "virtualmachine",
                "attributes": tensordock_config
            }
        }
        
        # Make API request
        response_data = await self._make_request("POST", "/api/v2/instances", request_data)
        
        # Parse response
        instance_data = response_data.get("data", {})
        
        # Create GPU instance
        instance = GPUInstance(
            id=instance_data.get("id", ""),
            name=config.name,
            provider=self.name,
            region=config.region or "auto",
            instance_type=config.instance_type,
            status=InstanceStatus.STARTING,
            cpu_count=config.cpu_count,
            memory_gb=config.memory_gb,
            storage_gb=config.storage_gb,
            gpu_model=config.gpu_model,
            gpu_count=config.gpu_count,
            hourly_cost=await self._get_instance_cost(config),
            created_at=datetime.utcnow()
        )
        
        logger.info(f"Created TensorDock instance: {instance.id}")
        return instance
    
    async def get_instance(self, instance_id: str) -> Optional[GPUInstance]:
        """Get instance details"""
        try:
            response_data = await self._make_request("GET", f"/api/v2/instances/{instance_id}")
            
            # Parse response
            resources_data = response_data.get("resources", {})
            
            # Extract GPU info
            gpu_model = "unknown"
            gpu_count = 0
            for gpu_model_name, gpu_info in resources_data.get("gpus", {}).items():
                gpu_model = gpu_model_name
                gpu_count = gpu_info.get("count", 0)
                break
            
            # Map status
            status_map = {
                "running": InstanceStatus.RUNNING,
                "starting": InstanceStatus.STARTING,
                "stopping": InstanceStatus.STOPPING,
                "stopped": InstanceStatus.STOPPED,
                "error": InstanceStatus.ERROR
            }
            status = status_map.get(response_data.get("status", "unknown"), InstanceStatus.UNKNOWN)
            
            instance = GPUInstance(
                id=response_data.get("id", instance_id),
                name=response_data.get("name", ""),
                provider=self.name,
                region="auto",
                instance_type="custom",
                status=status,
                cpu_count=resources_data.get("vcpu_count", 0),
                memory_gb=resources_data.get("ram_gb", 0),
                storage_gb=resources_data.get("storage_gb", 0),
                gpu_model=gpu_model,
                gpu_count=gpu_count,
                hourly_cost=response_data.get("rateHourly", 0.0),
                ip_address=response_data.get("ipAddress"),
                created_at=datetime.utcnow()
            )
            
            return instance
            
        except Exception as e:
            logger.error(f"Failed to get instance {instance_id}: {e}")
            return None
    
    async def list_instances(self) -> List[GPUInstance]:
        """List all instances"""
        logger.info("Listing TensorDock instances")
        
        try:
            response_data = await self._make_request("GET", "/api/v2/instances")
            
            instances = []
            for instance_data in response_data.get("data", {}).get("instances", []):
                instance = await self._parse_instance_data(instance_data)
                if instance:
                    instances.append(instance)
            
            return instances
            
        except Exception as e:
            logger.error(f"Failed to list instances: {e}")
            return []
    
    async def _parse_instance_data(self, instance_data: Dict[str, Any]) -> Optional[GPUInstance]:
        """Parse instance data from API response"""
        try:
            resources_data = instance_data.get("resources", {})
            
            # Extract GPU info
            gpu_model = "unknown"
            gpu_count = 0
            for gpu_model_name, gpu_info in resources_data.get("gpus", {}).items():
                gpu_model = gpu_model_name
                gpu_count = gpu_info.get("count", 0)
                break
            
            # Map status
            status_map = {
                "running": InstanceStatus.RUNNING,
                "starting": InstanceStatus.STARTING,
                "stopping": InstanceStatus.STOPPING,
                "stopped": InstanceStatus.STOPPED,
                "error": InstanceStatus.ERROR
            }
            status = status_map.get(instance_data.get("status", "unknown"), InstanceStatus.UNKNOWN)
            
            instance = GPUInstance(
                id=instance_data.get("id", ""),
                name=instance_data.get("name", ""),
                provider=self.name,
                region="auto",
                instance_type="custom",
                status=status,
                cpu_count=resources_data.get("vcpu_count", 0),
                memory_gb=resources_data.get("ram_gb", 0),
                storage_gb=resources_data.get("storage_gb", 0),
                gpu_model=gpu_model,
                gpu_count=gpu_count,
                hourly_cost=instance_data.get("rateHourly", 0.0),
                ip_address=instance_data.get("ipAddress"),
                created_at=datetime.utcnow()
            )
            
            return instance
            
        except Exception as e:
            logger.error(f"Failed to parse instance data: {e}")
            return None
    
    async def start_instance(self, instance_id: str) -> bool:
        """Start an instance"""
        try:
            await self._make_request("POST", f"/api/v2/instances/{instance_id}/start")
            logger.info(f"Started instance: {instance_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to start instance {instance_id}: {e}")
            return False
    
    async def stop_instance(self, instance_id: str) -> bool:
        """Stop an instance"""
        try:
            await self._make_request("POST", f"/api/v2/instances/{instance_id}/stop")
            logger.info(f"Stopped instance: {instance_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to stop instance {instance_id}: {e}")
            return False
    
    async def delete_instance(self, instance_id: str) -> bool:
        """Delete an instance"""
        try:
            await self._make_request("DELETE", f"/api/v2/instances/{instance_id}")
            logger.info(f"Deleted instance: {instance_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete instance {instance_id}: {e}")
            return False
    
    async def get_instance_logs(self, instance_id: str, lines: int = 100) -> str:
        """Get instance logs"""
        # TensorDock doesn't provide direct log access
        # Return SSH connection info instead
        instance = await self.get_instance(instance_id)
        if instance and instance.ip_address:
            return f"SSH to ubuntu@{instance.ip_address} to access logs"
        return "Instance not found or no IP address"
    
    async def _get_instance_cost(self, config: InstanceConfig) -> float:
        """Get hourly cost for instance configuration"""
        # Mock pricing calculation
        base_cost = 0.1  # Base cost per hour
        cpu_cost = config.cpu_count * 0.02
        memory_cost = config.memory_gb * 0.01
        storage_cost = config.storage_gb * 0.001
        gpu_cost = config.gpu_count * 0.4  # GPU cost
        
        return base_cost + cpu_cost + memory_cost + storage_cost + gpu_cost
    
    async def create_ml_instance(self, name: str, instance_type: str = "ml-medium", 
                               region: str = None, ssh_key: str = None) -> GPUInstance:
        """Create optimized ML instance"""
        
        if instance_type not in self.instance_types:
            raise ValueError(f"Unknown instance type: {instance_type}")
        
        type_config = self.instance_types[instance_type]
        
        config = TensorDockInstanceConfig(
            name=name,
            instance_type=instance_type,
            cpu_count=type_config["cpu"],
            memory_gb=type_config["memory"],
            storage_gb=type_config["storage"],
            gpu_model=type_config["gpu"],
            gpu_count=type_config["gpu_count"],
            region=region,
            ssh_key=ssh_key,
            use_dedicated_ip=True
        )
        
        return await self.create_instance(config)
    
    async def create_training_cluster(self, cluster_name: str, node_count: int = 3, 
                                    instance_type: str = "training") -> List[GPUInstance]:
        """Create distributed training cluster"""
        
        instances = []
        
        for i in range(node_count):
            node_name = f"{cluster_name}-node-{i+1}"
            
            try:
                instance = await self.create_ml_instance(node_name, instance_type)
                instances.append(instance)
                logger.info(f"Created cluster node: {node_name}")
                
            except Exception as e:
                logger.error(f"Failed to create cluster node {node_name}: {e}")
                # Clean up created instances
                for instance in instances:
                    await self.delete_instance(instance.id)
                raise
        
        return instances

# Factory function
def create_tensordock_provider(client_id: str, api_token: str) -> TensorDockProvider:
    """Create TensorDock provider instance"""
    return TensorDockProvider(client_id, api_token)

# Example usage
async def example_usage():
    """Example usage of TensorDock provider"""
    
    # Initialize provider
    provider = TensorDockProvider(
        client_id="6f71b631-5a32-42f1-94a5-d089adffdb24",
        api_token = os.environ.get("TOKEN_API_TOKEN", "rxOI1pnIZ9UL3J8MZmMmYBkKk7EwPdyS")
    )
    
    async with provider:
        # Test connection
        if await provider.test_connection():
            logging.info("✅ Connection successful")
        else:
            logging.info("❌ Connection failed")
            return
        
        # Get available instance types
        instance_types = await provider.get_instance_types()
        logging.info(f"Available instance types: {list(instance_types.keys()
        
        # Create ML instance
        try:
            instance = await provider.create_ml_instance(
                name="terradev-ml-test",
                instance_type="ml-medium"
            )
            logging.info(f"Created instance: {instance.id} - {instance.name}")
            
            # List instances
            instances = await provider.list_instances()
            logging.info(f"Total instances: {len(instances)
            
            # Get instance details
            details = await provider.get_instance(instance.id)
            if details:
                logging.info(f"Instance status: {details.status}")
                logging.info(f"Instance IP: {details.ip_address}")
                logging.info(f"Hourly cost: ${details.hourly_cost}")
            
            # Clean up
            await provider.delete_instance(instance.id)
            logging.info("Instance deleted")
            
        except Exception as e:
            logging.info(f"Example failed: {e}")

if __name__ == "__main__":
    asyncio.run(example_usage())
