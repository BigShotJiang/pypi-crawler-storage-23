import asyncio
import logging

#!/usr/bin/env python3
"""
Secure GCP Authentication Setup (No Service Account Keys)
Uses Application Default Credentials with user authentication
"""

import os
import json
import subprocess
from pathlib import Path

def setup_secure_gcp_auth():
    """Setup GCP authentication without service account keys"""
    
    logging.info("🔐 Secure GCP Authentication Setup (No Service Account Keys)
    logging.info("=" * 60)
    logging.info("📋 Organization Policy: iam.disableServiceAccountKeyCreation")
    logging.info("✅ This is a GOOD security practice!")
    logging.info()
    
    logging.info("🔧 Option 1: Use User Authentication (Recommended)
    logging.info("-" * 50)
    logging.info("1. Install Google Cloud CLI:")
    logging.info("   brew install google-cloud-sdk")
    logging.info()
    logging.info("2. Initialize gcloud:")
    logging.info("   gcloud init")
    logging.info()
    logging.info("3. Authenticate for Application Default Credentials:")
    logging.info("   gcloud auth application-default login")
    logging.info()
    logging.info("4. Enable Compute Engine API:")
    logging.info("   gcloud services enable compute.googleapis.com")
    logging.info()
    
    logging.info("🔧 Option 2: Use Workload Identity (Production)
    logging.info("-" * 50)
    logging.info("1. Create service account without keys")
    logging.info("2. Use Workload Identity Federation")
    logging.info("3. Authenticate through IAM roles")
    logging.info()
    
    logging.info("🔧 Option 3: Use Terraform Service Account (Current Setup)
    logging.info("-" * 50)
    logging.info("1. Let Terraform handle authentication")
    logging.info("2. Use ADC from gcloud CLI")
    logging.info("3. No manual key management needed")
    logging.info()

def install_gcloud_cli():
    """Install Google Cloud CLI on macOS"""
    logging.info("📦 Installing Google Cloud CLI...")
    
    try:
        # Check if gcloud is already installed
        result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        if result.returncode == 0:
            logging.info("✅ Google Cloud CLI already installed")
            gcloud_path = result.stdout.strip()
            logging.info(f"📍 Location: {gcloud_path}")
            return True
    except Exception as e:
        pass
    
    # Install with Homebrew
    try:
        logging.info("🍺 Installing with Homebrew...")
        result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        
        if result.returncode == 0:
            logging.info("✅ Google Cloud CLI installed successfully")
            
            # Add to PATH
            logging.info("🔧 Adding to shell profile...")
            shell_profile = Path.home() / ".zshrc"
            
            with open(shell_profile, 'a') as f:
                f.write("\n# Google Cloud CLI\n")
                f.write("if [ -f '/usr/local/Caskroom/google-cloud-sdk/latest/google-cloud-sdk/path.zsh.inc' ]; then\n")
                f.write("  source '/usr/local/Caskroom/google-cloud-sdk/latest/google-cloud-sdk/path.zsh.inc'\n")
                f.write("fi\n")
                f.write("if [ -f '/usr/local/Caskroom/google-cloud-sdk/latest/google-cloud-sdk/completion.zsh.inc' ]; then\n")
                f.write("  source '/usr/local/Caskroom/google-cloud-sdk/latest/google-cloud-sdk/completion.zsh.inc'\n")
                f.write("fi\n")
            
            logging.info("✅ Added to shell profile")
            logging.info("🔄 Please restart your terminal or run: source ~/.zshrc")
            return True
        else:
            logging.info(f"❌ Installation failed: {result.stderr}")
            return False
            
    except FileNotFoundError:
        logging.info("❌ Homebrew not found. Please install Homebrew first:")
        logging.info("   /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)
        return False
    except Exception as e:
        logging.info(f"❌ Installation error: {e}")
        return False

def setup_gcloud_auth():
    """Setup gcloud authentication"""
    logging.info("🔧 Setting up gcloud authentication...")
    
    # Check if gcloud is available
    try:
        result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        if result.returncode != 0:
            logging.info("❌ gcloud not found. Please install it first.")
            return False
    except FileNotFoundError:
        logging.info("❌ gcloud not found. Please install it first.")
        return False
    
    logging.info("✅ gcloud found")
    
    # Initialize gcloud
    logging.info("\n🚀 Initializing gcloud...")
    logging.info("📋 This will open a browser window for authentication")
    
    try:
        # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        logging.info("✅ gcloud initialized")
    except subprocess.CalledProcessError as e:
        logging.info(f"❌ gcloud init failed: {e}")
        return False
    
    # Set up application default credentials
    logging.info("\n🔑 Setting up Application Default Credentials...")
    logging.info("📋 This will open a browser window for authentication")
    
    try:
        # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        logging.info("✅ Application Default Credentials configured")
    except subprocess.CalledProcessError as e:
        logging.info(f"❌ ADC setup failed: {e}")
        return False
    
    # Get project information
    try:
        result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
        if result.returncode == 0 and result.stdout.strip():
            project_id = result.stdout.strip()
            logging.info(f"📋 Project ID: {project_id}")
            
            # Set environment variable
            os.environ['GOOGLE_CLOUD_PROJECT'] = project_id
            logging.info(f"🔧 Set GOOGLE_CLOUD_PROJECT={project_id}")
            
            return True
        else:
            logging.info("⚠️  Could not get project ID")
            return False
    except Exception as e:
        logging.info(f"⚠️  Error getting project ID: {e}")
        return False

def enable_compute_api():
    """Enable Compute Engine API"""
    logging.info("\n🔧 Enabling Compute Engine API...")
    
    try:
        project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
        if not project_id:
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            if result.returncode == 0:
                project_id = result.stdout.strip()
        
        if project_id:
            # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            logging.info(f"✅ Compute Engine API enabled for project {project_id}")
            return True
        else:
            logging.info("❌ Could not determine project ID")
            return False
            
    except subprocess.CalledProcessError as e:
        logging.info(f"❌ Failed to enable Compute Engine API: {e}")
        return False

def test_gcp_connection():
    """Test GCP connection with secure authentication"""
    logging.info("\n🧪 Testing GCP Connection...")
    
    try:
        from google.cloud import compute_v1
        from google.auth import default
        
        # Test authentication
        credentials, project_id = default()
        logging.info(f"✅ Authentication successful!")
        logging.info(f"📋 Project ID: {project_id}")
        
        # Test Compute Engine API
        client = compute_v1.InstancesClient()
        zones = client.list_zones(project=project_id)
        zone_count = len(list(zones))
        
        logging.info(f"✅ Compute Engine API working!")
        logging.info(f"📊 Found {zone_count} zones")
        
        return True
        
    except Exception as e:
        logging.info(f"❌ GCP connection failed: {e}")
        return False

def main():
    """Main setup function"""
    
    logging.info("🔐 Secure GCP Setup for Terradev Parallel Provisioning")
    logging.info("=" * 60)
    logging.info("📋 Your organization has good security practices!")
    logging.info("🔒 No service account keys needed - use user authentication")
    logging.info()
    
    # Step 1: Install gcloud CLI
    if not install_gcloud_cli():
        logging.info("❌ Failed to install gcloud CLI")
        return
    
    # Step 2: Setup authentication
    if not setup_gcloud_auth():
        logging.info("❌ Failed to setup authentication")
        return
    
    # Step 3: Enable Compute Engine API
    if not enable_compute_api():
        logging.info("❌ Failed to enable Compute Engine API")
        return
    
    # Step 4: Test connection
    if test_gcp_connection():
        logging.info("\n🎉 Secure GCP Setup Complete!")
        logging.info()
        logging.info("🚀 Next Steps:")
        logging.info("1. Test the parallel race:")
        logging.info("   python3 real_parallel_provisioning.py --race --gpu-type A100")
        logging.info("2. Run Terraform:")
        logging.info("   cd terraform && terraform apply")
        logging.info("3. Add RunPod and Lambda Labs API keys:")
        logging.info("   export RUNPOD_API_KEY='your-key'")
        logging.info("   export LAMBDA_API_KEY='your-key'")
    else:
        logging.info("❌ Setup failed. Please check the errors above.")

if __name__ == "__main__":
    main()
