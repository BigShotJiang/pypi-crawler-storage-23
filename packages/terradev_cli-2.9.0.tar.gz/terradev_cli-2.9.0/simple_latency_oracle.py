import logging

#!/usr/bin/env python3
"""
Simple Latency Oracle - Basic Ping Measurements
Minimal, lightweight latency testing for arbitrage decisions
"""

import asyncio
import subprocess
import json
import time
from datetime import datetime
from typing import Dict, List, Optional
import statistics

class SimpleLatencyOracle:
    """
    Simple latency measurement using ping
    Lightweight alternative to WebPageTest
    """
    
    def __init__(self):
        self.latency_cache = {}
    
    async def ping_latency(self, target: str, count: int = 3) -> Dict:
        """
        Measure latency to target using ping
        Returns basic latency metrics
        """
        
        try:
            # Run ping command
            cmd = ['ping', '-c', str(count), target]
            result = # TODO: PERFORMANCE - Consider async/await for subprocess call
# # TODO: Convert to async subprocess
# await asyncio.subprocess.run(...)
            
            if result.returncode != 0:
                return {"error": "Ping failed", "success": False}
            
            # Parse ping output
            lines = result.stdout.split('\n')
            latencies = []
            
            for line in lines:
                if "time=" in line:
                    # Extract time from ping output
                    time_part = line.split("time=")[1].split()[0]
                    latency = float(time_part)
                    latencies.append(latency)
            
            if not latencies:
                return {"error": "No latency data", "success": False}
            
            # Calculate metrics
            avg_latency = statistics.mean(latencies)
            min_latency = min(latencies)
            max_latency = max(latencies)
            
            # Calculate jitter (variation)
            jitter = statistics.stdev(latencies) if len(latencies) > 1 else 0
            
            # Score latency (lower is better)
            latency_score = self._score_latency(avg_latency)
            
            return {
                "success": True,
                "target": target,
                "avg_latency_ms": avg_latency,
                "min_latency_ms": min_latency,
                "max_latency_ms": max_latency,
                "jitter_ms": jitter,
                "latency_score": latency_score,
                "packet_count": count,
                "timestamp": datetime.now().isoformat()
            }
            
        except subprocess.TimeoutExpired:
            return {"error": "Ping timeout", "success": False}
        except Exception as e:
            return {"error": str(e), "success": False}
    
    def _score_latency(self, avg_latency: float) -> float:
        """Score latency (lower is better, 0-100 scale)"""
        
        # Latency scoring thresholds
        thresholds = {
            10: 100,    # Excellent
            25: 90,     # Good
            50: 80,     # Fair
            100: 70,    # Poor
            200: 50,    # Bad
            500: 30,    # Very Bad
            1000: 10    # Terrible
        }
        
        for threshold, score in sorted(thresholds.items()):
            if avg_latency <= threshold:
                return score
        
        return 0  # Worse than 1 second
    
    async def measure_provider_latency(self, 
                                     provider: str,
                                     region: str,
                                     target: str) -> Dict:
        """Measure latency from provider region to target"""
        
        cache_key = (provider, region, target)
        
        # Check cache (5 minutes)
        if cache_key in self.latency_cache:
            cached_data = self.latency_cache[cache_key]
            cache_time = datetime.fromisoformat(cached_data["timestamp"])
            if (datetime.now() - cache_time).total_seconds() < 300:
                logging.info(f"📋 Using cached latency for {provider}/{region}")
                return cached_data
        
        logging.info(f"🔍 Measuring latency from {provider}/{region} to {target}")
        
        # For now, simulate provider-specific latency
        # In real deployment, this would run from the actual provider region
        latency_result = await self.ping_latency(target)
        
        if latency_result["success"]:
            # Add provider info
            latency_result["provider"] = provider
            latency_result["region"] = region
            
            # Cache the result
            self.latency_cache[cache_key] = latency_result
            
            return latency_result
        else:
            return {"error": latency_result["error"], "success": False}

# Test the simple latency oracle
async def test_simple_latency():
    """Test simple latency oracle"""
    
    oracle = SimpleLatencyOracle()
    
    logging.info("🚀 Testing Simple Latency Oracle")
    logging.info("=" * 50)
    
    # Test basic ping
    logging.info("\n🔍 Testing basic ping to google.com...")
    result = await oracle.ping_latency("google.com")
    
    if result["success"]:
        logging.info(f"✅ Ping successful")
        logging.info(f"   Average Latency: {result['avg_latency_ms']:.2f}ms")
        logging.info(f"   Min/Max: {result['min_latency_ms']:.2f}ms / {result['max_latency_ms']:.2f}ms")
        logging.info(f"   Jitter: {result['jitter_ms']:.2f}ms")
        logging.info(f"   Score: {result['latency_score']}")
    else:
        logging.info(f"❌ Ping failed: {result['error']}")
    
    # Test provider latency simulation
    logging.info("\n🌍 Testing provider latency simulation...")
    
    providers = ['aws', 'gcp', 'azure', 'runpod']
    regions = ['us-east-1', 'us-west-2', 'eu-west-1']
    
    for provider in providers[:2]:  # Test first 2 providers
        for region in regions[:2]:  # Test first 2 regions
            result = await oracle.measure_provider_latency(
                provider, region, "google.com"
            )
            
            if result["success"]:
                logging.info(f"✅ {provider}/{region}: {result['avg_latency_ms']:.2f}ms")
            else:
                logging.info(f"❌ {provider}/{region}: {result['error']}")

if __name__ == "__main__":
    asyncio.run(test_simple_latency())
