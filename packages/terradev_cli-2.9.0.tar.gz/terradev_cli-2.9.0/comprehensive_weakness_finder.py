#!/usr/bin/env python3
"""
Terradev Comprehensive Weakness Finder
Deep dive analysis of ALL system weaknesses and vulnerabilities
"""

import os
import re
import json
import ast
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Any, Set, Tuple, Optional
from dataclasses import dataclass
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class Weakness:
    """System weakness classification"""
    category: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    component: str
    file_path: str
    line_number: int
    description: str
    code_snippet: str
    recommendation: str
    cwe_id: Optional[str] = None  # Common Weakness Enumeration
    cvss_score: Optional[float] = None

class TerradevWeaknessFinder:
    """Comprehensive weakness detection system"""
    
# TODO: REFACTOR - __init__() is 118 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        self.weaknesses: List[Weakness] = []
        
        # Security patterns
        self.security_patterns = {
            'hardcoded_secrets': [
                r'password\s*=\s*["\'][^"\']+["\']',
                r'api_key\s*=\s*["\'][^"\']+["\']',
                r'secret\s*=\s*["\'][^"\']+["\']',
                r'token\s*=\s*["\'][^"\']+["\']',
                r'credential\s*=\s*["\'][^"\']+["\']',
                r'private_key\s*=\s*["\'][^"\']+["\']',
                r'auth_token\s*=\s*["\'][^"\']+["\']',
                r'client_secret\s*=\s*["\'][^"\']+["\']',
                r'access_key\s*=\s*["\'][^"\']+["\']',
                r'secret_key\s*=\s*["\'][^"\']+["\']'
            ],
            'sql_injection': [
                r'execute\s*\(\s*["\'].*["\']\s*\)',
                r'cursor\.execute\s*\(\s*["\'].*["\']\s*\)',
                r'f["\']SELECT.*["\']',
                r'f["\']INSERT.*["\']',
                r'f["\']UPDATE.*["\']',
                r'f["\']DELETE.*["\']'
            ],
            'command_injection': [
                r'subprocess\.run\(',
                r'os\.system\(',
                r'os\.popen\(',
                r'eval\(',
                r'exec\(',
                r'__import__\(',
                r'open\s*\(\s*["\'][^"\']*["\']\s*,\s*["\']w["\']'
            ],
            'path_traversal': [
                r'open\s*\(\s*["\'][^"\']*["\'].*\+\s*',
                r'os\.path\.join.*\+\s*',
                r'\.\.\/',
                r'\.\.\\'
            ],
            'insecure_deserialization': [
                r'pickle\.load',
                r'pickle\.loads',
                r'cPickle\.load',
                r'marshal\.load',
                r'shelve\.open'
            ],
            'weak_crypto': [
                r'md5\(',
                r'sha1\(',
                r'hashlib\.md5',
                r'hashlib\.sha1',
                r'crypt\.crypt',
                r'base64\.decode.*decode'
            ]
        }
        
        # Code quality patterns
        self.quality_patterns = {
            'bare_except': [
                r'except:\s*$',
                r'except:\s*#'
            ],
            'print_statements': [
                r'print\s*\('
            ],
            'long_functions': [
                r'def\s+\w+.*:\s*(?:(?!def).)*\n((?:(?!def).)*\n){50,}'
            ],
            'deep_nesting': [
                r'(^\s{16,})'
            ],
            'duplicate_code': [],
            'magic_numbers': [
                r'\b(0|[1-9]\d*)\b'
            ],
            'unused_imports': [],
            'dead_code': [
                r'if\s+False\s*:',
                r'#.*TODO.*',
                r'#.*FIXME.*'
            ]
        }
        
        # Architecture patterns
        self.architecture_patterns = {
            'circular_imports': [],
            'tight_coupling': [],
            'god_classes': [],
            'long_parameter_lists': [
                r'def\s+\w+\([^)]{50,}'
            ],
            'feature_envy': [],
            'inappropriate_intimacy': []
        }
        
        # Performance patterns
        self.performance_patterns = {
            'inefficient_loops': [
                r'for\s+\w+\s+in\s+range\s*\(\s*len\s*\('
            ],
            'memory_leaks': [
                r'global\s+',
                r'del\s+\w+\s*$'
            ],
            'blocking_io': [
                r'requests\.(get|post|put|delete)\(',
                r'urllib\.request\.urlopen',
                r'socket\.socket'
            ],
            'database_nplus1': [
                r'for\s+\w+\s+in.*:\s*\n.*\.get\(',
                r'for\s+\w+\s+in.*:\s*\n.*\.filter\('
            ],
            'large_objects': [
                r'list\s*\(\s*.*\s*\*\s*\d{3,}'
            ]
        }
    
    def find_all_weaknesses(self) -> Dict[str, Any]:
        """Find all weaknesses in the codebase"""
        logger.info("🔍 STARTING COMPREHENSIVE WEAKNESS ANALYSIS")
        logger.info("=" * 80)
        
        # Find all Python files
        python_files = list(self.project_root.rglob("*.py"))
        config_files = list(self.project_root.rglob("*.tf"))
        config_files.extend(list(self.project_root.rglob("*.yaml")))
        config_files.extend(list(self.project_root.rglob("*.yml")))
        config_files.extend(list(self.project_root.rglob("*.json")))
        
        logger.info(f"📁 Analyzing {len(python_files)} Python files and {len(config_files)} config files")
        
        # Analyze Python files
        for file_path in python_files:
            self._analyze_python_file(file_path)
        
        # Analyze configuration files
        for file_path in config_files:
            self._analyze_config_file(file_path)
        
        # Analyze imports and dependencies
        self._analyze_imports()
        
        # Analyze architecture
        self._analyze_architecture()
        
        # Analyze performance
        self._analyze_performance()
        
        # Analyze deployment readiness
        self._analyze_deployment_readiness()
        
        # Categorize and prioritize
        return self._generate_weakness_report()
    
    def _analyze_python_file(self, file_path: Path) -> None:
        """Analyze a Python file for weaknesses"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')
            
            # Security analysis
            self._check_security_weaknesses(file_path, lines)
            
            # Code quality analysis
            self._check_quality_weaknesses(file_path, lines)
            
            # Architecture analysis
            self._check_architecture_weaknesses(file_path, content, lines)
            
            # Performance analysis
            self._check_performance_weaknesses(file_path, lines)
            
        except Exception as e:
            self.weaknesses.append(Weakness(
                category="File Analysis",
                severity="MEDIUM",
                component="File System",
                file_path=str(file_path),
                line_number=0,
                description=f"Could not analyze file: {str(e)}",
                code_snippet="",
                recommendation="Fix file encoding or corruption issues"
            ))
    
    def _check_security_weaknesses(self, file_path: Path, lines: List[str]) -> None:
        """Check for security weaknesses"""
        content = '\n'.join(lines)
        
        for category, patterns in self.security_patterns.items():
            for pattern in patterns:
                matches = re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE)
                
                for match in matches:
                    line_num = content[:match.start()].count('\n') + 1
                    line_content = lines[line_num - 1] if line_num <= len(lines) else ""
                    
                    # Determine severity
                    severity = self._get_security_severity(category, pattern)
                    
                    # Get CWE ID
                    cwe_id = self._get_cwe_id(category)
                    
                    # Get CVSS score
                    cvss_score = self._get_cvss_score(category)
                    
                    self.weaknesses.append(Weakness(
                        category="Security",
                        severity=severity,
                        component=category.replace('_', ' ').title(),
                        file_path=str(file_path),
                        line_number=line_num,
                        description=f"Security weakness detected: {category}",
                        code_snippet=line_content.strip(),
                        recommendation=self._get_security_recommendation(category),
                        cwe_id=cwe_id,
                        cvss_score=cvss_score
# TODO: REFACTOR - _check_quality_weaknesses() is 51 lines long (should be <50)
# Consider breaking into smaller, focused functions
                    ))
    
    def _check_quality_weaknesses(self, file_path: Path, lines: List[str]) -> None:
        """Check for code quality weaknesses"""
        content = '\n'.join(lines)
        
        # Check for bare except clauses
        for i, line in enumerate(lines, 1):
            if re.search(r'except:\s*$', line.strip()):
                self.weaknesses.append(Weakness(
                    category="Code Quality",
                    severity="MEDIUM",
                    component="Exception Handling",
                    file_path=str(file_path),
                    line_number=i,
                    description="Bare except clause detected",
                    code_snippet=line.strip(),
                    recommendation="Specify exception types for better error handling"
                ))
        
        # Check for excessive print statements
        print_count = len(re.findall(r'print\s*\(', content))
        if print_count > 10:
            self.weaknesses.append(Weakness(
                category="Code Quality",
                severity="LOW",
                component="Logging",
                file_path=str(file_path),
                line_number=0,
                description=f"Excessive print statements: {print_count}",
                code_snippet="",
                recommendation="Use proper logging framework instead of print statements"
            ))
        
        # Check for long functions
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if hasattr(node, 'end_lineno') and node.end_lineno:
                        func_length = node.end_lineno - node.lineno
                        if func_length > 50:
                            self.weaknesses.append(Weakness(
                                category="Code Quality",
                                severity="MEDIUM",
                                component="Function Design",
                                file_path=str(file_path),
                                line_number=node.lineno,
                                description=f"Long function: {node.name} ({func_length} lines)",
                                code_snippet=f"def {node.name}(...)",
                                recommendation="Break down long functions into smaller, focused functions"
                            ))
        except Exception as e:
            pass  # Skip if AST parsing fails
    
    def _check_architecture_weaknesses(self, file_path: Path, content: str, lines: List[str]) -> None:
        """Check for architectural weaknesses"""
        # Check for circular imports
        imports = re.findall(r'^(from\s+\S+|import\s+\S+)', content, re.MULTILINE)
        
        # Check for god classes (too many methods)
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    method_count = sum(1 for n in node.body if isinstance(n, ast.FunctionDef))
                    if method_count > 20:
                        self.weaknesses.append(Weakness(
                            category="Architecture",
                            severity="HIGH",
                            component="Class Design",
                            file_path=str(file_path),
                            line_number=node.lineno,
                            description=f"God class detected: {node.name} ({method_count} methods)",
                            code_snippet=f"class {node.name}",
                            recommendation="Break down large classes into smaller, focused classes"
                        ))
        except Exception as e:
            pass
        
        # Check for long parameter lists
        for i, line in enumerate(lines, 1):
            if len(re.findall(r',', line)) > 10 and 'def ' in line:
                self.weaknesses.append(Weakness(
                    category="Architecture",
                    severity="MEDIUM",
                    component="Function Design",
                    file_path=str(file_path),
                    line_number=i,
                    description="Function with too many parameters",
# TODO: REFACTOR - _check_performance_weaknesses() is 51 lines long (should be <50)
# Consider breaking into smaller, focused functions
                    code_snippet=line.strip(),
                    recommendation="Use parameter objects or configuration dictionaries"
                ))
    
    def _check_performance_weaknesses(self, file_path: Path, lines: List[str]) -> None:
        """Check for performance weaknesses"""
        content = '\n'.join(lines)
        
        # Check for blocking I/O
        blocking_patterns = [
            r'requests\.(get|post|put|delete)\(',
            r'urllib\.request\.urlopen',
            r'time\.sleep\(',
            r'subprocess\.run\('
        ]
        
        for pattern in blocking_patterns:
            matches = re.finditer(pattern, content)
            for match in matches:
                line_num = content[:match.start()].count('\n') + 1
                line_content = lines[line_num - 1] if line_num <= len(lines) else ""
                
                self.weaknesses.append(Weakness(
                    category="Performance",
                    severity="MEDIUM",
                    component="I/O Operations",
                    file_path=str(file_path),
                    line_number=line_num,
                    description="Blocking I/O operation detected",
                    code_snippet=line_content.strip(),
                    recommendation="Use async/await patterns for I/O operations"
                ))
        
        # Check for inefficient loops
        inefficient_patterns = [
            r'for\s+\w+\s+in\s+range\s*\(\s*len\s*\(',
            r'for\s+\w+\s+in\s+.*\.keys\(\)',
            r'while\s+True\s*:\s*\n.*break'
        ]
        
        for pattern in inefficient_patterns:
            matches = re.finditer(pattern, content)
            for match in matches:
                line_num = content[:match.start()].count('\n') + 1
                line_content = lines[line_num - 1] if line_num <= len(lines) else ""
                
                self.weaknesses.append(Weakness(
                    category="Performance",
                    severity="LOW",
                    component="Loop Efficiency",
                    file_path=str(file_path),
# TODO: REFACTOR - _analyze_config_file() is 97 lines long (should be <50)
# Consider breaking into smaller, focused functions
                    line_number=line_num,
                    description="Inefficient loop pattern detected",
                    code_snippet=line_content.strip(),
                    recommendation="Use more efficient iteration patterns"
                ))
    
    def _analyze_config_file(self, file_path: Path) -> None:
        """Analyze configuration files for weaknesses"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')
            
            # Check for hardcoded secrets in config files
            secret_patterns = [
                r'password\s*=\s*["\'][^"\']+["\']',
                r'api_key\s*=\s*["\'][^"\']+["\']',
                r'secret\s*=\s*["\'][^"\']+["\']',
                r'token\s*=\s*["\'][^"\']+["\']'
            ]
            
            for pattern in secret_patterns:
                matches = re.finditer(pattern, content, re.IGNORECASE)
                for match in matches:
                    line_num = content[:match.start()].count('\n') + 1
                    line_content = lines[line_num - 1] if line_num <= len(lines) else ""
                    
                    self.weaknesses.append(Weakness(
                        category="Security",
                        severity="CRITICAL",
                        component="Configuration Security",
                        file_path=str(file_path),
                        line_number=line_num,
                        description="Hardcoded secret in configuration file",
                        code_snippet=line_content.strip(),
                        recommendation="Use environment variables or secret management systems"
                    ))
            
            # Check for insecure configurations
            if file_path.suffix in ['.yaml', '.yml']:
                # Check for insecure Kubernetes configs
                if 'serviceAccountName: default' in content:
                    self.weaknesses.append(Weakness(
                        category="Security",
                        severity="HIGH",
                        component="Kubernetes Security",
                        file_path=str(file_path),
                        line_number=content.find('serviceAccountName: default') // len('\n') + 1,
                        description="Using default service account",
                        code_snippet="serviceAccountName: default",
                        recommendation="Create dedicated service accounts with minimal permissions"
                    ))
                
                # Check for privileged containers
                if 'privileged: true' in content:
                    self.weaknesses.append(Weakness(
                        category="Security",
                        severity="CRITICAL",
                        component="Container Security",
                        file_path=str(file_path),
                        line_number=content.find('privileged: true') // len('\n') + 1,
                        description="Privileged container detected",
                        code_snippet="privileged: true",
                        recommendation="Avoid privileged containers unless absolutely necessary"
                    ))
            
            elif file_path.suffix == '.tf':
                # Check for Terraform security issues
                if 'count = 0' in content and 'resource "aws_security_group"' in content:
                    self.weaknesses.append(Weakness(
                        category="Security",
                        severity="HIGH",
                        component="Infrastructure Security",
                        file_path=str(file_path),
                        line_number=0,
                        description="Security group with 0 rules may be overly restrictive",
                        code_snippet="",
                        recommendation="Review security group rules for proper access control"
                    ))
                
                # Check for unencrypted storage
                if 'storage_encrypted = false' in content.lower():
                    self.weaknesses.append(Weakness(
                        category="Security",
                        severity="HIGH",
                        component="Infrastructure Security",
                        file_path=str(file_path),
                        line_number=content.lower().find('storage_encrypted = false') // len('\n') + 1,
                        description="Unencrypted storage detected",
                        code_snippet="storage_encrypted = false",
                        recommendation="Enable encryption for all storage resources"
                    ))
        
        except Exception as e:
            self.weaknesses.append(Weakness(
                category="Configuration",
                severity="MEDIUM",
                component="File Analysis",
                file_path=str(file_path),
                line_number=0,
                description=f"Could not analyze config file: {str(e)}",
                code_snippet="",
                recommendation="Fix file format or encoding issues"
            ))
    
    def _analyze_imports(self) -> None:
        """Analyze import dependencies for issues"""
        python_files = list(self.project_root.rglob("*.py"))
        
        # Build import graph
        import_graph = {}
        
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Find imports
                imports = re.findall(r'^(?:from\s+(\S+)\s+)?import\s+(\S+)', content, re.MULTILINE)
                
                for module, name in imports:
                    if module:
                        full_import = f"{module}.{name}"
                    else:
                        full_import = name
                    
                    if str(file_path) not in import_graph:
                        import_graph[str(file_path)] = []
                    import_graph[str(file_path)].append(full_import)
            
            except Exception as e:
                continue
        
        # Check for circular imports
        for file_path, imports in import_graph.items():
            for imported_module in imports:
                # Try to find the actual file for this import
                for other_file, other_imports in import_graph.items():
                    if other_file != file_path:
                        # Check if other file imports current file
                        file_name = Path(file_path).stem
                        if any(file_name in imp for imp in other_imports):
                            # Check if current file imports other file
                            other_file_name = Path(other_file).stem
                            if any(other_file_name in imp for imp in imports):
                                self.weaknesses.append(Weakness(
                                    category="Architecture",
                                    severity="HIGH",
                                    component="Import Dependencies",
                                    file_path=file_path,
                                    line_number=0,
                                    description=f"Circular import detected: {file_path} <-> {other_file}",
                                    code_snippet="",
                                    recommendation="Refactor to eliminate circular dependencies"
                                ))
    
    def _analyze_architecture(self) -> None:
        """Analyze architectural issues"""
        python_files = list(self.project_root.rglob("*.py"))
        
        # Check for duplicate code
        code_blocks = {}
        
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Look for similar code blocks (simplified)
                lines = content.split('\n')
                for i in range(len(lines) - 5):
                    block = '\n'.join(lines[i:i+5])
                    if len(block) > 50:  # Only check substantial blocks
                        if block not in code_blocks:
                            code_blocks[block] = []
                        code_blocks[block].append((file_path, i+1))
            
            except Exception as e:
                continue
        
        # Report duplicate code
        for block, locations in code_blocks.items():
            if len(locations) > 1:
                self.weaknesses.append(Weakness(
                    category="Code Quality",
                    severity="MEDIUM",
                    component="Code Duplication",
                    file_path=str(locations[0][0]),
                    line_number=locations[0][1],
                    description=f"Duplicate code found in {len(locations)} locations",
                    code_snippet=block[:100] + "..." if len(block) > 100 else block,
                    recommendation="Extract common code into shared functions or classes"
                ))
    
    def _analyze_performance(self) -> None:
        """Analyze performance issues"""
        python_files = list(self.project_root.rglob("*.py"))
        
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Check for memory-intensive patterns
                if 'list(' in content and '*' in content:
                    # Look for large list comprehensions or multiplications
                    large_list_pattern = r'list\s*\(\s*\w+\s*\*\s*\d{3,}'
                    matches = re.findall(large_list_pattern, content)
                    
                    for match in matches:
                        self.weaknesses.append(Weakness(
                            category="Performance",
                            severity="MEDIUM",
                            component="Memory Usage",
                            file_path=str(file_path),
                            line_number=content.find(match) // len('\n') + 1,
                            description="Large list creation detected",
                            code_snippet=match,
                            recommendation="Use generators or lazy evaluation for large sequences"
                        ))
                
                # Check for database N+1 queries
                n_plus1_pattern = r'for\s+\w+\s+in.*:\s*\n.*\.get\('
                matches = re.findall(n_plus1_pattern, content, re.MULTILINE | re.DOTALL)
                
                for match in matches:
                    self.weaknesses.append(Weakness(
                        category="Performance",
                        severity="HIGH",
                        component="Database Performance",
                        file_path=str(file_path),
                        line_number=content.find(match) // len('\n') + 1,
                        description="Potential N+1 query pattern detected",
                        code_snippet=match[:100] + "..." if len(match) > 100 else match,
                        recommendation="Use eager loading or batch queries to avoid N+1 problems"
                    ))
            
            except Exception as e:
                continue
    
    def _analyze_deployment_readiness(self) -> None:
        """Analyze deployment readiness issues"""
        # Check for required files
        required_files = [
            'requirements.txt',
            'Dockerfile',
            'docker-compose.yml',
            '.env.template',
            '.gitignore'
        ]
        
        for required_file in required_files:
            file_path = self.project_root / required_file
            if not file_path.exists():
                self.weaknesses.append(Weakness(
                    category="Deployment",
                    severity="HIGH",
                    component="Configuration",
                    file_path=str(file_path),
                    line_number=0,
                    description=f"Required file missing: {required_file}",
                    code_snippet="",
                    recommendation=f"Create {required_file} for proper deployment"
                ))
        
        # Check for environment variable usage
        python_files = list(self.project_root.rglob("*.py"))
        env_usage = 0
        
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                env_usage += len(re.findall(r'os\.environ\.get', content))
            
            except Exception as e:
                continue
        
        if env_usage < 5:
            self.weaknesses.append(Weakness(
                category="Deployment",
                severity="MEDIUM",
                component="Configuration Management",
                file_path=str(self.project_root),
                line_number=0,
                description=f"Insufficient environment variable usage: {env_usage} occurrences",
                code_snippet="",
                recommendation="Use environment variables for configuration management"
            ))
    
    def _get_security_severity(self, category: str, pattern: str) -> str:
        """Get severity level for security weakness"""
        critical_patterns = ['password', 'api_key', 'secret', 'token']
        high_patterns = ['sql_injection', 'command_injection', 'path_traversal']
        
        if any(critical in pattern for critical in critical_patterns):
            return "CRITICAL"
        elif any(high in category for high in high_patterns):
            return "HIGH"
        elif category in ['insecure_deserialization', 'weak_crypto']:
            return "HIGH"
        else:
            return "MEDIUM"
    
    def _get_cwe_id(self, category: str) -> Optional[str]:
        """Get CWE ID for weakness category"""
        cwe_mapping = {
            'hardcoded_secrets': 'CWE-798',
            'sql_injection': 'CWE-89',
            'command_injection': 'CWE-78',
            'path_traversal': 'CWE-22',
            'insecure_deserialization': 'CWE-502',
            'weak_crypto': 'CWE-327'
        }
        return cwe_mapping.get(category)
    
    def _get_cvss_score(self, category: str) -> Optional[float]:
        """Get CVSS score for weakness category"""
        cvss_mapping = {
            'hardcoded_secrets': 7.5,
            'sql_injection': 9.0,
            'command_injection': 9.8,
            'path_traversal': 5.5,
            'insecure_deserialization': 8.8,
            'weak_crypto': 5.3
        }
        return cvss_mapping.get(category)
    
    def _get_security_recommendation(self, category: str) -> str:
        """Get security recommendation for category"""
        recommendations = {
            'hardcoded_secrets': 'Use environment variables or secret management systems',
# TODO: REFACTOR - _generate_weakness_report() is 64 lines long (should be <50)
# Consider breaking into smaller, focused functions
            'sql_injection': 'Use parameterized queries or ORM',
            'command_injection': 'Use subprocess with proper argument lists',
            'path_traversal': 'Validate and sanitize file paths',
            'insecure_deserialization': 'Use safe serialization formats',
            'weak_crypto': 'Use strong cryptographic algorithms'
        }
        return recommendations.get(category, 'Review and fix security issue')
    
    def _generate_weakness_report(self) -> Dict[str, Any]:
        """Generate comprehensive weakness report"""
        # Categorize weaknesses
        categories = {}
        for weakness in self.weaknesses:
            if weakness.category not in categories:
                categories[weakness.category] = []
            categories[weakness.category].append(weakness)
        
        # Severity breakdown
        severity_counts = {
            'CRITICAL': len([w for w in self.weaknesses if w.severity == 'CRITICAL']),
            'HIGH': len([w for w in self.weaknesses if w.severity == 'HIGH']),
            'MEDIUM': len([w for w in self.weaknesses if w.severity == 'MEDIUM']),
            'LOW': len([w for w in self.weaknesses if w.severity == 'LOW'])
        }
        
        # Component breakdown
        component_counts = {}
        for weakness in self.weaknesses:
            if weakness.component not in component_counts:
                component_counts[weakness.component] = 0
            component_counts[weakness.component] += 1
        
        # Calculate risk score
        risk_score = (
            severity_counts['CRITICAL'] * 10 +
            severity_counts['HIGH'] * 5 +
            severity_counts['MEDIUM'] * 2 +
            severity_counts['LOW'] * 1
        )
        
        # Generate detailed results
        detailed_results = []
        for weakness in self.weaknesses:
            detailed_results.append({
                'category': weakness.category,
                'severity': weakness.severity,
                'component': weakness.component,
                'file_path': weakness.file_path,
                'line_number': weakness.line_number,
                'description': weakness.description,
                'code_snippet': weakness.code_snippet,
                'recommendation': weakness.recommendation,
                'cwe_id': weakness.cwe_id,
                'cvss_score': weakness.cvss_score
            })
        
        # Sort by severity and CVSS score
        detailed_results.sort(key=lambda x: (
            {'CRITICAL': 4, 'HIGH': 3, 'MEDIUM': 2, 'LOW': 1}[x['severity']],
            x.get('cvss_score', 0) or 0
        ), reverse=True)
        
        return {
            'summary': {
                'total_weaknesses': len(self.weaknesses),
                'risk_score': risk_score,
                'severity_breakdown': severity_counts,
                'category_breakdown': {k: len(v) for k, v in categories.items()},
                'component_breakdown': component_counts
            },
            'detailed_results': detailed_results,
            'categories': categories
        }

def main():
    """Main weakness finder function"""
    project_root = "/Users/theowolfenden/CascadeProjects/Terradev"
    
    finder = TerradevWeaknessFinder(project_root)
    results = finder.find_all_weaknesses()
    
    # Save results
    with open('terradev_comprehensive_weakness_report.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    # Print summary
    logging.info("🔍 COMPREHENSIVE WEAKNESS ANALYSIS COMPLETE")
    logging.info("=" * 80)
    logging.info(f"📊 Total Weaknesses Found: {results['summary']['total_weaknesses']}")
    logging.info(f"🎯 Risk Score: {results['summary']['risk_score']}")
    
    logging.info(f"\n🚨 Severity Breakdown:")
    for severity, count in results['summary']['severity_breakdown'].items():
        emoji = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢"}[severity]
        logging.info(f"   {emoji} {severity}: {count}")
    
    logging.info(f"\n📁 Category Breakdown:")
    for category, count in results['summary']['category_breakdown'].items():
        logging.info(f"   📂 {category}: {count}")
    
    logging.info(f"\n🔧 Top 10 Critical Issues:")
    for i, weakness in enumerate(results['detailed_results'][:10], 1):
        logging.info(f"   {i}. {weakness['severity']} - {weakness['component']}")
        logging.info(f"      📁 {weakness['file_path']}:{weakness['line_number']}")
        logging.info(f"      📝 {weakness['description']}")
        logging.info(f"      💡 {weakness['recommendation']}")
        logging.info()
    
    return results

if __name__ == "__main__":
    main()
