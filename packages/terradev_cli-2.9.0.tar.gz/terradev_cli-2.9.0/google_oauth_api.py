import os

#!/usr/bin/env python3
"""
Google OAuth Integration for GCP API Access
Uses OAuth 2.0 for GCP Compute Engine API integration
"""

import asyncio
import aiohttp
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional
import base64
import urllib.parse

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GoogleOAuthAPI:
    """Google OAuth 2.0 integration for GCP API access"""
    
    def __init__(self, client_id: str):
        self.client_id = client_id
        self.base_url = "https://www.googleapis.com"
        self.auth_url = "https://accounts.google.com/o/oauth2/v2/auth"
        self.token_url = os.environ.get("TOKEN_TOKEN_URL", "https://oauth2.googleapis.com/token")
        self.access_token = None
        self.refresh_token = None
        
    def get_auth_url(self, redirect_uri: str = "http://localhost:8080/callback") -> str:
        """Generate OAuth authorization URL"""
        
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "https://www.googleapis.com/auth/cloud-platform",
            "access_type": "offline",
            "prompt": "consent"
        }
        
        auth_url = f"{self.auth_url}?" + urllib.parse.urlencode(params)
        
        logging.info(f"🔗 Please visit this URL to authorize the application:")
        logging.info(f"   {auth_url}")
        
        return auth_url
    
    async def exchange_code_for_token(self, code: str, redirect_uri: str = "http://localhost:8080/callback") -> Dict:
        """Exchange authorization code for access token"""
        
        data = {
            "client_id": self.client_id,
            "client_secret": "",  # For public clients, this is empty
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": redirect_uri
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(self.token_url, data=data) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        
                        self.access_token = token_data.get("access_token")
                        self.refresh_token = token_data.get("refresh_token")
                        
                        logger.info("✅ Successfully obtained access token")
                        return token_data
                    else:
                        logger.error(f"Token exchange failed: {response.status}")
                        error_text = await response.text()
                        logger.error(f"Error details: {error_text}")
                        return {}
        except Exception as e:
            logger.error(f"Token exchange error: {e}")
            return {}
    
    async def refresh_access_token(self) -> Dict:
        """Refresh access token using refresh token"""
        
        if not self.refresh_token:
            logger.error("No refresh token available")
            return {}
        
        data = {
            "client_id": self.client_id,
            "refresh_token": self.refresh_token,
            "grant_type": "refresh_token"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(self.token_url, data=data) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        
                        self.access_token = token_data.get("access_token")
                        
                        logger.info("✅ Successfully refreshed access token")
                        return token_data
                    else:
                        logger.error(f"Token refresh failed: {response.status}")
                        return {}
        except Exception as e:
            logger.error(f"Token refresh error: {e}")
            return {}
    
    async def get_gcp_instances(self, project_id: str, zone: str = "us-central1-a") -> List[Dict]:
        """Get GCP instances using OAuth token"""
        
        if not self.access_token:
            logger.error("No access token available")
            return []
        
        try:
            url = f"{self.base_url}/compute/v1/projects/{project_id}/zones/{zone}/instances"
            
            headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        instances = data.get("items", [])
                        logger.info(f"✅ Found {len(instances)} GCP instances")
                        return instances
                    else:
                        logger.error(f"GCP API error: {response.status}")
                        error_text = await response.text()
                        logger.error(f"Error details: {error_text}")
                        return []
        except Exception as e:
            logger.error(f"GCP API connection failed: {e}")
            return []
    
    async def get_gcp_machine_types(self, project_id: str, zone: str = "us-central1-a") -> List[Dict]:
        """Get GCP machine types (GPU instances)"""
        
        if not self.access_token:
            logger.error("No access token available")
            return []
        
        try:
            url = f"{self.base_url}/compute/v1/projects/{project_id}/zones/{zone}/machineTypes"
            
            headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        machine_types = data.get("items", [])
                        
                        # Filter for GPU instances
                        gpu_types = []
                        for mt in machine_types:
                            if "gpu" in mt.get("name", "").lower() or "accelerator" in mt.get("name", "").lower():
                                gpu_types.append(mt)
                        
                        logger.info(f"✅ Found {len(gpu_types)} GPU machine types")
                        return gpu_types
                    else:
                        logger.error(f"GCP machine types error: {response.status}")
                        return []
        except Exception as e:
            logger.error(f"GCP machine types API failed: {e}")
            return []
    
    async def get_gcp_pricing(self, project_id: str) -> Dict:
        """Get GCP pricing information (using Cloud Billing API)"""
        
        if not self.access_token:
            logger.error("No access token available")
            return {}
        
        try:
            # This is a simplified approach - in reality, pricing is complex
            url = f"{self.base_url}/cloudbilling/v1/services/6F81-5844-456A/skus"
            
            headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        skus = data.get("skus", [])
                        
                        # Filter for GPU pricing
                        gpu_pricing = {}
                        for sku in skus:
                            description = sku.get("description", "").lower()
                            if "gpu" in description and "compute" in sku.get("serviceDisplayName", "").lower():
                                pricing_info = sku.get("pricingInfo", [])
                                if pricing_info:
                                    price = pricing_info[0].get("pricingExpression", {}).get("tieredRates", [])
                                    if price:
                                        unit_price = price[0].get("unitPrice", {}).get("nanos", 0) / 1000000000
                                        gpu_pricing[sku.get("description", "unknown")] = unit_price
                        
                        logger.info(f"✅ Found pricing for {len(gpu_pricing)} GPU types")
                        return gpu_pricing
                    else:
                        logger.error(f"GCP pricing error: {response.status}")
                        return {}
        except Exception as e:
            logger.error(f"GCP pricing API failed: {e}")
            return {}

class MockGoogleOAuthAPI:
    """Mock Google OAuth API for testing without real OAuth flow"""
    
    def __init__(self, client_id: str):
        self.client_id = client_id
        self.access_token = os.environ.get("TOKEN_ACCESS_TOKEN", "mock_access_token_12345")
        self.refresh_token = os.environ.get("TOKEN_REFRESH_TOKEN", "mock_refresh_token_12345")
    
    async def get_gcp_instances(self, project_id: str, zone: str = "us-central1-a") -> List[Dict]:
        """Mock GCP instances"""
        
        mock_instances = [
            {
                "id": "1234567890123456789",
                "name": "gpu-instance-1",
                "machineType": f"zones/{zone}/machineTypes/n1-standard-4-k80-1",
                "status": "RUNNING",
                "zone": f"zones/{zone}",
                "creationTimestamp": datetime.now().isoformat(),
                "networkInterfaces": [
                    {
                        "network": "global/networks/default",
                        "internalIp": "10.128.0.2",
                        "externalIp": "34.123.45.67"
                    }
                ],
                "disks": [
                    {
                        "boot": True,
                        "initializeParams": {
                            "sourceImage": "projects/debian-cloud/global/images/family/debian-11"
                        },
                        "diskSizeGb": "20"
                    }
                ],
                "guestAccelerators": [
                    {
                        "acceleratorType": f"zones/{zone}/acceleratorTypes/nvidia-tesla-k80",
                        "acceleratorCount": 1
                    }
                ]
            },
            {
                "id": "1234567890123456790",
                "name": "gpu-instance-2",
                "machineType": f"zones/{zone}/machineTypes/n1-standard-8-v100-1",
                "status": "RUNNING",
                "zone": f"zones/{zone}",
                "creationTimestamp": datetime.now().isoformat(),
                "networkInterfaces": [
                    {
                        "network": "global/networks/default",
                        "internalIp": "10.128.0.3",
                        "externalIp": "34.123.45.68"
                    }
                ],
                "disks": [
                    {
                        "boot": True,
                        "initializeParams": {
                            "sourceImage": "projects/debian-cloud/global/images/family/debian-11"
                        },
                        "diskSizeGb": "50"
                    }
                ],
                "guestAccelerators": [
                    {
                        "acceleratorType": f"zones/{zone}/acceleratorTypes/nvidia-tesla-v100",
                        "acceleratorCount": 1
                    }
                ]
            }
        ]
        
        return mock_instances
    
    async def get_gcp_machine_types(self, project_id: str, zone: str = "us-central1-a") -> List[Dict]:
        """Mock GCP machine types"""
        
        mock_machine_types = [
            {
                "id": "1234567890123456789",
                "creationTimestamp": datetime.now().isoformat(),
                "name": "n1-standard-4-k80-1",
                "description": "1 NVIDIA Tesla K80, 4 vCPUs, 26 GB RAM",
                "guestCpus": 4,
                "memoryMb": 26624,
                "imageSpaceGb": 0,
                "diskSizeGb": 20,
                "maximumPersistentDisksSizeGb": 263168,
                "zone": f"zones/{zone}",
                "selfLink": f"https://www.googleapis.com/compute/v1/projects/{project_id}/zones/{zone}/machineTypes/n1-standard-4-k80-1",
                "isSharedCpu": False,
                "kind": "compute#machineType"
            },
            {
                "id": "1234567890123456790",
                "creationTimestamp": datetime.now().isoformat(),
                "name": "n1-standard-8-v100-1",
                "description": "1 NVIDIA Tesla V100, 8 vCPUs, 52 GB RAM",
                "guestCpus": 8,
                "memoryMb": 53248,
                "imageSpaceGb": 0,
                "diskSizeGb": 50,
                "maximumPersistentDisksSizeGb": 263168,
                "zone": f"zones/{zone}",
                "selfLink": f"https://www.googleapis.com/compute/v1/projects/{project_id}/zones/{zone}/machineTypes/n1-standard-8-v100-1",
                "isSharedCpu": False,
                "kind": "compute#machineType"
            },
            {
                "id": "1234567890123456791",
                "creationTimestamp": datetime.now().isoformat(),
                "name": "a2-highgpu-1g",
                "description": "1 NVIDIA A100 40GB, 12 vCPUs, 85 GB RAM",
                "guestCpus": 12,
                "memoryMb": 87040,
                "imageSpaceGb": 0,
                "diskSizeGb": 100,
                "maximumPersistentDisksSizeGb": 263168,
                "zone": f"zones/{zone}",
                "selfLink": f"https://www.googleapis.com/compute/v1/projects/{project_id}/zones/{zone}/machineTypes/a2-highgpu-1g",
                "isSharedCpu": False,
                "kind": "compute#machineType"
            }
        ]
        
        return mock_machine_types
    
    async def get_gcp_pricing(self, project_id: str) -> Dict:
        """Mock GCP pricing"""
        
        mock_pricing = {
            "NVIDIA Tesla K80 GPU": 0.45,
            "NVIDIA Tesla V100 GPU": 2.48,
            "NVIDIA A100 40GB GPU": 3.06,
            "NVIDIA A100 80GB GPU": 4.86,
            "NVIDIA T4 GPU": 0.35,
            "NVIDIA L4 GPU": 0.60
        }
        
        return mock_pricing

# Test Google OAuth integration
async def test_google_oauth():
    """Test Google OAuth integration"""
    
    client_id = "112009677560035284778"
    
    logging.info("🚀 Testing Google OAuth Integration")
    logging.info("=" * 50)
    
    # Use mock API for testing (since real OAuth requires user interaction)
    gcp = MockGoogleOAuthAPI(client_id)
    
    logging.info("📊 Using Mock Google OAuth API for testing")
    logging.info("   (Real OAuth would require browser interaction)
    
    # Test 1: Get GCP instances
    logging.info("\n🖥️ Getting GCP Instances...")
    instances = await gcp.get_gcp_instances("test-project-12345")
    logging.info(f"✅ Found {len(instances)
    
    for instance in instances:
        logging.info(f"   • {instance['name']}: {instance['status']}")
        logging.info(f"     Machine Type: {instance['machineType']}")
        logging.info(f"     Zone: {instance['zone']}")
        
        # Show GPU info
        accelerators = instance.get("guestAccelerators", [])
        if accelerators:
            for acc in accelerators:
                logging.info(f"     GPU: {acc['acceleratorType']} (x{acc['acceleratorCount']})
    
    # Test 2: Get GCP machine types
    logging.info("\n🔧 Getting GCP Machine Types...")
    machine_types = await gcp.get_gcp_machine_types("test-project-12345")
    logging.info(f"✅ Found {len(machine_types)
    
    for mt in machine_types:
        logging.info(f"   • {mt['name']}: {mt['guestCpus']} vCPUs, {mt['memoryMb']//1024}GB RAM")
        logging.info(f"     Description: {mt['description']}")
    
    # Test 3: Get GCP pricing
    logging.info("\n💰 Getting GCP Pricing...")
    pricing = await gcp.get_gcp_pricing("test-project-12345")
    logging.info(f"✅ Found pricing for {len(pricing)
    
    for gpu_type, price in pricing.items():
        logging.info(f"   • {gpu_type}: ${price:.2f}/hour")
    
    # Test 4: Show OAuth URL (for real implementation)
    logging.info("\n🔗 OAuth Authorization URL (for real implementation)
    real_oauth = GoogleOAuthAPI(client_id)
    auth_url = real_oauth.get_auth_url()
    logging.info(f"   {auth_url}")
    
    logging.info("\n📋 OAuth Flow Instructions:")
    logging.info("   1. Visit the URL above in a browser")
    logging.info("   2. Authorize the application")
    logging.info("   3. Copy the authorization code from the callback")
    logging.info("   4. Use exchange_code_for_token()
    logging.info("   5. Use access token for GCP API calls")

if __name__ == "__main__":
    asyncio.run(test_google_oauth())
