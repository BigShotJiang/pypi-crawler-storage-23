# Contributing to Terradev

Thank you for your interest in contributing to Terradev! This document provides guidelines and information for contributors.

## Getting Started

### Prerequisites
- Python 3.11+
- Docker
- Kubernetes
- Git

### Setup
1. Fork the repository
2. Clone your fork locally
3. Create a virtual environment
4. Install dependencies
5. Run the test suite

```bash
git clone https://github.com/your-username/terradev.git
cd terradev
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
pytest tests/
```

## Development Guidelines

### Code Style
- Follow PEP 8 style guidelines
- Use meaningful variable and function names
- Add docstrings to all functions and classes
- Keep functions focused and small (<50 lines)
- Use type hints where appropriate

### Security
- Never commit secrets or credentials
- Use environment variables for configuration
- Follow security best practices
- Review code for vulnerabilities

### Testing
- Write tests for all new features
- Maintain test coverage above 80%
- Use descriptive test names
- Test edge cases and error conditions

## Submitting Changes

### Branch Naming
- Use descriptive branch names
- Format: `feature/description` or `fix/description`
- Examples: `feature/user-authentication`, `fix/sql-injection`

### Commit Messages
- Use clear, descriptive commit messages
- Format: `type: description`
- Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`

### Pull Requests
- Create pull requests against the main branch
- Provide clear descriptions of changes
- Include tests for new functionality
- Ensure all tests pass
- Request code review from maintainers

## Code Review Process

### Review Criteria
- Code quality and style
- Security considerations
- Performance implications
- Test coverage
- Documentation

### Review Guidelines
- Be constructive and respectful
- Focus on the code, not the person
- Provide specific suggestions
- Ask questions for clarity

## Project Structure

```
terradev/
├── src/                 # Source code
├── tests/              # Test suite
├── docs/               # Documentation
├── infrastructure/     # Infrastructure code
├── scripts/            # Utility scripts
├── docker/             # Docker files
└── k8s/               # Kubernetes manifests
```

## Getting Help

- Create an issue for bugs or feature requests
- Join our Discord community
- Check the documentation
- Review existing issues and discussions

## License

By contributing to this project, you agree that your contributions will be licensed under the MIT License.
