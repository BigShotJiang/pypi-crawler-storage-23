import logging

#!/usr/bin/env python3
"""
Simplified Volatility Spread Analysis
Focus on volatility spreads using realized volatility
"""

import numpy as np
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

@dataclass
class VolatilitySpread:
    """Volatility spread analysis"""
    provider: str
    instance_type: str
    current_volatility: float
    forecast_volatility: float
    volatility_spread: float
    spread_percentage: float
    volatility_trend: str
    confidence_interval: Tuple[float, float]
    risk_level: str
    opportunity_score: float

class SimpleVolatilityAnalyzer:
    """Simple volatility analyzer for arbitrage decisions"""
    
    def __init__(self):
        self.volatility_data = {}
        
        # Volatility thresholds
        self.volatility_thresholds = {
            "low": 0.1,      # < 10% annualized volatility
            "medium": 0.3,   # 10-30% annualized volatility
            "high": 0.5,     # 30-50% annualized volatility
            "extreme": 1.0   # > 50% annualized volatility
        }
    
    def analyze_volatility_opportunities(self, gpu_type: str) -> Dict:
        """Analyze volatility arbitrage opportunities"""
        
        # Simulate volatility data for demonstration
        providers = ["aws", "runpod", "gcp"]
        instance_types = ["a100", "v100", "a10g"]
        
        spreads = []
        
        for provider in providers:
            for instance_type in instance_types:
                if gpu_type.lower() in instance_type.lower():
                    # Generate simulated volatility data
                    base_price = 2.0 + hash(f"{provider}-{instance_type}") % 3
                    
                    # Different volatility patterns for different providers
                    if provider == "aws":
                        volatility_factor = 0.05  # Lower volatility
                        trend_factor = 0.95  # Decreasing trend
                    elif provider == "runpod":
                        volatility_factor = 0.15  # Medium volatility
                        trend_factor = 1.05  # Slightly increasing
                    else:
                        volatility_factor = 0.25  # Higher volatility
                        trend_factor = 1.15  # Increasing trend
                    
                    # Generate simulated price series
                    prices = []
                    current_price = base_price
                    
                    for i in range(50):
                        price_change = np.random.normal(0, volatility_factor)
                        current_price *= (1 + price_change)
                        prices.append(current_price)
                    
                    # Calculate simple volatility metrics
                    returns = np.diff(np.log(prices))
                    historical_volatility = np.std(returns) * np.sqrt(365 * 24)
                    
                    # Simulate forecast
                    forecast_volatility = historical_volatility * trend_factor
                    
                    # Calculate spread
                    volatility_spread = forecast_volatility - historical_volatility
                    spread_percentage = (volatility_spread / historical_volatility) * 100 if historical_volatility > 0 else 0
                    
                    # Determine trend
                    if volatility_spread > historical_volatility * 0.1:
                        trend = "increasing"
                    elif volatility_spread < -historical_volatility * 0.1:
                        trend = "decreasing"
                    else:
                        trend = "stable"
                    
                    # Determine risk level
                    if forecast_volatility < self.volatility_thresholds["low"]:
                        risk_level = "low"
                    elif forecast_volatility < self.volatility_thresholds["medium"]:
                        risk_level = "medium"
                    elif forecast_volatility < self.volatility_thresholds["high"]:
                        risk_level = "high"
                    else:
                        risk_level = "extreme"
                    
                    # Calculate opportunity score
                    spread_score = max(0, 1 - abs(spread_percentage) / 100)
                    trend_score = 1.0 if trend == "stable" else 0.7
                    risk_scores = {"low": 1.0, "medium": 0.8, "high": 0.6, "extreme": 0.4}
                    risk_score = risk_scores.get(risk_level, 0.5)
                    
                    opportunity_score = (spread_score * 0.4 + trend_score * 0.3 + risk_score * 0.3)
                    
                    # Create volatility spread object
                    spread = VolatilitySpread(
                        provider=provider,
                        instance_type=instance_type,
                        current_volatility=historical_volatility,
                        forecast_volatility=forecast_volatility,
                        volatility_spread=volatility_spread,
                        spread_percentage=spread_percentage,
                        volatility_trend=trend,
                        confidence_interval=(forecast_volatility * 0.9, forecast_volatility * 1.1),
                        risk_level=risk_level,
                        opportunity_score=opportunity_score
                    )
                    
                    spreads.append(spread)
        
        # Sort by opportunity score (descending)
        spreads.sort(key=lambda x: x.opportunity_score, reverse=True)
        
        # Create opportunities
        opportunities = []
        for spread in spreads:
            opportunity = {
                "provider": spread.provider,
                "instance_type": spread.instance_type,
                "current_volatility": spread.current_volatility,
                "forecast_volatility": spread.forecast_volatility,
                "volatility_spread": spread.volatility_spread,
                "spread_percentage": spread.spread_percentage,
                "spread_classification": self._classify_spread(abs(spread.spread_percentage)),
                "volatility_trend": spread.volatility_trend,
                "risk_level": spread.risk_level,
                "confidence_interval": spread.confidence_interval,
                "opportunity_score": spread.opportunity_score
            }
            opportunities.append(opportunity)
        
        return {
            "gpu_type": gpu_type,
            "total_opportunities": len(opportunities),
            "opportunities": opportunities,
            "best_opportunity": opportunities[0] if opportunities else None,
            "volatility_summary": self._summarize_volatility(spreads)
        }
    
    def _classify_spread(self, spread_percentage: float) -> str:
        """Classify volatility spread"""
        
        if spread_percentage < 5:
            return "narrow"
        elif spread_percentage < 15:
            return "moderate"
        elif spread_percentage < 30:
            return "wide"
        else:
            return "extreme"
    
    def _summarize_volatility(self, spreads: List[VolatilitySpread]) -> Dict:
        """Summarize volatility analysis"""
        
        if not spreads:
            return {}
        
        current_volatilities = [s.current_volatility for s in spreads]
        forecast_volatilities = [s.forecast_volatility for s in spreads]
        volatility_spreads = [s.volatility_spread for s in spreads]
        spread_percentages = [float(s.spread_percentage) for s in spreads]
        
        return {
            "avg_current_volatility": np.mean(current_volatilities),
            "avg_forecast_volatility": np.mean(forecast_volatilities),
            "avg_volatility_spread": np.mean(volatility_spreads),
            "avg_spread_percentage": np.mean(spread_percentages),
            "volatility_range": {
                "min": min(current_volatilities),
                "max": max(current_volatilities),
                "std": np.std(current_volatilities)
            },
            "forecast_range": {
                "min": min(forecast_volatilities),
                "max": max(forecast_volatilities),
                "std": np.std(forecast_volatilities)
            },
            "spread_range": {
                "min": min(volatility_spreads),
                "max": max(volatility_spreads),
                "std": np.std(volatility_spreads)
            }
        }

# Test simple volatility analysis
def test_simple_volatility_analysis():
    """Test simple volatility analysis"""
    
    logging.info("🚀 Testing Simple Volatility Analysis")
    logging.info("=" * 50)
    
    analyzer = SimpleVolatilityAnalyzer()
    
    # Test A100 volatility analysis
    logging.info("\n📈 Analyzing A100 Volatility Spreads...")
    
    a100_analysis = analyzer.analyze_volatility_opportunities("a100")
    
    logging.info(f"✅ Found {a100_analysis['total_opportunities']} A100 opportunities")
    
    if a100_analysis["best_opportunity"]:
        best = a100_analysis["best_opportunity"]
        logging.info(f"\n🏆 Best A100 Opportunity:")
        logging.info(f"   Provider: {best['provider']}")
        logging.info(f"   Instance: {best['instance_type']}")
        logging.info(f"   Current Volatility: {best['current_volatility']:.2%}")
        logging.info(f"   Forecast Volatility: {best['forecast_volatility']:.2%}")
        logging.info(f"   Volatility Spread: {best['volatility_spread']:.2%}")
        logging.info(f"   Spread Percentage: {best['spread_percentage']:.2f}%")
        logging.info(f"   Spread Classification: {best['spread_classification']}")
        logging.info(f"   Trend: {best['volatility_trend']}")
        logging.info(f"   Risk Level: {best['risk_level']}")
        logging.info(f"   Opportunity Score: {best['opportunity_score']:.3f}")
    
    # Show top 3 opportunities
    logging.info(f"\n📊 Top 3 A100 Opportunities:")
    for i, opp in enumerate(a100_analysis["opportunities"][:3], 1):
        logging.info(f"\n{i}. {opp['provider']} - {opp['instance_type']}")
        logging.info(f"   Spread: {opp['volatility_spread']:.2%} ({opp['spread_percentage']:.1f}%)
        logging.info(f"   Classification: {opp['spread_classification']}")
        logging.info(f"   Trend: {opp['volatility_trend']}")
        logging.info(f"   Risk: {opp['risk_level']}")
        logging.info(f"   Score: {opp['opportunity_score']:.3f}")
    
    # Show volatility summary
    if "volatility_summary" in a100_analysis:
        summary = a100_analysis["volatility_summary"]
        logging.info(f"\n📋 A100 Volatility Summary:")
        logging.info(f"   Avg Current Volatility: {summary['avg_current_volatility']:.2%}")
        logging.info(f"   Avg Forecast Volatility: {summary['avg_forecast_volatility']:.2%}")
        logging.info(f"   Avg Volatility Spread: {summary['avg_volatility_spread']:.2%}")
        logging.info(f"   Avg Spread Percentage: {summary['avg_spread_percentage']:.2f}%")
        logging.info(f"   Current Volatility Range: {summary['volatility_range']['min']:.2%} - {summary['volatility_range']['max']:.2%}")
        logging.info(f"   Forecast Volatility Range: {summary['forecast_range']['min']:.2%} - {summary['forecast_range']['max']:.2%}")
    
    # Test V100 volatility analysis
    logging.info("\n📈 Analyzing V100 Volatility Spreads...")
    
    v100_analysis = analyzer.analyze_volatility_opportunities("v100")
    
    logging.info(f"✅ Found {v100_analysis['total_opportunities']} V100 opportunities")
    
    if v100_analysis["best_opportunity"]:
        best = v100_analysis["best_opportunity"]
        logging.info(f"\n🏆 Best V100 Opportunity:")
        logging.info(f"   Provider: {best['provider']}")
        logging.info(f"   Instance: {best['instance_type']}")
        logging.info(f"   Current Volatility: {best['current_volatility']:.2%}")
        logging.info(f"   Forecast Volatility: {best['forecast_volatility']:.2%}")
        logging.info(f"   Volatility Spread: {best['volatility_spread']:.2%}")
        logging.info(f"   Spread Percentage: {best['spread_percentage']:.2f}%")
        logging.info(f"   Spread Classification: {best['spread_classification']}")
        logging.info(f"   Trend: {best['volatility_trend']}")
        logging.info(f"   Risk Level: {best['risk_level']}")
        logging.info(f"   Opportunity Score: {best['opportunity_score']:.3f}")
    
    # Show top 3 opportunities
    logging.info(f"\n📊 Top 3 V100 Opportunities:")
    for i, opp in enumerate(v100_analysis["opportunities"][:3], 1):
        logging.info(f"\n{i}. {opp['provider']} - {opp['instance_type']}")
        logging.info(f"   Spread: {opp['volatility_spread']:.2%} ({opp['spread_percentage']:.1f}%)
        logging.info(f"   Classification: {opp['spread_classification']}")
        logging.info(f"   Trend: {opp['volatility_trend']}")
        logging.info(f"   Risk: {opp['risk_level']}")
        logging.info(f"   Score: {opp['opportunity_score']:.3f}")
    
    # Show volatility summary
    if "volatility_summary" in v100_analysis:
        summary = v100_analysis["volatility_summary"]
        logging.info(f"\n📋 V100 Volatility Summary:")
        logging.info(f"   Avg Current Volatility: {summary['avg_current_volatility']:.2%}")
        logging.info(f"   Avg Forecast Volatility: {summary['avg_forecast_volatility']:.2%}")
        logging.info(f"   Avg Volatility Spread: {summary['avg_volatility_spread']:.2%}")
        logging.info(f"   Avg Spread Percentage: {summary['avg_spread_percentage']:.2f}%")
        logging.info(f"   Current Volatility Range: {summary['volatility_range']['min']:.2%} - {summary['volatility_range']['max']:.2%}")
        logging.info(f"   Forecast Volatility Range: {summary['forecast_range']['min']:.2%} - {summary['forecast_range']['max']:.2%}")
    
    # Test A10G volatility analysis
    logging.info("\n📈 Analyzing A10G Volatility Spreads...")
    
    a10g_analysis = analyzer.analyze_volatility_opportunities("a10g")
    
    logging.info(f"✅ Found {a10g_analysis['total_opportunities']} A10G opportunities")
    
    if a10g_analysis["best_opportunity"]:
        best = a10g_analysis["best_opportunity"]
        logging.info(f"\n🏆 Best A10G Opportunity:")
        logging.info(f"   Provider: {best['provider']}")
        logging.info(f"   Instance: {best['instance_type']}")
        logging.info(f"   Current Volatility: {best['current_volatility']:.2%}")
        logging.info(f"   Forecast Volatility: {best['forecast_volatility']:.2%}")
        logging.info(f"   Volatility Spread: {best['volatility_spread']:.2%}")
        logging.info(f"   Spread Percentage: {best['spread_percentage']:.2f}%")
        logging.info(f"   Spread Classification: {best['spread_classification']}")
        logging.info(f"   Trend: {best['volatility_trend']}")
        logging.info(f"   Risk Level: {best['risk_level']}")
        logging.info(f"   Opportunity Score: {best['opportunity_score']:.3f}")
    
    # Show top 3 opportunities
    logging.info(f"\n📊 Top 3 A10G Opportunities:")
    for i, opp in enumerate(a10g_analysis["opportunities"][:3], 1):
        logging.info(f"\n{i}. {opp['provider']} - {opp['instance_type']}")
        logging.info(f"   Spread: {opp['volatility_spread']:.2%} ({opp['spread_percentage']:.1f}%)
        logging.info(f"   Classification: {opp['spread_classification']}")
        logging.info(f"   Trend: {opp['volatility_trend']}")
        logging.info(f"   Risk: {opp['risk_level']}")
        logging.info(f"   Score: {opp['opportunity_score']:.3f}")
    
    # Show volatility summary
    if "volatility_summary" in a10g_analysis:
        summary = a10g_analysis["volatility_summary"]
        logging.info(f"\n📋 A10G Volatility Summary:")
        logging.info(f"   Avg Current Volatility: {summary['avg_current_volatility']:.2%}")
        logging.info(f"   Avg Forecast Volatility: {summary['avg_forecast_volatility']:.2%}")
        logging.info(f"   Avg Volatility Spread: {summary['avg_volatility_spread']:.2%}")
        logging.info(f"   Avg Spread Percentage: {summary['avg_spread_percentage']:.2f}%")
        logging.info(f"   Current Volatility Range: {summary['volatility_range']['min']:.2%} - {summary['volatility_range']['max']:.2%}")
        logging.info(f"   Forecast Volatility Range: {summary['forecast_range']['min']:.2%} - {summary['forecast_range']['max']:.2%}")
    
    logging.info("\n🎯 Simple Volatility Analysis Completed!")
    logging.info("✅ Simple volatility calculation working")
    logging.info("✅ Volatility spread analysis working")
    logging.info("✅ Opportunity scoring working")
    logging.info("✅ Risk classification working")
    logging.info("✅ Trend analysis working")

if __name__ == "__main__":
    test_simple_volatility_analysis()
