#!/bin/bash
# Karpenter IAM Setup Script for Terradev
# This script sets up the necessary IAM roles and policies for Karpenter

set -euo pipefail

# Configuration
CLUSTER_NAME="${CLUSTER_NAME:-terradev-cluster}"
AWS_REGION="${AWS_REGION:-us-east-1}"
KARPENTER_NAMESPACE="${KARPENTER_NAMESPACE:-karpenter}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-$(aws sts get-caller-identity --query Account --output text)}"

echo "🚀 Setting up Karpenter IAM roles for Terradev"
echo "Cluster: $CLUSTER_NAME"
echo "Region: $AWS_REGION"
echo "Account: $AWS_ACCOUNT_ID"
echo "Namespace: $KARPENTER_NAMESPACE"
echo "=================================="

# Get OIDC provider URL
OIDC_PROVIDER_URL=$(aws eks describe-cluster \
  --name "$CLUSTER_NAME" \
  --query "cluster.identity.oidc.issuer" \
  --output text)

echo "🔍 OIDC Provider URL: $OIDC_PROVIDER_URL"

# Get OIDC provider ARN
OIDC_PROVIDER_ARN=$(aws iam list-open-id-connect-providers \
  --query "OpenIDConnectProviderList[?contains(Arn,\`$AWS_ACCOUNT_ID\`)].Arn" \
  --output text)

echo "🔍 OIDC Provider ARN: $OIDC_PROVIDER_ARN"

# Create Karpenter controller IAM policy
echo "📋 Creating Karpenter IAM policy..."

cat > karpenter-policy.json <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ssm:GetParameter",
                "ssm:GetParameters",
                "ec2:DescribeImages",
                "ec2:DescribeInstances",
                "ec2:DescribeInstanceTypes",
                "ec2:DescribeLaunchTemplates",
                "ec2:DescribeSecurityGroups",
                "ec2:DescribeSubnets",
                "ec2:DescribeVolumes",
                "ec2:CreateTags",
                "ec2:DeleteTags",
                "ec2:RunInstances",
                "ec2:TerminateInstances",
                "ec2:DescribeAvailabilityZones",
                "ec2:DescribeInstanceAttribute",
                "ec2:DescribeInstanceStatus",
                "ec2:DescribeSpotInstanceRequests",
                "ec2:RequestSpotInstances",
                "ec2:CancelSpotInstanceRequests",
                "ec2:DescribeNetworkInterfaces",
                "ec2:CreateNetworkInterface",
                "ec2:DeleteNetworkInterface",
                "ec2:ModifyInstanceAttribute",
                "ec2:DescribeSpotPriceHistory"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "iam:PassRole",
                "iam:CreateServiceLinkedRole",
                "iam:CreateInstanceProfile",
                "iam:DeleteInstanceProfile",
                "iam:GetInstanceProfile",
                "iam:RemoveRoleFromInstanceProfile",
                "iam:GetRole",
                "iam:CreateRole",
                "iam:DeleteRole",
                "iam:PutRolePolicy",
                "iam:DeleteRolePolicy",
                "iam:GetRolePolicy",
                "iam:ListAttachedRolePolicies"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "sqs:DeleteMessage",
                "sqs:GetQueueAttributes",
                "sqs:ReceiveMessage",
                "sqs:SendMessage"
            ],
            "Resource": "arn:aws:sqs:${AWS_REGION}:${AWS_ACCOUNT_ID}:${CLUSTER_NAME}"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudwatch:PutMetricData"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "ec2:CreateLaunchTemplate",
                "ec2:CreateLaunchTemplateVersion",
                "ec2:DeleteLaunchTemplate",
                "ec2:DeleteLaunchTemplateVersions",
                "ec2:DescribeLaunchTemplateVersions",
                "ec2:ModifyLaunchTemplate"
            ],
            "Resource": "*"
        }
    ]
}
EOF

# Create or update the policy
POLICY_NAME="${CLUSTER_NAME}-karpenter-policy"
POLICY_ARN="arn:aws:iam::${AWS_ACCOUNT_ID}:policy/${POLICY_NAME}"

if aws iam get-policy --policy-arn "$POLICY_ARN" >/dev/null 2>&1; then
    echo "📝 Policy already exists, updating..."
    aws iam create-policy-version \
        --policy-arn "$POLICY_ARN" \
        --policy-document file://karpenter-policy.json \
        --set-as-default
else
    echo "📝 Creating new policy..."
    aws iam create-policy \
        --policy-name "$POLICY_NAME" \
        --policy-document file://karpenter-policy.json \
        --description "Karpenter policy for Terradev cluster $CLUSTER_NAME"
fi

echo "✅ IAM policy created/updated: $POLICY_ARN"

# Create IAM role for Karpenter controller
echo "🔧 Creating IAM role for Karpenter controller..."

cat > karpenter-trust-policy.json <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Federated": "${OIDC_PROVIDER_ARN}"
            },
            "Action": "sts:AssumeRoleWithWebIdentity",
            "Condition": {
                "StringEquals": {
                    "${OIDC_PROVIDER_URL#https://}:sub": "system:serviceaccount:${KARPENTER_NAMESPACE}:karpenter"
                }
            }
        }
    ]
}
EOF

ROLE_NAME="${CLUSTER_NAME}-karpenter"
ROLE_ARN="arn:aws:iam::${AWS_ACCOUNT_ID}:role/${ROLE_NAME}"

if aws iam get-role --role-name "$ROLE_NAME" >/dev/null 2>&1; then
    echo "📝 Role already exists, updating trust policy..."
    aws iam update-assume-role-policy \
        --role-name "$ROLE_NAME" \
        --policy-document file://karpenter-trust-policy.json
else
    echo "📝 Creating new role..."
    aws iam create-role \
        --role-name "$ROLE_NAME" \
        --assume-role-policy-document file://karpenter-trust-policy.json \
        --description "Karpenter controller role for Terradev cluster $CLUSTER_NAME"
fi

# Attach policy to role
echo "🔗 Attaching policy to role..."
aws iam attach-role-policy \
    --role-name "$ROLE_NAME" \
    --policy-arn "$POLICY_ARN"

echo "✅ IAM role created/updated: $ROLE_ARN"

# Create interruption queue
echo "📨 Creating interruption queue..."

if aws sqs get-queue-url --queue-name "$CLUSTER_NAME" --region "$AWS_REGION" >/dev/null 2>&1; then
    echo "📝 Queue already exists"
    QUEUE_URL=$(aws sqs get-queue-url --queue-name "$CLUSTER_NAME" --region "$AWS_REGION" --output text --query QueueUrl)
else
    echo "📝 Creating new queue..."
    QUEUE_URL=$(aws sqs create-queue \
        --queue-name "$CLUSTER_NAME" \
        --region "$AWS_REGION" \
        --output text \
        --query QueueUrl)
fi

QUEUE_ARN=$(aws sqs get-queue-attributes \
    --queue-url "$QUEUE_URL" \
    --attribute-names QueueArn \
    --region "$AWS_REGION" \
    --output text \
    --query Attributes.QueueArn)

echo "✅ Interruption queue: $QUEUE_ARN"

# Set queue policy
echo "🔧 Setting queue policy..."

cat > queue-policy.json <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "sqs.amazonaws.com"
            },
            "Action": "SQS:SendMessage",
            "Resource": "${QUEUE_ARN}"
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "*"
            },
            "Action": "SQS:SendMessage",
            "Resource": "${QUEUE_ARN}",
            "Condition": {
                "StringEquals": {
                    "aws:SourceArn": "arn:aws:events:${AWS_REGION}:${AWS_ACCOUNT_ID}:rule/*"
                }
            }
        }
    ]
}
EOF

aws sqs set-queue-attributes \
    --queue-url "$QUEUE_URL" \
    --region "$AWS_REGION" \
    --attributes file://queue-policy.json

echo "✅ Queue policy set"

# Create event bridge rule for spot interruptions
echo "🔔 Creating EventBridge rule for spot interruptions..."

RULE_NAME="${CLUSTER_NAME}-spot-interruption-rule"

if aws events describe-rule --name "$RULE_NAME" --region "$AWS_REGION" >/dev/null 2>&1; then
    echo "📝 EventBridge rule already exists"
else
    echo "📝 Creating new EventBridge rule..."
    aws events put-rule \
        --name "$RULE_NAME" \
        --region "$AWS_REGION" \
        --event-pattern '{
            "source": ["aws.ec2"],
            "detail-type": ["EC2 Spot Instance Interruption Warning"]
        }'
fi

# Add target to rule
aws events put-targets \
    --rule "$RULE_NAME" \
    --region "$AWS_REGION" \
    --targets "Id"="1","Arn"="${QUEUE_ARN}"

echo "✅ EventBridge rule created"

# Create Kubernetes service account
echo "🔧 Creating Kubernetes service account..."

cat > karpenter-service-account.yaml <<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  name: karpenter
  namespace: ${KARPENTER_NAMESPACE}
  annotations:
    eks.amazonaws.com/role-arn: ${ROLE_ARN}
EOF

kubectl apply -f karpenter-service-account.yaml

echo "✅ Service account created"

# Create node IAM role for Karpenter-managed nodes
echo "🔧 Creating node IAM role..."

NODE_ROLE_NAME="${CLUSTER_NAME}-karpenter-node-role"

cat > node-trust-policy.json <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "ec2.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF

if aws iam get-role --role-name "$NODE_ROLE_NAME" >/dev/null 2>&1; then
    echo "📝 Node role already exists"
else
    echo "📝 Creating new node role..."
    aws iam create-role \
        --role-name "$NODE_ROLE_NAME" \
        --assume-role-policy-document file://node-trust-policy.json \
        --description "Karpenter node role for Terradev cluster $CLUSTER_NAME"
fi

# Attach AmazonEKSWorkerNodePolicy
aws iam attach-role-policy \
    --role-name "$NODE_ROLE_NAME" \
    --policy-arn arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy

# Attach AmazonEC2ContainerRegistryReadOnly
aws iam attach-role-policy \
    --role-name "$NODE_ROLE_NAME" \
    --policy-arn arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly

# Attach AmazonEKS_CNI_Policy
aws iam attach-role-policy \
    --role-name "$NODE_ROLE_NAME" \
    --policy-arn arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy

# Attach CloudWatchAgentServerPolicy for monitoring
aws iam attach-role-policy \
    --role-name "$NODE_ROLE_NAME" \
    --policy-arn arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy

echo "✅ Node role created and policies attached"

# Create instance profile for node role
INSTANCE_PROFILE_NAME="${CLUSTER_NAME}-karpenter-node-profile"

if aws iam get-instance-profile --instance-profile-name "$INSTANCE_PROFILE_NAME" >/dev/null 2>&1; then
    echo "📝 Instance profile already exists"
else
    echo "📝 Creating new instance profile..."
    aws iam create-instance-profile --instance-profile-name "$INSTANCE_PROFILE_NAME"
fi

# Add role to instance profile
aws iam add-role-to-instance-profile \
    --instance-profile-name "$INSTANCE_PROFILE_NAME" \
    --role-name "$NODE_ROLE_NAME"

echo "✅ Instance profile created"

# Clean up temporary files
echo "🧹 Cleaning up temporary files..."
rm -f karpenter-policy.json karpenter-trust-policy.json queue-policy.json node-trust-policy.json karpenter-service-account.yaml

echo ""
echo "🎉 Karpenter IAM setup completed successfully!"
echo "=================================="
echo "Policy ARN: $POLICY_ARN"
echo "Role ARN: $ROLE_ARN"
echo "Queue ARN: $QUEUE_ARN"
echo "Node Role: $NODE_ROLE_NAME"
echo "Instance Profile: $INSTANCE_PROFILE_NAME"
echo ""
echo "🚀 Ready to install Karpenter!"
echo "Run the following command to install Karpenter:"
echo ""
echo "export KARPENTER_VERSION=v0.32.0"
echo "export KARPENTER_NAMESPACE=karpenter"
echo "export CLUSTER_NAME=$CLUSTER_NAME"
echo ""
echo "helm upgrade --install karpenter oci://public.ecr.aws/karpenter/karpenter \\"
echo "  --version \"\${KARPENTER_VERSION}\" \\"
echo "  --namespace \"\${KARPENTER_NAMESPACE}\" \\"
echo "  --create-namespace \\"
echo "  --set \"settings.clusterName=\${CLUSTER_NAME}\" \\"
echo "  --set \"settings.interruptionQueue=\${CLUSTER_NAME}\" \\"
echo "  --set controller.resources.requests.cpu=1 \\"
echo "  --set controller.resources.requests.memory=1Gi \\"
echo "  --set controller.resources.limits.cpu=1 \\"
echo "  --set controller.resources.limits.memory=1Gi \\"
echo "  --wait"
