#!/usr/bin/env python3
"""
Karpenter Setup - Automatic Node Provisioning for Kubernetes
Integrates with Terradev for optimal GPU node provisioning
"""

import subprocess
import json
import os
import time
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class KarpenterConfig:
    """Karpenter configuration"""
    version: str
    namespace: str
    cluster_name: str
    controller_cpu: str = "1"
    controller_memory: str = "1Gi"
    interruption_queue: Optional[str] = None
    aws_region: str = "us-east-1"
    aws_account_id: Optional[str] = None

class KarpenterSetup:
    """Karpenter setup and management"""
    
    def __init__(self, config: KarpenterConfig):
        self.config = config
        self.helm_chart = "oci://public.ecr.aws/karpenter/karpenter"
        
        # Set interruption queue if not provided
        if not config.interruption_queue:
            config.interruption_queue = config.cluster_name
    
    def install_karpenter(self) -> bool:
        """Install Karpenter using Helm"""
        logger.info("🚀 Installing Karpenter...")
        
        # Prepare Helm command
        helm_cmd = self._build_helm_command()
        
        try:
            # Execute Helm installation
            result = subprocess.run(
                helm_cmd,
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )
            
            logger.info("✅ Karpenter installed successfully")
            logger.info(f"Output: {result.stdout}")
            
            # Wait for deployment to be ready
            self._wait_for_karpenter_ready()
            
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Failed to install Karpenter: {e}")
            logger.error(f"Error output: {e.stderr}")
            return False
    
    def _build_helm_command(self) -> str:
        """Build Helm installation command"""
        cmd_parts = [
            "helm upgrade --install karpenter",
            f"oci://public.ecr.aws/karpenter/karpenter",
            f'--version "{self.config.version}"',
            f'--namespace "{self.config.namespace}"',
            "--create-namespace",
            f'--set "settings.clusterName={self.config.cluster_name}"',
            f'--set "settings.interruptionQueue={self.config.interruption_queue}"',
            f'--set controller.resources.requests.cpu={self.config.controller_cpu}',
            f'--set controller.resources.requests.memory={self.config.controller_memory}',
            f'--set controller.resources.limits.cpu={self.config.controller_cpu}',
            f'--set controller.resources.limits.memory={self.config.controller_memory}',
            "--wait"
        ]
        
        return " ".join(cmd_parts)
    
    def _wait_for_karpenter_ready(self, timeout: int = 300) -> bool:
        """Wait for Karpenter to be ready"""
        logger.info("⏳ Waiting for Karpenter to be ready...")
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                # Check pod status
                result = subprocess.run(
                    f"kubectl get pods -n {self.config.namespace} -l app.kubernetes.io/name=karpenter",
                    shell=True,
                    capture_output=True,
                    text=True
                )
                
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    if len(lines) > 1:  # Skip header
                        pod_line = lines[1]
                        if "Running" in pod_line and "1/1" in pod_line:
                            logger.info("✅ Karpenter is ready")
                            return True
                
                time.sleep(10)
                
            except subprocess.CalledProcessError:
                time.sleep(10)
                continue
        
        logger.error("❌ Timeout waiting for Karpenter to be ready")
        return False
    
    def create_provisioner(self, provisioner_config: Dict[str, Any]) -> bool:
        """Create Karpenter provisioner for GPU nodes"""
        logger.info("🔧 Creating Karpenter provisioner...")
        
        # Generate provisioner YAML
        provisioner_yaml = self._generate_provisioner_yaml(provisioner_config)
        
        try:
            # Apply provisioner
            result = subprocess.run(
                "echo '{}' | kubectl apply -f -".format(provisioner_yaml),
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )
            
            logger.info("✅ Provisioner created successfully")
            logger.info(f"Output: {result.stdout}")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Failed to create provisioner: {e}")
            logger.error(f"Error output: {e.stderr}")
            return False
    
    def _generate_provisioner_yaml(self, config: Dict[str, Any]) -> str:
        """Generate provisioner YAML configuration"""
        
        provisioner = {
            "apiVersion": "karpenter.sh/v1beta1",
            "kind": "Provisioner",
            "metadata": {
                "name": config.get("name", "default"),
                "namespace": self.config.namespace
            },
            "spec": {
                "requirements": config.get("requirements", [
                    {"key": "karpenter.k8s.aws/instance-category", "operator": "In", "values": ["g", "p"]},
                    {"key": "karpenter.k8s.aws/instance-generation", "operator": "Gt", "values": ["2"]},
                    {"key": "topology.kubernetes.io/zone", "operator": "In", "values": config.get("zones", ["us-east-1a", "us-east-1b", "us-east-1c"])}
                ]),
                "limits": {
                    "resources": {
                        "cpu": config.get("cpu_limit", "1000"),
                        "memory": config.get("memory_limit", "1000Gi")
                    }
                },
                "providerRef": {
                    "name": config.get("provider_name", "default")
                },
                "ttlSecondsAfterEmpty": config.get("ttl_seconds_after_empty", 30),
                "consolidation": {
                    "enabled": config.get("consolidation_enabled", True)
                }
            }
        }
        
        return json.dumps(provisioner, indent=2)
    
    def create_node_template(self, template_config: Dict[str, Any]) -> bool:
        """Create AWS node template for Karpenter"""
        logger.info("🔧 Creating AWS Node Template...")
        
        # Generate node template YAML
        template_yaml = self._generate_node_template_yaml(template_config)
        
        try:
            # Apply node template
            result = subprocess.run(
                "echo '{}' | kubectl apply -f -".format(template_yaml),
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )
            
            logger.info("✅ Node template created successfully")
            logger.info(f"Output: {result.stdout}")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Failed to create node template: {e}")
            logger.error(f"Error output: {e.stderr}")
            return False
    
    def _generate_node_template_yaml(self, config: Dict[str, Any]) -> str:
        """Generate AWS Node Template YAML"""
        
        node_template = {
            "apiVersion": "karpenter.k8s.aws/v1beta1",
            "kind": "EC2NodeTemplate",
            "metadata": {
                "name": config.get("name", "default"),
                "namespace": self.config.namespace
            },
            "spec": {
                "subnetSelector": {
                    "karpenter.sh/discovery": config.get("cluster_name", self.config.cluster_name)
                },
                "securityGroupSelector": {
                    "karpenter.sh/discovery": config.get("cluster_name", self.config.cluster_name)
                },
                "tags": {
                    "karpenter.sh/discovery": config.get("cluster_name", self.config.cluster_name),
                    "Environment": config.get("environment", "terradev"),
                    "Project": config.get("project", "gpu-provisioning")
                },
                "metadataOptions": {
                    "httpEndpoint": "enabled",
                    "httpPutResponseHopLimit": 2,
                    "httpTokens": "required"
                },
                "blockDeviceMappings": [
                    {
                        "ebs": {
                            "volumeSize": config.get("volume_size", "100Gi"),
                            "volumeType": config.get("volume_type", "gp3"),
                            "deleteOnTermination": "true"
                        }
                    }
                ]
            }
        }
        
        # Add GPU-specific configuration
        if config.get("gpu_enabled", False):
            node_template["spec"]["instanceTypeSelector"] = {
                "instanceTypes": config.get("gpu_instance_types", ["p3.2xlarge", "p3.8xlarge", "p4d.24xlarge"])
            }
        
        return json.dumps(node_template, indent=2)
    
    def setup_iam_roles(self) -> bool:
        """Setup IAM roles for Karpenter"""
        logger.info("🔐 Setting up IAM roles for Karpenter...")
        
        # Get AWS account ID
        try:
            result = subprocess.run(
                "aws sts get-caller-identity --query Account --output text",
                shell=True,
                capture_output=True,
                text=True,
                check=True
            )
            self.config.aws_account_id = result.stdout.strip()
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Failed to get AWS account ID: {e}")
            return False
        
        # Create IAM policy
        policy_name = f"{self.config.cluster_name}-karpenter-policy"
        policy_arn = self._create_iam_policy(policy_name)
        
        if not policy_arn:
            return False
        
        # Create IAM role and service account
        role_name = f"{self.config.cluster_name}-karpenter"
        return self._create_iam_role_and_service_account(role_name, policy_arn)
    
    def _create_iam_policy(self, policy_name: str) -> Optional[str]:
        """Create IAM policy for Karpenter"""
        
        policy_document = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "ec2:DescribeAvailabilityZones",
                        "ec2:DescribeImages",
                        "ec2:DescribeInstances",
                        "ec2:DescribeInstanceTypes",
                        "ec2:DescribeLaunchTemplates",
                        "ec2:DescribeSecurityGroups",
                        "ec2:DescribeSubnets",
                        "ec2:RunInstances",
                        "ec2:TerminateInstances",
                        "ec2:CreateTags",
                        "ec2:DeleteTags"
                    ],
                    "Resource": "*"
                },
                {
                    "Effect": "Allow",
                    "Action": [
                        "iam:PassRole",
                        "iam:CreateInstanceProfile",
                        "iam:DeleteInstanceProfile",
                        "iam:GetInstanceProfile",
                        "iam:RemoveRoleFromInstanceProfile",
                        "iam:GetRole",
                        "iam:CreateRole",
                        "iam:DeleteRole",
                        "iam:PutRolePolicy"
                    ],
                    "Resource": "*"
                },
                {
                    "Effect": "Allow",
                    "Action": [
                        "sqs:DeleteMessage",
                        "sqs:GetQueueAttributes",
                        "sqs:ReceiveMessage",
                        "sqs:SendMessage"
                    ],
                    "Resource": f"arn:aws:sqs:{self.config.aws_region}:{self.config.aws_account_id}:{self.config.interruption_queue}"
                }
            ]
        }
        
        try:
            # Create policy
            result = subprocess.run([
                "aws", "iam", "create-policy",
                "--policy-name", policy_name,
                "--policy-document", json.dumps(policy_document),
                "--description", "Karpenter policy for Terradev"
            ], capture_output=True, text=True, check=True)
            
            policy_data = json.loads(result.stdout)
            policy_arn = policy_data["Policy"]["Arn"]
            
            logger.info(f"✅ IAM policy created: {policy_arn}")
            return policy_arn
            
        except subprocess.CalledProcessError as e:
            # Policy might already exist
            if "already exists" in e.stderr:
                logger.info("ℹ️ IAM policy already exists")
                return f"arn:aws:iam::{self.config.aws_account_id}:policy/{policy_name}"
            
            logger.error(f"❌ Failed to create IAM policy: {e}")
            return None
    
    def _create_iam_role_and_service_account(self, role_name: str, policy_arn: str) -> bool:
        """Create IAM role and Kubernetes service account"""
        
        # Trust relationship
        trust_policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {
                        "Federated": f"arn:aws:iam::{self.config.aws_account_id}:oidc-provider/oidc.eks.{self.config.aws_region}.amazonaws.com"
                    },
                    "Action": "sts:AssumeRoleWithWebIdentity",
                    "Condition": {
                        "StringEquals": {
                            f"oidc.eks.{self.config.aws_region}.amazonaws.com:sub": f"system:serviceaccount:{self.config.namespace}:karpenter"
                        }
                    }
                }
            ]
        }
        
        try:
            # Create IAM role
            subprocess.run([
                "aws", "iam", "create-role",
                "--role-name", role_name,
                "--assume-role-policy-document", json.dumps(trust_policy),
                "--description", "Karpenter controller role for Terradev"
            ], capture_output=True, text=True, check=True)
            
            # Attach policy
            subprocess.run([
                "aws", "iam", "attach-role-policy",
                "--role-name", role_name,
                "--policy-arn", policy_arn
            ], capture_output=True, text=True, check=True)
            
            # Create service account
            subprocess.run([
                "kubectl", "create", "serviceaccount", "karpenter",
                "--namespace", self.config.namespace
            ], capture_output=True, text=True, check=True)
            
            # Annotate service account
            subprocess.run([
                "kubectl", "annotate", "serviceaccount", "karpenter",
                f"eks.amazonaws.com/role-arn=arn:aws:iam::{self.config.aws_account_id}:role/{role_name}",
                "--namespace", self.config.namespace,
                "--overwrite"
            ], capture_output=True, text=True, check=True)
            
            logger.info("✅ IAM role and service account created")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Failed to create IAM role and service account: {e}")
            return False
    
    def verify_installation(self) -> bool:
        """Verify Karpenter installation"""
        logger.info("🔍 Verifying Karpenter installation...")
        
        try:
            # Check Helm release
            result = subprocess.run([
                "helm", "list", "-n", self.config.namespace, "--filter", "karpenter"
            ], capture_output=True, text=True, check=True)
            
            if "karpenter" in result.stdout:
                logger.info("✅ Karpenter Helm release found")
            else:
                logger.error("❌ Karpenter Helm release not found")
                return False
            
            # Check pods
            result = subprocess.run([
                "kubectl", "get", "pods", "-n", self.config.namespace, "-l", "app.kubernetes.io/name=karpenter"
            ], capture_output=True, text=True, check=True)
            
            if "Running" in result.stdout and "1/1" in result.stdout:
                logger.info("✅ Karpenter pod is running")
            else:
                logger.error("❌ Karpenter pod is not running")
                return False
            
            # Check CRDs
            result = subprocess.run([
                "kubectl", "get", "crd", "provisioners.karpenter.sh"
            ], capture_output=True, text=True, check=True)
            
            if result.returncode == 0:
                logger.info("✅ Karpenter CRDs are installed")
            else:
                logger.error("❌ Karpenter CRDs not found")
                return False
            
            logger.info("✅ Karpenter installation verified successfully")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Verification failed: {e}")
            return False

def main():
    """Main function to setup Karpenter"""
    logger.info("🚀 Karpenter Setup for Terradev")
    logger.info("=" * 50)
    
    # Configuration
    config = KarpenterConfig(
        version=os.environ.get("KARPENTER_VERSION", "v0.32.0"),
        namespace=os.environ.get("KARPENTER_NAMESPACE", "karpenter"),
        cluster_name=os.environ.get("CLUSTER_NAME", "terradev-cluster"),
        aws_region=os.environ.get("AWS_REGION", "us-east-1")
    )
    
    # Initialize setup
    setup = KarpenterSetup(config)
    
    # Step 1: Setup IAM roles
    logger.info("📋 Step 1: Setting up IAM roles...")
    if not setup.setup_iam_roles():
        logger.error("❌ IAM setup failed")
        return
    
    # Step 2: Install Karpenter
    logger.info("📋 Step 2: Installing Karpenter...")
    if not setup.install_karpenter():
        logger.error("❌ Karpenter installation failed")
        return
    
    # Step 3: Create GPU provisioner
    logger.info("📋 Step 3: Creating GPU provisioner...")
    provisioner_config = {
        "name": "gpu-provisioner",
        "zones": ["us-east-1a", "us-east-1b", "us-east-1c"],
        "cpu_limit": "100",
        "memory_limit": "1000Gi",
        "consolidation_enabled": True
    }
    
    if not setup.create_provisioner(provisioner_config):
        logger.error("❌ Provisioner creation failed")
        return
    
    # Step 4: Create node template
    logger.info("📋 Step 4: Creating AWS node template...")
    template_config = {
        "name": "gpu-node-template",
        "cluster_name": config.cluster_name,
        "environment": "terradev",
        "project": "gpu-provisioning",
        "gpu_enabled": True,
        "gpu_instance_types": ["p3.2xlarge", "p3.8xlarge", "p4d.24xlarge", "g5.xlarge", "g5.2xlarge"],
        "volume_size": "100Gi",
        "volume_type": "gp3"
    }
    
    if not setup.create_node_template(template_config):
        logger.error("❌ Node template creation failed")
        return
    
    # Step 5: Verify installation
    logger.info("📋 Step 5: Verifying installation...")
    if not setup.verify_installation():
        logger.error("❌ Verification failed")
        return
    
    logger.info("🎉 Karpenter setup completed successfully!")
    logger.info("🚀 Ready for automatic GPU node provisioning!")

if __name__ == "__main__":
    main()
