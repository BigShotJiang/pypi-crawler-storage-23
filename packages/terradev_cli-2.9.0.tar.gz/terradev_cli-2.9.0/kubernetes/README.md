# 🚀 Karpenter for Terradev - Automatic GPU Node Provisioning

Complete Karpenter setup for automatic GPU node provisioning in EKS clusters, optimized for Terradev's parallel compute workloads.

---

## 🎯 Overview

This Karpenter configuration provides automatic GPU node provisioning for Terradev workloads, with support for:

- **🔥 Multiple GPU Types**: A100, V100, H100, RTX4090, A10G, T4
- **💰 Cost Optimization**: Spot instances, consolidation, and intelligent selection
- **⚡ Performance**: High-performance and specialized provisioners
- **📊 Monitoring**: Complete observability with Grafana dashboards
- **🔒 Security**: IAM roles and policies properly configured

---

## 🏗️ Architecture

### **📋 Components**

1. **Karpenter Controller** - Core provisioning engine
2. **Provisioners** - Define node types and constraints
3. **Node Templates** - AWS-specific configuration
4. **IAM Roles** - Security and permissions
5. **Monitoring** - Observability and cost tracking

### **🔄 Provisioning Flow**

```
GPU Workload → Karpenter → Provisioner → Node Template → AWS EC2 → GPU Node
```

---

## 🚀 Quick Start

### **1. Prerequisites**

```bash
# Required tools
kubectl
helm
aws cli

# EKS cluster running
aws eks update-kubeconfig --region us-east-1 --name terradev-cluster
```

### **2. IAM Setup**

```bash
# Set environment variables
export CLUSTER_NAME=terradev-cluster
export AWS_REGION=us-east-1
export KARPENTER_NAMESPACE=karpenter

# Run IAM setup
./karpenter_iam_setup.sh
```

### **3. Install Karpenter**

```bash
# Set Karpenter version
export KARPENTER_VERSION=v0.32.0

# Install with your exact command
./karpenter_install.sh
```

### **4. Deploy GPU Workload**

```bash
# Deploy test workload to trigger provisioning
kubectl apply -f test_gpu_workload.yaml

# Watch provisioning
kubectl logs -f deployment/karpenter -n karpenter
```

---

## 📋 Configuration Files

### **🔧 Core Files**

| File | Purpose |
|------|---------|
| `karpenter_iam_setup.sh` | IAM roles and policies setup |
| `karpenter_install.sh` | Karpenter installation |
| `karpenter_provisioners.yaml` | Provisioner definitions |
| `karpenter_node_templates.yaml` | AWS node templates |
| `test_gpu_workload.yaml` | Test GPU workloads |
| `karpenter_monitoring.yaml` | Monitoring and observability |

### **🎯 Provisioners**

#### **GPU Provisioner**
- **Purpose**: General GPU workloads
- **Instance Types**: p3, p4, p5, g5, g4dn
- **Capacity Types**: Spot + On-demand
- **Consolidation**: Enabled

#### **High-Performance GPU Provisioner**
- **Purpose**: A100/H100 workloads
- **Instance Types**: p4d, p4de, p5, g5.48xlarge
- **Features**: EFA support, high I/O
- **Storage**: io2 volumes with high IOPS

#### **Cost-Optimized GPU Provisioner**
- **Purpose**: Development/testing
- **Instance Types**: g5, g4dn series
- **Capacity Types**: Spot only
- **TTL**: 15 seconds for fast cleanup

#### **Training Workload Provisioner**
- **Purpose**: ML/AI training
- **Instance Types**: p3, p4, p5, g5
- **Features**: EFA, CUDA, ML frameworks
- **TTL**: 5 minutes for job completion

#### **Inference Workload Provisioner**
- **Purpose**: Model serving
- **Instance Types**: g5, g4dn, inf1
- **Capacity Types**: On-demand for stability
- **Features**: Inferentia support

---

## 🖥️ GPU Instance Types

### **🔥 High-Performance GPUs**

| Instance | GPU Type | GPU Count | Memory | Price/Hour | Use Case |
|----------|----------|------------|--------|------------|----------|
| `p5.48xlarge` | H100 | 8 | 2TB | $98.32 | Large training |
| `p4d.24xlarge` | A100 | 8 | 1TB | $32.77 | Training |
| `p4de.24xlarge` | A100 | 8 | 1TB | $32.77 | Training |
| `p3.16xlarge` | V100 | 8 | 488GB | $24.48 | Training |
| `p3.8xlarge` | V100 | 4 | 244GB | $12.24 | Training |
| `p3.2xlarge` | V100 | 1 | 61GB | $3.06 | Training |

### **💰 Cost-Optimized GPUs**

| Instance | GPU Type | GPU Count | Memory | Price/Hour | Use Case |
|----------|----------|------------|--------|------------|----------|
| `g5.48xlarge` | A10G | 8 | 768GB | $12.96 | Training |
| `g5.24xlarge` | A10G | 4 | 384GB | $6.48 | Training |
| `g5.12xlarge` | A10G | 4 | 192GB | $3.24 | Training |
| `g5.2xlarge` | A10G | 1 | 32GB | $0.54 | Inference |
| `g5.xlarge` | A10G | 1 | 16GB | $0.27 | Inference |
| `g4dn.16xlarge` | T4 | 1 | 256GB | $1.204 | Inference |
| `g4dn.8xlarge` | T4 | 1 | 128GB | $0.602 | Inference |

### **🚀 Inference GPUs**

| Instance | GPU Type | GPU Count | Memory | Price/Hour | Use Case |
|----------|----------|------------|--------|------------|----------|
| `inf1.24xlarge` | Inferentia | 1 | 96GB | $1.341 | Inference |
| `inf1.6xlarge` | Inferentia | 4 | 64GB | $0.419 | Inference |
| `inf1.2xlarge` | Inferentia | 1 | 16GB | $0.154 | Inference |
| `inf1.xlarge` | Inferentia | 1 | 8GB | $0.083 | Inference |

---

## 📊 Monitoring & Observability

### **🔍 Metrics Available**

- **Node Provisioning Rate**: Nodes provisioned per second
- **Node Termination Rate**: Nodes terminated per second
- **GPU Instance Distribution**: Breakdown by instance type
- **Cost Analysis**: Hourly cost tracking
- **Spot vs On-Demand**: Capacity type distribution
- **Resource Utilization**: GPU and CPU usage

### **📈 Grafana Dashboard**

```bash
# Import dashboard
kubectl apply -f karpenter_monitoring.yaml

# Access Grafana (if configured)
kubectl port-forward svc/grafana 3000:3000 -n monitoring
```

### **🚨 Alerts**

- **High Provisioning Rate**: >0.1 nodes/sec
- **High Termination Rate**: >0.1 nodes/sec
- **No GPU Nodes**: Zero GPU nodes available
- **Spot Interruptions**: High interruption rate

---

## 💰 Cost Optimization

### **🎯 Optimization Strategies**

#### **1. Spot Instance Usage**
- **60-70% savings** vs on-demand
- **Interruption handling** with graceful termination
- **Multi-AZ distribution** for availability

#### **2. Instance Consolidation**
- **Right-sizing** based on workload requirements
- **Bin packing** for optimal utilization
- **Automatic consolidation** when nodes are underutilized

#### **3. Regional Optimization**
- **Price comparison** across availability zones
- **Latency-aware** placement
- **Capacity-aware** provisioning

#### **4. TTL Management**
- **Fast cleanup** for development workloads (15s)
- **Extended TTL** for training jobs (5min)
- **Balanced TTL** for inference (2min)

### **💡 Cost Savings Examples**

```bash
# Cost-optimized development
kubectl apply -f - <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: dev-workload
spec:
  nodeSelector:
    karpenter.sh/provisioner: cost-optimized-gpu-provisioner
  containers:
  - name: app
    resources:
      requests:
        nvidia.com/gpu: 1
EOF

# High-performance training
kubectl apply -f - <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: training-workload
spec:
  nodeSelector:
    karpenter.sh/provisioner: high-performance-gpu-provisioner
  containers:
  - name: training
    resources:
      requests:
        nvidia.com/gpu: 4
EOF
```

---

## 🔧 Advanced Configuration

### **🎛️ Custom Provisioners**

```yaml
apiVersion: karpenter.sh/v1beta1
kind: Provisioner
metadata:
  name: custom-gpu-provisioner
spec:
  requirements:
    - key: karpenter.k8s.aws/instance-category
      operator: In
      values: ["p", "g"]
    - key: karpenter.k8s.aws/instance-generation
      operator: Gt
      values: ["2"]
  limits:
    resources:
      cpu: "100"
      memory: "1000Gi"
  providerRef:
    name: custom-node-template
  consolidation:
    enabled: true
  ttlSecondsAfterEmpty: 30
```

### **🏗️ Custom Node Templates**

```yaml
apiVersion: karpenter.k8s.aws/v1beta1
kind: EC2NodeTemplate
metadata:
  name: custom-node-template
spec:
  subnetSelector:
    karpenter.sh/discovery: terradev-cluster
  securityGroupSelector:
    karpenter.sh/discovery: terradev-cluster
  instanceTypeSelector:
    instanceTypes: ["p4d.24xlarge", "p5.48xlarge"]
  tags:
    Environment: production
    Project: terradev
    Workload: custom-gpu
  blockDeviceMappings:
    - ebs:
        volumeSize: 500Gi
        volumeType: io2
        iops: 10000
```

### **🔧 User Data Customization**

```bash
# Custom GPU setup script
cat > custom-gpu-setup.sh <<'EOF'
#!/bin/bash
# Custom GPU node setup
yum update -y

# Install NVIDIA drivers
yum install -y nvidia-driver-latest-dkms cuda

# Install Docker
yum install -y docker
systemctl enable docker
systemctl start docker

# Install custom tools
pip3 install torch torchvision transformers

# Custom optimization
echo 'options nvidia NVreg_RegistryDwords=PowerMizerEnable=0x1;PowerMizerLevel=0x1' >> /etc/modprobe.d/nvidia.conf
EOF
```

---

## 🧪 Testing & Validation

### **🔬 Test Workloads**

```bash
# Test basic GPU functionality
kubectl apply -f test_gpu_workload.yaml

# Monitor provisioning
kubectl logs -f deployment/karpenter -n karpenter

# Check node status
kubectl get nodes -L karpenter.sh/capacity-type,node.kubernetes.io/instance-type

# Check GPU status
kubectl exec -it gpu-test-workload -- nvidia-smi
```

### **📊 Performance Testing**

```bash
# GPU stress test
kubectl apply -f - <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: gpu-stress-test
spec:
  nodeSelector:
    karpenter.sh/provisioner: high-performance-gpu-provisioner
  containers:
  - name: stress
    image: nvidia/cuda:11.8.0-base
    resources:
      requests:
        nvidia.com/gpu: 1
    command: ["nvidia-smi"]
EOF
```

### **🧹 Cleanup**

```bash
# Delete test workloads
kubectl delete -f test_gpu_workload.yaml

# Wait for node termination
kubectl get nodes -w

# Check Karpenter logs
kubectl logs -f deployment/karpenter -n karpenter
```

---

## 🔒 Security

### **🛡️ IAM Permissions**

- **Least Privilege**: Minimal required permissions
- **Resource Tagging**: Proper resource tagging
- **Network Security**: Security group management
- **Encryption**: EBS volume encryption

### **🔐 Network Security**

```yaml
# Security group configuration
securityGroupSelector:
  karpenter.sh/discovery: terradev-cluster
  # Additional security groups can be specified
  sg-name: gpu-node-security-group
```

### **🔑 Access Control**

```bash
# RBAC for Karpenter
kubectl create clusterrolebinding karpenter-controller \
  --clusterrole=karpenter-controller \
  --serviceaccount=karpenter:karpenter
```

---

## 🚨 Troubleshooting

### **🔍 Common Issues**

#### **1. Nodes Not Provisioning**
```bash
# Check Karpenter logs
kubectl logs -f deployment/karpenter -n karpenter

# Check provisioner status
kubectl get provisioners -n karpenter

# Check node templates
kubectl get ec2nodetemplates -n karpenter
```

#### **2. GPU Not Available**
```bash
# Check GPU device plugin
kubectl get pods -n kube-system | grep nvidia

# Check node labels
kubectl get nodes -L nvidia.com/gpu

# Check GPU status
kubectl describe node <node-name>
```

#### **3. IAM Permission Issues**
```bash
# Check service account
kubectl get serviceaccount karpenter -n karpenter -o yaml

# Check IAM role
aws iam get-role --role-name terradev-cluster-karpenter

# Test permissions
aws sts assume-role --role-arn <role-arn> --role-session-name test
```

#### **4. Spot Instance Issues**
```bash
# Check interruption queue
aws sqs get-queue-attributes --queue-url <queue-url>

# Check EventBridge rules
aws events list-rules --name-prefix terradev-cluster

# Check spot capacity
aws ec2 describe-spot-price-history --instance-types p3.2xlarge
```

### **📋 Debug Commands**

```bash
# Full cluster status
kubectl get all -A

# Karpenter resources
kubectl get provisioners,ec2nodetemplates -n karpenter

# Node details
kubectl get nodes -o wide

# GPU pods
kubectl get pods -o wide | grep gpu

# Events
kubectl get events --sort-by=.metadata.creationTimestamp
```

---

## 📈 Performance Tuning

### **⚡ Optimization Tips**

#### **1. Provisioner Configuration**
```yaml
# Optimize for faster provisioning
spec:
  ttlSecondsAfterEmpty: 30  # Faster cleanup
  consolidation:
    enabled: true
  weight: 100  # Higher priority
```

#### **2. Node Template Optimization**
```yaml
# Optimize for performance
spec:
  blockDeviceMappings:
    - ebs:
        volumeSize: 200Gi
        volumeType: gp3
        iops: 3000
        throughput: 125
```

#### **3. Resource Requests**
```yaml
# Right-size resources
resources:
  requests:
    nvidia.com/gpu: 1
    cpu: "4"
    memory: "16Gi"
  limits:
    nvidia.com/gpu: 1
    cpu: "8"
    memory: "32Gi"
```

---

## 🎯 Best Practices

### **✅ Recommended Practices**

1. **Use Spot Instances** for cost savings
2. **Enable Consolidation** for resource optimization
3. **Set Appropriate TTL** for workload types
4. **Monitor Costs** with CloudWatch integration
5. **Test Thoroughly** before production deployment
6. **Use Labels** for workload categorization
7. **Implement Alerts** for proactive monitoring

### **❌ Common Mistakes**

1. **Ignoring IAM permissions** - causes provisioning failures
2. **Wrong instance types** - leads to cost overruns
3. **No monitoring** - difficult to troubleshoot
4. **Ignoring spot interruptions** - causes workload failures
5. **Over-provisioning** - wastes resources and money

---

## 🚀 Production Deployment

### **📋 Production Checklist**

- [ ] IAM roles configured correctly
- [ ] Security groups properly set
- [ ] Monitoring and alerts configured
- [ ] Cost tracking enabled
- [ ] Backup and recovery plan
- [ ] Documentation updated
- [ ] Team training completed

### **🎛️ Production Configuration**

```yaml
# Production-ready provisioner
apiVersion: karpenter.sh/v1beta1
kind: Provisioner
metadata:
  name: production-gpu-provisioner
spec:
  requirements:
    - key: karpenter.k8s.aws/instance-category
      operator: In
      values: ["p", "g"]
    - key: kubernetes.io/arch
      operator: In
      values: ["amd64"]
  limits:
    resources:
      cpu: "1000"
      memory: "4000Gi"
  providerRef:
    name: production-node-template
  consolidation:
    enabled: true
  ttlSecondsAfterEmpty: 300
  weight: 100
```

---

## 🎉 Success Metrics

### **📊 Key Performance Indicators**

- **Provisioning Speed**: <2 minutes for GPU nodes
- **Cost Savings**: 60%+ with spot instances
- **Resource Utilization**: >80% GPU utilization
- **Uptime**: >99% availability
- **Interruption Handling**: <5% workload impact

### **💰 Cost Impact**

- **Development**: 70% cost reduction
- **Training**: 60% cost reduction
- **Inference**: 40% cost reduction
- **Overall**: 50%+ savings vs static nodes

---

## 🆘 Support

### **📞 Getting Help**

- **Documentation**: [Karpenter Docs](https://karpenter.sh/)
- **GitHub Issues**: [Karpenter Issues](https://github.com/awslabs/karpenter/issues)
- **AWS Support**: Enterprise support available
- **Community**: [Karpenter Slack](https://kubernetes.slack.com/archives/C02NQ7T5RLT)

### **🔧 Additional Resources**

- **Terradev CLI**: Parallel provisioning tool
- **Kubernetes Docs**: Cluster management
- **AWS Docs**: EKS and EC2 documentation
- **NVIDIA Docs**: GPU driver and CUDA

---

**🚀 Karpenter for Terradev - Automatic GPU Node Provisioning**

*Optimized for parallel compute workloads with cost-effective, scalable GPU provisioning*
