#!/bin/bash
# Karpenter Installation Script for Terradev
# This script installs Karpenter with the exact command you provided

set -euo pipefail

# Configuration
KARPENTER_VERSION="${KARPENTER_VERSION:-v0.32.0}"
KARPENTER_NAMESPACE="${KARPENTER_NAMESPACE:-karpenter}"
CLUSTER_NAME="${CLUSTER_NAME:-terradev-cluster}"
AWS_REGION="${AWS_REGION:-us-east-1}"

echo "🚀 Installing Karpenter for Terradev"
echo "Version: $KARPENTER_VERSION"
echo "Namespace: $KARPENTER_NAMESPACE"
echo "Cluster: $CLUSTER_NAME"
echo "Region: $AWS_REGION"
echo "=================================="

# Check prerequisites
echo "🔍 Checking prerequisites..."

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl is not installed or not in PATH"
    exit 1
fi

# Check if helm is available
if ! command -v helm &> /dev/null; then
    echo "❌ helm is not installed or not in PATH"
    exit 1
fi

# Check if AWS CLI is available
if ! command -v aws &> /dev/null; then
    echo "❌ aws CLI is not installed or not in PATH"
    exit 1
fi

# Check if cluster is reachable
if ! kubectl cluster-info &> /dev/null; then
    echo "❌ Cannot connect to Kubernetes cluster"
    exit 1
fi

# Check if IAM setup is complete
echo "🔍 Checking IAM setup..."
SERVICE_ACCOUNT_ANNOTATION=$(kubectl get serviceaccount karpenter -n "$KARPENTER_NAMESPACE" -o jsonpath='{.metadata.annotations.eks\.amazonaws\.com/role-arn}' 2>/dev/null || echo "")

if [[ -z "$SERVICE_ACCOUNT_ANNOTATION" ]]; then
    echo "❌ Karpenter service account not found or missing IAM role annotation"
    echo "Please run the IAM setup script first:"
    echo "./karpenter_iam_setup.sh"
    exit 1
fi

echo "✅ Service account IAM role: $SERVICE_ACCOUNT_ANNOTATION"

# Add Karpenter Helm repository
echo "📦 Adding Karpenter Helm repository..."
helm repo add karpenter https://charts.karpenter.sh/
helm repo update

echo "✅ Helm repository added"

# Install Karpenter using your exact command
echo "🚀 Installing Karpenter with your specified configuration..."

helm upgrade --install karpenter oci://public.ecr.aws/karpenter/karpenter \
  --version "${KARPENTER_VERSION}" \
  --namespace "${KARPENTER_NAMESPACE}" \
  --create-namespace \
  --set "settings.clusterName=${CLUSTER_NAME}" \
  --set "settings.interruptionQueue=${CLUSTER_NAME}" \
  --set controller.resources.requests.cpu=1 \
  --set controller.resources.requests.memory=1Gi \
  --set controller.resources.limits.cpu=1 \
  --set controller.resources.limits.memory=1Gi \
  --wait

echo "✅ Karpenter installation completed"

# Wait for Karpenter to be ready
echo "⏳ Waiting for Karpenter to be ready..."
kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=karpenter -n "$KARPENTER_NAMESPACE" --timeout=300s

echo "✅ Karpenter is ready"

# Verify installation
echo "🔍 Verifying Karpenter installation..."

# Check Helm release
echo "📋 Helm releases:"
helm list -n "$KARPENTER_NAMESPACE"

# Check pods
echo "📋 Karpenter pods:"
kubectl get pods -n "$KARPENTER_NAMESPACE"

# Check CRDs
echo "📋 Karpenter CRDs:"
kubectl get crd | grep karpenter

# Check service account
echo "📋 Service account:"
kubectl get serviceaccount karpenter -n "$KARPENTER_NAMESPACE" -o yaml

echo ""
echo "🎉 Karpenter installation completed successfully!"
echo "=================================="

# Apply provisioners and node templates
echo "🔧 Applying Karpenter provisioners and node templates..."

if [[ -f "karpenter_provisioners.yaml" ]]; then
    echo "📋 Applying provisioners..."
    kubectl apply -f karpenter_provisioners.yaml
    echo "✅ Provisioners applied"
else
    echo "⚠️ karpenter_provisioners.yaml not found, skipping"
fi

if [[ -f "karpenter_node_templates.yaml" ]]; then
    echo "📋 Applying node templates..."
    kubectl apply -f karpenter_node_templates.yaml
    echo "✅ Node templates applied"
else
    echo "⚠️ karpenter_node_templates.yaml not found, skipping"
fi

# Show final status
echo ""
echo "📊 Final Status:"
echo "=================================="
echo "Karpenter Version: $KARPENTER_VERSION"
echo "Namespace: $KARPENTER_NAMESPACE"
echo "Cluster: $CLUSTER_NAME"
echo "Region: $AWS_REGION"
echo ""

echo "📋 Provisioners:"
kubectl get provisioners -n "$KARPENTER_NAMESPACE"

echo ""
echo "📋 Node Templates:"
kubectl get ec2nodetemplates -n "$KARPENTER_NAMESPACE"

echo ""
echo "📋 Karpenter Controller:"
kubectl get deployment karpenter -n "$KARPENTER_NAMESPACE"

echo ""
echo "🚀 Karpenter is now ready to provision GPU nodes!"
echo ""
echo "📖 Next steps:"
echo "1. Deploy GPU workloads with appropriate node selectors"
echo "2. Monitor Karpenter logs: kubectl logs -f deployment/karpenter -n $KARPENTER_NAMESPACE"
echo "3. Check provisioned nodes: kubectl get nodes -L karpenter.sh/capacity-type"
echo "4. Monitor cost optimization: kubectl get provisioners -n $KARPETER_NAMESPACE"
echo ""
echo "💡 Example GPU workload deployment:"
echo "kubectl apply -f - <<EOF"
echo "apiVersion: v1"
echo "kind: Pod"
echo "metadata:"
echo "  name: gpu-test"
echo "spec:"
echo "  nodeSelector:"
echo "    karpenter.sh/provisioner: gpu-provisioner"
echo "  containers:"
echo "  - name: gpu-test"
echo "    image: nvidia/cuda:11.8.0-base"
echo "    resources:"
echo "      requests:"
echo "        nvidia.com/gpu: 1"
echo "      limits:"
echo "        nvidia.com/gpu: 1"
echo "    command: [\"nvidia-smi\"]"
echo "EOF"
