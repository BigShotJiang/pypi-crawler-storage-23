#!/usr/bin/env python3
"""
Microservices Architecture for Terradev
API Gateway, Provider Service, Risk Analyzer, and other services
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime
import aiohttp
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import redis
import asyncpg
from contextlib import asynccontextmanager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Shared configuration
@dataclass
class ServiceConfig:
    """Service configuration"""
    name: str
    port: int
    database_url: str
    redis_url: str
    environment: str
    log_level: str

class DatabaseManager:
    """Database connection manager"""
    
    def __init__(self, database_url: str):
        self.database_url = database_url
        self.pool = None
    
    async def initialize(self):
        """Initialize database connection pool"""
        self.pool = await asyncpg.create_pool(self.database_url)
        logger.info("Database connection pool initialized")
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            await self.pool.close()
            logger.info("Database connection pool closed")

class RedisManager:
    """Redis connection manager"""
    
    def __init__(self, redis_url: str):
        self.redis_url = redis_url
        self.client = None
    
    async def initialize(self):
        """Initialize Redis connection"""
        self.client = redis.from_url(self.redis_url, decode_responses=True)
        logger.info("Redis connection initialized")
    
    async def close(self):
        """Close Redis connection"""
        if self.client:
            await self.client.close()
            logger.info("Redis connection closed")

class BaseService:
    """Base service class"""
    
    def __init__(self, config: ServiceConfig):
        self.config = config
        self.app = FastAPI(title=config.name)
        self.db_manager = DatabaseManager(config.database_url)
        self.redis_manager = RedisManager(config.redis_url)
        
        # Setup middleware
        self.setup_middleware()
        self.setup_routes()
    
    def setup_middleware(self):
        """Setup CORS and other middleware"""
        _allowed_origins = os.getenv("CORS_ORIGINS", "https://terradev.com,https://app.terradev.com").split(",")
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=[o.strip() for o in _allowed_origins],
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            allow_headers=["Authorization", "Content-Type", "Accept"]
        )
    
    def setup_routes(self):
        """Setup basic routes"""
        
        @self.app.get("/health")
        async def health_check():
            """Health check endpoint"""
            return {"status": "healthy", "service": self.config.name, "timestamp": datetime.now().isoformat()}
        
        @self.app.get("/ready")
        async def readiness_check():
            """Readiness check endpoint"""
            try:
                # Check database connection
                if self.db_manager.pool:
                    async with self.db_manager.pool.acquire() as conn:
                        await conn.fetchval("SELECT 1")
                
                # Check Redis connection
                if self.redis_manager.client:
                    self.redis_manager.client.ping()
                
                return {"status": "ready", "service": self.config.name}
            except Exception as e:
                raise HTTPException(status_code=503, detail=f"Service not ready: {str(e)}")
        
        @self.app.get("/metrics")
        async def metrics():
            """Basic metrics endpoint"""
            return {
                "service": self.config.name,
                "timestamp": datetime.now().isoformat(),
                "environment": self.config.environment
            }
    
    async def initialize(self):
        """Initialize service"""
        await self.db_manager.initialize()
        await self.redis_manager.initialize()
        logger.info(f"{self.config.name} service initialized")
    
    async def shutdown(self):
        """Shutdown service"""
        await self.db_manager.close()
        await self.redis_manager.close()
        logger.info(f"{self.config.name} service shutdown")

class ProviderService(BaseService):
    """Provider management service"""
    
    def __init__(self, config: ServiceConfig):
        super().__init__(config)
        self.setup_provider_routes()
    
# TODO: REFACTOR - setup_provider_routes() is 101 lines long (should be <50)
# Consider breaking into smaller, focused functions
# TODO: REFACTOR - setup_provider_routes() is 101 lines long (>100)
# Consider breaking into smaller, focused functions
# Apply Single Responsibility Principle
    def setup_provider_routes(self):
        """Setup provider-specific routes"""
        
        @self.app.post("/providers/connect")
        async def connect_provider(provider_data: Dict[str, Any]):
            """Connect to a compute provider"""
            try:
                # Store provider configuration
                provider_id = provider_data.get("name")
                
                # Cache in Redis
                await self.redis_manager.client.setex(
                    f"provider:{provider_id}",
                    3600,  # 1 hour TTL
                    json.dumps(provider_data)
                )
                
                # Store in database
                async with self.db_manager.pool.acquire() as conn:
                    await conn.execute(
                        """
                        INSERT INTO providers (id, name, config, created_at)
                        VALUES ($1, $2, $3, $4)
                        ON CONFLICT (id) DO UPDATE SET
                        config = $3, updated_at = $4
                        """,
                        provider_id,
                        provider_data.get("name"),
                        json.dumps(provider_data),
                        datetime.now()
                    )
                
                return {"status": "connected", "provider_id": provider_id}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/providers")
        async def list_providers():
            """List all connected providers"""
            try:
                async with self.db_manager.pool.acquire() as conn:
                    providers = await conn.fetch(
                        "SELECT id, name, config, created_at, updated_at FROM providers"
                    )
                
                return {
                    "providers": [
                        {
                            "id": p["id"],
                            "name": p["name"],
                            "config": json.loads(p["config"]),
                            "created_at": p["created_at"].isoformat(),
                            "updated_at": p["updated_at"].isoformat() if p["updated_at"] else None
                        }
                        for p in providers
                    ]
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/providers/{provider_id}/instances")
        async def get_provider_instances(provider_id: str):
            """Get instances from a specific provider"""
            try:
                # Get provider config from cache or database
                cached_config = await self.redis_manager.client.get(f"provider:{provider_id}")
                
                if cached_config:
                    provider_config = json.loads(cached_config)
                else:
                    async with self.db_manager.pool.acquire() as conn:
                        provider = await conn.fetchrow(
                            "SELECT config FROM providers WHERE id = $1",
                            provider_id
                        )
                    
                    if not provider:
                        raise HTTPException(status_code=404, detail="Provider not found")
                    
                    provider_config = json.loads(provider["config"])
                
                # Mock instance data - would call actual provider API
                instances = [
                    {
                        "id": f"{provider_id}-instance-1",
                        "type": "p3.2xlarge",
                        "price": 3.06,
                        "region": "us-east-1",
                        "available": True
                    },
                    {
                        "id": f"{provider_id}-instance-2",
                        "type": "g4dn.xlarge",
                        "price": 0.526,
                        "region": "us-east-1",
                        "available": True
                    }
                ]
                
                return {"instances": instances}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

class RiskAnalyzerService(BaseService):
    """Risk analysis service"""
    
    def __init__(self, config: ServiceConfig):
        super().__init__(config)
# TODO: REFACTOR - setup_risk_routes() is 63 lines long (should be <50)
# Consider breaking into smaller, focused functions
        self.setup_risk_routes()
    
    def setup_risk_routes(self):
        """Setup risk analysis routes"""
        
        @self.app.post("/risk/assess")
        async def assess_risk(job_config: Dict[str, Any]):
            """Assess risk for a job configuration"""
            try:
                # Mock risk assessment
                risk_score = 0.15  # 15% risk
                risk_level = "medium"
                
                # Store assessment in database
                async with self.db_manager.pool.acquire() as conn:
                    await conn.execute(
                        """
                        INSERT INTO risk_assessments (job_id, provider, risk_score, risk_level, assessment_data, created_at)
                        VALUES ($1, $2, $3, $4, $5, $6)
                        """,
                        job_config.get("job_id"),
                        job_config.get("provider"),
                        risk_score,
                        risk_level,
                        json.dumps(job_config),
                        datetime.now()
                    )
                
                return {
                    "job_id": job_config.get("job_id"),
                    "risk_score": risk_score,
                    "risk_level": risk_level,
                    "recommendation": "Use checkpointing with 30-minute intervals"
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/risk/history/{job_id}")
        async def get_risk_history(job_id: str):
            """Get risk assessment history for a job"""
            try:
                async with self.db_manager.pool.acquire() as conn:
                    assessments = await conn.fetch(
                        """
                        SELECT risk_score, risk_level, assessment_data, created_at
                        FROM risk_assessments
                        WHERE job_id = $1
                        ORDER BY created_at DESC
                        """,
                        job_id
                    )
                
                return {
                    "job_id": job_id,
                    "assessments": [
                        {
                            "risk_score": a["risk_score"],
                            "risk_level": a["risk_level"],
                            "assessment_data": json.loads(a["assessment_data"]),
                            "created_at": a["created_at"].isoformat()
                        }
                        for a in assessments
                    ]
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

class LatencyAnalyzerService(BaseService):
    """Latency analysis service"""
    
    def __init__(self, config: ServiceConfig):
        super().__init__(config)
        self.setup_latency_routes()
    
    def setup_latency_routes(self):
        """Setup latency analysis routes"""
        
        @self.app.post("/latency/test")
        async def run_latency_test(test_config: Dict[str, Any]):
            """Run latency test for providers"""
            try:
                # Mock latency test results
                results = [
                    {
                        "provider": "aws",
                        "region": "us-east-1",
                        "latency_ms": 45.2,
                        "jitter_ms": 2.1,
                        "packet_loss": 0.1
                    },
                    {
                        "provider": "gcp",
                        "region": "us-central1",
                        "latency_ms": 52.8,
                        "jitter_ms": 3.4,
                        "packet_loss": 0.2
                    }
                ]
                
                # Cache results in Redis
                await self.redis_manager.client.setex(
                    "latency:latest",
                    300,  # 5 minutes TTL
                    json.dumps(results)
                )
                
                return {"test_id": f"test-{datetime.now().timestamp()}", "results": results}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/latency/latest")
        async def get_latest_latency():
            """Get latest latency test results"""
            try:
                cached_results = await self.redis_manager.client.get("latency:latest")
                
                if cached_results:
                    return json.loads(cached_results)
                else:
                    return {"message": "No recent latency tests found"}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

class CheckpointManagerService(BaseService):
    """Checkpoint management service"""
    
# TODO: REFACTOR - setup_checkpoint_routes() is 61 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def __init__(self, config: ServiceConfig):
        super().__init__(config)
        self.setup_checkpoint_routes()
    
    def setup_checkpoint_routes(self):
        """Setup checkpoint management routes"""
        
        @self.app.post("/checkpoint/plan")
        async def create_checkpoint_plan(job_config: Dict[str, Any]):
            """Create checkpoint plan for a job"""
            try:
                # Mock checkpoint plan
                plan = {
                    "job_id": job_config.get("job_id"),
                    "strategy": "adaptive",
                    "intervals": [30, 60, 90, 120, 180, 240],
                    "estimated_checkpoints": 6,
                    "total_checkpoint_time": 30.0,
                    "risk_mitigation": 0.8
                }
                
                # Store plan in database
                async with self.db_manager.pool.acquire() as conn:
                    await conn.execute(
                        """
                        INSERT INTO checkpoint_plans (job_id, plan_data, created_at)
                        VALUES ($1, $2, $3)
                        ON CONFLICT (job_id) DO UPDATE SET
                        plan_data = $2, updated_at = $3
                        """,
                        plan["job_id"],
                        json.dumps(plan),
                        datetime.now()
                    )
                
                return plan
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/checkpoint/execute")
        async def execute_checkpoint(checkpoint_data: Dict[str, Any]):
            """Execute checkpoint for a job"""
            try:
                # Mock checkpoint execution
                checkpoint_id = f"checkpoint-{datetime.now().timestamp()}"
                
                # Store checkpoint record
                async with self.db_manager.pool.acquire() as conn:
                    await conn.execute(
                        """
                        INSERT INTO checkpoints (id, job_id, status, created_at)
                        VALUES ($1, $2, $3, $4)
                        """,
                        checkpoint_id,
                        checkpoint_data.get("job_id"),
                        "completed",
                        datetime.now()
                    )
                
                return {
                    "checkpoint_id": checkpoint_id,
                    "status": "completed",
                    "duration_seconds": 120
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

class APIGateway(BaseService):
    """API Gateway service"""
    
    def __init__(self, config: ServiceConfig):
        super().__init__(config)
        self.setup_gateway_routes()
    
    def setup_gateway_routes(self):
        """Setup gateway routes"""
        
        @self.app.get("/api/status")
        async def get_system_status():
            """Get overall system status"""
            try:
                # Check all services
                services = {
                    "provider-service": "http://terradev-provider-service:80/health",
                    "risk-analyzer": "http://terradev-risk-analyzer:80/health",
                    "latency-analyzer": "http://terradev-latency-analyzer:80/health",
                    "checkpoint-manager": "http://terradev-checkpoint-manager:80/health",
                    "webapp": "http://terradev-webapp:80/health"
                }
                
                status = {}
                async with aiohttp.ClientSession() as session:
                    for service, url in services.items():
                        try:
                            async with session.get(url) as response:
                                status[service] = "healthy" if response.status == 200 else "unhealthy"
                        except Exception as e:
                            status[service] = "unreachable"
                
                return {"services": status, "timestamp": datetime.now().isoformat()}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/api/providers")
        async def proxy_providers():
            """Proxy to provider service"""
            return await self.proxy_request("http://terradev-provider-service:80/providers")
        
        @self.app.post("/api/risk/assess")
        async def proxy_risk_assess(job_config: Dict[str, Any]):
            """Proxy to risk analyzer"""
            return await self.proxy_request("http://terradev-risk-analyzer:80/risk/assess", "POST", job_config)
        
        @self.app.post("/api/latency/test")
        async def proxy_latency_test(test_config: Dict[str, Any]):
            """Proxy to latency analyzer"""
            return await self.proxy_request("http://terradev-latency-analyzer:80/latency/test", "POST", test_config)
        
        @self.app.post("/api/checkpoint/plan")
        async def proxy_checkpoint_plan(job_config: Dict[str, Any]):
            """Proxy to checkpoint manager"""
            return await self.proxy_request("http://terradev-checkpoint-manager:80/checkpoint/plan", "POST", job_config)
    
    async def proxy_request(self, url: str, method: str = "GET", data: Dict[str, Any] = None):
        """Proxy request to microservice"""
        try:
            async with aiohttp.ClientSession() as session:
                if method == "GET":
                    async with session.get(url) as response:
                        return await response.json()
                elif method == "POST":
                    async with session.post(url, json=data) as response:
                        return await response.json()
        except Exception as e:
            raise HTTPException(status_code=503, detail=f"Service unavailable: {str(e)}")

# Database initialization
async def initialize_database(database_url: str):
    """Initialize database tables"""
    conn = await asyncpg.connect(database_url)
    
    # Create tables
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS providers (
            id VARCHAR(255) PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            config JSONB NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP
        )
    """)
    
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS risk_assessments (
            id SERIAL PRIMARY KEY,
            job_id VARCHAR(255) NOT NULL,
            provider VARCHAR(255) NOT NULL,
            risk_score FLOAT NOT NULL,
            risk_level VARCHAR(50) NOT NULL,
            assessment_data JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS checkpoint_plans (
            job_id VARCHAR(255) PRIMARY KEY,
            plan_data JSONB NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP
        )
    """)
    
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS checkpoints (
            id VARCHAR(255) PRIMARY KEY,
            job_id VARCHAR(255) NOT NULL,
            status VARCHAR(50) NOT NULL,
            checkpoint_data JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    await conn.close()
    logger.info("Database tables initialized")

# Service factory
def create_service(service_type: str, config: ServiceConfig):
    """Create service instance"""
    services = {
        "provider": ProviderService,
        "risk-analyzer": RiskAnalyzerService,
        "latency-analyzer": LatencyAnalyzerService,
        "checkpoint-manager": CheckpointManagerService,
        "api-gateway": APIGateway
    }
    
    return services[service_type](config)

# Main execution functions
async def run_provider_service():
    """Run provider service"""
    config = ServiceConfig(
        name="provider-service",
        port=8081,
        database_url="postgresql://user:pass@localhost:5432/terradev",
        redis_url="redis://localhost:6379",
        environment="development",
        log_level="info"
    )
    
    service = create_service("provider", config)
    await service.initialize()
    
    config = uvicorn.Config(
        app=service.app,
        host="0.0.0.0",
        port=config.port,
        log_level=config.log_level
    )
    server = uvicorn.Server(config)
    
    try:
        await server.serve()
    finally:
        await service.shutdown()

async def run_risk_analyzer_service():
    """Run risk analyzer service"""
    config = ServiceConfig(
        name="risk-analyzer",
        port=8082,
        database_url="postgresql://user:pass@localhost:5432/terradev",
        redis_url="redis://localhost:6379",
        environment="development",
        log_level="info"
    )
    
    service = create_service("risk-analyzer", config)
    await service.initialize()
    
    config = uvicorn.Config(
        app=service.app,
        host="0.0.0.0",
        port=config.port,
        log_level=config.log_level
    )
    server = uvicorn.Server(config)
    
    try:
        await server.serve()
    finally:
        await service.shutdown()

async def run_api_gateway():
    """Run API gateway"""
    config = ServiceConfig(
        name="api-gateway",
        port=8080,
        database_url="postgresql://user:pass@localhost:5432/terradev",
        redis_url="redis://localhost:6379",
        environment="development",
        log_level="info"
    )
    
    service = create_service("api-gateway", config)
    await service.initialize()
    
    config = uvicorn.Config(
        app=service.app,
        host="0.0.0.0",
        port=config.port,
        log_level=config.log_level
    )
    server = uvicorn.Server(config)
    
    try:
        await server.serve()
    finally:
        await service.shutdown()

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        service_name = sys.argv[1]
        
        if service_name == "provider":
            asyncio.run(run_provider_service())
        elif service_name == "risk-analyzer":
            asyncio.run(run_risk_analyzer_service())
        elif service_name == "api-gateway":
            asyncio.run(run_api_gateway())
        else:
            logging.info(f"Unknown service: {service_name}")
            logging.info("Available services: provider, risk-analyzer, api-gateway")
    else:
        logging.info("Usage: python microservices.py <service-name>")
        logging.info("Available services: provider, risk-analyzer, api-gateway")
