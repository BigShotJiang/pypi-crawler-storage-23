#!/usr/bin/env python3
"""
Production Configuration Management
Secure configuration with environment variables and secrets management
"""

import os
import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass
from pathlib import Path
import json
from cryptography.fernet import Fernet
import hashlib
import base64

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DatabaseConfig:
    """Database configuration"""
    host: str
    port: int
    database: str
    username: str
    password: str
    ssl_mode: str = "require"
    pool_size: int = 20
    max_overflow: int = 30

@dataclass
class RedisConfig:
    """Redis configuration"""
    host: str
    port: int
    password: Optional[str]
    db: int = 0
    ssl: bool = True
    max_connections: int = 100

@dataclass
class SecurityConfig:
    """Security configuration"""
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    bcrypt_rounds: int = 12

@dataclass
class ProviderConfig:
    """Provider configuration"""
    name: str
    api_key: str
    api_secret: Optional[str]
    region: str
    endpoint: Optional[str]
    timeout: int = 30
    retry_attempts: int = 3
    retry_delay: float = 1.0

class ConfigManager:
    """Production configuration manager with security"""
    
    def __init__(self, config_file: str = "production_config.json"):
        self.config_file = Path(config_file)
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher_suite = Fernet(self.encryption_key)
        self._config_cache = {}
        
    def _get_or_create_encryption_key(self) -> bytes:
        """Get or create encryption key for sensitive data"""
        key_file = Path(".encryption_key")
        
        if key_file.exists():
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(key)
            # Set file permissions (owner only)
            key_file.chmod(0o600)
            return key
    
    def _encrypt_value(self, value: str) -> str:
        """Encrypt sensitive value"""
        if not value:
            return ""
        encrypted = self.cipher_suite.encrypt(value.encode())
        return base64.b64encode(encrypted).decode()
    
    def _decrypt_value(self, encrypted_value: str) -> str:
        """Decrypt sensitive value"""
        if not encrypted_value:
            return ""
        try:
            encrypted_bytes = base64.b64decode(encrypted_value.encode())
            decrypted = self.cipher_suite.decrypt(encrypted_bytes)
            return decrypted.decode()
        except Exception as e:
            logger.error(f"Failed to decrypt value: {e}")
            return ""
    
    def get_database_config(self) -> DatabaseConfig:
        """Get database configuration from environment variables"""
        return DatabaseConfig(
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "5432")),
            database=os.getenv("DB_NAME", "terradev"),
            username=os.getenv("DB_USERNAME", "terradev_user"),
            password=os.getenv("DB_PASSWORD", ""),
            ssl_mode=os.getenv("DB_SSL_MODE", "require"),
            pool_size=int(os.getenv("DB_POOL_SIZE", "20")),
            max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "30"))
        )
    
    def get_redis_config(self) -> RedisConfig:
        """Get Redis configuration from environment variables"""
        return RedisConfig(
            host=os.getenv("REDIS_HOST", "localhost"),
            port=int(os.getenv("REDIS_PORT", "6379")),
            password=os.getenv("REDIS_PASSWORD"),
            db=int(os.getenv("REDIS_DB", "0")),
            ssl=os.getenv("REDIS_SSL", "true").lower() == "true",
            max_connections=int(os.getenv("REDIS_MAX_CONNECTIONS", "100"))
        )
    
    def get_security_config(self) -> SecurityConfig:
        """Get security configuration from environment variables"""
        secret_key = os.getenv("SECRET_KEY")
        if not secret_key:
            # Generate a secure secret key
            secret_key = base64.b64encode(os.urandom(32)).decode()
            logger.warning("Generated new SECRET_KEY - please set it in environment")
        
        return SecurityConfig(
            secret_key=secret_key,
            algorithm=os.getenv("JWT_ALGORITHM", "HS256"),
            access_token_expire_minutes=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30")),
            refresh_token_expire_days=int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7")),
            bcrypt_rounds=int(os.getenv("BCRYPT_ROUNDS", "12"))
        )
    
# TODO: REFACTOR - get_provider_configs() is 95 lines long (should be <50)
# Consider breaking into smaller, focused functions
    def get_provider_configs(self) -> Dict[str, ProviderConfig]:
        """Get provider configurations from environment variables"""
        providers = {}
        
        # AWS Configuration
        if os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY"):
            providers["aws"] = ProviderConfig(
                name="aws",
                api_key=os.getenv("AWS_ACCESS_KEY_ID"),
                api_secret=os.getenv("AWS_SECRET_ACCESS_KEY"),
                region=os.getenv("AWS_REGION", "us-east-1"),
                endpoint=os.getenv("AWS_ENDPOINT"),
                timeout=int(os.getenv("AWS_TIMEOUT", "30")),
                retry_attempts=int(os.getenv("AWS_RETRY_ATTEMPTS", "3")),
                retry_delay=float(os.getenv("AWS_RETRY_DELAY", "1.0"))
            )
        
        # GCP Configuration
        if os.getenv("GCP_PROJECT_ID") and os.getenv("GCP_SERVICE_ACCOUNT_KEY"):
            providers["gcp"] = ProviderConfig(
                name="gcp",
                api_key=os.getenv("GCP_PROJECT_ID"),
                api_secret=os.getenv("GCP_SERVICE_ACCOUNT_KEY"),
                region=os.getenv("GCP_REGION", "us-central1"),
                endpoint=os.getenv("GCP_ENDPOINT"),
                timeout=int(os.getenv("GCP_TIMEOUT", "30")),
                retry_attempts=int(os.getenv("GCP_RETRY_ATTEMPTS", "3")),
                retry_delay=float(os.getenv("GCP_RETRY_DELAY", "1.0"))
            )
        
        # Azure Configuration
        if os.getenv("AZURE_CLIENT_ID") and os.getenv("AZURE_CLIENT_SECRET"):
            providers["azure"] = ProviderConfig(
                name="azure",
                api_key=os.getenv("AZURE_CLIENT_ID"),
                api_secret=os.getenv("AZURE_CLIENT_SECRET"),
                region=os.getenv("AZURE_REGION", "eastus"),
                endpoint=os.getenv("AZURE_ENDPOINT"),
                timeout=int(os.getenv("AZURE_TIMEOUT", "30")),
                retry_attempts=int(os.getenv("AZURE_RETRY_ATTEMPTS", "3")),
                retry_delay=float(os.getenv("AZURE_RETRY_DELAY", "1.0"))
            )
        
        # OCI Configuration
        if os.getenv("OCI_TENANCY_OCID") and os.getenv("OCI_USER_OCID"):
            providers["oci"] = ProviderConfig(
                name="oci",
                api_key=os.getenv("OCI_USER_OCID"),
                api_secret=os.getenv("OCI_PRIVATE_KEY_PATH"),
                region=os.getenv("OCI_REGION", "us-ashburn-1"),
                endpoint=os.getenv("OCI_ENDPOINT"),
                timeout=int(os.getenv("OCI_TIMEOUT", "30")),
                retry_attempts=int(os.getenv("OCI_RETRY_ATTEMPTS", "3")),
                retry_delay=float(os.getenv("OCI_RETRY_DELAY", "1.0"))
            )
        
        # HuggingFace Configuration
        if os.getenv("HUGGINGFACE_TOKEN"):
            providers["huggingface"] = ProviderConfig(
                name="huggingface",
                api_key=os.getenv("HUGGINGFACE_TOKEN"),
                api_secret=None,
                region="global",
                endpoint="https://huggingface.co",
                timeout=int(os.getenv("HF_TIMEOUT", "30")),
                retry_attempts=int(os.getenv("HF_RETRY_ATTEMPTS", "3")),
                retry_delay=float(os.getenv("HF_RETRY_DELAY", "1.0"))
            )
        
        # Vast.ai Configuration
        if os.getenv("VAST_API_KEY"):
            providers["vast"] = ProviderConfig(
                name="vast",
                api_key=os.getenv("VAST_API_KEY"),
                api_secret=None,
                region="global",
                endpoint="https://console.vast.ai/api/v0",
                timeout=int(os.getenv("VAST_TIMEOUT", "30")),
                retry_attempts=int(os.getenv("VAST_RETRY_ATTEMPTS", "3")),
                retry_delay=float(os.getenv("VAST_RETRY_DELAY", "1.0"))
            )
        
        # RunPod Configuration
        if os.getenv("RUNPOD_API_KEY"):
            providers["runpod"] = ProviderConfig(
                name="runpod",
                api_key=os.getenv("RUNPOD_API_KEY"),
                api_secret=None,
                region="global",
                endpoint="https://api.runpod.io",
                timeout=int(os.getenv("RUNPOD_TIMEOUT", "30")),
                retry_attempts=int(os.getenv("RUNPOD_RETRY_ATTEMPTS", "3")),
                retry_delay=float(os.getenv("RUNPOD_RETRY_DELAY", "1.0"))
            )
        
        return providers
    
    def save_encrypted_config(self, config_data: Dict[str, Any]) -> None:
        """Save encrypted configuration to file"""
        encrypted_data = {}
        
        for key, value in config_data.items():
            if isinstance(value, str) and any(secret in key.lower() for secret in ["key", "secret", "password", "token"]):
                encrypted_data[key] = self._encrypt_value(value)
            else:
                encrypted_data[key] = value
        
        with open(self.config_file, 'w') as f:
            json.dump(encrypted_data, f, indent=2)
        
        # Set file permissions (owner only)
        self.config_file.chmod(0o600)
        logger.info(f"Encrypted configuration saved to {self.config_file}")
    
    def load_encrypted_config(self) -> Dict[str, Any]:
        """Load and decrypt configuration from file"""
        if not self.config_file.exists():
            return {}
        
        try:
            with open(self.config_file, 'r') as f:
                encrypted_data = json.load(f)
            
            decrypted_data = {}
            for key, value in encrypted_data.items():
                if isinstance(value, str) and any(secret in key.lower() for secret in ["key", "secret", "password", "token"]):
                    decrypted_data[key] = self._decrypt_value(value)
                else:
                    decrypted_data[key] = value
            
            return decrypted_data
        except Exception as e:
            logger.error(f"Failed to load encrypted config: {e}")
            return {}
    
    def validate_config(self) -> bool:
        """Validate configuration completeness"""
        required_vars = [
            "DB_HOST", "DB_PORT", "DB_NAME", "DB_USERNAME", "DB_PASSWORD",
            "REDIS_HOST", "REDIS_PORT",
            "SECRET_KEY"
        ]
        
        missing_vars = []
        for var in required_vars:
            if not os.getenv(var):
                missing_vars.append(var)
        
        if missing_vars:
            logger.error(f"Missing required environment variables: {missing_vars}")
            return False
        
        return True

# Global configuration instance
config_manager = ConfigManager()

# Convenience functions
def get_db_config() -> DatabaseConfig:
    """Get database configuration"""
    return config_manager.get_database_config()

def get_redis_config() -> RedisConfig:
    """Get Redis configuration"""
    return config_manager.get_redis_config()

def get_security_config() -> SecurityConfig:
    """Get security configuration"""
    return config_manager.get_security_config()

def get_provider_configs() -> Dict[str, ProviderConfig]:
    """Get provider configurations"""
    return config_manager.get_provider_configs()

def validate_production_config() -> bool:
    """Validate production configuration"""
    return config_manager.validate_config()

if __name__ == "__main__":
    # Test configuration management
    logging.info("🔧 Testing Production Configuration Management")
    logging.info("=" * 50)
    
    # Validate configuration
    if validate_production_config():
        logging.info("✅ Configuration validation passed")
    else:
        logging.info("❌ Configuration validation failed")
        logging.info("Please set required environment variables")
    
    # Test database config
    db_config = get_db_config()
    logging.info(f"\n🗄️ Database Config:")
    logging.info(f"   Host: {db_config.host}")
    logging.info(f"   Port: {db_config.port}")
    logging.info(f"   Database: {db_config.database}")
    logging.info(f"   Username: {db_config.username}")
    logging.info(f"   SSL Mode: {db_config.ssl_mode}")
    
    # Test Redis config
    redis_config = get_redis_config()
    logging.info(f"\n🔴 Redis Config:")
    logging.info(f"   Host: {redis_config.host}")
    logging.info(f"   Port: {redis_config.port}")
    logging.info(f"   DB: {redis_config.db}")
    logging.info(f"   SSL: {redis_config.ssl}")
    
    # Test security config
    security_config = get_security_config()
    logging.info(f"\n🔐 Security Config:")
    logging.info(f"   Algorithm: {security_config.algorithm}")
    logging.info(f"   Access Token Expire: {security_config.access_token_expire_minutes} minutes")
    logging.info(f"   Refresh Token Expire: {security_config.refresh_token_expire_days} days")
    
    # Test provider configs
    provider_configs = get_provider_configs()
    logging.info(f"\n🌐 Provider Configs:")
    for provider, config in provider_configs.items():
        logging.info(f"   {provider}: {config.region}")
    
    logging.info(f"\n✅ Configuration management test completed!")
