"""
Unit tests for Terradev Arbitrage Engine
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timedelta
from typing import Dict, Any

from enhanced_arbitrage_engine import EnhancedArbitrageEngine, EnhancedArbitrageOpportunity
from complete_arbitrage_engine import ArbitrageEngine, ArbitrageOpportunity, InstanceInfo, Provider, GPUType
from advanced_risk_engine import AdvancedRiskEngine, AdvancedRiskMetrics
@pytest.mark.unit
class TestArbitrageEngine:
    """Test cases for core arbitrage engine"""
    
    @pytest.fixture
    def arbitrage_engine(self):
        """Create arbitrage engine instance for testing"""
        
        engine = ArbitrageEngine()
        # Mock external dependencies
        engine.aws_client = Mock()
        engine.gcp_client = Mock()
        engine.azure_client = Mock()
        engine.runpod_client = Mock()
        engine.lambda_client = Mock()
        engine.coreweave_client = Mock()
        
        return engine
    
    @pytest.fixture
    def sample_instances(self):
        """Sample instance data for testing"""
        
        return {
            Provider.AWS: [
                InstanceInfo(
                    provider=Provider.AWS,
                    instance_type="p4d.24xlarge",
                    gpu_type=GPUType.A100,
                    gpu_count=8,
                    price_per_hour=1.22,
                    spot_price=1.22,
                    region="us-west-2",
                    availability="available",
                    cpu_cores=96,
                    memory_gb=1152,
                    storage_gb=8192,
                    network_performance="100 Gbps"
                ),
                InstanceInfo(
                    provider=Provider.AWS,
                    instance_type="p5.48xlarge",
                    gpu_type=GPUType.H100,
                    gpu_count=8,
                    price_per_hour=2.16,
                    spot_price=2.16,
                    region="us-west-2",
                    availability="available",
                    cpu_cores=192,
                    memory_gb=2048,
                    storage_gb=32768,
                    network_performance="200 Gbps"
                )
            ],
            Provider.RUNPOD: [
                InstanceInfo(
                    provider=Provider.RUNPOD,
                    instance_type="A100-40GB",
                    gpu_type=GPUType.A100,
                    gpu_count=1,
                    price_per_hour=0.89,
                    spot_price=0.89,
                    region="us-west-2",
                    availability="available",
                    cpu_cores=12,
                    memory_gb=85,
                    storage_gb=500,
                    network_performance="10 Gbps"
                )
            ]
        }
    
    @pytest.mark.asyncio
    async def test_scan_provider_aws(self, arbitrage_engine, sample_instances):
        """Test scanning AWS provider"""
        
        # Mock AWS API response
        arbitrage_engine.aws_client.describe_spot_price_history.return_value = {
            'SpotPriceHistory': [
                {
                    'InstanceType': 'p4d.24xlarge',
                    'SpotPrice': '1.22',
                    'AvailabilityZone': 'us-west-2a',
                    'Timestamp': datetime.utcnow(),
                    'ProductDescription': 'Linux/UNIX'
                },
                {
                    'InstanceType': 'p5.48xlarge',
                    'SpotPrice': '2.16',
                    'AvailabilityZone': 'us-west-2a',
                    'Timestamp': datetime.utcnow(),
                    'ProductDescription': 'Linux/UNIX'
                }
            ]
        }
        
        instances = await arbitrage_engine.scan_provider(Provider.AWS)
        
        assert len(instances) > 0
        assert all(instance.provider == Provider.AWS for instance in instances)
        assert all(instance.gpu_type in [GPUType.A100, GPUType.H100] for instance in instances)
        
        # Verify API was called
        arbitrage_engine.aws_client.describe_spot_price_history.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_scan_provider_runpod(self, arbitrage_engine):
        """Test scanning RunPod provider"""
        
        # Mock RunPod API response
        mock_response = Mock()
        mock_response.json.return_value = {
            'data': [
                {
                    'id': 'a100-40gb',
                    'name': 'A100 40GB',
                    'price': 0.89,
                    'gpu': 'A100',
                    'gpuMemory': '40GB',
                    'status': 'available'
                }
            ]
        }
        
        arbitrage_engine.runpod_client.get.return_value = mock_response
        
        instances = await arbitrage_engine.scan_provider(Provider.RUNPOD)
        
        assert len(instances) > 0
        assert all(instance.provider == Provider.RUNPOD for instance in instances)
        
        # Verify API was called
        arbitrage_engine.runpod_client.get.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_find_arbitrage_opportunities(self, arbitrage_engine, sample_instances):
        """Test finding arbitrage opportunities"""
        
        # Mock the scan_all_providers method
        arbitrage_engine.scan_all_providers = AsyncMock(return_value=sample_instances)
        
        opportunities = await arbitrage_engine.find_arbitrage_opportunities(GPUType.A100)
        
        assert len(opportunities) > 0
        assert all(isinstance(opp, ArbitrageOpportunity) for opp in opportunities)
        assert all(opp.gpu_type == GPUType.A100 for opp in opportunities)
        
        # Verify opportunities are sorted by price
        prices = [opp.final_price for opp in opportunities]
        assert prices == sorted(prices)
    
    @pytest.mark.asyncio
    async def test_calculate_savings_percentage(self, arbitrage_engine):
        """Test savings percentage calculation"""
        
        on_demand_price = 4.06
        spot_price = 1.22
        
        savings = arbitrage_engine.calculate_savings_percentage(on_demand_price, spot_price)
        
        expected_savings = ((on_demand_price - spot_price) / on_demand_price) * 100
        assert abs(savings - expected_savings) < 0.01
    
    def test_filter_by_budget(self, arbitrage_engine, sample_instances):
        """Test filtering instances by budget"""
        
        max_budget = 2.0
        filtered_instances = arbitrage_engine.filter_by_budget(
            list(sample_instances.values())[0], max_budget
        )
        
        assert all(instance.spot_price <= max_budget for instance in filtered_instances)
    
    def test_filter_by_availability(self, arbitrage_engine, sample_instances):
        """Test filtering instances by availability"""
        
        # Mark some instances as unavailable
        instances = list(sample_instances.values())[0]
        instances[0].availability = "unavailable"
        
        filtered_instances = arbitrage_engine.filter_by_availability(instances)
        
        assert all(instance.availability == "available" for instance in filtered_instances)

@pytest.mark.unit
class TestEnhancedArbitrageEngine:
    """Test cases for enhanced arbitrage engine"""
    
    @pytest.fixture
    def enhanced_engine(self):
        """Create enhanced arbitrage engine instance"""
        
        engine = EnhancedArbitrageEngine()
        # Mock dependencies
        engine.base_engine = Mock()
        engine.advanced_risk_engine = Mock()
        engine.vast_integration = Mock()
        
        return engine
    
    @pytest.fixture
    def sample_base_opportunities(self):
        """Sample base arbitrage opportunities"""
        
        return [
            ArbitrageOpportunity(
                provider=Provider.AWS,
                instance_type="p4d.24xlarge",
                gpu_type=GPUType.A100,
                base_price=4.06,
                spot_price=1.22,
                final_price=1.22,
                confidence_score=0.85,
                success_probability=0.90,
                risk_level="low",
                instance_info=Mock()
            ),
            ArbitrageOpportunity(
                provider=Provider.RUNPOD,
                instance_type="A100-40GB",
                gpu_type=GPUType.A100,
                base_price=2.50,
                spot_price=0.89,
                final_price=0.89,
                confidence_score=0.78,
                success_probability=0.85,
                risk_level="medium",
                instance_info=Mock()
            )
        ]
    
    @pytest.fixture
    def sample_risk_metrics(self):
        """Sample risk metrics"""
        
        return AdvancedRiskMetrics(
            var_95=0.15,
            expected_shortfall=0.22,
            max_drawdown=0.08,
            sharpe_ratio=2.5,
            beta=0.85,
            correlation_risk=0.25,
            liquidity_risk=0.10,
            greeks={
                "delta": 0.75,
                "gamma": 0.15,
                "theta": -0.05,
                "vega": 0.25
            }
        )
    
    @pytest.fixture
    def sample_volatility_metrics(self):
        """Sample volatility metrics"""
        
        return {
            "daily_volatility": 0.15,
            "annualized_volatility": 0.89,
            "mean_reversion_rate": 0.05,
            "price_trend": "stable",
            "volatility_forecast": 0.12
        }
    
    @pytest.mark.asyncio
    async def test_find_enhanced_arbitrage_opportunities(
        self, enhanced_engine, sample_base_opportunities, 
        sample_risk_metrics, sample_volatility_metrics
    ):
        """Test finding enhanced arbitrage opportunities"""
        
        # Mock base engine
        enhanced_engine.base_engine.scan_all_providers.return_value = {}
        enhanced_engine.base_engine.find_arbitrage_opportunities.return_value = sample_base_opportunities
        
        # Mock risk engine
        enhanced_engine.advanced_risk_engine.calculate_risk_metrics.return_value = sample_risk_metrics
        
        opportunities = await enhanced_engine.find_enhanced_arbitrage_opportunities(
            GPUType.A100, max_results=10
        )
        
        assert len(opportunities) > 0
        assert all(isinstance(opp, EnhancedArbitrageOpportunity) for opp in opportunities)
        assert all(hasattr(opp, 'risk_adjusted_price') for opp in opportunities)
        assert all(hasattr(opp, 'volatility_adjusted_price') for opp in opportunities)
        assert all(hasattr(opp, 'greeks') for opp in opportunities)
    
    def test_calculate_risk_adjusted_price(self, enhanced_engine):
        """Test risk-adjusted price calculation"""
        
        base_price = 1.22
        risk_metrics = AdvancedRiskMetrics(
            var_95=0.15,
            expected_shortfall=0.22,
            liquidity_risk=0.10,
            correlation_risk=0.25
        )
        
        risk_adjusted_price = enhanced_engine._calculate_risk_adjusted_price(
            base_price, risk_metrics
        )
        
        # Risk-adjusted price should be higher than base price due to risk
        assert risk_adjusted_price >= base_price
    
    def test_calculate_volatility_adjusted_price(self, enhanced_engine):
        """Test volatility-adjusted price calculation"""
        
        base_price = 1.22
        volatility_metrics = {
            "daily_volatility": 0.15,
            "annualized_volatility": 0.89,
            "volatility_forecast": 0.12
        }
        
        volatility_adjusted_price = enhanced_engine._calculate_volatility_adjusted_price(
            base_price, volatility_metrics
        )
        
        # Volatility adjustment should modify the price
        assert isinstance(volatility_adjusted_price, float)
    
    def test_calculate_greeks(self, enhanced_engine):
        """Test Greeks calculation"""
        
        opportunity = Mock()
        opportunity.base_price = 1.22
        opportunity.spot_price = 1.22
        opportunity.volatility = 0.15
        opportunity.time_to_expiry = 30  # days
        
        greeks = enhanced_engine._calculate_greeks(opportunity)
        
        assert "delta" in greeks
        assert "gamma" in greeks
        assert "theta" in greeks
        assert "vega" in greeks
        assert "rho" in greeks
        
        # Verify Greeks are numeric
        for greek_value in greeks.values():
            assert isinstance(greek_value, (int, float))
    
    def test_calculate_confidence_score(self, enhanced_engine):
        """Test confidence score calculation"""
        
        risk_score = 0.3
        volatility_score = 0.2
        liquidity_score = 0.8
        correlation_score = 0.25
        
        confidence = enhanced_engine._calculate_confidence_score(
            risk_score, volatility_score, liquidity_score, correlation_score
        )
        
        assert 0 <= confidence <= 1
        assert isinstance(confidence, float)
    
    @pytest.mark.asyncio
    async def test_should_deploy_opportunity(self, enhanced_engine):
        """Test deployment decision logic"""
        
        # Create opportunity with high confidence
        opportunity = EnhancedArbitrageOpportunity(
            provider=Provider.AWS,
            instance_type="p4d.24xlarge",
            gpu_type=GPUType.A100,
            base_price=4.06,
            risk_adjusted_price=1.25,
            volatility_adjusted_price=1.28,
            tou_adjusted_price=1.30,
            final_adjusted_price=1.30,
            success_probability=0.90,
            confidence_score=0.85,
            latency_score=0.80,
            total_score=0.82,
            greeks={"delta": 0.75, "gamma": 0.15},
            volatility_metrics={"daily_volatility": 0.15},
            risk_metrics={"var_95": 0.15},
            tou_multiplier=1.02,
            var_95=0.15,
            expected_shortfall=0.22,
            liquidity_risk=0.10,
            correlation_risk=0.25,
            reasoning=["Low risk", "High availability"],
            instance_info=Mock()
        )
        
        should_deploy = enhanced_engine.should_deploy_opportunity(opportunity)
        
        assert should_deploy is True
        
        # Test with low confidence opportunity
        opportunity.confidence_score = 0.3
        should_deploy = enhanced_engine.should_deploy_opportunity(opportunity)
        
        assert should_deploy is False

@pytest.mark.unit
class TestAdvancedRiskEngine:
    """Test cases for advanced risk engine"""
    
    @pytest.fixture
    def risk_engine(self):
        """Create risk engine instance"""
        
        engine = AdvancedRiskEngine()
        # Mock external dependencies
        engine.market_data_client = Mock()
        engine.correlation_matrix = Mock()
        
        return engine
    
    @pytest.fixture
    def sample_price_history(self):
        """Sample price history data"""
        
        return [
            1.20, 1.22, 1.25, 1.18, 1.21, 1.23, 1.19, 1.24, 1.26, 1.22,
            1.20, 1.18, 1.25, 1.27, 1.23, 1.21, 1.19, 1.22, 1.24, 1.20
        ]
    
    def test_calculate_var(self, risk_engine, sample_price_history):
        """Test Value at Risk calculation"""
        
        var_95 = risk_engine.calculate_var(sample_price_history, confidence_level=0.95)
        
        assert isinstance(var_95, float)
        assert var_95 >= 0  # VaR should be positive (loss)
    
    def test_calculate_expected_shortfall(self, risk_engine, sample_price_history):
        """Test Expected Shortfall calculation"""
        
        es = risk_engine.calculate_expected_shortfall(sample_price_history, confidence_level=0.95)
        
        assert isinstance(es, float)
        assert es >= 0  # Expected shortfall should be positive
    
    def test_calculate_sharpe_ratio(self, risk_engine, sample_price_history):
        """Test Sharpe ratio calculation"""
        
        sharpe = risk_engine.calculate_sharpe_ratio(sample_price_history, risk_free_rate=0.02)
        
        assert isinstance(sharpe, float)
        # Sharpe ratio can be positive or negative
    
    def test_calculate_maximum_drawdown(self, risk_engine, sample_price_history):
        """Test Maximum Drawdown calculation"""
        
        max_dd = risk_engine.calculate_maximum_drawdown(sample_price_history)
        
        assert isinstance(max_dd, float)
        assert max_dd >= 0  # Drawdown should be positive
        assert max_dd <= 1  # Drawdown should not exceed 100%
    
    def test_calculate_beta(self, risk_engine):
        """Test Beta calculation"""
        
        asset_returns = [0.02, 0.01, -0.01, 0.03, 0.02]
        market_returns = [0.01, 0.02, -0.01, 0.02, 0.01]
        
        beta = risk_engine.calculate_beta(asset_returns, market_returns)
        
        assert isinstance(beta, float)
    
    def test_calculate_correlation_risk(self, risk_engine):
        """Test correlation risk calculation"""
        
        correlation_matrix = {
            "aws": {"aws": 1.0, "gcp": 0.7, "runpod": 0.5},
            "gcp": {"aws": 0.7, "gcp": 1.0, "runpod": 0.6},
            "runpod": {"aws": 0.5, "gcp": 0.6, "runpod": 1.0}
        }
        
        correlation_risk = risk_engine.calculate_correlation_risk(
            correlation_matrix, provider="aws"
        )
        
        assert isinstance(correlation_risk, float)
        assert 0 <= correlation_risk <= 1
    
    @pytest.mark.asyncio
    async def test_calculate_comprehensive_risk_metrics(
        self, risk_engine, sample_price_history
    ):
        """Test comprehensive risk metrics calculation"""
        
        metrics = await risk_engine.calculate_risk_metrics(
            sample_price_history, provider="aws", gpu_type="a100"
        )
        
        assert isinstance(metrics, AdvancedRiskMetrics)
        assert hasattr(metrics, 'var_95')
        assert hasattr(metrics, 'expected_shortfall')
        assert hasattr(metrics, 'sharpe_ratio')
        assert hasattr(metrics, 'beta')
        assert hasattr(metrics, 'correlation_risk')
        assert hasattr(metrics, 'liquidity_risk')
        assert hasattr(metrics, 'greeks')

# Integration test markers
@pytest.mark.integration
class TestArbitrageEngineIntegration:
    """Integration tests for arbitrage engine"""
    
    @pytest.mark.asyncio
    async def test_end_to_end_arbitrage_analysis(self):
        """Test complete arbitrage analysis workflow"""
        
        # This would be a more comprehensive integration test
        # that tests the entire workflow from data collection
        # to opportunity identification
        
        pass  # Implementation would depend on actual integration setup
