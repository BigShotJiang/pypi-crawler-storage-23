"""
Pytest configuration and fixtures for Terradev testing
"""

import asyncio
import json
import os
import pytest
import tempfile
from datetime import datetime, timedelta
from typing import Dict, Any, Generator, AsyncGenerator
from unittest.mock import Mock, AsyncMock, patch
import asyncpg
import aioredis
import httpx
from fastapi.testclient import TestClient

# Test configuration
TEST_DATABASE_URL = os.getenv(
    "TEST_DATABASE_URL", 
    "postgresql://postgres:postgres@localhost:5432/terradev_test"
)
TEST_REDIS_URL = os.getenv(
    "TEST_REDIS_URL", 
    "redis://localhost:6379/1"
)

@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture(scope="session")
async def test_database():
    """Create test database connection"""
    
    # Create test database
    conn = await asyncpg.connect(
        "postgresql://postgres:postgres@localhost:5432/postgres"
    )
    
    try:
        await conn.execute("CREATE DATABASE terradev_test")
    except asyncpg.exceptions.DuplicateDatabaseError:
        pass  # Database already exists
    
    await conn.close()
    
    # Connect to test database
    pool = await asyncpg.create_pool(TEST_DATABASE_URL, min_size=1, max_size=5)
    
    yield pool
    
    # Cleanup
    await pool.close()
    
    # Drop test database
    conn = await asyncpg.connect(
        "postgresql://postgres:postgres@localhost:5432/postgres"
    )
    await conn.execute("DROP DATABASE IF EXISTS terradev_test")
    await conn.close()

@pytest.fixture(scope="session")
async def test_redis():
    """Create test Redis connection"""
    
    redis_client = await aioredis.from_url(TEST_REDIS_URL, db=1)
    
    # Clear test database
    await redis_client.flushdb()
    
    yield redis_client
    
    await redis_client.close()

@pytest.fixture
# TODO: REFACTOR - sample_gpu_data() is 52 lines long (should be <50)
# Consider breaking into smaller, focused functions
def sample_gpu_data():
    """Sample GPU pricing data for testing"""
    
    return {
        "aws": {
            "a100": {
                "on_demand_price": 4.06,
                "spot_price": 1.22,
                "region": "us-west-2",
                "instance_type": "p4d.24xlarge"
            },
            "h100": {
                "on_demand_price": 7.20,
                "spot_price": 2.16,
                "region": "us-west-2",
                "instance_type": "p5.48xlarge"
            },
            "a10g": {
                "on_demand_price": 1.21,
                "spot_price": 0.36,
                "region": "us-west-2",
                "instance_type": "g4dn.xlarge"
            }
        },
        "gcp": {
            "a100": {
                "on_demand_price": 3.85,
                "spot_price": 1.15,
                "region": "us-central1",
                "instance_type": "a2-highgpu-1g"
            },
            "h100": {
                "on_demand_price": 6.80,
                "spot_price": 2.04,
                "region": "us-central1",
                "instance_type": "a2-ultragpu-1g"
            }
        },
        "runpod": {
            "a100": {
                "on_demand_price": 2.50,
                "spot_price": 0.89,
                "region": "us-west-2",
                "instance_type": "A100-40GB"
            },
            "h100": {
                "on_demand_price": 4.20,
                "spot_price": 1.50,
                "region": "us-west-2",
                "instance_type": "H100-80GB"
            }
        }
    }

@pytest.fixture
def sample_user_data():
    """Sample user data for testing"""
    
    return {
        "id": "test-user-123",
        "email": "test@example.com",
        "username": "testuser",
        "role": "developer",
        "is_active": True,
        "created_at": datetime.utcnow(),
        "last_login": None,
        "failed_login_attempts": 0,
        "locked_until": None,
        "mfa_enabled": False,
        "api_keys": []
    }

@pytest.fixture
def sample_arbitrage_opportunity():
    """Sample arbitrage opportunity for testing"""
    
    return {
        "provider": "aws",
        "instance_type": "p4d.24xlarge",
        "gpu_type": "a100",
        "hourly_cost": 1.22,
        "source": "spot",
        "confidence": 0.85,
        "success_probability": 0.90,
        "risk_level": "low",
        "features": ["spot_pricing", "high_availability", "fast_network"],
        "region": "us-west-2",
        "availability": "available",
        "estimated_savings": 70.0,
        "price_volatility": 0.15,
        "market_depth": 0.80
    }

@pytest.fixture
def mock_cloud_apis():
    """Mock cloud provider APIs"""
    
    with patch('boto3.client') as mock_aws, \
         patch('google.cloud.billing_v1.CloudBillingClient') as mock_gcp, \
         patch('azure.mgmt.billing.BillingManagementClient') as mock_azure:
        
        # Mock AWS
        mock_aws_client = Mock()
        mock_aws.return_value = mock_aws_client
        mock_aws_client.describe_spot_price_history.return_value = {
            'SpotPriceHistory': [
                {
                    'InstanceType': 'p4d.24xlarge',
                    'SpotPrice': '1.22',
                    'AvailabilityZone': 'us-west-2a',
                    'Timestamp': datetime.utcnow()
                }
            ]
        }
        
        # Mock GCP
        mock_gcp_client = Mock()
        mock_gcp.return_value = mock_gcp_client
        mock_gcp_client.list_skus.return_value = Mock(
            pages=[[Mock(sku=Mock(description="A100", pricing_info=[Mock(pricing_expression=Mock(
                rates=[Mock(unit_price={"currency_code": "USD", "units": "1", "nanos": 150000000})]
            ))]))]]
        )
        
        # Mock Azure
        mock_azure_client = Mock()
        mock_azure.return_value = mock_azure_client
        mock_azure_client.prices.list.return_value = [
            Mock(
                product_name="Standard_ND96asr_v4",
                meter_name="A100",
                retail_price=2.50,
                currency_code="USD"
            )
        ]
        
        yield {
            "aws": mock_aws_client,
            "gcp": mock_gcp_client,
            "azure": mock_azure_client
        }

@pytest.fixture
def temp_config_file():
    """Create temporary configuration file"""
    
    config_data = {
        "providers": ["aws", "gcp", "azure", "runpod"],
        "gpu_types": ["a100", "h100", "a10g"],
        "api_keys": {
            "aws": {"access_key": "test-key", "secret_key": "test-secret"},
            "gcp": {"service_account_key": "test-key"},
            "azure": {"client_id": "test-id", "client_secret": "test-secret"},
            "runpod": {"api_key": "test-key"}
        },
        "confidence_threshold": 0.8,
        "max_risk_score": 0.3,
        "spot_only": True,
        "max_price_per_hour": 10.0
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(config_data, f, indent=2)
        temp_file = f.name
    
    yield temp_file
    
    os.unlink(temp_file)

@pytest.fixture
async def http_client():
    """Create HTTP client for API testing"""
    
    async with httpx.AsyncClient() as client:
        yield client

@pytest.fixture
def mock_redis():
    """Mock Redis client"""
    
    mock_client = AsyncMock()
    mock_client.get.return_value = None
    mock_client.setex.return_value = True
    mock_client.incr.return_value = 1
    mock_client.flushdb.return_value = True
    
    return mock_client

@pytest.fixture
def mock_database():
    """Mock database connection"""
    
    mock_pool = AsyncMock()
    mock_conn = AsyncMock()
    mock_pool.acquire.return_value.__aenter__.return_value = mock_conn
    mock_pool.acquire.return_value.__aexit__.return_value = None
    
    mock_conn.fetchrow.return_value = None
    mock_conn.fetch.return_value = []
    mock_conn.execute.return_value = "INSERT 0 1"
    
    return mock_pool

@pytest.fixture
def sample_volatility_data():
    """Sample volatility data for testing"""
    
    return {
        "gpu_type": "a100",
        "price_history": [
            {"timestamp": "2024-01-01T00:00:00Z", "price": 1.20},
            {"timestamp": "2024-01-01T01:00:00Z", "price": 1.22},
            {"timestamp": "2024-01-01T02:00:00Z", "price": 1.25},
            {"timestamp": "2024-01-01T03:00:00Z", "price": 1.18},
            {"timestamp": "2024-01-01T04:00:00Z", "price": 1.21}
        ],
        "volatility_metrics": {
            "daily_volatility": 0.15,
            "annualized_volatility": 0.89,
            "mean_reversion_rate": 0.05,
            "price_trend": "stable"
        },
        "opportunities": [
            {
                "provider": "aws",
                "instance_type": "p4d.24xlarge",
                "current_price": 1.22,
                "predicted_price": 1.25,
                "opportunity_score": 0.75,
                "risk_level": "low"
            }
        ]
    }

@pytest.fixture
def sample_risk_metrics():
    """Sample risk metrics for testing"""
    
    return {
        "var_95": 0.15,
        "expected_shortfall": 0.22,
        "max_drawdown": 0.08,
        "sharpe_ratio": 2.5,
        "sortino_ratio": 3.2,
        "beta": 0.85,
        "alpha": 0.12,
        "correlation_risk": 0.25,
        "liquidity_risk": 0.10,
        "concentration_risk": 0.05,
        "greeks": {
            "delta": 0.75,
            "gamma": 0.15,
            "theta": -0.05,
            "vega": 0.25,
            "rho": 0.08
        }
    }

@pytest.fixture
def sample_cost_analysis():
    """Sample cost analysis data for testing"""
    
    return {
        "total_cost": 1250.50,
        "cost_breakdown": {
            "aws": {"cost": 450.25, "percentage": 36.0},
            "gcp": {"cost": 380.15, "percentage": 30.4},
            "runpod": {"cost": 320.10, "percentage": 25.6},
            "others": {"cost": 100.00, "percentage": 8.0}
        },
        "savings": {
            "total_savings": 890.25,
            "savings_percentage": 41.6,
            "spot_savings": 680.50,
            "arbitrage_savings": 209.75
        },
        "optimization_recommendations": [
            {
                "type": "spot_migration",
                "potential_savings": 125.30,
                "confidence": 0.85,
                "description": "Migrate 3 instances to spot pricing"
            },
            {
                "type": "provider_switch",
                "potential_savings": 89.75,
                "confidence": 0.72,
                "description": "Switch AWS instances to RunPod"
            }
        ],
        "trends": {
            "daily_costs": [45.20, 42.15, 48.30, 44.80, 46.25],
            "cost_trend": "increasing",
            "forecast": {
                "next_month": 1320.75,
                "confidence": 0.78
            }
        }
    }

@pytest.fixture
def performance_benchmark_data():
    """Sample performance benchmark data"""
    
    return {
        "api_response_times": {
            "gpu_pricing": {"avg": 120, "p95": 250, "p99": 450},
            "arbitrage_analysis": {"avg": 850, "p95": 1200, "p99": 1800},
            "risk_assessment": {"avg": 320, "p95": 580, "p99": 950}
        },
        "throughput_metrics": {
            "requests_per_second": 1250,
            "concurrent_users": 500,
            "error_rate": 0.002
        },
        "resource_usage": {
            "cpu_utilization": 0.65,
            "memory_utilization": 0.78,
            "disk_io": 125.5,
            "network_io": 89.2
        },
        "database_performance": {
            "query_times": {"avg": 45, "p95": 120, "p99": 280},
            "connection_pool": {"active": 15, "idle": 25, "max": 50},
            "index_usage": 0.92
        }
    }

@pytest.fixture
def load_test_config():
    """Load testing configuration"""
    
    return {
        "base_url": "http://localhost:8080",
        "concurrent_users": 100,
        "spawn_rate": 10,
        "run_time": "10m",
        "endpoints": [
            {
                "path": "/api/v1/gpu/pricing",
                "weight": 40,
                "method": "GET"
            },
            {
                "path": "/api/v1/arbitrage/opportunities",
                "weight": 30,
                "method": "GET"
            },
            {
                "path": "/api/v1/arbitrage/analyze",
                "weight": 20,
                "method": "POST"
            },
            {
                "path": "/api/v1/health",
                "weight": 10,
                "method": "GET"
            }
        ]
    }

# Test markers
pytest_plugins = []

def pytest_configure(config):
    """Configure pytest with custom markers"""
    
    config.addinivalue_line(
        "markers", "unit: mark test as unit test"
    )
    config.addinivalue_line(
        "markers", "integration: mark test as integration test"
    )
    config.addinivalue_line(
        "markers", "performance: mark test as performance test"
    )
    config.addinivalue_line(
        "markers", "load: mark test as load test"
    )
    config.addinivalue_line(
        "markers", "security: mark test as security test"
    )
    config.addinivalue_line(
        "markers", "slow: mark test as slow running"
    )

def pytest_collection_modifyitems(config, items):
    """Modify test collection to add markers based on test location"""
    
    for item in items:
        # Add markers based on test file location
        if "unit" in str(item.fspath):
            item.add_marker(pytest.mark.unit)
        elif "integration" in str(item.fspath):
            item.add_marker(pytest.mark.integration)
        elif "performance" in str(item.fspath):
            item.add_marker(pytest.mark.performance)
        elif "load" in str(item.fspath):
            item.add_marker(pytest.mark.load)
        elif "security" in str(item.fspath):
            item.add_marker(pytest.mark.security)
        
        # Add slow marker for tests that might take longer
        if "load" in str(item.fspath) or "performance" in str(item.fspath):
            item.add_marker(pytest.mark.slow)
