import logging

"""
Performance benchmarks for Terradev Arbitrage Engine
Measures API response times, throughput, and resource usage
"""

import asyncio
import time
import json
import statistics
import psutil
import pytest
from typing import Dict, List, Any, Callable
from concurrent.futures import ThreadPoolExecutor
import httpx
import memory_profiler
import cProfile
import pstats
import io
from dataclasses import dataclass
from datetime import datetime, timedelta

from enhanced_arbitrage_engine import EnhancedArbitrageEngine
from complete_arbitrage_engine import ArbitrageEngine, GPUType

@dataclass
class BenchmarkResult:
    """Benchmark result data structure"""
    
    test_name: str
    total_time: float
    avg_time: float
    min_time: float
    max_time: float
    p95_time: float
    p99_time: float
    throughput: float  # operations per second
    memory_usage_mb: float
    cpu_usage_percent: float
    success_rate: float
    error_count: int
    iterations: int

class PerformanceBenchmark:
    """Performance benchmarking suite"""
    
    def __init__(self):
        self.results: List[BenchmarkResult] = []
        self.process = psutil.Process()
        
    def measure_resource_usage(self) -> Dict[str, float]:
        """Measure current resource usage"""
        
        return {
            "memory_mb": self.process.memory_info().rss / 1024 / 1024,
            "cpu_percent": self.process.cpu_percent(),
            "threads": self.process.num_threads()
        }
    
    async def benchmark_function(
        self, 
        func: Callable, 
        iterations: int = 100,
        concurrency: int = 1,
        **kwargs
    ) -> BenchmarkResult:
        """Benchmark a function with specified iterations and concurrency"""
        
        logging.info(f"🚀 Benchmarking {func.__name__} with {iterations} iterations, concurrency={concurrency}")
        
        # Measure initial resource usage
        initial_resources = self.measure_resource_usage()
        
        # Run benchmark
        times = []
        errors = 0
        start_time = time.time()
        
        if concurrency == 1:
            # Sequential execution
            for i in range(iterations):
                try:
                    iteration_start = time.time()
                    if asyncio.iscoroutinefunction(func):
                        await func(**kwargs)
                    else:
                        func(**kwargs)
                    iteration_time = time.time() - iteration_start
                    times.append(iteration_time)
                except Exception as e:
                    errors += 1
                    logging.info(f"Error in iteration {i}: {e}")
        else:
            # Concurrent execution
            semaphore = asyncio.Semaphore(concurrency)
            
            async def bounded_func():
                async with semaphore:
                    iteration_start = time.time()
                    try:
                        if asyncio.iscoroutinefunction(func):
                            await func(**kwargs)
                        else:
                            func(**kwargs)
                        return time.time() - iteration_start
                    except Exception as e:
                        nonlocal errors
                        errors += 1
                        return None
            
            tasks = [bounded_func() for _ in range(iterations)]
            results = await asyncio.gather(*tasks)
            times = [t for t in results if t is not None]
        
        total_time = time.time() - start_time
        
        # Measure final resource usage
        final_resources = self.measure_resource_usage()
        
        # Calculate statistics
        if times:
            avg_time = statistics.mean(times)
            min_time = min(times)
            max_time = max(times)
            p95_time = statistics.quantiles(times, n=20)[18] if len(times) > 20 else max(times)
            p99_time = statistics.quantiles(times, n=100)[98] if len(times) > 100 else max(times)
        else:
            avg_time = min_time = max_time = p95_time = p99_time = 0
        
        throughput = len(times) / total_time if total_time > 0 else 0
        success_rate = len(times) / iterations if iterations > 0 else 0
        
        result = BenchmarkResult(
            test_name=func.__name__,
            total_time=total_time,
            avg_time=avg_time,
            min_time=min_time,
            max_time=max_time,
            p95_time=p95_time,
            p99_time=p99_time,
            throughput=throughput,
            memory_usage_mb=final_resources["memory_mb"] - initial_resources["memory_mb"],
            cpu_usage_percent=final_resources["cpu_percent"],
            success_rate=success_rate,
            error_count=errors,
            iterations=iterations
        )
        
        self.results.append(result)
        return result
    
    def profile_function(self, func: Callable, **kwargs):
        """Profile function execution"""
        
        profiler = cProfile.Profile()
        profiler.enable()
        
        if asyncio.iscoroutinefunction(func):
            asyncio.run(func(**kwargs))
        else:
            func(**kwargs)
        
        profiler.disable()
        
        # Get stats
        s = io.StringIO()
        ps = pstats.Stats(profiler, stream=s).sort_stats('cumulative')
        ps.print_stats()
        
        return s.getvalue()
    
    def print_results(self):
        """Print benchmark results"""
        
        logging.info("\n📊 Performance Benchmark Results")
        logging.info("=" * 80)
        
        for result in self.results:
            logging.info(f"\n🔍 {result.test_name}")
            logging.info(f"   Total Time: {result.total_time:.3f}s")
            logging.info(f"   Avg Time: {result.avg_time:.3f}s")
            logging.info(f"   Min Time: {result.min_time:.3f}s")
            logging.info(f"   Max Time: {result.max_time:.3f}s")
            logging.info(f"   P95 Time: {result.p95_time:.3f}s")
            logging.info(f"   P99 Time: {result.p99_time:.3f}s")
            logging.info(f"   Throughput: {result.throughput:.2f} ops/sec")
            logging.info(f"   Memory Usage: {result.memory_usage_mb:.2f} MB")
            logging.info(f"   CPU Usage: {result.cpu_usage_percent:.1f}%")
            logging.info(f"   Success Rate: {result.success_rate:.2%}")
            logging.info(f"   Errors: {result.error_count}/{result.iterations}")
    
    def save_results(self, filename: str):
        """Save benchmark results to file"""
        
        results_data = []
        for result in self.results:
            results_data.append({
                "test_name": result.test_name,
                "total_time": result.total_time,
                "avg_time": result.avg_time,
                "min_time": result.min_time,
                "max_time": result.max_time,
                "p95_time": result.p95_time,
                "p99_time": result.p99_time,
                "throughput": result.throughput,
                "memory_usage_mb": result.memory_usage_mb,
                "cpu_usage_percent": result.cpu_usage_percent,
                "success_rate": result.success_rate,
                "error_count": result.error_count,
                "iterations": result.iterations,
                "timestamp": datetime.utcnow().isoformat()
            })
        
        with open(filename, 'w') as f:
            json.dump(results_data, f, indent=2)
        
        logging.info(f"📁 Results saved to {filename}")

# Benchmark functions
async def benchmark_gpu_pricing_scan():
    """Benchmark GPU pricing scan performance"""
    
    engine = ArbitrageEngine()
    
    # Mock the actual API calls for benchmarking
    with pytest.MonkeyPatch().context() as m:
        # Mock AWS response
        def mock_aws_scan():
            # TODO: PERFORMANCE - Consider async/await for blocking sleep
# time.sleep(0.05)  # Simulate API latency
            return []
        
        m.setattr(engine, 'scan_provider', mock_aws_scan)
        
        # Perform scan
        await engine.scan_all_providers()

async def benchmark_arbitrage_analysis():
    """Benchmark arbitrage analysis performance"""
    
    engine = EnhancedArbitrageEngine()
    
    # Mock dependencies
    with pytest.MonkeyPatch().context() as m:
        # Mock base engine
        def mock_scan():
            # TODO: PERFORMANCE - Consider async/await for blocking sleep
# time.sleep(0.1)  # Simulate processing time
            return {}
        
        m.setattr(engine.base_engine, 'scan_all_providers', mock_scan)
        
        # Perform analysis
        await engine.find_enhanced_arbitrage_opportunities(GPUType.A100)

async def benchmark_risk_calculation():
    """Benchmark risk calculation performance"""
    
    from advanced_risk_engine import AdvancedRiskEngine
    
    engine = AdvancedRiskEngine()
    
    # Generate sample data
    price_history = [1.0 + i * 0.01 for i in range(100)]
    
    # Calculate risk metrics
    await engine.calculate_risk_metrics(price_history, "aws", "a100")

async def benchmark_api_response():
    """Benchmark API response time"""
    
    # This would benchmark actual API endpoints
    # For now, simulate API response
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get("http://localhost:8080/health", timeout=5.0)
            return response.status_code == 200
        except Exception as e:
            return False

def benchmark_memory_allocation():
    """Benchmark memory allocation patterns"""
    
    # Simulate memory-intensive operations
    data = []
    for i in range(1000):
        data.append({
            "id": i,
            "price": 1.0 + i * 0.01,
            "metadata": {"key": f"value_{i}", "data": "x" * 100}
        })
    
    # Process data
    processed = [item["price"] * 2 for item in data]
    return len(processed)

@pytest.mark.performance
@pytest.mark.slow
class TestPerformanceBenchmarks:
    """Performance benchmark test suite"""
    
    @pytest.fixture
    def benchmark(self):
        """Create benchmark instance"""
        return PerformanceBenchmark()
    
    @pytest.mark.asyncio
    async def test_gpu_pricing_performance(self, benchmark):
        """Test GPU pricing scan performance"""
        
        result = await benchmark.benchmark_function(
            benchmark_gpu_pricing_scan,
            iterations=50,
            concurrency=5
        )
        
        # Performance assertions
        assert result.avg_time < 1.0  # Should complete in under 1 second
        assert result.throughput > 1.0  # Should handle at least 1 op/sec
        assert result.success_rate > 0.9  # Should have high success rate
        
        logging.info(f"✅ GPU Pricing Scan: {result.avg_time:.3f}s avg, {result.throughput:.2f} ops/sec")
    
    @pytest.mark.asyncio
    async def test_arbitrage_analysis_performance(self, benchmark):
        """Test arbitrage analysis performance"""
        
        result = await benchmark.benchmark_function(
            benchmark_arbitrage_analysis,
            iterations=30,
            concurrency=3
        )
        
        # Performance assertions
        assert result.avg_time < 2.0  # Should complete in under 2 seconds
        assert result.throughput > 0.5  # Should handle at least 0.5 ops/sec
        assert result.success_rate > 0.8  # Should have reasonable success rate
        
        logging.info(f"✅ Arbitrage Analysis: {result.avg_time:.3f}s avg, {result.throughput:.2f} ops/sec")
    
    @pytest.mark.asyncio
    async def test_risk_calculation_performance(self, benchmark):
        """Test risk calculation performance"""
        
        result = await benchmark.benchmark_function(
            benchmark_risk_calculation,
            iterations=100,
            concurrency=10
        )
        
        # Performance assertions
        assert result.avg_time < 0.5  # Should complete in under 500ms
        assert result.throughput > 10.0  # Should handle at least 10 ops/sec
        assert result.success_rate > 0.95  # Should have very high success rate
        
        logging.info(f"✅ Risk Calculation: {result.avg_time:.3f}s avg, {result.throughput:.2f} ops/sec")
    
    def test_volatility_calculation_performance(self, benchmark):
        """Test volatility calculation performance"""
        
        result = asyncio.run(benchmark.benchmark_function(
            benchmark_volatility_calculation,
            iterations=200,
            concurrency=5
        ))
        
        # Performance assertions
        assert result.avg_time < 0.1  # Should complete in under 100ms
        assert result.throughput > 50.0  # Should handle at least 50 ops/sec
        assert result.success_rate > 0.95  # Should have very high success rate
        
        logging.info(f"✅ Volatility Calculation: {result.avg_time:.3f}s avg, {result.throughput:.2f} ops/sec")
    
    @pytest.mark.asyncio
    async def test_api_response_performance(self, benchmark):
        """Test API response performance"""
        
        result = await benchmark.benchmark_function(
            benchmark_api_response,
            iterations=100,
            concurrency=20
        )
        
        # Performance assertions (if API is available)
        if result.success_rate > 0:
            assert result.avg_time < 0.5  # Should respond in under 500ms
            assert result.throughput > 20.0  # Should handle at least 20 req/sec
        
        logging.info(f"✅ API Response: {result.avg_time:.3f}s avg, {result.throughput:.2f} req/sec")
    
    def test_memory_allocation_performance(self, benchmark):
        """Test memory allocation performance"""
        
        result = asyncio.run(benchmark.benchmark_function(
            benchmark_memory_allocation,
            iterations=100,
            concurrency=1
        ))
        
        # Performance assertions
        assert result.avg_time < 0.1  # Should complete in under 100ms
        assert result.memory_usage_mb < 100  # Should use less than 100MB
        
        logging.info(f"✅ Memory Allocation: {result.avg_time:.3f}s avg, {result.memory_usage_mb:.2f} MB")
    
    @pytest.mark.asyncio
    async def test_comprehensive_performance_suite(self, benchmark):
        """Run comprehensive performance test suite"""
        
        logging.info("\n🚀 Running Comprehensive Performance Suite")
        logging.info("=" * 60)
        
        # Test various scenarios with different loads
        test_scenarios = [
            {"func": benchmark_gpu_pricing_scan, "iterations": 20, "concurrency": 2, "name": "Light Load"},
            {"func": benchmark_gpu_pricing_scan, "iterations": 50, "concurrency": 5, "name": "Medium Load"},
            {"func": benchmark_gpu_pricing_scan, "iterations": 100, "concurrency": 10, "name": "Heavy Load"},
        ]
        
        for scenario in test_scenarios:
            logging.info(f"\n📊 Testing {scenario['name']}...")
            result = await benchmark.benchmark_function(
                scenario["func"],
                iterations=scenario["iterations"],
                concurrency=scenario["concurrency"]
            )
            
            # Validate performance doesn't degrade significantly
            if scenario["name"] == "Heavy Load":
                assert result.avg_time < 2.0  # Even under heavy load
                assert result.success_rate > 0.7  # Reasonable success rate
        
        # Print all results
        benchmark.print_results()
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        benchmark.save_results(f"performance_results_{timestamp}.json")
        
        logging.info(f"\n✅ Performance suite completed successfully")

@pytest.mark.performance
def test_memory_profiling():
    """Memory profiling test"""
    
    logging.info("\n🧠 Running Memory Profiling")
    
    # Profile memory usage
    @memory_profiler.profile
    def memory_intensive_function():
        """Function that uses significant memory"""
        
        data = []
        for i in range(10000):
            data.append({
                "id": i,
                "price": 1.0 + i * 0.001,
                "metadata": {"key": f"value_{i}", "data": "x" * 50}
            })
        
        # Process data
        processed = sum(item["price"] for item in data)
        return processed
    
    # Run memory profiling
    result = memory_intensive_function()
    
    assert result > 0
    logging.info(f"✅ Memory profiling completed, result: {result}")

@pytest.mark.performance
def test_cpu_profiling():
    """CPU profiling test"""
    
    logging.info("\n⚡ Running CPU Profiling")
    
    benchmark = PerformanceBenchmark()
    
    # Profile CPU-intensive function
    profile_output = benchmark.profile_function(benchmark_volatility_calculation)
    
    logging.info("📈 CPU Profile Results:")
    logging.info(profile_output[:1000] + "..." if len(profile_output)
    
    assert "function calls" in profile_output.lower()
    logging.info("✅ CPU profiling completed")

# Performance regression tests
@pytest.mark.performance
class TestPerformanceRegression:
    """Performance regression tests"""
    
    @pytest.mark.asyncio
    async def test_no_performance_regression(self):
        """Ensure no performance regression from baseline"""
        
        benchmark = PerformanceBenchmark()
        
        # Baseline performance values (these would be updated periodically)
        baseline_performance = {
            "gpu_pricing_scan": {"avg_time": 0.5, "throughput": 10.0},
            "arbitrage_analysis": {"avg_time": 1.0, "throughput": 2.0},
            "risk_calculation": {"avg_time": 0.2, "throughput": 20.0}
        }
        
        # Run current performance tests
        current_results = {}
        
        # Test GPU pricing scan
        result = await benchmark.benchmark_function(
            benchmark_gpu_pricing_scan, iterations=20, concurrency=2
        )
        current_results["gpu_pricing_scan"] = {
            "avg_time": result.avg_time,
            "throughput": result.throughput
        }
        
        # Test arbitrage analysis
        result = await benchmark.benchmark_function(
            benchmark_arbitrage_analysis, iterations=10, concurrency=1
        )
        current_results["arbitrage_analysis"] = {
            "avg_time": result.avg_time,
            "throughput": result.throughput
        }
        
        # Test risk calculation
        result = await benchmark.benchmark_function(
            benchmark_risk_calculation, iterations=50, concurrency=5
        )
        current_results["risk_calculation"] = {
            "avg_time": result.avg_time,
            "throughput": result.throughput
        }
        
        # Check for regressions
        regression_detected = False
        
        for test_name, current in current_results.items():
            baseline = baseline_performance[test_name]
            
            # Check average time (should not be more than 20% slower)
            if current["avg_time"] > baseline["avg_time"] * 1.2:
                logging.info(f"⚠️  Performance regression detected in {test_name}:")
                logging.info(f"   Baseline avg time: {baseline['avg_time']:.3f}s")
                logging.info(f"   Current avg time: {current['avg_time']:.3f}s")
                regression_detected = True
            
            # Check throughput (should not be more than 20% lower)
            if current["throughput"] < baseline["throughput"] * 0.8:
                logging.info(f"⚠️  Throughput regression detected in {test_name}:")
                logging.info(f"   Baseline throughput: {baseline['throughput']:.2f} ops/sec")
                logging.info(f"   Current throughput: {current['throughput']:.2f} ops/sec")
                regression_detected = True
        
        if regression_detected:
            pytest.fail("Performance regression detected!")
        else:
            logging.info("✅ No performance regression detected")

if __name__ == "__main__":
    # Run standalone performance tests
    async def main():
        benchmark = PerformanceBenchmark()
        
        logging.info("🚀 Running Standalone Performance Benchmarks")
        logging.info("=" * 60)
        
        # Run all benchmarks
        await benchmark.benchmark_function(benchmark_gpu_pricing_scan, iterations=10, concurrency=2)
        await benchmark.benchmark_function(benchmark_arbitrage_analysis, iterations=5, concurrency=1)
        await benchmark.benchmark_function(benchmark_risk_calculation, iterations=20, concurrency=5)
        
        benchmark.print_results()
        benchmark.save_results("standalone_performance_results.json")
    
    asyncio.run(main())
