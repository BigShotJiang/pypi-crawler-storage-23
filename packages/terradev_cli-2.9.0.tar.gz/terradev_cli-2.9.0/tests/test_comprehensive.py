#!/usr/bin/env python3
"""
Comprehensive Test Suite for Terradev
Unit tests, integration tests, and end-to-end tests
"""

import pytest
import asyncio
import json
import os
import tempfile
from unittest.mock import Mock, patch, AsyncMock
from typing import Dict, Any, List
import aiohttp
from datetime import datetime, timedelta

# Import Terradev modules
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config.secure_config_manager import SecureConfigManager, ConfigValidationError
from security.secure_api_handler import SecureAPIHandler, APIConfig, RateLimiter
from utils.error_handler import (
    TerradevException, NetworkException, AuthenticationException,
    ErrorHandler, with_retry, handle_exceptions, ErrorContext
)

class TestSecureConfigManager:
    """Test secure configuration management"""
    
    def test_load_config_success(self):
        """Test successful configuration loading"""
        with patch.dict(os.environ, {
            'DB_HOST': 'localhost',
            'DB_PORT': '5432',
            'DB_NAME': 'test_db',
            'DB_USERNAME': 'test_user',
            'DB_PASSWORD': 'test_password',
            'REDIS_HOST': 'localhost',
            'REDIS_PORT': '6379',
            'SECRET_KEY': 'super_secret_key_at_least_32_characters_long',
            'PORT': '8000'
        }):
            config_manager = SecureConfigManager()
            config = config_manager.load_config()
            
            assert config['database'].host == 'localhost'
            assert config['database'].port == 5432
            assert config['database'].name == 'test_db'
            assert config['security'].secret_key == 'super_secret_key_at_least_32_characters_long'
            assert config['app']['port'] == 8000
    
    def test_load_config_missing_required(self):
        """Test configuration loading with missing required variables"""
        with patch.dict(os.environ, {}, clear=True):
            config_manager = SecureConfigManager()
            
            with pytest.raises(ConfigValidationError, match="DB_HOST"):
                config_manager.load_config()
    
    def test_validate_config_warnings(self):
        """Test configuration validation warnings"""
        config_manager = SecureConfigManager()
        
        # Mock config with issues
        config = {
            'app': Mock(debug=True, environment='production'),
            'database': Mock(password='your_secure_password_here'),
            'monitoring': Mock(grafana_admin_password='admin')
        }
        
        warnings = config_manager.validate_config(config)
        
        assert len(warnings) >= 3
        assert any("DEBUG mode is enabled" in w for w in warnings)
        assert any("default database password" in w for w in warnings)
        assert any("default Grafana password" in w for w in warnings)
    
    def test_secret_key_validation(self):
        """Test secret key length validation"""
        with patch.dict(os.environ, {
            'DB_HOST': 'localhost',
            'DB_PORT': '5432',
            'DB_NAME': 'test_db',
            'DB_USERNAME': 'test_user',
            'DB_PASSWORD': 'test_password',
            'REDIS_HOST': 'localhost',
            'REDIS_PORT': '6379',
            'SECRET_KEY': 'short',  # Too short
            'PORT': '8000'
        }):
            config_manager = SecureConfigManager()
            
            with pytest.raises(ConfigValidationError, match="SECRET_KEY must be at least 32 characters"):
                config_manager.load_config()

class TestSecureAPIHandler:
    """Test secure API handling"""
    
    @pytest.fixture
    def api_config(self):
        """Create test API configuration"""
        return APIConfig(
            base_url="https://api.test.com",
            api_key="test_key",
            timeout=10,
            retry_attempts=2,
            rate_limit_per_minute=60
        )
    
    @pytest.fixture
    def api_handler(self, api_config):
        """Create test API handler"""
        return SecureAPIHandler(api_config)
    
    def test_rate_limiter(self):
        """Test rate limiting functionality"""
        rate_limiter = RateLimiter(rate=1.0, capacity=10)
        
        # Should allow initial requests
        assert asyncio.run(rate_limiter.acquire()) == True
        assert asyncio.run(rate_limiter.acquire()) == True
        
        # Exhaust tokens
        for _ in range(8):
            asyncio.run(rate_limiter.acquire())
        
        # Should be rate limited now
        assert asyncio.run(rate_limiter.acquire()) == False
    
    def test_auth_headers_bearer(self, api_handler):
        """Test Bearer token authentication headers"""
        headers = api_handler._get_auth_headers()
        
        assert 'Authorization' in headers
        assert headers['Authorization'] == 'Bearer test_key'
        assert headers['Content-Type'] == 'application/json'
    
    def test_auth_headers_api_key(self):
        """Test API key authentication headers"""
        config = APIConfig(
            base_url="https://api.test.com",
            api_key="test_key",
            auth_type="api_key"
        )
        handler = SecureAPIHandler(config)
        
        headers = handler._get_auth_headers()
        
        assert 'X-API-Key' in headers
        assert headers['X-API-Key'] == 'test_key'
        assert 'Authorization' not in headers
    
    @pytest.mark.asyncio
    async def test_request_with_retry_success(self, api_handler):
        """Test successful request with retry logic"""
        # Mock successful response
        mock_response = Mock()
        mock_response.status = 200
        mock_response.content_type = "application/json"
        mock_response.json = AsyncMock(return_value={"status": "success"})
        
        with patch.object(api_handler, 'session') as mock_session:
            mock_session.request.return_value.__aenter__.return_value = mock_response
            
            result = await api_handler._make_request_with_retry("GET", "/test")
            
            assert result["status"] == "success"
            assert mock_session.request.call_count == 1
    
    @pytest.mark.asyncio
    async def test_request_with_retry_on_server_error(self, api_handler):
        """Test retry logic on server errors"""
        # Mock server error response
        mock_error_response = Mock()
        mock_error_response.status = 500
        mock_error_response.request_info = Mock()
        mock_error_response.history = []
        
        # Mock successful response after retry
        mock_success_response = Mock()
        mock_success_response.status = 200
        mock_success_response.content_type = "application/json"
        mock_success_response.json = AsyncMock(return_value={"status": "success"})
        
        with patch.object(api_handler, 'session') as mock_session:
            # First call fails, second succeeds
            mock_session.request.side_effect = [
                mock_error_response,
                mock_success_response
            ]
            
            with patch('asyncio.sleep'):  # Skip actual sleep
                result = await api_handler._make_request_with_retry("GET", "/test")
            
            assert result["status"] == "success"
            assert mock_session.request.call_count == 2
    
    @pytest.mark.asyncio
    async def test_request_authentication_error(self, api_handler):
        """Test handling of authentication errors"""
        # Mock auth error response
        mock_response = Mock()
        mock_response.status = 401
        mock_response.request_info = Mock()
        mock_response.history = []
        
        with patch.object(api_handler, 'session') as mock_session:
            mock_session.request.return_value.__aenter__.return_value = mock_response
            
            with pytest.raises(aiohttp.ClientResponseError, match="Authentication failed"):
                await api_handler._make_request_with_retry("GET", "/test")

class TestErrorHandler:
    """Test error handling functionality"""
    
    def test_error_handler_basic(self):
        """Test basic error handling"""
        handler = ErrorHandler()
        
        # Test handling a regular exception
        try:
            raise ValueError("Test error")
        except Exception as e:
            error = handler.handle_error(e)
        
        assert error.message == "Test error"
        assert error.category.value == "system"
        assert error.severity.value == "medium"
        assert handler.error_stats['total_errors'] == 1
    
    def test_terradev_exception_handling(self):
        """Test handling of Terradev exceptions"""
        handler = ErrorHandler()
        context = ErrorContext(user_id="test_user", provider="aws")
        
        exception = NetworkException("Network failed", context=context)
        error = handler.handle_error(exception)
        
        assert error.message == "Network failed"
        assert error.category.value == "network"
        assert error.severity.value == "high"
        assert error.context.user_id == "test_user"
        assert error.context.provider == "aws"
    
    def test_error_statistics(self):
        """Test error statistics tracking"""
        handler = ErrorHandler()
        
        # Generate different types of errors
        handler.handle_error(NetworkException("Network error"))
        handler.handle_error(AuthenticationException("Auth error"))
        handler.handle_error(NetworkException("Another network error"))
        
        assert handler.error_stats['total_errors'] == 3
        assert handler.error_stats['by_category']['network'] == 2
        assert handler.error_stats['by_category']['authentication'] == 1
    
    def test_error_summary(self):
        """Test error summary generation"""
        handler = ErrorHandler()
        
        # Add some errors with timestamps
        now = datetime.now()
        old_error = TerradevError(
            message="Old error",
            category=ErrorCategory.SYSTEM,
            severity=ErrorSeverity.LOW,
            error_code="OLD_ERROR",
            context=ErrorContext(),
            timestamp=now - timedelta(hours=25)  # 25 hours ago
        )
        
        recent_error = TerradevError(
            message="Recent error",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.HIGH,
            error_code="RECENT_ERROR",
            context=ErrorContext(),
            timestamp=now - timedelta(hours=1)  # 1 hour ago
        )
        
        handler.error_log = [old_error, recent_error]
        
        summary = handler.get_error_summary(hours=24)
        
        assert summary['total_recent_errors'] == 1  # Only recent error
        assert summary['error_rate_per_hour'] == 1.0 / 24
        assert len(summary['critical_errors']) == 0

class TestRetryDecorator:
    """Test retry decorator functionality"""
    
    @pytest.mark.asyncio
    async def test_retry_success_on_first_attempt(self):
        """Test successful function on first attempt"""
        call_count = 0
        
        @with_retry(config=RetryConfig(max_attempts=3))
        async def test_function():
            nonlocal call_count
            call_count += 1
            return "success"
        
        result = await test_function()
        
        assert result == "success"
        assert call_count == 1
    
    @pytest.mark.asyncio
    async def test_retry_success_after_attempts(self):
        """Test successful function after retries"""
        call_count = 0
        
        @with_retry(config=RetryConfig(max_attempts=3, base_delay=0.1))
        async def test_function():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise NetworkException("Temporary failure")
            return "success"
        
        with patch('asyncio.sleep'):  # Skip actual sleep
            result = await test_function()
        
        assert result == "success"
        assert call_count == 3
    
    @pytest.mark.asyncio
    async def test_retry_exhausted(self):
        """Test function that fails after all retries"""
        call_count = 0
        
        @with_retry(config=RetryConfig(max_attempts=2, base_delay=0.1))
        async def test_function():
            nonlocal call_count
            call_count += 1
            raise NetworkException("Persistent failure")
        
        with patch('asyncio.sleep'):  # Skip actual sleep
            with pytest.raises(NetworkException):
                await test_function()
        
        assert call_count == 2
    
    def test_retry_non_retryable_exception(self):
        """Test that non-retryable exceptions are not retried"""
        call_count = 0
        
        @with_retry(config=RetryConfig(max_attempts=3))
        def test_function():
            nonlocal call_count
            call_count += 1
            raise ValueError("Non-retryable error")
        
        with pytest.raises(ValueError):
            test_function()
        
        assert call_count == 1  # Should not retry

class TestExceptionDecorator:
    """Test exception decorator functionality"""
    
    def test_handle_exceptions_success(self):
        """Test successful function with exception handler"""
        @handle_exceptions(reraise=False)
        def test_function():
            return "success"
        
        result = test_function()
        assert result == "success"
    
    def test_handle_exceptions_catch(self):
        """Test exception catching without reraise"""
        @handle_exceptions(reraise=False)
        def test_function():
            raise ValueError("Test error")
        
        result = test_function()
        assert result is None  # Function should return None on error
    
    def test_handle_exceptions_reraise(self):
        """Test exception catching with reraise"""
        @handle_exceptions(reraise=True)
        def test_function():
            raise ValueError("Test error")
        
        with pytest.raises(ValueError):
            test_function()

class TestIntegration:
    """Integration tests"""
    
    @pytest.mark.asyncio
    async def test_config_api_integration(self):
        """Test integration between config manager and API handler"""
        # Mock environment variables
        with patch.dict(os.environ, {
            'DB_HOST': 'localhost',
            'DB_PORT': '5432',
            'DB_NAME': 'test_db',
            'DB_USERNAME': 'test_user',
            'DB_PASSWORD': 'test_password',
            'REDIS_HOST': 'localhost',
            'REDIS_PORT': '6379',
            'SECRET_KEY': 'super_secret_key_at_least_32_characters_long',
            'PORT': '8000',
            'HUGGINGFACE_TOKEN': 'test_token'
        }):
            # Load configuration
            config_manager = SecureConfigManager()
            config = config_manager.load_config()
            
            # Create API handler
            api_handler = create_api_handler(
                base_url="https://huggingface.co/api",
                api_key="test_token",
                auth_type="bearer"
            )
            
            assert api_handler.config.api_key == "test_token"
            assert api_handler.config.auth_type == "bearer"
    
    @pytest.mark.asyncio
    async def test_error_handling_api_integration(self):
        """Test integration between error handling and API calls"""
        api_handler = create_api_handler(
            base_url="https://api.test.com",
            api_key="test_key"
        )
        
        # Mock API call that fails
        with patch.object(api_handler, '_make_request_with_retry') as mock_request:
            mock_request.side_effect = NetworkException("API failed")
            
            with pytest.raises(NetworkException):
                await api_handler.get("/test")

# Test fixtures and utilities
@pytest.fixture
def temp_config_file():
    """Create temporary configuration file"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({
            'database': {
                'host': 'localhost',
                'port': 5432,
                'name': 'test_db',
                'username': 'test_user',
                'password': 'test_password'
            }
        }, f)
        temp_file = f.name
    
    yield temp_file
    
    # Cleanup
    os.unlink(temp_file)

# Performance tests
class TestPerformance:
    """Performance and load tests"""
    
    @pytest.mark.asyncio
    async def test_concurrent_api_calls(self):
        """Test concurrent API calls"""
        api_handler = create_api_handler(
            base_url="https://api.test.com",
            api_key="test_key"
        )
        
        # Mock successful response
        mock_response = Mock()
        mock_response.status = 200
        mock_response.content_type = "application/json"
        mock_response.json = AsyncMock(return_value={"status": "success"})
        
        with patch.object(api_handler, 'session') as mock_session:
            mock_session.request.return_value.__aenter__.return_value = mock_response
            
            # Make 10 concurrent calls
            tasks = [api_handler.get("/test") for _ in range(10)]
            results = await asyncio.gather(*tasks)
            
            assert len(results) == 10
            assert all(result["status"] == "success" for result in results)
    
    def test_error_handler_performance(self):
        """Test error handler performance with many errors"""
        handler = ErrorHandler()
        
        # Generate 1000 errors
        start_time = datetime.now()
        
        for i in range(1000):
            handler.handle_error(ValueError(f"Error {i}"))
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # Should handle 1000 errors in under 1 second
        assert duration < 1.0
        assert handler.error_stats['total_errors'] == 1000

# Test configuration
pytest_plugins = []

if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v", "--tb=short"])
