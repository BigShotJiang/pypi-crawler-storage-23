#!/usr/bin/env python3
"""
Fast Provisioning Orchestrator
Orchestrates fastest GPU provisioning using user-provided API credentials
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
import json

from user_api_manager import UserAPIManager, APIProvider, APIValidationResult

# Import parallel optimization engine
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "parallel_orchestration"))
from parallel_provisioning_engine import ParallelProvisioningEngine, ProviderRequest, InstanceType, Provider

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ProvisioningRequest:
    """Provisioning request from user"""
    user_id: str
    gpu_type: str
    region: str
    duration_hours: int
    max_price_per_hour: float
    min_memory_gb: int
    min_storage_gb: int
    preferred_providers: List[str] = None
    requirements: Dict[str, Any] = None

@dataclass
class ProvisioningResult:
    """Result of provisioning operation"""
    success: bool
    user_id: str
    winning_provider: str
    instance_id: str
    gpu_type: str
    price_per_hour: float
    total_cost: float
    provision_time_seconds: float
    provider_response_time: float
    all_responses: List[Dict[str, Any]]
    error_message: Optional[str] = None
    instance_details: Dict[str, Any] = None

class FastProvisioningOrchestrator:
    """Orchestrates fastest GPU provisioning using user APIs"""
    
    def __init__(self):
        self.api_manager = UserAPIManager()
        self.parallel_engine = ParallelProvisioningEngine()
        
        # Performance tracking
        self.provisioning_stats = {
            "total_provisions": 0,
            "successful_provisions": 0,
            "failed_provisions": 0,
            "avg_provision_time": 0.0,
            "fastest_provision_time": float('inf'),
            "provider_performance": {},
            "user_performance": {}
        }
        
        logger.info("Fast Provisioning Orchestrator initialized")
    
    async def add_user_credentials(self, user_id: str, provider: str, 
                                 credentials: Dict[str, str]) -> bool:
        """Add user API credentials"""
        try:
            provider_enum = APIProvider(provider.lower())
            return await self.api_manager.add_user_credentials(user_id, provider_enum, credentials)
        except ValueError:
            logger.error(f"Unsupported provider: {provider}")
            return False
    
    async def fast_provision_gpu(self, request: ProvisioningRequest) -> ProvisioningResult:
        """
        Fast GPU provisioning using user's API credentials
        This is the core function for fastest provisioning
        """
        start_time = time.time()
        
        logger.info(f"🚀 Starting fast provisioning for user {request.user_id}")
        logger.info(f"   GPU Type: {request.gpu_type}")
        logger.info(f"   Duration: {request.duration_hours} hours")
        logger.info(f"   Max Price: ${request.max_price_per_hour}/hr")
        
        try:
            # Get user's available providers
            user_providers = self.api_manager.get_user_credentials(request.user_id)
            
            if not user_providers:
                return ProvisioningResult(
                    success=False,
                    user_id=request.user_id,
                    winning_provider="",
                    instance_id="",
                    gpu_type=request.gpu_type,
                    price_per_hour=0.0,
                    total_cost=0.0,
                    provision_time_seconds=time.time() - start_time,
                    provider_response_time=0.0,
                    all_responses=[],
                    error_message="No API credentials configured for user"
                )
            
            # Filter providers by user preferences
            available_providers = self._filter_providers(user_providers, request.preferred_providers)
            
            if not available_providers:
                return ProvisioningResult(
                    success=False,
                    user_id=request.user_id,
                    winning_provider="",
                    instance_id="",
                    gpu_type=request.gpu_type,
                    price_per_hour=0.0,
                    total_cost=0.0,
                    provision_time_seconds=time.time() - start_time,
                    provider_response_time=0.0,
                    all_responses=[],
                    error_message="No available providers match user preferences"
                )
            
            logger.info(f"   Available providers: {list(available_providers.keys())}")
            
            # Parallel provisioning across all user's providers
            provisioning_results = await self._parallel_provision_across_providers(
                request, available_providers
            )
            
            # Select winner (fastest and cheapest)
            winner = self._select_optimal_result(provisioning_results, request)
            
            # Update statistics
            self._update_provisioning_stats(winner, start_time)
            
            return winner
        
        except Exception as e:
            logger.error(f"Fast provisioning failed for user {request.user_id}: {e}")
            return ProvisioningResult(
                success=False,
                user_id=request.user_id,
                winning_provider="",
                instance_id="",
                gpu_type=request.gpu_type,
                price_per_hour=0.0,
                total_cost=0.0,
                provision_time_seconds=time.time() - start_time,
                provider_response_time=0.0,
                all_responses=[],
                error_message=str(e)
            )
    
    def _filter_providers(self, user_providers: Dict[str, Any], 
                           preferred_providers: List[str] = None) -> Dict[str, Any]:
        """Filter providers based on user preferences"""
        if preferred_providers:
            # Filter by user's preferred providers
            filtered = {}
            for provider_name in preferred_providers:
                if provider_name.lower() in user_providers:
                    filtered[provider_name.lower()] = user_providers[provider_name.lower()]
            return filtered
        else:
            # Use all available providers
            return user_providers
    
    async def _parallel_provision_across_providers(self, request: ProvisioningRequest, 
                                                available_providers: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Parallel provisioning across all user's available providers"""
        logger.info(f"🔄 Parallel provisioning across {len(available_providers)} providers")
        
        # Create tasks for parallel provisioning
        tasks = []
        for provider_name, provider_creds in available_providers.items():
            if provider_creds.validation_status == "valid":
                task = self._provision_from_provider(
                    request, 
                    APIProvider(provider_name), 
                    provider_creds
                )
                tasks.append(task)
            else:
                logger.warning(f"Skipping {provider_name} - credentials not valid")
        
        # Execute all provisioning requests in parallel
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        valid_results = []
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Provisioning error: {result}")
            else:
                valid_results.append(result)
        
        logger.info(f"✅ Parallel provisioning completed: {len(valid_results)} successful")
        return valid_results
    
    async def _provision_from_provider(self, request: ProvisioningRequest, 
                                       provider: APIProvider, 
                                       credentials: Any) -> Dict[str, Any]:
        """Provision from specific provider using user's API credentials"""
        start_time = time.time()
        
        try:
            # Get API session for this user and provider
            session = await self.api_manager.create_api_session(request.user_id, provider)
            
            # Make provisioning request
            result = await self.api_manager.fast_provision_gpu(
                request.user_id,
                provider,
                request.gpu_type,
                request.region,
                request.duration_hours
            )
            
            # Add provider info
            result['provider'] = provider.value
            result['provider_response_time'] = time.time() - start_time
            
            return result
        
        except Exception as e:
            logger.error(f"Provisioning from {provider.value} failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'provider': provider.value,
                'provider_response_time': time.time() - start_time
            }
    
    def _select_optimal_result(self, results: List[Dict[str, Any]], 
                             request: ProvisioningRequest) -> ProvisioningResult:
        """Select optimal result from provisioning responses"""
        successful_results = [r for r in results if r.get('success', False)]
        
        if not successful_results:
            # No successful provisions
            return ProvisioningResult(
                success=False,
                user_id=request.user_id,
                winning_provider="",
                instance_id="",
                gpu_type=request.gpu_type,
                price_per_hour=0.0,
                total_cost=0.0,
                provision_time_seconds=0.0,
                provider_response_time=0.0,
                all_responses=results,
                error_message="No successful provisioning attempts"
            )
        
        # Filter by price constraint
        affordable_results = [
            r for r in successful_results 
            if r.get('price_per_hour', float('inf')) <= request.max_price_per_hour
        ]
        
        if not affordable_results:
            # No affordable options, use cheapest available
            affordable_results = successful_results
        
        # Sort by price (primary) and response time (secondary)
        optimal = min(affordable_results, key=lambda x: (
            x.get('price_per_hour', float('inf')),
            x.get('provider_response_time', float('inf'))
        ))
        
        return ProvisioningResult(
            success=True,
            user_id=request.user_id,
            winning_provider=optimal.get('provider', ''),
            instance_id=optimal.get('instance_id', ''),
            gpu_type=request.gpu_type,
            price_per_hour=optimal.get('price_per_hour', 0.0),
            total_cost=optimal.get('estimated_cost', 0.0),
            provision_time_seconds=optimal.get('provision_time_seconds', 0.0),
            provider_response_time=optimal.get('provider_response_time', 0.0),
            all_responses=results,
            instance_details=optimal.get('instance_details')
        )
    
    def _update_provisioning_stats(self, result: ProvisioningResult, start_time: float):
        """Update provisioning statistics"""
        self.provisioning_stats["total_provisions"] += 1
        
        if result.success:
            self.provisioning_stats["successful_provisions"] += 1
            
            # Update average provision time
            current_avg = self.provisioning_stats["avg_provision_time"]
            total_successful = self.provisioning_stats["successful_provisions"]
            new_avg = ((current_avg * (total_successful - 1)) + result.provision_time_seconds) / total_successful
            self.provisioning_stats["avg_provision_time"] = new_avg
            
            # Update fastest provision time
            if result.provision_time_seconds < self.provisioning_stats["fastest_provision_time"]:
                self.provisioning_stats["fastest_provision_time"] = result.provision_time_seconds
            
            # Update provider performance
            provider = result.winning_provider
            if provider not in self.provisioning_stats["provider_performance"]:
                self.provisioning_stats["provider_performance"][provider] = {
                    "successful_provisions": 0,
                    "avg_provision_time": 0.0,
                    "avg_price": 0.0
                }
            
            provider_stats = self.provisioning_stats["provider_performance"][provider]
            provider_stats["successful_provisions"] += 1
            
            # Update provider averages
            current_avg_time = provider_stats["avg_provision_time"]
            provider_provisions = provider_stats["successful_provisions"]
            provider_stats["avg_provision_time"] = ((current_avg_time * (provider_provisions - 1)) + result.provision_time_seconds) / provider_provisions
            
            current_avg_price = provider_stats["avg_price"]
            provider_stats["avg_price"] = ((current_avg_price * (provider_provisions - 1)) + result.price_per_hour) / provider_provisions
            
            # Update user performance
            user_id = result.user_id
            if user_id not in self.provisioning_stats["user_performance"]:
                self.provisioning_stats["user_performance"][user_id] = {
                    "successful_provisions": 0,
                    "avg_provision_time": 0.0,
                    "total_savings": 0.0
                }
            
            user_stats = self.provisioning_stats["user_performance"][user_id]
            user_stats["successful_provisions"] += 1
            
            # Update user averages
            current_avg_time = user_stats["avg_provision_time"]
            user_provisions = user_stats["successful_provisions"]
            user_stats["avg_provision_time"] = ((current_avg_time * (user_provisions - 1)) + result.provision_time_seconds) / user_provisions
            
            # Calculate savings (mock calculation)
            estimated_savings = result.price_per_hour * 0.2 * request.duration_hours  # 20% savings estimate
            user_stats["total_savings"] += estimated_savings
            
        else:
            self.provisioning_stats["failed_provisions"] += 1
    
    async def get_user_provisioning_stats(self, user_id: str) -> Dict[str, Any]:
        """Get provisioning statistics for a specific user"""
        user_stats = self.provisioning_stats["user_performance"].get(user_id, {})
        
        return {
            "user_id": user_id,
            "successful_provisions": user_stats.get("successful_provisions", 0),
            "avg_provision_time": user_stats.get("avg_provision_time", 0.0),
            "total_savings": user_stats.get("total_savings", 0.0),
            "provisioning_history": self._get_user_provisioning_history(user_id)
        }
    
    def _get_user_provisioning_history(self, user_id: str) -> List[Dict[str, Any]]:
        """Get user's provisioning history"""
        # This would query the provenance database
        # For now, return mock data
        return []
    
    async def compare_user_vs_platform(self, user_id: str, gpu_type: str, 
                                        duration_hours: int) -> Dict[str, Any]:
        """Compare user's API performance vs platform averages"""
        # Get user's performance stats
        user_stats = await self.get_user_provisioning_stats(user_id)
        
        # Get platform averages
        platform_stats = self.provisioning_stats
        
        comparison = {
            "user_id": user_id,
            "user_avg_time": user_stats.get("avg_provision_time", 0.0),
            "platform_avg_time": platform_stats.get("avg_provision_time", 0.0),
            "time_improvement": 0.0,
            "user_savings": user_stats.get("total_savings", 0.0),
            "total_provisions": user_stats.get("successful_provisions", 0)
        }
        
        if platform_stats.get("avg_provision_time", 0) > 0:
            comparison["time_improvement"] = (
                (platform_stats["avg_provision_time"] - user_stats["avg_provision_time"]) / 
                platform_stats["avg_provision_time"]
            ) * 100
        
        return comparison
    
    def get_provider_rankings(self) -> List[Dict[str, Any]]:
        """Get provider performance rankings"""
        provider_stats = self.provisioning_stats["provider_performance"]
        
        rankings = []
        for provider, stats in provider_stats.items():
            if stats["successful_provisions"] > 0:
                rankings.append({
                    "provider": provider,
                    "successful_provisions": stats["successful_provisions"],
                    "avg_provision_time": stats["avg_provision_time"],
                    "avg_price": stats["avg_price"],
                    "score": self._calculate_provider_score(stats)
                })
        
        # Sort by score (higher is better)
        rankings.sort(key=lambda x: x["score"], reverse=True)
        
        return rankings
    
    def _calculate_provider_score(self, stats: Dict[str, Any]) -> float:
        """Calculate provider performance score"""
        # Score based on speed (40%), price (30%), and reliability (30%)
        speed_score = max(0, 100 - (stats["avg_provision_time"] / 10))  # Lower time is better
        price_score = max(0, 100 - (stats["avg_price"] * 20))  # Lower price is better
        reliability_score = min(100, stats["successful_provisions"] * 2)  # More provisions is better
        
        return (speed_score * 0.4 + price_score * 0.3 + reliability_score * 0.3)
    
    async def cleanup(self):
        """Clean up resources"""
        await self.api_manager.cleanup_sessions()
        logger.info("Fast Provisioning Orchestrator cleaned up")

if __name__ == "__main__":
    # Test the fast provisioning orchestrator
    print("🚀 Testing Fast Provisioning Orchestrator...")
    
    async def main():
        orchestrator = FastProvisioningOrchestrator()
        
        # Test adding credentials (mock)
        print("\n📝 Testing credential management...")
        
        # Mock user credentials
        user_id = "test_user@example.com"
        
        # Add mock credentials (would validate in real implementation)
        print("Note: In production, these would be validated against real APIs")
        
        # Test fast provisioning
        print("\n🚀 Testing fast provisioning...")
        
        request = ProvisioningRequest(
            user_id=user_id,
            gpu_type="A100",
            region="us-west-2",
            duration_hours=24,
            max_price_per_hour=5.0,
            min_memory_gb=64,
            min_storage_gb=100,
            preferred_providers=["vast_ai", "runpod", "lambda_labs"]
        )
        
        # Mock provisioning (would use real APIs in production)
        print("Note: In production, this would use real user API credentials")
        print(f"   Request: {request.gpu_type} for {request.duration_hours} hours")
        print(f"   Max price: ${request.max_price_per_hour}/hr")
        print(f"   Preferred providers: {request.preferred_providers}")
        
        # Show performance stats
        print("\n📊 Performance Statistics:")
        stats = orchestrator.provisioning_stats
        print(f"   Total provisions: {stats['total_provisions']}")
        print(f"   Successful provisions: {stats['successful_provisions']}")
        print(f"   Average provision time: {stats['avg_provision_time']:.2f}s")
        print(f"   Fastest provision time: {stats['fastest_provision_time']:.2f}s")
        
        # Show provider rankings
        print("\n🏆 Provider Rankings:")
        rankings = orchestrator.get_provider_rankings()
        for i, ranking in enumerate(rankings[:5], 1):
            print(f"   {i}. {ranking['provider']} - Score: {ranking['score']:.1f}")
        
        print("\n✅ Fast Provisioning Orchestrator working correctly!")
        
        # Cleanup
        await orchestrator.cleanup()
    
    asyncio.run(main())
