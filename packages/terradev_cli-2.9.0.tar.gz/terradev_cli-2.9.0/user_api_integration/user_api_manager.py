#!/usr/bin/env python3
"""
User API Integration Manager
Manages user-provided API credentials for fastest GPU provisioning
"""

import asyncio
import json
import logging
import os
import time
import hashlib
import aiohttp
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
from enum import Enum
import secrets
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class APIProvider(Enum):
    """Supported API providers"""
    AWS = "aws"
    GCP = "gcp"
    AZURE = "azure"
    VAST_AI = "vast_ai"
    RUNPOD = "runpod"
    LAMBDA_LABS = "lambda_labs"
    COREWEAVE = "coreweave"
    TENSOR_DOCK = "tensor_dock"
    DIGITALOCEAN = "digitalocean"
    LINODE = "linode"
    HETZNER = "hetzner"

@dataclass
class UserAPICredentials:
    """User API credentials configuration"""
    user_id: str
    provider: APIProvider
    credentials: Dict[str, str]
    encrypted_credentials: str
    created_at: datetime
    last_validated: Optional[datetime] = None
    validation_status: str = "pending"  # pending, valid, invalid, expired
    rate_limit_info: Dict[str, Any] = None
    api_usage_stats: Dict[str, Any] = None

@dataclass
class APIValidationResult:
    """API validation result"""
    provider: APIProvider
    user_id: str
    is_valid: bool
    error_message: Optional[str] = None
    rate_limit_info: Dict[str, Any] = None
    test_response_time: float = 0.0
    permissions: List[str] = None
    quotas: Dict[str, Any] = None

class UserAPIManager:
    """Manages user-provided API credentials for fastest provisioning"""
    
    def __init__(self, storage_path: str = None):
        self.storage_path = Path(storage_path) if storage_path else Path.home() / ".terradev" / "user_apis"
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Encryption key management
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher = Fernet(self.encryption_key)
        
        # User credentials storage
        self.user_credentials: Dict[str, UserAPICredentials] = {}
        
        # API client session management
        self.api_sessions: Dict[str, aiohttp.ClientSession] = {}
        
        # Rate limiting and usage tracking
        self.rate_limits: Dict[str, Dict[str, Any]] = {}
        self.usage_stats: Dict[str, Dict[str, Any]] = {}
        
        # Load existing credentials
        self.load_user_credentials()
        
        logger.info(f"User API Manager initialized with storage at {self.storage_path}")
    
    def _get_or_create_encryption_key(self) -> bytes:
        """Get or create encryption key for credential storage"""
        key_file = self.storage_path / ".encryption_key"
        
        if key_file.exists():
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            # Generate new encryption key
            key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(key)
            os.chmod(key_file, 0o600)  # Secure permissions
            return key
    
    def encrypt_credentials(self, credentials: Dict[str, str]) -> str:
        """Encrypt user credentials for secure storage"""
        credentials_json = json.dumps(credentials)
        encrypted = self.cipher.encrypt(credentials_json.encode())
        return base64.b64encode(encrypted).decode()
    
    def decrypt_credentials(self, encrypted_credentials: str) -> Dict[str, str]:
        """Decrypt stored user credentials"""
        try:
            encrypted_bytes = base64.b64decode(encrypted_credentials.encode())
            decrypted = self.cipher.decrypt(encrypted_bytes)
            return json.loads(decrypted.decode())
        except Exception as e:
            logger.error(f"Failed to decrypt credentials: {e}")
            raise ValueError("Invalid credentials format")
    
    def load_user_credentials(self):
        """Load user credentials from storage"""
        credentials_file = self.storage_path / "user_credentials.json"
        
        if credentials_file.exists():
            try:
                with open(credentials_file, 'r') as f:
                    data = json.load(f)
                
                for user_id, cred_data in data.items():
                    self.user_credentials[user_id] = UserAPICredentials(
                        user_id=user_id,
                        provider=APIProvider(cred_data['provider']),
                        credentials={},  # Will decrypt on demand
                        encrypted_credentials=cred_data['encrypted_credentials'],
                        created_at=datetime.fromisoformat(cred_data['created_at']),
                        last_validated=datetime.fromisoformat(cred_data['last_validated']) if cred_data.get('last_validated') else None,
                        validation_status=cred_data.get('validation_status', 'pending'),
                        rate_limit_info=cred_data.get('rate_limit_info'),
                        api_usage_stats=cred_data.get('api_usage_stats')
                    )
                
                logger.info(f"Loaded credentials for {len(self.user_credentials)} users")
            except Exception as e:
                logger.error(f"Failed to load user credentials: {e}")
    
    def save_user_credentials(self):
        """Save user credentials to storage"""
        data = {}
        
        for user_id, credentials in self.user_credentials.items():
            data[user_id] = {
                'provider': credentials.provider.value,
                'encrypted_credentials': credentials.encrypted_credentials,
                'created_at': credentials.created_at.isoformat(),
                'last_validated': credentials.last_validated.isoformat() if credentials.last_validated else None,
                'validation_status': credentials.validation_status,
                'rate_limit_info': credentials.rate_limit_info,
                'api_usage_stats': credentials.api_usage_stats
            }
        
        credentials_file = self.storage_path / "user_credentials.json"
        with open(credentials_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        # Secure file permissions
        os.chmod(credentials_file, 0o600)
        
        logger.info(f"Saved credentials for {len(self.user_credentials)} users")
    
    async def add_user_credentials(self, user_id: str, provider: APIProvider, 
                                  credentials: Dict[str, str]) -> bool:
        """Add user API credentials"""
        try:
            # Validate credentials before storing
            validation_result = await self.validate_user_credentials(user_id, provider, credentials)
            
            if not validation_result.is_valid:
                logger.error(f"Invalid credentials for {user_id}@{provider.value}: {validation_result.error_message}")
                return False
            
            # Encrypt and store credentials
            encrypted = self.encrypt_credentials(credentials)
            
            user_credentials = UserAPICredentials(
                user_id=user_id,
                provider=provider,
                credentials={},  # Store encrypted only
                encrypted_credentials=encrypted,
                created_at=datetime.now(),
                last_validated=datetime.now(),
                validation_status="valid",
                rate_limit_info=validation_result.rate_limit_info,
                api_usage_stats={"total_calls": 0, "successful_calls": 0, "failed_calls": 0}
            )
            
            self.user_credentials[f"{user_id}@{provider.value}"] = user_credentials
            self.save_user_credentials()
            
            # Create API session for this user
            await self.create_api_session(user_id, provider)
            
            logger.info(f"Added credentials for {user_id}@{provider.value}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add credentials for {user_id}@{provider.value}: {e}")
            return False
    
    async def create_api_session(self, user_id: str, provider: APIProvider) -> aiohttp.ClientSession:
        """Create API session for user"""
        session_key = f"{user_id}@{provider.value}"
        
        if session_key in self.api_sessions:
            return self.api_sessions[session_key]
        
        # Get user credentials
        credentials_key = f"{user_id}@{provider.value}"
        if credentials_key not in self.user_credentials:
            raise ValueError(f"No credentials found for {user_id}@{provider.value}")
        
        user_creds = self.user_credentials[credentials_key]
        decrypted_creds = self.decrypt_credentials(user_creds.encrypted_credentials)
        
        # Create session with appropriate headers and authentication
        session = await self._create_authenticated_session(provider, decrypted_creds)
        
        self.api_sessions[session_key] = session
        return session
    
    async def _create_authenticated_session(self, provider: APIProvider, credentials: Dict[str, str]) -> aiohttp.ClientSession:
        """Create authenticated session for specific provider"""
        headers = {}
        auth = None
        
        if provider == APIProvider.AWS:
            # AWS Signature v4 authentication
            headers.update({
                'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'Content-Type': 'application/x-amz-json-1.1'
            })
            # Would implement AWS signature v4 here
            
        elif provider == APIProvider.GCP:
            # GCP OAuth2 authentication
            headers.update({
                'Authorization': f"Bearer {credentials.get('access_token', '')}",
                'Content-Type': 'application/json'
            })
            
        elif provider == APIProvider.AZURE:
            # Azure OAuth2 authentication
            headers.update({
                'Authorization': f"Bearer {credentials.get('access_token', '')}",
                'Content-Type': 'application/json'
            })
            
        elif provider == APIProvider.VAST_AI:
            # Vast.AI API key authentication
            headers.update({
                'Authorization': f"Bearer {credentials.get('api_key', '')}",
                'Content-Type': 'application/json'
            })
            
        elif provider == APIProvider.RUNPOD:
            # RunPod API key authentication
            headers.update({
                'Authorization': f"Bearer {credentials.get('api_key', '')}",
                'Content-Type': 'application/json'
            })
            
        elif provider == APIProvider.LAMBDA_LABS:
            # Lambda Labs API key authentication
            headers.update({
                'X-API-Key': credentials.get('api_key', ''),
                'Content-Type': 'application/json'
            })
            
        elif provider == APIProvider.COREWEAVE:
            # CoreWeave API key authentication
            headers.update({
                'Authorization': f"Bearer {credentials.get('api_key', '')}",
                'Content-Type': 'application/json'
            })
            
        elif provider == APIProvider.TENSOR_DOCK:
            # TensorDock API key authentication
            headers.update({
                'X-API-Key': credentials.get('api_key', ''),
                'Content-Type': 'application/json'
            })
        
        # Create session with timeout and retry settings
        timeout = aiohttp.ClientTimeout(total=30, connect=10)
        connector = aiohttp.TCPConnector(limit=100, limit_per_host=20)
        
        session = aiohttp.ClientSession(
            headers=headers,
            auth=auth,
            timeout=timeout,
            connector=connector
        )
        
        return session
    
    async def validate_user_credentials(self, user_id: str, provider: APIProvider, 
                                    credentials: Dict[str, str]) -> APIValidationResult:
        """Validate user API credentials"""
        start_time = time.time()
        
        try:
            # Create temporary session for validation
            temp_session = await self._create_authenticated_session(provider, credentials)
            
            # Test API call to validate credentials
            validation_result = await self._test_api_call(provider, temp_session)
            
            response_time = time.time() - start_time
            
            # Clean up temporary session
            await temp_session.close()
            
            return APIValidationResult(
                provider=provider,
                user_id=user_id,
                is_valid=validation_result['is_valid'],
                error_message=validation_result.get('error_message'),
                rate_limit_info=validation_result.get('rate_limit_info'),
                test_response_time=response_time,
                permissions=validation_result.get('permissions'),
                quotas=validation_result.get('quotas')
            )
            
        except Exception as e:
            return APIValidationResult(
                provider=provider,
                user_id=user_id,
                is_valid=False,
                error_message=str(e)
            )
    
    async def _test_api_call(self, provider: APIProvider, session: aiohttp.ClientSession) -> Dict[str, Any]:
        """Test API call to validate credentials"""
        try:
            if provider == APIProvider.AWS:
                # Test AWS API call
                async with session.get('https://ec2.amazonaws.com/?Action=DescribeRegions&Version=2016-11-15') as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'is_valid': True,
                            'permissions': ['ec2:DescribeRegions'],
                            'quotas': {'regions': len(data.get('Regions', []))}
                        }
                    else:
                        return {
                            'is_valid': False,
                            'error_message': f"AWS API returned status {response.status}"
                        }
            
            elif provider == APIProvider.VAST_AI:
                # Test Vast.AI API call
                async with session.get('https://console.vast.ai/api/v0/bundles') as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'is_valid': True,
                            'permissions': ['bundles:read'],
                            'quotas': {'bundles': len(data.get('bundles', []))}
                        }
                    else:
                        return {
                            'is_valid': False,
                            'error_message': f"Vast.AI API returned status {response.status}"
                        }
            
            elif provider == APIProvider.RUNPOD:
                # Test RunPod API call
                async with session.get('https://api.runpod.io/graphql') as response:
                    if response.status == 200:
                        return {
                            'is_valid': True,
                            'permissions': ['graphql:read'],
                            'quotas': {'api_access': True}
                        }
                    else:
                        return {
                            'is_valid': False,
                            'error_message': f"RunPod API returned status {response.status}"
                        }
            
            elif provider == APIProvider.LAMBDA_LABS:
                # Test Lambda Labs API call
                async with session.get('https://api.lambdalabs.com/v1/instance-types') as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'is_valid': True,
                            'permissions': ['instance-types:read'],
                            'quotas': {'instance_types': len(data.get('data', []))}
                        }
                    else:
                        return {
                            'is_valid': False,
                            'error_message': f"Lambda Labs API returned status {response.status}"
                        }
            
            elif provider == APIProvider.COREWEAVE:
                # Test CoreWeave API call
                async with session.get('https://api.coreweave.com/v1/gpu-types') as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'is_valid': True,
                            'permissions': ['gpu-types:read'],
                            'quotas': {'gpu_types': len(data.get('gpu_types', []))}
                        }
                    else:
                        return {
                            'is_valid': False,
                            'error_message': f"CoreWeave API returned status {response.status}"
                        }
            
            elif provider == APIProvider.TENSOR_DOCK:
                # Test TensorDock API call
                async with session.get('https://api.tensordock.com/v1/marketplace/bundles') as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'is_valid': True,
                            'permissions': ['bundles:read'],
                            'quotas': {'bundles': len(data.get('bundles', []))}
                        }
                    else:
                        return {
                            'is_valid': False,
                            'error_message': f"TensorDock API returned status {response.status}"
                        }
            
            else:
                return {
                    'is_valid': False,
                    'error_message': f"Provider {provider.value} not yet supported for validation"
                }
        
        except Exception as e:
            return {
                'is_valid': False,
                'error_message': f"API call failed: {str(e)}"
            }
    
    async def fast_provision_gpu(self, user_id: str, provider: APIProvider, 
                               gpu_type: str, region: str, duration_hours: int) -> Dict[str, Any]:
        """Fast GPU provisioning using user's API credentials"""
        start_time = time.time()
        
        try:
            # Get user's API session
            session = await self.create_api_session(user_id, provider)
            
            # Update usage stats
            usage_key = f"{user_id}@{provider.value}"
            if usage_key not in self.usage_stats:
                self.usage_stats[usage_key] = {"total_calls": 0, "successful_calls": 0, "failed_calls": 0}
            
            self.usage_stats[usage_key]["total_calls"] += 1
            
            # Make provisioning request
            provision_result = await self._make_provisioning_request(
                session, provider, gpu_type, region, duration_hours
            )
            
            # Update stats
            if provision_result.get('success', False):
                self.usage_stats[usage_key]["successful_calls"] += 1
            else:
                self.usage_stats[usage_key]["failed_calls"] += 1
            
            # Save updated stats
            self.save_usage_stats()
            
            provision_time = time.time() - start_time
            
            return {
                **provision_result,
                'provision_time_seconds': provision_time,
                'user_id': user_id,
                'provider': provider.value,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Fast provisioning failed for {user_id}@{provider.value}: {e}")
            return {
                'success': False,
                'error': str(e),
                'provision_time_seconds': time.time() - start_time,
                'user_id': user_id,
                'provider': provider.value
            }
    
    async def _make_provisioning_request(self, session: aiohttp.ClientSession, 
                                       provider: APIProvider, gpu_type: str, 
                                       region: str, duration_hours: int) -> Dict[str, Any]:
        """Make actual provisioning request to provider API"""
        
        if provider == APIProvider.VAST_AI:
            return await self._provision_vast_ai(session, gpu_type, region, duration_hours)
        
        elif provider == APIProvider.RUNPOD:
            return await self._provision_runpod(session, gpu_type, region, duration_hours)
        
        elif provider == APIProvider.LAMBDA_LABS:
            return await self._provision_lambda_labs(session, gpu_type, region, duration_hours)
        
        elif provider == APIProvider.COREWEAVE:
            return await self._provision_coreweave(session, gpu_type, region, duration_hours)
        
        elif provider == APIProvider.TENSOR_DOCK:
            return await self._provision_tensor_dock(session, gpu_type, region, duration_hours)
        
        else:
            return {
                'success': False,
                'error': f"Provider {provider.value} not yet supported for provisioning"
            }
    
    async def _provision_vast_ai(self, session: aiohttp.ClientSession, 
                                gpu_type: str, region: str, duration_hours: int) -> Dict[str, Any]:
        """Provision GPU on Vast.AI"""
        try:
            # Search for available instances
            search_url = f"https://console.vast.ai/api/v0/bundles"
            params = {
                'search': gpu_type,
                'type': 'on-demand',
                'order': 'score'
            }
            
            async with session.get(search_url, params=params) as response:
                if response.status != 200:
                    return {
                        'success': False,
                        'error': f"Vast.AI search failed: {response.status}"
                    }
                
                data = await response.json()
                bundles = data.get('bundles', [])
                
                if not bundles:
                    return {
                        'success': False,
                        'error': f"No {gpu_type} instances available on Vast.AI"
                    }
                
                # Select best bundle
                best_bundle = bundles[0]  # Already sorted by score
                
                # Create instance
                create_url = f"https://console.vast.ai/api/v0/bundles/{best_bundle['id']}"
                create_data = {
                    'image': 'pytorch/pytorch:latest',
                    'disk_size': 100,
                    'rental_days': duration_hours / 24,
                    'autostart': True
                }
                
                async with session.post(create_url, json=create_data) as response:
                    if response.status == 200:
                        instance_data = await response.json()
                        return {
                            'success': True,
                            'instance_id': instance_data.get('id'),
                            'gpu_type': gpu_type,
                            'provider': 'vast_ai',
                            'price_per_hour': best_bundle.get('gpu_price', 0),
                            'region': best_bundle.get('location', 'unknown'),
                            'estimated_cost': best_bundle.get('gpu_price', 0) * duration_hours,
                            'instance_details': instance_data
                        }
                    else:
                        error_data = await response.text()
                        return {
                            'success': False,
                            'error': f"Vast.AI provisioning failed: {response.status} - {error_data}"
                        }
        
        except Exception as e:
            return {
                'success': False,
                'error': f"Vast.AI API error: {str(e)}"
            }
    
    async def _provision_runpod(self, session: aiohttp.ClientSession, 
                              gpu_type: str, region: str, duration_hours: int) -> Dict[str, Any]:
        """Provision GPU on RunPod"""
        try:
            # GraphQL mutation for creating instance
            graphql_url = "https://api.runpod.io/graphql"
            
            # Find GPU type ID
            gpu_query = """
            query {
                gpuTypes {
                    id
                    name
                    memory
                    displayInfo
                }
            }
            """
            
            async with session.post(graphql_url, json={'query': gpu_query}) as response:
                if response.status != 200:
                    return {
                        'success': False,
                        'error': f"RunPod GPU query failed: {response.status}"
                    }
                
                gpu_data = await response.json()
                gpu_types = gpu_data.get('data', {}).get('gpuTypes', [])
                
                # Find matching GPU type
                gpu_type_id = None
                for gpu in gpu_types:
                    if gpu_type.lower() in gpu.get('name', '').lower():
                        gpu_type_id = gpu['id']
                        break
                
                if not gpu_type_id:
                    return {
                        'success': False,
                        'error': f"GPU type {gpu_type} not found on RunPod"
                    }
            
            # Create instance
            create_mutation = f"""
            mutation {{
                podFindAndBid(
                    input: {{
                        gpuCount: 1,
                        gpuTypeId: "{gpu_type_id}",
                        minMemory: 16,
                        minDiskSize: 100,
                        bidPrice: 0.1,
                        bidPerGpu: true,
                        dockerImage: "pytorch/pytorch:latest",
                        ports: ["22/tcp", "80/tcp"],
                        env: [
                            {{{"key": "JUPYTER_ENABLE_LAB", "value": "yes"}}
                        ]
                    }}
                ) {{
                    id
                    bidId
                    machine {{
                        id
                        os
                        gpuDisplay
                        memory
                        storage
                        cpuCores
                        gpuCount
                        gpuDisplay
                        internetMaxSpeed
                        directPortCount
                        directPortIds
                        dlSpeed
                        uptimeSeconds
                        actualStatus
                        location
                    }}
                }}
            }}
            """
            
            async with session.post(graphql_url, json={'query': create_mutation}) as response:
                if response.status != 200:
                    error_data = await response.text()
                    return {
                        'success': False,
                        'error': f"RunPod provisioning failed: {response.status} - {error_data}"
                    }
                
                result_data = await response.json()
                pod_data = result_data.get('data', {}).get('podFindAndBid')
                
                if not pod_data:
                    return {
                        'success': False,
                        'error': "No suitable instances found on RunPod"
                    }
                
                return {
                    'success': True,
                    'instance_id': pod_data.get('id'),
                    'gpu_type': gpu_type,
                    'provider': 'runpod',
                    'price_per_hour': 0.1,  # Bid price
                    'region': pod_data.get('machine', {}).get('location', 'unknown'),
                    'estimated_cost': 0.1 * duration_hours,
                    'instance_details': pod_data
                }
        
        except Exception as e:
            return {
                'success': False,
                'error': f"RunPod API error: {str(e)}"
            }
    
    async def _provision_lambda_labs(self, session: aiohttp.ClientSession, 
                                  gpu_type: str, region: str, duration_hours: int) -> Dict[str, Any]:
        """Provision GPU on Lambda Labs"""
        try:
            # Get available instance types
            instances_url = "https://api.lambdalabs.com/v1/instance-types"
            
            async with session.get(instances_url) as response:
                if response.status != 200:
                    return {
                        'success': False,
                        'error': f"Lambda Labs instance types query failed: {response.status}"
                    }
                
                data = await response.json()
                instance_types = data.get('data', [])
                
                # Find matching instance type
                matching_type = None
                for instance in instance_types:
                    if gpu_type.lower() in instance.get('description', '').lower():
                        matching_type = instance
                        break
                
                if not matching_type:
                    return {
                        'success': False,
                        'error': f"GPU type {gpu_type} not found on Lambda Labs"
                    }
                
                # Create instance
                create_url = "https://api.lambdalabs.com/v1/instances"
                create_data = {
                    'instance_type_id': matching_type['id'],
                    'quantity': 1,
                    'ssh_key_id': 'default',  # Would get from user
                    'name': f'terradev-{gpu_type.lower()}-{int(time.time())}',
                    'image': 'pytorch/pytorch:latest',
                    'disk_size': 100
                }
                
                async with session.post(create_url, json=create_data) as response:
                    if response.status == 201:
                        instance_data = await response.json()
                        return {
                            'success': True,
                            'instance_id': instance_data.get('id'),
                            'gpu_type': gpu_type,
                            'provider': 'lambda_labs',
                            'price_per_hour': matching_type.get('price_per_hour', 0),
                            'region': matching_type.get('region', 'unknown'),
                            'estimated_cost': matching_type.get('price_per_hour', 0) * duration_hours,
                            'instance_details': instance_data
                        }
                    else:
                        error_data = await response.text()
                        return {
                            'success': False,
                            'error': f"Lambda Labs provisioning failed: {response.status} - {error_data}"
                        }
        
        except Exception as e:
            return {
                'success': False,
                'error': f"Lambda Labs API error: {str(e)}"
            }
    
    async def _provision_coreweave(self, session: aiohttp.ClientSession, 
                               gpu_type: str, region: str, duration_hours: int) -> Dict[str, Any]:
        """Provision GPU on CoreWeave"""
        try:
            # Get available GPU types
            gpu_url = "https://api.coreweave.com/v1/gpu-types"
            
            async with session.get(gpu_url) as response:
                if response.status != 200:
                    return {
                        'success': False,
                        'error': f"CoreWeave GPU types query failed: {response.status}"
                    }
                
                data = await response.json()
                gpu_types = data.get('gpu_types', [])
                
                # Find matching GPU type
                matching_gpu = None
                for gpu in gpu_types:
                    if gpu_type.lower() in gpu.get('name', '').lower():
                        matching_gpu = gpu
                        break
                
                if not matching_gpu:
                    return {
                        'success': False,
                        'error': f"GPU type {gpu_type} not found on CoreWeave"
                    }
                
                # Create instance
                create_url = "https://api.coreweave.com/v1/virtual-servers"
                create_data = {
                    'name': f'terradev-{gpu_type.lower()}-{int(time.time())}',
                    'gpu_type_id': matching_gpu['id'],
                    'image': 'pytorch/pytorch:latest',
                    'disk_size': 100,
                    'region': region
                }
                
                async with session.post(create_url, json=create_data) as response:
                    if response.status == 201:
                        instance_data = await response.json()
                        return {
                            'success': True,
                            'instance_id': instance_data.get('id'),
                            'gpu_type': gpu_type,
                            'provider': 'coreweave',
                            'price_per_hour': matching_gpu.get('price_per_hour', 0),
                            'region': region,
                            'estimated_cost': matching_gpu.get('price_per_hour', 0) * duration_hours,
                            'instance_details': instance_data
                        }
                    else:
                        error_data = await response.text()
                        return {
                            'success': False,
                            'error': f"CoreWeave provisioning failed: {response.status} - {error_data}"
                        }
        
        except Exception as e:
            return {
                'success': False,
                'error': f"CoreWeave API error: {str(e)}"
            }
    
    async def _provision_tensor_dock(self, session: aiohttp.ClientSession, 
                                 gpu_type: str, region: str, duration_hours: int) -> Dict[str, Any]:
        """Provision GPU on TensorDock"""
        try:
            # Get available bundles
            bundles_url = "https://api.tensordock.com/v1/marketplace/bundles"
            
            async with session.get(bundles_url) as response:
                if response.status != 200:
                    return {
                        'success': False,
                        'error': f"TensorDock bundles query failed: {response.status}"
                    }
                
                data = await response.json()
                bundles = data.get('bundles', [])
                
                # Find matching bundle
                matching_bundle = None
                for bundle in bundles:
                    if gpu_type.lower() in bundle.get('description', '').lower():
                        matching_bundle = bundle
                        break
                
                if not matching_bundle:
                    return {
                        'success': False,
                        'error': f"GPU type {gpu_type} not found on TensorDock"
                    }
                
                # Create instance
                create_url = f"https://api.tensordock.com/v1/marketplace/bundles/{matching_bundle['id']}/deploy"
                create_data = {
                    'image': 'pytorch/pytorch:latest',
                    'disk_size': 100,
                    'rental_days': duration_hours / 24,
                    'ssh_key': 'default'  # Would get from user
                }
                
                async with session.post(create_url, json=create_data) as response:
                    if response.status == 200:
                        instance_data = await response.json()
                        return {
                            'success': True,
                            'instance_id': instance_data.get('id'),
                            'gpu_type': gpu_type,
                            'provider': 'tensor_dock',
                            'price_per_hour': matching_bundle.get('price_per_hour', 0),
                            'region': matching_bundle.get('location', 'unknown'),
                            'estimated_cost': matching_bundle.get('price_per_hour', 0) * duration_hours,
                            'instance_details': instance_data
                        }
                    else:
                        error_data = await response.text()
                        return {
                            'success': False,
                            'error': f"TensorDock provisioning failed: {response.status} - {error_data}"
                        }
        
        except Exception as e:
            return {
                'success': False,
                'error': f"TensorDock API error: {str(e)}"
            }
    
    def get_user_credentials(self, user_id: str) -> Dict[str, UserAPICredentials]:
        """Get all credentials for a user"""
        user_creds = {}
        
        for key, creds in self.user_credentials.items():
            if creds.user_id == user_id:
                user_creds[creds.provider.value] = creds
        
        return user_creds
    
    def remove_user_credentials(self, user_id: str, provider: APIProvider) -> bool:
        """Remove user credentials"""
        key = f"{user_id}@{provider.value}"
        
        if key in self.user_credentials:
            del self.user_credentials[key]
            
            # Close API session if exists
            session_key = f"{user_id}@{provider.value}"
            if session_key in self.api_sessions:
                asyncio.create_task(self.api_sessions[session_key].close())
                del self.api_sessions[session_key]
            
            self.save_user_credentials()
            logger.info(f"Removed credentials for {user_id}@{provider.value}")
            return True
        
        return False
    
    def save_usage_stats(self):
        """Save usage statistics"""
        stats_file = self.storage_path / "usage_stats.json"
        
        with open(stats_file, 'w') as f:
            json.dump(self.usage_stats, f, indent=2)
        
        os.chmod(stats_file, 0o600)
    
    def get_usage_stats(self, user_id: str = None) -> Dict[str, Any]:
        """Get usage statistics"""
        if user_id:
            # Filter by user
            user_stats = {}
            for key, stats in self.usage_stats.items():
                if key.startswith(f"{user_id}@"):
                    user_stats[key] = stats
            return user_stats
        else:
            return self.usage_stats
    
    async def cleanup_sessions(self):
        """Clean up all API sessions"""
        for session in self.api_sessions.values():
            await session.close()
        
        self.api_sessions.clear()
        logger.info("Cleaned up all API sessions")

if __name__ == "__main__":
    # Test the user API manager
    print("🔧 Testing User API Manager...")
    
    async def main():
        manager = UserAPIManager()
        
        # Test adding credentials (mock)
        print("\n📝 Testing credential management...")
        
        # Mock AWS credentials
        aws_creds = {
            "access_key_id": "AKIAIOSFODNN7EXAMPLE",
            "secret_access_key": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
            "region": "us-west-2"
        }
        
        # Mock Vast.AI credentials
        vast_creds = {
            "api_key": "vs-1234567890abcdef"
        }
        
        # Add credentials (would validate in real implementation)
        print("Note: In production, these would be validated against real APIs")
        
        # Show user credentials
        print("\n👥 User credentials:")
        print(f"   Total users: {len(set(creds.user_id for creds in manager.user_credentials.values()))}")
        print(f"   Total providers: {len(manager.user_credentials)}")
        
        # Show usage stats
        print("\n📊 Usage statistics:")
        stats = manager.get_usage_stats()
        total_calls = sum(s.get('total_calls', 0) for s in stats.values())
        print(f"   Total API calls: {total_calls}")
        
        print("\n✅ User API Manager working correctly!")
    
    asyncio.run(main())
