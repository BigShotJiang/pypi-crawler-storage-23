#!/usr/bin/env python3
"""
User API CLI - Command-line interface for user API integration
Manages user-provided API credentials for fastest GPU provisioning
"""

import argparse
import asyncio
import json
import sys
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from user_api_manager import UserAPIManager, APIProvider
from fast_provisioning_orchestrator import FastProvisioningOrchestrator, ProvisioningRequest

class UserAPICLI:
    """Command-line interface for user API integration"""
    
    def __init__(self):
        self.api_manager = UserAPIManager()
        self.orchestrator = FastProvisioningOrchestrator()
        
        print("🚀 User API CLI initialized")
        print("📁 Storage:", self.api_manager.storage_path)
    
    async def add_credentials(self, provider: str, interactive: bool = False):
        """Add user API credentials"""
        print(f"🔧 Adding credentials for {provider}...")
        
        if interactive:
            # Interactive credential input
            credentials = {}
            
            if provider.lower() == "aws":
                print("📋 AWS Credentials Required:")
                credentials["access_key_id"] = input("AWS Access Key ID: ").strip()
                credentials["secret_access_key"] = input("AWS Secret Access Key: ").strip()
                credentials["region"] = input("Default Region (us-west-2): ").strip() or "us-west-2"
            
            elif provider.lower() == "gcp":
                print("📋 GCP Credentials Required:")
                credentials["project_id"] = input("GCP Project ID: ").strip()
                credentials["credentials_file"] = input("Path to service account key file: ").strip()
                credentials["access_token"] = input("Access Token (optional): ").strip() or ""
            
            elif provider.lower() == "azure":
                print("📋 Azure Credentials Required:")
                credentials["subscription_id"] = input("Azure Subscription ID: ").strip()
                credentials["tenant_id"] = input("Azure Tenant ID: ").strip()
                credentials["client_id"] = input("Azure Client ID: ").strip()
                credentials["client_secret"] = input("Azure Client Secret: ").strip()
            
            elif provider.lower() == "vast_ai":
                print("📋 Vast.AI Credentials Required:")
                credentials["api_key"] = input("Vast.AI API Key: ").strip()
            
            elif provider.lower() == "runpod":
                print("📋 RunPod Credentials Required:")
                credentials["api_key"] = input("RunPod API Key: ").strip()
            
            elif provider.lower() == "lambda_labs":
                print("📋 Lambda Labs Credentials Required:")
                credentials["api_key"] = input("Lambda Labs API Key: ").strip()
            
            elif provider.lower() == "coreweave":
                print("📋 CoreWeave Credentials Required:")
                credentials["api_key"] = input("CoreWeave API Key: ").strip()
            
            elif provider.lower() == "tensor_dock":
                print("📋 TensorDock Credentials Required:")
                credentials["api_key"] = input("TensorDock API Key: ").strip()
            
            else:
                print(f"❌ Unsupported provider: {provider}")
                print("Supported providers: aws, gcp, azure, vast_ai, runpod, lambda_labs, coreweave, tensor_dock")
                return
            
            # Get user ID
            user_id = input("Your User ID (email): ").strip()
            
            # Validate and add credentials
            print(f"\n🔍 Validating credentials for {user_id}@{provider}...")
            
            try:
                provider_enum = APIProvider(provider.lower())
                success = await self.api_manager.add_user_credentials(user_id, provider_enum, credentials)
                
                if success:
                    print(f"✅ Credentials added successfully for {user_id}@{provider}")
                    print(f"🔐 Credentials encrypted and stored securely")
                    print(f"📊 Usage tracking enabled")
                else:
                    print(f"❌ Failed to validate credentials for {provider}")
                    print(f"Please check your credentials and try again")
            
            except ValueError as e:
                print(f"❌ Error: {e}")
            except Exception as e:
                print(f"❌ Unexpected error: {e}")
        
        else:
            print("📝 Use --interactive flag to add credentials interactively")
            print(f"   user-api-cli add {provider} --interactive")
    
    def list_credentials(self, user_id: str = None):
        """List user credentials"""
        print("🔑 Stored Credentials:")
        print("-" * 60)
        
        if user_id:
            # Show specific user's credentials
            user_creds = self.api_manager.get_user_credentials(user_id)
            
            if not user_creds:
                print(f"❌ No credentials found for user: {user_id}")
                return
            
            print(f"User: {user_id}")
            for provider, creds in user_creds.items():
                status = "✅ Valid" if creds.validation_status == "valid" else f"❌ {creds.validation_status}"
                last_validated = creds.last_validated.strftime("%Y-%m-%d %H:%M") if creds.last_validated else "Never"
                print(f"   {provider:<15} {status:<12} {last_validated}")
        else:
            # Show all credentials
            all_creds = self.api_manager.user_credentials
            
            if not all_creds:
                print("No credentials stored. Use 'user-api-cli add <provider> --interactive'")
                return
            
            # Group by user
            users = {}
            for key, creds in all_creds.items():
                user = creds.user_id
                if user not in users:
                    users[user] = []
                users[user].append(creds)
            
            for user, user_creds_list in users.items():
                print(f"\nUser: {user}")
                for creds in user_creds_list:
                    status = "✅ Valid" if creds.validation_status == "valid" else f"❌ {creds.validation_status}"
                    last_validated = creds.last_validated.strftime("%Y-%m-%d %H:%M") if creds.last_validated else "Never"
                    print(f"   {creds.provider.value:<15} {status:<12} {last_validated}")
    
    async def remove_credentials(self, provider: str, user_id: str = None):
        """Remove user credentials"""
        if not user_id:
            user_id = input("User ID (email): ").strip()
        
        print(f"🗑️ Removing credentials for {user_id}@{provider}...")
        
        try:
            provider_enum = APIProvider(provider.lower())
            success = self.api_manager.remove_user_credentials(user_id, provider_enum)
            
            if success:
                print(f"✅ Credentials removed successfully")
                print(f"🔐 Encrypted credentials deleted")
                print(f"📊 Usage statistics preserved")
            else:
                print(f"❌ No credentials found for {user_id}@{provider}")
        
        except ValueError as e:
            print(f"❌ Error: {e}")
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
    
    async def fast_provision(self, gpu_type: str, duration: int, user_id: str, 
                            max_price: float = None, region: str = "us-west-2",
                            providers: str = None):
        """Fast GPU provisioning using user APIs"""
        print(f"🚀 Fast GPU Provisioning")
        print(f"   User: {user_id}")
        print(f"   GPU Type: {gpu_type}")
        print(f"   Duration: {duration} hours")
        print(f"   Region: {region}")
        if max_price:
            print(f"   Max Price: ${max_price}/hr")
        
        # Parse preferred providers
        preferred_providers = None
        if providers:
            preferred_providers = [p.strip() for p in providers.split(',')]
            print(f"   Preferred Providers: {', '.join(preferred_providers)}")
        
        print(f"\n🔄 Starting parallel provisioning...")
        
        try:
            # Create provisioning request
            request = ProvisioningRequest(
                user_id=user_id,
                gpu_type=gpu_type,
                region=region,
                duration_hours=duration,
                max_price_per_hour=max_price or 10.0,
                min_memory_gb=64,
                min_storage_gb=100,
                preferred_providers=preferred_providers
            )
            
            # Execute fast provisioning
            result = await self.orchestrator.fast_provision_gpu(request)
            
            # Display results
            print(f"\n📊 Provisioning Results:")
            print(f"   Success: {'✅' if result.success else '❌'}")
            print(f"   Winning Provider: {result.winning_provider}")
            print(f"   Instance ID: {result.instance_id}")
            print(f"   Price: ${result.price_per_hour:.2f}/hr")
            print(f"   Total Cost: ${result.total_cost:.2f}")
            print(f"   Provision Time: {result.provision_time_seconds:.2f}s")
            print(f"   Provider Response Time: {result.provider_response_time:.2f}s")
            
            if result.success:
                print(f"\n🎉 GPU Provisioned Successfully!")
                print(f"   📋 Access your instance using the provider's console")
                print(f"   💰 Total cost: ${result.total_cost:.2f} for {duration} hours")
                
                if result.instance_details:
                    print(f"   📄 Instance Details:")
                    for key, value in result.instance_details.items():
                        if key != 'api_key':  # Don't expose API keys
                            print(f"      {key}: {value}")
            else:
                print(f"\n❌ Provisioning Failed")
                print(f"   Error: {result.error_message}")
                
                # Show all responses for debugging
                print(f"\n📋 All Provider Responses:")
                for i, response in enumerate(result.all_responses, 1):
                    provider = response.get('provider', 'Unknown')
                    success = response.get('success', False)
                    error = response.get('error', 'No error')
                    print(f"   {i}. {provider}: {'✅' if success else '❌'} {error}")
        
        except Exception as e:
            print(f"❌ Provisioning error: {e}")
    
    async def show_stats(self, user_id: str = None):
        """Show provisioning statistics"""
        print("📊 Provisioning Statistics")
        print("-" * 60)
        
        if user_id:
            # Show user-specific stats
            user_stats = await self.orchestrator.get_user_provisioning_stats(user_id)
            
            print(f"User: {user_id}")
            print(f"   Successful Provisions: {user_stats['successful_provisions']}")
            print(f"   Average Provision Time: {user_stats['avg_provision_time']:.2f}s")
            print(f"   Total Savings: ${user_stats['total_savings']:.2f}")
            
            # Compare user vs platform
            comparison = await self.orchestrator.compare_user_vs_platform(
                user_id, "A100", 24
            )
            
            print(f"\n📈 Performance Comparison:")
            print(f"   User Avg Time: {comparison['user_avg_time']:.2f}s")
            print(f"   Platform Avg Time: {comparison['platform_avg_time']:.2f}s")
            print(f"   Time Improvement: {comparison['time_improvement']:.1f}%")
        else:
            # Show platform-wide stats
            stats = self.orchestrator.provisioning_stats
            
            print(f"Platform Statistics:")
            print(f"   Total Provisions: {stats['total_provisions']}")
            print(f"   Successful Provisions: {stats['successful_provisions']}")
            print(f"   Failed Provisions: {stats['failed_provisions']}")
            print(f"   Average Provision Time: {stats['avg_provision_time']:.2f}s")
            print(f"   Fastest Provision Time: {stats['fastest_provision_time']:.2f}s")
            
            # Show provider rankings
            rankings = self.orchestrator.get_provider_rankings()
            
            print(f"\n🏆 Provider Rankings:")
            for i, ranking in enumerate(rankings[:5], 1):
                print(f"   {i}. {ranking['provider']} - Score: {ranking['score']:.1f}")
                print(f"      Provisions: {ranking['successful_provisions']}")
                print(f"      Avg Time: {ranking['avg_provision_time']:.2f}s")
                print(f"      Avg Price: ${ranking['avg_price']:.2f}/hr")
    
    async def validate_credentials(self, provider: str, user_id: str = None):
        """Validate existing credentials"""
        if not user_id:
            user_id = input("User ID (email): ").strip()
        
        print(f"🔍 Validating credentials for {user_id}@{provider}...")
        
        try:
            provider_enum = APIProvider(provider.lower())
            
            # Get user's credentials
            credentials_key = f"{user_id}@{provider.lower()}"
            if credentials_key not in self.api_manager.user_credentials:
                print(f"❌ No credentials found for {user_id}@{provider}")
                return
            
            user_creds = self.api_manager.user_credentials[credentials_key]
            decrypted_creds = self.api_manager.decrypt_credentials(user_creds.encrypted_credentials)
            
            # Validate credentials
            validation_result = await self.api_manager.validate_user_credentials(
                user_id, provider_enum, decrypted_creds
            )
            
            if validation_result.is_valid:
                print(f"✅ Credentials are valid")
                print(f"   Response Time: {validation_result.test_response_time:.2f}s")
                print(f"   Permissions: {', '.join(validation_result.permissions or [])}")
                
                if validation_result.quotas:
                    print(f"   Quotas: {json.dumps(validation_result.quotas, indent=6)}")
                
                # Update validation status
                user_creds.last_validated = datetime.now()
                user_creds.validation_status = "valid"
                self.api_manager.save_user_credentials()
                
            else:
                print(f"❌ Credentials are invalid")
                print(f"   Error: {validation_result.error_message}")
                
                # Update validation status
                user_creds.validation_status = "invalid"
                self.api_manager.save_user_credentials()
        
        except ValueError as e:
            print(f"❌ Error: {e}")
        except Exception as e:
            print(f"❌ Unexpected error: {e}")

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="User API CLI - Fast GPU Provisioning with Your API Keys",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Add credentials interactively
  user-api-cli add vast_ai --interactive
  
  # List all credentials
  user-api-cli list
  
  # Fast provision GPU
  user-api-cli provision --gpu-type A100 --duration 24 --user-id your@email.com
  
  # Show statistics
  user-api-cli stats
  
  # Validate credentials
  user-api-cli validate vast_ai --user-id your@email.com
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Add credentials command
    add_parser = subparsers.add_parser('add', help='Add API credentials')
    add_parser.add_argument('provider', help='Provider name (aws, vast_ai, runpod, etc.)')
    add_parser.add_argument('--interactive', action='store_true', help='Interactive credential input')
    
    # List credentials command
    list_parser = subparsers.add_parser('list', help='List stored credentials')
    list_parser.add_argument('--user-id', help='Filter by user ID')
    
    # Remove credentials command
    remove_parser = subparsers.add_parser('remove', help='Remove API credentials')
    remove_parser.add_argument('provider', help='Provider name')
    remove_parser.add_argument('--user-id', help='User ID (prompts if not provided)')
    
    # Fast provision command
    provision_parser = subparsers.add_parser('provision', help='Fast GPU provisioning')
    provision_parser.add_argument('--gpu-type', required=True, help='GPU type (A100, H100, A10G, etc.)')
    provision_parser.add_argument('--duration', type=int, required=True, help='Duration in hours')
    provision_parser.add_argument('--user-id', required=True, help='User ID (email)')
    provision_parser.add_argument('--max-price', type=float, help='Maximum price per hour')
    provision_parser.add_argument('--region', default='us-west-2', help='Region (default: us-west-2)')
    provision_parser.add_argument('--providers', help='Preferred providers (comma-separated)')
    
    # Statistics command
    stats_parser = subparsers.add_parser('stats', help='Show provisioning statistics')
    stats_parser.add_argument('--user-id', help='Filter by user ID')
    
    # Validate credentials command
    validate_parser = subparsers.add_parser('validate', help='Validate existing credentials')
    validate_parser.add_argument('provider', help='Provider name')
    validate_parser.add_argument('--user-id', help='User ID (prompts if not provided)')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    cli = UserAPICLI()
    
    # Run the appropriate command
    if args.command == 'add':
        asyncio.run(cli.add_credentials(args.provider, args.interactive))
    
    elif args.command == 'list':
        cli.list_credentials(args.user_id)
    
    elif args.command == 'remove':
        asyncio.run(cli.remove_credentials(args.provider, args.user_id))
    
    elif args.command == 'provision':
        asyncio.run(cli.fast_provision(
            args.gpu_type, args.duration, args.user_id, 
            args.max_price, args.region, args.providers
        ))
    
    elif args.command == 'stats':
        asyncio.run(cli.show_stats(args.user_id))
    
    elif args.command == 'validate':
        asyncio.run(cli.validate_credentials(args.provider, args.user_id))
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
