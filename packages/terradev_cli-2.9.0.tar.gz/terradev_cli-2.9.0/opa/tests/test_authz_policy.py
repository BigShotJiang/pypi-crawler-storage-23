#!/usr/bin/env python3
"""
Test suite for the OPA authorization policy
"""

import pytest
import json
from pathlib import Path

# Import OPA evaluation (in a real implementation, you'd use the OPA library)
# For this demo, we'll simulate the policy evaluation

class MockOPA:
    """Mock OPA evaluator for testing"""
    
    def __init__(self):
        self.policy = self.load_policy()
    
    def load_policy(self):
        """Load the authorization policy"""
        policy_file = Path(__file__).parent.parent / "policies" / "application" / "authz.rego"
        with open(policy_file, 'r') as f:
            return f.read()
    
    def evaluate(self, input_data):
        """Evaluate the policy with given input"""
        # Mock evaluation based on the policy logic
        input_obj = input_data
        
        # Default deny
        allow = False
        reason = "denied"
        
        # Check if it's a PUT request for pet update
        if (input_obj.get("method") == "PUT" and 
            len(input_obj.get("path", [])) == 2 and
            input_obj.get("path", [])[0] == "pets" and
            input_obj.get("user") == input_obj.get("owner")):
            allow = True
            reason = "owner_update"
        
        # Check staff access for GET
        elif (input_obj.get("method") == "GET" and
              len(input_obj.get("path", [])) == 2 and
              input_obj.get("path", [])[0] == "pets" and
              self.is_staff(input_obj.get("user"))):
            allow = True
            reason = "staff_access"
        
        # Check owner access for GET
        elif (input_obj.get("method") == "GET" and
              len(input_obj.get("path", [])) == 2 and
              input_obj.get("path", [])[0] == "pets" and
              input_obj.get("user") == input_obj.get("owner")):
            allow = True
            reason = "owner_access"
        
        # Check veterinarian access for medical records
        elif (input_obj.get("method") == "PUT" and
              len(input_obj.get("path", [])) == 3 and
              input_obj.get("path", [])[0] == "pets" and
              input_obj.get("path", [])[2] == "medical" and
              self.is_veterinarian(input_obj.get("user"))):
            allow = True
            reason = "veterinarian_access"
        
        # Check groomer access for grooming records
        elif (input_obj.get("method") == "PUT" and
              len(input_obj.get("path", [])) == 3 and
              input_obj.get("path", [])[0] == "pets" and
              input_obj.get("path", [])[2] == "grooming" and
              self.is_groomer(input_obj.get("user"))):
            allow = True
            reason = "groomer_access"
        
        return {
            "allow": allow,
            "reason": reason
        }
    
    def is_staff(self, user):
        """Check if user is staff"""
        user_roles = {
            "alice@example.com": ["staff", "admin"],
            "bob@example.com": ["user"],
            "charlie@example.com": ["staff", "veterinarian"],
            "diana@example.com": ["user", "groomer"]
        }
        return user_roles.get(user, []).__contains__("staff")
    
    def is_veterinarian(self, user):
        """Check if user is veterinarian"""
        user_roles = {
            "alice@example.com": ["staff", "admin"],
            "bob@example.com": ["user"],
            "charlie@example.com": ["staff", "veterinarian"],
            "diana@example.com": ["user", "groomer"]
        }
        return user_roles.get(user, []).__contains__("veterinarian")
    
    def is_groomer(self, user):
        """Check if user is groomer"""
        user_roles = {
            "alice@example.com": ["staff", "admin"],
            "bob@example.com": ["user"],
            "charlie@example.com": ["staff", "veterinarian"],
            "diana@example.com": ["user", "groomer"]
        }
        return user_roles.get(user, []).__contains__("groomer")

@pytest.fixture
def opa():
    """OPA evaluator fixture"""
    return MockOPA()

class TestPetAuthorization:
    """Test cases for pet authorization"""
    
    def test_owner_can_update_pet(self, opa):
        """Test that pet owner can update their pet"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987"],
            "user": "bob@example.com",
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == True
        assert result["reason"] == "owner_update"
    
    def test_non_owner_cannot_update_pet(self, opa):
        """Test that non-owner cannot update pet"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987"],
            "user": "alice@example.com",
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"
    
    def test_staff_can_read_any_pet(self, opa):
        """Test that staff can read any pet"""
        input_data = {
            "method": "GET",
            "path": ["pets", "pet113-987"],
            "user": "alice@example.com",
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == True
        assert result["reason"] == "staff_access"
    
    def test_owner_can_read_own_pet(self, opa):
        """Test that owner can read their own pet"""
        input_data = {
            "method": "GET",
            "path": ["pets", "pet113-987"],
            "user": "bob@example.com",
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == True
        assert result["reason"] == "owner_access"
    
    def test_non_owner_non_staff_cannot_read_pet(self, opa):
        """Test that non-owner non-staff cannot read pet"""
        input_data = {
            "method": "GET",
            "path": ["pets", "pet113-987"],
            "user": "diana@example.com",
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"
    
    def test_veterinarian_can_update_medical_records(self, opa):
        """Test that veterinarian can update medical records"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987", "medical"],
            "user": "charlie@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == True
        assert result["reason"] == "veterinarian_access"
    
    def test_non_veterinarian_cannot_update_medical_records(self, opa):
        """Test that non-veterinarian cannot update medical records"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987", "medical"],
            "user": "alice@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"
    
    def test_groomer_can_update_grooming_records(self, opa):
        """Test that groomer can update grooming records"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987", "grooming"],
            "user": "diana@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == True
        assert result["reason"] == "groomer_access"
    
    def test_non_groomer_cannot_update_grooming_records(self, opa):
        """Test that non-groomer cannot update grooming records"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987", "grooming"],
            "user": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"

class TestPolicyEdgeCases:
    """Test edge cases and boundary conditions"""
    
    def test_empty_input(self, opa):
        """Test with empty input"""
        input_data = {}
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"
    
    def test_invalid_method(self, opa):
        """Test with invalid HTTP method"""
        input_data = {
            "method": "PATCH",
            "path": ["pets", "pet113-987"],
            "user": "bob@example.com",
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"
    
    def test_invalid_path(self, opa):
        """Test with invalid path"""
        input_data = {
            "method": "PUT",
            "path": ["dogs", "pet113-987"],
            "user": "bob@example.com",
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"
    
    def test_missing_user(self, opa):
        """Test with missing user"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987"],
            "owner": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"
    
    def test_missing_owner(self, opa):
        """Test with missing owner"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987"],
            "user": "bob@example.com"
        }
        
        result = opa.evaluate(input_data)
        
        assert result["allow"] == False
        assert result["reason"] == "denied"

class TestPolicyPerformance:
    """Test policy performance"""
    
    def test_policy_evaluation_speed(self, opa):
        """Test that policy evaluation is fast"""
        import time
        
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987"],
            "user": "bob@example.com",
            "owner": "bob@example.com"
        }
        
        start_time = time.time()
        result = opa.evaluate(input_data)
        end_time = time.time()
        
        evaluation_time = end_time - start_time
        
        assert result["allow"] == True
        assert evaluation_time < 0.01  # Should be under 10ms
    
    def test_multiple_evaluations(self, opa):
        """Test multiple policy evaluations"""
        input_data = {
            "method": "PUT",
            "path": ["pets", "pet113-987"],
            "user": "bob@example.com",
            "owner": "bob@example.com"
        }
        
        # Run 100 evaluations
        for i in range(100):
            result = opa.evaluate(input_data)
            assert result["allow"] == True

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
