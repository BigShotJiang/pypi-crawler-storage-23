#!/usr/bin/env python3
"""
Open Policy Agent Control Plane Server
REST API for managing OPA bundles, sources, stacks, and data
"""

import os
import json
import logging
import hashlib
import secrets
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path

from fastapi import FastAPI, HTTPException, Depends, Query, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
API_KEY = os.environ.get("OCP_API_KEY", "admin-api-key-change-me")
HOST = os.environ.get("OCP_HOST", "0.0.0.0")
PORT = int(os.environ.get("OCP_PORT", "8080"))

# FastAPI app
app = FastAPI(
    title="OPA Control Plane Server",
    description="REST API for managing OPA bundles, sources, stacks, and data",
    version="1.0.0"
)

# Security
security = HTTPBearer()

# In-memory storage (in production, use a proper database)
bundles: Dict[str, Dict] = {}
sources: Dict[str, Dict] = {}
stacks: Dict[str, Dict] = {}
secrets: Dict[str, Dict] = {}

# Pydantic models
class AWSStorage(BaseModel):
    bucket: str
    key: str
    region: str
    credentials: str
    url: Optional[str] = None

class FilesystemStorage(BaseModel):
    path: str

class GCPStorage(BaseModel):
    project: str
    bucket: str
    object: str
    credentials: str

class AzureStorage(BaseModel):
    account_url: str
    container: str
    path: str
    credentials: str

class ObjectStorage(BaseModel):
    aws: Optional[AWSStorage] = None
    filesystem: Optional[FilesystemStorage] = None
    gcp: Optional[GCPStorage] = None
    azure: Optional[AzureStorage] = None

class GitConfig(BaseModel):
    repo: str
    reference: str = "refs/heads/main"
    commit: Optional[str] = None
    path: Optional[str] = None
    included_files: Optional[List[str]] = None
    excluded_files: Optional[List[str]] = None
    credentials: Optional[str] = None

class DatasourceConfig(BaseModel):
    url: str
    headers: Optional[Dict[str, str]] = None

class Datasource(BaseModel):
    name: str
    path: str
    type: str = "http"
    config: DatasourceConfig
    credentials: Optional[str] = None
    transform_query: Optional[str] = None

class Source(BaseModel):
    name: Optional[str] = None
    git: Optional[GitConfig] = None
    directory: Optional[str] = None
    paths: Optional[List[str]] = None
    datasources: Optional[List[Datasource]] = None
    builtin: Optional[str] = None
    requirements: Optional[List[Dict[str, str]]] = None

class Requirement(BaseModel):
    source: str
    path: Optional[str] = None
    prefix: Optional[str] = None

class Bundle(BaseModel):
    name: Optional[str] = None
    labels: Optional[Dict[str, str]] = None
    object_storage: Optional[ObjectStorage] = None
    requirements: Optional[List[Requirement]] = None
    excluded_files: Optional[List[str]] = None

class Selector(BaseModel):
    environment: Optional[List[str]] = None
    service: Optional[List[str]] = None
    team: Optional[List[str]] = None
    region: Optional[List[str]] = None

class Stack(BaseModel):
    name: Optional[str] = None
    selector: Optional[Selector] = None
    exclude_selector: Optional[Selector] = None
    requirements: Optional[List[Requirement]] = None

class Secret(BaseModel):
    name: Optional[str] = None
    value: Dict[str, Any]

class PaginatedResponse(BaseModel):
    result: List[Dict[str, Any]]
    next_cursor: Optional[str] = None

# Authentication dependency
async def verify_api_key(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials.credentials != API_KEY:
        raise HTTPException(
            status_code=401,
            detail="Unauthorized"
        )
    return credentials.credentials

# Utility functions
def generate_cursor(items: List[Dict], limit: int) -> Optional[str]:
    if len(items) <= limit:
        return None
    last_item = items[limit - 1]
    cursor_data = f"{last_item.get('id', '')}:{datetime.now().timestamp()}"
    return secrets.token_urlsafe(32)

def paginate_items(items: List[Dict], limit: int, cursor: Optional[str] = None) -> Tuple[List[Dict], Optional[str]]:
    if cursor:
        # Simple cursor implementation (in production, use proper pagination)
        try:
            cursor_data = secrets.token_urlsafe(32)
            # Find starting point based on cursor
            start_index = 0
            for i, item in enumerate(items):
                if item.get('id') == cursor:
                    start_index = i + 1
                    break
            items = items[start_index:]
        except:
            pass
    
    paginated_items = items[:limit]
    next_cursor = generate_cursor(items, limit)
    
    return paginated_items, next_cursor

def validate_bundle_name(bundle_name: str, bundle_data: Dict) -> bool:
    if "name" in bundle_data and bundle_data["name"] != bundle_name:
        return False
    return True

def validate_source_usage(source_name: str) -> bool:
    # Check if source is used by bundles, stacks, or other sources
    for bundle in bundles.values():
        for req in bundle.get("requirements", []):
            if req.get("source") == source_name:
                return False
    
    for stack in stacks.values():
        for req in stack.get("requirements", []):
            if req.get("source") == source_name:
                return False
    
    for source in sources.values():
        for req in source.get("requirements", []):
            if req.get("source") == source_name:
                return False
    
    return True

# API Endpoints

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {}

@app.get("/v1/bundles", response_model=PaginatedResponse)
async def list_bundles(
    limit: int = Query(100, le=100),
    cursor: Optional[str] = Query(None),
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """List all bundles with pagination support"""
    bundle_list = list(bundles.values())
    paginated_bundles, next_cursor = paginate_items(bundle_list, limit, cursor)
    
    return PaginatedResponse(
        result=paginated_bundles,
        next_cursor=next_cursor
    )

@app.get("/v1/bundles/{bundle:path}")
async def get_bundle(
    bundle: str,
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """Get a specific bundle by name"""
    if bundle not in bundles:
        raise HTTPException(status_code=404, detail=f"bundle '{bundle}' not found")
    
    return {"result": bundles[bundle]}

@app.put("/v1/bundles/{bundle:path}")
async def create_or_update_bundle(
    bundle: str,
    bundle_data: Bundle,
    api_key: str = Depends(verify_api_key)
):
    """Create or update a bundle"""
    if not validate_bundle_name(bundle, bundle_data.dict(exclude_unset=True)):
        raise HTTPException(status_code=400, detail="bundle name must match path")
    
    bundle_dict = bundle_data.dict(exclude_unset=True)
    bundle_dict["name"] = bundle
    bundle_dict["id"] = hashlib.md5(bundle.encode()).hexdigest()
    bundle_dict["created_at"] = datetime.now().isoformat()
    bundle_dict["updated_at"] = datetime.now().isoformat()
    
    bundles[bundle] = bundle_dict
    
    return {}

@app.delete("/v1/bundles/{bundle:path}")
async def delete_bundle(
    bundle: str,
    api_key: str = Depends(verify_api_key)
):
    """Delete a bundle"""
    if bundle not in bundles:
        raise HTTPException(status_code=404, detail=f"bundle '{bundle}' not found")
    
    del bundles[bundle]
    
    return {}

@app.get("/v1/sources", response_model=PaginatedResponse)
async def list_sources(
    limit: int = Query(100, le=100),
    cursor: Optional[str] = Query(None),
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """List all sources with pagination support"""
    source_list = list(sources.values())
    paginated_sources, next_cursor = paginate_items(source_list, limit, cursor)
    
    return PaginatedResponse(
        result=paginated_sources,
        next_cursor=next_cursor
    )

@app.get("/v1/sources/{source:path}")
async def get_source(
    source: str,
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """Get a specific source by name"""
    if source not in sources:
        raise HTTPException(status_code=404, detail=f"source '{source}' not found")
    
    return {"result": sources[source]}

@app.put("/v1/sources/{source:path}")
async def create_or_update_source(
    source: str,
    source_data: Source,
    api_key: str = Depends(verify_api_key)
):
    """Create or update a source"""
    source_dict = source_data.dict(exclude_unset=True)
    source_dict["name"] = source
    source_dict["id"] = hashlib.md5(source.encode()).hexdigest()
    source_dict["created_at"] = datetime.now().isoformat()
    source_dict["updated_at"] = datetime.now().isoformat()
    
    sources[source] = source_dict
    
    return {}

@app.delete("/v1/sources/{source:path}")
async def delete_source(
    source: str,
    api_key: str = Depends(verify_api_key)
):
    """Delete a source"""
    if source not in sources:
        raise HTTPException(status_code=404, detail=f"source '{source}' not found")
    
    if not validate_source_usage(source):
        raise HTTPException(status_code=400, detail=f"source '{source}' is in use")
    
    del sources[source]
    
    return {}

@app.get("/v1/sources/{source:path}/data/{path:path}")
async def get_source_data(
    source: str,
    path: str,
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """Retrieve data from a source at a specific path"""
    if source not in sources:
        raise HTTPException(status_code=404, detail=f"source '{source}' not found")
    
    # In a real implementation, this would read from actual data storage
    data_path = f"{path}/data.json"
    
    # Mock data for demonstration
    mock_data = {
        "users": [
            {
                "id": "user123",
                "name": "John Doe",
                "roles": ["admin", "user"]
            },
            {
                "id": "user456",
                "name": "Jane Smith",
                "roles": ["user"]
            }
        ],
        "last_updated": datetime.now().isoformat()
    }
    
    return {"result": mock_data}

@app.post("/v1/sources/{source:path}/data/{path:path}")
@app.put("/v1/sources/{source:path}/data/{path:path}")
async def upload_source_data(
    source: str,
    path: str,
    data: Dict[str, Any],
    api_key: str = Depends(verify_api_key)
):
    """Upload data to a source at a specific path"""
    if source not in sources:
        raise HTTPException(status_code=404, detail=f"source '{source}' not found")
    
    # In a real implementation, this would store the data
    data_path = f"{path}/data.json"
    
    logger.info(f"Data uploaded to source '{source}' at path '{data_path}'")
    
    return {}

@app.delete("/v1/sources/{source:path}/data/{path:path}")
async def delete_source_data(
    source: str,
    path: str,
    api_key: str = Depends(verify_api_key)
):
    """Delete data from a source at a specific path"""
    if source not in sources:
        raise HTTPException(status_code=404, detail=f"source '{source}' not found")
    
    data_path = f"{path}/data.json"
    
    # In a real implementation, this would delete the data
    logger.info(f"Data deleted from source '{source}' at path '{data_path}'")
    
    return {}

@app.get("/v1/stacks", response_model=PaginatedResponse)
async def list_stacks(
    limit: int = Query(100, le=100),
    cursor: Optional[str] = Query(None),
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """List all stacks with pagination support"""
    stack_list = list(stacks.values())
    paginated_stacks, next_cursor = paginate_items(stack_list, limit, cursor)
    
    return PaginatedResponse(
        result=paginated_stacks,
        next_cursor=next_cursor
    )

@app.get("/v1/stacks/{stack:path}")
async def get_stack(
    stack: str,
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """Get a specific stack by name"""
    if stack not in stacks:
        raise HTTPException(status_code=404, detail=f"stack '{stack}' not found")
    
    return {"result": stacks[stack]}

@app.put("/v1/stacks/{stack:path}")
async def create_or_update_stack(
    stack: str,
    stack_data: Stack,
    api_key: str = Depends(verify_api_key)
):
    """Create or update a stack"""
    stack_dict = stack_data.dict(exclude_unset=True)
    stack_dict["name"] = stack
    stack_dict["id"] = hashlib.md5(stack.encode()).hexdigest()
    stack_dict["created_at"] = datetime.now().isoformat()
    stack_dict["updated_at"] = datetime.now().isoformat()
    
    stacks[stack] = stack_dict
    
    return {}

@app.delete("/v1/stacks/{stack:path}")
async def delete_stack(
    stack: str,
    api_key: str = Depends(verify_api_key)
):
    """Delete a stack"""
    if stack not in stacks:
        raise HTTPException(status_code=404, detail=f"stack '{stack}' not found")
    
    del stacks[stack]
    
    return {}

@app.get("/v1/secrets", response_model=PaginatedResponse)
async def list_secrets(
    limit: int = Query(100, le=100),
    cursor: Optional[str] = Query(None),
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """List all secrets with pagination support, omitting values"""
    secret_list = list(secrets.keys())
    paginated_secrets, next_cursor = paginate_items(
        [{"name": name} for name in secret_list], limit, cursor
    )
    
    return PaginatedResponse(
        result=[item["name"] for item in paginated_secrets],
        next_cursor=next_cursor
    )

@app.get("/v1/secrets/{secret:path}")
async def get_secret(
    secret: str,
    pretty: Optional[bool] = Query(None),
    api_key: str = Depends(verify_api_key)
):
    """Get a specific secret by name"""
    if secret not in secrets:
        raise HTTPException(status_code=404, detail=f"secret '{secret}' not found")
    
    return {"result": secret}

@app.put("/v1/secrets/{secret:path}")
async def create_or_update_secret(
    secret: str,
    secret_data: Secret,
    api_key: str = Depends(verify_api_key)
):
    """Create or update a secret"""
    secret_dict = secret_data.dict(exclude_unset=True)
    if "name" in secret_dict and secret_dict["name"] != secret:
        raise HTTPException(status_code=400, detail="secret name must match path")
    
    secret_dict["name"] = secret
    secret_dict["created_at"] = datetime.now().isoformat()
    secret_dict["updated_at"] = datetime.now().isoformat()
    
    secrets[secret] = secret_dict
    
    return {}

@app.delete("/v1/secrets/{secret:path}")
async def delete_secret(
    secret: str,
    api_key: str = Depends(verify_api_key)
):
    """Delete a secret"""
    if secret not in secrets:
        raise HTTPException(status_code=404, detail=f"secret '{secret}' not found")
    
    # Check if secret is in use
    for bundle in bundles.values():
        storage = bundle.get("object_storage", {})
        if storage.get("aws", {}).get("credentials") == secret:
            raise HTTPException(status_code=400, detail="secret is in use")
        if storage.get("gcp", {}).get("credentials") == secret:
            raise HTTPException(status_code=400, detail="secret is in use")
        if storage.get("azure", {}).get("credentials") == secret:
            raise HTTPException(status_code=400, detail="secret is in use")
    
    for source in sources.values():
        if source.get("git", {}).get("credentials") == secret:
            raise HTTPException(status_code=400, detail="secret is in use")
        for datasource in source.get("datasources", []):
            if datasource.get("credentials") == secret:
                raise HTTPException(status_code=400, detail="secret is in use")
    
    del secrets[secret]
    
    return {}

# Error handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "code": "http_error",
            "message": exc.detail
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    logger.error(f"Internal error: {exc}")
    return JSONResponse(
        status_code=500,
        content={
            "code": "internal_error",
            "message": "An internal error occurred"
        }
    )

# Initialize sample data
def init_sample_data():
    """Initialize sample data for demonstration"""
    
    # Sample bundle
    bundles["main-bundle"] = {
        "name": "main-bundle",
        "id": hashlib.md5("main-bundle".encode()).hexdigest(),
        "labels": {
            "env": "production",
            "team": "platform"
        },
        "object_storage": {
            "aws": {
                "bucket": "my-policy-bundles",
                "key": "bundles/my-app/bundle.tar.gz",
                "region": "us-east-1",
                "credentials": "aws-creds"
            }
        },
        "requirements": [
            {
                "source": "my-app-policies"
            },
            {
                "source": "shared-policies",
                "path": "library",
                "prefix": "shared.lib"
            }
        ],
        "excluded_files": [
            "*.test.rego",
            ".git/*"
        ],
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }
    
    # Sample source
    sources["myorg-git-policies"] = {
        "name": "myorg-git-policies",
        "id": hashlib.md5("myorg-git-policies".encode()).hexdigest(),
        "git": {
            "repo": "https://github.com/myorg/policies.git",
            "reference": "refs/heads/main",
            "path": "src/policies",
            "included_files": ["*.rego"],
            "excluded_files": ["*.test.rego"],
            "credentials": "github-creds"
        },
        "requirements": [
            {
                "source": "base-policies"
            }
        ],
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }
    
    # Sample stack
    stacks["prod-stack"] = {
        "name": "prod-stack",
        "id": hashlib.md5("prod-stack".encode()).hexdigest(),
        "selector": {
            "environment": ["production"],
            "service": ["auth-service", "api-gateway"]
        },
        "exclude_selector": {
            "region": ["us-west-1"]
        },
        "requirements": [
            {
                "source": "production-policies"
            },
            {
                "source": "security-baseline"
            }
        ],
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }
    
    # Sample secret
    secrets["api-token"] = {
        "name": "api-token",
        "value": {
            "type": "token_auth",
            "token": "open-sesame"
        },
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }

if __name__ == "__main__":
    # Initialize sample data
    init_sample_data()
    
    # Run the server
    print(f"🚀 Starting OCP Server on {HOST}:{PORT}")
    print(f"🔑 API Key: {API_KEY}")
    print(f"📖 Health check: http://{HOST}:{PORT}/health")
    print(f"📚 API docs: http://{HOST}:{PORT}/docs")
    
    uvicorn.run(app, host=HOST, port=PORT)
