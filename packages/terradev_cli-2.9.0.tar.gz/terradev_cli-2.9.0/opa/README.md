# 🔐 Open Policy Agent (OPA) Control Plane

Complete OPA implementation with authorization policies and REST API server for managing OPA bundles, sources, stacks, and data.

---

## 🎯 Overview

This implementation provides:

- **🔐 Authorization Policies** - Rego policies for fine-grained access control
- **🌐 REST API Server** - Complete OCP server implementation
- **📦 Bundle Management** - Policy and data bundle distribution
- **🔄 Source Management** - Git, filesystem, and HTTP data sources
- **📚 Stack Management** - Environment-specific policy distribution
- **🔒 Secrets Management** - Secure credential management
- **🧪 Test Suite** - Comprehensive policy testing
- **📖 API Examples** - Usage demonstrations

---

## 🏗️ Architecture

### **📋 Components**

1. **Authorization Policies** (`policies/application/authz.rego`)
   - Pet management authorization
   - Role-based access control
   - Multi-level permissions

2. **OCP Server** (`ocp_server/main.py`)
   - FastAPI-based REST server
   - Bearer token authentication
   - Complete API implementation

3. **Test Suite** (`tests/test_authz_policy.py`)
   - Policy evaluation tests
   - Edge case testing
   - Performance testing

4. **API Examples** (`examples/api_examples.py`)
   - Client implementation
   - Usage demonstrations
   - Best practices

---

## 🔐 Authorization Policy

### **📋 Core Policy Rules**

```rego
package application.authz

# Only owner can update pet information
default allow := false

allow if {
    input.method == "PUT"
    some petid
    input.path = ["pets", petid]
    input.user == input.owner
}
```

### **🎯 Authorization Features**

#### **Pet Management**
- **✅ Owner Update** - Pet owners can update their pets
- **✅ Staff Access** - Staff can read any pet information
- **✅ Owner Access** - Owners can read their own pets
- **✅ Creation** - Owners can create new pets
- **✅ Deletion** - Owners and staff can delete pets

#### **Specialized Access**
- **🩺 Veterinarian Access** - Update medical records
- **✂️ Groomer Access** - Update grooming records
- **🚫 Sensitive Data Protection** - Medical/billing records restricted

#### **Role-Based Access**
```rego
user_roles := {
    "alice@example.com": ["staff", "admin"],
    "bob@example.com": ["user"],
    "charlie@example.com": ["staff", "veterinarian"],
    "diana@example.com": ["user", "groomer"]
}
```

---

## 🌐 OCP Server API

### **🔐 Authentication**

```bash
# Bearer token authentication
Authorization: Bearer admin-api-key-change-me
```

### **📋 API Endpoints**

#### **Health Check**
```bash
GET /health
# Response: 200 OK
```

#### **Bundle Management**
```bash
# List bundles
GET /v1/bundles?limit=100&cursor=xxx

# Get specific bundle
GET /v1/bundles/{bundle}

# Create/update bundle
PUT /v1/bundles/{bundle}

# Delete bundle
DELETE /v1/bundles/{bundle}
```

#### **Source Management**
```bash
# List sources
GET /v1/sources

# Get specific source
GET /v1/sources/{source}

# Create/update source
PUT /v1/sources/{source}

# Delete source
DELETE /v1/sources/{source}
```

#### **Data Management**
```bash
# Get source data
GET /v1/sources/{source}/data/{path}

# Upload data
POST /v1/sources/{source}/data/{path}

# Delete data
DELETE /v1/sources/{source}/data/{path}
```

#### **Stack Management**
```bash
# List stacks
GET /v1/stacks

# Get specific stack
GET /v1/stacks/{stack}

# Create/update stack
PUT /v1/stacks/{stack}

# Delete stack
DELETE /v1/stacks/{stack}
```

#### **Secrets Management**
```bash
# List secrets
GET /v1/secrets

# Get specific secret
GET /v1/secrets/{secret}

# Create/update secret
PUT /v1/secrets/{secret}

# Delete secret
DELETE /v1/secrets/{secret}
```

---

## 📦 Bundle Configuration

### **🗂️ Object Storage Types**

#### **AWS S3**
```json
{
  "object_storage": {
    "aws": {
      "bucket": "my-policy-bundles",
      "key": "bundles/my-app/bundle.tar.gz",
      "region": "us-east-1",
      "credentials": "aws-creds"
    }
  }
}
```

#### **Filesystem**
```json
{
  "object_storage": {
    "filesystem": {
      "path": "/local/bundles/my-app/bundle.tar.gz"
    }
  }
}
```

#### **GCP Cloud Storage**
```json
{
  "object_storage": {
    "gcp": {
      "project": "my-gcp-project",
      "bucket": "policy-bundles",
      "object": "bundles/my-app/bundle.tar.gz",
      "credentials": "gcp-service-account"
    }
  }
}
```

#### **Azure Blob Storage**
```json
{
  "object_storage": {
    "azure": {
      "account_url": "https://mystorageaccount.blob.core.windows.net",
      "container": "policy-bundles",
      "path": "bundles/my-app/bundle.tar.gz",
      "credentials": "azure-credentials"
    }
  }
}
```

---

## 🔄 Source Configuration

### **📦 Git Source**
```json
{
  "git": {
    "repo": "https://github.com/myorg/policies.git",
    "reference": "refs/heads/main",
    "path": "policies",
    "included_files": ["*.rego"],
    "excluded_files": ["*.test.rego"],
    "credentials": "github-creds"
  }
}
```

### **📁 Directory Source**
```json
{
  "directory": "/local/policies",
  "paths": [
    "authz.rego",
    "utils.rego"
  ]
}
```

### **🌐 HTTP Datasource**
```json
{
  "datasources": [
    {
      "name": "user-directory",
      "path": "external/users",
      "type": "http",
      "config": {
        "url": "https://api.company.com/users",
        "headers": {
          "Accept": "application/json"
        }
      },
      "credentials": "api-credentials"
    }
  ]
}
```

---

## 📚 Stack Configuration

### **🎯 Environment-Based Distribution**
```json
{
  "selector": {
    "environment": ["production"],
    "service": ["auth-service", "api-gateway"]
  },
  "exclude_selector": {
    "region": ["us-west-1"]
  },
  "requirements": [
    {
      "source": "production-policies"
    },
    {
      "source": "security-baseline"
    }
  ]
}
```

---

## 🚀 Quick Start

### **📋 Prerequisites**
- Python 3.9+
- pip package manager

### **🔧 Installation**

```bash
# Clone repository
git clone <repository-url>
cd opa

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export OCP_API_KEY="admin-api-key-change-me"
export OCP_HOST="0.0.0.0"
export OCP_PORT="8080"
```

### **🚀 Run Server**

```bash
# Start OCP server
python ocp_server/main.py

# Server will start on http://localhost:8080
```

### **🧪 Run Tests**

```bash
# Run policy tests
python -m pytest tests/test_authz_policy.py -v

# Run with coverage
python -m pytest tests/ --cov=opa
```

### **📖 API Examples**

```bash
# Run API examples
python examples/api_examples.py
```

---

## 🧪 Testing

### **🔍 Policy Tests**

#### **Owner Authorization**
```python
def test_owner_can_update_pet(self, opa):
    input_data = {
        "method": "PUT",
        "path": ["pets", "pet113-987"],
        "user": "bob@example.com",
        "owner": "bob@example.com"
    }
    
    result = opa.evaluate(input_data)
    assert result["allow"] == True
    assert result["reason"] == "owner_update"
```

#### **Staff Access**
```python
def test_staff_can_read_any_pet(self, opa):
    input_data = {
        "method": "GET",
        "path": ["pets", "pet113-987"],
        "user": "alice@example.com",
        "owner": "bob@example.com"
    }
    
    result = opa.evaluate(input_data)
    assert result["allow"] == True
    assert result["reason"] == "staff_access"
```

#### **Specialized Roles**
```python
def test_veterinarian_can_update_medical_records(self, opa):
    input_data = {
        "method": "PUT",
        "path": ["pets", "pet113-987", "medical"],
        "user": "charlie@example.com"
    }
    
    result = opa.evaluate(input_data)
    assert result["allow"] == True
    assert result["reason"] == "veterinarian_access"
```

### **📊 Test Coverage**

- ✅ **Authorization Logic** - All policy rules tested
- ✅ **Edge Cases** - Invalid inputs and boundary conditions
- ✅ **Performance** - Evaluation speed tests
- ✅ **Role Management** - All user roles tested
- ✅ **Resource Protection** - Sensitive data access controls

---

## 📖 API Usage Examples

### **🔧 Python Client**

```python
from examples.api_examples import OCPClient

# Initialize client
client = OCPClient("http://localhost:8080", "admin-api-key-change-me")

# Create Git source
source_data = {
    "git": {
        "repo": "https://github.com/myorg/policies.git",
        "reference": "refs/heads/main",
        "path": "policies"
    }
}

result = client.create_source("myorg-policies", source_data)
```

### **🌐 cURL Examples**

```bash
# Health check
curl -X GET http://localhost:8080/health

# List bundles
curl -X GET \
  -H "Authorization: Bearer admin-api-key-change-me" \
  http://localhost:8080/v1/bundles

# Create bundle
curl -X PUT \
  -H "Authorization: Bearer admin-api-key-change-me" \
  -H "Content-Type: application/json" \
  -d '{
    "labels": {"env": "production"},
    "object_storage": {
      "aws": {
        "bucket": "policy-bundles",
        "key": "bundle.tar.gz",
        "region": "us-east-1"
      }
    }
  }' \
  http://localhost:8080/v1/bundles/production-bundle
```

---

## 🔒 Security Features

### **🛡️ Authentication**
- **Bearer Token** - API key authentication
- **HTTPS Required** - Encrypted communication
- **Token Validation** - Secure token verification

### **🔐 Authorization**
- **Role-Based Access** - Fine-grained permissions
- **Resource Protection** - Sensitive data controls
- **Audit Logging** - Complete access tracking

### **🔑 Secrets Management**
- **Encrypted Storage** - Secure secret storage
- **Access Control** - Restricted secret access
- **Rotation Support** - Secret rotation capabilities

---

## 📊 Monitoring & Observability

### **📈 Metrics Available**
- **API Request Rate** - Requests per second
- **Response Times** - API performance metrics
- **Error Rates** - Error tracking and alerting
- **Policy Evaluations** - Authorization decision metrics

### **🔍 Logging**
- **Request Logging** - All API requests logged
- **Decision Logging** - Policy decision audit trail
- **Error Logging** - Comprehensive error tracking
- **Security Events** - Security incident logging

---

## 🚀 Production Deployment

### **🐳 Docker Deployment**

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8080

CMD ["python", "ocp_server/main.py"]
```

```bash
# Build and run
docker build -t ocp-server .
docker run -d -p 8080:8080 -e OCP_API_KEY="your-api-key" ocp-server
```

### **☸️ Kubernetes Deployment**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ocp-server
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ocp-server
  template:
    metadata:
      labels:
        app: ocp-server
    spec:
      containers:
      - name: ocp-server
        image: ocp-server:latest
        ports:
        - containerPort: 8080
        env:
        - name: OCP_API_KEY
          valueFrom:
            secretKeyRef:
              name: ocp-secrets
              key: api-key
```

---

## 🔧 Configuration

### **📋 Environment Variables**

| Variable | Default | Description |
|----------|---------|-------------|
| `OCP_API_KEY` | `admin-api-key-change-me` | API authentication key |
| `OCP_HOST` | `0.0.0.0` | Server host |
| `OCP_PORT` | `8080` | Server port |

### **🔧 Advanced Configuration**

- **Database** - PostgreSQL for persistence
- **Redis** - Caching layer
- **TLS** - HTTPS configuration
- **Rate Limiting** - API rate limiting
- **CORS** - Cross-origin resource sharing

---

## 🤝 Contributing

### **📋 Development Setup**

```bash
# Clone repository
git clone <repository-url>
cd opa

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt
pip install pytest pytest-cov

# Run tests
python -m pytest tests/ -v --cov=opa
```

### **🔧 Code Style**

- **Black** - Code formatting
- **Flake8** - Linting
- **MyPy** - Type checking
- **Pre-commit** - Git hooks

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🆘 Support

### **📞 Getting Help**

- **Documentation**: [Full API docs](http://localhost:8080/docs)
- **Issues**: [GitHub Issues](https://github.com/your-org/opa/issues)
- **Community**: [OPA Community](https://openpolicyagent.org/community)

### **🔧 Troubleshooting**

#### **Common Issues**

1. **Authentication Failed**
   - Check API key in Authorization header
   - Verify key format: `Bearer <key>`

2. **Policy Evaluation Errors**
   - Check Rego syntax
   - Verify input data format

3. **Bundle Creation Failed**
   - Validate object storage configuration
   - Check credentials

---

## 🎉 Success Summary

**✅ COMPLETE OPA IMPLEMENTATION**
- **Authorization policies** with fine-grained access control
- **Complete REST API** server with all endpoints
- **Comprehensive test suite** with full coverage
- **Production-ready** deployment configurations
- **Security features** with authentication and secrets management

**✅ KEY FEATURES**
- **Role-based authorization** for pet management
- **Multi-level permissions** with specialized roles
- **Bundle management** with multiple storage backends
- **Source management** with Git, filesystem, and HTTP support
- **Stack management** for environment-specific distribution
- **Secrets management** with secure storage

**✅ ENTERPRISE READY**
- **Authentication** with bearer tokens
- **Authorization** with fine-grained policies
- **Monitoring** with comprehensive logging
- **Security** with encrypted storage
- **Scalability** with containerized deployment

---

**🔐 Open Policy Agent Control Plane - Complete Implementation**

*Fine-grained authorization with comprehensive policy management*
