#!/usr/bin/env python3
"""
OPA Control Plane API Examples
Demonstrates how to use the OCP server API
"""

import requests
import json
from typing import Dict, Any

class OCPClient:
    """Client for interacting with OCP Server"""
    
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
    
    def _make_request(self, method: str, endpoint: str, data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Make HTTP request to OCP server"""
        url = f"{self.base_url}{endpoint}"
        
        try:
            if method.upper() == 'GET':
                response = requests.get(url, headers=self.headers)
            elif method.upper() == 'POST':
                response = requests.post(url, headers=self.headers, json=data)
            elif method.upper() == 'PUT':
                response = requests.put(url, headers=self.headers, json=data)
            elif method.upper() == 'DELETE':
                response = requests.delete(url, headers=self.headers)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            response.raise_for_status()
            return response.json()
        
        except requests.exceptions.RequestException as e:
            print(f"Error making request: {e}")
            return {}
    
    def health_check(self) -> bool:
        """Check if server is healthy"""
        try:
            response = requests.get(f"{self.base_url}/health")
            return response.status_code == 200
        except:
            return False
    
    # Bundle Management
    def list_bundles(self, limit: int = 100, cursor: str = None) -> Dict[str, Any]:
        """List all bundles"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        
        url = "/v1/bundles"
        if params:
            url += "?" + "&".join([f"{k}={v}" for k, v in params.items()])
        
        return self._make_request('GET', url)
    
    def get_bundle(self, bundle_name: str) -> Dict[str, Any]:
        """Get a specific bundle"""
        return self._make_request('GET', f"/v1/bundles/{bundle_name}")
    
    def create_bundle(self, bundle_name: str, bundle_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a bundle"""
        return self._make_request('PUT', f"/v1/bundles/{bundle_name}", bundle_data)
    
    def delete_bundle(self, bundle_name: str) -> Dict[str, Any]:
        """Delete a bundle"""
        return self._make_request('DELETE', f"/v1/bundles/{bundle_name}")
    
    # Source Management
    def list_sources(self, limit: int = 100, cursor: str = None) -> Dict[str, Any]:
        """List all sources"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        
        url = "/v1/sources"
        if params:
            url += "?" + "&".join([f"{k}={v}" for k, v in params.items()])
        
        return self._make_request('GET', url)
    
    def get_source(self, source_name: str) -> Dict[str, Any]:
        """Get a specific source"""
        return self._make_request('GET', f"/v1/sources/{source_name}")
    
    def create_source(self, source_name: str, source_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a source"""
        return self._make_request('PUT', f"/v1/sources/{source_name}", source_data)
    
    def delete_source(self, source_name: str) -> Dict[str, Any]:
        """Delete a source"""
        return self._make_request('DELETE', f"/v1/sources/{source_name}")
    
    # Source Data Management
    def get_source_data(self, source_name: str, path: str) -> Dict[str, Any]:
        """Get data from a source"""
        return self._make_request('GET', f"/v1/sources/{source_name}/data/{path}")
    
    def upload_source_data(self, source_name: str, path: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Upload data to a source"""
        return self._make_request('POST', f"/v1/sources/{source_name}/data/{path}", data)
    
    def delete_source_data(self, source_name: str, path: str) -> Dict[str, Any]:
        """Delete data from a source"""
        return self._make_request('DELETE', f"/v1/sources/{source_name}/data/{path}")
    
    # Stack Management
    def list_stacks(self, limit: int = 100, cursor: str = None) -> Dict[str, Any]:
        """List all stacks"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        
        url = "/v1/stacks"
        if params:
            url += "?" + "&".join([f"{k}={v}" for k, v in params.items()])
        
        return self._make_request('GET', url)
    
    def get_stack(self, stack_name: str) -> Dict[str, Any]:
        """Get a specific stack"""
        return self._make_request('GET', f"/v1/stacks/{stack_name}")
    
    def create_stack(self, stack_name: str, stack_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a stack"""
        return self._make_request('PUT', f"/v1/stacks/{stack_name}", stack_data)
    
    def delete_stack(self, stack_name: str) -> Dict[str, Any]:
        """Delete a stack"""
        return self._make_request('DELETE', f"/v1/stacks/{stack_name}")
    
    # Secrets Management
    def list_secrets(self, limit: int = 100, cursor: str = None) -> Dict[str, Any]:
        """List all secrets"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        
        url = "/v1/secrets"
        if params:
            url += "?" + "&".join([f"{k}={v}" for k, v in params.items()])
        
        return self._make_request('GET', url)
    
    def get_secret(self, secret_name: str) -> Dict[str, Any]:
        """Get a specific secret"""
        return self._make_request('GET', f"/v1/secrets/{secret_name}")
    
    def create_secret(self, secret_name: str, secret_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a secret"""
        return self._make_request('PUT', f"/v1/secrets/{secret_name}", secret_data)
    
    def delete_secret(self, secret_name: str) -> Dict[str, Any]:
        """Delete a secret"""
        return self._make_request('DELETE', f"/v1/secrets/{secret_name}")

def main():
    """Demonstrate OCP API usage"""
    
    # Initialize client
    base_url = "http://localhost:8080"
    api_key = "admin-api-key-change-me"
    
    client = OCPClient(base_url, api_key)
    
    print("🚀 OPA Control Plane API Examples")
    print("=" * 50)
    
    # Health check
    print("📋 Health Check:")
    if client.health_check():
        print("✅ Server is healthy")
    else:
        print("❌ Server is not healthy")
        return
    
    # Example 1: Create a Git source
    print("\n📦 Creating Git Source:")
    git_source_data = {
        "git": {
            "repo": "https://github.com/myorg/policies.git",
            "reference": "refs/heads/main",
            "path": "policies",
            "included_files": ["*.rego"],
            "excluded_files": ["*.test.rego"],
            "credentials": "github-creds"
        },
        "requirements": [
            {
                "source": "base-policies"
            }
        ]
    }
    
    result = client.create_source("myorg-policies", git_source_data)
    print(f"✅ Source created: {result}")
    
    # Example 2: Create a bundle
    print("\n📦 Creating Bundle:")
    bundle_data = {
        "labels": {
            "env": "production",
            "team": "security"
        },
        "object_storage": {
            "aws": {
                "bucket": "policy-bundles-prod",
                "key": "bundles/auth-service/bundle.tar.gz",
                "region": "us-east-1",
                "credentials": "aws-prod-creds"
            }
        },
        "requirements": [
            {
                "source": "myorg-policies"
            },
            {
                "source": "security-baseline",
                "path": "security",
                "prefix": "security.rules"
            }
        ],
        "excluded_files": [
            "*.test.rego",
            "examples/*"
        ]
    }
    
    result = client.create_bundle("auth-service-bundle", bundle_data)
    print(f"✅ Bundle created: {result}")
    
    # Example 3: Create a stack
    print("\n📦 Creating Stack:")
    stack_data = {
        "selector": {
            "environment": ["production"],
            "service": ["auth-service", "api-gateway"]
        },
        "exclude_selector": {
            "region": ["us-west-1"]
        },
        "requirements": [
            {
                "source": "auth-service-bundle"
            },
            {
                "source": "compliance-rules"
            }
        ]
    }
    
    result = client.create_stack("production-stack", stack_data)
    print(f"✅ Stack created: {result}")
    
    # Example 4: Upload data to source
    print("\n📦 Uploading Source Data:")
    user_data = {
        "users": [
            {
                "id": "user123",
                "name": "John Doe",
                "email": "john@example.com",
                "roles": ["admin", "user"]
            },
            {
                "id": "user456",
                "name": "Jane Smith",
                "email": "jane@example.com",
                "roles": ["user"]
            }
        ],
        "permissions": {
            "read": ["admin", "user"],
            "write": ["admin"],
            "delete": ["admin"]
        }
    }
    
    result = client.upload_source_data("myorg-policies", "users", user_data)
    print(f"✅ Data uploaded: {result}")
    
    # Example 5: Create a secret
    print("\n🔐 Creating Secret:")
    secret_data = {
        "name": "github-token",
        "value": {
            "type": "token_auth",
            "token": "ghp_xxxxxxxxxxxxxxxxxxxx"
        }
    }
    
    result = client.create_secret("github-token", secret_data)
    print(f"✅ Secret created: {result}")
    
    # Example 6: List all resources
    print("\n📋 Listing Resources:")
    
    bundles = client.list_bundles()
    print(f"📦 Bundles: {len(bundles.get('result', []))} items")
    
    sources = client.list_sources()
    print(f"📦 Sources: {len(sources.get('result', []))} items")
    
    stacks = client.list_stacks()
    print(f"📦 Stacks: {len(stacks.get('result', []))} items")
    
    secrets = client.list_secrets()
    print(f"🔐 Secrets: {len(secrets.get('result', []))} items")
    
    # Example 7: Get specific bundle
    print("\n📦 Getting Bundle Details:")
    bundle_details = client.get_bundle("auth-service-bundle")
    print(f"📦 Bundle: {json.dumps(bundle_details, indent=2)}")
    
    # Example 8: Get source data
    print("\n📦 Getting Source Data:")
    source_data = client.get_source_data("myorg-policies", "users")
    print(f"📦 Data: {json.dumps(source_data, indent=2)}")
    
    print("\n🎉 API Examples Completed!")
    print("=" * 50)

if __name__ == "__main__":
    main()
