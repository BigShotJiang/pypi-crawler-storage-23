#!/usr/bin/env python3
"""
Production Readiness Assessment & Bug Hunt
Comprehensive codebase review for production deployment
"""

import os
import sys
import json
import logging
from pathlib import Path
from typing import Dict, List, Set, Any, Optional
from dataclasses import dataclass

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ProductionIssue:
    """Production issue found during review"""
    file_path: str
    line_number: int
    issue_type: str
    severity: str  # critical, high, medium, low
    description: str
    recommendation: str
    code_snippet: str

@dataclass
class ProductionReadinessScore:
    """Production readiness assessment score"""
    overall_score: float
    security_score: float
    performance_score: float
    reliability_score: float
    maintainability_score: float
    scalability_score: float
    critical_issues: int
    high_issues: int
    medium_issues: int
    low_issues: int
    total_files: int

class ProductionBugHunter:
    """Production bug hunter and code reviewer"""
    
    def __init__(self, codebase_path: str):
        self.codebase_path = Path(codebase_path)
        self.issues: List[ProductionIssue] = []
        self.python_files: List[Path] = []
        self.config_files: List[Path] = []
        self.terraform_files: List[Path] = []
        
    def scan_codebase(self) -> ProductionReadinessScore:
        """Comprehensive codebase scan for production readiness"""
        logger.info("🔍 Starting comprehensive production readiness assessment")
        
        # Find all relevant files
        self._discover_files()
        
        # Run all checks
        self._check_hardcoded_secrets()
        self._check_error_handling()
        self._check_security_issues()
        self._check_performance_issues()
        self._check_reliability_issues()
        self._check_maintainability()
        self._check_scalability()
        self._check_configuration_management()
        self._check_dependency_management()
        self._check_logging_and_monitoring()
        self._check_database_connections()
        self._check_api_design()
        self._check_authentication()
        self._check_input_validation()
        
        # Calculate scores
        return self._calculate_scores()
    
    def _discover_files(self):
        """Discover all relevant files in the codebase"""
        logger.info("📁 Discovering files...")
        
        # Python files
        self.python_files = list(self.codebase_path.rglob("*.py"))
        logger.info(f"   Found {len(self.python_files)} Python files")
        
        # Configuration files
        self.config_files = list(self.codebase_path.rglob("*.json")) + \
                          list(self.codebase_path.rglob("*.yaml")) + \
                          list(self.codebase_path.rglob("*.yml")) + \
                          list(self.codebase_path.rglob("*.toml"))
        logger.info(f"   Found {len(self.config_files)} configuration files")
        
        # Terraform files
        self.terraform_files = list(self.codebase_path.rglob("*.tf"))
        logger.info(f"   Found {len(self.terraform_files)} Terraform files")
        
        self.total_files = len(self.python_files) + len(self.config_files) + len(self.terraform_files)
    
    def _check_hardcoded_secrets(self):
        """Check for hardcoded secrets and credentials"""
        logger.info("🔐 Checking for hardcoded secrets...")
        
        secret_patterns = [
            "password", "secret", "token", "key", "credential",
            "api_key", "access_key", "private_key", "auth_token"
        ]
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    
                for line_num, line in enumerate(lines, 1):
                    line_lower = line.lower()
                    
                    # Check for hardcoded secrets
                    for pattern in secret_patterns:
                        if pattern in line_lower and ("=" in line or ":" in line):
                            # Skip if it's a variable assignment or parameter
                            if not any(skip in line_lower for skip in ["def ", "class ", "import ", "from ", "print(", "logging."]):
                                self.issues.append(ProductionIssue(
                                    file_path=str(file_path),
                                    line_number=line_num,
                                    issue_type="hardcoded_secret",
                                    severity="critical",
                                    description=f"Potential hardcoded secret found: {pattern}",
                                    recommendation="Use environment variables or secret management",
                                    code_snippet=line.strip()
                                ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_error_handling(self):
        """Check for proper error handling"""
        logger.info("🛡️ Checking error handling...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                # Check for bare except clauses
                if "except:" in content:
                    lines = content.split('\n')
                    for line_num, line in enumerate(lines, 1):
                        if "except:" in line and not any(skip in line for skip in ["# except:", "# except :", "except Exception", "except ValueError"]):
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=line_num,
                                issue_type="bare_except",
                                severity="medium",
                                description="Bare except clause found",
                                recommendation="Use specific exception types",
                                code_snippet=line.strip()
                            ))
                
                # Check for unhandled exceptions in critical functions
                if "def " in content:
                    lines = content.split('\n')
                    for line_num, line in enumerate(lines, 1):
                        if line.strip().startswith("def ") and "try:" not in content[line_num-5:line_num+5]:
                            function_name = line.strip().split("(")[0].replace("def ", "")
                            if any(critical in function_name for critical in ["deploy", "connect", "authenticate", "delete", "create"]):
                                self.issues.append(ProductionIssue(
                                    file_path=str(file_path),
                                    line_number=line_num,
                                    issue_type="unhandled_exception",
                                    severity="high",
                                    description=f"Critical function {function_name} lacks error handling",
                                    recommendation="Add try-catch blocks for critical operations",
                                    code_snippet=line.strip()
                                ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_security_issues(self):
        """Check for security vulnerabilities"""
        logger.info("🔒 Checking security issues...")
        
        security_patterns = {
            "sql_injection": ["execute(", "cursor.execute", "sql %", "f\"SELECT"],
            "command_injection": ["subprocess.run", "os.system", "os.popen"],
            "path_traversal": ["open(", "file(", "path.join"],
            "xss": ["innerHTML", "document.write", "eval("],
        }
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                for issue_type, patterns in security_patterns.items():
                    for pattern in patterns:
                        if pattern in content:
                            lines = content.split('\n')
                            for line_num, line in enumerate(lines, 1):
                                if pattern in line:
                                    self.issues.append(ProductionIssue(
                                        file_path=str(file_path),
                                        line_number=line_num,
                                        issue_type=issue_type,
                                        severity="high",
                                        description=f"Potential {issue_type} vulnerability",
                                        recommendation="Use parameterized queries and input validation",
                                        code_snippet=line.strip()
                                    ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_performance_issues(self):
        """Check for performance issues"""
        logger.info("⚡ Checking performance issues...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    
                for line_num, line in enumerate(lines, 1):
                    line_stripped = line.strip()
                    
                    # Check for synchronous I/O in async functions
                    if "async def" in lines[max(0, line_num-10):line_num]:
                        if any(sync in line_stripped for sync in ["requests.", "subprocess.run", "os.system", "time.sleep"]):
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=line_num,
                                issue_type="sync_io_in_async",
                                severity="medium",
                                description="Synchronous I/O in async function",
                                recommendation="Use async alternatives (aiohttp, asyncio)",
                                code_snippet=line_stripped
                            ))
                    
                    # Check for potential memory leaks
                    if "# TODO: Add proper exit condition to prevent infinite loop
while True:" in line_stripped or "for i in range(" in line_stripped:
                        if "break" not in lines[line_num-5:line_num+20]:
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=line_num,
                                issue_type="potential_memory_leak",
                                severity="medium",
                                description="Potential infinite loop",
                                recommendation="Add break condition or timeout",
                                code_snippet=line_stripped
                            ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_reliability_issues(self):
        """Check for reliability issues"""
        logger.info("🔧 Checking reliability issues...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    content = ''.join(lines)
                    
                for line_num, line in enumerate(lines, 1):
                    line_stripped = line.strip()
                    
                    # Check for hardcoded timeouts
                    if "timeout=" in line_stripped and line_stripped.split("timeout=")[1].split('"')[0] in ["5", "10", "30"]:
                        self.issues.append(ProductionIssue(
                            file_path=str(file_path),
                            line_number=line_num,
                            issue_type="hardcoded_timeout",
                            severity="low",
                            description="Hardcoded timeout value",
                            recommendation="Use configurable timeouts",
                            code_snippet=line_stripped
                        ))
                    
                    # Check for missing retry logic
                    if "requests." in line_stripped and "retry" not in content.lower():
                        self.issues.append(ProductionIssue(
                            file_path=str(file_path),
                            line_number=line_num,
                            issue_type="missing_retry",
                            severity="medium",
                            description="HTTP request without retry logic",
                            recommendation="Add retry mechanism for external calls",
                            code_snippet=line_stripped
                        ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_maintainability(self):
        """Check for maintainability issues"""
        logger.info("🔧 Checking maintainability...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    lines = content.split('\n')
                    
                # Check file length
                if len(lines) > 500:
                    self.issues.append(ProductionIssue(
                        file_path=str(file_path),
                        line_number=1,
                        issue_type="large_file",
                        severity="medium",
                        description=f"Large file ({len(lines)} lines)",
                        recommendation="Consider splitting into smaller modules",
                        code_snippet=f"File has {len(lines)} lines"
                    ))
                
                # Check for complex functions
                for line_num, line in enumerate(lines, 1):
                    if line.strip().startswith("def "):
                        function_name = line.strip().split("(")[0].replace("def ", "")
                        # Count lines in function
                        func_lines = 0
                        indent_level = len(line) - len(line.lstrip())
                        
                        for i in range(line_num, len(lines)):
                            if i > line_num and lines[i].strip() and len(lines[i]) - len(lines[i].lstrip()) <= indent_level:
                                break
                            func_lines += 1
                        
                        if func_lines > 50:
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=line_num,
                                issue_type="complex_function",
                                severity="medium",
                                description=f"Complex function {function_name} ({func_lines} lines)",
                                recommendation="Break down into smaller functions",
                                code_snippet=line.strip()
                            ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_scalability(self):
        """Check for scalability issues"""
        logger.info("📈 Checking scalability...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                # Check for hardcoded limits
                if any(limit in content for limit in ["range(100)", "range(1000)", "max_results = 100"]):
                    lines = content.split('\n')
                    for line_num, line in enumerate(lines, 1):
                        if any(limit in line for limit in ["range(100)", "range(1000)", "max_results = 100"]):
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=line_num,
                                issue_type="hardcoded_limit",
                                severity="medium",
                                description="Hardcoded pagination/limit",
                                recommendation="Use configurable limits",
                                code_snippet=line.strip()
                            ))
                
                # Check for synchronous operations that could block
                if "# TODO: PERFORMANCE - Consider async/await for requests HTTP call
# get" in content or "# TODO: PERFORMANCE - Consider async/await for requests HTTP call
# get" in content:
                    lines = content.split('\n')
                    for line_num, line in enumerate(lines, 1):
                        if "requests." in line and "async" not in content[line_num-5:line_num+5]:
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=line_num,
                                issue_type="blocking_http",
                                severity="high",
                                description="Blocking HTTP request",
                                recommendation="Use async HTTP client",
                                code_snippet=line.strip()
                            ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_configuration_management(self):
        """Check configuration management"""
        logger.info("⚙️ Checking configuration management...")
        
        # Check for hardcoded configuration
        config_patterns = ["host =", "port =", "database =", "api_key = os.environ.get("API_KEY_API_KEY", ", ")secret ="]
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    
                for line_num, line in enumerate(lines, 1):
                    for pattern in config_patterns:
                        if pattern in line and not any(skip in line.lower() for skip in ["# ", "#", "print(", "logging."]):
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=line_num,
                                issue_type="hardcoded_config",
                                severity="medium",
                                description=f"Hardcoded configuration: {pattern}",
                                recommendation="Use environment variables or config files",
                                code_snippet=line.strip()
                            ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_dependency_management(self):
        """Check dependency management"""
        logger.info("📦 Checking dependency management...")
        
        # Check for requirements.txt
        requirements_file = self.codebase_path / "requirements.txt"
        if not requirements_file.exists():
            self.issues.append(ProductionIssue(
                file_path="requirements.txt",
                line_number=1,
                issue_type="missing_requirements",
                severity="high",
                description="Missing requirements.txt file",
                recommendation="Create requirements.txt with pinned versions",
                code_snippet="requirements.txt not found"
            ))
        else:
            try:
                with open(requirements_file, 'r') as f:
                    requirements = f.read()
                    
                # Check for unpinned versions
                for line_num, line in enumerate(requirements.split('\n'), 1):
                    if line.strip() and not line.startswith('#'):
                        if '==' not in line and '>=' not in line and '<=' not in line:
                            package_name = line.split('==')[0].split('>=')[0].split('<=')[0].strip()
                            self.issues.append(ProductionIssue(
                                file_path=str(requirements_file),
                                line_number=line_num,
                                issue_type="unpinned_dependency",
                                severity="medium",
                                description=f"Unpinned dependency: {package_name}",
                                recommendation="Pin dependency versions for reproducibility",
                                code_snippet=line.strip()
                            ))
            except Exception as e:
                logger.error(f"Error reading requirements.txt: {e}")
    
    def _check_logging_and_monitoring(self):
        """Check logging and monitoring"""
        logger.info("📊 Checking logging and monitoring...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                # Check for proper logging
                if "import logging" in content:
                    if "logging.basicConfig" not in content and "logger = " not in content:
                        self.issues.append(ProductionIssue(
                            file_path=str(file_path),
                            line_number=1,
                            issue_type="missing_logging_config",
                            severity="medium",
                            description="Logging imported but not configured",
                            recommendation="Configure logging with basicConfig",
                            code_snippet="logging imported but not configured"
                        ))
                
                # Check for missing error logging
                lines = content.split('\n')
                for line_num, line in enumerate(lines, 1):
                    if "except" in line and "logger." not in lines[max(0, line_num-3):line_num+3]:
                        self.issues.append(ProductionIssue(
                            file_path=str(file_path),
                            line_number=line_num,
                            issue_type="missing_error_logging",
                            severity="low",
                            description="Exception without logging",
                            recommendation="Add logging for exception handling",
                            code_snippet=line.strip()
                        ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_database_connections(self):
        """Check database connection management"""
        logger.info("🗄️ Checking database connections...")
        
        db_patterns = ["psycopg2", "asyncpg", "redis", "sqlite3", "mysql"]
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                for db_lib in db_patterns:
                    if db_lib in content:
                        # Check for connection pooling
                        if "create_pool" not in content and "connect(" in content:
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=1,
                                issue_type="no_connection_pooling",
                                severity="high",
                                description=f"Database connection without pooling: {db_lib}",
                                recommendation="Use connection pooling for performance",
                                code_snippet=f"{db_lib} found without connection pooling"
                            ))
                        
                        # Check for connection closing
                        if ".close()" not in content and "connect(" in content:
                            self.issues.append(ProductionIssue(
                                file_path=str(file_path),
                                line_number=1,
                                issue_type="unclosed_connection",
                                severity="medium",
                                description=f"Database connection not properly closed: {db_lib}",
                                recommendation="Ensure connections are properly closed",
                                code_snippet=f"{db_lib} connection not closed"
                            ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_api_design(self):
        """Check API design issues"""
        logger.info("🔌 Checking API design...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                # Check for FastAPI apps
                if "FastAPI" in content:
                    # Check for missing rate limiting
                    if "limiter" not in content and "RateLimitMiddleware" not in content:
                        self.issues.append(ProductionIssue(
                            file_path=str(file_path),
                            line_number=1,
                            issue_type="missing_rate_limiting",
                            severity="medium",
                            description="FastAPI app without rate limiting",
                            recommendation="Add rate limiting middleware",
                            code_snippet="FastAPI app without rate limiting"
                        ))
                    
                    # Check for missing CORS
                    if "CORSMiddleware" not in content:
                        self.issues.append(ProductionIssue(
                            file_path=str(file_path),
                            line_number=1,
                            issue_type="missing_cors",
                            severity="medium",
                            description="FastAPI app without CORS middleware",
                            recommendation="Add CORS middleware for web frontend",
                            code_snippet="FastAPI app without CORS"
                        ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_authentication(self):
        """Check authentication implementation"""
        logger.info("🔑 Checking authentication...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                # Check for API endpoints without authentication
                if "@app." in content and "def " in content:
                    lines = content.split('\n')
                    for line_num, line in enumerate(lines, 1):
                        if "@app." in line and "def " in lines[line_num]:
                            endpoint_name = lines[line_num].split("def ")[1].split("(")[0]
                            if "public" in endpoint_name or "health" in endpoint_name.lower():
                                continue  # Skip public endpoints
                            
                            # Check if next few lines have authentication
                            has_auth = any("auth" in lines[i].lower() or "token" in lines[i].lower() 
                                         for i in range(line_num, min(line_num + 5, len(lines))))
                            
                            if not has_auth:
                                self.issues.append(ProductionIssue(
                                    file_path=str(file_path),
                                    line_number=line_num,
                                    issue_type="unauthenticated_endpoint",
                                    severity="high",
                                    description=f"API endpoint without authentication: {endpoint_name}",
                                    recommendation="Add authentication middleware",
                                    code_snippet=line.strip()
                                ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _check_input_validation(self):
        """Check input validation"""
        logger.info("✅ Checking input validation...")
        
        for file_path in self.python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                # Check for API endpoints without validation
                if "@app." in content and "def " in content:
                    lines = content.split('\n')
                    for line_num, line in enumerate(lines, 1):
                        if "@app." in line and "def " in lines[line_num]:
                            # Check function parameters
                            func_lines = []
                            for i in range(line_num, len(lines)):
                                if lines[i].strip().startswith("def ") or lines[i].strip().startswith("@"):
                                    break
                                func_lines.append(lines[i])
                            
                            func_content = '\n'.join(func_lines)
                            if "request" in func_content and "validate" not in func_content.lower():
                                self.issues.append(ProductionIssue(
                                    file_path=str(file_path),
                                    line_number=line_num,
                                    issue_type="missing_input_validation",
                                    severity="medium",
                                    description="API endpoint without input validation",
                                    recommendation="Add input validation for API parameters",
                                    code_snippet=line.strip()
                                ))
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
    
    def _calculate_scores(self) -> ProductionReadinessScore:
        """Calculate production readiness scores"""
        logger.info("📊 Calculating production readiness scores...")
        
        # Count issues by severity
        critical_issues = len([i for i in self.issues if i.severity == "critical"])
        high_issues = len([i for i in self.issues if i.severity == "high"])
        medium_issues = len([i for i in self.issues if i.severity == "medium"])
        low_issues = len([i for i in self.issues if i.severity == "low"])
        
        # Calculate scores (0-100 scale)
        total_issues = critical_issues + high_issues + medium_issues + low_issues
        
        # Deduct points based on severity
        deduction = (critical_issues * 20 + high_issues * 10 + medium_issues * 5 + low_issues * 1)
        base_score = max(0, 100 - deduction)
        
        # Category-specific scores
        security_issues = [i for i in self.issues if i.issue_type in ["hardcoded_secret", "sql_injection", "command_injection", "xss", "unauthenticated_endpoint"]]
        security_score = max(0, 100 - (len(security_issues) * 15))
        
        performance_issues = [i for i in self.issues if i.issue_type in ["sync_io_in_async", "blocking_http", "no_connection_pooling"]]
        performance_score = max(0, 100 - (len(performance_issues) * 12))
        
        reliability_issues = [i for i in self.issues if i.issue_type in ["bare_except", "unhandled_exception", "missing_retry"]]
        reliability_score = max(0, 100 - (len(reliability_issues) * 10))
        
        maintainability_issues = [i for i in self.issues if i.issue_type in ["large_file", "complex_function", "hardcoded_config"]]
        maintainability_score = max(0, 100 - (len(maintainability_issues) * 8))
        
        scalability_issues = [i for i in self.issues if i.issue_type in ["hardcoded_limit", "missing_rate_limiting", "missing_cors"]]
        scalability_score = max(0, 100 - (len(scalability_issues) * 10))
        
        overall_score = (security_score + performance_score + reliability_score + maintainability_score + scalability_score) / 5
        
        return ProductionReadinessScore(
            overall_score=overall_score,
            security_score=security_score,
            performance_score=performance_score,
            reliability_score=reliability_score,
            maintainability_score=maintainability_score,
            scalability_score=scalability_score,
            critical_issues=critical_issues,
            high_issues=high_issues,
            medium_issues=medium_issues,
            low_issues=low_issues,
            total_files=self.total_files
        )
    
    def generate_report(self, score: ProductionReadinessScore) -> str:
        """Generate comprehensive production readiness report"""
        report = []
        report.append("# 🎯 PRODUCTION READINESS ASSESSMENT REPORT")
        report.append("=" * 60)
        report.append("")
        
        # Executive Summary
        report.append("## 📊 EXECUTIVE SUMMARY")
        report.append(f"**Overall Score:** {score.overall_score:.1f}/100")
        report.append(f"**Total Files Scanned:** {score.total_files}")
        report.append(f"**Total Issues Found:** {score.critical_issues + score.high_issues + score.medium_issues + score.low_issues}")
        report.append("")
        
        # Score Breakdown
        report.append("## 📈 SCORE BREAKDOWN")
        report.append(f"**Security Score:** {score.security_score:.1f}/100")
        report.append(f"**Performance Score:** {score.performance_score:.1f}/100")
        report.append(f"**Reliability Score:** {score.reliability_score:.1f}/100")
        report.append(f"**Maintainability Score:** {score.maintainability_score:.1f}/100")
        report.append(f"**Scalability Score:** {score.scalability_score:.1f}/100")
        report.append("")
        
        # Issues Summary
        report.append("## 🚨 ISSUES SUMMARY")
        report.append(f"🔴 Critical Issues: {score.critical_issues}")
        report.append(f"🟠 High Issues: {score.high_issues}")
        report.append(f"🟡 Medium Issues: {score.medium_issues}")
        report.append(f"🟢 Low Issues: {score.low_issues}")
        report.append("")
        
        # Critical Issues
        critical_issues = [i for i in self.issues if i.severity == "critical"]
        if critical_issues:
            report.append("## 🔴 CRITICAL ISSUES (Must Fix Before Production)")
            for issue in critical_issues[:10]:  # Show first 10
                report.append(f"### {issue.file_path}:{issue.line_number}")
                report.append(f"**Type:** {issue.issue_type}")
                report.append(f"**Description:** {issue.description}")
                report.append(f"**Recommendation:** {issue.recommendation}")
                report.append(f"**Code:** `{issue.code_snippet}`")
                report.append("")
        
        # High Priority Issues
        high_issues = [i for i in self.issues if i.severity == "high"]
        if high_issues:
            report.append("## 🟠 HIGH PRIORITY ISSUES")
            for issue in high_issues[:10]:  # Show first 10
                report.append(f"### {issue.file_path}:{issue.line_number}")
                report.append(f"**Type:** {issue.issue_type}")
                report.append(f"**Description:** {issue.description}")
                report.append(f"**Recommendation:** {issue.recommendation}")
                report.append(f"**Code:** `{issue.code_snippet}`")
                report.append("")
        
        # Production Readiness Assessment
        report.append("## 🎯 PRODUCTION READINESS ASSESSMENT")
        
        if score.overall_score >= 90:
            report.append("✅ **EXCELLENT** - Ready for production deployment")
            report.append("   - All critical and high-priority issues resolved")
            report.append("   - Robust security and error handling")
            report.append("   - Scalable and maintainable architecture")
        elif score.overall_score >= 80:
            report.append("✅ **GOOD** - Ready for production with minor fixes")
            report.append("   - No critical issues")
            report.append("   - Address high-priority issues before deployment")
            report.append("   - Good security and reliability practices")
        elif score.overall_score >= 70:
            report.append("⚠️ **FAIR** - Production ready with significant fixes")
            report.append("   - No critical issues")
            report.append("   - Multiple high-priority issues need attention")
            report.append("   - Security and reliability improvements needed")
        else:
            report.append("❌ **NOT READY** - Not ready for production")
            report.append("   - Critical issues must be resolved")
            report.append("   - Significant security and reliability concerns")
            report.append("   - Major architectural improvements needed")
        
        report.append("")
        report.append("## 💡 RECOMMENDATIONS")
        report.append("1. **Fix all critical issues immediately**")
        report.append("2. **Address high-priority issues before production**")
        report.append("3. **Implement comprehensive testing**")
        report.append("4. **Add monitoring and alerting**")
        report.append("5. **Create deployment and rollback procedures**")
        report.append("6. **Document architecture and operations**")
        report.append("")
        
        return "\n".join(report)

def main():
    """Main production readiness assessment"""
    logging.info("🔍 PRODUCTION READINESS ASSESSMENT & BUG HUNT")
    logging.info("=" * 60)
    
    # Initialize bug hunter
    codebase_path = Path("/Users/theowolfenden/CascadeProjects/Terradev")
    hunter = ProductionBugHunter(str(codebase_path))
    
    # Run comprehensive scan
    score = hunter.scan_codebase()
    
    # Generate report
    report = hunter.generate_report(score)
    
    # Save report
    report_file = codebase_path / "production_readiness_report.md"
    with open(report_file, 'w') as f:
        f.write(report)
    
    logging.info(f"\n📊 Production Readiness Assessment Complete!")
    logging.info(f"📄 Report saved to: {report_file}")
    logging.info(f"🎯 Overall Score: {score.overall_score:.1f}/100")
    logging.info(f"🔴 Critical Issues: {score.critical_issues}")
    logging.info(f"🟠 High Issues: {score.high_issues}")
    logging.info(f"🟡 Medium Issues: {score.medium_issues}")
    logging.info(f"🟢 Low Issues: {score.low_issues}")
    
    # Show top issues
    logging.info(f"\n🚨 Top 5 Critical Issues:")
    critical_issues = [i for i in hunter.issues if i.severity == "critical"][:5]
    for i, issue in enumerate(critical_issues, 1):
        logging.info(f"{i}. {issue.file_path}:{issue.line_number} - {issue.description}")
    
    logging.info(f"\n🎯 Production Readiness: {'EXCELLENT' if score.overall_score >= 90 else 'GOOD' if score.overall_score >= 80 else 'FAIR' if score.overall_score >= 70 else 'NOT READY'}")

if __name__ == "__main__":
    main()
