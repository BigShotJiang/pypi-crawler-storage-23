#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages
import os

# Read the README file for long description
with open(os.path.join(os.path.dirname(__file__), 'README.md'), 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='py-enjoy',
    version='1.0.1',
    description='JFinal-Enjoy Python 3.9+ 实现,基于5.2.2版本',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='James Zhan 詹波 (original), Python port by mrzhou@miw.cn',
    author_email='mrzhou@miw.cn',
    url='https://github.com/yourusername/py_enjoy',  # 请替换为实际的GitHub仓库URL
    license='Apache-2.0',
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.6',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Text Processing :: Markup',
    ],
    keywords='template engine, jfinal, enjoy, python',
)
