#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Directive - Base Directive Class
"""

from typing import Optional
from .expr.ast import ExprList
from .stat.ast.Stat import Stat

class Directive(Stat):
    """Base class for custom directives"""
    
    def __init__(self):
        """Initialize directive"""
        super().__init__()
        self._expr_list: Optional[ExprList] = None
        self._stat: Optional[Stat] = None
    
    @property
    def expr_list(self) -> Optional[ExprList]:
        """Get expression list"""
        return self._expr_list
    
    @expr_list.setter
    def expr_list(self, value: ExprList):
        """Set expression list"""
        self._expr_list = value
    
    @property
    def stat(self) -> Optional[Stat]:
        """Get nested stat"""
        return self._stat
    
    @stat.setter
    def stat(self, value: Stat):
        """Set nested stat"""
        self._stat = value
    
    def set_expr_list(self, expr_list: ExprList):
        """Set expression list (for parser)"""
        self._expr_list = expr_list
    
    def set_stat(self, stat: Stat):
        """Set nested stat (for parser)"""
        self._stat = stat
