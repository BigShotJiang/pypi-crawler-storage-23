#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal FileSourceFactory - File Source Factory
"""

import os
from .ISourceFactory import ISourceFactory

class FileSourceFactory(ISourceFactory):
    """File source factory for template loading"""
    
    def get_source(self, base_template_path: str, fileName: str, encoding: str):
        """
        Get file source
        
        Args:
            base_template_path: Base template path
            fileName: File name
            encoding: Encoding
            
        Returns:
            File source object
        """
        from .FileSource import FileSource
        return FileSource(base_template_path, fileName, encoding)
    
    def __repr__(self) -> str:
        return "FileSourceFactory()"
