#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal ISourceFactory - Source Factory Interface
"""

class ISourceFactory:
    """Source factory interface for template loading"""
    
    def get_source(self, base_template_path: str, fileName: str, encoding: str):
        """
        Get source by file name
        
        Args:
            base_template_path: Base template path
            fileName: File name
            encoding: Encoding
            
        Returns:
            Source object
        """
        raise NotImplementedError("ISourceFactory.get_source() must be implemented by subclasses")
