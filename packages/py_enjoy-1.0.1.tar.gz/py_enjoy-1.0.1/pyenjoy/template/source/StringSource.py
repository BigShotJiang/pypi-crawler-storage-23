#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal StringSource - String Source
"""

class StringSource:
    """String source for template loading"""
    
    def __init__(self, content: str, cache_key: str = None):
        """
        Initialize string source
        
        Args:
            content: Template content
            cache_key: Cache key (optional)
        """
        self._content = content
        self._cache_key = cache_key
    
    def get_content(self) -> str:
        """
        Get string content
        
        Returns:
            Content as string
        """
        return self._content
    
    def is_modified(self) -> bool:
        """
        Check if content has been modified
        
        Returns:
            Always False for string sources
        """
        return False
    
    def get_cache_key(self) -> str:
        """
        Get cache key
        
        Returns:
            Cache key
        """
        return self._cache_key
    
    def __repr__(self) -> str:
        content_preview = self._content[:50] + "..." if len(self._content) > 50 else self._content
        return f"StringSource('{content_preview}')"
