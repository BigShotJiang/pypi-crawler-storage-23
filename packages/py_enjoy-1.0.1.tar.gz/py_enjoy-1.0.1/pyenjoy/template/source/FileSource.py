#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal FileSource - File Source
"""

import os
import time

class FileSource:
    """File source for template loading"""
    
    def __init__(self, base_template_path: str, fileName: str, encoding: str):
        """
        Initialize file source
        
        Args:
            base_template_path: Base template path
            fileName: File name
            encoding: Encoding
        """
        self._fileName = fileName
        self._encoding = encoding
        self._lastModified = 0
        
        # Build file path
        if base_template_path:
            self._filePath = os.path.join(base_template_path, fileName)
        else:
            self._filePath = fileName
        
        # Normalize path
        self._filePath = os.path.normpath(self._filePath)
        
        # Get last modified time
        self._update_last_modified()
    
    def get_content(self) -> str:
        """
        Get file content
        
        Returns:
            File content as string
        """
        try:
            with open(self._filePath, 'r', encoding=self._encoding) as f:
                return f.read()
        except Exception as e:
            raise RuntimeError(f"Error reading file {self._filePath}: {e}")
    
    def is_modified(self) -> bool:
        """
        Check if file has been modified
        
        Returns:
            True if modified, False otherwise
        """
        current_modified = os.path.getmtime(self._filePath)
        if current_modified > self._lastModified:
            self._lastModified = current_modified
            return True
        return False
    
    def _update_last_modified(self):
        """Update last modified time"""
        try:
            self._lastModified = os.path.getmtime(self._filePath)
        except:
            self._lastModified = 0
    
    def get_file_name(self) -> str:
        """Get file name"""
        return self._fileName
    
    def __repr__(self) -> str:
        return f"FileSource({self._fileName})"
