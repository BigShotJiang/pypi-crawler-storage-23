#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal ClassPathSourceFactory - Class Path Source Factory
"""

from .ISourceFactory import ISourceFactory

class ClassPathSourceFactory(ISourceFactory):
    """Class path source factory for template loading"""
    
    def get_source(self, base_template_path: str, fileName: str, encoding: str):
        """
        Get class path source
        
        Args:
            base_template_path: Base template path
            fileName: File name
            encoding: Encoding
            
        Returns:
            Class path source object
        """
        from .ClassPathSource import ClassPathSource
        return ClassPathSource(base_template_path, fileName, encoding)
    
    def __repr__(self) -> str:
        return "ClassPathSourceFactory()"
