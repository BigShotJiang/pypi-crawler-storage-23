#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Env - Template Environment
"""

from typing import Dict, Optional, List

class Env:
    """Template environment for storing template functions and managing sources"""
    
    def __init__(self, engine_config):
        """
        Initialize environment
        
        Args:
            engine_config: Engine configuration
        """
        self._engine_config = engine_config
        self._function_map: Dict[str, object] = {}
        self._source_list: Optional[List[object]] = None
    
    @property
    def engine_config(self):
        """Get engine configuration"""
        return self._engine_config
    
    @property
    def is_dev_mode(self) -> bool:
        """Check if in development mode"""
        return self._engine_config.is_dev_mode()
    
    def add_function(self, function_name: str, function: object):
        """
        Add template function
        
        Args:
            function_name: Function name
            function: Function object
        """
        if function_name in self._function_map:
            raise ValueError(f"Template function '{function_name}' already defined")
        
        self._function_map[function_name] = function
    
    def get_function(self, function_name: str) -> Optional[object]:
        """
        Get template function
        
        Args:
            function_name: Function name
            
        Returns:
            Function object or None
        """
        func = self._function_map.get(function_name)
        if func is not None:
            return func
        
        # Try to get from shared functions
        return self._engine_config.get_shared_function(function_name)
    
    def get_function_map(self) -> Dict[str, object]:
        """Get all functions"""
        return self._function_map.copy()
    
    def add_source(self, source):
        """
        Add source for dev mode tracking
        
        Args:
            source: Source object
        """
        if self._source_list is None:
            self._source_list = []
        
        self._source_list.append(source)
    
    def is_source_list_modified(self) -> bool:
        """Check if any source has been modified (for dev mode)"""
        if self._source_list:
            for source in self._source_list:
                if hasattr(source, 'is_modified') and source.is_modified():
                    return True
        return False
    
    def clear_functions(self):
        """Clear all functions"""
        self._function_map.clear()
    
    def __repr__(self) -> str:
        return f"Env(function_count={len(self._function_map)}, dev_mode={self.is_dev_mode})"
