#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Const - Constant Expression
"""

from .Expr import Expr

class Const(Expr):
    """Constant value expression"""
    
    def __init__(self, value):
        """
        Initialize constant
        
        Args:
            value: Constant value
        """
        self._value = value
    
    def eval(self, scope):
        """Evaluate and return constant value"""
        return self._value
    
    def __repr__(self) -> str:
        return f"Const({self._value})"


class NullExpr(Expr):
    """Null expression"""
    
    def eval(self, scope):
        """Evaluate and return None"""
        return None
    
    def __repr__(self) -> str:
        return "NullExpr()"


class Id(Expr):
    """Identifier expression (variable reference)"""
    
    def __init__(self, name: str):
        """
        Initialize identifier
        
        Args:
            name: Variable name
        """
        self._name = name
    
    def eval(self, scope):
        """Evaluate and return variable value"""
        return scope.get(self._name)
    
    @property
    def name(self) -> str:
        """Get identifier name"""
        return self._name
    
    def __repr__(self) -> str:
        return f"Id({self._name})"


class Map(Expr):
    """Map/dictionary expression"""
    
    def __init__(self):
        """Initialize empty map"""
        self._entries = []
    
    def add_entry(self, key_expr: Expr, value_expr: Expr):
        """
        Add map entry
        
        Args:
            key_expr: Key expression
            value_expr: Value expression
        """
        self._entries.append((key_expr, value_expr))
    
    def eval(self, scope):
        """Evaluate and return map"""
        result = {}
        for key_expr, value_expr in self._entries:
            key = key_expr.eval(scope)
            value = value_expr.eval(scope)
            if key is not None:
                result[key] = value
        return result
    
    def __repr__(self) -> str:
        return f"Map({len(self._entries)} entries)"


class Array(Expr):
    """Array/list expression"""
    
    def __init__(self):
        """Initialize empty array"""
        self._elements = []
    
    def add_element(self, element_expr: Expr):
        """
        Add array element
        
        Args:
            element_expr: Element expression
        """
        self._elements.append(element_expr)
    
    def eval(self, scope):
        """Evaluate and return array"""
        return [expr.eval(scope) for expr in self._elements]
    
    def __repr__(self) -> str:
        return f"Array({len(self._elements)} elements)"


class RangeArray(Expr):
    """Range array expression (e.g., 1..10)"""
    
    def __init__(self, start_expr: Expr, end_expr: Expr, inclusive: bool = True):
        """
        Initialize range array
        
        Args:
            start_expr: Start expression
            end_expr: End expression
            inclusive: Whether end is inclusive
        """
        self._start_expr = start_expr
        self._end_expr = end_expr
        self._inclusive = inclusive
    
    def eval(self, scope):
        """Evaluate and return range array"""
        start = self._start_expr.eval(scope)
        end = self._end_expr.eval(scope)
        
        if isinstance(start, int) and isinstance(end, int):
            if self._inclusive:
                return list(range(start, end + 1))
            else:
                return list(range(start, end))
        
        # For non-integer ranges, return empty list
        return []
    
    def __repr__(self) -> str:
        return f"RangeArray({self._start_expr}, {self._end_expr}, inclusive={self._inclusive})"
