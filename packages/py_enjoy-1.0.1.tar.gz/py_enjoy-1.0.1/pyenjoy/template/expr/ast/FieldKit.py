#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal FieldKit - Field Access Utilities
"""

class FieldKit:
    """Field access utilities"""
    
    @staticmethod
    def get_field(obj, field_name: str):
        """
        Get field value from object
        
        Args:
            obj: Object to get field from
            field_name: Field name
            
        Returns:
            Field value or None
        """
        if obj is None:
            return None
        
        # Try attribute access
        if hasattr(obj, field_name):
            return getattr(obj, field_name)
        
        # Try dictionary access
        if isinstance(obj, dict) and field_name in obj:
            return obj[field_name]
        
        return None
    
    @staticmethod
    def set_field(obj, field_name: str, value):
        """
        Set field value on object
        
        Args:
            obj: Object to set field on
            field_name: Field name
            value: Value to set
            
        Returns:
            True if successful, False otherwise
        """
        if obj is None:
            return False
        
        # Try attribute access
        if hasattr(obj, field_name):
            setattr(obj, field_name, value)
            return True
        
        # Try dictionary access
        if isinstance(obj, dict):
            obj[field_name] = value
            return True
        
        return False
    
    def __repr__(self) -> str:
        return "FieldKit()"
