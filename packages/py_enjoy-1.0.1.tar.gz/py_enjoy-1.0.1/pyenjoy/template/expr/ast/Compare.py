#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Compare - Comparison Expression
"""

from .Expr import Expr

class Compare(Expr):
    """Comparison expression"""
    
    EQ = "=="
    NE = "!="
    GT = ">"
    GTE = ">="
    LT = "<"
    LTE = "<="
    
    def __init__(self, left: Expr, operator: str, right: Expr):
        """
        Initialize comparison
        
        Args:
            left: Left expression
            operator: Comparison operator
            right: Right expression
        """
        self._left = left
        self._operator = operator
        self._right = right
    
    def eval(self, scope):
        """Evaluate comparison"""
        left_val = self._left.eval(scope)
        right_val = self._right.eval(scope)
        
        # Handle None comparisons
        if left_val is None and right_val is None:
            return self._operator == Compare.EQ
        if left_val is None or right_val is None:
            return self._operator == Compare.NE
        
        # Perform comparison based on operator
        if self._operator == Compare.EQ:
            return left_val == right_val
        elif self._operator == Compare.NE:
            return left_val != right_val
        elif self._operator == Compare.GT:
            return left_val > right_val
        elif self._operator == Compare.GTE:
            return left_val >= right_val
        elif self._operator == Compare.LT:
            return left_val < right_val
        elif self._operator == Compare.LTE:
            return left_val <= right_val
        else:
            raise ValueError(f"Unknown operator: {self._operator}")
    
    @property
    def operator(self) -> str:
        """Get operator"""
        return self._operator
    
    def __repr__(self) -> str:
        return f"Compare({self._left} {self._operator} {self._right})"


class Logic(Expr):
    """Logical expression (and, or, not)"""
    
    AND = "&&"
    OR = "||"
    NOT = "!"
    
    def __init__(self, operator: str, *expressions: Expr):
        """
        Initialize logical expression
        
        Args:
            operator: Logical operator
            expressions: Expressions to operate on
        """
        self._operator = operator
        self._expressions = expressions
    
    def eval(self, scope):
        """Evaluate logical expression"""
        if self._operator == Logic.NOT:
            # Unary NOT
            if not self._expressions:
                return True
            return not self._expressions[0].eval(scope)
        else:
            # Binary AND/OR
            results = [expr.eval(scope) for expr in self._expressions]
            
            if self._operator == Logic.AND:
                return all(results)
            elif self._operator == Logic.OR:
                return any(results)
            else:
                raise ValueError(f"Unknown operator: {self._operator}")
    
    def __repr__(self) -> str:
        expr_str = f" {self._operator} ".join(str(expr) for expr in self._expressions)
        if self._operator == Logic.NOT:
            return f"NOT({expr_str})"
        return f"({expr_str})"


class Ternary(Expr):
    """Ternary conditional expression (condition ? true_val : false_val)"""
    
    def __init__(self, condition: Expr, true_expr: Expr, false_expr: Expr):
        """
        Initialize ternary expression
        
        Args:
            condition: Condition expression
            true_expr: Expression when condition is true
            false_expr: Expression when condition is false
        """
        self._condition = condition
        self._true_expr = true_expr
        self._false_expr = false_expr
    
    def eval(self, scope):
        """Evaluate ternary expression"""
        cond_val = self._condition.eval(scope)
        
        # Convert to boolean (handle None, 0, empty strings, etc.)
        if cond_val:
            return self._true_expr.eval(scope)
        else:
            return self._false_expr.eval(scope)
    
    def __repr__(self) -> str:
        return f"Ternary({self._condition} ? {self._true_expr} : {self._false_expr})"
