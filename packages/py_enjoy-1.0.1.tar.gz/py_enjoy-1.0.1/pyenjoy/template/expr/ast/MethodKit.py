#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal MethodKit - Method Access Utilities
"""

class MethodKit:
    """Method access utilities"""
    
    @staticmethod
    def get_method(obj, method_name: str, *args):
        """
        Get method from object
        
        Args:
            obj: Object to get method from
            method_name: Method name
            args: Method arguments
            
        Returns:
            Method or None
        """
        if obj is None:
            return None
        
        # Try attribute access
        if hasattr(obj, method_name):
            method = getattr(obj, method_name)
            if callable(method):
                return method
        
        return None
    
    @staticmethod
    def invoke_method(obj, method_name: str, *args):
        """
        Invoke method on object
        
        Args:
            obj: Object to invoke method on
            method_name: Method name
            args: Method arguments
            
        Returns:
            Method result or None
        """
        method = MethodKit.get_method(obj, method_name)
        if method:
            try:
                return method(*args)
            except:
                return None
        return None
    
    def __repr__(self) -> str:
        return "MethodKit()"
