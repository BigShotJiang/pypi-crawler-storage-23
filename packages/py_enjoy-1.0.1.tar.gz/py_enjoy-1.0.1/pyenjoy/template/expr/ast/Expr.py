#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Expr - Expression Evaluation Base Class
"""

from typing import Any
from ...stat.Scope import Scope
from ...Env import Env

class Expr:
    """Base class for expression AST nodes"""
    
    def eval(self, scope: Scope) -> Any:
        """
        Evaluate expression
        
        Args:
            scope: Execution scope
            
        Returns:
            Expression result
        """
        raise NotImplementedError("Expr.eval() must be implemented by subclasses")
    
    def eval_expr_list(self, scope: Scope) -> list:
        """
        Evaluate as expression list
        
        Args:
            scope: Execution scope
            
        Returns:
            List of expression results
        """
        return [self.eval(scope)]
    
    def __repr__(self) -> str:
        return f"Expr({self.__class__.__name__})"


class ExprList(Expr):
    """Expression list containing multiple expressions"""
    
    def __init__(self, expressions: list = None):
        """
        Initialize expression list
        
        Args:
            expressions: List of expressions
        """
        self._expressions = expressions or []
    
    def add_expr(self, expr: Expr):
        """
        Add expression to list
        
        Args:
            expr: Expression to add
        """
        if expr:
            self._expressions.append(expr)
    
    def eval(self, scope: Scope) -> Any:
        """
        Evaluate all expressions and return last result
        
        Args:
            scope: Execution scope
            
        Returns:
            Last expression result
        """
        result = None
        for expr in self._expressions:
            result = expr.eval(scope)
        return result
    
    def eval_expr_list(self, scope: Scope) -> list:
        """
        Evaluate all expressions and return list of results
        
        Args:
            scope: Execution scope
            
        Returns:
            List of results
        """
        return [expr.eval(scope) for expr in self._expressions]
    
    def get_expressions(self) -> list:
        """Get all expressions"""
        return self._expressions.copy()
    
    def __len__(self) -> int:
        """Get number of expressions"""
        return len(self._expressions)
    
    def __repr__(self) -> str:
        return f"ExprList({len(self._expressions)} expressions)"
