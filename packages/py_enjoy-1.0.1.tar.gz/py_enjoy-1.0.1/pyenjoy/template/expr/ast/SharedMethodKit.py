#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal SharedMethodKit - Shared Method Kit
"""

from typing import Dict, List, Any, Optional

class SharedMethodKit:
    """Shared method kit for template functions"""
    
    def __init__(self):
        """Initialize shared method kit"""
        self._shared_methods: Dict[str, List[Any]] = {}
    
    def add_shared_method(self, obj: Any):
        """
        Add shared methods from object
        
        Args:
            obj: Object with methods to add
        """
        if obj is None:
            return
        
        # Get all methods from object
        import inspect
        for name, method in inspect.getmembers(obj, predicate=inspect.ismethod):
            if not name.startswith('_'):
                if name not in self._shared_methods:
                    self._shared_methods[name] = []
                self._shared_methods[name].append(method)
    
    def add_shared_method_from_class(self, clazz):
        """
        Add shared methods from class
        
        Args:
            clazz: Class with methods to add
        """
        if clazz is None:
            return
        
        # Get all methods from class
        import inspect
        for name, method in inspect.getmembers(clazz, predicate=inspect.isfunction):
            if not name.startswith('_'):
                if name not in self._shared_methods:
                    self._shared_methods[name] = []
                self._shared_methods[name].append(method)
    
    def add_shared_static_method(self, clazz):
        """
        Add shared static methods from class
        
        Args:
            clazz: Class with static methods to add
        """
        if clazz is None:
            return
        
        # Get all static methods from class
        import inspect
        for name, method in inspect.getmembers(clazz, predicate=inspect.isfunction):
            if not name.startswith('_'):
                if name not in self._shared_methods:
                    self._shared_methods[name] = []
                self._shared_methods[name].append(method)
    
    def remove_shared_method(self, method_name: str):
        """
        Remove shared method by name
        
        Args:
            method_name: Method name to remove
        """
        if method_name in self._shared_methods:
            del self._shared_methods[method_name]
    
    def get_shared_method(self, method_name: str) -> Optional[Any]:
        """
        Get shared method by name
        
        Args:
            method_name: Method name to get
            
        Returns:
            Shared method or None
        """
        if method_name in self._shared_methods:
            methods = self._shared_methods[method_name]
            if methods:
                return methods[0]
        return None
    
    def get_shared_methods(self, method_name: str) -> List[Any]:
        """
        Get all shared methods with given name
        
        Args:
            method_name: Method name
            
        Returns:
            List of shared methods
        """
        return self._shared_methods.get(method_name, [])
    
    def has_shared_method(self, method_name: str) -> bool:
        """
        Check if shared method exists
        
        Args:
            method_name: Method name
            
        Returns:
            True if method exists, False otherwise
        """
        return method_name in self._shared_methods and self._shared_methods[method_name]
    
    def __repr__(self) -> str:
        return f"SharedMethodKit({len(self._shared_methods)} methods)"
