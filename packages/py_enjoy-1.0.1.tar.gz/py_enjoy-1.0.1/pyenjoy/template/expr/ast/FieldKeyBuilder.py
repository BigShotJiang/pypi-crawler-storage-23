#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal FieldKeyBuilder - Field Key Builder
"""

class FieldKeyBuilder:
    """Field key builder for field access"""
    
    def __init__(self):
        """Initialize field key builder"""
        pass
    
    def build_field_key(self, field_name: str) -> str:
        """
        Build field key
        
        Args:
            field_name: Field name
            
        Returns:
            Field key
        """
        return field_name
    
    def __repr__(self) -> str:
        return "FieldKeyBuilder()"
