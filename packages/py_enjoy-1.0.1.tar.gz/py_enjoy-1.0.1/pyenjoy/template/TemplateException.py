#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal TemplateException - Template Exception
"""

class TemplateException(Exception):
    """Template runtime exception"""
    
    def __init__(self, message: str, location = None, cause: Exception = None):
        """
        Initialize template exception
        
        Args:
            message: Error message
            location: Error location (optional)
            cause: Original exception (optional)
        """
        full_message = message
        if location is not None:
            full_message += str(location)
        
        super().__init__(full_message)
        self._location = location
        self._cause = cause
    
    @property
    def location(self):
        """Get error location"""
        return self._location
    
    @property
    def cause(self) -> Exception:
        """Get original cause"""
        return self._cause
    
    def __str__(self) -> str:
        result = super().__str__()
        if self._cause and self._cause != self:
            result += f"\nCaused by: {self._cause}"
        return result
    
    def __repr__(self) -> str:
        return f"TemplateException(message={super().__repr__()}, location={self._location})"
