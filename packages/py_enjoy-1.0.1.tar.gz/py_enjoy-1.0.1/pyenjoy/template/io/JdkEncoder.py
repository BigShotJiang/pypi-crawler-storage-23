#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal JdkEncoder - JDK Encoder
"""

class JdkEncoder:
    """JDK encoder for template output"""
    
    def encode(self, str_val: str) -> str:
        """
        Encode string
        
        Args:
            str_val: String to encode
            
        Returns:
            Encoded string
        """
        return str_val
    
    def encode_half(self, str_val: str) -> str:
        """
        Encode string (half encoding)
        
        Args:
            str_val: String to encode
            
        Returns:
            Encoded string
        """
        return str_val
    
    def encode_all(self, str_val: str) -> str:
        """
        Encode string (full encoding)
        
        Args:
            str_val: String to encode
            
        Returns:
            Encoded string
        """
        return str_val
    
    def __repr__(self) -> str:
        return "JdkEncoder()"
