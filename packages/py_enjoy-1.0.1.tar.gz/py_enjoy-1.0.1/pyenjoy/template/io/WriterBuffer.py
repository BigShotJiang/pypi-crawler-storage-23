#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal WriterBuffer - Writer Buffer
"""

class WriterBuffer:
    """Writer buffer for template output"""
    
    def __init__(self):
        """Initialize writer buffer"""
        self._encoding = "UTF-8"
        self._buffer_size = 8192
        self._reentrant_buffer_size = 1024
        self._encoder_factory = None
    
    def set_encoding(self, encoding: str):
        """Set encoding"""
        self._encoding = encoding
        if self._encoder_factory:
            # Set encoding on encoder factory if available
            pass
    
    def set_buffer_size(self, buffer_size: int):
        """Set buffer size"""
        self._buffer_size = buffer_size
    
    def set_reentrant_buffer_size(self, reentrant_buffer_size: int):
        """Set reentrant buffer size"""
        self._reentrant_buffer_size = reentrant_buffer_size
    
    def set_encoder_factory(self, encoder_factory):
        """Set encoder factory"""
        self._encoder_factory = encoder_factory
    
    def get_encoding(self) -> str:
        """Get encoding"""
        return self._encoding
    
    def get_buffer_size(self) -> int:
        """Get buffer size"""
        return self._buffer_size
    
    def get_reentrant_buffer_size(self) -> int:
        """Get reentrant buffer size"""
        return self._reentrant_buffer_size
    
    def get_encoder_factory(self):
        """Get encoder factory"""
        return self._encoder_factory
    
    def __repr__(self) -> str:
        return f"WriterBuffer(encoding={self._encoding}, buffer_size={self._buffer_size})"
