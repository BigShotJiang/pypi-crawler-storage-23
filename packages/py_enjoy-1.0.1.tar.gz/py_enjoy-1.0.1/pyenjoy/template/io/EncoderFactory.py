#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal EncoderFactory - Encoder Factory
"""

class EncoderFactory:
    """Encoder factory for template output"""
    
    encoding = "UTF-8"
    
    def get_encoder(self):
        """Get encoder"""
        from .JdkEncoder import JdkEncoder
        return JdkEncoder()
    
    @classmethod
    def set_encoding(cls, encoding: str):
        """Set encoding"""
        cls.encoding = encoding
    
    @classmethod
    def get_encoding(cls) -> str:
        """Get encoding"""
        return cls.encoding
    
    def __repr__(self) -> str:
        return f"EncoderFactory(encoding={self.encoding})"
