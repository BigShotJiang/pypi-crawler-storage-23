#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal JdkEncoderFactory - JDK Encoder Factory
"""

from .EncoderFactory import EncoderFactory

class JdkEncoderFactory(EncoderFactory):
    """JDK encoder factory"""
    
    def __init__(self):
        """Initialize JDK encoder factory"""
        super().__init__()
    
    def get_encoder(self):
        """Get JDK encoder"""
        from .JdkEncoder import JdkEncoder
        return JdkEncoder()
    
    def __repr__(self) -> str:
        return "JdkEncoderFactory()"
