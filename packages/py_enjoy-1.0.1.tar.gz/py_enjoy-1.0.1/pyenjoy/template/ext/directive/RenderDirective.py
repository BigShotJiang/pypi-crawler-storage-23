#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal RenderDirective - Render Directive
"""

from ...Directive import Directive
from ...Env import Env
from ...stat.Scope import Scope

class RenderDirective(Directive):
    """Render directive for template rendering"""
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute render directive
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        # Simplified implementation
        if self.expr_list:
            # Get template name
            template_name = self.expr_list.eval(scope)
            
            if template_name:
                # Get engine from env
                from ...Engine import Engine
                engine = Engine.use()
                
                # Render template
                template = engine.get_template(str(template_name))
                template.render(scope.get_data(), writer)
    
    def __repr__(self) -> str:
        return "RenderDirective()"
