#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal StringDirective - String Directive
"""

from ...Directive import Directive
from ...Env import Env
from ...stat.Scope import Scope

class StringDirective(Directive):
    """String directive for string operations"""
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute string directive
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        if self.expr_list:
            # Get string value
            string_value = self.expr_list.eval(scope)
            
            if string_value is not None:
                # Output string
                if hasattr(writer, 'write'):
                    writer.write(str(string_value))
    
    def __repr__(self) -> str:
        return "StringDirective()"
