#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal NumberDirective - Number Directive
"""

from ...Directive import Directive
from ...Env import Env
from ...stat.Scope import Scope

class NumberDirective(Directive):
    """Number directive for number formatting"""
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute number directive
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        if self.expr_list:
            # Get number value
            number_value = self.expr_list.eval(scope)
            
            if number_value is not None:
                # Format number
                formatted = str(number_value)
                if hasattr(writer, 'write'):
                    writer.write(formatted)
    
    def __repr__(self) -> str:
        return "NumberDirective()"
