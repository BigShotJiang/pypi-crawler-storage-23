#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal EscapeDirective - Escape Directive
"""

from ...Directive import Directive
from ...Env import Env
from ...stat.Scope import Scope

class EscapeDirective(Directive):
    """Escape directive for HTML escaping"""
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute escape directive
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        if self.expr_list:
            # Get value to escape
            value = self.expr_list.eval(scope)
            
            if value:
                # Escape HTML special characters
                escaped = str(value).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#39;')
                if hasattr(writer, 'write'):
                    writer.write(escaped)
    
    def __repr__(self) -> str:
        return "EscapeDirective()"
