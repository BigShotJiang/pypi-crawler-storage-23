#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal CallDirective - Call Directive
"""

from ...Directive import Directive
from ...Env import Env
from ...stat.Scope import Scope

class CallDirective(Directive):
    """Call directive for calling template functions"""
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute call directive
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        if self.expr_list:
            # Get function name
            function_name = self.expr_list.eval(scope)
            
            if function_name:
                # Get function from env
                func = env.get_function(str(function_name))
                
                if func:
                    # Call function
                    func.exec(env, scope, writer)
    
    def __repr__(self) -> str:
        return "CallDirective()"
