#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal DateDirective - Date Directive
"""

from ...Directive import Directive
from ...Env import Env
from ...stat.Scope import Scope

class DateDirective(Directive):
    """Date directive for date formatting"""
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute date directive
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        if self.expr_list:
            # Get date value and pattern
            values = self.expr_list.eval_expr_list(scope)
            
            if values:
                date_value = values[0]
                pattern = values[1] if len(values) > 1 else "yyyy-MM-dd HH:mm"
                
                # Format date
                from ...kit.TimeKit import TimeKit
                if date_value:
                    formatted_date = TimeKit.format(date_value, pattern)
                    if hasattr(writer, 'write'):
                        writer.write(formatted_date)
    
    def __repr__(self) -> str:
        return "DateDirective()"
