#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Compressor - Template Compressor
"""

class Compressor:
    """Template compressor for minimizing output"""
    
    def __init__(self, separator: str = '\n'):
        """
        Initialize compressor
        
        Args:
            separator: Separator string
        """
        self._separator = separator
    
    def compress(self, content: str) -> str:
        """
        Compress template content
        
        Args:
            content: Content to compress
            
        Returns:
            Compressed content
        """
        # Simplified compression
        if not content:
            return content
        
        # Remove extra whitespace
        lines = content.split(self._separator)
        compressed_lines = []
        
        for line in lines:
            compressed_line = line.strip()
            if compressed_line:
                compressed_lines.append(compressed_line)
        
        return self._separator.join(compressed_lines)
    
    def __repr__(self) -> str:
        return f"Compressor(separator={repr(self._separator)})"
