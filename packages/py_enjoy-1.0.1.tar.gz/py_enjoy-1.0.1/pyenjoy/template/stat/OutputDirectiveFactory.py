#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal OutputDirectiveFactory - Output Directive Factory
"""

from typing import Optional
from .ast.Stat import Stat
from .Scope import Scope
from ..Env import Env

class OutputDirectiveFactory:
    """Factory for creating output directives"""
    
    def __init__(self):
        """Initialize factory"""
        pass
    
    def get_output_directive(self, expr_list, location) -> 'Output':
        """
        Get output directive
        
        Args:
            expr_list: Expression list
            location: Location information
            
        Returns:
            Output directive
        """
        from .ast.Output import Output
        return Output(expr_list)


# Create singleton instance
me = OutputDirectiveFactory()
