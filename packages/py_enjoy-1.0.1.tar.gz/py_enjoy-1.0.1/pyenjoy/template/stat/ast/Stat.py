#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Stat - Abstract Syntax Tree Base Class
"""

from typing import Any
from ..Scope import Scope
from ...Env import Env

class Stat:
    """Base class for statement AST nodes"""
    
    def exec(self, env: Env, scope: Scope, writer) -> Any:
        """
        Execute the statement
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
            
        Returns:
            Execution result
        """
        raise NotImplementedError("Stat.exec() must be implemented by subclasses")
    
    def get_stat_list(self) -> 'StatList':
        """Get as StatList if applicable"""
        return None
    
    def __repr__(self) -> str:
        return f"Stat({self.__class__.__name__})"


class StatList(Stat):
    """Statement list containing multiple statements"""
    
    def __init__(self):
        """Initialize statement list"""
        self._stats: list = []
    
    def add_stat(self, stat: Stat):
        """
        Add statement to list
        
        Args:
            stat: Statement to add
        """
        if stat:
            self._stats.append(stat)
    
    def exec(self, env: Env, scope: Scope, writer) -> Any:
        """
        Execute all statements in list
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
            
        Returns:
            Last statement result or None
        """
        result = None
        for stat in self._stats:
            result = stat.exec(env, scope, writer)
        return result
    
    def get_stats(self) -> list:
        """Get all statements"""
        return self._stats.copy()
    
    def __len__(self) -> int:
        """Get number of statements"""
        return len(self._stats)
    
    def __repr__(self) -> str:
        return f"StatList({len(self._stats)} statements)"
