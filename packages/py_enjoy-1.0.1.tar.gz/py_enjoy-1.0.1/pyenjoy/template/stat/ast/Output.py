#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Output - Output Directive
"""

from .Stat import Stat
from ..Scope import Scope
from ...Env import Env
from ...expr.ast import ExprList

class Output(Stat):
    """Output directive for template expressions"""
    
    def __init__(self, expr_list: ExprList):
        """
        Initialize output directive
        
        Args:
            expr_list: Expression list to evaluate
        """
        self._expr_list = expr_list
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute output directive
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        if self._expr_list:
            result = self._expr_list.eval(scope)
            if result is not None:
                if hasattr(writer, 'write'):
                    writer.write(str(result))
    
    def __repr__(self) -> str:
        return f"Output({self._expr_list})"
