#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Define - Template Function Definition
"""

from .Stat import Stat
from ..Scope import Scope
from ...Env import Env

class Define(Stat):
    """Template function definition"""
    
    def __init__(self, function_name: str):
        """
        Initialize define statement
        
        Args:
            function_name: Function name
        """
        self._function_name = function_name
    
    def exec(self, env: Env, scope: Scope, writer) -> None:
        """
        Execute define statement
        
        Args:
            env: Template environment
            scope: Execution scope
            writer: Output writer
        """
        # Register the function with the environment
        env.add_function(self._function_name, self)
    
    def get_function_name(self) -> str:
        """Get function name"""
        return self._function_name
    
    def set_env_for_dev_mode(self, env: Env):
        """Set environment for dev mode"""
        pass
    
    def is_source_modified_for_dev_mode(self) -> bool:
        """Check if source is modified (for dev mode)"""
        return False
    
    def __repr__(self) -> str:
        return f"Define({self._function_name})"
