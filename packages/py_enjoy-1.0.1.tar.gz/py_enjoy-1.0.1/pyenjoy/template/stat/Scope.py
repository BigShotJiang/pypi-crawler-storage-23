#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Scope - Template Execution Scope
"""

from typing import Dict, Any, Optional

class Scope:
    """Template execution scope"""
    
    def __init__(self, data: Dict = None, shared_objects: Dict = None):
        """
        Initialize scope
        
        Args:
            data: Data dictionary
            shared_objects: Shared objects dictionary
        """
        self._parent = None
        self._data = data or {}
        self._shared_objects = shared_objects or {}
        self._local_vars: Dict[str, Any] = {}
    
    def set_parent(self, parent: 'Scope'):
        """Set parent scope"""
        self._parent = parent
    
    def get(self, key: str) -> Any:
        """
        Get value by key, searching through scopes
        
        Args:
            key: Variable key
            
        Returns:
            Value or None
        """
        # Check local vars first
        if key in self._local_vars:
            return self._local_vars[key]
        
        # Check data
        if key in self._data:
            return self._data[key]
        
        # Check shared objects
        if key in self._shared_objects:
            return self._shared_objects[key]
        
        # Check parent scope
        if self._parent:
            return self._parent.get(key)
        
        return None
    
    def set(self, key: str, value: Any):
        """
        Set value in local scope
        
        Args:
            key: Variable key
            value: Value to set
        """
        self._local_vars[key] = value
    
    def set_local(self, key: str, value: Any):
        """Set local variable"""
        self._local_vars[key] = value
    
    def remove(self, key: str) -> Any:
        """
        Remove and return value
        
        Args:
            key: Variable key
            
        Returns:
            Removed value or None
        """
        # Try local vars
        if key in self._local_vars:
            return self._local_vars.pop(key)
        
        # Try data
        if key in self._data:
            return self._data.pop(key, None)
        
        return None
    
    def contains(self, key: str) -> bool:
        """Check if key exists in any scope"""
        return self.get(key) is not None
    
    def keys(self) -> set:
        """Get all keys in scope"""
        keys = set()
        keys.update(self._local_vars.keys())
        keys.update(self._data.keys())
        keys.update(self._shared_objects.keys())
        if self._parent:
            keys.update(self._parent.keys())
        return keys
    
    def get_local_vars(self) -> Dict[str, Any]:
        """Get local variables"""
        return self._local_vars.copy()
    
    def get_data(self) -> Dict[str, Any]:
        """Get data dictionary"""
        return self._data.copy()
    
    def get_shared_objects(self) -> Dict[str, Any]:
        """Get shared objects"""
        return self._shared_objects.copy()
    
    def clear_local_vars(self):
        """Clear local variables"""
        self._local_vars.clear()
    
    def new_scope(self) -> 'Scope':
        """
        Create a new scope with this scope as parent
        
        Returns:
            New scope instance
        """
        new_scope = Scope(self._data.copy(), self._shared_objects.copy())
        new_scope.set_parent(self)
        return new_scope
    
    def __repr__(self) -> str:
        return f"Scope(local_vars={len(self._local_vars)}, data={len(self._data)}, shared={len(self._shared_objects)})"
