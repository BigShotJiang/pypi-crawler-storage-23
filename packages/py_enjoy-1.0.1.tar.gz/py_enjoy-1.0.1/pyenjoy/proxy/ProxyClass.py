#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal ProxyClass - Proxy Class Information
"""

from typing import Dict, Any, Optional, Type

class ProxyClass:
    """Proxy class information holder"""
    
    def __init__(self, target: Type):
        """
        Initialize proxy class
        
        Args:
            target: Target class to be proxied
        """
        self._target = target
        self._pkg = target.__module__
        self._name = target.__name__ + "$$EnhancerByJFinal"
        self._source_code: Optional[str] = None
        self._byte_code: Optional[Dict[str, bytes]] = None
        self._clazz: Optional[Type] = None
    
    @property
    def target(self) -> Type:
        """Get target class"""
        return self._target
    
    @property
    def pkg(self) -> str:
        """Get package name"""
        return self._pkg
    
    @property
    def name(self) -> str:
        """Get proxy class name"""
        return self._name
    
    @property
    def source_code(self) -> Optional[str]:
        """Get source code"""
        return self._source_code
    
    @source_code.setter
    def source_code(self, value: str):
        """Set source code"""
        self._source_code = value
    
    @property
    def byte_code(self) -> Optional[Dict[str, bytes]]:
        """Get byte code"""
        return self._byte_code
    
    @byte_code.setter
    def byte_code(self, value: Dict[str, bytes]):
        """Set byte code"""
        self._byte_code = value
    
    @property
    def clazz(self) -> Optional[Type]:
        """Get loaded class"""
        return self._clazz
    
    @clazz.setter
    def clazz(self, value: Type):
        """Set loaded class"""
        self._clazz = value
    
    @property
    def full_name(self) -> str:
        """Get full class name with package"""
        return f"{self._pkg}.{self._name}"
    
    def __repr__(self) -> str:
        return f"ProxyClass(target={self._target.__name__}, name={self._name})"
