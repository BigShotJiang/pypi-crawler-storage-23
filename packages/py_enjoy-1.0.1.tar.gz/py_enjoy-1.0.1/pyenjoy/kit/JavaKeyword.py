#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal JavaKeyword - Java Keyword Detection
"""

from typing import Set, FrozenSet

class JavaKeyword:
    """Java keyword detection utility"""
    
    _KEYWORD_SET: FrozenSet[str] = frozenset({
        "abstract", "assert", "boolean", "break", "byte", "case", "catch",
        "char", "class", "const", "continue", "default", "do", "double",
        "else", "enum", "extends", "final", "finally", "float", "for",
        "goto", "if", "implements", "import", "instanceof", "int",
        "interface", "long", "native", "new", "package", "private",
        "protected", "public", "return", "strictfp", "short", "static",
        "super", "switch", "synchronized", "this", "throw", "throws",
        "transient", "try", "void", "volatile", "while"
    })
    
    _instance = None
    
    @staticmethod
    def get_instance():
        """Get shared instance"""
        if JavaKeyword._instance is None:
            JavaKeyword._instance = JavaKeyword()
        return JavaKeyword._instance
    
    def __init__(self):
        self._keywords = set(JavaKeyword._KEYWORD_SET)
        # Make it read-only by default
        self._read_only = True
    
    def add_keyword(self, keyword: str) -> 'JavaKeyword':
        """Add custom keyword"""
        if self._read_only:
            raise RuntimeError("Cannot modify read-only JavaKeyword instance")
        
        if keyword and keyword.strip():
            self._keywords.add(keyword)
        
        return self
    
    def remove_keyword(self, keyword: str) -> 'JavaKeyword':
        """Remove keyword"""
        if self._read_only:
            raise RuntimeError("Cannot modify read-only JavaKeyword instance")
        
        self._keywords.discard(keyword)
        return self
    
    def contains(self, word: str) -> bool:
        """Check if word is a Java keyword"""
        return word in self._keywords
    
    def is_keyword(self, word: str) -> bool:
        """Check if word is a Java keyword (alias of contains)"""
        return self.contains(word)
    
    @property
    def keywords(self) -> FrozenSet[str]:
        """Get all keywords"""
        return frozenset(self._keywords)
    
    @property
    def keyword_count(self) -> int:
        """Get keyword count"""
        return len(self._keywords)


# Create shared instance
me = JavaKeyword.get_instance()
