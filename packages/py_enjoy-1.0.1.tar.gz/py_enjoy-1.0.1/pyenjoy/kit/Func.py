#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Func - Lambda Function Utilities
"""

from typing import Callable, TypeVar, Generic

T = TypeVar('T')
U = TypeVar('U')
V = TypeVar('V')
W = TypeVar('W')
X = TypeVar('X')
Y = TypeVar('Y')
Z = TypeVar('Z')
R = TypeVar('R')

class F00:
    """0 parameter 0 return function"""
    @staticmethod
    def call(func: Callable[[], None]):
        """Execute function with no parameters and no return"""
        func()

class F10(Generic[T]):
    """1 parameter 0 return function"""
    @staticmethod
    def call(func: Callable[[T], None], t: T):
        """Execute function with one parameter and no return"""
        func(t)

class F20(Generic[T, U]):
    """2 parameter 0 return function"""
    @staticmethod
    def call(func: Callable[[T, U], None], t: T, u: U):
        """Execute function with two parameters and no return"""
        func(t, u)

class F30(Generic[T, U, V]):
    """3 parameter 0 return function"""
    @staticmethod
    def call(func: Callable[[T, U, V], None], t: T, u: U, v: V):
        """Execute function with three parameters and no return"""
        func(t, u, v)

class F40(Generic[T, U, V, W]):
    """4 parameter 0 return function"""
    @staticmethod
    def call(func: Callable[[T, U, V, W], None], t: T, u: U, v: V, w: W):
        """Execute function with four parameters and no return"""
        func(t, u, v, w)

class F01(Generic[R]):
    """0 parameter 1 return function"""
    @staticmethod
    def call(func: Callable[[], R]) -> R:
        """Execute function with no parameters and return value"""
        return func()

class F11(Generic[T, R]):
    """1 parameter 1 return function"""
    @staticmethod
    def call(func: Callable[[T], R], t: T) -> R:
        """Execute function with one parameter and return value"""
        return func(t)

class F21(Generic[T, U, R]):
    """2 parameter 1 return function"""
    @staticmethod
    def call(func: Callable[[T, U], R], t: T, u: U) -> R:
        """Execute function with two parameters and return value"""
        return func(t, u)

class F31(Generic[T, U, V, R]):
    """3 parameter 1 return function"""
    @staticmethod
    def call(func: Callable[[T, U, V], R], t: T, u: U, v: V) -> R:
        """Execute function with three parameters and return value"""
        return func(t, u, v)

class F41(Generic[T, U, V, W, R]):
    """4 parameter 1 return function"""
    @staticmethod
    def call(func: Callable[[T, U, V, W], R], t: T, u: U, v: V, w: W) -> R:
        """Execute function with four parameters and return value"""
        return func(t, u, v, w)
