#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal Okv (Ordered Key Value) - Ordered Dictionary Implementation
"""

from .Kv import Kv
from .StrKit import StrKit
from .TypeKit import TypeKit

class Okv(dict):
    """Ordered Key Value dictionary with utility methods"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # In Python 3.7+, dict maintains insertion order
    
    @staticmethod
    def of(key, value):
        """Create Okv with initial key-value pair"""
        return Okv().set(key, value)
    
    @staticmethod
    def by(key, value):
        """Create Okv with initial key-value pair (alias of of)"""
        return Okv.of(key, value)
    
    @staticmethod
    def create():
        """Create empty Okv"""
        return Okv()
    
    def set(self, key, value):
        """Set key-value pair and return self for chaining"""
        super().__setitem__(key, value)
        return self
    
    def set_if_not_blank(self, key, value):
        """Set value only if not blank"""
        if StrKit.not_blank(value):
            self.set(key, value)
        return self
    
    def set_if_not_null(self, key, value):
        """Set value only if not None"""
        if value is not None:
            self.set(key, value)
        return self
    
    def delete(self, key):
        """Delete key and return self"""
        super().pop(key, None)
        return self
    
    def get_as(self, key, default_value=None):
        """Get value as specific type"""
        return self.get(key, default_value)
    
    def get_str(self, key, default_value=None):
        """Get value as string"""
        value = self.get(key)
        return str(value) if value is not None else default_value
    
    def get_int(self, key, default_value=None):
        """Get value as integer"""
        return TypeKit.to_int(self.get(key, default_value))
    
    def get_long(self, key, default_value=None):
        """Get value as long integer"""
        return TypeKit.to_long(self.get(key, default_value))
    
    def get_big_decimal(self, key, default_value=None):
        """Get value as BigDecimal"""
        return TypeKit.to_big_decimal(self.get(key, default_value))
    
    def get_double(self, key, default_value=None):
        """Get value as double"""
        return TypeKit.to_double(self.get(key, default_value))
    
    def get_float(self, key, default_value=None):
        """Get value as float"""
        return TypeKit.to_float(self.get(key, default_value))
    
    def get_number(self, key, default_value=None):
        """Get value as Number"""
        return TypeKit.to_number(self.get(key, default_value))
    
    def get_boolean(self, key, default_value=None):
        """Get value as boolean"""
        return TypeKit.to_boolean(self.get(key, default_value))
    
    def get_date(self, key, default_value=None):
        """Get value as Date"""
        return TypeKit.to_date(self.get(key, default_value))
    
    def get_local_datetime(self, key, default_value=None):
        """Get value as LocalDateTime"""
        return TypeKit.to_local_date_time(self.get(key, default_value))
    
    def not_null(self, key):
        """Check if key exists and value is not None"""
        return self.get(key) is not None
    
    def is_null(self, key):
        """Check if key doesn't exist or value is None"""
        return self.get(key) is None
    
    def not_blank(self, key):
        """Check if value is not blank string"""
        return StrKit.not_blank(self.get_str(key))
    
    def is_blank(self, key):
        """Check if value is blank string"""
        return StrKit.is_blank(self.get_str(key))
    
    def is_true(self, key):
        """Check if value is True"""
        value = self.get(key)
        return value is not None and TypeKit.to_boolean(value)
    
    def is_false(self, key):
        """Check if value is False"""
        value = self.get(key)
        return value is not None and not TypeKit.to_boolean(value)
    
    def keep(self, *keys):
        """Keep only specified keys"""
        if keys and len(keys) > 0:
            new_okv = Okv()
            for key in keys:
                if self.contains_key(key):
                    new_okv.set(key, self.get(key))
            
            self.clear()
            self.update(new_okv)
        else:
            self.clear()
        
        return self
    
    def to_map(self):
        """Convert to regular map"""
        return self
