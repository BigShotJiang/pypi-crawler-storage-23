#!/usr/bin/env python3.9
# -*- coding: utf-8 -*-
"""
JFinal PropKit - Properties File Management
"""

import os
from typing import Optional, Dict
from .Prop import Prop
from .StrKit import StrKit

class PropKit:
    """Properties file management utility"""
    
    _env_key = "app.env"
    _prop: Optional[Prop] = None
    _cache: Dict[str, Prop] = {}
    
    def __init__(self):
        raise NotImplementedError("PropKit is a utility class and cannot be instantiated")
    
    @staticmethod
    def set_env_key(env_key: str):
        """Set environment key for config"""
        PropKit._env_key = env_key
    
    @staticmethod
    def get_env_key() -> str:
        """Get environment key"""
        return PropKit._env_key
    
    @staticmethod
    def get_env() -> str:
        """Get current environment value"""
        return PropKit.get_prop().get(PropKit._env_key)
    
    @staticmethod
    def use(file_name: str, encoding: str = Prop.DEFAULT_ENCODING) -> Prop:
        """Use properties file"""
        if file_name not in PropKit._cache:
            PropKit._cache[file_name] = Prop(file_name, encoding)
            PropKit._handle_env(PropKit._cache[file_name], file_name)
            
            if PropKit._prop is None:
                PropKit._prop = PropKit._cache[file_name]
        
        return PropKit._cache[file_name]
    
    @staticmethod
    def _handle_env(result: Prop, file_name: str):
        """Handle environment-specific configuration"""
        env = result.get(PropKit._env_key)
        if StrKit.not_blank(env):
            dot_index = file_name.rfind('.')
            if dot_index != -1:
                env_config_name = file_name[:dot_index] + "-" + env + file_name[dot_index:]
            else:
                env_config_name = file_name + "-" + env
            
            try:
                env_config = Prop(env_config_name)
                result.append(env_config)
            except:
                pass  # Ignore if env config doesn't exist
    
    @staticmethod
    def useless(file_name: str) -> Optional[Prop]:
        """Remove properties file from cache"""
        removed = PropKit._cache.pop(file_name, None)
        if PropKit._prop is removed:
            PropKit._prop = None
        return removed
    
    @staticmethod
    def clear():
        """Clear all cached properties"""
        PropKit._prop = None
        PropKit._cache.clear()
    
    @staticmethod
    def append(prop: Prop) -> Prop:
        """Append properties"""
        with PropKit:
            if PropKit._prop is not None:
                PropKit._prop.append(prop)
            else:
                PropKit._prop = prop
            return PropKit._prop
    
    @staticmethod
    def append_content(content: str, encoding: str = Prop.DEFAULT_ENCODING) -> Prop:
        """Append properties from content string"""
        return PropKit.append(Prop(content, encoding, is_file=False))
    
    @staticmethod
    def get_prop() -> Prop:
        """Get current properties"""
        if PropKit._prop is None:
            raise IllegalStateException("Load properties file by invoking PropKit.use(String fileName) method first.")
        return PropKit._prop
    
    @staticmethod
    def get(key: str, default_value: str = None) -> Optional[str]:
        """Get property value"""
        return PropKit.get_prop().get(key, default_value)
    
    @staticmethod
    def get_int(key: str, default_value: int = None) -> Optional[int]:
        """Get property as integer"""
        return PropKit.get_prop().get_int(key, default_value)
    
    @staticmethod
    def get_long(key: str, default_value: int = None) -> Optional[int]:
        """Get property as long"""
        return PropKit.get_prop().get_long(key, default_value)
    
    @staticmethod
    def get_double(key: str, default_value: float = None) -> Optional[float]:
        """Get property as double"""
        return PropKit.get_prop().get_double(key, default_value)
    
    @staticmethod
    def get_boolean(key: str, default_value: bool = None) -> Optional[bool]:
        """Get property as boolean"""
        return PropKit.get_prop().get_boolean(key, default_value)
    
    @staticmethod
    def contains_key(key: str) -> bool:
        """Check if key exists"""
        return PropKit.get_prop().contains_key(key)


class IllegalStateException(Exception):
    """Illegal state exception"""
    pass
