"""Fitting module unit tests."""
