"""Utility function unit tests for XPCS Toolkit."""
