"""Unit tests for simplemask module."""
