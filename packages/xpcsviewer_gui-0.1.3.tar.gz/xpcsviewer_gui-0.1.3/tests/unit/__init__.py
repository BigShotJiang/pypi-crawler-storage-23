"""Unit tests package for XPCS Toolkit.

This package contains comprehensive unit tests for all core modules
of the XPCS Toolkit, organized by functional area.
"""
