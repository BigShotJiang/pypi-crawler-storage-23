"""Scientific analysis module unit tests for XPCS Toolkit."""
