"""Numerical equivalence tests (NumPy vs JAX, CPU vs GPU)."""
