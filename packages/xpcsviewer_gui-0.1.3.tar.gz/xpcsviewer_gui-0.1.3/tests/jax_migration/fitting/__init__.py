"""Tests for Bayesian fitting module."""
