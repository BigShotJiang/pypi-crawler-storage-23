"""Automatic differentiation tests for JAX migration (US4)."""
