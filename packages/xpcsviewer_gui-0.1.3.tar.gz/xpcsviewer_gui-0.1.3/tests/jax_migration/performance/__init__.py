"""Performance tests for JIT compilation (US3)."""
