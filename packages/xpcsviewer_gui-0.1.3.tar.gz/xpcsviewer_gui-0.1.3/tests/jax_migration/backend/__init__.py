"""Backend detection and device transfer tests."""
