"""Integration tests (Qt-JAX interop, HDF5-JAX I/O, memory limits)."""
