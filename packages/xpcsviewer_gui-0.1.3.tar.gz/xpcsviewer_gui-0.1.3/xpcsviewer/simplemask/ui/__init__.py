"""UI components for SimpleMask window."""

from xpcsviewer.simplemask.ui.simplemask_ui import setup_ui

__all__ = ["setup_ui"]
