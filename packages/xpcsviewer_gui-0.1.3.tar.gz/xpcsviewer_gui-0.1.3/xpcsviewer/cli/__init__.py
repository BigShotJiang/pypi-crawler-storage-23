"""CLI modules for XPCS Viewer."""

# Import main function from parent module for console script compatibility
from ..cli_main import main

__all__ = ["main"]
