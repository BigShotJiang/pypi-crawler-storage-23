Architecture
============

Technical architecture documentation, dependency analysis, and design records
for the XPCS Viewer codebase.

Architecture Decision Records
-----------------------------

.. toctree::
   :maxdepth: 1

   ADR-001-jax-migration
   ADR-002-nlsq-migration
   ADR-003-hdf5-facade
   ADR-004-backend-abstraction

System Diagrams
---------------

.. toctree::
   :maxdepth: 2

   system_overview
   data_flow

Analysis and Catalogs
---------------------

.. toctree::
   :maxdepth: 2

   dependency_analysis
   dependency_diagram
   integration_catalog
   FACADE_INFRASTRUCTURE
