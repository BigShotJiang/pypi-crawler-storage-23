The Mask Editor (SimpleMask) provides tools for creating, editing, and managing detector masks
for XPCS analysis. It also supports Q-map generation and Q-binning (partition) for correlation analysis.

Key capabilities:

* Create masks using drawing tools (Rectangle, Circle, Polygon, Line, Ellipse)
* Remove masked regions with the Eraser tool
* Save and load masks in HDF5 format
* Generate Q-maps from detector geometry
* Define Q-bins (partition) for XPCS correlation analysis
* Export masks and partitions back to XPCS Viewer
