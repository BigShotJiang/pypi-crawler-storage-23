.. code-block:: bash

   # Install from PyPI
   pip install xpcsviewer-gui

   # Or install with uv (recommended)
   uv pip install xpcsviewer-gui

   # Launch the GUI
   xpcsviewer-gui /path/to/hdf/data

   # CLI batch processing
   xpcsviewer twotime --input /data --output /results --q 0.05
