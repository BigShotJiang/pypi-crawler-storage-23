.. list-table::
   :widths: 15 10 40
   :header-rows: 1

   * - Tool
     - Shortcut
     - Description
   * - Rectangle
     - ``R``
     - Draw rectangular mask regions
   * - Circle
     - ``C``
     - Draw circular mask regions
   * - Polygon
     - ``P``
     - Draw polygonal mask regions (click to add vertices)
   * - Line
     - ``L``
     - Draw line mask regions with adjustable width
   * - Ellipse
     - ``E``
     - Draw elliptical mask regions
   * - Eraser
     - ``X``
     - Remove (include) previously masked regions
