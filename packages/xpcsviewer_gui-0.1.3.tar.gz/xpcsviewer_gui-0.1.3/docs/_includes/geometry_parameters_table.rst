.. list-table::
   :widths: 20 15 40
   :header-rows: 1

   * - Parameter
     - Unit
     - Description
   * - Beam X
     - pixels
     - Beam center X coordinate (column)
   * - Beam Y
     - pixels
     - Beam center Y coordinate (row)
   * - Distance
     - mm
     - Sample-to-detector distance
   * - Pixel Size
     - mm
     - Pixel dimension
   * - Energy
     - keV
     - X-ray energy
