Tutorials
=========

Step-by-step lessons that take you through a series of steps to complete a project.
Tutorials are **learning-oriented**: they help you get started and build understanding.

.. toctree::
   :maxdepth: 2

   quickstart
   getting_started
   mask_editor
   fitting_guide
   backend_selection
   cookbook

.. tip::

   New to xpcsviewer? Start with :doc:`quickstart` for a 5-minute overview, then
   work through :doc:`getting_started` for a guided walkthrough of loading data,
   inspecting metadata, and plotting your first G2 curve.
