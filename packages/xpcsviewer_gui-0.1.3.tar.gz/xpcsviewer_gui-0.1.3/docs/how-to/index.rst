How-To Guides
=============

Practical step-by-step guides for accomplishing specific tasks.
How-to guides are **task-oriented**: they help you solve a real-world problem.

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   /usage
   mask_editor_guide
   examples
   /contributing

.. note::

   More how-to guides are planned, including:

   - Batch processing with the CLI
   - Creating custom masks for different detector geometries
   - Exporting publication-quality figures
   - Configuring JAX backend acceleration
