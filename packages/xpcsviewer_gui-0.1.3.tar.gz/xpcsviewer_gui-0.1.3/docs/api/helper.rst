Helper Utilities
================

Internal helper modules for data models, logging, and common operations.

.. currentmodule:: xpcsviewer.helper

List Data Model
---------------

Qt-compatible list and table data models for the GUI file lists.

.. automodule:: xpcsviewer.helper.listmodel
   :members:
   :no-index:

Logger Writer
-------------

Stream-like wrapper that redirects ``stdout``/``stderr`` writes to the
Python logging system.

.. automodule:: xpcsviewer.helper.logwriter
   :members:
   :no-index:

Utility Functions
-----------------

Shared utility functions for data normalization and array slicing.

.. automodule:: xpcsviewer.helper.utils
   :members:
   :no-index:
