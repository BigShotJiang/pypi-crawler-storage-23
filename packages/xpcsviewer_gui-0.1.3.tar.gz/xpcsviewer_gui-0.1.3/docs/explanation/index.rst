Explanation
===========

Background and context that helps you understand concepts and design decisions.
Explanations are **understanding-oriented**: they clarify and illuminate a topic.

.. toctree::
   :maxdepth: 2

   xpcs_data_formats
   g2_theory
   twotime_analysis
   backend_architecture
   mask_qmap_internals
   /developer/optimization
