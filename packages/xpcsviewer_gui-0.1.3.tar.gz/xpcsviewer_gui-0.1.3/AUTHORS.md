# Credits

## Development Lead

- Miaoqi Chu <mqichu@anl.gov>

## Contributors

- Wei Chen <wchen@anl.gov>

## Original Project

Forked from pyXpcsViewer (Advanced Photon Source, Argonne National Laboratory).

## Citation

Chu et al., "pyXPCSviewer: an open-source interactive tool for X-ray photon correlation spectroscopy visualization and analysis", Journal of Synchrotron Radiation, (2022) 29, 1122–1129.
