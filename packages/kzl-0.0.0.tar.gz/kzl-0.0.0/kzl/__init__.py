print('hello word')

# t u n


