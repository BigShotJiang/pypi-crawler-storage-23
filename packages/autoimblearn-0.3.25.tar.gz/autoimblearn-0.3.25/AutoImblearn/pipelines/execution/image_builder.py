import logging
import os
from typing import Optional

import docker

from AutoImblearn.components.model_client.image_spec import ImageSpec

logger = logging.getLogger("autoimblearn.preflight")


def _is_truthy(value: Optional[str]) -> bool:
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def build_image(spec: ImageSpec) -> None:
    client = docker.from_env()
    tag = spec.image if not spec.tag else f"{spec.image}:{spec.tag}"
    context = str(spec.context) if spec.context else "."
    dockerfile = str(spec.dockerfile) if spec.dockerfile else None
    no_cache = _is_truthy(os.getenv("AUTOIMBLEARN_DOCKER_NOCACHE"))
    logger.info("[preflight] building image '%s' from %s (nocache=%s)", tag, context, no_cache)
    client.images.build(path=context, tag=tag, dockerfile=dockerfile, nocache=no_cache)
    logger.info("[preflight] built image '%s'", tag)
