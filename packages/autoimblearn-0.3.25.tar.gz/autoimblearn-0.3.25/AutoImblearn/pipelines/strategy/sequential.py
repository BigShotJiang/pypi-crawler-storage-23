import os
import pickle
import numpy as np
import logging
import json
import hashlib

from .base import BasePipelineStrategy
from ..customrsp import CustomResamplar
from ..customclf import CustomClassifier
from ..customhbd import CustomHybrid
from ..customautoml import CustomAutoML
from ..customunsupervised import CustomUnsupervisedModel
from ..logging import runtime_tracker as rt
from ..logging.failure_logger import (
    safe_cleanup,
    log_cache_recompute,
    log_cache_load_failure,
)


class ThreeElementPipelineStrategy(BasePipelineStrategy):
    """
    Strategy for 3-element pipelines: Imputer -> Resampler -> Classifier

    Example: ['median', 'smote', 'lr']
    """

    def validate_pipeline(self, pipe):
        """Ensure pipeline has exactly 3 elements"""
        if len(pipe) != 3:
            raise ValueError(
                f"Pipeline {pipe} length is not correct, not a regular method pipeline"
            )

    def execute_fold(self, pipe, X_train, y_train, X_test, y_test):
        """
        Execute one fold of a 3-element pipeline.

        Steps:
        1. Imputation (with caching)
        2. Resampling (on training data only)
        3. Classification
        4. Prediction
        """
        imp, rsp, clf = pipe
        interim_dir = self._dataset_interim_dir()
        stage_times = rt.new_stage_times()

        # Imputation level - FIT on train, TRANSFORM both train and test
        with rt.measure(stage_times, "imputation"):
            X_train_imputed, X_test_imputed = self._impute_with_caching(
                imp, X_train, y_train, X_test, y_test
            )

        # Resampling level - ONLY on training data, with caching on imputed inputs and params
        resample_file_path = os.path.join(interim_dir, f"rsp_{rsp}_fold{self.args.repeat}.p")
        resample_y_path = resample_file_path.replace(".p", "_y.p")
        resample_meta_path = resample_file_path + ".meta"
        resamplar = None

        def _hash_array(arr):
            arr = np.asarray(arr)
            return hashlib.sha256(arr.tobytes()).hexdigest()

        # Build cache signature on imputed data and resampler params
        resampler_params = {}
        if hasattr(self.args, "hyperparams") and self.args.hyperparams:
            resampler_params = self.args.hyperparams.get(rsp, {}) or {}
        resampler_signature = {
            "resampler": rsp,
            "params_hash": hashlib.sha256(json.dumps(resampler_params, sort_keys=True).encode("utf-8")).hexdigest(),
            "X_train_hash": _hash_array(X_train_imputed),
            "y_train_hash": _hash_array(y_train),
            "X_train_shape": list(np.asarray(X_train_imputed).shape),
            "y_train_shape": list(np.asarray(y_train).shape),
        }

        cache_valid = False
        if (
            os.path.exists(resample_file_path)
            and os.path.exists(resample_y_path)
            and os.path.exists(resample_meta_path)
        ):
            try:
                with open(resample_meta_path, "r") as mf:
                    meta = json.load(mf)
                if meta == resampler_signature:
                    logging.info("\t Loading cached resampling result")
                    with open(resample_file_path, "rb") as f:
                        X_train_imputed_cached = pickle.load(f)
                    with open(resample_y_path, "rb") as f:
                        y_train_cached = pickle.load(f)
                    X_train_imputed, y_train = X_train_imputed_cached, y_train_cached
                    cache_valid = True
                else:
                    log_cache_recompute("\t Resampler cache mismatch; recomputing.")
            except Exception as cache_err:
                log_cache_load_failure("\t Failed to load cached resampling (%s); recomputing.", cache_err)

        if not cache_valid:
            resamplar = CustomResamplar(
                method=rsp,
                host_data_root=self.args.host_data_root,
                dataset_name=self.args.dataset,
                result_file_path=resample_file_path,
                result_file_name=os.path.basename(resample_file_path),
                **(resampler_params or {}),
            )
            try:
                if resamplar.need_resample(y_train):
                    logging.info("\t Re-Sampling Started")
                    with rt.measure(stage_times, "resampling"):
                        X_train_imputed, y_train = resamplar.fit_resample(self.args, X_train_imputed, y_train)
                    logging.info("\t Re-Sampling Done")

                    # Persist cache artifacts
                    with open(resample_file_path, "wb") as f:
                        pickle.dump(X_train_imputed, f)
                    with open(resample_y_path, "wb") as f:
                        pickle.dump(y_train, f)
                    with open(resample_meta_path, "w") as mf:
                        json.dump(resampler_signature, mf, indent=2)
            finally:
                safe_cleanup(resamplar, "Resampler cleanup failed")

        # Classification level
        logging.info(f"\t Training in fold {self.args.repeat} Start")
        clf_result_path = os.path.join(interim_dir, f"clf_{clf}_fold{self.args.repeat}.p")
        trainer = CustomClassifier(
            method=clf,
            host_data_root=self.args.host_data_root,
            metric=self.args.metric,
            dataset_name=self.args.dataset,
            result_file_path=clf_result_path,
        )
        model_impl = getattr(trainer, "classifier_model", None)
        if model_impl is not None:
            setattr(model_impl, "keep_container_alive", True)
        try:
            with rt.measure(stage_times, "classification"):
                trainer.fit(self.args, X_train_imputed, y_train)
            logging.info(f"\t Training in fold {self.args.repeat} Done")

            # Validation on imputed test data
            with rt.measure(stage_times, "evaluation"):
                result = trainer.score(X_test_imputed, y_test)
        finally:
            safe_cleanup(trainer, "Classifier cleanup failed")

        del trainer

        return result, stage_times


class HybridPipelineStrategy(BasePipelineStrategy):
    """
    Strategy for 2-element pipelines: Imputer -> Hybrid Method

    Hybrid methods combine resampling and classification in one step.
    Example: ['median', 'autosmote']
    """

    def validate_pipeline(self, pipe):
        """Ensure pipeline has exactly 2 elements"""
        if len(pipe) != 2:
            raise ValueError(
                f"Pipeline {pipe} length is not correct, not a hybrid method pipeline"
            )

    def execute_fold(self, pipe, X_train, y_train, X_test, y_test):
        """
        Execute one fold of a 2-element hybrid pipeline.

        Steps:
        1. Imputation (with caching)
        2. Hybrid method (combines resampling + classification)
        3. Prediction
        """
        imp, hbd = pipe
        interim_dir = self._dataset_interim_dir()
        stage_times = rt.new_stage_times()

        # Imputation level - FIT on train, TRANSFORM both train and test
        with rt.measure(stage_times, "imputation"):
            X_train_imputed, X_test_imputed = self._impute_with_caching(
                imp, X_train, y_train, X_test, y_test
            )

        # Hybrid method (combines resampling + classification)
        logging.info(f"\t Training in fold {self.args.repeat} Start")
        hybrid_result_path = os.path.join(interim_dir, f"hybrid_{hbd}_fold{self.args.repeat}.p")

        trainer = CustomHybrid(
            method=hbd,
            host_data_root=self.args.host_data_root,
            dataset_name=self.args.dataset,
            metric=self.args.metric,
            result_file_path=hybrid_result_path,
            imputer_method=imp,
        )

        model_impl = getattr(trainer, "hybrid_component", None)
        if model_impl is not None:
            setattr(model_impl, "keep_container_alive", True)
        try:
            with rt.measure(stage_times, "classification"):
                trainer.fit(
                    self.args,
                    X_train_imputed,
                    y_train,
                    X_test_imputed,
                    y_test,
                )
            logging.info(f"\t Training in fold {self.args.repeat} Done")

            with rt.measure(stage_times, "evaluation"):
                trainer.predict(X_test=X_test_imputed)
                result = trainer.result
        finally:
            trainer.cleanup()

        return result, stage_times


class AutoMLPipelineStrategy(BasePipelineStrategy):
    """
    Strategy for 1-element pipelines: AutoML only

    AutoML methods handle imputation, resampling, and classification internally.
    Example: ['autosklearn']

    Note: This strategy doesn't use K-fold cross-validation because
    AutoML methods typically handle cross-validation internally.
    """

    is_fold_based = False

    def validate_pipeline(self, pipe):
        """Ensure pipeline has exactly 1 element"""
        if len(pipe) != 1:
            raise ValueError(
                f"Pipeline {pipe} length is not correct, not a AutoML method pipeline"
            )

    def execute(self, pipe, train_ratio=1.0):
        return self.execute_non_fold(pipe, train_ratio)

    def execute_non_fold(self, pipe, train_ratio=1.0):
        result, stage_times = self.run_non_fold(pipe, train_ratio)
        self.args.repeat += 1
        total_train_time = rt.sum_stage_times(stage_times)
        self.saver.append(pipe, result, train_time_seconds=total_train_time)
        return result, stage_times

    def run_non_fold(self, pipe, train_ratio=1.0):
        """
        Execute AutoML pipeline (overrides base execute method).

        AutoML methods don't use K-fold cross-validation - they handle
        validation internally.
        """
        self.validate_pipeline(pipe)

        automl = pipe[0]

        # Load and preprocess data
        X, y = self.preprocessor.preprocess(self.args)

        # Fit
        stage_times = rt.new_stage_times()

        logging.info(f"\t Training of {pipe} Start")
        trainer = CustomAutoML(self.args, automl)
        with rt.measure(stage_times, "classification"):
            trainer.train(X, y)
        logging.info(f"\t Training of {pipe} Ended")

        # Predict
        logging.info(f"\t Predicting of {pipe} Start")
        with rt.measure(stage_times, "evaluation"):
            result = trainer.predict()
        logging.info(f"\t Predicting of {pipe} Ended")
        return result, stage_times

    def execute_fold(self, pipe, X_train, y_train, X_test, y_test):
        """Not used for AutoML pipelines"""
        raise NotImplementedError("AutoML pipelines don't use fold-based execution")


class UnsupervisedPipelineStrategy(BasePipelineStrategy):
    """
    Strategy for 2-element unsupervised pipelines: Imputer -> Unsupervised Model

    Supports clustering, dimensionality reduction, and anomaly detection.
    Example: ['median', 'kmeans'], ['knn', 'pca'], ['mean', 'isoforest']
    """

    def validate_pipeline(self, pipe):
        """Ensure pipeline has exactly 2 elements"""
        if len(pipe) != 2:
            raise ValueError(
                f"Pipeline {pipe} length is not correct, not an unsupervised pipeline"
            )

    def execute_fold(self, pipe, X_train, y_train, X_test, y_test):
        """
        Execute one fold of a 2-element unsupervised pipeline.

        Steps:
        1. Imputation (with caching)
        2. Unsupervised model training and prediction

        Note: y_train and y_test may be used for evaluation but not for training
        """
        imp, model = pipe
        stage_times = rt.new_stage_times()

        # Imputation level - FIT on train, TRANSFORM both train and test
        with rt.measure(stage_times, "imputation"):
            X_train_imputed, X_test_imputed = self._impute_with_caching(
                imp, X_train, y_train, X_test, y_test
            )

        # Unsupervised model training
        logging.info(f"\t Training unsupervised model in fold {self.args.repeat} Start")
        trainer = CustomUnsupervisedModel(
            method=model,
            host_data_root=self.args.host_data_root,
            metric=self.args.metric,
        )
        model_impl = getattr(trainer, "unsupervised_model", None)
        if model_impl is not None:
            setattr(model_impl, "keep_container_alive", True)
        try:
            with rt.measure(stage_times, "classification"):
                trainer.fit(self.args, X_train_imputed, y_train)
            logging.info(f"\t Training unsupervised model in fold {self.args.repeat} Done")

            # Prediction and evaluation on test data
            with rt.measure(stage_times, "evaluation"):
                result = trainer.score(X_test_imputed, y_test)
        finally:
            safe_cleanup(trainer, "Unsupervised model cleanup failed")

        del trainer

        return result, stage_times
