def execute_parallel_or_fallback(strategy, pipe, train_ratio=1.0):
    # Parallel execution is not implemented in the current runtime; preserve sequential behavior.
    return strategy.execute(pipe, train_ratio)

