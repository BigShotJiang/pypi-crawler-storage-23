import os
import pickle
import numpy as np
import logging
import json
import hashlib

from ...processing.utils import SurvivalSamplar
from .base import BasePipelineStrategy
from ..customsurvival import (
    CustomSurvivalModel,
    CustomSurvivalResamplar,
    CustomSurvivalUnsupervisedModel,
)
from ..logging import runtime_tracker as rt
from ..logging.failure_logger import (
    safe_cleanup,
    log_cache_recompute,
    log_cache_load_failure,
)


class SurvivalPipelineStrategy(BasePipelineStrategy):
    """
    Strategy for 3-element survival pipelines: Imputer -> Survival Resampler -> Survival Model

    Example: ['median', 'rus', 'CPH']

    Handles survival data with structured arrays containing event indicators and times.
    """

    def build_fold_sampler(self, X, y):
        return SurvivalSamplar(X, y)

    def validate_pipeline(self, pipe):
        """Ensure pipeline has exactly 3 elements"""
        if len(pipe) != 3:
            raise ValueError(
                f"Pipeline {pipe} length is not correct, not a survival method pipeline"
            )

    def execute(self, pipe, train_ratio=1.0):
        return super().execute(pipe, train_ratio)

    def execute_fold(self, pipe, X_train, y_train, X_test, y_test):
        """
        Execute one fold of a 3-element survival pipeline.

        Steps:
        1. Imputation (with caching) - same as regular pipelines
        2. Survival-aware resampling (on training data only, preserves censoring)
        3. Survival model training and prediction

        Args:
            pipe: [imputer, survival_resampler, survival_model]
            X_train, y_train: Training data (y_train is structured survival array)
            X_test, y_test: Test data (y_test is structured survival array)
        """
        imp, rsp, model = pipe
        interim_dir = self._dataset_interim_dir()
        stage_times = rt.new_stage_times()

        # Imputation level - FIT on train, TRANSFORM both train and test
        # Note: Imputation only works on features (X), not on survival outcomes (y)
        with rt.measure(stage_times, "imputation"):
            X_train_imputed, X_test_imputed = self._impute_with_caching(
                imp, X_train, y_train, X_test, y_test
            )

        # Store original y_train for Uno's C-index calculation
        y_train_original = y_train.copy()

        resample_file_path = os.path.join(interim_dir, f"rsp_{rsp}_fold{self.args.repeat}.p")
        resample_y_path = resample_file_path.replace(".p", "_y.p")
        resample_meta_path = resample_file_path + ".meta"

        def _hash_array(arr):
            arr = np.asarray(arr)
            return hashlib.sha256(arr.tobytes()).hexdigest()

        resampler_params = {}
        if hasattr(self.args, "hyperparams") and self.args.hyperparams:
            resampler_params = self.args.hyperparams.get(rsp, {}) or {}
        resampler_signature = {
            "resampler": rsp,
            "params_hash": hashlib.sha256(json.dumps(resampler_params, sort_keys=True).encode("utf-8")).hexdigest(),
            "X_train_hash": _hash_array(X_train_imputed),
            "y_train_hash": _hash_array(y_train),
            "X_train_shape": list(np.asarray(X_train_imputed).shape),
            "y_train_shape": list(np.asarray(y_train).shape),
        }

        cache_valid = False
        if (
            os.path.exists(resample_file_path)
            and os.path.exists(resample_y_path)
            and os.path.exists(resample_meta_path)
        ):
            try:
                with open(resample_meta_path, "r") as mf:
                    meta = json.load(mf)
                if meta == resampler_signature:
                    logging.info("\t Loading cached survival resampling result")
                    with open(resample_file_path, "rb") as f:
                        X_train_imputed_cached = pickle.load(f)
                    with open(resample_y_path, "rb") as f:
                        y_train_cached = pickle.load(f)
                    X_train_imputed, y_train = X_train_imputed_cached, y_train_cached
                    cache_valid = True
                else:
                    log_cache_recompute("\t Survival resampler cache mismatch; recomputing.")
            except Exception as cache_err:
                log_cache_load_failure("\t Failed to load cached survival resampling (%s); recomputing.", cache_err)

        if not cache_valid:
            resamplar = CustomSurvivalResamplar(
                method=rsp,
                host_data_root=self.args.host_data_root,
                result_file_path=resample_file_path,
                result_file_name=os.path.basename(resample_file_path),
                **(resampler_params or {}),
            )
            try:
                if resamplar.need_resample(y_train):
                    logging.info("\t Survival Re-Sampling Started")
                    with rt.measure(stage_times, "resampling"):
                        X_train_imputed, y_train = resamplar.fit_resample(self.args, X_train_imputed, y_train)
                    logging.info("\t Survival Re-Sampling Done")

                    # Persist cache artifacts
                    with open(resample_file_path, "wb") as f:
                        pickle.dump(X_train_imputed, f)
                    with open(resample_y_path, "wb") as f:
                        pickle.dump(y_train, f)
                    with open(resample_meta_path, "w") as mf:
                        json.dump(resampler_signature, mf, indent=2)
            finally:
                safe_cleanup(resamplar, "Survival resampler cleanup failed")

        # Survival model training
        logging.info(f"\t Survival Training in fold {self.args.repeat} Start")
        trainer = CustomSurvivalModel(
            method=model,
            host_data_root=self.args.host_data_root,
            metric=self.args.metric,
        )
        model_impl = getattr(trainer, "_survival_clf", None)
        if model_impl is not None:
            setattr(model_impl, "keep_container_alive", True)
        try:
            with rt.measure(stage_times, "classification"):
                trainer.fit(self.args, X_train_imputed, y_train, X_test=X_test, y_test=y_test)
            logging.info(f"\t Survival Training in fold {self.args.repeat} Done")

            # Prediction and evaluation on test data
            with rt.measure(stage_times, "evaluation"):
                result = trainer.score(X_test_imputed, y_test, y_train=y_train_original)
        finally:
            safe_cleanup(trainer, "Survival model cleanup failed")
            del trainer

        return result, stage_times


class SurvivalUnsupervisedPipelineStrategy(BasePipelineStrategy):
    """
    Strategy for 2-element survival unsupervised pipelines: Imputer -> Survival Unsupervised Model

    Supports survival clustering and risk stratification.
    Example: ['median', 'survival_tree'], ['knn', 'survival_kmeans']
    """

    def validate_pipeline(self, pipe):
        """Ensure pipeline has exactly 2 elements"""
        if len(pipe) != 2:
            raise ValueError(
                f"Pipeline {pipe} length is not correct, not a survival unsupervised pipeline"
            )

    def execute_fold(self, pipe, X_train, y_train, X_test, y_test):
        """
        Execute one fold of a 2-element survival unsupervised pipeline.

        Steps:
        1. Imputation (with caching) - same as regular pipelines
        2. Survival unsupervised model training and prediction

        Args:
            pipe: [imputer, survival_unsupervised_model]
            X_train, y_train: Training data (y_train is structured survival array)
            X_test, y_test: Test data (y_test is structured survival array)
        """
        imp, model = pipe
        stage_times = rt.new_stage_times()

        # Imputation level - FIT on train, TRANSFORM both train and test
        with rt.measure(stage_times, "imputation"):
            X_train_imputed, X_test_imputed = self._impute_with_caching(
                imp, X_train, y_train, X_test, y_test
            )

        # Survival unsupervised model training
        logging.info(f"\t Training survival unsupervised model in fold {self.args.repeat} Start")
        trainer = CustomSurvivalUnsupervisedModel(
            method=model,
            host_data_root=self.args.host_data_root,
            metric=self.args.metric,
        )
        model_impl = getattr(trainer, "survival_unsupervised_model", None)
        if model_impl is not None:
            setattr(model_impl, "keep_container_alive", True)
        try:
            with rt.measure(stage_times, "classification"):
                trainer.fit(self.args, X_train_imputed, y_train)
            logging.info(f"\t Training survival unsupervised model in fold {self.args.repeat} Done")

            # Prediction and evaluation on test data
            with rt.measure(stage_times, "evaluation"):
                result = trainer.score(X_test_imputed, y_test)
        finally:
            safe_cleanup(trainer, "Survival unsupervised model cleanup failed")

        del trainer

        return result, stage_times
