import os
import pickle
import numpy as np
import logging
import json
import hashlib
from abc import ABC, abstractmethod
from typing import Any

from ...processing.utils import Samplar
from ..customimputation import CustomImputer
from ..logging import runtime_tracker as rt
from ..logging.failure_logger import log_cache_recompute, log_cache_load_failure


def execute_fold_pipeline(strategy, pipe, train_ratio=1.0):
    """Shared fold-based orchestration used by the entry layer and compatibility wrappers."""
    # Validate pipeline format
    strategy.validate_pipeline(pipe)

    # Reset fold counter for this pipeline run so logs and artifact names
    # reflect the current CV loop instead of accumulating across runs.
    strategy.args.repeat = 0

    X, y = strategy.prepare_fold_data(train_ratio)

    logging.info("Data loaded and preprocessed")

    train_sampler = strategy.build_fold_sampler(X, y)

    results = []
    stage_totals = rt.new_stage_totals()
    for X_train, y_train, X_test, y_test in train_sampler.apply_kfold(strategy.args.n_splits):
        logging.info(f"\t Fold {strategy.args.repeat}")

        # Execute this fold (strategy-specific logic)
        result, stage_times = strategy.execute_fold(pipe, X_train, y_train, X_test, y_test)
        results.append(result)
        rt.accumulate_stage_totals(stage_totals, stage_times)
        rt.log_fold_result(strategy.args.repeat, result)

        strategy.args.repeat += 1

    # Average results and save
    avg_result = rt.average(results)
    total_train_time = rt.sum_stage_times(stage_totals)
    strategy.saver.append(pipe, avg_result, train_time_seconds=total_train_time)
    return avg_result, stage_totals


class BasePipelineStrategy(ABC):
    """
    Abstract base class for pipeline execution strategies.

    Each strategy handles a specific pipeline type and encapsulates
    the logic for data loading, K-fold splitting, training, and evaluation.
    """

    is_fold_based = True

    def __init__(self, args, dataloader, preprocessor, saver):
        """
        Initialize the strategy.

        Args:
            args: Command-line arguments
            dataloader: DataLoader instance
            preprocessor: DataPreprocess instance
            saver: Result instance for saving/loading results
        """
        self.args = args
        self.dataloader = dataloader
        self.preprocessor = preprocessor
        self.saver = saver

    def _dataset_interim_dir(self) -> str:
        """Folder under container_data_root/interim for this dataset."""
        base = self.dataloader.get_interim_data_folder()
        dataset_dir = os.path.join(base, self.args.dataset)
        os.makedirs(dataset_dir, exist_ok=True)
        return dataset_dir

    @abstractmethod
    def validate_pipeline(self, pipe) -> None:
        """Validate that the pipeline has the correct format"""
        pass

    @abstractmethod
    def execute_fold(self, pipe, X_train, y_train, X_test, y_test) -> tuple[Any, dict[str, float]]:
        """Execute one fold of the pipeline"""
        pass

    def execute_non_fold(self, pipe, train_ratio=1.0) -> tuple[Any, dict[str, float]]:
        raise NotImplementedError("This strategy uses fold-based execution")

    def prepare_fold_data(self, train_ratio=1.0) -> tuple[Any, Any]:
        # Load and preprocess raw data (with missing values)
        X, y = self.preprocessor.preprocess(self.args)

        # Apply train_ratio if needed
        if train_ratio != 1.0:
            X, y = self._stratified_sample(X, y, train_ratio)

        return X, y

    def build_fold_sampler(self, X, y) -> Samplar:
        # Create K-fold splits on RAW data (before imputation)
        return Samplar(np.array(X), np.array(y))

    def execute(self, pipe, train_ratio=1.0) -> tuple[Any, dict[str, float]]:
        """Compatibility wrapper for direct strategy usage."""
        return execute_fold_pipeline(self, pipe, train_ratio)

    def _stratified_sample(self, X, y, train_ratio):
        """Apply stratified sampling to reduce dataset size"""
        import pandas as pd

        data = pd.concat([X, y], axis=1)
        new_data = data.groupby('Status', group_keys=False).apply(
            lambda x: x.sample(frac=train_ratio)
        )
        new_data.sort_index(inplace=True)
        new_data.reset_index(inplace=True, drop=True)
        columns = list(new_data.columns.values)
        columns.remove("Status")
        X = new_data[columns].copy()
        y = new_data["Status"].copy()
        return X, y

    def _impute_with_caching(self, imp, X_train, y_train, X_test, y_test=None):
        """
        Perform imputation with intelligent caching.

        This method checks if cached imputation results exist for this fold.
        If so, it loads them. Otherwise, it runs imputation and caches the results.

        Args:
            imp: Imputer name (e.g., 'mean', 'knn')
            X_train: Training features
            X_train: Training labels
            X_test: Test features

        Returns:
            Tuple of (X_train_imputed, X_test_imputed)
        """
        result_file_name = f"imp_{imp}_fold{self.args.repeat}.p"
        interim_dir = self._dataset_interim_dir()
        result_file_path = os.path.join(interim_dir, result_file_name)
        result_test_file_path = result_file_path.replace('.p', '_test.p')
        meta_file_path = result_file_path + ".meta"

        def _hash_array(arr):
            arr = np.asarray(arr)
            return hashlib.sha256(arr.tobytes()).hexdigest()

        def _hash_resampler_params(resampler_name: str, params: dict) -> str:
            """Hash the resampler name + params to invalidate cache on param changes."""
            if params is None:
                params = {}
            payload = {
                "resampler": resampler_name,
                "params": params,
            }
            return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()

        expected_meta = {
            "y_train_hash": _hash_array(y_train),
            "y_train_len": int(len(y_train)),
        }
        if y_test is not None:
            expected_meta.update(
                {
                    "y_test_hash": _hash_array(y_test),
                    "y_test_len": int(len(y_test)),
                }
            )

        # Check if cached imputation results exist and match the current split signature
        cache_valid = False
        if (
            os.path.exists(result_file_path)
            and os.path.exists(result_test_file_path)
            and os.path.exists(meta_file_path)
        ):
            try:
                logging.info(f"\t Loading cached imputation from {result_file_name}")
                with open(meta_file_path, "r") as mf:
                    meta = json.load(mf)
                if meta == expected_meta:
                    with open(result_file_path, "rb") as f:
                        X_train_imputed = pickle.load(f)
                    with open(result_test_file_path, "rb") as f:
                        X_test_imputed = pickle.load(f)
                    cache_valid = True
                    logging.info("\t Cached imputation loaded")
                else:
                    log_cache_recompute("\t Cached imputation signature mismatch; recomputing.", level="warning")
            except Exception as cache_err:
                log_cache_load_failure("\t Failed to load cached imputation (%s); recomputing.", cache_err)

        if not cache_valid:
            # Run imputation - results will be cached automatically
            logging.info("\t Imputation Started")
            imputer = CustomImputer(
                method=imp,
                host_data_root=self.args.host_data_root,
                dataset_name=self.args.dataset,
                result_file_path=result_file_path
            )

            # Fit on train, transform both
            X_train_imputed = imputer.fit_transform(self.args, X_train)
            X_test_imputed = imputer.transform(X_test)

            logging.info("\t Imputation Done")
            try:
                with open(meta_file_path, "w") as mf:
                    json.dump(expected_meta, mf, indent=2)
            except Exception as meta_err:
                logging.warning("\t Failed to write imputation meta: %s", meta_err)

        return X_train_imputed, X_test_imputed
