import logging


def safe_cleanup(obj, warning_message):
    if obj is None:
        return
    try:
        obj.cleanup()
    except Exception:
        logging.warning(warning_message, exc_info=True)


def run_preflight_if_present(preflight):
    if not callable(preflight):
        return
    try:
        preflight()
    except Exception:
        logging.error("Pipeline image preflight failed", exc_info=True)
        raise


def log_cache_recompute(message, level="info"):
    getattr(logging, level)(message)


def log_cache_load_failure(message, err):
    logging.warning(message, err)
