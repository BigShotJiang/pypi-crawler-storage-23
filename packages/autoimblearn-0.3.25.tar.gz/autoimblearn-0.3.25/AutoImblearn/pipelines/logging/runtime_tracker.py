import logging
import time
from contextlib import contextmanager


STAGE_KEYS = ("imputation", "resampling", "classification", "evaluation")


def new_stage_times():
    return {key: 0.0 for key in STAGE_KEYS}


def new_stage_totals():
    return {key: 0.0 for key in STAGE_KEYS}


def add_elapsed(stage_times, stage, started_at):
    stage_times[stage] += time.time() - started_at


@contextmanager
def measure(stage_times, stage):
    started_at = time.time()
    try:
        yield
    finally:
        add_elapsed(stage_times, stage, started_at)


def accumulate_stage_totals(stage_totals, stage_times):
    for key in STAGE_KEYS:
        stage_totals[key] += stage_times.get(key, 0.0)


def sum_stage_times(stage_times):
    return sum(stage_times.values())


def average(values):
    return sum(values) / len(values)


def log_fold_result(fold, result):
    try:
        logging.info(
            f"\t Fold {fold} result: {result}",
            extra={"ui_log": True, "stage": "fold", "fold": fold},
        )
    except Exception:
        logging.info(f"\t Fold {fold} result: {result}")
