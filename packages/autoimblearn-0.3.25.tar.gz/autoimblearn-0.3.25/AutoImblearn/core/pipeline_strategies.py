# AutoImblearn/core/pipeline_strategies.py
"""Pipeline strategy composition root: selection, preflight, execution, and aggregation."""

from ..pipelines.strategy.base import BasePipelineStrategy, execute_fold_pipeline
from ..pipelines.strategy.sequential import (
    ThreeElementPipelineStrategy,
    HybridPipelineStrategy,
    AutoMLPipelineStrategy,
    UnsupervisedPipelineStrategy,
)
from ..pipelines.strategy.survival import (
    SurvivalPipelineStrategy,
    SurvivalUnsupervisedPipelineStrategy,
)
from ..pipelines.strategy.parallel import execute_parallel_or_fallback
from ..pipelines.strategy.filtered import filter_pipeline_spec
from ..pipelines.logging import runtime_tracker as rt
from ..pipelines.logging.failure_logger import run_preflight_if_present
from ..pipelines.customsurvival import survival_models, survival_unsupervised_models
from ..pipelines.customunsupervised import unsupervised_models

average = rt.average


STRATEGY_EXPORTS = {
    "three_element": ThreeElementPipelineStrategy,
    "hybrid": HybridPipelineStrategy,
    "automl": AutoMLPipelineStrategy,
    "survival": SurvivalPipelineStrategy,
    "unsupervised": UnsupervisedPipelineStrategy,
    "survival_unsupervised": SurvivalUnsupervisedPipelineStrategy,
}


def select_pipeline_strategy(args, dataloader, preprocessor, saver, pipe):
    """Parse pipeline configuration and build the matching strategy instance."""
    pipe_length = len(pipe)

    if pipe_length == 3:
        model = pipe[2]
        strategy_cls = (
            SurvivalPipelineStrategy if model in survival_models else ThreeElementPipelineStrategy
        )
    elif pipe_length == 2:
        model = pipe[1]
        if model in survival_unsupervised_models:
            strategy_cls = SurvivalUnsupervisedPipelineStrategy
        elif model in unsupervised_models:
            strategy_cls = UnsupervisedPipelineStrategy
        else:
            strategy_cls = HybridPipelineStrategy
    elif pipe_length == 1:
        strategy_cls = AutoMLPipelineStrategy
    else:
        raise ValueError(
            f"Invalid pipeline length {pipe_length}. "
            f"Expected 1 (AutoML), 2 (Hybrid/Unsupervised), 3 (Regular/Survival) elements."
        )

    return strategy_cls(args, dataloader, preprocessor, saver)


def _resolve_preflight_hook(args, preflight):
    if callable(preflight):
        return preflight
    for attr in ("pipeline_preflight", "preflight", "preflight_images"):
        candidate = getattr(args, attr, None)
        if callable(candidate):
            return candidate
    return None


def _execute_non_fold_strategy(strategy, pipe, train_ratio):
    if hasattr(strategy, "run_non_fold"):
        result, stage_times = strategy.run_non_fold(pipe, train_ratio)
        strategy.args.repeat += 1
        total_train_time = rt.sum_stage_times(stage_times)
        strategy.saver.append(pipe, result, train_time_seconds=total_train_time)
        return result, stage_times
    return execute_parallel_or_fallback(strategy, pipe, train_ratio)


def execute_pipeline_strategy(
    args,
    dataloader,
    preprocessor,
    saver,
    pipe,
    train_ratio=1.0,
    preflight=None,
):
    """Select, optionally preflight, execute, and aggregate pipeline results."""
    filtered_pipe = filter_pipeline_spec(pipe)
    strategy = select_pipeline_strategy(args, dataloader, preprocessor, saver, filtered_pipe)

    # Responsibility boundary: image checks/preparation are triggered here, never in strategy modules.
    run_preflight_if_present(_resolve_preflight_hook(args, preflight))

    if getattr(strategy, "is_fold_based", True):
        return execute_fold_pipeline(strategy, filtered_pipe, train_ratio)

    return _execute_non_fold_strategy(strategy, filtered_pipe, train_ratio)


__all__ = [
    "average",
    "STRATEGY_EXPORTS",
    "BasePipelineStrategy",
    "ThreeElementPipelineStrategy",
    "HybridPipelineStrategy",
    "AutoMLPipelineStrategy",
    "SurvivalPipelineStrategy",
    "UnsupervisedPipelineStrategy",
    "SurvivalUnsupervisedPipelineStrategy",
    "select_pipeline_strategy",
    "execute_pipeline_strategy",
]
