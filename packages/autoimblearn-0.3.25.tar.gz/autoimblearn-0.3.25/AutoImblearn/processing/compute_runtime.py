import glob
import json
import os
import re
import shutil
import subprocess


def parse_gpu_ids(value):
    if value is None:
        return []

    if isinstance(value, (list, tuple, set)):
        raw_items = list(value)
    elif isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        if text.startswith("[") and text.endswith("]"):
            try:
                parsed = json.loads(text)
                raw_items = parsed if isinstance(parsed, list) else [parsed]
            except Exception:
                raw_items = [tok for tok in re.split(r"[,\s]+", text) if tok]
        else:
            raw_items = [tok for tok in re.split(r"[,\s]+", text) if tok]
    else:
        raw_items = [value]

    gpu_ids = []
    for item in raw_items:
        try:
            gpu_ids.append(int(item))
        except (TypeError, ValueError):
            continue
    return sorted(set(gpu_ids))


def is_truthy(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


def detect_available_gpus():
    """
    Detect available GPU devices for backend runtime.

    Returns:
        list[dict]: [{"id": int, "name": str}, ...]
    """
    env_override = os.getenv("AUTOIMBLEARN_GPU_IDS", "").strip()
    if env_override:
        ids = parse_gpu_ids(env_override)
        return [{"id": idx, "name": f"GPU {idx}"} for idx in ids]

    gpus = []
    nvidia_smi = shutil.which("nvidia-smi")
    if nvidia_smi:
        try:
            proc = subprocess.run(
                [
                    nvidia_smi,
                    "--query-gpu=index,name",
                    "--format=csv,noheader,nounits",
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=2,
            )
            if proc.returncode == 0:
                for line in (proc.stdout or "").splitlines():
                    parts = [p.strip() for p in line.split(",", 1)]
                    if not parts:
                        continue
                    try:
                        idx = int(parts[0])
                    except (TypeError, ValueError):
                        continue
                    name = parts[1] if len(parts) > 1 and parts[1] else f"GPU {idx}"
                    gpus.append({"id": idx, "name": name})
        except Exception:
            pass

    if gpus:
        return sorted(gpus, key=lambda x: x["id"])

    ids = []
    for dev in sorted(glob.glob("/dev/nvidia[0-9]*")):
        match = re.search(r"(\d+)$", dev)
        if match:
            ids.append(int(match.group(1)))
    ids = sorted(set(ids))
    return [{"id": idx, "name": f"GPU {idx}"} for idx in ids]


def normalize_compute_params(params, available_gpus=None, *, prefer_all_gpus=True):
    """
    Normalize compute settings into a consistent shape.

    Returned keys:
    - cpu_mode: bool
    - gpu_ids: list[int]
    - compute_device: str
    - device: str
    - cuda: "0" | "1"
    """
    params = dict(params or {})
    if available_gpus is None:
        available_gpus = detect_available_gpus()
    available_ids = [gpu["id"] for gpu in available_gpus]

    explicit = any(
        key in params
        for key in ("cpu_mode", "gpu_ids", "compute_device", "device", "cuda")
    )

    cpu_mode = None
    if "cpu_mode" in params:
        cpu_mode = is_truthy(params.get("cpu_mode"))

    gpu_ids = parse_gpu_ids(params.get("gpu_ids"))
    if available_ids:
        gpu_ids = [idx for idx in gpu_ids if idx in available_ids]
    else:
        gpu_ids = []

    compute_device = (params.get("compute_device") or params.get("device") or "").strip().lower()
    if compute_device.startswith("cuda:"):
        try:
            dev_idx = int(compute_device.split(":", 1)[1])
            if not available_ids or dev_idx in available_ids:
                if dev_idx not in gpu_ids:
                    gpu_ids.append(dev_idx)
        except (TypeError, ValueError):
            pass
    elif compute_device == "cpu" and cpu_mode is None:
        cpu_mode = True

    if cpu_mode is None:
        if explicit:
            cpu_mode = not bool(gpu_ids)
            if not cpu_mode and not gpu_ids and available_ids:
                gpu_ids = available_ids[:] if prefer_all_gpus else [available_ids[0]]
                cpu_mode = False
        else:
            if available_ids:
                cpu_mode = False
                gpu_ids = available_ids[:] if prefer_all_gpus else [available_ids[0]]
            else:
                cpu_mode = True
                gpu_ids = []

    if cpu_mode:
        gpu_ids = []
        compute_device = "cpu"
        cuda = "0"
    else:
        if not gpu_ids:
            if available_ids:
                gpu_ids = available_ids[:] if prefer_all_gpus else [available_ids[0]]
            else:
                return {
                    "cpu_mode": True,
                    "gpu_ids": [],
                    "compute_device": "cpu",
                    "device": "cpu",
                    "cuda": "0",
                }
        gpu_ids = sorted(set(gpu_ids))
        compute_device = f"cuda:{gpu_ids[0]}"
        cuda = "1"

    return {
        "cpu_mode": cpu_mode,
        "gpu_ids": gpu_ids,
        "compute_device": compute_device,
        "device": compute_device,
        "cuda": cuda,
    }
