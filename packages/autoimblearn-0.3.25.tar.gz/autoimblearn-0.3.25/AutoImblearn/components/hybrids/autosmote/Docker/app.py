# print(__package__)

# if __name__ == "__main__":
#     import os
#     import sys
#     current_path = os.path.dirname(os.path.abspath(__file__))
#     parent_path = os.path.dirname(os.path.dirname(current_path))  # Adjust based on actual layout
#     sys.path.insert(0, parent_path)
#
#     # Optionally set package name for relative imports to work
#     __package__ = "AutoImblearn.api"

import logging
import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
AUTOSMOTE_DIR = os.path.join(CURRENT_DIR, "autosmote")
if AUTOSMOTE_DIR not in sys.path:
    sys.path.insert(0, AUTOSMOTE_DIR)

from classifiers import get_clf, name2f
from data_loading import split_train_validation
from rl.training import train

from AutoImblearn.components.api import BaseEstimatorAPI

import numpy as np

VAL_RATIO = 0.2
DEFAULT_SAVE_ROOT = "/tmp/autosmote_logs"

# Keep noisy runtime logs inside container internals.
logging.getLogger("werkzeug").setLevel(logging.ERROR)
logging.getLogger("gym").setLevel(logging.ERROR)


class RunAutosmoteAPI(BaseEstimatorAPI):
    def get_hyperparameter_search_space(self):
        return {
            "seed": {
                "type": "int",
                "min": 0,
                "max": 10000,
                "default": 1
            },
            "device": {
                "type": "categorical",
                "choices": ["cpu", "cuda:0", "cuda:1"],
                "default": "cuda:0"
            },
            "cuda": {
                "type": "categorical",
                "choices": ["0", "1"],
                "default": "0"
            },
            "xpid": {
                "type": "categorical",
                "choices": ["AutoSMOTE"],
                "default": "AutoSMOTE"
            },
            "undersample_ratio": {
                "type": "int",
                "min": 10,
                "max": 300,
                "default": 100
            },
            "num_instance_specific_actions": {
                "type": "int",
                "min": 1,
                "max": 50,
                "default": 10
            },
            "num_max_neighbors": {
                "type": "int",
                "min": 5,
                "max": 100,
                "default": 30
            },
            "cross_instance_scale": {
                "type": "int",
                "min": 1,
                "max": 10,
                "default": 4
            },
            "num_actors": {
                "type": "int",
                "min": 1,
                "max": 100,
                "default": 8
            },
            "total_steps": {
                "type": "int",
                "min": 100,
                "max": 50000,
                "default": 1000
            },
            "batch_size": {
                "type": "int",
                "min": 2,
                "max": 64,
                "default": 8
            },
            "cross_instance_unroll_length": {
                "type": "int",
                "min": 1,
                "max": 20,
                "default": 2
            },
            "instance_specific_unroll_length": {
                "type": "int",
                "min": 50,
                "max": 1000,
                "default": 300
            },
            "low_level_unroll_length": {
                "type": "int",
                "min": 50,
                "max": 1000,
                "default": 300
            },
            "num_buffers": {
                "type": "int",
                "min": 5,
                "max": 100,
                "default": 20
            },
            "entropy_cost": {
                "type": "float",
                "min": 0.0001,
                "max": 0.01,
                "default": 0.0006
            },
            "baseline_cost": {
                "type": "float",
                "min": 0.0,
                "max": 1.0,
                "default": 0.5
            },
            "discounting": {
                "type": "float",
                "min": 0.9,
                "max": 1.0,
                "default": 1.0
            },
            "learning_rate": {
                "type": "float",
                "min": 1e-5,
                "max": 0.1,
                "default": 0.005,
                "log_scale": True
            },
            "grad_norm_clipping": {
                "type": "float",
                "min": 1.0,
                "max": 100.0,
                "default": 40.0
            },
            "clf": {
                "type": "categorical",
                "choices": list(name2f.keys()),
                "default": "svm"
            },
        }

    def _build_runtime_params(self, args):
        params = self.dict_to_namespace()
        search_space = self.get_hyperparameter_search_space()

        # Fill in AutoSMOTE defaults for parameters not provided by /set payload.
        for key, spec in search_space.items():
            if hasattr(params, key):
                continue
            if isinstance(spec, dict) and "default" in spec:
                setattr(params, key, spec["default"])

        params.metric = getattr(args, "metric", getattr(params, "metric", "auroc"))
        params.val_ratio = VAL_RATIO

        dataset_name = getattr(args, "dataset_name", None) or getattr(args, "dataset", "dataset")
        safe_dataset_name = str(dataset_name).replace("/", "_")
        if not hasattr(params, "savedir") or not getattr(params, "savedir"):
            params.savedir = os.path.join(DEFAULT_SAVE_ROOT, safe_dataset_name)

        return params

    def fit(self, args, X_train, y_train, X_test=None, y_test=None):
        if X_test is None or y_test is None:
            raise ValueError("AutoSMOTE requires X_test and y_test for final evaluation.")

        params = self._build_runtime_params(args)
        train_X, val_X, train_y, val_y = split_train_validation(
            X_train,
            y_train,
            val_ratio=VAL_RATIO,
            seed=getattr(params, "seed", None),
        )

        test_X = X_test.to_numpy() if hasattr(X_test, "to_numpy") else np.asarray(X_test)
        test_y = np.asarray(y_test).ravel()

        logging.info("finished parameter setting")

        params.ratio_map = [0.0, 0.25, 0.5, 0.75, 1.0]
        clf = get_clf(params.clf)
        score = train(params, train_X, train_y, val_X, val_y, test_X, test_y, clf)
        self.result = score
        return score

    def predict(self, X_test, y_test=None):
        return self.result

    def predict_proba(self, X):
        raise NotImplementedError("predict_proba is not supported for AutoSMOTE.")


if __name__ == "__main__":
    RunAutosmoteAPI(__name__).run(host="0.0.0.0", port=8080, debug=False)
