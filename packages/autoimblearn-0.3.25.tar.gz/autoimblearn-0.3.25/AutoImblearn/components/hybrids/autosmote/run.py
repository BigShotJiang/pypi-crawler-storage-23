from typing import Optional
from pathlib import Path

# from ..model_client.base_model_client import BaseDockerModelClient
from AutoImblearn.components.model_client.base_estimator import BaseEstimator
from AutoImblearn.components.model_client.image_spec import ImageSpec
import os


class RunAutoSmote(BaseEstimator):
    def __init__(
        self,
        host_data_root: str,
        result_file_path: Optional[str] = None,
        result_file_name: Optional[str] = None,
        metric: str = "auroc",
        **kwargs,
    ):
        if host_data_root is None:
            raise ValueError("host_data_root cannot be None")

        host_host_data_root = os.path.abspath(host_data_root)
        image_spec = ImageSpec(
            image="autosmote-api",
            context=Path(__file__).resolve().parent,
        )

        super().__init__(
            image_spec=image_spec,
            container_name="autosmote_container",
            container_port=8080,
            host_data_root=host_host_data_root,
        )

        self.result_file_path = result_file_path
        if result_file_name:
            self.result_file_name = result_file_name
        elif result_file_path:
            self.result_file_name = os.path.basename(result_file_path)
        else:
            self.result_file_name = "autosmote_result.p"
        self.metric = metric

    @property
    def payload(self):
        dataset = self.args.dataset
        container_name = self.container_name
        metric = getattr(self.args, "metric", None) or self.metric

        payload = {
            "metric": metric,
            "dataset_name": dataset,
            "dataset": [
                f"{dataset}/X_train_{container_name}.csv",
                f"{dataset}/y_train_{container_name}.csv",
                f"{dataset}/X_test_{container_name}.csv",
                f"{dataset}/y_test_{container_name}.csv",
            ],
        }

        if self.result_file_name:
            payload["result_file_name"] = self.result_file_name

        return payload
