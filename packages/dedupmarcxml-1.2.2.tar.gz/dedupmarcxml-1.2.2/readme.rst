**************************************************
Deduplication of records library for MarcXML |doc|
**************************************************

This python module is a tool to deduplicate records in format MarcXML.

* Author: Raphaël Rey (raphael.rey@slsp.ch)
* Year: 2025
* License: GNU General Public License v3.0
* `Documentation <https://dedupmarcxml.readthedocs.io/en/latest/>`_

.. |doc| image:: https://readthedocs.org/projects/dedupmarcxml/badge/?version=latest
    :target: https://dedupmarcxml.readthedocs.io/en/latest/
    :alt: Documentation Status