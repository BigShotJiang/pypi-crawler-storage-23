# CHANGELOG

<!-- version list -->

## v2.5.1 (2026-02-19)

### Bug Fixes

- Make agent instructions dynamic based on enabled agents
  ([`18a731c`](https://github.com/snokam/voice-vibecoder/commit/18a731c77c0fa85f62f5ca29e105ef406824f544))


## v2.5.0 (2026-02-19)

### Features

- **tools**: Require display_name for send_to_session
  ([`d50f71d`](https://github.com/snokam/voice-vibecoder/commit/d50f71dafc624ebe17f00bcf9880ec546786cbe9))


## v2.4.0 (2026-02-19)

### Bug Fixes

- **server**: Handle unexpected errors during authentication
  ([`f0ac102`](https://github.com/snokam/voice-vibecoder/commit/f0ac1025cac939f8fc048c796d63668c1d687f9e))


## v2.3.0 (2026-02-19)


## v2.2.0 (2026-02-19)


## v2.1.0 (2026-02-19)


## v2.0.1 (2026-02-18)

### Bug Fixes

- Publish to PyPI even when version was bumped in a prior run
  ([`bb3968d`](https://github.com/snokam/voice-vibecoder/commit/bb3968d026f00c0072ecf1925eac1f722dec8bc2))


## v2.0.0 (2026-02-18)

### Chores

- Remove obsolete GitHub workflow and Dockerfile
  ([`b1f7cf6`](https://github.com/snokam/voice-vibecoder/commit/b1f7cf63f4a9fd35dfcd39081c5bb45c6db8a8d7))

### Features

- Replace hardcoded OBO exchange with pre_agent_hook
  ([`343b284`](https://github.com/snokam/voice-vibecoder/commit/343b2849c7abd58500ef4f631793d274625a14ca))


## v1.34.0 (2026-02-18)

### Features

- Add MS 365 MCP server with OBO token support
  ([`772b4c7`](https://github.com/snokam/voice-vibecoder/commit/772b4c7ccb833069421c98675512e0e7602ab646))


## v1.33.0 (2026-02-18)


## v1.32.0 (2026-02-18)

### Features

- Add external tool registry for extensibility
  ([`72313d6`](https://github.com/snokam/voice-vibecoder/commit/72313d66a514252d1c80e2f41ca5db43a3da32f0))


## v1.31.2 (2026-02-18)

### Bug Fixes

- Improve websocket send reliability and truncate [DONE] output
  ([`e5b6eec`](https://github.com/snokam/voice-vibecoder/commit/e5b6eeca0103b5e82b77744d173810b6896a92c3))


## v1.31.1 (2026-02-18)

### Bug Fixes

- Remove duplicate state sync that caused doubled output lines
  ([`0aea6e1`](https://github.com/snokam/voice-vibecoder/commit/0aea6e1bf8c9dc423c733574887751ad3498a7da))


## v1.31.0 (2026-02-18)

### Features

- Tag-style badges for MCP tools in agent panel
  ([`980bdef`](https://github.com/snokam/voice-vibecoder/commit/980bdefcbebfcd5b446a21026cdf3eb89591b116))


## v1.30.0 (2026-02-18)

### Documentation

- Add CLAUDE.md with Jira MCP server and issue creation guide
  ([`e6c7fc6`](https://github.com/snokam/voice-vibecoder/commit/e6c7fc6acac4d9e0b48ce10e2b5e8710830392a4))

- Update help text formatting in server.py
  ([`639a2a9`](https://github.com/snokam/voice-vibecoder/commit/639a2a99c57ffac4a4863449d52f80424da2111e))

### Features

- Tag-style badges for tool calls and MCP servers in agent panel
  ([`82543ac`](https://github.com/snokam/voice-vibecoder/commit/82543ac2b20f5d9f3ce9963f9f7825b2e08b897c))


## v1.29.12 (2026-02-18)

### Bug Fixes

- Compact helper description to avoid spacing issues
  ([`2198a08`](https://github.com/snokam/voice-vibecoder/commit/2198a0864f9520a2329ae8a1b990b9c4432a2e0a))


## v1.29.11 (2026-02-18)

### Bug Fixes

- Switch Jira MCP to mcp-atlassian (sooperset)
  ([`3e04f75`](https://github.com/snokam/voice-vibecoder/commit/3e04f7532f4654d348cbf4e7eb69ec5fd1ed13c9))


## v1.29.10 (2026-02-18)

### Bug Fixes

- Avoid duplicate helper description on session restore
  ([`05c7b0b`](https://github.com/snokam/voice-vibecoder/commit/05c7b0b43458a37fe5908621bfa0a463c9ba96b4))


## v1.29.9 (2026-02-18)

### Bug Fixes

- Skip file tree updates for helper instance
  ([`2de0c74`](https://github.com/snokam/voice-vibecoder/commit/2de0c74032293c867349ced9fc58c5e5d0eca287))


## v1.29.8 (2026-02-18)

### Bug Fixes

- Pre-install jira-mcp in Docker image to avoid npx download at runtime
  ([`6980423`](https://github.com/snokam/voice-vibecoder/commit/698042371418c08eece4558d73180548dadbab24))


## v1.29.7 (2026-02-18)

### Bug Fixes

- Inject process env vars into MCP server configs
  ([`36839e9`](https://github.com/snokam/voice-vibecoder/commit/36839e9aff7d796d0229a66c8351186009e30615))

### Chores

- Remove ENV_CHECK debug logging from agent startup
  ([`f49eb63`](https://github.com/snokam/voice-vibecoder/commit/f49eb63daef9f9b7d12b62d3bf87a1afcdb40123))


## v1.29.6 (2026-02-18)

### Bug Fixes

- Update helper instance description with PR/issue/Jira examples
  ([`394c0c3`](https://github.com/snokam/voice-vibecoder/commit/394c0c3525c828011ce9fe493b48acc3b4735554))


## v1.29.5 (2026-02-18)

### Bug Fixes

- Skip file tree updates for helper instance on repo root
  ([`3a916da`](https://github.com/snokam/voice-vibecoder/commit/3a916dacb9f133c5b3c6f55d2a35b47c1f9faa59))


## v1.29.4 (2026-02-18)

### Bug Fixes

- Show only first line of multi-line bash commands in agent output
  ([`3eb08b9`](https://github.com/snokam/voice-vibecoder/commit/3eb08b96781a1facb27e917bbd55f4f241ba97be))


## v1.29.3 (2026-02-18)

### Bug Fixes

- Send syncing/ready status around state sync
  ([`2bc5cef`](https://github.com/snokam/voice-vibecoder/commit/2bc5ceffc368b7a4e917d62af3105544f3b90879))


## v1.29.2 (2026-02-18)

### Bug Fixes

- Simplify git push auth to use gh auth git-credential
  ([`8d9f0e9`](https://github.com/snokam/voice-vibecoder/commit/8d9f0e9b1f59fdb2c2f9a509e641d535b1f2a29d))


## v1.29.1 (2026-02-18)

### Bug Fixes

- Use git credential helper with SSH-to-HTTPS rewrite for push
  ([`21bf327`](https://github.com/snokam/voice-vibecoder/commit/21bf327221004737514758f6ed72670c75291326))


## v1.29.0 (2026-02-18)

### Features

- Support MCP_SERVERS_JSON environment variable
  ([`19ad9be`](https://github.com/snokam/voice-vibecoder/commit/19ad9be9ec5b491696b9dfa338232d2e356d2e6a))


## v1.28.0 (2026-02-17)

### Features

- Add Jira MCP server configuration
  ([`8066c1c`](https://github.com/snokam/voice-vibecoder/commit/8066c1c9e94fd41251b6af1d363b401829fecfd9))


## v1.27.1 (2026-02-17)

### Bug Fixes

- Configure git credential helper for GitHub token authentication
  ([`9d64c1e`](https://github.com/snokam/voice-vibecoder/commit/9d64c1edd834fa208c4d08ef79f953fcbc79c82e))

- Prevent duplicate files in tree structure
  ([`7258218`](https://github.com/snokam/voice-vibecoder/commit/7258218cec95ca1d64960917d42b051cf019e46c))


## v1.27.0 (2026-02-17)

### Features

- Show file tree for all instances including idle feature branches
  ([`26cfda2`](https://github.com/snokam/voice-vibecoder/commit/26cfda2bc82b3b796a42343ec2ed9bc3cf848e8c))


## v1.26.0 (2026-02-17)

### Features

- Add helpful description text to helper instance
  ([`0354d54`](https://github.com/snokam/voice-vibecoder/commit/0354d54c61eda202471bd946eb2d8b9323b60747))


## v1.25.0 (2026-02-17)

### Features

- Convert file tree to hierarchical structure with auto-expand
  ([`44d74f8`](https://github.com/snokam/voice-vibecoder/commit/44d74f8d42fb1df5d1eefdaf90a77ec4b5a63391))


## v1.24.2 (2026-02-17)

### Bug Fixes

- Use dedicated test ACR (crsnkmtest) in snøkam-t subscription
  ([`9160af8`](https://github.com/snokam/voice-vibecoder/commit/9160af8d1179d54656818e07a7650a23c6520508))


## v1.24.1 (2026-02-17)

### Bug Fixes

- Use platform-t subscription for ACR in test deployment
  ([`26a029a`](https://github.com/snokam/voice-vibecoder/commit/26a029a675a6d51c2da935cbf9999fe3175d5127))


## v1.24.0 (2026-02-17)

### Features

- Use dedicated production ACR (crsnkmprod)
  ([`5969867`](https://github.com/snokam/voice-vibecoder/commit/59698673458d216b40d97ee7a83f6b172a06d7ec))


## v1.23.0 (2026-02-17)

### Features

- Use GitHub environments snkm-p and snkm-t for deployments
  ([`89108e1`](https://github.com/snokam/voice-vibecoder/commit/89108e166c3b277ede8c0fa21b125f389af35b01))


## v1.22.1 (2026-02-17)

### Bug Fixes

- Deploy to correct container app in snøkam tenant
  ([`bcb1da1`](https://github.com/snokam/voice-vibecoder/commit/bcb1da1b4460266706f9f9e703394d5f11334053))


## v1.22.0 (2026-02-17)

### Bug Fixes

- Include agentType in instance status change messages
  ([`f0790b9`](https://github.com/snokam/voice-vibecoder/commit/f0790b91ae94e453f0ab13b48f85c640210d8d68))


## v1.21.0 (2026-02-17)

### Chores

- Remove debug logging from agent_task
  ([`a9627a6`](https://github.com/snokam/voice-vibecoder/commit/a9627a6d39e306ee1857cdc4e11af1dba3c67ce4))

### Features

- Add OpenClaw integration with OAuth support
  ([`d8da351`](https://github.com/snokam/voice-vibecoder/commit/d8da3515d3ff145e6180922a9e1458155f105e20))

- Show complete project structure in file tree
  ([`9c9d185`](https://github.com/snokam/voice-vibecoder/commit/9c9d1853d2370be50b5aa5659ff7f1841a86251d))


## v1.20.0 (2026-02-17)

### Chores

- Remove accidentally committed serverless deployment files
  ([`2def1ff`](https://github.com/snokam/voice-vibecoder/commit/2def1ff3ec68472603ab1fae7fb5be8c6d834f07))

### Features

- Persist voice transcripts to backend state
  ([`32a9ad3`](https://github.com/snokam/voice-vibecoder/commit/32a9ad3fa5ca6008f2082e945b8119829e6eac9a))


## v1.19.0 (2026-02-17)

### Features

- Add sync_state API and per-user state storage
  ([`7d5094a`](https://github.com/snokam/voice-vibecoder/commit/7d5094a4f5161e0300ceec3b4afd2a1f91d3dc12))


## v1.18.3 (2026-02-17)

### Bug Fixes

- Send output buffer to frontend on reconnect
  ([`131d5da`](https://github.com/snokam/voice-vibecoder/commit/131d5da2a28165e3eaeaf6221f444a9f1d78e5f9))


## v1.18.2 (2026-02-17)

### Bug Fixes

- Preserve PATH and environment variables for agents
  ([`aad070c`](https://github.com/snokam/voice-vibecoder/commit/aad070c8cd73bab4df1fe758a27d75960d250804))


## v1.18.1 (2026-02-17)

### Bug Fixes

- Remove GitHub token env var reference until secret is configured
  ([`0a6d910`](https://github.com/snokam/voice-vibecoder/commit/0a6d9107a59703c6174938fdba1dd2acdef22f47))


## v1.18.0 (2026-02-17)


## v1.17.0 (2026-02-17)

### Features

- Add serverless container management API for users
  ([`9ecd09e`](https://github.com/snokam/voice-vibecoder/commit/9ecd09e202f81777007b19eb028929ab624b5f11))


## v1.16.0 (2026-02-17)


## v1.15.0 (2026-02-17)

### Features

- Send file tree to UI after agent task completes
  ([`71c72bf`](https://github.com/snokam/voice-vibecoder/commit/71c72bf0a3d8dde5b3f0fa356daa320680fa9e67))

### Refactoring

- Remove redundant _send_file_tree in favor of file_tree module
  ([`7788d35`](https://github.com/snokam/voice-vibecoder/commit/7788d353f405a6e41df4c427c9ad5f0e4bdd4912))


## v1.14.0 (2026-02-17)

### Bug Fixes

- Accept both v1 and v2 Azure AD token formats in JWT validation
  ([`6820ce3`](https://github.com/snokam/voice-vibecoder/commit/6820ce3a8b91cdd089b3218fcec4a9a738bc5627))

- Create /worktrees dir for non-root user in container
  ([`fc0be99`](https://github.com/snokam/voice-vibecoder/commit/fc0be9969f320c6f089514cb439f7853208ac770))

- Sync existing instances to web client on connect
  ([`7bb600c`](https://github.com/snokam/voice-vibecoder/commit/7bb600cd66c072e5a04cbeb0282c69e1c90e8f91))

- **security**: Harden WebSocket server auth and Docker build
  ([`d45c2cd`](https://github.com/snokam/voice-vibecoder/commit/d45c2cdf124c4d5d3ab35501ec7b880aabfa78d5))

### Build System

- Multi-stage Dockerfile for ACR Build compatibility
  ([`eb08e96`](https://github.com/snokam/voice-vibecoder/commit/eb08e96012ecc5dac24ae70cff3db0ed847bfc1a))

- Update Dockerfile for user permissions and setup
  ([`6516b1a`](https://github.com/snokam/voice-vibecoder/commit/6516b1aaefdb216ec163173ebb694c7d43f2f2da))

### Continuous Integration

- Add deploy workflows for test and prod
  ([`1cd3451`](https://github.com/snokam/voice-vibecoder/commit/1cd345135eb75702d964db0559c8c6c7a439067f))

### Features

- Add WebSocket server and CLI entry point
  ([`35a6536`](https://github.com/snokam/voice-vibecoder/commit/35a6536e0a4c4d3604caa2d24a3bb26e1048d8aa))

- Wire up on_tool_call and on_ui_command callbacks for web client
  ([`ecc907e`](https://github.com/snokam/voice-vibecoder/commit/ecc907ec6bf16c7ce6518182b1d4d79878f4b933))

- **docker**: Add Dockerfile for container deployment
  ([`d1f2e8f`](https://github.com/snokam/voice-vibecoder/commit/d1f2e8fdbebfaf34d0ff24078b126d85a82636b8))


## v1.13.0 (2026-02-16)


## v1.12.0 (2026-02-16)

### Continuous Integration

- Update release workflow for version checking logic
  ([`1954217`](https://github.com/snokam/voice-vibecoder/commit/19542172741a253ba75eac0143873d3333791586))

### Features

- **cursor**: Set limit for large NDJSON lines in cursor
  ([`6d5f816`](https://github.com/snokam/voice-vibecoder/commit/6d5f816b2b09cc8e5906a16c82b37326e02019f6))


## v1.11.0 (2026-02-16)


## v1.10.0 (2026-02-16)

### Features

- **help**: Add help modal for shortcuts and usage guide
  ([`d6c7cef`](https://github.com/snokam/voice-vibecoder/commit/d6c7cef8ada876baf1329c074406f5491615871c))

### Refactoring

- Update _get_repo_root to return tuple with status
  ([`e1dfdf4`](https://github.com/snokam/voice-vibecoder/commit/e1dfdf41baba14968372ef95ffde7111b3d4fcb7))

- **ui**: Move imports inside _play_audio method
  ([`7f4f4ae`](https://github.com/snokam/voice-vibecoder/commit/7f4f4aee2765e04df81daa0516fa760bff0d27d9))


## v1.9.0 (2026-02-16)


## v1.8.0 (2026-02-16)

### Features

- Add centralized agent registry and output truncation
  ([`bad0a19`](https://github.com/snokam/voice-vibecoder/commit/bad0a19630340a87aa3b284643c035e0a09c39de))


## v1.7.0 (2026-02-16)


## v1.6.0 (2026-02-16)


## v1.5.0 (2026-02-16)


## v1.4.0 (2026-02-16)


## v1.3.0 (2026-02-16)


## v1.2.0 (2026-02-16)


## v1.1.0 (2026-02-16)

### Features

- Implement voice provider connection testing methods
  ([`4ce0b59`](https://github.com/snokam/voice-vibecoder/commit/4ce0b59a7571dc4d4b9e3917ebae6526ce0bb939))


## v1.0.3 (2026-02-16)

### Bug Fixes

- Add vibecoder script alias alongside voice-vibecoder
  ([`13c6a1c`](https://github.com/snokam/voice-vibecoder/commit/13c6a1c859f3d3463189143d539d5940e901f5bb))


## v1.0.2 (2026-02-16)

### Bug Fixes

- Rename script entry to voice-vibecoder so uvx voice-vibecoder works
  ([`b7933f2`](https://github.com/snokam/voice-vibecoder/commit/b7933f29b9ebd1d532b80b3d61e51d46e66917ae))


## v1.0.1 (2026-02-16)

### Bug Fixes

- Rename PyPI package to voice-vibecoder
  ([`174ddad`](https://github.com/snokam/voice-vibecoder/commit/174ddad9278fd341087af1223e1e45bfdca01f19))


## v1.0.0 (2026-02-16)

- Initial Release
