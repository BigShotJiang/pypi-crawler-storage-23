"""Cursor Agent CLI runner.

Implements the AgentRunner protocol by spawning `cursor-agent` as a subprocess
and parsing its NDJSON stream output. Supports session resume via --resume.

Event format (from cursor-agent --output-format stream-json):
  {"type":"system","subtype":"init","session_id":"...","model":"..."}
  {"type":"user","message":{"role":"user","content":[...]},"session_id":"..."}
  {"type":"assistant","message":{"role":"assistant","content":[...]},"session_id":"..."}
  {"type":"tool_call","subtype":"started"|"completed",...}
  {"type":"result","subtype":"success","result":"...","session_id":"..."}
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

from voice_vibecoder.code_providers import AgentOutput, AgentResult

logger = logging.getLogger(__name__)

MAX_DIFF_LINES = 20

# Maps Cursor's nested tool_call keys to short names
_CURSOR_TOOL_KEYS = {
    "globToolCall": "glob",
    "grepToolCall": "grep",
    "readToolCall": "read",
    "editToolCall": "edit",
    "writeToolCall": "write",
    "commandToolCall": "command",
    "listDirToolCall": "listdir",
    "codebaseSearchToolCall": "search",
    "fileSearchToolCall": "filesearch",
}


def _parse_cursor_tool_call(event: dict) -> tuple[str, dict, dict]:
    """Extract (tool_name, args, result) from Cursor's nested tool_call format."""
    tc = event.get("tool_call", {})
    for key, name in _CURSOR_TOOL_KEYS.items():
        if key in tc:
            inner = tc[key]
            args = inner.get("args", {})
            result = inner.get("result", {})
            # Unwrap success/error envelope
            if isinstance(result, dict) and "success" in result:
                result = result["success"]
            return name, args, result
    # Fallback: try flat fields
    name = event.get("name", "") or event.get("tool", "")
    return name, {}, {}


def _describe_cursor_tool(name: str, args: dict) -> str:
    """Human-readable description for a Cursor tool call."""
    if name == "read":
        return f"\\[Read] {_basename(args.get('path', ''))}"
    elif name == "edit":
        return f"\\[Edit] {_basename(args.get('path', ''))}"
    elif name == "write":
        path = _basename(args.get("path", ""))
        content = args.get("streamContent", "") or args.get("content", "")
        n = len(content.splitlines()) if content else 0
        suffix = f" ({n} lines)" if n else ""
        return f"\\[Write] {path}{suffix}"
    elif name == "command":
        cmd = args.get("command", "")
        preview = cmd[:80] + "..." if len(cmd) > 80 else cmd
        return f"\\[Bash] {preview}"
    elif name == "glob":
        return f"\\[Glob] {args.get('globPattern', '') or args.get('pattern', '')}"
    elif name == "grep":
        return f"\\[Grep] {args.get('query', '') or args.get('pattern', '')}"
    elif name == "search":
        return f"\\[Search] {args.get('query', '')}"
    elif name == "filesearch":
        return f"\\[FileSearch] {args.get('query', '')}"
    elif name == "listdir":
        return f"\\[ListDir] {args.get('path', '.')}"
    elif name:
        return f"\\[{name}]"
    return "\\[tool]"


def _basename(path: str) -> str:
    return path.rsplit("/", 1)[-1] if path else "unknown"


def _summarize_cursor_result(name: str, result: dict) -> str:
    """Short summary of a completed Cursor tool result."""
    if not result:
        return ""
    if name == "edit":
        msg = result.get("message", "")
        added = result.get("linesAdded", 0)
        removed = result.get("linesRemoved", 0)
        if msg:
            return msg
        parts = []
        if added:
            parts.append(f"+{added}")
        if removed:
            parts.append(f"-{removed}")
        return ", ".join(parts) if parts else "done"
    elif name == "glob":
        files = result.get("files", [])
        total = result.get("totalFiles", len(files))
        return f"{total} file(s)"
    elif name == "read":
        lines = result.get("totalLines", 0)
        return f"{lines} lines" if lines else ""
    elif name == "command":
        output = result.get("output", "") or result.get("stdout", "")
        if output:
            preview = str(output)[:200] + ("..." if len(str(output)) > 200 else "")
            return preview
    # Generic fallback
    content = str(result)
    if len(content) > 200:
        return content[:200] + "..."
    return content if len(content) < 200 else ""


def _cursor_edit_diff(name: str, args: dict) -> list[AgentOutput]:
    """Extract diff lines from a Cursor edit tool call."""
    outputs: list[AgentOutput] = []
    content = args.get("streamContent", "") or args.get("content", "")

    if name == "write" and content:
        lines = content.splitlines()
        for i, line in enumerate(lines):
            if i >= MAX_DIFF_LINES:
                outputs.append(AgentOutput(category="diff_add", content=f"... (+{len(lines) - i} more)"))
                break
            outputs.append(AgentOutput(category="diff_add", content=line))
        return outputs

    if name == "edit" and content:
        # Cursor edit with streamContent is a full-file write
        lines = content.splitlines()
        for i, line in enumerate(lines):
            if i >= MAX_DIFF_LINES:
                outputs.append(AgentOutput(category="diff_add", content=f"... (+{len(lines) - i} more)"))
                break
            outputs.append(AgentOutput(category="diff_add", content=line))

    return outputs


class CursorRunner:
    """AgentRunner implementation using the Cursor CLI (cursor-agent)."""

    def __init__(self) -> None:
        self._process: asyncio.subprocess.Process | None = None

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        args = [
            "cursor-agent",
            "-p",
            "--output-format", "stream-json",
            "--force",
        ]
        if session_id:
            args.extend(["--resume", session_id])
        args.append(message)

        self._process = await asyncio.create_subprocess_exec(
            *args,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=1024 * 1024,  # 1 MB — Cursor emits large NDJSON lines for file reads
        )

        result_text = ""
        result_session_id: str | None = None

        try:
            assert self._process.stdout is not None
            while True:
                line = await self._process.stdout.readline()
                if not line:
                    break
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue

                etype = event.get("type", "")

                # Capture session_id from any event
                sid = event.get("session_id")
                if sid:
                    result_session_id = sid

                # Map to output (may yield multiple lines for multi-line text)
                for output in self._map_event(event):
                    if on_output:
                        on_output(output)

                if etype == "result":
                    result_text = event.get("result", "")

        except asyncio.CancelledError:
            self.cancel()
            raise

        await self._process.wait()

        if not result_text and self._process.returncode != 0:
            assert self._process.stderr is not None
            stderr = await self._process.stderr.read()
            if stderr:
                result_text = f"Cursor error (exit {self._process.returncode}): {stderr.decode(errors='replace')[:500]}"

        self._process = None
        return AgentResult(text=result_text, session_id=result_session_id)

    def cancel(self) -> bool:
        if self._process and self._process.returncode is None:
            self._process.terminate()
            return True
        return False

    @staticmethod
    def _map_event(event: dict) -> list[AgentOutput]:
        etype = event.get("type", "")
        subtype = event.get("subtype", "")

        if etype == "assistant":
            msg = event.get("message", {})
            content_blocks = msg.get("content", [])
            texts = []
            for block in content_blocks:
                if isinstance(block, dict) and block.get("type") == "text":
                    texts.append(block.get("text", ""))
                elif isinstance(block, str):
                    texts.append(block)
            # Split into one output per line to avoid multi-line blobs
            outputs = []
            for text in texts:
                for line in text.splitlines():
                    line = line.strip()
                    if line:
                        outputs.append(AgentOutput(category="text", content=line))
            return outputs

        elif etype == "tool_call":
            tool_name, tool_args, tool_result = _parse_cursor_tool_call(event)
            if subtype == "started":
                desc = _describe_cursor_tool(tool_name, tool_args)
                is_edit = tool_name in ("edit", "write")
                category = (
                    "file_edit" if is_edit
                    else "bash" if tool_name == "command"
                    else "tool_call"
                )
                outputs: list[AgentOutput] = [AgentOutput(category=category, content=desc)]
                if is_edit:
                    outputs.extend(_cursor_edit_diff(tool_name, tool_args))
                return outputs
            elif subtype == "completed":
                content = _summarize_cursor_result(tool_name, tool_result)
                if content:
                    return [AgentOutput(category="tool_result", content=content)]

        elif etype == "result":
            if event.get("is_error"):
                return [AgentOutput(category="text", content=f"[ERROR] {event.get('result', '')}")]

        return []
