"""Voice Code Assistant — Olaf The Vibecoder.

A voice-controlled coding assistant using OpenAI Realtime API + Claude Code.
"""

__version__ = "2.5.1"

from voice_vibecoder.app_config import VoiceConfig
from voice_vibecoder.ui.screen import VoiceCodingScreen

__all__ = ["VoiceConfig", "VoiceCodingScreen", "VoiceCodingApp", "__version__"]


def _get_repo_root() -> tuple["Path", bool]:
    """Find the git repo root from cwd. Returns (path, is_git_repo)."""
    import subprocess
    from pathlib import Path

    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return Path(result.stdout.strip()), True
    return Path.cwd(), False


class VoiceCodingApp:
    """Standalone Textual app for voice coding."""

    def __init__(self, config: VoiceConfig | None = None) -> None:
        self._config = config or VoiceConfig()

    def run(self) -> None:
        import os
        import sys
        from pathlib import Path
        from textual.app import App

        config = self._config
        repo_root, is_git = _get_repo_root()

        if is_git:
            _subtitle = str(repo_root)
        else:
            _subtitle = f"⚠ Not a git repo: {repo_root}"

        class _App(App):
            TITLE = config.app_name
            SUB_TITLE = _subtitle

            def on_mount(self) -> None:
                self.push_screen(
                    VoiceCodingScreen(repo_root, config=config),
                    callback=lambda _: self.exit(),
                )

        app = _App()
        result = app.run()
        if result == "_restart":
            os.execv(sys.executable, [sys.executable] + sys.argv)


def _cli_main() -> None:
    """Entry point for `voice-code-assistant` CLI command."""
    VoiceCodingApp().run()
