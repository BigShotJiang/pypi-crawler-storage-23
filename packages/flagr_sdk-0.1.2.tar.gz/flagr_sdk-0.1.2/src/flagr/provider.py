"""OpenFeature provider for Flagr."""

from __future__ import annotations

import threading
from typing import Optional, Union

from openfeature.evaluation_context import EvaluationContext
from openfeature.exception import FlagNotFoundError
from openfeature.flag_evaluation import FlagResolutionDetails, Reason
from openfeature.hook import Hook
from openfeature.provider.metadata import Metadata
from openfeature.provider.no_op_provider import AbstractProvider

from .client import FlagrClient, FlagValue


def _resolve(val: FlagValue, tenant_id: str) -> bool:
    """Resolve a cached FlagValue to a boolean for the given tenant."""
    if val.state == "enabled":
        return True
    if val.state == "partially_enabled":
        return tenant_id in val.enabled_list
    return False


class FlagrProvider(AbstractProvider):
    """
    OpenFeature-compatible provider for Flagr.

    Usage::

        from openfeature import api
        from flagr import FlagrProvider

        provider = FlagrProvider(sdk_key="sdk_live_xxx")
        api.set_provider(provider)

        client = api.get_client()
        enabled = client.get_boolean_value(
            "new-checkout",
            default_value=False,
            # tenant_id can be a user ID, org ID, account ID, or any entity identifier in your product
        evaluation_context=EvaluationContext(targeting_key="a1b2c3d4-e5f6-7890-abcd-ef1234567890"),
        )
    """

    def __init__(self, sdk_key: str, base_url: str = "https://api.flagr.dev") -> None:
        self._client = FlagrClient(sdk_key, base_url)
        self._lock = threading.RLock()
        self._cache: dict[str, FlagValue] = {}

    # ── OpenFeature lifecycle ──────────────────────────────────────────────

    def get_metadata(self) -> Metadata:
        return Metadata(name="flagr")

    def get_provider_hooks(self) -> list[Hook]:
        return []

    def initialize(self, evaluation_context: Optional[EvaluationContext] = None) -> None:
        self._client.connect(
            on_snapshot=self._on_snapshot,
            on_update=self._on_update,
        )

    def shutdown(self) -> None:
        self._client.close()

    # ── Flag resolution ────────────────────────────────────────────────────

    def resolve_boolean_details(
        self,
        flag_key: str,
        default_value: bool,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[bool]:
        val = self._get(flag_key)
        tenant_id = (evaluation_context.targeting_key or "") if evaluation_context else ""
        return FlagResolutionDetails(
            value=_resolve(val, tenant_id),
            reason=Reason.TARGETING_MATCH if val.state == "partially_enabled" else Reason.STATIC,
        )

    def resolve_string_details(
        self,
        flag_key: str,
        default_value: str,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[str]:
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    def resolve_integer_details(
        self,
        flag_key: str,
        default_value: int,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[int]:
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    def resolve_float_details(
        self,
        flag_key: str,
        default_value: float,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[float]:
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    def resolve_object_details(
        self,
        flag_key: str,
        default_value: Union[dict, list],  # type: ignore[type-arg]
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[Union[dict, list]]:  # type: ignore[type-arg]
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    # ── internals ─────────────────────────────────────────────────────────

    def _get(self, flag_key: str) -> FlagValue:
        with self._lock:
            val = self._cache.get(flag_key)
        if val is None:
            raise FlagNotFoundError(f"Flag '{flag_key}' not found")
        return val

    def _on_snapshot(self, flags: dict[str, FlagValue]) -> None:
        with self._lock:
            self._cache.update(flags)

    def _on_update(self, flag_key: str, value: FlagValue) -> None:
        with self._lock:
            self._cache[flag_key] = value
