#!/bin/bash
{marker}

{callback}
