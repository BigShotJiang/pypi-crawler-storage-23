from pathlib import Path
from pyPhases import PluginAdapter
from pyPhasesRecordloader import RecordLoader


class Plugin(PluginAdapter):
    defaultConfig = "config.yaml"

    def initPlugin(self):
        def onConfigChanged(field):
            if field == "mesa-path":
                mesaPath = Path(self.getConfig("mesa-path", "datasets/mesa"))

                self.project.setConfig("loader.mesa.filePath", mesaPath.as_posix())
                self.project.setConfig("loader.mesa.dataset.downloader.basePath", mesaPath.as_posix())
                self.project.setConfig(
                    "loader.mesa.dataset.downloader.basePathExtensionwise",
                    [
                        (mesaPath / "polysomnography/edfs/").as_posix(),
                        (mesaPath / "polysomnography/annotations-events-nsrr/").as_posix(),
                    ],
                )

        self.project.on("configChanged", onConfigChanged)
        onConfigChanged("mesa-path")

        RecordLoader.registerRecordLoader("RecordLoaderMESA", "pyPhasesRecordloaderMESA.recordLoaders")
        RecordLoader.registerRecordLoader("MESAAnnotationLoader", "pyPhasesRecordloaderMESA.recordLoaders")
