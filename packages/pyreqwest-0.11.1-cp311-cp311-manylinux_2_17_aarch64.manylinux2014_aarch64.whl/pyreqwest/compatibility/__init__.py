"""Compatibility layers for different HTTP client libraries.

See individual modules for details.
"""
