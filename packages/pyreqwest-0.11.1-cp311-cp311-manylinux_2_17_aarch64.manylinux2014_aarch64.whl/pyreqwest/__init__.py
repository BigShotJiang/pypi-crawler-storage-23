""".. include:: ../../README.md"""

from ._pyreqwest import __version__, _start_time_ns  # noqa: F401
