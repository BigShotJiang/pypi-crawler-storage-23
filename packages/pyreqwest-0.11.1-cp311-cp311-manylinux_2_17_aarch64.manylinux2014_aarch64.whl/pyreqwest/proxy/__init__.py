"""Proxy classes."""

from pyreqwest._pyreqwest.proxy import ProxyBuilder

__all__ = ["ProxyBuilder"]
