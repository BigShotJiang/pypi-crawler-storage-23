"""Simple interfaces for doing one-off requests."""
