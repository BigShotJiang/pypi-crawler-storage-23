"""Logging utilities for pyreqwest."""

from pyreqwest._pyreqwest.logging import flush_logs

__all__ = [
    "flush_logs",
]
