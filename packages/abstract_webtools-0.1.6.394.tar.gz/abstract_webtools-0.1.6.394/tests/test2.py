from imports import *

url = "https://solscan.io"
soup_mgr = usurpit(url,max_depth=30)


