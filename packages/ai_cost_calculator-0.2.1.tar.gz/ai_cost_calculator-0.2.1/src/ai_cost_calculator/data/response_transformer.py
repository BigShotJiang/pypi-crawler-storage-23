import math
from typing import Any

from jsonpath_ng import parse

from ai_cost_calculator.data.model_resolver import normalize_model_id, strip_provider_prefix
from ai_cost_calculator.data.config_loader import load_response_mappings_config
from ai_cost_calculator.errors import ModelInferenceError, ProviderInferenceError, UsageNotFoundError
from ai_cost_calculator.providers.berri_client import get_berri_model_provider_map
from ai_cost_calculator.types import TokenUsage


def _get_first_numeric_value(response: Any, paths: list[str]) -> float | None:
    for path in paths:
        matches = parse(path).find(response)
        if not matches:
            continue
        first = matches[0].value
        if isinstance(first, (int, float)) and math.isfinite(first):
            return float(first)
        if isinstance(first, str):
            try:
                return float(first)
            except ValueError:
                continue
    return None


def extract_token_usage(response: Any, provider: str) -> TokenUsage:
    mappings = load_response_mappings_config()
    mapping = mappings.get(provider) or mappings.get("default")
    if not mapping:
        raise UsageNotFoundError(
            f'No response mapping found for provider "{provider}" and no default mapping exists.'
        )

    input_tokens = _get_first_numeric_value(response, mapping["inputTokensPaths"])
    output_tokens = _get_first_numeric_value(response, mapping["outputTokensPaths"])
    total_tokens = _get_first_numeric_value(response, mapping["totalTokensPaths"])

    if input_tokens is None and output_tokens is None and total_tokens is None:
        raise UsageNotFoundError(
            f'Could not extract token usage for provider "{provider}".'
        )

    cache_read_paths = mapping.get("cacheReadTokensPaths", [])
    cache_creation_paths = mapping.get("cacheCreationTokensPaths", [])
    cache_read = _get_first_numeric_value(response, cache_read_paths) if cache_read_paths else 0.0
    cache_creation = _get_first_numeric_value(response, cache_creation_paths) if cache_creation_paths else 0.0

    if input_tokens is not None or output_tokens is not None:
        input_value = input_tokens or 0.0
        output_value = output_tokens or 0.0
        return TokenUsage(
            input_tokens=input_value,
            output_tokens=output_value,
            total_tokens=total_tokens or (input_value + output_value),
            cache_read_tokens=cache_read or 0.0,
            cache_creation_tokens=cache_creation or 0.0,
        )

    return TokenUsage(
        input_tokens=total_tokens or 0.0,
        output_tokens=0.0,
        total_tokens=total_tokens or 0.0,
        cache_read_tokens=cache_read or 0.0,
        cache_creation_tokens=cache_creation or 0.0,
    )


def detect_tool_calls(response: Any) -> bool:
    if not isinstance(response, dict):
        return False

    # OpenAI chat completions: choices[].message.tool_calls
    choices = response.get("choices")
    if isinstance(choices, list):
        for choice in choices:
            message = choice.get("message") if isinstance(choice, dict) else None
            if isinstance(message, dict):
                tool_calls = message.get("tool_calls")
                if isinstance(tool_calls, list) and len(tool_calls) > 0:
                    return True

    # Anthropic: content[].type === "tool_use"
    content = response.get("content")
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                return True

    # OpenAI Responses API: output[].type === "function_call"
    output = response.get("output")
    if isinstance(output, list):
        for item in output:
            if isinstance(item, dict) and item.get("type") == "function_call":
                return True

    # Google Gemini: candidates[].content.parts[].functionCall
    candidates = response.get("candidates")
    if isinstance(candidates, list):
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            content = candidate.get("content")
            if isinstance(content, dict):
                parts = content.get("parts")
                if isinstance(parts, list):
                    for part in parts:
                        if isinstance(part, dict) and part.get("functionCall"):
                            return True

    return False


def get_input_includes_cache_read(provider: str) -> bool:
    mappings = load_response_mappings_config()
    mapping = mappings.get(provider) or mappings.get("default")
    if not mapping:
        return True
    return mapping.get("inputIncludesCacheRead", True)


def _get_first_string_value(response: Any, paths: list[str]) -> str | None:
    for path in paths:
        matches = parse(path).find(response)
        if not matches:
            continue
        first = matches[0].value
        if isinstance(first, str) and first.strip():
            return first.strip()
    return None


def extract_response_model(response: Any) -> str:
    model = _get_first_string_value(response, ["$.model", "$.response.model", "$.data.model"])
    if model is None:
        raise ModelInferenceError("Could not infer model from response.")
    return model


def infer_provider_from_model(model: str) -> str:
    provider_map = get_berri_model_provider_map()
    normalized_model = normalize_model_id(model)

    provider = provider_map.get(normalized_model)
    if provider is not None:
        return provider

    stripped = strip_provider_prefix(normalized_model)
    if stripped != normalized_model:
        provider = provider_map.get(stripped)
        if provider is not None:
            return provider
        double_stripped = strip_provider_prefix(stripped)
        if double_stripped != stripped:
            provider = provider_map.get(double_stripped)
            if provider is not None:
                return provider

    best_match: tuple[str, str] | None = None
    for key, value in provider_map.items():
        if (
            normalized_model.startswith(key)
            and len(normalized_model) > len(key)
        ):
            sep = normalized_model[len(key)]
            if sep in ("-", ":", "."):
                if best_match is None or len(key) > len(best_match[0]):
                    best_match = (key, value)
    if best_match is not None:
        return best_match[1]

    raise ProviderInferenceError(
        f'Could not infer provider from model "{model}" using Berri config mapping.'
    )


def extract_response_metadata(
    response: Any,
    *,
    model: str | None = None,
    provider: str | None = None,
) -> dict[str, str]:
    resolved_model = model if model is not None else extract_response_model(response)
    resolved_provider = provider if provider is not None else infer_provider_from_model(resolved_model)
    return {"model": resolved_model, "provider": resolved_provider}
