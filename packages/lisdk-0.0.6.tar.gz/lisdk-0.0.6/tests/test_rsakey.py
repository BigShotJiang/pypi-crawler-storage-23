
from lisdk import RSAKey, RsaKeyBuilder


def test_read_rsaprikeytext():
    keytext = RsaKeyBuilder().filepath('/Users/lizhankang/Documents/shouqianba/pems/ka/beta/28lp467052302/client/priKey.pem').build().export()
    print(keytext)

def test_read_rsapubkeytext():
    keytext = RsaKeyBuilder().filepath('/Users/lizhankang/Documents/shouqianba/pems/ka/beta/28lp467052302/client/pubkey.pem').build().export()
    print(keytext)

def test_rsakey_builder():
    print()
    # 测试 builder 生成
    # 测试从文本构建
    prikeytext = '-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC7h2cFdrl/xJs7c90GQDfIaLYBpclFwEkg4W+Fh5aqcsHM4o66vjp8KKU6BN/ZfOhA7zHdzU2K4WRPpU9CCPUN0rNxyyjIMlU+MN3cs/JZJvAj43lAFLV1McyM9fEAv56oJKkjda4DKbYyUiRTmAucQYqe907RAbEPi8eOXNgz3FvRc9ecdcqad/nty0EO788gfPBth9bikWZQjRUwI7piiZIdJAhG21mBOAE2Bq6/5JzAeLN39zZh3XydRYUWBYvL+OEjopqc3eExeTRQhh/HQALicDcnR1wLAFw8OTAZMdlzG7T/MdaYFPXQqc6Cmp2vc4yYtO4hd57xEN8F13+FAgMBAAECggEBAIo3FwBY7Am2r68XC22jATpNqu/18C3ftkZswZSKRcrk/9/xj78lm9eM4ZKsqwwSWuAZLAjNW3yj+RoWvh7umScSB740PZ+oMVnADJWxb0q0P0REUUagvMle5eNzFak2kkpdkugWwSWFpcra7flK1Cvbxr65ijbT51uM640K8zLszpVHPDU2g406uri0twKk1AbxImZjKwvrgpiwvpbCqqibHMZIm0hBR/PpWdtwDvmAlfZLYVAKDtBHhkOvnI9XzVi7gBcK11vSZKKcTROltA/UxCwKhuAkVt3KLsihCjMJpFqcqFPHuo9KQ2tUgAigP4nEiAZ1ML13XPCTk8+YtIECgYEA+JK/KFsIH6dO8YFaChlSqf+Me3Cnn5+Ks1a27Q+8utS7jMOaWSxqurUWmJvXvFQZGTVmjbYcAeoMgVX1nGrIqioPZUNdygCE5BgQXFfIZlZeitcW9pylR9/KUa3onCdi7lnqa890W0chBcWKZnMmvUyM3pSx6SjNR2czC0qfbeECgYEAwSG/i/jPmaRNSiUkA0tYdH7c5LDIUQC7ewNxhBDw9Qg/wnKCQtv7sXvV8z4u6biTnm4fAysDtRgixujLdq9GP3bG82lzgo5QmhIuTCv3MUdo/J3SrZU+Ccp7lqdlDASnzZ0kvcwg7/oe4Pphe8JkE6LVSWGzrztTo5umcPj0XiUCgYEAr/VxS+fkwEN3Jo4iZrO2SJCVqWv9vIj7bigcJYPWXYrpmKN+R1Gh27kE3dKzzKTbf3TFu9sFyHUdlRB8ZNVSZuKPM2eUpMHpUG2YZ0XcnlTVaAMKRlhsx4wrc9ZfqupWpdMQlnCsNVEMl0FWz18ENUxTC9zGc/5mEf2DrKKOaQECgYBSr/tNl2Jyuoio1Qv9KRYfEm3Kr/Gj1LdwLII+c+5mSnjZ7KLes0aor4djlF0Ljg4Nx8IZXiJBN6s0FFmAX/yokVcOwjhFTl8uB9iwniZAf/1wIrYfwYUFNh8B2nuF0LxzaPNhG3OCq0jrM+fmz8x/J7k/qMgAn1ro8mwpdD1TzQKBgQDcP6JxbjBa/QllKUpDVWs5hh7djWj2rxK6UfQy5b88YwDN8nIfl9dC0dtTzuf/ns7jptSJSy4aRoSWYpYEFUhXYlBHLDXlo8DuF67Xn6W+kp9ZfkmNE+kn3AcCE5a6dy0o1rSOSweupqb4LXmF971Gj/h608e6BxDnF8LKF+YqBg==\n-----END PRIVATE KEY-----'
    rsakey = RsaKeyBuilder().keytext(prikeytext).build()

    signature = rsakey.sign({'a': 1, 'name': '李占康', 'age': 18, 'sex': True, 'email': 'lizhankang@shouqianba.com'})
    print(signature)
    
    assert rsakey.is_private is True

def test_rsakey_pubkey():
    # 测试公钥
    prikeytext = '-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC7h2cFdrl/xJs7c90GQDfIaLYBpclFwEkg4W+Fh5aqcsHM4o66vjp8KKU6BN/ZfOhA7zHdzU2K4WRPpU9CCPUN0rNxyyjIMlU+MN3cs/JZJvAj43lAFLV1McyM9fEAv56oJKkjda4DKbYyUiRTmAucQYqe907RAbEPi8eOXNgz3FvRc9ecdcqad/nty0EO788gfPBth9bikWZQjRUwI7piiZIdJAhG21mBOAE2Bq6/5JzAeLN39zZh3XydRYUWBYvL+OEjopqc3eExeTRQhh/HQALicDcnR1wLAFw8OTAZMdlzG7T/MdaYFPXQqc6Cmp2vc4yYtO4hd57xEN8F13+FAgMBAAECggEBAIo3FwBY7Am2r68XC22jATpNqu/18C3ftkZswZSKRcrk/9/xj78lm9eM4ZKsqwwSWuAZLAjNW3yj+RoWvh7umScSB740PZ+oMVnADJWxb0q0P0REUUagvMle5eNzFak2kkpdkugWwSWFpcra7flK1Cvbxr65ijbT51uM640K8zLszpVHPDU2g406uri0twKk1AbxImZjKwvrgpiwvpbCqqibHMZIm0hBR/PpWdtwDvmAlfZLYVAKDtBHhkOvnI9XzVi7gBcK11vSZKKcTROltA/UxCwKhuAkVt3KLsihCjMJpFqcqFPHuo9KQ2tUgAigP4nEiAZ1ML13XPCTk8+YtIECgYEA+JK/KFsIH6dO8YFaChlSqf+Me3Cnn5+Ks1a27Q+8utS7jMOaWSxqurUWmJvXvFQZGTVmjbYcAeoMgVX1nGrIqioPZUNdygCE5BgQXFfIZlZeitcW9pylR9/KUa3onCdi7lnqa890W0chBcWKZnMmvUyM3pSx6SjNR2czC0qfbeECgYEAwSG/i/jPmaRNSiUkA0tYdH7c5LDIUQC7ewNxhBDw9Qg/wnKCQtv7sXvV8z4u6biTnm4fAysDtRgixujLdq9GP3bG82lzgo5QmhIuTCv3MUdo/J3SrZU+Ccp7lqdlDASnzZ0kvcwg7/oe4Pphe8JkE6LVSWGzrztTo5umcPj0XiUCgYEAr/VxS+fkwEN3Jo4iZrO2SJCVqWv9vIj7bigcJYPWXYrpmKN+R1Gh27kE3dKzzKTbf3TFu9sFyHUdlRB8ZNVSZuKPM2eUpMHpUG2YZ0XcnlTVaAMKRlhsx4wrc9ZfqupWpdMQlnCsNVEMl0FWz18ENUxTC9zGc/5mEf2DrKKOaQECgYBSr/tNl2Jyuoio1Qv9KRYfEm3Kr/Gj1LdwLII+c+5mSnjZ7KLes0aor4djlF0Ljg4Nx8IZXiJBN6s0FFmAX/yokVcOwjhFTl8uB9iwniZAf/1wIrYfwYUFNh8B2nuF0LxzaPNhG3OCq0jrM+fmz8x/J7k/qMgAn1ro8mwpdD1TzQKBgQDcP6JxbjBa/QllKUpDVWs5hh7djWj2rxK6UfQy5b88YwDN8nIfl9dC0dtTzuf/ns7jptSJSy4aRoSWYpYEFUhXYlBHLDXlo8DuF67Xn6W+kp9ZfkmNE+kn3AcCE5a6dy0o1rSOSweupqb4LXmF971Gj/h608e6BxDnF8LKF+YqBg==\n-----END PRIVATE KEY-----'
    rsa = RsaKeyBuilder().keytext(prikeytext).build()
    pubkey = rsa.publickey()
    print(pubkey.export())
    assert pubkey.is_private is False

def test_rsapubkey():
    keyfile = '/Users/lizhankang/Documents/shouqianba/pems/ka/beta/28lp467052302/client/pubkey.pem'
    rsakey = RsaKeyBuilder().filepath(keyfile).build()

    assert rsakey.verify({'a': 1, 'name': '李占康', 'age': 18, 'sex': True, 'email': 'lizhankang@shouqianba.com'}, signature) is True

    assert rsakey.is_private is False



