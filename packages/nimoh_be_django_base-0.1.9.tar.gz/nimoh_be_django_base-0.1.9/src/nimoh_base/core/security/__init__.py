"""Security package for core app."""
