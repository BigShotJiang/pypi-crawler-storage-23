"""
Security views.

This module provides views for security-related functionality including:
- CSP violation reporting
- Security incident logging
- Security metrics endpoints
"""

import json
import logging
from typing import Any

from django.conf import settings
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from nimoh_base.core.utils import get_client_ip

logger = logging.getLogger(__name__)


@method_decorator(csrf_exempt, name="dispatch")
class CSPReportView(View):
    """
    Content Security Policy violation report handler.

    This endpoint receives and logs CSP violation reports from browsers.
    CSP reports are sent automatically by browsers when content violates
    the application's Content Security Policy.

    See: https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP
    """

    def post(self, request: HttpRequest) -> HttpResponse:
        """
        Handle CSP violation report.

        Args:
            request: Django HTTP request containing CSP report JSON

        Returns:
            HTTP 204 No Content on success
            HTTP 400 Bad Request on invalid JSON
            HTTP 405 Method Not Allowed for non-POST requests
        """
        try:
            # Parse CSP report JSON
            if request.body:
                report = json.loads(request.body.decode("utf-8"))
            else:
                logger.warning("CSP report received with empty body")
                return HttpResponse(status=400)

            # Extract report details
            csp_report = report.get("csp-report", {})

            # Log CSP violation with appropriate severity
            self._log_csp_violation(request, csp_report)

            # In production, you might want to:
            # 1. Store reports in database for analysis
            # 2. Send alerts for critical violations
            # 3. Track violation trends
            # 4. Integrate with monitoring systems (Sentry, etc.)

            if self._is_critical_violation(csp_report):
                self._handle_critical_violation(request, csp_report)

            # Return 204 No Content (standard for CSP reports)
            return HttpResponse(status=204)

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in CSP report: {e}")
            return HttpResponse(status=400)

        except Exception as e:
            logger.error(f"Error processing CSP report: {e}", exc_info=True)
            return HttpResponse(status=500)

    def _log_csp_violation(self, request: HttpRequest, csp_report: dict[str, Any]) -> None:
        """
        Log CSP violation with relevant details.

        Args:
            request: Django HTTP request
            csp_report: Parsed CSP report dictionary
        """
        # Extract key violation details
        document_uri = csp_report.get("document-uri", "unknown")
        violated_directive = csp_report.get("violated-directive", "unknown")
        blocked_uri = csp_report.get("blocked-uri", "unknown")
        csp_report.get("original-policy", "unknown")
        source_file = csp_report.get("source-file", "unknown")
        line_number = csp_report.get("line-number", "unknown")

        # Get client information
        user_agent = request.META.get("HTTP_USER_AGENT", "unknown")
        client_ip = self._get_client_ip(request)

        # Log with structured data
        logger.warning(
            f"CSP Violation Detected | "
            f"Document: {document_uri} | "
            f"Violated: {violated_directive} | "
            f"Blocked: {blocked_uri} | "
            f"Source: {source_file}:{line_number} | "
            f"Client: {client_ip} | "
            f"User-Agent: {user_agent[:100]}"
        )

        # Log full report at debug level for troubleshooting
        logger.debug(f"Full CSP Report: {json.dumps(csp_report, indent=2)}")

    def _is_critical_violation(self, csp_report: dict[str, Any]) -> bool:
        """
        Determine if CSP violation is critical.

        Critical violations include:
        - Inline script execution attempts
        - External script loading from unexpected domains
        - Data exfiltration attempts via connect-src violations

        Args:
            csp_report: Parsed CSP report dictionary

        Returns:
            True if violation is critical, False otherwise
        """
        violated_directive = csp_report.get("violated-directive", "")
        blocked_uri = csp_report.get("blocked-uri", "")

        # Check for critical violation patterns
        critical_patterns = [
            "script-src",  # Script loading violations
            "connect-src",  # Potential data exfiltration
            "frame-ancestors",  # Clickjacking attempts
        ]

        # Check if violation involves critical directives
        is_critical = any(pattern in violated_directive for pattern in critical_patterns)

        # Additional checks for suspicious URIs
        suspicious_uris = ["eval", "inline", "data:"]
        has_suspicious_uri = any(pattern in blocked_uri for pattern in suspicious_uris)

        return is_critical or has_suspicious_uri

    def _handle_critical_violation(self, request: HttpRequest, csp_report: dict[str, Any]) -> None:
        """
        Handle critical CSP violations with additional actions.

        Args:
            request: Django HTTP request
            csp_report: Parsed CSP report dictionary
        """
        # Log at ERROR level for critical violations
        logger.error(
            f"CRITICAL CSP VIOLATION | "
            f"Document: {csp_report.get('document-uri')} | "
            f"Violated: {csp_report.get('violated-directive')} | "
            f"Blocked: {csp_report.get('blocked-uri')}"
        )

        # In production, you might want to:
        # 1. Send immediate alert to security team
        # 2. Record in security incident tracking system
        # 3. Trigger automated response (rate limiting, etc.)
        # 4. Update threat intelligence feeds

    @staticmethod
    def _get_client_ip(request: HttpRequest) -> str:
        """Delegate to canonical get_client_ip."""
        return get_client_ip(request)


@require_http_methods(["GET"])
def security_health_check(request: HttpRequest) -> JsonResponse:
    """
    Security health check endpoint.

    Returns basic security configuration status without exposing sensitive details.

    Args:
        request: Django HTTP request

    Returns:
        JSON response with security health status
    """
    health_status = {
        "status": "healthy",
        "security_features": {
            "https_enforced": settings.SECURE_SSL_REDIRECT if hasattr(settings, "SECURE_SSL_REDIRECT") else False,
            "hsts_enabled": bool(getattr(settings, "SECURE_HSTS_SECONDS", 0) > 0),
            "csp_enabled": True,  # CSP is always enabled via SecurityHeadersMiddleware
            "cors_configured": "corsheaders" in settings.INSTALLED_APPS,
            "csrf_protection": True,  # Always enabled in Django
        },
    }

    return JsonResponse(health_status)
