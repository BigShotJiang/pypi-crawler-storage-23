from typing import NamedTuple


class AuthInfo(NamedTuple):
    user_id: str
    tenant_id: str
