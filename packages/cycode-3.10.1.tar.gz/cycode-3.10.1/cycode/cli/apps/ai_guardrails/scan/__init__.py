# Prompt scan command for AI guardrails (hooks)
