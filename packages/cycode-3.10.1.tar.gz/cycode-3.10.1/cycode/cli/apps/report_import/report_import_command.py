import typer


def report_import_command(ctx: typer.Context) -> int:
    """:bar_chart: [bold cyan]Import security reports.[/]

    Example usage:
    * `cycode import sbom`: Import SBOM report
    """
    return 1
