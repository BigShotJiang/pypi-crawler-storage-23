"""
Server core business logic.

This module contains the core evaluation orchestration logic.
"""
