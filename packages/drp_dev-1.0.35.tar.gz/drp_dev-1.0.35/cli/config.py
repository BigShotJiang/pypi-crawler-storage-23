"""
CLI configuration — persistent settings stored in ~/.config/drp/config.toml.

    from cli import config
    cfg = config.load()
    cfg["host"]         # "https://drp.fyi"
    cfg["token"]        # bearer token (empty = not logged in)
    cfg["username"]     # logged-in user's name
    config.save(cfg)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

# ── Config path ───────────────────────────────────────────────────────────────

_CONFIG_DIR = Path(os.environ.get("DRP_CONFIG_DIR", ""))
if not _CONFIG_DIR.name:
    _CONFIG_DIR = Path.home() / ".config" / "drp"

CONFIG_FILE = _CONFIG_DIR / "config.toml"

_DEFAULTS: dict[str, Any] = {
    "host": "https://drp.fyi",
    "token": "",
    "username": "",
    "email": "",
}


# ── Load / save ───────────────────────────────────────────────────────────────

def load() -> dict[str, Any]:
    """Read config from disk.  Returns defaults if file doesn't exist."""
    cfg = dict(_DEFAULTS)
    if not CONFIG_FILE.exists():
        return cfg
    if sys.version_info >= (3, 11):
        import tomllib
    else:
        import tomli as tomllib  # type: ignore[no-redef]
    try:
        with open(CONFIG_FILE, "rb") as f:
            disk = tomllib.load(f)
        cfg.update(disk)
    except Exception:
        pass
    return cfg


def save(cfg: dict[str, Any]) -> None:
    """Write config to disk."""
    import tomli_w
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "wb") as f:
        tomli_w.dump(cfg, f)


def get(key: str, default: Any = None) -> Any:
    """Read a single config value."""
    return load().get(key, default)


def set_val(key: str, value: Any) -> None:
    """Write a single config value."""
    cfg = load()
    cfg[key] = value
    save(cfg)
