"""setkey — Rename a file's key."""

from . import Arg, Command, register

cmd = register(Command(
    name="setkey",
    description="Rename a file's key. The old key stops working immediately.",
    shell_only=True,
    args=(
        Arg("filename",
            "Current filename in the drive folder.",
            required=True),
        Arg("newkey",
            "New key. Format: [a-zA-Z0-9_-]{1,64}.",
            required=True),
    ),
))


def run(shell, args_str):
    """Rename a file's key."""
    import requests
    from cli.session import api_get, api_post, api_delete, is_logged_in

    if not is_logged_in():
        shell.poutput("not logged in — run 'login' first")
        return

    args = args_str.strip().split() if args_str.strip() else []
    if len(args) < 2:
        shell.poutput("usage: setkey <filename> <newkey>")
        return

    filename, newkey = args[0], args[1]

    # Resolve filename to current key
    path = shell.cwd.strip("/")
    params = {"path": path} if path else {}
    resp = api_get("/api/v1/folders/", params=params)
    old_key = None
    if resp.status_code == 200:
        for f in resp.json().get("files", []):
            if f.get("filename") == filename:
                old_key = f.get("key")
                break

    if not old_key:
        shell.poutput(f"  not found: {filename}")
        return

    # Download, re-upload with new key, delete old
    detail = api_get(f"/api/v1/keys/{old_key}/")
    if detail.status_code != 200:
        shell.poutput(f"  error: {detail.json().get('error', detail.status_code)}")
        return

    url = detail.json().get("download_url")
    if not url:
        shell.poutput("  error: no download URL")
        return

    r = requests.get(url)
    folder = shell.cwd.strip("/")
    resp2 = api_post("/api/v1/keys/",
                     files={"file": (filename, r.content)},
                     data={"folder": folder, "key": newkey})
    if resp2.status_code not in (200, 201):
        shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
        return

    api_delete(f"/api/v1/keys/{old_key}/")
    shell.poutput(f"  {old_key} → {newkey}")
