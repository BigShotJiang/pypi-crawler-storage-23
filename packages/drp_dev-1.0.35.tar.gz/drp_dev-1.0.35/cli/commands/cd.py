"""cd — Change the virtual working directory."""

from . import Arg, Command, register

cmd = register(Command(
    name="cd",
    description="Change the virtual working directory.",
    shell_only=True,
    args=(
        Arg("path",
            "Subfolder, .., /, or @username to browse another user's public drive.",
            required=True),
    ),
))


def run(shell, args_str):
    """Change the virtual working directory."""
    target = args_str.strip()
    if not target:
        shell.poutput("usage: cd <path>")
        return

    if target == "/":
        shell.cwd = "/"
        shell._update_prompt()
        return

    if target == "..":
        parts = [p for p in shell.cwd.strip("/").split("/") if p]
        if parts:
            parts.pop()
        shell.cwd = "/" + "/".join(parts)
        shell._update_prompt()
        return

    from cli.session import api_get, is_logged_in

    if not is_logged_in():
        shell.poutput("not logged in — run 'login' first")
        return

    # Build new path
    if target.startswith("/"):
        new_path = target.strip("/")
    else:
        current = shell.cwd.strip("/")
        new_path = f"{current}/{target}".strip("/")

    # Validate the folder exists on the server
    resp = api_get("/api/v1/folders/", params={"path": new_path})
    if resp.status_code != 200:
        shell.poutput(f"  folder not found: {target}")
        return

    shell.cwd = "/" + new_path
    shell._update_prompt()
