"""rm — Delete a file or folder."""

from . import Arg, Command, register

cmd = register(Command(
    name="rm",
    description="Delete a file or folder.",
    args=(
        Arg("ref",
            "Key, filename, or folder path to delete.",
            required=True),
        Arg("--recursive",
            "Required to delete a non-empty folder.",
            type="bool"),
    ),
))


def run(shell, args_str):
    """Delete a file or folder."""
    from cli.session import api_delete, api_get, is_logged_in

    if not is_logged_in():
        shell.poutput("not logged in — run 'login' first")
        return

    args = args_str.strip().split() if args_str.strip() else []
    if not args:
        shell.poutput("usage: rm <key|filename|folder> [--recursive]")
        return

    ref = args[0]
    recursive = "--recursive" in args or "-r" in args

    # Try as key first
    resp = api_delete(f"/api/v1/keys/{ref}/")
    if resp.status_code == 200:
        shell.poutput(f"  deleted key: {ref}")
        return

    # Try resolving as filename in current folder
    path = shell.cwd.strip("/")
    params = {"path": path} if path else {}
    ls_resp = api_get("/api/v1/folders/", params=params)
    if ls_resp.status_code == 200:
        data = ls_resp.json()
        # Check files
        for f in data.get("files", []):
            if f.get("filename") == ref and f.get("key"):
                resp2 = api_delete(f"/api/v1/keys/{f['key']}/")
                if resp2.status_code == 200:
                    shell.poutput(f"  deleted: {ref}")
                    return
                shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
                return
        # Check folders
        for folder in data.get("folders", []):
            if folder.get("name") == ref or folder.get("slug") == ref:
                url = f"/api/v1/folders/{folder['id']}/"
                if recursive:
                    url += "?recursive=true"
                resp2 = api_delete(url)
                if resp2.status_code == 200:
                    shell.poutput(f"  deleted folder: {ref}")
                    return
                shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
                return

    shell.poutput(f"  not found: {ref}")
