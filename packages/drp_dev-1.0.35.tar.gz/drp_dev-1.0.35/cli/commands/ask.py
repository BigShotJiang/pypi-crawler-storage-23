"""ask — Ask the drp help bot a question."""

from . import Arg, Command, register

cmd = register(Command(
    name="ask",
    description="Ask the drp help bot a question.",
    args=(
        Arg("question",
            "Your question, in quotes.",
            required=True),
    ),
))


def run(shell, args_str):
    """Ask the drp help bot a question."""
    from cli.session import api_post, is_logged_in

    if not is_logged_in():
        shell.poutput("not logged in — run 'login' first")
        return

    question = args_str.strip()
    if not question:
        shell.poutput("usage: ask <question>")
        return

    # Strip surrounding quotes if present
    if (question.startswith('"') and question.endswith('"')) or \
       (question.startswith("'") and question.endswith("'")):
        question = question[1:-1]

    resp = api_post("/api/v1/helpbot/", json={"question": question})
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    answer = resp.json().get("answer", "")
    shell.poutput(answer)
