"""setup — First-time configuration wizard."""

from . import Command, register

cmd = register(Command(
    name="setup",
    description="First-time configuration wizard. Sets server URL and writes config.",
))


def run(shell, args_str):
    """Interactive first-time setup."""
    from cli import config

    cfg = config.load()
    shell.poutput("drp setup")
    shell.poutput(f"  Current host: {cfg['host']}")

    try:
        host = input("  Server URL [enter to keep]: ").strip()
    except (EOFError, KeyboardInterrupt):
        shell.poutput("")
        return

    if host:
        if not host.startswith("http"):
            host = f"https://{host}"
        cfg["host"] = host.rstrip("/")

    config.save(cfg)
    shell.poutput(f"  Saved to {config.CONFIG_FILE}")
    shell.poutput("  Run 'drp login' to authenticate.")
