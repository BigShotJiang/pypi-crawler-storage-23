"""getkey — Print the key for a file looked up by filename."""

from . import Arg, Command, register

cmd = register(Command(
    name="getkey",
    description="Print the key for a file in the current drive folder.",
    shell_only=True,
    args=(
        Arg("filename",
            "Filename to look up.",
            required=True),
    ),
))


def run(shell, args_str):
    """Print the key for a file looked up by filename."""
    from cli.session import api_get, is_logged_in

    if not is_logged_in():
        shell.poutput("not logged in — run 'login' first")
        return

    filename = args_str.strip()
    if not filename:
        shell.poutput("usage: getkey <filename>")
        return

    path = shell.cwd.strip("/")
    params = {"path": path} if path else {}
    resp = api_get("/api/v1/folders/", params=params)
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    for f in resp.json().get("files", []):
        if f.get("filename") == filename:
            key = f.get("key", "")
            if key:
                shell.poutput(key)
            else:
                shell.poutput("  no key assigned")
            return

    shell.poutput(f"  not found: {filename}")
