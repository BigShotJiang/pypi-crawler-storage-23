"""cat — Display a file's content in the terminal with syntax highlighting."""

from . import Arg, Command, register

cmd = register(Command(
    name="cat",
    description="Display a file's content in the terminal with syntax highlighting.",
    args=(
        Arg("ref",
            "A key (xK9mZ2) or filename in the current drive folder (shell only).",
            required=True),
        Arg("--encryption-key",
            "Passphrase for client-side encrypted content. Decrypts in memory for display.",
            type="passphrase"),
        Arg("--parse",
            "Parse and pretty-print. JSON is formatted; CSV rendered as a table.",
            type="bool"),
        Arg("--field",
            "Extract a single field. JSON: dot-notation. CSV: column name or index. Implies --parse."),
        Arg("--highlight",
            "Force a syntax lexer, e.g. --highlight python. Overrides auto-detection."),
    ),
))


def run(shell, args_str):
    """Display a file's content in the terminal."""
    from cli.session import api_get, is_logged_in

    if not is_logged_in():
        shell.poutput("not logged in — run 'login' first")
        return

    args = args_str.strip().split() if args_str.strip() else []
    if not args:
        shell.poutput("usage: cat <key|filename>")
        return

    ref = args[0]

    # If it looks like a filename (has extension), resolve via ls
    key = ref
    if "." in ref and len(ref) > 6:
        key = _resolve_filename(shell, ref)
        if not key:
            key = ref  # fall back to using as key

    resp = api_get(f"/api/v1/keys/{key}/raw/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    content = data.get("content")
    if content is not None:
        shell.poutput(content)
    else:
        download_url = data.get("download_url")
        if download_url:
            shell.poutput(f"binary file — download with: get {key}")
        else:
            shell.poutput("error: no content available")


def _resolve_filename(shell, filename):
    """Look up a key by filename in the current folder."""
    from cli.session import api_get

    path = shell.cwd.strip("/")
    params = {"path": path} if path else {}
    resp = api_get("/api/v1/folders/", params=params)
    if resp.status_code != 200:
        return None
    for f in resp.json().get("files", []):
        if f.get("filename") == filename:
            return f.get("key")
    return None
