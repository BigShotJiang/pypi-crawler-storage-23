"""
Authenticated HTTP session for the CLI.

    from cli.session import api_get, api_post
    resp = api_get("/api/v1/ping/")
    resp = api_post("/api/v1/keys/", json={...})
"""

from __future__ import annotations

import requests

from cli import config


def _session() -> tuple[requests.Session, dict]:
    """Build a requests.Session with the bearer token (if any)."""
    cfg = config.load()
    s = requests.Session()
    token = cfg.get("token", "")
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    s.headers["User-Agent"] = f"drp-cli"
    return s, cfg


def api_url(path: str) -> str:
    """Resolve a relative API path to an absolute URL."""
    cfg = config.load()
    host = cfg.get("host", "https://drp.fyi").rstrip("/")
    if path.startswith("/"):
        return f"{host}{path}"
    return f"{host}/{path}"


def api_get(path: str, **kwargs) -> requests.Response:
    """GET an API endpoint with auth."""
    s, _ = _session()
    return s.get(api_url(path), **kwargs)


def api_post(path: str, **kwargs) -> requests.Response:
    """POST to an API endpoint with auth."""
    s, _ = _session()
    return s.post(api_url(path), **kwargs)


def api_delete(path: str, **kwargs) -> requests.Response:
    """DELETE an API endpoint with auth."""
    s, _ = _session()
    return s.delete(api_url(path), **kwargs)


def api_patch(path: str, **kwargs) -> requests.Response:
    """PATCH an API endpoint with auth."""
    s, _ = _session()
    return s.patch(api_url(path), **kwargs)


def is_logged_in() -> bool:
    """Check if a token is configured."""
    cfg = config.load()
    return bool(cfg.get("token"))


def save_session(token: str, username: str = "", email: str = "") -> None:
    """Persist auth credentials to config."""
    cfg = config.load()
    cfg["token"] = token
    if username:
        cfg["username"] = username
    if email:
        cfg["email"] = email
    config.save(cfg)


def clear_session() -> None:
    """Remove auth credentials from config."""
    cfg = config.load()
    cfg["token"] = ""
    cfg["username"] = ""
    cfg["email"] = ""
    config.save(cfg)
