"""Local LLM summarization."""
