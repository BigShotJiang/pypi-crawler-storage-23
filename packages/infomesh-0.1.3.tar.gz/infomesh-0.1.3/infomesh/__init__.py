"""InfoMesh — Fully decentralized P2P search engine for LLMs via MCP."""

from __future__ import annotations

__version__ = "0.1.3"
