"""Generaptor module"""
