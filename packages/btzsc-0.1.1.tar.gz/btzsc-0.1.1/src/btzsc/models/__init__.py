"""Model adapters for BTZSC benchmark evaluation."""

from btzsc.models.base import BaseModel

__all__ = [
    "BaseModel",
]
