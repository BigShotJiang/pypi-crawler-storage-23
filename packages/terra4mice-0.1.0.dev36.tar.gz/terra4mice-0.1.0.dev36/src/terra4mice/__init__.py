"""
terra4mice - State-Driven Development Framework

"El software no está listo cuando funciona,
 está listo cuando el state converge con el spec"
"""

__version__ = "0.1.0"
