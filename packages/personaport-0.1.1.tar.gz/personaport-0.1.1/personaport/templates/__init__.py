"""Jinja2 templates for migration outputs."""
