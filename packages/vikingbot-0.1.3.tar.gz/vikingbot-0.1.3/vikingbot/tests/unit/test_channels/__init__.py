"""Channel adapter tests."""
