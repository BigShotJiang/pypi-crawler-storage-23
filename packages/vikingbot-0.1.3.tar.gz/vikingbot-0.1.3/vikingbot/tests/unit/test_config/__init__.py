"""Configuration tests."""
