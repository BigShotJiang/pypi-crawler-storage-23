"""Vikingbot test suite."""
