from typing import Optional

from polars_units.core import BaseUnit, Unit
from polars_units.core._catalog import _KNOWN_UNITS
from polars_units.core._parsing import _parse_symbol_prefix, _parse_unit_string
from polars_units.core._prefixes import _PREFIX_FACTORS
from polars_units.utils.exceptions import UnitNotFoundError


class Registry:
    """Registry for managing units."""

    def __init__(self, units: Optional[list[BaseUnit]] = None):
        if units is None:
            units = []
        self._units = {unit.symbol: unit for unit in units}

    def register(self, unit: BaseUnit):
        """Register a new unit in the registry."""
        if unit.symbol in self._units:
            raise ValueError(f"Unit with symbol '{unit.symbol}' is already registered.")
        self._units[unit.symbol] = unit

    def get(self, symbol: str) -> Unit:
        """Retrieve a unit by its symbol."""

        components = {}

        for symbol_, exponent in _parse_unit_string(symbol).items():
            prefix, base_symbol = _parse_symbol_prefix(symbol_)

            unit = self._units.get(base_symbol)

            if unit is None:
                raise UnitNotFoundError(
                    f"Unit with symbol '{base_symbol}' not found in registry."
                )

            factor = _PREFIX_FACTORS[prefix]
            components[unit.derive(symbol_, factor, prefix=prefix)] = exponent

        return Unit(symbol, components)


class DefaultRegistry(Registry):
    """Default registry with known units."""

    def __init__(self, units: Optional[list[BaseUnit]] = None):
        if units is None:
            units = [BaseUnit(**unit) for unit in _KNOWN_UNITS]
        super().__init__(units)
