from typing import Optional

import regex

_PREFIXES = [
    "Y",
    "Z",
    "E",
    "P",
    "T",
    "G",
    "M",
    "k",
    "h",
    "da",
    "d",
    "c",
    "m",
    "µ",
    "n",
    "p",
    "f",
    "a",
    "z",
    "y",
]


def _parse_symbol_prefix(symbol: str) -> tuple[Optional[str], str]:
    """Parse a unit symbol into its prefix and base symbol components."""
    # Special case: kg is the SI base unit for mass
    if symbol == "kg":
        return None, "kg"

    for prefix in _PREFIXES:
        if prefix and symbol.startswith(prefix):
            # Disambiguation: only apply prefix if the remaining symbol is a
            # valid base unit (e.g. 'm' is meter but 'mm' is millimeter)
            if symbol == prefix:
                return None, symbol
            return prefix, symbol[len(prefix) :]

    return None, symbol


def _parse_symbol_exponent(symbol: str) -> tuple[str, int]:
    """Parse a unit symbol into its base unit and exponent components."""
    match = regex.fullmatch(r"([\p{L}°]+)(?:\^?(-?\d+))?", symbol)
    if not match:
        raise ValueError(f"Invalid unit symbol: {symbol}")

    base_symbol, exponent = match.groups()

    return base_symbol, int(exponent) if exponent else 1


def _parse_unit_string(symbol: str) -> dict[str, int]:
    """
    Parse a unit string into its component base units and their exponents. To be
    valid, a unit string must consist of base unit symbols (with optional
    prefixes and exponents) separated by `.` for multiplication and `/` for
    division.

    Example
    -------

    >>> _parse_unit_string("kg.m/s2")
    {'kg': 1, 'm': 1, 's': -2}
    """

    def _parse_component(component: str) -> tuple[str, str, str]:
        """Parse the rightmost component of a unit string to retrieve a base
        unit and the corresponding operator (`/` or `.`).

        Example
        -------
        >>> _parse_component("kg.m/s2")
        ('kg.m', '/', 's2')
        """
        character = "/" if component.rfind("/") > component.rfind(".") else "."
        return component.rpartition(character)

    components: dict[str, int] = {}

    while True:
        symbol, character, right = _parse_component(symbol)
        _symbol, exponent = _parse_symbol_exponent(right)

        if character == "/":
            exponent = -exponent

        components[_symbol] = components.get(_symbol, 0) + exponent

        if not symbol:
            break

    # Reversing the dict to match the order of the input
    return dict(reversed(components.items()))
