from typing import Optional, Self

from polars_units.core import Dimension
from polars_units.core._prefixes import _PREFIX_NAMES
from polars_units.utils.typings import UnitMetadata


class BaseUnit:
    """A base unit represents a single unit possibly with a prefix.

    `km` (kilometer), `A` (Ampere), `µT` (Tesla) are base units. `km/s`
    (kilometer per second) or `A/s` (Ampere per second) are not."""

    def __init__(
        self,
        symbol: str,
        formula: str | Dimension,
        prefix: str = None,
        name: Optional[str] = None,
        alias: Optional[str] = None,
        si_factor: float = 1.0,
        si_offset: float = 0.0,
    ):
        self.symbol = symbol
        self.formula = Dimension(formula)
        self.prefix = prefix
        self._name = name  # base name without prefix
        self.alias = alias

        self.si_factor = si_factor
        self.si_offset = si_offset

    @property
    def name(self) -> Optional[str]:
        if self._name:
            return _PREFIX_NAMES.get(self.prefix, "") + self._name

    def __str__(self):
        return self.symbol

    def __repr__(self):
        return (
            f"BaseUnit(symbol='{self.symbol}', formula='{self.formula}', "
            f"name='{self._name}', alias='{self.alias}', prefix='{self.prefix}', "
            f"si_factor={self.si_factor}, si_offset={self.si_offset})"
        )

    def derive(
        self,
        symbol: str,
        factor: float,
        offset: float = 0.0,
        prefix: Optional[str] = None,
    ) -> Self:
        """Return a new BaseUnit derived from this one with the given factor and offset."""
        return self.__class__(
            symbol=symbol,
            formula=self.formula,
            name=self.name,
            alias=self.alias,
            prefix=prefix,
            si_factor=self.si_factor * factor,
            si_offset=self.si_offset * factor + offset,
        )


class Unit:
    """A unit represented by its components."""

    def __init__(self, symbol: str, components: dict[BaseUnit, int]):
        self.symbol = symbol
        self._components = components

    def __str__(self):
        if not self._components:
            return "-"

        parts = []
        for base_unit, exponent in self._components.items():
            if exponent == 0:
                continue
            if exponent == 1:
                parts.append(f"{base_unit}")
            else:
                parts.append(f"{base_unit}^{exponent}")

        if not parts:
            return "-"

        return ".".join(parts)

    def __repr__(self):
        return f"Unit(components={self._components})"

    @property
    def dimension(self) -> Dimension:
        """Return the dimension of the unit."""
        components = {}
        for base_unit, u_exponent in self._components.items():
            for dimension, d_exponent in base_unit.formula._components.items():
                components[dimension] = (
                    components.get(dimension, 0) + d_exponent * u_exponent
                )

        # Remove null dimensions
        components = {dim: exp for dim, exp in components.items() if exp != 0}

        return Dimension(components)

    def serialize(self) -> UnitMetadata:
        """
        Serialize the unit to a dictionary for storage in Polars metadata.
        """
        return {
            "components": [
                {
                    "symbol": unit.symbol,
                    "exponent": exponent,
                    "si_factor": unit.si_factor,
                    "si_offset": unit.si_offset,
                }
                for unit, exponent in self._components.items()
            ],
            "symbol": str(self),
            "dimension": self.dimension.serialize(),
        }
