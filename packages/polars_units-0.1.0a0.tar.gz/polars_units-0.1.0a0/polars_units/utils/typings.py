from typing import TypedDict


class BaseUnitMetadata(TypedDict):
    """Metadata for base units stored in Polars extension type metadata."""

    symbol: str
    exponent: int
    si_factor: float
    si_offset: float


class UnitMetadata(TypedDict):
    """Metadata for units stored in Polars extension type metadata."""

    components: list[BaseUnitMetadata]
    dimension: dict[str, int]
