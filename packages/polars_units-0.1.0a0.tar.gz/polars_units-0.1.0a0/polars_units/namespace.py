from pathlib import Path

import polars as pl

from polars_units._config import config
from polars_units.core._units import Unit
from polars_units.extension import Quantity

_LIB = Path(__file__).parent


@pl.api.register_expr_namespace("unit")
class UnitExprNamespace:
    """Namespace for unit-related expression methods."""

    def __init__(self, expr: pl.Expr):
        self._expr = expr

    def symbol(self) -> pl.Expr:
        """Extract the unit symbol from a Quantity extension type column."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_symbol",
            args=self._expr,
            is_elementwise=True,
        )

    def to(self, target: str | Unit | Quantity):
        """Convert a column to another unit of the same dimension."""

        if isinstance(target, str):
            target = config.registry.get(target)
        elif isinstance(target, Quantity):
            target = target.unit

        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_convert",
            args=self._expr,
            kwargs={"target": target.serialize()},
            is_elementwise=True,
        )

    def add(self, other: pl.Expr) -> pl.Expr:
        """Add two quantity columns, converting the right operand to the left
        operand unit if necessary."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_add",
            args=[self._expr, other],
            is_elementwise=True,
        )

    def sub(self, other: pl.Expr) -> pl.Expr:
        """Subtract two quantity columns, converting the right operand to the left
        operand unit if necessary."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_sub",
            args=[self._expr, other],
            is_elementwise=True,
        )

    def mul(self, other: pl.Expr) -> pl.Expr:
        """Multiply two quantity columns, converting the right operand to the left
        operand unit if necessary."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_mul",
            args=[self._expr, other],
            is_elementwise=True,
        )
