"""Optional DataFrame extras — Arrow, pandas, polars conversions.

Implemented in Phase 6.
"""
from __future__ import annotations
