"""Fat-tailed and regime-switching return distributions."""
