"""Agentest web UI server."""
