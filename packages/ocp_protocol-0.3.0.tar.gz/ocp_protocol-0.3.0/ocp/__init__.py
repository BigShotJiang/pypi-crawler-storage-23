"""
OCP — Open Cognitive Protocol
Standardized benchmark for functional cognitive analogs in LLMs.
"""

__version__ = "0.3.0"
__author__ = "Pedja Urosevic"

# Public high-level API alias
from ocp.engine.orchestrator import OCPOrchestrator as CognitiveEvaluator

# Backward compatibility — deprecated, use CognitiveEvaluator
ConsciousnessEvaluator = CognitiveEvaluator
