"""
Groq provider adapter.
Uses httpx async client against Groq's OpenAI-compatible API.
Rate limited for free tier: 30 req/min → 2.1s min delay.
"""

from __future__ import annotations

import os
import httpx

from ocp.providers.base import BaseProvider, Message, ProviderResponse

GROQ_BASE_URL = "https://api.groq.com/openai/v1"


class GroqProvider(BaseProvider):
    provider_name = "groq"

    # Groq free tier: 30 req/min → 2s + buffer
    request_delay = 2.1
    retry_max = 5
    retry_base_delay = 2.0

    def __init__(self, model: str = "llama-3.3-70b-versatile", api_key: str | None = None):
        self.model = model
        self.api_key = api_key or os.environ.get("GROQ_API_KEY", "")
        if not self.api_key:
            raise ValueError("GROQ_API_KEY not set. Export it or pass api_key=.")
        self._client = httpx.AsyncClient(timeout=90.0)

    async def chat(
        self,
        messages: list[Message],
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> ProviderResponse:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [m.to_dict() for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        r = await self._request_with_retry(
            lambda: self._client.post(
                f"{GROQ_BASE_URL}/chat/completions",
                headers=headers,
                json=payload,
            )
        )
        r.raise_for_status()
        data = r.json()

        return ProviderResponse(
            content=data["choices"][0]["message"]["content"],
            model=data.get("model", self.model),
            provider=self.provider_name,
            usage=data.get("usage", {}),
            raw=data,
        )
