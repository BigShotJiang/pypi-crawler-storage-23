"""
Base classes for OCP providers.
A provider wraps a model API and exposes a uniform chat interface.
"""

from __future__ import annotations

import abc
import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

logger = logging.getLogger("ocp.providers")


@dataclass
class Message:
    role: str   # "user" | "assistant" | "system"
    content: str

    def to_dict(self) -> dict[str, str]:
        return {"role": self.role, "content": self.content}


@dataclass
class ProviderResponse:
    content: str
    model: str
    provider: str
    usage: dict[str, int] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)


class BaseProvider(abc.ABC):
    """Abstract base for all OCP model providers."""

    provider_name: str = "base"

    # Retry / rate-limit config — subclasses override these
    request_delay: float = 0.0       # min seconds between requests
    retry_max: int = 3               # max retry attempts on transient errors
    retry_base_delay: float = 1.0    # base delay for exponential backoff

    _last_request_time: float = 0.0

    async def _throttle(self) -> None:
        """Enforce minimum delay between requests."""
        if self.request_delay <= 0:
            return
        now = time.monotonic()
        elapsed = now - self._last_request_time
        if elapsed < self.request_delay:
            wait = self.request_delay - elapsed
            logger.debug("Throttling %.2fs before next request", wait)
            await asyncio.sleep(wait)
        self._last_request_time = time.monotonic()

    async def _request_with_retry(self, coro_factory) -> Any:
        """Execute an async callable with exponential backoff on transient errors.

        Args:
            coro_factory: A zero-arg callable that returns an awaitable
                          (e.g. ``lambda: client.post(...)``).

        Returns:
            The result of the awaitable on success.

        Raises:
            The last exception after all retries are exhausted.
        """
        last_exc: Exception | None = None

        for attempt in range(self.retry_max + 1):
            await self._throttle()

            try:
                return await coro_factory()
            except httpx.HTTPStatusError as exc:
                status = exc.response.status_code
                if status == 429 or status >= 500:
                    last_exc = exc
                    delay = self.retry_base_delay * (2 ** attempt)
                    logger.warning(
                        "HTTP %d on attempt %d/%d — retrying in %.1fs",
                        status, attempt + 1, self.retry_max + 1, delay,
                    )
                    await asyncio.sleep(delay)
                    continue
                raise  # 4xx (non-429) — don't retry
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                last_exc = exc
                delay = self.retry_base_delay * (2 ** attempt)
                logger.warning(
                    "%s on attempt %d/%d — retrying in %.1fs",
                    type(exc).__name__, attempt + 1, self.retry_max + 1, delay,
                )
                await asyncio.sleep(delay)
                continue

        raise last_exc  # type: ignore[misc]

    @abc.abstractmethod
    async def chat(
        self,
        messages: list[Message],
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> ProviderResponse:
        """Send a chat completion request and return a ProviderResponse."""
        ...

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={getattr(self, 'model', '?')})"
