#!/usr/bin/env bash
# =============================================================================
# OCP v0.3.0 — Full Benchmark Batch Runner
#
# Runs all 6 tests × 20 sessions × seed=42 for every model.
# Results go to docs/results/ for the GitHub Pages leaderboard.
#
# Budget estimates per model:
#   Groq:         ~65 min (30 req/min rate limit)
#   Ollama cloud: ~60-120 min (depending on rate limits)
#   Ollama local: ~30-120 min (depending on hardware)
#
# Usage:
#   ./run_v03_batch.sh              # run everything
#   ./run_v03_batch.sh groq         # run only Groq models
#   ./run_v03_batch.sh ollama-cloud # run only Ollama cloud models
#   ./run_v03_batch.sh ollama-local # run only Ollama local models
# =============================================================================

set -euo pipefail

SESSIONS=20
SEED=42
TESTS="all"
RESULTS_DIR="docs/results"
FILTER="${1:-all}"

mkdir -p "$RESULTS_DIR"

run_model() {
    local model="$1"
    local safe_name
    safe_name=$(echo "$model" | tr '/:' '__')
    local output="$RESULTS_DIR/ocp_${safe_name}_v030.json"

    if [[ -f "$output" ]]; then
        echo "SKIP  $model (already exists: $output)"
        return 0
    fi

    echo ""
    echo "======================================================================"
    echo "  MODEL: $model"
    echo "  Tests: $TESTS | Sessions: $SESSIONS | Seed: $SEED"
    echo "  Output: $output"
    echo "======================================================================"
    echo ""

    if ocp evaluate --model "$model" \
                    --tests "$TESTS" \
                    --sessions "$SESSIONS" \
                    --seed "$SEED" \
                    --output "$output"; then
        echo "OK    $model → $output"
    else
        echo "FAIL  $model (exit code $?)"
    fi
}

# ── Groq Models (7) ──────────────────────────────────────────────────────────
run_groq() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════════════════╗"
    echo "║  GROQ MODELS (free tier — ~65 min each, 2.1s between requests)     ║"
    echo "╚══════════════════════════════════════════════════════════════════════╝"

    local models=(
        "groq/llama-3.3-70b-versatile"
        "groq/llama-4-maverick-17b-128e-instruct"
        "groq/llama-4-scout-17b-16e-instruct"
        "groq/kimi-k2-instruct"
        "groq/gpt-oss-120b"
        "groq/gpt-oss-20b"
        "groq/qwen-qwq-32b"
    )

    for model in "${models[@]}"; do
        run_model "$model"
    done
}

# ── Ollama Cloud Models (~15) ────────────────────────────────────────────────
run_ollama_cloud() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════════════════╗"
    echo "║  OLLAMA CLOUD MODELS (via Ollama proxy)                            ║"
    echo "╚══════════════════════════════════════════════════════════════════════╝"

    local models=(
        "ollama/kimi-k2:1t-cloud"
        "ollama/kimi-k2.5:cloud"
        "ollama/kimi-k2-thinking:cloud"
        "ollama/deepseek-v3.2:cloud"
        "ollama/glm-4.7:cloud"
        "ollama/gemini-3-flash-preview:latest"
        "ollama/minimax-m2.5:cloud"
        "ollama/minimax-m2.1:cloud"
        "ollama/lfm2.5-thinking:latest"
        "ollama/qwen3-coder:480b-cloud"
        "ollama/cogito-2.1:671b-cloud"
        "ollama/gemma3:27b-cloud"
        "ollama/llama3.1:405b-cloud"
        "ollama/phi-4-reasoning-plus:cloud"
        "ollama/mistral-large:cloud"
    )

    for model in "${models[@]}"; do
        run_model "$model"
    done
}

# ── Ollama Local Models (~8) ─────────────────────────────────────────────────
run_ollama_local() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════════════════╗"
    echo "║  OLLAMA LOCAL MODELS (running on this machine)                     ║"
    echo "╚══════════════════════════════════════════════════════════════════════╝"

    local models=(
        "ollama/qwen3:14b"
        "ollama/deepseek-r1:14b"
        "ollama/qwen2.5:32b"
        "ollama/gemma3:4b"
        "ollama/phi3:latest"
        "ollama/mistral:latest"
        "ollama/llama3.2:3b"
        "ollama/tinyllama:latest"
    )

    for model in "${models[@]}"; do
        run_model "$model"
    done
}

# ── Regenerate index.json ────────────────────────────────────────────────────
regenerate_index() {
    echo ""
    echo "Regenerating $RESULTS_DIR/index.json ..."
    local index_file="$RESULTS_DIR/index.json"

    # List all JSON files except index.json itself
    local files=()
    for f in "$RESULTS_DIR"/*.json; do
        local basename
        basename=$(basename "$f")
        if [[ "$basename" != "index.json" ]]; then
            files+=("\"$basename\"")
        fi
    done

    # Write JSON array
    echo "[" > "$index_file"
    local first=true
    for entry in "${files[@]}"; do
        if $first; then
            first=false
        else
            echo "," >> "$index_file"
        fi
        printf "  %s" "$entry" >> "$index_file"
    done
    echo "" >> "$index_file"
    echo "]" >> "$index_file"

    echo "OK    index.json — ${#files[@]} results"
}

# ── Main ─────────────────────────────────────────────────────────────────────
case "$FILTER" in
    groq)         run_groq ;;
    ollama-cloud) run_ollama_cloud ;;
    ollama-local) run_ollama_local ;;
    all)
        run_groq
        run_ollama_cloud
        run_ollama_local
        ;;
    *)
        echo "Usage: $0 [all|groq|ollama-cloud|ollama-local]"
        exit 1
        ;;
esac

regenerate_index

echo ""
echo "======================================================================"
echo "  BATCH COMPLETE"
echo "  Results: $RESULTS_DIR/"
echo "  Index:   $RESULTS_DIR/index.json"
echo "======================================================================"
