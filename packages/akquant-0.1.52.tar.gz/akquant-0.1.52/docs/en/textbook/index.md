# Textbook: Quantitative Investment from Theory to Practice

*This textbook is currently available in Chinese only. English translation is planned for future releases.*

Please refer to the [Chinese Version](../../textbook/index.md) for the full content.
