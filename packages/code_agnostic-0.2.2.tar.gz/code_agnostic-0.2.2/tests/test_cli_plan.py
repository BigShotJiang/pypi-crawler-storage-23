from pathlib import Path

from code_agnostic.__main__ import cli


def test_plan_shows_invalid_json_error_for_mcp_base(
    minimal_shared_config: Path, core_root: Path, cli_runner, enable_app
) -> None:
    enable_app("opencode")
    (core_root / "config" / "mcp.base.json").write_text("{bad", encoding="utf-8")

    result = cli_runner.invoke(cli, ["plan"])

    assert result.exit_code != 0
    assert "Invalid JSON format" in result.output


def test_plan_target_cursor_excludes_workspace_actions(
    minimal_shared_config: Path,
    tmp_path: Path,
    core_root: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")

    workspace_root = tmp_path / "team-workspace"
    workspace_root.mkdir()
    (workspace_root / "service-a" / ".git").mkdir(parents=True)

    add_result = cli_runner.invoke(
        cli, ["workspaces", "add", "--name", "team", "--path", str(workspace_root)]
    )
    assert add_result.exit_code == 0

    ws_config_dir = core_root / "workspaces" / "team"
    (ws_config_dir / "rules").mkdir(parents=True, exist_ok=True)
    (ws_config_dir / "rules" / "shared.md").write_text("rules", encoding="utf-8")

    plan_result = cli_runner.invoke(cli, ["plan", "-a", "cursor"])
    assert plan_result.exit_code == 0
    assert "cursor" in plan_result.output
    assert "workspace config sync" not in plan_result.output


def test_plan_with_no_apps_enabled(minimal_shared_config: Path, cli_runner) -> None:
    result = cli_runner.invoke(cli, ["plan"])

    assert result.exit_code == 0


def test_plan_target_opencode_when_not_enabled(
    minimal_shared_config: Path, cli_runner
) -> None:
    result = cli_runner.invoke(cli, ["plan", "-a", "opencode"])

    assert result.exit_code == 0


def test_plan_missing_mcp_base_json(tmp_path: Path, cli_runner, enable_app) -> None:
    core_root = tmp_path / ".config" / "code-agnostic"
    core_root.mkdir(parents=True, exist_ok=True)

    result = cli_runner.invoke(cli, ["plan"])

    assert result.exit_code == 0


def test_plan_default_view_shows_app_labels_not_paths(
    minimal_shared_config: Path, cli_runner, enable_app
) -> None:
    enable_app("cursor")

    result = cli_runner.invoke(cli, ["plan", "-a", "cursor"])

    assert result.exit_code == 0
    assert "Code Agnostic" in result.output
    assert "Cursor" in result.output
    assert "Source Path" not in result.output
    assert "Target Path" not in result.output


def test_plan_verbose_view_shows_path_columns_with_home_shorthand(
    minimal_shared_config: Path, cli_runner, enable_app
) -> None:
    enable_app("cursor")

    result = cli_runner.invoke(cli, ["plan", "-a", "cursor", "-v"])

    assert result.exit_code == 0
    assert "Path" in result.output
    assert "~/" in result.output
