"""WL-APDP Python SDK.

A Python SDK for integrating wl-apdp authorization into any agentic AI system.
Framework-agnostic core with optional integrations for popular platforms.

Basic Usage:
    >>> from wl_apdp import WlApdpClient, AuthorizationContext, authorization_context
    >>>
    >>> # Set up authorization context
    >>> ctx = AuthorizationContext(
    ...     principal="agent-123",
    ...     principal_type="Agent",
    ...     tenant_id="tenant-abc"
    ... )
    >>>
    >>> # Check authorization
    >>> async with WlApdpClient() as client:
    ...     async with authorization_context(ctx):
    ...         result = await client.authorize(
    ...             principal=ctx.to_cedar_principal(),
    ...             action='Action::"execute"',
    ...             resource='Tool::"web_search"',
    ...             context=ctx.to_context_dict()
    ...         )
    ...         print(result.decision)  # "Allow" or "Deny"

Tool Authorization:
    >>> from wl_apdp import authorized_tool, authorization_context, AuthorizationContext
    >>>
    >>> @authorized_tool(resource='Tool::"calculator"', action="execute")
    ... def calculate(expression: str) -> float:
    ...     return eval(expression)
    >>>
    >>> with authorization_context(AuthorizationContext(principal="agent-1", principal_type="Agent")):
    ...     result = calculate("2 + 2")

Executor Pattern:
    >>> from wl_apdp import AuthorizedExecutor
    >>>
    >>> executor = AuthorizedExecutor(
    ...     principal_id="agent-123",
    ...     principal_type="Agent"
    ... )
    >>>
    >>> if executor.can_execute("web_search"):
    ...     result = search_tool.run(query)
"""

from .client import WlApdpClient, WlApdpSyncClient
from .context import (
    AuthorizationContext,
    authorization_context,
    get_current_context,
    require_context,
    set_current_context,
)
from .decorators import (
    audit_action,
    authorize,
    optional_authorization,
    require_authorization,
)
from .exceptions import (
    AgentQuarantined,
    # Trust-related exceptions (for trust-gated guidance access control)
    AgentTrustError,
    AgentTrustRevoked,
    AgentUnverified,
    AuthorizationDenied,
    ConfigurationError,
    ServiceUnavailable,
    TokenError,
    ValidationError,
    # Base exceptions
    WlApdpError,
)
from .executor import AsyncAuthorizedExecutor, AuthorizedExecutor
from .manifest import fetch_agent_manifest, format_manifest_for_prompt
from .models import (
    # Constraint manifest models
    AgentContext,
    AgentGuidance,
    # Core authorization models
    AuthorizationRequest,
    AuthorizationResponse,
    CapabilitiesQuery,
    CapabilitiesResponse,
    Capability,
    ConstraintManifest,
    ConstraintSet,
    Decision,
    DynamicLimits,
    EffectiveScope,
    EscalationDetails,
    EscalationRule,
    ForbiddenAction,
    GoalContext,
    HealthResponse,
    IntentActionMapping,
    IntentDeclaration,
    Policy,
    PolicyAnalysis,
    PreflightIssue,
    PreflightRequest,
    PreflightResponse,
    PrincipalType,
    RequiredContext,
    ResourcePattern,
    RiskLevel,
    Suggestion,
    TrustState,
    cedar_action,
    cedar_principal,
    cedar_resource,
)
from .registry import AgentRegistry, JobMapping
from .resolver import TenantResolver
from .tools import AuthorizedCallable, authorized_tool, authorized_tool_async

__version__ = "0.2.0"

__all__ = [
    # Version
    "__version__",
    # Clients
    "WlApdpClient",
    "WlApdpSyncClient",
    # Context
    "AuthorizationContext",
    "authorization_context",
    "get_current_context",
    "set_current_context",
    "require_context",
    # Decorators
    "authorize",
    "audit_action",
    "require_authorization",
    "optional_authorization",
    # Exceptions
    "WlApdpError",
    "AuthorizationDenied",
    "ServiceUnavailable",
    "ConfigurationError",
    "ValidationError",
    "TokenError",
    # Trust-related exceptions (trust-gated guidance access control)
    "AgentTrustError",
    "AgentTrustRevoked",
    "AgentQuarantined",
    "AgentUnverified",
    # Executor
    "AuthorizedExecutor",
    "AsyncAuthorizedExecutor",
    # Core Models
    "PrincipalType",
    "Decision",
    "AuthorizationRequest",
    "AuthorizationResponse",
    "PolicyAnalysis",
    "HealthResponse",
    "Policy",
    "cedar_principal",
    "cedar_action",
    "cedar_resource",
    # Constraint Manifest Models
    "AgentContext",
    "AgentGuidance",
    "CapabilitiesQuery",
    "CapabilitiesResponse",
    "Capability",
    "ConstraintManifest",
    "ConstraintSet",
    "DynamicLimits",
    "EffectiveScope",
    "EscalationDetails",
    "EscalationRule",
    "ForbiddenAction",
    "GoalContext",
    "IntentActionMapping",
    "IntentDeclaration",
    "PreflightIssue",
    "PreflightRequest",
    "PreflightResponse",
    "RequiredContext",
    "ResourcePattern",
    "RiskLevel",
    "Suggestion",
    "TrustState",
    # Tools
    "authorized_tool",
    "authorized_tool_async",
    "AuthorizedCallable",
    # Registry & Job Mapping
    "AgentRegistry",
    "JobMapping",
    "TenantResolver",
    # Manifest Utilities
    "fetch_agent_manifest",
    "format_manifest_for_prompt",
]
