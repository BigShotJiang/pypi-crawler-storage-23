"""Contrib modules for framework-specific integrations."""
