"""OpenFeature provider for Flagr."""

from __future__ import annotations

import logging
import threading
from typing import Callable, Optional, Union

from openfeature.evaluation_context import EvaluationContext
from openfeature.exception import FlagNotFoundError
from openfeature.flag_evaluation import FlagResolutionDetails, Reason
from openfeature.hook import Hook
from openfeature.provider.metadata import Metadata
from openfeature.provider.no_op_provider import AbstractProvider

from .client import FlagrClient, FlagValue

logger = logging.getLogger(__name__)


class Subscription:
    """Returned by `FlagrProvider.on_change`. Holds an active flag listener."""

    def __init__(self, unsubscribe_fn: Callable[[], None]) -> None:
        self._unsubscribe = unsubscribe_fn

    def unsubscribe(self) -> None:
        """Stop receiving updates."""
        self._unsubscribe()

    def wait(self) -> None:
        """Block until Ctrl+C, then unsubscribe automatically."""
        try:
            threading.Event().wait()
        except KeyboardInterrupt:
            pass
        finally:
            self.unsubscribe()

    def __enter__(self) -> "Subscription":
        return self

    def __exit__(self, *_: object) -> None:
        self.unsubscribe()


def _resolve(val: FlagValue, tenant_id: str) -> bool:
    """Resolve a cached FlagValue to a boolean for the given tenant."""
    if val.state == "enabled":
        return True
    if val.state == "partially_enabled":
        return tenant_id in val.enabled_list
    return False


class FlagrProvider(AbstractProvider):
    """
    Feature flag provider for Flagr. Connects via SSE, caches flags locally,
    and resolves every evaluation without a network call.

    Simple usage::

        from flagr import FlagrProvider

        provider = FlagrProvider(sdk_key="sdk_live_xxx")

        # one-shot evaluation
        enabled = provider.evaluate("new-checkout", tenant_id="user-123")

        # reactive — callback fires immediately and on every change
        unsubscribe = provider.on_change(
            "new-checkout",
            tenant_id="user-123",
            callback=lambda value: print(f"new-checkout is now {value}"),
        )

    OpenFeature usage::

        from openfeature import api
        from flagr import FlagrProvider

        api.set_provider(FlagrProvider(sdk_key="sdk_live_xxx"))
    """

    def __init__(self, sdk_key: str, base_url: str = "https://api.flagr.dev") -> None:
        self._client = FlagrClient(sdk_key, base_url)
        self._lock = threading.RLock()
        self._cache: dict[str, FlagValue] = {}
        self._subscribers: dict[str, list[tuple[str, Callable[[bool], None], bool]]] = {}
        self._connected = False
        self._connect()

    def _connect(self) -> None:
        if self._connected:
            return
        self._connected = True
        self._client.connect(
            on_snapshot=self._on_snapshot,
            on_update=self._on_update,
        )

    # ── Public API ─────────────────────────────────────────────────────────

    def evaluate(self, flag_key: str, tenant_id: str, default_value: bool = False) -> bool:
        """Evaluate a boolean flag. Returns default_value if the flag is not found."""
        try:
            return _resolve(self._get(flag_key), tenant_id)
        except FlagNotFoundError:
            return default_value

    def on_change(
        self,
        flag_key: str,
        tenant_id: str,
        callback: Callable[[bool], None],
        default_value: bool = False,
    ) -> Subscription:
        """
        Register a callback that fires immediately with the current flag value,
        then again whenever the flag changes. Uses the existing SSE connection —
        no new connection is made.

        Returns a `Subscription`. Call `.wait()` to block until Ctrl+C, or
        `.unsubscribe()` to stop manually.

        Examples::

            # Block until Ctrl+C
            provider.on_change("dark-mode", "user-123", lambda v: apply_theme(v)).wait()

            # Manual unsubscribe
            sub = provider.on_change("dark-mode", "user-123", lambda v: apply_theme(v))
            sub.unsubscribe()

            # Context manager
            with provider.on_change("dark-mode", "user-123", lambda v: apply_theme(v)):
                do_something()
        """
        entry = (tenant_id, callback, default_value)
        with self._lock:
            self._subscribers.setdefault(flag_key, []).append(entry)

        callback(self.evaluate(flag_key, tenant_id, default_value))

        def _unsubscribe() -> None:
            with self._lock:
                subs = self._subscribers.get(flag_key, [])
                try:
                    subs.remove(entry)
                except ValueError:
                    pass

        return Subscription(_unsubscribe)

    # ── OpenFeature lifecycle ──────────────────────────────────────────────

    def get_metadata(self) -> Metadata:
        return Metadata(name="flagr")

    def get_provider_hooks(self) -> list[Hook]:
        return []

    def initialize(self, evaluation_context: Optional[EvaluationContext] = None) -> None:
        self._connect()

    def shutdown(self) -> None:
        self._client.close()

    # ── OpenFeature flag resolution ────────────────────────────────────────

    def resolve_boolean_details(
        self,
        flag_key: str,
        default_value: bool,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[bool]:
        val = self._get(flag_key)
        tenant_id = (evaluation_context.targeting_key or "") if evaluation_context else ""
        return FlagResolutionDetails(
            value=_resolve(val, tenant_id),
            reason=Reason.TARGETING_MATCH if val.state == "partially_enabled" else Reason.STATIC,
        )

    def resolve_string_details(
        self,
        flag_key: str,
        default_value: str,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[str]:
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    def resolve_integer_details(
        self,
        flag_key: str,
        default_value: int,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[int]:
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    def resolve_float_details(
        self,
        flag_key: str,
        default_value: float,
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[float]:
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    def resolve_object_details(
        self,
        flag_key: str,
        default_value: Union[dict, list],  # type: ignore[type-arg]
        evaluation_context: Optional[EvaluationContext] = None,
    ) -> FlagResolutionDetails[Union[dict, list]]:  # type: ignore[type-arg]
        return FlagResolutionDetails(value=default_value, reason=Reason.DEFAULT)

    # ── internals ─────────────────────────────────────────────────────────

    def _get(self, flag_key: str) -> FlagValue:
        with self._lock:
            val = self._cache.get(flag_key)
        if val is None:
            raise FlagNotFoundError(f"Flag '{flag_key}' not found")
        return val

    def _on_snapshot(self, flags: dict[str, FlagValue]) -> None:
        with self._lock:
            self._cache.update(flags)

    def _on_update(self, flag_key: str, value: FlagValue) -> None:
        with self._lock:
            self._cache[flag_key] = value
            subscribers = list(self._subscribers.get(flag_key, []))
        for tenant_id, callback, default_value in subscribers:
            try:
                callback(_resolve(value, tenant_id))
            except Exception:
                logger.exception("Flagr: on_change callback raised for flag %r", flag_key)
