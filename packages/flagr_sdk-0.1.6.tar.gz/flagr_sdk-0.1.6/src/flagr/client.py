"""SSE client — connects to the Flagr evaluation stream."""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Callable

import httpx
from httpx_sse import connect_sse

logger = logging.getLogger(__name__)

FlagState = str  # "enabled" | "disabled" | "partially_enabled"


class AuthenticationError(Exception):
    """Raised when the SDK key is rejected by the Flagr API (HTTP 401)."""


class FlagValue:
    __slots__ = ("state", "enabled_list")

    def __init__(self, state: FlagState, enabled_list: list[str]) -> None:
        self.state = state
        self.enabled_list = enabled_list

    @classmethod
    def from_dict(cls, d: dict) -> "FlagValue":  # type: ignore[type-arg]
        return cls(
            state=d.get("state", "disabled"),
            enabled_list=d.get("enabled_list") or [],
        )


OnSnapshot = Callable[[dict[str, FlagValue]], None]
OnUpdate = Callable[[str, FlagValue], None]


class FlagrClient:
    """
    Connects to the Flagr SSE stream, seeds the local cache from the
    `init` snapshot, and calls `on_update` for every `flag_update` event.

    The connection runs in a daemon thread and reconnects automatically on
    any error.
    """

    def __init__(self, sdk_key: str, base_url: str) -> None:
        self.sdk_key = sdk_key
        self.base_url = base_url.rstrip("/")
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def connect(
        self,
        on_snapshot: OnSnapshot,
        on_update: OnUpdate,
    ) -> None:
        """
        Start the background SSE thread. Blocks until the initial snapshot
        has been received (or raises on connection failure).
        """
        ready = threading.Event()
        error: list[Exception] = []

        def _snapshot_once(flags: dict[str, FlagValue]) -> None:
            on_snapshot(flags)
            ready.set()

        self._thread = threading.Thread(
            target=self._stream_loop,
            args=(_snapshot_once, on_update, error),
            daemon=True,
            name="flagr-sse",
        )
        self._thread.start()

        # Wait up to 10 seconds for the init snapshot.
        if not ready.wait(timeout=10):
            if error:
                raise error[0]
            raise TimeoutError("Flagr: timed out waiting for initial flag snapshot")

    def close(self) -> None:
        """Stop the background SSE thread."""
        self._stop.set()

    # ── internals ──────────────────────────────────────────────────────────

    def _stream_loop(
        self,
        on_snapshot: OnSnapshot,
        on_update: OnUpdate,
        error_out: list[Exception],
    ) -> None:
        snapshot_sent = False
        while not self._stop.is_set():
            try:
                self._connect_once(on_snapshot if not snapshot_sent else None, on_update)
                snapshot_sent = True
            except AuthenticationError as exc:
                # Invalid SDK key — no point retrying.
                error_out.append(exc)
                return
            except Exception as exc:
                if not snapshot_sent:
                    error_out.append(exc)
                    return
                logger.warning("Flagr SSE error, reconnecting in 5s: %s", exc)
            if not self._stop.is_set():
                time.sleep(5)

    def _connect_once(
        self,
        on_snapshot: OnSnapshot | None,
        on_update: OnUpdate,
    ) -> None:
        url = f"{self.base_url}/evaluate/stream"
        headers = {
            "Authorization": f"Bearer {self.sdk_key}",
            "Accept": "text/event-stream",
            "Cache-Control": "no-cache",
        }

        with httpx.Client(timeout=None) as client:
            with connect_sse(client, "GET", url, headers=headers) as event_source:
                if event_source.response.status_code == 401:
                    raise AuthenticationError(
                        "Flagr: invalid SDK key — check your sdk_key and try again"
                    )
                event_source.response.raise_for_status()
                for sse in event_source.iter_sse():
                    if self._stop.is_set():
                        return

                    if sse.event == "init" and on_snapshot is not None:
                        raw: dict[str, dict] = json.loads(sse.data)  # type: ignore[type-arg]
                        flags = {k: FlagValue.from_dict(v) for k, v in raw.items()}
                        on_snapshot(flags)
                        on_snapshot = None  # Only call once.

                    elif sse.event == "flag_update":
                        msg = json.loads(sse.data)
                        on_update(
                            msg["flag_key"],
                            FlagValue(
                                state=msg.get("state", "disabled"),
                                enabled_list=msg.get("enabled_list") or [],
                            ),
                        )
