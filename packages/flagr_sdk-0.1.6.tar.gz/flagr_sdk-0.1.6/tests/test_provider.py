"""Unit tests for FlagrProvider — no real network calls."""

import threading
from unittest.mock import MagicMock, patch

import pytest
from openfeature.evaluation_context import EvaluationContext
from openfeature.exception import FlagNotFoundError

from flagr.client import FlagValue
from flagr.provider import FlagrProvider


def make_provider() -> FlagrProvider:
    p = FlagrProvider.__new__(FlagrProvider)
    p._lock = threading.RLock()
    p._cache = {}
    p._client = MagicMock()
    return p


def test_enabled_flag_returns_true():
    p = make_provider()
    p._cache["my-flag"] = FlagValue("enabled", [])
    result = p.resolve_boolean_details("my-flag", False)
    assert result.value is True


def test_disabled_flag_returns_false():
    p = make_provider()
    p._cache["my-flag"] = FlagValue("disabled", [])
    result = p.resolve_boolean_details("my-flag", True)
    assert result.value is False


def test_partial_flag_enabled_for_tenant_in_list():
    p = make_provider()
    p._cache["my-flag"] = FlagValue("partially_enabled", [
        "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        "b2c3d4e5-f6a7-8901-bcde-f01234567891",
    ])
    ctx = EvaluationContext(targeting_key="a1b2c3d4-e5f6-7890-abcd-ef1234567890")
    result = p.resolve_boolean_details("my-flag", False, ctx)
    assert result.value is True


def test_partial_flag_disabled_for_tenant_not_in_list():
    p = make_provider()
    p._cache["my-flag"] = FlagValue("partially_enabled", [
        "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        "b2c3d4e5-f6a7-8901-bcde-f01234567891",
    ])
    ctx = EvaluationContext(targeting_key="c3d4e5f6-a7b8-9012-cdef-012345678912")
    result = p.resolve_boolean_details("my-flag", True, ctx)
    assert result.value is False


def test_unknown_flag_raises():
    p = make_provider()
    with pytest.raises(FlagNotFoundError):
        p.resolve_boolean_details("nonexistent", False)


def test_snapshot_populates_cache():
    p = make_provider()
    snapshot = {
        "flag-a": FlagValue("enabled", []),
        "flag-b": FlagValue("disabled", []),
    }
    p._on_snapshot(snapshot)
    assert p._cache["flag-a"].state == "enabled"
    assert p._cache["flag-b"].state == "disabled"


def test_update_overwrites_cache():
    p = make_provider()
    p._cache["flag-a"] = FlagValue("disabled", [])
    p._on_update("flag-a", FlagValue("enabled", []))
    assert p._cache["flag-a"].state == "enabled"
