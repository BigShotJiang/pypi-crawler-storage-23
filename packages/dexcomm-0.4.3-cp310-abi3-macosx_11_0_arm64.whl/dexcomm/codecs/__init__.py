# Copyright (c) 2026 Dexmate
#
# 1. GNU Affero General Public License v3.0 (AGPL-3.0)
#    See LICENSE-AGPL for details
#

"""Data type codecs for DexComm.

This module provides high-performance encoding/decoding using a unified class-based API.

All codecs follow the same pattern: DataType.encode() and DataType.decode()

Basic Codecs:
-------------
- AutoData.encode/decode - Automatic type detection and serialization
- BasicData.encode/decode - Compact primitive encoding (pure Rust, most efficient)
- JsonData.encode/decode - orjson (2-10x faster than standard json)
- PickleData.encode/decode - Python pickle protocol 5 (fastest for mixed types)
- NumpyArrayCodec.encode/decode - Optimized binary format (5-10x faster than pickle for small arrays)
- DictData.encode/decode - orjson (4x faster than msgpack)

Sensor Data Codecs:
-------------------
- RGBImageCodec.encode/decode - RGB/BGR/Grayscale images with JPEG/PNG compression
- DepthImageCodec.encode/decode - Depth images with PNG compression
- IMUDataCodec.encode/decode - IMU sensor data (protobuf)
- LidarScan2DCodec.encode/decode - 2D LiDAR scans (protobuf)

Control Message Codecs:
------------------------
- JointState.encode/decode - Unified joint state (pos, vel, torque, cur)
- JointCmd.encode/decode - Unified joint command (pos, vel, torque, cur)
- (... 20+ other control message types)

Examples:
---------
    >>> from dexcomm.codecs import JsonDataCodec, NumpyArrayCodec, RGBImageCodec
    >>> import numpy as np
    >>>
    >>> # JSON serialization (human-readable, fast)
    >>> json_data = {"status": "ok", "count": 42}
    >>> encoded = JsonDataCodec.encode(json_data)
    >>> decoded = JsonDataCodec.decode(encoded)
    >>>
    >>> # Numpy array serialization (ultra-fast for small arrays)
    >>> arr = np.array([1, 2, 3, 4, 5], dtype=np.float32)
    >>> encoded = NumpyArrayCodec.encode(arr)
    >>> decoded = NumpyArrayCodec.decode(encoded)
    >>>
    >>> # RGB image compression (JPEG/PNG)
    >>> image = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
    >>> data = {"height": 480, "width": 640, "data": image, "encoding": "jpeg"}
    >>> encoded = RGBImageCodec.encode(data)
    >>> decoded = RGBImageCodec.decode(encoded)

Performance Guide:
------------------
- For pure numpy arrays: NumpyArrayCodec (5-10x faster for small arrays, similar for large)
- For mixed types: PickleDataCodec (fastest for dicts/lists/objects)
- For compression: NumpyArrayCodec with compress=True (saves bandwidth)
- For images: RGBImageCodec/DepthImageCodec (optimized JPEG/PNG encoding)
- For dicts: DictDataCodec (fastest dict serialization using orjson)
- For human-readable: JsonDataCodec (orjson - fast and readable)

"""

# Image serialization - optimized native implementation (if feature enabled)
try:
    from dexcomm._core import (
        DepthImageCodec,
        RGBImageCodec,
    )

    _HAS_IMAGE_SUPPORT = True
except ImportError:
    _HAS_IMAGE_SUPPORT = False

# Python codec implementations
# New codec architecture - Pure Rust implementations with Python bindings
from dexcomm._core import (
    BaseLEDCmdCodec,
    BaseLEDStateCodec,
    # Basic data type codec (unified)
    BasicDataCodec,
    # Sensor codecs
    BMSStateCodec,
    ClearErrorCodec,
    # End effector codecs
    EEPassThroughCmdCodec,
    EStopStateCodec,
    FingertipForceCodec,
    IMUBatchCodec,
    IMUDataCodec,
    JointCmdCodec,
    JointModeCodec,
    # Joint control codecs
    JointStateCodec,
    Lidar3DCodec,
    LidarBatchCodec,
    LidarScan2DCodec,
    # Utility codecs
    NTPRequestCodec,
    NTPResponseCodec,
    RebootComponentCodec,
    RobotComponentStatesCodec,
    RobotVersionCodec,
    # Robot system codecs
    SoftwareEstopCodec,
    UltrasonicStateCodec,
    WrenchStateCodec,
    WristButtonStateCodec,
)
from dexcomm.codecs.basic_codecs import (
    DictDataCodec,
    JsonDataCodec,
    NumpyArrayCodec,
    PickleDataCodec,
)

# Protobuf enum constants for easy access
from dexcomm.codecs.enums import (
    BaseLEDSideEnum,
    ConnectionStatusEnum,
    ErrorSeverityEnum,
    JointModeEnum,
    OperationalStatusEnum,
    PriorityEnum,
    RobotComponentEnum,
)

__all__ = [
    # Python codec classes
    "JsonDataCodec",
    "PickleDataCodec",
    "NumpyArrayCodec",
    "DictDataCodec",
    # Joint control codecs
    "JointStateCodec",
    "JointCmdCodec",
    "JointModeCodec",
    # Robot system codecs
    "SoftwareEstopCodec",
    "EStopStateCodec",
    "ClearErrorCodec",
    "RebootComponentCodec",
    "RobotVersionCodec",
    "RobotComponentStatesCodec",
    "BaseLEDCmdCodec",
    "BaseLEDStateCodec",
    "WristButtonStateCodec",
    # Sensor codecs
    "BMSStateCodec",
    "WrenchStateCodec",
    "FingertipForceCodec",
    "UltrasonicStateCodec",
    "IMUDataCodec",
    "IMUBatchCodec",
    "LidarScan2DCodec",
    "LidarBatchCodec",
    "Lidar3DCodec",
    # Utility codecs
    "NTPRequestCodec",
    "NTPResponseCodec",
    # Basic data type codec (unified)
    "BasicDataCodec",
    # End effector codecs
    "EEPassThroughCmdCodec",
    # Protobuf enum constants
    "JointModeEnum",
    "ConnectionStatusEnum",
    "OperationalStatusEnum",
    "RobotComponentEnum",
    "ErrorSeverityEnum",
    "BaseLEDSideEnum",
    "PriorityEnum",
]

# Conditionally add image codecs if feature is enabled
if _HAS_IMAGE_SUPPORT:
    __all__ += [
        "RGBImageCodec",
        "DepthImageCodec",
    ]
