# Copyright (c) 2026 Dexmate
#
# 1. GNU Affero General Public License v3.0 (AGPL-3.0)
#    See LICENSE-AGPL for details
#

"""Protobuf enum constants for easy access.

This module provides convenient access to protobuf enum values.
Enum values are exposed directly from Rust to avoid distributing
protobuf generated files.

Example:
    >>> from dexcomm.codecs.enums import JointModeEnum
    >>> mode = JointModeEnum.ENABLE  # Returns 2
    >>> mode = JointModeEnum.POSITION  # Returns 4
"""

# Import enum constants directly from Rust bindings (no protobuf files needed)
from dexcomm._core import (
    BaseLEDSideEnum,
    ConnectionStatusEnum,
    ErrorSeverityEnum,
    JointModeEnum,
    OperationalStatusEnum,
    PriorityEnum,
    RobotComponentEnum,
)

__all__ = [
    "JointModeEnum",
    "ConnectionStatusEnum",
    "OperationalStatusEnum",
    "RobotComponentEnum",
    "ErrorSeverityEnum",
    "BaseLEDSideEnum",
    "PriorityEnum",
]
