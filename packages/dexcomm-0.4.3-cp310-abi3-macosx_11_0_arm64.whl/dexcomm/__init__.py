# Copyright (c) 2026 Dexmate
#
# 1. GNU Affero General Public License v3.0 (AGPL-3.0)
#    See LICENSE-AGPL for details
#

"""DexComm: High-Performance Distributed Communication for Robotics

High-performance communication library built on Zenoh.
All core functionality uses native optimized implementations.

Quick Start:
    from dexcomm import Publisher, Subscriber, Node

    # Publisher
    pub = Publisher("my/topic")
    pub.publish({"data": 42})

    # Subscriber
    sub = Subscriber("my/topic", callback=lambda msg: print(msg))

    # Node pattern
    node = Node("my_robot", namespace="robot1")
    pub = node.create_publisher("sensors")
"""


# === CONFLICT DETECTION ===
# Must be at the very top, before any other imports
# Prevents both dexcomm and dexcomm-video from being installed simultaneously
def _check_package_conflict():
    """Prevent both dexcomm and dexcomm-video from being installed simultaneously."""
    try:
        # Try Python 3.8+ importlib.metadata first
        from importlib.metadata import distributions

        # Python 3.13+ compatibility: dist.name triggers DeprecationWarning
        # for distributions with missing Name metadata, use .get() instead
        installed = set()
        for dist in distributions():
            name = dist.metadata.get("Name")
            if name is not None:
                installed.add(name)
        conflicts = installed & {"dexcomm", "dexcomm-video"}

        if len(conflicts) > 1:
            raise ImportError(
                f"\n{'=' * 70}\n"
                f"ERROR: Package conflict detected!\n"
                f"\n"
                f"Both {sorted(conflicts)} are installed.\n"
                f"These packages conflict - only ONE can be used.\n"
                f"\n"
                f"To fix this issue:\n"
                f"  1. Uninstall both packages:\n"
                f"     pip uninstall dexcomm dexcomm-video\n"
                f"\n"
                f"  2. Install only ONE package:\n"
                f"     pip install dexcomm         # Base package (~10MB, no video)\n"
                f"     # OR\n"
                f"     pip install dexcomm-video   # Full package (~180MB, with video)\n"
                f"\n"
                f"Which one should you choose?\n"
                f"  - Use 'dexcomm' if you don't need video streaming\n"
                f"  - Use 'dexcomm-video' if you need RTC video streaming support\n"
                f"{'=' * 70}\n"
            )
    except ImportError:
        # Fallback for Python < 3.8 or if importlib.metadata not available
        try:
            import pkg_resources

            installed = {pkg.project_name for pkg in pkg_resources.working_set}
            conflicts = installed & {"dexcomm", "dexcomm-video"}
            if len(conflicts) > 1:
                raise ImportError(
                    "\nERROR: Both 'dexcomm' and 'dexcomm-video' are installed.\n"
                    "Uninstall one: pip uninstall dexcomm dexcomm-video\n"
                    "Then reinstall only one package.\n"
                )
        except ImportError:
            # If both methods fail, skip check (better than breaking import)
            pass


_check_package_conflict()
del _check_package_conflict  # Clean up namespace

from pathlib import Path  # noqa: E402

# === Core Native Imports (Maximum Performance) ===
from dexcomm._core import (  # noqa: E402
    # Core Classes
    # Enum Constants
    ConnectionStatusEnum,
    ErrorSeverityEnum,
    HeartbeatMonitor,
    JointModeEnum,
    Node,
    OperationalStatusEnum,
    PeriodicExecutor,
    PriorityEnum,
    Publisher,
    # Manager Classes (also in Rust now)
    PublisherManager,
    RateLimitedPublisher,
    RateLimiter,
    RobotComponentEnum,
    Service,
    ServiceClient,
    SessionManager,
    Subscriber,
    SubscriberManager,
    # Configuration & Session
    ZenohConfig,
    cleanup_session,
    get_active_services,
    get_active_topics,
    get_session,
    get_session_manager,
)

# Convenience functions (Python wrappers)
from dexcomm.convenience import (  # noqa: E402
    call_service,
    publish,
    serve,
    shutdown,
    subscribe,
    subscribe_once,
    wait_for_message,
)

# === Package Info ===
LIB_PATH = Path(__file__).parent

try:
    from importlib.metadata import version

    __version__ = version("dexcomm")
except Exception:
    __version__ = "unknown"

# === Exports ===
__all__ = [
    # Core Classes
    "Publisher",
    "RateLimitedPublisher",
    "Subscriber",
    "Service",
    "ServiceClient",
    "Node",
    "HeartbeatMonitor",
    "RateLimiter",
    "PeriodicExecutor",
    # Configuration
    "ZenohConfig",
    "SessionManager",
    "get_session",
    "get_session_manager",
    "cleanup_session",
    "get_active_topics",
    "get_active_services",
    # Managers
    "PublisherManager",
    "SubscriberManager",
    # Enum Constants
    "ConnectionStatusEnum",
    "OperationalStatusEnum",
    "RobotComponentEnum",
    "ErrorSeverityEnum",
    "JointModeEnum",
    "PriorityEnum",
    # Convenience Functions
    "publish",
    "subscribe",
    "subscribe_once",
    "wait_for_message",
    "call_service",
    "serve",
    "shutdown",
    # Package Info
    "__version__",
    "LIB_PATH",
]
