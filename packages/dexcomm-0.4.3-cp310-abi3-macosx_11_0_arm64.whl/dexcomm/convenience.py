# Copyright (c) 2026 Dexmate
#
# 1. GNU Affero General Public License v3.0 (AGPL-3.0)
#    See LICENSE-AGPL for details
#

"""Convenience functions for quick one-off communication operations.

These functions provide a simple way to publish, subscribe, or call services
without explicitly creating and managing communication objects.
"""

from collections.abc import Callable
from pathlib import Path
from typing import Any

from dexcomm._core import (
    Publisher,
    Service,
    ServiceClient,
    Subscriber,
    ZenohConfig,
    cleanup_session,
)


def publish(
    topic: str,
    message: Any,
    config: ZenohConfig | Path | str | None = None,
    encoder: Any = None,
) -> None:
    """Quick publish without creating a Publisher object.

    This is useful for one-off publishes where you don't need to keep
    the publisher around.

    Args:
        topic: Topic to publish on.
        message: Message to publish.
        config: Zenoh configuration or config file path. Defaults to None.
        encoder: Custom encoder function (e.g., AutoData.encode). If None, expects raw bytes.
            Defaults to None.

    Example:
        >>> from dexcomm import publish, AutoData
        >>> publish("sensor/temp", b"raw bytes")
        >>> publish("sensor/temp", {"temp": 25.5}, encoder=AutoData.encode)
    """
    pub = Publisher(topic, config=config, encoder=encoder)
    try:
        pub.publish(message)
    finally:
        pub.shutdown()


def subscribe(
    topic: str,
    callback: Callable[[Any], None],
    config: ZenohConfig | Path | str | None = None,
    decoder: Any = None,
) -> Subscriber:
    """Create a subscriber with a callback.

    This is a convenience wrapper that creates a subscriber.
    Unlike publish(), this returns the subscriber since it needs
    to stay alive to receive messages.

    Args:
        topic: Topic to subscribe to.
        callback: Function to call with received messages.
        config: Zenoh configuration or config file path. Defaults to None.
        decoder: Custom decoder function (e.g., AutoData.decode). If None, returns raw bytes.
            Defaults to None.

    Returns:
        Subscriber instance (remember to call shutdown() when done).

    Example:
        >>> from dexcomm import subscribe, AutoData
        >>> sub = subscribe("sensor/temp", lambda msg: print(f"Raw: {msg}"))
        >>> sub_auto = subscribe("sensor/temp", lambda msg: print(f"Data: {msg}"), decoder=AutoData.decode)
        >>> # Subscriber stays alive until shutdown
    """
    return Subscriber(topic, callback=callback, config=config, decoder=decoder)


def subscribe_once(
    topic: str,
    timeout: float = 5.0,
    config: ZenohConfig | Path | str | None = None,
    decoder: Any = None,
) -> Any | None:
    """Subscribe and wait for a single message then unsubscribe.

    This is useful for request-response patterns or waiting for
    a single event.

    Args:
        topic: Topic to subscribe to.
        timeout: Maximum time to wait for a message in seconds.
            Defaults to 5.0.
        config: Zenoh configuration or config file path. Defaults to None.
        decoder: Custom decoder function (e.g., AutoData.decode). If None, returns raw bytes.
            Defaults to None.

    Returns:
        Received message or None if timeout.

    Example:
        >>> from dexcomm import subscribe_once, AutoData
        >>> msg = subscribe_once("sensor/temp", timeout=10.0, decoder=AutoData.decode)
        >>> if msg:
        ...     print(f"Got temperature: {msg}")
    """
    sub = Subscriber(topic, config=config, decoder=decoder)
    try:
        return sub.wait_for_message(timeout=timeout)
    finally:
        sub.shutdown()


def wait_for_message(
    topic: str,
    timeout: float = 5.0,
    config: ZenohConfig | Path | str | None = None,
    decoder: Any = None,
) -> Any | None:
    """Wait for a message on a topic.

    Alias for subscribe_once for better readability in some contexts.

    Args:
        topic: Topic to wait on.
        timeout: Maximum time to wait in seconds. Defaults to 5.0.
        config: Zenoh configuration or config file path. Defaults to None.
        decoder: Custom decoder function (e.g., AutoData.decode). If None, returns raw bytes.
            Defaults to None.

    Returns:
        Received message or None if timeout.

    Example:
        >>> from dexcomm import wait_for_message, AutoData
        >>> msg = wait_for_message("robot/ready", timeout=30.0, decoder=AutoData.decode)
    """
    return subscribe_once(topic, timeout=timeout, config=config, decoder=decoder)


def call_service(
    service_name: str,
    request: Any = None,
    timeout: float = 5.0,
    config: ZenohConfig | Path | str | None = None,
    request_encoder: Any = None,
    response_decoder: Any = None,
) -> Any | None:
    """Quick service call without creating a ServiceClient.

    This is useful for one-off service calls where you don't need
    to keep the client around.

    Args:
        service_name: Name of the service to call.
        request: Request data to send. Defaults to None.
        timeout: Maximum time to wait for response in seconds.
            Defaults to 5.0.
        config: Zenoh configuration or config file path. Defaults to None.
        request_encoder: Custom request encoder function (e.g., AutoData.encode). If None, expects raw bytes.
            Defaults to None.
        response_decoder: Custom response decoder function (e.g., AutoData.decode). If None, returns raw bytes.
            Defaults to None.

    Returns:
        Response from the service or None if timeout/error.

    Example:
        >>> from dexcomm import call_service, AutoData
        >>> result = call_service("add_two_ints", {"a": 5, "b": 3},
        ...                       request_encoder=AutoData.encode,
        ...                       response_decoder=AutoData.decode)
        >>> if result:
        ...     print(f"Sum: {result['sum']}")
    """
    client = ServiceClient(
        service_name,
        timeout=timeout,
        config=config,
        request_encoder=request_encoder,
        response_decoder=response_decoder,
    )
    return client.call(request)


def serve(
    service_name: str,
    handler: Callable[[Any], Any],
    config: ZenohConfig | Path | str | None = None,
    request_decoder: Any = None,
    response_encoder: Any = None,
) -> Service:
    """Create a service with a handler.

    This is a convenience wrapper that creates a service.
    The service stays alive until shutdown.

    Args:
        service_name: Name of the service.
        handler: Function to handle requests.
        config: Zenoh configuration or config file path. Defaults to None.
        request_decoder: Custom request decoder function (e.g., AutoData.decode). If None, returns raw bytes.
            Defaults to None.
        response_encoder: Custom response encoder function (e.g., AutoData.encode). If None, expects raw bytes.
            Defaults to None.

    Returns:
        Service instance (remember to call shutdown() when done).

    Example:
        >>> from dexcomm import serve, AutoData
        >>>
        >>> def add_handler(request):
        ...     return {"sum": request["a"] + request["b"]}
        >>>
        >>> service = serve("add_two_ints", add_handler,
        ...                 request_decoder=AutoData.decode,
        ...                 response_encoder=AutoData.encode)
        >>> # Service stays alive until shutdown
    """
    return Service(
        service_name,
        handler=handler,
        config=config,
        request_decoder=request_decoder,
        response_encoder=response_encoder,
    )


def shutdown() -> None:
    """Cleanly shutdown all DexComm resources.

    This convenience function shuts down all active publishers, subscribers,
    and services, and closes the shared Zenoh session. Call this when you're
    done using DexComm to ensure all resources are properly released.

    This is particularly useful for:
    - Clean application shutdown
    - Interactive sessions (Jupyter notebooks, REPL)
    - Testing and cleanup between test runs

    Example:
        >>> from dexcomm import Publisher, Subscriber, shutdown
        >>> pub = Publisher("my/topic")
        >>> sub = Subscriber("my/topic", callback=lambda msg: print(msg))
        >>> # ... do work ...
        >>> shutdown()  # Clean up everything
    """
    cleanup_session()
