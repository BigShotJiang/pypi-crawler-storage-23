"""inkhinge包的核心功能模块"""
import os
import numpy as np
import pandas as pd
from ase.io import write
from ase.visualize import view
from scipy.spatial import cKDTree
from spectrochempy_omnic import OMNICReader as read
from decimal import Decimal, Context, ROUND_HALF_UP
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.signal import find_peaks, savgol_filter, medfilt
from PIL import Image
from collections import defaultdict
import datetime
import pyabf
import traceback
import re
import warnings

"read_to_csv module:"
def read_to_csv(input_path, output_path=None, background_path=None, overwrite=False, recursive=False, precision=20, merge_output=None):
    """
    Read Omnic SPA files and convert to CSV format, with option to merge all converted CSV files

    Parameters:
        input_path (str): Path to input SPA file or directory containing files
        output_path (str): Path for output CSV file or directory
        background_path (str): Path to background BG.spa file
        overwrite (bool): Whether to overwrite existing files
        recursive (bool): Process subdirectories recursively (only effective for directories)
        precision (int): Decimal precision for output data
        merge_output (str): Output path for merged CSV file, None means no merging

    Returns:
        Processing result information (number of successfully converted files or output path)
    """
    def float_to_fixed_str(value, precision=20):
        """Convert float to fixed-point decimal string with specified precision"""
        if np.isnan(value):
            return 'nan'
        try:
            ctx = Context(prec=max(25, precision + 5), rounding=ROUND_HALF_UP)
            dec = ctx.create_decimal(str(value))
            return f"{dec:.{precision}f}"
        except:
            return str(value)

    def detect_data_type(reader):
        """Detect data type and return corresponding title and units"""
        data_type_mapping = {
            0: ("Absorbance", "AU"),
            1: ("Transmittance", "%"),
            2: ("Reflectance", "%"),
            3: ("Single Beam", ""),
            4: ("Kubelka-Munk", "KM units"),
        }

        if hasattr(reader, 'data_type') and reader.data_type in data_type_mapping:
            return data_type_mapping[reader.data_type]

        if hasattr(reader, 'title'):
            title = reader.title.lower()
            if "absorbance" in title:
                return "Absorbance", "AU"
            elif "transmittance" in title or "Transmittance" in title:  # Updated
                return "Transmittance", "%"
            elif "reflectance" in title:
                return "Reflectance", "%"
            elif "single beam" in title or "Single Beam" in title:  # Updated
                return "Single Beam", ""
            elif "kubelka-munk" in title or "km" in title:
                return "Kubelka-Munk", "KM units"

        y_title = reader.y_title or "Intensity"
        y_units = reader.y_units or ""

        if "kubelka" in y_title.lower() or "km" in y_title.lower():
            return "Kubelka-Munk", "KM units"

        return y_title, y_units

    def calculate_kubelka_munk(reflectance):
        """Calculate Kubelka-Munk values"""
        reflectance = np.clip(reflectance, 0.0001, 0.9999)
        return ((1 - reflectance) **2) / (2 * reflectance)

    def extract_spectral_data(reader):
        """Extract spectral data and corresponding X-axis data from reader"""
        data = reader.data
        x = reader.x

        x_units = reader.x_units or "cm^-1"
        x_title = reader.x_title or "Wavelength"

        if data.ndim == 1:
            spectral_data = data.reshape(1, -1)
        elif data.ndim >= 2:
            spectral_dim = None

            if data.shape[-1] == len(x):
                spectral_dim = -1
            elif data.shape[0] == len(x):
                spectral_dim = 0

            if spectral_dim is None:
                for i in range(data.ndim):
                    if data.shape[i] == len(x):
                        spectral_dim = i
                        break

            if spectral_dim is None:
                spectral_dim = np.argmin(np.abs(np.array(data.shape) - len(x)))
                print(f"Warning: Unable to determine spectral data dimension, assuming dimension {spectral_dim}")

            if spectral_dim != -1:
                axes = list(range(data.ndim))
                axes.remove(spectral_dim)
                axes.append(spectral_dim)
                data = data.transpose(axes)

            spectral_data = data.reshape(-1, len(x))
        else:
            raise ValueError(f"Unsupported data dimension: {data.ndim}")

        return spectral_data, x, x_title, x_units

    def apply_background_correction(sample_data, background_data, x_sample, x_bg):
        """Apply background correction"""
        if np.array_equal(x_sample, x_bg):
            corrected_data = sample_data / background_data
        else:
            corrected_data = np.zeros_like(sample_data)
            for i, spectrum in enumerate(sample_data):
                bg_interp = np.interp(x_sample, x_bg, background_data[0])
                corrected_data[i] = spectrum / bg_interp

        return corrected_data

    def convert_spa_to_csv(input_file, output_file=None, background_path=None, overwrite=False, precision=20):
        """Convert Omnic SPA file to CSV format"""
        if not os.path.exists(input_file):
            raise FileNotFoundError(f"Input file not found: {input_file}")

        if not output_file:
            base_name, _ = os.path.splitext(input_file)
            output_file = f"{base_name}_converted.csv"

        if os.path.exists(output_file) and not overwrite:
            raise FileExistsError(f"Output file already exists: {output_file}")

        try:
            print(f"Reading sample file: {input_file}")
            sample_reader = read(input_file)

            sample_data, x_sample, x_title, x_units = extract_spectral_data(sample_reader)
            y_title, y_units = detect_data_type(sample_reader)

            if background_path:
                if not os.path.exists(background_path):
                    raise FileNotFoundError(f"Background file not found: {background_path}")

                print(f"Reading background file: {background_path}")
                bg_reader = read(background_path)
                bg_data, x_bg, _, _ = extract_spectral_data(bg_reader)

                if y_title == "Reflectance":
                    corrected_data = apply_background_correction(sample_data, bg_data, x_sample, x_bg)
                    y_title = "Corrected Reflectance"
                elif y_title == "Transmittance":
                    corrected_data = sample_data - bg_data
                    y_title = "Corrected Transmittance"
                else:
                    corrected_data = apply_background_correction(sample_data, bg_data, x_sample, x_bg)
                    y_title = f"Corrected {y_title}"

                spectral_data = corrected_data
            else:
                spectral_data = sample_data

            print(f"Data dimension: {spectral_data.shape}")
            print(f"X-axis: {x_title} ({x_units})")
            print(f"Data type: {y_title} ({y_units})")

            # Create DataFrame column data (resolve fragmentation)
            columns_data = {
                f"{x_title} ({x_units})": [float_to_fixed_str(val, precision) for val in x_sample]
            }

            if y_title == "Reflectance" or y_title == "Corrected Reflectance":
                km_data = calculate_kubelka_munk(spectral_data)
                km_title = "Kubelka-Munk"
                km_units = "KM units"

                if km_data.shape[0] == 1:
                    columns_data[f"{km_title} ({km_units})"] = [float_to_fixed_str(val, precision) for val in km_data[0]]
                else:
                    for i in range(km_data.shape[0]):
                        columns_data[f"{km_title}_{i} ({km_units})"] = [float_to_fixed_str(val, precision) for val in km_data[i]]

            if spectral_data.shape[0] == 1:
                columns_data[f"{y_title} ({y_units})"] = [float_to_fixed_str(val, precision) for val in spectral_data[0]]
            else:
                if hasattr(sample_reader, 'spectra_titles') and len(sample_reader.spectra_titles) == spectral_data.shape[0]:
                    for i, title in enumerate(sample_reader.spectra_titles):
                        clean_title = title.strip() or f"{y_title}_{i}"
                        columns_data[f"{clean_title} ({y_units})"] = [float_to_fixed_str(val, precision) for val in spectral_data[i]]
                else:
                    for i in range(spectral_data.shape[0]):
                        columns_data[f"{y_title}_{i} ({y_units})"] = [float_to_fixed_str(val, precision) for val in spectral_data[i]]

            df = pd.DataFrame(columns_data)
            df.to_csv(output_file, index=False, na_rep='nan')
            print(f"Successfully converted and saved to: {output_file}")
            return output_file

        except Exception as e:
            print(f"Conversion failed: {str(e)}")
            return None

    def batch_convert_spa_to_csv(input_dir, output_dir=None, background_path=None, overwrite=False, recursive=False,
                                 precision=20, merge_output=None):
        """Batch convert SPA files in directory to CSV format, with option to merge all CSV files"""
        if not os.path.exists(input_dir):
            raise FileNotFoundError(f"Input directory not found: {input_dir}")

        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        spa_files = []
        for root, _, files in os.walk(input_dir):
            for file in files:
                if file.lower().endswith('.spa'):
                    spa_files.append(os.path.join(root, file))

            if not recursive:
                break

        if not spa_files:
            print(f"No SPA files found in directory: {input_dir}")
            return []

        # Sort by filename
        spa_files.sort()
        output_files = []
        for spa_file in spa_files:
            try:
                if output_dir:
                    rel_path = os.path.relpath(spa_file, input_dir)
                    base_name, _ = os.path.splitext(rel_path)
                    output_file = os.path.join(output_dir, f"{base_name}.csv")
                    os.makedirs(os.path.dirname(output_file), exist_ok=True)
                else:
                    output_file = None

                result = convert_spa_to_csv(spa_file, output_file, background_path, overwrite, precision)
                if result:
                    output_files.append(result)
            except Exception as e:
                print(f"Error processing file {spa_file}: {str(e)}")

        print(f"Batch conversion completed: {len(output_files)}/{len(spa_files)} successful")

        # Merge CSV files
        if merge_output and output_files:
            merge_csv_files(output_files, merge_output, overwrite, precision)

        return output_files

    def merge_csv_files(csv_files, output_path, overwrite=False, precision=20):
        """
        Merge multiple CSV files sequentially, resolve performance warnings and start column names from 0

        Parameters:
            csv_files (list): List of CSV file paths (in order)
            output_path (str): Output path for merged file
            overwrite (bool): Whether to overwrite existing file
            precision (int): Decimal precision for output data
        """
        if not csv_files:
            print("No CSV files to merge")
            return

        # Check if output file exists
        if os.path.exists(output_path) and not overwrite:
            raise FileExistsError(f"Merged output file already exists: {output_path}")

        print(f"Starting merge of {len(csv_files)} CSV files...")

        # Read all dataframes and prepare for merge
        data_frames = []
        x_column = None

        for i, csv_file in enumerate(csv_files):
            df = pd.read_csv(csv_file)

            # Validate X-axis column
            current_x_col = df.columns[0]
            if i == 0:
                x_column = current_x_col
                # Keep X-axis column of first file, rename data columns with suffix _0
                rename_map = {col: f"{col}_0" for col in df.columns[1:]}
                renamed_df = df.rename(columns=rename_map)
                data_frames.append(renamed_df)
            else:
                if current_x_col != x_column:
                    print(f"Warning: X-axis column name in file {csv_file} differs from first file: {current_x_col} vs {x_column}")
                    continue

                # Rename data columns of subsequent files, counting from 1
                file_suffix = f"_{i}"
                rename_map = {col: f"{col}{file_suffix}" for col in df.columns[1:]}
                renamed_df = df.rename(columns=rename_map)
                # Remove X-axis column from subsequent files
                data_frames.append(renamed_df.drop(columns=[current_x_col]))

            print(f"Prepared file {i+1}/{len(csv_files)}: {csv_file}")

        # Merge all dataframes at once (resolve performance warning)
        merged_df = pd.concat(data_frames, axis=1)

        # Save CSV with custom formatting function to ensure fixed decimal precision
        float_format = lambda x: float_to_fixed_str(x, precision)
        merged_df.to_csv(output_path, index=False, na_rep='nan', float_format=float_format)

        print(f"Successfully merged and saved to: {output_path}")
        return output_path

    # Determine if input is file or directory
    if os.path.isfile(input_path):
        # Ensure input is .spa file
        if not input_path.lower().endswith('.spa'):
            raise ValueError(f"Input file is not SPA file: {input_path}")
        # Process single file
        result = convert_spa_to_csv(input_path, output_path, background_path, overwrite, precision)
        if merge_output:
            return [result] if result else []
        return result
    elif os.path.isdir(input_path):
        # Process directory
        return batch_convert_spa_to_csv(input_path, output_path, background_path, overwrite, recursive, precision, merge_output)
    else:
        raise ValueError(f"Input path does not exist: {input_path}")

"curvefit_km_t module:"
def curvefit_km_t(file_path, target_row=1, txt_output_path="curvefit_km_t.txt", png_output_path="curvefit_km_t.png", show_plot=True):
    """
    Read CSV file, perform curve fitting on KM units data of specified row, and visualize results

    Parameters:
    file_path (str): CSV file path
    target_row (int, optional): Target row number (1-based), default is 1
    txt_output_path (str, optional): Output text file path for fitting results
    png_output_path (str, optional): Output PNG file path for fitting image
    show_plot (bool, optional): Whether to show plot, default True

    Returns:
    dict: Dictionary containing fitting parameters, evaluation metrics, and raw data
    """
    try:
        # Read CSV file
        df = pd.read_csv(file_path)
    except Exception as e:
        print(f"File read error: {e}")
        return None

    # Check data row count
    rows, columns = df.shape
    if rows < target_row:
        print(f'Data has {rows} rows, less than specified row {target_row}, unable to get corresponding row data')
        return None

    # Get specified row data
    row_data = df.iloc[target_row - 1]
    title = row_data[0]

    # Extract time and KM values
    time = np.array(range(1, len(row_data)))
    km_values = row_data[1:].values

    # Set image clarity and font
    plt.rcParams['figure.dpi'] = 150
    plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'Heiti TC', 'sans-serif']

    # Define new fitting function: y = a * x^b * exp(-c * x)
    def new_fit_func(x, a, b, c):
        return a * np.power(x, b) * np.exp(-c * x)

    # Initial parameter guesses
    a_guess = max(km_values)
    b_guess = 0.5
    c_guess = 0.1
    p0 = [a_guess, b_guess, c_guess]

    try:
        # Perform curve fitting
        popt, pcov = curve_fit(new_fit_func, time, km_values, p0=p0, maxfev=5000)

        # Calculate fitted values and R²
        y_fit = new_fit_func(time, *popt)
        residuals = km_values - y_fit
        ss_res = np.sum(residuals ** 2)
        ss_tot = np.sum((km_values - np.mean(km_values)) ** 2)
        r_squared = 1 - (ss_res / ss_tot)

        # Generate fitting function expression
        fit_expr = f"y = {popt[0]:.6f} * x^{popt[1]:.6f} * exp(-{popt[2]:.6f} * x)"

        # Write fitting results to text file
        with open(txt_output_path, "w") as f:
            f.write(f"Fitting Results - {title}\n\n")
            f.write("Fitting function expression:\n")
            f.write(f"{fit_expr}\n\n")
            f.write("Fitting parameters:\n")
            f.write(f"a = {popt[0]:.6f}\n")
            f.write(f"b = {popt[1]:.6f}\n")
            f.write(f"c = {popt[2]:.6f}\n\n")
            f.write(f"R² = {r_squared:.6f}\n")

        print(f"Fitting results successfully written to {txt_output_path}")

        # Create plot
        plt.figure(figsize=(7, 5))
        plt.scatter(time, km_values, marker='o', label='Raw data')
        plt.plot(time, y_fit, 'r-',
                 label=f'Fitted curve: {fit_expr}\nR² = {r_squared:.4f}')

        # Set plot properties
        plt.xlabel('T (s)')
        plt.ylabel('KM units')
        plt.title(title)
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.tight_layout()

        # Save image
        plt.savefig(png_output_path, dpi=300, bbox_inches='tight')
        print(f"Fitting image successfully saved to {png_output_path}")

        # Show plot if needed
        if show_plot:
            plt.show()

        # Return result dictionary
        return {
            'title': title,
            'time': time,
            'km_values': km_values,
            'parameters': {'a': popt[0], 'b': popt[1], 'c': popt[2]},
            'r_squared': r_squared,
            'fitted_values': y_fit,
            'fit_expression': fit_expr
        }

    except Exception as e:
        print(f"Fitting process error: {e}")
        return None

"curvefit_km_wavenumber module:"
def curvefit_km_wavenumber(file_path, time_column_index=1, txt_output_path="curvefit_km_wavenumber.txt",
                      png_output_path="curvefit_km_wavenumber.png"):
    """
    Fit KM values vs wavenumber using Gaussian-Lorentzian hybrid function at specific time

    Parameters:
        file_path: CSV file path, each row represents a wavenumber, each column represents KM values
        time_column_index: Time column index to fit (0-based), default is 1
        txt_output_path: Output text file path
        png_output_path: Output image file path

    Returns:
        Dictionary containing fitting results including parameters, R² value and function expression
    """

    # Gaussian-Lorentzian hybrid function (3 peaks)
    def gaussian_lorentzian(x, a1, x01, sigma1, eta1, a2, x02, sigma2, eta2, a3, x03, sigma3, eta3):
        g1 = a1 * np.exp(-(x - x01) ** 2 / (2 * sigma1 ** 2))
        l1 = a1 / (1 + ((x - x01) / sigma1) ** 2)
        g2 = a2 * np.exp(-(x - x02) ** 2 / (2 * sigma2 ** 2))
        l2 = a2 / (1 + ((x - x02) / sigma2) ** 2)
        g3 = a3 * np.exp(-(x - x03) ** 2 / (2 * sigma3 ** 2))
        l3 = a3 / (1 + ((x - x03) / sigma3) ** 2)
        return eta1 * l1 + (1 - eta1) * g1 + eta2 * l2 + (1 - eta2) * g2 + eta3 * l3 + (1 - eta3) * g3

    # Calculate R² value (goodness of fit)
    def calculate_r_squared(actual, predicted):
        ss_res = np.sum((actual - predicted) ** 2)
        ss_tot = np.sum((actual - np.mean(actual)) ** 2)
        return 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    # 1. Data reading and preprocessing
    df = pd.read_csv(file_path)

    wavenumbers = df.iloc[:, 0].values  # Wavenumber column is index 0

    # Ensure wavenumbers are monotonically increasing
    is_increasing = np.all(np.diff(wavenumbers) >= 0)
    if not is_increasing:
        print("Detected non-monotonic wavenumbers, auto-correcting with sorting...")
        sorted_indices = np.argsort(wavenumbers)
        wavenumbers = wavenumbers[sorted_indices]
        df = df.iloc[sorted_indices]

    # Filter 1300-1320 cm⁻¹ range
    mask = (wavenumbers >= 1300) & (wavenumbers <= 1320)
    valid_wavenumbers = wavenumbers[mask]
    km_values = df.iloc[mask, time_column_index].values  # Get KM values for specified time column

    # 2. Three-peak fitting
    def fit_3peaks(x, y):
        x_min, x_max = x.min(), x.max()
        x_range = x_max - x_min
        y_max = y.max()

        # Enhanced peak detection
        peaks, _ = find_peaks(y, height=np.percentile(y, 70), distance=5)
        if len(peaks) < 3:
            peaks = [
                np.argmax(y),
                int(len(x) * 0.25),
                int(len(x) * 0.75)
            ]
        peaks = sorted(peaks)

        # Physically constrained initial values
        p0 = [
            y[peaks[0]] * 0.9, x[peaks[0]], max(x_range * 0.05, 0.05), 0.3,
            y[peaks[1]] * 0.6, x[peaks[1]], max(x_range * 0.08, 0.08), 0.5,
            y[peaks[2]] * 0.4, x[peaks[2]], max(x_range * 0.06, 0.06), 0.7
        ]

        # Reasonable constraints
        bounds = (
            [0, x_min, 0.01, 0.2, 0, x_min, 0.01, 0.2, 0, x_min, 0.01, 0.2],
            [np.inf, x_max, x_range, 0.8, np.inf, x_max, x_range, 0.8, np.inf, x_max, x_range, 0.8]
        )

        # Ensure initial values are within constraints
        for i in range(len(p0)):
            p0[i] = max(bounds[0][i], min(p0[i], bounds[1][i]))

        try:
            popt, pcov = curve_fit(
                gaussian_lorentzian, x, y, p0=p0, bounds=bounds,
                maxfev=100000, method='trf'
            )
            predicted = gaussian_lorentzian(x, *popt)
            r_squared = calculate_r_squared(y, predicted)
            return popt, r_squared
        except Exception as e:
            print(f"Three-peak fitting warning: {e}, enabling backup strategy")
            # Backup initial values
            simplified_popt = [
                y_max * 0.5, x.mean() - x_range * 0.2, x_range * 0.05, 0.4,
                y_max * 0.3, x.mean(), x_range * 0.07, 0.5,
                y_max * 0.2, x.mean() + x_range * 0.2, x_range * 0.06, 0.6
            ]
            # Ensure backup values are within constraints
            for i in range(len(simplified_popt)):
                simplified_popt[i] = max(bounds[0][i], min(simplified_popt[i], bounds[1][i]))
            popt, pcov = curve_fit(
                gaussian_lorentzian, x, y, p0=simplified_popt,
                bounds=bounds, maxfev=100000, method='trf'
            )
            predicted = gaussian_lorentzian(x, *popt)
            r_squared = calculate_r_squared(y, predicted)
            return popt, r_squared

    # Fit KM vs wavenumber relationship
    popt, r2 = fit_3peaks(valid_wavenumbers, km_values)

    # 3. Generate fitting function expression
    def format_gaussian_lorentzian(params):
        a1, x01, sigma1, eta1, a2, x02, sigma2, eta2, a3, x03, sigma3, eta3 = params
        expr = "KM(w) = "
        expr += f"{eta1:.6f} * ({a1:.6f} / (1 + ((w - {x01:.6f}) / {sigma1:.6f})^2)) + "
        expr += f"{1 - eta1:.6f} * ({a1:.6f} * exp(-(w - {x01:.6f})^2 / (2 * {sigma1:.6f}^2))) + "
        expr += f"{eta2:.6f} * ({a2:.6f} / (1 + ((w - {x02:.6f}) / {sigma2:.6f})^2)) + "
        expr += f"{1 - eta2:.6f} * ({a2:.6f} * exp(-(w - {x02:.6f})^2 / (2 * {sigma2:.6f}^2))) + "
        expr += f"{eta3:.6f} * ({a3:.6f} / (1 + ((w - {x03:.6f}) / {sigma3:.6f})^2)) + "
        expr += f"{1 - eta3:.6f} * ({a3:.6f} * exp(-(w - {x03:.6f})^2 / (2 * {sigma3:.6f}^2)))"
        return expr

    # Generate function expression
    km_expr = format_gaussian_lorentzian(popt)

    # Write to file
    with open(txt_output_path, "w") as f:
        f.write("===== Fitting Function Expression =====\n\n")
        f.write("Gaussian-Lorentzian hybrid function for KM vs wavenumber:\n")
        f.write(f"{km_expr}\n\n")
        f.write("===== Goodness of Fit =====\n")
        f.write(f"R² value: {r2:.6f}\n")

    print(f"Fitting function expression successfully written to {txt_output_path}")

    # 4. Visualize fitting results
    plt.rcParams["font.family"] = ["Arial Unicode MS", "Heiti TC", "sans-serif"]
    plt.rcParams["axes.unicode_minus"] = True

    plt.figure(figsize=(12, 6))
    plt.scatter(valid_wavenumbers, km_values, color='blue', label='Raw data')

    # Generate fitted curve
    x_fit = np.linspace(valid_wavenumbers.min(), valid_wavenumbers.max(), 1000)
    y_fit = gaussian_lorentzian(x_fit, *popt)
    plt.plot(x_fit, y_fit, 'r-', label=f'Fitted curve (R²={r2:.4f})')

    plt.title('Fitted Relationship between KM Values and Wavenumber')
    plt.xlabel('Wavenumber (cm⁻¹)')
    plt.ylabel('KM Value')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()

    # Save image
    plt.savefig(png_output_path, dpi=300, bbox_inches='tight')
    print(f"Fitting result image successfully saved to {png_output_path}")

    # Show image (optional)
    plt.show()

    # Return key fitting results
    return {
        'popt': popt,
        'r2': r2,
        'km_expr': km_expr,
        'valid_wavenumbers': valid_wavenumbers,
        'km_values': km_values
    }

"curvefit_km_t_wavenumber module："
def curvefit_km_t_wavenumber(file_path, wavenumber_min=1300, wavenumber_max=1320,
                             output_txt_path="curvefit.txt", output_img_path="curvefit.png",
                             peak_num=3):
    """
    Perform 3D fitting on time-wavenumber-KM value data, return fitting results
    and generate visualizations and text reports.

    Parameters:
        file_path (str): Path to CSV data file
        wavenumber_min (float): Lower limit of wavenumber range, default 1300 cm⁻¹
        wavenumber_max (float): Upper limit of wavenumber range, default 1320 cm⁻¹
        output_txt_path (str): Output text report path, default "curvefit.txt"
        output_img_path (str): Output image path, default "curvefit.png"
        peak_num (int): Number of peaks to use in fitting, default 3
    """

    # Dynamically create Gaussian-Lorentzian mixture function (based on number of peaks)
    def create_gaussian_lorentzian(num_peaks):
        def func(x, *params):
            result = np.zeros_like(x)
            param_len = 4  # Each peak has 4 parameters: a, x0, sigma, eta
            for i in range(num_peaks):
                a = params[i * param_len]
                x0 = params[i * param_len + 1]
                sigma = params[i * param_len + 2]
                eta = params[i * param_len + 3]

                gaussian = a * np.exp(-(x - x0) ** 2 / (2 * sigma ** 2))
                lorentzian = a / (1 + ((x - x0) / sigma) ** 2)
                result += eta * lorentzian + (1 - eta) * gaussian
            return result

        return func

    # Power-exponential time function (for initial b value calculation)
    def power_exp_func_original(t, a, b, c):
        return a * t ** b * np.exp(-c * t)

    # Calculate R² (goodness of fit)
    def calculate_r_squared(actual, predicted):
        ss_res = np.sum((actual - predicted) ** 2)
        ss_tot = np.sum((actual - np.mean(actual)) ** 2)
        return 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    # 1. Data reading and preprocessing
    df = pd.read_csv(file_path)
    wavenumbers = df.iloc[:, 0].values
    first_column_name = df.columns[0]
    print(f"Automatically using first column '{first_column_name}' as wavenumber data")

    # Ensure wavenumbers are monotonically increasing
    if not np.all(np.diff(wavenumbers) >= 0):
        print("Detected non-monotonic wavenumbers, auto-correcting...")
        sorted_indices = np.argsort(wavenumbers)
        wavenumbers = wavenumbers[sorted_indices]
        df = df.iloc[sorted_indices]

    # Filter specified wavenumber range
    mask = (wavenumbers >= wavenumber_min) & (wavenumbers <= wavenumber_max)
    valid_wavenumbers = wavenumbers[mask]
    time = np.arange(1, df.shape[1])

    print(f"Using wavenumber range: {wavenumber_min} - {wavenumber_max} cm⁻¹")
    print(f"Filtered to {len(valid_wavenumbers)} valid wavenumber data points")
    print(f"Using number of peaks: {peak_num}")

    # 2. Two-step fitting: First get b value to calculate constant k, then fix k to fit a(w) and c(w)
    a_temp, b_temp, c_temp = [], [], []
    for w in valid_wavenumbers:
        try:
            row_idx = np.where(wavenumbers == w)[0][0]
            km_values = df.iloc[row_idx, 1:].values
            km_values = savgol_filter(km_values, window_length=5, polyorder=2)

            # Initial value estimation
            early_mean = np.mean(km_values[:int(len(km_values) * 0.1)])
            late_mean = np.mean(km_values[-int(len(km_values) * 0.1):])
            a_guess = max(early_mean - late_mean, 0.1)
            b_guess = 0.5 if km_values[-1] > km_values[0] * 0.5 else 1.0
            c_guess = 0.05 if km_values[-1] > km_values[0] * 0.5 else 0.2

            # Constrained fitting
            popt, _ = curve_fit(
                power_exp_func_original, time, km_values, p0=[a_guess, b_guess, c_guess],
                maxfev=20000, bounds=([0, 0, 0], [np.inf, np.inf, np.inf])
            )
            a_temp.append(popt[0])
            b_temp.append(popt[1])
            c_temp.append(popt[2])
        except Exception as e:
            print(f"Wavenumber {w} initial fitting failed: {e}")
            a_temp.append(np.nan)
            b_temp.append(np.nan)
            c_temp.append(np.nan)

    # Calculate constant k
    k = np.nanmean(b_temp)
    print(f"Calculated constant k value: {k:.6f}")

    # Filter invalid data
    valid_mask = ~np.isnan(a_temp) & ~np.isnan(b_temp) & ~np.isnan(c_temp)
    valid_wavenumbers = valid_wavenumbers[valid_mask]
    a_temp = np.array(a_temp)[valid_mask]
    b_temp = np.array(b_temp)[valid_mask]
    c_temp = np.array(c_temp)[valid_mask]

    if len(valid_wavenumbers) < 12:
        raise ValueError("Insufficient valid data points (minimum 12 required)")

    # Second step: Fix k value and refit
    def power_exp_func_fixed_k(t, a, c):
        return a * t ** k * np.exp(-c * t)

    a_list, c_list = [], []
    a_r2_list, c_r2_list = [], []

    for i, w in enumerate(valid_wavenumbers):
        try:
            row_idx = np.where(wavenumbers == w)[0][0]
            km_values = df.iloc[row_idx, 1:].values
            a_guess = a_temp[i]
            c_guess = c_temp[i]

            popt, _ = curve_fit(
                power_exp_func_fixed_k, time, km_values, p0=[a_guess, c_guess],
                maxfev=20000, bounds=([0, 0], [np.inf, np.inf]))
            predicted = power_exp_func_fixed_k(time, *popt)
            r_squared = calculate_r_squared(km_values, predicted)

            a_list.append(popt[0])
            c_list.append(popt[1])
            a_r2_list.append(r_squared)
            c_r2_list.append(r_squared)
        except Exception as e:
            print(f"Wavenumber {w} secondary fitting failed: {e}")
            a_list.append(np.nan)
            c_list.append(np.nan)
            a_r2_list.append(np.nan)
            c_r2_list.append(np.nan)

    # Filter invalid data again
    valid_mask2 = ~np.isnan(a_list) & ~np.isnan(c_list)
    valid_wavenumbers = valid_wavenumbers[valid_mask2]
    a_vals = np.array(a_list)[valid_mask2]
    c_vals = np.array(c_list)[valid_mask2]
    a_r2 = np.array(a_r2_list)[valid_mask2]
    c_r2 = np.array(c_r2_list)[valid_mask2]

    if len(valid_wavenumbers) < 12:
        raise ValueError("Insufficient valid data points after secondary fitting (minimum 12 required)")

    # 3. Multi-peak fitting (based on peak_num parameter)
    def fit_peaks(x, y, num_peaks):
        # Create mixture function
        gl_func = create_gaussian_lorentzian(num_peaks)

        x_min, x_max = x.min(), x.max()
        x_range = x_max - x_min
        y_max = y.max()

        # Peak detection
        peaks, _ = find_peaks(y, height=np.percentile(y, 70), distance=5)
        if len(peaks) < num_peaks:
            peaks = list(peaks)
            # Supplement missing peaks
            while len(peaks) < num_peaks:
                candidate = int(len(x) * len(peaks) / (num_peaks + 1))
                peaks.append(candidate)
        peaks = sorted(peaks)[:num_peaks]  # Take only first num_peaks peaks

        # Initial values setup
        p0 = []
        bounds_lower = []
        bounds_upper = []
        for i in range(num_peaks):
            peak_idx = peaks[i] if i < len(peaks) else int(len(x) * (i + 1) / (num_peaks + 1))
            a_val = y[peak_idx] * (0.9 - i * 0.2)
            x0_val = x[peak_idx]
            sigma_val = max(x_range * 0.05, 0.05)
            eta_val = 0.3 + i * 0.1

            p0.extend([a_val, x0_val, sigma_val, eta_val])
            bounds_lower.extend([0, x_min, 0.01, 0.2])
            bounds_upper.extend([np.inf, x_max, x_range, 0.8])

        # Ensure initial values are within bounds
        for i in range(len(p0)):
            p0[i] = max(bounds_lower[i], min(p0[i], bounds_upper[i]))

        try:
            popt, _ = curve_fit(
                gl_func, x, y, p0=p0,
                bounds=(bounds_lower, bounds_upper),
                maxfev=500000, method='trf'
            )
            predicted = gl_func(x, *popt)
            r_squared = calculate_r_squared(y, predicted)
            return popt, r_squared
        except Exception as e:
            print(f"{num_peaks}-peak fitting failed: {e}")
            # Fallback strategy: Use simpler initial values
            simple_p0 = []
            for i in range(num_peaks):
                a_val = y_max * (0.5 - i * 0.1)
                x0_val = x_min + (i + 1) / (num_peaks + 1) * x_range
                sigma_val = x_range * 0.05
                eta_val = 0.5
                simple_p0.extend([a_val, x0_val, sigma_val, eta_val])

            popt, _ = curve_fit(
                gl_func, x, y, p0=simple_p0,
                bounds=(bounds_lower, bounds_upper),
                maxfev=500000, method='trf'
            )
            predicted = gl_func(x, *popt)
            r_squared = calculate_r_squared(y, predicted)
            return popt, r_squared

    # Fit spectral distributions for a and c
    popt_a, r2_a = fit_peaks(valid_wavenumbers, a_vals, peak_num)
    popt_c, r2_c = fit_peaks(valid_wavenumbers, c_vals, peak_num)

    # Get final mixture function
    gl_func = create_gaussian_lorentzian(peak_num)

    # 4. Construct 3D KM function
    def km_3d(t, w):
        a = gl_func(w, *popt_a)
        c = gl_func(w, *popt_c)
        return a * t ** k * np.exp(-c * t)

    # 5. Generate grid data
    t_grid = np.linspace(time[0], time[-1], 30)
    w_grid = valid_wavenumbers.reshape(-1, 1)

    km_grid = np.zeros((len(valid_wavenumbers), len(t_grid)))
    for i, w in enumerate(valid_wavenumbers):
        for j, t in enumerate(t_grid):
            km_grid[i, j] = km_3d(t, w)

    # Original data grid
    original_km_grid = np.zeros_like(km_grid)
    for i, w in enumerate(valid_wavenumbers):
        row_idx = np.where(wavenumbers == w)[0][0]
        km_values = df.iloc[row_idx, 1:].values
        original_km_grid[i, :] = np.interp(t_grid, time, km_values)

    # 6. Calculate overall R²
    actual_values = original_km_grid.flatten()
    predicted_values = km_grid.flatten()
    r2_overall = calculate_r_squared(actual_values, predicted_values)

    # 7. Format function expressions
    def format_gl_func(params, func_name, num_peaks):
        expr = f"{func_name}(w) = "
        for i in range(num_peaks):
            a = params[i * 4]
            x0 = params[i * 4 + 1]
            sigma = params[i * 4 + 2]
            eta = params[i * 4 + 3]

            expr += f"{eta:.6f} * ({a:.6f} / (1 + ((w - {x0:.6f}) / {sigma:.6f})^2)) + "
            expr += f"{1 - eta:.6f} * ({a:.6f} * exp(-(w - {x0:.6f})^2 / (2 * {sigma:.6f}^2)))"
            if i < num_peaks - 1:
                expr += " + "
        return expr

    # Generate function expressions
    a_expr = format_gl_func(popt_a, "a", peak_num)
    c_expr = format_gl_func(popt_c, "c", peak_num)
    km_3d_expr = f"km_3d(t, w) = a(w) * t^{k:.6f} * exp(-c(w))"

    # Ensure output directories exist
    os.makedirs(os.path.dirname(output_txt_path) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(output_img_path) or ".", exist_ok=True)

    # Write to file
    with open(output_txt_path, "w") as f:
        f.write("===== Fitted Function Expressions =====\n\n")
        f.write(f"Number of peaks used: {peak_num}\n\n")
        f.write("1. Mixture function for parameter a:\n")
        f.write(f"{a_expr}\n\n")
        f.write("2. Mixture function for parameter c:\n")
        f.write(f"{c_expr}\n\n")
        f.write("3. 3D KM function:\n")
        f.write(f"{km_3d_expr}\n\n")
        f.write(f"Wavenumber range used: {wavenumber_min} - {wavenumber_max} cm⁻¹\n")
        f.write(f"CSV first column header: '{first_column_name}'\n\n")
        f.write("===== Goodness of Fit =====\n")
        f.write(f"R² for parameter a: {r2_a:.6f}\n")
        f.write(f"R² for parameter c: {r2_c:.6f}\n")
        f.write(f"Constant k value: {k:.6f}\n")
        f.write(f"Overall surface R²: {r2_overall:.6f}\n")
        f.write(f"Average R² for time function: {np.mean(a_r2):.6f}\n")

    print(f"Fitted function expressions successfully written to {output_txt_path}")

    # 8. Visualization comparison
    plt.rcParams["font.family"] = ["Arial", "DejaVu Sans", "Liberation Sans", "sans-serif"]
    plt.rcParams["axes.unicode_minus"] = False

    fig = plt.figure(figsize=(20, 8))

    # Original data surface
    ax1 = fig.add_subplot(121, projection='3d')
    surf1 = ax1.plot_surface(
        t_grid, w_grid, original_km_grid,
        cmap='viridis', alpha=0.9, edgecolor='none'
    )
    ax1.set_xlabel('Time t (s)')
    ax1.set_ylabel(f'Wavenumber ({wavenumber_min}-{wavenumber_max} cm⁻¹)')
    ax1.set_zlabel('KM Value')
    ax1.set_title('Original Data')

    # Fitted data surface
    ax2 = fig.add_subplot(122, projection='3d')
    surf2 = ax2.plot_surface(
        t_grid, w_grid, km_grid,
        cmap='plasma', alpha=0.9, edgecolor='none'
    )
    ax2.set_xlabel('Time t (s)')
    ax2.set_ylabel(f'Wavenumber ({wavenumber_min}-{wavenumber_max} cm⁻¹)')
    ax2.set_zlabel('KM Value')
    ax2.set_title(f'Fitted Surface (Overall R²: {r2_overall:.4f}, Peaks: {peak_num})')

    # Synchronize viewing angles
    ax2.view_init(elev=30, azim=45)
    ax1.view_init(elev=30, azim=45)

    # Fit evaluation information
    stats_text = (f"Fit Evaluation:\n"
                  f"• Number of peaks: {peak_num}\n"
                  f"• R² for parameter a: {r2_a:.4f}\n"
                  f"• R² for parameter c: {r2_c:.4f}\n"
                  f"• Constant k value: {k:.6f}\n"
                  f"• Average R² for time function: {np.mean(a_r2):.4f}\n"
                  f"• Overall surface R²: {r2_overall:.4f}\n"
                  f"• Wavenumber range: {wavenumber_min}-{wavenumber_max} cm⁻¹\n"
                  f"• CSV first column: '{first_column_name}'")
    fig.text(0.01, 0.01, stats_text, fontsize=9, bbox=dict(facecolor='white', alpha=0.8))

    # Colorbar
    cbar_ax = fig.add_axes([0.92, 0.15, 0.02, 0.7])
    fig.colorbar(surf2, cax=cbar_ax)

    plt.tight_layout()

    # Save image
    plt.savefig(output_img_path, dpi=300, bbox_inches='tight')
    print(f"Visualization successfully saved to {output_img_path}")

    # Display image
    plt.show()

    # Output evaluation results
    print(f"===== Fit Evaluation Results =====")
    print(f"Number of peaks used: {peak_num}")
    print(f"CSV first column header: '{first_column_name}'")
    print(f"Wavenumber range used: {wavenumber_min} - {wavenumber_max} cm⁻¹")
    print(f"R² for parameter a: {r2_a:.4f}")
    print(f"R² for parameter c: {r2_c:.4f}")
    print(f"Constant k value: {k:.6f}")
    print(f"Average R² for time function: {np.mean(a_r2):.4f}")
    print(f"Overall surface R²: {r2_overall:.4f}")

    # Return fitting results
    return {
        'k': k,
        'popt_a': popt_a,
        'popt_c': popt_c,
        'r2_a': r2_a,
        'r2_c': r2_c,
        'r2_overall': r2_overall,
        'mean_time_r2': np.mean(a_r2),
        'km_3d_func': km_3d,
        'valid_wavenumbers': valid_wavenumbers,
        'time': time,
        'wavenumber_min': wavenumber_min,
        'wavenumber_max': wavenumber_max,
        'first_column_name': first_column_name,
        'peak_num': peak_num,
        'output_txt_path': output_txt_path,
        'output_img_path': output_img_path
    }

class GrayValueCalculation:
    @staticmethod
    def process_single_image(image_path,
                             red_range, green_range, blue_range,
                             max_valid_width, max_valid_height,
                             region_size,
                             output_dir="results"):
        """Process a single image and return the processing result"""
        # Check if the file exists
        if not os.path.exists(image_path):
            print(f"Error: File '{image_path}' does not exist")
            return None

        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)

        # Generate result file name (based on original file name and timestamp)
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = os.path.join(output_dir, f"{base_name}_results_{timestamp}.txt")

        # Store all output content for writing to file
        output_content = []
        # Store skipped content and valid content separately for separate display
        skipped_content = []
        valid_content = []

        def log(message, is_skipped=False):
            """Output to console and store in content list simultaneously"""
            print(message)
            output_content.append(message + "\n")
            if is_skipped:
                skipped_content.append(message + "\n")
            else:
                valid_content.append(message + "\n")

        # Record processing information
        log(f"===== Image processing started: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
        log(f"Processing image: {image_path}")
        log(f"RGB ranges - Red: {red_range}, Green: {green_range}, Blue: {blue_range}")
        log(f"Maximum valid region size: {max_valid_width}x{max_valid_height}")
        log(f"Base region size: {region_size}x{region_size}")
        log("----------------------------------------")

        # Open the image and convert to RGB format
        try:
            with Image.open(image_path) as img:
                # Convert to RGB mode to handle compatibility with different image modes
                image = img.convert('RGB')
            log(f"Image size: {image.size[0]}x{image.size[1]} pixels")
        except Exception as e:
            error_msg = f"Error opening image: {e}"
            log(error_msg)
            # Save error information to file
            with open(output_file, 'w', encoding='utf-8') as f:
                f.writelines(output_content)
            return None

        pixels = image.load()
        width, height = image.size

        # Parse parameters
        red_min, red_max = red_range
        green_min, green_max = green_range
        blue_min, blue_max = blue_range
        region_edge = region_size  # Side length of the region
        region_offset = region_edge - 1  # Offset for boundary calculation

        # Ensure the region size is valid
        if region_edge <= 0:
            error_msg = "Error: Region size must be a positive number"
            log(error_msg)
            with open(output_file, 'w', encoding='utf-8') as f:
                f.writelines(output_content)
            return None

        # Ensure the image is large enough to contain at least one region
        if width < region_edge or height < region_edge:
            error_msg = f"Error: Image size ({width}x{height}) is smaller than the specified region size ({region_edge}x{region_edge})"
            log(error_msg)
            with open(output_file, 'w', encoding='utf-8') as f:
                f.writelines(output_content)
            return None

        # Step 1: Collect all top-left coordinates (x, y) of qualified regions of specified size
        valid_regions = []
        # Ensure regions do not exceed image boundaries
        for y in range(0, height - region_offset):
            for x in range(0, width - region_offset):
                # Check if all pixels in the region meet RGB range requirements
                match = True
                for dy in range(region_edge):
                    if not match:
                        break
                    for dx in range(region_edge):
                        r, g, b = pixels[x + dx, y + dy]
                        if not (red_min <= r <= red_max and
                                green_min <= g <= green_max and
                                blue_min <= b <= blue_max):
                            match = False
                            break
                if match:
                    valid_regions.append((x, y))

        log(f"Number of qualified base regions found: {len(valid_regions)}")

        # Store average gray values of all valid regions
        all_region_averages = []

        # Step 2: Merge continuously adjacent regions and calculate overall average gray value
        if valid_regions:
            # Group by y-coordinate (regions in the same horizontal strip are grouped together)
            region_groups = defaultdict(list)
            for x, y in valid_regions:
                region_groups[y].append(x)

            log(f"Number of horizontal strips (grouped by y-coordinate): {len(region_groups)}")
            log("----------------------------------------")

            # Iterate through each y group and process regions with continuous x-coordinates
            for y0, x_list in region_groups.items():
                sorted_x = sorted(x_list)
                if not sorted_x:
                    continue

                # Divide continuous x-coordinates into groups
                continuous_groups = []
                current_start = sorted_x[0]
                current_end = sorted_x[0]
                for x in sorted_x[1:]:
                    if x == current_end + 1:
                        current_end = x
                    else:
                        continuous_groups.append((current_start, current_end))
                        current_start = x
                        current_end = x
                continuous_groups.append((current_start, current_end))

                # Calculate overall average gray value for each continuous group
                for start_x, end_x in continuous_groups:
                    # Calculate width and height of the merged region
                    region_width = end_x - start_x + region_edge
                    region_height = region_edge  # Height is fixed as region size

                    # Check if the region exceeds maximum limits
                    if region_width > max_valid_width or region_height > max_valid_height:
                        msg = f"Invalid region exceeding size limit - Top-left coordinate ({start_x}, {y0}), Bottom-right coordinate ({end_x + region_offset}, {y0 + region_offset}), " \
                              f"Size: {region_width}x{region_height}, skipped"
                        # log(msg, is_skipped=True)
                        continue

                    # Calculate average gray value of the region
                    total_gray = 0
                    total_pixels = 0
                    for y_pixel in range(y0, y0 + region_edge):
                        for x_pixel in range(start_x, end_x + region_edge):
                            r, g, b = pixels[x_pixel, y_pixel]
                            gray = int(0.2989 * r + 0.5870 * g + 0.1140 * b)
                            total_gray += gray
                            total_pixels += 1

                    # Output information of the merged region
                    if total_pixels > 0:
                        average_gray = total_gray / total_pixels
                        all_region_averages.append(average_gray)
                        msg = f"Qualified valid region - Top-left coordinate ({start_x}, {y0}), Bottom-right coordinate ({end_x + region_offset}, {y0 + region_offset}), " \
                              f"Size: {region_width}x{region_height}, Average gray value: {average_gray:.2f}"
                        log(msg)

        # Add separator to distinguish skipped content and valid content
        if skipped_content and valid_content:
            separator = "----------"
            print(separator)
            output_content.append(separator + "\n")

        # Calculate and output total average of all valid regions
        log("----------------------------------------")
        overall_average = None
        if all_region_averages:
            overall_average = sum(all_region_averages) / len(all_region_averages)
            msg = f"Average gray value of all qualified valid regions: {overall_average:.2f}"
            log(msg)
        else:
            log("No qualified valid regions found")

        # Record processing end information
        log(f"===== Image processing ended: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")

        # Write results to file
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.writelines(output_content)
            print(f"Results saved to: {output_file}\n")
        except Exception as e:
            print(f"Error saving result file: {e}\n")

        return {
            'image_path': image_path,
            'overall_average': overall_average,
            'result_file': output_file
        }

    @staticmethod
    def process_images(input_path,
                       red_range, green_range, blue_range,
                       max_valid_width, max_valid_height,
                       region_size,
                       output_dir="results"):
        """
        Process images, automatically identify whether the input is a single file or a directory

        Parameters:
            input_path: Path to a single image file or a directory containing images
            red_range: Red channel range, tuple (minimum, maximum)
            green_range: Green channel range, tuple (minimum, maximum)
            blue_range: Blue channel range, tuple (minimum, maximum)
            max_valid_width: Maximum valid region width
            max_valid_height: Maximum valid region height
            region_size: Size of the base region to calculate (e.g., 9 represents 9x9 region)
            output_dir: Directory to save result files, default is "results"
        """
        # Check if the input path exists
        if not os.path.exists(input_path):
            print(f"Error: Input path '{input_path}' does not exist")
            return []

        # If it's a single file
        if os.path.isfile(input_path):
            # Check if the file format is supported
            supported_formats = ('.png', '.jpg', '.jpeg', '.tif', '.tiff')
            file_ext = os.path.splitext(input_path)[1].lower()
            if file_ext in supported_formats:
                result = GrayValueCalculation.process_single_image(
                    image_path=input_path,
                    red_range=red_range,
                    green_range=green_range,
                    blue_range=blue_range,
                    max_valid_width=max_valid_width,
                    max_valid_height=max_valid_height,
                    region_size=region_size,
                    output_dir=output_dir
                )
                return [result] if result else []
            else:
                print(f"Error: Unsupported file format '{file_ext}', supported formats are: {supported_formats}")
                return []

        # If it's a directory, perform batch processing
        elif os.path.isdir(input_path):
            # Supported file formats
            supported_formats = ('.png', '.jpg', '.jpeg', '.tif', '.tiff')

            # Get all image files in the directory that meet the format requirements
            image_files = []
            for filename in os.listdir(input_path):
                file_path = os.path.join(input_path, filename)
                # Check if it's a file and the format meets the requirements
                if os.path.isfile(file_path):
                    file_ext = os.path.splitext(filename)[1].lower()
                    if file_ext in supported_formats:
                        image_files.append(file_path)

            if not image_files:
                print(f"No supported image files found in directory '{input_path}'")
                return []

            print(f"Found {len(image_files)} qualified image files, starting batch processing...\n")

            # Store summary information of all processing results
            batch_results = []

            # Process images one by one
            for i, image_path in enumerate(image_files, 1):
                print(f"----- Processing image {i}/{len(image_files)} -----")
                result = GrayValueCalculation.process_single_image(
                    image_path=image_path,
                    red_range=red_range,
                    green_range=green_range,
                    blue_range=blue_range,
                    max_valid_width=max_valid_width,
                    max_valid_height=max_valid_height,
                    region_size=region_size,
                    output_dir=output_dir
                )
                if result:
                    batch_results.append(result)

            # Generate batch processing summary report
            summary_file = os.path.join(output_dir,
                                        f"batch_summary_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
            try:
                with open(summary_file, 'w', encoding='utf-8') as f:
                    f.write(f"===== Batch processing summary report: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====\n")
                    f.write(f"Processing directory: {input_path}\n")
                    f.write(f"Total number of images processed: {len(image_files)}\n")
                    f.write(f"Successfully processed: {len(batch_results)}\n")
                    f.write("----------------------------------------\n")
                    f.write("Summary of average gray values for each image:\n")
                    for result in batch_results:
                        avg = result['overall_average'] if result['overall_average'] is not None else "No valid regions"
                        f.write(f"{os.path.basename(result['image_path'])}: {avg}\n")
                    f.write("----------------------------------------\n")
                    f.write(f"Result save directory: {output_dir}\n")

                print(f"Batch processing completed! Summary report saved to: {summary_file}")
            except Exception as e:
                print(f"Error generating summary report: {e}")

            return batch_results

        else:
            print(f"Error: Input path '{input_path}' is neither a file nor a directory")
            return []

class TifToPng:
    """TIF格式到PNG格式的转换工具类"""

    @staticmethod
    def convert_single(input_path, output_path=None):
        """
        将单个TIF文件转换为PNG格式

        参数:
            input_path: TIF文件的路径
            output_path: 输出PNG文件的路径，若为None则在原目录生成同名PNG文件

        返回:
            转换成功返回True，否则返回False
        """
        try:
            # 打开TIF文件
            with Image.open(input_path) as img:
                # 如果未指定输出路径，则在原目录生成同名PNG文件
                if output_path is None:
                    # 获取文件名和目录
                    file_dir, file_name = os.path.split(input_path)
                    # 替换扩展名
                    base_name = os.path.splitext(file_name)[0]
                    output_path = os.path.join(file_dir, f"{base_name}.png")

                # 创建输出目录（如果不存在）
                output_dir = os.path.dirname(output_path)
                if not os.path.exists(output_dir):
                    os.makedirs(output_dir)

                # 保存为PNG格式
                img.save(output_path, "PNG")
                print(f"成功转换: {input_path} -> {output_path}")
                return True
        except Exception as e:
            print(f"转换失败 {input_path}: {str(e)}")
            return False

    @staticmethod
    def batch(input_dir, output_dir=None):
        """
        批量转换目录中的所有TIF文件为PNG格式

        参数:
            input_dir: 包含TIF文件的目录
            output_dir: 输出PNG文件的目录，若为None则使用输入目录
        """
        # 检查输入目录是否存在
        if not os.path.isdir(input_dir):
            print(f"错误: 目录 {input_dir} 不存在")
            return

        # 遍历目录中的所有文件
        for file_name in os.listdir(input_dir):
            # 检查文件是否为TIF格式
            if file_name.lower().endswith(('.tif', '.tiff')):
                input_path = os.path.join(input_dir, file_name)

                # 构建输出路径
                if output_dir:
                    base_name = os.path.splitext(file_name)[0]
                    output_path = os.path.join(output_dir, f"{base_name}.png")
                else:
                    output_path = None

                # 转换文件
                TifToPng.convert_single(input_path, output_path)

def Convert3D(file_path):
    """
    将CSV或XLSX文件数据转换为3D可视化图表

    参数:
    file_path (str): CSV或XLSX文件的路径
    """
    try:
        # 根据文件扩展名读取数据
        file_ext = os.path.splitext(file_path)[1].lower()
        if file_ext == '.csv':
            df = pd.read_csv(file_path)
        elif file_ext in ['.xlsx', '.xls']:
            df = pd.read_excel(file_path)
        else:
            raise ValueError("不支持的文件格式，请提供CSV或XLSX文件")

        # 检查数据是否为空
        if df.empty:
            raise ValueError("文件中没有数据")

        # 检查列数是否足够
        if df.shape[1] < 2:
            raise ValueError("文件至少需要包含两列数据")

        # 设置图片清晰度
        plt.rcParams['figure.dpi'] = 150

        # 设置 matplotlib 支持中文
        plt.rcParams['font.sans-serif'] = ['WenQuanYi Zen Hei', 'Heiti TC', 'SimHei']
        plt.rcParams['axes.unicode_minus'] = False

        # 创建三维图形对象
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')

        # 获取坐标轴标签（从列名获取）
        x_label = df.columns[0]
        z_label = '数据系列'  # 可以根据需要修改

        # 遍历从第二列开始的每一列
        for col_index in range(1, df.shape[1]):
            x = df.iloc[:, 0]
            z = [col_index - 1] * len(df)
            y = df.iloc[:, col_index]
            ax.plot(x, y, z, label=df.columns[col_index])

        # 设置坐标轴标签
        ax.set_xlabel(x_label)
        ax.set_zlabel(z_label)
        ax.set_ylabel('数值')  # 可以根据需要修改或从数据中获取

        # 添加图例
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')

        # 调整布局
        plt.tight_layout()

        # 显示图形
        plt.show()

    except FileNotFoundError:
        print(f"错误: 找不到文件 '{file_path}'")
    except Exception as e:
        print(f"发生错误: {str(e)}")

def insert_crystals(host_path, insert_path, center, radius, num, tolerance=0.9,
                    max_attempts=1000, output_path=None,view_crystals=True):
    """
    将晶体结构插入到主体结构中

    参数:
        host_path: 主体结构文件路径
        insert_path: 要插入的结构文件路径
        center: 插入区域中心坐标 (x, y, z)
        radius: 插入区域半径
        num: 要插入的数量
        tolerance: 碰撞容忍度 (0.0-1.0)
        max_attempts: 最大尝试次数
        output_path: 输出文件路径，若为None则不保存
        view_crystals:是否可视化生成的晶体结构（默认为TRUE）

    返回:
        插入后的结构对象
    """
    # 晶体半径字典，用于判断原子间距离是否合适
    CRYSTAL_RADII = {
        'Cu': 1.40, 'Fe': 1.40, 'Ni': 1.40,
        'Na+': 0.95, 'Cl-': 1.81, 'K+': 1.33,
        'H': 1.20, 'O': 1.52, 'C': 1.70,
        'default': 1.75
    }

    def get_minimal_displacement(pos1, pos2, cell, pbc):
        """计算考虑周期性边界条件的最小位移向量"""
        delta = pos1 - pos2
        scaled = np.linalg.solve(cell.T, delta.T).T

        for i in range(3):
            if pbc[i]:
                scaled[:, i] -= np.round(scaled[:, i])

        return np.dot(scaled, cell)

    def get_crystal_radius(atom):
        """获取原子的晶体半径"""
        symbol = atom.symbol
        return CRYSTAL_RADII.get(symbol, CRYSTAL_RADII['default'])

    def check_molecular_overlap(host, insert, tolerance):
        """检查分子与主体结构之间是否存在重叠"""
        host_pos = host.get_positions()
        insert_pos = insert.get_positions()

        # 计算分子质心和最大半径
        centroid = np.mean(insert_pos, axis=0)
        max_offset = max(np.linalg.norm(p - centroid) for p in insert_pos)
        mol_radius = max_offset + max(get_crystal_radius(a) for a in insert)

        # 使用KDTree快速查找潜在的碰撞原子
        host_tree = cKDTree(host_pos)
        neighbors = host_tree.query_ball_point(centroid, mol_radius)

        if not neighbors:
            return False

        host_radii = [get_crystal_radius(a) for a in host]
        insert_radii = [get_crystal_radius(a) for a in insert]

        # 详细检查潜在碰撞
        for h_idx in neighbors:
            h_pos = host_pos[h_idx]
            h_rad = host_radii[h_idx]
            for i_pos, i_rad in zip(insert_pos, insert_radii):
                delta = get_minimal_displacement(h_pos, i_pos, host.cell, host.pbc)
                distance = np.linalg.norm(delta)
                if distance < (h_rad + i_rad) * tolerance:
                    return True
        return False

    def check_ionic_overlap(host, insert, tolerance):
        """检查离子与主体结构之间是否存在重叠"""
        host_pos = host.get_positions()
        insert_pos = insert.get_positions()
        host_radii = [get_crystal_radius(a) for a in host]
        insert_radii = [get_crystal_radius(a) for a in insert]

        max_host_rad = max(host_radii)
        host_tree = cKDTree(host_pos)

        # 对每个插入原子检查是否与主体原子碰撞
        for i_pos, i_rad in zip(insert_pos, insert_radii):
            query_radius = (max_host_rad + i_rad) * tolerance
            neighbors = host_tree.query_ball_point(i_pos, query_radius)
            for h_idx in neighbors:
                h_rad = host_radii[h_idx]
                h_pos = host_pos[h_idx]
                delta = get_minimal_displacement(h_pos, i_pos, host.cell, host.pbc)
                distance = np.linalg.norm(delta)
                if distance < (h_rad + i_rad) * tolerance:
                    return True
        return False

    def random_in_sphere(center, radius):
        """在球内生成随机点"""
        theta = np.random.uniform(0, 2 * np.pi)
        phi = np.arccos(np.random.uniform(-1, 1))
        r = radius * np.random.uniform(0, 1) ** (1 / 3)

        return np.array([
            r * np.sin(phi) * np.cos(theta),
            r * np.sin(phi) * np.sin(theta),
            r * np.cos(phi)
        ]) + center

    def process_structure(struct):
        """处理结构，确定其类型并设置适当的晶胞"""
        if len(struct) == 0:
            struct.info['crystal_type'] = 'unknown'
            return struct

        pos = struct.positions
        min_dist = max_dist = avg_dist = 0
        if len(pos) > 1:
            dists = np.linalg.norm(pos[:, None] - pos, axis=2)
            np.fill_diagonal(dists, np.inf)
            min_dist = np.min(dists)
            max_dist = np.max(dists)
            avg_dist = np.mean(dists[dists < np.inf])

        has_ions = any(s in a.symbol for a in struct for s in ['+', '-'])

        # 确定晶体类型
        if len(struct) == 1:
            struct.info['crystal_type'] = 'atomic'
        elif min_dist < 1.5 and max_dist < 5.0 and not has_ions:
            struct.info['crystal_type'] = 'molecular'
        elif avg_dist > 2.0 and has_ions:
            struct.info['crystal_type'] = 'ionic'
        else:
            struct.info['crystal_type'] = 'atomic'

        # 设置适当的晶胞
        if not np.any(struct.cell):
            span = np.ptp(pos, axis=0)
            scale_factor = 4.0 if struct.info['crystal_type'] == 'molecular' else 3.0
            struct.cell = np.diag(span * scale_factor + 10.0)
            struct.center()
        return struct

    def safe_insert_cluster(host, cluster, check_overlap, tolerance):
        """安全地插入团簇，处理可能的错误"""
        original_host = host.copy()
        try:
            if not check_overlap(host, cluster, tolerance):
                host += cluster
                return True
            return False
        except Exception as e:
            # 出错时恢复原始状态
            host.positions = original_host.positions
            host.numbers = original_host.numbers
            host.cell = original_host.cell
            print(f"插入错误: {str(e)}")
            return False

    # 主逻辑实现
    # 读取并处理主体和插入结构
    host = process_structure(read(host_path))
    insert = process_structure(read(insert_path))
    original_insert = insert.copy()

    # 根据晶体类型选择合适的插入策略
    strategies = {
        'molecular': (check_molecular_overlap, 'rigid'),
        'ionic': (check_ionic_overlap, 'rigid'),
        'atomic': (check_ionic_overlap, 'single')
    }
    check_overlap, move_mode = strategies.get(
        insert.info['crystal_type'],
        (check_ionic_overlap, 'single')
    )

    success = 0
    attempts = 0

    # 尝试插入指定数量的结构
    while success < num and attempts < max_attempts:
        attempts += 1
        new_pos = random_in_sphere(center, radius)

        candidate = original_insert.copy()
        if move_mode == 'rigid':
            # 刚性移动整个分子/离子团
            original_centroid = np.mean(candidate.positions, axis=0)
            candidate.positions += new_pos - original_centroid

            # 调整到晶胞周期内
            current_centroid = np.mean(candidate.positions, axis=0)
            frac_centroid = np.linalg.solve(host.cell.T, current_centroid)
            for i in range(3):
                if host.pbc[i]:
                    frac_centroid[i] %= 1.0
            adjusted_centroid = np.dot(frac_centroid, host.cell)

            delta = adjusted_centroid - current_centroid
            candidate.positions += delta

            # 确保完全在主晶胞内
            frac_coords = np.linalg.solve(host.cell.T, candidate.positions.T).T
            min_floor = np.floor(frac_coords.min(axis=0))
            shift = np.dot(min_floor, host.cell)
            candidate.positions -= shift
        else:
            # 单个原子移动
            candidate.positions += new_pos

        # 检查并插入
        if safe_insert_cluster(host, candidate, check_overlap, tolerance):
            success += 1
            print(f"成功插入 {success}/{num}")

    print(f"插入完成: 尝试次数 {attempts}, 成功率 {success / (attempts + 1e-6):.1%}")

    # 保存结果（如果指定了输出路径）
    if output_path:
        write(output_path, host, wrap=False)
        print(f"最终结构已保存到 {output_path}，原子总数: {len(host)}")

    if view_crystals:
        atoms = read(output_path)
        view(atoms)

    return host

def abf_to_csv(input_path, output_path=None, recursive=False):
    """
    Convert ABF files to CSV format, supporting both single file and batch processing.

    Automatically determines processing mode based on input and output paths:
    - If input is a single .abf file and output is a file path: single file conversion
    - If input is a folder and output is a folder path: batch conversion

    Parameters:
        input_path: Path to input ABF file or folder containing ABF files
        output_path: Optional output path (file or folder)
        recursive: Whether to recursively process subfolders when input is a folder

    Returns:
        Tuple of (success_count, failure_count)
    """

    # Helper function to process a single file
    def process_single_file(abf_file_path, output_csv_path=None):
        try:
            # Verify input file existence
            if not os.path.exists(abf_file_path):
                print(f"Error: File does not exist - {abf_file_path}")
                return None

            # Load ABF file
            abf = pyabf.ABF(abf_file_path)
            print(f"Successfully loaded ABF file: {os.path.basename(abf_file_path)}")
            print(f"Version: {abf.abfVersion}, Channels: {abf.channelCount}, Sampling rate: {abf.dataRate} Hz")
            print(f"Total data points: {abf.dataPointCount}")

            # Determine output path with validation
            if output_csv_path is None:
                # Use default path if not specified
                file_dir = os.path.dirname(abf_file_path)
                file_name = os.path.splitext(os.path.basename(abf_file_path))[0]
                output_csv_path = os.path.join(file_dir, f"{file_name}.csv")
                print(f"Will output to default path: {output_csv_path}")
            else:
                # Validate provided output path is not a directory
                if os.path.isdir(output_csv_path):
                    print(f"Output path is a directory, auto-correcting...")
                    # Create filename based on input and use provided directory
                    file_name = os.path.splitext(os.path.basename(abf_file_path))[0]
                    output_csv_path = os.path.join(output_csv_path, f"{file_name}.csv")
                    print(f"Corrected output path: {output_csv_path}")

            # Create output directory if it doesn't exist
            output_dir = os.path.dirname(output_csv_path)
            if not os.path.exists(output_dir):
                os.makedirs(output_dir, exist_ok=True)
                print(f"Created output directory: {output_dir}")

            # Calculate time axis
            sampling_rate = abf.dataRate  # Sampling rate (Hz)
            sampling_interval = 1.0 / sampling_rate  # Sampling interval (seconds)
            total_points = abf.dataPointCount  # Total number of data points
            time = np.linspace(0, (total_points - 1) * sampling_interval, total_points)
            print(f"Generated time axis: {len(time)} points, from {time[0]:.6f}s to {time[-1]:.6f}s")

            # Prepare data dictionary
            data = {"Time (s)": time}

            # Process each channel
            for channel in range(abf.channelCount):
                print(f"Processing channel {channel + 1}/{abf.channelCount}")

                # Get channel data
                channel_data = abf.data[channel]
                print(f"Channel {channel + 1} data length: {len(channel_data)}")

                # Ensure data length matches time axis
                if len(channel_data) != len(time):
                    print(f"Warning: Channel {channel + 1} data length mismatch, truncating/padding")
                    if len(channel_data) > len(time):
                        channel_data = channel_data[:len(time)]
                    else:
                        channel_data = np.pad(channel_data, (0, len(time) - len(channel_data)),
                                              mode='constant', constant_values=np.nan)

                # Get channel name and unit
                channel_name = f"Channel {channel + 1}"
                channel_unit = ""

                # Try to get channel name (compatible with different pyabf versions)
                if hasattr(abf, 'channelNames') and channel < len(abf.channelNames):
                    channel_name = abf.channelNames[channel]
                elif hasattr(abf, 'channelList') and channel < len(abf.channelList):
                    channel_name = abf.channelList[channel]

                # Try to get unit
                if hasattr(abf, 'adcUnits') and channel < len(abf.adcUnits):
                    channel_unit = abf.adcUnits[channel]

                column_name = f"{channel_name} ({channel_unit})" if channel_unit else channel_name
                data[column_name] = channel_data

            # Create DataFrame and save
            df = pd.DataFrame(data)
            df.to_csv(output_csv_path, index=False)
            print(f"Successfully saved CSV file: {output_csv_path}")

            return output_csv_path

        except Exception as e:
            print(f"\nConversion failed: {str(e)}")
            print("Error details:")
            traceback.print_exc()
            return None

    # Main logic to determine processing mode
    success = 0
    failed = 0

    # Check if input path exists
    if not os.path.exists(input_path):
        print(f"Error: Input path does not exist - {input_path}")
        return (success, failed)

    # Determine if input is a file or directory
    if os.path.isfile(input_path):
        # Single file processing
        # Check if it's an ABF file
        if not input_path.lower().endswith('.abf'):
            print(f"Error: Input file is not an ABF file - {input_path}")
            return (success, failed)

        print(f"Processing single file: {input_path}")
        result = process_single_file(input_path, output_path)
        if result:
            success = 1
        else:
            failed = 1

    elif os.path.isdir(input_path):
        # Batch processing
        print(f"Processing directory: {input_path} (recursive={recursive})")

        # Validate output directory if provided
        output_dir = output_path
        if output_dir is not None:
            if os.path.isfile(output_dir):
                print(f"Warning: Output path is a file, using its directory instead")
                output_dir = os.path.dirname(output_dir)
            os.makedirs(output_dir, exist_ok=True)
            print(f"All outputs will be saved to: {output_dir}")

        # Collect all ABF files
        abf_files = []
        if recursive:
            for root, _, files in os.walk(input_path):
                for file in files:
                    if file.lower().endswith('.abf'):
                        abf_files.append(os.path.join(root, file))
        else:
            for file in os.listdir(input_path):
                file_path = os.path.join(input_path, file)
                if os.path.isfile(file_path) and file.lower().endswith('.abf'):
                    abf_files.append(file_path)

        total = len(abf_files)
        print(f"Found {total} ABF files, starting batch conversion...")

        for i, abf_file in enumerate(abf_files, 1):
            print(f"\nProcessing file {i}/{total}: {abf_file}")

            # Determine output path for this file
            if output_dir:
                file_name = os.path.splitext(os.path.basename(abf_file))[0]
                output_csv_path = os.path.join(output_dir, f"{file_name}.csv")
            else:
                output_csv_path = None  # Use default path

            result = process_single_file(abf_file, output_csv_path)
            if result:
                success += 1
            else:
                failed += 1

        print(f"\nBatch processing completed: Total {total} files, {success} succeeded, {failed} failed")
    else:
        print(f"Error: Input path is neither a file nor a directory - {input_path}")

    return (success, failed)


def FindPeak_Single(
        csv_file_path,
        start_row=0,
        end_row=None,
        max_peak_count=500,
        x_col=None,
        y_col=None,
        plot_result=True,
        output_image="detected_valley_features.png",
        output_csv="detected_valley_features.csv",
        sampling_rate=1e6,
        enable_filtering=True,
        savgol_polyorder=3,
        enable_outlier_removal=True,
        create_connected_peaks=True
):
    """
    Main function for automatic detection of significant features (valleys).
    (Detailed documentation unchanged, only event classification related content removed)
    """
    # ==================== Internal Helper Functions ====================
    def evaluate_detection_quality(features, baseline_std):
        """
        Evaluate quality metrics for detected features.
        """
        if not features:
            return {'avg_snr': 0, 'depth_variation': 0, 'valid_event_count': 0}

        snr_values = [f['signal_to_noise'] for f in features if f['signal_to_noise'] > 0]
        depth_values = [f['valley_depth'] for f in features]

        avg_snr = np.mean(snr_values) if snr_values else 0
        depth_consistency = np.std(depth_values) / baseline_std if depth_values else 0

        return {
            'avg_snr': avg_snr,
            'depth_variation': depth_consistency,
            'valid_event_count': len(features),
            'snr_std': np.std(snr_values) if snr_values else 0
        }

    def calculate_baseline_mode(signal, bins=1000):
        """
        Calculate the mode of the signal as a robust baseline.
        """
        q1, q3 = np.percentile(signal, [25, 75])
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        filtered_signal = signal[(signal >= lower_bound) & (signal <= upper_bound)]

        if len(filtered_signal) == 0:
            filtered_signal = signal

        counts, bin_edges = np.histogram(filtered_signal, bins=bins)
        peak_idx = np.argmax(counts)
        mode_value = (bin_edges[peak_idx] + bin_edges[peak_idx + 1]) / 2
        return mode_value

    def calculate_comprehensive_snr(y_data, peak_idx, left_bound, right_bound, noise_window=10):
        """
        Calculate comprehensive signal-to-noise ratio (SNR).
        """
        pre_noise_start = max(0, left_bound - noise_window)
        pre_noise_end = left_bound
        post_noise_start = right_bound
        post_noise_end = min(len(y_data), right_bound + noise_window)

        noise_region = np.concatenate([
            y_data[pre_noise_start:pre_noise_end],
            y_data[post_noise_start:post_noise_end]
        ])

        if len(noise_region) < 5:
            return 0
        noise_std = np.std(noise_region)
        if noise_std == 0:
            return 0

        signal_depth = np.median(y_data[left_bound:right_bound]) - y_data[peak_idx]
        return signal_depth / noise_std

    def calculate_kinetic_features(y_data, x_data, start_idx, peak_idx, end_idx, baseline_mean):
        """
        Calculate kinetic features of the event: rise time, fall time, full width at half maximum (FWHM).
        """
        rise_time = x_data[peak_idx] - x_data[start_idx]
        fall_time = x_data[end_idx] - x_data[peak_idx]

        valley_val = y_data[peak_idx]
        half_height = baseline_mean - (baseline_mean - valley_val) / 2

        left_x = x_data[start_idx]
        for i in range(peak_idx, start_idx - 1, -1):
            if y_data[i] >= half_height:
                left_x = x_data[i]
                break

        right_x = x_data[end_idx]
        for i in range(peak_idx, end_idx + 1):
            if y_data[i] >= half_height:
                right_x = x_data[i]
                break

        fwhm = right_x - left_x

        return {
            'rise_time': rise_time,
            'fall_time': fall_time,
            'full_width_half_max': fwhm
        }

    def validate_parameters(sampling_rate):
        if sampling_rate <= 0:
            raise ValueError("Sampling rate must be positive")
        return True

    def parse_voltage_from_filename(filename):
        voltage_match = re.search(r'(\d+)\s*mV', filename, re.IGNORECASE)
        return int(voltage_match.group(1)) if voltage_match else None

    def get_processing_params():
        return {
            'noise_window': 8,
            'savgol_window': 9,
            'kernel_size': 3,
            'outlier_sigma': 4.0,
            'min_width': 3,
            'max_width': 20,
            'min_distance': 10
        }

    def create_connected_peaks_image(features, x_data, y_data, baseline_value,
                                     x_col, y_col, start_idx, output_image,
                                     xlim=None, ylim=None, figsize=(8, 5)):
        if not features:
            return

        print(f"\nCreating connected peaks image...")
        sorted_features = sorted(features, key=lambda x: x['start_time'])
        fig, ax = plt.subplots(figsize=figsize)

        event_color = '#0072B2'
        event_marker = 'o'

        all_x_segments = []
        all_y_segments = []

        if len(all_x_segments) > 0:
            min_x, max_x = min(all_x_segments), max(all_x_segments)
            ax.plot([min_x, max_x], [baseline_value, baseline_value],
                    linewidth=0.6, alpha=0.8, color='#D55E00',
                    linestyle='--', label='Baseline', zorder=1)

        if xlim is None and len(all_x_segments) > 0:
            x_margin = (max(all_x_segments) - min(all_x_segments)) * 0.05
            xlim = [min(all_x_segments) - x_margin, max(all_x_segments) + x_margin]
        if ylim is None and len(all_y_segments) > 0:
            y_min, y_max = min(all_y_segments), max(all_y_segments)
            y_lim_min = min(y_min, baseline_value)
            y_lim_max = max(y_max, baseline_value)
            y_margin = (y_lim_max - y_lim_min) * 0.1
            ylim = [y_lim_min - y_margin, y_lim_max + y_margin]

        if xlim:
            ax.set_xlim(xlim)
        if ylim:
            ax.set_ylim(ylim)

        for i, feature in enumerate(sorted_features):
            array_start = feature['array_start_idx']
            array_end = feature['array_end_idx']

            if array_start < 0 or array_end >= len(y_data):
                continue

            segment_x = x_data[array_start:array_end + 1]
            segment_y = y_data[array_start:array_end + 1]

            all_x_segments.extend(segment_x)
            all_y_segments.extend(segment_y)

            ax.plot(segment_x, segment_y, linewidth=0.7, alpha=0.9,
                    color=event_color, label='Events' if i == 0 else "", zorder=2)

            valley_value = feature['extreme_value']
            rel_idx = feature.get('relative_peak_idx', 0)

            if rel_idx < len(segment_x):
                valley_t = segment_x[rel_idx]
                ax.scatter(valley_t, valley_value,
                           color=event_color, s=20, marker=event_marker,
                           edgecolors='#000000', linewidth=0.5, zorder=3)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_xlabel(x_col)
        ax.set_ylabel(y_col)

        title = f"Connected Peaks ({len(sorted_features)} events) - 0.1 < Sym < 0.55"
        if features[0].get('voltage_mv'):
            title += f" - {features[0]['voltage_mv']} mV"
        ax.set_title(title)
        ax.legend(frameon=False, fontsize=7, loc='best')
        ax.grid(True, linestyle='--', alpha=0.3, linewidth=0.5)
        plt.tight_layout()

        if output_image:
            output_dir = os.path.dirname(output_image)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir)
            base_name = os.path.splitext(output_image)[0]
            connected_image = f"{base_name}_connected_peaks.png"
            plt.savefig(connected_image, dpi=600, bbox_inches='tight', format='png')
            print(f"Connected peaks image saved to: {connected_image}")
        plt.close(fig)
        return connected_image

    def create_detail_comparison_image(features, x_data, y_data_raw, y_data_filtered, baseline_value, output_path):
        if not features or not output_path:
            return

        top_features = sorted(features, key=lambda x: x['valley_depth'], reverse=True)[:6]

        rows = min(len(top_features), 6)
        if rows == 0:
            return

        fig, axes = plt.subplots(rows, 1, figsize=(8, 2 * rows), sharex=False)
        if rows == 1:
            axes = [axes]

        print(f"Generating detailed raw/filtered comparison for top {rows} events...")

        for i, (ax, feature) in enumerate(zip(axes, top_features)):
            start = max(0, feature['array_start_idx'] - 20)
            end = min(len(y_data_raw), feature['array_end_idx'] + 20)

            t = x_data[start:end]
            raw = y_data_raw[start:end]
            filt = y_data_filtered[start:end]

            ax.plot(t, raw, color='#999999', alpha=0.6, linewidth=1, label='Raw Signal')
            ax.plot(t, filt, color='#0072B2', linewidth=1.5, label='Filtered')
            ax.axhline(baseline_value, color='#D55E00', linestyle='--', linewidth=1, label='Baseline')
            ax.axvspan(feature['start_time'], feature['end_time'], color='yellow', alpha=0.2, label='Detected Region')

            ax.set_ylabel('Current (pA)')
            if i == 0:
                ax.legend(loc='upper right', fontsize=6)

            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)

        axes[-1].set_xlabel('Time (s)')
        plt.tight_layout()

        base_name = os.path.splitext(output_path)[0]
        detail_image = f"{base_name}_detail_comparison.png"
        plt.savefig(detail_image, dpi=300, bbox_inches='tight')
        print(f"Event detail comparison image saved to: {detail_image}")
        plt.close(fig)

    # ==================== Main Function Body ====================
    # Set matplotlib and warnings (do it once per call)
    warnings.filterwarnings('ignore')
    plt.rcParams['agg.path.chunksize'] = 10000
    plt.rcParams['font.family'] = 'Arial'
    plt.rcParams['font.size'] = 8
    plt.rcParams['axes.linewidth'] = 0.5
    plt.rcParams['axes.unicode_minus'] = False

    connected_image_path = None  # local variable

    voltage_mv = parse_voltage_from_filename(os.path.basename(csv_file_path))
    proc_params = get_processing_params()

    LIMIT_MAX_WIDTH = 200
    LIMIT_MIN_WIDTH = 3
    LIMIT_MIN_DISTANCE = 10
    SYMMETRY_MIN = 0.1
    SYMMETRY_MAX = 0.55

    print(f"Loaded unified processing parameters, voltage info: {voltage_mv if voltage_mv else 'unidentified'} mV")
    print(f"[Logic optimization] Using Mode as robust baseline")
    print(f"[Strict constraint] Duration range [{LIMIT_MIN_WIDTH}, {LIMIT_MAX_WIDTH}] points")
    print(f"[Continuity] Mask method ensures events are fully continuous below baseline")
    print(f"[Filter condition] Symmetry ratio must be in ({SYMMETRY_MIN}, {SYMMETRY_MAX})")
    print(f"[Important modification] Depth filter condition: valley depth > 1.5 * baseline mode")
    print(f"[New logic] If an event contains points above baseline and the maximum value ≥ |baseline| × 1.2, it is considered invalid")

    validate_parameters(sampling_rate)
    np.random.seed(42)

    try:
        # File reading and data loading
        if not os.path.exists(csv_file_path):
            print(f"Error: File does not exist - {csv_file_path}")
            return None

        with open(csv_file_path, 'r', encoding='utf-8') as f:
            header_line = f.readline().strip()
            total_data_rows = sum(1 for _ in f)
        all_columns = [col.strip() for col in header_line.split(',')]

        end_row = min(end_row, total_data_rows - 1) if end_row else total_data_rows - 1
        actual_row_count = end_row - start_row + 1

        if x_col is None:
            time_keywords = ['time', 't(s)', 't', 'Time']
            for col in all_columns:
                if any(keyword in col.lower() for keyword in time_keywords):
                    x_col = col
                    break
            x_col = x_col or all_columns[0]
        if y_col is None:
            for col in all_columns:
                if col != x_col:
                    y_col = col
                    break

        skip_rows = list(range(1, start_row + 1)) if start_row > 0 else None
        df = pd.read_csv(
            csv_file_path,
            skiprows=skip_rows,
            nrows=actual_row_count,
            usecols=[x_col, y_col],
            header=0
        ).dropna(subset=[x_col, y_col])

        if enable_outlier_removal and not df.empty:
            y_mean, y_std = df[y_col].mean(), df[y_col].std()
            df = df[np.abs(df[y_col] - y_mean) <= proc_params['outlier_sigma'] * y_std]

        if df.empty:
            return None

        df['global_row'] = start_row + df.index
        y_data_raw = df[y_col].values
        x_data = df[x_col].values

        if enable_filtering:
            y_data = medfilt(y_data_raw, kernel_size=proc_params['kernel_size'])
            if len(y_data) > proc_params['savgol_window']:
                y_data = savgol_filter(y_data, proc_params['savgol_window'], savgol_polyorder)
        else:
            y_data = y_data_raw.copy()

        baseline_mode = calculate_baseline_mode(y_data)
        baseline_std = np.std(y_data[np.abs(y_data - baseline_mode) < np.std(y_data)])
        if baseline_std == 0:
            baseline_std = np.std(y_data)

        print(f"Baseline statistics: Mode={baseline_mode:.6f}, local Std={baseline_std:.6f}")

        all_features = []
        excluded_count_symmetry = 0
        excluded_count_upward = 0
        excluded_count_depth = 0

        is_below_baseline = y_data < (baseline_mode - 1e-12)
        padded_mask = np.concatenate(([False], is_below_baseline, [False]))
        diffs = np.diff(padded_mask.astype(int))
        start_indices = np.where(diffs == 1)[0]
        end_indices = np.where(diffs == -1)[0] - 1

        print(f"Initially identified {len(start_indices)} continuous segments below baseline (Mode)")

        abs_baseline = abs(baseline_mode)
        upward_threshold = abs_baseline * 1.2

        last_valid_end_idx = -LIMIT_MIN_DISTANCE - 100

        for start_idx, end_idx in zip(start_indices, end_indices):
            duration = end_idx - start_idx + 1
            if duration < LIMIT_MIN_WIDTH or duration > LIMIT_MAX_WIDTH:
                continue

            distance_from_last = start_idx - last_valid_end_idx
            if distance_from_last <= LIMIT_MIN_DISTANCE:
                continue

            segment_y = y_data[start_idx:end_idx + 1]

            above_mask = segment_y > baseline_mode
            if np.any(above_mask):
                max_up = np.max(segment_y[above_mask])
                if max_up >= upward_threshold:
                    excluded_count_upward += 1
                    continue

            local_min_idx = np.argmin(segment_y)
            peak_idx = start_idx + local_min_idx
            valley_depth = baseline_mode - y_data[peak_idx]

            if valley_depth < 1.5 * baseline_mode:
                excluded_count_depth += 1
                continue

            left_half = peak_idx - start_idx
            right_half = end_idx - peak_idx
            max_half = max(left_half, right_half)
            min_half = min(left_half, right_half)
            symmetry_ratio = 1.0
            if max_half > 0:
                symmetry_ratio = min_half / max_half

            if symmetry_ratio <= SYMMETRY_MIN or symmetry_ratio >= SYMMETRY_MAX:
                excluded_count_symmetry += 1
                continue

            last_valid_end_idx = end_idx

            region_df = df.iloc[start_idx:end_idx + 1]
            area_under_curve = np.trapz(baseline_mode - segment_y)
            snr = calculate_comprehensive_snr(y_data, peak_idx, start_idx, end_idx)
            kinetic = calculate_kinetic_features(y_data, x_data, start_idx, peak_idx, end_idx, baseline_mode)

            feature_data = {
                'voltage_mv': voltage_mv if voltage_mv else 0,
                'feature_type': 'valley',
                'start_row': region_df['global_row'].min(),
                'end_row': region_df['global_row'].max(),
                'array_start_idx': start_idx,
                'array_end_idx': end_idx,
                'start_time': region_df[x_col].min(),
                'end_time': region_df[x_col].max(),
                'extreme_value': y_data[peak_idx],
                'relative_peak_idx': int(local_min_idx),
                'valley_depth': valley_depth,
                'corrected_depth': valley_depth,
                'area_under_curve': area_under_curve,
                'signal_to_noise': snr,
                'duration': duration,
                'symmetry_ratio': symmetry_ratio,
                **kinetic,
                'signal_values': region_df[y_col].tolist(),
                'signal_rows': region_df['global_row'].tolist()
            }
            all_features.append(feature_data)

        all_features.sort(key=lambda x: x['valley_depth'], reverse=True)
        if len(all_features) > max_peak_count:
            all_features = all_features[:max_peak_count]

        print(f"Excluded by depth: {excluded_count_depth} (valley depth < 1.5 * baseline mode)")
        print(f"Excluded by symmetry: {excluded_count_symmetry}")
        print(f"Excluded by upward invalid: {excluded_count_upward} (points above baseline and ≥ |baseline|×1.2)")
        print(f"Final retained events: {len(all_features)}")

        if not all_features:
            print("No events meeting criteria detected")
            return None

        # Data sanity check
        sum_valuePeak = 0
        total_points = 0
        for f in all_features:
            seg_sum = np.sum(y_data[f['array_start_idx']:f['array_end_idx']+1])
            sum_valuePeak += seg_sum
            total_points += (f['array_end_idx'] - f['array_start_idx'] + 1)
        avg_sum = sum_valuePeak / total_points if total_points > 0 else 0
        if abs(avg_sum) - abs(baseline_mode) > 200:
            print(f"Data unreasonable: avg_sum = {avg_sum:.2f}, baseline_mode = {baseline_mode:.2f}, "
                  f"abs(avg_sum)-abs(baseline_mode) = {abs(avg_sum)-abs(baseline_mode):.2f} > 200, skipping image generation.")
            skip_plotting = True
        else:
            skip_plotting = False

        quality_metrics = evaluate_detection_quality(all_features, baseline_std)

        if output_csv:
            save_features = []
            for f in all_features:
                save_f = f.copy()
                save_f['signal_values'] = ','.join(map(str, f['signal_values']))
                save_f['signal_rows'] = ','.join(map(str, f['signal_rows']))
                save_features.append(save_f)
            features_df = pd.DataFrame(save_features)
            if not os.path.exists(os.path.dirname(output_csv)) and os.path.dirname(output_csv):
                os.makedirs(os.path.dirname(output_csv))
            features_df.to_csv(output_csv, index=False, encoding='utf-8-sig')

        if not skip_plotting:
            if create_connected_peaks and output_image:
                connected_image_path = create_connected_peaks_image(
                    features=all_features,
                    x_data=x_data,
                    y_data=y_data,
                    baseline_value=baseline_mode,
                    x_col=x_col,
                    y_col=y_col,
                    start_idx=start_row,
                    output_image=output_image,
                    figsize=(10, 6)
                )

            create_detail_comparison_image(
                features=all_features,
                x_data=x_data,
                y_data_raw=y_data_raw,
                y_data_filtered=y_data,
                baseline_value=baseline_mode,
                output_path=output_image
            )

            if plot_result:
                fig, ax = plt.subplots(figsize=(8, 5))
                ax.plot(x_data, y_data_raw, linewidth=0.5, alpha=0.4, color='#888888', label='Raw')
                ax.plot(x_data, y_data, linewidth=0.7, alpha=0.9, color='#000000', label='Filtered')
                ax.axhline(y=baseline_mode, linewidth=0.6, alpha=0.8, color='#D55E00', linestyle='--',
                           label='Baseline (Mode)')

                event_color = '#0072B2'

                for feature in all_features:
                    ax.axvspan(feature['start_time'], feature['end_time'], alpha=0.2, color=event_color)

                    idx_offset = feature['array_start_idx'] + feature['relative_peak_idx']
                    if idx_offset < len(x_data):
                        valley_t = x_data[idx_offset]
                        ax.scatter(valley_t, feature['extreme_value'], color=event_color, s=10, zorder=5)

                ax.set_title(f"Features: {len(all_features)} (0.1 < Sym < 0.55) - Depth > 1.5×Mode")
                ax.set_xlabel(x_col)
                ax.set_ylabel(y_col)
                ax.legend(loc='upper right', fontsize=7)
                plt.tight_layout()

                if output_image:
                    plt.savefig(output_image, dpi=600, bbox_inches='tight')
                    print(f"Global detection comparison image saved to: {output_image}")
                else:
                    plt.show()
        else:
            print("Skipped all image generation due to unreasonable data.")

        return {
            'features': all_features,
            'quality_metrics': quality_metrics,
            'voltage': voltage_mv,
            'connected_image_path': connected_image_path if not skip_plotting else None
        }

    except Exception as e:
        print(f"Processing failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

import json
import random
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from scipy.spatial.distance import cosine
from scipy.stats import pearsonr

import matplotlib.font_manager as fm
import seaborn as sns
import joblib
import copy
import shutil

# PyTorch deep learning library
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
    from torch.optim.lr_scheduler import OneCycleLR
    import torch.nn.functional as F

    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("⚠️ PyTorch not available, skipping deep learning models")

# SHAP feature importance analysis library
try:
    import shap

    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    print("⚠️ SHAP not available, skipping feature importance analysis")

warnings.filterwarnings('ignore')


def HAP_MoE(
        json_file_path='processed_valleys_data.json',
        test_size=0.15,
        n_splits=5,
        seed=42,
        max_lr=0.002,
        output_dir='hap_moe_results'
):
    """
    HAP-MoE: Hybrid Attention Pooling - Mixture of Experts model for valley feature classification.

    This function performs:
        - Data loading and preprocessing from a JSON file.
        - Feature engineering and selection.
        - 5-fold cross-validation training of HAP-MoE ensemble.
        - Evaluation on a held-out test set.
        - Visualization of confusion matrix, expert utilization, SHAP feature importance,
          and selected feature similarity.
        - Creation of a deployment package.

    Parameters:
        json_file_path (str): Path to the JSON file containing the data.
        test_size (float): Proportion of data to use as test set.
        n_splits (int): Number of folds for cross-validation.
        seed (int): Random seed for reproducibility.
        max_lr (float): Maximum learning rate for OneCycleLR scheduler.
        output_dir (str): Directory to save all outputs (plots, models, deployment package).

    Returns:
        dict: A dictionary containing:
            - test_accuracy (float): Accuracy on test set.
            - class_names (list): List of original class names.
            - simplified_names (list): List of simplified class names.
            - deployment_dir (str): Path to the created deployment package.
    """
    # ==================== Internal Helper Functions ====================
    # (All internal functions and classes are defined here)
    # Note: These are taken from the original code and indented inside HAP_MoE.
    matplotlib.use('Agg')
    def set_seed(seed=42):
        """Lock all random seeds for reproducibility"""
        random.seed(seed)
        np.random.seed(seed)
        if TORCH_AVAILABLE:
            torch.manual_seed(seed)
            torch.cuda.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        print(f"🔒 Global random seed fixed to: {seed}")

    def configure_fonts():
        system_fonts = set(f.name for f in fm.fontManager.ttflist)
        candidate_fonts = ['WenQuanYi Zen Hei', 'Heiti TC', 'SimHei', 'Arial', 'DejaVu Sans', 'sans-serif']
        selected_font = next((f for f in candidate_fonts if f in system_fonts), 'sans-serif')
        plt.rcParams['font.sans-serif'] = [selected_font]

    # Set matplotlib parameters
    plt.rcParams['agg.path.chunksize'] = 10000
    plt.rcParams['font.size'] = 10
    plt.rcParams['axes.linewidth'] = 1.0
    plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    configure_fonts()

    # ==========================================
    # 1. Data parsing and preprocessing
    # ==========================================

    def parse_feature_string(feature_str):
        """
        Parse feature string, handling multiple formats
        """
        features = {}
        try:
            # Handle cases with prefixes
            if "Classification features:" in feature_str and "Core morphology:" in feature_str:
                # Remove prefix, find core morphology start
                core_start = feature_str.find("Core morphology:")
                feature_str = feature_str[core_start:]

            if "Core morphology:" not in feature_str:
                raise ValueError("Missing 'Core morphology' field")

            # Parse core morphology
            core_morphology = feature_str.split("Core morphology:")[1].split("| Kinetics:")[0]
            features['valley_depth'] = float(core_morphology.split("Valley depth(pA):")[1].split(";")[0].strip())
            features['curve_area'] = float(core_morphology.split("Curve area(pA·μs):")[1].split(";")[0].strip())
            features['fwhm'] = float(core_morphology.split("FWHM(μs):")[1].split(";")[0].strip())
            features['current_extreme'] = float(core_morphology.split("Current extreme(pA):")[1].split(";")[0].strip())

            # Handle relative intensity
            rel_str = core_morphology.split("Relative intensity:")[1].split(" |")[0].strip()
            features['relative_intensity'] = float(rel_str)

            # Parse kinetics
            dynamics = feature_str.split("Kinetics:")[1].split("| Signal quality:")[0]
            features['rise_slope'] = float(dynamics.split("Rise slope(pA/μs):")[1].split(";")[0].strip())
            features['fall_slope'] = float(dynamics.split("Fall slope(pA/μs):")[1].split(" |")[0].strip())

            # Parse signal quality
            signal_quality = feature_str.split("Signal quality:")[1].split("| Advanced features:")[0]
            features['snr'] = float(signal_quality.split("SNR:")[1].split(" |")[0].strip())

            # Parse advanced features
            advanced_features = feature_str.split("Advanced features:")[1]
            features['slope_asymmetry'] = float(advanced_features.split("Slope asymmetry:")[1].split(";")[0].strip())
            features['signal_sharpness'] = float(advanced_features.split("Signal sharpness:")[1].split(";")[0].strip())
            features['area_efficiency'] = float(advanced_features.split("Area efficiency:")[1].split(" |")[0].strip())

            return features

        except Exception as e:
            snippet = feature_str[:50] + "..." if len(feature_str) > 50 else feature_str
            print(f"⚠️ Data parsing failed: {str(e)} | Data snippet: {snippet}")
            return None

    def load_and_preprocess_data(json_file_path):
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        features_list = []
        labels = []
        label_mapping = {}
        current_label_id = 0
        skipped_count = 0

        for item in data:
            features = parse_feature_string(item['input'])
            if features is None:
                skipped_count += 1
                continue

            features_list.append(features)
            label_str = item['output'].strip()

            if label_str not in label_mapping:
                label_mapping[label_str] = current_label_id
                current_label_id += 1
            labels.append(label_mapping[label_str])

        if skipped_count > 0:
            print(f"⚠️ Warning: Skipped {skipped_count} unparsable records")

        if not features_list:
            raise ValueError("❌ Error: No data successfully parsed")

        df = pd.DataFrame(features_list)
        labels = np.array(labels)
        reverse_mapping = {v: k for k, v in label_mapping.items()}
        class_names = [reverse_mapping[i] for i in range(len(reverse_mapping))]

        simplified_names = []
        for name in class_names:
            if 'GSH' in name:
                try:
                    parts = name.split()
                    mv = [p for p in parts if 'mV' in p][0] if any('mV' in p for p in parts) else ""
                    simplified = f"GSH_{mv}"
                except:
                    simplified = name[:10]
            elif 'PUTAO' in name:
                simplified = 'PUTAO'
            elif 'N gan' in name:
                simplified = 'NganLao'
            elif 'D mutang' in name:
                simplified = 'Dmutang'
            else:
                simplified = name[:10] + '..'
            simplified_names.append(simplified)

        print(f"\n🎯 Successfully loaded {len(class_names)} classes, {len(labels)} valid samples")
        return df, labels, class_names, simplified_names

    # ==========================================
    # 2. HAP-MoE Model and Loss
    # ==========================================

    class HAP_AdaptiveLoss(nn.Module):
        """[HAP-AdaptiveLoss]"""

        def __init__(self, alpha=None, gamma=2.0, adaptive_weighting=True, reduction='mean'):
            super(HAP_AdaptiveLoss, self).__init__()
            if alpha is not None and not isinstance(alpha, torch.Tensor):
                self.alpha = torch.FloatTensor(alpha)
            else:
                self.alpha = alpha
            self.gamma = gamma
            self.adaptive_weighting = adaptive_weighting
            self.reduction = reduction

        def compute_hard_sample_weights(self, predictions, targets, smoothing=0.1):
            if not self.adaptive_weighting:
                return None
            with torch.no_grad():
                probs = F.softmax(predictions, dim=1)
                target_probs = probs.gather(1, targets.unsqueeze(1)).squeeze()
                hard_weights = (1 - target_probs) + smoothing
                min_w, max_w = hard_weights.min(), hard_weights.max()
                if max_w > min_w:
                    hard_weights = 0.5 + 1.5 * (hard_weights - min_w) / (max_w - min_w + 1e-8)
                else:
                    hard_weights = torch.ones_like(hard_weights)
                return hard_weights

        def forward(self, inputs, targets):
            if self.alpha is not None:
                self.alpha = self.alpha.to(inputs.device)

            ce_loss = F.cross_entropy(inputs, targets, reduction='none', weight=self.alpha)
            pt = torch.exp(-ce_loss)
            adaptive_gamma = self.gamma + (1 - pt.detach()) * 1.0
            focal_loss = ((1 - pt) ** adaptive_gamma) * ce_loss

            if self.adaptive_weighting:
                hard_weights = self.compute_hard_sample_weights(inputs, targets)
                if hard_weights is not None:
                    if focal_loss.dim() > hard_weights.dim():
                        hard_weights = hard_weights.view(-1, 1)
                    elif hard_weights.dim() > focal_loss.dim():
                        hard_weights = hard_weights.squeeze()
                    if focal_loss.shape == hard_weights.shape:
                        focal_loss = focal_loss * hard_weights

            if self.reduction == 'mean':
                return focal_loss.mean()
            elif self.reduction == 'sum':
                return focal_loss.sum()
            else:
                return focal_loss

    class HAP_MoE(nn.Module):
        def __init__(self, input_size, num_classes, dropout_rate=0.25):
            super(HAP_MoE, self).__init__()
            self.input_size = input_size
            self.num_classes = num_classes

            self.feature_encoder = nn.Sequential(
                nn.Linear(input_size, 1024), nn.BatchNorm1d(1024), nn.GELU(), nn.Dropout(dropout_rate * 0.7),
                nn.Linear(1024, 1536), nn.BatchNorm1d(1536), nn.GELU(), nn.Dropout(dropout_rate),
                nn.Linear(1536, 2048), nn.BatchNorm1d(2048), nn.GELU(), nn.Dropout(dropout_rate),
                nn.Linear(2048, 1536), nn.BatchNorm1d(1536), nn.GELU(), nn.Dropout(dropout_rate),
                nn.Linear(1536, 1024), nn.BatchNorm1d(1024), nn.GELU(), nn.Dropout(dropout_rate * 0.7)
            )
            self.attention = nn.MultiheadAttention(1024, num_heads=8, dropout=0.1, batch_first=True)

            self.num_experts = 4  # Changed from 8 experts to 4 experts
            self.experts = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(1024, 768), nn.BatchNorm1d(768), nn.GELU(), nn.Dropout(0.2),
                    nn.Linear(768, 512), nn.BatchNorm1d(512), nn.GELU(), nn.Dropout(0.15),
                    nn.Linear(512, 256), nn.BatchNorm1d(256), nn.GELU(), nn.Dropout(0.1),
                    nn.Linear(256, num_classes)
                ) for _ in range(self.num_experts)
            ])
            self.gating_network = nn.Sequential(
                nn.Linear(1024, 768), nn.GELU(), nn.Dropout(0.2),
                nn.Linear(768, 512), nn.GELU(), nn.Dropout(0.15),
                nn.Linear(512, self.num_experts),  # Output layer now for 4 experts
                nn.Softmax(dim=1)
            )
            self.feature_fusion = nn.Sequential(
                nn.Linear(1024, 768), nn.BatchNorm1d(768), nn.GELU(), nn.Dropout(0.15),
                nn.Linear(768, 512), nn.BatchNorm1d(512), nn.GELU(), nn.Dropout(0.1),
                nn.Linear(512, 256), nn.BatchNorm1d(256), nn.GELU()
            )
            self.classifier = nn.Sequential(
                nn.Linear(256, 192), nn.GELU(), nn.Dropout(0.08),
                nn.Linear(192, 128), nn.GELU(), nn.Dropout(0.05),
                nn.Linear(128, num_classes)
            )
            self.residual = nn.Sequential(nn.Linear(input_size, num_classes), nn.BatchNorm1d(num_classes))
            self.progressive_weights = nn.Parameter(torch.ones(6))
            self.expert_importance = nn.Parameter(torch.ones(self.num_experts))  # Now for 4 experts
            self._initialize_weights()

        def _initialize_weights(self):
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
                elif isinstance(m, nn.BatchNorm1d):
                    nn.init.constant_(m.bias, 0)
            nn.init.uniform_(self.progressive_weights, 0.8, 1.2)
            nn.init.uniform_(self.expert_importance, 0.8, 1.2)

        def forward(self, x):
            encoded_features = x
            layer_outputs = []
            for i, layer in enumerate(self.feature_encoder):
                encoded_features = layer(encoded_features)
                if i % 3 == 2 and len(layer_outputs) < len(self.progressive_weights):
                    layer_outputs.append(encoded_features)

            weighted_features = []
            for i, feat in enumerate(layer_outputs):
                if i < len(self.progressive_weights):
                    weight = self.progressive_weights[i]
                    weighted_features.append(feat * weight)
            final_encoded = weighted_features[-1] if weighted_features else encoded_features

            encoded_features_seq = final_encoded.unsqueeze(1)
            attended_features, _ = self.attention(encoded_features_seq, encoded_features_seq, encoded_features_seq)
            attended_features = attended_features.squeeze(1)

            gating_weights = self.gating_network(attended_features)
            expert_outputs = []
            for i, expert in enumerate(self.experts):
                expert_out = expert(attended_features)
                importance_weight = self.expert_importance[i]
                expert_outputs.append(expert_out.unsqueeze(1) * importance_weight)
            expert_outputs = torch.cat(expert_outputs, dim=1)

            gating_weights_expanded = gating_weights.unsqueeze(2)
            weighted_expert_outputs = expert_outputs * gating_weights_expanded
            gated_ensemble = weighted_expert_outputs.sum(dim=1)

            fused_features = self.feature_fusion(attended_features)
            moe_output = self.classifier(fused_features)

            ensemble_output = 0.6 * gated_ensemble + 0.4 * moe_output
            residual = self.residual(x)
            return ensemble_output + residual

        def extract_gating_weights(self, x):
            with torch.no_grad():
                encoded_features = x
                layer_outputs = []
                for i, layer in enumerate(self.feature_encoder):
                    encoded_features = layer(encoded_features)
                    if i % 3 == 2 and len(layer_outputs) < len(self.progressive_weights):
                        layer_outputs.append(encoded_features)
                weighted_features = []
                for i, feat in enumerate(layer_outputs):
                    if i < len(self.progressive_weights):
                        weight = self.progressive_weights[i]
                        weighted_features.append(feat * weight)
                final_encoded = weighted_features[-1] if weighted_features else encoded_features
                encoded_features_seq = final_encoded.unsqueeze(1)
                attended_features, _ = self.attention(encoded_features_seq, encoded_features_seq, encoded_features_seq)
                attended_features = attended_features.squeeze(1)
                return self.gating_network(attended_features)

    # ==========================================
    # 3. Pipeline
    # ==========================================

    class FeatureEngineeringPipeline:
        def __init__(self):
            self.scaler = None
            self.feature_selector = None
            self.selected_features = None
            self.original_feature_names = None
            self.enhanced_feature_names = None

        def create_enhanced_features(self, df):
            df = df.copy()
            df['slope_ratio'] = np.abs(df['rise_slope'] / (df['fall_slope'] + 1e-8))
            df['area_depth_ratio'] = df['curve_area'] / (np.abs(df['valley_depth']) + 1e-8)
            df['peak_to_valley_ratio'] = np.abs(df['current_extreme'] / (df['valley_depth'] + 1e-8))
            df['signal_steepness'] = (df['rise_slope'] + np.abs(df['fall_slope'])) / 2
            df['asymmetry_index'] = (df['rise_slope'] - df['fall_slope']) / (df['rise_slope'] + df['fall_slope'] + 1e-8)
            df['composite_signal_quality'] = (df['snr'] * df['signal_sharpness']) / (df['fwhm'] + 1e-8)
            df['dynamic_range'] = np.abs(df['current_extreme'] - df['valley_depth'])
            df['energy_efficiency'] = df['curve_area'] / (df['fwhm'] + 1e-8)
            df['slope_consistency'] = np.abs(df['rise_slope'] / (df['fall_slope'] + 1e-8)) - 1
            df['normalized_valley'] = df['valley_depth'] / df['current_extreme']
            df['signal_complexity'] = df['snr'] * df['signal_sharpness'] * df['dynamic_range']
            return df

        def fit(self, X_train, y_train, feature_names):
            print("🛠️ Fitting Feature Pipeline (on Train Set)...")
            self.original_feature_names = feature_names
            df_train = pd.DataFrame(X_train, columns=feature_names)
            df_train_enhanced = self.create_enhanced_features(df_train)
            self.enhanced_feature_names = df_train_enhanced.columns.tolist()
            self.scaler = StandardScaler()
            X_train_scaled = self.scaler.fit_transform(df_train_enhanced)
            print("🎯 Fitting Feature Selector...")
            selector_rf = RandomForestClassifier(n_estimators=100, max_depth=15, random_state=42)
            selector_rf.fit(X_train_scaled, y_train)
            self.feature_selector = SelectFromModel(selector_rf, threshold='0.7*mean')
            self.feature_selector.fit(X_train_scaled, y_train)
            mask = self.feature_selector.get_support()
            self.selected_features = [self.enhanced_feature_names[i] for i in range(len(self.enhanced_feature_names)) if
                                      mask[i]]
            print(f"📊 Selected Features: {len(self.selected_features)}")
            return self

        def transform(self, X):
            if self.scaler is None: raise ValueError("Pipeline not fitted!")
            df = pd.DataFrame(X, columns=self.original_feature_names)
            df_enhanced = self.create_enhanced_features(df)
            df_enhanced = df_enhanced[self.enhanced_feature_names]
            X_scaled = self.scaler.transform(df_enhanced)
            return self.feature_selector.transform(X_scaled)

    # ==========================================
    # Feature similarity computation module (only for final selected features)
    # ==========================================

    def compute_selected_features_similarity(df, pipeline, X_sample=None):
        """
        Compute similarity among the final selected features

        Parameters:
        - df: DataFrame containing original features
        - pipeline: trained feature engineering pipeline
        - X_sample: optional sample data, if None use df

        Returns:
        - similarity_matrices: dictionary of similarity matrices from different methods
        - selected_features: list of selected feature names
        """
        if not pipeline.selected_features:
            print("⚠️ No features selected")
            return None, None

        print("\n" + "=" * 60)
        print("🔍 Computing similarity among selected features")
        print("=" * 60)

        selected_features = pipeline.selected_features
        print(f"📊 Analyzing {len(selected_features)} selected features:")
        for i, feat in enumerate(selected_features):
            print(f"  {i + 1}. {feat}")

        # Prepare data
        if X_sample is None:
            df_enhanced = pipeline.create_enhanced_features(df)
        else:
            df_temp = pd.DataFrame(X_sample, columns=pipeline.original_feature_names)
            df_enhanced = pipeline.create_enhanced_features(df_temp)

        # Use only selected features
        available_features = [f for f in selected_features if f in df_enhanced.columns]
        if len(available_features) != len(selected_features):
            print(f"⚠️ Warning: Some selected features not present in data")
            print(f"  Selected features: {selected_features}")
            print(f"  Available features: {available_features}")

        data = df_enhanced[available_features].values
        n_features = len(available_features)

        similarity_matrices = {}

        # Standardize data
        data_scaled = StandardScaler().fit_transform(data)

        # 1. Pearson correlation coefficient
        print("\n📊 Computing Pearson correlation...")
        pearson_matrix = np.zeros((n_features, n_features))

        for i in range(n_features):
            for j in range(n_features):
                if i == j:
                    pearson_matrix[i, j] = 1.0
                else:
                    correlation, _ = pearsonr(data[:, i], data[:, j])
                    pearson_matrix[i, j] = correlation

        similarity_matrices['pearson'] = pearson_matrix

        # 2. Cosine similarity
        print("📊 Computing cosine similarity...")
        cosine_matrix = np.zeros((n_features, n_features))

        for i in range(n_features):
            for j in range(n_features):
                if i == j:
                    cosine_matrix[i, j] = 1.0
                else:
                    cos_sim = 1 - cosine(data_scaled[:, i], data_scaled[:, j])
                    cosine_matrix[i, j] = cos_sim

        similarity_matrices['cosine'] = cosine_matrix

        return similarity_matrices, available_features

    def analyze_high_similarity_pairs(similarity_matrices, feature_names):
        """
        Analyze highly similar feature pairs

        Parameters:
        - similarity_matrices: dictionary of similarity matrices from different methods
        - feature_names: list of feature names

        Returns:
        - high_similarity_pairs: dictionary of highly similar feature pairs
        """
        high_similarity_pairs = {}

        for method, matrix in similarity_matrices.items():
            print(f"\n🔍 Highly similar feature pairs based on {method} (similarity > 0.8):")

            pairs = []
            n_features = len(feature_names)

            for i in range(n_features):
                for j in range(i + 1, n_features):
                    similarity = matrix[i, j]
                    if similarity > 0.8:
                        pairs.append({
                            'feature1': feature_names[i],
                            'feature2': feature_names[j],
                            'similarity': similarity
                        })

            # Sort by similarity
            pairs.sort(key=lambda x: x['similarity'], reverse=True)

            # Output highly similar pairs
            if pairs:
                for idx, pair in enumerate(pairs[:10]):
                    print(f"  {idx + 1}. {pair['feature1']} ↔ {pair['feature2']}: {pair['similarity']:.4f}")
            else:
                print("  No highly similar pairs found")

            high_similarity_pairs[method] = pairs

        return high_similarity_pairs

    def plot_selected_features_similarity_heatmaps(similarity_matrices, feature_names,
                                                   save_path='selected_features_similarity_heatmap.png'):
        """
        Plot heatmaps of selected features similarity

        Parameters:
        - similarity_matrices: dictionary of similarity matrices from different methods
        - feature_names: list of feature names
        - save_path: path to save the image
        """
        n_methods = len(similarity_matrices)

        # Determine subplot layout based on number of methods
        n_cols = min(2, n_methods)
        n_rows = (n_methods + n_cols - 1) // n_cols

        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 10, n_rows * 8))

        if n_methods == 1:
            axes = np.array([axes])

        axes = axes.flatten()

        # Shorten feature names for display in heatmap
        short_names = []
        for name in feature_names:
            if len(name) > 20:
                short_names.append(name[:18] + '...')
            elif len(name) > 15:
                short_names.append(name[:13] + '...')
            else:
                short_names.append(name)

        for idx, (method, matrix) in enumerate(similarity_matrices.items()):
            if idx < len(axes):
                ax = axes[idx]

                # Create heatmap
                im = ax.imshow(matrix, cmap='coolwarm', vmin=-1, vmax=1, aspect='auto')

                # Set ticks and labels
                ax.set_xticks(np.arange(len(feature_names)))
                ax.set_yticks(np.arange(len(feature_names)))
                ax.set_xticklabels(short_names, rotation=45, ha='right', fontsize=10)
                ax.set_yticklabels(short_names, rotation=0, fontsize=10)

                # Add color bar
                plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

                # Add title
                ax.set_title(f'Selected Features Similarity Matrix ({method})', fontsize=14, fontweight='bold')

                # Add values in heatmap
                thresh = matrix.max() / 2.0
                for i in range(len(feature_names)):
                    for j in range(len(feature_names)):
                        ax.text(j, i, f'{matrix[i, j]:.2f}',
                                ha="center", va="center",
                                color="white" if abs(matrix[i, j]) > thresh else "black",
                                fontsize=8)

        # Hide unused subplots
        for idx in range(len(similarity_matrices), len(axes)):
            axes[idx].axis('off')

        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"📊 Selected features similarity heatmap saved: {save_path}")

        return save_path

    def run_selected_features_similarity_analysis(df, pipeline, X_sample=None):
        """
        Run similarity analysis on selected features

        Parameters:
        - df: DataFrame containing original features
        - pipeline: trained feature engineering pipeline
        - X_sample: optional sample data

        Returns:
        - analysis_results: dictionary of analysis results
        """
        # Compute similarity among selected features
        similarity_matrices, selected_features = compute_selected_features_similarity(df, pipeline, X_sample)

        if similarity_matrices is None:
            return None

        # Analyze highly similar pairs
        high_similarity_pairs = analyze_high_similarity_pairs(similarity_matrices, selected_features)

        # Compute average similarity and similarity statistics
        analysis_results = {
            'selected_features': selected_features,
            'similarity_matrices': similarity_matrices,
            'high_similarity_pairs': high_similarity_pairs,
            'similarity_stats': {}
        }

        # Compute similarity statistics
        for method, matrix in similarity_matrices.items():
            # Only consider upper triangular (excluding diagonal)
            n_features = len(selected_features)
            upper_triangular = []
            for i in range(n_features):
                for j in range(i + 1, n_features):
                    upper_triangular.append(matrix[i, j])

            upper_triangular = np.array(upper_triangular)

            analysis_results['similarity_stats'][method] = {
                'mean': np.mean(upper_triangular),
                'std': np.std(upper_triangular),
                'min': np.min(upper_triangular),
                'max': np.max(upper_triangular),
                'median': np.median(upper_triangular),
                'high_similarity_count': np.sum(upper_triangular > 0.8),
                'high_similarity_ratio': np.sum(upper_triangular > 0.8) / len(upper_triangular)
            }

        # Print statistics
        print("\n📊 Selected features similarity statistics:")
        for method, stats in analysis_results['similarity_stats'].items():
            print(f"\n  {method.upper()} method:")
            print(f"    Mean similarity: {stats['mean']:.4f}")
            print(f"    Std deviation: {stats['std']:.4f}")
            print(f"    Min similarity: {stats['min']:.4f}")
            print(f"    Max similarity: {stats['max']:.4f}")
            print(f"    Median similarity: {stats['median']:.4f}")
            print(f"    High similarity pairs count (>0.8): {stats['high_similarity_count']}")
            print(f"    High similarity ratio: {stats['high_similarity_ratio']:.2%}")

        # Plot heatmaps
        save_path = plot_selected_features_similarity_heatmaps(similarity_matrices, selected_features)
        analysis_results['heatmap_path'] = save_path

        print("\n✅ Selected features similarity analysis complete!")

        return analysis_results

    # ==========================================
    # 4. Training and Ensemble
    # ==========================================

    def should_save_model(current_metrics, best_metrics, epoch, total_epochs):
        current_val_acc = current_metrics['val_acc']
        best_val_acc = best_metrics.get('val_acc', 0.0)

        if current_val_acc > best_val_acc:
            return True, "accuracy_improvement"
        return False, "no_improvement"

    def train_single_fold(X_train_raw, y_train, X_val_raw, y_val, fold_idx, feature_names, num_classes, max_lr=0.002):
        # 1. Pipeline
        pipeline = FeatureEngineeringPipeline()
        pipeline.fit(X_train_raw, y_train, feature_names)
        X_train_proc = pipeline.transform(X_train_raw)
        X_val_proc = pipeline.transform(X_val_raw)
        input_size = X_train_proc.shape[1]

        # 2. Weight calculation
        class_counts = np.bincount(y_train)
        max_count = class_counts.max()
        adjusted_weights = []
        for count in class_counts:
            weight = 1.0 + 1.0 * np.log(max_count / count) if count > 0 else 1.0
            adjusted_weights.append(weight)
        adjusted_weights = np.array(adjusted_weights)
        adjusted_weights = adjusted_weights / adjusted_weights.sum() * len(adjusted_weights)

        # 3. Data Loaders
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        X_train_tensor = torch.FloatTensor(X_train_proc)
        y_train_tensor = torch.LongTensor(y_train)
        X_val_tensor = torch.FloatTensor(X_val_proc)
        y_val_tensor = torch.LongTensor(y_val)

        sample_weights = adjusted_weights[y_train]
        sampler = WeightedRandomSampler(torch.DoubleTensor(sample_weights), len(sample_weights))

        train_loader = DataLoader(TensorDataset(X_train_tensor, y_train_tensor),
                                  batch_size=128, sampler=sampler, drop_last=True)
        val_loader = DataLoader(TensorDataset(X_val_tensor, y_val_tensor),
                                batch_size=256, shuffle=False)

        # 4. Model & Loss
        model = HAP_MoE(input_size=input_size, num_classes=num_classes, dropout_rate=0.25).to(device)
        class_weights_tensor = torch.FloatTensor(adjusted_weights).to(device)

        criterion = HAP_AdaptiveLoss(alpha=class_weights_tensor, gamma=1.3, adaptive_weighting=True)
        optimizer = optim.AdamW(model.parameters(), lr=max_lr, weight_decay=8e-5, betas=(0.9, 0.999))
        scheduler = OneCycleLR(optimizer, max_lr=max_lr, epochs=1200,
                               steps_per_epoch=len(train_loader), pct_start=0.15)

        # 5. Training loop
        best_acc = 0.0
        best_model_state = None

        print(f"\n🔄 Fold {fold_idx + 1} Training (Feats: {input_size})...")

        for epoch in range(1200):
            model.train()
            train_correct = 0
            train_total = 0

            for batch_x, batch_y in train_loader:
                batch_x, batch_y = batch_x.to(device), batch_y.to(device)
                optimizer.zero_grad()
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.5)
                optimizer.step()
                scheduler.step()

                _, predicted = torch.max(outputs.data, 1)
                train_total += batch_y.size(0)
                train_correct += (predicted == batch_y).sum().item()

            train_acc = train_correct / train_total

            model.eval()
            val_correct = 0
            val_total = 0
            with torch.no_grad():
                for batch_x, batch_y in val_loader:
                    batch_x, batch_y = batch_x.to(device), batch_y.to(device)
                    outputs = model(batch_x)
                    _, predicted = torch.max(outputs.data, 1)
                    val_total += batch_y.size(0)
                    val_correct += (predicted == batch_y).sum().item()

            val_acc = val_correct / val_total

            if val_acc > best_acc:
                best_acc = val_acc
                best_model_state = copy.deepcopy(model.state_dict())

            if (epoch + 1) % 200 == 0:
                print(f"  Fold {fold_idx + 1} | Ep {epoch + 1} | Tr: {train_acc:.4f} | Va: {val_acc:.4f}")

        print(f"✅ Fold {fold_idx + 1} Finished. Best Val Acc: {best_acc:.4f}")

        model_filename = f'best_fold_{fold_idx}_model.pth'
        pipeline_filename = f'best_fold_{fold_idx}_pipeline.pkl'

        torch.save(best_model_state, model_filename)
        joblib.dump(pipeline, pipeline_filename)

        model.load_state_dict(best_model_state)
        return model, pipeline, best_acc, model_filename, pipeline_filename

    def train_ensemble_kfold(X_raw, y, feature_names, num_classes, n_splits=5):
        print(f"\n🚀 Starting {n_splits}-Fold Ensemble (Soft Log Weights + Full Cycle)...")
        kfold = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

        saved_artifacts = []
        fold_scores = []
        model_files = []
        pipeline_files = []

        for fold, (train_idx, val_idx) in enumerate(kfold.split(X_raw, y)):
            X_train_fold, X_val_fold = X_raw[train_idx], X_raw[val_idx]
            y_train_fold, y_val_fold = y[train_idx], y[val_idx]

            model, pipeline, best_acc, model_file, pipeline_file = train_single_fold(
                X_train_fold, y_train_fold, X_val_fold, y_val_fold,
                fold_idx=fold, feature_names=feature_names, num_classes=num_classes, max_lr=max_lr
            )

            saved_artifacts.append({
                'model': model,
                'pipeline': pipeline,
                'val_acc': best_acc,
                'model_file': model_file,
                'pipeline_file': pipeline_file
            })
            fold_scores.append(best_acc)
            model_files.append(model_file)
            pipeline_files.append(pipeline_file)

        print(f"\n🏆 CV Average Accuracy: {np.mean(fold_scores):.4f} (±{np.std(fold_scores):.4f})")
        return saved_artifacts, model_files, pipeline_files

    def predict_ensemble(saved_artifacts, X_raw, device):
        """Performance-weighted ensemble prediction"""
        weighted_probs = None
        total_weight = 0.0

        # Calculate weights: e^(acc * 50)
        val_accs = [artifact['val_acc'] for artifact in saved_artifacts]
        weights = np.exp(np.array(val_accs) * 50)
        weights = weights / np.sum(weights)

        with torch.no_grad():
            for i, artifact in enumerate(saved_artifacts):
                model = artifact['model']
                pipeline = artifact['pipeline']
                weight = weights[i]
                model.eval()

                X_proc = pipeline.transform(X_raw)
                X_tensor = torch.FloatTensor(X_proc).to(device)

                outputs = model(X_tensor)
                probs = F.softmax(outputs, dim=1)

                if weighted_probs is None:
                    weighted_probs = probs * weight
                else:
                    weighted_probs += probs * weight

                total_weight += weight

        return torch.max(weighted_probs, 1)[1].cpu().numpy()

    # ==========================================
    # 5. Plotting
    # ==========================================

    def plot_expert_utilization(model, pipeline, X_raw, y_test, class_names, save_path='expert_utilization.png'):
        print("\n🎨 Drawing Expert Heatmap...")
        device = next(model.parameters()).device
        model.eval()

        X_proc = pipeline.transform(X_raw)
        X_tensor = torch.FloatTensor(X_proc)

        gating_weights_list = []
        loader = DataLoader(TensorDataset(X_tensor), batch_size=512, shuffle=False)

        with torch.no_grad():
            for batch in loader:
                inputs = batch[0].to(device)
                weights = model.extract_gating_weights(inputs)
                gating_weights_list.append(weights.cpu().numpy())

        gating_weights = np.concatenate(gating_weights_list, axis=0)
        n_classes = len(class_names)
        n_experts = gating_weights.shape[1]
        class_expert_map = np.zeros((n_classes, n_experts))

        for c in range(n_classes):
            mask = (y_test == c)
            if np.sum(mask) > 0:
                class_expert_map[c] = np.mean(gating_weights[mask], axis=0)

        fig, ax = plt.subplots(figsize=(12, 10))
        sns.heatmap(class_expert_map, cmap='viridis', ax=ax)
        ax.set_xlabel('Expert ID')
        ax.set_ylabel('Class')
        ax.set_title('Expert Utilization Heatmap')
        simple_names = [name[:15] + '..' if len(name) > 15 else name for name in class_names]
        ax.set_yticks(np.arange(len(class_names)) + 0.5)
        ax.set_yticklabels(simple_names, rotation=0, fontsize=8)
        plt.tight_layout()
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"📊 Expert utilization heatmap saved: {save_path}")

    def plot_final_results(y_true, y_pred, class_names, simplified_names, save_path='final_confusion_matrix.png'):
        print("\n🎨 Plotting Final Results...")

        # Sort class names
        def sort_key(name):
            if 'GSH' in name:
                import re
                nums = re.findall(r'\d+', name)
                if nums:
                    return (0, int(nums[0]))
                return (0, 0)
            elif 'PUTAO' in name:
                return (1, 0)
            elif 'NganLao' in name or 'N gan' in name:
                return (2, 0)
            elif 'Dmutang' in name or 'D mutang' in name:
                return (3, 0)
            else:
                return (4, name)

        sorted_indices = sorted(range(len(class_names)), key=lambda i: sort_key(class_names[i]))
        sorted_class_names = [class_names[i] for i in sorted_indices]
        sorted_simplified_names = [simplified_names[i] for i in sorted_indices]

        label_remap = {old_idx: new_idx for new_idx, old_idx in enumerate(sorted_indices)}
        y_true_remapped = np.array([label_remap[label] for label in y_true])
        y_pred_remapped = np.array([label_remap[label] for label in y_pred])

        fig, ax = plt.subplots(figsize=(16, 14))
        cm = confusion_matrix(y_true_remapped, y_pred_remapped)
        cm_norm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

        im = ax.imshow(cm_norm, cmap='Blues', aspect='auto')

        n_classes = cm.shape[0]
        ax.set_xticks(np.arange(n_classes))
        ax.set_yticks(np.arange(n_classes))

        if n_classes > 20:
            display_names = []
            for name in sorted_simplified_names[:n_classes]:
                if len(name) > 8:
                    name = name[:6] + '..'
                display_names.append(name)
        else:
            display_names = sorted_simplified_names[:n_classes]

        ax.set_xticklabels(display_names, rotation=45, ha='right', fontsize=8)
        ax.set_yticklabels(display_names, rotation=0, fontsize=8)

        thresh = cm_norm.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, format(cm[i, j], 'd'),
                        ha="center", va="center",
                        color="white" if cm_norm[i, j] > thresh else "black", fontsize=6)

        ax.set_xlabel('Predicted')
        ax.set_ylabel('True')
        ax.set_title(f'HAP-MoE Ensemble Confusion Matrix (Acc: {accuracy_score(y_true, y_pred):.4f})')
        plt.colorbar(im, ax=ax)
        plt.tight_layout()
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"📊 Result Saved: {save_path}")
        print("\n📋 Final Ensemble Report:")
        print(classification_report(y_true_remapped, y_pred_remapped, target_names=sorted_class_names[:n_classes]))

    def plot_shap_feature_importance(model, pipeline, X_raw, y_test, class_names, simplified_names,
                                     sample_size=None, save_path='shap_feature_importance.png'):
        """Use SHAP to analyze feature importance and visualize"""

        if not SHAP_AVAILABLE:
            print("⚠️ SHAP library not installed, skipping feature importance analysis")
            print("   Install with: pip install shap")
            return None

        print("\n🔍 Computing SHAP Feature Importance...")

        X_proc = pipeline.transform(X_raw)
        feature_names = pipeline.selected_features

        if sample_size is not None and len(X_proc) > sample_size:
            print(f"    Using {sample_size} samples for SHAP analysis...")
            indices = np.random.choice(len(X_proc), sample_size, replace=False)
            X_sample = X_proc[indices]
            y_sample = y_test[indices]
        else:
            X_sample = X_proc
            y_sample = y_test
            print(f"    Using all {len(X_sample)} test samples for SHAP analysis...")

        device = next(model.parameters()).device
        X_tensor = torch.FloatTensor(X_sample).to(device)

        def model_wrapper(x):
            x_tensor = torch.FloatTensor(x).to(device)
            with torch.no_grad():
                outputs = model(x_tensor)
                return F.softmax(outputs, dim=1).cpu().numpy()

        try:
            print("    Computing SHAP values...")

            # Use more efficient background data
            background_data = shap.kmeans(X_sample, min(100, len(X_sample)))

            # Create explainer
            explainer = shap.KernelExplainer(model_wrapper, background_data)

            # Compute SHAP values
            shap_values = explainer.shap_values(X_sample, nsamples=50)

            print(f"   SHAP values computed")

            # Process SHAP values
            if isinstance(shap_values, list):
                shap_abs_mean = np.mean([np.abs(sv).mean(axis=0) for sv in shap_values], axis=0)
                shap_values_single = shap_values[0]
            elif hasattr(shap_values, 'shape') and len(shap_values.shape) == 3:
                shap_abs_mean = np.abs(shap_values).mean(axis=(0, 2))
                shap_values_single = shap_values[:, :, 0]
            else:
                shap_abs_mean = np.abs(shap_values).mean(axis=0)
                shap_values_single = shap_values

            # Adjust feature names length
            if len(feature_names) != len(shap_abs_mean):
                feature_names = feature_names[:len(shap_abs_mean)]

            # Create visualization
            fig, axes = plt.subplots(1, 2, figsize=(16, 7))

            # 1. Global feature importance
            sorted_idx = np.argsort(shap_abs_mean)[-15:]
            sorted_features = [feature_names[i] for i in sorted_idx]
            sorted_values = shap_abs_mean[sorted_idx]

            axes[0].barh(range(len(sorted_features)), sorted_values, color='steelblue')
            axes[0].set_yticks(range(len(sorted_features)))
            axes[0].set_yticklabels(sorted_features)
            axes[0].set_xlabel('Mean |SHAP|')
            axes[0].set_title('Top 15 Feature Importance (Global Average)')

            # 2. SHAP summary plot
            shap.summary_plot(shap_values_single, X_sample,
                              feature_names=feature_names,
                              max_display=min(15, len(feature_names)),
                              show=False,
                              plot_size=None)
            fig2 = plt.gcf()
            fig2.set_size_inches(8, 6)
            plt.tight_layout()
            plt.savefig('shap_summary_plot.png', dpi=300, bbox_inches='tight')
            plt.close(fig2)

            plt.tight_layout()
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"📊 SHAP feature importance plot saved: {save_path}")

            # Print top features
            print(f"\n🎯 Top 10 features most important to model (SHAP):")
            top_10_idx = np.argsort(shap_abs_mean)[-10:][::-1]
            for i, idx in enumerate(top_10_idx):
                if idx < len(feature_names):
                    print(f"  {i + 1}. {feature_names[idx]}: {shap_abs_mean[idx]:.4f}")

            return shap_values, feature_names

        except Exception as e:
            print(f"⚠️ SHAP analysis failed: {str(e)}")
            import traceback
            traceback.print_exc()
            return None

    def create_deployment_package(saved_artifacts, class_names, simplified_names, feature_names,
                                  test_accuracy, X_test_raw, y_test, y_pred):
        deployment_dir = os.path.join(output_dir, "hap_moe_deployment_package")
        if os.path.exists(deployment_dir):
            shutil.rmtree(deployment_dir)
        os.makedirs(deployment_dir, exist_ok=True)

        config = {
            "model_name": "HAP-MoE Ensemble Model",
            "model_type": "HAP_MoE",
            "num_classes": len(class_names),
            "class_names": class_names,
            "simplified_names": simplified_names,
            "original_features": feature_names,
            "test_accuracy": float(test_accuracy),
            "num_folds": len(saved_artifacts),
            "ensemble_weights": [float(artifact['val_acc']) for artifact in saved_artifacts],
            "model_files": [],
            "pipeline_files": [],
            "creation_time": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": "1.0.0"
        }

        for i, artifact in enumerate(saved_artifacts):
            model_src = artifact['model_file']
            pipeline_src = artifact['pipeline_file']

            model_dst = os.path.join(deployment_dir, f"fold_{i}_model.pth")
            pipeline_dst = os.path.join(deployment_dir, f"fold_{i}_pipeline.pkl")

            shutil.copy2(model_src, model_dst)
            shutil.copy2(pipeline_src, pipeline_dst)

            config["model_files"].append(os.path.basename(model_dst))
            config["pipeline_files"].append(os.path.basename(pipeline_dst))

        weights = np.exp(np.array([artifact['val_acc'] for artifact in saved_artifacts]) * 50)
        weights = weights / np.sum(weights)
        config["normalized_weights"] = [float(w) for w in weights]

        config_path = os.path.join(deployment_dir, "model_config.json")
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

        label_mapping = {i: name for i, name in enumerate(class_names)}
        label_mapping_path = os.path.join(deployment_dir, "label_mapping.json")
        with open(label_mapping_path, 'w', encoding='utf-8') as f:
            json.dump(label_mapping, f, ensure_ascii=False, indent=2)

        simplified_mapping = {i: name for i, name in enumerate(simplified_names)}
        simplified_mapping_path = os.path.join(deployment_dir, "simplified_label_mapping.json")
        with open(simplified_mapping_path, 'w', encoding='utf-8') as f:
            json.dump(simplified_mapping, f, ensure_ascii=False, indent=2)

        test_results = {
            "test_accuracy": float(test_accuracy),
            "y_true": y_test.tolist(),
            "y_pred": y_pred.tolist(),
            "confusion_matrix": confusion_matrix(y_test, y_pred).tolist()
        }
        test_results_path = os.path.join(deployment_dir, "test_results.json")
        with open(test_results_path, 'w', encoding='utf-8') as f:
            json.dump(test_results, f, ensure_ascii=False, indent=2)

        return deployment_dir

    # ==================== Main Execution Body ====================
    print("=" * 60)
    print("🔬 HAP-MoE Rigorous Nested-CV Ensemble System")
    print("=" * 60)

    if not TORCH_AVAILABLE:
        print("❌ PyTorch not available, cannot run model")
        return

    # Set seed for reproducibility
    set_seed(seed)

    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    # Change working directory to output_dir for saving files (optional)
    original_cwd = os.getcwd()
    os.chdir(output_dir)

    try:
        # Load data
        df, labels, class_names, simplified_names = load_and_preprocess_data(json_file_path)
        X_raw = df.values
        y = labels
        feature_names = df.columns.tolist()

        print("\n[Step 1] Splitting test set ({:.0%})...".format(test_size))
        X_dev_raw, X_test_raw, y_dev, y_test = train_test_split(
            X_raw, y, test_size=test_size, random_state=seed, stratify=y)

        print(f"📊 Training set: {len(X_dev_raw)} samples")
        print(f"📊 Test set: {len(X_test_raw)} samples")

        print("\n[Step 2] {}-fold cross-validation training of ensemble...".format(n_splits))
        saved_artifacts, model_files, pipeline_files = train_ensemble_kfold(
            X_dev_raw, y_dev, feature_names, len(class_names), n_splits=n_splits)

        print("\n[Step 3] Evaluating on test set...")
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        y_pred = predict_ensemble(saved_artifacts, X_test_raw, device)

        acc = accuracy_score(y_test, y_pred)
        print(f"\n🏆 Final test set accuracy: {acc:.4f}")

        # Save confusion matrix plot
        cm_path = os.path.join(output_dir, 'final_confusion_matrix.png')
        plot_final_results(y_test, y_pred, class_names, simplified_names, save_path=cm_path)

        best_artifact = max(saved_artifacts, key=lambda x: x['val_acc'])
        print(f"\n[Step 4] Generating expert utilization visualization (best model val acc: {best_artifact['val_acc']:.4f})...")
        expert_path = os.path.join(output_dir, 'expert_utilization.png')
        plot_expert_utilization(best_artifact['model'], best_artifact['pipeline'],
                                X_test_raw, y_test, class_names, save_path=expert_path)

        print(f"\n[Step 5] Analyzing feature importance...")
        shap_path = os.path.join(output_dir, 'shap_feature_importance.png')
        shap_results = plot_shap_feature_importance(
            best_artifact['model'],
            best_artifact['pipeline'],
            X_test_raw,
            y_test,
            class_names,
            simplified_names,
            sample_size=200,
            save_path=shap_path
        )

        print(f"\n[Step 6] Analyzing selected features similarity...")
        similarity_results = run_selected_features_similarity_analysis(
            df=df,
            pipeline=best_artifact['pipeline'],
            X_sample=X_test_raw
        )
        # Optionally save similarity heatmap (already saved inside function)

        print(f"\n[Step 7] Creating deployment package...")
        deployment_dir = create_deployment_package(
            saved_artifacts=saved_artifacts,
            class_names=class_names,
            simplified_names=simplified_names,
            feature_names=feature_names,
            test_accuracy=acc,
            X_test_raw=X_test_raw,
            y_test=y_test,
            y_pred=y_pred
        )

        print(f"\n✅ Analysis complete! Deployment package saved to: {deployment_dir}")

        # Clean up temporary files
        print("\n🧹 Cleaning up temporary files...")
        for file in model_files + pipeline_files:
            if os.path.exists(file):
                os.remove(file)
                print(f"   Deleted: {file}")

        # Return results
        return {
            'test_accuracy': acc,
            'class_names': class_names,
            'simplified_names': simplified_names,
            'deployment_dir': deployment_dir
        }

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return None
    finally:
        # Restore original working directory
        os.chdir(original_cwd)

import json
import warnings
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.feature_selection import SelectFromModel
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.neighbors import LocalOutlierFactor
import matplotlib

import matplotlib.pyplot as plt
import seaborn as sns
import os
import joblib
import copy
from scipy import stats

warnings.filterwarnings('ignore')


def load_HAP_MoE(
        deployment_dir="hap_moe_deployment_package",
        new_data_path="processed_valleys_data_val.json",
        anomaly_threshold=0.8,
        output_dir=None,
        save_plots=True,
        return_results=True
):
    """
    Load and run HAP-MoE model for valley feature classification using two-stage detection.

    This function loads a pre-trained HAP-MoE ensemble from a deployment package,
    processes new data from a JSON file, performs two-stage prediction (classification + anomaly detection),
    and optionally saves results and plots.

    Parameters:
        deployment_dir (str): Path to the deployment package directory containing model files.
        new_data_path (str): Path to the new JSON data file to be predicted.
        anomaly_threshold (float): Threshold for anomaly detection (0 to 1). Higher values are more strict.
        output_dir (str, optional): Directory to save output files. If None, uses current directory.
        save_plots (bool): Whether to save visualization plots.
        return_results (bool): Whether to return the prediction results as a dictionary.

    Returns:
        dict: A dictionary containing:
            - predictions: array of predicted class indices (including -1 for unknown)
            - probabilities: array of class probabilities
            - confidence_scores: array of max probabilities
            - top_k_classes: list of top-3 class names
            - top_k_confidences: array of top-3 confidences
            - anomaly_scores: array of anomaly scores
            - report: detailed report dictionary
            - output_files: paths to saved files (if any)
    """
    # ==========================================
    # 1. 重新定义与训练代码完全一致的类
    # ==========================================
    matplotlib.use('Agg')
    class FeatureEngineeringPipeline:
        """特征工程流水线类 - 必须与训练代码中的定义完全一致"""

        def __init__(self):
            self.scaler = None
            self.feature_selector = None
            self.selected_features = None
            self.original_feature_names = None
            self.enhanced_feature_names = None

        def create_enhanced_features(self, df):
            """创建增强特征 - 必须与训练代码完全一致"""
            df = df.copy()
            df['slope_ratio'] = np.abs(df['rise_slope'] / (df['fall_slope'] + 1e-8))
            df['area_depth_ratio'] = df['curve_area'] / (np.abs(df['valley_depth']) + 1e-8)
            df['peak_to_valley_ratio'] = np.abs(df['current_extreme'] / (df['valley_depth'] + 1e-8))
            df['signal_steepness'] = (df['rise_slope'] + np.abs(df['fall_slope'])) / 2
            df['asymmetry_index'] = (df['rise_slope'] - df['fall_slope']) / (
                        df['rise_slope'] + df['fall_slope'] + 1e-8)
            df['composite_signal_quality'] = (df['snr'] * df['signal_sharpness']) / (df['fwhm'] + 1e-8)
            df['dynamic_range'] = np.abs(df['current_extreme'] - df['valley_depth'])
            df['energy_efficiency'] = df['curve_area'] / (df['fwhm'] + 1e-8)
            df['slope_consistency'] = np.abs(df['rise_slope'] / (df['fall_slope'] + 1e-8)) - 1
            df['normalized_valley'] = df['valley_depth'] / df['current_extreme']
            df['signal_complexity'] = df['snr'] * df['signal_sharpness'] * df['dynamic_range']
            return df

        def fit(self, X_train, y_train, feature_names):
            """训练流水线 - 这里只用于理解结构，实际预测时不需要"""
            print("🛠️ Fitting Feature Pipeline (on Train Set)...")
            self.original_feature_names = feature_names
            df_train = pd.DataFrame(X_train, columns=feature_names)
            df_train_enhanced = self.create_enhanced_features(df_train)
            self.enhanced_feature_names = df_train_enhanced.columns.tolist()
            self.scaler = StandardScaler()
            X_train_scaled = self.scaler.fit_transform(df_train_enhanced)
            print("🎯 Fitting Feature Selector...")
            selector_rf = RandomForestClassifier(n_estimators=100, max_depth=15, random_state=42)
            selector_rf.fit(X_train_scaled, y_train)
            self.feature_selector = SelectFromModel(selector_rf, threshold='0.7*mean')
            self.feature_selector.fit(X_train_scaled, y_train)
            mask = self.feature_selector.get_support()
            self.selected_features = [self.enhanced_feature_names[i] for i in range(len(self.enhanced_feature_names)) if
                                      mask[i]]
            print(f"📊 Selected Features: {len(self.selected_features)}")
            return self

        def transform(self, X):
            """转换数据 - 与训练时完全一致"""
            if self.scaler is None:
                raise ValueError("Pipeline not fitted!")
            df = pd.DataFrame(X, columns=self.original_feature_names)
            df_enhanced = self.create_enhanced_features(df)
            df_enhanced = df_enhanced[self.enhanced_feature_names]
            X_scaled = self.scaler.transform(df_enhanced)
            return self.feature_selector.transform(X_scaled)

    class HAP_AdaptiveLoss(nn.Module):
        """[HAP-AdaptiveLoss] - 必须与训练代码中的定义完全一致"""

        def __init__(self, alpha=None, gamma=2.0, adaptive_weighting=True, reduction='mean'):
            super(HAP_AdaptiveLoss, self).__init__()
            if alpha is not None and not isinstance(alpha, torch.Tensor):
                self.alpha = torch.FloatTensor(alpha)
            else:
                self.alpha = alpha
            self.gamma = gamma
            self.adaptive_weighting = adaptive_weighting
            self.reduction = reduction

        def compute_hard_sample_weights(self, predictions, targets, smoothing=0.1):
            if not self.adaptive_weighting:
                return None
            with torch.no_grad():
                probs = F.softmax(predictions, dim=1)
                target_probs = probs.gather(1, targets.unsqueeze(1)).squeeze()
                hard_weights = (1 - target_probs) + smoothing
                min_w, max_w = hard_weights.min(), hard_weights.max()
                if max_w > min_w:
                    hard_weights = 0.5 + 1.5 * (hard_weights - min_w) / (max_w - min_w + 1e-8)
                else:
                    hard_weights = torch.ones_like(hard_weights)
                return hard_weights

        def forward(self, inputs, targets):
            if self.alpha is not None:
                self.alpha = self.alpha.to(inputs.device)

            ce_loss = F.cross_entropy(inputs, targets, reduction='none', weight=self.alpha)
            pt = torch.exp(-ce_loss)
            adaptive_gamma = self.gamma + (1 - pt.detach()) * 1.0
            focal_loss = ((1 - pt) ** adaptive_gamma) * ce_loss

            if self.adaptive_weighting:
                hard_weights = self.compute_hard_sample_weights(inputs, targets)
                if hard_weights is not None:
                    if focal_loss.dim() > hard_weights.dim():
                        hard_weights = hard_weights.view(-1, 1)
                    elif hard_weights.dim() > focal_loss.dim():
                        hard_weights = hard_weights.squeeze()
                    if focal_loss.shape == hard_weights.shape:
                        focal_loss = focal_loss * hard_weights

            if self.reduction == 'mean':
                return focal_loss.mean()
            elif self.reduction == 'sum':
                return focal_loss.sum()
            else:
                return focal_loss

    class HAP_MoE(nn.Module):
        """[HAP-MoE] 架构 - 修改为4个专家，与训练代码完全一致"""

        def __init__(self, input_size, num_classes, dropout_rate=0.25):
            super(HAP_MoE, self).__init__()
            self.input_size = input_size
            self.num_classes = num_classes

            self.feature_encoder = nn.Sequential(
                nn.Linear(input_size, 1024), nn.BatchNorm1d(1024), nn.GELU(), nn.Dropout(dropout_rate * 0.7),
                nn.Linear(1024, 1536), nn.BatchNorm1d(1536), nn.GELU(), nn.Dropout(dropout_rate),
                nn.Linear(1536, 2048), nn.BatchNorm1d(2048), nn.GELU(), nn.Dropout(dropout_rate),
                nn.Linear(2048, 1536), nn.BatchNorm1d(1536), nn.GELU(), nn.Dropout(dropout_rate),
                nn.Linear(1536, 1024), nn.BatchNorm1d(1024), nn.GELU(), nn.Dropout(dropout_rate * 0.7)
            )
            self.attention = nn.MultiheadAttention(1024, num_heads=8, dropout=0.1, batch_first=True)

            # 修改点1: 将专家数量从8个改为4个
            self.num_experts = 4
            self.experts = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(1024, 768), nn.BatchNorm1d(768), nn.GELU(), nn.Dropout(0.2),
                    nn.Linear(768, 512), nn.BatchNorm1d(512), nn.GELU(), nn.Dropout(0.15),
                    nn.Linear(512, 256), nn.BatchNorm1d(256), nn.GELU(), nn.Dropout(0.1),
                    nn.Linear(256, num_classes)
                ) for _ in range(self.num_experts)
            ])
            # 修改点2: gating_network的最后一层输出维度改为4
            self.gating_network = nn.Sequential(
                nn.Linear(1024, 768), nn.GELU(), nn.Dropout(0.2),
                nn.Linear(768, 512), nn.GELU(), nn.Dropout(0.15),
                nn.Linear(512, self.num_experts),  # 输出维度改为4
                nn.Softmax(dim=1)
            )
            self.feature_fusion = nn.Sequential(
                nn.Linear(1024, 768), nn.BatchNorm1d(768), nn.GELU(), nn.Dropout(0.15),
                nn.Linear(768, 512), nn.BatchNorm1d(512), nn.GELU(), nn.Dropout(0.1),
                nn.Linear(512, 256), nn.BatchNorm1d(256), nn.GELU()
            )
            self.classifier = nn.Sequential(
                nn.Linear(256, 192), nn.GELU(), nn.Dropout(0.08),
                nn.Linear(192, 128), nn.GELU(), nn.Dropout(0.05),
                nn.Linear(128, num_classes)
            )
            self.residual = nn.Sequential(nn.Linear(input_size, num_classes), nn.BatchNorm1d(num_classes))
            self.progressive_weights = nn.Parameter(torch.ones(6))
            # 修改点3: expert_importance参数数量改为4
            self.expert_importance = nn.Parameter(torch.ones(self.num_experts))
            self._initialize_weights()

        def _initialize_weights(self):
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
                elif isinstance(m, nn.BatchNorm1d):
                    nn.init.constant_(m.bias, 0)
            nn.init.uniform_(self.progressive_weights, 0.8, 1.2)
            nn.init.uniform_(self.expert_importance, 0.8, 1.2)

        def forward(self, x):
            encoded_features = x
            layer_outputs = []
            for i, layer in enumerate(self.feature_encoder):
                encoded_features = layer(encoded_features)
                if i % 3 == 2 and len(layer_outputs) < len(self.progressive_weights):
                    layer_outputs.append(encoded_features)

            weighted_features = []
            for i, feat in enumerate(layer_outputs):
                if i < len(self.progressive_weights):
                    weight = self.progressive_weights[i]
                    weighted_features.append(feat * weight)
            final_encoded = weighted_features[-1] if weighted_features else encoded_features

            encoded_features_seq = final_encoded.unsqueeze(1)
            attended_features, _ = self.attention(encoded_features_seq, encoded_features_seq, encoded_features_seq)
            attended_features = attended_features.squeeze(1)

            gating_weights = self.gating_network(attended_features)
            expert_outputs = []
            for i, expert in enumerate(self.experts):
                expert_out = expert(attended_features)
                importance_weight = self.expert_importance[i]
                expert_outputs.append(expert_out.unsqueeze(1) * importance_weight)
            expert_outputs = torch.cat(expert_outputs, dim=1)

            gating_weights_expanded = gating_weights.unsqueeze(2)
            weighted_expert_outputs = expert_outputs * gating_weights_expanded
            gated_ensemble = weighted_expert_outputs.sum(dim=1)

            fused_features = self.feature_fusion(attended_features)
            moe_output = self.classifier(fused_features)

            ensemble_output = 0.6 * gated_ensemble + 0.4 * moe_output
            residual = self.residual(x)
            return ensemble_output + residual

        def extract_gating_weights(self, x):
            with torch.no_grad():
                encoded_features = x
                layer_outputs = []
                for i, layer in enumerate(self.feature_encoder):
                    encoded_features = layer(encoded_features)
                    if i % 3 == 2 and len(layer_outputs) < len(self.progressive_weights):
                        layer_outputs.append(encoded_features)
                weighted_features = []
                for i, feat in enumerate(layer_outputs):
                    if i < len(self.progressive_weights):
                        weight = self.progressive_weights[i]
                        weighted_features.append(feat * weight)
                final_encoded = weighted_features[-1] if weighted_features else encoded_features
                encoded_features_seq = final_encoded.unsqueeze(1)
                attended_features, _ = self.attention(encoded_features_seq, encoded_features_seq, encoded_features_seq)
                attended_features = attended_features.squeeze(1)
                return self.gating_network(attended_features)

    # ==========================================
    # 2. 模型部署器类（最终优化版）
    # ==========================================

    class HAPMoEDeployer:
        """HAP-MoE模型部署器 - 使用两阶段识别法"""

        def __init__(self, deployment_dir):
            self.deployment_dir = deployment_dir
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

            # 加载配置
            config_path = os.path.join(deployment_dir, "model_config.json")
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)

            # 加载类别映射
            label_mapping_path = os.path.join(deployment_dir, "label_mapping.json")
            with open(label_mapping_path, 'r', encoding='utf-8') as f:
                self.label_mapping = json.load(f)

            # 创建反向映射
            self.reverse_label_mapping = {v: k for k, v in self.label_mapping.items()}

            # 设置"不知道"类别
            self.unknown_class_index = -1
            self.unknown_class_name = "unknown"

            # 加载模型
            self.models = []
            self.pipelines = []
            self.fold_input_sizes = []
            self.fold_weights = []

            num_folds = self.config['num_folds']
            for i in range(num_folds):
                # 寻找模型文件
                possible_model_paths = [
                    os.path.join(deployment_dir, f"fold_{i}_model.pth"),
                    os.path.join(deployment_dir, f"best_fold_{i}_model.pth"),
                    os.path.join(deployment_dir, f"fold_{i}_model.pt"),
                    os.path.join(deployment_dir, f"best_fold_{i}_model.pt")
                ]

                model_path = None
                for path in possible_model_paths:
                    if os.path.exists(path):
                        model_path = path
                        break

                if model_path is None:
                    print(f"⚠️ 警告: 找不到Fold {i}的模型文件")
                    continue

                # 加载pipeline
                possible_pipeline_paths = [
                    os.path.join(deployment_dir, f"fold_{i}_pipeline.pkl"),
                    os.path.join(deployment_dir, f"best_fold_{i}_pipeline.pkl")
                ]

                pipeline_path = None
                for path in possible_pipeline_paths:
                    if os.path.exists(path):
                        pipeline_path = path
                        break

                if pipeline_path is None:
                    print(f"⚠️ 警告: 找不到Fold {i}的pipeline文件")
                    continue

                try:
                    pipeline = joblib.load(pipeline_path)

                    # 获取输入维度
                    if hasattr(pipeline, 'selected_features'):
                        input_size = len(pipeline.selected_features)
                    elif hasattr(pipeline, 'feature_selector') and hasattr(pipeline.feature_selector, 'get_support'):
                        mask = pipeline.feature_selector.get_support()
                        input_size = np.sum(mask)
                    else:
                        input_size = len(self.config.get('original_features', []))

                    print(f"🔍 Fold {i} 输入特征维度: {input_size}")

                    # 创建模型 - 使用修改后的HAP_MoE类（4个专家）
                    model = HAP_MoE(input_size=input_size, num_classes=self.config['num_classes'], dropout_rate=0.25)
                    model_state_dict = torch.load(model_path, map_location=self.device)
                    model.load_state_dict(model_state_dict)
                    model.to(self.device)
                    model.eval()

                    self.models.append(model)
                    self.pipelines.append(pipeline)
                    self.fold_input_sizes.append(input_size)

                    print(f"✅ 成功加载Fold {i}模型 (输入维度: {input_size}, 专家数量: 4)")
                except Exception as e:
                    print(f"❌ 加载Fold {i}失败: {e}")
                    import traceback
                    traceback.print_exc()

            if len(self.models) == 0:
                raise ValueError("❌ 未能加载任何模型")

            # 集成权重
            val_accs = self.config['ensemble_weights']
            weights = np.exp(np.array(val_accs) * 50)
            weights = weights / np.sum(weights)
            self.fold_weights = weights.tolist()

            # 加载训练数据的特征统计信息（用于异常检测）
            self.feature_stats = self.load_feature_stats()

            # 初始化异常检测器
            self.isolation_forest = None
            self.init_anomaly_detector()

            print(f"\n✅ 成功加载模型: {self.config['model_name']}")
            print(f"   版本: {self.config['version']}")
            print(f"   测试准确率: {self.config['test_accuracy']:.4f}")
            print(f"   类别数量: {self.config['num_classes']}")
            print(f"   成功加载 {len(self.models)} 个fold的模型")
            print(f"   每个模型使用 {self.models[0].num_experts if self.models else '未知'} 个专家")

        def load_feature_stats(self):
            """加载特征统计信息（用于异常检测）"""
            stats_path = os.path.join(self.deployment_dir, "feature_stats.json")
            if os.path.exists(stats_path):
                with open(stats_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return None

        def init_anomaly_detector(self):
            """初始化异常检测器"""
            # 如果没有训练数据特征统计，使用默认方法
            if self.feature_stats:
                print("📊 加载了特征统计信息用于异常检测")
            else:
                print("⚠️ 未找到特征统计信息，使用基于距离的异常检测")

        def parse_feature_string(self, feature_str):
            """解析特征字符串"""
            features = {}
            try:
                if "核心形态:" not in feature_str:
                    raise ValueError("缺少 '核心形态' 字段")

                core_morphology = feature_str.split("核心形态:")[1].split("| 动力学:")[0]
                features['valley_depth'] = float(core_morphology.split("谷深(pA):")[1].split("；")[0])
                features['curve_area'] = float(core_morphology.split("曲线面积(pA·μs):")[1].split("；")[0])
                features['fwhm'] = float(core_morphology.split("半高宽(μs):")[1].split("；")[0])
                features['current_extreme'] = float(core_morphology.split("电流极值(pA):")[1].split("；")[0])

                rel_str = core_morphology.split("相对强度:")[1].split(" |")[0]
                features['relative_intensity'] = float(rel_str.strip())

                dynamics = feature_str.split("动力学:")[1].split("| 信号质量:")[0]
                features['rise_slope'] = float(dynamics.split("上升斜率(pA/μs):")[1].split("；")[0])
                features['fall_slope'] = float(dynamics.split("下降斜率(pA/μs):")[1].split(" |")[0])

                signal_quality = feature_str.split("信号质量:")[1].split("| 高级特征:")[0]
                features['snr'] = float(signal_quality.split("信噪比:")[1].split(" |")[0])

                advanced_features = feature_str.split("高级特征:")[1]
                features['slope_asymmetry'] = float(advanced_features.split("斜率不对称性:")[1].split("；")[0])
                features['signal_sharpness'] = float(advanced_features.split("信号锐度:")[1].split("；")[0])
                features['area_efficiency'] = float(advanced_features.split("面积效率:")[1].split(" |")[0])

                return features

            except Exception as e:
                snippet = feature_str[:50] + "..." if len(feature_str) > 50 else feature_str
                print(f"⚠️ 数据解析失败: {str(e)} | 数据片段: {snippet}")
                return None

        def load_and_preprocess_data(self, json_file_path, has_labels=True):
            """加载和预处理数据"""
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            features_list = []
            labels = []
            skipped_count = 0

            for item in data:
                features = self.parse_feature_string(item['input'])

                if features is None:
                    skipped_count += 1
                    continue

                features_list.append(features)

                if has_labels and 'output' in item:
                    label_str = item['output'].strip()

                    if label_str == self.unknown_class_name:
                        labels.append(self.unknown_class_index)
                    elif label_str in self.reverse_label_mapping:
                        label_idx = int(self.reverse_label_mapping[label_str])
                        labels.append(label_idx)
                    else:
                        labels.append(self.unknown_class_index)
                else:
                    labels.append(self.unknown_class_index)

            if skipped_count > 0:
                print(f"⚠️ 警告: 已跳过 {skipped_count} 条无法解析的数据")

            if not features_list:
                raise ValueError("❌ 错误: 没有成功解析任何数据，请检查输入格式！")

            df = pd.DataFrame(features_list)
            labels = np.array(labels)

            print(f"🎯 成功加载 {len(features_list)} 条有效数据")

            return df, labels

        def predict_with_ensemble(self, df_features):
            """集成预测"""
            original_features = self.config.get('original_features', [])
            missing_features = set(original_features) - set(df_features.columns)
            if missing_features:
                print(f"⚠️ 警告: 缺少以下特征: {missing_features}")
                print(f"   可用的特征: {list(df_features.columns)}")
                raise ValueError(f"输入数据缺少必要的特征: {missing_features}")

            df_features = df_features[original_features]
            X_raw = df_features.values

            all_probs = []

            with torch.no_grad():
                for i, (model, pipeline) in enumerate(zip(self.models, self.pipelines)):
                    try:
                        X_proc = pipeline.transform(X_raw)
                        X_tensor = torch.FloatTensor(X_proc).to(self.device)
                        outputs = model(X_tensor)
                        probs = F.softmax(outputs, dim=1)
                        weighted_probs = probs * self.fold_weights[i]
                        all_probs.append(weighted_probs.cpu().numpy())
                    except Exception as e:
                        print(f"⚠️ Fold {i} 预测失败: {e}")
                        continue

            if not all_probs:
                raise ValueError("❌ 所有fold的预测都失败")

            # 集成平均
            ensemble_probs = np.mean(all_probs, axis=0)
            row_sums = ensemble_probs.sum(axis=1, keepdims=True)
            ensemble_probs = ensemble_probs / row_sums

            return ensemble_probs

        def detect_anomalies(self, df_features, predictions, probabilities):
            """检测异常样本（即"不知道"类别）"""
            n_samples = len(df_features)
            anomaly_scores = np.zeros(n_samples)

            # 方法1: 基于置信度
            confidence_scores = np.max(probabilities, axis=1)

            # 方法2: 基于概率分布的熵
            entropies = -np.sum(probabilities * np.log(probabilities + 1e-10), axis=1)

            # 方法3: 基于特征与训练数据的距离（如果可用）
            if self.feature_stats:
                for i, (_, row) in enumerate(df_features.iterrows()):
                    dist_score = 0
                    for feature in self.config.get('original_features', []):
                        if feature in self.feature_stats:
                            mean = self.feature_stats[feature]['mean']
                            std = self.feature_stats[feature]['std']
                            if std > 0:
                                z_score = abs(row[feature] - mean) / std
                                dist_score += min(z_score, 5)  # 限制最大距离
                    anomaly_scores[i] = dist_score / len(self.config.get('original_features', []))
            else:
                # 如果没有特征统计，使用归一化的熵
                anomaly_scores = entropies / np.log(probabilities.shape[1])

            # 综合异常分数
            final_anomaly_scores = (
                    0.3 * (1 - confidence_scores) +  # 低置信度 -> 高异常分数
                    0.4 * anomaly_scores +  # 特征异常
                    0.3 * (entropies / np.max(entropies + 1e-10))  # 高熵 -> 高异常分数
            )

            return final_anomaly_scores

        def predict_with_two_stage(self, df_features, anomaly_threshold=0.6):
            """
            两阶段预测法：
            1. 第一阶段：常规分类
            2. 第二阶段：异常检测识别"不知道"
            """
            print("🔍 开始两阶段预测...")

            # 第一阶段：常规预测
            probabilities = self.predict_with_ensemble(df_features)
            predictions = np.argmax(probabilities, axis=1)
            confidence_scores = np.max(probabilities, axis=1)

            # 第二阶段：异常检测
            print("🔍 第二阶段：异常检测...")
            anomaly_scores = self.detect_anomalies(df_features, predictions, probabilities)

            # 确定哪些样本是"不知道"
            # 使用自适应阈值：置信度低或异常分数高的样本标记为"不知道"
            final_predictions = predictions.copy()

            for i in range(len(final_predictions)):
                # 计算综合不确定度
                uncertainty_score = (
                        0.5 * (1 - confidence_scores[i]) +  # 置信度因素
                        0.5 * anomaly_scores[i]  # 异常因素
                )

                # 如果综合不确定度超过阈值，标记为"不知道"
                if uncertainty_score > anomaly_threshold:
                    final_predictions[i] = self.unknown_class_index
                # 如果置信度过低，也标记为"不知道"
                elif confidence_scores[i] < 0.3:
                    final_predictions[i] = self.unknown_class_index
                # 如果概率分布太平坦（熵高），标记为"不知道"
                else:
                    probs = probabilities[i]
                    entropy = -np.sum(probs * np.log(probs + 1e-10))
                    max_entropy = np.log(len(probs))
                    if entropy > 0.7 * max_entropy:  # 熵超过最大熵的70%
                        final_predictions[i] = self.unknown_class_index

            # 获取top-k信息
            top_k = 3
            top_k_indices = np.argsort(probabilities, axis=1)[:, ::-1][:, :top_k]
            top_k_confidences = np.take_along_axis(probabilities, top_k_indices, axis=1)

            top_k_classes = []
            for i in range(len(predictions)):
                sample_top_k = []
                for idx in top_k_indices[i]:
                    class_name = self.label_mapping.get(str(idx), f"Class_{idx}")
                    sample_top_k.append(class_name)
                top_k_classes.append(sample_top_k)

            return final_predictions, probabilities, confidence_scores, top_k_classes, top_k_confidences, anomaly_scores

        def predict_from_json(self, json_file_path, anomaly_threshold=0.6):
            """从JSON文件加载数据并进行预测"""
            print(f"📥 加载数据: {json_file_path}")

            df_features, true_labels = self.load_and_preprocess_data(json_file_path, has_labels=True)

            predictions, probabilities, confidence_scores, top_k_classes, top_k_confidences, anomaly_scores = self.predict_with_two_stage(
                df_features, anomaly_threshold
            )

            # 生成报告
            report = self.generate_report(
                predictions, probabilities, confidence_scores, true_labels, top_k_classes, top_k_confidences,
                anomaly_scores
            )

            return predictions, probabilities, confidence_scores, top_k_classes, top_k_confidences, anomaly_scores, report

        def generate_report(self, predictions, probabilities, confidence_scores, true_labels=None,
                            top_k_classes=None, top_k_confidences=None, anomaly_scores=None):
            """生成详细的预测报告"""
            report = {
                "summary": {},
                "class_distribution": {},
                "confidence_distribution": {},
                "anomaly_distribution": {},
                "uncertain_samples": [],
                "classification_report": {}
            }

            total_samples = len(predictions)
            uncertain_samples = np.sum(predictions == self.unknown_class_index)
            certain_samples = total_samples - uncertain_samples

            report["summary"]["total_samples"] = total_samples
            report["summary"]["certain_samples"] = int(certain_samples)
            report["summary"]["uncertain_samples"] = int(uncertain_samples)
            report["summary"]["uncertain_ratio"] = float(uncertain_samples / total_samples) if total_samples > 0 else 0.0

            # 统计每个类别的样本数量
            for class_idx in range(self.config['num_classes']):
                class_name = self.label_mapping.get(str(class_idx), f"Class_{class_idx}")
                class_count = np.sum(predictions == class_idx)
                if class_count > 0:
                    avg_confidence = np.mean(confidence_scores[predictions == class_idx])
                    report["class_distribution"][class_name] = {
                        "count": int(class_count),
                        "percentage": float(class_count / total_samples) if total_samples > 0 else 0.0,
                        "avg_confidence": float(avg_confidence)
                    }

            # 统计"不知道"类别
            unknown_count = np.sum(predictions == self.unknown_class_index)
            if unknown_count > 0:
                unknown_confidences = confidence_scores[predictions == self.unknown_class_index]
                report["class_distribution"][self.unknown_class_name] = {
                    "count": int(unknown_count),
                    "percentage": float(unknown_count / total_samples) if total_samples > 0 else 0.0,
                    "avg_confidence": float(np.mean(unknown_confidences)) if len(unknown_confidences) > 0 else 0.0
                }

            # 置信度分布
            confidence_bins = [0.0, 0.3, 0.5, 0.7, 0.8, 0.9, 1.0]
            for i in range(len(confidence_bins) - 1):
                lower = confidence_bins[i]
                upper = confidence_bins[i + 1]
                mask = (confidence_scores >= lower) & (confidence_scores < upper)
                if i == len(confidence_bins) - 2:
                    mask = (confidence_scores >= lower) & (confidence_scores <= upper)
                bin_count = np.sum(mask)
                report["confidence_distribution"][f"{lower:.1f}-{upper:.1f}"] = {
                    "count": int(bin_count),
                    "percentage": float(bin_count / total_samples) if total_samples > 0 else 0.0
                }

            # 异常分数分布
            if anomaly_scores is not None:
                anomaly_bins = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
                for i in range(len(anomaly_bins) - 1):
                    lower = anomaly_bins[i]
                    upper = anomaly_bins[i + 1]
                    mask = (anomaly_scores >= lower) & (anomaly_scores < upper)
                    if i == len(anomaly_bins) - 2:
                        mask = (anomaly_scores >= lower) & (anomaly_scores <= upper)
                    bin_count = np.sum(mask)
                    report["anomaly_distribution"][f"{lower:.1f}-{upper:.1f}"] = {
                        "count": int(bin_count),
                        "percentage": float(bin_count / total_samples) if total_samples > 0 else 0.0
                    }

            # 不确定样本示例
            uncertain_indices = np.where(predictions == self.unknown_class_index)[0]
            for idx in uncertain_indices[:10]:
                max_prob = np.max(probabilities[idx])
                top_class_idx = np.argmax(probabilities[idx])
                top_class_name = self.label_mapping.get(str(top_class_idx), f"Class_{top_class_idx}")

                sample_info = {
                    "sample_index": int(idx),
                    "max_confidence": float(max_prob),
                    "top_class": top_class_name,
                    "top_class_confidence": float(max_prob)
                }

                if anomaly_scores is not None:
                    sample_info["anomaly_score"] = float(anomaly_scores[idx])

                if top_k_classes is not None and idx < len(top_k_classes):
                    sample_info["top_k_classes"] = top_k_classes[idx]
                    if top_k_confidences is not None and idx < len(top_k_confidences):
                        sample_info["top_k_confidences"] = [float(c) for c in top_k_confidences[idx]]

                report["uncertain_samples"].append(sample_info)

            # 分类报告
            if true_labels is not None and len(true_labels) > 0:
                y_true_transformed = []
                y_pred_transformed = []

                for i in range(len(true_labels)):
                    true_idx = true_labels[i]
                    pred_idx = predictions[i]

                    if true_idx == self.unknown_class_index:
                        y_true_transformed.append(self.unknown_class_name)
                    else:
                        true_label_name = self.label_mapping.get(str(true_idx), f"Class_{true_idx}")
                        y_true_transformed.append(true_label_name)

                    if pred_idx == self.unknown_class_index:
                        y_pred_transformed.append(self.unknown_class_name)
                    else:
                        pred_label_name = self.label_mapping.get(str(pred_idx), f"Class_{pred_idx}")
                        y_pred_transformed.append(pred_label_name)

                all_unique_classes = sorted(set(y_true_transformed + y_pred_transformed))

                try:
                    report_dict = classification_report(
                        y_true_transformed,
                        y_pred_transformed,
                        labels=all_unique_classes,
                        target_names=all_unique_classes,
                        output_dict=True,
                        zero_division=0
                    )

                    report["classification_report"] = report_dict

                    accuracy = accuracy_score(y_true_transformed, y_pred_transformed)
                    report["summary"]["original_accuracy"] = float(accuracy)

                    certain_mask = [pred != self.unknown_class_name for pred in y_pred_transformed]
                    if any(certain_mask):
                        certain_true = [y_true_transformed[i] for i in range(len(y_true_transformed)) if certain_mask[i]]
                        certain_pred = [y_pred_transformed[i] for i in range(len(y_pred_transformed)) if certain_mask[i]]

                        certain_accuracy = accuracy_score(certain_true, certain_pred)
                        report["summary"]["certain_accuracy"] = float(certain_accuracy)
                        report["summary"]["certain_samples_count"] = int(sum(certain_mask))

                    error_mask = [(pred != true and pred != self.unknown_class_name) for pred, true in
                                  zip(y_pred_transformed, y_true_transformed)]
                    if any(error_mask):
                        error_confidences = [confidence_scores[i] for i in range(len(confidence_scores)) if
                                             error_mask[i]]
                        if error_confidences:
                            report["summary"]["error_count"] = int(sum(error_mask))
                            report["summary"]["avg_confidence_on_errors"] = float(np.mean(error_confidences))

                except Exception as e:
                    print(f"⚠️ 生成分类报告时出错: {e}")

            return report

        def plot_predictions(self, predictions, true_labels=None, confidence_scores=None,
                             anomaly_scores=None, save_path='prediction_results.png'):
            """可视化预测结果"""
            print("\n🎨 绘制预测结果图...")

            fig, axes = plt.subplots(2, 2, figsize=(16, 14))

            # 1. 预测类别分布
            pred_labels_processed = []
            for pred in predictions:
                if pred == self.unknown_class_index:
                    pred_labels_processed.append(self.unknown_class_name)
                else:
                    pred_labels_processed.append(self.label_mapping.get(str(pred), f"Class_{pred}"))

            unique_preds, pred_counts = np.unique(pred_labels_processed, return_counts=True)
            sort_indices = np.argsort(
                [label if label != self.unknown_class_name else "zzz" for label in unique_preds])
            unique_preds = unique_preds[sort_indices]
            pred_counts = pred_counts[sort_indices]

            colors = plt.cm.Set3(np.linspace(0, 1, len(unique_preds)))
            axes[0, 0].bar(unique_preds, pred_counts, color=colors)
            axes[0, 0].set_xlabel('预测类别')
            axes[0, 0].set_ylabel('样本数量')
            axes[0, 0].set_title('预测类别分布')
            axes[0, 0].tick_params(axis='x', rotation=45)

            # 2. 置信度分布直方图
            if confidence_scores is not None:
                axes[0, 1].hist(confidence_scores, bins=20, alpha=0.7, color='orange', edgecolor='black')
                axes[0, 1].set_xlabel('置信度')
                axes[0, 1].set_ylabel('样本数量')
                axes[0, 1].set_title('置信度分布')
                axes[0, 1].axvline(x=0.5, color='red', linestyle='--', label='阈值(0.5)')
                axes[0, 1].legend()

            # 3. 异常分数分布
            if anomaly_scores is not None:
                axes[1, 0].hist(anomaly_scores, bins=20, alpha=0.7, color='purple', edgecolor='black')
                axes[1, 0].set_xlabel('异常分数')
                axes[1, 0].set_ylabel('样本数量')
                axes[1, 0].set_title('异常分数分布')
                axes[1, 0].axvline(x=0.6, color='red', linestyle='--', label='阈值(0.6)')
                axes[1, 0].legend()

            # 4. 确定 vs 不确定预测
            uncertain_count = np.sum(predictions == self.unknown_class_index)
            certain_count = len(predictions) - uncertain_count

            axes[1, 1].pie([certain_count, uncertain_count],
                           labels=['确定预测', '不确定预测'],
                           autopct='%1.1f%%',
                           colors=['lightgreen', 'lightcoral'])
            axes[1, 1].set_title('确定 vs 不确定预测')

            plt.tight_layout()
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"📊 预测结果图已保存: {save_path}")

    # ==========================================
    # 3. 执行预测
    # ==========================================

    print("=" * 60)
    print("🔬 HAP-MoE 模型预测系统（两阶段识别法）- 4专家版")
    print("=" * 60)

    print(f"部署包路径: {deployment_dir}")
    print(f"新数据路径: {new_data_path}")
    print(f"异常检测阈值: {anomaly_threshold}")
    print("注意: 使用两阶段识别法（分类 + 异常检测）")
    print("模型架构: HAP-MoE 包含 4 个专家")
    print()

    # 检查文件是否存在
    if not os.path.exists(deployment_dir):
        raise FileNotFoundError(f"❌ 部署包目录不存在: {deployment_dir}")

    if not os.path.exists(new_data_path):
        raise FileNotFoundError(f"❌ 新数据文件不存在: {new_data_path}")

    # 加载部署器
    try:
        deployer = HAPMoEDeployer(deployment_dir)
    except Exception as e:
        print(f"❌ 加载模型失败: {e}")
        import traceback
        traceback.print_exc()
        raise

    # 进行预测
    try:
        predictions, probabilities, confidence_scores, top_k_classes, top_k_confidences, anomaly_scores, report = deployer.predict_from_json(
            new_data_path, anomaly_threshold
        )
    except Exception as e:
        print(f"❌ 预测失败: {e}")
        import traceback
        traceback.print_exc()
        raise

    # 输出详细报告
    print("\n" + "=" * 60)
    print("📋 预测结果报告（两阶段识别法）")
    print("=" * 60)

    # 基本统计
    summary = report["summary"]
    print(f"\n📊 基本统计:")
    print(f"   总样本数: {summary['total_samples']}")
    print(f"   确定预测: {summary['certain_samples']}")
    print(f"   不确定预测: {summary['uncertain_samples']}")
    print(f"   不确定比例: {summary['uncertain_ratio']:.2%}")

    if 'original_accuracy' in summary:
        print(f"   原始准确率: {summary['original_accuracy']:.4f}")
    if 'certain_accuracy' in summary:
        print(f"   确定预测准确率: {summary['certain_accuracy']:.4f}")
    if 'error_count' in summary:
        print(f"   错误预测数量: {summary['error_count']}")
    if 'avg_confidence_on_errors' in summary:
        print(f"   错误预测的平均置信度: {summary['avg_confidence_on_errors']:.4f}")

    # 类别分布
    print(f"\n🎯 预测类别分布:")
    sorted_class_distribution = sorted(report["class_distribution"].items())
    sorted_class_distribution = [item for item in sorted_class_distribution if
                                 item[0] != deployer.unknown_class_name] + \
                                [item for item in sorted_class_distribution if
                                 item[0] == deployer.unknown_class_name]

    for class_name, stats in sorted_class_distribution:
        print(
            f"   {class_name}: {stats['count']}个样本 ({stats['percentage']:.2%}), 平均置信度: {stats['avg_confidence']:.4f}")

    # 置信度分布
    print(f"\n📈 置信度分布:")
    for bin_range, stats in report["confidence_distribution"].items():
        print(f"   置信度{bin_range}: {stats['count']}个样本 ({stats['percentage']:.2%})")

    # 异常分数分布
    if "anomaly_distribution" in report:
        print(f"\n⚠️ 异常分数分布:")
        for bin_range, stats in report["anomaly_distribution"].items():
            print(f"   异常分数{bin_range}: {stats['count']}个样本 ({stats['percentage']:.2%})")

    # 输出详细分类报告
    if "classification_report" in report and report["classification_report"]:
        print(f"\n📋 详细分类报告（包含'unknown'类别）:")
        print("-" * 80)

        class_report = report["classification_report"]
        all_class_names = [name for name in class_report.keys() if
                           name not in ['accuracy', 'macro avg', 'weighted avg']]
        all_class_names_sorted = sorted(all_class_names)
        if deployer.unknown_class_name in all_class_names_sorted:
            all_class_names_sorted.remove(deployer.unknown_class_name)
            all_class_names_sorted.append(deployer.unknown_class_name)

        max_name_len = max([len(name) for name in all_class_names_sorted] + [len("类别")])
        max_name_len = min(max_name_len, 50)

        header_format = f"{{:<{max_name_len}}} {{:<10}} {{:<10}} {{:<10}} {{:<10}}"
        print(header_format.format("类别", "精确率", "召回率", "F1分数", "支持数"))
        print("-" * 80)

        row_format = f"{{:<{max_name_len}}} {{:<10.4f}} {{:<10.4f}} {{:<10.4f}} {{:<10}}"

        for class_name in all_class_names_sorted:
            if class_name in class_report:
                metrics = class_report[class_name]
                if isinstance(metrics, dict):
                    print(row_format.format(
                        class_name[:max_name_len],
                        metrics.get('precision', 0),
                        metrics.get('recall', 0),
                        metrics.get('f1-score', 0),
                        int(metrics.get('support', 0))
                    ))

        print("-" * 80)

        if 'macro avg' in class_report:
            metrics = class_report['macro avg']
            print(row_format.format(
                "宏平均",
                metrics.get('precision', 0),
                metrics.get('recall', 0),
                metrics.get('f1-score', 0),
                int(metrics.get('support', 0))
            ))

        if 'weighted avg' in class_report:
            metrics = class_report['weighted avg']
            print(row_format.format(
                "加权平均",
                metrics.get('precision', 0),
                metrics.get('recall', 0),
                metrics.get('f1-score', 0),
                int(metrics.get('support', 0))
            ))

        if 'accuracy' in class_report:
            accuracy_format = f"{{:<{max_name_len}}} {{:<10}} {{:<10}} {{:<10.4f}} {{:<10}}"
            macro_support = class_report['macro avg']['support'] if 'macro avg' in class_report else 0
            print(accuracy_format.format(
                "准确率",
                "",
                "",
                class_report['accuracy'],
                int(macro_support)
            ))

        print("-" * 80)

    # 不确定样本
    uncertain_samples = report["uncertain_samples"]
    if uncertain_samples:
        print(f"\n❓ 不确定样本示例（前{len(uncertain_samples)}个）:")
        for sample in uncertain_samples:
            print(f"   样本{sample['sample_index']}: 最高置信度{sample['max_confidence']:.4f}, "
                  f"最可能类别: {sample['top_class']} ({sample['top_class_confidence']:.4f})")
            if "anomaly_score" in sample:
                print(f"      异常分数: {sample['anomaly_score']:.4f}")

    # 准备输出目录
    if output_dir is None:
        output_dir = os.getcwd()
    os.makedirs(output_dir, exist_ok=True)

    # 保存预测结果
    output_results = {
        "predictions": predictions.tolist(),
        "confidence_scores": confidence_scores.tolist(),
        "probabilities": probabilities.tolist(),
        "top_k_classes": top_k_classes,
        "top_k_confidences": top_k_confidences.tolist() if top_k_confidences is not None else [],
        "anomaly_scores": anomaly_scores.tolist() if anomaly_scores is not None else [],
        "class_mapping": deployer.label_mapping,
        "summary": summary,
        "class_distribution": report["class_distribution"],
        "confidence_distribution": report["confidence_distribution"],
        "anomaly_distribution": report.get("anomaly_distribution", {}),
        "classification_report": report.get("classification_report", {})
    }

    output_file = os.path.join(output_dir, "prediction_results_final.json")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_results, f, ensure_ascii=False, indent=2)

    print(f"\n💾 详细预测结果已保存到: {output_file}")

    # 可视化
    if save_plots:
        try:
            with open(new_data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            true_labels = []
            for item in data:
                if 'output' in item:
                    label_str = item['output'].strip()
                    if label_str == deployer.unknown_class_name:
                        true_labels.append(deployer.unknown_class_index)
                    elif label_str in deployer.reverse_label_mapping:
                        label_idx = int(deployer.reverse_label_mapping[label_str])
                        true_labels.append(label_idx)
                    else:
                        true_labels.append(deployer.unknown_class_index)
                else:
                    true_labels.append(deployer.unknown_class_index)

            true_labels = np.array(true_labels)

            plot_path = os.path.join(output_dir, 'prediction_visualization_final.png')
            deployer.plot_predictions(
                predictions,
                true_labels,
                confidence_scores,
                anomaly_scores,
                save_path=plot_path
            )
        except Exception as e:
            print(f"⚠️ 可视化失败: {e}")
            import traceback
            traceback.print_exc()

    print("\n✅ 预测完成!")

    if return_results:
        return {
            'predictions': predictions,
            'probabilities': probabilities,
            'confidence_scores': confidence_scores,
            'top_k_classes': top_k_classes,
            'top_k_confidences': top_k_confidences,
            'anomaly_scores': anomaly_scores,
            'report': report,
            'output_files': {
                'results_json': output_file,
                'plot': plot_path if save_plots else None
            }
        }
    else:
        return None

import os
import csv
import json
import glob
import random
from pathlib import Path
import numpy as np
import re
from collections import defaultdict


def PeakCsv_to_Json_Down(
        input_path,
        output_folder=None,
        output_filename=None,
        use_filename_as_class=True,
        split_train_val=True,
        train_ratio=0.8,
        seed=42,
        stratify_by_class=True
):
    """
    Convert peak CSV files (single or multiple) to JSON format for HAP-MoE training,
    with optional splitting into training and validation sets.

    The function automatically detects whether the input is a single file or a folder:
    - If input is a single .csv file, it processes that file.
    - If input is a folder, it processes all .csv files in the folder (and optionally subfolders).

    Parameters:
        input_path (str): Path to a single CSV file or a folder containing CSV files.
        output_folder (str, optional): Output folder for JSON files. If None, uses input's parent directory.
        output_filename (str, optional): Output JSON filename (without split suffixes). Default: "processed_valleys_data.json".
        use_filename_as_class (bool): Whether to extract class label from filename. Default True.
        split_train_val (bool): Whether to split data into train/val sets. Default True.
        train_ratio (float): Proportion of training data (0-1). Default 0.8.
        seed (int): Random seed for reproducibility. Default 42.
        stratify_by_class (bool): Whether to stratify split by class. Default True.

    Returns:
        dict: A dictionary containing:
            - 'success' (bool): True if processing succeeded.
            - 'total_records' (int): Number of records processed.
            - 'output_file' (str): Path to the full JSON file.
            - 'train_file' (str, optional): Path to training JSON file if split.
            - 'val_file' (str, optional): Path to validation JSON file if split.
            - 'data' (list): Full list of JSON records (if not split, or full data).
    """
    # ==================== Internal Helper Functions ====================

    def clean_string(s):
        """
        Clean a string by removing invisible characters, especially zero-width non-breaking spaces (ZWNBSP).
        """
        if s is None:
            return ""
        s = str(s)
        # Remove zero-width non-breaking spaces and other zero-width characters
        s = s.replace('\uFEFF', '').replace('\u200B', '').replace('\u200C', '').replace('\u200D', '')
        # Remove other invisible control characters
        s = ''.join(char for char in s if ord(char) >= 32 or char in '\t\n\r')
        return s.strip()

    def extract_category_from_filename(filename):
        """
        Extract category name from filename - merge different measurement files of the same substance,
        and remove time segments.
        """
        name = os.path.basename(filename)
        if name.startswith('enhanced_'):
            name = name[9:]  # remove 'enhanced_' prefix
        if name.endswith('.csv'):
            name = name[:-4]  # remove '.csv' suffix
        name = clean_string(name)

        # Merge different measurement files by removing trailing underscore+number (e.g., _0, _1)
        name = re.sub(r'_\d+$', '', name)
        name = re.sub(r'-\d+$', '', name)
        name = re.sub(r'\s+\d+$', '', name)

        # Remove time segments: patterns like _X.Xmin-Y.Ymin, _Xs-Ys, etc.
        name = re.sub(r'_\s*\d+\.?\d*\s*min\s*-\s*\d+\.?\d*\s*min', '', name)
        name = re.sub(r'_\s*\d+\.?\d*\s*s\s*-\s*\d+\.?\d*\s*s', '', name)
        name = re.sub(r'_\s*\d+\.?\d*\s*-\s*\d+\.?\d*\s*min', '', name)
        name = re.sub(r'_\s*\d+\.?\d*\s*-\s*\d+\.?\d*\s*$', '', name)

        # Remove possible trailing underscores or spaces
        name = re.sub(r'_\s*$', '', name)
        name = re.sub(r'\s+$', '', name)
        return name

    def safe_float_conversion(value, default=np.nan):
        """Safely convert a value to float."""
        if value is None or value == '' or (isinstance(value, float) and value != value):
            return default
        try:
            if isinstance(value, str):
                value = clean_string(value)
                if 'e' in value.lower() or 'e+' in value.lower() or 'e-' in value.lower():
                    return float(value)
            return float(value)
        except (ValueError, TypeError):
            return default

    def safe_int_conversion(value, default=0):
        """Safely convert a value to int."""
        float_val = safe_float_conversion(value, default)
        if np.isnan(float_val):
            return default
        return int(round(float_val))

    def normalize_slope_values(input_features):
        """
        Normalize slope values: convert abnormally large slopes (likely in per second) to per microsecond.
        """
        normalized = input_features.copy()
        slope_fields = ['rise_slope', 'fall_slope']
        for field in slope_fields:
            if field in normalized and not np.isnan(normalized[field]):
                if abs(normalized[field]) > 1000:
                    normalized[field] = normalized[field] * 1e-6
                    print(f"Normalized slope: {field} from {input_features[field]:.2f} to {normalized[field]:.6f}")
        return normalized

    def normalize_time_values(input_features):
        """
        Normalize time values: convert seconds to microseconds.
        """
        normalized = input_features.copy()
        time_fields = ['rise_time', 'fall_time', 'full_width_half_max']
        for field in time_fields:
            if field in normalized and not np.isnan(normalized[field]):
                normalized[field] = normalized[field] * 1e6
                print(f"Time unit conversion: {field} from {input_features[field]:.2e}s to {normalized[field]:.2f}μs")
        return normalized

    def should_keep_as_string(key, value):
        """Determine whether a key-value pair should be kept as a string."""
        string_fields = ['feature_type', 'feature_name', 'event_class', 'signal_values', 'signal_rows']
        clean_key = clean_string(key).lower()
        if any(field in clean_key for field in [f.lower() for f in string_fields]):
            return True
        if isinstance(value, str):
            cleaned = clean_string(value)
            if any(c.isalpha() for c in cleaned) and 'e' not in cleaned.lower():
                return True
        return False

    def get_instruction():
        """Return the instruction text for the model."""
        return ("You are an electrochemical signal classification expert. "
                "Please output the corresponding material category directly based on the following features, "
                "without explanation or additional content.")

    def format_feature_string(input_features):
        """Format feature dictionary into a string."""
        event_class = input_features.get('event_class', 'unknown')
        feature_type = input_features.get('feature_type', 'valley')
        valley_depth = input_features.get('valley_depth', 0.0)
        area_under_curve = input_features.get('area_under_curve', 0.0)
        full_width_half_max = input_features.get('full_width_half_max', 0.0)
        extreme_value = input_features.get('extreme_value', 0.0)
        rise_slope = input_features.get('rise_slope', 0.0)
        fall_slope = input_features.get('fall_slope', 0.0)
        signal_to_noise = input_features.get('signal_to_noise', 0.0)
        relative_strength = input_features.get('strength', valley_depth)

        slope_asymmetry = abs(rise_slope) / abs(fall_slope) if fall_slope != 0 else 1.0
        signal_sharpness = valley_depth / full_width_half_max if full_width_half_max != 0 else 0
        area_efficiency = area_under_curve / (valley_depth * full_width_half_max) if (
                valley_depth * full_width_half_max) != 0 else 0

        feature_string = (
            f"Classification features: Class: {event_class}; Feature type: {feature_type} | "
            f"Core morphology: Valley depth(pA): {valley_depth:.3f}; Curve area(pA·μs): {area_under_curve:.3f}; "
            f"FWHM(μs): {full_width_half_max:.1f}; Current extreme(pA): {extreme_value:.3f}; "
            f"Relative intensity: {relative_strength:.2f} | "
            f"Kinetics: Rise slope(pA/μs): {rise_slope:.4f}; Fall slope(pA/μs): {fall_slope:.4f} | "
            f"Signal quality: SNR: {signal_to_noise:.2f} | "
            f"Advanced features: Slope asymmetry: {slope_asymmetry:.3f}; Signal sharpness: {signal_sharpness:.4f}; "
            f"Area efficiency: {area_efficiency:.2f}"
        )
        return feature_string

    def extract_features_with_fallback(input_features):
        """Extract required features with fallback defaults."""
        features = {
            'event_class': input_features.get('event_class', 'unknown'),
            'feature_type': input_features.get('feature_type', 'valley'),
            'valley_depth': safe_float_conversion(input_features.get('valley_depth', 0.0), 0.0),
            'area_under_curve': safe_float_conversion(input_features.get('area_under_curve', 0.0), 0.0),
            'full_width_half_max': safe_float_conversion(input_features.get('full_width_half_max', 0.0), 0.0),
            'extreme_value': safe_float_conversion(input_features.get('extreme_value', 0.0), 0.0),
            'rise_slope': safe_float_conversion(input_features.get('rise_slope', 0.0), 0.0),
            'fall_slope': safe_float_conversion(input_features.get('fall_slope', 0.0), 0.0),
            'signal_to_noise': safe_float_conversion(input_features.get('signal_to_noise', 0.0), 0.0),
        }
        for key in features:
            if isinstance(features[key], float) and np.isnan(features[key]):
                features[key] = 0.0

        strength_keys = ['strength', 'relative_strength', 'corrected_depth', 'corrected_height', 'valley_depth']
        strength_value = 0.0
        for key in strength_keys:
            if key in input_features:
                strength_value = safe_float_conversion(input_features[key], 0.0)
                if not np.isnan(strength_value) and strength_value > 0:
                    break
        if np.isnan(strength_value) or strength_value <= 0:
            strength_value = features['valley_depth']
        features['strength'] = strength_value
        return features

    def split_data_into_train_val(json_data, train_ratio=0.8, seed=42, stratify_by_class=True):
        """Split JSON data into training and validation sets."""
        if not json_data:
            return [], []
        random.seed(seed)
        total = len(json_data)
        train_size = int(total * train_ratio)
        print(f"Data split: total={total}, train ratio={train_ratio}")
        print(f"Train size: {train_size}, Val size: {total - train_size}")

        if stratify_by_class:
            print("Using stratified sampling...")
            class_groups = defaultdict(list)
            for item in json_data:
                class_groups[item['output']].append(item)
            train_data = []
            val_data = []
            for class_label, items in class_groups.items():
                class_size = len(items)
                class_train_size = max(1, int(class_size * train_ratio))
                random.shuffle(items)
                train_data.extend(items[:class_train_size])
                val_data.extend(items[class_train_size:])
                print(f"  Class '{class_label}': total={class_size}, train={class_train_size}, val={class_size-class_train_size}")
            random.shuffle(train_data)
            random.shuffle(val_data)
        else:
            print("Using simple random sampling...")
            shuffled = json_data.copy()
            random.shuffle(shuffled)
            train_data = shuffled[:train_size]
            val_data = shuffled[train_size:]
        return train_data, val_data

    def save_split_datasets(json_data, output_filename, output_folder, train_ratio=0.8, seed=42, stratify_by_class=True):
        """Split and save training/validation datasets."""
        train_data, val_data = split_data_into_train_val(json_data, train_ratio, seed, stratify_by_class)
        os.makedirs(output_folder, exist_ok=True)
        base = output_filename.replace('.json', '')
        train_file = os.path.join(output_folder, f"{base}_train.json")
        val_file = os.path.join(output_folder, f"{base}_val.json")

        with open(train_file, 'w', encoding='utf-8') as f:
            json.dump(train_data, f, ensure_ascii=False, indent=2)
        print(f"Train set saved: {train_file} ({len(train_data)} records)")
        with open(val_file, 'w', encoding='utf-8') as f:
            json.dump(val_data, f, ensure_ascii=False, indent=2)
        print(f"Val set saved: {val_file} ({len(val_data)} records)")

        # Print class distribution after split
        if train_data:
            print("\nTraining set class distribution:")
            train_dist = defaultdict(int)
            for item in train_data:
                train_dist[item['output']] += 1
            for cls, cnt in sorted(train_dist.items()):
                print(f"  '{cls}': {cnt}")
        if val_data:
            print("\nValidation set class distribution:")
            val_dist = defaultdict(int)
            for item in val_data:
                val_dist[item['output']] += 1
            for cls, cnt in sorted(val_dist.items()):
                print(f"  '{cls}': {cnt}")

        return train_file, val_file

    def show_statistics(json_data):
        """Display statistics of the JSON data."""
        if not json_data:
            print("No data to show.")
            return
        class_dist = defaultdict(int)
        for item in json_data:
            class_dist[item['output']] += 1
        print("\nClass distribution:")
        total = sum(class_dist.values())
        for cls, cnt in sorted(class_dist.items()):
            print(f"  Class '{cls}': {cnt} records ({cnt/total*100:.1f}%)")
        if json_data:
            print("\nFirst record example:")
            print(json.dumps(json_data[0], ensure_ascii=False, indent=2))

    def process_single_csv(file_path, class_label):
        """Process one CSV file and return list of JSON records."""
        records = []
        print(f"Processing file: {os.path.basename(file_path)}")
        print(f"  Using class: '{class_label}'")
        encodings = ['utf-8-sig', 'utf-8', 'gbk', 'latin-1']
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    reader = csv.DictReader(f)
                    if reader.fieldnames:
                        reader.fieldnames = [clean_string(field) for field in reader.fieldnames]
                    for row in reader:
                        input_features = {}
                        for key, value in row.items():
                            clean_key = clean_string(key)
                            if clean_key.lower() in ['class', 'category', 'label']:
                                continue
                            if should_keep_as_string(key, value):
                                input_features[clean_key] = clean_string(value) if value is not None else ""
                            else:
                                input_features[clean_key] = safe_float_conversion(value)
                        input_features = normalize_slope_values(input_features)
                        input_features = normalize_time_values(input_features)
                        extracted = extract_features_with_fallback(input_features)
                        feature_str = format_feature_string(extracted)
                        records.append({
                            "instruction": get_instruction(),
                            "input": feature_str,
                            "output": class_label
                        })
                    print(f"  Successfully processed: {len(records)} records from this file.")
                    break
            except UnicodeDecodeError:
                print(f"  Failed with {encoding}, trying next...")
                continue
            except Exception as e:
                print(f"  Error with {encoding}: {str(e)}")
                continue
        else:
            print(f"  Error: Could not read file with any encoding.")
        return records

    # ==================== Main Logic ====================

    if output_folder is None:
        if os.path.isfile(input_path):
            output_folder = os.path.dirname(input_path)
        else:
            output_folder = input_path
    os.makedirs(output_folder, exist_ok=True)

    if output_filename is None:
        output_filename = "processed_valleys_data.json"
    elif not output_filename.endswith('.json'):
        output_filename += '.json'

    all_records = []

    if os.path.isfile(input_path):
        # Single file mode
        if not input_path.lower().endswith('.csv'):
            raise ValueError("Input file is not a CSV file.")
        class_label = extract_category_from_filename(input_path) if use_filename_as_class else "unknown"
        records = process_single_csv(input_path, class_label)
        all_records.extend(records)
    elif os.path.isdir(input_path):
        # Batch mode: collect all CSV files
        csv_files = glob.glob(os.path.join(input_path, "*.csv"))
        print(f"Found {len(csv_files)} CSV files in {input_path}")
        category_mapping = {}
        for f in csv_files:
            cat = extract_category_from_filename(f)
            category_mapping[os.path.basename(f)] = cat
        print("File to category mapping:")
        for fname, cat in category_mapping.items():
            print(f"  {fname} -> '{cat}'")
        for csv_file in csv_files:
            class_label = extract_category_from_filename(csv_file) if use_filename_as_class else "unknown"
            records = process_single_csv(csv_file, class_label)
            all_records.extend(records)
        print(f"\nFile merging statistics:")
        file_counts = defaultdict(int)
        for fname, cat in category_mapping.items():
            file_counts[cat] += 1
        for cat, cnt in sorted(file_counts.items()):
            print(f"  Category '{cat}': merged from {cnt} files")
    else:
        raise ValueError(f"Input path does not exist: {input_path}")

    if not all_records:
        print("No records were generated.")
        return {"success": False, "total_records": 0}

    # Save full JSON
    full_output_path = os.path.join(output_folder, output_filename)
    with open(full_output_path, 'w', encoding='utf-8') as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2)

    print(f"\nProcessing complete!")
    print(f"Total records: {len(all_records)}")
    print(f"Full dataset saved: {full_output_path}")

    show_statistics(all_records)

    result = {
        "success": True,
        "total_records": len(all_records),
        "output_file": full_output_path,
        "data": all_records
    }

    if split_train_val and all_records:
        print("\n" + "=" * 50)
        print("Splitting dataset into train/validation...")
        print("=" * 50)
        train_file, val_file = save_split_datasets(
            all_records,
            output_filename,
            output_folder,
            train_ratio,
            seed,
            stratify_by_class
        )
        result["train_file"] = train_file
        result["val_file"] = val_file

    return result