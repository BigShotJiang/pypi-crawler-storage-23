"""
webhooklogger.embed
~~~~~~~~~~~~~~~~~~~
Chainable Embed builder for Discord webhooks.
"""

from datetime import datetime, timezone


class Embed:
    """
    Build a Discord embed with a clean, fluent interface.

    Example::

        embed = (
            Embed()
            .set_title("Hello!")
            .set_description("This is a webhook embed.")
            .set_color("#5865F2")
            .add_field("Status", "Online", inline=True)
            .set_footer("Sent by webhooklogger")
            .set_timestamp()
        )
    """

    # ------------------------------------------------------------------ #
    # Preset colour themes                                                 #
    # ------------------------------------------------------------------ #
    THEMES = {
        "default":  0x5865F2,   # Discord blurple
        "success":  0x57F287,   # green
        "warning":  0xFEE75C,   # yellow
        "error":    0xED4245,   # red
        "info":     0x5DADE2,   # blue
        "dark":     0x2C2F33,   # dark grey
        "light":    0xFFFFFF,   # white
        "purple":   0x9B59B6,
        "orange":   0xE67E22,
        "pink":     0xFF69B4,
    }

    def __init__(self):
        self._data = {}

    # ------------------------------------------------------------------ #
    # Core setters                                                         #
    # ------------------------------------------------------------------ #

    def set_title(self, title: str) -> "Embed":
        """Set the embed title (max 256 chars)."""
        self._data["title"] = str(title)
        return self

    def set_description(self, description: str) -> "Embed":
        """Set the embed description / body text (max 4096 chars)."""
        self._data["description"] = str(description)
        return self

    def set_url(self, url: str) -> "Embed":
        """Make the title a clickable hyperlink."""
        self._data["url"] = str(url)
        return self

    # ------------------------------------------------------------------ #
    # Colour / theme                                                       #
    # ------------------------------------------------------------------ #

    def set_color(self, color) -> "Embed":
        """
        Set the left-border colour.

        Accepts:
        - Hex string  → ``"#FF5733"`` or ``"FF5733"``
        - Integer     → ``16711680``
        - Theme name  → ``"success"``, ``"error"``, ``"warning"``, etc.
        """
        if isinstance(color, str):
            color = color.strip().lstrip("#")
            if color.lower() in self.THEMES:
                self._data["color"] = self.THEMES[color.lower()]
            else:
                self._data["color"] = int(color, 16)
        elif isinstance(color, int):
            self._data["color"] = color
        else:
            raise TypeError("color must be a hex string or int")
        return self

    # Alias for British English users
    set_colour = set_color

    def set_theme(self, theme: str) -> "Embed":
        """
        Apply a named colour theme.

        Available themes: ``default``, ``success``, ``warning``,
        ``error``, ``info``, ``dark``, ``light``, ``purple``,
        ``orange``, ``pink``.
        """
        theme = theme.lower()
        if theme not in self.THEMES:
            raise ValueError(
                f"Unknown theme '{theme}'. "
                f"Available: {', '.join(self.THEMES)}"
            )
        self._data["color"] = self.THEMES[theme]
        return self

    # ------------------------------------------------------------------ #
    # Author                                                               #
    # ------------------------------------------------------------------ #

    def set_author(
        self,
        name: str,
        url: str = None,
        icon_url: str = None,
    ) -> "Embed":
        """Set the author block shown above the title."""
        author = {"name": str(name)}
        if url:
            author["url"] = url
        if icon_url:
            author["icon_url"] = icon_url
        self._data["author"] = author
        return self

    # ------------------------------------------------------------------ #
    # Images                                                               #
    # ------------------------------------------------------------------ #

    def set_thumbnail(self, url: str) -> "Embed":
        """Set the small thumbnail image (top-right corner)."""
        self._data["thumbnail"] = {"url": str(url)}
        return self

    def set_image(self, url: str) -> "Embed":
        """Set the large image shown below the body."""
        self._data["image"] = {"url": str(url)}
        return self

    # ------------------------------------------------------------------ #
    # Footer                                                               #
    # ------------------------------------------------------------------ #

    def set_footer(self, text: str, icon_url: str = None) -> "Embed":
        """Set the footer text and optional icon."""
        footer = {"text": str(text)}
        if icon_url:
            footer["icon_url"] = icon_url
        self._data["footer"] = footer
        return self

    # ------------------------------------------------------------------ #
    # Timestamp                                                            #
    # ------------------------------------------------------------------ #

    def set_timestamp(self, dt: datetime = None) -> "Embed":
        """
        Add a timestamp to the footer.

        Pass a :class:`datetime` object, or leave blank to use **now** (UTC).
        """
        if dt is None:
            dt = datetime.now(tz=timezone.utc)
        self._data["timestamp"] = dt.isoformat()
        return self

    # ------------------------------------------------------------------ #
    # Fields                                                               #
    # ------------------------------------------------------------------ #

    def add_field(
        self,
        name: str,
        value: str,
        inline: bool = False,
    ) -> "Embed":
        """
        Add an inline or block field (up to 25 fields per embed).

        :param name:   Field title.
        :param value:  Field body text.
        :param inline: If ``True``, fields sit side-by-side (up to 3 per row).
        """
        fields = self._data.setdefault("fields", [])
        if len(fields) >= 25:
            raise ValueError("Discord embeds support a maximum of 25 fields")
        fields.append({"name": str(name), "value": str(value), "inline": inline})
        return self

    def clear_fields(self) -> "Embed":
        """Remove all previously added fields."""
        self._data.pop("fields", None)
        return self

    # ------------------------------------------------------------------ #
    # Build                                                                #
    # ------------------------------------------------------------------ #

    def build(self) -> dict:
        """Return the raw embed dictionary ready for the Discord API."""
        return dict(self._data)

    def __repr__(self) -> str:
        title = self._data.get("title", "<no title>")
        fields = len(self._data.get("fields", []))
        return f"<Embed title={title!r} fields={fields}>"
