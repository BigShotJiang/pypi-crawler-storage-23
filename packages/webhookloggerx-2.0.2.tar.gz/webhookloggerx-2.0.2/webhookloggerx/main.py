def hello():
    print("Hello From Webhook Logger!")