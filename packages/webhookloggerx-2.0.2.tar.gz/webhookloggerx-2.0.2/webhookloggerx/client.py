"""
webhooklogger.client
~~~~~~~~~~~~~~~~~~~~
WebhookClient — send messages and embeds to Discord webhooks.
"""

import requests
from .embed import Embed


class WebhookError(Exception):
    """Raised when the Discord API returns a non-2xx response."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"[HTTP {status_code}] {message}")


class WebhookClient:
    """
    Main client for sending data to a Discord webhook URL.

    Example::

        from webhooklogger import WebhookClient, Embed

        client = WebhookClient("https://discord.com/api/webhooks/...")
        client.set_profile(username="MyBot", avatar_url="https://...")
        client.send("Hello, world!")

        embed = (
            Embed()
            .set_title("Alert")
            .set_color("error")
            .set_description("Something went wrong!")
            .set_timestamp()
        )
        client.send_embed(embed)
    """

    BASE_URL = "https://discord.com/api/webhooks/"

    def __init__(self, url: str):
        """
        :param url: Full Discord webhook URL.
        """
        if not url or "discord.com/api/webhooks" not in url:
            raise ValueError(
                "Invalid webhook URL. "
                "It must be a Discord webhook URL "
                "(https://discord.com/api/webhooks/...)."
            )
        self._url = url.rstrip("/") + "?wait=true"
        self._username: str = None
        self._avatar_url: str = None

    # ------------------------------------------------------------------ #
    # Profile                                                              #
    # ------------------------------------------------------------------ #

    def set_profile(
        self,
        username: str = None,
        avatar_url: str = None,
    ) -> "WebhookClient":
        """
        Override the webhook's display name and/or avatar.

        :param username:   Custom display name shown in Discord.
        :param avatar_url: URL to an image used as the avatar.

        Returns ``self`` so you can chain calls::

            client.set_profile(username="AlertBot", avatar_url="https://...")
        """
        if username:
            self._username = str(username)
        if avatar_url:
            self._avatar_url = str(avatar_url)
        return self

    # ------------------------------------------------------------------ #
    # Internal helpers                                                     #
    # ------------------------------------------------------------------ #

    def _base_payload(self) -> dict:
        payload = {}
        if self._username:
            payload["username"] = self._username
        if self._avatar_url:
            payload["avatar_url"] = self._avatar_url
        return payload

    def _post(self, payload: dict) -> dict:
        """Send the payload and raise WebhookError on failure."""
        response = requests.post(self._url, json=payload, timeout=10)
        if not response.ok:
            try:
                detail = response.json().get("message", response.text)
            except Exception:
                detail = response.text
            raise WebhookError(response.status_code, detail)
        return response.json()

    # ------------------------------------------------------------------ #
    # Public send methods                                                  #
    # ------------------------------------------------------------------ #

    def send(self, content: str) -> dict:
        """
        Send a plain text message.

        :param content: The message text (max 2000 chars).
        :returns: The response dict from Discord.
        """
        if not content:
            raise ValueError("content cannot be empty")
        payload = self._base_payload()
        payload["content"] = str(content)
        return self._post(payload)

    def send_embed(self, embed: Embed) -> dict:
        """
        Send a single :class:`~webhooklogger.Embed`.

        :param embed: An :class:`~webhooklogger.Embed` instance.
        :returns: The response dict from Discord.
        """
        if not isinstance(embed, Embed):
            raise TypeError("embed must be an Embed instance")
        payload = self._base_payload()
        payload["embeds"] = [embed.build()]
        return self._post(payload)

    def send_embeds(self, embeds: list) -> dict:
        """
        Send multiple embeds in a single request (up to 10).

        :param embeds: A list of :class:`~webhooklogger.Embed` instances.
        :returns: The response dict from Discord.
        """
        if not embeds:
            raise ValueError("embeds list cannot be empty")
        if len(embeds) > 10:
            raise ValueError("Discord allows a maximum of 10 embeds per message")
        for i, e in enumerate(embeds):
            if not isinstance(e, Embed):
                raise TypeError(f"Item at index {i} is not an Embed instance")
        payload = self._base_payload()
        payload["embeds"] = [e.build() for e in embeds]
        return self._post(payload)

    def send_message(self, content: str = None, embed: Embed = None) -> dict:
        """
        Send a message with optional text content AND an embed together.

        :param content: Optional plain text message.
        :param embed:   Optional :class:`~webhooklogger.Embed`.
        :returns: The response dict from Discord.
        """
        if content is None and embed is None:
            raise ValueError("Provide at least content or an embed")
        payload = self._base_payload()
        if content:
            payload["content"] = str(content)
        if embed:
            if not isinstance(embed, Embed):
                raise TypeError("embed must be an Embed instance")
            payload["embeds"] = [embed.build()]
        return self._post(payload)

    # ------------------------------------------------------------------ #
    # Repr                                                                 #
    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        name = self._username or "<default>"
        return f"<WebhookClient username={name!r}>"
