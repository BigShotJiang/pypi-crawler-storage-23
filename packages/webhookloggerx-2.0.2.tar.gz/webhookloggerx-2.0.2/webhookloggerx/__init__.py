"""
webhookloggerx
~~~~~~~~~~~~~~
A clean, user-friendly Python package for sending Discord webhook messages
and rich embeds.

Usage::

    from webhookloggerx import WebhookClient, Embed

    client = WebhookClient("https://discord.com/api/webhooks/...")
    client.set_profile(username="MyBot")
    client.send("Hello from webhookloggerx!")

    embed = (
        Embed()
        .set_title("Notification")
        .set_theme("success")
        .set_description("Everything is running smoothly.")
        .set_timestamp()
    )
    client.send_embed(embed)

:license: MIT
"""

from .client import WebhookClient, WebhookError
from .embed import Embed

__all__ = ["WebhookClient", "WebhookError", "Embed"]
__version__ = "2.0.2"
__author__ = "Nur Mohammad Rafi"