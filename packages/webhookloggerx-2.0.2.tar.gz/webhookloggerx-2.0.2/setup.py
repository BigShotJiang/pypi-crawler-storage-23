from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="webhookloggerx",
    version="2.0.2",
    packages=find_packages(),
    install_requires=[
        "requests>=2.20.0",
    ],
    author="Nur Mohammad Rafi",
    author_email="",
    description="A clean, user-friendly Python package for sending Discord webhook messages and rich embeds.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    # url="https://github.com/yourusername/webhooklogger",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Communications",
    ],
    python_requires=">=3.7",
    keywords="discord webhook embed notification bot",
)