"""MCP protocol support for Sage."""

from sage.mcp.client import MCPClient
from sage.mcp.server import MCPServer

__all__ = ["MCPClient", "MCPServer"]
