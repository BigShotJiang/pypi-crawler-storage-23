"""Git integration for Sage."""
