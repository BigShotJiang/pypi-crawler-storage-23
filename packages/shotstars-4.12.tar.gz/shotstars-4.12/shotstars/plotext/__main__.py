from .plotext_cli import main
main()
