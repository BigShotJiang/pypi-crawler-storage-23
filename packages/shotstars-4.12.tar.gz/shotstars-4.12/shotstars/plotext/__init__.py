"""\nplotext plots directly on terminal"""
    
__name__ = "plotext"
__version__ = "5.3.2"

from ._core import *
#from .plotext_cli import build_parser # not sure why this line was here
