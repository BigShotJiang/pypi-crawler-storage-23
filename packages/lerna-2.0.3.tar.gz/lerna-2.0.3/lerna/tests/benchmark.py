# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

from typing import Any

from pytest import fixture

from lerna._internal.config_loader_impl import ConfigLoaderImpl
from lerna._internal.utils import create_config_search_path
from lerna.types import RunMode


@fixture(scope="module")
def config_loader() -> Any:
    return ConfigLoaderImpl(config_search_path=create_config_search_path("pkg://lerna.test_utils.configs"))


def test_config_loading(config_loader: ConfigLoaderImpl, benchmark: Any) -> None:
    benchmark(
        config_loader.load_configuration,
        "config",
        overrides=[],
        run_mode=RunMode.RUN,
    )
