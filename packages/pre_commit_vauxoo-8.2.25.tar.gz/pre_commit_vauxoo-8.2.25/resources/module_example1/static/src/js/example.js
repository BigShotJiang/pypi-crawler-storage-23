/** @odoo-module **/

function greet(name) {
    return "Hello " + name;
}
