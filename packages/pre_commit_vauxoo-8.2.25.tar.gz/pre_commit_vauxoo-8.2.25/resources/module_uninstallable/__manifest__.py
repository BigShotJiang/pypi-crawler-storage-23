{
    "name": "Uninstallable Module",
    "description": "Dummy Module to Verify pre-commit-vauxoo does not include modules with installable: False",
    "author": "Vauxoo,Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "website": "https://vauxoo.com",
    "category": "Uncategorized",
    "version": "15.0.1.0.0",
    "depends": ["base"],
    "data": [],
    "demo": [],
    "installable": False
}
