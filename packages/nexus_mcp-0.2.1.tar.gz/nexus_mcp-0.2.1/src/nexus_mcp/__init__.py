"""Nexus MCP - AI CLI Agent MCP Server."""
