"""
GCP Pipeline Core Library
"""
__version__ = "0.1.0"
