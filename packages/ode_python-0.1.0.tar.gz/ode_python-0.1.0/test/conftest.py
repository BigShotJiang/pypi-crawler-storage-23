# -*- coding: utf-8 -*-

from .utils.world import g
from .utils.world import world

from .utils.space import space
from .utils.space import ground
from .utils.space import contactgroup
