# -*- coding: utf-8 -*-

DS_VERSION = 0x0002
