"""
Build client for connecting to remote CodeSpeak build server.
"""

import json
import logging
import queue
import threading
from argparse import Namespace
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from typing import Any, cast

import grpc
from api_stubs import os_environment_pb2
from api_stubs.build_server_pb2 import (
    CancelBuildRequest,
    ClientMessage,
    ServerMessage,
    StartBuildRequest,
)
from api_stubs.build_server_pb2_grpc import BuildServiceStub
from api_stubs.operation_logging import OsEnvRequestLogging
from api_stubs.os_environment_pb2 import OperationRequest, OperationResponse
from codespeak_shared import BuildResult
from codespeak_shared.build_insight.events import (
    BuildInsightEvent,
    ProgressItemCreateEvent,
    ProgressItemUpdateEvent,
    SpanCloseEvent,
    SpanOpenEvent,
    TestsRunEvent,
    TextOutputEvent,
    ToolCallEvent,
    UserVisibleModelOutputEvent,
)
from codespeak_shared.build_insight.storage import BuildInsightStorage, BuildInsightStorageMode
from codespeak_shared.codespeak_project import FileBasedCodeSpeakProject
from codespeak_shared.env_allowlist import filter_env_vars
from codespeak_shared.exceptions import (
    BuildStartFailedUserError,
    CodespeakInternalError,
    CodeSpeakServerUnavailableUserError,
)
from codespeak_shared.os_environment import OsEnvironment
from codespeak_shared.os_environment.os_environment import ClientResponseTooBig
from codespeak_shared.progress.rich_progress_output import RichBasedCliProgressRenderer
from codespeak_shared.protocol_version import CURRENT_VERSION as PROTOCOL_VERSION
from rich.console import Console

from console_client.auth.token_storage import load_user_token
from console_client.build_client_event_converter import (
    convert_build_finished_proto_to_result,
    convert_proto_to_build_insight_event,
)
from console_client.client_feature_flags import ConsoleClientFeatureFlags
from console_client.os_environment_servicer import OsEnvironmentServicer
from console_client.sequence_reorder_buffer import SequenceReorderBuffer


def _get_build_insight_event_summary(event: BuildInsightEvent) -> str:
    if isinstance(event, ProgressItemCreateEvent):
        return f"create '{event.title}' [{event.status.value}]"
    elif isinstance(event, ProgressItemUpdateEvent):
        status_text = f" ({event.status_text})" if event.status_text else ""
        return f"update [{event.status.value}]{status_text}"
    elif isinstance(event, ToolCallEvent):
        return f"tool '{event.title}'"
    elif isinstance(event, TextOutputEvent):
        text_preview = event.text[:50] + "..." if len(event.text) > 50 else event.text
        return f"text: {text_preview}"
    elif isinstance(event, UserVisibleModelOutputEvent):
        text_preview = event.text[:50] + "..." if len(event.text) > 50 else event.text
        return f"output: {text_preview}"
    elif isinstance(event, SpanOpenEvent):
        return f"span_open '{event.title}'"
    elif isinstance(event, SpanCloseEvent):
        return f"span_close '{event.span_id[:8]}'"
    elif isinstance(event, TestsRunEvent):
        return "tests_run"
    else:
        return type(event).__name__


def handle_os_env_request(
    request: OperationRequest,
    os_env: OsEnvironment,
    logger: logging.Logger,
    console: Console,
) -> OperationResponse:
    """Handle an OsEnvironment operation request from the server."""
    try:
        # Use OsEnvironmentServicer to handle the request
        servicer = OsEnvironmentServicer(os_env, console)

        # Handle the request synchronously
        # The servicer's StreamOperations method processes requests one at a time
        def request_iter() -> Iterator[OperationRequest]:
            yield request

        # Process the request and get the response
        response_iterator = servicer.StreamOperations(request_iter(), None)
        response: OperationResponse = next(response_iterator)
        return response
    except Exception as e:  # noqa: BLE001 (os env handler catch-all block)
        # Return a response with client_error set - server will check this field first
        logger.exception(f"Error handling OsEnv request: {e}")
        error_info = os_environment_pb2.ErrorInfo(
            message=f"Client internal error: {type(e).__name__}: {e}",
            type=os_environment_pb2.ErrorType.ERROR_TYPE_UNSPECIFIED,
        )
        return OperationResponse(request_id=request.request_id, client_internal_error=error_info)


def run_build_client(
    args: Namespace,
    local_project: FileBasedCodeSpeakProject,
    client_feature_flags: ConsoleClientFeatureFlags,
    console: Console,
    env: dict[str, str],
) -> BuildResult:
    server_host = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_BUILD_SERVER_HOST)
    server_port = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_BUILD_SERVER_PORT)
    use_secure = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_BUILD_SERVER_SECURE)

    server_address = f"{server_host}:{server_port}"
    console.print(f"Connecting to {server_address}...", highlight=False)

    # Load authentication token (or send empty token if feature flag is disabled)
    if client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_SEND_USER_TOKEN):
        user_token = load_user_token() or ""
    else:
        user_token = ""

    print_grpc_events = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_PRINT_GRPC_EVENTS)

    def print_grpc_event(message: str) -> None:
        console.print(f"[Client] {message}", style="dim")

    follower_build_insight_storage = BuildInsightStorage(mode=BuildInsightStorageMode.FOLLOWER)
    cli_renderer = RichBasedCliProgressRenderer(
        console, follower_build_insight_storage, interactive=(not args.no_interactive)
    )

    # Create reorder buffer to handle out-of-order events
    def publish_to_storage(event: BuildInsightEvent) -> None:
        # Events come from the server with sequence numbers already assigned
        follower_build_insight_storage.report_event(event)

    build_insight_events_buffer = SequenceReorderBuffer[BuildInsightEvent](publish_to_storage)

    # Connect to server using secure or insecure channel
    max_grpc_message_length: int = client_feature_flags.get_flag_value(
        ConsoleClientFeatureFlags.MAX_GRPC_MESSAGE_LENGTH
    )
    channel_options = [
        ("grpc.max_receive_message_length", max_grpc_message_length),
        ("grpc.max_send_message_length", max_grpc_message_length),
    ]
    if use_secure:
        ssl_credentials = grpc.ssl_channel_credentials()
        channel = grpc.secure_channel(server_address, ssl_credentials, options=channel_options)
    else:
        channel = grpc.insecure_channel(server_address, options=channel_options)

    stub = cast(Any, BuildServiceStub(channel))

    # Create message queue for bidirectional streaming
    # Use None as sentinel to signal end of requests
    # It contains true client requests (like start or cancel a build) as well as responses to server os env requests
    message_queue: queue.Queue[ClientMessage | None] = queue.Queue()

    # Create request iterator
    def request_iterator() -> Iterator[ClientMessage]:
        while True:
            message = message_queue.get()
            if message is None:
                # Sentinel value - stop sending requests
                break
            yield message

    # Start bidirectional stream
    response_stream = stub.Build(request_iterator())

    # Serialize args to JSON (convert Namespace to dict)
    args_dict = vars(args)
    args_json = json.dumps(args_dict)

    # Send StartBuild message with settings, args, feature flags, and user token
    # Convert feature flags to map<string, string> (protobuf requirement)
    feature_flags_str = {k: str(v) for k, v in client_feature_flags.to_dict().items()}
    start_request = ClientMessage(
        start_build=StartBuildRequest(
            project_root=str(local_project.project_root.get_underlying_path().resolve()),
            settings_json=local_project.settings_json_str(),
            args_json=args_json,
            client_feature_flags=feature_flags_str,
            env_vars=filter_env_vars(env),
            user_token=user_token,
            client_protocol_version=PROTOCOL_VERSION,
        )
    )
    if print_grpc_events:
        print_grpc_event("Sending: start_build")

    message_queue.put(start_request)

    result: BuildResult | None = None
    stop_event = threading.Event()
    cancellation_requested = threading.Event()

    logger = logging.getLogger(__name__)

    # Process server messages in a separate thread to handle os_env_request
    def process_server_messages() -> None:
        nonlocal result

        def _handle_and_enqueue_response(req: OperationRequest) -> None:
            os_response = handle_os_env_request(req, local_project.os_env(), logger, console)
            client_message = ClientMessage(os_env_response=os_response)
            message_size = client_message.ByteSize()
            if message_size > max_grpc_message_length:
                error = ClientResponseTooBig(message_size, max_grpc_message_length)
                request_type = req.WhichOneof("operation")
                logger.warning(
                    f"Responding with CLIENT_RESPONSE_TOO_BIG for {request_type} (request_id={req.request_id}): {error}"
                )
                error_info = os_environment_pb2.ErrorInfo(
                    message=str(error),
                    type=os_environment_pb2.ErrorType.CLIENT_RESPONSE_TOO_BIG,
                )
                client_message = ClientMessage(
                    os_env_response=OperationResponse(request_id=req.request_id, client_internal_error=error_info)
                )
            message_queue.put(client_message)

        thread_pool_size: int = client_feature_flags.get_flag_value(
            ConsoleClientFeatureFlags.CONSOLE_CLIENT_WORKER_THREAD_POOL_SIZE
        )
        executor = ThreadPoolExecutor(max_workers=thread_pool_size, thread_name_prefix="os-env")
        try:
            for server_message in response_stream:
                if stop_event.is_set():
                    break

                server_message = cast(ServerMessage, server_message)
                which = server_message.WhichOneof("message")

                if print_grpc_events and which not in ("os_env_request", "build_insight_event"):
                    # Don't print generic "Received" for these since we print detailed "Handling" messages
                    print_grpc_event(f"Received: {which}")

                if which == "build_started":
                    build_started = server_message.build_started
                    result_type = build_started.WhichOneof("result")
                    if result_type == "failure":
                        error = BuildStartFailedUserError(build_started.failure.message)
                        result = BuildResult.failed("build", error)
                        break
                    message = f"Remote build started (ID: {build_started.success.build_id})"
                    logger.info(message)
                    console.print(message, highlight=False)

                elif which == "build_insight_event":
                    # Convert protobuf event back to Python and add to reorder buffer
                    # The buffer will handle out-of-order delivery and publish to storage in order
                    proto_event = server_message.build_insight_event
                    py_event = convert_proto_to_build_insight_event(proto_event)
                    if print_grpc_events:
                        summary = _get_build_insight_event_summary(py_event)
                        print_grpc_event(f"Handling build_insight_event: {summary}")
                    build_insight_events_buffer.add(py_event)

                elif which == "os_env_request":
                    # Handle file operation request from server
                    os_request = cast(os_environment_pb2.OperationRequest, getattr(server_message, "os_env_request"))
                    if print_grpc_events:
                        request_description = OsEnvRequestLogging.format(os_request)
                        print_grpc_event(f"Handling OsEnv request: {request_description}")
                    executor.submit(_handle_and_enqueue_response, os_request)

                elif which == "build_finished":
                    build_finished = server_message.build_finished
                    logger.info(f"Received build finished message: {build_finished}")
                    result = convert_build_finished_proto_to_result(build_finished)
                    break

        except grpc.RpcError as e:
            logger.exception(f"Grpc error: {e}")

            if not stop_event.is_set():
                # Check if this is a connection error
                if e.code() == grpc.StatusCode.UNAVAILABLE:
                    # Convert to user-friendly error
                    user_error = CodeSpeakServerUnavailableUserError(server_address)
                    result = BuildResult.failed("build", user_error)
                else:
                    # Other gRPC errors
                    console.print(f"Error during build: {e}", style="bright_red")
                    result = BuildResult.failed("build", e)
        except Exception as e:  # noqa: BLE001
            if not stop_event.is_set():
                logger.exception(f"Error during build ({type(e).__name__}): {e}")
                console.print(f"Error during build: {e}", style="bright_red")
                result = BuildResult.failed("build", e)
        finally:
            executor.shutdown(wait=True)

    # Start processing server messages in a thread
    message_thread = threading.Thread(target=process_server_messages, daemon=False)
    message_thread.start()

    try:
        while True:
            try:
                # Wait for the thread to complete
                message_thread.join(timeout=0.1)
                if not message_thread.is_alive():
                    break
            except KeyboardInterrupt:
                # Do not interrupt client loop immediately.
                # Instead, send build cancellation request to the server and so let it finish the loop
                if not cancellation_requested.is_set():
                    cli_renderer.append_text("[yellow]Waiting for server to cancel build...[/yellow]")
                    cli_renderer.append_text("[yellow]Press Ctrl+C again to force exit[/yellow]")
                    cancellation_requested.set()
                    # Send CancelBuild request to server
                    cancel_request = ClientMessage(cancel_build=CancelBuildRequest())
                    if print_grpc_events:
                        print_grpc_event("Sending: cancel_build")
                    message_queue.put(cancel_request)
                else:
                    # Second Ctrl+C - force exit without waiting for server
                    cli_renderer.append_text("[yellow]Force exiting...[/yellow]")
                    break
    finally:
        stop_event.set()
        # Send sentinel to stop the request iterator cleanly
        message_queue.put(None)
        cli_renderer.finalize()
        channel.close()

    if result is None:
        if cancellation_requested.is_set():
            result = BuildResult.failed("build", KeyboardInterrupt())
        else:
            result = BuildResult.failed(
                "build", CodespeakInternalError("Error: connection with server closed before obtaining build result")
            )

    return result
