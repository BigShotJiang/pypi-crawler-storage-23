import importlib.metadata


def get_current_package_version() -> str:
    """Get the version of the console_client package."""
    package_name = __name__.split(".")[0]
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        return f"0.1.0+dev_{package_name}"
