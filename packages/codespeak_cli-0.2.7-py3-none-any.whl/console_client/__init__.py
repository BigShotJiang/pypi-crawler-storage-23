"""Build client package for CodeSpeak."""
