import functools
import logging
import typing
from collections.abc import Callable
from contextlib import contextmanager
from datetime import UTC, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, override

from codespeak_shared import SpanProvider as SharedSpanProvider
from codespeak_shared.logging import get_span_provider, set_span_provider
from codespeak_shared.logging.span_provider import SpanProvider

from console_client.version import get_current_package_version


class IndentingFormatter(logging.Formatter):
    def __init__(self, fmt: str | None = None):
        super().__init__(fmt)
        self.indent_level = 0
        self.indent_str = SpanProvider.INDENT_STR

    def indent_increase(self) -> int:
        self.indent_level += 1
        return self.indent_level

    def indent_decrease(self) -> int:
        if self.indent_level > 0:
            self.indent_level -= 1
        else:
            raise ValueError("Cannot decrease indent")
        return self.indent_level

    @override
    def format(self, record: logging.LogRecord) -> str:
        original_msg = super().format(record)
        indent = self.indent_str * self.indent_level
        result_msg = indent + original_msg.replace("\n", "\\n")
        return result_msg

    @override
    def formatTime(self, record: logging.LogRecord, datefmt: str | None = None) -> str:
        dt = datetime.fromtimestamp(record.created, tz=UTC)
        return dt.isoformat()


class NoOpFormatter(IndentingFormatter):
    @override
    def format(self, record: logging.LogRecord) -> str:
        return record.getMessage()

    @override
    def indent_increase(self) -> int:
        return 0

    @override
    def indent_decrease(self) -> int:
        return 0

    @override
    def formatTime(self, record: logging.LogRecord, datefmt: str | None = None) -> str:
        dt = datetime.fromtimestamp(record.created, tz=UTC)
        return dt.isoformat()


class ConsoleClientLoggingUtil:
    _FILE_PATTERN = "%(asctime)s - [%(threadName)s] %(levelname)s - %(name)s - %(message)s"
    _CONSOLE_PATTERN = "%(asctime)s - %(message)s"

    initialized = False
    tracer = None
    no_file_logging: bool = True
    enable_spans = True

    @classmethod
    def initialize_logger(
        cls,
        log_file_path: Path | None,
        enable_console_logging: bool,
        enable_spans: bool = True,
        log_rotation: bool = False,
    ):
        """
        If log_file_path is None, logging to file will be disabled.
        """
        if log_file_path:
            log_file_path.parent.mkdir(parents=True, exist_ok=True)

        logger = logging.getLogger()  # root logger
        logger.setLevel(logging.INFO)
        logger.handlers.clear()

        if log_file_path:
            if log_rotation:
                file_handler = RotatingFileHandler(log_file_path, maxBytes=10 * 1024 * 1024, backupCount=100)
            else:
                file_handler = logging.FileHandler(log_file_path)

            cls.enable_spans = enable_spans

            if enable_spans:
                formatter = IndentingFormatter(ConsoleClientLoggingUtil._FILE_PATTERN)
            else:
                formatter = logging.Formatter(ConsoleClientLoggingUtil._FILE_PATTERN)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            cls.no_file_logging = False
        else:
            cls.no_file_logging = True

        if enable_console_logging:
            console_handler = logging.StreamHandler()
            formatter = logging.Formatter(ConsoleClientLoggingUtil._CONSOLE_PATTERN)
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)

        cls.initialized = True

        current_package_name = __name__.split(".")[0]
        logging.getLogger(__class__.__qualname__).info(
            f"Current package ({current_package_name}) version: {get_current_package_version()}"
        )

        class IndentingLogSpanProvider(SharedSpanProvider):
            @contextmanager
            def create_span(self, name: str) -> typing.Iterator[None]:
                ConsoleClientLoggingUtil.enter_span(name)
                try:
                    yield None
                finally:
                    ConsoleClientLoggingUtil.exit_span(name)

        set_span_provider(IndentingLogSpanProvider())

    @classmethod
    def ensure_initialized(cls):
        if not cls.initialized:
            raise ValueError("Please call ConsoleClientLoggingUtil.initialize()")

    @staticmethod
    def span(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any):
                def delegate() -> Any:
                    return func(*args, **kwargs)

                ConsoleClientLoggingUtil.run_in_span(delegate, name, func)

            return wrapper

        return decorator

    @classmethod
    def enter_span(cls, name: str, annotated_function: Callable[..., Any] | None = None):
        cls.ensure_initialized()
        cause = f"annotated function: {annotated_function.__qualname__}" if annotated_function else "explicitly"

        # for unnamed spans, just increase indent
        if name:
            logging.getLogger(ConsoleClientLoggingUtil.__class__.__qualname__).info(f"{name}")
        new_depth = ConsoleClientLoggingUtil._find_indenter().indent_increase()

        logging.getLogger(ConsoleClientLoggingUtil.__class__.__qualname__).debug(
            f"Started span: {name if name else 'empty'}, {cause}, new depth: {new_depth}"
        )

    @classmethod
    def exit_span(cls, name: str, annotated_function: Callable[..., Any] | None = None):
        ConsoleClientLoggingUtil.ensure_initialized()
        new_depth = ConsoleClientLoggingUtil._find_indenter().indent_decrease()
        cause = f"annotated function: {annotated_function.__qualname__}" if annotated_function else "explicitly"
        logging.getLogger(ConsoleClientLoggingUtil.__class__.__qualname__).debug(
            f"Exited span: {name}, {cause}, new depth: {new_depth}"
        )

    @classmethod
    def _find_indenter(cls) -> IndentingFormatter:
        if not cls.enable_spans or cls.no_file_logging:
            return NoOpFormatter()

        file_handler = next(
            (handler for handler in logging.getLogger().handlers if isinstance(handler, logging.FileHandler)), None
        )
        if not file_handler:
            raise ValueError("No file handler found")
        assert isinstance(file_handler.formatter, IndentingFormatter)
        return file_handler.formatter or NoOpFormatter()

    @staticmethod
    def run_in_span(
        func: Callable[..., Any], span_name: str, annotated_function: Callable[..., Any] | None = None
    ) -> Any:
        ConsoleClientLoggingUtil.enter_span(span_name, annotated_function)
        try:
            return func()
        finally:
            ConsoleClientLoggingUtil.exit_span(span_name, annotated_function)

    class Span:
        def __init__(self, name: str) -> None:
            self.exited = False
            self.name = name
            self._span = get_span_provider().create_span(name)

        def __enter__(self) -> "ConsoleClientLoggingUtil.Span":
            self._span.__enter__()
            return self

        def enter(self):
            self.__enter__()

        def exit(self):
            self.__exit__(None, None, None)

        def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any):
            if not self.exited:
                self._span.__exit__(exc_type, exc_val, exc_tb)
                self.exited = True
