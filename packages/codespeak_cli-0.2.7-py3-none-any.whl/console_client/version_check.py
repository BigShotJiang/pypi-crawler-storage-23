"""Auto-check PyPI for new CLI version availability."""

import json
import time
from pathlib import Path

import requests
from codespeak_shared.client_constants import ClientConstants
from pydantic import BaseModel
from rich.console import Console
from semver import Version

from console_client.auth.token_storage import ensure_codespeak_home, get_codespeak_home
from console_client.version import get_current_package_version

_CACHE_FILENAME = "version_check.json"
_PYPI_URL = f"https://pypi.org/pypi/{ClientConstants.CONSOLE_CLIENT_PACKAGE_NAME}/json"
_HTTP_TIMEOUT_SECONDS = 2


class VersionCheckCache(BaseModel):
    latest_version: str
    checked_at: float


def get_cache_path() -> Path:
    return get_codespeak_home() / _CACHE_FILENAME


def load_cache() -> VersionCheckCache | None:
    cache_path = get_cache_path()
    if not cache_path.exists():
        return None
    try:
        data = json.loads(cache_path.read_text(encoding="utf-8"))
        return VersionCheckCache.model_validate(data)
    except (json.JSONDecodeError, ValueError):
        return None


def save_cache(cache: VersionCheckCache) -> None:
    ensure_codespeak_home()
    cache_path = get_cache_path()
    cache_path.write_text(cache.model_dump_json(), encoding="utf-8")


def fetch_latest_version() -> str:
    response = requests.get(_PYPI_URL, timeout=_HTTP_TIMEOUT_SECONDS)
    response.raise_for_status()
    data = response.json()
    return data["info"]["version"]


def is_newer_version(current: str, latest: str) -> bool:
    return Version.parse(latest) > Version.parse(current)


def check_for_updates(console: Console, check_interval_hours: int) -> None:
    try:
        current_version = get_current_package_version()

        cache = load_cache()
        if cache and (time.time() - cache.checked_at) < check_interval_hours * 3600:
            latest_version = cache.latest_version
        else:
            latest_version = fetch_latest_version()
            save_cache(VersionCheckCache(latest_version=latest_version, checked_at=time.time()))

        if is_newer_version(current_version, latest_version):
            console.print(
                f"[warning]A new version of CodeSpeak CLI is available: {current_version} → {latest_version}\n"
                f"Upgrade with: {ClientConstants.CONSOLE_CLIENT_UPGRADE_COMMAND}[/warning]"
            )
    except Exception:  # noqa: BLE001
        pass
