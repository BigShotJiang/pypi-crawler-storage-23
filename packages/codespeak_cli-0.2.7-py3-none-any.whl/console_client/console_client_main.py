"""Console client CLI for CodeSpeak - remote builds and authentication."""

import logging
import os
import sys
from argparse import SUPPRESS, ArgumentParser
from importlib.metadata import version
from pathlib import Path
from typing import NoReturn

import dotenv
from api_stubs.setup_grpc import setup_grpc
from codespeak_shared import BuildResult, LoggingUtil
from codespeak_shared.change_request_utils import implement_code_change_request
from codespeak_shared.client_constants import ClientConstants
from codespeak_shared.codespeak_project import FileBasedCodeSpeakProject
from codespeak_shared.environment_enhancer import enhance_environment_with_api_key
from codespeak_shared.exceptions import (
    BuildWithExistingChangeRequest,
    CodespeakInternalError,
    CodespeakUserError,
    ProjectNotFoundUserError,
)
from codespeak_shared.project_initializer import initialize_project
from codespeak_shared.shared_feature_flags import SharedFeatureFlags
from codespeak_shared.utils.colors import Colors, ThemeType
from codespeak_shared.utils.error_reporting import print_stack_trace_if_enabled
from codespeak_shared.utils.lenient_namespace import LenientNamespace
from codespeak_shared.utils.process_util import register_signal_handlers
from rich.console import Console

from console_client.auth.auth_manager import login
from console_client.auth.token_storage import is_token_expired, load_user_token
from console_client.client_feature_flags import ConsoleClientFeatureFlags
from console_client.console_client_logging import ConsoleClientLoggingUtil
from console_client.version_check import check_for_updates


def _ensure_authenticated(console: Console, client_feature_flags: ConsoleClientFeatureFlags) -> BuildResult:
    """
    Ensure user is authenticated. If no token is found, trigger login flow.

    Args:
        console: Rich console for user output.
        client_feature_flags: Feature flags instance to check if authentication is enabled.

    Returns:
        Result indicating authentication success or failure.
    """
    # Skip authentication check if feature flag is disabled
    if not client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_SEND_USER_TOKEN):
        return BuildResult.succeeded("authentication-check")

    try:
        token = load_user_token()
        if token:
            if not is_token_expired():
                # Token exists and is valid
                return BuildResult.succeeded("authentication-check")

            # Token is expired - trigger login
            console.print("[yellow]Your authentication token has expired.[/yellow]")
            console.print("[yellow]Please log in again to continue...[/yellow]\n")
            return _login_user(console, client_feature_flags)

        # Token is missing or empty - trigger login
        console.print("[yellow]Authentication required.[/yellow]")
        console.print("[yellow]Please log in to continue...[/yellow]\n")
        return _login_user(console, client_feature_flags)

    except BaseException as e:  # noqa: BLE001
        return BuildResult.failed("authentication-check", e)


def _login_user(console: Console, client_feature_flags: ConsoleClientFeatureFlags) -> BuildResult:
    """Execute login flow."""
    if not client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_SEND_USER_TOKEN):
        console.print("Login disabled")
        return BuildResult.succeeded("login")

    try:
        login(console, client_feature_flags)
        return BuildResult.succeeded("login")

    except KeyboardInterrupt as e:
        console.print("\n[yellow]Login cancelled by user.[/yellow]")
        return BuildResult.failed("login", e)

    except CodespeakUserError as e:
        return BuildResult.failed("login", e)

    except BaseException as e:  # noqa: BLE001 (login catch-all block)
        return BuildResult.failed("login", e)


class ArgumentParserWithHelp(ArgumentParser):
    def error(self, message: str) -> NoReturn:
        sys.stderr.write(f"{message}\n")
        sys.stderr.write("\n")
        self.print_help()
        sys.exit(CodespeakUserError.EXIT_CODE)


def main() -> None:
    register_signal_handlers()

    dotenv.load_dotenv(dotenv.find_dotenv(usecwd=True))
    dotenv.load_dotenv(".env.local", override=True)

    logger = logging.getLogger("console-client")
    logger.info(f"Invocation: {' '.join([os.path.basename(sys.argv[0])] + sys.argv[1:])}")

    def add_common_params(parser: ArgumentParser) -> None:
        parser.add_argument("--enable-flag", action="append", help=SUPPRESS)
        parser.add_argument("--disable-flag", action="append", help=SUPPRESS)

    def add_build_params(parser: ArgumentParser) -> None:
        add_common_params(parser)
        parser.add_argument("--start", help=SUPPRESS)
        parser.add_argument("--until", help=SUPPRESS)
        parser.add_argument("--dry-run", action="store_true", help=SUPPRESS)
        parser.add_argument(
            "--no-diff-check",
            action="store_true",
            help=SUPPRESS,
        )
        parser.add_argument(
            "--no-interactive",
            action="store_true",
            default=None,
            help="run in non-interactive mode without real-time progress updates",
        )
        parser.add_argument(
            "--disable-parallelism",
            action="store_true",
            help=SUPPRESS,
        )
        parser.add_argument(
            "--spec",
            help="path to the specification file to build; if omitted, all registered specification files will be built",
            default=None,
        )

        resume_control_group = parser.add_mutually_exclusive_group()
        resume_control_group.add_argument(
            "--clean",
            action="store_true",
            help=SUPPRESS,
        )
        resume_control_group.add_argument(
            "--retry",
            action="store_true",
            help=SUPPRESS,
        )
        parser.add_argument(
            "--skip-tests",
            action="store_true",
            help="Skip improving test coverage",
        )

    def add_init_params(parser: ArgumentParser) -> None:
        add_common_params(parser)
        parser.add_argument("--profile", help="configuration profile to use for initialization")
        parser.add_argument(
            "--project-name", default=None, help="custom name for the project (defaults to directory name)"
        )
        parser.add_argument(
            "--mixed",
            action="store_true",
            help="enable mixed mode, allowing both CodeSpeak spec-driven code and manually written code to coexist",
            default=False,
        )
        parser.add_argument(
            "--ignore-enclosing-project-check",
            default=False,
            action="store_true",
            help=SUPPRESS,
        )

    # Create main parser
    parser = ArgumentParserWithHelp(description="CodeSpeak build system")
    parser.prog = "codespeak"
    parser.add_argument(
        "--version", action="version", version=f"CodeSpeak CLI {version(ClientConstants.CONSOLE_CLIENT_PACKAGE_NAME)}"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Init command (local project initialization)
    init_parser = subparsers.add_parser(
        "init",
        help="initialize a new CodeSpeak project",
        description="Initialize a new CodeSpeak project in the current directory. This creates the necessary configuration files and project structure.",
    )
    add_init_params(init_parser)

    # Login command
    login_parser = subparsers.add_parser(
        "login",
        help="authenticate with CodeSpeak",
        description="Authenticate with CodeSpeak to enable builds. Opens a browser for authentication.",
    )
    add_common_params(login_parser)

    # Build command (remote build)
    build_parser = subparsers.add_parser(
        "build",
        help="run build",
        description="Build your project according to the specification file(s). CodeSpeak will generate or update code to match the spec.",
    )
    add_build_params(build_parser)

    # Change command (remote change request)
    change_parser = subparsers.add_parser(
        "change",
        help="code change request",
        description="Request a code change to an existing project. Use --new to create a change request file, or -m to specify the change directly.",
    )
    add_build_params(change_parser)
    change_parser.add_argument(
        "--new",
        action="store_true",
        default=False,
        help="create an empty change request file for further manual editing; after editing, implement the change request with 'codespeak change'",
    )
    change_parser.add_argument("-m", "--message", help="implement a given change request")

    # Run command (remote build + run target app)
    run_parser = subparsers.add_parser(
        "run",
        help="build and run the target application",
        description="Build and run target application.",
    )
    add_build_params(run_parser)

    # Parse arguments
    args = parser.parse_args(namespace=LenientNamespace())
    env_vars = dict(os.environ)
    client_feature_flags = ConsoleClientFeatureFlags(env_vars, args.enable_flag, args.disable_flag)

    # Setup console with theme
    theme = Colors.get_theme(
        ThemeType.DARK
        if client_feature_flags.get_flag_value(SharedFeatureFlags.CONSOLE_USES_DARK_THEME)
        else ThemeType.LIGHT
    )
    console = Console(theme=theme)
    stderr_console = Console(stderr=True, theme=theme)

    # Print any feature flag warnings
    for warning in client_feature_flags.warnings:
        stderr_console.print(warning)

    if client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_VERSION_CHECK_ENABLED):
        check_for_updates(
            stderr_console,
            client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_VERSION_CHECK_INTERVAL_HOURS),
        )

    # Handle commands
    try:
        if args.command == "init":

            def init_logging(local_project: FileBasedCodeSpeakProject, feature_flags: SharedFeatureFlags) -> None:
                ConsoleClientLoggingUtil.initialize_logger(
                    local_project.ignored_data_path("codespeak.log").get_underlying_path(), enable_console_logging=False
                )

            result = initialize_project(
                current_path=Path(os.curdir),
                console=console,
                feature_flags=client_feature_flags,
                args=args,
                initialize_logging=init_logging,
            )

        elif args.command == "login":
            result = _login_user(console, client_feature_flags)

        elif args.command in ("build", "change", "run"):
            # Find project
            local_project = FileBasedCodeSpeakProject.find_upwards(Path(os.curdir))
            if not local_project:
                result = BuildResult.failed(args.command, ProjectNotFoundUserError(Path(os.curdir).resolve()))
            else:
                ConsoleClientLoggingUtil.initialize_logger(
                    local_project.ignored_data_path("codespeak.log").get_underlying_path(), enable_console_logging=False
                )

                # Enhance environment with API key on client side (before sending to server)
                env_vars = enhance_environment_with_api_key(
                    console=console,
                    env_vars=env_vars,
                    project_root=local_project.project_root.get_underlying_path(),
                    no_interactive=args.no_interactive,
                )

                def call_server() -> BuildResult:
                    # Ensure user is authenticated before running build
                    auth_result = _ensure_authenticated(console, client_feature_flags)
                    if auth_result.enum_type != BuildResult.SUCCEEDED:
                        return auth_result
                    else:
                        with LoggingUtil.Span(f"Running command: {args.command}"):
                            # setup GRPC logging before importing build_client (which imports grpc)
                            setup_grpc(client_feature_flags.get_flag_value(SharedFeatureFlags.DEBUG_GRPC))

                            from console_client.build_client import run_build_client  # noqa: PLC0415

                            return run_build_client(args, local_project, client_feature_flags, console, env_vars)

                if args.command in ("build", "run"):
                    ccr_path = local_project.code_change_request_path()
                    if local_project.os_env().exists(ccr_path):
                        result = BuildResult.failed(
                            "build", BuildWithExistingChangeRequest(ccr_path.get_underlying_path())
                        )
                    else:
                        result = call_server()
                else:
                    result = implement_code_change_request(local_project, args, console, call_server)
        else:
            # Shouldn't happen as argparse should fail before we get here
            console.print(f"[red]Unknown command: {args.command}[/red]")
            sys.exit(1)

    except BaseException as e:  # noqa: BLE001 (global catch-all block)
        result = BuildResult.failed(args.command, e)

    # Handle result and exit
    if result.enum_type == BuildResult.SUCCEEDED:
        sys.exit(0)
    elif result.enum_type == BuildResult.SKIPPED:
        sys.exit(0)
    elif result.enum_type == BuildResult.FAILED:
        assert result.exception
        if isinstance(result.exception, KeyboardInterrupt):
            stderr_console.print(
                f"[error.emphasized]{result.command.capitalize()} interrupted by user.[/error.emphasized]"
            )
            sys.exit(130)
        elif isinstance(result.exception, (CodespeakUserError, CodespeakUserError)):
            stderr_console.print(
                f"[error.emphasized]{result.command.capitalize()} failed:[/error.emphasized]\n{result.exception}"
            )
            sys.exit(CodespeakUserError.EXIT_CODE)
        else:
            stderr_console.print(
                f"[error.emphasized]{result.command.capitalize()} failed: [/error.emphasized]{result.exception}"
            )
            server_trace = getattr(result.exception, "server_stack_trace", None)
            if server_trace or result.exception.__traceback__:
                if not client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.PRINT_STACKTRACE_ON_FAILURE):
                    stderr_console.print(
                        "[dim]To see full error details, run with --enable-flag PRINT_STACKTRACE_ON_FAILURE[/dim]"
                    )
                print_stack_trace_if_enabled(result.exception, stderr_console, client_feature_flags)
            sys.exit(CodespeakInternalError.EXIT_CODE)


if __name__ == "__main__":
    main()
