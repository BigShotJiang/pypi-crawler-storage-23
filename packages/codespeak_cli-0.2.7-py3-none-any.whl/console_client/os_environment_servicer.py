from collections.abc import Iterator
from typing import Any

import api_stubs.os_environment_pb2 as os_env_pb2
from api_stubs.operation_logging import OsEnvRequestLogging
from api_stubs.os_environment_pb2 import (
    AppendToFileRequest,
    AppendToFileResponse,
    ChildProcessOutcome,
    CopyRequest,
    CopyResponse,
    DeleteFileRequest,
    DeleteFileResponse,
    DeleteRecursivelyRequest,
    DeleteRecursivelyResponse,
    ErrorInfo,
    ErrorType,
    ExistsRequest,
    ExistsResponse,
    GetAttributesRequest,
    GetAttributesResponse,
    GlobRequest,
    GlobResponse,
    GrepRequest,
    GrepResponse,
    IsDirectoryRequest,
    IsDirectoryResponse,
    IsFileRequest,
    IsFileResponse,
    ListDirectoryRequest,
    ListDirectoryResponse,
    ListTreeRequest,
    ListTreeResponse,
    MkdirsRequest,
    MkdirsResponse,
    OperationRequest,
    OperationResponse,
    ReadFileRequest,
    ReadFileResponse,
    ResolvePathRequest,
    ResolvePathResponse,
    ResolveUserNameRequest,
    ResolveUserNameResponse,
    RunChildProcessRequest,
    RunChildProcessResponse,
    RunDjangoDevServerRequest,
    RunDjangoDevServerResponse,
    TraverseRequest,
    TraverseResponse,
    WriteFileRequest,
    WriteFileResponse,
)
from api_stubs.os_environment_pb2 import (
    ChildProcessResult as ChildProcessResultProto,
)
from api_stubs.os_environment_pb2 import (
    DjangoServerRunMode as DjangoServerRunModeProto,
)
from api_stubs.os_environment_pb2 import (
    EntryAttributes as EntryAttributesProto,
)
from api_stubs.os_environment_pb2 import GrepFileCount as GrepFileCountProto
from api_stubs.os_environment_pb2 import GrepMatch as GrepMatchProto
from api_stubs.os_environment_pb2 import (
    GrepOutputMode as GrepOutputModeProto,
)
from api_stubs.os_environment_pb2 import TreeEntry as TreeEntryProto
from api_stubs.os_environment_pb2_grpc import OsEnvironmentServiceServicer
from codespeak_shared.logging import LoggingUtil
from codespeak_shared.os_environment.os_environment import (
    ChildProcessFailedToStartException,
    ChildProcessTimedOutException,
    DjangoServerRunMode,
    EntryAttributes,
    ExistsWithLastModifiedTimestamp,
    FileNotFoundException,
    FileState,
    FileStateExpectationNotMet,
    GrepOutputMode,
    MaxFileSizeExceededException,
    Missing,
    OsEnvironment,
    OsEnvironmentException,
)
from codespeak_shared.project_path import ProjectPath
from codespeak_shared.utils.process_util import OutputType
from rich.console import Console


class OsEnvironmentServicer(OsEnvironmentServiceServicer):
    """
    gRPC server implementation that delegates all operations to OsEnvironment using bidirectional streaming.
    """

    def __init__(self, os_env: OsEnvironment, console: Console | None = None):
        self._os_env = os_env
        self._console = console

    @staticmethod
    def create_error_info_from_exception(exception: OsEnvironmentException) -> ErrorInfo:
        message = str(exception)
        if isinstance(exception, FileNotFoundException):
            return ErrorInfo(message=message, type=ErrorType.FILE_NOT_FOUND)
        if isinstance(exception, MaxFileSizeExceededException):
            return ErrorInfo(message=message, type=ErrorType.MAX_FILE_SIZE_EXCEEDED)
        if isinstance(exception, FileStateExpectationNotMet):
            return ErrorInfo(message=message, type=ErrorType.FILE_STATE_EXPECTATION_NOT_MET)
        return ErrorInfo(message=message)

    @staticmethod
    def _to_proto_attributes(attributes: EntryAttributes) -> EntryAttributesProto:
        return EntryAttributesProto(
            last_modified=attributes.last_modified,
            size=attributes.size,
            mode=attributes.mode,
            nlink=attributes.nlink,
            user_name=attributes.user_name,
            group_name=attributes.group_name,
        )

    def StreamOperations(
        self, request_iterator: Iterator[OperationRequest], context: Any
    ) -> Iterator[OperationResponse]:
        """Handle bidirectional streaming of operations."""
        for request in request_iterator:
            request_id = request.request_id

            # Format operation string once for logging
            request_description = OsEnvRequestLogging.format(request)

            # Determine which operation was requested
            which = request.WhichOneof("operation")

            if which == "get_attributes":
                yield self._handle_get_attributes(request_id, request.get_attributes, request_description)
            elif which == "read_file":
                yield self._handle_read_file(request_id, request.read_file, request_description)
            elif which == "write_file":
                yield self._handle_write_file(request_id, request.write_file, request_description)
            elif which == "append_to_file":
                yield self._handle_append_to_file(request_id, request.append_to_file, request_description)
            elif which == "mkdirs":
                yield self._handle_mkdirs(request_id, request.mkdirs, request_description)
            elif which == "is_file":
                yield self._handle_is_file(request_id, request.is_file, request_description)
            elif which == "is_directory":
                yield self._handle_is_directory(request_id, request.is_directory, request_description)
            elif which == "exists":
                yield self._handle_exists(request_id, request.exists, request_description)
            elif which == "copy":
                yield self._handle_copy(request_id, request.copy, request_description)
            elif which == "delete_recursively":
                yield self._handle_delete_recursively(request_id, request.delete_recursively, request_description)
            elif which == "delete_file":
                yield self._handle_delete_file(request_id, request.delete_file, request_description)
            elif which == "list_directory":
                yield self._handle_list_directory(request_id, request.list_directory, request_description)
            elif which == "glob":
                yield self._handle_glob(request_id, request.glob, request_description)
            elif which == "resolve_user_name":
                yield self._handle_resolve_user_name(request_id, request.resolve_user_name, request_description)
            elif which == "run_child_process":
                yield self._handle_run_child_process(request_id, request.run_child_process, request_description)
            elif which == "resolve_path":
                yield self._handle_resolve_path(request_id, request.resolve_path, request_description)
            elif which == "traverse":
                yield self._handle_traverse(request_id, request.traverse, request_description)
            elif which == "run_django_dev_server":
                yield self._handle_run_django_dev_server(request_id, request.run_django_dev_server, request_description)
            elif which == "grep":
                yield self._handle_grep(request_id, request.grep, request_description)
            elif which == "list_tree":
                yield self._handle_list_tree(request_id, request.list_tree, request_description)

    def _handle_get_attributes(
        self, request_id: str, request: GetAttributesRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                attributes = self._os_env.get_attributes(ProjectPath.from_string(request.path))
                proto_attributes = self._to_proto_attributes(attributes)
                return OperationResponse(
                    request_id=request_id,
                    get_attributes=GetAttributesResponse(attributes=proto_attributes),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    get_attributes=GetAttributesResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_read_file(
        self, request_id: str, request: ReadFileRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                max_allowed = (
                    request.max_allowed_file_size_bytes if request.max_allowed_file_size_bytes > 0 else 20 * 1024 * 1024
                )
                offset_line = request.offset_line if request.HasField("offset_line") else None
                limit_lines = request.limit_lines if request.HasField("limit_lines") else None
                content, attributes, truncated = self._os_env.read_file_ex(
                    ProjectPath.from_string(request.path),
                    max_allowed_file_size_bytes=max_allowed,
                    offset_line=offset_line,
                    limit_lines=limit_lines,
                )
                proto_attributes = self._to_proto_attributes(attributes)
                return OperationResponse(
                    request_id=request_id,
                    read_file=ReadFileResponse(content=content, attributes=proto_attributes, truncated=truncated),
                )
            except MaxFileSizeExceededException as e:
                # Include file size in attributes so client can construct proper exception
                attrs_with_size = EntryAttributesProto(
                    size=e.file_size,
                    last_modified=0,
                    mode=0,
                    nlink=0,
                    user_name="",
                    group_name="",
                )
                return OperationResponse(
                    request_id=request_id,
                    read_file=ReadFileResponse(
                        error=self.create_error_info_from_exception(e),
                        attributes=attrs_with_size,
                        content="",
                    ),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    read_file=ReadFileResponse(
                        error=self.create_error_info_from_exception(e),
                        attributes=EntryAttributesProto(),
                        content="",
                    ),
                )

    def _handle_write_file(
        self, request_id: str, request: WriteFileRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                path = ProjectPath.from_string(request.path)

                expected_state = (
                    self._proto_to_file_state(request.expected_state) if request.HasField("expected_state") else None
                )

                new_last_modified = self._os_env.write_file(path, request.content, expected_state=expected_state)

                return OperationResponse(
                    request_id=request_id,
                    write_file=WriteFileResponse(new_last_modified=new_last_modified),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    write_file=WriteFileResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_append_to_file(
        self, request_id: str, request: AppendToFileRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                path = ProjectPath.from_string(request.path)

                expected_state = (
                    self._proto_to_file_state(request.expected_state) if request.HasField("expected_state") else None
                )

                new_last_modified = self._os_env.append_to_file(path, request.content, expected_state=expected_state)

                return OperationResponse(
                    request_id=request_id,
                    append_to_file=AppendToFileResponse(new_last_modified=new_last_modified),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    append_to_file=AppendToFileResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_mkdirs(
        self, request_id: str, request: MkdirsRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                self._os_env.mkdirs(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    mkdirs=MkdirsResponse(),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    mkdirs=MkdirsResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_is_file(
        self, request_id: str, request: IsFileRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                result = self._os_env.is_file(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    is_file=IsFileResponse(result=result),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    is_file=IsFileResponse(result=False, error=self.create_error_info_from_exception(e)),
                )

    def _handle_is_directory(
        self, request_id: str, request: IsDirectoryRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                result = self._os_env.is_directory(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    is_directory=IsDirectoryResponse(result=result),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    is_directory=IsDirectoryResponse(result=False, error=self.create_error_info_from_exception(e)),
                )

    def _handle_exists(
        self, request_id: str, request: ExistsRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                result = self._os_env.exists(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    exists=ExistsResponse(result=result),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    exists=ExistsResponse(result=False, error=self.create_error_info_from_exception(e)),
                )

    def _handle_copy(self, request_id: str, request: CopyRequest, operation_details_to_log: str) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                self._os_env.copy(
                    ProjectPath.from_string(request.source_path), ProjectPath.from_string(request.dest_path)
                )
                return OperationResponse(
                    request_id=request_id,
                    copy=CopyResponse(),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    copy=CopyResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_delete_recursively(
        self, request_id: str, request: DeleteRecursivelyRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                self._os_env.delete_recursively(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    delete_recursively=DeleteRecursivelyResponse(),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    delete_recursively=DeleteRecursivelyResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_delete_file(
        self, request_id: str, request: DeleteFileRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                self._os_env.delete_file(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    delete_file=DeleteFileResponse(),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    delete_file=DeleteFileResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_list_directory(
        self, request_id: str, request: ListDirectoryRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                entries = self._os_env.list_directory(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    list_directory=ListDirectoryResponse(entries=entries),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    list_directory=ListDirectoryResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_glob(self, request_id: str, request: GlobRequest, operation_details_to_log: str) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                path = ProjectPath.from_string(request.path) if request.path else None
                paths = self._os_env.glob(request.pattern, path)
                return OperationResponse(
                    request_id=request_id,
                    glob=GlobResponse(paths=[str(p) for p in paths]),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    glob=GlobResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_grep(self, request_id: str, request: GrepRequest, operation_details_to_log: str) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                # Convert proto output mode to enum
                output_mode_map = {
                    GrepOutputModeProto.GREP_OUTPUT_MODE_FILES_WITH_MATCHES: GrepOutputMode.FILES_WITH_MATCHES,
                    GrepOutputModeProto.GREP_OUTPUT_MODE_CONTENT: GrepOutputMode.CONTENT,
                    GrepOutputModeProto.GREP_OUTPUT_MODE_COUNT: GrepOutputMode.COUNT,
                }
                output_mode = output_mode_map.get(request.output_mode, GrepOutputMode.FILES_WITH_MATCHES)

                path = ProjectPath.from_string(request.path) if request.path else None

                result = self._os_env.grep(
                    pattern=request.pattern,
                    path=path,
                    glob_filter=request.glob if request.glob else None,
                    output_mode=output_mode,
                    context_before=request.context_before if request.HasField("context_before") else None,
                    context_after=request.context_after if request.HasField("context_after") else None,
                    context_both=request.context_both if request.HasField("context_both") else None,
                    show_line_numbers=request.show_line_numbers if request.HasField("show_line_numbers") else True,
                    case_insensitive=request.case_insensitive if request.HasField("case_insensitive") else False,
                    file_type=request.file_type if request.file_type else None,
                    head_limit=request.head_limit if request.HasField("head_limit") else None,
                    offset=request.offset if request.HasField("offset") else None,
                    multiline=request.multiline if request.HasField("multiline") else False,
                )

                return OperationResponse(
                    request_id=request_id,
                    grep=GrepResponse(
                        matching_files=result.matching_files,
                        matches=[
                            GrepMatchProto(
                                file_path=m.file_path,
                                line_number=m.line_number,
                                line_content=m.line_content,
                            )
                            for m in result.matches
                        ],
                        file_counts=[
                            GrepFileCountProto(
                                file_path=fc.file_path,
                                match_count=fc.match_count,
                            )
                            for fc in result.file_counts
                        ],
                    ),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    grep=GrepResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_resolve_user_name(
        self, request_id: str, request: ResolveUserNameRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                username = self._os_env.resolve_user_name()
                return OperationResponse(
                    request_id=request_id,
                    resolve_user_name=ResolveUserNameResponse(username=username),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    resolve_user_name=ResolveUserNameResponse(
                        username="", error=self.create_error_info_from_exception(e)
                    ),
                )

    def _handle_run_child_process(
        self, request_id: str, request: RunChildProcessRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                redirected_output = (
                    ProjectPath.from_string(request.redirected_output_path) if request.redirected_output_path else None
                )
                output_limit_chars = request.output_limit_chars if request.HasField("output_limit_chars") else None
                result = self._os_env.run_child_process(
                    args=list(request.args),
                    cwd=ProjectPath.from_string(request.cwd_relative),
                    timeout=request.timeout,
                    check=request.check,
                    redirected_output_path=redirected_output,
                    shell=request.shell,
                    output_limit_chars=output_limit_chars,
                    interactive_mode=request.interactive_mode,
                    add_distribution_bin=request.add_distribution_bin,
                )
                proto_result = ChildProcessResultProto(
                    exit_code=result.exit_code,
                    stdout=result.stdout,
                    stderr=result.stderr,
                )
                return OperationResponse(
                    request_id=request_id,
                    run_child_process=RunChildProcessResponse(
                        result=proto_result, outcome=ChildProcessOutcome.PROCESS_FINISHED
                    ),
                )
            except ChildProcessFailedToStartException as e:
                return OperationResponse(
                    request_id=request_id,
                    run_child_process=RunChildProcessResponse(
                        error=self.create_error_info_from_exception(e),
                        outcome=ChildProcessOutcome.FAILED_TO_START_PROCESS,
                    ),
                )
            except ChildProcessTimedOutException as e:
                return OperationResponse(
                    request_id=request_id,
                    run_child_process=RunChildProcessResponse(
                        result=ChildProcessResultProto(exit_code=-1, stdout=e.stdout, stderr=e.stderr),
                        error=self.create_error_info_from_exception(e),
                        outcome=ChildProcessOutcome.PROCESS_TIMED_OUT,
                    ),
                )
            except OsEnvironmentException as e:
                # This catches other generic OsEnvironmentException errors that are not specifically
                # ChildProcessFailedToStartException or ChildProcessTimedOutException.
                # Since we don't know what happened, we use UNKNOWN outcome.
                return OperationResponse(
                    request_id=request_id,
                    run_child_process=RunChildProcessResponse(
                        error=self.create_error_info_from_exception(e),
                        outcome=ChildProcessOutcome.UNKNOWN,
                    ),
                )

    def _handle_resolve_path(
        self, request_id: str, request: ResolvePathRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                resolved = self._os_env.resolve_path(ProjectPath.from_string(request.path))
                return OperationResponse(
                    request_id=request_id,
                    resolve_path=ResolvePathResponse(resolved_path=str(resolved)),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    resolve_path=ResolvePathResponse(resolved_path="", error=self.create_error_info_from_exception(e)),
                )

    def _handle_traverse(
        self, request_id: str, request: TraverseRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                paths = self._os_env.traverse(
                    prune_dirnames=set(request.prune_dirnames),
                    skip_file_basenames=set(request.skip_file_basenames),
                    required_extension=request.required_extension,
                )
                return OperationResponse(
                    request_id=request_id,
                    traverse=TraverseResponse(paths=[str(p) for p in paths]),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    traverse=TraverseResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_list_tree(
        self, request_id: str, request: ListTreeRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                path = ProjectPath.from_string(request.path) if request.path else None
                max_depth = request.max_depth if request.HasField("max_depth") else None
                max_entries = request.max_entries if request.HasField("max_entries") else None
                entries, truncated = self._os_env.list_tree(path=path, max_depth=max_depth, max_entries=max_entries)
                return OperationResponse(
                    request_id=request_id,
                    list_tree=ListTreeResponse(
                        entries=[TreeEntryProto(path=e.path, is_directory=e.is_directory) for e in entries],
                        truncated=truncated,
                    ),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    list_tree=ListTreeResponse(error=self.create_error_info_from_exception(e)),
                )

    def _handle_run_django_dev_server(
        self, request_id: str, request: RunDjangoDevServerRequest, operation_details_to_log: str
    ) -> OperationResponse:
        with LoggingUtil.Span(operation_details_to_log):
            try:
                # Convert proto enum to Python enum
                run_mode = (
                    DjangoServerRunMode.SHUTDOWN_WHEN_READY
                    if request.run_mode == DjangoServerRunModeProto.DJANGO_SERVER_RUN_MODE_SHUTDOWN_WHEN_READY
                    else DjangoServerRunMode.INTERACTIVE
                )

                local_console_printer = None
                if self._console and run_mode == DjangoServerRunMode.INTERACTIVE:
                    console = self._console

                    def _print(line: str, _output_type: OutputType) -> None:
                        console.print(line, markup=False, highlight=False)

                    local_console_printer = _print

                success, error_output = self._os_env.run_django_dev_server(
                    server_readiness_timeout=request.server_readiness_timeout_sec,
                    run_mode=run_mode,
                    output_printer=local_console_printer,
                )
                return OperationResponse(
                    request_id=request_id,
                    run_django_dev_server=RunDjangoDevServerResponse(
                        success=success,
                        error_output=error_output if error_output else None,
                    ),
                )
            except OsEnvironmentException as e:
                return OperationResponse(
                    request_id=request_id,
                    run_django_dev_server=RunDjangoDevServerResponse(
                        success=False, error=self.create_error_info_from_exception(e)
                    ),
                )

    @staticmethod
    def _proto_to_file_state(proto_state: "os_env_pb2.FileState | None") -> FileState | None:
        if proto_state is None:
            return None

        state_type = proto_state.WhichOneof("state")
        match state_type:
            case "exists_with_last_modified_timestamp":
                return ExistsWithLastModifiedTimestamp(
                    timestamp=proto_state.exists_with_last_modified_timestamp.timestamp
                )
            case "missing":
                return Missing()
            case _:
                return None
