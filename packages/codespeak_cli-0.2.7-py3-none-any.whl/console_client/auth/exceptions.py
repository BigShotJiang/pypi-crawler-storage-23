"""Authentication-specific exceptions for CodeSpeak CLI."""

from codespeak_shared.exceptions import CodespeakUserError


class Auth0NotConfiguredUserError(CodespeakUserError):
    """Raised when Auth0 configuration is missing or incomplete."""

    def __init__(self, missing_config: str):
        message = (
            f"Auth0 is not configured. Missing: {missing_config}\n\n"
            "Please set the following environment variables:\n"
            "  - CODESPEAK_AUTH0_CLIENT_ID (required)\n"
            "  - CODESPEAK_AUTH0_DOMAIN (optional, defaults to codespeak.us.auth0.com)\n\n"
            "See documentation for Auth0 setup instructions."
        )
        super().__init__(message)


class LoginTimeoutUserError(CodespeakUserError):
    """Raised when the user doesn't complete login within the timeout period."""

    def __init__(self, timeout_seconds: int):
        message = f"Login timed out after {timeout_seconds} seconds.\nPlease try again with: codespeak login"
        super().__init__(message)


class LoginCancelledUserError(CodespeakUserError):
    """Raised when the user cancels the login process."""

    def __init__(self):
        message = "Login cancelled by user."
        super().__init__(message)


class StateMismatchUserError(CodespeakUserError):
    """Raised when the OAuth state parameter doesn't match (potential CSRF attack)."""

    def __init__(self):
        message = (
            "Security error: OAuth state mismatch detected.\n"
            "This could indicate a CSRF attack. Please try logging in again."
        )
        super().__init__(message)


class TokenExchangeFailedUserError(CodespeakUserError):
    """Raised when the authorization code to token exchange fails."""

    def __init__(self, error_detail: str):
        message = f"Failed to exchange authorization code for token.\nError: {error_detail}"
        super().__init__(message)


class TokenStorageFailedUserError(CodespeakUserError):
    """Raised when the token cannot be saved to the filesystem."""

    def __init__(self, error_detail: str):
        message = (
            f"Failed to save authentication token to ~/.codespeak/token.json\n"
            f"Error: {error_detail}\n\n"
            "Please check file permissions and disk space."
        )
        super().__init__(message)


class Auth0CallbackError(CodespeakUserError):
    """Raised when Auth0 returns an error in the callback."""

    def __init__(self, error: str, error_description: str | None = None):
        if error_description:
            message = f"Authentication failed: {error}\nDetails: {error_description}"
        else:
            message = f"Authentication failed: {error}"
        super().__init__(message)


class TokenExpiredUserError(CodespeakUserError):
    """Raised when the user's access token has expired."""

    def __init__(self):
        message = "Your authentication token has expired. Please run 'codespeak login' to re-authenticate."
        super().__init__(message)
