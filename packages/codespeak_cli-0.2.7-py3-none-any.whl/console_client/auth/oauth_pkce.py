# ruff: noqa: TID251
"""OAuth 2.0 Authorization Code with PKCE flow implementation."""

import base64
import hashlib
import secrets
from dataclasses import dataclass
from urllib.parse import urlencode

import requests


@dataclass
class OAuthConfig:
    """OAuth configuration for Auth0 authentication."""

    auth0_domain: str  # e.g., "codespeak.us.auth0.com"
    client_id: str  # Auth0 application client ID
    redirect_uri: str  # e.g., "http://localhost:8080/callback"
    scopes: list[str]  # e.g., ["openid", "profile", "email"]


@dataclass
class OAuthTokens:
    """OAuth tokens returned from token exchange."""

    access_token: str
    id_token: str | None
    refresh_token: str | None
    expires_in: int
    token_type: str


def generate_code_verifier() -> str:
    """
    Generate a cryptographically random code verifier for PKCE.

    The verifier is a random string between 43-128 characters using
    unreserved characters [A-Z, a-z, 0-9, -, ., _, ~].

    Returns:
        Base64url-encoded random string (64 characters).
    """
    # Generate 32 random bytes and base64url encode (results in 43 chars without padding)
    # Using 48 bytes to get ~64 characters for better security
    random_bytes = secrets.token_bytes(48)
    # Base64url encoding without padding
    return base64.urlsafe_b64encode(random_bytes).decode("utf-8").rstrip("=")


def generate_code_challenge(code_verifier: str) -> str:
    """
    Generate the code challenge from the code verifier for PKCE.

    The challenge is the SHA256 hash of the verifier, base64url encoded.

    Args:
        code_verifier: The code verifier string.

    Returns:
        Base64url-encoded SHA256 hash of the code verifier.
    """
    # SHA256 hash of the verifier
    sha256_hash = hashlib.sha256(code_verifier.encode("utf-8")).digest()
    # Base64url encoding without padding
    return base64.urlsafe_b64encode(sha256_hash).decode("utf-8").rstrip("=")


def build_authorization_url(config: OAuthConfig, code_challenge: str, state: str) -> str:
    """
    Build the Auth0 authorization URL for the OAuth flow.

    Args:
        config: OAuth configuration.
        code_challenge: The PKCE code challenge.
        state: Random state parameter for CSRF protection.

    Returns:
        Complete authorization URL to open in browser.
    """
    params = {
        "response_type": "code",
        "client_id": config.client_id,
        "redirect_uri": config.redirect_uri,
        "scope": " ".join(config.scopes),
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }

    base_url = f"https://{config.auth0_domain}/authorize"
    return f"{base_url}?{urlencode(params)}"


def exchange_code_for_token(config: OAuthConfig, code: str, code_verifier: str) -> OAuthTokens:
    """
    Exchange the authorization code for access token.

    Args:
        config: OAuth configuration.
        code: Authorization code from callback.
        code_verifier: The original code verifier for PKCE.

    Returns:
        OAuth tokens including access_token.

    Raises:
        requests.RequestException: If the token exchange request fails.
        KeyError: If the response doesn't contain expected fields.
    """
    token_url = f"https://{config.auth0_domain}/oauth/token"

    payload = {
        "grant_type": "authorization_code",
        "client_id": config.client_id,
        "code": code,
        "redirect_uri": config.redirect_uri,
        "code_verifier": code_verifier,
    }

    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    response = requests.post(token_url, data=payload, headers=headers, timeout=30)
    response.raise_for_status()

    data = response.json()

    return OAuthTokens(
        access_token=data["access_token"],
        id_token=data.get("id_token"),
        refresh_token=data.get("refresh_token"),
        expires_in=data.get("expires_in", 0),
        token_type=data.get("token_type", "Bearer"),
    )
