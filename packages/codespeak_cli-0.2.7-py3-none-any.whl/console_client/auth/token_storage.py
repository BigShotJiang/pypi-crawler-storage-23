"""Token storage module for managing user authentication tokens."""

import json
import os
import time
from pathlib import Path

from pydantic import BaseModel

# Buffer time in seconds before actual expiry to trigger re-login
_TOKEN_EXPIRY_BUFFER_SECONDS = 30


class StoredToken(BaseModel):
    """Token data stored in the token file."""

    access_token: str
    expires_at: int | None = None


def get_codespeak_home() -> Path:
    """Get the CodeSpeak home directory path (~/.codespeak)."""
    return Path.home() / ".codespeak"


def ensure_codespeak_home() -> Path:
    """
    Ensure the CodeSpeak home directory exists.

    Creates the directory with secure permissions (0700) if it doesn't exist.

    Returns:
        Path to the CodeSpeak home directory.
    """
    codespeak_home = get_codespeak_home()
    if not codespeak_home.exists():
        codespeak_home.mkdir(parents=True, mode=0o700, exist_ok=True)
    return codespeak_home


def get_token_path() -> Path:
    """Get the path to the token file (~/.codespeak/token.json)."""
    return get_codespeak_home() / "token.json"


def save_token(token: str, expires_in: int = 0) -> None:
    """
    Save the authentication token and its expiration time.

    Creates the CodeSpeak home directory if it doesn't exist.
    Sets file permissions to 0600 (owner read/write only) for security.

    Args:
        token: The authentication token to save.
        expires_in: Token lifetime in seconds from now. If 0, no expiry is saved.

    Raises:
        OSError: If the token cannot be saved due to filesystem errors.
    """
    ensure_codespeak_home()
    token_path = get_token_path()

    expires_at = int(time.time()) + expires_in if expires_in > 0 else None
    stored = StoredToken(access_token=token, expires_at=expires_at)

    token_path.write_text(stored.model_dump_json(), encoding="utf-8")
    os.chmod(token_path, 0o600)


def _load_stored_token() -> StoredToken | None:
    """Load the stored token data from the token file."""
    token_path = get_token_path()
    if not token_path.exists():
        return None

    try:
        data = json.loads(token_path.read_text(encoding="utf-8"))
        return StoredToken.model_validate(data)
    except (json.JSONDecodeError, ValueError):
        return None


def load_user_token() -> str | None:
    """
    Load the authentication token from the token file.

    Returns:
        The authentication token if it exists, None otherwise.
    """
    stored = _load_stored_token()
    return stored.access_token if stored else None


def delete_token() -> None:
    """
    Delete the authentication token file.

    Does nothing if the file doesn't exist.

    Raises:
        OSError: If the file exists but cannot be deleted.
    """
    token_path = get_token_path()
    if token_path.exists():
        token_path.unlink()


def is_token_expired() -> bool:
    """
    Check if the stored token is expired or about to expire.

    Returns True if the token is expired or will expire within the buffer period,
    giving time for re-login before actual expiry.

    Returns:
        True if token is expired or will expire soon, False otherwise.
    """
    stored = _load_stored_token()
    if not stored or stored.expires_at is None:
        return False

    return time.time() >= stored.expires_at - _TOKEN_EXPIRY_BUFFER_SECONDS
