"""Local HTTP server for OAuth callback handling."""

import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import ClassVar
from urllib.parse import parse_qs, urlparse

from codespeak_shared.utils.ports import is_port_free


class OAuthCallbackServer:
    """Local HTTP server to receive OAuth callback."""

    # Ports to try (must all be configured in Auth0's Allowed Callback URLs)
    # Configure these in Auth0: http://localhost:8080/callback, http://localhost:8081/callback, etc.
    ALLOWED_PORTS = [8080, 8081, 8082, 8083, 8084, 8085, 8086, 8087, 8088, 8089]

    # Class variables shared with handler (intentionally not private)
    authorization_code: ClassVar[str | None] = None
    state_received: ClassVar[str | None] = None
    error: ClassVar[str | None] = None
    callback_received: ClassVar[threading.Event] = threading.Event()

    def __init__(self, timeout: int = 300):
        """
        Initialize the OAuth callback server.

        Args:
            timeout: Maximum time to wait for callback in seconds (default: 300 = 5 minutes).
        """
        self._timeout = timeout
        self._port: int = 0
        self._server: HTTPServer | None = None
        self._server_thread: threading.Thread | None = None

    def start(self) -> str:
        """
        Start the callback server on a free port.

        Returns:
            The redirect URI (e.g., "http://localhost:8080/callback").

        Raises:
            RuntimeError: If the server fails to start.
        """
        # Reset class variables
        OAuthCallbackServer.authorization_code = None
        OAuthCallbackServer.state_received = None
        OAuthCallbackServer.error = None
        OAuthCallbackServer.callback_received.clear()

        # Try each allowed port in sequence
        server_started = False
        for port in self.ALLOWED_PORTS:
            if is_port_free(port):
                try:
                    self._server = HTTPServer(("localhost", port), _OAuthCallbackHandler)
                    self._port = port
                    server_started = True
                    break
                except OSError:
                    # Port became busy between check and bind, try next
                    continue

        if not server_started:
            ports_str = ", ".join(str(p) for p in self.ALLOWED_PORTS)
            raise RuntimeError(
                f"Failed to start callback server. All allowed ports are busy: {ports_str}\n"
                f"Please close other applications using these ports and try again.\n"
                f"These ports must be configured in Auth0's Allowed Callback URLs."
            )

        # Start server in background thread
        assert self._server is not None  # Ensured by server_started check above
        self._server_thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._server_thread.start()

        return f"http://localhost:{self._port}/callback"

    def wait_for_callback(self) -> tuple[str | None, str | None, str | None]:
        """
        Wait for the OAuth callback.

        Blocks until callback is received or timeout occurs.

        Returns:
            Tuple of (authorization_code, state_received, error).
            If timeout, all values will be None.

        Raises:
            TimeoutError: If no callback is received within the timeout period.
        """
        # Wait for callback with timeout
        callback_received = OAuthCallbackServer.callback_received.wait(timeout=self._timeout)

        if not callback_received:
            raise TimeoutError(f"No callback received within {self._timeout} seconds")

        return (
            OAuthCallbackServer.authorization_code,
            OAuthCallbackServer.state_received,
            OAuthCallbackServer.error,
        )

    def shutdown(self) -> None:
        """Shutdown the callback server."""
        if self._server:
            self._server.shutdown()
            self._server = None
        if self._server_thread:
            self._server_thread.join(timeout=1)
            self._server_thread = None


class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP request handler for OAuth callback."""

    def log_message(self, format: str, *args: object) -> None:  # noqa: ARG002, A002
        """Suppress default HTTP server logging."""

    def do_GET(self) -> None:  # noqa: N802
        """Handle GET request to /callback."""
        # Parse URL
        parsed_url = urlparse(self.path)

        if parsed_url.path == "/callback":
            # Parse query parameters
            query_params = parse_qs(parsed_url.query)

            # Extract authorization code, state, and error
            OAuthCallbackServer.authorization_code = query_params.get("code", [None])[0]
            OAuthCallbackServer.state_received = query_params.get("state", [None])[0]
            OAuthCallbackServer.error = query_params.get("error", [None])[0]

            # Signal that callback was received
            OAuthCallbackServer.callback_received.set()

            # Send success response
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()

            # Display success page
            if OAuthCallbackServer.error:
                html = f"""
                <html>
                <head><title>Authentication Error</title></head>
                <body>
                    <h1>Authentication Error</h1>
                    <p>Error: {OAuthCallbackServer.error}</p>
                    <p>You can close this window now.</p>
                </body>
                </html>
                """
            else:
                html = """
                <html>
                <head><title>Authentication Successful</title></head>
                <body>
                    <h1>Authentication Successful!</h1>
                    <p>You have been successfully authenticated with CodeSpeak.</p>
                    <p>You can close this window now and return to the terminal.</p>
                </body>
                </html>
                """

            self.wfile.write(html.encode("utf-8"))
        else:
            # Return 404 for other paths
            self.send_error(404)
