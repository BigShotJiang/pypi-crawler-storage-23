"""Authentication manager for orchestrating the OAuth login flow."""

import os
import secrets
import webbrowser

import requests
from rich.console import Console

from console_client.auth.callback_server import OAuthCallbackServer
from console_client.auth.exceptions import (
    Auth0CallbackError,
    LoginTimeoutUserError,
    StateMismatchUserError,
    TokenExchangeFailedUserError,
    TokenStorageFailedUserError,
)
from console_client.auth.oauth_pkce import (
    OAuthConfig,
    build_authorization_url,
    exchange_code_for_token,
    generate_code_challenge,
    generate_code_verifier,
)
from console_client.auth.token_storage import save_token
from console_client.client_feature_flags import ConsoleClientFeatureFlags


def login(console: Console, client_feature_flags: ConsoleClientFeatureFlags) -> None:
    """
    Orchestrate the OAuth PKCE login flow with Auth0.

    Steps:
    1. Read Auth0 configuration from feature flags
    2. Start local callback server
    3. Generate PKCE parameters (code_verifier, code_challenge, state)
    4. Build authorization URL
    5. Open browser to Auth0 login page
    6. Wait for callback
    7. Validate state parameter
    8. Exchange authorization code for token
    9. Save access token to ~/.codespeak/token
    10. Display success message

    Args:
        console: Rich console for user output.
        client_feature_flags: Feature flags instance for reading Auth0 configuration.

    Raises:
        Auth0NotConfiguredUserError: If Auth0 configuration is missing.
        LoginTimeoutUserError: If user doesn't complete login in time.
        StateMismatchUserError: If OAuth state validation fails.
        TokenExchangeFailedUserError: If code-to-token exchange fails.
        TokenStorageFailedUserError: If token cannot be saved.
        Auth0CallbackError: If Auth0 returns an error.
    """
    # Step 1: Read Auth0 configuration from feature flags
    auth0_domain = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_AUTH0_DOMAIN)
    client_id = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_AUTH0_CLIENT_ID)
    scopes_str = client_feature_flags.get_flag_value(ConsoleClientFeatureFlags.CONSOLE_CLIENT_AUTH0_SCOPES)
    scopes = scopes_str.split()
    callback_timeout = client_feature_flags.get_flag_value(
        ConsoleClientFeatureFlags.CONSOLE_CLIENT_AUTH0_CALLBACK_TIMEOUT
    )

    # Step 2: Start local callback server
    console.print("[blue]Starting local callback server...[/blue]")
    callback_server = OAuthCallbackServer(timeout=callback_timeout)

    try:
        redirect_uri = callback_server.start()
        console.print(f"[dim]Callback server listening on {redirect_uri}[/dim]")

        # Step 3: Generate PKCE parameters
        code_verifier = generate_code_verifier()
        code_challenge = generate_code_challenge(code_verifier)
        state = secrets.token_urlsafe(32)

        # Step 4: Build authorization URL
        oauth_config = OAuthConfig(
            auth0_domain=auth0_domain,
            client_id=client_id,
            redirect_uri=redirect_uri,
            scopes=scopes,
        )

        auth_url = build_authorization_url(oauth_config, code_challenge, state)

        # Step 5: Open browser
        console.print(f"\n[bold green]Opening browser for authentication...[/bold green]")
        console.print(f"[dim]If browser doesn't open automatically, visit:[/dim]")
        console.print(f"[dim]{auth_url}[/dim]\n")

        browser_opened = webbrowser.open(auth_url)
        if not browser_opened:
            console.print("[yellow]Warning: Failed to open browser automatically.[/yellow]")
            console.print(f"[yellow]Please manually visit: {auth_url}[/yellow]\n")

        # Step 6: Wait for callback
        console.print("[blue]Waiting for authentication...[/blue]")
        console.print("[dim](You can press Ctrl+C to cancel)[/dim]\n")

        try:
            authorization_code, state_received, error = callback_server.wait_for_callback()
        except TimeoutError:
            raise LoginTimeoutUserError(callback_timeout) from None

        # Check for Auth0 error
        if error:
            error_description = os.environ.get("error_description")
            raise Auth0CallbackError(error, error_description)

        # Step 7: Validate state
        if state_received != state:
            raise StateMismatchUserError()

        # Step 8: Exchange code for token
        console.print("[blue]Exchanging authorization code for token...[/blue]")

        try:
            tokens = exchange_code_for_token(oauth_config, authorization_code, code_verifier)  # type: ignore
        except requests.RequestException as e:
            error_detail = str(e)
            if hasattr(e, "response") and e.response is not None:
                try:
                    error_json = e.response.json()
                    error_detail = error_json.get("error_description", error_json.get("error", str(e)))
                except Exception:  # noqa: BLE001
                    error_detail = e.response.text or str(e)
            raise TokenExchangeFailedUserError(error_detail) from e

        # Step 9: Save token
        console.print("[blue]Saving authentication token...[/blue]")

        try:
            save_token(tokens.access_token, tokens.expires_in)
        except OSError as e:
            raise TokenStorageFailedUserError(str(e)) from e

        # Step 10: Display success
        console.print("\n[bold green]✓ Authentication successful![/bold green]")
        console.print("[green]Token saved to ~/.codespeak/token.json[/green]")

        if tokens.expires_in > 0:
            hours = tokens.expires_in // 3600
            minutes = (tokens.expires_in % 3600) // 60
            if hours > 0:
                console.print(f"[dim]Token expires in {hours}h {minutes}m[/dim]")
            else:
                console.print(f"[dim]Token expires in {minutes}m[/dim]")

        console.print("\n[green]You can now use CodeSpeak commands that require authentication.[/green]")

    finally:
        # Always shutdown the callback server
        callback_server.shutdown()
