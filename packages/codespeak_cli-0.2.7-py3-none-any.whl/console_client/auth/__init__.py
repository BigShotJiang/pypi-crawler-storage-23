"""Authentication module for CodeSpeak CLI."""
