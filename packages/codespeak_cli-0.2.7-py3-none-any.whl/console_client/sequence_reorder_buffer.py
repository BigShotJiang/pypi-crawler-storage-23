"""Generic buffer for reordering sequenced items that may arrive out of order."""

from collections.abc import Callable
from typing import Generic, Protocol, TypeVar


class Sequenced(Protocol):
    """Protocol for items that have a sequence number."""

    @property
    def sequence_number(self) -> int | None:
        """Get the sequence number of this item."""
        ...


T = TypeVar("T", bound=Sequenced)


class SequenceReorderBuffer(Generic[T]):
    """Buffer that reorders items by sequence number and publishes contiguous chunks.

    This buffer ensures that items are published in order, even if they arrive out of order.
    Items are buffered until all previous items in the sequence have been received.

    Example:
        If events arrive in order: 0, 1, 3, 2, 4
        They will be published as: [0], [1], [2, 3, 4]
        (item 2 and 3 were buffered until 2 arrived, then the contiguous chunk 2,3,4 was published)

    Usage:
        def publish(item: MyItem) -> None:
            print(f"Publishing: {item}")

        buffer = SequenceReorderBuffer[MyItem](publish)
        buffer.add(item_0)  # Publishes immediately: [item_0]
        buffer.add(item_2)  # Buffered
        buffer.add(item_1)  # Publishes: [item_1, item_2]
    """

    def __init__(self, publish_callback: Callable[[T], None]):
        """Initialize the buffer.

        Args:
            publish_callback: Function called for each item when it's ready to be published
        """
        self._publish_callback = publish_callback
        self._next_expected_sequence = 0
        self._buffer: dict[int, T] = {}

    def add(self, item: T) -> None:
        """Add an item to the buffer.

        If the item completes a contiguous sequence starting from _next_expected_sequence,
        all items in that sequence are published immediately.

        Args:
            item: The item to add

        Raises:
            ValueError: If the item does not have a sequence number assigned
        """
        sequence_num = item.sequence_number
        if sequence_num is None:
            raise ValueError("Cannot add item without sequence number to reorder buffer")

        # If this is the next expected item, publish it and any buffered items that follow
        if sequence_num == self._next_expected_sequence:
            self._publish_callback(item)
            self._next_expected_sequence += 1

            # Publish any contiguous buffered items
            while self._next_expected_sequence in self._buffer:
                buffered_item = self._buffer.pop(self._next_expected_sequence)
                self._publish_callback(buffered_item)
                self._next_expected_sequence += 1
        elif sequence_num > self._next_expected_sequence:
            # Buffer this item for later
            self._buffer[sequence_num] = item
        # else: sequence_num < self._next_expected_sequence, ignore duplicate/old item

    @property
    def next_expected_sequence(self) -> int:
        """Get the next expected sequence number."""
        return self._next_expected_sequence

    @property
    def buffered_count(self) -> int:
        """Get the number of items currently buffered."""
        return len(self._buffer)

    def get_buffered_sequences(self) -> list[int]:
        """Get the sequence numbers of all buffered items (for debugging/testing)."""
        return sorted(self._buffer.keys())
