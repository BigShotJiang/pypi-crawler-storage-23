"""Converter from protobuf BuildInsightEvent messages to Python objects."""

from typing import Any

from api_stubs import build_server_pb2
from api_stubs.build_server_pb2 import BuildFinished, BuildResultType
from codespeak_shared import BuildResult
from codespeak_shared.build_insight.events import (
    BuildInsightEvent,
    ProgressItemCreateEvent,
    ProgressItemStatus,
    ProgressItemUpdateEvent,
    SpanCloseEvent,
    SpanOpenEvent,
    StopInteractiveProgressEvent,
    TestsRunEvent,
    TextOutputEvent,
    ToolCallEvent,
    UserVisibleModelOutputEvent,
)
from codespeak_shared.exceptions import CodespeakInternalError, CodespeakUserError
from codespeak_shared.test_runner_types import TestResults


def _convert_progress_status_from_proto(status: int) -> ProgressItemStatus:
    """Convert protobuf enum to Python ProgressItemStatus."""
    mapping: dict[int, ProgressItemStatus] = {
        int(build_server_pb2.PROGRESS_ITEM_STATUS_PENDING): ProgressItemStatus.PENDING,
        int(build_server_pb2.PROGRESS_ITEM_STATUS_IN_PROGRESS): ProgressItemStatus.IN_PROGRESS,
        int(build_server_pb2.PROGRESS_ITEM_STATUS_SKIPPED): ProgressItemStatus.SKIPPED,
        int(build_server_pb2.PROGRESS_ITEM_STATUS_DONE): ProgressItemStatus.DONE,
        int(build_server_pb2.PROGRESS_ITEM_STATUS_FAILED): ProgressItemStatus.FAILED,
    }
    result = mapping.get(status)
    return result if result is not None else ProgressItemStatus.PENDING


def convert_proto_to_build_insight_event(proto_event: Any) -> BuildInsightEvent:
    """Convert a protobuf BuildInsightEvent to a Python BuildInsightEvent."""
    which = proto_event.WhichOneof("event")

    sequence_number = proto_event.sequence_number

    if which == "progress_item_create":
        create = proto_event.progress_item_create
        extra: dict[str, Any] = {}
        if create.truncate_child_output:
            extra["truncate_child_output"] = True
        return ProgressItemCreateEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            progress_item_id=create.progress_item_id,
            status=_convert_progress_status_from_proto(create.status),
            title=create.title,
            description=create.description if create.description else None,
            parent_item_id=create.parent_item_id if create.parent_item_id else None,
            status_text=create.status_text if create.status_text else None,
            extra=extra,
        )
    elif which == "progress_item_update":
        update = proto_event.progress_item_update
        return ProgressItemUpdateEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            progress_item_id=update.progress_item_id,
            status=_convert_progress_status_from_proto(update.status),
            status_text=update.status_text if update.status_text else None,
        )
    elif which == "text_output":
        text = proto_event.text_output
        return TextOutputEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            text=text.text,
            parent_progress_item_id=text.parent_progress_item_id if text.parent_progress_item_id else None,
        )
    elif which == "tool_call":
        tool = proto_event.tool_call
        return ToolCallEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            title=tool.title,
            details=tool.details if tool.details else None,
            parent_progress_item_id=tool.parent_progress_item_id if tool.parent_progress_item_id else None,
        )
    elif which == "user_visible_model_output":
        model_out = proto_event.user_visible_model_output
        return UserVisibleModelOutputEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            text=model_out.text,
            parent_progress_item_id=model_out.parent_progress_item_id if model_out.parent_progress_item_id else None,
        )
    elif which == "span_open":
        span = proto_event.span_open
        return SpanOpenEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            span_id=span.span_id,
            title=span.title,
            description=span.description if span.description else None,
        )
    elif which == "span_close":
        span = proto_event.span_close
        return SpanCloseEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            span_id=span.span_id,
        )
    elif which == "tests_run":
        tests = proto_event.tests_run
        test_results = None
        if tests.test_results_json:
            test_results = TestResults.model_validate_json(tests.test_results_json)
        return TestsRunEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
            test_results=test_results,
        )
    elif which == "stop_interactive_progress":
        return StopInteractiveProgressEvent(
            timestamp=proto_event.timestamp,
            sequence_number=sequence_number,
        )
    else:
        raise ValueError(f"Unknown type {which} of event {proto_event}")


def convert_build_finished_proto_to_result(build_finished: BuildFinished) -> BuildResult:
    if build_finished.result_type == BuildResultType.BUILD_RESULT_SUCCEEDED:
        result = BuildResult.succeeded(build_finished.command)
    elif build_finished.result_type == BuildResultType.BUILD_RESULT_SKIPPED:
        result = BuildResult(BuildResult.SKIPPED, build_finished.command)
    elif build_finished.result_type == BuildResultType.BUILD_RESULT_CANCELLED:
        result = BuildResult.failed(build_finished.command, KeyboardInterrupt())
    elif build_finished.result_type == BuildResultType.BUILD_RESULT_FAILED:
        if not build_finished.build_error:
            raise ValueError(f"build_finished.build_error is missing in {build_finished}")

        build_error = build_finished.build_error

        if build_error.HasField("user_error"):
            exception = CodespeakUserError(user_visible_message=build_error.user_error.user_visible_message)
        elif build_error.HasField("internal_error"):
            exception = CodespeakInternalError(
                internal_message=build_error.internal_error.internal_message,
                server_stack_trace=build_error.internal_error.stack_trace
                if build_error.internal_error.stack_trace
                else None,
            )
        else:
            raise ValueError(f"BuildError has neither user_error nor internal_error: {build_error}")

        result = BuildResult.failed(build_finished.command, exception)
    else:
        raise ValueError(f"Unexpected build result type: {build_finished.result_type}")

    # Set build statistics
    if build_finished.build_stats:
        stats = build_finished.build_stats
        result.build_stats.cache_enabled = stats.cache_enabled
        result.build_stats.cache_hits = stats.cache_hits
        result.build_stats.cache_misses = stats.cache_misses

    return result
