"""Console client feature flags."""

from codespeak_shared.shared_feature_flags import FeatureFlag, FeatureFlagsMeta, SharedFeatureFlags


class ConsoleClientFeatureFlags(SharedFeatureFlags, metaclass=FeatureFlagsMeta):
    CONSOLE_CLIENT_PRINT_GRPC_EVENTS = FeatureFlag(default_value=False)

    CONSOLE_CLIENT_SEND_USER_TOKEN = FeatureFlag(default_value=True)

    CONSOLE_CLIENT_BUILD_SERVER_HOST = FeatureFlag(default_value="build.codespeak.dev")

    CONSOLE_CLIENT_BUILD_SERVER_PORT = FeatureFlag(default_value=50053)

    CONSOLE_CLIENT_BUILD_SERVER_SECURE = FeatureFlag(default_value=True)

    CONSOLE_CLIENT_AUTH0_DOMAIN = FeatureFlag[str](default_value="auth.codespeak.dev")

    CONSOLE_CLIENT_AUTH0_CLIENT_ID = FeatureFlag[str](default_value="zVHCedn5lS2hl6hiVtQuTMm9Hg2ZHZk9")

    CONSOLE_CLIENT_AUTH0_SCOPES = FeatureFlag[str](default_value="openid profile email")

    CONSOLE_CLIENT_AUTH0_CALLBACK_TIMEOUT = FeatureFlag[int](default_value=300)

    CONSOLE_CLIENT_WORKER_THREAD_POOL_SIZE = FeatureFlag[int](default_value=4)

    CONSOLE_CLIENT_VERSION_CHECK_ENABLED = FeatureFlag(default_value=True)

    CONSOLE_CLIENT_VERSION_CHECK_INTERVAL_HOURS = FeatureFlag[int](default_value=8)
