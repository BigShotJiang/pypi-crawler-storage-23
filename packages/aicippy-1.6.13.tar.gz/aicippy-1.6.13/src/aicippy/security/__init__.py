"""
Security audit module for AiCippy.

Provides AI-powered security analysis via api.aicippy.com + aivedha.ai integration.
This is a cross-service feature that does NOT require CHAKRA plan validation.

Components:
- SecurityAuditClient: HTTP + WebSocket client for security audit API
- AuditFinding, SecurityAuditResult: Data models for audit results
- SecurityAuditFormatter: Rich-formatted terminal output for audit results
"""

from __future__ import annotations

from aicippy.security.models import (
    AuditFinding,
    AuditSeverity,
    AuditStatus,
    AuditSummary,
    SecurityAuditResult,
)

__all__ = [
    "AuditFinding",
    "AuditSeverity",
    "AuditStatus",
    "AuditSummary",
    "SecurityAuditResult",
]
