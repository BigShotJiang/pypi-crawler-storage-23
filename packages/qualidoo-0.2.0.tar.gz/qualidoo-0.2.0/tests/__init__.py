# Qualidoo CLI test suite
