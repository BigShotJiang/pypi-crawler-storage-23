# Code of Conduct

We expect all contributors and community participants to be respectful and constructive.

Unacceptable behavior includes harassment, discrimination, threats, or hostility toward others.

Project maintainers may remove, edit, or reject contributions or participation that violates this code of conduct.

If you experience or witness unacceptable behavior, please report it to:

- security@sentinoshq.com

