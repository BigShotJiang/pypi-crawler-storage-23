"""Custom exceptions raised by this package."""
