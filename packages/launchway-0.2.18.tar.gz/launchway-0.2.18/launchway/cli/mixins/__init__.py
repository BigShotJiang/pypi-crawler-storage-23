# Mixin modules for CLIJobAgent
