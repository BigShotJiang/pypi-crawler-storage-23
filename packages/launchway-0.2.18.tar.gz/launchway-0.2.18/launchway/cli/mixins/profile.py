"""
Profile management mixin.

Field names match the profile_service / frontend convention exactly
(e.g.  "date of birth",  "zip",  "work experience",  "other links")
so that data round-trips correctly through POST /api/profile.
"""

import logging
from datetime import datetime
from launchway.api_client import LaunchwayAPIError
from launchway.cli.utils import Colors

logger = logging.getLogger(__name__)

# ── helpers ──────────────────────────────────────────────────────────────────

def _parse_date(raw: str):
    """
    Accept several common date formats from user input and return a
    datetime object, or None if the string is unrecognisable.

    Accepted: DD/MM/YYYY  DD-MM-YYYY  MM/DD/YYYY  YYYY-MM-DD
    """
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(raw.strip(), fmt)
        except ValueError:
            continue
    return None


def _to_iso_date(raw: str) -> str:
    """
    Convert any supported date string to YYYY-MM-DD (required by the
    HTML <input type="date"> on the frontend).
    Returns the original string unchanged if it cannot be parsed.
    """
    dt = _parse_date(raw)
    return dt.strftime("%Y-%m-%d") if dt else raw


def _display_date(iso: str) -> str:
    """
    Format a stored YYYY-MM-DD date as the friendlier DD/MM/YYYY for
    display in the terminal.  Falls back to the raw value.
    """
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d/%m/%Y")
    except Exception:
        return iso or "Not set"


def _yn(val) -> str:
    """Render a boolean / string value as Yes / No / the raw string."""
    if val is True  or (isinstance(val, str) and val.lower() in ('yes', 'true', '1')):
        return "Yes"
    if val is False or (isinstance(val, str) and val.lower() in ('no', 'false', '0')):
        return "No"
    return str(val) if val else "Not set"

def _list_str(val) -> str:
    if isinstance(val, list):
        return ", ".join(str(v) for v in val) if val else "—"
    return str(val) if val else "—"

def _ask(prompt: str, current=None) -> str:
    display = f" (current: {current})" if current else ""
    return input(f"  {prompt}{display}: ").strip()

def _ask_list(prompt: str, current: list = None) -> list:
    display = f" (current: {_list_str(current)})" if current else ""
    raw = input(f"  {prompt}{display}\n  (comma-separated, leave blank to keep): ").strip()
    if not raw:
        return current or []
    return [s.strip() for s in raw.split(",") if s.strip()]


# ── mixin ────────────────────────────────────────────────────────────────────

class ProfileMixin:

    # ── menu ──────────────────────────────────────────────────────────────

    def profile_menu(self):
        options = [
            ("View Full Profile",           self.view_profile),
            ("Basic Info",                  self.update_basic_info),
            ("Contact Info",                self.update_contact_info),
            ("Resume",                       self.update_resume),
            ("Summary / Bio",               self.update_summary),
            ("Education",                   self.update_education),
            ("Work Experience",             self.update_work_experience),
            ("Projects",                    self.update_projects),
            ("Skills",                      self.update_skills),
            ("Cover Letter Template",       self.update_cover_letter),
            ("Job Preferences",             self.update_job_preferences),
            ("EEO / Compliance Info",       self.update_eeo_info),
            ("Other Links / Portfolio",     self.update_other_links),
            ("AI Engine",                   self.update_ai_engine),
            ("Back to Main Menu",           None),
        ]

        while True:
            self.clear_screen()
            self.print_header("PROFILE MANAGEMENT")
            for i, (label, _) in enumerate(options, 1):
                print(f"  {i:>2}. {label}")
            print()

            choice = self.get_input(f"Select option (1-{len(options)}): ").strip()
            try:
                idx = int(choice) - 1
                if idx < 0 or idx >= len(options):
                    raise ValueError
            except ValueError:
                self.print_error("Invalid option")
                self.pause()
                continue

            label, fn = options[idx]
            if fn is None:
                break
            fn()

    # ── view ──────────────────────────────────────────────────────────────

    def view_profile(self):
        self.clear_screen()
        self.print_header("YOUR PROFILE")

        if not self.current_profile:
            self.print_warning("No profile data available.")
            self.pause()
            return

        p = self.current_profile

        def section(title):
            print(f"\n{Colors.BOLD}{Colors.OKCYAN}{title}{Colors.ENDC}")

        def row(label, key, fmt=None):
            val = p.get(key, "")
            if fmt:
                val = fmt(val)
            print(f"  {label:<28} {val or '—'}")

        section("Basic Information")
        row("Name",               "first name",  lambda v: f"{v} {p.get('last name','')}")
        row("Email",              "email")
        row("Date of Birth",      "date of birth", _display_date)
        row("Gender",             "gender")
        row("Nationality",        "nationality")
        row("Preferred Language", "preferred language")

        section("Contact")
        row("Phone",              "phone")
        row("Address",            "address")
        row("City",               "city")
        row("State",              "state")
        row("ZIP",                "zip")
        row("Country",            "country")
        row("LinkedIn",           "linkedin")
        row("GitHub",             "github")

        section("Resume")
        row("Resume URL",         "resume_url")
        row("Source Type",        "resume_source_type")

        summary = p.get("summary", "")
        if summary:
            section("Summary / Bio")
            print(f"  {summary[:300]}")

        education = p.get("education", [])
        if education:
            section("Education")
            for i, edu in enumerate(education, 1):
                print(f"  {i}. {edu.get('degree','')} — {edu.get('institution','')}")
                print(f"     Graduated: {edu.get('graduation_year','')}  |  GPA: {edu.get('gpa','')}")

        work_exp = p.get("work experience", p.get("work_experience", []))
        if work_exp:
            section("Work Experience")
            for i, exp in enumerate(work_exp, 1):
                print(f"  {i}. {exp.get('title','')} at {exp.get('company','')}")
                print(f"     {exp.get('start_date','')} – {exp.get('end_date','Present')}")

        projects = p.get("projects", [])
        if projects:
            section("Projects")
            for i, proj in enumerate(projects, 1):
                techs = _list_str(proj.get("technologies", []))
                print(f"  {i}. {proj.get('name','')}  [{techs}]")

        skills = p.get("skills", {})
        if skills:
            section("Skills")
            for cat, items in skills.items():
                if items:
                    print(f"  {cat:<24} {_list_str(items)}")

        section("Job Preferences")
        row("Willing to Relocate",    "willing to relocate", _yn)
        row("Preferred Location(s)",  "preferred location",  _list_str)

        section("EEO / Compliance")
        row("Visa Status",        "visa status")
        row("Visa Sponsorship",   "visa sponsorship")
        row("Veteran Status",     "veteran status")
        row("Disabilities",       "disabilities", _list_str)

        other_links = p.get("other links", [])
        if other_links:
            section("Other Links")
            for link in other_links:
                label = link.get("label", "") if isinstance(link, dict) else ""
                url   = link.get("url", link)  if isinstance(link, dict) else link
                print(f"  {label+': ' if label else ''}{url}")

        print()
        self.pause()

    # ── save helper ───────────────────────────────────────────────────────

    def _save_profile_changes(self, changes: dict) -> bool:
        """
        Merge changes into current_profile, POST to the API, and refresh.

        Shows a live "Saving..." indicator while the request is in flight.
        Prints the outcome inline (done / failed) so every caller gets
        consistent feedback without duplicating any print logic.

        Returns True on success, False on failure.
        """
        import sys

        self.current_profile = {**(self.current_profile or {}), **changes}

        sys.stdout.write(f"\n  {Colors.OKCYAN}Saving to your profile...{Colors.ENDC} ")
        sys.stdout.flush()

        try:
            self.api.update_profile(self.current_profile)
            self.current_profile = self.api.get_profile()
            sys.stdout.write(f"{Colors.OKGREEN}done.{Colors.ENDC}\n")
            sys.stdout.flush()
            return True
        except LaunchwayAPIError as e:
            sys.stdout.write(f"{Colors.FAIL}failed.{Colors.ENDC}\n")
            sys.stdout.write(f"  {Colors.FAIL}Error: {e}{Colors.ENDC}\n")
            sys.stdout.flush()
            return False

    # ── section editors ───────────────────────────────────────────────────

    def update_basic_info(self):
        self.clear_screen()
        self.print_header("BASIC INFO")
        print("  Leave blank to keep the current value.\n")

        p = self.current_profile or {}
        changes = {}

        current_dob = _display_date(p.get("date of birth", ""))
        val = _ask("Date of Birth (DD/MM/YYYY)", current_dob)
        if val:
            iso = _to_iso_date(val)
            if iso == val and not _parse_date(val):
                # Unrecognised format — warn but don't block
                self.print_warning(f"Could not parse '{val}' as a date. Please use DD/MM/YYYY.")
                self.pause()
                return
            changes["date of birth"] = iso

        val = _ask("Gender", p.get("gender"))
        if val: changes["gender"] = val

        val = _ask("Nationality", p.get("nationality"))
        if val: changes["nationality"] = val

        val = _ask("Preferred Language", p.get("preferred language"))
        if val: changes["preferred language"] = val

        if not changes:
            self.print_warning("No changes made.")
            self.pause()
            return
        if self._save_profile_changes(changes):
            self.print_success("Basic info updated!")
        self.pause()

    def update_contact_info(self):
        self.clear_screen()
        self.print_header("CONTACT INFO")
        print("  Leave blank to keep the current value.\n")

        p = self.current_profile or {}
        fields = [
            ("phone",   "Phone"),
            ("address", "Address"),
            ("city",    "City"),
            ("state",   "State"),
            ("zip",     "ZIP Code"),
            ("country", "Country"),
            ("country_code", "Country Code (e.g. +1)"),
            ("state_code",   "State Code (e.g. CA)"),
            ("linkedin", "LinkedIn URL"),
            ("github",   "GitHub URL"),
        ]
        changes = {}
        for key, label in fields:
            val = _ask(label, p.get(key))
            if val:
                changes[key] = val

        if not changes:
            self.print_warning("No changes made.")
            self.pause()
            return
        if self._save_profile_changes(changes):
            self.print_success("Contact info updated!")
        self.pause()

    def update_resume(self):
        """Let the user provide either a Google Doc URL or upload a PDF/DOCX."""
        self.clear_screen()
        self.print_header("RESUME")

        p = self.current_profile or {}
        current_url = p.get('resume_url') or ''
        current_type = p.get('resume_source_type') or 'google_doc'

        # Show current state
        if current_url:
            print(f"  Current resume: {current_url}  [{current_type}]")
        else:
            print(f"  Current resume: {'—'} (type: {current_type})")
        print()

        print("  How would you like to provide your resume?\n")
        print("  1. Google Docs URL   (enables resume tailoring ✅)")
        print("  2. Upload PDF / DOCX (tailoring disabled ⚠️ )")
        print("  3. Cancel\n")

        choice = input("  Choose [1/2/3]: ").strip()

        if choice == '1':
            self._update_resume_google_doc()
        elif choice == '2':
            self._update_resume_file()
        else:
            self.print_warning("No changes made.")
            self.pause()

    def _update_resume_google_doc(self):
        self.clear_screen()
        self.print_header("RESUME — GOOGLE DOCS URL")
        print("  Paste the sharing link of your Google Doc resume.")
        print("  The document must be set to 'Anyone with the link can view'.\n")
        url = _ask("Google Docs URL")
        if not url:
            self.print_warning("No changes made.")
            self.pause()
            return
        if 'docs.google.com' not in url:
            self.print_warning("That doesn't look like a Google Docs URL. Please try again.")
            self.pause()
            return
        if self._save_profile_changes({"resume_url": url, "resume_source_type": "google_doc"}):
            self.print_success("Resume URL saved. Resume tailoring is now enabled.")
        self.pause()

    def _update_resume_file(self):
        import os

        self.clear_screen()
        self.print_header("RESUME — UPLOAD PDF / DOCX")
        print(f"  {Colors.YELLOW}⚠️  WARNING: Resume tailoring is NOT available for PDF/DOCX uploads.{Colors.RESET}")
        print("  Your profile will be populated from the file, but AI tailoring")
        print("  requires a Google Docs URL. To enable tailoring, go back and")
        print("  choose 'Google Docs URL' instead.\n")

        file_path = _ask("Full path to PDF or DOCX file (or blank to cancel)").strip()
        if not file_path:
            self.print_warning("No changes made.")
            self.pause()
            return

        file_path = os.path.expanduser(file_path)
        if not os.path.isfile(file_path):
            self.print_error(f"File not found: {file_path}")
            self.pause()
            return

        ext = os.path.splitext(file_path)[1].lower()
        if ext not in ('.pdf', '.docx'):
            self.print_error("Only .pdf and .docx files are supported.")
            self.pause()
            return

        file_size = os.path.getsize(file_path)
        if file_size > 10 * 1024 * 1024:
            self.print_error("File is too large (maximum 10 MB).")
            self.pause()
            return
        if file_size == 0:
            self.print_error("File is empty.")
            self.pause()
            return

        print("\n  Uploading and extracting profile data...", end="", flush=True)
        try:
            with open(file_path, 'rb') as fh:
                import requests as _req
                backend_url = self.api.base_url.rstrip('/')
                headers = {"Authorization": f"Bearer {self.api.token}"}
                resp = _req.post(
                    f"{backend_url}/api/upload-resume",
                    files={"resume": (os.path.basename(file_path), fh,
                                      "application/pdf" if ext == '.pdf'
                                      else "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
                    headers=headers,
                    timeout=60,
                )
            data = resp.json()
        except Exception as e:
            print(f" failed.\n")
            self.print_error(f"Upload error: {e}")
            self.pause()
            return

        if not data.get("success"):
            print(" failed.\n")
            self.print_error(data.get("error", "Upload failed."))
            self.pause()
            return

        print(" done.\n")
        self.print_success(
            f"{ext.upper()[1:]} resume uploaded. Profile has been populated."
        )
        print(f"\n  {Colors.YELLOW}⚠️  Remember: resume tailoring is disabled for this format.{Colors.RESET}")
        print("  To enable tailoring, add your Google Docs resume URL.")

        # Refresh cached profile so the user sees updated data
        try:
            self.current_profile = self.api.get_profile()
        except Exception:
            pass
        self.pause()

    def update_ai_engine(self):
        """Configure primary and optional secondary Gemini API key method."""
        self.clear_screen()
        self.print_header("AI ENGINE SETUP")

        # Show current config
        try:
            data = self.api.get_ai_key_settings()
            current_primary = data.get("api_primary_mode") or None
            current_secondary = data.get("api_secondary_mode") or None
            has_key = data.get("has_custom_key", False)
            masked = data.get("masked_custom_key") or ""
            print(f"  Current primary  : {current_primary or '(not configured)'}")
            print(f"  Current secondary: {current_secondary or 'none'}")
            if has_key:
                print(f"  Custom key       : {masked}")
        except Exception:
            current_primary = None
            current_secondary = None
            has_key = False
            masked = ""
        print()

        print("  Choose PRIMARY method (used first):\n")
        print("  1. Launchway's shared keys (free, may be slower under high load)")
        print("  2. My own Gemini key      (private quota, faster)")
        print()
        primary_choice = input("  Primary [1/2]: ").strip()
        if primary_choice == '1':
            primary_mode = 'launchway'
        elif primary_choice == '2':
            primary_mode = 'custom'
        else:
            self.print_warning("No changes made.")
            self.pause()
            return

        print(f"\n  Choose SECONDARY / fallback method (optional):\n")
        print("  1. None (stop when primary quota runs out)")
        if primary_mode != 'launchway':
            print("  2. Launchway's shared keys (fallback to shared when your key runs out)")
        if primary_mode != 'custom':
            print("  2. My own Gemini key      (fallback to your key when shared runs out)")
        print()
        secondary_choice = input("  Secondary [1/2]: ").strip()

        secondary_mode = None
        if secondary_choice == '2':
            secondary_mode = 'launchway' if primary_mode == 'custom' else 'custom'

        custom_key = None
        if primary_mode == 'custom' or secondary_mode == 'custom':
            print()
            if has_key:
                print(f"  A key is already saved ({masked}). Press Enter to keep it.")
            else:
                print("  Get a free key at: https://aistudio.google.com/app/apikey")
            raw = input("  Gemini API Key (starts with AIza): ").strip()
            if raw:
                if not raw.startswith("AIza"):
                    self.print_error("That doesn't look like a valid Gemini API key (should start with 'AIza'). Try again.")
                    self.pause()
                    return
                custom_key = raw
            elif not has_key:
                self.print_error("A Gemini API key is required when using 'custom' mode.")
                self.pause()
                return

        print("\n  Saving AI Engine settings...", end="", flush=True)
        try:
            self.api.save_ai_key_settings(
                primary_mode=primary_mode,
                secondary_mode=secondary_mode,
                custom_api_key=custom_key,
            )
            print(" done.\n")
            self.print_success(
                f"AI Engine saved — primary: {primary_mode}"
                + (f", secondary: {secondary_mode}" if secondary_mode else ", no secondary")
            )
            print(f"\n  Fallback order: primary → secondary → retry primary → 60s cooldown → final retry.")
        except Exception as e:
            print(" failed.\n")
            self.print_error(f"Could not save: {e}")
        self.pause()

    def update_summary(self):
        self.clear_screen()
        self.print_header("SUMMARY / BIO")

        p = self.current_profile or {}
        current = p.get("summary", "")
        if current:
            print(f"  Current summary:\n  {current[:300]}\n")
        else:
            print("  No summary set.\n")

        print("  Enter your professional summary (2-4 sentences).")
        print("  This appears in cover letters and helps AI tailor your resume.\n")
        val = input("  Summary: ").strip()
        if not val:
            self.print_warning("No changes made.")
            self.pause()
            return
        if self._save_profile_changes({"summary": val}):
            self.print_success("Summary updated!")
        self.pause()

    def update_education(self):
        self.clear_screen()
        self.print_header("EDUCATION")

        p         = self.current_profile or {}
        education = list(p.get("education", []))

        print(f"  You have {len(education)} education entr{'y' if len(education)==1 else 'ies'}.\n")
        print("  1. Add new entry")
        print("  2. View existing entries")
        print("  3. Remove last entry")
        print("  4. Cancel\n")

        choice = self.get_input("Select option: ").strip()

        if choice == "1":
            print()
            degree     = _ask("Degree (e.g. Bachelor's, Master's)")
            institution = _ask("Institution / University")
            grad_year  = _ask("Graduation Year (YYYY or 'Expected YYYY')")
            gpa        = _ask("GPA (optional, e.g. 3.8/4.0)")
            courses_raw = input("  Relevant Courses (comma-separated, optional): ").strip()
            courses    = [c.strip() for c in courses_raw.split(",") if c.strip()] if courses_raw else []

            if not degree or not institution:
                self.print_error("Degree and institution are required.")
                self.pause()
                return

            education.append({
                "degree":          degree,
                "institution":     institution,
                "graduation_year": grad_year,
                "gpa":             gpa or None,
                "relevant_courses": courses,
            })
            if self._save_profile_changes({"education": education}):
                self.print_success("Education entry added!")

        elif choice == "2":
            if not education:
                self.print_warning("No entries yet.")
            else:
                print()
                for i, edu in enumerate(education, 1):
                    courses = _list_str(edu.get("relevant_courses", []))
                    print(f"  {i}. {edu.get('degree','')} — {edu.get('institution','')}")
                    print(f"     Year: {edu.get('graduation_year','')}  |  GPA: {edu.get('gpa') or '—'}")
                    if courses and courses != "—":
                        print(f"     Courses: {courses}")

        elif choice == "3":
            if not education:
                self.print_warning("No entries to remove.")
            else:
                removed = education.pop()
                if self._save_profile_changes({"education": education}):
                    self.print_success(f"Removed: {removed.get('degree','')} from {removed.get('institution','')}")

        self.pause()

    def update_work_experience(self):
        self.clear_screen()
        self.print_header("WORK EXPERIENCE")

        p        = self.current_profile or {}
        work_exp = list(p.get("work experience", p.get("work_experience", [])))

        print(f"  You have {len(work_exp)} work experience entr{'y' if len(work_exp)==1 else 'ies'}.\n")
        print("  1. Add new entry")
        print("  2. View existing entries")
        print("  3. Remove last entry")
        print("  4. Cancel\n")

        choice = self.get_input("Select option: ").strip()

        if choice == "1":
            print()
            title      = _ask("Job Title")
            company    = _ask("Company")
            start_date = _ask("Start Date (MM/YYYY)")
            end_date   = _ask("End Date (MM/YYYY or 'Present')")
            description = input("  Description / responsibilities: ").strip()
            achieve_raw = input("  Key achievements (comma-separated, optional): ").strip()
            achievements = [a.strip() for a in achieve_raw.split(",") if a.strip()] if achieve_raw else []

            if not title or not company:
                self.print_error("Job title and company are required.")
                self.pause()
                return

            work_exp.append({
                "title":        title,
                "company":      company,
                "start_date":   start_date,
                "end_date":     end_date,
                "description":  description,
                "achievements": achievements,
            })
            if self._save_profile_changes({"work experience": work_exp}):
                self.print_success("Work experience entry added!")

        elif choice == "2":
            if not work_exp:
                self.print_warning("No entries yet.")
            else:
                print()
                for i, exp in enumerate(work_exp, 1):
                    achievements = _list_str(exp.get("achievements", []))
                    print(f"  {i}. {exp.get('title','')} at {exp.get('company','')}")
                    print(f"     {exp.get('start_date','')} – {exp.get('end_date','Present')}")
                    if exp.get("description"):
                        print(f"     {exp['description'][:120]}")
                    if achievements and achievements != "—":
                        print(f"     Achievements: {achievements[:100]}")

        elif choice == "3":
            if not work_exp:
                self.print_warning("No entries to remove.")
            else:
                removed = work_exp.pop()
                if self._save_profile_changes({"work experience": work_exp}):
                    self.print_success(f"Removed: {removed.get('title','')} at {removed.get('company','')}")

        self.pause()

    def update_projects(self):
        self.clear_screen()
        self.print_header("PROJECTS")

        p        = self.current_profile or {}
        projects = list(p.get("projects", []))

        print(f"  You have {len(projects)} project entr{'y' if len(projects)==1 else 'ies'}.\n")
        print("  1. Add new project")
        print("  2. View existing projects")
        print("  3. Remove last project")
        print("  4. Cancel\n")

        choice = self.get_input("Select option: ").strip()

        if choice == "1":
            print()
            name        = _ask("Project Name")
            description = input("  Description: ").strip()
            tech_raw    = input("  Technologies used (comma-separated): ").strip()
            technologies = [t.strip() for t in tech_raw.split(",") if t.strip()] if tech_raw else []
            github_url  = _ask("GitHub URL (optional)")
            live_url    = _ask("Live / Demo URL (optional)")
            feats_raw   = input("  Key features (comma-separated, optional): ").strip()
            features    = [f.strip() for f in feats_raw.split(",") if f.strip()] if feats_raw else []

            if not name:
                self.print_error("Project name is required.")
                self.pause()
                return

            projects.append({
                "name":         name,
                "description":  description,
                "technologies": technologies,
                "github_url":   github_url or None,
                "live_url":     live_url or None,
                "features":     features,
            })
            if self._save_profile_changes({"projects": projects}):
                self.print_success("Project added!")

        elif choice == "2":
            if not projects:
                self.print_warning("No projects yet.")
            else:
                print()
                for i, proj in enumerate(projects, 1):
                    techs = _list_str(proj.get("technologies", []))
                    print(f"  {i}. {proj.get('name','')}")
                    print(f"     Tech: {techs}")
                    if proj.get("github_url"):
                        print(f"     GitHub: {proj['github_url']}")
                    if proj.get("live_url"):
                        print(f"     Live: {proj['live_url']}")

        elif choice == "3":
            if not projects:
                self.print_warning("No projects to remove.")
            else:
                removed = projects.pop()
                if self._save_profile_changes({"projects": projects}):
                    self.print_success(f"Removed: {removed.get('name','')}")

        self.pause()

    def update_skills(self):
        self.clear_screen()
        self.print_header("SKILLS")
        print("  Enter comma-separated values. Leave blank to keep current.\n")

        p      = self.current_profile or {}
        skills = dict(p.get("skills", {}))

        categories = [
            ("technical",             "Technical Skills (tools, platforms, etc.)"),
            ("programming_languages", "Programming Languages"),
            ("frameworks",            "Frameworks & Libraries"),
            ("tools",                 "DevOps / Build Tools"),
            ("soft_skills",           "Soft Skills"),
            ("languages",             "Spoken Languages"),
        ]

        changed = False
        for key, label in categories:
            new_list = _ask_list(label, skills.get(key, []))
            if new_list != skills.get(key, []):
                skills[key]  = new_list
                changed      = True

        if not changed:
            self.print_warning("No changes made.")
            self.pause()
            return
        if self._save_profile_changes({"skills": skills}):
            self.print_success("Skills updated!")
        self.pause()

    def update_cover_letter(self):
        self.clear_screen()
        self.print_header("COVER LETTER TEMPLATE")

        p = self.current_profile or {}
        current = p.get("cover_letter_template", "")
        if current:
            print(f"  Current template (first 300 chars):\n  {current[:300]}\n")
        else:
            print("  No cover letter template set.\n")

        print("  Enter your cover letter template below.")
        print("  You can use placeholders like {company}, {job_title}, {your_name}.\n")
        print("  (Paste multi-line text, then press Enter on an empty line to finish)\n")

        lines = []
        while True:
            line = input("  > ")
            if line == "" and lines and lines[-1] == "":
                break
            lines.append(line)

        template = "\n".join(lines).strip()
        if not template:
            self.print_warning("No changes made.")
            self.pause()
            return
        if self._save_profile_changes({"cover_letter_template": template}):
            self.print_success("Cover letter template saved!")
        self.pause()

    def update_job_preferences(self):
        self.clear_screen()
        self.print_header("JOB PREFERENCES")
        print("  Leave blank to keep the current value.\n")

        p = self.current_profile or {}

        relocate_current = _yn(p.get("willing to relocate", ""))
        relocate_input   = _ask(f"Willing to Relocate? (yes/no)", relocate_current)
        willing_to_relocate = None
        if relocate_input.lower() in ("yes", "y"):
            willing_to_relocate = True
        elif relocate_input.lower() in ("no", "n"):
            willing_to_relocate = False

        pref_locations = _ask_list(
            "Preferred Job Location(s) (e.g. Remote, New York NY, San Francisco CA)",
            p.get("preferred location", []),
        )

        changes = {}
        if willing_to_relocate is not None:
            changes["willing to relocate"] = willing_to_relocate
        if pref_locations:
            changes["preferred location"] = pref_locations

        if not changes:
            self.print_warning("No changes made.")
            self.pause()
            return
        if self._save_profile_changes(changes):
            self.print_success("Job preferences updated!")
        self.pause()

    def update_eeo_info(self):
        self.clear_screen()
        self.print_header("EEO / COMPLIANCE INFO")
        print("  This information is used to answer optional diversity and")
        print("  compliance questions on job applications.\n")
        print("  Leave blank to keep the current value.\n")

        p = self.current_profile or {}

        val = _ask("Visa Status (e.g. US Citizen, F-1, H-1B, PR, OPT, etc.)", p.get("visa status"))
        visa_status = val or None

        val = _ask("Visa Sponsorship Required? (yes/no/not required)", p.get("visa sponsorship"))
        visa_sponsorship = val or None

        val = _ask("Veteran Status (e.g. Not a veteran, Veteran, etc.)", p.get("veteran status"))
        veteran_status = val or None

        disabilities_list = _ask_list(
            "Disability Status (e.g. No disability, Blind, Deaf — comma-separated)",
            p.get("disabilities", []),
        )

        changes = {}
        if visa_status:          changes["visa status"]     = visa_status
        if visa_sponsorship:     changes["visa sponsorship"] = visa_sponsorship
        if veteran_status:       changes["veteran status"]  = veteran_status
        if disabilities_list:    changes["disabilities"]    = disabilities_list

        if not changes:
            self.print_warning("No changes made.")
            self.pause()
            return
        if self._save_profile_changes(changes):
            self.print_success("EEO / compliance info updated!")
        self.pause()

    def update_other_links(self):
        self.clear_screen()
        self.print_header("OTHER LINKS / PORTFOLIO")

        p           = self.current_profile or {}
        other_links = list(p.get("other links", []))

        print(f"  You have {len(other_links)} additional link(s).\n")
        print("  1. Add a link")
        print("  2. View existing links")
        print("  3. Remove last link")
        print("  4. Cancel\n")

        choice = self.get_input("Select option: ").strip()

        if choice == "1":
            print()
            label = _ask("Label (e.g. Portfolio, Dribbble, Personal Website)")
            url   = _ask("URL (https://...)")
            if not url:
                self.print_error("URL is required.")
                self.pause()
                return
            other_links.append({"label": label, "url": url})
            if self._save_profile_changes({"other links": other_links}):
                self.print_success("Link added!")

        elif choice == "2":
            if not other_links:
                self.print_warning("No links added yet.")
            else:
                print()
                for i, link in enumerate(other_links, 1):
                    lbl = link.get("label", "") if isinstance(link, dict) else ""
                    u   = link.get("url", link)  if isinstance(link, dict) else link
                    print(f"  {i}. {lbl+': ' if lbl else ''}{u}")

        elif choice == "3":
            if not other_links:
                self.print_warning("No links to remove.")
            else:
                removed = other_links.pop()
                label = removed.get("label", "") if isinstance(removed, dict) else ""
                if self._save_profile_changes({"other links": other_links}):
                    self.print_success(f"Removed: {label}")

        self.pause()
