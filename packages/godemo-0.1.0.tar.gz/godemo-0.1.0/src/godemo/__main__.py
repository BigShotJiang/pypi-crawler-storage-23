from godemo import run_cli

run_cli()
