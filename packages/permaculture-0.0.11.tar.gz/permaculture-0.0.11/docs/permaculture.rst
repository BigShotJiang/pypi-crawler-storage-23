permaculture package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   permaculture.locales
   permaculture.testing

Submodules
----------

permaculture.action module
--------------------------

.. automodule:: permaculture.action
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.cli module
-----------------------

.. automodule:: permaculture.cli
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.converter module
-----------------------------

.. automodule:: permaculture.converter
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.data module
------------------------

.. automodule:: permaculture.data
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.database module
----------------------------

.. automodule:: permaculture.database
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.de module
----------------------

.. automodule:: permaculture.de
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.google module
--------------------------

.. automodule:: permaculture.google
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.http module
------------------------

.. automodule:: permaculture.http
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.ingestor module
----------------------------

.. automodule:: permaculture.ingestor
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.ipinfo module
--------------------------

.. automodule:: permaculture.ipinfo
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.location module
----------------------------

.. automodule:: permaculture.location
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.logger module
--------------------------

.. automodule:: permaculture.logger
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.nc module
----------------------

.. automodule:: permaculture.nc
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.nlp module
-----------------------

.. automodule:: permaculture.nlp
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.nominatim module
-----------------------------

.. automodule:: permaculture.nominatim
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.pfaf module
------------------------

.. automodule:: permaculture.pfaf
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.priority module
----------------------------

.. automodule:: permaculture.priority
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.registry module
----------------------------

.. automodule:: permaculture.registry
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.runner module
--------------------------

.. automodule:: permaculture.runner
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.sdp module
-----------------------

.. automodule:: permaculture.sdp
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.serializer module
------------------------------

.. automodule:: permaculture.serializer
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.storage module
---------------------------

.. automodule:: permaculture.storage
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.unit module
------------------------

.. automodule:: permaculture.unit
   :members:
   :undoc-members:
   :show-inheritance:

permaculture.usda module
------------------------

.. automodule:: permaculture.usda
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: permaculture
   :members:
   :undoc-members:
   :show-inheritance:
