"""ControlGate - NIST RMF Cloud Security Hardening Agent."""

__version__ = "0.1.3"
