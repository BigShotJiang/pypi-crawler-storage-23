quiet = False
scrapeGoogle = False
usePandoc = False
uspto_api_key = None