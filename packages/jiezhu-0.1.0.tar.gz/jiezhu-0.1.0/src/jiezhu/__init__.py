from .hijack import install, uninstall, set_prefix, get_prefix

__all__ = ["install", "uninstall", "set_prefix", "get_prefix"]
