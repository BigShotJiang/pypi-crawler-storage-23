"""Ergodic Insurance Limits - Core Package.

This module provides the main entry point for the Ergodic Insurance Limits
package, exposing the key classes and functions for insurance simulation
and analysis using ergodic theory. The framework helps optimize insurance
retentions and limits for businesses by analyzing time-average outcomes
rather than traditional ensemble approaches.

Key Features:
    - Ergodic analysis of insurance decisions
    - Business optimization with insurance constraints
    - Monte Carlo simulation with trajectory storage
    - Insurance strategy backtesting and validation
    - Performance optimization and benchmarking
    - Comprehensive visualization and reporting

Top-level Exports:
    The top-level ``__all__`` exposes the essential classes for most workflows:

    - ``run_analysis`` / ``AnalysisResults`` — one-call analysis entry point
    - ``Config`` / ``ManufacturerConfig`` — configuration
    - ``InsuranceProgram`` / ``EnhancedInsuranceLayer`` — insurance modeling
    - ``Simulation`` / ``SimulationResults`` — running simulations

    All other classes remain importable from their respective submodules
    (see *Import Recipes* below) and via ``from ergodic_insurance import <name>``
    for backward compatibility.

Examples:
    One-call analysis (recommended starting point)::

        from ergodic_insurance import run_analysis

        results = run_analysis(
            initial_assets=10_000_000,
            loss_frequency=2.5,
            loss_severity_mean=1_000_000,
            deductible=500_000,
            limit=10_000_000,
            premium_rate=0.025,
        )
        print(results.summary())
        results.plot()

    Quick start with defaults (creates a $10M manufacturer, 50-year horizon)::

        from ergodic_insurance import Config

        config = Config()  # All defaults — just works

    From basic company info::

        from ergodic_insurance import Config

        config = Config.from_company(
            initial_assets=50_000_000,
            operating_margin=0.12,
        )

Import Recipes:
    Loss modeling::

        from ergodic_insurance.loss_distributions import (
            LossEvent, LossData, ManufacturingLossGenerator,
        )

    Business simulation::

        from ergodic_insurance.manufacturer import WidgetManufacturer
        from ergodic_insurance.monte_carlo import MonteCarloEngine, MonteCarloResults

    Ergodic & risk analysis::

        from ergodic_insurance.ergodic_analyzer import ErgodicAnalyzer
        from ergodic_insurance.ergodic_types import (
            ErgodicData, ErgodicAnalysisResults, ValidationResults,
            ScenarioComparison, BatchAnalysisResults,
        )
        from ergodic_insurance.scenario_analysis import (
            compare_scenarios, analyze_simulation_batch,
        )
        from ergodic_insurance.integrated_analysis import (
            integrate_loss_ergodic_analysis,
            validate_insurance_ergodic_impact,
        )
        from ergodic_insurance.risk_metrics import RiskMetrics
        from ergodic_insurance.ruin_probability import RuinProbabilityAnalyzer

    Insurance pricing::

        from ergodic_insurance.insurance_pricing import InsurancePricer, MarketCycle

    Business optimization::

        from ergodic_insurance.business_optimizer import (
            BusinessOptimizer, BusinessObjective, BusinessConstraints,
            OptimalStrategy, BusinessOptimizationResult,
        )

    Strategies & backtesting::

        from ergodic_insurance.strategy_backtester import (
            InsuranceStrategy, NoInsuranceStrategy, ConservativeFixedStrategy,
            AggressiveFixedStrategy, OptimizedStaticStrategy, AdaptiveStrategy,
            StrategyBacktester,
        )
        from ergodic_insurance.walk_forward_validator import WalkForwardValidator

    Sensitivity analysis::

        from ergodic_insurance.sensitivity import (
            SensitivityAnalyzer, SensitivityResult, TwoWaySensitivityResult,
        )

    Visualization::

        from ergodic_insurance.visualization import StyleManager, Theme, FigureFactory

    Validation & performance::

        from ergodic_insurance.validation_metrics import (
            ValidationMetrics, MetricCalculator, PerformanceTargets,
        )
        from ergodic_insurance.accuracy_validator import AccuracyValidator, ValidationResult
        from ergodic_insurance.performance_optimizer import (
            PerformanceOptimizer, OptimizationConfig,
        )

    Ledger (event sourcing)::

        from ergodic_insurance.ledger import (
            Ledger, LedgerEntry, TransactionType, EntryType, AccountType, AccountName,
        )

Note:
    This module uses lazy imports to avoid circular dependencies during
    test discovery. All classes listed in the *Import Recipes* above are
    also accessible as ``from ergodic_insurance import <name>`` for
    backward compatibility, but they are not included in ``__all__``
    and will not appear in IDE auto-complete at the top level.

Since:
    Version 0.4.0
"""

# pylint: disable=undefined-all-variable

try:
    from ergodic_insurance._version import __version__
except ImportError:
    from importlib.metadata import version as _get_version

    __version__ = _get_version("ergodic-insurance")

__all__ = [
    "__version__",
    # Quick-start factory
    "run_analysis",
    "AnalysisResults",
    # Configuration
    "Config",
    "ManufacturerConfig",
    # Insurance modeling
    "InsuranceProgram",
    "EnhancedInsuranceLayer",
    # Simulation
    "Simulation",
    "SimulationResults",
    "StrategyComparisonResult",
    # Standalone Monte Carlo orchestration (Issue #1301)
    "run_monte_carlo",
    "compare_strategies",
]


def __getattr__(name):
    """Lazy import modules to avoid circular dependencies during test discovery.

    This function implements PEP 562 for lazy loading of submodules, which helps
    reduce import time and avoid circular dependencies during test discovery.

    Args:
        name: The name of the attribute to retrieve.

    Returns:
        The requested module, class, or function.

    Raises:
        AttributeError: If the requested attribute does not exist in the module.

    Note:
        This function is called automatically by Python when accessing module
        attributes that are not yet loaded. It should not be called directly.
    """
    if name in ("run_analysis", "AnalysisResults"):
        from ._run_analysis import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            AnalysisResults,
            run_analysis,
        )

        return locals()[name]
    if name in ("InsurancePolicy", "InsuranceLayer"):
        from .insurance import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            InsuranceLayer,
            InsurancePolicy,
        )

        return locals()[name]
    if name in ("InsuranceProgram", "EnhancedInsuranceLayer"):
        from .insurance_program import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            EnhancedInsuranceLayer,
            InsuranceProgram,
        )

        return locals()[name]
    if name in ("InsurancePricer", "MarketCycle", "LayerPricer"):
        from .insurance_pricing import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            InsurancePricer,
            LayerPricer,
            MarketCycle,
        )

        return locals()[name]
    if name == "RiskMetrics":
        from .risk_metrics import RiskMetrics  # pylint: disable=import-outside-toplevel

        return RiskMetrics
    if name in ("MonteCarloEngine", "MonteCarloResults"):
        from .monte_carlo import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            MonteCarloEngine,
            MonteCarloResults,
        )

        return locals()[name]
    if name == "RuinProbabilityAnalyzer":
        from .ruin_probability import (  # pylint: disable=import-outside-toplevel
            RuinProbabilityAnalyzer,
        )

        return RuinProbabilityAnalyzer
    if name in (
        "BusinessObjective",
        "BusinessConstraints",
        "OptimalStrategy",
        "BusinessOptimizationResult",
        "BusinessOptimizer",
    ):
        from .business_optimizer import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            BusinessConstraints,
            BusinessObjective,
            BusinessOptimizationResult,
            BusinessOptimizer,
            OptimalStrategy,
        )

        return locals()[name]
    if name in ("LossEvent", "LossData", "ManufacturingLossGenerator"):
        from .loss_distributions import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            LossData,
            LossEvent,
            ManufacturingLossGenerator,
        )

        return locals()[name]
    if name in ("Config", "ManufacturerConfig"):
        from .config import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            Config,
            ManufacturerConfig,
        )

        return locals()[name]
    if name == "ErgodicAnalyzer":
        from .ergodic_analyzer import ErgodicAnalyzer  # pylint: disable=import-outside-toplevel

        return ErgodicAnalyzer
    if name in (
        "ScenarioComparison",
        "ScenarioMetrics",
        "ErgodicAdvantage",
        "BatchAnalysisResults",
        "TimeAverageStats",
        "EnsembleAverageStats",
        "ConvergenceStats",
        "SurvivalAnalysisStats",
        "ClaimResult",
        "LayerPayment",
    ):
        from .ergodic_types import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            BatchAnalysisResults,
            ClaimResult,
            ConvergenceStats,
            EnsembleAverageStats,
            ErgodicAdvantage,
            LayerPayment,
            ScenarioComparison,
            ScenarioMetrics,
            SurvivalAnalysisStats,
            TimeAverageStats,
        )

        return locals()[name]
    if name == "WidgetManufacturer":
        from .manufacturer import WidgetManufacturer  # pylint: disable=import-outside-toplevel

        return WidgetManufacturer
    if name in ("run_monte_carlo", "compare_strategies", "StrategyComparisonResult"):
        from ._compare_strategies import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            StrategyComparisonResult,
            compare_strategies,
            run_monte_carlo,
        )

        return locals()[name]
    if name in ("Simulation", "SimulationResults"):
        from .simulation import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            Simulation,
            SimulationResults,
        )

        return locals()[name]
    if name in ("ValidationMetrics", "MetricCalculator", "PerformanceTargets"):
        from .validation_metrics import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            MetricCalculator,
            PerformanceTargets,
            ValidationMetrics,
        )

        return locals()[name]
    if name in (
        "InsuranceStrategy",
        "NoInsuranceStrategy",
        "ConservativeFixedStrategy",
        "AggressiveFixedStrategy",
        "OptimizedStaticStrategy",
        "AdaptiveStrategy",
        "StrategyBacktester",
    ):
        from .strategy_backtester import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            AdaptiveStrategy,
            AggressiveFixedStrategy,
            ConservativeFixedStrategy,
            InsuranceStrategy,
            NoInsuranceStrategy,
            OptimizedStaticStrategy,
            StrategyBacktester,
        )

        return locals()[name]
    if name == "WalkForwardValidator":
        from .walk_forward_validator import (  # pylint: disable=import-outside-toplevel
            WalkForwardValidator,
        )

        return WalkForwardValidator
    if name in ("PerformanceOptimizer", "OptimizationConfig"):
        from .performance_optimizer import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            OptimizationConfig,
            PerformanceOptimizer,
        )

        return locals()[name]
    if name in ("AccuracyValidator", "ValidationResult"):
        from .accuracy_validator import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            AccuracyValidator,
            ValidationResult,
        )

        return locals()[name]
    if name in ("StyleManager", "Theme", "FigureFactory"):
        from .visualization import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            FigureFactory,
            StyleManager,
            Theme,
        )

        return locals()[name]
    if name in ("SensitivityAnalyzer", "SensitivityResult", "TwoWaySensitivityResult"):
        from .sensitivity import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            SensitivityAnalyzer,
            SensitivityResult,
            TwoWaySensitivityResult,
        )

        return locals()[name]
    if name in (
        "Ledger",
        "LedgerEntry",
        "TransactionType",
        "EntryType",
        "AccountType",
        "AccountName",
    ):
        from .ledger import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            AccountName,
            AccountType,
            EntryType,
            Ledger,
            LedgerEntry,
            TransactionType,
        )

        return locals()[name]
    if name in (
        "ErgodicInsuranceWarning",
        "ErgodicInsuranceDeprecationWarning",
        "ConfigurationWarning",
        "DataQualityWarning",
        "ExportWarning",
    ):
        from ._warnings import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            ConfigurationWarning,
            DataQualityWarning,
            ErgodicInsuranceDeprecationWarning,
            ErgodicInsuranceWarning,
            ExportWarning,
        )

        return locals()[name]
    if name in ("GPUSimulationParams", "run_gpu_simulation"):
        from .gpu_mc_engine import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            GPUSimulationParams,
            run_gpu_simulation,
        )

        return locals()[name]
    if name in (
        "get_array_module",
        "to_device",
        "to_numpy",
        "gpu_info",
        "is_gpu_available",
        "set_random_seed",
        "gpu_memory_pool",
        "gpu_device",
        "GPUConfig",
        "detect_colab_environment",
        "colab_setup_helper",
        "is_gpu_array",
    ):
        from .gpu_backend import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            GPUConfig,
            colab_setup_helper,
            detect_colab_environment,
            get_array_module,
            gpu_device,
            gpu_info,
            gpu_memory_pool,
            is_gpu_array,
            is_gpu_available,
            set_random_seed,
            to_device,
            to_numpy,
        )

        return locals()[name]
    if name in (
        "GPUBatchObjective",
        "GPUObjectiveWrapper",
        "GPUMultiStartScreener",
        "GPUDifferentialEvolution",
    ):
        from .gpu_objective import (  # pylint: disable=import-outside-toplevel,possibly-unused-variable
            GPUBatchObjective,
            GPUDifferentialEvolution,
            GPUMultiStartScreener,
            GPUObjectiveWrapper,
        )

        return locals()[name]
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
