"""Example scripts demonstrating ergodic insurance optimization features."""
