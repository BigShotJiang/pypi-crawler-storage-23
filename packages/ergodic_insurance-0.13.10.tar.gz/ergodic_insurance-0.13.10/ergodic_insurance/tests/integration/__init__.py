"""Integration tests for the ergodic insurance framework.

This package contains comprehensive integration tests that validate
cross-module interactions, data flow, and system-wide behavior.
"""
