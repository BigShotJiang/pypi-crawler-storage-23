"""Tests for Ergodic Insurance Limits package."""
