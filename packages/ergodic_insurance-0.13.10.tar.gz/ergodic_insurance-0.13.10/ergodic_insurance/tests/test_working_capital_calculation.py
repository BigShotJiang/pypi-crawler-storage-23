"""Test working capital component calculations using DSO/DIO/DPO ratios."""

import pytest

from ergodic_insurance.config import ManufacturerConfig, WorkingCapitalRatiosConfig
from ergodic_insurance.decimal_utils import to_decimal
from ergodic_insurance.manufacturer import WidgetManufacturer


class TestWorkingCapitalCalculation:
    """Test working capital calculations with industry-standard ratios."""

    @pytest.fixture
    def manufacturer(self):
        """Create a manufacturer with standard configuration."""
        config = ManufacturerConfig(
            initial_assets=10_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.10,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        return WidgetManufacturer(config)

    @pytest.fixture
    def wc_ratios_config(self):
        """Create working capital ratios configuration."""
        return WorkingCapitalRatiosConfig(
            days_sales_outstanding=45, days_inventory_outstanding=60, days_payable_outstanding=30
        )

    def test_accounts_receivable_calculation(self, manufacturer):
        """Test accounts receivable calculation using DSO."""
        revenue = 10_000_000
        dso = 45  # 45 days sales outstanding

        components = manufacturer.calculate_working_capital_components(revenue, dso=dso)

        # AR = Revenue * (DSO / 365)
        expected_ar = revenue * (dso / 365)
        assert float(components["accounts_receivable"]) == pytest.approx(expected_ar, rel=0.01)
        assert float(manufacturer.accounts_receivable) == pytest.approx(expected_ar, rel=0.01)

    def test_inventory_calculation(self, manufacturer):
        """Test inventory calculation using DIO."""
        revenue = 10_000_000
        dio = 60  # 60 days inventory outstanding

        # COGS = Revenue * (1 - operating_margin)
        cogs = revenue * (1 - manufacturer.base_operating_margin)

        components = manufacturer.calculate_working_capital_components(revenue, dio=dio)

        # Inventory = COGS * (DIO / 365)
        expected_inventory = cogs * (dio / 365)
        assert float(components["inventory"]) == pytest.approx(expected_inventory, rel=0.01)
        assert float(manufacturer.inventory) == pytest.approx(expected_inventory, rel=0.01)

    def test_accounts_payable_calculation(self, manufacturer):
        """Test accounts payable calculation using DPO."""
        revenue = 10_000_000
        dpo = 30  # 30 days payable outstanding

        # COGS = Revenue * (1 - operating_margin)
        cogs = revenue * (1 - manufacturer.base_operating_margin)

        components = manufacturer.calculate_working_capital_components(revenue, dpo=dpo)

        # AP = COGS * (DPO / 365)
        expected_ap = cogs * (dpo / 365)
        assert float(components["accounts_payable"]) == pytest.approx(expected_ap, rel=0.01)
        assert float(manufacturer.accounts_payable) == pytest.approx(expected_ap, rel=0.01)

    def test_net_working_capital_calculation(self, manufacturer):
        """Test net working capital calculation."""
        revenue = 10_000_000
        dso, dio, dpo = 45, 60, 30

        components = manufacturer.calculate_working_capital_components(
            revenue, dso=dso, dio=dio, dpo=dpo
        )

        # Net WC = AR + Inventory - AP
        expected_net_wc = (
            components["accounts_receivable"]
            + components["inventory"]
            - components["accounts_payable"]
        )
        assert float(components["net_working_capital"]) == pytest.approx(
            float(expected_net_wc), rel=0.01
        )

    def test_cash_conversion_cycle(self, manufacturer):
        """Test cash conversion cycle calculation."""
        revenue = 10_000_000
        dso, dio, dpo = 45, 60, 30

        components = manufacturer.calculate_working_capital_components(
            revenue, dso=dso, dio=dio, dpo=dpo
        )

        # CCC = DSO + DIO - DPO
        expected_ccc = dso + dio - dpo
        assert components["cash_conversion_cycle"] == expected_ccc

    def test_working_capital_with_different_margins(self, manufacturer):
        """Test that working capital adjusts with operating margin."""
        revenue = 10_000_000
        dio = 60
        dpo = 30

        # Test with different operating margins
        margins = [0.05, 0.10, 0.15]
        inventories = []
        payables = []

        for margin in margins:
            manufacturer.base_operating_margin = margin
            components = manufacturer.calculate_working_capital_components(
                revenue, dio=dio, dpo=dpo
            )
            inventories.append(components["inventory"])
            payables.append(components["accounts_payable"])

        # Higher margin means lower COGS, thus lower inventory and AP
        assert inventories[0] > inventories[1] > inventories[2]
        assert payables[0] > payables[1] > payables[2]

    def test_working_capital_integration_with_step(self, manufacturer):
        """Test that working capital assets are initialized to steady state and maintained during step() method."""
        # Initial state should have non-zero AR and Inventory (steady state)
        # AP starts at zero and builds up on first step
        # This prevents Year 1 distortion from working capital buildup
        initial_ar = manufacturer.accounts_receivable
        initial_inv = manufacturer.inventory
        initial_ap = manufacturer.accounts_payable

        assert initial_ar > 0, "AR should be initialized to steady state"
        assert initial_inv > 0, "Inventory should be initialized to steady state"
        assert initial_ap == 0, "AP starts at zero (will build up on first step)"

        # Run a step
        metrics = manufacturer.step()

        # After step, working capital components should all be positive
        assert manufacturer.accounts_receivable > 0
        assert manufacturer.inventory > 0
        assert manufacturer.accounts_payable > 0, "AP should build up on first step"

        # AR and Inventory changes should be modest (within 20% of initial values)
        # since we're starting from steady state
        assert abs(manufacturer.accounts_receivable - initial_ar) < initial_ar * to_decimal(0.2)
        assert abs(manufacturer.inventory - initial_inv) < initial_inv * to_decimal(0.2)

        # Components should be in metrics
        assert metrics["accounts_receivable"] > 0
        assert metrics["inventory"] > 0
        assert metrics["accounts_payable"] > 0

    def test_working_capital_persistence_across_steps(self, manufacturer):
        """Test that working capital components update correctly across multiple steps."""
        wc_components_history = []

        # Run multiple steps
        for _ in range(3):
            metrics = manufacturer.step()
            wc_components_history.append(
                {
                    "ar": metrics["accounts_receivable"],
                    "inv": metrics["inventory"],
                    "ap": metrics["accounts_payable"],
                }
            )

        # Components should exist and potentially change based on revenue
        for components in wc_components_history:
            assert components["ar"] > 0
            assert components["inv"] > 0
            assert components["ap"] > 0

    def test_working_capital_ratios_validation(self):
        """Test WorkingCapitalRatiosConfig validation."""
        # Valid configuration
        config = WorkingCapitalRatiosConfig(
            days_sales_outstanding=45, days_inventory_outstanding=60, days_payable_outstanding=30
        )
        assert config.days_sales_outstanding == 45
        assert config.days_inventory_outstanding == 60
        assert config.days_payable_outstanding == 30

        # Edge cases
        config_zero = WorkingCapitalRatiosConfig(
            days_sales_outstanding=0, days_inventory_outstanding=0, days_payable_outstanding=0
        )
        assert config_zero.days_sales_outstanding == 0

        # Maximum values
        config_max = WorkingCapitalRatiosConfig(
            days_sales_outstanding=365, days_inventory_outstanding=365, days_payable_outstanding=365
        )
        assert config_max.days_sales_outstanding == 365

    def test_cash_conversion_cycle_warnings(self, caplog):
        """Test that appropriate warnings are issued for unusual cash conversion cycles."""
        import logging

        # Negative cash conversion cycle (good but unusual)
        with caplog.at_level(logging.WARNING):
            config_negative = WorkingCapitalRatiosConfig(
                days_sales_outstanding=30,
                days_inventory_outstanding=20,
                days_payable_outstanding=60,
            )
        assert "Negative cash conversion cycle" in caplog.text

        caplog.clear()

        # Very long cash conversion cycle (problematic)
        with caplog.at_level(logging.WARNING):
            config_long = WorkingCapitalRatiosConfig(
                days_sales_outstanding=120,
                days_inventory_outstanding=150,
                days_payable_outstanding=30,
            )
        assert "Very long cash conversion cycle" in caplog.text

    def test_working_capital_impact_on_cash(self, manufacturer):
        """Test that working capital affects cash position and balance sheet balances."""
        initial_cash = manufacturer.cash

        # Calculate working capital components
        revenue = manufacturer.calculate_revenue()
        manufacturer.calculate_working_capital_components(revenue)

        # Run a step to update cash
        manufacturer.step()

        # Verify that the accounting equation holds: Assets = Liabilities + Equity
        assert float(manufacturer.total_assets) == pytest.approx(
            float(manufacturer.total_liabilities + manufacturer.equity), rel=0.01
        ), "Accounting equation should balance: Assets = Liabilities + Equity"

        # Verify that cash is correctly calculated as part of total assets
        # Total Assets = Cash + AR + Inventory + Prepaid + Net PPE + Restricted
        expected_cash = (
            manufacturer.total_assets
            - manufacturer.accounts_receivable
            - manufacturer.inventory
            - manufacturer.prepaid_insurance
            - manufacturer.net_ppe
            - manufacturer.restricted_assets
        )
        assert float(manufacturer.cash) == pytest.approx(float(expected_cash), rel=0.01)

    def test_working_capital_with_zero_revenue(self, manufacturer):
        """Test working capital calculation with zero revenue."""
        components = manufacturer.calculate_working_capital_components(revenue=0)

        # All components should be zero with zero revenue
        assert components["accounts_receivable"] == 0
        assert components["inventory"] == 0
        assert components["accounts_payable"] == 0
        assert components["net_working_capital"] == 0

    def test_working_capital_monthly_vs_annual(self, manufacturer):
        """Test working capital calculation consistency between monthly and annual steps."""
        # Annual step
        manufacturer.reset()
        annual_metrics = manufacturer.step(time_resolution="annual")
        annual_ar = annual_metrics["accounts_receivable"]

        # Monthly steps (12 months)
        manufacturer.reset()
        for month in range(12):
            monthly_metrics = manufacturer.step(time_resolution="monthly")

        # Final AR should be similar (based on annualized revenue)
        final_monthly_ar = monthly_metrics["accounts_receivable"]

        # Should be reasonably close
        assert annual_ar == pytest.approx(final_monthly_ar, rel=0.1)

    def test_no_year1_working_capital_distortion(self, manufacturer):
        """Test that Year 1 doesn't have unusual working capital buildup (Issue #223).

        This test verifies that initializing AR and Inventory to steady state
        eliminates the Year 1 distortion where a large working capital buildup
        artificially depresses ROE and cash flow.

        The key test is that AR and Inventory start at substantial levels
        (not building up from zero), preventing the Year 1 cash flow distortion.
        """
        # Store initial working capital values
        initial_ar = manufacturer.accounts_receivable
        initial_inv = manufacturer.inventory
        initial_ap = manufacturer.accounts_payable

        # Verify AR and Inventory start at steady state (the core fix for Issue #223)
        assert initial_ar > 0, "AR should start at steady state, not zero"
        assert initial_inv > 0, "Inventory should start at steady state, not zero"
        assert (
            initial_ap == 0
        ), "AP starts at zero (builds up on first step to maintain total_assets)"

        # Calculate expected initial values based on initialization formula
        initial_revenue = to_decimal(manufacturer.config.initial_assets) * to_decimal(
            manufacturer.config.asset_turnover_ratio
        )
        initial_cogs = initial_revenue * (
            to_decimal(1) - to_decimal(manufacturer.config.base_operating_margin)
        )
        expected_initial_ar = initial_revenue * to_decimal(45 / 365)
        expected_initial_inv = initial_cogs * to_decimal(60 / 365)

        # Verify AR and Inventory initialization matches expected steady-state values
        assert float(initial_ar) == pytest.approx(float(expected_initial_ar), rel=0.01)
        assert float(initial_inv) == pytest.approx(float(expected_initial_inv), rel=0.01)

        # Run first step
        year1_metrics = manufacturer.step()

        # Year 1 AR and Inventory should remain substantial (not building from zero)
        # The values should be in the same order of magnitude as initialization
        assert year1_metrics["accounts_receivable"] > initial_ar * to_decimal(
            0.5
        ), "Year 1 AR should remain substantial"
        assert year1_metrics["inventory"] > initial_inv * to_decimal(
            0.5
        ), "Year 1 inventory should remain substantial"

        # AP will build up on first step
        assert (
            year1_metrics["accounts_payable"] > 0
        ), "Year 1 AP should be positive after first step"

        # The key benefit: AR and Inventory are NOT building from zero in Year 1
        # If they were building from zero, Year 1 ending values would represent the full buildup
        # But with steady-state init, Year 1 only shows modest adjustments from initialization
        # This prevents the massive cash outflow that was depressing Year 1 ROE and cash flow
