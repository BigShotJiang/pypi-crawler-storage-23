"""Tests for configuration management system.

This module contains comprehensive tests for the Pydantic-based configuration
system, including validation, loading, overrides, and scenario management.
"""

from pathlib import Path
import warnings

from pydantic import ValidationError
import pytest
import yaml

from ergodic_insurance.config import (
    Config,
    DebtConfig,
    GrowthConfig,
    LoggingConfig,
    ManufacturerConfig,
    OutputConfig,
    SimulationConfig,
    WorkingCapitalConfig,
)
from ergodic_insurance.config_loader import ConfigLoader, load_config


class TestManufacturerConfig:
    """Test manufacturer configuration validation.

    Tests for the ManufacturerConfig Pydantic model including field
    validation, constraint checking, and warning generation.
    """

    def test_valid_manufacturer_config(self):
        """Test creating valid manufacturer config.

        Verifies that a properly configured ManufacturerConfig object
        can be created with valid parameters.
        """
        config = ManufacturerConfig(
            initial_assets=10_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.08,
            tax_rate=0.25,
            retention_ratio=1.0,
        )
        assert config.initial_assets == 10_000_000
        assert config.base_operating_margin == 0.08

    def test_invalid_initial_assets(self):
        """Test that negative initial assets are rejected.

        Ensures that Pydantic validation rejects negative initial
        asset values with appropriate error messages.
        """
        with pytest.raises(ValidationError) as exc_info:
            ManufacturerConfig(
                initial_assets=-1000,
                asset_turnover_ratio=1.0,
                base_operating_margin=0.08,
                tax_rate=0.25,
                retention_ratio=1.0,
            )
        assert "greater than 0" in str(exc_info.value)

    def test_invalid_tax_rate(self):
        """Test that invalid tax rates are rejected.

        Verifies that tax rates outside the valid range [0, 1]
        are properly rejected by validation.
        """
        with pytest.raises(ValidationError):
            ManufacturerConfig(
                initial_assets=10_000_000,
                asset_turnover_ratio=1.0,
                base_operating_margin=0.08,
                tax_rate=1.5,  # > 1
                retention_ratio=1.0,
            )

    def test_high_margin_warning(self, caplog):
        """Test warning for unusually high operating margin.

        Args:
            caplog: Pytest fixture for capturing log output.

        Tests that the custom validator issues warnings for
        unrealistically high operating margins.
        """
        import logging

        with caplog.at_level(logging.WARNING):
            config = ManufacturerConfig(
                initial_assets=10_000_000,
                asset_turnover_ratio=1.0,
                base_operating_margin=0.4,  # 40% - unusually high
                tax_rate=0.25,
                retention_ratio=1.0,
            )
        assert "unusually high" in caplog.text


class TestWorkingCapitalConfig:
    """Test working capital configuration.

    Tests for working capital percentage validation and
    constraint enforcement.
    """

    def test_valid_working_capital(self):
        """Test valid working capital configuration.

        Verifies that valid working capital percentages are
        accepted without error.
        """
        config = WorkingCapitalConfig(percent_of_sales=0.2)
        assert config.percent_of_sales == 0.2

    def test_excessive_working_capital(self):
        """Test that excessive working capital is rejected.

        Ensures that working capital percentages above 50% of sales
        are rejected as unrealistic.
        """
        with pytest.raises(ValidationError) as exc_info:
            WorkingCapitalConfig(percent_of_sales=0.6)  # 60% is too high
        assert "unrealistically high" in str(exc_info.value)


class TestGrowthConfig:
    """Test growth configuration.

    Tests for growth model validation including deterministic
    and stochastic growth parameter constraints.
    """

    def test_deterministic_growth(self):
        """Test deterministic growth configuration."""
        config = GrowthConfig(type="deterministic", annual_growth_rate=0.05, volatility=0.0)
        assert config.type == "deterministic"
        assert config.volatility == 0.0

    def test_stochastic_requires_volatility(self):
        """Test that stochastic growth requires volatility."""
        with pytest.raises(ValidationError) as exc_info:
            GrowthConfig(type="stochastic", annual_growth_rate=0.05, volatility=0.0)
        assert "requires non-zero volatility" in str(exc_info.value)

    def test_stochastic_with_volatility(self):
        """Test valid stochastic growth configuration."""
        config = GrowthConfig(type="stochastic", annual_growth_rate=0.05, volatility=0.1)
        assert config.volatility == 0.1


class TestSimulationConfig:
    """Test simulation configuration."""

    def test_valid_simulation_config(self):
        """Test valid simulation configuration."""
        config = SimulationConfig(
            time_resolution="annual",
            time_horizon_years=100,
            max_horizon_years=1000,
            random_seed=42,
        )
        assert config.time_horizon_years == 100
        assert config.random_seed == 42

    def test_horizon_exceeds_maximum(self):
        """Test that horizon cannot exceed maximum."""
        with pytest.raises(ValidationError) as exc_info:
            SimulationConfig(
                time_resolution="annual",
                time_horizon_years=2000,
                max_horizon_years=1000,
            )
        assert "less than or equal to 1000" in str(exc_info.value)

    def test_monthly_resolution(self):
        """Test monthly resolution configuration."""
        config = SimulationConfig(
            time_resolution="monthly", time_horizon_years=10, max_horizon_years=1000
        )
        assert config.time_resolution == "monthly"


class TestCompleteConfig:
    """Test complete configuration loading and validation."""

    @pytest.fixture
    def sample_config_dict(self):
        """Create a sample configuration dictionary.

        Returns:
            Dictionary containing valid configuration parameters
            for testing purposes.
        """
        return {
            "manufacturer": {
                "initial_assets": 10_000_000,
                "asset_turnover_ratio": 1.0,
                "base_operating_margin": 0.08,
                "tax_rate": 0.25,
                "retention_ratio": 1.0,
            },
            "working_capital": {"percent_of_sales": 0.2},
            "growth": {
                "type": "deterministic",
                "annual_growth_rate": 0.05,
                "volatility": 0.0,
            },
            "debt": {
                "interest_rate": 0.015,
                "max_leverage_ratio": 2.0,
                "minimum_cash_balance": 100_000,
            },
            "simulation": {
                "time_resolution": "annual",
                "time_horizon_years": 100,
                "max_horizon_years": 1000,
                "random_seed": 42,
            },
            "output": {
                "output_directory": "outputs",
                "file_format": "csv",
                "checkpoint_frequency": 10,
                "detailed_metrics": True,
            },
            "logging": {
                "enabled": True,
                "level": "INFO",
                "log_file": "simulation.log",
                "console_output": True,
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            },
        }

    def test_complete_config_from_dict(self, sample_config_dict):
        """Test creating complete config from dictionary.

        Args:
            sample_config_dict: Sample configuration dictionary fixture.

        Verifies that a complete Config object can be instantiated
        from a dictionary with all required sections.
        """
        config = Config(**sample_config_dict)
        assert config.manufacturer.initial_assets == 10_000_000
        assert config.simulation.time_horizon_years == 100
        assert config.output.file_format == "csv"

    def test_config_from_yaml(self, tmp_path, sample_config_dict):
        """Test loading config from YAML file.

        Args:
            tmp_path: Pytest temporary path fixture.
            sample_config_dict: Sample configuration dictionary fixture.

        Tests the Config.from_yaml class method for loading
        configuration from YAML files.
        """
        # Create temporary YAML file
        yaml_file = tmp_path / "test_config.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(sample_config_dict, f)

        # Load config
        config = Config.from_yaml(yaml_file)
        assert config.manufacturer.initial_assets == 10_000_000

    def test_config_override(self, sample_config_dict):
        """Test configuration override mechanism."""
        config = Config(**sample_config_dict)

        # Override using dot notation
        new_config = config.override(
            {
                "manufacturer.base_operating_margin": 0.1,
                "simulation.time_horizon_years": 200,
            }
        )

        assert new_config.manufacturer.base_operating_margin == 0.1
        assert new_config.simulation.time_horizon_years == 200
        # Original should be unchanged
        assert config.manufacturer.base_operating_margin == 0.08

    def test_config_override_invalid_section(self, sample_config_dict):
        """Test that override with invalid section raises ValueError."""
        config = Config(**sample_config_dict)

        with pytest.raises(ValueError, match="not a valid config section"):
            config.override({"nonexistent.field": 42})

    def test_config_override_invalid_field(self, sample_config_dict):
        """Test that override with invalid field raises ValueError."""
        config = Config(**sample_config_dict)

        with pytest.raises(ValueError, match="not a valid field"):
            config.override({"manufacturer.nonexistent_field": 42})

    def test_config_from_dict_with_base(self, sample_config_dict):
        """Test creating config from dict with base config."""
        base_config = Config(**sample_config_dict)

        # Override some values
        override_dict = {
            "manufacturer": {"base_operating_margin": 0.12},
            "growth": {"annual_growth_rate": 0.08},
        }

        new_config = Config.from_dict(override_dict, base_config=base_config)

        assert new_config.manufacturer.base_operating_margin == 0.12
        assert new_config.growth.annual_growth_rate == 0.08
        # Unchanged values should remain
        assert new_config.manufacturer.initial_assets == 10_000_000


@pytest.mark.filterwarnings("ignore:ConfigLoader is deprecated:DeprecationWarning")
class TestConfigLoader:
    """Test configuration loader functionality.

    Tests for the ConfigLoader class including caching, overrides,
    scenario loading, and configuration comparison features.
    """

    @pytest.fixture
    def config_loader(self, project_root):
        """Create config loader with test directory.

        Args:
            project_root: Project root directory fixture.

        Returns:
            ConfigLoader instance configured for testing.
        """
        return ConfigLoader(project_root / "data" / "parameters")

    def test_load_baseline(self, config_loader):
        """Test loading baseline configuration."""
        config = config_loader.load("baseline")
        assert config.manufacturer.initial_assets == 10_000_000
        assert config.manufacturer.base_operating_margin == 0.10

    def test_load_conservative(self, config_loader):
        """Test loading conservative configuration."""
        config = config_loader.load("conservative")
        assert config.growth.annual_growth_rate == 0.03  # Conservative growth
        assert config.manufacturer.base_operating_margin == 0.06  # Lower margin

    def test_load_optimistic(self, config_loader):
        """Test loading optimistic configuration."""
        config = config_loader.load("optimistic")
        assert config.growth.annual_growth_rate == 0.08  # Optimistic growth
        assert config.manufacturer.base_operating_margin == 0.12  # Higher margin

    def test_load_with_overrides(self, config_loader):
        """Test loading config with overrides."""
        config = config_loader.load(
            "baseline",
            overrides={
                "manufacturer": {"base_operating_margin": 0.10},
                "simulation.time_horizon_years": 200,
            },
        )
        assert config.manufacturer.base_operating_margin == 0.10
        assert config.simulation.time_horizon_years == 200

    def test_load_scenario(self, config_loader):
        """Test loading predefined scenarios."""
        baseline = config_loader.load_scenario("baseline")
        conservative = config_loader.load_scenario("conservative")
        optimistic = config_loader.load_scenario("optimistic")

        assert baseline.growth.annual_growth_rate == 0.12
        assert conservative.growth.annual_growth_rate == 0.03
        assert optimistic.growth.annual_growth_rate == 0.08

    def test_invalid_scenario(self, config_loader):
        """Test loading invalid scenario raises error."""
        with pytest.raises(ValueError) as exc_info:
            config_loader.load_scenario("invalid")
        assert "Unknown scenario" in str(exc_info.value)

    def test_compare_configs(self, config_loader):
        """Test comparing two configurations."""
        differences = config_loader.compare_configs("baseline", "conservative")

        # Check some expected differences
        assert "growth.annual_growth_rate" in differences
        assert differences["growth.annual_growth_rate"]["config1"] == 0.12
        assert differences["growth.annual_growth_rate"]["config2"] == 0.03

    def test_list_available_configs(self, config_loader):
        """Test listing available configurations."""
        configs = config_loader.list_available_configs()
        assert "baseline" in configs
        assert "conservative" in configs
        assert "optimistic" in configs

    def test_config_caching(self, config_loader):
        """Test that configs are cached after first load."""
        # Load twice
        config1 = config_loader.load("baseline")
        config2 = config_loader.load("baseline")

        # Should be the same cached object
        assert config1 is config2

        # Clear cache and load again
        config_loader.clear_cache()
        config3 = config_loader.load("baseline")

        # Should be different object after cache clear
        assert config1 is not config3


class TestConfigValidation:
    """Test configuration validation logic."""

    def test_output_path_property(self):
        """Test output path property."""
        config = OutputConfig(
            output_directory="test/outputs",
            file_format="csv",
            checkpoint_frequency=0,
            detailed_metrics=True,
        )
        assert isinstance(config.output_path, Path)
        assert config.output_path == Path("test/outputs")

    def test_logging_setup(self, tmp_path, monkeypatch):
        """Test logging configuration setup."""
        # Change to temp directory
        monkeypatch.chdir(tmp_path)

        config = Config(
            manufacturer=ManufacturerConfig(
                initial_assets=10_000_000,
                asset_turnover_ratio=1.0,
                base_operating_margin=0.08,
                tax_rate=0.25,
                retention_ratio=1.0,
            ),
            working_capital=WorkingCapitalConfig(percent_of_sales=0.2),
            growth=GrowthConfig(type="deterministic", annual_growth_rate=0.05, volatility=0.0),
            debt=DebtConfig(
                interest_rate=0.015,
                max_leverage_ratio=2.0,
                minimum_cash_balance=100_000,
            ),
            simulation=SimulationConfig(
                time_resolution="annual",
                time_horizon_years=100,
                max_horizon_years=1000,
                random_seed=42,
            ),
            output=OutputConfig(
                output_directory=str(tmp_path / "outputs"),
                file_format="csv",
                checkpoint_frequency=10,
                detailed_metrics=True,
            ),
            logging=LoggingConfig(
                enabled=True,
                level="INFO",
                log_file="test.log",
                console_output=True,
                format="%(message)s",
            ),
        )

        # Setup logging
        config.setup_logging()

        # Verify log file would be created in correct location
        expected_log = tmp_path / "outputs" / "test.log"
        assert expected_log.parent.exists()


@pytest.mark.filterwarnings("ignore:ConfigLoader is deprecated:DeprecationWarning")
class TestQuickLoad:
    """Test quick load convenience function.

    Tests for the convenience load_config function that provides
    a simplified interface to the configuration system.
    """

    def test_load_config_function(self, project_root):
        """Test the quick load_config function."""
        config = load_config("baseline")
        assert config.manufacturer.initial_assets == 10_000_000

    def test_load_config_with_overrides(self):
        """Test quick load with overrides."""
        config = load_config(
            "baseline",
            overrides={"manufacturer.base_operating_margin": 0.15},
        )
        assert config.manufacturer.base_operating_margin == 0.15


class TestConfigDefaults:
    """Test that Config() with no arguments creates a valid default config.

    Acceptance criteria from issue #369: Config() with no arguments creates
    a valid default configuration with sensible manufacturing defaults.
    """

    def test_config_no_args(self):
        """Config() with no arguments creates a valid configuration."""
        config = Config()
        assert config.manufacturer.initial_assets == 10_000_000
        assert config.manufacturer.asset_turnover_ratio == 0.8
        assert config.manufacturer.base_operating_margin == 0.08
        assert config.manufacturer.tax_rate == 0.25
        assert config.manufacturer.retention_ratio == 0.7
        assert config.working_capital.percent_of_sales == 0.20
        assert config.growth.annual_growth_rate == 0.05
        assert config.debt.interest_rate == 0.05
        assert config.debt.max_leverage_ratio == 2.0
        assert config.debt.minimum_cash_balance == 500_000
        assert config.simulation.time_horizon_years == 50
        assert config.output.output_directory == "outputs"
        assert config.logging.enabled is True

    def test_sub_config_defaults(self):
        """Each sub-config can be created with no arguments."""
        mfg = ManufacturerConfig()
        assert mfg.initial_assets == 10_000_000

        wc = WorkingCapitalConfig()
        assert wc.percent_of_sales == 0.20

        g = GrowthConfig()
        assert g.annual_growth_rate == 0.05

        d = DebtConfig()
        assert d.interest_rate == 0.05

        s = SimulationConfig()
        assert s.time_horizon_years == 50

    def test_partial_override(self):
        """Config accepts partial overrides, filling remaining from defaults."""
        config = Config(
            manufacturer=ManufacturerConfig(initial_assets=20_000_000),
        )
        assert config.manufacturer.initial_assets == 20_000_000
        # Other sub-configs should still have defaults
        assert config.working_capital.percent_of_sales == 0.20
        assert config.simulation.time_horizon_years == 50

    def test_backward_compatibility_explicit(self):
        """Existing explicit instantiation still works unchanged."""
        config = Config(
            manufacturer=ManufacturerConfig(
                initial_assets=10_000_000,
                asset_turnover_ratio=1.0,
                base_operating_margin=0.08,
                tax_rate=0.25,
                retention_ratio=1.0,
            ),
            working_capital=WorkingCapitalConfig(percent_of_sales=0.2),
            growth=GrowthConfig(annual_growth_rate=0.05),
            debt=DebtConfig(
                interest_rate=0.015,
                max_leverage_ratio=2.0,
                minimum_cash_balance=100_000,
            ),
            simulation=SimulationConfig(time_horizon_years=100),
            output=OutputConfig(),
            logging=LoggingConfig(),
        )
        assert config.manufacturer.initial_assets == 10_000_000
        assert config.manufacturer.retention_ratio == 1.0
        assert config.simulation.time_horizon_years == 100


class TestConfigFromCompany:
    """Test Config.from_company() factory method.

    Acceptance criteria from issue #369: Config.from_company(initial_assets=10e6)
    creates a reasonable config with one parameter.
    """

    def test_from_company_minimal(self):
        """Config.from_company(initial_assets=10e6) works with one param."""
        config = Config.from_company(initial_assets=10_000_000)
        assert config.manufacturer.initial_assets == 10_000_000
        assert config.manufacturer.base_operating_margin == 0.08
        assert config.manufacturer.asset_turnover_ratio == 0.8

    def test_from_company_no_args(self):
        """Config.from_company() uses all defaults."""
        config = Config.from_company()
        assert config.manufacturer.initial_assets == 10_000_000
        assert config.simulation.time_horizon_years == 50

    def test_from_company_custom_margin(self):
        """Custom operating margin is applied."""
        config = Config.from_company(
            initial_assets=50_000_000,
            operating_margin=0.15,
        )
        assert config.manufacturer.initial_assets == 50_000_000
        assert config.manufacturer.base_operating_margin == 0.15

    def test_from_company_service_industry(self):
        """Service industry gets appropriate defaults."""
        config = Config.from_company(
            initial_assets=5_000_000,
            industry="service",
        )
        assert config.manufacturer.asset_turnover_ratio == 1.2
        assert config.manufacturer.retention_ratio == 0.6
        assert config.working_capital.percent_of_sales == 0.15

    def test_from_company_retail_industry(self):
        """Retail industry gets appropriate defaults."""
        config = Config.from_company(
            initial_assets=5_000_000,
            industry="retail",
        )
        assert config.manufacturer.asset_turnover_ratio == 1.5
        assert config.working_capital.percent_of_sales == 0.25

    def test_from_company_unknown_industry_raises(self):
        """Unknown industry raises ValueError with supported values."""
        with pytest.raises(ValueError, match="Unsupported industry 'technology'") as exc_info:
            Config.from_company(
                initial_assets=10_000_000,
                industry="technology",
            )
        msg = str(exc_info.value)
        assert "manufacturing" in msg
        assert "retail" in msg
        assert "service" in msg
        assert "Use Config() with explicit sub-configs" in msg

    def test_from_company_unknown_industry_lists_all_supported(self):
        """Error message lists every supported industry value."""
        with pytest.raises(ValueError, match="Supported values:.*manufacturing.*retail.*service"):
            Config.from_company(industry="unknown")

    def test_from_company_override_kwargs(self):
        """Extra kwargs override industry defaults."""
        config = Config.from_company(
            initial_assets=10_000_000,
            asset_turnover_ratio=1.5,
            retention_ratio=0.9,
        )
        assert config.manufacturer.asset_turnover_ratio == 1.5
        assert config.manufacturer.retention_ratio == 0.9

    def test_from_company_time_horizon(self):
        """Custom time horizon is applied."""
        config = Config.from_company(time_horizon_years=100)
        assert config.simulation.time_horizon_years == 100

    def test_from_company_produces_valid_config(self):
        """Config from from_company() can be used with override()."""
        config = Config.from_company(initial_assets=20_000_000)
        new_config = config.override({"manufacturer.base_operating_margin": 0.12})
        assert new_config.manufacturer.base_operating_margin == 0.12
        assert new_config.manufacturer.initial_assets == 20_000_000
