"""Transport module for backend communication."""

from .connection import BackendConnection

__all__ = ['BackendConnection']
