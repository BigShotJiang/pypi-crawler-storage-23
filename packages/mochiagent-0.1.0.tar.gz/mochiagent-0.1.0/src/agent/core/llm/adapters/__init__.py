"""LLM Adapters"""

from .openai import OpenAIAdapter

__all__ = ["OpenAIAdapter"]
