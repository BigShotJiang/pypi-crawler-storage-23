"""System prompt build and injection utilities."""

from .injector import inject_system_prompt

__all__ = ["inject_system_prompt"]
