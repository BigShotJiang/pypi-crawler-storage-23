"""Prompt package placeholder after legacy prompt modules were removed."""

__all__: list[str] = []
