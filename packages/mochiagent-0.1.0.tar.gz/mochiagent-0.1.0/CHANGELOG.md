# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project follows [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added

- Placeholder for upcoming changes.

## [0.1.0] - 2026-02-25

### Added

- Initial public release of MochiAgent.
- Async event-driven agent runtime.
- Tool execution framework with policy and security guard.
- MCP integration support.
- Skills loading and session event streaming.
