# Code of Conduct

## Our Standards

We expect contributors to:

- Be respectful and constructive.
- Focus on technical discussion and evidence.
- Avoid harassment, discrimination, and personal attacks.

## Enforcement

Maintainers may remove comments, reject contributions, or restrict participation
for behavior that violates this policy.

## Reporting

Please report incidents to project maintainers through repository issue channels
or maintainer contact methods.
