## Summary

Describe what changed and why.

## Changes

- 

## Validation

- [ ] `uv run --extra dev ruff check .`
- [ ] `uv run --extra dev ruff format --check .`
- [ ] `uv run --extra dev pytest -q`

## Risk / Compatibility

- [ ] Breaking change
- [ ] Behavior change without breaking API
- [ ] Internal refactor only

If this can break users, describe migration steps.
