HOME_POSITION = [90, 90, 90, 60, 90]

SERVO_LIMITS = {
    "base": (0, 180),
    "shoulder": (0, 180),
    "elbow": (10, 180),
    "wrist": (0, 120),
    "gripper": (0, 180),
}

SMOOTHING_ALPHA = 0.3
SEND_INTERVAL = 0.05