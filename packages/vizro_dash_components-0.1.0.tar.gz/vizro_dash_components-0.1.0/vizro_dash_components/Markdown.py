# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component, _explicitize_args

ComponentSingleType = typing.Union[str, int, float, Component, None]
ComponentType = typing.Union[
    ComponentSingleType,
    typing.Sequence[ComponentSingleType],
]

NumberType = typing.Union[
    typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex
]


class Markdown(Component):
    """A Markdown component.


Keyword arguments:

- children (boolean | number | string | dict | list; optional):
    A markdown string (or array of strings) that adheres to the
    CommonMark spec.

- id (boolean | number | string | dict | list; optional):
    The ID of this component, used to identify dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (boolean | number | string | dict | list; optional):
    Class name of the container element.

- dangerously_allow_html (boolean | number | string | dict | list; optional):
    A boolean to control raw HTML escaping. Setting HTML from code is
    risky because it's easy to inadvertently expose your users to a
    cross-site scripting (XSS)
    (https://en.wikipedia.org/wiki/Cross-site_scripting) attack.

- dedent (boolean | number | string | dict | list; optional):
    Remove matching leading whitespace from all lines. Lines that are
    empty, or contain *only* whitespace, are ignored. Both spaces and
    tab characters are removed, but only if they match; we will not
    convert tabs to spaces or vice versa.

- highlight_config (boolean | number | string | dict | list; optional):
    Config options for syntax highlighting.

- link_target (boolean | number | string | dict | list; optional):
    A string for the target attribute to use on links (such as
    \"_blank\").

- mathjax (boolean | number | string | dict | list; optional):
    If True, loads mathjax v3 (tex-svg) into the page and use it in
    the markdown.

- setProps (boolean | number | string | dict | list; optional):
    Dash-assigned callback that gets fired when the value changes."""
    _children_props: typing.List[str] = []
    _base_nodes = ['children']
    _namespace = 'vizro_dash_components'
    _type = 'Markdown'


    def __init__(
        self,
        children: typing.Optional[ComponentType] = None,
        id: typing.Optional[typing.Union[str, dict]] = None,
        className: typing.Optional[typing.Any] = None,
        mathjax: typing.Optional[typing.Any] = None,
        dangerously_allow_html: typing.Optional[typing.Any] = None,
        link_target: typing.Optional[typing.Any] = None,
        dedent: typing.Optional[typing.Any] = None,
        highlight_config: typing.Optional[typing.Any] = None,
        style: typing.Optional[typing.Any] = None,
        **kwargs
    ):
        self._prop_names = ['children', 'id', 'className', 'dangerously_allow_html', 'dedent', 'highlight_config', 'link_target', 'mathjax', 'setProps', 'style']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'dangerously_allow_html', 'dedent', 'highlight_config', 'link_target', 'mathjax', 'setProps', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(Markdown, self).__init__(children=children, **args)

setattr(Markdown, "__init__", _explicitize_args(Markdown.__init__))
