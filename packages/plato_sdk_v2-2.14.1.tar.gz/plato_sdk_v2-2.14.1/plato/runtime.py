"""Runtime configuration for Plato agents and worlds.

Defines execution environments (Docker containers or Firecracker VMs)
and resource allocation for VMs.
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field


class VMResources(BaseModel):
    """VM resource allocation."""

    cpus: int = 1
    memory: int = 2048  # MB
    disk: int = 10240  # MB
    timeout: int = 1800
    """Job timeout in seconds. The VM is killed after this duration (default: 1800 = 30 min)."""


class DockerRuntimeConfig(BaseModel):
    """Docker runtime configuration."""

    type: Literal["docker"] = "docker"


class VMRuntimeConfig(BaseModel):
    """VM runtime configuration with resource allocation."""

    type: Literal["vm"] = "vm"
    vm: VMResources = Field(default_factory=VMResources)


# Discriminated union for runtime config
RuntimeConfig = Annotated[DockerRuntimeConfig | VMRuntimeConfig, Field(discriminator="type")]

# Runtime environment type
Runtime = Literal["docker", "vm"]
