import csv
import pathlib
import karrio.lib as lib
import karrio.core.units as units
import karrio.core.models as models


class LabelType(lib.Enum):
    LABEL_PDF = ("PDF", "LABEL_PDF")
    LABEL_PNG_100X150 = ("PNG", "LABEL_PNG_100X150")
    LABEL_PNG_100X175 = ("PNG", "LABEL_PNG_100X175")
    LABEL_PDF_100X175 = ("PDF", "LABEL_PDF_100X175")
    LABEL_PDF_100X150 = ("PDF", "LABEL_PDF_100X150")
    LABEL_ZPL_100X175 = ("ZPL", "LABEL_ZPL_100X175")
    LABEL_ZPL_100X150 = ("ZPL", "LABEL_ZPL_100X150")

    """ Unified Label type mapping """
    PDF = LABEL_PDF_100X150
    ZPL = LABEL_ZPL_100X150
    PNG = LABEL_PNG_100X150


class PackagingType(lib.StrEnum):
    """Carrier specific packaging type"""

    Bag = "Bag"
    Box = "Box"
    Carton = "Carton"
    Container = "Container"
    Crate = "Crate"
    Envelope = "Envelope"
    Pail = "Pail"
    Pallet = "Pallet"
    Satchel = "Satchel"
    Tube = "Tube"
    Custom = "Custom"

    """ Unified Packaging type mapping """
    envelope = Envelope
    pak = Satchel
    tube = Tube
    pallet = Pallet
    small_box = Box
    medium_box = Carton
    your_packaging = Custom


class ShippingService(lib.StrEnum):
    """Carrier specific services"""

    seko_ecommerce_standard_tracked = "eCommerce Standard Tracked"
    seko_ecommerce_express_tracked = "eCommerce Express Tracked"
    seko_domestic_express = "Domestic Express"
    seko_domestic_standard = "Domestic Standard"
    seko_domestic_large_parcel = "Domestic Large Parcel"


class ShippingOption(lib.Enum):
    """Carrier specific options"""

    seko_carrier = lib.OptionEnum("Carrier")
    seko_ship_type = lib.OptionEnum("ShipType")
    seko_package_id = lib.OptionEnum("PackageId")
    seko_destination_id = lib.OptionEnum("DestinationId")
    seko_product_category = lib.OptionEnum("ProductCategory")
    origin_instructions = lib.OptionEnum("OriginInstructions", meta=dict(category="INSTRUCTIONS"))
    destination_instructions = lib.OptionEnum("DestinationInstructions", meta=dict(category="INSTRUCTIONS"))
    seko_is_saturday_delivery = lib.OptionEnum("IsSaturdayDelivery", bool, meta=dict(category="DELIVERY_OPTIONS"))
    seko_is_signature_required = lib.OptionEnum("IsSignatureRequired", bool, meta=dict(category="SIGNATURE"))
    seko_send_tracking_email = lib.OptionEnum("SendTrackingEmail", bool, meta=dict(category="NOTIFICATION"))
    seko_amount_collected = lib.OptionEnum("AmountCollected", float)
    seko_tax_collected = lib.OptionEnum("TaxCollected", bool)
    seko_cod_amount = lib.OptionEnum("CODAmount", float, meta=dict(category="COD"))
    seko_reference_2 = lib.OptionEnum("Reference2")
    seko_reference_3 = lib.OptionEnum("Reference3")
    seko_invoice_data = lib.OptionEnum("InvoiceData")
    seko_origin_id = lib.OptionEnum("OriginId", int)
    seko_print_to_printer = lib.OptionEnum("PrintToPrinter", bool)
    seko_cif_value = lib.OptionEnum("CIFValue", float)
    seko_freight_value = lib.OptionEnum("FreightValue", float)
    seko_send_label = lib.OptionEnum("SendLabel", bool)
    seko_special_instructions = lib.OptionEnum("SpecialInstructions", meta=dict(category="INSTRUCTIONS"))
    seko_insurance_value = lib.OptionEnum("InsuranceValue", float, meta=dict(category="INSURANCE"))
    seko_estimated_delivery_date = lib.OptionEnum("EstimatedDeliveryDate")
    seko_dangerous_goods = lib.OptionEnum("DangerousGoods", bool, meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_additional_handling = lib.OptionEnum("DGAdditionalHandling", meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_hazchem_code = lib.OptionEnum("DGHazchemCode", meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_radioactive = lib.OptionEnum("DGRadioactive", bool, meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_cargo_aircraft_only = lib.OptionEnum("DGCargoAircraftOnly", bool, meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_limited_quantity = lib.OptionEnum("DGLimitedQuantity", bool, meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_total_quantity = lib.OptionEnum("DGTotalQuantity", int, meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_total_kg = lib.OptionEnum("DGTotalKg", float, meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_signoff_name = lib.OptionEnum("DGSignOffName", meta=dict(category="DANGEROUS_GOOD"))
    seko_dg_signoff_role = lib.OptionEnum("DGSignOffRole", meta=dict(category="DANGEROUS_GOOD"))

    """ Unified Option type mapping """
    saturday_delivery = seko_is_saturday_delivery
    signature_required = seko_is_signature_required
    email_notification = seko_send_tracking_email
    doc_files = lib.OptionEnum("doc_files", lib.to_dict, meta=dict(category="PAPERLESS"))
    doc_references = lib.OptionEnum("doc_references", lib.to_dict, meta=dict(category="PAPERLESS"))


def shipping_options_initializer(
    options: dict,
    package_options: units.ShippingOptions = None,
) -> units.ShippingOptions:
    """
    Apply default values to the given options.
    """

    if package_options is not None:
        options.update(package_options.content)

    def items_filter(key: str) -> bool:
        return key in ShippingOption  # type: ignore

    return units.ShippingOptions(options, ShippingOption, items_filter=items_filter)


class CustomsOption(lib.Enum):
    XIEORINumber = lib.OptionEnum("XIEORINumber")
    IOSSNUMBER = lib.OptionEnum("IOSSNUMBER")
    GBEORINUMBER = lib.OptionEnum("GBEORINUMBER")
    VOECNUMBER = lib.OptionEnum("VOECNUMBER")
    VATNUMBER = lib.OptionEnum("VATNUMBER")
    VENDORID = lib.OptionEnum("VENDORID")
    NZIRDNUMBER = lib.OptionEnum("NZIRDNUMBER")
    SWISS_VAT = lib.OptionEnum("SWISS VAT")
    OVRNUMBER = lib.OptionEnum("OVRNUMBER")
    EUEORINumber = lib.OptionEnum("EUEORINumber")
    EUVATNumber = lib.OptionEnum("EUVATNumber")
    LVGRegistrationNumber = lib.OptionEnum("LVGRegistrationNumber")

    """ Unified Customs Identifier type mapping """

    ioss = IOSSNUMBER
    eori_number = EUEORINumber
    vat_registration_number = VATNUMBER


class TrackingStatus(lib.Enum):
    pending = [
        "OP-1",  # Pending
        "OP-8",  # Manifest Received by Carrier
        "OP-9",  # Not yet received by carrier
        "OP-11",  # Received by carrier – no manifest sent
        "OP-12",  # Collection request received by carrier
    ]
    on_hold = [
        "OP-26",  # Held by carrier
        "OP-2",  # Held at Export Hub
        "OP-6",  # Customs held for inspection and clearance
        "OP-49",  # Held by Delivery Courier
        "OP-70",  # Parcel Blocked
        "OP-87",  # Aged Parcel - High Value Unpaid
        "OP-88",  # Held at Export Hub - Additional Payment Required
        "OP-41",  # Incorrect details declared by sender
        "OP-36",  # Delivery arranged with receiver
        "OP-39",  # Package repacked
        "OP-44",  # Selected for redelivery
        "OP-46",  # Customer Enquiry lodged
        "OP-52",  # Parcel Redirection Requested
        "OP-53",  # Parcel Redirected
        "OP-91",  # Parcel Blocked - Declared LIT
    ]
    delivered = [
        "OP-71",  # Delivered in part
        "OP-72",  # Delivered
        "OP-73",  # Delivered to neighbour
        "OP-74",  # Delivered - Authority to Leave / Safe Drop
        "OP-75",  # Delivered - Parcel Collected
        "OP-76",  # Delivered to locker/collection point
        "OP-77",  # Delivered to alternate delivery point
    ]
    in_transit = [
        "OP-18",  # In transit
        "OP-20",  # Sub-contractor update
        "OP-22",  # Received by Sub-contractor
        "OP-3",  # Processed through Export Hub
        "OP-4",  # International transit to destination country
        "OP-5",  # Customs cleared
        "OP-47",  # Processed through Sorting Facility
        "OP-50",  # Parcel arrived to courier processing facility
        "OP-51",  # Parcel departed courier processing facility
        "OP-78",  # Flight Arrived
        "OP-79",  # InTransit
        "OP-80",  # Reshipped
        "OP-81",  # Flight Departed
        "OP-7",  # Picked up by Delivery Courier
        "OP-10",  # Received by carrier
        "OP-14",  # Parcel received and accepted
        "OP-31",  # Information
        "OP-32",  # Information
        "OP-33",  # Collected from sender
        "OP-48",  # With Delivery Courier
        "OP-82",  # Inbound freight received
        "OP-83",  # Delivery exception
        "OP-84",  # Recipient not available
        "OP-89",  # Collected from sender
        "OP-54",  # Transferred to Collection Point
        "OP-56",  # Transferred to delivery provider
    ]
    delivery_failed = [
        "OP-24",  # Attempted Delivery - Receiver carded
        "OP-27",  # Attempted Delivery - Customer not known at address
        "OP-28",  # Attempted Delivery - Refused by customer
        "OP-29",  # Return to sender
        "OP-30",  # Non delivery
        "OP-37",  # Attempted Delivery - No access to receivers address
        "OP-38",  # Attempted Delivery - Customer Identification failed
        "OP-45",  # Attempted delivery
        "OP-55",  # Attempted Delivery - Returned to Sender
        "OP-15",  # Parcel lost
        "OP-17",  # Parcel Damaged
        "OP-23",  # Invalid / Insufficient Address
        "OP-86",  # Attempted delivery
        "OP-40",  # Package disposed
        "OP-92",  # Amazon RTS - DESTROY
        "OP-43",  # Not collected from store
    ]
    delivery_delayed = [
        "OP-16",  # Parcel Delayed
        "OP-13",  # Misdirected
        "OP-35",  # Mis sorted by carrier
    ]
    out_for_delivery = [
        "OP-21",  # Out for delivery
    ]
    ready_for_pickup = [
        "OP-19",  # Awaiting Collection
        "OP-25",  # Customer to collect from carrier
        "OP-42",  # Awaiting collection
    ]
    cancelled = [
        "OP-34",  # Cancelled
        "OP-67",  # RTS - Cancelled Order
    ]
    return_to_sender = [
        "OP-57",  # RTS Received  - Authorised Return
        "OP-58",  # RTS Received - Cancelled Order
        "OP-59",  # RTS Received - Card Left, Never Collected
        "OP-60",  # RTS - Fraudulant
        "OP-61",  # RTS Received - Invalid or Insufficient Address
        "OP-62",  # RTS Received- No Reason Given
        "OP-63",  # RTS - High Value Rejected
        "OP-64",  # RTS Received - Refused
        "OP-65",  # RTS Received - Unclaimed
        "OP-66",  # Return to Sender
        "OP-68",  # RTS Received
        "OP-69",  # RTS Received - Damaged Parcel
        "OP-85",  # RTS - In transit
        "OP-90",  # Return processed
        "OP-94",  # RTS consolidated
    ]


class TrackingIncidentReason(lib.Enum):
    """Maps SEKO exception codes to normalized TrackingIncidentReason."""

    # Carrier-caused issues
    carrier_damaged_parcel = ["OP-17", "OP-69"]  # Parcel Damaged, RTS - Damaged Parcel
    carrier_parcel_lost = ["OP-15"]  # Parcel lost
    carrier_sorting_error = ["OP-13", "OP-35"]  # Misdirected, Mis sorted by carrier
    carrier_delay = ["OP-16"]  # Parcel Delayed

    # Consignee-caused issues
    consignee_refused = ["OP-28", "OP-64"]  # Refused by customer, RTS - Refused
    consignee_not_home = ["OP-24", "OP-84"]  # Receiver carded, Recipient not available
    consignee_not_available = ["OP-59", "OP-65"]  # Card Left Never Collected, Unclaimed
    consignee_business_closed = ["OP-43"]  # Not collected from store
    consignee_incorrect_address = ["OP-23", "OP-27", "OP-41", "OP-61"]  # Invalid/Insufficient Address, Customer not known, Incorrect details, RTS - Invalid Address
    consignee_access_restricted = ["OP-37"]  # No access to receivers address
    consignee_identification_failed = ["OP-38"]  # Customer Identification failed

    # Customs-related issues
    customs_delay = ["OP-6"]  # Customs held for inspection and clearance

    # Payment/Delivery issues
    delivery_exception_hold = ["OP-26", "OP-49", "OP-87", "OP-88"]  # Held by carrier, Held by Delivery Courier, High Value Unpaid, Additional Payment Required
    delivery_exception_undeliverable = ["OP-30", "OP-70", "OP-91"]  # Non delivery, Parcel Blocked, Parcel Blocked - Declared LIT
    delivery_exception_cancelled = ["OP-34", "OP-60", "OP-67"]  # Cancelled, RTS - Fraudulent, RTS - Cancelled Order
    delivery_exception_high_value_rejected = ["OP-63"]  # RTS - High Value Rejected

    # Unknown/Other
    unknown = []


def load_services_from_csv() -> list:
    csv_path = pathlib.Path(__file__).resolve().parent / "services.csv"
    if not csv_path.exists():
        return []
    services_dict: dict[str, dict] = {}
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            service_code = row["service_code"]
            karrio_service_code = ShippingService.map(service_code).name_or_key
            if karrio_service_code not in services_dict:
                services_dict[karrio_service_code] = {
                    "service_name": row["service_name"],
                    "service_code": karrio_service_code,
                    "currency": row.get("currency", "USD"),
                    "min_weight": float(row["min_weight"]) if row.get("min_weight") else None,
                    "max_weight": float(row["max_weight"]) if row.get("max_weight") else None,
                    "max_length": float(row["max_length"]) if row.get("max_length") else None,
                    "max_width": float(row["max_width"]) if row.get("max_width") else None,
                    "max_height": float(row["max_height"]) if row.get("max_height") else None,
                    "weight_unit": "KG",
                    "dimension_unit": "CM",
                    "domicile": (row.get("domicile") or "").lower() == "true",
                    "international": True if (row.get("international") or "").lower() == "true" else None,
                    "zones": [],
                }
            country_codes = [c.strip() for c in row.get("country_codes", "").split(",") if c.strip()]
            zone = models.ServiceZone(
                label=row.get("zone_label", "Default Zone"),
                rate=float(row.get("rate", 0.0)),
                min_weight=float(row["min_weight"]) if row.get("min_weight") else None,
                max_weight=float(row["max_weight"]) if row.get("max_weight") else None,
                transit_days=int(row["transit_days"].split("-")[0]) if row.get("transit_days") and row["transit_days"].split("-")[0].isdigit() else None,
                country_codes=country_codes if country_codes else None,
            )
            services_dict[karrio_service_code]["zones"].append(zone)
    return [models.ServiceLevel(**service_data) for service_data in services_dict.values()]


DEFAULT_SERVICES = load_services_from_csv()
