# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["EmailSendParams"]


class EmailSendParams(TypedDict, total=False):
    body: Required[str]
    """Plain-text email body."""

    subject: Required[str]
    """Email subject line."""

    to: Required[SequenceNotStr[str]]
    """List of recipient email addresses."""

    bcc: SequenceNotStr[str]
    """List of BCC email addresses."""

    cc: SequenceNotStr[str]
    """List of CC email addresses."""

    from_name: Optional[str]
    """Display name for the sender. Defaults to "Village"."""
