# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village.types import EmailSendResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestEmail:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_send(self, client: Village) -> None:
        email = client.email.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_send_with_all_params(self, client: Village) -> None:
        email = client.email.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
            bcc=["dev@stainless.com"],
            cc=["dev@stainless.com"],
            from_name="from_name",
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_send(self, client: Village) -> None:
        response = client.email.with_raw_response.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = response.parse()
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_send(self, client: Village) -> None:
        with client.email.with_streaming_response.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = response.parse()
            assert_matches_type(EmailSendResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncEmail:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_send(self, async_client: AsyncVillage) -> None:
        email = await async_client.email.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_send_with_all_params(self, async_client: AsyncVillage) -> None:
        email = await async_client.email.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
            bcc=["dev@stainless.com"],
            cc=["dev@stainless.com"],
            from_name="from_name",
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_send(self, async_client: AsyncVillage) -> None:
        response = await async_client.email.with_raw_response.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = await response.parse()
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_send(self, async_client: AsyncVillage) -> None:
        async with async_client.email.with_streaming_response.send(
            body="body",
            subject="subject",
            to=["dev@stainless.com"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = await response.parse()
            assert_matches_type(EmailSendResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True
