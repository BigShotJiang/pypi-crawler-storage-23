# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village.types import CompanyLookupResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestCompany:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_lookup(self, client: Village) -> None:
        company = client.company.lookup(
            "AAPL:NASDAQ",
        )
        assert_matches_type(CompanyLookupResponse, company, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_lookup(self, client: Village) -> None:
        response = client.company.with_raw_response.lookup(
            "AAPL:NASDAQ",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        company = response.parse()
        assert_matches_type(CompanyLookupResponse, company, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_lookup(self, client: Village) -> None:
        with client.company.with_streaming_response.lookup(
            "AAPL:NASDAQ",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            company = response.parse()
            assert_matches_type(CompanyLookupResponse, company, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_lookup(self, client: Village) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `qualified_ticker` but received ''"):
            client.company.with_raw_response.lookup(
                "",
            )


class TestAsyncCompany:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_lookup(self, async_client: AsyncVillage) -> None:
        company = await async_client.company.lookup(
            "AAPL:NASDAQ",
        )
        assert_matches_type(CompanyLookupResponse, company, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_lookup(self, async_client: AsyncVillage) -> None:
        response = await async_client.company.with_raw_response.lookup(
            "AAPL:NASDAQ",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        company = await response.parse()
        assert_matches_type(CompanyLookupResponse, company, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_lookup(self, async_client: AsyncVillage) -> None:
        async with async_client.company.with_streaming_response.lookup(
            "AAPL:NASDAQ",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            company = await response.parse()
            assert_matches_type(CompanyLookupResponse, company, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_lookup(self, async_client: AsyncVillage) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `qualified_ticker` but received ''"):
            await async_client.company.with_raw_response.lookup(
                "",
            )
