"""Weight-based shuffling router completion provider using LiteLLM Router."""

import json
import time
import logging
from typing import Dict, Any, Optional, List
import traceback

from litellm import Router

from .base import CompletionProvider
from .config import config
from .logger import logger
from .exceptions import (
    CompletionError,
    APIKeyError,
    RateLimitError,
    ModelNotAvailableError,
    InvalidRequestError,
    LLMTimeoutError,
)

# Logical model name used across all router deployments
ROUTER_MODEL_NAME = "weighted-llm"


def _build_model_list() -> List[Dict[str, Any]]:
    """Build the model list for the LiteLLM Router.

    Deployments (in priority / weight order):
        1. OpenRouter – Grok          weight=5  (primary)
        2. OpenRouter – Gemini Flash  weight=3
        3. OpenAI – GPT-4.1           weight=2

    Returns:
        List of deployment dicts accepted by litellm.Router.

    Raises:
        APIKeyError: If no OpenRouter or OpenAI key is available.
    """
    model_list: List[Dict[str, Any]] = []

    if config.openrouter_api_key:
        # Primary: OpenRouter Grok (weight=5)
        model_list.append(
            {
                "model_name": ROUTER_MODEL_NAME,
                "litellm_params": {
                    "model": config.openrouter_grok_model,
                    "api_key": config.openrouter_api_key,
                    "timeout": config.openrouter_timeout,
                    "max_tokens": config.max_tokens,
                    "temperature": config.temperature,
                    "weight": 5,
                },
            }
        )

        # Secondary: OpenRouter Gemini Flash (weight=3)
        model_list.append(
            {
                "model_name": ROUTER_MODEL_NAME,
                "litellm_params": {
                    "model": config.openrouter_gemini_model,
                    "api_key": config.openrouter_api_key,
                    "timeout": config.openrouter_timeout,
                    "max_tokens": config.max_tokens,
                    "temperature": config.temperature,
                    "weight": 3,
                },
            }
        )

    if config.openai_api_key:
        # Tertiary: OpenAI GPT-4.1 (weight=2)
        model_list.append(
            {
                "model_name": ROUTER_MODEL_NAME,
                "litellm_params": {
                    "model": "gpt-4.1",
                    "api_key": config.openai_api_key,
                    "timeout": config.openai_timeout,
                    "max_tokens": config.max_tokens,
                    "temperature": config.temperature,
                    "weight": 2,
                },
            }
        )

    if not model_list:
        raise APIKeyError(
            "No API keys available for the weighted router. "
            "Set OPENROUTER_API_KEY and/or OPENAI_API_KEY."
        )

    return model_list


class WeightedRouterCompletion(CompletionProvider):
    """Weight-based shuffling router using LiteLLM's Router.

    Routing weights:
        - OpenRouter Grok:         weight=5  (~50% of traffic)
        - OpenRouter Gemini Flash: weight=3  (~30% of traffic)
        - OpenAI GPT-4.1:          weight=2  (~20% of traffic)

    The ``simple-shuffle`` strategy (LiteLLM default) respects the ``weight``
    field while also handling cooldowns and retries transparently.
    """

    def __init__(self) -> None:
        """Initialize the weighted router."""
        model_list = _build_model_list()

        self._router = Router(
            model_list=model_list,
            routing_strategy="simple-shuffle",
            num_retries=2,
            retry_after=1,
        )

        deployment_summary = [
            f"{d['litellm_params']['model']} (weight={d['litellm_params']['weight']})"
            for d in model_list
        ]
        logger.info(
            f"Initialized WeightedRouterCompletion with deployments: {deployment_summary}"
        )

    # ------------------------------------------------------------------
    # Sync completion
    # ------------------------------------------------------------------

    def complete(
        self, prompt: str, system_prompt: Optional[str] = None, **kwargs: Any
    ) -> str:
        """Generate a text completion via the weighted router.

        Args:
            prompt: User prompt.
            system_prompt: Optional system instructions.
            **kwargs: Extra parameters forwarded to LiteLLM.

        Returns:
            The generated text.

        Raises:
            CompletionError: If the router exhausts all deployments.
        """
        try:
            start_time = time.time()
            messages = self._create_messages(prompt, system_prompt)

            response = self._router.completion(
                model=ROUTER_MODEL_NAME,
                messages=messages,
                drop_params=True,
                **kwargs,
            )

            completion_text: str = response.choices[0].message.content
            duration = time.time() - start_time
            logger.info(f"WeightedRouter completion successful ({duration:.2f}s)")
            return completion_text

        except Exception as e:
            logger.error(f"WeightedRouter completion failed: {str(e)}")
            logger.error(traceback.format_exc())
            raise CompletionError(f"WeightedRouter completion failed: {str(e)}") from e

    # ------------------------------------------------------------------
    # Async completion
    # ------------------------------------------------------------------

    async def acomplete(
        self, prompt: str, system_prompt: Optional[str] = None, **kwargs: Any
    ) -> str:
        """Asynchronously generate a text completion via the weighted router.

        Args:
            prompt: User prompt.
            system_prompt: Optional system instructions.
            **kwargs: Extra parameters forwarded to LiteLLM.

        Returns:
            The generated text.

        Raises:
            CompletionError: If the router exhausts all deployments.
        """
        try:
            start_time = time.time()
            messages = self._create_messages(prompt, system_prompt)

            response = await self._router.acompletion(
                model=ROUTER_MODEL_NAME,
                messages=messages,
                drop_params=True,
                **kwargs,
            )

            completion_text: str = response.choices[0].message.content
            duration = time.time() - start_time
            logger.info(f"WeightedRouter async completion successful ({duration:.2f}s)")
            return completion_text

        except Exception as e:
            logger.error(f"WeightedRouter async completion failed: {str(e)}")
            logger.error(traceback.format_exc())
            raise CompletionError(f"WeightedRouter async completion failed: {str(e)}") from e

    # ------------------------------------------------------------------
    # Sync JSON completion
    # ------------------------------------------------------------------

    def complete_with_json(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        json_schema: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Generate a JSON completion via the weighted router.

        Args:
            prompt: User prompt.
            system_prompt: Optional system instructions.
            json_schema: Optional JSON schema for structured output.
            **kwargs: Extra parameters forwarded to LiteLLM.

        Returns:
            Parsed JSON dict.

        Raises:
            CompletionError: On failure or invalid JSON response.
        """
        json_system_prompt = (
            "You must respond with valid JSON only, no other text. "
            "Ensure the response can be parsed as JSON."
        )
        if system_prompt:
            json_system_prompt = f"{system_prompt}\n\n{json_system_prompt}"

        if json_schema:
            kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "json_data_generation",
                    "schema": json_schema,
                    "strict": False,
                },
            }

        try:
            result = self.complete(prompt, json_system_prompt, **kwargs)
            return self._parse_json_response(result)
        except CompletionError:
            raise
        except Exception as e:
            raise CompletionError(f"Error getting JSON completion: {str(e)}") from e

    # ------------------------------------------------------------------
    # Async JSON completion
    # ------------------------------------------------------------------

    async def acomplete_with_json(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        json_schema: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Asynchronously generate a JSON completion via the weighted router.

        Args:
            prompt: User prompt.
            system_prompt: Optional system instructions.
            json_schema: Optional JSON schema for structured output.
            **kwargs: Extra parameters forwarded to LiteLLM.

        Returns:
            Parsed JSON dict.

        Raises:
            CompletionError: On failure or invalid JSON response.
        """
        json_system_prompt = (
            "You must respond with valid JSON only, no other text. "
            "Ensure the response can be parsed as JSON."
        )
        if system_prompt:
            json_system_prompt = f"{system_prompt}\n\n{json_system_prompt}"

        if json_schema:
            kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "json_data_generation",
                    "schema": json_schema,
                    "strict": False,
                },
            }

        try:
            result = await self.acomplete(prompt, json_system_prompt, **kwargs)
            return self._parse_json_response(result)
        except CompletionError:
            raise
        except Exception as e:
            raise CompletionError(f"Error getting async JSON completion: {str(e)}") from e

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _create_messages(
        self, prompt: str, system_prompt: Optional[str] = None
    ) -> List[Dict[str, str]]:
        """Build the messages list for the LLM API."""
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        return messages

    def _parse_json_response(self, result: str) -> Dict[str, Any]:
        """Extract and parse JSON from a raw completion string."""
        if "```json" in result:
            try:
                json_content = result.split("```json")[1].split("```")[0].strip()
                return json.loads(json_content)
            except (IndexError, json.JSONDecodeError):
                pass

        try:
            return json.loads(result)
        except json.JSONDecodeError as e:
            error_msg = f"Failed to parse response as JSON: {str(e)}\nResponse: {result}"
            logger.error(error_msg)
            raise CompletionError(error_msg) from e
