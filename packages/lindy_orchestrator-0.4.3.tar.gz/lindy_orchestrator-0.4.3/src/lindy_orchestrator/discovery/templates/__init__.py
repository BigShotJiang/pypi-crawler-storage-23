"""Artifact generation templates."""
