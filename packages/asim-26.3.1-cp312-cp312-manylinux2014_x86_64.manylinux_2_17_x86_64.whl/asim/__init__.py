import logging

from .common import *
from .version import __version__

log = logging.getLogger(__name__)

log.info(f"asim version {__version__}")
