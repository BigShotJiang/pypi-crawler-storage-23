from typing import Any, Self


class Var(dict):
    _type = ""

    def __init__(
        self,
        label: str,
        alias: str = None,
        group: str = "default",
        minmax: tuple[Any, Any] = (None, None),
        union: str = None,
        mono: int = 1,
        ref: str = None,
        enable=True,
    ):
        """
        Args:
            label (str): pandas column name
            alias (str): display name in chart, default to label
            group (str): group name, multiple sub-systems joint
            minmax (tuple[Any, Any]): control min max
            mono (int): gradient constraint direction, only for Vu
                1 -> monotonically increasing (default): penalize negative gradients
               -1 -> monotonically decreasing: penalize positive gradients
                0 -> unconstrained: no gradient penalty is applied
            union (str): union unit, normalize
            ref str: data ref
                group/label
            enable (bool): available
                Vu -> control
                Vc -> null
                Vx -> constraint
        """
        super().__init__()
        self.type = self._type
        self._typeIdx = None
        #
        self.group = group
        self.label = label
        self.alias = alias or label
        self.simMin, self.simMax = None, None
        self.optMin, self.optMax = minmax
        self.union = union or label
        self.ref = ref
        self.mono = mono
        self.enable = enable

    def __setattr__(self, key, value):
        object.__setattr__(self, key, value)
        if not key.startswith("_"):
            self[key] = value

    def isControl(self):
        return self.type == "u"

    @property
    def optId(self):
        if self.label == "ts":
            return "ts"

        return f"{self.group}/{self._type}{self._typeIdx}"

    def setTypeIdx(self, idx):
        self._typeIdx = idx

    def load(self, sim_min, sim_max) -> Self:
        self.simMin = sim_min
        self.simMax = sim_max
        return self


class Vt(Var):
    """
    ts 时序变量 单位 s
    """

    _type = "t"


class Vu(Var):
    """
    control 控制变量
    """

    _type = "u"


class Vc(Var):
    """
    const 不可控变量 可选
    tvp - 时变参数 (Time-Varying Parameters)
        含义：在预测时域内随时间变化的已知参数
        特点：每个时间步可以有不同的值，但变化轨迹是预先知道的
    使用场景：
        已知的未来扰动
        已知的参考轨迹
        可预测的外部变化
    """

    _type = "c"


class Vx(Var):
    """
    x 状态变量
    """

    _type = "x"


class Vz(Var):
    """
    代数状态 (Algebraic Variables)
        含义：代数状态是必须满足代数方程约束的变量
        特点：不随时间动态变化，但受代数约束
    使用场景：
        稳态关系（如平衡方程）
        中间计算变量
        需要满足代数约束的状态
    """

    _type = "z"


class Vp(Var):
    """
    时不变参数 (Time-Invariant Parameters)
        含义：在预测时域内保持不变的参数
        特点：在MPC求解期间保持不变，但在不同MPC步之间可以改变
    使用场景：
        系统参数（如质量、长度等）
        设定点（setpoints）
        不随时间变化的操作条件
    """

    _type = "p"
