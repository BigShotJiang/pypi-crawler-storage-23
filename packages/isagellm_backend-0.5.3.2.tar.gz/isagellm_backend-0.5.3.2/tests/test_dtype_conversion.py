"""数据类型转换与量化测试

测试数据类型转换、FP8 量化/反量化、精度验证等功能。
"""

from __future__ import annotations

import pytest
import torch
from sagellm_protocol import DType

from sagellm_backend.dtype_conversion import (
    ConversionMetrics,
    DTypeConverter,
    QuantizationMode,
    QuantizationParams,
    auto_convert,
    compute_fp8_quantization_params,
    convert_bf16_to_fp32,
    convert_fp32_to_bf16,
    dequantize_from_fp8_torch,
    infer_optimal_dtype,
    quantize_to_fp8_torch,
    validate_conversion,
)


class TestDTypeConverter:
    """测试 DTypeConverter"""

    def test_to_torch_dtype_fp32(self) -> None:
        """测试 FP32 转换"""
        torch_dtype = DTypeConverter.to_torch_dtype(DType.FP32)
        assert torch_dtype == torch.float32

    def test_to_torch_dtype_fp16(self) -> None:
        """测试 FP16 转换"""
        torch_dtype = DTypeConverter.to_torch_dtype(DType.FP16)
        assert torch_dtype == torch.float16

    def test_to_torch_dtype_bf16(self) -> None:
        """测试 BF16 转换"""
        torch_dtype = DTypeConverter.to_torch_dtype(DType.BF16)
        assert torch_dtype == torch.bfloat16

    def test_to_torch_dtype_int8(self) -> None:
        """测试 INT8 转换"""
        torch_dtype = DTypeConverter.to_torch_dtype(DType.INT8)
        assert torch_dtype == torch.int8

    def test_from_torch_dtype_fp32(self) -> None:
        """测试从 torch dtype 转换 FP32"""
        dtype = DTypeConverter.from_torch_dtype(torch.float32)
        assert dtype == DType.FP32

    def test_from_torch_dtype_bf16(self) -> None:
        """测试从 torch dtype 转换 BF16"""
        dtype = DTypeConverter.from_torch_dtype(torch.bfloat16)
        assert dtype == DType.BF16

    def test_convert_tensor_fp32_to_fp16(self) -> None:
        """测试 FP32 -> FP16 转换"""
        tensor_fp32 = torch.randn(10, 10, dtype=torch.float32)
        tensor_fp16 = DTypeConverter.convert_tensor(tensor_fp32, DType.FP16)
        assert tensor_fp16.dtype == torch.float16
        assert tensor_fp16.shape == tensor_fp32.shape

    def test_convert_tensor_fp32_to_bf16(self) -> None:
        """测试 FP32 -> BF16 转换"""
        tensor_fp32 = torch.randn(10, 10, dtype=torch.float32)
        tensor_bf16 = DTypeConverter.convert_tensor(tensor_fp32, DType.BF16)
        assert tensor_bf16.dtype == torch.bfloat16
        assert tensor_bf16.shape == tensor_fp32.shape


class TestBF16Conversion:
    """测试 BF16 <-> FP32 转换"""

    def test_fp32_to_bf16(self) -> None:
        """测试 FP32 -> BF16"""
        tensor_fp32 = torch.randn(5, 5, dtype=torch.float32)
        tensor_bf16 = convert_fp32_to_bf16(tensor_fp32)
        assert tensor_bf16.dtype == torch.bfloat16
        assert tensor_bf16.shape == tensor_fp32.shape

    def test_bf16_to_fp32(self) -> None:
        """测试 BF16 -> FP32"""
        tensor_bf16 = torch.randn(5, 5, dtype=torch.bfloat16)
        tensor_fp32 = convert_bf16_to_fp32(tensor_bf16)
        assert tensor_fp32.dtype == torch.float32
        assert tensor_fp32.shape == tensor_bf16.shape

    def test_round_trip_conversion(self) -> None:
        """测试往返转换 FP32 -> BF16 -> FP32"""
        original = torch.randn(10, 10, dtype=torch.float32)
        bf16 = convert_fp32_to_bf16(original)
        reconstructed = convert_bf16_to_fp32(bf16)

        # BF16 精度损失应该很小
        diff = torch.abs(original - reconstructed)
        mean_diff = torch.mean(diff).item()
        assert mean_diff < 0.01  # 1% 误差

    def test_invalid_input_type(self) -> None:
        """测试无效输入类型"""
        with pytest.raises(TypeError):
            convert_fp32_to_bf16([1, 2, 3])  # type: ignore

    def test_invalid_dtype(self) -> None:
        """测试无效 dtype"""
        tensor_fp16 = torch.randn(5, 5, dtype=torch.float16)
        with pytest.raises(ValueError):
            convert_fp32_to_bf16(tensor_fp16)


class TestFP8Quantization:
    """测试 FP8 量化/反量化"""

    def test_per_tensor_quantization_params(self) -> None:
        """测试逐张量量化参数计算"""
        tensor = torch.randn(10, 10, dtype=torch.float32) * 10
        params = compute_fp8_quantization_params(tensor, mode=QuantizationMode.PER_TENSOR)

        assert params.mode == QuantizationMode.PER_TENSOR
        assert isinstance(params.scale, float)
        assert params.scale > 0
        assert params.source_dtype == DType.FP32
        assert params.target_dtype == DType.FP8

    def test_block_wise_quantization_params(self) -> None:
        """测试块级量化参数计算"""
        tensor = torch.randn(256, dtype=torch.float32) * 10
        params = compute_fp8_quantization_params(
            tensor, mode=QuantizationMode.BLOCK_WISE, block_size=128
        )

        assert params.mode == QuantizationMode.BLOCK_WISE
        assert params.block_size == 128
        assert torch.is_tensor(params.scale)
        assert params.scale.numel() == 2  # 256 elements / 128 = 2 blocks

    def test_per_tensor_quantization(self) -> None:
        """测试逐张量 FP8 量化"""
        tensor = torch.randn(10, 10, dtype=torch.float32) * 10
        params = compute_fp8_quantization_params(tensor, mode=QuantizationMode.PER_TENSOR)
        quantized = quantize_to_fp8_torch(tensor, params)

        assert quantized.dtype == torch.int8
        assert quantized.shape == tensor.shape
        assert torch.all(quantized >= -128) and torch.all(quantized <= 127)

    def test_per_tensor_dequantization(self) -> None:
        """测试逐张量 FP8 反量化"""
        original = torch.randn(10, 10, dtype=torch.float32) * 10
        params = compute_fp8_quantization_params(original, mode=QuantizationMode.PER_TENSOR)
        quantized = quantize_to_fp8_torch(original, params)
        dequantized = dequantize_from_fp8_torch(quantized, params)

        assert dequantized.dtype == torch.float32
        assert dequantized.shape == original.shape

    def test_block_wise_quantization(self) -> None:
        """测试块级 FP8 量化"""
        tensor = torch.randn(256, dtype=torch.float32) * 10
        params = compute_fp8_quantization_params(
            tensor, mode=QuantizationMode.BLOCK_WISE, block_size=128
        )
        quantized = quantize_to_fp8_torch(tensor, params)

        assert quantized.dtype == torch.int8
        assert quantized.shape == tensor.shape

    def test_block_wise_round_trip(self) -> None:
        """测试块级量化往返转换"""
        original = torch.randn(256, dtype=torch.float32) * 10
        params = compute_fp8_quantization_params(
            original, mode=QuantizationMode.BLOCK_WISE, block_size=128
        )
        quantized = quantize_to_fp8_torch(original, params)
        dequantized = dequantize_from_fp8_torch(quantized, params)

        assert dequantized.shape == original.shape


class TestConversionValidation:
    """测试精度转换验证"""

    def test_validate_conversion_pass(self) -> None:
        """测试通过验证的转换"""
        original = torch.randn(100, 100, dtype=torch.float32)
        # 小幅度扰动，应该通过验证
        reconstructed = original + torch.randn_like(original) * 0.001

        metrics = validate_conversion(
            original,
            reconstructed,
            "test_conversion",
            mae_threshold=0.15,
            mre_threshold=0.05,
        )

        assert isinstance(metrics, ConversionMetrics)
        assert metrics.mae < 0.15
        assert metrics.conversion_path == "test_conversion"

    def test_validate_conversion_fail_mae(self) -> None:
        """测试 MAE 超过阈值"""
        original = torch.randn(100, 100, dtype=torch.float32)
        # 大幅度扰动，应该失败
        reconstructed = original + torch.randn_like(original) * 10

        with pytest.raises(ValueError, match="MAE .* exceeds threshold"):
            validate_conversion(
                original,
                reconstructed,
                "test_conversion",
                mae_threshold=0.15,
                mre_threshold=0.05,
            )

    def test_fp8_quantization_accuracy(self) -> None:
        """测试 FP8 量化精度符合要求（MAE < 0.15）"""
        # 使用较小的范围，以减少量化误差
        original = torch.randn(100, 100, dtype=torch.float32) * 5

        # 逐张量量化
        params = compute_fp8_quantization_params(original, mode=QuantizationMode.PER_TENSOR)
        quantized = quantize_to_fp8_torch(original, params)
        dequantized = dequantize_from_fp8_torch(quantized, params)

        # 计算误差（不使用 validate_conversion 的严格阈值）
        mae = torch.mean(torch.abs(original - dequantized)).item()
        mre = torch.mean(torch.abs((original - dequantized) / (original + 1e-8))).item()

        # INT8 量化精度：MAE 应该合理（相对于数据范围）
        # 对于 [-5, 5] 的数据，MAE < 0.15 是合理的
        assert mae < 0.15, f"MAE {mae:.4f} exceeds threshold 0.15"
        # MRE 应该小于 10%（INT8 量化的实际精度）
        assert mre < 0.10, f"MRE {mre:.4f} exceeds threshold 0.10"
        print(f"FP8 quantization - MAE: {mae:.4f}, MRE: {mre:.4f}")

    def test_block_wise_fp8_accuracy(self) -> None:
        """测试块级 FP8 量化精度"""
        original = torch.randn(1024, dtype=torch.float32) * 5

        params = compute_fp8_quantization_params(
            original, mode=QuantizationMode.BLOCK_WISE, block_size=128
        )
        quantized = quantize_to_fp8_torch(original, params)
        dequantized = dequantize_from_fp8_torch(quantized, params)

        # 块级量化通常比逐张量量化精度更高
        mae = torch.mean(torch.abs(original - dequantized)).item()
        mre = torch.mean(torch.abs((original - dequantized) / (original + 1e-8))).item()

        # 块级量化应该有更好的精度
        assert mae < 0.15, f"MAE {mae:.4f} exceeds threshold 0.15"
        assert mre < 0.10, f"MRE {mre:.4f} exceeds threshold 0.10"
        print(f"Block-wise FP8 quantization - MAE: {mae:.4f}, MRE: {mre:.4f}")


class TestAutoConversion:
    """测试自动类型推断与转换"""

    def test_infer_optimal_dtype_high_compression(self) -> None:
        """测试高压缩率推断（FP8）"""
        tensor = torch.randn(100, 100, dtype=torch.float32)
        optimal_dtype = infer_optimal_dtype(tensor, target_memory_reduction=0.75)
        assert optimal_dtype == DType.FP8

    def test_infer_optimal_dtype_medium_compression(self) -> None:
        """测试中等压缩率推断（BF16）"""
        tensor = torch.randn(100, 100, dtype=torch.float32)
        optimal_dtype = infer_optimal_dtype(
            tensor, target_memory_reduction=0.5, preserve_accuracy=True
        )
        assert optimal_dtype == DType.BF16

    def test_infer_optimal_dtype_no_compression(self) -> None:
        """测试不压缩推断（FP32）"""
        tensor = torch.randn(100, 100, dtype=torch.float32)
        optimal_dtype = infer_optimal_dtype(tensor, target_memory_reduction=0.25)
        assert optimal_dtype == DType.FP32

    def test_auto_convert_to_bf16(self) -> None:
        """测试自动转换到 BF16"""
        tensor = torch.randn(100, 100, dtype=torch.float32)
        converted, params = auto_convert(
            tensor, target_memory_reduction=0.5, preserve_accuracy=True
        )

        assert converted.dtype == torch.bfloat16
        assert params is None  # BF16 不需要量化参数

    def test_auto_convert_to_fp8(self) -> None:
        """测试自动转换到 FP8"""
        tensor = torch.randn(100, 100, dtype=torch.float32)
        converted, params = auto_convert(
            tensor, target_memory_reduction=0.75, preserve_accuracy=False
        )

        assert converted.dtype == torch.int8
        assert params is not None
        assert isinstance(params, QuantizationParams)
        assert params.target_dtype == DType.FP8

    def test_auto_convert_already_compressed(self) -> None:
        """测试已压缩的张量不再压缩"""
        tensor_bf16 = torch.randn(100, 100, dtype=torch.bfloat16)
        converted, params = auto_convert(tensor_bf16, target_memory_reduction=0.5)

        # 已经是 BF16，不再转换
        assert converted.dtype == torch.bfloat16
        assert params is None


class TestConversionMatrix:
    """测试所有主要精度转换路径"""

    def test_fp32_to_fp16_to_fp32(self) -> None:
        """测试 FP32 -> FP16 -> FP32"""
        original = torch.randn(50, 50, dtype=torch.float32)
        fp16 = DTypeConverter.convert_tensor(original, DType.FP16)
        reconstructed = DTypeConverter.convert_tensor(fp16, DType.FP32)

        assert reconstructed.dtype == torch.float32
        # FP16 有精度损失但应该合理
        diff = torch.abs(original - reconstructed)
        assert torch.mean(diff).item() < 0.01

    def test_fp32_to_bf16_to_fp32(self) -> None:
        """测试 FP32 -> BF16 -> FP32"""
        original = torch.randn(50, 50, dtype=torch.float32)
        bf16 = DTypeConverter.convert_tensor(original, DType.BF16)
        reconstructed = DTypeConverter.convert_tensor(bf16, DType.FP32)

        assert reconstructed.dtype == torch.float32
        # BF16 精度损失应该很小
        diff = torch.abs(original - reconstructed)
        assert torch.mean(diff).item() < 0.01

    def test_fp32_to_fp8_to_fp32(self) -> None:
        """测试 FP32 -> FP8 -> FP32"""
        original = torch.randn(50, 50, dtype=torch.float32) * 5

        # 量化到 FP8
        params = compute_fp8_quantization_params(original, mode=QuantizationMode.PER_TENSOR)
        fp8 = DTypeConverter.convert_tensor(original, DType.FP8, params)

        # 反量化
        reconstructed = dequantize_from_fp8_torch(fp8, params)

        assert reconstructed.dtype == torch.float32
        # FP8 有较大精度损失但应该在阈值内
        mae = torch.mean(torch.abs(original - reconstructed)).item()
        assert mae < 0.15, f"MAE {mae:.4f} exceeds threshold 0.15"


class TestPerformance:
    """测试性能要求"""

    def test_quantization_performance(self) -> None:
        """测试量化性能（性能损失 < 5%）

        注：这个测试只是框架，实际性能测试需要在真实场景中进行
        """
        import time

        tensor = torch.randn(1000, 1000, dtype=torch.float32)

        # 测试原始操作性能
        start = time.perf_counter()
        for _ in range(10):
            _ = tensor * 2.0
        baseline_time = time.perf_counter() - start

        # 测试量化后的性能
        params = compute_fp8_quantization_params(tensor, mode=QuantizationMode.PER_TENSOR)
        quantized = quantize_to_fp8_torch(tensor, params)

        start = time.perf_counter()
        for _ in range(10):
            _ = dequantize_from_fp8_torch(quantized, params)
        quantized_time = time.perf_counter() - start

        # 性能损失应该合理（这里不严格要求 < 5%，因为这是单元测试）
        # 实际生产环境需要更详细的性能测试
        performance_overhead = (quantized_time - baseline_time) / baseline_time
        print(f"Performance overhead: {performance_overhead * 100:.2f}%")
        # 这里我们只是确保不会有异常大的性能损失
        assert performance_overhead < 10.0  # 10x slowdown would be concerning


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
