"""Allow  python -m tinygnn.tests  to invoke the smoke-test runner."""
from .smoke_tests import _main

_main()
