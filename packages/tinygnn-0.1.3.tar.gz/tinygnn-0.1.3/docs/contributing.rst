Contributing
============

See the `CONTRIBUTING.md <https://github.com/JaiAnshSB/TinyGNN/blob/main/CONTRIBUTING.md>`_
file for contribution guidelines.
