"""murl - A curl-like CLI tool for Model Context Protocol (MCP) servers."""

__version__ = "0.3.0"
