# Tasks: phase0-pixi-env

## Test-first tasks
- [x] Add static test for pixi config presence and key tasks.

## Implementation tasks
- [x] Add `pixi.toml`.
- [x] Update README with pixi instructions.
