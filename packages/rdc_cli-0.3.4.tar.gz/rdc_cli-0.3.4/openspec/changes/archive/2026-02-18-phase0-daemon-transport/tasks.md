# Tasks: phase0-daemon-transport

## Test-first tasks
- [x] Add daemon transport tests for command flow.
- [x] Add token rejection test.

## Implementation tasks
- [x] Add daemon server module.
- [x] Add daemon client request helper.
- [x] Update session commands to start/connect daemon.
- [x] Update README.
