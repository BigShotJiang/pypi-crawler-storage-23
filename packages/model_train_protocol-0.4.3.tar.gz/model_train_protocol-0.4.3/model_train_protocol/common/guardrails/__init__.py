"""
Instruction classes for the Model Train Protocol package.
"""

from .Guardrail import Guardrail

__all__ = [
    "Guardrail"
]
