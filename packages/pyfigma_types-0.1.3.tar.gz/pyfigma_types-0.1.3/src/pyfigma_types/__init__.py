from __future__ import annotations

from pyfigma_types.__version__ import __version__


__all__ = ["__version__"]
