from __future__ import annotations

from typing import Any

from pydantic import BeforeValidator
from pydantic_core import PydanticUseDefault


def default_if_none(value: Any) -> Any:  # noqa: ANN401
    if value is None:
        raise PydanticUseDefault

    return value


DefaultIfNone = BeforeValidator(default_if_none)
