from __future__ import annotations

from importlib.metadata import version as _metadata_version


__version__ = _metadata_version("pyfigma-types")
