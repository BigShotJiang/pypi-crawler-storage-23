from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import Field

from pyfigma_types._models import BaseModel

from .property_types import (
    RGBA,
    ArcData,
    BlendMode,
    ComponentProperty,
    ComponentPropertyDefinition,
    ConnectorEndpoint,
    ConnectorLineType,
    ConnectorTextBackground,
    DevStatus,
    EasingType,
    Effect,
    ExportSetting,
    FlowStartingPoint,
    Interaction,
    LayoutConstraint,
    LayoutGrid,
    MaskType,
    Measurement,
    Overrides,
    Paint,
    PaintOverride,
    Path,
    PrototypeDevice,
    Rectangle,
    ShapeType,
    StrokeWeights,
    TextPathTypeStyle,
    Transform,
    TypeStyle,
    VariableAlias,
    Vector,
)


class IsLayerTrait(BaseModel):
    id: str
    """A string uniquely identifying this node within the document."""

    name: str
    """The name given to the node by the user in the tool."""

    visible: bool = True
    """Whether or not the node is visible on the canvas."""

    locked: bool = False
    """If True, layer is locked and cannot be edited."""

    is_fixed: Annotated[bool, Field(deprecated=True)] = False
    """Whether the layer is fixed while the parent is scrolling."""

    scroll_behavior: Literal["SCROLLS", "FIXED", "STICKY_SCROLLS"]
    """How layer should be treated when the frame is resized."""

    rotation: float = 0.0
    """The rotation of the node, if not 0."""

    component_property_references: dict[str, str] | None = None
    """A mapping of a layer's property to component property name of component properties
    attached to this node. The component property name can be used to look up more
    information on the corresponding component's or component set's
    `component_property_definitions`.
    """

    plugin_data: Any | None = None
    """
    Data written by plugins that is visible only to the plugin that wrote it. Requires the
    `plugin_data` to include the ID of the plugin.
    """

    shared_plugin_data: Any | None = None
    """
    Data written by plugins that is visible to all plugins. Requires the `plugin_data`
    parameter to include the string "shared".
    """

    bound_variables: IsLayerTraitBoundVariables | None = None
    """
    A mapping of field to the variables applied to this field.
    """

    explicit_variable_modes: dict[str, str] | None = None
    """
    A mapping of variable collection ID to mode ID representing explicitly set modes
    for this node.
    """


class IsLayerTraitBoundVariables(BaseModel):
    size: IsLayerTraitBoundVariablesSize | None = None
    individual_stroke_weights: (
        IsLayerTraitBoundVariablesIndividualStrokeWeights | None
    ) = None
    characters: VariableAlias | None = None
    item_spacing: VariableAlias | None = None
    padding_left: VariableAlias | None = None
    padding_right: VariableAlias | None = None
    padding_top: VariableAlias | None = None
    padding_bottom: VariableAlias | None = None
    visible: VariableAlias | None = None
    top_left_radius: VariableAlias | None = None
    top_right_radius: VariableAlias | None = None
    bottom_left_radius: VariableAlias | None = None
    bottom_right_radius: VariableAlias | None = None
    min_width: VariableAlias | None = None
    max_width: VariableAlias | None = None
    min_height: VariableAlias | None = None
    max_height: VariableAlias | None = None
    counter_axis_spacing: VariableAlias | None = None
    opacity: VariableAlias | None = None
    font_family: list[VariableAlias] | None = None
    font_size: list[VariableAlias] | None = None
    font_style: list[VariableAlias] | None = None
    font_weight: list[VariableAlias] | None = None
    letter_spacing: list[VariableAlias] | None = None
    line_height: list[VariableAlias] | None = None
    paragraph_spacing: list[VariableAlias] | None = None
    paragraph_indent: list[VariableAlias] | None = None
    fills: list[VariableAlias] | None = None
    strokes: list[VariableAlias] | None = None
    component_properties: dict[str, VariableAlias] | None = None
    text_range_fills: list[VariableAlias] | None = None
    effects: list[VariableAlias] | None = None
    layout_grids: list[VariableAlias] | None = None
    rectangle_corner_radii: IsLayerTraitBoundVariablesRectangleCornerRadii | None = None


class IsLayerTraitBoundVariablesSize(BaseModel):
    x: VariableAlias | None = None
    y: VariableAlias | None = None


class IsLayerTraitBoundVariablesIndividualStrokeWeights(BaseModel):
    top: VariableAlias | None = None
    bottom: VariableAlias | None = None
    left: VariableAlias | None = None
    right: VariableAlias | None = None


class IsLayerTraitBoundVariablesRectangleCornerRadii(BaseModel):
    rectangle_top_left_corner_radius: Annotated[
        VariableAlias | None,
        Field(validation_alias="RECTANGLE_TOP_LEFT_CORNER_RADIUS"),
    ] = None
    rectangle_top_right_corner_radius: Annotated[
        VariableAlias | None,
        Field(validation_alias="RECTANGLE_TOP_RIGHT_CORNER_RADIUS"),
    ] = None
    rectangle_bottom_left_corner_radius: Annotated[
        VariableAlias | None,
        Field(validation_alias="RECTANGLE_BOTTOM_LEFT_CORNER_RADIUS"),
    ] = None
    rectangle_bottom_right_corner_radius: Annotated[
        VariableAlias | None,
        Field(validation_alias="RECTANGLE_BOTTOM_RIGHT_CORNER_RADIUS"),
    ] = None


class HasChildrenTrait(BaseModel):
    children: list[SubcanvasNode]
    """
    An array of nodes that are direct children of this node.
    """


class HasLayoutTrait(BaseModel):
    absolute_bounding_box: Rectangle | None
    """
    Bounding box of the node in absolute space coordinates.
    """

    absolute_render_bounds: Rectangle | None
    """
    The actual bounds of a node accounting for drop shadows, thick strokes, and anything
    else that may fall outside the node's regular bounding box defined in `x`, `y`,
    `width`, and `height`. The `x` and `y` inside this property represent the absolute
    position of the node on the page. This value will be `null` if the node is invisible.
    """

    preserve_ratio: bool = False
    """
    Keep height and width constrained to same ratio.
    """

    constraints: LayoutConstraint | None = None
    """
    Horizontal and vertical layout constraints for node.
    """

    relative_transform: Transform | None = None
    """
    The top two rows of a matrix that represents the 2D transform of this node relative to
    its parent. The bottom row of the matrix is implicitly always (0, 0, 1). Use to
    transform coordinates in geometry. Only present if `geometry=paths` is passed.
    """

    size: Vector | None = None
    """
    Width and height of element. This is different from the width and height of the
    bounding box in that the absolute bounding box represents the element after scaling
    and rotation. Only present if `geometry=paths` is passed.
    """

    layout_align: Literal["INHERIT", "STRETCH", "MIN", "CENTER", "MAX"] | None = None
    """
    Determines if the layer should stretch along the parent's counter axis. This property
    is only provided for direct children of auto-layout frames.

    - `INHERIT`
    - `STRETCH`

    In previous versions of auto layout, determined how the layer is aligned inside an
    auto-layout frame. This property is only provided for direct children of auto-layout
    frames.

    - `MIN`
    - `CENTER`
    - `MAX`
    - `STRETCH`

    In horizontal auto-layout frames, "MIN" and "MAX" correspond to "TOP" and "BOTTOM". In
    vertical auto-layout frames, "MIN" and "MAX" correspond to "LEFT" and "RIGHT".
    """

    layout_grow: Literal[0, 1] | None = None
    """
    This property is applicable only for direct children of auto-layout frames, ignored
    otherwise. Determines whether a layer should stretch along the parent's primary axis.
    A `0` corresponds to a fixed size and `1` corresponds to stretch.
    """

    layout_positioning: Literal["AUTO", "ABSOLUTE"] = "AUTO"
    """
    Determines whether a layer's size and position should be determined by auto-layout
    settings or manually adjustable.
    """

    min_width: float = 0.0
    """
    The minimum width of the frame. This property is only applicable for auto-layout
    frames or direct children of auto-layout frames.
    """

    max_width: float = 0.0
    """
    The maximum width of the frame. This property is only applicable for auto-layout
    frames or direct children of auto-layout frames.
    """

    min_height: float = 0.0
    """
    The minimum height of the frame. This property is only applicable for auto-layout
    frames or direct children of auto-layout frames.
    """

    max_height: float = 0.0
    """
    The maximum height of the frame. This property is only applicable for auto-layout
    frames or direct children of auto-layout frames.
    """

    layout_sizing_horizontal: Literal["FIXED", "HUG", "FILL"] | None = None
    """
    The horizontal sizing setting on this auto-layout frame or frame child.

    - `FIXED`
    - `HUG`: only valid on auto-layout frames and text nodes.
    - `FILL`: only valid on auto-layout frame children.
    """

    layout_sizing_vertical: Literal["FIXED", "HUG", "FILL"] | None = None
    """
    The vertical sizing setting on this auto-layout frame or frame child.

    - `FIXED`
    - `HUG`: only valid on auto-layout frames and text nodes.
    - `FILL`: only valid on auto-layout frame children.
    """

    grid_row_count: int | None = None
    """
    The number of rows in the grid layout. This property is only applicable for
    auto-layout frames with `layout_mode: GRID`.
    """

    grid_column_count: int | None = None
    """
    The number of columns in the grid layout. This property is only applicable for
    auto-layout frames with `layout_mode: GRID`.
    """

    grid_row_gap: float = 0.0
    """
    The distance between rows in the grid layout. This property is only applicable for
    auto-layout frames with `layout_mode: GRID`.
    """

    grid_column_gap: float = 0.0
    """
    The distance between columns in the grid layout. This property is only applicable for
    auto-layout frames with `layout_mode: GRID`.
    """

    grid_columns_sizing: str | None = None
    """
    The string for the CSS grid-template-columns property. This property is only
    applicable for auto-layout frames with `layout_mode: GRID`.
    """

    grid_rows_sizing: str | None = None
    """
    The string for the CSS grid-template-rows property. This property is only applicable
    for auto-layout frames with `layout_mode: GRID`.
    """

    grid_child_horizontal_align: Literal["AUTO", "MIN", "CENTER", "MAX"] | None = None
    """
    Determines how a GRID frame's child should be aligned in the horizontal direction
    within its grid area. This property is only applicable for direct children of frames
    with `layout_mode: GRID`.
    """

    grid_child_vertical_align: Literal["AUTO", "MIN", "CENTER", "MAX"] | None = None
    """
    Determines how a GRID frame's child should be aligned in the vertical direction within
    its grid area. This property is only applicable for direct children of frames with
    `layout_mode: GRID`.
    """

    grid_row_span: int = 1
    """
    The number of rows that a GRID frame's child should span. This property is only
    applicable for direct children of frames with `layout_mode: GRID`.
    """

    grid_column_span: int = 1
    """
    The number of columns that a GRID frame's child should span. This property is only
    applicable for direct children of frames with `layout_mode: GRID`.
    """

    grid_row_anchor_index: int = 0
    """
    The index of the row that a GRID frame's child should be anchored to. This property
    is only applicable for direct children of frames with `layout_mode: GRID`.
    """

    grid_column_anchor_index: int = 0
    """
    The index of the column that a GRID frame's child should be anchored to. This property
    is only applicable for direct children of frames with `layout_mode: GRID`.
    """


class HasFramePropertiesTrait(BaseModel):
    clips_content: bool
    """
    Whether or not this node clips content outside of its bounds.
    """

    background: Annotated[list[Paint] | None, Field(deprecated=True)] = None
    """
    Background of the node.
    This is deprecated, as backgrounds for frames are now in the `fills` field.
    """

    background_color: Annotated[RGBA | None, Field(deprecated=True)] = None
    """
    Background color of the node.
    This is deprecated, as frames now support more than a solid color as a background.
    Please use the `fills` field instead.
    """

    layout_grids: list[LayoutGrid] | None = None
    """
    An array of layout grids attached to this node (see layout grids section for more
    details). GROUP nodes do not have this attribute.
    """

    overflow_direction: Literal[
        "HORIZONTAL_SCROLLING",
        "VERTICAL_SCROLLING",
        "HORIZONTAL_AND_VERTICAL_SCROLLING",
        "NONE",
    ] = "NONE"
    """
    Whether a node has primary axis scrolling, horizontal or vertical.
    """

    layout_mode: Literal["NONE", "HORIZONTAL", "VERTICAL", "GRID"] = "NONE"
    """
    Whether this layer uses auto-layout to position its children.
    """

    primary_axis_sizing_mode: Literal["FIXED", "AUTO"] = "AUTO"
    """
    Whether the primary axis has a fixed length (determined by the user) or an automatic
    length (determined by the layout engine). This property is only applicable for
    auto-layout frames.
    """

    counter_axis_sizing_mode: Literal["FIXED", "AUTO"] = "AUTO"
    """
    Whether the counter axis has a fixed length (determined by the user) or an automatic
    length (determined by the layout engine). This property is only applicable for
    auto-layout frames.
    """

    primary_axis_align_items: Literal["MIN", "CENTER", "MAX", "SPACE_BETWEEN"] = "MIN"
    """
    Determines how the auto-layout frame's children should be aligned in the primary axis
    direction. This property is only applicable for auto-layout frames.
    """

    counter_axis_align_items: Literal["MIN", "CENTER", "MAX", "BASELINE"] = "MIN"
    """
    Determines how the auto-layout frame's children should be aligned in the counter axis
    direction. This property is only applicable for auto-layout frames.
    """

    padding_left: float = 0.0
    """
    The padding between the left border of the frame and its children. This property is
    only applicable for auto-layout frames.
    """

    padding_right: float = 0.0
    """
    The padding between the right border of the frame and its children. This property is
    only applicable for auto-layout frames.
    """

    padding_top: float = 0.0
    """
    The padding between the top border of the frame and its children. This property is
    only applicable for auto-layout frames.
    """

    padding_bottom: float = 0.0
    """
    The padding between the bottom border of the frame and its children. This property is
    only applicable for auto-layout frames.
    """

    item_spacing: float = 0.0
    """
    The distance between children of the frame. Can be negative. This property is only
    applicable for auto-layout frames.
    """

    item_reverse_z_index: bool = False
    """
    Determines the canvas stacking order of layers in this frame. When True, the first
    layer will be draw on top. This property is only applicable for auto-layout frames.
    """

    strokes_included_in_layout: bool = False
    """
    Determines whether strokes are included in layout calculations. When True,
    auto-layout frames behave like css "box-sizing: border-box". This property is only
    applicable for auto-layout frames.
    """

    layout_wrap: Literal["NO_WRAP", "WRAP"] | None = None
    """
    Whether this auto-layout frame has wrapping enabled.
    """

    counter_axis_spacing: float | None = None
    """
    The distance between wrapped tracks of an auto-layout frame. This property is only
    applicable for auto-layout frames with `layout_wrap: WRAP`
    """

    counter_axis_align_content: Literal["AUTO", "SPACE_BETWEEN"] = "AUTO"
    """
    Determines how the auto-layout frame's wrapped tracks should be aligned in the counter
    axis direction. This property is only applicable for auto-layout frames with
    `layout_wrap: WRAP`.
    """


class HasBlendModeAndOpacityTrait(BaseModel):
    blend_mode: BlendMode
    """
    How this node blends with nodes behind it in the scene.
    """

    opacity: Annotated[float, Field(ge=0.0, le=1.0)] = 1.0
    """
    Opacity of the node.
    """


class HasExportSettingsTrait(BaseModel):
    export_settings: list[ExportSetting] | None = None
    """
    An array of export settings representing images to export from the node.
    """


class MinimalFillsTrait(BaseModel):
    fills: list[Paint]
    """
    An array of fill paints applied to the node.
    """

    styles: dict[str, str] | None = None
    """
    A mapping of a StyleType to style ID of styles present on this node. The style ID can
    be used to look up more information about the style in the top-level styles field.
    """


class MinimalStrokesTrait(BaseModel):
    strokes: list[Paint] | None = None
    """
    An array of stroke paints applied to the node.
    """

    stroke_weight: float = 1.0
    """
    The weight of strokes on the node.
    """

    stroke_align: Literal["INSIDE", "OUTSIDE", "CENTER"] | None = None
    """
    Position of stroke relative to vector outline.

    - `INSIDE`: stroke drawn inside the shape boundary
    - `OUTSIDE`: stroke drawn outside the shape boundary
    - `CENTER`: stroke drawn centered along the shape boundary
    """

    stroke_join: Literal["MITER", "BEVEL", "ROUND"] = "MITER"
    """
    A string enum with value of "MITER", "BEVEL", or "ROUND", describing how corners in
    vector paths are rendered.
    """

    stroke_dashes: list[float] | None = None
    """
    An array of floating point numbers describing the pattern of dash length and gap
    lengths that the vector stroke will use when drawn.

    For example a value of [1, 2] indicates that the stroke will be drawn with a dash of
    length 1 followed by a gap of length 2, repeated.
    """


class HasGeometryTrait(MinimalFillsTrait, MinimalStrokesTrait):
    fill_override_table: dict[str, PaintOverride | None] | None = None
    """
    Map from ID to PaintOverride for looking up fill overrides. To see which regions are
    overridden, you must use the `geometry=paths` option. Each path returned may have an
    `override_id` which maps to this table.
    """

    fill_geometry: list[Path] | None = None
    """
    Only specified if parameter `geometry=paths` is used. An array of paths representing
    the object fill.
    """

    stroke_geometry: list[Path] | None = None
    """
    Only specified if parameter `geometry=paths` is used. An array of paths representing
    the object stroke.
    """

    stroke_cap: Literal[
        "NONE",
        "ROUND",
        "SQUARE",
        "LINE_ARROW",
        "TRIANGLE_ARROW",
        "DIAMOND_FILLED",
        "CIRCLE_FILLED",
        "TRIANGLE_FILLED",
        "WASHI_TAPE_1",
        "WASHI_TAPE_2",
        "WASHI_TAPE_3",
        "WASHI_TAPE_4",
        "WASHI_TAPE_5",
        "WASHI_TAPE_6",
    ] = "NONE"
    """
    Describes the end caps of vector paths.
    """

    stroke_miter_angle: float = 28.96
    """
    Only valid if `stroke_join` is "MITER". The corner angle, in degrees, below which
    `stroke_join` will be set to "BEVEL" to avoid super sharp corners. By default this is
    28.96 degrees.k
    """


class IndividualStrokesTrait(BaseModel):
    individual_stroke_weights: StrokeWeights | None = None
    """
    An object including the top, bottom, left, and right stroke weights. Only returned if
    individual stroke weights are used.
    """


class VariableWidthStrokesTrait(BaseModel): ...


class ComplexStrokesTrait(BaseModel): ...


class CornerTrait(BaseModel):
    corner_radius: float = 0.0
    """
    Radius of each corner if a single radius is set for all corners.
    """

    corner_smoothing: Annotated[float | None, Field(ge=0.0, le=1.0)] = None
    """
    A value that lets you control how "smooth" the corners are. Ranges from 0 to 1.
    - 0 is the default and means that the corner is perfectly circular.
    - A value of 0.6 means the corner matches the iOS 7 "squircle" icon shape.
    - Other values produce various other curves.
    """

    rectangle_corner_radii: Annotated[
        list[float] | None,
        Field(min_length=4, max_length=4),
    ] = None
    """
    Array of length 4 of the radius of each corner of the frame, starting in the top left
    and proceeding clockwise.
    Values are given in the order top-left, top-right, bottom-right, bottom-left.
    """


class HasEffectsTrait(BaseModel):
    effects: list[Effect]
    """
    An array of effects attached to this node (see effects section for more details)
    """


class HasMaskTrait(BaseModel):
    is_mask: bool = False
    """
    Does this node mask sibling nodes in front of it?
    """

    mask_type: MaskType | None = None
    """
    Describes the operation used to mask the layer's siblings.
    """

    is_mask_outline: Annotated[bool, Field(deprecated=True)] = False
    """
    True if `mask_type` is VECTOR. This field is deprecated; use `mask_type` instead.
    @deprecated
    """


class ComponentPropertiesTrait(BaseModel):
    component_property_definitions: dict[str, ComponentPropertyDefinition] | None = None
    """
    A mapping of name to `ComponentPropertyDefinition` for every component property on
    this component. Each property has a type, `default_value`, and other optional values.
    """


class TypePropertiesTrait(BaseModel):
    characters: str
    """
    The raw characters in the text node.
    """

    style: TypeStyle
    """
    Style of text including font family and weight.
    """

    character_style_overrides: list[float]
    """
    The array corresponds to characters in the text box, where each element references the
    `style_override_table` to apply specific styles to each character. The array's length
    can be less than or equal to the number of characters due to the removal of trailing
    zeros. Elements with a value of 0 indicate characters that use the default type style.
    If the array is shorter than the total number of characters, the characters beyond the
    array's length also use the default style.
    """

    layout_version: float | None = None
    """
    Internal property, preserved for backward compatibility. Avoid using this value.
    """

    style_override_table: dict[str, TypeStyle]
    """
    Map from ID to TypeStyle for looking up style overrides.
    """

    line_types: list[Literal["NONE", "ORDERED", "UNORDERED"]]
    """
    An array with the same number of elements as lines in the text node, where lines are
    delimited by newline or paragraph separator characters. Each element in the array
    corresponds to the list type of a specific line. List types are represented as string
    enums with one of these possible values:
    - `NONE`: Not a list item.
    - `ORDERED`: Text is an ordered list (numbered).
    - `UNORDERED`: Text is an unordered list (bulleted).
    """

    line_indentations: list[float]
    """
    An array with the same number of elements as lines in the text node, where lines are
    delimited by newline or paragraph separator characters. Each element in the array
    corresponds to the indentation level of a specific line.
    """


class TextPathPropertiesTrait(BaseModel):
    characters: str
    """
    The raw characters in the text path node.
    """

    style: TextPathTypeStyle
    """
    Style of text including font family and weight.
    """

    character_style_overrides: list[float]
    """
    The array corresponds to characters in the text box, where each element references the
    `style_override_table` to apply specific styles to each character. The array's length
    can be less than or equal to the number of characters due to the removal of trailing
    zeros. Elements with a value of 0 indicate characters that use the default type style.
    If the array is shorter than the total number of characters, the characters beyond the
    array's length also use the default style.
    """

    layout_version: float | None = None
    """
    Internal property, preserved for backward compatibility. Avoid using this value.
    """

    style_override_table: dict[str, TextPathTypeStyle]
    """
    Map from ID to TextPathTypeStyle for looking up style overrides.
    """


class HasTextSublayerTrait(BaseModel):
    characters: str
    """
    Text contained within a text box.
    """


class TransitionSourceTrait(BaseModel):
    transition_node_id: Annotated[
        str | None,
        Field(validation_alias="transitionNodeID"),
    ] = None
    """
    Node ID of node to transition to in prototyping.
    """

    transition_duration: float | None = None
    """
    The duration of the prototyping transition on this node (in milliseconds). This will
    override the default transition duration on the prototype, for this node.
    """

    transition_easing: EasingType | None = None
    """
    The easing curve used in the prototyping transition on this node.
    """

    interactions: list[Interaction] | None = None


class DevStatusTrait(BaseModel):
    dev_status: DevStatus | None = None
    """
    Represents if a node has a particular handoff (or dev) status applied to it.
    """


class AnnotationsTrait(BaseModel): ...


class TransformModifiersTrait(BaseModel): ...


class FrameTraits(
    IsLayerTrait,
    HasBlendModeAndOpacityTrait,
    HasChildrenTrait,
    HasLayoutTrait,
    HasFramePropertiesTrait,
    CornerTrait,
    HasGeometryTrait,
    HasExportSettingsTrait,
    HasEffectsTrait,
    HasMaskTrait,
    TransitionSourceTrait,
    IndividualStrokesTrait,
    VariableWidthStrokesTrait,
    ComplexStrokesTrait,
    DevStatusTrait,
    AnnotationsTrait,
): ...


class DefaultShapeTraits(
    IsLayerTrait,
    HasBlendModeAndOpacityTrait,
    HasLayoutTrait,
    HasGeometryTrait,
    HasExportSettingsTrait,
    HasEffectsTrait,
    HasMaskTrait,
    TransitionSourceTrait,
    VariableWidthStrokesTrait,
    ComplexStrokesTrait,
): ...


class CornerRadiusShapeTraits(DefaultShapeTraits, CornerTrait): ...


class RectangularShapeTraits(
    DefaultShapeTraits,
    CornerTrait,
    IndividualStrokesTrait,
    AnnotationsTrait,
): ...


class DocumentNode(IsLayerTrait):
    type: Literal["DOCUMENT"] = "DOCUMENT"
    children: list[CanvasNode]


class CanvasNode(IsLayerTrait, HasExportSettingsTrait):
    type: Literal["CANVAS"] = "CANVAS"
    children: list[SubcanvasNode]

    background_color: RGBA
    """
    Background color of the canvas.
    """

    flow_starting_points: list[FlowStartingPoint]
    """
    An array of flow starting points sorted by its position in the prototype settings
    panel.
    """

    prototype_device: PrototypeDevice
    """
    The device used to view a prototype.
    """

    prototype_backgrounds: list[RGBA] | None = None
    """
    The background color of the prototype (currently only supports a single solid color
    paint).
    """

    measurements: list[Measurement] | None = None


class BooleanOperationNode(
    IsLayerTrait,
    HasBlendModeAndOpacityTrait,
    HasChildrenTrait,
    HasLayoutTrait,
    HasGeometryTrait,
    HasExportSettingsTrait,
    HasEffectsTrait,
    HasMaskTrait,
    TransitionSourceTrait,
):
    type: Literal["BOOLEAN_OPERATION"] = "BOOLEAN_OPERATION"

    boolean_operation: Literal["UNION", "INTERSECT", "SUBTRACT", "EXCLUDE"]
    """
    Indicates the type of boolean operation applied.
    """


class SectionNode(
    IsLayerTrait,
    HasGeometryTrait,
    HasChildrenTrait,
    HasLayoutTrait,
    DevStatusTrait,
):
    type: Literal["SECTION"] = "SECTION"

    section_contents_hidden: bool
    """
    Whether the contents of the section are visible.
    """


class FrameNode(FrameTraits):
    type: Literal["FRAME"] = "FRAME"


class GroupNode(FrameTraits):
    type: Literal["GROUP"] = "GROUP"


class ComponentNode(FrameTraits, ComponentPropertiesTrait):
    type: Literal["COMPONENT"] = "COMPONENT"


class ComponentSetNode(FrameTraits, ComponentPropertiesTrait):
    type: Literal["COMPONENT_SET"] = "COMPONENT_SET"


class VectorNode(CornerRadiusShapeTraits, AnnotationsTrait):
    type: Literal["VECTOR"] = "VECTOR"


class StarNode(CornerRadiusShapeTraits, AnnotationsTrait):
    type: Literal["STAR"] = "STAR"


class LineNode(DefaultShapeTraits, AnnotationsTrait):
    type: Literal["LINE"] = "LINE"


class EllipseNode(DefaultShapeTraits, AnnotationsTrait):
    type: Literal["ELLIPSE"] = "ELLIPSE"

    arc_data: ArcData
    """
    Information about the arc properties of an ellipse.
    """


class RegularPolygonNode(CornerRadiusShapeTraits, AnnotationsTrait):
    type: Literal["REGULAR_POLYGON"] = "REGULAR_POLYGON"


class RectangleNode(RectangularShapeTraits):
    type: Literal["RECTANGLE"] = "RECTANGLE"


class TextNode(
    DefaultShapeTraits,
    TypePropertiesTrait,
    AnnotationsTrait,
):
    type: Literal["TEXT"] = "TEXT"


class TextPathNode(
    DefaultShapeTraits,
    TextPathPropertiesTrait,
):
    type: Literal["TEXT_PATH"] = "TEXT_PATH"


class TableNode(
    IsLayerTrait,
    HasChildrenTrait,
    HasLayoutTrait,
    MinimalStrokesTrait,
    HasEffectsTrait,
    HasBlendModeAndOpacityTrait,
    HasExportSettingsTrait,
):
    type: Literal["TABLE"] = "TABLE"


class TableCellNode(
    IsLayerTrait,
    MinimalFillsTrait,
    HasLayoutTrait,
    HasTextSublayerTrait,
):
    type: Literal["TABLE_CELL"] = "TABLE_CELL"


class TransformGroupNode(FrameTraits, TransformModifiersTrait):
    type: Literal["TRANSFORM_GROUP"] = "TRANSFORM_GROUP"


class SliceNode(IsLayerTrait):
    type: Literal["SLICE"] = "SLICE"


class InstanceNode(FrameTraits):
    type: Literal["INSTANCE"] = "INSTANCE"

    component_id: str
    """
    ID of component that this instance came from.
    """

    is_exposed_instance: bool | None = None
    """
    If True, this node has been marked as exposed to its containing component or component
    set.
    """

    exposed_instances: list[str] | None = None
    """
    IDs of instances that have been exposed to this node's level.
    """

    component_properties: dict[str, ComponentProperty] | None = None
    """
    A mapping of name to `ComponentProperty` for all component properties on this
    instance. Each property has a type, value, and other optional values.
    """

    overrides: list[Overrides]
    """
    An array of all of the fields directly overridden on this instance. Inherited
    overrides are not included.
    """


class EmbedNode(IsLayerTrait, HasExportSettingsTrait):
    type: Literal["EMBED"] = "EMBED"


class LinkUnfurlNode(IsLayerTrait, HasExportSettingsTrait):
    type: Literal["LINK_UNFURL"] = "LINK_UNFURL"


class StickyNode(
    IsLayerTrait,
    HasLayoutTrait,
    HasBlendModeAndOpacityTrait,
    MinimalFillsTrait,
    HasMaskTrait,
    HasEffectsTrait,
    HasExportSettingsTrait,
    HasTextSublayerTrait,
):
    type: Literal["STICKY"] = "STICKY"

    author_visible: bool | None = None
    """
    If True, author name is visible.
    """


class ShapeWithTextNode(
    IsLayerTrait,
    HasLayoutTrait,
    HasBlendModeAndOpacityTrait,
    MinimalFillsTrait,
    HasMaskTrait,
    HasEffectsTrait,
    HasExportSettingsTrait,
    HasTextSublayerTrait,
    CornerTrait,
    MinimalStrokesTrait,
):
    type: Literal["SHAPE_WITH_TEXT"] = "SHAPE_WITH_TEXT"

    shape_type: ShapeType
    """
    Geometric shape type. Most shape types have the same name as their tooltip but there
    are a few exceptions.
    """


class ConnectorNode(
    IsLayerTrait,
    HasLayoutTrait,
    HasBlendModeAndOpacityTrait,
    HasEffectsTrait,
    HasExportSettingsTrait,
    HasTextSublayerTrait,
    MinimalStrokesTrait,
):
    type: Literal["CONNECTOR"] = "CONNECTOR"

    connector_start: ConnectorEndpoint
    """
    The starting point of the connector.
    """

    connector_end: ConnectorEndpoint
    """
    The ending point of the connector.
    """

    connector_start_stroke_cap: Literal[
        "NONE",
        "LINE_ARROW",
        "TRIANGLE_ARROW",
        "DIAMOND_FILLED",
        "CIRCLE_FILLED",
        "TRIANGLE_FILLED",
    ]
    """
    Describes the end cap of the start of the connector.
    """

    connector_end_stroke_cap: Literal[
        "NONE",
        "LINE_ARROW",
        "TRIANGLE_ARROW",
        "DIAMOND_FILLED",
        "CIRCLE_FILLED",
        "TRIANGLE_FILLED",
    ]
    """
    Describes the end cap of the end of the connector.
    """

    connector_line_type: ConnectorLineType
    """
    Connector line type.
    """

    text_background: ConnectorTextBackground | None = None
    """
    Connector text background.
    """


class WashiTapeNode(DefaultShapeTraits):
    type: Literal["WASHI_TAPE"] = "WASHI_TAPE"


class WidgetNode(IsLayerTrait, HasExportSettingsTrait, HasChildrenTrait):
    type: Literal["WIDGET"] = "WIDGET"


Node = Annotated[
    BooleanOperationNode
    | ComponentNode
    | ComponentSetNode
    | ConnectorNode
    | EllipseNode
    | EmbedNode
    | FrameNode
    | GroupNode
    | InstanceNode
    | LineNode
    | LinkUnfurlNode
    | RectangleNode
    | RegularPolygonNode
    | SectionNode
    | ShapeWithTextNode
    | SliceNode
    | StarNode
    | StickyNode
    | TableNode
    | TableCellNode
    | TextNode
    | TextPathNode
    | TransformGroupNode
    | VectorNode
    | WashiTapeNode
    | WidgetNode
    | DocumentNode
    | CanvasNode,
    Field(discriminator="type"),
]

SubcanvasNode = Annotated[
    BooleanOperationNode
    | ComponentNode
    | ComponentSetNode
    | ConnectorNode
    | EllipseNode
    | EmbedNode
    | FrameNode
    | GroupNode
    | InstanceNode
    | LineNode
    | LinkUnfurlNode
    | RectangleNode
    | RegularPolygonNode
    | SectionNode
    | ShapeWithTextNode
    | SliceNode
    | StarNode
    | StickyNode
    | TableNode
    | TableCellNode
    | TextNode
    | TextPathNode
    | TransformGroupNode
    | VectorNode
    | WashiTapeNode
    | WidgetNode,
    Field(discriminator="type"),
]
