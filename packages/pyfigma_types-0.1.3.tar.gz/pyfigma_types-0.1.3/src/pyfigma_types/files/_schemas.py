from __future__ import annotations

from typing import Literal

from pydantic import AwareDatetime

from pyfigma_types._models import BaseModel
from pyfigma_types.types import FileBranch, LinkAccess, Role
from pyfigma_types.users import User

from .node_types import DocumentNode, Node
from .property_types import Component, ComponentSet, Style


class GetFileResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key` endpoint."""

    name: str
    """
    The name of the file as it appears in the editor.
    """

    role: Role
    """
    The role of the user making the API request in relation to the file.
    """

    last_modified: AwareDatetime
    """
    The UTC ISO 8601 time at which the file was last modified.
    """

    editor_type: Literal["figma", "figjam"]
    """
    The type of editor associated with this file.
    """

    thumbnail_url: str | None = None
    """
    A URL to a thumbnail image of the file.
    """

    version: str
    """
    The version number of the file. This number is incremented when a file is modified and
    can be used to check if the file has changed between requests.
    """

    document: DocumentNode
    """
    The root document node of this file.
    """

    components: dict[str, Component]
    """
    A mapping from component IDs to component metadata.
    """

    component_sets: dict[str, ComponentSet]
    """
    A mapping from component set IDs to component set metadata.
    """

    schema_version: int = 0
    """
    The version of the file schema that this file uses.
    """

    styles: dict[str, Style]
    """
    A mapping from style IDs to style metadata.
    """

    link_access: LinkAccess | None = None
    """
    The share permission level of the file link.
    """

    main_file_key: str | None = None
    """
    The key of the main file for this file. If present, this file is a component or
    component set.
    """

    branches: list[FileBranch] | None = None
    """
    A list of branches for this file.
    """


class GetFileNodesResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key/nodes` endpoint."""

    name: str
    """
    The name of the file as it appears in the editor.
    """

    role: Role
    """
    The role of the user making the API request in relation to the file.
    """

    last_modified: AwareDatetime
    """
    The UTC ISO 8601 time at which the file was last modified.
    """

    editor_type: Literal["figma", "figjam"]
    """
    The type of editor associated with this file.
    """

    thumbnail_url: str | None = None
    """
    A URL to a thumbnail image of the file.
    """

    version: str
    """
    The version number of the file. This number is incremented when a file is modified and
    can be used to check if the file has changed between requests.
    """

    nodes: dict[str, GetFileNodesResponseNode]
    """
    A mapping from node IDs to node metadata.
    """


class GetFileNodesResponseNode(BaseModel):
    document: Node

    components: dict[str, Component]
    """
    A mapping from component IDs to component metadata.
    """

    component_sets: dict[str, ComponentSet]
    """
    A mapping from component set IDs to component set metadata.
    """

    schema_version: int = 0
    """
    The version of the file schema that this file uses.
    """

    styles: dict[str, Style]
    """
    A mapping from style IDs to style metadata.
    """


class GetImageResponse(BaseModel):
    """Response schema for the `GET /v1/images/:key` endpoint."""

    err: None = None
    """
    For successful requests, this value is always `None`.
    """

    images: dict[str, str | None]
    """
    A map from node IDs to URLs of the rendered images.
    """


class GetImageFillsResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key/images` endpoint."""

    error: Literal[False]
    """
    For successful requests, this value is always `false`.
    """

    status: Literal[200]
    """
    Status code
    """

    meta: GetImageFillsResponseMeta


class GetImageFillsResponseMeta(BaseModel):
    images: dict[str, str]


class GetFileMetadataResponse(BaseModel):
    """Response schema for the `GET /v1/files/:key/meta` endpoint."""

    name: str
    """
    The name of the file.
    """

    folder_name: str | None = None
    """
    The name of the project containing the file.
    """

    last_touched_at: AwareDatetime
    """
    The UTC ISO 8601 time at which the file content was last modified.
    """

    creator: User
    """
    The user who created the file.
    """

    last_touched_by: User | None = None
    """
    The user who last modified the file contents.
    """

    thumbnail_url: str | None = None
    """
    A URL to a thumbnail image of the file.
    """

    editor_type: Literal["figma", "figjam", "slides", "buzz", "sites", "make"]
    """
    The type of editor associated with this file.
    """

    role: Role | None = None
    """
    The role of the user making the API request in relation to the file.
    """

    link_access: LinkAccess | None = None
    """
    Access policy for users who have the link to the file.
    """

    url: str | None = None
    """
    The URL of the file.
    """

    version: str | None = None
    """
    The version number of the file. This number is incremented when a file is modified and
    can be used to check if the file has changed between requests.
    """
