from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from pyfigma_types._models import BaseModel
from pyfigma_types._validators import DefaultIfNone

from ._base import Hyperlink, VariableAlias
from ._paints import Paint


class BaseTypeStyle(BaseModel):
    font_family: str | None = None
    """
    Font family of text (standard name).
    """

    font_post_script_name: str | None = None
    """
    PostScript font name.
    """

    font_style: str | None = None
    """
    Describes visual weight or emphasis, such as Bold or Italic.
    """

    italic: bool = False
    """
    Whether or not text is italicized.
    """

    font_weight: float | None = None
    """
    Numeric font weight.
    """

    font_size: float | None = None
    """
    Font size in px.
    """

    text_case: (
        Literal["ORIGINAL", "UPPER", "LOWER", "TITLE", "SMALL_CAPS", "SMALL_CAPS_FORCED"]
        | None
    ) = None
    """
    Text casing applied to the node, default is the original casing.
    """

    text_align_horizontal: Literal["LEFT", "RIGHT", "CENTER", "JUSTIFIED"] | None = None
    """
    Horizontal text alignment as string enum.
    """

    text_align_vertical: Literal["TOP", "CENTER", "BOTTOM"] | None = None
    """
    Vertical text alignment as string enum.
    """

    letter_spacing: float | None = None
    """
    Space between characters in px.
    """

    fills: list[Paint] | None = None
    """
    An array of fill paints applied to the characters.
    """

    hyperlink: Hyperlink | None = None
    """
    Link to a URL or frame.
    """

    opentype_flags: dict[str, bool] | None = None
    """
    A map of OpenType feature flags to True or False, True if it is enabled and False if
    it is disabled. Note that some flags aren't reflected here. For example, SMCP (small
    caps) is still represented by the `text_case` field.
    """

    semantic_weight: Literal["BOLD", "NORMAL"] | None = None
    """
    Indicates how the font weight was overridden when there is a text style override.
    """

    semantic_italic: Literal["ITALIC", "NORMAL"] | None = None
    """
    Indicates how the font style was overridden when there is a text style override.
    """


class TypeStyle(BaseTypeStyle):
    """Metadata for character formatting."""

    paragraph_spacing: float = 0.0
    """
    Space between paragraphs in px, 0 if not present.
    """

    paragraph_indent: float = 0.0
    """
    Paragraph indentation in px, 0 if not present.
    """

    list_spacing: float = 0.0
    """
    Space between list items in px, 0 if not present.
    """

    text_decoration: Literal["NONE", "STRIKETHROUGH", "UNDERLINE"] = "NONE"
    """
    Text decoration applied to the node, default is none.
    """

    text_auto_resize: Literal["NONE", "WIDTH_AND_HEIGHT", "HEIGHT", "TRUNCATE"] = "NONE"
    """
    Dimensions along which text will auto resize.
    Default is that the text does not auto-resize.

    `TRUNCATE` means that the text will be shortened and trailing text will be replaced
    with "…" if the text contents is larger than the bounds. `TRUNCATE` as a return value
    is deprecated and will be removed in a future version. Read from `text_truncation`
    instead.
    """

    text_truncation: Literal["DISABLED", "ENDING"] = "DISABLED"
    """
    Whether this text node will truncate with an ellipsis when the text contents is
    larger than the text node.
    """

    max_lines: int | None = None
    """
    When `text_truncation: "ENDING"` is set, `max_lines` determines how many lines a text
    node can grow to before it truncates.
    """

    line_height_px: float | None = None
    """
    Line height in px.
    """

    line_height_percent: Annotated[
        float,
        Field(deprecated=True),
        DefaultIfNone,
    ] = 100.0
    """
    Line height as a percentage of normal line height.
    This is deprecated; in a future version of the API only `line_height_px` and
    `line_height_percent_font_size` will be returned.
    """

    line_height_percent_font_size: float | None = None
    """
    Line height as a percentage of the font size.
    Only returned when `line_height_percent` (deprecated) is not 100.
    """

    line_height_unit: Literal["PIXELS", "FONT_SIZE_%", "INTRINSIC_%"] | None = None
    """
    The unit of the line height value specified by the user.
    """

    is_override_over_text_style: bool | None = None
    """
    Whether or not this style has overrides over a text style.
    The possible fields to override are `semantic_weight`, `semantic_italic`, `hyperlink`,
    and `text_decoration`. If this is True, then those fields are overrides if present.
    """

    bound_variables: TypeStyleBoundVariables | None = None
    """
    The variables bound to a particular field on this style
    """


class TypeStyleBoundVariables(BaseModel):
    font_family: VariableAlias | None = None
    font_size: VariableAlias | None = None
    font_style: VariableAlias | None = None
    font_weight: VariableAlias | None = None
    letter_spacing: VariableAlias | None = None
    line_height: VariableAlias | None = None
    paragraph_spacing: VariableAlias | None = None
    paragraph_indent: VariableAlias | None = None


class TextPathTypeStyle(BaseTypeStyle):
    """Metadata for character formatting for text on a path."""

    is_override_over_text_style: bool | None = None
    """
    Whether or not this style has overrides over a text style.
    The possible fields to override are `semantic_weight`, `semantic_italic`, and
    `hyperlink`. If this is True, then those fields are overrides if present.
    """

    bound_variables: TextPathTypeStyleBoundVariables | None = None
    """
    Variables bound to text path style properties.
    """


class TextPathTypeStyleBoundVariables(BaseModel):
    font_family: VariableAlias | None = None
    font_size: VariableAlias | None = None
    font_style: VariableAlias | None = None
    font_weight: VariableAlias | None = None
    letter_spacing: VariableAlias | None = None
