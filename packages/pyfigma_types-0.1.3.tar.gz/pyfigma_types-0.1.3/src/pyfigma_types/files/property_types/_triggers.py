"""[Figma Property types](https://developers.figma.com/docs/rest-api/file-property-types)."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from pyfigma_types._models import BaseModel


class OnInteractionTrigger(BaseModel):
    type: Literal["ON_CLICK", "ON_HOVER", "ON_PRESS", "ON_DRAG"]


class AfterTimeoutTrigger(BaseModel):
    type: Literal["AFTER_TIMEOUT"] = "AFTER_TIMEOUT"
    timeout: float
    """
    The amount of time in milliseconds after which the trigger fires.
    """


class OnMouseTrigger(BaseModel):
    type: Literal["MOUSE_ENTER", "MOUSE_LEAVE", "MOUSE_UP", "MOUSE_DOWN"]
    delay: float
    """
    The amount of time in milliseconds the trigger needs to be held for before the
    action occurs.
    """

    deprecated_version: bool | None = None
    """
    Whether this is a [deprecated version](https://help.figma.com/hc/en-us/articles/360040035834-Prototype-triggers#h_01HHN04REHJNP168R26P1CMP0A)
    of the trigger that was left unchanged for backwards compatibility. If not present,
    the trigger is the latest version.
    """


class OnKeyDownTrigger(BaseModel):
    type: Literal["ON_KEY_DOWN"] = "ON_KEY_DOWN"
    device: Literal["KEYBOARD", "XBOX_ONE", "PS4", "SWITCH_PRO", "UNKNOWN_CONTROLLER"]
    key_codes: list[float]


class OnMediaHitTrigger(BaseModel):
    type: Literal["ON_MEDIA_HIT"] = "ON_MEDIA_HIT"
    media_hit_time: float


class OnMediaEndTrigger(BaseModel):
    type: Literal["ON_MEDIA_END"] = "ON_MEDIA_END"


Trigger = Annotated[
    OnInteractionTrigger
    | AfterTimeoutTrigger
    | OnMouseTrigger
    | OnKeyDownTrigger
    | OnMediaHitTrigger
    | OnMediaEndTrigger,
    Field(discriminator="type"),
    """
    A prototyping Trigger describes the user input needed to cause an interaction to happen.

    - `ON_HOVER` and `ON_PRESS` trigger types revert the navigation when the trigger is
      finished (the result is temporary).
    - `MOUSE_ENTER`, `MOUSE_LEAVE`, `MOUSE_UP` and `MOUSE_DOWN` are permanent, one-way
      navigation. The `delay` parameter requires the trigger to be held for a certain
      duration of time before the action occurs.
    - `ON_MEDIA_HIT` and `ON_MEDIA_END` trigger types can only trigger from a video. They
      fire when a video reaches a certain time or ends. The `timestamp` value is in seconds.
    """,  # noqa: E501
]
