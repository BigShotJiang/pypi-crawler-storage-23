"""[Figma property types - Effect](https://developers.figma.com/docs/rest-api/file-property-types/#effect-type)."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from pyfigma_types._models import BaseModel

from ._base import Vector
from ._paints import Paint


class ConnectorEndpointPosition(BaseModel):
    endpoint_node_id: str | None = None
    """
    Node ID that this endpoint attaches to.
    """

    position: Vector | None = None
    """
    The position of the endpoint relative to the node.
    """


class ConnectorEndpointMagnet(BaseModel):
    endpoint_node_id: str | None = None
    """
    Node ID that this endpoint attaches to.
    """

    magnet: Literal["AUTO", "TOP", "BOTTOM", "LEFT", "RIGHT", "CENTER"] | None = None
    """
    The magnet type.
    """


ConnectorEndpoint = Annotated[
    ConnectorEndpointPosition | ConnectorEndpointMagnet,
    """
    Stores canvas location for a connector start/end point.
    """,
]

ConnectorLineType = Annotated[
    Literal["STRAIGHT", "ELBOWED", "CURVED"],
    """
    Connector line type.
    """,
]


class ConnectorTextBackground(BaseModel):
    corner_radius: float = 0.0
    """
    Radius of each corner if a single radius is set for all corners.
    """

    corner_smoothing: Annotated[float | None, Field(ge=0.0, le=1.0)] = None
    """
    A value that lets you control how "smooth" the corners are. Ranges from 0 to 1.
    - 0 is the default and means that the corner is perfectly circular.
    - A value of 0.6 means the corner matches the iOS 7 "squircle" icon shape.
    - Other values produce various other curves.
    """

    rectangle_corner_radii: Annotated[
        list[float] | None,
        Field(min_length=4, max_length=4),
    ] = None
    """
    Array of length 4 of the radius of each corner of the frame, starting in the top left
    and proceeding clockwise.
    Values are given in the order top-left, top-right, bottom-right, bottom-left.
    """

    fills: list[Paint]
    """
    An array of fill paints applied to the node.
    """

    styles: dict[str, str] | None = None
    """
    A mapping of a StyleType to style ID of styles present on this node. The style ID can
    be used to look up more information about the style in the top-level styles field.
    """
