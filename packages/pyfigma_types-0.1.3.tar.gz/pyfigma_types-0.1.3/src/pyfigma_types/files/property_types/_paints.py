"""[Figma property types - Paint](https://developers.figma.com/docs/rest-api/file-property-types/#paint-type)."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from pyfigma_types._models import BaseModel

from ._base import (
    RGBA,
    BlendMode,
    ColorStop,
    ImageFilters,
    Transform,
    VariableAlias,
    Vector,
)


class BasePaint(BaseModel):
    visible: bool = True
    """
    Is the paint enabled?
    """

    opacity: Annotated[float, Field(ge=0.0, le=1.0)] = 1.0
    """
    Overall opacity of paint (colors within the paint can also have opacity values which
    would blend with this).
    """

    blend_mode: BlendMode
    """
    How this node blends with nodes behind it in the scene.
    """


class SolidPaint(BasePaint):
    type: Literal["SOLID"] = "SOLID"

    color: RGBA
    """
    Solid color of the paint.
    """

    bound_variables: SolidPaintBoundVariables | None = None
    """
    The variables bound to a particular field on this paint.
    """


class SolidPaintBoundVariables(BaseModel):
    color: VariableAlias | None = None


class GradientPaint(BasePaint):
    type: Literal[
        "GRADIENT_LINEAR",
        "GRADIENT_RADIAL",
        "GRADIENT_ANGULAR",
        "GRADIENT_DIAMOND",
    ]

    gradient_handle_positions: list[Vector]
    """
    This field contains three vectors, each of which are a position in normalized object
    space (normalized object space is if the top left corner of the bounding box of the
    object is (0, 0) and the bottom right is (1,1)). The first position corresponds to the
    start of the gradient (value 0 for the purposes of calculating gradient stops), the
    second position is the end of the gradient (value 1), and the third handle position
    determines the width of the gradient.
   """

    gradient_stops: list[ColorStop]
    """
    Positions of key points along the gradient axis with the colors anchored there. Colors
    along the gradient are interpolated smoothly between neighboring gradient stops.
    """


class ImagePaint(BasePaint):
    type: Literal["IMAGE"] = "IMAGE"

    scale_mode: Literal["FILL", "FIT", "TILE", "STRETCH"]
    """
    Image scaling mode.
    """

    image_ref: str
    """
    A reference to an image embedded in this node. To download the image using this
    reference, use the `GET file images` endpoint to retrieve the mapping from image
    references to image URLs.
    """

    image_transform: Transform | None = None
    """
    Affine transform applied to the image, only present if `scale_mode` is `STRETCH`.
    """

    scaling_factor: float | None = None
    """
    Amount image is scaled by in tiling, only present if `scale_mode` is `TILE`.
    """

    filters: ImageFilters | None = None
    """
    Defines what image filters have been applied to this paint, if any. If this property
    is not defined, no filters have been applied.
    """

    rotation: float = 0.0
    """Image rotation, in degrees."""

    gif_ref: str | None = None
    """
    A reference to an animated GIF embedded in this node. To download the image using this
    reference, use the `GET file images` endpoint to retrieve the mapping from image
    references to image URLs.
    """


class PatternPaint(BasePaint):
    type: Literal["PATTERN"] = "PATTERN"

    source_node_id: str
    """
    The node id of the source node for the pattern.
    """

    tile_type: Literal["RECTANGULAR", "HORIZONTAL_HEXAGONAL", "VERTICAL_HEXAGONAL"]
    """
    The tile type for the pattern.
    """

    scaling_factor: float
    """
    The scaling factor for the pattern.
    """

    spacing: Vector
    """
    The spacing for the pattern.
    """

    horizontal_alignment: Literal["START", "CENTER", "END"]
    """
    The horizontal alignment for the pattern.
    """

    vertical_alignment: Literal["START", "CENTER", "END"]
    """
    The vertical alignment for the pattern.
    """


Paint = Annotated[
    SolidPaint | GradientPaint | ImagePaint | PatternPaint,
    Field(discriminator="type"),
    """
    A solid color, gradient, image, or pattern that can be applied as fills or strokes.
    """,
]


class PaintOverride(BaseModel):
    """Paint metadata to override default paints."""

    fills: list[Paint] | None = None
    """
    Paints applied to characters.
    """

    inherit_fill_style_id: str | None = None
    """
    ID of style node, if any, that this inherits fill data from.
    """
