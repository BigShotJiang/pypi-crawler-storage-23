"""Cache router - SQLite-backed persistent cache."""

import json
import os
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from .. import get_logger, APP_DIR

logger = get_logger()

router = APIRouter(prefix="/api/cache", tags=["cache"])

_db_path = os.path.join(APP_DIR, "cache.db")


class CacheStore:
    """SQLite-backed key-value store with TTL support."""

    def __init__(self, db_path: str = _db_path):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    ttl INTEGER DEFAULT 0,
                    created_at REAL DEFAULT (strftime('%s', 'now'))
                )"""
            )

    def get(self, key: str) -> Optional[Any]:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT value, ttl, created_at FROM cache WHERE key = ?", (key,)
            ).fetchone()
            if row is None:
                return None

            value_str, ttl, created_at = row
            if ttl > 0 and (time.time() - created_at) > ttl:
                conn.execute("DELETE FROM cache WHERE key = ?", (key,))
                return None

            try:
                return json.loads(value_str)
            except (json.JSONDecodeError, TypeError):
                return value_str

    def set(self, key: str, value: Any, ttl: int = 0):
        value_str = json.dumps(value) if not isinstance(value, str) else value
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO cache (key, value, ttl, created_at)
                   VALUES (?, ?, ?, ?)""",
                (key, value_str, ttl, time.time()),
            )

    def delete(self, key: str):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM cache WHERE key = ?", (key,))

    def clear(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM cache")

    def keys(self, pattern: str = None):
        with sqlite3.connect(self.db_path) as conn:
            if pattern:
                rows = conn.execute(
                    "SELECT key FROM cache WHERE key LIKE ?",
                    (pattern.replace("*", "%"),),
                ).fetchall()
            else:
                rows = conn.execute("SELECT key FROM cache").fetchall()
            return [r[0] for r in rows]

    def cleanup_expired(self):
        now = time.time()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "DELETE FROM cache WHERE ttl > 0 AND (? - created_at) > ttl",
                (now,),
            )


class CacheManager:
    """Manages multiple named cache stores."""

    def __init__(self):
        self._stores = {}
        self._default = CacheStore()

    def get_store(self, name: str = None) -> CacheStore:
        if name is None:
            return self._default
        if name not in self._stores:
            store_path = os.path.join(APP_DIR, f"cache_{name}.db")
            self._stores[name] = CacheStore(store_path)
        return self._stores[name]


cache_manager = CacheManager()


@router.get("/")
async def list_cache_keys(pattern: str = None, store: str = None):
    """List cache keys, optionally by pattern (glob-style with *)."""
    try:
        s = cache_manager.get_store(store)
        keys = s.keys(pattern)
        return {"keys": keys}
    except Exception as e:
        logger.exception("Error listing cache keys", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.delete("/")
async def clear_cache(store: str = None):
    """Clear all cache entries."""
    try:
        s = cache_manager.get_store(store)
        s.clear()
        return {"status": "ok"}
    except Exception as e:
        logger.exception("Error clearing cache", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/{key:path}")
async def get_cache(key: str, store: str = None):
    """Get a cached value by key."""
    try:
        s = cache_manager.get_store(store)
        value = s.get(key)
        if value is None:
            return JSONResponse(status_code=404, content={"error": "Not found"})
        return {"key": key, "value": value}
    except Exception as e:
        logger.exception("Error getting cache", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.post("/{key:path}")
async def set_cache(key: str, request: Request, store: str = None):
    """Set a cached value."""
    try:
        body = await request.json()
        value = body.get("value")
        ttl = body.get("ttl", 0)
        s = cache_manager.get_store(store)
        s.set(key, value, ttl)
        return {"status": "ok"}
    except Exception as e:
        logger.exception("Error setting cache", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.delete("/{key:path}")
async def delete_cache(key: str, store: str = None):
    """Delete a cached value."""
    try:
        s = cache_manager.get_store(store)
        s.delete(key)
        return {"status": "ok"}
    except Exception as e:
        logger.exception("Error deleting cache", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})
