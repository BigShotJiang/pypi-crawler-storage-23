"""Auth router - AWS SSO."""

import asyncio

from fastapi import APIRouter, Depends, Query, Request
from fastapi.exceptions import HTTPException
from fastapi.responses import JSONResponse

from .. import get_logger
from aws_sso_lite.sso import AWSSSO

logger = get_logger()

router = APIRouter(prefix="/api/auth", tags=["auth"])


def sso_dependency(
    sso_region: str = Query(..., description="AWS SSO region"),
    sso_start_url: str = Query(..., description="AWS SSO start URL"),
):
    """FastAPI dependency that resolves an AWSSSO instance from query params."""
    return AWSSSO(sso_start_url, sso_region)


@router.get("/status")
async def get_auth_status(sso=Depends(sso_dependency)):
    """Get AWS SSO auth status."""
    try:
        authenticated = await asyncio.get_running_loop().run_in_executor(
            None, sso.has_valid_token
        )
        return {"authenticated": authenticated}
    except Exception as e:
        return {"authenticated": False, "error": str(e)}


@router.get("/accounts")
async def get_accounts(sso=Depends(sso_dependency)):
    """Get AWS SSO accounts."""
    try:
        accounts = await asyncio.get_running_loop().run_in_executor(
            None, sso.list_accounts
        )
        return accounts
    except Exception as e:
        logger.exception("Error listing accounts", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/roles")
async def get_roles(sso=Depends(sso_dependency), account_id: str = None):
    """Get AWS SSO roles for an account."""
    try:
        roles = await asyncio.get_running_loop().run_in_executor(
            None, lambda: sso.list_roles(account_id)
        )
        return roles
    except Exception as e:
        logger.exception("Error listing roles", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.post("/device")
async def start_device_authorization(sso=Depends(sso_dependency)):
    """Start AWS SSO device authorization flow."""
    try:
        result = await asyncio.get_running_loop().run_in_executor(
            None, sso.start_device_authorization
        )
        return result
    except Exception as e:
        logger.exception("Error starting device authorization", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.post("/device/token")
async def create_token(request: Request, sso=Depends(sso_dependency)):
    """Create token from device code."""
    try:
        body = await request.json()
        device_code = body.get("deviceCode")
        result = await asyncio.get_running_loop().run_in_executor(
            None, lambda: sso.create_token(device_code)
        )
        return result
    except Exception as e:
        logger.exception("Error creating token", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})
