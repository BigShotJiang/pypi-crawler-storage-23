"""Adapter 模块测试。"""
