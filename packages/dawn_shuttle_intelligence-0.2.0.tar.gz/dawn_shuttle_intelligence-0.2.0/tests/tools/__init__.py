"""tools 模块测试。"""

from __future__ import annotations
