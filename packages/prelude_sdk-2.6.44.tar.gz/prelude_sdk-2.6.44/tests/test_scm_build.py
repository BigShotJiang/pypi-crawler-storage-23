import pytest
import uuid

from prelude_sdk.controllers.scm_controller import ScmController
from prelude_sdk.models.codes import ControlCategory


@pytest.mark.order(8)
@pytest.mark.usefixtures("setup_account")
class TestScmBuild:
    def setup_class(self):
        if not pytest.expected_account["features"]["policy_evaluator"]:
            pytest.skip("POLICY_EVALUATOR feature not enabled")
        self.scm = ScmController(pytest.account)

    def test_create_object_exception(self, unwrap):
        res = unwrap(self.scm.create_object_exception)(
            self.scm,
            ControlCategory.ASSET_MANAGER,
            comment="test comment",
            expires="5555-05-05",
            filter="hostname eq 'host1'",
            name="filter me",
        )
        assert res["exception_id"]
        pytest.exception_id = res["exception_id"]

    def test_update_object_exception(self, unwrap):
        res = unwrap(self.scm.update_object_exception)(
            self.scm,
            pytest.exception_id,
            expires=None,
            filter="hostname eq 'host2'",
        )
        assert res["status"]

    def test_list_object_exceptions(self, unwrap):
        res = unwrap(self.scm.list_object_exceptions)(self.scm)
        exception = [x for x in res if x["id"] == pytest.exception_id]
        assert len(exception) == 1
        exception = exception[0]
        del exception["author"]
        del exception["created"]
        assert exception == {
            "category": ControlCategory.ASSET_MANAGER.value,
            "comment": "test comment",
            "expires": None,
            "filter": "hostname eq 'host2'",
            "id": pytest.exception_id,
            "name": "filter me",
        }

    def test_delete_object_exception(self, unwrap):
        res = unwrap(self.scm.delete_object_exception)(self.scm, pytest.exception_id)
        assert res["status"]
        res = unwrap(self.scm.list_object_exceptions)(self.scm)
        assert not any(x["id"] == pytest.exception_id for x in res)

    def test_put_report(self, unwrap):
        report_blob = {
            "name": "test report",
            "sections": [
                {
                    "name": "test section",
                    "charts": [
                        {
                            "name": "test chart",
                            "columns": ["platforms"],
                            "type": "PIE",
                            "filter": "instances/any(i: i/control eq 1)",
                            "group_by": "platforms",
                            "scm_category": "ENDPOINT",
                        }
                    ],
                }
            ],
        }
        res = unwrap(self.scm.put_report)(self.scm, report_data=report_blob)
        pytest.report_id = res["report_id"]
        for section in res["report"]["sections"]:
            assert "id" in section
        for chart in res["report"]["sections"][0]["charts"]:
            assert "id" in chart
            assert "ignore" in chart

    def test_list_reports(self, unwrap):
        res = unwrap(self.scm.list_reports)(self.scm)
        report = [r for r in res if r["report_id"] == pytest.report_id]
        assert len(report) == 1
        assert report[0]["name"] == "test report"
        assert "report" not in report[0]

    def test_get_report(self, unwrap):
        res = unwrap(self.scm.get_report)(self.scm, pytest.report_id)
        assert res["report_id"] == pytest.report_id
        for section in res["report"]["sections"]:
            assert "id" in section
        for chart in res["report"]["sections"][0]["charts"]:
            assert "id" in chart
            assert "ignore" in chart

    def test_delete_report(self, unwrap):
        res = unwrap(self.scm.delete_report)(self.scm, pytest.report_id)
        assert res["status"]
        res = unwrap(self.scm.list_reports)(self.scm)
        assert not any(r["report_id"] == pytest.report_id for r in res)
