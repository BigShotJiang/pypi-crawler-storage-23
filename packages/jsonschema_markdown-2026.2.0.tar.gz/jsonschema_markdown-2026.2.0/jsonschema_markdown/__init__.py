from jsonschema_markdown.converter.markdown import generate

generate = generate
