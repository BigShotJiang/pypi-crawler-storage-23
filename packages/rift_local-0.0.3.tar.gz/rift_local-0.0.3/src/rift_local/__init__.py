"""rift-local: Local inference server for RIFT Transcription."""

__version__ = "0.0.3"
