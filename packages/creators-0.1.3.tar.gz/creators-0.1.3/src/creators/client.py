from creatorsapi_python_sdk.api.default_api import DefaultApi
from creatorsapi_python_sdk.api_client import ApiClient

from .models import *


class Client:

    def __init__(
            self,
            credential_id: str,
            credential_secret: str,
            version: str,
            marketplace: str,
            partner_tag: str,
    ):
        api_client = ApiClient(
            credential_id=credential_id,
            credential_secret=credential_secret,
            version=version,
        )
        self.api = DefaultApi(api_client)
        self.marketplace = marketplace
        self.partner_tag = partner_tag

    def search_items(self, **kwargs) -> SearchItemsResponseContent:
        if 'partner_tag' not in kwargs:
            kwargs['partner_tag'] = self.partner_tag

        if 'item_count' not in kwargs:
            kwargs['item_count'] = 10

        if 'resources' not in kwargs:
            kwargs['resources'] = list(SearchItemsResource)

        request = SearchItemsRequestContent(**kwargs)
        return self.api.search_items(
            x_marketplace=self.marketplace,
            search_items_request_content=request,
        )

    def get_items(self, item_ids: list[str], **kwargs) -> GetItemsResponseContent:
        if 'partner_tag' not in kwargs:
            kwargs['partner_tag'] = self.partner_tag

        if 'resources' not in kwargs:
            kwargs['resources'] = list(GetItemsResource)

        request = GetItemsRequestContent(item_ids=item_ids, **kwargs)
        return self.api.get_items(
            x_marketplace=self.marketplace,
            get_items_request_content=request,
        )
