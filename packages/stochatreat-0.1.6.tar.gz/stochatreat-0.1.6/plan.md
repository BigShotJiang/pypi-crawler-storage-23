# Refactoring Plan: stochatreat.py — Monolith → Classes

## Problem

`stochatreat.py` contains a single 285-line function that does everything:
validation, data preparation, sampling, treatment mask computation, misfit
re-arrangement, and assignment. Breaking this into focused classes will improve
readability, testability, and maintainability.

**Constraint:** the public interface (`stochatreat(...)` function in
`__init__.py`) must remain unchanged.

---

## Codebase Snapshot

- `src/stochatreat/stochatreat.py` — monolithic function (285 lines)
- `src/stochatreat/utils.py` — `get_lcm_prob_denominators` helper
- `src/stochatreat/__init__.py` — re-exports `stochatreat`
- `tests/test_io.py` — input validation & output shape tests
- `tests/test_assignment.py` — statistical correctness & edge-case tests

---

## Proposed Class Decomposition

The monolithic function has six logical sections; they map cleanly to three classes:

### 1. `TreatmentConfig`
**Responsibility:** validate and store treatment parameters. No pandas involved.

Captures from the function:
- misfit_strategy validation
- RNG creation (`np.random.RandomState`)
- probs validation (sum-to-1, length match)
- Construction of `treatment_ids` list and `probs_np` array

Fields:
```
treatment_ids: list[int]
probs_np: np.ndarray
misfit_strategy: MisfitStrategy
rand: np.random.RandomState
```

---

### 2. `StratifiedDataset`
**Responsibility:** validate and prepare the input DataFrame.

Captures from the function:
- Empty / min-row checks
- `idx_col` defaulting & type check
- Column existence check
- Uniqueness check of `idx_col`
- `size` sanity check
- `stratum_cols` normalization
- Sorting by `idx_col`
- `stratum_id` assignment via `groupby(...).ngroup()`
- Trimming to `[idx_col, stratum_id]`
- Proportional sampling when `size` is not None

Fields:
```
data: pd.DataFrame          # prepared [idx_col, stratum_id] frame
idx_col: str
idx_col_type: dtype
```

---

### 3. `TreatmentAssigner`
**Responsibility:** perform the actual treatment assignment on prepared data.

Captures from the function:
- `treat_mask` computation (uses `get_lcm_prob_denominators`)
- Global misfit rearrangement (when `misfit_strategy == "global"`)
- Fake-row padding per stratum
- Vectorised permutation generation
- Treatment column attachment
- Fake-row removal & dtype restoration

Method: `assign() -> pd.DataFrame`

---

## Refactored `stochatreat` function (thin wrapper)

```python
def stochatreat(...) -> pd.DataFrame:
    config  = TreatmentConfig(treats, probs, misfit_strategy, random_state)
    dataset = StratifiedDataset(data, stratum_cols, idx_col, size, config.rand,
                                random_state)
    assigner = TreatmentAssigner(config, dataset.data, dataset.idx_col,
                                 dataset.idx_col_type)
    return assigner.assign()
```

---

## File Changes

| File | Change |
|------|--------|
| `src/stochatreat/stochatreat.py` | Replace monolith with 3 classes + thin wrapper function |
| `src/stochatreat/__init__.py` | No change (still exports only `stochatreat`) |
| `src/stochatreat/utils.py` | No change |
| `tests/` | No changes — all existing tests must continue to pass |

The three classes are **internal implementation details** and will not be added
to `__all__` or the public API.
