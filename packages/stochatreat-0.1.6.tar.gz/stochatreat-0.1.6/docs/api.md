# API Reference

::: stochatreat.stochatreat
