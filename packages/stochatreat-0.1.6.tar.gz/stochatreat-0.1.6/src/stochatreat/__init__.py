"""Stochatreat: stratified random treatment assignment."""

from stochatreat.stochatreat import stochatreat

__all__ = ["stochatreat"]
