"""Version information for stochatreat."""

# pragma: no cover
__version__ = "0.1.6"
