from .detection import (
    is_color_supported,
    is_console_terminal,
    is_dumb_terminal,
    is_input_interactive,
    is_interactive_tty,
)

__all__ = [
    "is_color_supported",
    "is_console_terminal",
    "is_dumb_terminal",
    "is_input_interactive",
    "is_interactive_tty",
]
