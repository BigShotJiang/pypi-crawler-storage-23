<head>
<title>Readme</title>
<style>
.welcome {
color: rgb(1, 170, 170)
}
</style>
</head>


<h1 class="welcome">Hi! This is my example python 3x-ui wrapper!</h1>
<p>I'm not expecting much to be honest, so please feel free to fork it if I abandon the project and you need it!</p>
<p>Also, if you REALLY want it I can give you the ownership if I step down, you can find my email in the pyproject.toml (I don't check it that much but trust me I do)</p>