import re
from dataclasses import dataclass
from typing import Optional

OPERATORS = {
    '+': "PLUS",
    '-': "MINUS",
    '*': "MUL",
    '/': "DIV",
    '^': "POW"
}

# This tokeniser converts the input string into a list of tokens that the parser can understand. It handles numbers, variables, functions, and operators.
@dataclass
class Token:
    type: str
    value: Optional[float | str] = None


def tokenize(expr: str):
    tokens = []
    i = 0

    while i < len(expr):
        c = expr[i]

        if c.isdigit() or c == '.':
            num = c
            i += 1
            while i < len(expr) and (expr[i].isdigit() or expr[i] == '.'):
                num += expr[i]
                i += 1
            tokens.append(Token("NUM", float(num)))
            continue

        if c.isalpha():
            ident = c
            i += 1
            while i < len(expr) and expr[i].isalpha():
                ident += expr[i]
                i += 1

            if ident in ("x", "e"):
                tokens.append(Token("VAR", ident))
            else:
                tokens.append(Token("FUNC", ident))
            continue

        if c in OPERATORS:
            tokens.append(Token(OPERATORS[c]))
            i += 1
            continue

        if c == '(':
            tokens.append(Token("LPAREN"))
            i += 1
            continue

        if c == ')':
            tokens.append(Token("RPAREN"))
            i += 1
            continue

        raise ValueError(f"Unexpected character '{c}'")

    return tokens