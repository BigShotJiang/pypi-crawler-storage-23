from diffstep.core.nodes import Num, Var, BinOp, Func

def ast_to_string(node):
    if isinstance(node, Num):
        # Show integers without decimal
        return str(int(node.value) if node.value.is_integer() else node.value)

    if isinstance(node, Var):
        return node.name

    if isinstance(node, BinOp):
        op_map = {
            "PLUS": "+",
            "MINUS": "-",
            "MUL": "*",
            "DIV": "/",
            "POW": "^"
        }
        op_str = op_map.get(node.op, node.op)

        # Add parentheses for clarity
        left_str = ast_to_string(node.left)
        right_str = ast_to_string(node.right)

        if node.op in ("PLUS", "MINUS"):
            return f"({left_str} {op_str} {right_str})"
        if node.op in ("MUL", "DIV"):
            return f"({left_str}{op_str}{right_str})"
        if node.op == "POW":
            return f"({left_str}^{right_str})"

    if isinstance(node, Func):
        return f"{node.name}({ast_to_string(node.arg)})"

    raise TypeError(f"Unknown node type: {node}")