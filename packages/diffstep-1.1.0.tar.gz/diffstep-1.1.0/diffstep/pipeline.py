import warnings

from diffstep.core.normalise import validate_and_normalise as normalise
from diffstep.core.tokeniser import tokenize
from diffstep.core.parser import parse
from diffstep.differentiation.derivative import differentiate
from diffstep.printer.to_string import ast_to_string
from diffstep.simplify.simplify import simplify

# This is the main function that users will call to differentiate an expression.
def DiffStep(expression: str):
    warnings.warn(
        "DiffStep is deprecated and will be removed in a future version. \n "
        "Use 'diffstep' instead.",
        category=DeprecationWarning,
        stacklevel=2
    )

    return diffstep(expression)
    

def diffstep(expression: str):
    normalised_expression = normalise(expression)
    tokens = tokenize(normalised_expression)
    ast = parse(tokens)
    derivative_ast = differentiate(ast)
    result = simplify(derivative_ast)

    return result