from diffstep.core.nodes import Num, Var, BinOp, Func

def differentiate(node):
    # Numbers: d/dx(c) = 0
    if isinstance(node, Num):
        return Num(0)

    # Variable: d/dx(x) = 1
    if isinstance(node, Var):
        return Num(1)

    # Binary operations
    if isinstance(node, BinOp):
        u = node.left
        v = node.right
        op = node.op

        if op == "PLUS":
            return BinOp("PLUS", differentiate(u), differentiate(v))

        if op == "MINUS":
            return BinOp("MINUS", differentiate(u), differentiate(v))

        if op == "MUL":
            return BinOp(
                "PLUS",
                BinOp("MUL", differentiate(u), v),
                BinOp("MUL", u, differentiate(v))
            )
        # Product rule: d/dx(u/v) = (u'v - uv') / v^2

        if op == "DIV":
            numerator = BinOp(
                "MINUS",
                BinOp("MUL", differentiate(u), v),
                BinOp("MUL", u, differentiate(v))
            )
            denominator = BinOp("POW", v, Num(2))
            return BinOp("DIV", numerator, denominator)
        # Quotient rule: d/dx(u^v) = v*u^(v-1)*u' + u^v*ln(u)*v'

        if op == "POW":
        # Power rule for constants and variables:
            # x^n
            if isinstance(v, Num):
                return BinOp(
                    "MUL",
                    BinOp(
                        "MUL",
                        Num(v.value),
                        BinOp("POW", u, Num(v.value - 1))
                    ),
                    differentiate(u)
                )

            # a^f(x)
            if isinstance(u, Num):
                return BinOp(
                    "MUL",
                    BinOp(
                        "MUL",
                        BinOp("POW", u, v),
                        Func("ln", u)
                    ),
                    differentiate(v)
                )

            # e^f(x)
            if isinstance(u, Var) and u.name == "e":
                return BinOp(
                    "MUL",
                    BinOp("POW", u, v),
                    differentiate(v)
                )

            raise ValueError("Unsupported power form.")

    # Function nodes
    if isinstance(node, Func):
        u = node.arg
        u_prime = differentiate(u)

        # Natural logarithm
        if node.name == "ln":
            return BinOp("DIV", u_prime, u)

        # Square root: d/dx(sqrt(u)) = u' / (2*sqrt(u))
        if node.name == "sqrt":
            return BinOp(
                "DIV",
                u_prime,
                BinOp("MUL", Num(2), Func("sqrt", u))
            )

        # Trigonometric functions
        if node.name == "sin":
            return BinOp("MUL", Func("cos", u), u_prime)

        if node.name == "cos":
            return BinOp(
                "MUL",
                BinOp("MUL", Num(-1), Func("sin", u)),
                u_prime
            )

        if node.name == "tan":
            return BinOp(
                "MUL",
                BinOp("POW", Func("sec", u), Num(2)),
                u_prime
            )

        if node.name == "sec":
            return BinOp(
                "MUL",
                BinOp("MUL", Func("sec", u), Func("tan", u)),
                u_prime
            )

        if node.name == "cosec":
            return BinOp(
                "MUL",
                BinOp(
                    "MUL",
                    Num(-1),
                    BinOp("MUL", Func("cosec", u), Func("cot", u))
                ),
                u_prime
            )

        if node.name == "cot":
            return BinOp(
                "MUL",
                BinOp(
                    "MUL",
                    Num(-1),
                    BinOp("POW", Func("cosec", u), Num(2))
                ),
                u_prime
            )

        # Inverse trigonometric functions
        if node.name == "arcsin":
            return BinOp(
                "MUL",
                BinOp(
                    "DIV",
                    Num(1),
                    Func("sqrt", BinOp("MINUS", Num(1), BinOp("POW", u, Num(2))))
                ),
                u_prime
            )

        if node.name == "arccos":
            return BinOp(
                "MUL",
                BinOp(
                    "MUL",
                    Num(-1),
                    BinOp(
                        "DIV",
                        Num(1),
                        Func("sqrt", BinOp("MINUS", Num(1), BinOp("POW", u, Num(2))))
                    )
                ),
                u_prime
            )

        if node.name == "arctan":
            return BinOp(
                "MUL",
                BinOp(
                    "DIV",
                    Num(1),
                    BinOp("PLUS", Num(1), BinOp("POW", u, Num(2)))
                ),
                u_prime
            )

        raise ValueError(f"Unsupported function: {node.name}")

    raise TypeError(f"Unknown node type: {node}")