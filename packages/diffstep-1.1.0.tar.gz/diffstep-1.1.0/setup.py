from setuptools import setup, find_packages

classifiers = [
    'Development Status :: 5 - Production/Stable',
    'Intended Audience :: Education',
    'Operating System :: OS Independent',
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3'
]


setup (
    name='diffstep',
    version='1.1.0',
    description="This is a library for Algorithmic Differentiation.",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://campus.cs.le.ac.uk/gitlab/ug_project/25-26/aoe8',
    author="Ayo",
    author_email="akoitilo@gmail.com",
    license= 'MIT',
    classifiers=classifiers, 
    keywords='differentiation',
    packages=find_packages(),
    install_requires=['sympy'],
    )