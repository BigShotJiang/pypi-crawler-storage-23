# These are the SystemVerilog FPU support files from:
#
#   https://github.com/davidel/v_fplib
#
# Do not update locally in case of bugs or feature additions.
# Update in their repo and copy here.
macros.sv
fpu.sv
fp_conv.sv
fp_utils.sv
