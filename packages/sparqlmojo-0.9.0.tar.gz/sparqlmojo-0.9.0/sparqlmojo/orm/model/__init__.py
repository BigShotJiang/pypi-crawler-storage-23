"""
RDF model field types and base classes.

This package provides the core building blocks for defining RDF models:
- Field types for literals, IRIs, and collections
- PropertyPath for SPARQL path expressions
- Model base class with Pydantic integration
"""

from .base import Model, ModelMetaclass, validate_instance
from .collection_fields import (
    CollectionFieldMixin,
    IRIList,
    LangStringList,
    LiteralList,
    TypedLiteralList,
    is_collection_field,
)
from .constants import (
    COLLECTION_CONCAT_SUFFIX,
    DATATYPE_VALUE_SEPARATOR,
    DEFAULT_COLLECTION_SEPARATOR,
    LANG_VALUE_SEPARATOR,
    LANG_VARIABLE_SUFFIX,
    RDF_TYPE,
    SAMPLE_VARIABLE_SUFFIX,
    VALUE_METADATA_SEPARATOR,
    XSD,
    XSD_BOOLEAN,
    XSD_DATE,
    XSD_DATETIME,
    XSD_DECIMAL,
    XSD_DOUBLE,
    XSD_FLOAT,
    XSD_INTEGER,
    XSD_STRING,
    _PROPERTY_PATH_ALLOWED_CHARS_PATTERN,
    _SUBJECT_FIELD_PREDICATE_MARKER,
    _escape_sparql_string,
)
from .field_base import RDFFieldInfo
from .iri_fields import IRIField, InverseField, ObjectPropertyField, SubjectField
from .literal_fields import (
    LangString,
    LiteralField,
    MultiLangString,
    validate_language_tag,
)
from .property_path import PropertyPath

# Import value types for backward compatibility (they were in original model.py)
from ..values import IRI, LangLiteral, Literal, TypedLiteral

__all__ = [
    # Base classes
    "Model",
    "ModelMetaclass",
    "RDFFieldInfo",
    # Literal fields
    "LiteralField",
    "LangString",
    "MultiLangString",
    # IRI fields
    "IRIField",
    "InverseField",
    "ObjectPropertyField",
    "SubjectField",
    # Collection fields
    "CollectionFieldMixin",
    "LiteralList",
    "LangStringList",
    "IRIList",
    "TypedLiteralList",
    "is_collection_field",
    # Property paths
    "PropertyPath",
    # Value types (re-exported for backward compatibility)
    "IRI",
    "LangLiteral",
    "Literal",
    "TypedLiteral",
    # XSD types
    "XSD",
    "XSD_STRING",
    "XSD_INTEGER",
    "XSD_DECIMAL",
    "XSD_FLOAT",
    "XSD_DOUBLE",
    "XSD_BOOLEAN",
    "XSD_DATE",
    "XSD_DATETIME",
    # Constants
    "RDF_TYPE",
    "LANG_VARIABLE_SUFFIX",
    "DEFAULT_COLLECTION_SEPARATOR",
    "VALUE_METADATA_SEPARATOR",
    "LANG_VALUE_SEPARATOR",
    "DATATYPE_VALUE_SEPARATOR",
    "COLLECTION_CONCAT_SUFFIX",
    "SAMPLE_VARIABLE_SUFFIX",
    # Validation
    "validate_instance",
    "validate_language_tag",
    # Private/internal (but still exported for backward compat)
    "_escape_sparql_string",
    "_PROPERTY_PATH_ALLOWED_CHARS_PATTERN",
    "_SUBJECT_FIELD_PREDICATE_MARKER",
]
