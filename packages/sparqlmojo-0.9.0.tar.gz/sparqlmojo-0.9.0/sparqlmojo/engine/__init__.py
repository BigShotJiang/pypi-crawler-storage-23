"""
Engine layer for SPARQLMojo.

Provides SPARQL endpoint session management and query execution.
"""

from .session import Session

__all__ = ["Session"]
