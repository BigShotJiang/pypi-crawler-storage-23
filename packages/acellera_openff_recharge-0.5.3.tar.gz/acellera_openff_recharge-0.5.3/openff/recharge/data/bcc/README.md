Manifest
========

* ``original-am1-bcc.json`` - an evolving file containing the original AM1 bond charge corrections. This file was
  generated using the ``scripts/convert-am1-bcc/convert.py`` script.
