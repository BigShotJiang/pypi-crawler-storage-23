"""Helpful utilities used and exposed by the framework"""
