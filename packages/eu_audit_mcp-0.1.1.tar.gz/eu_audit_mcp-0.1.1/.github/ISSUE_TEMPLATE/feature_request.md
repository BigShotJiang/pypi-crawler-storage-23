---
name: Feature Request
about: Suggest a new feature or improvement
title: "[Feature] "
labels: enhancement
assignees: ''
---

## Problem

<!-- What problem does this feature solve? -->

## Proposed solution

<!-- Describe your proposed solution or feature. -->

## Alternatives considered

<!-- Have you considered any alternative approaches? -->

## Additional context

<!-- Any other context, references to EU AI Act / GDPR articles, or screenshots. -->
