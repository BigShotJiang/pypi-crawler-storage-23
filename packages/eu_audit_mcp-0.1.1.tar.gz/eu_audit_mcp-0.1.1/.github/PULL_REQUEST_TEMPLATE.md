## What does this PR do?

<!-- Briefly describe the change and its motivation. -->

## Checklist

- [ ] Tests added or updated
- [ ] `pytest tests/ -v` passes locally
- [ ] `pre-commit run --all-files` passes
- [ ] No secrets, database files, or `audit_config.yaml` committed
- [ ] Documentation updated (if applicable)
- [ ] Commit messages follow `feat:/fix:/docs:` convention
