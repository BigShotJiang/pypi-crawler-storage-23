from eu_audit_mcp.server import main

main()
