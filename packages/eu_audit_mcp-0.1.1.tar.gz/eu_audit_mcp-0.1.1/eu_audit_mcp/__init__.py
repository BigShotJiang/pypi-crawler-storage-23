"""EU Audit Trail MCP Server — tamper-evident audit logging for EU AI Act and GDPR compliance."""
