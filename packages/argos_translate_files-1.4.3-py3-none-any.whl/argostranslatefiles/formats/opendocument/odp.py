from argostranslatefiles.formats.opendocument.odt import Odt


class Odp(Odt):
    supported_file_extensions = ['.odp']
