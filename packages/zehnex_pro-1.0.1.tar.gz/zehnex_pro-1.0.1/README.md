# ⚡ Zehnex Pro 1.0.1

**Ultra-fast async Telegram bot framework** — YouTube yuklovchi, valyuta konvertor, Wikipedia→PDF va QR kod generatori bilan.

```
pip install zehnex-pro
```

---

## 🚀 Tez boshlash

```python
from zehnex_pro import ZehnexBot, VideoDownloader, CurrencyConverter, WikiToPDF, QRGenerator, Filter

bot = ZehnexBot("YOUR_BOT_TOKEN")
dl = VideoDownloader()
currency = CurrencyConverter()
wiki = WikiToPDF(language="uz")
qr = QRGenerator()

# ─── /start ───────────────────────────────────────────────
@bot.command("start", aliases=["help"])
async def start(ctx):
    await ctx.reply(
        "👋 Salom! <b>Zehnex Pro Bot</b>\n\n"
        "📹 /video [URL] — video yuklab berish\n"
        "🎵 /audio [URL] — mp3 yuklab berish\n"
        "💱 /convert 100 USD UZS — valyuta\n"
        "📖 /wiki [mavzu] — Wikipedia PDF\n"
        "🔲 /qr [matn/URL] — QR kod\n"
        "📶 /wifi [ssid] [parol] — WiFi QR"
    )

# ─── Video yuklovchi ──────────────────────────────────────
@bot.command("video")
async def video_cmd(ctx):
    url = ctx.args[0] if ctx.args else VideoDownloader.extract_url(ctx.text)
    if not url:
        await ctx.reply("❌ URL yuboring!\nMisol: /video https://youtube.com/watch?v=...")
        return

    await ctx.upload_video()
    try:
        info = await dl.get_info(url)
        await ctx.reply(f"⏳ Yuklanmoqda...\n\n{info}")
        path = await dl.download(url, quality="720p")
        await ctx.send_video(path, caption=f"🎬 {info.title}")
        dl.cleanup(path)
    except Exception as e:
        await ctx.reply(f"❌ Xato: {e}")

# ─── Audio (MP3) yuklovchi ────────────────────────────────
@bot.command("audio")
async def audio_cmd(ctx):
    url = ctx.args[0] if ctx.args else None
    if not url:
        await ctx.reply("❌ URL yuboring!")
        return
    await ctx.typing()
    path = await dl.download(url, audio_only=True)
    await ctx.send_document(path, caption="🎵 MP3 tayyor!")
    dl.cleanup(path)

# ─── Valyuta konvertatsiya ────────────────────────────────
@bot.command("convert")
async def convert_cmd(ctx):
    # /convert 100 USD UZS
    parsed = CurrencyConverter.parse_convert_command(ctx.text)
    if not parsed:
        await ctx.reply("❌ Foydalanish: /convert 100 USD UZS")
        return
    amount, from_c, to_c = parsed
    await ctx.typing()
    try:
        result = await currency.convert(amount, from_c, to_c)
        await ctx.reply(str(result))
    except Exception as e:
        await ctx.reply(f"❌ {e}")

@bot.command("kurs")
async def rates_cmd(ctx):
    base = ctx.args[0].upper() if ctx.args else "USD"
    await ctx.typing()
    rates = await currency.get_popular_rates(base)
    await ctx.reply(currency.format_rates(rates, base))

# ─── Wikipedia → PDF ──────────────────────────────────────
@bot.command("wiki")
async def wiki_cmd(ctx):
    if not ctx.args:
        await ctx.reply("📖 Foydalanish: /wiki Python\n(yoki /wiki Amir Temur)")
        return
    query = " ".join(ctx.args)
    await ctx.typing()
    result = await wiki.search(query)
    if not result:
        await ctx.reply(f"❌ '{query}' bo'yicha hech narsa topilmadi.")
        return
    await ctx.reply(result.preview())
    await ctx.upload_document()
    pdf_path = await wiki.to_pdf(result)
    await ctx.send_document(pdf_path, caption=f"📄 {result.title}")
    wiki.cleanup(pdf_path)

# ─── QR Kod ───────────────────────────────────────────────
@bot.command("qr")
async def qr_cmd(ctx):
    if not ctx.args:
        await ctx.reply("🔲 Foydalanish: /qr https://google.com\nYoki: /qr Salom Dunyo!")
        return
    data = " ".join(ctx.args)
    await ctx.typing()
    path = await qr.generate(
        data,
        style="rounded",
        color="#1a237e",
        size=500,
    )
    await ctx.send_photo(path, caption=f"✅ QR kod tayyor!\n\n<code>{data[:80]}</code>")
    qr.cleanup(path)

# ─── WiFi QR ──────────────────────────────────────────────
@bot.command("wifi")
async def wifi_cmd(ctx):
    args = ctx.args
    if len(args) < 2:
        await ctx.reply("📶 Foydalanish: /wifi [SSID] [Parol] [WPA|WEP|nopass]")
        return
    ssid = args[0]
    password = args[1]
    security = args[2] if len(args) > 2 else "WPA"
    await ctx.typing()
    path = await qr.wifi(ssid=ssid, password=password, security=security)
    await ctx.send_photo(path, caption=f"📶 WiFi: <b>{ssid}</b>")
    qr.cleanup(path)

# ─── URL yuborilsa avtomatik video yukla ──────────────────
@bot.message(Filter.AND(Filter.is_url, Filter.NOT(Filter.text_startswith("/"))))
async def auto_video(ctx):
    url = ctx.text.strip()
    if VideoDownloader.is_supported(url):
        await ctx.reply(
            "🔗 Link topildi! Yuklab beraymi?",
            keyboard=bot.inline_keyboard([
                [
                    {"text": "📹 Video (720p)", "callback_data": f"dl_video_720p:{url[:100]}"},
                    {"text": "🎵 MP3", "callback_data": f"dl_audio:{url[:100]}"},
                ]
            ])
        )

# ─── Callback handlers ────────────────────────────────────
@bot.on("callback_query")
async def handle_callbacks(ctx):
    await ctx.answer()
    if ctx.data.startswith("dl_video_"):
        await ctx.reply("⏳ Video yuklanmoqda... iltimos kuting.")
    elif ctx.data.startswith("dl_audio:"):
        await ctx.reply("⏳ Audio yuklanmoqda... iltimos kuting.")

# ─── Run ──────────────────────────────────────────────────
if __name__ == "__main__":
    bot.run()
```

---

## 📦 O'rnatish

```bash
pip install zehnex-pro
```

Barcha imkoniyatlar bilan:
```bash
pip install zehnex-pro[all]
```

---

## 🧩 Modullar

| Modul | Tavsif |
|-------|--------|
| `ZehnexBot` | Asosiy bot engine (async polling) |
| `VideoDownloader` | YouTube, TikTok, Instagram, Twitter va 1000+ saytdan video |
| `CurrencyConverter` | Real-vaqt valyuta kurslari |
| `WikiToPDF` | Wikipedia qidiruv va PDF generator |
| `QRGenerator` | Chiroyli QR kod generatori |
| `Router` | Handler guruhlovchi |
| `Filter` | Xabar filtrlari |
| `Context` | Handler kontekst obyekti |

---

## ⚡ Nima uchun Zehnex Pro tez?

- **httpx** async HTTP — bir vaqtda yuzlab so'rov
- **asyncio.Semaphore** — parallel xabar ishlash
- **Keepalive connections** — TCP qayta ulanish xarajatisiz
- **Smart caching** — valyuta kurslari 5 daqiqa keshlanadi
- **Executor** — og'ir operatsiyalar thread poolda

---

## 📋 Talablar

- Python 3.9+
- `httpx` — async HTTP
- `yt-dlp` — video yuklovchi
- `reportlab` — PDF generator
- `qrcode[pil]` — QR kod
- `Pillow` — rasm ishlash

---

## 📄 Litsenziya

MIT License — bepul foydalaning, o'zgartiring, tarqating!

---

*Zehnex Pro 1.0.1 — Made with ❤️ for Uzbek developers*
