"""
Router - Group and organize bot handlers.
Filter - Message filtering utilities.
"""

from typing import Callable, List, Optional, Any
import re


# ══════════════════════════════════════════════════════════
#                        ROUTER
# ══════════════════════════════════════════════════════════

class Router:
    """
    Group related handlers together (like Django URLconf or Flask Blueprints).

    Example:
        admin_router = Router(name="admin")

        @admin_router.command("ban")
        async def ban_user(ctx):
            ...

        # In main file:
        bot.include_router(admin_router)
    """

    def __init__(self, name: str = "router", prefix: str = ""):
        self.name = name
        self.prefix = prefix
        self._commands = {}
        self._handlers = {}

    def command(self, cmd: str, aliases: Optional[List[str]] = None):
        """Register command in this router."""
        def decorator(func: Callable):
            full_cmd = f"{self.prefix}{cmd}".lower()
            self._commands[full_cmd] = func
            if aliases:
                for alias in aliases:
                    self._commands[f"{self.prefix}{alias}".lower()] = func
            return func
        return decorator

    def on(self, event: str, filter_func: Optional[Callable] = None):
        """Register event handler in this router."""
        def decorator(func: Callable):
            if event not in self._handlers:
                self._handlers[event] = []
            self._handlers[event].append((func, filter_func))
            return func
        return decorator

    def message(self, filter_func: Optional[Callable] = None):
        return self.on("message", filter_func)

    def include(self, bot) -> None:
        """Include this router's handlers into a bot instance."""
        bot._commands.update(self._commands)
        for event, handlers in self._handlers.items():
            if event not in bot._handlers:
                bot._handlers[event] = []
            bot._handlers[event].extend(handlers)


# ══════════════════════════════════════════════════════════
#                        FILTERS
# ══════════════════════════════════════════════════════════

class Filter:
    """
    Pre-built message filters for handler routing.

    Example:
        @bot.message(Filter.text_contains("salom"))
        async def greet(ctx):
            await ctx.reply("Va alaykum assalom! 👋")

        @bot.message(Filter.is_url)
        async def handle_url(ctx):
            await ctx.reply("URL oldim!")

        @bot.message(Filter.regex(r"^\d+$"))
        async def handle_number(ctx):
            await ctx.reply(f"Raqam: {ctx.text}")
    """

    # ── Text filters ──

    @staticmethod
    def text(value: str, ignore_case: bool = True) -> Callable:
        """Exact text match."""
        def check(ctx):
            t = ctx.text
            if ignore_case:
                return t.lower() == value.lower()
            return t == value
        return check

    @staticmethod
    def text_contains(value: str, ignore_case: bool = True) -> Callable:
        """Text contains substring."""
        def check(ctx):
            t = ctx.text or ""
            if ignore_case:
                return value.lower() in t.lower()
            return value in t
        return check

    @staticmethod
    def text_startswith(prefix: str) -> Callable:
        """Text starts with prefix."""
        def check(ctx):
            return (ctx.text or "").startswith(prefix)
        return check

    @staticmethod
    def regex(pattern: str, flags: int = 0) -> Callable:
        """Text matches regex pattern."""
        compiled = re.compile(pattern, flags)
        def check(ctx):
            return bool(compiled.search(ctx.text or ""))
        return check

    # ── Content type filters ──

    @staticmethod
    def is_photo(ctx) -> bool:
        return bool((ctx.message or {}).get("photo"))

    @staticmethod
    def is_video(ctx) -> bool:
        return bool((ctx.message or {}).get("video"))

    @staticmethod
    def is_document(ctx) -> bool:
        return bool((ctx.message or {}).get("document"))

    @staticmethod
    def is_audio(ctx) -> bool:
        return bool((ctx.message or {}).get("audio") or (ctx.message or {}).get("voice"))

    @staticmethod
    def is_sticker(ctx) -> bool:
        return bool((ctx.message or {}).get("sticker"))

    @staticmethod
    def is_url(ctx) -> bool:
        text = ctx.text or ""
        return bool(re.search(r'https?://[^\s]+', text))

    @staticmethod
    def is_reply(ctx) -> bool:
        return bool((ctx.message or {}).get("reply_to_message"))

    @staticmethod
    def is_forwarded(ctx) -> bool:
        return bool(
            (ctx.message or {}).get("forward_from")
            or (ctx.message or {}).get("forward_from_chat")
        )

    # ── User filters ──

    @staticmethod
    def from_user(*user_ids: int) -> Callable:
        """Only from specific user IDs."""
        ids = set(user_ids)
        def check(ctx):
            return ctx.user_id in ids
        return check

    @staticmethod
    def not_from_user(*user_ids: int) -> Callable:
        """Exclude specific user IDs."""
        ids = set(user_ids)
        def check(ctx):
            return ctx.user_id not in ids
        return check

    @staticmethod
    def in_chat(*chat_ids: int) -> Callable:
        """Only in specific chats."""
        ids = set(chat_ids)
        def check(ctx):
            return ctx.chat_id in ids
        return check

    # ── Callback filters ──

    @staticmethod
    def callback_data(value: str) -> Callable:
        """Exact callback data match."""
        def check(ctx):
            return ctx.data == value
        return check

    @staticmethod
    def callback_startswith(prefix: str) -> Callable:
        """Callback data starts with prefix."""
        def check(ctx):
            return ctx.data.startswith(prefix)
        return check

    # ── Logical combinators ──

    @staticmethod
    def AND(*filters: Callable) -> Callable:
        """All filters must pass."""
        def check(ctx):
            return all(f(ctx) for f in filters)
        return check

    @staticmethod
    def OR(*filters: Callable) -> Callable:
        """Any filter must pass."""
        def check(ctx):
            return any(f(ctx) for f in filters)
        return check

    @staticmethod
    def NOT(filter_func: Callable) -> Callable:
        """Negate a filter."""
        def check(ctx):
            return not filter_func(ctx)
        return check
