"""
ZehnexBot - Ultra-fast async Telegram Bot Engine
"""

import asyncio
import logging
import time
from typing import Callable, Dict, List, Optional, Any
import httpx

logger = logging.getLogger("zehnex-pro")


class ZehnexBot:
    """
    Ultra-fast async Telegram Bot.

    Example:
        bot = ZehnexBot("YOUR_TOKEN")

        @bot.command("start")
        async def start(ctx):
            await ctx.reply("Salom! Men Zehnex botman 🚀")

        bot.run()
    """

    BASE_URL = "https://api.telegram.org/bot{token}/{method}"

    def __init__(
        self,
        token: str,
        workers: int = 10,
        timeout: int = 30,
        parse_mode: str = "HTML",
    ):
        self.token = token
        self.workers = workers
        self.timeout = timeout
        self.parse_mode = parse_mode
        self._handlers: Dict[str, List[Callable]] = {}
        self._commands: Dict[str, Callable] = {}
        self._middlewares: List[Callable] = []
        self._filters: Dict[str, Callable] = {}
        self._offset = 0
        self._running = False
        self._client: Optional[httpx.AsyncClient] = None
        self._semaphore = asyncio.Semaphore(workers)
        self._start_time = time.time()

        logging.basicConfig(
            format="%(asctime)s [ZEHNEX-PRO] %(levelname)s: %(message)s",
            level=logging.INFO,
        )

    # ─────────────────────────── Decorators ───────────────────────────

    def command(self, cmd: str, aliases: Optional[List[str]] = None):
        """Register a command handler."""
        def decorator(func: Callable):
            self._commands[cmd.lower()] = func
            if aliases:
                for alias in aliases:
                    self._commands[alias.lower()] = func
            return func
        return decorator

    def on(self, event: str, filter_func: Optional[Callable] = None):
        """Register an event handler (message, photo, video, document, etc.)."""
        def decorator(func: Callable):
            if event not in self._handlers:
                self._handlers[event] = []
            self._handlers[event].append((func, filter_func))
            return func
        return decorator

    def message(self, filter_func: Optional[Callable] = None):
        """Shortcut for @bot.on('message')."""
        return self.on("message", filter_func)

    def middleware(self, func: Callable):
        """Register middleware. Runs before every handler."""
        self._middlewares.append(func)
        return func

    # ─────────────────────────── API Methods ──────────────────────────

    async def _request(self, method: str, **kwargs) -> Dict:
        url = self.BASE_URL.format(token=self.token, method=method)
        try:
            response = await self._client.post(url, json=kwargs, timeout=self.timeout)
            data = response.json()
            if not data.get("ok"):
                logger.error(f"API Error [{method}]: {data.get('description')}")
            return data.get("result", {})
        except Exception as e:
            logger.error(f"Request error [{method}]: {e}")
            return {}

    async def send_message(
        self,
        chat_id: int,
        text: str,
        parse_mode: Optional[str] = None,
        reply_to: Optional[int] = None,
        keyboard=None,
        **kwargs,
    ) -> Dict:
        params = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode or self.parse_mode,
            **kwargs,
        }
        if reply_to:
            params["reply_to_message_id"] = reply_to
        if keyboard:
            params["reply_markup"] = keyboard
        return await self._request("sendMessage", **params)

    async def send_document(
        self,
        chat_id: int,
        document_path: str,
        caption: Optional[str] = None,
        parse_mode: Optional[str] = None,
        **kwargs,
    ) -> Dict:
        url = self.BASE_URL.format(token=self.token, method="sendDocument")
        params = {
            "chat_id": str(chat_id),
            "parse_mode": parse_mode or self.parse_mode,
        }
        if caption:
            params["caption"] = caption

        with open(document_path, "rb") as f:
            files = {"document": f}
            response = await self._client.post(
                url, data=params, files=files, timeout=60
            )
        return response.json().get("result", {})

    async def send_video(
        self,
        chat_id: int,
        video_path: str,
        caption: Optional[str] = None,
        **kwargs,
    ) -> Dict:
        url = self.BASE_URL.format(token=self.token, method="sendVideo")
        params = {"chat_id": str(chat_id)}
        if caption:
            params["caption"] = caption

        with open(video_path, "rb") as f:
            files = {"video": f}
            response = await self._client.post(
                url, data=params, files=files, timeout=120
            )
        return response.json().get("result", {})

    async def send_photo(
        self,
        chat_id: int,
        photo_path: str,
        caption: Optional[str] = None,
        **kwargs,
    ) -> Dict:
        url = self.BASE_URL.format(token=self.token, method="sendPhoto")
        params = {"chat_id": str(chat_id)}
        if caption:
            params["caption"] = caption

        with open(photo_path, "rb") as f:
            files = {"photo": f}
            response = await self._client.post(
                url, data=params, files=files, timeout=60
            )
        return response.json().get("result", {})

    async def send_chat_action(self, chat_id: int, action: str = "typing") -> Dict:
        return await self._request("sendChatAction", chat_id=chat_id, action=action)

    async def get_me(self) -> Dict:
        return await self._request("getMe")

    async def delete_message(self, chat_id: int, message_id: int) -> Dict:
        return await self._request(
            "deleteMessage", chat_id=chat_id, message_id=message_id
        )

    async def answer_callback_query(
        self, callback_query_id: str, text: Optional[str] = None, show_alert: bool = False
    ) -> Dict:
        return await self._request(
            "answerCallbackQuery",
            callback_query_id=callback_query_id,
            text=text or "",
            show_alert=show_alert,
        )

    # ─────────────────────────── Keyboards ────────────────────────────

    @staticmethod
    def inline_keyboard(buttons: List[List[Dict]]) -> Dict:
        """
        Build inline keyboard.
        
        Example:
            kb = bot.inline_keyboard([
                [{"text": "✅ Ha", "callback_data": "yes"}],
                [{"text": "❌ Yo'q", "callback_data": "no"}],
            ])
        """
        return {"inline_keyboard": buttons}

    @staticmethod
    def reply_keyboard(
        buttons: List[List[str]],
        resize: bool = True,
        one_time: bool = False,
    ) -> Dict:
        """Build reply keyboard."""
        return {
            "keyboard": [[{"text": btn} for btn in row] for row in buttons],
            "resize_keyboard": resize,
            "one_time_keyboard": one_time,
        }

    @staticmethod
    def remove_keyboard() -> Dict:
        return {"remove_keyboard": True}

    # ─────────────────────────── Polling ──────────────────────────────

    async def _get_updates(self) -> List[Dict]:
        result = await self._request(
            "getUpdates",
            offset=self._offset,
            timeout=25,
            limit=100,
            allowed_updates=["message", "callback_query", "inline_query"],
        )
        return result if isinstance(result, list) else []

    async def _process_update(self, update: Dict):
        async with self._semaphore:
            from zehnex_pro.context import Context

            update_id = update.get("update_id", 0)
            self._offset = max(self._offset, update_id + 1)

            # Run middlewares
            for mw in self._middlewares:
                try:
                    await mw(update)
                except Exception as e:
                    logger.error(f"Middleware error: {e}")

            ctx = Context(update=update, bot=self)

            # Command handling
            if "message" in update:
                msg = update["message"]
                text = msg.get("text", "")

                if text.startswith("/"):
                    parts = text[1:].split()
                    cmd = parts[0].lower().split("@")[0]
                    if cmd in self._commands:
                        try:
                            await self._commands[cmd](ctx)
                            return
                        except Exception as e:
                            logger.error(f"Command /{cmd} error: {e}")

                # Message handlers
                for handler, filter_func in self._handlers.get("message", []):
                    try:
                        if filter_func is None or await _run_filter(filter_func, ctx):
                            await handler(ctx)
                    except Exception as e:
                        logger.error(f"Handler error: {e}")

            # Callback query
            elif "callback_query" in update:
                for handler, filter_func in self._handlers.get("callback_query", []):
                    try:
                        if filter_func is None or await _run_filter(filter_func, ctx):
                            await handler(ctx)
                    except Exception as e:
                        logger.error(f"Callback handler error: {e}")

    async def _poll(self):
        logger.info("🚀 Zehnex-Pro polling started...")
        me = await self.get_me()
        logger.info(f"✅ Bot: @{me.get('username', 'unknown')} (id: {me.get('id')})")

        while self._running:
            try:
                updates = await self._get_updates()
                if updates:
                    tasks = [self._process_update(u) for u in updates]
                    await asyncio.gather(*tasks, return_exceptions=True)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Polling error: {e}")
                await asyncio.sleep(1)

    async def start(self):
        """Start the bot (async)."""
        self._running = True
        self._client = httpx.AsyncClient(
            limits=httpx.Limits(
                max_connections=100,
                max_keepalive_connections=50,
            )
        )
        await self._poll()

    async def stop(self):
        """Stop the bot gracefully."""
        self._running = False
        if self._client:
            await self._client.aclose()
        logger.info("🛑 Zehnex-Pro bot stopped.")

    def run(self):
        """Run the bot (blocking, sync entry point)."""
        try:
            asyncio.run(self.start())
        except KeyboardInterrupt:
            logger.info("Bot stopped by user.")

    @property
    def uptime(self) -> float:
        """Bot uptime in seconds."""
        return time.time() - self._start_time


async def _run_filter(filter_func: Callable, ctx: Any) -> bool:
    if asyncio.iscoroutinefunction(filter_func):
        return await filter_func(ctx)
    return filter_func(ctx)
