import os
import sys
from pathlib import Path

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT / "paegents"))

from escrow_signing import (  # noqa: E402
    build_bilateral_agreement_signatures,
    validate_amount,
    verify_calldata_selector,
)


def test_validate_amount_mismatch_raises():
    with pytest.raises(ValueError, match="Amount mismatch"):
        validate_amount(
            {"service_amount_atomic": 1},
            quantity=100,
            price_per_unit_cents=10,
        )


def test_verify_calldata_selector_recognizes_known_selector():
    fn_name = verify_calldata_selector("0x379607f500000000")
    assert fn_name == "sellerClaim(uint256)"


def test_build_signatures_enforces_amount_validation_before_signing():
    with pytest.raises(ValueError, match="Amount mismatch"):
        build_bilateral_agreement_signatures(
            buyer_private_key="0x" + "11" * 32,
            deposit_params={
                "agreement_id": "agr_1",
                "chain_id": 84532,
                "usdc_address": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
                "escrow_contract_address": "0x1111111111111111111111111111111111111111",
                "service_amount_atomic": 1,
            },
            quantity=100,
            price_per_unit_cents=10,
            permit_deadline=4_102_444_800,  # 2100-01-01
            deposit_auth_deadline=4_102_444_800,
            usdc_permit_nonce=0,
        )
