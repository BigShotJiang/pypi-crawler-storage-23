# Paegents Python SDK
from .agent_payments import (
    # Main SDK class
    AgentPaymentsSDK,

    # Legacy MCP models
    PaymentRequest,
    PaymentResponse,
    RecipientSearchResult,
    Receipt,
    SpendingLimits,

    # A2A Protocol models
    A2APaymentRequest,
    A2APaymentResponse,
    A2AStatusQuery,
    A2AStatusResponse,

    # AP2 / x402 helpers
    IntentMandate,
    CartMandate,
    AP2PaymentResult,
    PaymentMethodPayload,
    build_card_payment_method,
    build_braintree_payment_method,
    build_stablecoin_payment_method,  # For AP2 direct payments only (not agreements)

    # Bilateral escrow types
    EscrowStatusResponse,
    DepositParamsResponse,
    RefreshPermitRequest,
    ClaimInstructionsResponse,
    InitiateCloseCalldataResponse,
    TransactionCalldata,
    CallProofItem,
    CallProofResponse,
    CumulativeReceiptItem,
    CumulativeReceiptResponse,
    EscrowEventType,

    # Settlement polling utility
    poll_settlement_status,

    # Errors
    ApiError,
    PolicyDeniedError,
)

# Expose x402 signing for AP2 direct payments
from .x402_signing import create_signed_x402_payment

# Expose escrow signing for bilateral agreements
from .escrow_signing import (
    sign_usdc_permit,
    sign_deposit_authorization,
    sign_infra_fee_permit,
    build_bilateral_agreement_signatures,
    verify_calldata_selector,
    validate_chain_id,
    validate_deadline,
    validate_amount,
    CHAIN_CONFIG,
)

__version__ = "2.7.0"
__author__ = "Paegents Inc"
__email__ = "support@paegents.com"

# Convenience alias
PaegentsSDK = AgentPaymentsSDK

__all__ = [
    "AgentPaymentsSDK",
    "PaegentsSDK",
    "PaymentRequest",
    "PaymentResponse",
    "RecipientSearchResult",
    "Receipt",
    "SpendingLimits",
    "A2APaymentRequest",
    "A2APaymentResponse",
    "A2AStatusQuery",
    "A2AStatusResponse",
    "IntentMandate",
    "CartMandate",
    "AP2PaymentResult",
    "PaymentMethodPayload",
    "build_card_payment_method",
    "build_braintree_payment_method",
    "build_stablecoin_payment_method",
    "create_signed_x402_payment",
    # Bilateral escrow
    "EscrowStatusResponse",
    "DepositParamsResponse",
    "RefreshPermitRequest",
    "ClaimInstructionsResponse",
    "InitiateCloseCalldataResponse",
    "TransactionCalldata",
    "CallProofItem",
    "CallProofResponse",
    "CumulativeReceiptItem",
    "CumulativeReceiptResponse",
    "EscrowEventType",
    "sign_usdc_permit",
    "sign_deposit_authorization",
    "sign_infra_fee_permit",
    "build_bilateral_agreement_signatures",
    "verify_calldata_selector",
    "validate_chain_id",
    "validate_deadline",
    "validate_amount",
    "CHAIN_CONFIG",
    "poll_settlement_status",
    # Errors
    "ApiError",
    "PolicyDeniedError",
]
