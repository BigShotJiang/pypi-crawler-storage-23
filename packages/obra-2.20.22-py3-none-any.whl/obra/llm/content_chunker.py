"""Content chunking for LLM context management.

This module provides ContentChunker, which handles content truncation
based on model context windows and configurable safety margins.

The chunker derives maximum character limits from:
1. Model context window (from model registry)
2. Safety margin (configurable, default 80%)
3. Chars-per-token estimate (configurable, default 4)

Example:
    >>> from obra.llm.content_chunker import ContentChunker
    >>> chunker = ContentChunker(model="sonnet", provider="anthropic")
    >>> truncated = chunker.truncate(large_content)

Related:
    - obra/model_registry.py (context window data)
    - obra/config/default_config.yaml (orchestration.content)
    - CHORE-MAGIC-VALUES-001 Story 2
"""

import logging
from typing import Any

from obra.config.loaders import load_layered_config
from obra.model_registry import MODEL_REGISTRY, get_model_info

logger = logging.getLogger(__name__)

# Default context window when model info unavailable
DEFAULT_CONTEXT_WINDOW = 200_000


class ContentChunker:
    """Content chunker that respects model context windows.

    Calculates maximum content size based on model context window,
    safety margin, and chars-per-token estimate. Provides truncation
    with optional preservation of content start and end.

    Attributes:
        model: Model identifier
        provider: LLM provider name (optional, searches all if not provided)
        context_window: Model's context window in tokens
        max_tokens: Maximum tokens for content (context_window * safety_margin)
        max_chars: Maximum characters for content (max_tokens * chars_per_token)

    Example:
        >>> chunker = ContentChunker(model="sonnet", provider="anthropic")
        >>> # Long content gets truncated with preserved ends
        >>> result = chunker.truncate(very_long_string)
        >>> len(result) <= chunker.max_chars
        True
    """

    def __init__(
        self,
        model: str,
        provider: str | None = None,
    ) -> None:
        """Initialize ContentChunker with model and optional provider.

        Args:
            model: Model identifier (e.g., "sonnet", "claude-sonnet-4-5")
            provider: Optional provider name (e.g., "anthropic"). If not
                provided, searches all providers for the model.
        """
        self.model = model
        self.provider = provider

        # Load content config
        config, _, _ = load_layered_config()
        content_config: dict[str, Any] = config.get("orchestration", {}).get("content", {})

        # Read configurable parameters
        self.safety_margin: float = content_config.get("safety_margin", 0.8)
        self.chars_per_token: int = content_config.get("chars_per_token", 4)
        self.preserve_ends_default: bool = content_config.get("preserve_ends", True)

        # Get context window from model registry
        self.context_window = self._get_context_window()

        # Calculate limits
        self.max_tokens = int(self.context_window * self.safety_margin)
        self.max_chars = self.max_tokens * self.chars_per_token

        logger.debug(
            f"ContentChunker initialized: model={model}, provider={provider}, "
            f"context_window={self.context_window}, max_chars={self.max_chars}"
        )

    def _get_context_window(self) -> int:
        """Get context window for the model.

        If provider is specified, looks up directly. Otherwise searches
        all providers for the model.

        Returns:
            Context window in tokens, or DEFAULT_CONTEXT_WINDOW if not found.
        """
        # If provider specified, direct lookup
        if self.provider:
            model_info = get_model_info(self.provider, self.model)
            if model_info and model_info.context_window:
                return model_info.context_window

        # Search all providers for the model
        for provider_name in MODEL_REGISTRY:
            model_info = get_model_info(provider_name, self.model)
            if model_info and model_info.context_window:
                # Update provider for future reference
                self.provider = provider_name
                return model_info.context_window

        logger.warning(
            f"Model '{self.model}' not found in registry, "
            f"using default context window: {DEFAULT_CONTEXT_WINDOW}"
        )
        return DEFAULT_CONTEXT_WINDOW

    def truncate(
        self,
        content: str,
        preserve_ends: bool | None = None,
    ) -> str:
        """Truncate content to fit within max_chars limit.

        Args:
            content: Content to potentially truncate
            preserve_ends: If True, keeps start and end of content with
                truncation marker in middle. If False, truncates from end.
                Defaults to instance's preserve_ends_default.

        Returns:
            Original content if within limits, otherwise truncated content
            with appropriate marker indicating truncation.

        Example:
            >>> chunker = ContentChunker(model="sonnet", provider="anthropic")
            >>> # Short content unchanged
            >>> chunker.truncate("hello") == "hello"
            True
            >>> # Long content truncated with preserved ends
            >>> result = chunker.truncate("x" * 1000000, preserve_ends=True)
            >>> "[... truncated" in result
            True
        """
        if len(content) <= self.max_chars:
            return content

        # Determine preserve_ends behavior
        use_preserve_ends = (
            preserve_ends if preserve_ends is not None else self.preserve_ends_default
        )

        truncated_chars = len(content) - self.max_chars

        if use_preserve_ends:
            # Split at half, preserve start and end
            half = self.max_chars // 2
            return (
                f"{content[:half]}\n\n"
                f"[... truncated {truncated_chars} chars ...]\n\n"
                f"{content[-half:]}"
            )

        # Simple truncation from end
        return content[: self.max_chars] + "\n... (truncated)"
