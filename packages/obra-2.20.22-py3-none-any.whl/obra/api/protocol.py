"""Shared protocol types for the Hybrid Architecture.

This module is kept byte-for-byte in sync between:
- functions/src/orchestration/protocol.py
- obra/api/protocol.py

Protocol Design (from PRD Section 1):
    - Server owns the brain (decisions, orchestration logic)
    - Client owns the hands (execution, code access)

Message Flow:
    Client -> Server: SessionStart, DerivedPlan, ExaminationReport,
                     RevisedPlan, ExecutionResult, AgentReport, FixResult, UserDecision
    Server -> Client: DeriveRequest, IntentRequest, ExamineRequest, RevisionRequest,
                     ExecutionRequest, ReviewRequest, FixRequest, EscalationNotice,
                     CompletionNotice, Story0Request

Phase Flow:
    DERIVATION -> STORY0 (always) -> EXECUTION

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - functions/src/orchestration/coordinator.py
    - functions/src/state/session_schema.py
"""

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from functools import lru_cache
from importlib import resources
from pathlib import Path
from typing import Any, TypeVar

logger = logging.getLogger(__name__)

# =============================================================================
# Safe Enum Parsing (Forward Compatibility)
# =============================================================================

E = TypeVar("E", bound=Enum)


def safe_enum_parse(enum_class: type[E], value: str | None, default: E) -> E:
    """Safely parse an enum value with fallback for unknown values.

    This provides forward compatibility when the server sends enum values
    that the client doesn't recognize (e.g., new escalation reasons added
    to server before client is updated).

    Args:
        enum_class: The enum class to parse into
        value: The string value to parse (may be None or unknown)
        default: Default value to return if parsing fails

    Returns:
        Parsed enum value, or default if value is None/unknown

    Example:
        reason = safe_enum_parse(EscalationReason, "new_reason", EscalationReason.UNKNOWN)
    """
    if value is None:
        return default
    try:
        return enum_class(value)
    except ValueError:
        logger.warning(
            "Unknown %s value '%s', using fallback '%s'. "
            "Consider upgrading obra: pip install --upgrade obra",
            enum_class.__name__,
            value,
            default.value,
        )
        return default


# =============================================================================
# Enums
# =============================================================================


class ActionType(str, Enum):
    """Server action types (server instructs client)."""

    DERIVE = "derive"  # Derive plan from objective
    INTENT = "intent"  # Generate and enrich intent before derivation
    STORY0 = "story0"  # STORY0: Environment preparation phase (always after DERIVE)
    EXAMINE = "examine"  # Examine current plan
    REVISE = "revise"  # Revise plan based on issues
    EXECUTE = "execute"  # Execute plan item
    REVIEW = "review"  # Run review agents
    VALIDATOR = "validator"  # Execute validator request (FEAT-SENSECHECK-PIPELINE-001)
    FIX = "fix"  # Fix issues found in review
    PIPELINE_STAGE = "pipeline_stage"  # Run custom pipeline stage (FEAT-PIPELINE-001)
    COMPLETE = "complete"  # Session complete
    STORY_PREFLIGHT = "story_preflight"  # Pre-story verification and refinement
    ESCALATE = "escalate"  # Escalate to human
    WAIT = "wait"  # Wait for async operation
    ERROR = "error"  # Error occurred
    UNKNOWN = "unknown"  # Forward compatibility: unrecognized action from newer server


class SessionPhase(str, Enum):
    """Current phase of the orchestration session.

    Note: COMPLETED is a terminal phase set when sessions reach terminal states
    (completed, escalated, abandoned, expired). Added to fix ISSUE-SAAS-045.
    STORY0: Environment preparation phase - installs deps, configures services.
    ALWAYS runs after DERIVE, even when no prerequisites (emits validation message).
    """

    DERIVATION = "derivation"
    STORY0 = "story0"
    REFINEMENT = "refinement"
    EXECUTION = "execution"
    REVIEW = "review"
    COMPLETED = "completed"  # ISSUE-SAAS-045: Terminal phase
    UNKNOWN = "unknown"  # Forward compatibility


class SessionStatus(str, Enum):
    """Session status values."""

    ACTIVE = "active"
    COMPLETED = "completed"
    ESCALATED = "escalated"
    ABANDONED = "abandoned"
    EXPIRED = "expired"
    FAILED = "failed"  # ISSUE-006: Crashed sessions, resumable for retry
    UNKNOWN = "unknown"  # Forward compatibility


class Priority(str, Enum):
    """Priority classification for issues."""

    P0 = "P0"  # Critical - blocks execution
    P1 = "P1"  # High - should be fixed
    P2 = "P2"  # Medium - nice to fix
    P3 = "P3"  # Low - informational


class ExecutionStatus(str, Enum):
    """Status of plan item execution."""

    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"


class AgentType(str, Enum):
    """Types of review agents."""

    SECURITY = "security"
    TESTING = "testing"
    DOCS = "docs"
    CODE_QUALITY = "code_quality"
    TEST_EXECUTION = "test_execution"
    SENSE_CHECK = "sense_check"
    CODE_VERIFY = "code_verify"


DEFAULT_REVIEW_AGENTS = [
    agent.value for agent in AgentType if agent != AgentType.CODE_VERIFY
]

# Conservative fallback used when server review agent selection is missing
# (for example during legacy resume recovery payloads).
DEFAULT_REPORT_REVIEW_AGENT_TYPES = [
    AgentType.SECURITY.value,
    AgentType.TESTING.value,
    AgentType.DOCS.value,
    AgentType.CODE_QUALITY.value,
    AgentType.TEST_EXECUTION.value,
]


class EscalationReason(str, Enum):
    """Reasons for escalation."""

    BLOCKED = "blocked"
    EXECUTION_FAILURE = (
        "execution_failure"  # Server sends when execution fails (ISSUE-SAAS-050)
    )
    MAX_ITERATIONS = "max_iterations"
    MAX_REFINEMENT_ITERATIONS = "max_refinement_iterations"  # ISSUE-CLI-019: Server sends when refinement hits max iterations
    OSCILLATION = "oscillation"
    CONVERGENCE_STALLED = "convergence_stalled"
    BLOCKING_ISSUES_UNRESOLVED = "blocking_issues_unresolved"
    PENDING_HUMAN_REVIEW = "pending_human_review"  # ISSUE-CLI-019: Server sends when human review requested
    QUALITY_THRESHOLD_NOT_MET = "quality_threshold_not_met"  # ISSUE-CLI-019: Server sends when quality score fails
    USER_REQUESTED = "user_requested"
    UNKNOWN = "unknown"  # Forward compatibility: unrecognized reason from newer server


class UserDecisionChoice(str, Enum):
    """User decision options during escalation."""

    FORCE_COMPLETE = "force_complete"
    CONTINUE_FIXING = "continue_fixing"
    SKIP_ISSUES = "skip_issues"
    ABANDON = "abandon"


# =============================================================================
# Server -> Client Message Types
# =============================================================================


@dataclass
class ServerAction:
    """Action instruction from server to client.

    This is the base response type from the server. The `action` field
    determines what the client should do next, and `payload` contains
    action-specific data.

    Attributes:
        action: Action type to perform
        session_id: Session identifier
        iteration: Current iteration number
        payload: Action-specific data
        metadata: Additional metadata
        bypass_modes_active: List of active bypass modes (for warnings)
        error_code: Error code if action is ERROR
        error_message: Error message if action is ERROR
    """

    action: ActionType
    session_id: str
    iteration: int = 0
    payload: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    bypass_modes_active: list[str] = field(default_factory=list)
    error_code: str | None = None
    error_message: str | None = None
    timestamp: str | None = None
    rationale: str | None = (
        None  # ISSUE-SAAS-023: Server may include rationale for action
    )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ServerAction":
        """Create from API response dictionary with Pydantic validation.

        Uses safe enum parsing for forward compatibility - unknown action types
        from newer servers will be mapped to ActionType.UNKNOWN instead of
        raising an error.

        Args:
            data: Dictionary containing server action data

        Returns:
            ServerAction instance with validated fields

        Raises:
            ValueError: If validation fails due to missing required fields or type mismatches
        """
        from pydantic import ValidationError

        from obra.api.schemas import ServerActionSchema

        try:
            # Validate with Pydantic schema first
            validated = ServerActionSchema(**data)

            # Convert validated data to ServerAction dataclass
            # Use safe_enum_parse for forward compatibility with new action types
            return cls(
                action=safe_enum_parse(
                    ActionType, validated.action, ActionType.UNKNOWN
                ),
                session_id=validated.session_id,
                iteration=validated.iteration,
                payload=validated.payload,
                metadata=validated.metadata,
                bypass_modes_active=validated.bypass_modes_active,
                error_code=validated.error_code,
                error_message=validated.error_message,
                timestamp=validated.timestamp,
                rationale=validated.rationale,  # ISSUE-SAAS-023
            )
        except ValidationError as e:
            # Re-raise with detailed error information
            error_details = "; ".join(
                [f"{err['loc'][0]}: {err['msg']}" for err in e.errors()]
            )
            raise ValueError(f"ServerAction validation failed: {error_details}") from e
        except KeyError as e:
            # Handle missing required fields
            raise ValueError(f"ServerAction validation failed: {e!s}") from e

    def is_error(self) -> bool:
        """Check if this is an error action."""
        return self.action == ActionType.ERROR or self.error_code is not None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API response format."""

        ts = self.timestamp or datetime.now(UTC).isoformat()
        result = {
            "action": self.action.value,
            "session_id": self.session_id,
            "iteration": self.iteration,
            "payload": self.payload,
            "metadata": self.metadata,
            "bypass_modes_active": self.bypass_modes_active,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "timestamp": ts,
        }
        # ISSUE-SAAS-023: Only include rationale if present
        if self.rationale is not None:
            result["rationale"] = self.rationale
        return result


@dataclass
class DeriveRequest:
    """Request to derive a plan from objective.

    Sent by server after SessionStart to instruct client
    to derive an implementation plan.

    Attributes:
        objective: Task objective to plan for
        userplan_id: Required UserPlan ID that this derivation is for
        userplan_version: Required version of UserPlan used for derivation
        userplan_steps: Optional UserPlan step metadata for source linkage
        project_context: Project context (languages, frameworks, etc.)
        llm_provider: LLM provider to use
        constraints: Derivation constraints
        plan_items_reference: Plan items to preserve from previous derivation (for --from-step)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
        complexity_score: Pre-computed complexity score for exploration triggers (ADR-055)
        skip_story0: If True, skip Story 0 derivation step (debug/re-derive)
        intent_ready: If True, intent was pre-validated and should be loaded from storage
    """

    objective: str
    userplan_id: str  # Required: UserPlan ID for derivation linkage
    userplan_version: int  # Required: Version of UserPlan used for derivation
    userplan_steps: list[dict[str, Any]] = field(default_factory=list)
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    constraints: dict[str, Any] = field(default_factory=dict)
    plan_items_reference: list[dict[str, Any]] = field(default_factory=list)
    base_prompt: str | None = None
    from_step: int | None = None  # Re-derive from step N, preserving steps 1 to N-1
    complexity_score: float | None = None  # Pre-computed complexity score (ADR-055)
    skip_story0: bool = False  # If True, skip Story 0 derivation step
    intent_ready: bool = False  # If True, intent pre-validated; load from storage

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "DeriveRequest":
        """Create from ServerAction payload.

        Raises:
            ValueError: If userplan_id is missing from the payload
            ValueError: If userplan_version is missing from the payload
        """
        userplan_id = payload.get("userplan_id")
        if not userplan_id:
            raise ValueError("userplan_id is required for derivation")
        userplan_version = payload.get("userplan_version")
        if userplan_version is None:
            raise ValueError("userplan_version is required for derivation")
        return cls(
            objective=payload.get("objective", ""),
            userplan_id=userplan_id,
            userplan_version=int(userplan_version),
            userplan_steps=payload.get("userplan_steps", []),
            project_context=payload.get("project_context", {}),
            llm_provider=payload.get("llm_provider", "anthropic"),
            constraints=payload.get("constraints", {}),
            plan_items_reference=payload.get("plan_items_reference", []),
            base_prompt=payload.get("base_prompt"),
            from_step=payload.get("from_step"),
            complexity_score=payload.get("complexity_score"),
            skip_story0=bool(payload.get("skip_story0", False)),
            intent_ready=bool(payload.get("intent_ready", False)),
        )


@dataclass
class IntentRequest:
    """Request to generate and enrich intent before derivation.

    Sent by server when intent validation is enabled, to collect enriched
    intent content for SenseCheck validation prior to derivation.

    Attributes:
        objective: Task objective to derive intent for
        userplan_id: Required UserPlan ID that this intent is for
        userplan_version: Required version of UserPlan used for intent generation
        project_context: Project context (languages, frameworks, etc.)
        llm_provider: LLM provider to use
        from_step: Optional re-derivation start step for context
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
    """

    objective: str
    userplan_id: str
    userplan_version: int
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    from_step: int | None = None
    base_prompt: str | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "IntentRequest":
        """Create from ServerAction payload.

        Raises:
            ValueError: If userplan_id is missing from the payload
            ValueError: If userplan_version is missing from the payload
        """
        userplan_id = payload.get("userplan_id")
        if not userplan_id:
            raise ValueError("userplan_id is required for intent generation")
        userplan_version = payload.get("userplan_version")
        if userplan_version is None:
            raise ValueError("userplan_version is required for intent generation")
        return cls(
            objective=payload.get("objective", ""),
            userplan_id=userplan_id,
            userplan_version=int(userplan_version),
            project_context=payload.get("project_context", {}),
            llm_provider=payload.get("llm_provider", "anthropic"),
            from_step=payload.get("from_step"),
            base_prompt=payload.get("base_prompt"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "objective": self.objective,
            "userplan_id": self.userplan_id,
            "userplan_version": self.userplan_version,
            "project_context": self.project_context,
            "llm_provider": self.llm_provider,
        }
        if self.from_step is not None:
            data["from_step"] = self.from_step
        if self.base_prompt is not None:
            data["base_prompt"] = self.base_prompt
        return data


@dataclass
class ExamineRequest:
    """Request to examine the current plan.

    Sent by server after DerivedPlan or RevisedPlan to instruct
    client to examine the plan using LLM.

    Attributes:
        plan_version_id: Version ID of plan to examine
        plan_items: Plan items to examine
        all_plan_item_ids: Optional full plan item ID list for cross-batch dependency checks
        thinking_required: Whether extended thinking is required
        thinking_level: Thinking level (standard, high, max)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        iteration: Current refinement cycle number (None if not in a cycle)
        max_iterations: Maximum refinement iterations allowed (None if unbounded)
    """

    plan_version_id: str
    plan_items: list[dict[str, Any]]
    thinking_required: bool = True
    thinking_level: str = "standard"
    base_prompt: str | None = None
    iteration: int | None = None
    max_iterations: int | None = None
    all_plan_item_ids: list[str] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ExamineRequest":
        """Create from ServerAction payload."""
        raw_all_plan_item_ids = payload.get("all_plan_item_ids")
        all_plan_item_ids = None
        if isinstance(raw_all_plan_item_ids, list):
            normalized_ids = [
                str(item_id).strip()
                for item_id in raw_all_plan_item_ids
                if str(item_id).strip()
            ]
            all_plan_item_ids = normalized_ids or None
        return cls(
            plan_version_id=payload.get("plan_version_id", ""),
            plan_items=payload.get("plan_items", []),
            thinking_required=payload.get("thinking_required", True),
            thinking_level=payload.get("thinking_level", "standard"),
            base_prompt=payload.get("base_prompt"),
            iteration=payload.get("iteration"),
            max_iterations=payload.get("max_iterations"),
            all_plan_item_ids=all_plan_item_ids,
        )


@dataclass
class RevisionRequest:
    """Request to revise the plan based on issues.

    Sent by server after ExaminationReport when blocking issues found.

    Attributes:
        issues: All issues from examination
        blocking_issues: Issues that must be addressed
        current_plan_version_id: Current plan version ID
        focus_areas: Areas to focus revision on
        batch_index: Zero-based revision batch index for batched revise flows
        total_batches: Total revision batches in current revise flow
        batches_remaining: Number of remaining batches after current batch
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        proposed_defaults: Proposed defaults to unblock P1 issues (optional)
        userplan_id: Optional UserPlan ID for source_step_id fallbacks
    """

    issues: list[dict[str, Any]]
    blocking_issues: list[dict[str, Any]]
    current_plan_version_id: str = ""
    focus_areas: list[str] = field(default_factory=list)
    batch_index: int = 0
    total_batches: int = 0
    batches_remaining: int = 0
    base_prompt: str | None = None
    proposed_defaults: list[dict[str, Any]] | None = None
    userplan_id: str | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "RevisionRequest":
        """Create from ServerAction payload."""
        return cls(
            issues=payload.get("issues", []),
            blocking_issues=payload.get("blocking_issues", []),
            current_plan_version_id=payload.get("current_plan_version_id", ""),
            focus_areas=payload.get("focus_areas", []),
            batch_index=int(payload.get("batch_index", 0) or 0),
            total_batches=int(payload.get("total_batches", 0) or 0),
            batches_remaining=int(payload.get("batches_remaining", 0) or 0),
            base_prompt=payload.get("base_prompt"),
            proposed_defaults=payload.get("proposed_defaults"),
            userplan_id=payload.get("userplan_id"),
        )


@dataclass
class ExecutionRequest:
    """Request to execute a plan item.

    Sent by server when plan passes examination.

    Attributes:
        plan_items: All plan items
        execution_index: Index of item to execute
        current_item: The specific item to execute
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        execution_context: Server-supplied context for deduplication (Issue #6)
    """

    plan_items: list[dict[str, Any]]
    execution_index: int = 0
    current_item: dict[str, Any] | None = None
    base_prompt: str | None = None
    execution_context: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ExecutionRequest":
        """Create from ServerAction payload."""
        plan_items = payload.get("plan_items", [])
        execution_index = payload.get("execution_index", 0)
        current_item = None
        if plan_items and not (0 <= execution_index < len(plan_items)):
            # Defensive fallback for partial plan payloads.
            execution_index = 0
        if plan_items and 0 <= execution_index < len(plan_items):
            current_item = plan_items[execution_index]
        return cls(
            plan_items=plan_items,
            execution_index=execution_index,
            current_item=current_item,
            base_prompt=payload.get("base_prompt"),
            execution_context=payload.get("execution_context"),
        )


@dataclass
class ReviewRequest:
    """Request to run review agents on executed item.

    Sent by server after ExecutionResult.

    Attributes:
        item_id: Plan item ID that was executed
        agents_to_run: Optional list of agent types to run; defaults to
            report-review compatible baseline when missing/None/empty
        agent_budgets: Timeout/weight budgets per agent
        format: Optional output format (e.g., text, json)
        fail_on: Optional fail-fast threshold (e.g., p1, p2)
        complexity: Optional complexity tier provided by the server (simple|medium|complex)
        tests_required: Whether coverage gaps should be treated as blocking
        review_cycle_id: Optional review cycle identifier for event correlation
        diagnostic: Optional review-routing diagnostic message from server
        execution_status: Optional execution status context from prior action
        changed_files: Optional execution-scoped file paths for focused review
    """

    item_id: str
    agents_to_run: list[str] | None = None
    agent_budgets: dict[str, dict[str, Any]] = field(default_factory=dict)
    format: str | None = None
    fail_on: str | None = None
    complexity: str | None = None
    tests_required: bool = False
    review_cycle_id: str | None = None
    diagnostic: str | None = None
    execution_status: str | None = None
    changed_files: list[str] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ReviewRequest":
        """Create from ServerAction payload."""
        agents = payload.get("agents_to_run")
        if not agents:
            agents = payload.get("review_agents")

        agents_to_run = DEFAULT_REPORT_REVIEW_AGENT_TYPES.copy()
        if isinstance(agents, list) and agents:
            agents_to_run = agents

        complexity_value = payload.get("complexity")
        complexity = str(complexity_value) if complexity_value is not None else None
        return cls(
            item_id=payload.get("item_id", ""),
            agents_to_run=agents_to_run,
            agent_budgets=payload.get("agent_budgets", {}),
            format=payload.get("format"),
            fail_on=payload.get("fail_on"),
            complexity=complexity,
            tests_required=bool(payload.get("tests_required", False)),
            review_cycle_id=(
                str(payload.get("review_cycle_id"))
                if payload.get("review_cycle_id") is not None
                else None
            ),
            diagnostic=payload.get("diagnostic"),
            execution_status=(
                str(payload.get("execution_status"))
                if payload.get("execution_status") is not None
                else None
            ),
            changed_files=payload.get("changed_files"),
        )


@dataclass
class FixRequest:
    """Request to fix issues found during review.

    Sent by server after AgentReport when issues need fixing.

    Attributes:
        issues_to_fix: List of issues to fix (may be strings or dicts)
        execution_order: Order to fix issues (by ID)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        item_id: Plan item ID being fixed (ISSUE-SAAS-021)
        issue_details: Full issue dicts with priority info (FIX-PRIORITY-LOSS-001)
        issue_details may include test-gap metadata (issue_type, target_test_file,
        target_paths, test_name, arrange/act/assert) to guide test-focused fixes.
        fix_history: Optional summary of previous fix attempts
        fresh_fix: Whether this request is a guarded convergence fresh-fix pass
    """

    issues_to_fix: list[dict[str, Any]]
    execution_order: list[str] = field(default_factory=list)
    base_prompt: str | None = None
    item_id: str = ""  # ISSUE-SAAS-021: Track item for fix-review loop
    issue_details: list[dict[str, Any]] = field(
        default_factory=list
    )  # FIX-PRIORITY-LOSS-001
    fix_history: str | None = None
    fresh_fix: bool = False

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "FixRequest":
        """Create from ServerAction payload."""
        return cls(
            issues_to_fix=payload.get("issues_to_fix", []),
            execution_order=payload.get("execution_order", []),
            base_prompt=payload.get("base_prompt"),
            item_id=payload.get("item_id", ""),  # ISSUE-SAAS-021
            issue_details=payload.get("issue_details", []),  # FIX-PRIORITY-LOSS-001
            fix_history=payload.get("fix_history"),
            fresh_fix=bool(payload.get("fresh_fix", False)),
        )


# =============================================================================
# Validator Messages (FEAT-SENSECHECK-PIPELINE-001)
# =============================================================================


VALIDATOR_STAGES = {"intent", "plan", "review_filter", "code", "code_verify"}
VALIDATOR_SUBJECT_TYPES = {"intent", "plan_items", "agent_reports", "code_delta"}
_VALIDATOR_SCHEMA_REL_PATH = "schemas/validator_payload.schema.json"
_VALIDATOR_SCHEMA_PACKAGES = ("src.config", "obra.config")


def _resolve_validator_schema_path() -> Path:
    attempted: list[str] = []
    for parent in Path(__file__).resolve().parents:
        candidates = (
            parent / "config" / "schemas" / "validator_payload.schema.json",
            parent / "src" / "config" / "schemas" / "validator_payload.schema.json",
            parent / "obra" / "config" / "schemas" / "validator_payload.schema.json",
        )
        for candidate in candidates:
            candidate_str = str(candidate)
            if candidate_str in attempted:
                continue
            attempted.append(candidate_str)
            if candidate.is_file():
                return candidate
    attempted_paths = ", ".join(attempted)
    raise FileNotFoundError(
        f"validator_payload.schema.json not found (attempted: {attempted_paths})"
    )


@lru_cache(maxsize=1)
def _load_validator_payload_schema() -> dict[str, Any]:
    package_errors: list[str] = []
    for package_name in _VALIDATOR_SCHEMA_PACKAGES:
        try:
            schema_path = resources.files(package_name).joinpath(
                _VALIDATOR_SCHEMA_REL_PATH
            )
            content = schema_path.read_text(encoding="utf-8")
            return json.loads(content) if content.strip() else {}
        except Exception as exc:
            package_errors.append(f"{package_name}: {exc}")

    logger.warning(
        "Failed to load validator schema from packaged resources (%s); "
        "falling back to filesystem lookup.",
        "; ".join(package_errors),
    )
    path = _resolve_validator_schema_path()
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _schema_type_matches(value: Any, expected_type: str) -> bool:
    if expected_type == "boolean":
        return isinstance(value, bool)
    if expected_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected_type == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "object":
        return isinstance(value, dict)
    if expected_type == "array":
        return isinstance(value, list)
    return True


def _validate_against_schema(
    value: Any, schema: dict[str, Any], path: str = "payload"
) -> tuple[bool, str]:
    expected_type = schema.get("type")
    if expected_type:
        types = expected_type if isinstance(expected_type, list) else [expected_type]
        if not any(_schema_type_matches(value, t) for t in types):
            return False, f"{path} must be of type {expected_type}"

    if "enum" in schema and value not in schema["enum"]:
        return False, f"{path} must be one of {schema['enum']}"

    if expected_type == "integer" and "minimum" in schema:
        minimum = schema.get("minimum")
        if isinstance(value, int) and not isinstance(value, bool) and value < minimum:
            return False, f"{path} must be >= {minimum}"

    if expected_type == "object":
        if not isinstance(value, dict):
            return False, f"{path} must be an object"
        required = schema.get("required", [])
        for field_name in required:
            if field_name not in value:
                return False, f"Missing required field: {field_name}"

        properties = schema.get("properties", {})
        for key, subschema in properties.items():
            if key in value:
                is_valid, error = _validate_against_schema(
                    value[key],
                    subschema,
                    path=f"{path}.{key}",
                )
                if not is_valid:
                    return False, error

        if schema.get("additionalProperties") is False:
            extra = set(value.keys()) - set(properties.keys())
            if extra:
                return False, f"Unexpected fields: {', '.join(sorted(extra))}"

    if expected_type == "array":
        if not isinstance(value, list):
            return False, f"{path} must be an array"
        items_schema = schema.get("items")
        if items_schema:
            for index, item in enumerate(value):
                is_valid, error = _validate_against_schema(
                    item,
                    items_schema,
                    path=f"{path}[{index}]",
                )
                if not is_valid:
                    return False, error

    return True, ""


def _validate_validator_schema(
    payload: dict[str, Any],
    schema_name: str,
) -> tuple[bool, str]:
    try:
        schema = _load_validator_payload_schema()
    except FileNotFoundError as exc:
        return False, str(exc)

    definitions = schema.get("$defs", {})
    definition = definitions.get(schema_name)
    if not isinstance(definition, dict):
        return False, f"Schema definition not found: {schema_name}"
    return _validate_against_schema(payload, definition)


@dataclass
class ValidatorRequest:
    """Request to execute a validator on the client.

    Sent by the server to request a validator run against a subject payload.

    Attributes:
        stage: Validation stage (intent, plan, review_filter, code)
        subject_type: Type of subject payload (intent, plan_items, agent_reports, code_delta)
        subject_payload: Payload to validate
        prompt_id: Prompt identifier for provenance
        prompt_version: Prompt version for provenance
        compiled_prompt: Fully compiled prompt text (server-owned)
        timeout_s: Timeout in seconds for validator execution
        config: Validator config (schema_validation, prompt_provenance, etc.)
    """

    stage: str
    subject_type: str
    subject_payload: dict[str, Any]
    prompt_id: str
    prompt_version: str
    compiled_prompt: str
    timeout_s: int
    config: dict[str, Any]

    @classmethod
    def from_payload(
        cls, payload: dict[str, Any], *, schema_validation: bool = True
    ) -> "ValidatorRequest":
        """Create from ServerAction payload with validation."""
        request = cls(
            stage=payload.get("stage", ""),
            subject_type=payload.get("subject_type", ""),
            subject_payload=payload.get("subject_payload", {}),
            prompt_id=payload.get("prompt_id", ""),
            prompt_version=payload.get("prompt_version", ""),
            compiled_prompt=payload.get("compiled_prompt", ""),
            timeout_s=payload.get("timeout_s", 30),
            config=payload.get("config", {}),
        )
        is_valid, error = validate_validator_request(
            request, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"ValidatorRequest validation failed: {error}")
        return request

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage": self.stage,
            "subject_type": self.subject_type,
            "subject_payload": self.subject_payload,
            "prompt_id": self.prompt_id,
            "prompt_version": self.prompt_version,
            "compiled_prompt": self.compiled_prompt,
            "timeout_s": self.timeout_s,
            "config": self.config,
        }


@dataclass
class ValidatorResult:
    """Result payload returned by a validator."""

    sound: bool
    issues: list[dict[str, Any]] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    decisions: list[dict[str, Any]] = field(default_factory=list)
    version: str = "v1"
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "sound": self.sound,
            "issues": self.issues,
            "constraints": self.constraints,
            "decisions": self.decisions,
            "version": self.version,
            "provenance": self.provenance,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any], *, schema_validation: bool = True
    ) -> "ValidatorResult":
        """Create from dictionary with validation."""
        result = cls(
            sound=bool(data.get("sound", False)),
            issues=data.get("issues", []),
            constraints=data.get("constraints", []),
            decisions=data.get("decisions", []),
            version=data.get("version", "v1"),
            provenance=data.get("provenance", {}),
        )
        is_valid, error = validate_validator_result(
            result, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"ValidatorResult validation failed: {error}")
        return result


@dataclass
class StoryPreflightResult:
    """Result payload returned by Story Pre-flight verification."""

    findings: list[dict[str, Any]] = field(default_factory=list)
    task_modifications: list[dict[str, Any]] = field(default_factory=list)
    sense_check: dict[str, Any] | None = None
    resolved_findings: list[dict[str, Any]] = field(default_factory=list)
    loop_metadata: dict[str, Any] = field(default_factory=dict)
    disposition: str = "PROCEED"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "findings": self.findings,
            "task_modifications": self.task_modifications,
            "sense_check": self.sense_check,
            "resolved_findings": self.resolved_findings,
            "loop_metadata": self.loop_metadata,
            "disposition": self.disposition,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StoryPreflightResult":
        """Create from dictionary with validation."""
        disposition = str(data.get("disposition", "PROCEED")).upper()
        allowed = {"PROCEED", "REVISE", "ESCALATE"}
        if disposition not in allowed:
            msg = (
                f"StoryPreflightResult disposition must be one of "
                f"{sorted(allowed)}, got {disposition!r}"
            )
            raise ValueError(msg)
        return cls(
            findings=data.get("findings", []),
            task_modifications=data.get("task_modifications", []),
            sense_check=data.get("sense_check"),
            resolved_findings=data.get("resolved_findings", []),
            loop_metadata=data.get("loop_metadata", {}),
            disposition=disposition,
        )


@dataclass
class StoryPreflightRequest:
    """Request to run story pre-flight verification and refinement.

    Sent by the server before entering execution for a story boundary.

    Attributes:
        story_item: Story-level item payload under evaluation
        plan_items: Full execution-plan items for context and dependency checks
        exploration_context: Optional exploration artifacts used by preflight checks
    """

    story_item: dict[str, Any] = field(default_factory=dict)
    plan_items: list[dict[str, Any]] = field(default_factory=list)
    exploration_context: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "StoryPreflightRequest":
        """Create from ServerAction payload."""
        raw_story_item = payload.get("story_item")
        raw_plan_items = payload.get("plan_items")
        raw_exploration_context = payload.get("exploration_context")
        return cls(
            story_item=raw_story_item if isinstance(raw_story_item, dict) else {},
            plan_items=raw_plan_items if isinstance(raw_plan_items, list) else [],
            exploration_context=(
                raw_exploration_context
                if isinstance(raw_exploration_context, dict)
                else None
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "story_item": self.story_item,
            "plan_items": self.plan_items,
        }
        if self.exploration_context is not None:
            data["exploration_context"] = self.exploration_context
        return data


def validate_validator_request(
    request: ValidatorRequest, *, schema_validation: bool = True
) -> tuple[bool, str]:
    """Validate a ValidatorRequest."""
    if not isinstance(request, ValidatorRequest):
        return False, "Request must be a ValidatorRequest"
    if not request.stage:
        return False, "Missing required field: stage"
    if request.stage not in VALIDATOR_STAGES:
        return False, f"Invalid stage: {request.stage}"
    if not request.subject_type:
        return False, "Missing required field: subject_type"
    if request.subject_type not in VALIDATOR_SUBJECT_TYPES:
        return False, f"Invalid subject_type: {request.subject_type}"
    if request.subject_payload is None:
        return False, "Missing required field: subject_payload"
    if not isinstance(request.subject_payload, dict):
        return False, "subject_payload must be a dict"
    if request.prompt_id is None:
        return False, "Missing required field: prompt_id"
    if request.prompt_version is None:
        return False, "Missing required field: prompt_version"
    if request.compiled_prompt is None:
        return False, "Missing required field: compiled_prompt"
    if request.timeout_s is None:
        return False, "Missing required field: timeout_s"
    if not isinstance(request.timeout_s, int):
        return False, "timeout_s must be an int"
    if request.config is None:
        return False, "Missing required field: config"
    if not isinstance(request.config, dict):
        return False, "config must be a dict"
    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            request.to_dict(), "validator_request"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""


def validate_validator_result(
    result: ValidatorResult, *, schema_validation: bool = True
) -> tuple[bool, str]:
    """Validate a ValidatorResult."""
    if not isinstance(result, ValidatorResult):
        return False, "Result must be a ValidatorResult"
    if not isinstance(result.sound, bool):
        return False, "sound must be a bool"
    if not isinstance(result.issues, list):
        return False, "issues must be a list"
    if not isinstance(result.constraints, list):
        return False, "constraints must be a list"
    if not isinstance(result.decisions, list):
        return False, "decisions must be a list"
    if not isinstance(result.provenance, dict):
        return False, "provenance must be a dict"
    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            result.to_dict(), "validator_result"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""


# =============================================================================
# Pipeline Stage Messages (FEAT-PIPELINE-001)
# =============================================================================


@dataclass
class PipelineStageRequest:
    """Request to run a custom pipeline stage.

    Sent by server when a custom stage trigger point is reached.
    The client executes the specified agent and returns results.

    Attributes:
        stage_name: Name of the stage from configuration
        trigger: Trigger point (after_intent, after_derivation, before_step, etc.)
        agent: Agent name/id to run (resolved via AgentRegistry)
        input_type: Type of input content (intent_document, derived_plan, etc.)
        content: Content to analyze (varies by input_type)
        iteration: Current iteration count (0-indexed, increments on re-validate)
        max_iterations: Maximum iterations before escalation
        timeout_s: Timeout for stage execution in seconds
    """

    stage_name: str
    trigger: str
    agent: str
    input_type: str
    content: dict[str, Any]
    iteration: int = 0
    max_iterations: int = 3
    timeout_s: int = 300

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "PipelineStageRequest":
        """Create from ServerAction payload."""
        return cls(
            stage_name=payload.get("stage_name", ""),
            trigger=payload.get("trigger", ""),
            agent=payload.get("agent", ""),
            input_type=payload.get("input_type", ""),
            content=payload.get("content", {}),
            iteration=payload.get("iteration", 0),
            max_iterations=payload.get("max_iterations", 3),
            timeout_s=payload.get("timeout_s", 300),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "trigger": self.trigger,
            "agent": self.agent,
            "input_type": self.input_type,
            "content": self.content,
            "iteration": self.iteration,
            "max_iterations": self.max_iterations,
            "timeout_s": self.timeout_s,
        }


@dataclass
class PipelineStageResult:
    """Result from a custom pipeline stage execution.

    Sent by client after executing a pipeline stage agent.
    Contains verdict and any issues found for routing decisions.

    Attributes:
        stage_name: Name of the stage that was executed
        verdict: Stage verdict (sound = no issues, issues = problems found)
        issues: List of issues found (empty if sound)
        iteration: Iteration that was executed
        duration_s: Execution time in seconds
    """

    stage_name: str
    verdict: str  # "sound" | "issues"
    issues: list[dict[str, Any]] = field(default_factory=list)
    iteration: int = 0
    duration_s: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "verdict": self.verdict,
            "issues": self.issues,
            "iteration": self.iteration,
            "duration_s": self.duration_s,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PipelineStageResult":
        """Create from dictionary."""
        return cls(
            stage_name=data.get("stage_name", ""),
            verdict=data.get("verdict", "sound"),
            issues=data.get("issues", []),
            iteration=data.get("iteration", 0),
            duration_s=data.get("duration_s", 0.0),
        )


@dataclass
class EscalationNotice:
    """Notice that session requires human intervention.

    Sent by server when max iterations reached or oscillation detected.

    Attributes:
        escalation_id: Unique escalation identifier
        reason: Reason for escalation
        reason_text: Human-readable escalation detail
        reason_code: Machine-readable escalation detail code
        invariant_errors: Structured invariant/integrity errors
        repair_attempt_history: Auto-repair attempt diagnostics
        blocking_issues: Issues causing escalation
        iteration_history: Summary of iterations
        options: Available user options
        convergence_diagnostic: Optional convergence guard context for user display
    """

    escalation_id: str
    reason: EscalationReason
    reason_text: str = ""
    reason_code: str = ""
    invariant_errors: list[str] = field(default_factory=list)
    repair_attempt_history: list[dict[str, Any]] = field(default_factory=list)
    blocking_issues: list[dict[str, Any]] = field(default_factory=list)
    iteration_history: list[dict[str, Any]] = field(default_factory=list)
    options: list[dict[str, Any]] = field(default_factory=list)
    convergence_diagnostic: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "EscalationNotice":
        """Create from ServerAction payload.

        Uses safe enum parsing for forward compatibility - unknown escalation
        reasons from newer servers will be mapped to EscalationReason.UNKNOWN.
        """
        raw_convergence_diagnostic = payload.get("convergence_diagnostic", {})
        raw_invariant_errors = payload.get("invariant_errors", [])
        raw_repair_attempt_history = payload.get("repair_attempt_history", [])
        return cls(
            escalation_id=payload.get("escalation_id", ""),
            reason=safe_enum_parse(
                EscalationReason,
                payload.get("reason"),
                EscalationReason.BLOCKED,
            ),
            reason_text=str(payload.get("reason_text", "") or ""),
            reason_code=str(payload.get("reason_code", "") or ""),
            invariant_errors=(
                raw_invariant_errors if isinstance(raw_invariant_errors, list) else []
            ),
            repair_attempt_history=(
                raw_repair_attempt_history
                if isinstance(raw_repair_attempt_history, list)
                else []
            ),
            blocking_issues=payload.get("blocking_issues", []),
            iteration_history=payload.get("iteration_history", []),
            options=payload.get("options", []),
            convergence_diagnostic=(
                raw_convergence_diagnostic
                if isinstance(raw_convergence_diagnostic, dict)
                else {}
            ),
        )


@dataclass
class CompletionNotice:
    """Notice that session has completed (success or escalation).

    Sent by server when all items executed/reviewed or session terminates.

    Attributes:
        session_summary: Summary of completed session
        items_completed: Number of items completed
        total_iterations: Total refinement iterations
        quality_score: Final quality score
        was_escalated: Whether session ended via escalation
        terminal_phase: Session phase when completion occurred
        plan_final: Final plan items (optional)
        objective: Original user objective
        work_summary: 2-3 bullet summary of work done
        duration_seconds: This invocation duration
        total_duration_seconds: Cumulative duration across invocations
        invocation_count: Number of run/resume calls
        files_created: List of files created
        files_modified: List of files modified
        git_branch: Current git branch
        git_commit_hash: Commit hash if committed
        termination_reason: Reason for non-success termination
        warnings: Any warnings to display
        epics_completed: Count of completed epics
        epics_total: Total epic count
        stories_completed: Count of completed stories
        stories_total: Total story count
        tasks_completed: Count of completed tasks
        tasks_total: Total task count

    Note:
        CompletionNotice is a distinct return type and does not carry an
        action field. Client code should handle it explicitly (e.g., via
        isinstance checks) rather than reading result.action.
    """

    session_summary: str = ""
    items_completed: int = 0
    total_iterations: int = 0
    quality_score: float = 0.0
    was_escalated: bool = False
    terminal_phase: str = ""
    plan_final: list[dict[str, Any]] = field(default_factory=list)
    # Enhanced closeout fields (FEAT-SESSION-CLOSEOUT-001)
    objective: str = ""
    work_summary: list[str] = field(default_factory=list)
    duration_seconds: float = 0.0
    total_duration_seconds: float = 0.0
    invocation_count: int = 1
    files_created: list[str] = field(default_factory=list)
    files_modified: list[str] = field(default_factory=list)
    git_branch: str = ""
    git_commit_hash: str = ""
    termination_reason: str = ""
    warnings: list[str] = field(default_factory=list)
    epics_completed: int = 0
    epics_total: int = 0
    stories_completed: int = 0
    stories_total: int = 0
    tasks_completed: int = 0
    tasks_total: int = 0

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "CompletionNotice":
        """Create from ServerAction payload."""
        summary = payload.get("session_summary", {})
        return cls(
            session_summary=summary.get("objective", ""),
            items_completed=summary.get("items_completed", 0),
            total_iterations=summary.get("total_iterations", 0),
            quality_score=summary.get("quality_score", 0.0),
            was_escalated=payload.get("was_escalated", False),
            terminal_phase=payload.get("terminal_phase", ""),
            plan_final=payload.get("plan_final", []),
            # Enhanced closeout fields
            objective=summary.get("objective", ""),
            work_summary=payload.get("work_summary", []),
            duration_seconds=payload.get("duration_seconds", 0.0),
            total_duration_seconds=payload.get("total_duration_seconds", 0.0),
            invocation_count=payload.get("invocation_count", 1),
            files_created=payload.get("files_created", []),
            files_modified=payload.get("files_modified", []),
            git_branch=payload.get("git_branch", ""),
            git_commit_hash=payload.get("git_commit_hash", ""),
            termination_reason=payload.get("termination_reason", ""),
            warnings=payload.get("warnings", []),
            epics_completed=payload.get("epics_completed", 0),
            epics_total=payload.get("epics_total", 0),
            stories_completed=payload.get("stories_completed", 0),
            stories_total=payload.get("stories_total", 0),
            tasks_completed=payload.get("tasks_completed", 0),
            tasks_total=payload.get("tasks_total", 0),
        )


# =============================================================================
# Client -> Server Message Types
# =============================================================================


@dataclass
class PlanUploadRequest:
    """Request to upload a plan file to server.

    Sent by client to upload a MACHINE_PLAN.yaml file for reuse.

    Attributes:
        name: Plan name (typically work_id from YAML)
        plan_data: Parsed YAML structure (dict representation)
    """

    name: str
    plan_data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "name": self.name,
            "plan_data": self.plan_data,
        }


@dataclass
class PlanUploadResponse:
    """Response from plan upload operation.

    Sent by server after successful plan storage.

    Attributes:
        plan_id: UUID identifier for the uploaded plan
        name: Plan name (echoed from request)
        story_count: Number of stories in the plan
    """

    plan_id: str
    name: str
    story_count: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PlanUploadResponse":
        """Create from API response dictionary."""
        return cls(
            plan_id=data.get("plan_id", ""),
            name=data.get("name", ""),
            story_count=data.get("story_count", 0),
        )


@dataclass
class SessionStart:
    """Start a new orchestration session.

    Sent by client to initiate a new session.

    Attributes:
        objective: Task objective
        project_hash: SHA256 hash of project path (privacy)
        working_dir: Working directory path for project resolution
        project_id: Optional project ID override (Firestore document ID)
        project_context: Project context (languages, frameworks, etc.)
        client_version: Client version string
        effective_llm_map: Per-stage LLM configuration map. Keys are stage names
            (derive, examine, revise, execute, fix, review) or agent names
            (sense_check, code_quality, test_execution). Values are dicts with
            keys: provider, model, tier, thinking_level.
        plan_id: Optional reference to uploaded plan (for plan import workflow)
        userplan_id: Optional UserPlan ID (for plan file import - S2.T3)
        bypass_modes: Optional list of bypass flags (e.g., planning_permissive)
        from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
    """

    objective: str
    project_hash: str
    working_dir: str | None = None
    project_id: str | None = None
    project_context: dict[str, Any] = field(default_factory=dict)
    client_version: str = ""
    effective_llm_map: dict[str, dict[str, str]] = field(default_factory=dict)
    plan_id: str | None = None
    userplan_id: str | None = None
    bypass_modes: list[str] = field(default_factory=list)
    from_step: int | None = None
    quality_policy_mode: str | None = None  # FEAT-QUALITY-POLICY-MODE-001

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        result: dict[str, Any] = {
            "objective": self.objective,
            "project_hash": self.project_hash,
            "project_context": self.project_context,
            "client_version": self.client_version,
            "effective_llm_map": self.effective_llm_map,
        }
        if self.working_dir is not None:
            result["working_dir"] = self.working_dir
        if self.project_id is not None:
            result["project_id"] = self.project_id
        if self.plan_id is not None:
            result["plan_id"] = self.plan_id
        if self.userplan_id is not None:
            result["userplan_id"] = self.userplan_id
        if self.bypass_modes:
            result["bypass_modes"] = self.bypass_modes
        if self.from_step is not None:
            result["from_step"] = self.from_step
        if self.quality_policy_mode is not None:
            result["quality_policy_mode"] = self.quality_policy_mode
        return result


@dataclass
class DerivedPlan:
    """Report derived plan to server.

    Sent by client after completing derivation.

    Attributes:
        session_id: Session identifier
        userplan_id: UserPlan ID that this derivation is for
        userplan_version: Version of UserPlan used for derivation
        plan_items: Derived plan items
        raw_response: Raw LLM response (for debugging)
        work_type: Detected work type for analytics/display (e.g., feature, bugfix)
        verification_tools: Client-reported verification tools (optional)
        story0_prerequisites: Story 0 prerequisites derived by client (optional)
    """

    session_id: str
    userplan_id: str
    userplan_version: int
    plan_items: list[dict[str, Any]]
    raw_response: str = ""
    work_type: str | None = None
    verification_tools: dict[str, Any] | None = None
    story0_prerequisites: list[dict[str, Any]] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        result = {
            "session_id": self.session_id,
            "userplan_id": self.userplan_id,
            "userplan_version": self.userplan_version,
            "plan_items": self.plan_items,
            "raw_response": self.raw_response,
        }
        if self.work_type is not None:
            result["work_type"] = self.work_type
        if self.verification_tools is not None:
            result["verification_tools"] = self.verification_tools
        if self.story0_prerequisites is not None:
            result["story0_prerequisites"] = self.story0_prerequisites
        return result


@dataclass
class ExaminationReport:
    """Report examination results to server.

    Sent by client after completing LLM examination.

    Attributes:
        session_id: Session identifier
        iteration: Examination iteration number
        issues: Issues found during examination
        thinking_budget_used: Tokens used for extended thinking
        thinking_fallback: Whether thinking mode fell back
        raw_response: Raw LLM response
    """

    session_id: str
    iteration: int
    issues: list[dict[str, Any]]
    thinking_budget_used: int = 0
    thinking_fallback: bool = False
    raw_response: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "iteration": self.iteration,
            "issues": self.issues,
            "thinking_budget_used": self.thinking_budget_used,
            "thinking_fallback": self.thinking_fallback,
            "raw_response": self.raw_response,
        }


@dataclass
class RevisedPlan:
    """Report revised plan to server.

    Sent by client after completing revision.

    Attributes:
        session_id: Session identifier
        plan_items: Revised plan items
        addressed_issues: Issue IDs explicitly addressed during revision
        deferred_issues: Issues explicitly deferred during revision
        changes_summary: Summary of changes made
        raw_response: Raw LLM response
    """

    session_id: str
    plan_items: list[dict[str, Any]]
    addressed_issues: list[str] = field(default_factory=list)
    deferred_issues: list[dict[str, Any]] = field(default_factory=list)
    changes_summary: str = ""
    raw_response: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "plan_items": self.plan_items,
            "addressed_issues": self.addressed_issues,
            "deferred_issues": self.deferred_issues,
            "changes_summary": self.changes_summary,
            "raw_response": self.raw_response,
        }


@dataclass
class ExecutionResult:
    """Report execution result to server.

    Sent by client after executing a plan item.

    Attributes:
        session_id: Session identifier
        item_id: Plan item ID that was executed
        status: Execution status (success, failure, partial)
        summary: LLM-generated summary
        files_changed: Number of files changed
        changed_file_paths: Exact file paths changed during execution
        tests_passed: Whether tests passed
        test_count: Number of tests run
        coverage_delta: Change in coverage percentage
        verification_tools: Optional verification tools discovered post-execution
        decomposition_suggested: Whether adaptive decomposition was suggested
        decomposition_reason: Reason for decomposition suggestion
        partial_work_summary: Summary of partial work completed
    """

    session_id: str
    item_id: str
    status: ExecutionStatus
    summary: str = ""
    files_changed: int = 0
    changed_file_paths: list[str] = field(default_factory=list)
    tests_passed: bool = False
    test_count: int = 0
    coverage_delta: float = 0.0
    verification_tools: dict[str, Any] | None = None
    decomposition_suggested: bool = False
    decomposition_reason: str | None = None
    partial_work_summary: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        payload: dict[str, Any] = {
            "session_id": self.session_id,
            "item_id": self.item_id,
            "status": self.status.value,
            "summary": self.summary,
            "files_changed": self.files_changed,
            "changed_file_paths": self.changed_file_paths,
            "tests_passed": self.tests_passed,
            "test_count": self.test_count,
            "coverage_delta": self.coverage_delta,
            "decomposition_suggested": self.decomposition_suggested,
        }
        if self.verification_tools:
            payload["verification_tools"] = self.verification_tools
        if self.decomposition_reason is not None:
            payload["decomposition_reason"] = self.decomposition_reason
        if self.partial_work_summary is not None:
            payload["partial_work_summary"] = self.partial_work_summary
        return payload

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionResult":
        """Create from dictionary."""
        return cls(
            session_id=data.get("session_id", ""),
            item_id=data.get("item_id", ""),
            status=safe_enum_parse(
                ExecutionStatus, data.get("status"), ExecutionStatus.SUCCESS
            ),
            summary=data.get("summary", ""),
            files_changed=data.get("files_changed", 0),
            changed_file_paths=list(data.get("changed_file_paths") or []),
            tests_passed=data.get("tests_passed", False),
            test_count=data.get("test_count", 0),
            coverage_delta=data.get("coverage_delta", 0.0),
            verification_tools=data.get("verification_tools"),
            decomposition_suggested=data.get("decomposition_suggested", False),
            decomposition_reason=data.get("decomposition_reason"),
            partial_work_summary=data.get("partial_work_summary"),
        )


@dataclass
class AgentReport:
    """Report review agent results to server.

    Sent by client after running review agents.

    Attributes:
        session_id: Session identifier
        item_id: Plan item ID that was reviewed
        agent_type: Type of agent (security, testing, docs, code_quality, test_execution,
            sense_check)
        execution_time_ms: Time taken by agent
        status: Agent execution status
        issues: Issues found by agent
        scores: Dimension scores (0.0 - 1.0)
    """

    session_id: str
    item_id: str
    agent_type: AgentType
    execution_time_ms: int
    status: str  # complete, timeout, error
    issues: list[dict[str, Any]] = field(default_factory=list)
    scores: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "item_id": self.item_id,
            "agent_type": self.agent_type.value,
            "execution_time_ms": self.execution_time_ms,
            "status": self.status,
            "issues": self.issues,
            "scores": self.scores,
        }


@dataclass
class FixResult:
    """Report fix attempt result to server.

    Sent by client after attempting to fix an issue.

    Attributes:
        session_id: Session identifier
        issue_id: Legacy issue ID that was fixed
        canonical_id: Canonical issue ID for lifecycle tracking
        status: Fix status (applied, failed, skipped)
        reason: Optional reason for reported status
        files_modified: List of modified file paths
        verification: Verification results
    """

    session_id: str
    issue_id: str
    status: str  # applied, failed, skipped
    canonical_id: str = ""
    reason: str = ""
    files_modified: list[str] = field(default_factory=list)
    verification: dict[str, bool] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "issue_id": self.issue_id,
            "canonical_id": self.canonical_id or self.issue_id,
            "status": self.status,
            "reason": self.reason,
            "files_modified": self.files_modified,
            "verification": self.verification,
        }


@dataclass
class FixReport:
    """Report fix-loop summary to server.

    Sent by client after a FIX action completes.

    Attributes:
        session_id: Session identifier
        item_id: Plan item ID currently in fix/review loop
        fixes_applied: Count of successful fix attempts
        fixes_failed: Count of failed fix attempts
        fix_details: Per-issue fix details
        progress_cursor: Optional cursor for incremental progress events
    """

    session_id: str
    item_id: str = ""
    fixes_applied: int = 0
    fixes_failed: int = 0
    fix_details: list[dict[str, Any]] = field(default_factory=list)
    progress_cursor: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        payload: dict[str, Any] = {
            "session_id": self.session_id,
            "item_id": self.item_id,
            "fixes_applied": self.fixes_applied,
            "fixes_failed": self.fixes_failed,
            "fix_details": self.fix_details,
        }
        if self.progress_cursor:
            payload["progress_cursor"] = self.progress_cursor
        return payload

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FixReport":
        """Create from dictionary."""
        return cls(
            session_id=data.get("session_id", ""),
            item_id=data.get("item_id", ""),
            fixes_applied=int(data.get("fixes_applied") or 0),
            fixes_failed=int(data.get("fixes_failed") or 0),
            fix_details=list(data.get("fix_details") or []),
            progress_cursor=(
                str(data.get("progress_cursor")).strip()
                if data.get("progress_cursor") is not None
                and str(data.get("progress_cursor")).strip()
                else None
            ),
        )


@dataclass
class UserDecision:
    """Report user decision during escalation.

    Sent by client when user responds to escalation.

    Attributes:
        session_id: Session identifier
        escalation_id: Escalation identifier
        decision: User's decision
        reason: Optional reason for decision
    """

    session_id: str
    escalation_id: str
    decision: UserDecisionChoice
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "escalation_id": self.escalation_id,
            "decision": self.decision.value,
            "reason": self.reason,
        }


# =============================================================================
# Resume Context
# =============================================================================


@dataclass
class ResumeContext:
    """Context for resuming an interrupted session.

    Returned by GET /get_hybrid_session endpoint.

    Attributes:
        session_id: Session identifier
        status: Session status
        current_phase: Current phase
        can_resume: Whether session can be resumed
        last_successful_step: Description of last successful step
        pending_action: Human-readable pending action
        resume_instructions: Instructions for resuming
    """

    session_id: str
    status: SessionStatus
    current_phase: SessionPhase
    can_resume: bool = False
    last_successful_step: str = ""
    pending_action: str = ""
    resume_instructions: str = ""
    awaiting_message: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ResumeContext":
        """Create from API response dictionary.

        Uses safe enum parsing for forward compatibility - unknown status/phase
        values from newer servers will be mapped to UNKNOWN variants.
        """
        return cls(
            session_id=data.get("session_id", ""),
            status=safe_enum_parse(
                SessionStatus,
                data.get("status"),
                SessionStatus.ACTIVE,
            ),
            current_phase=safe_enum_parse(
                SessionPhase,
                data.get("current_phase"),
                SessionPhase.DERIVATION,
            ),
            can_resume=data.get("can_resume", False),
            last_successful_step=data.get("last_successful_step", ""),
            pending_action=data.get("pending_action", ""),
            resume_instructions=data.get("resume_instructions", ""),
            awaiting_message=data.get("awaiting_message", ""),
        )


# =============================================================================
# Progress Event Types (ISSUE-CLI-023)
# =============================================================================


@dataclass
class ProgressEvent:
    """Progress event transmitted from server to client during polling.

    Progress events enable rich progress indicators (task prefixes, heartbeats,
    file activity summaries, spinners) to be displayed by the client when the
    orchestrator runs on the server.

    Related:
        - ISSUE-CLI-023: Progress dashboard features not visible in SaaS mode
        - docs/quality/investigations/ISSUE-CLI-023_RCA.md
        - functions/main.py (get_session_action includes progress_events)
        - obra/hybrid/orchestrator.py (_handle_progress_events_from_response)

    Attributes:
        event_type: Type of progress event (item_started, heartbeat, file_event, etc.)
        timestamp: ISO-8601 timestamp when event occurred
        payload: Event-specific data (varies by event_type)
    """

    event_type: str
    timestamp: str
    payload: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProgressEvent":
        """Create from dictionary with validation.

        Args:
            data: Dictionary containing progress event data

        Returns:
            ProgressEvent instance

        Raises:
            ValueError: If required fields are missing
        """
        if "event_type" not in data:
            raise ValueError("ProgressEvent requires 'event_type' field")
        if "timestamp" not in data:
            raise ValueError("ProgressEvent requires 'timestamp' field")

        return cls(
            event_type=data["event_type"],
            timestamp=data["timestamp"],
            payload=data.get("payload", {}),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "payload": self.payload,
        }


__all__ = [
    # Utilities
    "safe_enum_parse",
    # Enums
    "ActionType",
    "SessionPhase",
    "SessionStatus",
    "Priority",
    "ExecutionStatus",
    "AgentType",
    "EscalationReason",
    "UserDecisionChoice",
    # Server -> Client
    "ServerAction",
    "DeriveRequest",
    "IntentRequest",
    "ExamineRequest",
    "RevisionRequest",
    "ExecutionRequest",
    "ReviewRequest",
    "FixRequest",
    "ValidatorRequest",
    "ValidatorResult",
    "PipelineStageRequest",
    "PipelineStageResult",
    "EscalationNotice",
    "CompletionNotice",
    # Client -> Server
    "PlanUploadRequest",
    "PlanUploadResponse",
    "SessionStart",
    "DerivedPlan",
    "ExaminationReport",
    "RevisedPlan",
    "ExecutionResult",
    "AgentReport",
    "FixResult",
    "FixReport",
    "UserDecision",
    # Resume
    "ResumeContext",
    # Progress (ISSUE-CLI-023)
    "ProgressEvent",
    # Validator schema validation
    "validate_validator_request",
    "validate_validator_result",
]
