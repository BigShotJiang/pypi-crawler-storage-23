"""Agent tier configuration loader.

Loads per-agent LLM configuration from layered config under
features.quality_automation.agents.<agent>.llm with inheritance from the
implementation profile. Legacy config/dobra_config.yaml support remains for
compatibility.
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from obra.config.llm import resolve_tier_config
from obra.config.loaders import load_layered_config

logger = logging.getLogger(__name__)

_LEGACY_AGENT_NAME_MAP: dict[str, str] = {
    "security_audit": "security",
    "test_generation": "testing",
    "code_review": "code_quality",
    "doc_audit": "docs",
}

_DEFAULT_AGENT_MODEL_TIERS: dict[str, str] = {
    "security_audit": "fast",
    "test_generation": "fast",
    "code_review": "fast",
    "doc_audit": "fast",
    "sense_check": "high",
    "code_verify": "high",
    # Legacy agent names for backward compatibility.
    "security": "fast",
    "testing": "fast",
    "code_quality": "fast",
    "docs": "fast",
}


@dataclass(frozen=True)
class AgentLLMConfig:
    provider: str | None = None
    model: str | None = None
    model_tier: str | None = None
    reasoning_level: str | None = None
    escalate_tier: str | None = None


def _normalize_inherit(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    if not normalized or normalized.lower() == "inherit":
        return None
    return normalized


def _default_model_tier(agent_name: str) -> str:
    return _DEFAULT_AGENT_MODEL_TIERS.get(agent_name, "fast")


def _legacy_agent_name(agent_name: str) -> str | None:
    if agent_name in _LEGACY_AGENT_NAME_MAP:
        return _LEGACY_AGENT_NAME_MAP[agent_name]
    if agent_name in _LEGACY_AGENT_NAME_MAP.values():
        return agent_name
    return None


def _load_legacy_review_tiers(
    agent_name: str,
    config_path: Path | None,
) -> tuple[str | None, str | None]:
    legacy_name = _legacy_agent_name(agent_name)
    if not legacy_name:
        return None, None

    path = config_path or Path("config/dobra_config.yaml")
    if not path.exists():
        return None, None

    try:
        with path.open(encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    except (OSError, yaml.YAMLError) as exc:
        logger.warning("Failed to load legacy agent tiers from %s: %s", path, exc)
        return None, None

    agents_config: dict[str, Any] = config.get("agents", {})
    review_config: dict[str, Any] = agents_config.get("review", {})
    agent_config: dict[str, Any] = review_config.get(legacy_name, {})
    if not isinstance(agent_config, dict):
        return None, None

    start_tier = agent_config.get("start_tier")
    escalate_tier = agent_config.get("escalate_tier")
    start_tier = start_tier if isinstance(start_tier, str) else None
    escalate_tier = escalate_tier if isinstance(escalate_tier, str) else None
    return start_tier, escalate_tier


def load_agent_llm_config(agent_name: str) -> AgentLLMConfig:
    config, _, _ = load_layered_config(include_defaults=True)
    agents_section = config.get("features", {}).get("quality_automation", {}).get("agents", {})
    agent_section = agents_section.get(agent_name, {}) if isinstance(agents_section, dict) else {}
    llm_section = agent_section.get("llm", {}) if isinstance(agent_section, dict) else {}

    provider = _normalize_inherit(llm_section.get("provider"))
    model = _normalize_inherit(llm_section.get("model"))
    model_tier = _normalize_inherit(llm_section.get("model_tier"))
    reasoning_level = _normalize_inherit(llm_section.get("reasoning_level"))

    default_escalate = "high" if agent_name in ("security_audit", "security") else None
    overrides_present = any(
        value is not None for value in (provider, model, model_tier, reasoning_level)
    )

    if not overrides_present:
        legacy_start, legacy_escalate = _load_legacy_review_tiers(agent_name, None)
        if legacy_start or legacy_escalate:
            warnings.warn(
                "Legacy agent tier config in config/dobra_config.yaml is deprecated; "
                "use features.quality_automation.agents.<agent>.llm.* instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            if legacy_start:
                model_tier = legacy_start
            if legacy_escalate:
                default_escalate = legacy_escalate

    return AgentLLMConfig(
        provider=provider,
        model=model,
        model_tier=model_tier,
        reasoning_level=reasoning_level,
        escalate_tier=default_escalate,
    )


def resolve_agent_tier_config(
    agent_name: str,
    tier_override: str | None = None,
) -> dict[str, Any]:
    """Resolve full LLM tier config for an agent.

    Parameter Contracts (ADR-042):
        - agent_name: registered agent name (e.g. 'code_verify', 'security')
        - tier_override: optional tier to use instead of agent config default
    """
    agent_config = load_agent_llm_config(agent_name)
    tier = tier_override or agent_config.model_tier or _default_model_tier(agent_name)
    override_thinking_level = (
        agent_config.reasoning_level if agent_config.reasoning_level is not None else None
    )

    return resolve_tier_config(
        tier,
        role="implementation",
        override_provider=agent_config.provider,
        override_model=agent_config.model,
        override_thinking_level=override_thinking_level,
    )


def load_agent_tier_config(
    agent_name: str,
    config_path: Path | None = None,
) -> dict[str, str | None]:
    """Load tier configuration for an agent from legacy config.

    Deprecated: use resolve_agent_tier_config/load_agent_llm_config.

    Parameter Contracts (ADR-042):
        - agent_name: registered agent name
        - config_path: optional path to config file (default: standard resolution)
    """
    warnings.warn(
        "load_agent_tier_config is deprecated; use resolve_agent_tier_config instead.",
        DeprecationWarning,
        stacklevel=2,
    )

    default_start = _default_model_tier(agent_name)
    default_escalate = "high" if agent_name in ("security", "security_audit") else None
    start_tier, escalate_tier = _load_legacy_review_tiers(agent_name, config_path)

    return {
        "start_tier": start_tier or default_start,
        "escalate_tier": (escalate_tier if escalate_tier is not None else default_escalate),
    }


__all__ = [
    "AgentLLMConfig",
    "load_agent_llm_config",
    "resolve_agent_tier_config",
    "load_agent_tier_config",
]
