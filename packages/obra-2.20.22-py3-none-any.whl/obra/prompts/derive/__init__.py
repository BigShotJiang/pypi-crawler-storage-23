"""Derivation and exploration prompts.

This package contains prompts for plan derivation and codebase exploration:
- derivation: Main plan generation prompts
- revision: Plan improvement prompts
- exploration: Codebase exploration and task classification
"""

from __future__ import annotations

# Define lazy-loaded exports
_SUBMODULE_EXPORTS = {
    # derivation.py exports
    "FOUR_PHASE_GUIDANCE": ".derivation",
    "PATTERN_GUIDANCE": ".derivation",
    "SIZING_GUIDANCE": ".derivation",
    "build_sizing_guidance_block": ".derivation",
    "build_derivation_prompt": ".derivation",
    "build_four_phase_guidance": ".derivation",
    "build_refinement_prompt": ".derivation",
    "build_step1_prompt": ".derivation",
    "build_step1_epics_only_prompt": ".derivation",
    "build_step2_prompt": ".derivation",
    "build_step2_per_epic_prompt": ".derivation",
    "build_step3_prompt": ".derivation",
    "get_pattern_guidance": ".derivation",
    # revision.py exports
    "build_revision_prompt": ".revision",
    # exploration.py exports
    "EXPLORATION_PROMPT_TEMPLATE": ".exploration",
    "build_exploration_prompt": ".exploration",
    "build_task_classification_prompt": ".exploration",
}

__all__ = list(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """PEP 562 lazy loading for submodule exports."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module_name = _SUBMODULE_EXPORTS[name]
        module = import_module(module_name, package=__name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__():
    """List available exports."""
    return __all__
