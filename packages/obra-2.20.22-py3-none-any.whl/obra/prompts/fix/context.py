"""Prompts for issue fixing operations.

Contains prompts extracted from obra/hybrid/handlers/fix.py as part of
the prompt library refactoring (REFACTOR-PROMPT-LIBRARY-001).

Prompts:
    build_batch_fix_context: Builder for batch fix context blocks
    build_issue_specific_context: Builder for single-issue context blocks
"""

from __future__ import annotations

__all__ = [
    "build_batch_fix_context",
    "build_issue_specific_context",
    "build_test_gap_batch_context",
    "build_test_gap_inference_prompt",
    "build_test_gap_issue_context",
]


def build_batch_fix_context(
    file_path: str,
    issues: list[dict],
    file_contents: str | None,
) -> str:
    """Build context block for fixing multiple issues in the same file.

    This returns the CONTEXT portion that gets prepended to the base_prompt.
    The base_prompt comes from the server.

    Args:
        file_path: Path to the file being fixed
        issues: List of issue dicts with 'id', 'priority', 'description', etc.
        file_contents: Optional file contents to include for context

    Returns:
        Context block string to prepend to base_prompt
    """
    context_parts = [
        "=" * 70,
        f"FIX {len(issues)} ISSUES IN: {file_path}",
        "=" * 70,
        "",
    ]

    # Include file contents if available
    if file_contents:
        context_parts.append("## Current File Contents")
        context_parts.append(
            "IMPORTANT: This file already exists. EDIT the existing file, do NOT create a new one."
        )
        context_parts.append("```")
        context_parts.append(file_contents)
        context_parts.append("```")
        context_parts.append("")

    for i, issue in enumerate(issues, 1):
        issue_id = issue.get("id", f"issue-{i}")
        priority = issue.get("priority", "P2")
        description = issue.get("description", "")
        suggestion = issue.get("suggestion", "")
        line_number = issue.get("line_number") or issue.get("line", "")
        metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
        enrichment = metadata.get("sensecheck_enrichment")

        context_parts.append(f"### Issue {i}: {issue_id} (Priority: {priority})")
        if line_number:
            context_parts.append(f"**Location**: Line {line_number}")
        if suggestion:
            context_parts.append(f"**Fix**: {suggestion}")
        context_parts.append(f"**Problem**: {description}")
        if isinstance(enrichment, dict) and enrichment:
            root_cause = enrichment.get("root_cause") or ""
            fix_guidance = enrichment.get("fix_guidance") or ""
            is_band_aid = enrichment.get("is_band_aid")
            reason = enrichment.get("reason") or ""
            context_parts.append("**SenseCheck Guidance**:")
            if is_band_aid is not None:
                context_parts.append(f"- Band-aid risk: {str(is_band_aid).lower()}")
            if root_cause:
                context_parts.append(f"- Root cause: {root_cause}")
            if fix_guidance:
                context_parts.append(f"- Fix guidance: {fix_guidance}")
            if reason:
                context_parts.append(f"- Reason: {reason}")
        context_parts.append("")

    context_parts.append("## Scope Constraints")
    context_parts.append("- Fix ONLY the specific issues described above")
    context_parts.append("- Do NOT refactor unrelated code")
    context_parts.append("- Do NOT add unrelated improvements")
    context_parts.append("- Make the MINIMUM changes necessary to resolve the issues")
    context_parts.append("- If changes span multiple files, list each change explicitly")
    context_parts.append("- Avoid broad search-and-replace operations")
    context_parts.append(
        "- Do NOT modify existing tests to accommodate your changes. "
        "If your fix causes test failures, your approach is wrong — "
        "find an alternative that preserves existing test behavior."
    )
    context_parts.append("")

    context_parts.append("=" * 70)
    context_parts.append("")

    return "\n".join(context_parts)


def build_issue_specific_context(
    issue: dict,
    file_contents: str | None,
) -> str:
    """Build context block for fixing a single specific issue.

    This returns the CONTEXT portion that gets prepended to the base_prompt.
    The base_prompt comes from the server.

    Args:
        issue: Issue dict with 'id', 'description', 'priority', 'file_path', etc.
        file_contents: Optional file contents to include for context

    Returns:
        Context block string to prepend to base_prompt
    """
    issue_id = issue.get("id", "unknown")
    description = issue.get("description", "")
    priority = issue.get("priority", "P2")
    file_path = issue.get("file_path") or issue.get("file", "")
    line_number = issue.get("line_number") or issue.get("line", "")
    suggestion = issue.get("suggestion", "")
    category = issue.get("category") or issue.get("dimension", "")

    # Extract failing scenario if embedded in description
    failing_scenario = ""
    if "Failing scenario:" in description:
        parts = description.split("Failing scenario:", 1)
        description = parts[0].strip()
        failing_scenario = parts[1].strip() if len(parts) > 1 else ""

    # Also check metadata for failing_scenario and raw_finding (from AgentIssue)
    metadata = issue.get("metadata", {})
    if isinstance(metadata, dict):
        if not failing_scenario:
            failing_scenario = metadata.get("failing_scenario", "")
        # Get raw finding for full context preservation
        raw_finding = metadata.get("raw_finding", "")
        enrichment = metadata.get("sensecheck_enrichment")
    else:
        raw_finding = ""
        enrichment = None

    # Build the issue context block
    context_parts = [
        "=" * 70,
        f"ISSUE TO FIX: {issue_id} (Priority: {priority})",
        "=" * 70,
    ]

    # Location info
    if file_path:
        location = f"File: {file_path}"
        if line_number:
            location += f" (line {line_number})"
        context_parts.append(location)

    if category:
        context_parts.append(f"Category: {category}")

    context_parts.append("")

    if isinstance(enrichment, dict) and enrichment:
        root_cause = enrichment.get("root_cause") or ""
        fix_guidance = enrichment.get("fix_guidance") or ""
        is_band_aid = enrichment.get("is_band_aid")
        reason = enrichment.get("reason") or ""
        context_parts.append("## SenseCheck Guidance")
        if is_band_aid is not None:
            context_parts.append(f"Band-aid risk: {str(is_band_aid).lower()}")
        if root_cause:
            context_parts.append(f"Root cause: {root_cause}")
        if fix_guidance:
            context_parts.append(f"Fix guidance: {fix_guidance}")
        if reason:
            context_parts.append(f"Reason: {reason}")
        context_parts.append("")

    # Include actual file contents so fix agent can see and edit
    if file_contents:
        context_parts.append("## Current File Contents")
        context_parts.append(
            "IMPORTANT: This file already exists. EDIT the existing file, do NOT create a new one."
        )
        context_parts.append("```")
        context_parts.append(file_contents)
        context_parts.append("```")
        context_parts.append("")

    # Prefer raw finding to preserve full review agent context
    if raw_finding:
        context_parts.append("## Review Agent Finding")
        context_parts.append(raw_finding)
    elif suggestion:
        # Fallback: suggestion-first framing
        context_parts.append("## Your Task")
        context_parts.append("Apply the following fix:")
        context_parts.append("")
        context_parts.append(suggestion)
        context_parts.append("")
        context_parts.append("## Context")
        context_parts.append(description if description else "No description provided")
        if failing_scenario:
            context_parts.append("")
            context_parts.append("## Failing Scenario")
            context_parts.append(failing_scenario)
    else:
        # Fallback: problem-first framing
        context_parts.append("## Problem Description")
        context_parts.append(description if description else "No description provided")
        if failing_scenario:
            context_parts.append("")
            context_parts.append("## Failing Scenario")
            context_parts.append(failing_scenario)

    context_parts.append("")
    context_parts.append("## Scope Constraints")
    context_parts.append("- Fix ONLY the specific issue described above")
    context_parts.append("- Do NOT refactor unrelated code")
    context_parts.append("- Do NOT add unrelated improvements")
    context_parts.append("- Make the MINIMUM changes necessary to resolve the issue")
    context_parts.append(
        "- If the fix requires changes to multiple files, list each change explicitly"
    )
    context_parts.append("- Avoid broad search-and-replace operations")
    context_parts.append(
        "- Do NOT modify existing tests to accommodate your changes. "
        "If your fix causes test failures, your approach is wrong — "
        "find an alternative that preserves existing test behavior."
    )
    context_parts.append("")
    context_parts.append("=" * 70)
    context_parts.append("")

    return "\n".join(context_parts)


def build_test_gap_issue_context(
    issue: dict,
    source_file_contents: str | None,
    test_file_contents: str | None,
) -> str:
    """Build context block for a test coverage issue (test gap).

    The source file is read-only context. The fix should create/modify tests.
    """
    issue_id = issue.get("id", "unknown")
    priority = issue.get("priority", "P2")
    source_path = issue.get("file_path") or issue.get("file", "")
    line_number = issue.get("line_number") or issue.get("line", "")
    target_test_file = issue.get("target_test_file") or ""
    target_paths = issue.get("target_paths") or []
    test_name = issue.get("test_name") or ""

    description = issue.get("description", "")
    suggestion = issue.get("suggestion", "")
    metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
    failing_scenario = metadata.get("failing_scenario") or ""
    arrange = issue.get("arrange") or metadata.get("arrange", "")
    act = issue.get("act") or metadata.get("act", "")
    assert_steps = issue.get("assert") or metadata.get("assert", "")
    resolution_path = (
        issue.get("resolution_path") or metadata.get("resolution_path") or "tests_only"
    )

    allow_source_edits = str(resolution_path).lower() == "code_and_tests"
    context_parts = [
        "=" * 70,
        f"TEST GAP ISSUE: {issue_id} (Priority: {priority})",
        "=" * 70,
        "",
        "## Your Task",
        "Write or update tests to cover the untested path below.",
        "You MAY modify production/source code if resolution_path allows (code_and_tests).",
        "Do NOT modify production/source code when resolution_path is tests_only.",
        "",
    ]

    if allow_source_edits:
        context_parts.append(
            "Resolution path: code_and_tests (source edits allowed if needed to satisfy tests)."
        )
        context_parts.append("")

    if source_path:
        location = f"Source: {source_path}"
        if line_number:
            location += f" (line {line_number})"
        context_parts.append(location)
        context_parts.append("")

    if source_file_contents:
        context_parts.append("## Source Code (READ ONLY)")
        context_parts.append("```")
        context_parts.append(source_file_contents)
        context_parts.append("```")
        context_parts.append("")

    if target_test_file or target_paths:
        context_parts.append("## Target Test File")
        if target_test_file:
            context_parts.append(f"Primary: {target_test_file}")
        if target_paths:
            context_parts.append(f"Alternates: {', '.join(target_paths)}")
        context_parts.append("")

    if test_file_contents:
        context_parts.append("## Current Test File Contents (EDIT THIS FILE)")
        context_parts.append("```")
        context_parts.append(test_file_contents)
        context_parts.append("```")
        context_parts.append("")
    else:
        context_parts.append("## Test File Instructions")
        context_parts.append("If the target test file does not exist, create it.")
        context_parts.append("")

    if test_name:
        context_parts.append(f"## Suggested Test Name\n{test_name}\n")

    if description:
        context_parts.append("## Context")
        context_parts.append(description)
        context_parts.append("")

    if suggestion:
        context_parts.append("## Suggested Fix")
        context_parts.append(suggestion)
        context_parts.append("")

    if failing_scenario:
        context_parts.append("## Failing Scenario to Test")
        context_parts.append(failing_scenario)
        context_parts.append("")

    if arrange or act or assert_steps:
        context_parts.append("## Test Steps")
        if arrange:
            context_parts.append(f"- ARRANGE: {arrange}")
        if act:
            context_parts.append(f"- ACT: {act}")
        if assert_steps:
            context_parts.append(f"- ASSERT: {assert_steps}")
        context_parts.append("")

    context_parts.append("## Scope Constraints")
    context_parts.append("- Fix ONLY the specific test gap described above")
    context_parts.append("- Do NOT refactor unrelated code")
    context_parts.append("- Do NOT modify production code unless explicitly required")
    context_parts.append("- Make the MINIMUM changes necessary to add coverage")
    context_parts.append("")
    context_parts.append("=" * 70)
    context_parts.append("")

    return "\n".join(context_parts)


def build_test_gap_batch_context(
    test_file_path: str,
    issues: list[dict],
    test_file_contents: str | None,
    source_contexts: dict[str, str] | None = None,
) -> str:
    """Build context block for multiple test-gap issues in the same test file."""
    allow_source_edits = False
    for issue in issues:
        metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
        resolution_path = issue.get("resolution_path") or metadata.get("resolution_path") or ""
        if str(resolution_path).lower() == "code_and_tests":
            allow_source_edits = True
            break

    context_parts = [
        "=" * 70,
        f"FIX {len(issues)} TEST GAP ISSUES IN: {test_file_path}",
        "=" * 70,
        "",
        "## Your Task",
        "Write or update tests in the target test file.",
        "You MAY modify production/source code if resolution_path allows (code_and_tests).",
        "Do NOT modify production/source code when resolution_path is tests_only.",
        "",
    ]

    if allow_source_edits:
        context_parts.append(
            "Resolution path: code_and_tests detected in this batch (source edits allowed if needed)."
        )
        context_parts.append("")

    if test_file_contents:
        context_parts.append("## Current Test File Contents (EDIT THIS FILE)")
        context_parts.append("```")
        context_parts.append(test_file_contents)
        context_parts.append("```")
        context_parts.append("")

    for i, issue in enumerate(issues, 1):
        issue_id = issue.get("id", f"issue-{i}")
        priority = issue.get("priority", "P2")
        description = issue.get("description", "")
        suggestion = issue.get("suggestion", "")
        line_number = issue.get("line_number") or issue.get("line", "")
        source_path = issue.get("file_path") or issue.get("file", "")
        test_name = issue.get("test_name") or ""
        metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
        failing_scenario = metadata.get("failing_scenario", "")
        arrange = issue.get("arrange") or metadata.get("arrange", "")
        act = issue.get("act") or metadata.get("act", "")
        assert_steps = issue.get("assert") or metadata.get("assert", "")

        context_parts.append(f"### Issue {i}: {issue_id} (Priority: {priority})")
        if source_path:
            location = f"Source: {source_path}"
            if line_number:
                location += f" (line {line_number})"
            context_parts.append(location)
        if test_name:
            context_parts.append(f"**Test Name**: {test_name}")
        if suggestion:
            context_parts.append(f"**Fix**: {suggestion}")
        if description:
            context_parts.append(f"**Problem**: {description}")
        if failing_scenario:
            context_parts.append(f"**Failing Scenario**: {failing_scenario}")
        if arrange or act or assert_steps:
            steps = []
            if arrange:
                steps.append(f"ARRANGE: {arrange}")
            if act:
                steps.append(f"ACT: {act}")
            if assert_steps:
                steps.append(f"ASSERT: {assert_steps}")
            context_parts.append("**Test Steps**: " + " | ".join(steps))
        if source_contexts and issue_id in source_contexts:
            context_parts.append("")
            context_parts.append("**Source Context (READ ONLY)**")
            context_parts.append("```")
            context_parts.append(source_contexts[issue_id])
            context_parts.append("```")
        context_parts.append("")

    context_parts.append("## Scope Constraints")
    context_parts.append("- Fix ONLY the specific test gaps described above")
    context_parts.append("- Do NOT refactor unrelated code")
    context_parts.append("- Do NOT modify production code")
    context_parts.append("- Make the MINIMUM changes necessary to add coverage")
    context_parts.append("")
    context_parts.append("=" * 70)
    context_parts.append("")

    return "\n".join(context_parts)


def build_test_gap_inference_prompt(
    issue: dict,
    candidate_paths: list[str],
) -> str:
    """Build prompt to infer the most likely test file target."""
    source_path = issue.get("file_path") or issue.get("file", "")
    line_number = issue.get("line_number") or issue.get("line", "")
    description = issue.get("description", "")
    suggestion = issue.get("suggestion", "")
    metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
    failing_scenario = metadata.get("failing_scenario", "")

    prompt_parts = [
        "You are selecting the best target test file for a test coverage gap.",
        "Return ONLY valid JSON with keys: target_test_file, confidence, rationale.",
        "confidence must be a float between 0 and 1.",
        "",
        f"Source file: {source_path}" + (f" (line {line_number})" if line_number else ""),
    ]
    if description:
        prompt_parts.append(f"Description: {description}")
    if suggestion:
        prompt_parts.append(f"Suggested fix: {suggestion}")
    if failing_scenario:
        prompt_parts.append(f"Failing scenario: {failing_scenario}")

    if candidate_paths:
        prompt_parts.append("")
        prompt_parts.append("Candidate test files:")
        for path in candidate_paths:
            prompt_parts.append(f"- {path}")
        prompt_parts.append("")
        prompt_parts.append("Prefer an existing candidate if it matches conventions.")
    else:
        prompt_parts.append("")
        prompt_parts.append("No candidate test files were found.")
        prompt_parts.append("Propose a new test file path that matches project conventions.")

    prompt_parts.append("")
    prompt_parts.append("Example response:")
    prompt_parts.append(
        '{"target_test_file": "tests/test_board.py", "confidence": 0.82, "rationale": "Matches source module name and existing tests directory."}'
    )

    return "\n".join(prompt_parts)
