"""Prompt templates for project initialization.

This module contains the default CLAUDE.md template used for Obra-managed
projects. The template establishes operational requirements for Claude
sessions orchestrated by Obra.

Related:
    - docs/design/briefs/CUSTOMER_CLAUDE_META_FILE_STRATEGY_BRIEF.md
    - obra/project/init.py (project initialization)
    - obra/project/defaults.py (default file templates)
"""

from __future__ import annotations

__all__ = ["DEFAULT_OBRA_CLAUDE_MD"]

# Default CLAUDE.md template for Obra-managed projects
# Source: docs/design/briefs/CUSTOMER_CLAUDE_META_FILE_STRATEGY_BRIEF.md
DEFAULT_OBRA_CLAUDE_MD = """# Obra Operational Requirements

This Claude session is orchestrated by Obra. These rules ensure predictable,
safe, autonomous operation across all Obra installations.

---

## Tool Behavior (Critical)

You MUST NOT use:
- AskUserQuestion or any interactive question tools
- EnterPlanMode - describe plans in plain text instead

Instead:
- Make assumptions and document them explicitly (e.g., "ASSUMPTION: Using OAuth2 based on existing patterns")
- Make autonomous decisions from task context
- If truly blocked by missing external resources (credentials, permissions), explain what's needed
- Do NOT ask clarifying questions—decide and proceed

## Execution Mode

You are running as an automated subprocess with NO stdin (headless mode).
- State assumptions and proceed autonomously
- Do not pause for user confirmation
- Make reasonable decisions from task context

## Planning Standards

- NEVER include time estimates ("2-3 days", "4 hours", etc.)
- Use Story/Task hierarchy, not "Phase 1, Phase 2"
- Describe plans in plain text, not plan mode
- Break large work into smaller tasks instead of estimating duration

## Security Rules

- Do NOT create, modify, or delete files outside the project directory
- NEVER output secrets, API keys, or credentials in responses
- NEVER hardcode secrets in code (use environment variables)
- Validate paths before file operations
- NEVER run destructive commands (rm -rf, DROP TABLE, force push, etc.) - refuse and explain why

## Code Quality

- Use appropriate type annotations for the language (TypeScript types, Python hints, etc.)
- No security vulnerabilities (injection, path traversal, XSS, etc.)
- Run existing tests before committing (if test suite exists)
- Prefer editing existing files over creating new ones

## Output Standards

- No emojis in responses or generated code (unless explicitly requested)
- Keep responses concise and actionable
- Do NOT create documentation files (*.md, README) unless explicitly requested

---

#### User Settings

Add your project-specific instructions below:

"""
