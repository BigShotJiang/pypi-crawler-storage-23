"""
Warning domain message templates.

Templates for deprecation notices, quality warnings, cache warnings,
version warnings, and runtime warnings.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    MessageDomain,
    MessageTemplate,
    WarningCategory,
)

__all__ = [
    "TEMPLATES",
    "build_cache_warning",
    "build_deprecation_warning",
    "get_warning",
]

# =============================================================================
# Warning Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Deprecation Category
    # -------------------------------------------------------------------------
    "warning.deprecation.flag": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.DEPRECATION,
        template="Warning: {old} is deprecated. Use '{new}' instead.",
        verbose_template=(
            "Deprecation warning:\n"
            "  {old} is deprecated and will be removed in a future version.\n"
            "  Use '{new}' instead."
        ),
        placeholders=("old", "new"),
    ),
    "warning.deprecation.command": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.DEPRECATION,
        template="'{old}' is deprecated. Use '{new}' instead.",
        verbose_template=(
            "Command deprecation:\n"
            "  '{old}' is deprecated and will be removed.\n"
            "  Please use '{new}' instead."
        ),
        placeholders=("old", "new"),
    ),
    "warning.deprecation.option": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.DEPRECATION,
        template="Option {old} is deprecated. Use {new} instead.",
        verbose_template=(
            "Option deprecation:\n  {old} is deprecated.\n  Please use {new} instead."
        ),
        placeholders=("old", "new"),
    ),
    "warning.deprecation.config_key": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.DEPRECATION,
        template="Config key '{old}' is deprecated. Use '{new}'.",
        verbose_template=(
            "Configuration deprecation:\n"
            "  The config key '{old}' is deprecated.\n"
            "  Please update to '{new}' in your configuration."
        ),
        placeholders=("old", "new"),
    ),
    "warning.deprecation.model": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.DEPRECATION,
        template="Model '{old}' has been superseded and may not work.",
        verbose_template=(
            "Model deprecation:\n"
            "  Model '{old}' has been superseded and may not work.\n"
            "  Consider using a newer model for best results."
        ),
        placeholders=("old",),
    ),
    "warning.deprecation.package": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.DEPRECATION,
        template="Package '{old}' has been superseded. Use '{new}' instead.",
        verbose_template=(
            "Package deprecation:\n"
            "  The package '{old}' has been superseded.\n"
            "  Please update all imports to use '{new}' instead."
        ),
        placeholders=("old", "new"),
    ),
    # -------------------------------------------------------------------------
    # Quality Category
    # -------------------------------------------------------------------------
    "warning.quality.input_check": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.QUALITY,
        template="Input Quality Check",
        ascii_template="[!] Input Quality Check",
    ),
    "warning.quality.objective_vague": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.QUALITY,
        template="Objective may be too vague for effective execution.",
        verbose_template=(
            "Objective quality warning:\n"
            "The objective may be too vague for effective execution.\n"
            "Consider providing more specific requirements."
        ),
    ),
    # -------------------------------------------------------------------------
    # Cache Category
    # -------------------------------------------------------------------------
    "warning.cache.size_warning": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.CACHE,
        template="Cache size exceeds {threshold}MB",
        verbose_template=(
            "Cache size warning:\n"
            "  Cache size exceeds {threshold}MB.\n"
            "  Consider clearing old cache entries."
        ),
        placeholders=("threshold",),
    ),
    "warning.cache.size_critical": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.CACHE,
        template="Cache size critical: {size}MB exceeds {threshold}MB limit",
        verbose_template=(
            "Critical cache warning:\n"
            "  Cache size ({size}MB) exceeds the {threshold}MB limit.\n"
            "  Immediate cleanup recommended."
        ),
        placeholders=("size", "threshold"),
    ),
    # -------------------------------------------------------------------------
    # Version Category
    # -------------------------------------------------------------------------
    "warning.version.update_available": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.VERSION,
        template="Update available: {version}",
        verbose_template=(
            "A newer version of Obra is available: {version}\n"
            "Run 'pip install --upgrade obra' to update."
        ),
        placeholders=("version",),
    ),
    "warning.version.incompatible": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.VERSION,
        template="Version {version} may be incompatible",
        verbose_template=(
            "Version compatibility warning:\n"
            "  Version {version} may be incompatible with current server.\n"
            "  Consider upgrading for best results."
        ),
        placeholders=("version",),
    ),
    # -------------------------------------------------------------------------
    # Runtime Category
    # -------------------------------------------------------------------------
    "warning.runtime.generic": MessageTemplate(
        domain=MessageDomain.WARNING,
        category=WarningCategory.RUNTIME,
        template="Warning: {message}",
        placeholders=("message",),
    ),
}


# =============================================================================
# Builder Functions (FR-3)
# =============================================================================


def get_warning(key: str, **kwargs: Any) -> str:
    """
    Get a warning message with automatic domain prefix.

    Args:
        key: Key without 'warning.' prefix (e.g., 'deprecation.flag')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"warning.{key}", **kwargs)


def build_deprecation_warning(old: str, new: str) -> str:
    """
    Build a deprecation warning message.

    Args:
        old: The deprecated item (flag, command, option, etc.)
        new: The replacement item

    Returns:
        Formatted deprecation warning
    """
    from obra.messages.registry import get_message

    return get_message("warning.deprecation.flag", old=old, new=new)


def build_cache_warning(path: str, size: int, threshold: int) -> str:
    """
    Build a cache size warning message with path context.

    Args:
        path: Path to the cache directory
        size: Current cache size in MB
        threshold: Warning threshold in MB

    Returns:
        Formatted cache warning with context
    """
    from obra.messages.registry import get_message

    if size >= threshold:
        msg = get_message("warning.cache.size_critical", size=size, threshold=threshold)
    else:
        msg = get_message("warning.cache.size_warning", threshold=threshold)

    return f"{msg}\n  Location: {path}"
