"""Shared constants grouped by category for reuse across Obra."""

"""HTTP status codes."""

HTTP_OK = 200
HTTP_CREATED = 201
HTTP_ACCEPTED = 202
HTTP_NO_CONTENT = 204
HTTP_BAD_REQUEST = 400
HTTP_UNAUTHORIZED = 401
HTTP_FORBIDDEN = 403
HTTP_NOT_FOUND = 404
HTTP_CONFLICT = 409
HTTP_UNPROCESSABLE_ENTITY = 422
HTTP_TOO_MANY_REQUESTS = 429
HTTP_INTERNAL_SERVER_ERROR = 500
HTTP_BAD_GATEWAY = 502
HTTP_SERVICE_UNAVAILABLE = 503
HTTP_GATEWAY_TIMEOUT = 504

"""Timeouts and retries."""

DEFAULT_NETWORK_TIMEOUT_S = 30
DEFAULT_AUTH_TIMEOUT_S = 300
DEFAULT_RETRY_COUNT = 3
DEFAULT_RETRY_BACKOFF_S = 1.0
DEFAULT_RETRY_MAX_DELAY_S = 30.0
PYPI_TIMEOUT_S = 2
VERSION_CHECK_EXIT_TIMEOUT_S = 3.0
# DEPRECATED: Use obra.config.loaders.get_llm_timeouts() instead. Config path: timeouts.auto_assessor_s
AUTO_ASSESSOR_TIMEOUT_S = 900  # 15 min - LLM quality assessment (ISSUE-SIM-001)
# DEPRECATED: Use get_auto_story_timeout_s() from obra.config.loaders
AUTO_STORY_TIMEOUT_S = 3600  # 1 hour - full story execution
# DEPRECATED: Use obra.config.loaders.get_llm_timeouts() instead. Config path: timeouts.llm_subprocess_s
LLM_SUBPROCESS_TIMEOUT_S = 900  # 15 min - LLM subprocess calls (ISSUE-SIM-001)
LLM_MONITOR_STOP_TIMEOUT_S = 2.0
LLM_STDERR_JOIN_TIMEOUT_S = 5
# DEPRECATED: Use obra.config.loaders.get_ollama_timeouts() instead. Config path: timeouts.ollama.default_s
OLLAMA_DEFAULT_TIMEOUT_S = 900  # 15 min - Ollama LLM calls (ISSUE-SIM-001)
OLLAMA_STATUS_TIMEOUT_S = 5  # Status check (not LLM call)
OLLAMA_STATUS_READY_TIMEOUT_S = 10  # Ready check (not LLM call)
# DEPRECATED: Use obra.config.loaders.get_api_timeouts() instead. Config path: api.timeouts.feedback_submission_s
FEEDBACK_SUBMIT_TIMEOUT_S = 60
PROMPT_ENRICHER_GIT_LOG_TIMEOUT_S = 5
# DEPRECATED: Use config path hybrid.polling.max_delay_s via get_hybrid_polling_config() from obra.config.loaders
HYBRID_POLLING_MAX_DELAY_S = 30.0
# DEPRECATED: Use config path hybrid.polling.backoff_multiplier via get_hybrid_polling_config() from obra.config.loaders
HYBRID_POLLING_BACKOFF_MULTIPLIER = 2.0
# DEPRECATED: Use config path hybrid.polling.base_delay_s via get_hybrid_polling_config() from obra.config.loaders
HYBRID_POLLING_BASE_DELAY_S = 1.0

# Interval between liveness checks for LLM subprocesses (seconds). Used by all handlers.
LIVENESS_CHECK_INTERVAL_S = 180

"""Thresholds and limits."""

MAX_POLLING_RETRIES = 5
MAX_PROMPT_FILES = 200
MAX_STORIES_PER_RUN = 50
LLM_INVOKER_MAX_RETRIES = DEFAULT_RETRY_COUNT
LLM_RETRY_DEFAULT_BASE_DELAY_S = 8.0
LLM_RETRY_DEFAULT_MAX_ATTEMPTS = 3
LLM_RETRY_DEFAULT_AUTH_MAX_ATTEMPTS = 3
LLM_RETRY_DEFAULT_RATE_LIMIT_MAX_ATTEMPTS = 1
LLM_RETRY_DEFAULT_MAX_DELAY_S = 120.0
# DEPRECATED: Use config path review.complexity.simple.max_words via get_review_complexity_simple() from obra.config.loaders
REVIEW_SIMPLE_MAX_WORDS = 20
# DEPRECATED: Use config path review.complexity.simple.max_files via get_review_complexity_simple() from obra.config.loaders
REVIEW_SIMPLE_MAX_FILES = 2
# DEPRECATED: Use config path review.complexity.simple.max_lines via get_review_complexity_simple() from obra.config.loaders
REVIEW_SIMPLE_MAX_LINES = 50
# DEPRECATED: Use config path review.complexity.medium.max_files via get_review_complexity_medium() from obra.config.loaders
REVIEW_MEDIUM_MAX_FILES = 5
# DEPRECATED: Use config path review.complexity.medium.max_lines via get_review_complexity_medium() from obra.config.loaders
REVIEW_MEDIUM_MAX_LINES = 200
# DEPRECATED: Use config path intent.context.max_items via get_intent_context_max_items() from obra.config.loaders
REVIEW_INTENT_CONTEXT_MAX_ITEMS = 5
# DEPRECATED: Use config path intent.context.max_item_chars via get_intent_context_max_item_chars() from obra.config.loaders
REVIEW_INTENT_CONTEXT_MAX_ITEM_CHARS = 200
# DEPRECATED: Use config path intent.context.max_chars via get_intent_context_max_chars() from obra.config.loaders
REVIEW_INTENT_CONTEXT_MAX_CHARS = 1200
# DEPRECATED: Use config path intent.slug_max_length via get_intent_slug_max_length() from obra.config.loaders
INTENT_SLUG_MAX_LENGTH = 50
# DEPRECATED: Use get_intent_thresholds_config()['detection_empty'] from obra.config.loaders
INTENT_DETECTION_EMPTY_THRESHOLD = 5
# DEPRECATED: Use get_intent_thresholds_config()['detection_existing'] from obra.config.loaders
INTENT_DETECTION_EXISTING_THRESHOLD = 50
INTENT_VAGUE_MAX_WORDS = 10
INTENT_VAGUE_MAX_CHARS = 100
FEEDBACK_MAX_SESSIONS = 10
FEEDBACK_SANITIZER_MAX_LENGTH = 500
FEEDBACK_SANITIZER_MAX_LINES = 20
FEEDBACK_PROMPT_TRUNCATE_FIRST_CHARS = 500
FEEDBACK_PROMPT_TRUNCATE_LAST_CHARS = 200
FEEDBACK_TRACEBACK_MAX_LINES = 20
FEEDBACK_LOG_MAX_LINES = 500
FEEDBACK_LOG_MIN_LINES = 20
FEEDBACK_LOG_STANDARD_LINES = 100
FEEDBACK_OBSERVABILITY_MAX_AGE_HOURS = 24
WORKFLOW_CUSTOMER_CONFIDENCE_THRESHOLD = 0.8
WORKFLOW_TIERED_CONFIDENCE_THRESHOLD = 0.6
WORKFLOW_OBRA_CONFIDENCE_THRESHOLD = 0.7
WORKFLOW_SOTA_CONFIDENCE_THRESHOLD = 0.6
WORKFLOW_FALLBACK_CONFIDENCE_THRESHOLD = 0.0
EVENT_LOG_MAX_BACKUP_COUNT = 5
PROMPT_ENRICHER_FILE_LIMIT = 30
PROMPT_ENRICHER_RECENT_COMMITS_LIMIT = 5
PROMPT_ENRICHER_RECENT_ERRORS_LIMIT = 5
# DEPRECATED: Use get_intent_thresholds_config()['interrogative_ratio'] from obra.config.loaders
INTENT_INTERROGATIVE_RATIO_THRESHOLD = 0.5
# DEPRECATED: Use config path intent.rate_limit.max_retries via get_intent_rate_limit_config() from obra.config.loaders
INTENT_RATE_LIMIT_MAX_RETRIES = 3
# DEPRECATED: Use config path intent.rate_limit.backoff_delays_s via get_intent_rate_limit_config() from obra.config.loaders
INTENT_RATE_LIMIT_BACKOFF_DELAYS_S = (2.0, 4.0, 8.0)
API_DEFAULT_TIMEOUT_S = DEFAULT_NETWORK_TIMEOUT_S
API_MAX_RETRIES = DEFAULT_RETRY_COUNT
API_TOKEN_REFRESH_THRESHOLD_MINUTES = 5
API_SESSIONS_DEFAULT_LIMIT = 10
API_EVENTS_DEFAULT_LIMIT = 100
API_PLANS_DEFAULT_LIMIT = 50
API_USER_FEEDBACK_DEFAULT_LIMIT = 20
API_LIMIT_MAX = 100
# DEPRECATED: Use obra.config.loaders.get_api_retry_delays() instead. Config path: api.retry_delays_s
API_RETRY_DELAYS_S = (1, 2, 4)

# Connection pool settings (ISSUE-HYBRID-001)
# DEPRECATED: Use obra.config.loaders.get_api_connection_pool_config() instead. Config path: api.connection_pool.timeout_s
API_CONNECT_TIMEOUT_S = 10  # Separate connect timeout for hung connection detection
# DEPRECATED: Use obra.config.loaders.get_api_connection_pool_config() instead. Config path: api.connection_pool.connections
API_POOL_CONNECTIONS = 10  # Number of connection pools to cache
# DEPRECATED: Use obra.config.loaders.get_api_connection_pool_config() instead. Config path: api.connection_pool.maxsize
API_POOL_MAXSIZE = 10  # Max connections per host
# DEPRECATED: Use obra.config.loaders.get_api_connection_pool_config() instead. Config path: api.connection_pool.retry_total
API_POOL_RETRY_TOTAL = 3  # Total retry attempts for connection failures
# DEPRECATED: Use obra.config.loaders.get_api_connection_pool_config() instead. Config path: api.connection_pool.retry_connect
API_POOL_RETRY_CONNECT = 3  # Retry on connection errors (CLOSE_WAIT, refused)
# DEPRECATED: Use obra.config.loaders.get_api_connection_pool_config() instead. Config path: api.connection_pool.retry_backoff
API_POOL_RETRY_BACKOFF = 0.5  # Backoff factor: 0.5s, 1s, 2s between retries

# Fallback output token budget when model-specific budget unavailable. Used by all LLM providers.
FALLBACK_OUTPUT_BUDGET = 16_384

# DEPRECATED: Use obra.config.loaders.get_thinking_config() instead. Config path: llm.thinking.min_tokens
THINKING_MIN_TOKENS = 1024

# DEPRECATED: Use obra.config.loaders.get_thinking_config() instead. Config path: llm.thinking.standard_tokens
THINKING_STANDARD_TOKENS = 8000

# DEPRECATED: Use obra.config.loaders.get_thinking_config() instead. Config path: llm.thinking.max_tokens
THINKING_MAX_TOKENS = 31999

# DEPRECATED: Use obra.config.loaders.get_thinking_config() instead. Config path: llm.thinking (not exposed separately)
THINKING_HIGH_TOKENS = 16000

# DEPRECATED: Use obra.config.loaders.get_thinking_config() instead. Config path: llm.thinking.default_budget
THINKING_DEFAULT_BUDGET_TOKENS = 10000

"""Intent extraction token budget."""

# Maximum tokens for intent extraction input
# Default 120K tokens for Claude models (200K context - 80K for prompt+output)
# Can be overridden via OBRA_INTENT_TOKEN_BUDGET environment variable
INTENT_TOKEN_BUDGET_DEFAULT = 120_000

# DEPRECATED: Use config path intent.chunking.size_tokens via get_intent_chunking_config() from obra.config.loaders
# Chunk size for splitting large inputs (tokens)
# When input exceeds budget, split into chunks of this size
INTENT_CHUNK_SIZE_TOKENS = 80_000

# DEPRECATED: Use config path intent.chunking.overlap_tokens via get_intent_chunking_config() from obra.config.loaders
# Overlap between chunks (tokens) to maintain context continuity
INTENT_CHUNK_OVERLAP_TOKENS = 2000

# DEPRECATED: Use get_intent_thresholds_config()['token_warning'] from obra.config.loaders
# Warning threshold - warn when input is above this percentage of budget
INTENT_TOKEN_WARNING_THRESHOLD = 0.8  # 80%

"""Sizes and ports."""

KIBIBYTE = 1024
MEBIBYTE = 1024 * KIBIBYTE
GIBIBYTE = 1024 * MEBIBYTE
EVENT_LOG_MAX_SIZE_BYTES = 10 * MEBIBYTE
FEEDBACK_MAX_ATTACHMENT_SIZE_BYTES = 5 * MEBIBYTE
FEEDBACK_MAX_TOTAL_ATTACHMENTS_SIZE_BYTES = 10 * MEBIBYTE
DEFAULT_HTTP_PORT = 80
DEFAULT_HTTPS_PORT = 443
DEFAULT_GRPC_PORT = 50051

"""Auto-decomposition settings (S9)."""

# DEPRECATED: Use config path derivation.auto_decompose.failure_threshold via get_derivation_auto_decompose_config() from obra.config.loaders
# Number of consecutive failures before auto-decomposition is triggered
# See docs/exploration/S9-T1-auto-decomposition-triggers.md
AUTO_DECOMPOSE_FAILURE_THRESHOLD = 3

# DEPRECATED: Use config path derivation.auto_decompose.max_depth via get_derivation_auto_decompose_config() from obra.config.loaders
# Maximum depth for recursive decomposition (aligns with MAX_DERIVATION_DEPTH)
AUTO_DECOMPOSE_MAX_DEPTH = 3

"""Budget monitoring settings (S9.T1b)."""

# DEPRECATED: Use config path derivation.task.token_budget via get_derivation_task_config() from obra.config.loaders
# Default token budget per task (100K tokens per task)
DEFAULT_TASK_TOKEN_BUDGET = 100_000

# DEPRECATED: Use config path derivation.task.cost_budget_usd via get_derivation_task_config() from obra.config.loaders
# Default cost budget per task in USD (e.g., $0.50 per task)
DEFAULT_TASK_COST_BUDGET_USD = 0.50

# DEPRECATED: Use config path derivation.budget.decompose_threshold via get_derivation_budget_config() from obra.config.loaders
# Threshold percentage at which to trigger auto-decomposition
# When budget consumption exceeds this threshold without completion, flag for decomposition
BUDGET_DECOMPOSE_THRESHOLD = 0.80  # 80% of allocated budget

# DEPRECATED: Use config path derivation.budget.warning_threshold via get_derivation_budget_config() from obra.config.loaders
# Warning threshold - log warning when approaching decomposition threshold
BUDGET_WARNING_THRESHOLD = 0.60  # 60% of allocated budget

# DEPRECATED: Use config path derivation.budget.min_subtask_ratio via get_derivation_budget_config() from obra.config.loaders
# Minimum remaining budget ratio to pass to subtasks during decomposition
# Ensures subtasks get at least this much of original budget
MIN_SUBTASK_BUDGET_RATIO = 0.10  # At least 10% of original budget
