"""Navigation Menu widget for config explorer entry points.

Provides 9 entry points ordered by increasing complexity:
0. Personas - Behavior presets (safety/autonomy)
1. LLM Simple - Single provider/model
2. LLM Moderate - Tier-based models
3. LLM Custom - Per-action control
4. Pipeline Options - Behavior settings
5. Specialized Agents - Review agents
6. Pre-Execution Setup - Environment, tooling, automation
7. Debug & Advanced - Prompts, logging, breakpoints, timeouts
8. Full Config - Raw access (most complex)
"""

from textual.app import ComposeResult
from textual.containers import Container, Vertical
from textual.message import Message
from textual.widgets import Button, Static

# Entry point definitions: (id, label, subtitle)
# Ordered by increasing complexity (0 = simplest, 8 = most complex)
ENTRY_POINTS = [
    ("personas", "0. Personas", "Behavior presets - Safety rails and autonomy level."),
    ("simple_llm", "1. LLM Simple", "Basic setup - Pick provider and model."),
    (
        "moderate_llm",
        "2. LLM Moderate",
        "Tier-based - Configure fast/medium/high models.",
    ),
    (
        "custom_llm",
        "3. LLM Custom",
        "Per-action - Fine-tune model for each pipeline action.",
    ),
    (
        "pipeline",
        "4. Pipeline Options",
        "Behavior - Iterations, timeouts, thresholds. See inherited models.",
    ),
    (
        "agents",
        "5. Specialized Agents",
        "Specialized agents - Review, security, testing.",
    ),
    (
        "validation",
        "6. Pre-Execution Setup",
        "Environment preparation, tooling detection, and automation.",
    ),
    (
        "debug_advanced",
        "7. Debug & Advanced",
        "Prompts, logging, breakpoints, timeouts, and monitoring.",
    ),
    ("full_config", "8. Full Config", "Everything - Raw access to all settings."),
]

# Build lookup dict for quick access by entry_point ID
_ENTRY_POINT_LOOKUP = {ep[0]: {"label": ep[1], "subtitle": ep[2]} for ep in ENTRY_POINTS}


def get_menu_info(entry_point: str) -> dict[str, str]:
    """Get menu info (label, subtitle) for an entry point.

    Args:
        entry_point: Entry point ID (e.g., 'moderate_llm')

    Returns:
        Dict with 'label' and 'subtitle' keys, or defaults if not found.

    Example:
        >>> get_menu_info('moderate_llm')
        {'label': '2. LLM Moderate', 'subtitle': 'Tier-based - Configure fast/medium/high models.'}
    """
    return _ENTRY_POINT_LOOKUP.get(entry_point, {"label": entry_point, "subtitle": ""})


class NavigationMenu(Static):
    """Navigation menu with 9 entry points for config explorer.

    Renders buttons for each entry point with subtitles describing the workflow.
    Emits Selected message when user clicks a button.
    """

    DEFAULT_CSS = """
    NavigationMenu {
        width: 100%;
        height: auto;
        align: center middle;
        padding: 1 2;
    }

    NavigationMenu > Vertical {
        width: auto;
        height: auto;
        align: center middle;
    }

    NavigationMenu .title {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    NavigationMenu .entry-container {
        width: auto;
        height: auto;
        margin-bottom: 1;
        align: center middle;
    }

    NavigationMenu Button {
        width: 50;
        margin-bottom: 0;
    }

    NavigationMenu .subtitle {
        width: 50;
        color: $text-muted;
        text-align: center;
        margin-bottom: 1;
    }
    """

    class Selected(Message):
        """Message emitted when an entry point is selected."""

        def __init__(self, entry_point: str) -> None:
            """Initialize the Selected message.

            Args:
                entry_point: ID of the selected entry point
            """
            super().__init__()
            self.entry_point = entry_point

    def compose(self) -> ComposeResult:
        """Create the navigation menu content."""
        with Vertical():
            yield Static("Configuration Explorer", classes="title")
            yield Static("Select a configuration area:", classes="title")

            for entry_id, label, subtitle in ENTRY_POINTS:
                with Container(classes="entry-container"):
                    yield Button(label, id=entry_id)
                    yield Static(subtitle, classes="subtitle")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks by emitting Selected message."""
        entry_point = event.button.id
        if entry_point:
            self.post_message(self.Selected(entry_point))
