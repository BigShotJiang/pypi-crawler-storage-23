"""Autonomous workplan execution.

This package provides the autonomous runner that executes multi-story
workplans without continuous LLM attention:

- AutoRunner: Main orchestration loop for story sequencing
- PlanReader: Loads and updates MACHINE_PLAN.json
- ErrorHandler: Retry/skip/escalate logic for failures
- ErrorAssessor: Optional LLM-based error assessment

Related:
    - docs/design/briefs/AUTONOMOUS_RUNNER_BRIEF.md
    - docs/development/AUTO-RUN-001_IMPLEMENTATION_PLAN.md
"""

from obra.auto.assessor import ErrorAssessor
from obra.auto.error_handler import ErrorHandler
from obra.auto.plan_reader import PlanReader
from obra.auto.runner import AutoRunner

__all__ = [
    "AutoRunner",
    "ErrorAssessor",
    "ErrorHandler",
    "PlanReader",
]
