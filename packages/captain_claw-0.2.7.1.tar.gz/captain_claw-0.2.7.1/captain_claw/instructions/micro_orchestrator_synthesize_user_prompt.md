Original request:
{user_input}

Task results:
{task_results}

Synthesis instruction:
{synthesis_instruction}

Provide final answer from task results. Note failures. Be concise but thorough.