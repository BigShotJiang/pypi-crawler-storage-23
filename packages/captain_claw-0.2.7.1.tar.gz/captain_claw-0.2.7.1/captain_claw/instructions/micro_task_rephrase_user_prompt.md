Rewrite into a structured prompt for the AI agent.

User's task:
{user_input}

Return ONLY the restructured prompt.