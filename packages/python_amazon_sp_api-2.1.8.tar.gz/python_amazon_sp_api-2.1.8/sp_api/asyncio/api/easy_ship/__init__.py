from .easy_ship import EasyShip

__all__ = [
    "EasyShip",
]