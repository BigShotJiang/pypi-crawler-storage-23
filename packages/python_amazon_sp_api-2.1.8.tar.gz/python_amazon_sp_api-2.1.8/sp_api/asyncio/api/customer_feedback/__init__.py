from .customer_feedback import CustomerFeedback

__all__ = [
    "CustomerFeedback",
]