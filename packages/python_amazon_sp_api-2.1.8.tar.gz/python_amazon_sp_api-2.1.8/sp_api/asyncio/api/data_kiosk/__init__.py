from .data_kiosk import DataKiosk

__all__ = [
    "DataKiosk",
]