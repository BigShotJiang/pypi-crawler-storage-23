from sp_api.auth.exceptions import AuthorizationError

__all__ = [
    "AuthorizationError",
]
