from enum import Enum


class InventoryGranularity(str, Enum):
    MARKETPLACE = "Marketplace"
