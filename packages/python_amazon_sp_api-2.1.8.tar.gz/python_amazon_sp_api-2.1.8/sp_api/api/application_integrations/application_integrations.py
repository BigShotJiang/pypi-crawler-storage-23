import urllib.parse

from sp_api.base import Client, sp_endpoint, fill_query_params, ApiResponse


class ApplicationIntegrations(Client):
    """
    ApplicationIntegrations SP-API Client
    :link: 

    With the AppIntegrations API v2024-04-01, you can send notifications to Amazon Selling Partners and display the notifications in Seller Central.
    """


    @sp_endpoint('/appIntegrations/2024-04-01/notifications', method='POST')
    def create_notification(self, **kwargs) -> ApiResponse:
        """
        create_notification(self, **kwargs) -> ApiResponse
        
        Create a notification for sellers in Seller Central.
        
        **Usage Plan:**
        
        ======================================  ==============
        Rate (requests per second)               Burst
        ======================================  ==============
        1                                       5
        ======================================  ==============
        
        For more information, see "Usage Plans and Rate Limits" in the Selling Partner API documentation.
        
        Examples:
            literal blocks::
            
                ApplicationIntegrations().create_notification()
        
        Args:
            body: CreateNotificationRequest | required The request body for the `createNotification` operation.
        
        Returns:
            ApiResponse
        """
    
        return self._request(kwargs.pop('path'), data=kwargs)
    

    @sp_endpoint('/appIntegrations/2024-04-01/notifications/deletion', method='POST')
    def delete_notifications(self, **kwargs) -> ApiResponse:
        """
        delete_notifications(self, **kwargs) -> ApiResponse
        
        Remove your application's notifications from the Appstore notifications dashboard.
        
        **Usage Plan:**
        
        ======================================  ==============
        Rate (requests per second)               Burst
        ======================================  ==============
        1                                       5
        ======================================  ==============
        
        For more information, see "Usage Plans and Rate Limits" in the Selling Partner API documentation.
        
        Examples:
            literal blocks::
            
                ApplicationIntegrations().delete_notifications()
        
        Args:
            body: DeleteNotificationsRequest | required The request body for the `deleteNotifications` operation.
        
        Returns:
            ApiResponse
        """
    
        return self._request(kwargs.pop('path'), data=kwargs)
    

    @sp_endpoint('/appIntegrations/2024-04-01/notifications/{}/feedback', method='POST')
    def record_action_feedback(self, notificationId, **kwargs) -> ApiResponse:
        """
        record_action_feedback(self, notificationId, **kwargs) -> ApiResponse
        
        Records the seller's response to a notification.
        
        **Usage Plan:**
        
        ======================================  ==============
        Rate (requests per second)               Burst
        ======================================  ==============
        1                                       5
        ======================================  ==============
        
        For more information, see "Usage Plans and Rate Limits" in the Selling Partner API documentation.
        
        Examples:
            literal blocks::
            
                ApplicationIntegrations().record_action_feedback("value")
        
        Args:
            notificationId: object | required A `notificationId` uniquely identifies a notification.
            body: RecordActionFeedbackRequest | required The request body for the `recordActionFeedback` operation.
        
        Returns:
            ApiResponse
        """
    
        return self._request(fill_query_params(kwargs.pop('path'), notificationId), data=kwargs)
