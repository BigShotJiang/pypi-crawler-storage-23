from application_sdk.workflows import WorkflowInterface


class QueryExtractionWorkflow(WorkflowInterface):
    pass
