# Testing

- Test command and conventions: `.cursor/rules/testing.mdc`.
- New code should target 85% coverage per `.cursor/BUGBOT.md` (the tooling threshold in `pyproject.toml` is 50%).
- Current tests live in `tests/unit/`; follow existing structure when adding new tests.
