# Code Review

- Use `.cursor/BUGBOT.md` as the review checklist for security, performance, stability, and testing risks.
