# Documentation Updates

- When changing `application_sdk` modules, update the matching conceptual docs per `.cursor/rules/documentation.mdc`.
- Conceptual docs live under `docs/concepts/` (see the mapping in that rule file).
