from pydantic import BaseModel


class Evidence(BaseModel):
    id: int
    content: str
    source: dict | None = None
    score: float | None = None
    created_at: str


class Skill(BaseModel):
    id: str
    title: str
    file_path: str
    created_at: str
    updated_at: str | None = None


class Outcome(BaseModel):
    id: int
    skill_id: str
    success: bool
    notes: str
    created_at: str


class SkillDocument(BaseModel):
    title: str
    content: str
