# Copyright (c) 2026 Pointmatic
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Output file writing (JSON, txt, VTT, SRT)."""

from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path

from tubefetch.core.models import BatchResult, Metadata, Transcript
from tubefetch.utils.time_fmt import seconds_to_srt, seconds_to_vtt

logger = logging.getLogger("tubefetch")


def write_metadata(metadata: Metadata, out_dir: Path) -> Path:
    """Write metadata as JSON. Returns the written file path."""
    video_dir = out_dir / metadata.video_id
    video_dir.mkdir(parents=True, exist_ok=True)
    dest = video_dir / "metadata.json"
    _atomic_write_json(dest, metadata.model_dump(mode="json"))
    return dest


def read_metadata(out_dir: Path, video_id: str) -> Metadata | None:
    """Read cached metadata.json and return a Metadata model.

    Returns None if the file does not exist or cannot be parsed.
    """
    path = Path(out_dir) / video_id / "metadata.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return Metadata.model_validate(data)
    except Exception as exc:
        logger.warning("Failed to read cached metadata for %s: %s", video_id, exc)
        return None


def read_transcript_json(out_dir: Path, video_id: str) -> Transcript | None:
    """Read cached transcript.json and return a Transcript model.

    Returns None if the file does not exist or cannot be parsed.
    """
    path = Path(out_dir) / video_id / "transcript.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return Transcript.model_validate(data)
    except Exception as exc:
        logger.warning("Failed to read cached transcript for %s: %s", video_id, exc)
        return None


def write_transcript_json(transcript: Transcript, out_dir: Path) -> Path:
    """Write transcript as JSON. Returns the written file path."""
    video_dir = out_dir / transcript.video_id
    video_dir.mkdir(parents=True, exist_ok=True)
    dest = video_dir / "transcript.json"
    _atomic_write_json(dest, transcript.model_dump(mode="json"))
    return dest


def write_transcript_txt(transcript: Transcript, out_dir: Path) -> Path:
    """Write transcript as plain text (no timestamps). Returns the written file path."""
    video_dir = out_dir / transcript.video_id
    video_dir.mkdir(parents=True, exist_ok=True)
    dest = video_dir / "transcript.txt"
    lines = [seg.text for seg in transcript.segments]
    _atomic_write_text(dest, "\n".join(lines) + "\n")
    return dest


def write_transcript_vtt(transcript: Transcript, out_dir: Path) -> Path:
    """Write transcript as WebVTT. Returns the written file path."""
    video_dir = out_dir / transcript.video_id
    video_dir.mkdir(parents=True, exist_ok=True)
    dest = video_dir / "transcript.vtt"

    parts = ["WEBVTT", ""]
    for seg in transcript.segments:
        start = seconds_to_vtt(seg.start)
        end = seconds_to_vtt(seg.start + seg.duration)
        parts.append(f"{start} --> {end}")
        parts.append(seg.text)
        parts.append("")

    _atomic_write_text(dest, "\n".join(parts))
    return dest


def write_transcript_srt(transcript: Transcript, out_dir: Path) -> Path:
    """Write transcript as SRT. Returns the written file path."""
    video_dir = out_dir / transcript.video_id
    video_dir.mkdir(parents=True, exist_ok=True)
    dest = video_dir / "transcript.srt"

    parts = []
    for i, seg in enumerate(transcript.segments, start=1):
        start = seconds_to_srt(seg.start)
        end = seconds_to_srt(seg.start + seg.duration)
        parts.append(str(i))
        parts.append(f"{start} --> {end}")
        parts.append(seg.text)
        parts.append("")

    _atomic_write_text(dest, "\n".join(parts))
    return dest


def write_summary(results: BatchResult, out_dir: Path) -> Path:
    """Write a batch summary as JSON. Returns the written file path."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    dest = out_dir / "summary.json"
    _atomic_write_json(dest, results.model_dump(mode="json"))
    return dest


def _atomic_write_json(dest: Path, data: dict) -> None:
    """Write JSON atomically: write to temp file, then rename."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=dest.parent, suffix=".tmp", prefix=".tubefetch_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str, ensure_ascii=False)
            f.write("\n")
        os.replace(tmp_path, dest)
    except BaseException:
        os.unlink(tmp_path)
        raise


def _atomic_write_text(dest: Path, content: str) -> None:
    """Write text atomically: write to temp file, then rename."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=dest.parent, suffix=".tmp", prefix=".tubefetch_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp_path, dest)
    except BaseException:
        os.unlink(tmp_path)
        raise
