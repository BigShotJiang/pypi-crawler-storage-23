/// Docs
///
/// More docs
#[derive(Debug, rusmpp_macros::Rusmpp)]
#[rusmpp(decode = skip)]
pub struct DistributionListName {
    /// Docs
    ///
    /// More docs
    dest_flag: DestFlag,
}
