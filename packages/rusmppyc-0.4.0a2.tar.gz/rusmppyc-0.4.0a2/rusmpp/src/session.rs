//! Session state of the ESME <-> MC session.
//!
//! Can be useful if you write a MC or an ESME to describe the session state.

pub use rusmpp_core::session::*;
