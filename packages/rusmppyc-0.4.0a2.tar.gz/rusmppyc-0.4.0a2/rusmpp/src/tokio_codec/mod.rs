//! Codec for encoding and decoding `SMPP` PDUs.

pub use rusmpp_core::tokio_codec::*;
