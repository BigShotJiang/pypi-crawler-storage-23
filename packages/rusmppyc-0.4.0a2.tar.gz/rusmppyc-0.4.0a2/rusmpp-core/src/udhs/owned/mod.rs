//! Owned User Data Headers (UDHs).

mod udh;
pub use udh::{Udh, UdhParts, UdhValue};
