# ui-ticket-mcp

Review system for UI prototypes. Humans write comments in the browser, AI agents resolve them via MCP. One process serves both MCP (stdio) and REST API (HTTP).

## Setup

Add to your `.mcp.json`:

```json
{
  "mcpServers": {
    "ui-ticket-mcp": {
      "command": "uvx",
      "args": ["ui-ticket-mcp"],
      "env": {
        "PROJECT_ROOT": "/path/to/your/project"
      }
    }
  }
}
```

`uvx` downloads and runs the package automatically. MCP connects via stdio, REST API starts in background on `http://localhost:3200`. Reviews are stored in `{PROJECT_ROOT}/.reviews/reviews.db` (auto-created, committable to git).

Port configurable via `REVIEW_PORT` env var.

> **Fallback** if you don't have `uv`: `pip install ui-ticket-mcp`, then use `"command": "ui-ticket-mcp"` instead of `uvx`.

### MCP Tools

| Tool | Description |
|------|-------------|
| `get_review_summary()` | Summary of pages with open/resolved counts |
| `get_reviews(page_id?)` | List comments, optionally filtered by page |
| `add_review(page_id, author, text)` | Add a new comment |
| `resolve_review(review_id, resolved_by?)` | Mark as resolved |
| `reopen_review(review_id)` | Reopen a resolved review |
| `batch_resolve(page_id, resolved_by?)` | Resolve all open on a page |
| `get_pending_work()` | Open reviews grouped by page (todo list) |
| `find_source_file_tool(page_id)` | Find source files matching a page_id |
| `get_annotated_reviews(page_id?)` | Reviews with element annotation metadata |
| `get_setup_guide()` | Full setup guide for the review system |

## REST API (starts automatically)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/reviews/summary` | Per-page summary |
| GET | `/api/reviews` | All reviews |
| GET | `/api/reviews/{page_id}` | Reviews for a page |
| POST | `/api/reviews/{page_id}` | Add review |
| PATCH | `/api/review/{id}` | Update status/text |
| DELETE | `/api/review/{id}` | Delete review |
| GET | `/api/version` | Server version |

## Links

- **Website:** [uiticket.0ics.ai](https://uiticket.0ics.ai/)
- **GitHub:** [github.com/0ics-srls/ui-ticket-mcp_public](https://github.com/0ics-srls/ui-ticket-mcp_public)
- **npm (panel):** [ui-ticket-panel](https://www.npmjs.com/package/ui-ticket-panel)
- **npm (core):** [ui-ticket-core](https://www.npmjs.com/package/ui-ticket-core)
