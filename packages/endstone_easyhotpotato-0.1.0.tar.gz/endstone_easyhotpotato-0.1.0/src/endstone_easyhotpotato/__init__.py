from endstone_easyhotpotato.easyhotpotato import EasyHotPotatoPlugin

__all__ = ["EasyHotPotatoPlugin"]
