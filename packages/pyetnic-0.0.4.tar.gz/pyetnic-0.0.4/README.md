# pyetnic

Bibliothèque Python d'accès aux services web SOAP d'[ETNIC](https://www.etnic.be/) pour l'enseignement de promotion sociale (Wallonie-Bruxelles).

## Fonctionnalités

- **Formations** : lister les formations organisables et les formations organisées
- **Organisation** : créer, lire, modifier et supprimer une organisation de formation
- **Document 1** : lire, modifier et approuver le document de population (inscriptions)
- **Document 2** : lire et modifier le document des périodes d'activités d'enseignement
- **Document 3** : lire et modifier le document des attributions d'enseignants

## Installation

```bash
pip install pyetnic
```

## Configuration

Générer un fichier `.env` de départ avec la commande CLI :

```bash
pyetnic init-config
```

Puis remplir les valeurs dans le fichier `.env` généré :

```ini
# Environnement : dev (services-web.tq.etnic.be) ou prod (services-web.etnic.be)
ENV=dev

# Identifiants pour le développement
DEV_USERNAME=
DEV_PASSWORD=

# Identifiants pour la production
PROD_USERNAME=
PROD_PASSWORD=

# Paramètres par défaut
DEFAULT_ETABID=
DEFAULT_IMPLID=
DEFAULT_SCHOOLYEAR=2024-2025
```

Les identifiants sont ceux fournis par ETNIC pour accéder aux services web de votre établissement.

## Utilisation

### Lister les formations

```python
import pyetnic

# Formations organisables (catalogue)
result = pyetnic.lister_formations_organisables(annee_scolaire="2024-2025")
for formation in result:
    print(formation.numAdmFormation, formation.libelleFormation)

# Formations organisées (avec leurs organisations)
result = pyetnic.lister_formations(annee_scolaire="2024-2025")
for formation in result:
    for org in formation.organisations:
        print(org.id.numOrganisation, org.dateDebutOrganisation, org.dateFinOrganisation)
```

### Organisation

```python
import pyetnic

# Lire une organisation
org = pyetnic.lire_organisation(
    annee_scolaire="2024-2025",
    etab_id=3052,
    num_adm_formation=12345,
    num_organisation=1,
)

# Modifier une organisation
pyetnic.modifier_organisation(organisation=org)

# Créer une organisation
pyetnic.creer_organisation(organisation=org)

# Supprimer une organisation
pyetnic.supprimer_organisation(organisation=org)
```

### Documents administratifs

```python
import pyetnic

# Document 1 - Population
doc1 = pyetnic.lire_document_1(annee_scolaire="2024-2025", etab_id=3052,
                                num_adm_formation=12345, num_organisation=1)
pyetnic.modifier_document_1(document=doc1)
pyetnic.approuver_document_1(document=doc1)

# Document 2 - Périodes d'activités
doc2 = pyetnic.lire_document_2(annee_scolaire="2024-2025", etab_id=3052,
                                num_adm_formation=12345, num_organisation=1)
pyetnic.modifier_document_2(document=doc2)

# Document 3 - Attributions d'enseignants
doc3 = pyetnic.lire_document_3(annee_scolaire="2024-2025", etab_id=3052,
                                num_adm_formation=12345, num_organisation=1)
pyetnic.modifier_document_3(document=doc3)
```

## Dépendances

- [zeep](https://docs.python-zeep.org/) — client SOAP
- [python-dotenv](https://pypi.org/project/python-dotenv/) — chargement de la configuration
- [requests](https://pypi.org/project/requests/)
- [openpyxl](https://pypi.org/project/openpyxl/)

## Licence

MIT — voir [LICENSE](LICENSE)
