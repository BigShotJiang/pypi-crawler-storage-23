"""Parent node for generating a random string."""

# pylint: disable=too-many-arguments
# pylint: disable=too-many-positional-arguments

import random
from string import ascii_lowercase, ascii_uppercase, digits, punctuation
from typing import Any

from click_extended.core.nodes.parent_node import ParentNode
from click_extended.core.other.context import Context
from click_extended.types import Decorator


class RandomString(ParentNode):
    """Parent node for generating random strings."""

    def load(self, context: Context, *args: Any, **kwargs: Any) -> str:
        if kwargs.get("seed") is not None:
            random.seed(kwargs["seed"])

        chars = ""
        if kwargs["lowercase"]:
            chars += ascii_lowercase
        if kwargs["uppercase"]:
            chars += ascii_uppercase
        if kwargs["numbers"]:
            chars += digits
        if kwargs["symbols"]:
            chars += punctuation

        return "".join(random.choice(chars) for _ in range(kwargs["length"]))


def random_string(
    name: str,
    length: int = 8,
    lowercase: bool = True,
    uppercase: bool = True,
    numbers: bool = True,
    symbols: bool = True,
    seed: int | None = None,
) -> Decorator:
    """
    Generate a random string.

    Type: `ParentNode`

    :param name: The name of the parent node.
    :param length: The length of the string to generate.
    :param lowercase: Whether to include lowercase characters.
    :param uppercase: Whether to include uppercase characters.
    :param numbers: Whether to include numbers.
    :param symbols: Whether to include symbols.
    :param seed: Optional seed for reproducible randomness.
    :returns: The decorator function.
    :rtype: Decorator
    """
    return RandomString.as_decorator(
        name=name,
        length=length,
        lowercase=lowercase,
        uppercase=uppercase,
        numbers=numbers,
        symbols=symbols,
        seed=seed,
    )
