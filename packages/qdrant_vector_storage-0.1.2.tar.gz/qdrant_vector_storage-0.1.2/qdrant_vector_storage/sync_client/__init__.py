"""Synchronous client for Qdrant."""

from .client import QdrantSyncClient

__all__ = ["QdrantSyncClient"]