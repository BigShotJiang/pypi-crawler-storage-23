# ruff: noqa: PLR0913
"""wafer settings deps -- check and install external tool dependencies."""
from __future__ import annotations

import shutil
import subprocess
import sys
from dataclasses import dataclass

import typer

deps_app = typer.Typer(help="Check and install external tool dependencies.")


@dataclass(frozen=True)
class DepSpec:
    """Specification for an external dependency wafer integrates with."""

    name: str
    check_cmd: str
    install_cmd: str | None
    platform: str  # "amd", "nvidia", or "any"
    description: str


DEPS_REGISTRY: dict[str, DepSpec] = {
    "ncu": DepSpec(
        name="ncu",
        check_cmd="ncu",
        install_cmd="sudo apt install -y nvidia-cuda-toolkit",
        platform="nvidia",
        description="NVIDIA Nsight Compute (part of CUDA toolkit)",
    ),
    "nsys": DepSpec(
        name="nsys",
        check_cmd="nsys",
        install_cmd="sudo apt install -y nvidia-cuda-toolkit",
        platform="nvidia",
        description="NVIDIA Nsight Systems (part of CUDA toolkit)",
    ),
    "nvcc": DepSpec(
        name="nvcc",
        check_cmd="nvcc",
        install_cmd="sudo apt install -y nvidia-cuda-toolkit",
        platform="nvidia",
        description="NVIDIA CUDA compiler",
    ),
    "rocprof": DepSpec(
        name="rocprof",
        check_cmd="rocprof",
        install_cmd=None,
        platform="amd",
        description="AMD kernel profiling (part of ROCm base install)",
    ),
    "rocprof-compute": DepSpec(
        name="rocprof-compute",
        check_cmd="rocprof-compute",
        install_cmd="sudo apt install -y rocprofiler-compute && python3 -m pip install -r /opt/rocm/libexec/rocprofiler-compute/requirements.txt",
        platform="amd",
        description="AMD GPU profiling (roofline, memory) - requires ROCm >= 6.3",
    ),
    "rocprof-systems": DepSpec(
        name="rocprof-systems",
        check_cmd="rocprof-systems",
        install_cmd="sudo apt install -y rocprofiler-systems && python3 -m pip install -r /opt/rocm/libexec/rocprofiler-systems/requirements.txt",
        platform="amd",
        description="AMD system-wide tracing - requires ROCm >= 6.3",
    ),
    "rocprofv3": DepSpec(
        name="rocprofv3",
        check_cmd="rocprofv3",
        install_cmd=None,
        platform="amd",
        description="AMD ROCprofiler SDK v3 (part of ROCm >= 6.0 base install)",
    ),
    "gh": DepSpec(
        name="gh",
        check_cmd="gh",
        install_cmd="brew install gh" if sys.platform == "darwin" else "sudo apt install -y gh",
        platform="any",
        description="GitHub CLI",
    ),
}


def check_dep(name: str) -> bool:
    """Check if a single dep is installed locally via shutil.which()."""
    spec = DEPS_REGISTRY[name]
    return shutil.which(spec.check_cmd) is not None


def check_all_deps() -> dict[str, bool]:
    """Check all deps, return {name: installed}."""
    return {name: check_dep(name) for name in DEPS_REGISTRY}


def deps_hint() -> str:
    """Return hint to run when a tool is not found."""
    return "Tip: Run 'wafer settings deps check' to see install commands."


@deps_app.command("check")
def deps_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Report status of external tools wafer integrates with.

    Examples:
        wafer settings deps check
        wafer settings deps check --json
    """
    results: list[dict] = []
    for name, spec in sorted(DEPS_REGISTRY.items()):
        path = shutil.which(spec.check_cmd)
        entry = {
            "name": name,
            "installed": path is not None,
            "platform": spec.platform,
            "description": spec.description,
        }
        if path:
            entry["path"] = path
        elif spec.install_cmd:
            entry["install_command"] = spec.install_cmd
        results.append(entry)

    if json_output:
        from .output import json_response
        typer.echo(json_response(data={"deps": results}))
        return

    for entry in results:
        name = entry["name"]
        if entry["installed"]:
            typer.echo(f"{name + ':':<20} installed     {entry['path']}")
        else:
            install_hint = f"  ({entry['install_command']})" if "install_command" in entry else ""
            typer.echo(f"{name + ':':<20} not installed{install_hint}")


@deps_app.command("install")
def deps_install(
    tool: str = typer.Argument(..., help="Tool name to install"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Run the install command non-interactively"),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="Install on a remote target instead of locally",
    ),
) -> None:
    """Install an external dep locally, or on a remote target.

    Examples:
        wafer settings deps install ncu
        wafer settings deps install ncu --yes
        wafer settings deps install rocprof-compute --target mi300x --yes
    """
    assert tool in DEPS_REGISTRY, f"Unknown tool: {tool}. Available: {', '.join(sorted(DEPS_REGISTRY.keys()))}"

    spec = DEPS_REGISTRY[tool]

    if spec.install_cmd is None:
        typer.echo(f"{tool} cannot be auto-installed (part of {spec.description}).", err=True)
        raise typer.Exit(1)

    if target:
        _install_on_target(tool, spec, target, yes)
    else:
        _install_locally(tool, spec, yes)


def _install_locally(tool: str, spec: DepSpec, run: bool) -> None:
    assert spec.install_cmd is not None
    assert tool  # non-empty

    if not run:
        typer.echo(f"To install {tool}:")
        typer.echo(f"  {spec.install_cmd}")
        return

    typer.echo(f"Installing {tool}...")
    result = subprocess.run(spec.install_cmd, shell=True, capture_output=False)
    if result.returncode != 0:
        typer.echo(f"Install failed (exit {result.returncode}). Run manually:", err=True)
        typer.echo(f"  {spec.install_cmd}", err=True)
        raise typer.Exit(1)
    typer.echo(f"{tool} installed successfully.")


def _install_on_target(tool: str, spec: DepSpec, target_name: str, run: bool) -> None:
    assert spec.install_cmd is not None
    assert target_name  # non-empty

    import trio

    from .targets import load_target
    from .targets_ops import (
        TOOL_REGISTRY,
        TargetExecError,
        ensure_tool,
        get_target_ssh_info,
    )

    try:
        target_config = load_target(target_name)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    if not run:
        typer.echo(f"To install {tool} on target '{target_name}':")
        typer.echo(f"  wafer settings deps install {tool} --target {target_name} --yes")
        return

    if tool in TOOL_REGISTRY:  # delegate to existing ensure_tool when possible
        from .targets_ops import get_target_platform
        platform = get_target_platform(target_config)
        tool_spec = TOOL_REGISTRY[tool]
        if tool_spec.platform in ("nvidia", "amd") and platform in ("trainium", "tpu", "other"):
            typer.echo(
                f"Error: {tool} is not available for {platform} accelerators. "
                "NCU/NSYS require NVIDIA; rocprof requires AMD.",
                err=True,
            )
            raise typer.Exit(1)
        try:
            ssh_info = trio.run(get_target_ssh_info, target_config)
        except TargetExecError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None

        result = ensure_tool(ssh_info, tool, force=False, timeout=300)
        if result.error:
            typer.echo(f"Error: {result.error}", err=True)
            raise typer.Exit(1)
        if result.already_installed:
            typer.echo(f"{tool} is already installed on {target_name}")
        elif result.installed:
            typer.echo(f"{tool} installed on {target_name}")
        return

    from .targets_ops import exec_on_target_sync

    try:
        ssh_info = trio.run(get_target_ssh_info, target_config)
    except TargetExecError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    typer.echo(f"Installing {tool} on {target_name}...")
    exit_code = exec_on_target_sync(ssh_info, spec.install_cmd, timeout_seconds=300)
    if exit_code != 0:
        typer.echo(f"Install failed (exit {exit_code}).", err=True)
        raise typer.Exit(1)
    typer.echo(f"{tool} installed on {target_name}.")
