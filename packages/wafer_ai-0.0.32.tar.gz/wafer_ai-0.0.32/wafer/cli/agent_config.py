"""Agent configuration loaded from TOML files.

This is the experiment knob: everything that affects how the agent behaves.
Designed to be versioned alongside experiment results for reproducibility.

Usage:
    config = load_agent_config(Path("experiments/kernelbench_v1.toml"))
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal


@dataclass(frozen=True)
class SubagentConfig:
    """Configuration for a named subagent (Claude or Codex backend)."""
    backend: Literal["claude", "codex"]
    mode: Literal["plan", "execute"] = "plan"
    allowed_tools: list[str] | None = None
    timeout: int = 300
    model: str | None = None
    sandbox: str | None = None


@dataclass(frozen=True)
class AgentFileConfig:
    """Agent configuration loaded from a TOML file.

    All fields are optional (None). Unset fields defer to CLI flags, then
    template defaults, then hard-coded defaults. Override precedence:
        CLI flag > config file > template > defaults
    """

    # Model selection
    model: str | None = None
    provider: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None

    # Agent behavior
    max_turns: int | None = None
    single_turn: bool | None = None
    template: str | None = None

    # Prompts
    system_prompt: str | None = None
    user_prompt_template: str | None = None

    # Tools
    tools: list[str] | None = None
    bash_allowlist: list[str] | None = None

    # Extended thinking (Anthropic)
    thinking_enabled: bool | None = None
    thinking_budget_tokens: int | None = None

    # Reasoning (OpenAI)
    reasoning_effort: str | None = None
    max_completion_tokens: int | None = None

    # Environment
    allow_network: bool | None = None
    workspace: str | None = None

    # Runtime / routing
    agent: str | None = None  # only "wafer" supported as top-level agent
    target_name: str | None = None  # wafer target run --name <name> (e.g. Trainium)
    direct_endpoint: str | None = None  # If set, POST to this API path instead of
    # running local agent (e.g. /v1/docs/query for ask-docs). No tools, no local loop.
    timeout_sec: float | None = None  # max seconds per eval problem
    defaults: dict[str, str] | None = None  # template variable defaults

    # Subagents (populated from [subagents.*] TOML sections)
    subagents: dict[str, SubagentConfig] = field(default_factory=dict)

    # Display (for --list-templates)
    description: str | None = None


def load_agent_config(path: Path) -> AgentFileConfig:
    """Load agent config from a TOML file.

    Returns AgentFileConfig with only the fields that were explicitly set.
    Unset fields remain None, allowing CLI flags and template defaults to fill in.

    Supports nested sections:
        [thinking]
        enabled = true
        budget_tokens = 10000

        [bash]
        allowlist = ["make", "hipcc"]

        [reasoning]
        effort = "high"
        max_tokens = 8192
    """
    import tomllib

    assert path.exists(), f"Config file not found: {path}"
    assert path.suffix == ".toml", f"Config file must be .toml, got: {path.suffix}"

    with open(path, "rb") as f:
        raw = tomllib.load(f)

    thinking = raw.pop("thinking", {})
    bash = raw.pop("bash", {})
    reasoning = raw.pop("reasoning", {})
    defaults = raw.pop("defaults", {})
    raw_subagents = raw.pop("subagents", {})

    _validate_no_unknown_keys(raw, thinking, bash, reasoning, defaults)

    defaults_dict: dict[str, str] | None = None
    if defaults:
        defaults_dict = {k: str(v) for k, v in defaults.items()}

    subagents = _parse_subagents(raw_subagents)

    return AgentFileConfig(
        model=raw.get("model"),
        provider=raw.get("provider"),
        temperature=raw.get("temperature"),
        max_tokens=raw.get("max_tokens"),
        max_turns=raw.get("max_turns"),
        single_turn=raw.get("single_turn"),
        template=raw.get("template"),
        system_prompt=raw.get("system_prompt"),
        user_prompt_template=raw.get("user_prompt_template"),
        tools=raw.get("tools"),
        bash_allowlist=bash.get("allowlist") or raw.get("bash_allowlist"),
        thinking_enabled=thinking.get("enabled"),
        thinking_budget_tokens=thinking.get("budget_tokens"),
        reasoning_effort=reasoning.get("effort") or raw.get("reasoning_effort"),
        max_completion_tokens=reasoning.get("max_tokens") or raw.get("max_completion_tokens"),
        allow_network=raw.get("allow_network"),
        workspace=raw.get("workspace"),
        agent=raw.get("agent"),
        target_name=raw.get("target_name"),
        direct_endpoint=raw.get("direct_endpoint"),
        timeout_sec=raw.get("timeout_sec"),
        subagents=subagents,
        defaults=defaults_dict,
        description=raw.get("description"),
    )


_KNOWN_TOP_LEVEL_KEYS = frozenset({
    "model", "provider", "temperature", "max_tokens",
    "max_turns", "single_turn", "template",
    "system_prompt", "user_prompt_template",
    "tools", "bash_allowlist",
    "thinking_enabled", "thinking_budget_tokens",
    "reasoning_effort", "max_completion_tokens",
    "allow_network", "workspace",
    "agent", "env", "target_name", "direct_endpoint", "timeout_sec", "defaults",
    "description",
})

_VALID_SUBAGENT_BACKENDS = ("claude", "codex")
_VALID_SUBAGENT_MODES = ("plan", "execute")
_KNOWN_SUBAGENT_KEYS = frozenset({"backend", "mode", "allowed_tools", "timeout", "model", "sandbox"})


def _parse_subagents(raw: dict[str, Any]) -> dict[str, SubagentConfig]:
    """Parse [subagents.*] TOML sections into SubagentConfig dict."""
    if not raw:
        return {}
    result: dict[str, SubagentConfig] = {}
    for name, section in raw.items():
        assert isinstance(section, dict), f"[subagents.{name}] must be a table, got {type(section)}"
        unknown = set(section.keys()) - _KNOWN_SUBAGENT_KEYS
        assert not unknown, f"Unknown keys in [subagents.{name}]: {unknown}"
        backend = section.get("backend")
        assert backend in _VALID_SUBAGENT_BACKENDS, (
            f"[subagents.{name}].backend must be one of {_VALID_SUBAGENT_BACKENDS}, got {backend!r}"
        )
        mode = section.get("mode", "plan")
        assert mode in _VALID_SUBAGENT_MODES, (
            f"[subagents.{name}].mode must be one of {_VALID_SUBAGENT_MODES}, got {mode!r}"
        )
        result[name] = SubagentConfig(
            backend=backend,
            mode=mode,
            allowed_tools=section.get("allowed_tools"),
            timeout=section.get("timeout", 300),
            model=section.get("model"),
            sandbox=section.get("sandbox"),
        )
    return result

_KNOWN_THINKING_KEYS = frozenset({"enabled", "budget_tokens"})
_KNOWN_BASH_KEYS = frozenset({"allowlist"})
_KNOWN_REASONING_KEYS = frozenset({"effort", "max_tokens"})


def write_agent_config_toml(path: Path, **kwargs: Any) -> Path:
    """Write an AgentFileConfig as a TOML file.

    Handles multi-line strings (system_prompt) correctly with TOML triple-quotes.
    Returns the path for chaining.
    """
    lines: list[str] = []
    nested_sections: dict[str, dict[str, Any]] = {}

    for key, value in kwargs.items():
        if value is None:
            continue
        # Route nested keys to their sections
        if key == "thinking_enabled":
            nested_sections.setdefault("thinking", {})["enabled"] = value
        elif key == "thinking_budget_tokens":
            nested_sections.setdefault("thinking", {})["budget_tokens"] = value
        elif key == "bash_allowlist":
            nested_sections.setdefault("bash", {})["allowlist"] = value
        elif key == "reasoning_effort":
            nested_sections.setdefault("reasoning", {})["effort"] = value
        elif key == "max_completion_tokens":
            nested_sections.setdefault("reasoning", {})["max_tokens"] = value
        elif key == "defaults" and isinstance(value, dict):
            nested_sections["defaults"] = value
        elif isinstance(value, str) and "\n" in value:
            lines.append(f'{key} = """\n{value}"""')
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, bool):
            lines.append(f"{key} = {'true' if value else 'false'}")
        elif isinstance(value, (int, float)):
            lines.append(f"{key} = {value}")
        elif isinstance(value, list):
            items = ", ".join(f'"{v}"' for v in value)
            lines.append(f"{key} = [{items}]")

    for section_name, section_vals in nested_sections.items():
        lines.append(f"\n[{section_name}]")
        for k, v in section_vals.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, (int, float)):
                lines.append(f"{k} = {v}")
            elif isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            elif isinstance(v, list):
                items = ", ".join(f'"{i}"' for i in v)
                lines.append(f"{k} = [{items}]")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n")
    return path


_BUNDLED_TOML_DIR = Path(__file__).parent / "templates" / "toml"


def get_bundled_template_path(name: str) -> Path | None:
    """Resolve a template name to its bundled TOML path, or None if not found.

    Normalizes name: "trace-analyze" -> "trace_analyze.toml".
    """
    module_name = name.replace("-", "_")
    toml_path = _BUNDLED_TOML_DIR / f"{module_name}.toml"
    if toml_path.exists():
        return toml_path
    toml_path = _BUNDLED_TOML_DIR / f"{name}.toml"
    if toml_path.exists():
        return toml_path
    return None


def list_bundled_templates() -> list[str]:
    """List available bundled TOML template names."""
    if not _BUNDLED_TOML_DIR.exists():
        return []
    return sorted(
        f.stem.replace("_", "-")
        for f in _BUNDLED_TOML_DIR.glob("*.toml")
    )


def _validate_no_unknown_keys(
    raw: dict[str, Any],
    thinking: dict[str, Any],
    bash: dict[str, Any],
    reasoning: dict[str, Any],
    defaults: dict[str, Any],
) -> None:
    """Fail fast on unknown keys to catch typos."""
    unknown_top = set(raw.keys()) - _KNOWN_TOP_LEVEL_KEYS
    assert not unknown_top, f"Unknown keys in agent config: {unknown_top}"

    unknown_thinking = set(thinking.keys()) - _KNOWN_THINKING_KEYS
    assert not unknown_thinking, f"Unknown keys in [thinking]: {unknown_thinking}"

    unknown_bash = set(bash.keys()) - _KNOWN_BASH_KEYS
    assert not unknown_bash, f"Unknown keys in [bash]: {unknown_bash}"

    unknown_reasoning = set(reasoning.keys()) - _KNOWN_REASONING_KEYS
    assert not unknown_reasoning, f"Unknown keys in [reasoning]: {unknown_reasoning}"
