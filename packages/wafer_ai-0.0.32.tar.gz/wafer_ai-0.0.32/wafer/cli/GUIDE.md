# Wafer CLI Guide

GPU development primitives for LLM agents.

## Quick Start

Run code on a GPU in three commands:

```bash
wafer settings login                                         # One-time auth
wafer target init workspace dev --gpu B200                   # Create a GPU target
wafer target run -- python -c "import torch; print(torch.cuda.get_device_name(0))"
```

**Available GPUs:**

- `MI300X` - AMD Instinct MI300X (192GB HBM3, ROCm)
- `B200` - NVIDIA Blackwell B200 (180GB HBM3e, CUDA) - default

## Running Code on a GPU

Use `wafer target run` to execute commands on any target (workspace or SSH host):

```bash
# Auto-select a target (uses default if set)
wafer target run -- python train.py

# Pick a target by name
wafer target run --name dev -- python train.py

# Pick by GPU type
wafer target run --gpu MI300X -- ./benchmark.sh

# Sync local files before running
wafer target run --sync ./project -- python train.py

# Set a timeout (seconds)
wafer target run --timeout 300 -- python long_job.py
```

## Managing Targets

Targets are GPU environments you run code on. They can be cloud workspaces or your own SSH hosts.

```bash
wafer target list                                # List all targets
wafer target show dev                            # Show target details
wafer target ssh dev                             # Interactive SSH
wafer target sync dev ./project                  # Sync files to target
wafer target pull dev /remote/results ./local    # Pull files from target
wafer target probe dev                           # Probe GPU capabilities
wafer target default dev                         # Set default target
wafer target remove dev                          # Remove a target
```

**Creating targets:**

```bash
# Cloud workspace (no hardware required)
wafer target init workspace dev --gpu B200
wafer target init workspace amd-dev --gpu MI300X

# Your own SSH host
wafer target init ssh --name my-box --host user@host:22
```

## Documentation Lookup

Answer GPU programming questions from wafer's documentation corpus.

```bash
# Query documentation (uses wafer API — no local download needed)
wafer agent -t ask-docs "What is warp divergence?"
wafer agent -t ask-docs "What is a TiledMma in CUTLASS?"
```

## Trace Analysis

Analyze performance traces from NCU, NSYS, or PyTorch profiler.

```bash
# Direct trace queries (PyTorch/Perfetto JSON)
wafer tool perfetto tables trace.json
wafer tool perfetto query trace.json \
  "SELECT name, dur/1e6 as ms FROM slice WHERE cat='kernel' ORDER BY dur DESC LIMIT 10"

# NCU/NSYS analysis
wafer tool ncu analyze profile.ncu-rep
wafer tool nsys analyze profile.nsys-rep
```

## Kernel Evaluation

Test kernel correctness and measure speedup against a reference.

```bash
# List available evaluation tasks
wafer tool eval --list-tasks

# Run evaluation locally
wafer tool eval --task kernelbench
wafer tool eval --task gpumode

# Run evaluation on a GPU target (compose with target run)
wafer target run --name dev -- wafer tool eval --task gpumode

# Sync files and run (cd into /workspace/ where synced files land)
wafer target run --name dev --sync ./my-kernel -- bash -c "cd /workspace && wafer tool eval --task kernelbench"
```

For target setup, see `wafer target init --help`.

## Kernel Optimization (AI-assisted)

Use the wafer agent to optimize GPU kernels with AI assistance.

```bash
# Optimize a kernel interactively (local TUI)
wafer agent "optimize this GEMM kernel for B200"

# Run optimization on the cloud
wafer agent --cloud -t default "optimize this kernel" --single-turn --dir .

# Use the agent with a specific target
wafer agent --cloud --dir ./my-kernel "reduce memory bandwidth usage in this matmul"
```

Combine with evaluation to measure improvement:

```bash
# Evaluate before and after optimization
wafer tool eval --task gpumode --after ./optimized --before ./original

# Roofline analysis to identify bottleneck
wafer tool roofline --gpu B200 --bytes 100e6 --flops 137e12 --time-ms 85
```

## Command Reference

```bash
wafer target init|list|show|remove|default  # Manage GPU targets
wafer target run|ssh|sync|pull|probe        # Run code and interact with targets
wafer target pool list|create|status        # Fleet-level target pools
wafer tool eval                             # Test kernel correctness/performance
wafer tool ncu|nsys|perfetto                # NVIDIA profiling tools
wafer tool isa|rocprof-compute|rocprof-sdk|rocprof-systems  # AMD profiling tools
wafer tool roofline                         # Roofline analysis
wafer tool baseline run|hardware            # Baseline benchmarks
wafer tool compare analyze|fusion           # Kernel comparison
wafer tool capture run|list                  # Trace capture
wafer tool tracelens check|report|compare|collective  # Trace lens analysis
wafer tool nvidia-distributed-traces analyze|collect|compare|metrics  # NVIDIA distributed traces
wafer tool amd-distributed-traces analyze|collect|compare|metrics    # AMD distributed traces
wafer agent -t ask-docs                     # GPU docs lookup
wafer settings login|logout|whoami|status   # Authentication
wafer settings guide                        # CLI usage guide
wafer settings config|billing|ssh-keys|deps|telemetry|skill|auth  # Configuration
wafer demo                                  # Interactive demos
wafer --version                             # Show CLI version
```
