# ruff: noqa: E402
"""Wafer keys sub-commands – manage Wafer-generated SSH keys."""
from __future__ import annotations

from pathlib import Path

import typer

keys_app = typer.Typer(
    help="Manage Wafer-generated SSH keys (used by cloud agents to SSH into your targets).",
)


def _exit_with_error(msg: str) -> None:
    """Print error to stderr and exit with code 1."""
    typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1) from None


@keys_app.command("list")
def keys_list() -> None:
    """List Wafer-managed SSH keys."""
    try:
        from .user_targets_api import list_wafer_keys
        keys = list_wafer_keys()
    except RuntimeError as e:
        _exit_with_error(str(e))
    if not keys:
        typer.echo("  No Wafer keys. Generate one: wafer keys generate <name>")
        return
    typer.echo("  Wafer-managed keys:\n")
    for k in keys:
        typer.echo(f"    {k.get('name', ''):<20} {k.get('fingerprint', '')}")


@keys_app.command("generate")
def keys_generate(
    name: str = typer.Argument(..., help="Key name"),
) -> None:
    """Generate a Wafer SSH keypair. Private key returned one time only."""
    try:
        from .user_targets_api import generate_wafer_key
        key = generate_wafer_key(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    keys_dir = Path.home() / ".wafer" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    key_path = keys_dir / name
    if key.get("private_key"):
        key_path.write_text(key["private_key"])
        key_path.chmod(0o600)
        typer.echo(f"  Wafer key saved to: {key_path}")
    typer.echo(f"  Public key: {key.get('public_key', '')}")
    typer.echo(f"  Fingerprint: {key.get('fingerprint', '')}")


@keys_app.command("delete")
def keys_delete(
    key_id: str = typer.Argument(..., help="Key ID or name"),
) -> None:
    """Delete a Wafer key."""
    try:
        from .user_targets_api import delete_wafer_key, list_wafer_keys
        keys = list_wafer_keys()
        key_id_resolved = key_id
        for k in keys:
            if k.get("id") == key_id or k.get("name") == key_id:
                key_id_resolved = k["id"]
                break
        delete_wafer_key(key_id_resolved)
        typer.echo(f"  Deleted key: {key_id}")
    except RuntimeError as e:
        _exit_with_error(str(e))
    except ValueError as e:
        _exit_with_error(str(e))
