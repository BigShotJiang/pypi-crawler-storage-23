"""Wafer API client for remote GPU operations.
Thin client that calls wafer-api endpoints instead of direct SSH.
"""
from .global_config import get_api_url  # noqa: F401 - re-exported for backwards compat


def _get_auth_headers() -> dict[str, str]:
    """Get auth headers from stored credentials (lazy import to avoid circular)."""
    from .auth import get_auth_headers
    headers = get_auth_headers()
    try:
        from .global_config import get_preferences
        if not get_preferences().data_retention_enabled:
            headers["X-Wafer-No-Retain"] = "true"
    except Exception:
        pass  # Don't break API calls if config read fails
    return headers
