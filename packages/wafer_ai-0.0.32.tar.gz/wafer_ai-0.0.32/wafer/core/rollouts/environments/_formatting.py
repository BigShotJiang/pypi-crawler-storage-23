"""Shared formatting utilities for environment tool output.
Provides consistent formatting across all environments for:
- Extracting text from tool results
- Formatting tool output with truncation and theming
- Default tool rendering (works for any tool with zero config)
- GPU event line formatting (wafer target run lock acquire/release)
"""
from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Any

_GPU_EVENT_PREFIX = "[GPU_EVENT] "


def format_gpu_event_line(line: str) -> str | None:
    """Format [GPU_EVENT] JSON line for human display. Returns None if not a GPU event."""
    if not line.strip().startswith(_GPU_EVENT_PREFIX):
        return None
    try:
        json_str = line.strip()[len(_GPU_EVENT_PREFIX) :]
        event = json.loads(json_str)
    except (json.JSONDecodeError, KeyError):
        return None
    etype = event.get("type", "")
    target = event.get("target", "?")
    if etype == "gpu_acquire":
        gpu_ids = event.get("gpu_ids", [])
        if gpu_ids:
            ids_str = ",".join(map(str, gpu_ids))
            return f"[GPU] Acquired {target} (GPU {ids_str})"
        return f"[GPU] Acquired {target}"
    if etype == "gpu_release":
        hold_ms = event.get("hold_duration_ms")
        suffix = f" ({hold_ms}ms)" if hold_ms is not None else ""
        return f"[GPU] Released {target}{suffix}"
    return f"[GPU] {etype}: {target}"

if TYPE_CHECKING:
    from ..dtypes import DetailLevel, ToolRenderConfig
    from ..frontends.tui.theme import Theme


def get_text_output(result: dict[str, Any] | None) -> str:
    """Extract text output from tool result.
    Handles result formats:
    - {"content": "string"} - direct string content
    - {"content": [{"type": "text", "text": "..."}]} - content blocks
    Returns:
        Extracted text with ANSI codes and carriage returns stripped.
    """
    if not result:
        return ""
    content = result.get("content", {})
    # Direct string content
    if isinstance(content, str):
        return content
    # Content block list
    if isinstance(content, list):
        text_blocks = [c for c in content if isinstance(c, dict) and c.get("type") == "text"]
        text_output = "\n".join(c.get("text", "") for c in text_blocks if c.get("text"))
        return _strip_ansi(text_output)
    return ""


def _strip_ansi(text: str) -> str:
    """Strip ANSI escape codes and carriage returns."""
    text = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", text)
    return text.replace("\r", "")


_BODY_CONTENT_ARGS = frozenset({
    "content", "code", "body", "new_string", "old_string", "source", "script",
})

_STREAMING_CONTENT_ARGS = _BODY_CONTENT_ARGS | frozenset({
    "command", "text", "query", "sql", "prompt",
})


def _default_header(tool_name: str, args: dict[str, Any], theme: Any = None) -> str:
    """Generate default header for a tool call.
    Format: tool_name(arg1=..., arg2=...)
    Content args (body/code/content) are excluded from the header since they're
    shown in the result body or streaming display. Remaining args are truncated
    at 50 chars. When a theme is provided, tool name gets accent color and args
    get muted color for visual hierarchy.
    """
    display_args = {k: v for k, v in args.items() if k not in _BODY_CONTENT_ARGS}
    name_str = theme.accent_fg(tool_name) if theme else tool_name
    if not display_args:
        return f"{name_str}()"
    parts = []
    for key, value in list(display_args.items())[:3]:
        if isinstance(value, str):
            display = repr(value[:50] + "..." if len(value) > 50 else value)
        else:
            display = repr(value)
            if len(display) > 50:
                display = display[:50] + "..."
        part_str = f"{key}={display}"
        if theme:
            part_str = theme.muted_fg(part_str)
        parts.append(part_str)
    if len(display_args) > 3:
        parts.append("...")
    return f"{name_str}({', '.join(parts)})"


def _get_streaming_content_arg(args: dict[str, Any]) -> str | None:
    """Find the primary streaming content arg from tool call args."""
    for name in _STREAMING_CONTENT_ARGS:
        val = args.get(name)
        if isinstance(val, str) and val:
            return val
    best: str | None = None
    best_len = 50
    for val in args.values():
        if isinstance(val, str) and len(val) > best_len:
            best = val
            best_len = len(val)
    return best


def format_tool_output(
    header: str,
    result: dict[str, Any] | None,
    detail_level: DetailLevel,
    theme: Theme | None = None,
    config: ToolRenderConfig | None = None,
) -> str:
    """Format tool output with consistent styling."""
    from ..dtypes import DetailLevel, ToolRenderConfig
    if config is None:
        config = ToolRenderConfig()
    text = header
    if not result:
        return text
    output = get_text_output(result).strip()
    if not output:
        return text
    is_error = result.get("isError", False)
    lines = output.split("\n")

    max_lines = config.get_max_lines(detail_level)
    if max_lines < 0:  # -1 = unlimited
        display_count = len(lines)
    else:
        display_count = min(len(lines), max_lines)
    display_lines = lines[:display_count]
    remaining = len(lines) - display_count

    summary = config.error_summary if is_error else config.success_summary
    if summary:
        text += f"\n⎿ {summary}"
    style_method = None
    if theme and config.style_fn:
        style_method = getattr(theme, config.style_fn, None)
    for line in display_lines:
        gpu_formatted = format_gpu_event_line(line)
        display_line = gpu_formatted if gpu_formatted is not None else line
        if display_line.startswith("[GPU]") and theme and hasattr(theme, "accent_fg"):
            styled_line = theme.accent_fg(display_line)
        elif style_method:
            styled_line = style_method(display_line)
        else:
            styled_line = display_line
        text += f"\n  {styled_line}"
    if remaining > 0:
        hint = f"... ({remaining} more lines)"
        styled_hint = theme.muted_fg(hint) if theme else hint
        text += f"\n  {styled_hint}"
    return text


def format_tool(
    tool_name: str,
    args: dict[str, Any],
    result: dict[str, Any] | None,
    detail_level: DetailLevel,
    theme: Theme | None = None,
    config: ToolRenderConfig | None = None,
) -> str:
    """Format any tool output using config or sensible defaults."""
    from ..dtypes import DetailLevel, ToolRenderConfig
    if config is None:
        config = ToolRenderConfig()

    if config.custom_formatter:
        return config.custom_formatter(tool_name, args, result, detail_level, theme)

    if config.header_fn:
        header = config.header_fn(tool_name, args)
    else:
        header = _default_header(tool_name, args, theme)
    return format_tool_output(header, result, detail_level, theme, config)


def format_streaming_tool(
    tool_name: str,
    args: dict[str, Any],
    detail_level: DetailLevel,
    theme: Theme | None = None,
    config: ToolRenderConfig | None = None,
) -> str:
    """Format a tool call during streaming (before result is received)."""
    from ..dtypes import DetailLevel, ToolRenderConfig

    if config is None:
        config = ToolRenderConfig()

    if config.custom_formatter:
        return config.custom_formatter(tool_name, args, None, detail_level, theme)

    content = _get_streaming_content_arg(args)
    is_multiline = content is not None and "\n" in content
    if not content or not is_multiline:
        return _default_header(tool_name, args, theme)

    if config.header_fn:
        header = config.header_fn(tool_name, args)
    else:
        header = _default_header(tool_name, args, theme)

    lines = content.split("\n")
    max_lines = max(config.streaming_max_lines, 1)
    display_lines = lines[:max_lines]
    remaining = len(lines) - max_lines

    parts: list[str] = [header]
    for line in display_lines:
        parts.append(f"  {line}")
    if remaining > 0:
        parts.append(f"  ... ({remaining} more lines)")

    return "\n".join(parts)


def shorten_path(path: str) -> str:
    """Convert absolute path to tilde notation if in home directory."""
    import os
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home) :]
    return path


def replace_tabs(text: str) -> str:
    """Replace tabs with spaces for consistent rendering."""
    return text.replace("\t", "   ")
