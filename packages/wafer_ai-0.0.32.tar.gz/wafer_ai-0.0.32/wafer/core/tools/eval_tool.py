"""Eval task tool for agent-driven hillclimbing.

Exposes Task.produce() + Task.score() as a first-class agent tool.
The agent can use builtin tasks (kernelbench, vllm, etc.) or write
a custom Task subclass in a .py file and point this tool at it.

The Task interface the agent must implement:

    from wafer.eval import Task, Score, Metric
    from wafer.eval.sandbox_runner import sandbox_run

    class MyTask(Task):
        async def produce(self, args: list[str]) -> str:
            work_dir = args[0]
            # Use sandbox_run() to execute on the remote GPU
            output = await sandbox_run("cd /tmp && ./benchmark")
            return output

        def score(self, output: str, baseline: str | None = None) -> Score:
            # Parse output, return Score with Metric entries
            return Score(metrics=(
                Metric("my_metric", value, weight=0.0),
                Metric("score", composite, weight=1.0),
            ))

For tasks that need remote GPU execution, use sandbox_run() from
wafer.eval.sandbox_runner. It delegates to `wafer sandbox run` CLI,
handling SSH, tmux sessions, and target resolution automatically.
"""
import json
from pathlib import Path

import trio

from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)

EVAL_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="eval_task",
        description=(
            "Evaluate the current solution using a Task (produce + score). "
            "Use a builtin task name (kernelbench, vllm, pytest, aiter, hipblaslt, "
            "hipblaslt-gemm, flashinfer-bench) or a path to a .py file that defines "
            "a Task subclass with produce() and score() methods. "
            "Returns JSON with scored metrics. Use this tool in a loop to hillclimb: "
            "make changes, evaluate, check score, repeat until maximized.\n\n"
            "To write a custom task.py that runs commands on the remote GPU, "
            "use `from wafer.eval.sandbox_runner import sandbox_run` in your "
            "task's produce() method. Example:\n"
            "  output = await sandbox_run('cd /tmp && nvcc -O3 k.cu -o k && ./k')\n"
            "sandbox_run() delegates to `wafer sandbox run` CLI, handling SSH "
            "and target resolution automatically."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "task": {
                    "type": "string",
                    "description": (
                        "Builtin task name (e.g. 'kernelbench') or path to a .py file "
                        "implementing a Task subclass with produce() and score() methods. "
                        "Custom tasks can use `from wafer.eval.sandbox_runner import sandbox_run` "
                        "to execute commands on the remote GPU from within produce()."
                    ),
                },
                "after": {
                    "type": "string",
                    "description": "Directory to evaluate (default: current directory '.')",
                },
                "before": {
                    "type": "string",
                    "description": "Optional baseline directory for comparison scoring.",
                },
                "task_args": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Extra arguments passed to produce() after the directory.",
                },
            },
        ),
        required=["task"],
    ),
)


async def exec_eval(
    tool_call: ToolCall,
    working_dir: Path,
) -> ToolResult:
    """Execute eval task: load Task, run produce(), then score()."""
    assert tool_call.name == "eval_task"
    assert "task" in tool_call.args

    task_name = tool_call.args["task"]
    after_dir = Path(tool_call.args.get("after", "."))
    before_dir_str = tool_call.args.get("before")
    extra_args = tool_call.args.get("task_args", [])

    if not after_dir.is_absolute():
        after_dir = working_dir / after_dir
    after_dir = after_dir.resolve()

    assert after_dir.is_dir(), f"--after directory does not exist: {after_dir}"

    # Resolve task .py paths relative to working_dir
    if task_name.endswith(".py") and not Path(task_name).is_absolute():
        task_name = str((working_dir / task_name).resolve())

    try:
        from wafer.eval import load_task
        task_obj = load_task(task_name)
    except Exception as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Failed to load task {task_name!r}: {e}",
        )

    after_args = [str(after_dir)] + list(extra_args)

    try:
        after_output = await trio.to_thread.run_sync(
            lambda: _run_produce(task_obj, after_args)
        )
    except Exception as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Task produce() failed: {e}",
        )

    before_output: str | None = None
    if before_dir_str:
        before_dir = Path(before_dir_str)
        if not before_dir.is_absolute():
            before_dir = working_dir / before_dir
        before_dir = before_dir.resolve()
        assert before_dir.is_dir(), f"--before directory does not exist: {before_dir}"
        before_args = [str(before_dir)] + list(extra_args)
        try:
            before_output = await trio.to_thread.run_sync(
                lambda: _run_produce(task_obj, before_args)
            )
        except Exception as e:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Baseline produce() failed: {e}",
            )

    try:
        score = task_obj.score(after_output, before_output)
    except Exception as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Task score() failed: {e}",
        )

    score_dict = score.to_dict()
    details = {m["name"]: m["value"] for m in score_dict["metrics"]}

    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=json.dumps(score_dict, indent=2),
        details=details,
    )


def _run_produce(task_obj: object, args: list[str]) -> str:
    """Run task.produce() in a sync context (called via trio.to_thread)."""
    import asyncio
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(task_obj.produce(args))  # type: ignore[union-attr]
    finally:
        loop.close()
