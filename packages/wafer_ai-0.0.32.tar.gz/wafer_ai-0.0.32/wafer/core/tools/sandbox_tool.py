"""Sandbox tool: run commands on the remote GPU machine via persistent tmux session."""
from __future__ import annotations

from collections.abc import Awaitable, Callable

from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)
from wafer.core.sandbox.session import SandboxSession
from wafer.core.tools._output import truncate_output

OnOutputCallback = Callable[[str], Awaitable[None]]

SANDBOX_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="sandbox",
        description=(
            "Run a command on the remote GPU machine, or upload a file to it. "
            "To run a command, set 'command'. To upload a file, set 'upload_path' "
            "and 'upload_content' (transfers via SFTP, reliable for any file size)."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "command": {
                    "type": "string",
                    "description": "Command to run on the remote GPU machine. Use && to chain commands.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default: 180)",
                },
                "upload_path": {
                    "type": "string",
                    "description": "Remote file path to upload content to (e.g. '~/gemm/kernel.cu'). Use with upload_content.",
                },
                "upload_content": {
                    "type": "string",
                    "description": "File content to upload to upload_path. Transferred via SFTP, works for any size.",
                },
            },
        ),
        required=[],
    ),
)


async def exec_sandbox(
    tool_call: ToolCall,
    session: SandboxSession,
    on_output: OnOutputCallback | None = None,
) -> ToolResult:
    """Execute sandbox tool call. Returns ToolResult."""
    upload_path = tool_call.args.get("upload_path")
    upload_content = tool_call.args.get("upload_content")

    if upload_path and upload_content is not None:
        return await _handle_upload(tool_call, session, upload_path, upload_content)

    command = tool_call.args.get("command", "")
    if not command:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error="sandbox requires either 'command' or 'upload_path'+'upload_content'",
        )
    timeout = tool_call.args.get("timeout", 180)
    output, exit_code = await session.run_command(command, timeout, on_output=on_output)
    output = truncate_output(output)
    if exit_code == -1:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=output,
            error=f"Command timed out after {timeout} seconds",
        )
    if exit_code != 0:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=output,
            error=f"Command exited with code {exit_code}",
        )
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=output or "(no output)",
    )


async def _handle_upload(
    tool_call: ToolCall,
    session: SandboxSession,
    upload_path: str,
    upload_content: str,
) -> ToolResult:
    """Upload file content to sandbox via SSH exec with stdin piping.

    Bypasses tmux send-keys (unreliable for large content) and SFTP (trio-asyncio
    bridge issues). Pipes content through SSH exec channel which handles binary
    data reliably at any size.
    """
    assert session._client is not None, "SandboxSession not started"
    import shlex as _shlex

    from wafer.core.async_ssh import _trio_wrap

    if upload_path.startswith("~"):
        home_result = await session._client.exec("printf '%s' \"$HOME\"")
        home = home_result.stdout.strip()
        assert home, "failed to resolve $HOME on remote"
        resolved_path = home + upload_path[1:]
    else:
        resolved_path = upload_path

    parent_dir = "/".join(resolved_path.rsplit("/", 1)[:-1])
    if parent_dir:
        await session._client.exec(f"mkdir -p {_shlex.quote(parent_dir)}")

    conn = await session._client._get_connection()
    write_cmd = f"cat > {_shlex.quote(resolved_path)}"
    result = await _trio_wrap(conn.run)(write_cmd, input=upload_content, check=False)
    exit_code = result.exit_status or 0
    if exit_code != 0:
        stderr = result.stderr or ""
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Upload failed (exit {exit_code}): {stderr}",
        )

    byte_count = len(upload_content.encode("utf-8"))
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=f"Uploaded {byte_count} bytes to {resolved_path}",
    )
