"""NSYS Tools - Shared NSYS parsing and profiling utilities.

This package provides shared logic for NSYS (Nsight Systems) profiling and analysis
that can be used by both the Wafer CLI and wafer-api.

Components:
- discovery: Find nsys executable on various platforms
- parser: Parse nsys stats CSV output into structured data
- models: Frozen dataclasses for results
- profiler: Profiling execution helpers
"""

from .discovery import (
    NSYSInstallation,
    find_nsys,
    get_install_command,
    get_nsys_version,
    is_macos,
)
from .models import (
    KernelInfo,
    MemoryTransfer,
    NSYSParseResult,
    NSYSProfileResult,
    NSYSSummary,
)
from .parser import (
    analyze_report,
    parse_kernel_csv,
    parse_memory_csv,
    run_nsys_stats,
)

__all__ = [
    # Discovery
    "find_nsys",
    "get_nsys_version",
    "get_install_command",
    "is_macos",
    "NSYSInstallation",
    # Models
    "KernelInfo",
    "MemoryTransfer",
    "NSYSSummary",
    "NSYSParseResult",
    "NSYSProfileResult",
    # Parser
    "parse_kernel_csv",
    "parse_memory_csv",
    "run_nsys_stats",
    "analyze_report",
]
