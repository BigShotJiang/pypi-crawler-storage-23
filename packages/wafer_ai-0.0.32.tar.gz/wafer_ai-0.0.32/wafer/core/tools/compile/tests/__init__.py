"""Tests for the cloud CUDA compiler."""
