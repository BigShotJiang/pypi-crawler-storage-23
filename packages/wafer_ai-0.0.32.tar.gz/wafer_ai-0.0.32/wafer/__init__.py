"""Wafer unified package (CLI, SDK, and LSP)."""

__version__ = "0.3.0"
