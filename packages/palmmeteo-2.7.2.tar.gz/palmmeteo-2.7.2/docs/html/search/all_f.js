var searchData=
[
  ['origin_0',['origin',['../classpalmmeteo_1_1library_1_1NCDates.html#a381d66f7632c280b16081d18d53837b4',1,'palmmeteo::library::NCDates']]],
  ['output_5fdims_1',['output_dims',['../classpalmmeteo_1_1library_1_1InputGatherer.html#a784f5743286b6baa6be4aef353a45c89',1,'palmmeteo::library::InputGatherer']]]
];
