"""Controller layer (legacy).

The hardware controller and factory have been replaced by
:class:`~redsun.containers.AppContainer`.
"""
