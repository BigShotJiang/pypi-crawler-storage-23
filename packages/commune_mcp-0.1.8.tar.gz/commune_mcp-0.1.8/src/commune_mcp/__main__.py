"""Allow running with `python -m commune_mcp`."""

from commune_mcp.server import main

main()
