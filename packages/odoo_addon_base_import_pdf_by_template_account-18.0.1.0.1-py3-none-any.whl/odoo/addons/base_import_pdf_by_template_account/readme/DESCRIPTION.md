Added support for account to process the PDF attached to the invoice when creating the invoice from an email alias.
Add 'Invoicing > Configuration > Management > Invoice Templates' menu item to Manager Accounting users.
