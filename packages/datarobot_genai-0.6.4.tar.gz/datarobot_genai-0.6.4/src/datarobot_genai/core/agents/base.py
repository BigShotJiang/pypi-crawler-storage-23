# Copyright 2025 DataRobot, Inc. and its affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import abc
import json
import os
from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING
from typing import Any
from typing import Generic
from typing import Optional
from typing import TypeAlias
from typing import TypedDict
from typing import TypeVar

from ag_ui.core import Event
from ag_ui.core import RunAgentInput

from datarobot_genai.core.agents.history import build_history_summary_from_messages
from datarobot_genai.core.config import get_max_history_messages_default
from datarobot_genai.core.utils.auth import prepare_identity_header
from datarobot_genai.core.utils.urls import get_api_base

if TYPE_CHECKING:
    from ragas import MultiTurnSample

TTool = TypeVar("TTool")


class BaseAgent(Generic[TTool], abc.ABC):
    """BaseAgent centralizes common initialization for agent templates.

    Fields:
      - api_key: DataRobot API token
      - api_base: Endpoint for DataRobot, normalized for LLM Gateway usage
      - model: Preferred model name
      - timeout: Request timeout
      - verbose: Verbosity flag
      - authorization_context: Authorization context for downstream agents/tools
      - max_history_messages: Maximum number of prior messages to include in chat history
    """

    _max_history_messages: int | None = None

    @property
    def max_history_messages(self) -> int:
        """Maximum number of prior messages to include in chat history.

        Defaults to ``DATAROBOT_GENAI_MAX_HISTORY_MESSAGES`` env var (read at
        call time). Subclasses can override via the constructor parameter or
        by overriding this property.
        """
        if self._max_history_messages is not None:
            return self._max_history_messages
        return get_max_history_messages_default()

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        model: str | None = None,
        verbose: bool | str | None = True,
        timeout: int | None = 90,
        authorization_context: dict[str, Any] | None = None,
        forwarded_headers: dict[str, str] | None = None,
        max_history_messages: int | None = None,
        **_: Any,
    ) -> None:
        self._max_history_messages = max_history_messages
        self.api_key = api_key or os.environ.get("DATAROBOT_API_TOKEN")
        self.api_base = (
            api_base or os.environ.get("DATAROBOT_ENDPOINT") or "https://app.datarobot.com"
        )
        self.model = model
        self.timeout = timeout if timeout is not None else 90
        if isinstance(verbose, str):
            self.verbose = verbose.lower() == "true"
        elif verbose is None:
            self.verbose = True
        else:
            self.verbose = bool(verbose)
        self._mcp_tools: list[TTool] = []
        self._authorization_context = authorization_context or {}
        self._forwarded_headers: dict[str, str] = forwarded_headers or {}
        self._identity_header: dict[str, str] = prepare_identity_header(self._forwarded_headers)

    def set_mcp_tools(self, tools: list[TTool]) -> None:
        self._mcp_tools = tools

    @property
    def mcp_tools(self) -> list[TTool]:
        """Return the list of MCP tools available to this agent.

        Subclasses can use this to wire tools into CrewAI agents/tasks during
        workflow construction inside ``crew``.
        """
        return self._mcp_tools

    @property
    def authorization_context(self) -> dict[str, Any]:
        """Return the authorization context for this agent."""
        return self._authorization_context

    @property
    def forwarded_headers(self) -> dict[str, str]:
        """Return the forwarded headers for this agent."""
        return self._forwarded_headers

    def litellm_api_base(self, deployment_id: str | None) -> str:
        return get_api_base(self.api_base, deployment_id)

    @abc.abstractmethod
    def invoke(self, run_agent_input: RunAgentInput) -> InvokeReturn:
        raise NotImplementedError("Not implemented")

    def build_history_summary(
        self,
        run_agent_input: RunAgentInput,
    ) -> str:
        """Instance helper to summarize prior turns as plain-text transcript.

        Subclasses can override ``max_history_messages`` to control how many
        prior messages are included. This is primarily intended for exposing a
        ``chat_history`` variable in prompts across different agent types.
        """
        return build_history_summary_from_messages(run_agent_input, self.max_history_messages)

    @classmethod
    def create_pipeline_interactions_from_events(
        cls,
        events: list[Any] | None,
    ) -> MultiTurnSample | None:
        """Create a simple MultiTurnSample from a list of generic events/messages."""
        if not events:
            return None
        # Lazy import to reduce memory overhead when ragas is not used
        from ragas import MultiTurnSample

        return MultiTurnSample(user_input=events)


def extract_user_prompt_content(run_agent_input: RunAgentInput) -> Any:
    """Extract the last user message content from input."""
    user_messages = [msg for msg in run_agent_input.messages if msg.role == "user"]
    # Get the last user message
    content: str = user_messages[-1].content if user_messages else ""
    # Try converting prompt from json to a dict
    if isinstance(content, str):
        try:
            content = json.loads(content)
        except json.JSONDecodeError:
            pass

    return content


def make_system_prompt(suffix: str = "", *, prefix: str | None = None) -> str:
    """Build a system prompt with optional prefix and suffix.

    Parameters
    ----------
    suffix : str, default ""
        Text appended after the prefix. If non-empty, it is placed on a new line.
    prefix : str | None, keyword-only, default None
        Custom prefix text. When ``None``, a default collaborative assistant
        instruction is used.

    Returns
    -------
    str
        The composed system prompt string.
    """
    default_prefix = (
        "You are a helpful AI assistant, collaborating with other assistants."
        " Use the provided tools to progress towards answering the question."
        " If you are unable to fully answer, that's OK, another assistant with different tools "
        " will help where you left off. Execute what you can to make progress."
    )
    head = prefix if prefix is not None else default_prefix
    if suffix:
        return head + "\n" + suffix
    return head


# Structured type for token usage metrics in responses
class UsageMetrics(TypedDict):
    completion_tokens: int
    prompt_tokens: int
    total_tokens: int


# Canonical return type for all agent invoke implementations
InvokeReturn: TypeAlias = AsyncGenerator[
    tuple[Event, Optional["MultiTurnSample"], UsageMetrics], None
]


def default_usage_metrics() -> UsageMetrics:
    """Return a metrics dict with required keys for OpenAI-compatible responses."""
    return {
        "completion_tokens": 0,
        "prompt_tokens": 0,
        "total_tokens": 0,
    }
