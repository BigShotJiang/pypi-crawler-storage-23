"""grafeo-memory MCP server — expose the memory API as MCP tools."""

from grafeo_memory.mcp.server import mcp

__all__ = ["mcp"]
