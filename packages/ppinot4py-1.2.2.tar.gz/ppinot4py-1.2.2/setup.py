from setuptools import setup

# Compatibility shim: project metadata is defined in pyproject.toml.
setup()
