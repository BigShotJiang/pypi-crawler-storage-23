__title__ = "tgcore"
__version__ = "1.0.28"
__author__ = "TeamKillerX"
__license__ = "Apache-2.0"

__description__ = (
    "Enterprise-grade bot API framework for secure, scalable integrations. "
    "Built with zero-trust architecture, encrypted credentials, "
    "and real-time request validation."
)

__url__ = "https://github.com/TeamKillerX/tgcore"
