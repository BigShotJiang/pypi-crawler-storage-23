---
name: imagor
description: Generate and edit images, icons, diagrams, and visual stories using AI models via OpenRouter
---

# Imagor — Multi-Model Image Generation

Generate and edit images using the best AI models (Gemini, GPT-5 Image, FLUX.2) through a single unified tool.

## Quick Reference

### Generate an image
```bash
uv run imagor create "a sunset over mountains with a sailboat"
```

### Edit an existing image
```bash
uv run imagor edit /path/to/image.png "add a rainbow in the sky"
```

### Generate an icon
```bash
uv run imagor icon "rocket ship"
```
Note: Icons are generated on a white/light background. No model currently supports true alpha transparency via OpenRouter.

### Create a diagram
```bash
# Direct LLM generation (recommended — produces better results)
uv run imagor diagram "OAuth2 authentication flow"
```
Prefer the direct approach — it produces cleaner, more professional diagrams than the hybrid mode. Only fall back to hybrid (`--source flow.mmd --engine mermaid`) if the direct approach fails for your specific diagram type.

### Combine images
```bash
uv run imagor combine img1.png img2.png --prompt "Create a before/after comparison"
```

### Generate a visual story
```bash
uv run imagor story storyboard.json
```
The story pipeline auto-generates character reference sheets and uses multi-turn conversations for character consistency across scenes.

### Check credits
```bash
uv run imagor credits
```

## Piping Support
Commands can be chained — each prints the output file path to stdout:
```bash
uv run imagor create "a cat" | uv run imagor edit - "add a top hat"
```

## Model Selection

| Alias | Model | Best For | Cost |
|-------|-------|----------|------|
| `gemini` (default) | Gemini 2.5 Flash | General use, editing | ~$0.06/image |
| `gemini-pro` | Gemini 3 Pro | High quality, 4K | ~$0.15/image |
| `gpt5` | GPT-5 Image | Text-heavy images | ~$0.07/image |
| `gpt5-mini` | GPT-5 Image Mini | Budget GPT, good icons | ~$0.05/image |
| `flux` | FLUX.2 Pro | Photorealistic | ~$0.03/image |

Override with `--model` or `-m`:
```bash
uv run imagor create "portrait" -m gemini-pro --image-size 4K
```

## Common Options
- `--model`, `-m` — Model name or alias
- `--output`, `-o` — Output file path
- `--size` — Aspect ratio (e.g. `16:9`, `1:1`, `3:2`)
- `--image-size` — Resolution: `1K`, `2K`, `4K`
- `--format`, `-f` — Output format: `png`, `jpg`, `webp`
- `--quality`, `-q` — JPEG/WebP quality 0-100 (default 85)

## MCP Tools

When used as an MCP server (`uv run imagor-mcp`), these tools are available:

| Tool | Description |
|------|-------------|
| `imagor_create` | Text-to-image generation |
| `imagor_edit` | Edit/modify an existing image |
| `imagor_icon` | Generate icons |
| `imagor_diagram` | Create diagrams (prefer direct mode) |
| `imagor_combine` | Composite multiple images |
| `imagor_story` | Visual story from storyboard JSON |
| `imagor_models` | List available models |
| `imagor_credits` | Check remaining credits |

## Storyboard JSON Format

A storyboard is a **narrative** — scenes should tell a connected story, not be random frames. Key principles:
- Use `"setting"` to anchor all scenes in a consistent location/world
- Each scene prompt should reference what happened before and what happens next
- Keep characters in the same environment unless the story explicitly moves locations
- Think of it as a picture book: each page advances the plot

```json
{
    "title": "Elara's Lost Lantern",
    "style": "warm watercolor storybook illustration",
    "setting": "A cozy woodland village at twilight, with glowing mushroom houses, stone paths, and firefly-lit trees",
    "characters": [
        {
            "name": "Elara",
            "appearance": "tall elf, silver hair, green eyes, blue tunic",
            "reference": "optional/path/to/reference.png"
        }
    ],
    "scenes": [
        {
            "title": "The Discovery",
            "prompt": "Elara notices her lantern has gone dark while walking the village stone path. She holds it up, puzzled, as fireflies swirl around the nearby mushroom houses."
        },
        {
            "title": "Asking for Help",
            "prompt": "Elara kneels beside a wise old toad sitting on the same stone path. The toad points toward a glowing cave at the edge of the village. The mushroom houses are visible in the background."
        },
        {
            "title": "The Glow Returns",
            "prompt": "Elara stands at the cave entrance, holding her lantern which now glows brightly again. The village stone path stretches behind her, fireflies celebrating. She smiles triumphantly."
        }
    ]
}
```

**Tips for good storyboards:**
- Each scene prompt should describe specific actions and emotions, not just settings
- Mention shared landmarks (the stone path, the mushroom houses) across scenes for visual continuity
- Character reference images (photos or illustrations) dramatically improve consistency — use `"reference"` to point to one

## Configuration

Config file: `~/.config/imagor/config.json`
```json
{
    "openrouter_api_key": "sk-or-...",
    "default_model": "google/gemini-2.5-flash-image",
    "model_overrides": {"story": "google/gemini-3-pro-image-preview"},
    "low_credit_warning": 1.0
}
```

Environment variable `OPENROUTER_API_KEY` takes priority over config file.
