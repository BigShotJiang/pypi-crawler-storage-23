# Imagor

Multi-model image generation CLI and MCP server via [OpenRouter](https://openrouter.ai/).

Generate and edit images, icons, diagrams, and visual stories using the best AI image models (Gemini, GPT-5 Image, FLUX.2) through a single unified tool.

## Features

- **Create** — text-to-image generation with detailed prompts (2000+ chars supported)
- **Edit** — modify existing images with natural language instructions
- **Icons** — flat-style UI icons, square format
- **Diagrams** — technical diagrams via direct LLM generation or hybrid Kroki+LLM
- **Combine** — composite multiple images with LLM guidance
- **Stories** — multi-scene visual narratives with character consistency
- **Piping** — chain commands together (`create | edit -`)
- **Format conversion** — PNG, JPEG, WebP with quality control

## Setup

Requires [uv](https://docs.astral.sh/uv/) and an [OpenRouter](https://openrouter.ai/) API key.

```bash
# Option 1: Environment variable
export OPENROUTER_API_KEY="sk-or-..."

# Option 2: Config file
mkdir -p ~/.config/imagor
echo '{"openrouter_api_key": "sk-or-..."}' > ~/.config/imagor/config.json
```

## Usage

```bash
# Generate an image
uv run imagor create "a sunset over mountains with a sailboat"

# Edit an existing image
uv run imagor edit photo.png "make it look like a painting"

# Generate an icon
uv run imagor icon "rocket ship"

# Create a diagram (direct LLM — recommended)
uv run imagor diagram "OAuth2 authentication flow"

# Combine images
uv run imagor combine img1.png img2.png --prompt "before/after comparison"

# Generate a visual story
uv run imagor story storyboard.json

# Chain commands via piping
uv run imagor create "a cat" | uv run imagor edit - "add a top hat"

# Check credits & models
uv run imagor credits
uv run imagor models
```

## Models

| Alias | Model | Gen | Edit | Best For | Cost |
|-------|-------|-----|------|----------|------|
| `gemini` (default) | Gemini 2.5 Flash | yes | yes | General use, editing | ~$0.06/image |
| `gemini-pro` | Gemini 3 Pro | yes | yes | High quality, 4K | ~$0.15/image |
| `gpt5` | GPT-5 Image | yes | yes | Text-heavy images | ~$0.07/image |
| `gpt5-mini` | GPT-5 Image Mini | yes | yes | Budget GPT, good icons | ~$0.05/image |
| `flux` | FLUX.2 Pro | yes | no | Photorealistic | ~$0.03/image |

Override with `--model` or `-m`:

```bash
uv run imagor create "portrait" -m gemini-pro --image-size 4K
```

## Common Options

| Flag | Description |
|------|-------------|
| `--model`, `-m` | Model name or alias |
| `--output`, `-o` | Output file path |
| `--size` | Aspect ratio (`16:9`, `1:1`, `3:2`) |
| `--image-size` | Resolution: `1K`, `2K`, `4K` |
| `--format`, `-f` | Output format: `png`, `jpg`, `webp` |
| `--quality`, `-q` | JPEG/WebP quality 0-100 (default 85) |

## Visual Stories

The story command generates multi-scene illustrated narratives with character consistency. Pass a storyboard JSON:

```json
{
    "title": "The Runaway Ball",
    "style": "warm watercolor children's book illustration",
    "setting": "A sunny living room with a colorful play mat and wooden toy shelf",
    "characters": [
        {
            "name": "Sam",
            "appearance": "toddler with curly brown hair, blue shirt",
            "reference": "optional/path/to/photo.png"
        }
    ],
    "scenes": [
        {
            "title": "Found It!",
            "prompt": "Sam sits on the play mat holding a bright red ball, smiling."
        },
        {
            "title": "Oops!",
            "prompt": "The red ball rolls away across the play mat. Sam watches with wide eyes."
        }
    ]
}
```

Key fields:
- **`setting`** — anchors all scenes in a consistent location for visual continuity
- **`reference`** — point to a photo or illustration for character consistency
- Each scene prompt should reference shared landmarks across scenes

Output: scene images + an `index.html` gallery in the output directory.

## MCP Server

Run as an MCP server for use with Claude Code or other MCP clients:

```bash
uv run imagor-mcp
```

Add to Claude Code settings (`~/.claude.json`):

```json
{
  "mcpServers": {
    "imagor": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/imagor", "imagor-mcp"],
      "env": {"OPENROUTER_API_KEY": "sk-or-..."}
    }
  }
}
```

Available MCP tools: `imagor_create`, `imagor_edit`, `imagor_icon`, `imagor_diagram`, `imagor_combine`, `imagor_story`, `imagor_models`, `imagor_credits`.

## Architecture

```
src/imagor/
├── operations.py  — All async business logic (single source of truth)
├── cli.py         — Typer CLI (thin wrapper)
├── server.py      — FastMCP MCP server (thin wrapper)
├── client.py      — OpenRouter httpx client
├── models.py      — Model registry & constraints
├── prompts.py     — Task-specific prompt templates
├── diagram.py     — Kroki/Mermaid rendering pipeline
├── image_utils.py — Format conversion, temp file management
└── config.py      — Config loading (file + env)
```

The CLI and MCP server are thin wrappers around `operations.py` — zero code duplication.

## License

[MIT](LICENSE)
