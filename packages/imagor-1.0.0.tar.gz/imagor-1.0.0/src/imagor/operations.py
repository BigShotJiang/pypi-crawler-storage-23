"""Shared async business logic — single source of truth.

All functions return dicts. CLI and MCP are thin wrappers.
"""

from __future__ import annotations

import html
import json
import tempfile
from pathlib import Path
from typing import Any, Callable

from imagor.client import encode_image_to_data_url, get_client
from imagor.image_utils import save_image
from imagor.models import MODELS, ModelSpec, resolve_model
from imagor import prompts


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_image_config(
    spec: ModelSpec,
    aspect_ratio: str | None,
    image_size: str | None,
) -> dict[str, Any] | None:
    """Build the image_config dict for the API request."""
    cfg: dict[str, Any] = {}
    if spec.fixed_sizes and aspect_ratio and "x" in aspect_ratio:
        # Fixed-size model: pass as "size" (e.g. "1024x1024")
        cfg["size"] = aspect_ratio
    elif aspect_ratio:
        cfg["aspect_ratio"] = aspect_ratio
    if image_size:
        cfg["image_size"] = image_size
    return cfg or None


def _extract_images(response: dict[str, Any]) -> list[str]:
    """Extract base64 data URLs from the API response."""
    images: list[str] = []
    for choice in response.get("choices", []):
        msg = choice.get("message", {})
        # Images in the images array
        for img in msg.get("images", []):
            url = img.get("image_url", {}).get("url", "")
            if url:
                images.append(url)
        # Also check content for inline images (some models)
        content = msg.get("content", "")
        if isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "image_url":
                    url = part.get("image_url", {}).get("url", "")
                    if url:
                        images.append(url)
    return images


def _extract_text(response: dict[str, Any]) -> str:
    """Extract text content from the API response."""
    for choice in response.get("choices", []):
        msg = choice.get("message", {})
        content = msg.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = [p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"]
            return "\n".join(parts)
    return ""


def _extract_cost(response: dict[str, Any]) -> float | None:
    """Extract cost from usage info if available."""
    usage = response.get("usage", {})
    return usage.get("cost")


def _make_result(
    file_path: Path,
    response: dict[str, Any],
) -> dict[str, Any]:
    """Build a standard result dict."""
    cost = _extract_cost(response)
    size_bytes = file_path.stat().st_size
    return {
        "file": str(file_path),
        "size_bytes": size_bytes,
        "size_human": _human_size(size_bytes),
        "cost": cost,
        "text": _extract_text(response),
        "model": response.get("model", ""),
    }


def _human_size(size: float) -> str:
    for unit in ("B", "KB", "MB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


# ---------------------------------------------------------------------------
# Shared generate-call-save pattern
# ---------------------------------------------------------------------------

async def _generate(
    command: str,
    prompt_fn: Callable[[str], str],
    prompt: str,
    *,
    model: str | None = None,
    aspect_ratio: str | None = None,
    image_size: str | None = None,
    output: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
) -> dict[str, Any]:
    """Shared pattern: resolve model, build prompt, call API, save image."""
    spec = resolve_model(model, command)
    errors = spec.validate(aspect_ratio, image_size, target_format)
    if errors:
        raise ValueError("\n".join(errors))

    client = await get_client()
    messages = [{"role": "user", "content": prompt_fn(prompt)}]
    image_config = _build_image_config(spec, aspect_ratio, image_size)

    response = await client.generate_image(
        messages=messages,
        model=spec.id,
        modalities=list(spec.modalities),
        image_config=image_config,
    )

    images = _extract_images(response)
    if not images:
        text = _extract_text(response)
        return {"error": "No image generated", "text": text, "model": spec.id}

    file_path = save_image(
        images[0], command, output, output_dir, target_format, quality,
    )
    return _make_result(file_path, response)


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------

async def create_image(
    prompt: str,
    *,
    model: str | None = None,
    aspect_ratio: str | None = None,
    image_size: str | None = None,
    output: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
) -> dict[str, Any]:
    """Generate an image from a text prompt."""
    return await _generate(
        "create", prompts.create_prompt, prompt,
        model=model, aspect_ratio=aspect_ratio, image_size=image_size,
        output=output, output_dir=output_dir,
        target_format=target_format, quality=quality,
    )


# ---------------------------------------------------------------------------
# edit
# ---------------------------------------------------------------------------

async def edit_image(
    input_path: str,
    prompt: str,
    *,
    model: str | None = None,
    aspect_ratio: str | None = None,
    image_size: str | None = None,
    output: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
) -> dict[str, Any]:
    """Edit an existing image using a text prompt."""
    spec = resolve_model(model, "edit")
    if not spec.can_edit:
        raise ValueError(f"Model {spec.id} does not support editing.")
    errors = spec.validate(aspect_ratio, image_size, target_format)
    if errors:
        raise ValueError("\n".join(errors))

    data_url = encode_image_to_data_url(input_path)
    client = await get_client()

    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": data_url}},
                {"type": "text", "text": prompts.edit_prompt(prompt)},
            ],
        }
    ]
    image_config = _build_image_config(spec, aspect_ratio, image_size)

    response = await client.generate_image(
        messages=messages,
        model=spec.id,
        modalities=list(spec.modalities),
        image_config=image_config,
    )

    images = _extract_images(response)
    if not images:
        text = _extract_text(response)
        return {"error": "No image generated", "text": text, "model": spec.id}

    file_path = save_image(
        images[0], "edit", output, output_dir, target_format, quality,
    )
    return _make_result(file_path, response)


# ---------------------------------------------------------------------------
# icon
# ---------------------------------------------------------------------------

async def create_icon(
    prompt: str,
    *,
    model: str | None = None,
    aspect_ratio: str | None = None,
    image_size: str | None = None,
    output: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
) -> dict[str, Any]:
    """Generate an icon."""
    spec = resolve_model(model, "icon")

    # Icons are square — pick the right default for the model type
    if not aspect_ratio and spec.fixed_sizes:
        square = next((s for s in spec.fixed_sizes if s.split("x")[0] == s.split("x")[1]), None)
        aspect_ratio = square
    elif not aspect_ratio:
        aspect_ratio = "1:1"

    return await _generate(
        "icon", prompts.icon_prompt, prompt,
        model=spec.id, aspect_ratio=aspect_ratio, image_size=image_size,
        output=output, output_dir=output_dir,
        target_format=target_format, quality=quality,
    )


# ---------------------------------------------------------------------------
# diagram
# ---------------------------------------------------------------------------

async def create_diagram(
    prompt: str,
    *,
    source: str | None = None,
    engine: str | None = None,
    model: str | None = None,
    aspect_ratio: str | None = None,
    image_size: str | None = None,
    output: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
) -> dict[str, Any]:
    """Create a diagram — direct LLM or hybrid (Kroki render + LLM enhance)."""
    spec = resolve_model(model, "diagram")

    # Hybrid mode: render source first, then enhance
    if source:
        from imagor.diagram import render_diagram_source

        rendered_path = await render_diagram_source(source, engine)
        return await edit_image(
            str(rendered_path),
            prompts.diagram_enhance_prompt(prompt),
            model=spec.id,
            aspect_ratio=aspect_ratio,
            image_size=image_size,
            output=output,
            output_dir=output_dir,
            target_format=target_format,
            quality=quality,
        )

    # Direct LLM mode
    return await _generate(
        "diagram", prompts.diagram_prompt, prompt,
        model=spec.id, aspect_ratio=aspect_ratio or "16:9", image_size=image_size,
        output=output, output_dir=output_dir,
        target_format=target_format, quality=quality,
    )


# ---------------------------------------------------------------------------
# combine
# ---------------------------------------------------------------------------

async def combine_images(
    input_paths: list[str],
    prompt: str,
    *,
    model: str | None = None,
    aspect_ratio: str | None = None,
    image_size: str | None = None,
    output: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
) -> dict[str, Any]:
    """Combine multiple images with LLM guidance."""
    spec = resolve_model(model, "combine")
    if not spec.can_edit:
        raise ValueError(f"Model {spec.id} does not support image inputs.")
    errors = spec.validate(aspect_ratio, image_size, target_format)
    if errors:
        raise ValueError("\n".join(errors))

    # Build content with all images + text
    content: list[dict[str, Any]] = []
    for path in input_paths:
        data_url = encode_image_to_data_url(path)
        content.append({"type": "image_url", "image_url": {"url": data_url}})
    content.append({"type": "text", "text": prompts.combine_prompt(prompt)})

    client = await get_client()
    messages = [{"role": "user", "content": content}]
    image_config = _build_image_config(spec, aspect_ratio, image_size)

    response = await client.generate_image(
        messages=messages,
        model=spec.id,
        modalities=list(spec.modalities),
        image_config=image_config,
    )

    images = _extract_images(response)
    if not images:
        text = _extract_text(response)
        return {"error": "No image generated", "text": text, "model": spec.id}

    file_path = save_image(
        images[0], "combine", output, output_dir, target_format, quality,
    )
    return _make_result(file_path, response)


# ---------------------------------------------------------------------------
# story
# ---------------------------------------------------------------------------

# Maximum number of conversation turns to keep (user+assistant pairs).
# Prevents unbounded token growth on long stories.
_STORY_CONTEXT_WINDOW = 4


async def generate_story(
    storyboard_path: str,
    *,
    model: str | None = None,
    output_dir: str | None = None,
    target_format: str | None = None,
    quality: int = 85,
    ref_overrides: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Generate a visual story from a storyboard JSON definition.

    Uses multi-turn conversation for character consistency.
    """
    storyboard = json.loads(Path(storyboard_path).read_text())
    spec = resolve_model(model, "story")
    client = await get_client()

    title = storyboard.get("title", "Story")
    style = storyboard.get("style", "digital illustration")
    characters = storyboard.get("characters", [])
    scenes = storyboard.get("scenes", [])
    global_refs = storyboard.get("references", {})

    # Validate characters
    for i, char in enumerate(characters):
        if "name" not in char:
            raise ValueError(f"Character {i} is missing required 'name' field")
        if "appearance" not in char:
            raise ValueError(f"Character '{char['name']}' is missing required 'appearance' field")

    # Apply ref overrides
    if ref_overrides:
        for key, path in ref_overrides.items():
            if key.startswith("character="):
                char_name = key.split("=", 1)[1]
                for c in characters:
                    if c["name"].lower() == char_name.lower():
                        c["reference"] = path
            else:
                global_refs[key] = path

    # Output directory
    out_dir = Path(output_dir) if output_dir else Path(tempfile.mkdtemp(prefix=f"imagor_story_{title[:20]}_"))
    out_dir.mkdir(parents=True, exist_ok=True)

    # Multi-turn conversation for consistency
    conversation: list[dict[str, Any]] = []
    scene_results: list[dict[str, Any]] = []
    total_cost = 0.0

    # Phase 1: Character reference images
    char_ref_paths: dict[str, str] = {}
    for char in characters:
        name = char["name"]
        appearance = char["appearance"]
        ref_path = char.get("reference")

        if ref_path and Path(ref_path).exists():
            char_ref_paths[name] = ref_path
            continue

        # Generate character reference
        msg_content = prompts.story_character_prompt(name, appearance)
        conversation.append({"role": "user", "content": msg_content})

        response = await client.generate_image(
            messages=conversation,
            model=spec.id,
            modalities=list(spec.modalities),
            image_config={"aspect_ratio": "1:1", "image_size": "1K"},
        )

        imgs = _extract_images(response)
        if imgs:
            char_path = save_image(
                imgs[0], f"char_{name.lower()}", output_dir=str(out_dir),
            )
            char_ref_paths[name] = str(char_path)
            # Standard content-list format for assistant response
            conversation.append({
                "role": "assistant",
                "content": [
                    {"type": "text", "text": _extract_text(response)},
                    {"type": "image_url", "image_url": {"url": imgs[0]}},
                ],
            })

        cost = _extract_cost(response)
        if cost:
            total_cost += cost

    # Phase 2: Scene generation
    setting = storyboard.get("setting", "")
    previous_scene_prompt = ""
    for i, scene in enumerate(scenes):
        scene_title = scene.get("title", f"Scene {i+1}")
        scene_prompt = scene.get("prompt", "")
        scene_refs = scene.get("references", [])

        # Build character descriptions for this scene
        char_descs = [f"{c['name']}: {c['appearance']}" for c in characters]

        # Build message content
        content_parts: list[dict[str, Any]] = []

        # Only attach character refs on first scene (they're in conversation history after that)
        if i == 0:
            for name, ref_path in char_ref_paths.items():
                data_url = encode_image_to_data_url(ref_path)
                content_parts.append({"type": "image_url", "image_url": {"url": data_url}})

            # Add global reference images on first scene only
            for ref_key, ref_path in global_refs.items():
                if Path(ref_path).exists():
                    data_url = encode_image_to_data_url(ref_path)
                    content_parts.append({"type": "image_url", "image_url": {"url": data_url}})

        # Add per-scene references
        for ref_path in scene_refs:
            if Path(ref_path).exists():
                data_url = encode_image_to_data_url(ref_path)
                content_parts.append({"type": "image_url", "image_url": {"url": data_url}})

        # Add the scene prompt with continuity context
        full_prompt = prompts.story_scene_prompt(
            scene_prompt, style, char_descs,
            scene_number=i + 1,
            total_scenes=len(scenes),
            setting=setting,
            previous_scene=previous_scene_prompt,
        )
        content_parts.append({"type": "text", "text": full_prompt})

        conversation.append({"role": "user", "content": content_parts})

        # Trim conversation to sliding window (keep character gen + last N scene exchanges)
        # Each scene exchange = 1 user + 1 assistant = 2 entries
        # Character phase entries are at the start, keep them
        char_entries = len(char_ref_paths) * 2  # user + assistant per character
        scene_entries = len(conversation) - char_entries
        max_scene_entries = _STORY_CONTEXT_WINDOW * 2 + 1  # +1 for current user msg
        if scene_entries > max_scene_entries:
            trim_count = scene_entries - max_scene_entries
            conversation = conversation[:char_entries] + conversation[char_entries + trim_count:]

        response = await client.generate_image(
            messages=conversation,
            model=spec.id,
            modalities=list(spec.modalities),
            image_config={"aspect_ratio": "16:9", "image_size": "1K"},
        )

        imgs = _extract_images(response)
        if imgs:
            scene_path = save_image(
                imgs[0],
                f"scene_{i+1:02d}",
                output_dir=str(out_dir),
                target_format=target_format,
                quality=quality,
            )
            scene_results.append({
                "scene": i + 1,
                "title": scene_title,
                "file": str(scene_path),
            })
            # Standard content-list format for assistant response
            conversation.append({
                "role": "assistant",
                "content": [
                    {"type": "text", "text": _extract_text(response)},
                    {"type": "image_url", "image_url": {"url": imgs[0]}},
                ],
            })

        previous_scene_prompt = scene_prompt

        cost = _extract_cost(response)
        if cost:
            total_cost += cost

    # Phase 3: Generate HTML gallery
    gallery_path = _generate_story_gallery(out_dir, title, scene_results)

    return {
        "title": title,
        "output_dir": str(out_dir),
        "gallery": str(gallery_path),
        "scenes": scene_results,
        "total_cost": total_cost,
        "model": spec.id,
    }


def _generate_story_gallery(
    out_dir: Path,
    title: str,
    scenes: list[dict[str, Any]],
) -> Path:
    """Create a simple HTML gallery for the story."""
    safe_title = html.escape(title)
    html_parts = [
        "<!DOCTYPE html>",
        f"<html><head><title>{safe_title}</title>",
        "<style>",
        "body { font-family: system-ui; max-width: 900px; margin: 0 auto; padding: 2rem; background: #1a1a1a; color: #eee; }",
        "h1 { text-align: center; }",
        ".scene { margin: 2rem 0; }",
        ".scene img { width: 100%; border-radius: 8px; }",
        ".scene h2 { margin-top: 1rem; }",
        "</style></head><body>",
        f"<h1>{safe_title}</h1>",
    ]
    for s in scenes:
        rel_path = Path(s["file"]).name
        safe_scene_title = html.escape(s["title"])
        html_parts.append(f'<div class="scene">')
        html_parts.append(f'<img src="{html.escape(rel_path)}" alt="{safe_scene_title}">')
        html_parts.append(f'<h2>Scene {s["scene"]}: {safe_scene_title}</h2>')
        html_parts.append("</div>")
    html_parts.append("</body></html>")

    gallery = out_dir / "index.html"
    gallery.write_text("\n".join(html_parts))
    return gallery


# ---------------------------------------------------------------------------
# credits
# ---------------------------------------------------------------------------

async def get_credits() -> dict[str, Any]:
    """Fetch remaining OpenRouter credits."""
    client = await get_client()
    data = await client.get_credits()
    total = data.get("total_credits", 0)
    used = data.get("total_usage", 0)
    remaining = total - used
    return {
        "total_credits": total,
        "total_usage": used,
        "remaining": remaining,
    }


# ---------------------------------------------------------------------------
# list models
# ---------------------------------------------------------------------------

def list_models() -> list[dict[str, Any]]:
    """Return model info for display."""
    result = []
    for spec in MODELS.values():
        result.append({
            "id": spec.id,
            "name": spec.name,
            "can_generate": spec.can_generate,
            "can_edit": spec.can_edit,
            "aspect_ratios": list(spec.aspect_ratios),
            "image_sizes": list(spec.image_sizes),
            "fixed_sizes": list(spec.fixed_sizes),
            "output_formats": list(spec.output_formats),
            "cost_note": spec.cost_note,
        })
    return result
