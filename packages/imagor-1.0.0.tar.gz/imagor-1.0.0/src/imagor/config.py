"""Configuration loading from file + environment variables."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


def _config_dir() -> Path:
    """Return XDG-compliant config directory."""
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        base = Path(xdg)
    elif os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path.home() / ".config"
    return base / "imagor"


CONFIG_PATH = _config_dir() / "config.json"


def load_config() -> dict[str, Any]:
    """Load config from disk, returning empty dict if missing."""
    if CONFIG_PATH.exists():
        return json.loads(CONFIG_PATH.read_text())
    return {}



def get_api_key() -> str:
    """Resolve OpenRouter API key (env var takes priority)."""
    key = os.environ.get("OPENROUTER_API_KEY") or load_config().get("openrouter_api_key")
    if not key:
        raise RuntimeError(
            "No OpenRouter API key found. Set OPENROUTER_API_KEY env var "
            f"or add 'openrouter_api_key' to {CONFIG_PATH}"
        )
    return key


def get_default_model(command: str) -> str:
    """Return the configured default model for a given command."""
    from imagor.models import COMMAND_DEFAULTS

    cfg = load_config()
    # Per-command override in config
    overrides = cfg.get("model_overrides", {})
    if command in overrides:
        return overrides[command]
    # Global default in config
    if "default_model" in cfg:
        return cfg["default_model"]
    # Hardcoded default
    return COMMAND_DEFAULTS[command]


