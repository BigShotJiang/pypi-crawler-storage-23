"""Imagor: Multi-model image generation via OpenRouter."""
