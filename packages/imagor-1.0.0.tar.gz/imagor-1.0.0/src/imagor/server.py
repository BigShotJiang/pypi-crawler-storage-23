"""Imagor MCP Server — FastMCP application wrapping operations."""

from __future__ import annotations

import json
from pydantic import BaseModel, Field

from mcp.server.fastmcp import FastMCP

from imagor import operations
from imagor.client import close_client

mcp = FastMCP("imagor")


# ---------------------------------------------------------------------------
# Pydantic input models
# ---------------------------------------------------------------------------

class _BaseImageInput(BaseModel):
    """Shared fields for all image generation inputs."""
    model: str | None = Field(default=None, description="Model name or alias (default: gemini flash)")
    aspect_ratio: str | None = Field(default=None, description="Aspect ratio, e.g. '16:9', '1:1'")
    image_size: str | None = Field(default=None, description="Resolution tier: '1K', '2K', '4K'")
    output: str | None = Field(default=None, description="Output file path")
    output_dir: str | None = Field(default=None, description="Output directory")
    target_format: str | None = Field(default=None, description="Output format: png, jpg, webp")
    quality: int = Field(default=85, description="JPEG/WebP quality 0-100")


class CreateInput(_BaseImageInput):
    prompt: str = Field(..., description="Text prompt for image generation")


class EditInput(_BaseImageInput):
    input_path: str = Field(..., description="Path to the image to edit")
    prompt: str = Field(..., description="Edit instructions")


class IconInput(_BaseImageInput):
    prompt: str = Field(..., description="Icon description")


class DiagramInput(_BaseImageInput):
    prompt: str = Field(..., description="Diagram description or enhancement instructions")
    source: str | None = Field(default=None, description="Source file path (Mermaid, PlantUML, D2)")
    engine: str | None = Field(default=None, description="Rendering engine: mermaid, plantuml, d2")


class CombineInput(_BaseImageInput):
    input_paths: list[str] = Field(..., description="Paths to images to combine")
    prompt: str = Field(default="Combine these images naturally", description="Composition instructions")


class StoryInput(BaseModel):
    storyboard_path: str = Field(..., description="Path to storyboard JSON file")
    model: str | None = Field(default=None, description="Model name or alias")
    output_dir: str | None = Field(default=None, description="Output directory for story")
    target_format: str | None = Field(default=None, description="Output format")
    quality: int = Field(default=85, description="Quality 0-100")
    ref_overrides: dict[str, str] | None = Field(default=None, description="Reference overrides: {key: path}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_result(result: dict) -> str:
    return json.dumps(result, indent=2)


def _handle_error(e: Exception) -> str:
    return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------

@mcp.tool(name="imagor_create")
async def imagor_create(params: CreateInput) -> str:
    """Generate an image from a text prompt."""
    try:
        result = await operations.create_image(
            params.prompt,
            model=params.model,
            aspect_ratio=params.aspect_ratio,
            image_size=params.image_size,
            output=params.output,
            output_dir=params.output_dir,
            target_format=params.target_format,
            quality=params.quality,
        )
        return _format_result(result)
    except Exception as e:
        return _handle_error(e)


@mcp.tool(name="imagor_edit")
async def imagor_edit(params: EditInput) -> str:
    """Edit an existing image using a text prompt."""
    try:
        result = await operations.edit_image(
            params.input_path,
            params.prompt,
            model=params.model,
            aspect_ratio=params.aspect_ratio,
            image_size=params.image_size,
            output=params.output,
            output_dir=params.output_dir,
            target_format=params.target_format,
            quality=params.quality,
        )
        return _format_result(result)
    except Exception as e:
        return _handle_error(e)


@mcp.tool(name="imagor_icon")
async def imagor_icon(params: IconInput) -> str:
    """Generate an icon (default 1:1, UI-ready)."""
    try:
        result = await operations.create_icon(
            params.prompt,
            model=params.model,
            aspect_ratio=params.aspect_ratio,
            image_size=params.image_size,
            output=params.output,
            output_dir=params.output_dir,
            target_format=params.target_format,
            quality=params.quality,
        )
        return _format_result(result)
    except Exception as e:
        return _handle_error(e)


@mcp.tool(name="imagor_diagram")
async def imagor_diagram(params: DiagramInput) -> str:
    """Create a diagram (direct LLM or hybrid Kroki+LLM)."""
    try:
        result = await operations.create_diagram(
            params.prompt,
            source=params.source,
            engine=params.engine,
            model=params.model,
            aspect_ratio=params.aspect_ratio,
            image_size=params.image_size,
            output=params.output,
            output_dir=params.output_dir,
            target_format=params.target_format,
            quality=params.quality,
        )
        return _format_result(result)
    except Exception as e:
        return _handle_error(e)


@mcp.tool(name="imagor_combine")
async def imagor_combine(params: CombineInput) -> str:
    """Combine multiple images into one composition."""
    try:
        result = await operations.combine_images(
            params.input_paths,
            params.prompt,
            model=params.model,
            aspect_ratio=params.aspect_ratio,
            image_size=params.image_size,
            output=params.output,
            output_dir=params.output_dir,
            target_format=params.target_format,
            quality=params.quality,
        )
        return _format_result(result)
    except Exception as e:
        return _handle_error(e)


@mcp.tool(name="imagor_story")
async def imagor_story(params: StoryInput) -> str:
    """Generate a visual story from a storyboard JSON definition."""
    try:
        result = await operations.generate_story(
            params.storyboard_path,
            model=params.model,
            output_dir=params.output_dir,
            target_format=params.target_format,
            quality=params.quality,
            ref_overrides=params.ref_overrides,
        )
        return _format_result(result)
    except Exception as e:
        return _handle_error(e)


@mcp.tool(name="imagor_models")
async def imagor_models() -> str:
    """List available image generation models with capabilities and cost info."""
    return _format_result(operations.list_models())


@mcp.tool(name="imagor_credits")
async def imagor_credits() -> str:
    """Check remaining OpenRouter credits."""
    try:
        result = await operations.get_credits()
        return _format_result(result)
    except Exception as e:
        return _handle_error(e)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    import atexit
    import asyncio
    atexit.register(lambda: asyncio.run(close_client()))
    mcp.run()
