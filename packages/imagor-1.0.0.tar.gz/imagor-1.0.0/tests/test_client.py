"""Tests for OpenRouter client, helpers, and singleton management."""

from __future__ import annotations

import base64
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from imagor.client import (
    OpenRouterClient,
    OpenRouterError,
    _raise_api_error,
    close_client,
    encode_image_to_data_url,
    get_client,
    reset_client,
)


# ---------------------------------------------------------------------------
# encode_image_to_data_url()
# ---------------------------------------------------------------------------

class TestEncodeImageToDataUrl:
    def test_valid_png(self, tmp_path):
        img = tmp_path / "test.png"
        img.write_bytes(b"fakepng")
        result = encode_image_to_data_url(str(img))
        assert result.startswith("data:image/png;base64,")
        # Decode and verify round-trip
        encoded = result.split(",", 1)[1]
        assert base64.b64decode(encoded) == b"fakepng"

    def test_valid_jpeg(self, tmp_path):
        img = tmp_path / "photo.jpg"
        img.write_bytes(b"fakejpg")
        result = encode_image_to_data_url(str(img))
        assert result.startswith("data:image/jpeg;base64,")

    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError, match="Image not found"):
            encode_image_to_data_url("/nonexistent/image.png")

    def test_unknown_extension_defaults_to_png(self, tmp_path):
        img = tmp_path / "test.bmp"
        img.write_bytes(b"fakebmp")
        result = encode_image_to_data_url(str(img))
        assert result.startswith("data:image/png;base64,")


# ---------------------------------------------------------------------------
# _raise_api_error()
# ---------------------------------------------------------------------------

class TestRaiseApiError:
    def test_with_json_error(self):
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 400
        resp.json.return_value = {"error": {"message": "Bad prompt"}}
        resp.text = "raw"
        with pytest.raises(OpenRouterError, match="Bad prompt"):
            _raise_api_error(resp)

    def test_with_no_json(self):
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 500
        resp.json.side_effect = Exception("not json")
        resp.text = "Internal Server Error"
        with pytest.raises(OpenRouterError, match="Internal Server Error"):
            _raise_api_error(resp)

    def test_status_code_in_message(self):
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 429
        resp.json.return_value = {"error": {"message": "Rate limited"}}
        resp.text = ""
        with pytest.raises(OpenRouterError, match="429"):
            _raise_api_error(resp)


# ---------------------------------------------------------------------------
# OpenRouterClient
# ---------------------------------------------------------------------------

class TestOpenRouterClient:
    async def test_generate_image_sends_payload(self, mock_api_key):
        client = OpenRouterClient(api_key="test-key")
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"choices": [], "model": "test"}

        with patch.object(client, "_get_client") as mock_get:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_get.return_value = mock_http

            result = await client.generate_image(
                messages=[{"role": "user", "content": "hello"}],
                model="test-model",
                modalities=["image", "text"],
            )

            mock_http.post.assert_called_once()
            call_kwargs = mock_http.post.call_args
            payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
            assert payload["model"] == "test-model"
            assert payload["modalities"] == ["image", "text"]

    async def test_generate_image_raises_on_error(self, mock_api_key):
        client = OpenRouterClient(api_key="test-key")
        mock_resp = MagicMock()
        mock_resp.status_code = 400
        mock_resp.json.return_value = {"error": {"message": "bad request"}}
        mock_resp.text = "bad request"

        with patch.object(client, "_get_client") as mock_get:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_get.return_value = mock_http

            with pytest.raises(OpenRouterError, match="bad request"):
                await client.generate_image(
                    messages=[], model="test",
                )

    async def test_get_credits(self, mock_api_key):
        client = OpenRouterClient(api_key="test-key")
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"data": {"total_credits": 10, "total_usage": 3}}

        with patch.object(client, "_get_client") as mock_get:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_get.return_value = mock_http

            result = await client.get_credits()
            assert result == {"total_credits": 10, "total_usage": 3}


# ---------------------------------------------------------------------------
# Singleton management
# ---------------------------------------------------------------------------

class TestSingleton:
    async def test_get_client_returns_instance(self, mock_api_key):
        reset_client()
        c1 = await get_client()
        c2 = await get_client()
        assert c1 is c2
        await close_client()

    async def test_close_client_resets(self, mock_api_key):
        reset_client()
        c1 = await get_client()
        await close_client()
        # After close, get_client should create a new instance
        c2 = await get_client()
        assert c1 is not c2
        await close_client()

    def test_reset_client(self, mock_api_key):
        reset_client()
        # Just verifies it doesn't error
