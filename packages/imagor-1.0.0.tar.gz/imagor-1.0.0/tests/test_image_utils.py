"""Tests for image decoding, format conversion, and output paths."""

from __future__ import annotations

from pathlib import Path

import pytest

from imagor.image_utils import (
    convert_image,
    decode_data_url,
    make_output_path,
    mime_to_ext,
    save_image,
)
from tests.conftest import TINY_PNG, TINY_PNG_DATA_URL


# ---------------------------------------------------------------------------
# decode_data_url()
# ---------------------------------------------------------------------------

class TestDecodeDataUrl:
    def test_valid_png(self):
        raw, mime = decode_data_url(TINY_PNG_DATA_URL)
        assert mime == "image/png"
        assert raw == TINY_PNG

    def test_valid_jpeg_url(self):
        import base64
        # Doesn't need to be valid JPEG bytes — just tests parsing
        data = base64.b64encode(b"fakejpeg").decode()
        url = f"data:image/jpeg;base64,{data}"
        raw, mime = decode_data_url(url)
        assert mime == "image/jpeg"
        assert raw == b"fakejpeg"

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="Invalid data URL"):
            decode_data_url("not-a-data-url")

    def test_missing_base64_prefix_raises(self):
        with pytest.raises(ValueError, match="Invalid data URL"):
            decode_data_url("data:image/png,rawdata")


# ---------------------------------------------------------------------------
# mime_to_ext()
# ---------------------------------------------------------------------------

class TestMimeToExt:
    def test_png(self):
        assert mime_to_ext("image/png") == "png"

    def test_jpeg(self):
        assert mime_to_ext("image/jpeg") == "jpg"

    def test_webp(self):
        assert mime_to_ext("image/webp") == "webp"

    def test_unknown_defaults_to_png(self):
        assert mime_to_ext("image/bmp") == "png"


# ---------------------------------------------------------------------------
# make_output_path()
# ---------------------------------------------------------------------------

class TestMakeOutputPath:
    def test_explicit_output(self, tmp_path):
        out = tmp_path / "my_image.png"
        result = make_output_path("create", "png", output=str(out))
        assert result == out

    def test_explicit_output_creates_parent(self, tmp_path):
        out = tmp_path / "subdir" / "deep" / "img.png"
        result = make_output_path("create", "png", output=str(out))
        assert result == out
        assert out.parent.exists()

    def test_output_dir(self, tmp_path):
        result = make_output_path("create", "png", output_dir=str(tmp_path))
        assert result.parent == tmp_path
        assert result.name.startswith("create_")
        assert result.suffix == ".png"

    def test_temp_dir_fallback(self):
        result = make_output_path("create", "png")
        assert "imagor-" in str(result.parent)
        assert result.suffix == ".png"

    def test_unique_filenames(self, tmp_path):
        """Two calls should produce different filenames."""
        a = make_output_path("create", "png", output_dir=str(tmp_path))
        b = make_output_path("create", "png", output_dir=str(tmp_path))
        assert a != b


# ---------------------------------------------------------------------------
# convert_image()
# ---------------------------------------------------------------------------

class TestConvertImage:
    def test_png_passthrough(self):
        result = convert_image(TINY_PNG, "png")
        # Should still be valid PNG
        from PIL import Image
        from io import BytesIO
        img = Image.open(BytesIO(result))
        assert img.format == "PNG"

    def test_rgba_to_jpeg_flattens_alpha(self):
        result = convert_image(TINY_PNG, "jpeg")
        from PIL import Image
        from io import BytesIO
        img = Image.open(BytesIO(result))
        assert img.format == "JPEG"
        assert img.mode == "RGB"

    def test_to_webp(self):
        result = convert_image(TINY_PNG, "webp")
        from PIL import Image
        from io import BytesIO
        img = Image.open(BytesIO(result))
        assert img.format == "WEBP"


# ---------------------------------------------------------------------------
# save_image()
# ---------------------------------------------------------------------------

class TestSaveImage:
    def test_save_png(self, tmp_path):
        out = tmp_path / "test.png"
        result = save_image(TINY_PNG_DATA_URL, "create", output=str(out))
        assert result == out
        assert out.exists()
        assert out.stat().st_size > 0

    def test_save_with_format_conversion(self, tmp_path):
        out = tmp_path / "test.jpg"
        result = save_image(
            TINY_PNG_DATA_URL, "create",
            output=str(out), target_format="jpeg",
        )
        assert result == out
        assert out.exists()

    def test_save_to_output_dir(self, tmp_path):
        result = save_image(
            TINY_PNG_DATA_URL, "icon", output_dir=str(tmp_path),
        )
        assert result.parent == tmp_path
        assert result.exists()
