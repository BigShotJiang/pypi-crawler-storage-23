"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import multiprocessing as mp
from typing import TYPE_CHECKING

import onnx
from numpy import ndarray

if TYPE_CHECKING:
    from onnx import ModelProto

from aidge_benchmark import NamedTensor
from aidge_benchmark.registrations import (
    register_backend_inference,
    register_backend_time,
)

from ..dynamic_lib_import import load_package


def _worker(
    model_bytes: bytes,
    inputs_list: list[ndarray],
    nb_warmup: int,
    nb_iterations: int,
    n_threads: int,
    return_dict: dict[str, float],
) -> None:
    import time

    import onnx
    import onnx2torch
    import torch

    # Thread settings MUST happen before using PyTorch
    torch.set_num_interop_threads(1)
    if n_threads > 0:
        torch.set_num_threads(n_threads)

    # Move inputs to CPU tensors
    device = torch.device("cpu")
    inputs = [torch.tensor(i, device=device) for i in inputs_list]

    # Reconstruct ONNX model
    model = onnx.load_from_string(model_bytes)

    # Convert to PyTorch
    model_torch = onnx2torch.convert(model)
    model_torch.to(device)
    model_torch.eval()

    timings = [0.0] * (nb_warmup + nb_iterations)
    with torch.no_grad():
        # Warm-up runs
        for i in range(nb_warmup + nb_iterations):
            start = time.perf_counter()
            model_torch(*inputs)
            end = time.perf_counter()
            timings[i] = end - start

    return_dict["timings"] = timings[nb_warmup:]


def _measure_inference_time(
    model_onnx: "ModelProto",
    inputs: list[NamedTensor],
    *,
    nb_warmup: int = 10,
    nb_iterations: int = 50,
    n_threads: int = -1,
) -> list[float]:
    """
    Run the provided PyTorch model.
    Performs 10 warm-up runs followed by 50 timed runs (using CPU process time).

    Args:
        model_onnx: The ONNX model.
        input_data: Dictionary mapping all input names to NumPy arrays.

    Returns:
        List of CPU times (in seconds) for the 50 timed runs.
    """

    # Spawn isolated process
    ctx = mp.get_context("spawn")
    return_dict = ctx.Manager().dict()
    p = ctx.Process(
        target=_worker,
        args=(
            model_onnx.SerializeToString(),
            [i.array for i in inputs],
            nb_warmup,
            nb_iterations,
            n_threads,
            return_dict,
        ),
    )
    p.start()
    p.join()

    if p.exitcode != 0:
        raise RuntimeError(f"Subprocess failed with exit code {p.exitcode}")

    return return_dict["timings"]


def _compute_output(
    model_onnx: "ModelProto", inputs: dict[NamedTensor]
) -> list[ndarray]:
    """
    Run the PyTorch model inference.

    Args:
        model: The PyTorch model.
        input_data: Dictionary mapping all input names to NumPy arrays.

    Returns:
        The first output tensor if there is only one, else a list of output tensors.
    """
    torch = load_package("torch")
    onnx2torch = load_package("onnx2torch")

    model_torch = onnx2torch.convert(model_onnx)

    device = torch.device("cpu")
    model_torch.to(device)
    model_torch.eval()

    inputs = [torch.tensor(i.array, device=device) for i in inputs]

    with torch.no_grad():
        # Warning: not tested for multiple outputs case
        output = model_torch(*inputs)

    return [o.numpy() for o in output]


register_backend_time("torch", _measure_inference_time)
register_backend_inference("torch", _compute_output)

register_backend_time("PyTorch (CPU)", _measure_inference_time)
register_backend_inference("PyTorch (CPU)", _compute_output)
