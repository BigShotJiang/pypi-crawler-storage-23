import argparse
import json
import os
import sys
from dataclasses import dataclass
from importlib import resources
from types import ModuleType

import numpy as np
import onnx

import aidge_core as ai
import aidge_benchmark as ab
import aidge_onnx
from aidge_benchmark.registrations.dynamic_lib_import import load_package
from aidge_benchmark.utils import compare_tensors
from aidge_benchmark.utils.json_template_generation import build_onnx_template_config

from .CLI_utils import logger

COLOR_ON = True
log = logger.Logger(COLOR_ON)


@dataclass
class UsedModules:
    name: str
    module: ModuleType

    def model_format(self) -> str:
        """
        Returns the format 'aidge' or 'onnx' associated with the module.
        """
        return "aidge" if "aidge" in self.name.lower() else "onnx"


################################################################################
### Helper functions


def format_time_stats(times: list[float]) -> str:
    """Return mean ± std formatted in ms (scientific notation)."""
    mean, std, median = np.mean(times), np.std(times), np.median(times)
    return f"{mean*1e3:.3e} ± {std*1e3:.3e} ms (median: {median*1e3:.3e})"


def ensure_dir(path: str) -> None:
    path = os.path.expandvars(path)
    if path and not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)


def show_available_config():
    config_dir = resources.files("aidge_benchmark.operations_config")
    config_files = [
        f for f in config_dir.iterdir() if f.is_file() and (f.suffix == ".json")
    ]
    nb_files = len(config_files)
    tree = logger.TreeStruct()
    print("◇ Available configuration files")
    for i, cf in enumerate(config_files):
        print(f"{tree.grow(False, i >= nb_files - 1)} {cf.name}")


def parse_generate_template_arg(arg: str) -> tuple[str, int, int]:
    """
    Parse a ``--generate-template`` argument.

    :param arg: String formatted as ``OperatorName:opset:rank`` (e.g. ``Add:13:1``).
    :returns: ``(operator_name, opset_version, initializer_rank)``.
    :rtype: tuple[str, int, int]
    :raises ValueError: If the input is not three ``:``-separated fields or if opset/rank
        are not valid integers.
    """
    try:
        operator_name, opset_version_str, initializer_rank_str = arg.split(":")
        return operator_name, int(opset_version_str), int(initializer_rank_str)
    except ValueError:
        raise ValueError(
            f"Invalid format for --generate-template. Use format: 'OperatorName:opset:rank', e.g., 'Add:13:1'"
        )


# def load_onnx_model(huggingface_url: str) -> onnx.ModelProto:
#     model_file_name = huggingface_url.split("/")[-1]
#     model_onnx: onnx.ModelProto = onnx.ModelProto()
#     if not os.path.exists(model_file_name):
#         model_onnx = onnx.load_from_string(
#             requests.get(huggingface_url, timeout=60).content
#         )
#         onnx.save_model(model_onnx, model_file_name)
#     else:
#         model_onnx = onnx.load_model(model_file_name)
#     onnx.checker.check_model(model_onnx)
#     return model_onnx


def compare_model(
    params: dict, module_names: list[str], ref_name: str, tree: logger.TreeStruct
) -> None:
    ref_outputs: list[np.ndarray] = ab.compute_output(
        ref_name,
        **params["aidge" if "aidge" in ref_name else "onnx"],
    )
    for m_id, m_name in enumerate(module_names):
        if m_name == ref_name:
            continue
        # if we remove the tree system for printing, this becomes way easier
        # here there is a special condition if the next module is both the reference and the last name of the list
        print(
            f"{tree.grow(
                branch=False,
                leaf= ((m_id >= len(module_names) - 1)
                       or ((module_names[m_id + 1] == ref_name)
                           and (m_id + 1 == len(module_names) - 1)))
                           )}"
            f"{m_name}",
            end="",
        )
        # TODO: change to be more flexible with model format
        # currently: use aidge model if "aidge" string is included in the module name, else use onnx model
        format = "aidge" if "aidge" in m_name else "onnx"
        mod_outputs: list[np.ndarray] = ab.compute_output(m_name, **params[format])
        is_equal = True
        for out_id in range(len(ref_outputs)):
            is_equal &= compare_tensors(
                ref_outputs[out_id],
                mod_outputs[out_id],
                rtol=1e-5,
                atol=1e-5,
                verbose=False,
            )
        comp_str = f" [ {log.to_color('OK', logger.Color.GREEN, bold=False) if is_equal else log.to_color('XX', logger.Color.RED, bold=True)} ]"
        print(f"{comp_str:.>{100 - len(tree.last()) - len(m_name) + 11*COLOR_ON}}")


def time_model(
    params: dict,
    module_names: list[str],
    ref_name: str,
    tree: logger.TreeStruct,
    nb_warmup: int = 10,
    nb_iterations: int = 50,
):
    results: dict[str, list[float]] = {}
    for m_id, m_name in enumerate(module_names):
        print(
            f"{tree.grow(branch=False, leaf= (m_id >= len(module_names) - 1))}{m_name}",
            end="",
        )
        # TODO: change to be more flexible with model format
        # currently: use aidge model if "aidge" string is included in the module name, else use onnx model
        format = "aidge" if "aidge" in m_name else "onnx"
        results[m_name] = ab.measure_inference_time(
            m_name, **params[format], nb_warmup=nb_warmup, nb_iterations=nb_iterations
        )
        timings_str = f" {format_time_stats(results[m_name])}"
        print(f"{timings_str:.>{100 - len(tree.last()) - len(m_name)}}")
    return results


def main():

    ############################################################################
    ###  Parse Arguments
    ############################################################################

    # Use a separate parser to avoid mandatory arguments of the main parser.
    pre_parser = argparse.ArgumentParser(add_help=False)
    # TODO: change for auto-displayed list when calling help
    pre_parser.add_argument(
        "--show-available-config",
        action="store_true",
        help="Show JSON configuration files stored in the benchmark package configuration directory.",
    )
    pre_parser.add_argument(
        "--generate-template",
        type=str,
        help="Create a well-structured draft that includes all the necessary inputs and attributes for the chosen ONNX operator, "
        "along with their default values (when available). Format: 'OperatorName:opset_version:initializer_rank'",
    )
    pre_parser.add_argument(
        "--save-directory",
        type=str,
        default=".",
        help="Directory used for saving any output from the script.",
    )

    known_args, _ = pre_parser.parse_known_args()

    if known_args.show_available_config:
        show_available_config()
        sys.exit(0)

    save_dir: str = os.path.expandvars(known_args.save_directory)
    ensure_dir(save_dir)

    if known_args.generate_template:
        operator_name, opset_version, initializer_rank = parse_generate_template_arg(
            known_args.generate_template
        )
        config = build_onnx_template_config(
            operator_name, opset_version, initializer_rank
        )
        filename = f"{operator_name}_opset{opset_version}_template.json"
        out_path = os.path.join(save_dir, filename)
        with open(out_path, "w") as f:
            json.dump(config, f, indent=4)
        print(f"template configuration saved as '{out_path}'.")
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description="Operator Kernel Performance Benchmarking across multiple inference modules.",
        parents=[pre_parser],
    )

    onnx_model_group = parser.add_mutually_exclusive_group(required=True)
    onnx_model_group.add_argument(
        "--config-file",
        "-cf",
        type=str,
        help="Path to a JSON configuration file containing an ONNX operator description with reference and tested parameter values. A new ONNX model will automatically be generated for each test case. Cannot be specified with '--onnx-file' option",
    )
    onnx_model_group.add_argument(
        "--onnx-file",
        "-of",
        type=str,
        help="Path to an existing ONNX file that will be used for benchmarking. Cannot be specified with '--config-file' option.",
    )
    parser.add_argument(
        "--modules",
        "-m",
        type=str,
        nargs="+",
        required=True,
        help="List of inference module names to benchmark (e.g., 'torch', 'onnxruntime').",
    )
    parser.add_argument(
        "--ref",
        type=str,
        default="onnxruntime",
        help="Reference module used for comparing results (default: 'onnxruntime').",
    )
    parser.add_argument(
        "--compare",
        "-c",
        action="store_true",
        help="Compare the inference outputs of each module against a reference implementation.",
    )
    parser.add_argument(
        "--time",
        "-t",
        action="store_true",
        help="Measure inference time for each module.",
    )
    parser.add_argument(
        "--nb-iterations",
        type=int,
        default=50,
        help="Number of iterations to run for the 'time' test (default: 50).",
    )
    parser.add_argument(
        "--nb-warmups",
        type=int,
        default=10,
        help="Number of warm-up steps to run for the 'time' test (default: 10).",
    )
    parser.add_argument(
        "--results-filename",
        type=str,
        required=False,
        default="",
        help="Name of the saved result file. If not provided, it will default to the '<operator_name>_<module_to_bench_list>.json'. If a file with that name and at that location already exists, it will be overridden with elements individually replaced only if new ones are computed",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help=(
            "Set the verbosity level of the console output. "
            "Use -v to increase verbosity, with the following levels in ascending order:\n"
            "  default: WARN - Only warnings and higher (WARN, ERROR, FATAL) are displayed.\n"
            "  -v: NOTICE - Notices and higher (NOTICE, WARN, ERROR, FATAL) are displayed.\n"
            "  -vv INFO - Informational messages and higher (INFO, NOTICE, WARN, ERROR, FATAL) are displayed.\n"
            "  -vvv: DEBUG - All messages, including debug information, are displayed.\n"
            "Available levels in descending order of severity:\n"
            "  DEBUG < INFO < NOTICE < WARN < ERROR < FATAL."
        ),
    )
    args = parser.parse_args()

    # Setting Aidge verbose level
    if args.verbose == 0:
        ai.Log.set_console_level(ai.Level.Fatal)
    elif args.verbose == 1:
        ai.Log.set_console_level(ai.Level.Notice)
    elif args.verbose == 2:
        ai.Log.set_console_level(ai.Level.Info)
    elif args.verbose >= 3:
        ai.Log.set_console_level(ai.Level.Debug)
    # Configure Tensor precision
    ai.Log.set_precision(10)

    ############################################################################
    ### Set/Create variables

    comparison_flag_on: bool = args.compare
    timing_flag_on: bool = args.time

    nb_warmups: int = args.nb_warmups
    nb_iterations: int = args.nb_iterations

    tree = logger.TreeStruct()  # structure information about the script execution

    model_aidge: ai.GraphView | None = None
    model_onnx: onnx.ModelProto = None

    # Load the inference modules + ref module if forgotten from 'modules' arg list
    ref_module: UsedModules | None = None
    modules: list[UsedModules] = []

    # Unused if (timing_flag_on == False)
    timings: dict = {}
    # Unused if (comparison_flag_on == False)
    comparisons: dict[str, bool] = {}

    ############################################################################
    ### Loading
    print("◇ Loading modules...")

    module_names = args.modules + (
        [args.ref] if comparison_flag_on and (args.ref not in args.modules) else []
    )
    for m_id, m_name in enumerate(module_names):
        ref_tag_string = (
            f"{' (reference)' if comparison_flag_on and (m_name == args.ref) else ''}"
        )
        print(
            f"{tree.grow(branch=False, leaf= (m_id >= len(module_names) - 1))}{m_name}{ref_tag_string}",
            end="",
        )
        try:
            modules.append(UsedModules(m_name, load_package(m_name)))
        except:
            load_str = f" [ {log.to_color('XX', logger.Color.RED, bold=True)} ]"
            print(
                f"{load_str:.>{100 - len(tree.last()) - len(m_name) - len(ref_tag_string) + 11*COLOR_ON}}"
            )
            sys.exit(1)
        load_str = f" [ {log.to_color('OK', logger.Color.GREEN)} ]"
        print(
            f"{load_str:.>{100 - len(tree.last()) - len(m_name) -len(ref_tag_string) + 11*COLOR_ON}}"
        )
        if m_name == args.ref:
            ref_module = modules[-1]
        tree.reset()

    ############################################################################
    ### Running tests
    if args.onnx_file:
        # load the model
        print(f"◇ Loading the model...")
        print(
            f"{tree.grow(branch=False, leaf= True)}{args.onnx_file}",
            end="",
        )
        try:
            model_onnx = model_onnx = onnx.load_model(
                args.onnx_file
            )  # for Torch, ORT, Qualcomm, ...
            model_aidge = aidge_onnx.convert_onnx_to_aidge(
                model_onnx
            )  # for Aidge modules
        except:
            load_str = f" [ {log.to_color('XX', logger.Color.RED, bold=True)} ]"
            print(
                f"{load_str:.>{100 - len(tree.last()) - len(args.onnx_file) + 11*COLOR_ON}}"
            )
            sys.exit(1)
        load_str = f" [ {log.to_color('OK', logger.Color.GREEN)} ]"
        print(
            f"{load_str:.>{100 - len(tree.last()) - len(args.onnx_file) + 11*COLOR_ON}}"
        )

        tree.reset()

        # Create inputs
        inputs: list[ab.NamedTensor] = []
        for i in model_onnx.graph.input:
            shape = i.type.tensor_type.shape
            shape_array: list[int] = [dim.dim_value for dim in shape.dim]
            inputs.append(
                ab.NamedTensor(i.name, np.random.rand(*shape_array).astype(np.float32))
            )

        # Associate parameters
        backend_params = {
            "aidge": {"model": model_aidge, "inputs": inputs},
            "onnx": {"model": model_onnx, "inputs": inputs},
        }

        # Run tests
        if comparison_flag_on:
            print(f"◇ Comparison with reference")
            compare_model(
                backend_params, [m.name for m in modules], ref_module.name, tree
            )
            tree.reset()
        if timing_flag_on:
            print(f"◇ Compute inference time")
            timings["model"] = time_model(
                backend_params,
                [m.name for m in modules],
                "",
                tree,
                nb_warmups,
                nb_iterations,
            )
            tree.reset()

    if args.config_file:
        # load test configs
        scheme, default_cfg = ab.create_benchmark_from_json(args.config_file)
        scheme = ab.BenchmarkScheme(scheme._tree.filter_out(["error"]))

        for label, cfg in scheme:
            # for  label, cfg in bench.BenchmarkScheme(scheme._tree.to_subtree('kernel_shape')):
            print(f"\n- {label}")

            # Merge test config with default settings
            full_cfg = default_cfg.override_with(cfg)

            inputs = full_cfg.generate_inputs()

            # Build ONNX and Aidge model description from 'cfg' described with ONNX format
            if full_cfg.format.name.lower() == "aidge":
                model_aidge = full_cfg.as_model(input_arrays=inputs)
                model_onnx = aidge_onnx.convert_aidge_to_onnx(
                    model_aidge,
                    f"test-model_{full_cfg.operation}_{label}",
                    opset=21,  # opset may be changed
                    ir_version=10,
                )
            else:  # onnx
                model_onnx = full_cfg.as_model(input_arrays=inputs)
                model_aidge = aidge_onnx.convert_onnx_to_aidge(model_onnx)
            # update input names for ONNX
            for idx, named_tensor in enumerate(inputs):
                if idx < len(model_onnx.graph.input):
                    for node in model_onnx.graph.node:
                        for i, inp in enumerate(node.input):
                            if inp == model_onnx.graph.input[idx].name:
                                node.input[i] = named_tensor.name
                    model_onnx.graph.input[idx].name = named_tensor.name

            # /!\ specific to ONNX format
            # Determine how many inputs are actual data (excluding initializers)
            nb_data_inputs = full_cfg.format.metadata["initializer_rank"]
            inputs = inputs[:nb_data_inputs]

            # Associate parameters
            backend_params = {
                "aidge": {"model": model_aidge, "inputs": inputs},
                "onnx": {"model": model_onnx, "inputs": inputs},
            }
            if comparison_flag_on:
                print(f"◇ Comparison with reference")
                compare_model(
                    backend_params, [m.name for m in modules], ref_module.name, tree
                )
                tree.reset()

            if timing_flag_on:
                print(f"◇ Compute inference time")
                timings[label] = time_model(
                    backend_params,
                    [m.name for m in modules],
                    ref_module.name,
                    tree,
                    nb_warmups,
                    nb_iterations,
                )
                tree.reset()

    # Save results
    tree.reset()
    print("◇ Saving results to JSON files...")
    filename: str = ""
    if args.results_filename:
        filename = args.results_filename
    else:
        filename = (
            args.onnx_file
            if args.onnx_file
            else args.config_file.split("/")[-1].split(".")[0]
        )
        for m in modules:
            filename += "_" + m.name
    filename += ".json"
    filepath = os.path.join(save_dir, filename)
    print(
        f"{tree.grow(branch=False, leaf= True)}{filepath}",
        end="",
    )

    try:
        with open(filepath, "w") as outfile:
            json.dump(timings, outfile, indent=4)
    except:
        load_str = f" [ {log.to_color('XX', logger.Color.RED, bold=True)} ]"
        print(f"{load_str:.>{100 - len(tree.last()) - len(filepath) + 11*COLOR_ON}}")
        exit(1)
    load_str = f" [ {log.to_color('OK', logger.Color.GREEN)} ]"
    print(f"{load_str:.>{100 - len(tree.last()) - len(filepath) + 11*COLOR_ON}}")


if __name__ == "__main__":
    main()
