from enum import Enum

COLOR_ON = True


class Color(Enum):
    RED = "31"
    GREEN = "32"
    YELLOW = "33"
    BLUE = "34"
    MAGENTA = "35"
    CYAN = "36"
    WHITE = "37"


class Logger:
    def __init__(self, color_on: bool = True):
        self.color_on = color_on

    def to_color(self, msg: str, color: Color, bold: bool = False) -> str:
        if self.color_on:
            return f"\033[{int(bold)};{color.value}m{msg}\033[0m"
        else:
            return msg


class TreeStruct:
    """
    TreeStruct enables structured, tree-like rendering of nested operations
    using Unicode line-drawing characters (e.g. ├─, └─, │) for visual clarity.

    It is especially useful for displaying progress or hierarchical steps
    in command-line tools, such as loading modules or benchmarking results.

    Example output:

        Loading modules...
        ├──torch [ ok ]
        ├──aidge_backend_cpu [ ok ]
        └──onnxruntime [ ok ]

        Benchmarking...
        ├─┬─torch
        │ ├──time [ 5.70e-04 ± 1.45e-04 ] (seconds)
        │ └──comp [ xx ]
        ├─┬─aidge_backend_cpu
        │ ├──time [ 5.70e-04 ± 1.45e-04 ] (seconds)
        │ └──comp [ xx ]
        └─┬─onnxruntime
          ├──time [ 5.70e-04 ± 1.45e-04 ] (seconds)
          └──comp [ xx ]

    Usage:
        tree = TreeStruct()
        print(tree.grow(branch=True, leaf=False) + "torch")
        print(tree.grow(branch=False, leaf=True) + "comp [ ok ]")
        tree.reset()
    """

    def __init__(self):
        self.branch = " "
        self.last_branch = ""

    def _stack_to_str() -> str:
        str_conversion_table = " │├┬└─"

    def grow(self, branch: bool, leaf: bool) -> str:
        """
        Advances the tree depth and returns the prefix string for the current line,
        automatically adjusting indentation and connection characters.

        Args:
            branch (bool): Whether the current node will have children.
            leaf (bool): Whether this is the last item at the current depth.
        """
        self.branch += "└" if leaf else "├"
        self.branch += "─"
        self.branch += "┬" if branch else "─"
        self.last_branch = self.branch + "─"
        self._truncate(branch, leaf)

        return self.last_branch

    def __str__(self):
        return self.last_branch

    def _truncate(self, branch: bool, leaf: bool):
        if len(self.branch):
            # truncate
            self.branch = self.branch[:-3]
            # add
            if branch:
                self.branch += "  " if leaf else "│ "
            # remove
            elif leaf and len(self.branch):
                index = len(self.branch) - 1
                while index > 0 and self.branch[index] != "│":
                    index -= 1
                self.branch = self.branch[:index]

    def last(self) -> str:
        return self.last_branch

    def next(self) -> str:
        return self.branch

    def reset(self):
        """Resets the internal state, allowing reuse for a new tree."""
        self.branch = " "
        self.last_branch = ""
