"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import numpy as np


def compare_tensors(
    actual_tensors: list[np.ndarray],
    expected_tensors: list[np.ndarray],
    rtol=1e-3,
    atol=1e-5,
    verbose: bool = False,
) -> bool:
    """
    Compares two tensors element-wise using relative and absolute tolerance.

    Args:
        acactual_tensorstual (list[np.ndarray]): The computed or observed tensor values.
        expected_tensors (list[np.ndarray]): The reference or expected tensor values.
        rtol (float): Relative tolerance. Defaults to 1e-3.
        atol (float): Absolute tolerance. Defaults to 1e-5.
        verbose (bool): If True, prints detailed mismatch information, including indices and error values.

    Returns:
        bool: True if all elements are equal within the specified tolerances, False otherwise.
    """
    if len(actual_tensors) != len(expected_tensors):
        raise ValueError(
            f"Number of tensors mismatch: actual has {len(actual_tensors)} tensor(s), expected {len(expected_tensors)} tensor(s)"
        )

    is_all_equal = True
    for t, (actual, expected) in enumerate(zip(actual_tensors, expected_tensors)):
        if actual.shape != expected.shape:
            raise ValueError(
                f"Tensor #{t} shape mismatch: actual {actual.shape}, expected {expected.shape}"
            )

        equality: np.ndarray = np.isclose(actual, expected, rtol=rtol, atol=atol)
        is_equal = bool(np.all(equality))
        if not is_equal:
            is_all_equal = False
        if verbose:
            print(f"Equal: {is_equal}")
            if not is_equal:
                mismatches = ~equality
                n_mismatches = np.count_nonzero(mismatches)
                print(f"Mismatch:\t{n_mismatches}/{equality.size}")
                print(
                    "Average diff: "
                    f"rtol = {np.sum(np.abs(np.subtract(actual, expected)/expected))/equality.size}, "
                    f"atol = {np.sum(np.abs(np.subtract(actual, expected)))/equality.size}"
                )

                mismatch_indices = np.argwhere(mismatches)
                for idx in mismatch_indices[:10]:
                    actual_val = actual[tuple(idx)]
                    expected_val = expected[tuple(idx)]
                    print(
                        f"  at index {idx}: "
                        f"\t| actual={actual_val:.3E}, "
                        f"\t| expected={expected_val:.3E}, "
                        f"\t| adiff={np.abs(actual_val - expected_val):.5E}"
                        f"\t| rdiff={np.abs((actual_val - expected_val)/expected_val):.5E}"
                    )
    return is_all_equal
