# [0.2.0](https://github.com/ervan0707/thira/compare/v0.1.0...v0.2.0) (2025-08-16)


### Features

* add Ctrl+C cancellation support for script execution ([cb8bf7f](https://github.com/ervan0707/thira/commit/cb8bf7ff8bd60deb861718452157f2335118360f))

# [0.1.0](https://github.com/ervan0707/thira/compare/v0.0.1...v0.1.0) (2025-08-13)


### Features

* **cli:** add interactive setup wizard for project templates ([cb90472](https://github.com/ervan0707/thira/commit/cb90472201b72ace1e01ab10b2c05693b9d6e832))
* **config:** standardize script defaults to sequential execution ([2d7701d](https://github.com/ervan0707/thira/commit/2d7701d67a84e5b4b7148f8b5c9ae0d4ab13874c))

## [0.0.1](https://github.com/ervan0707/thira/compare/v0.0.0...v0.0.1) (2025-06-25)


### Bug Fixes

* rename athira npm package to thira ([8ec3795](https://github.com/ervan0707/thira/commit/8ec379524a72b0645f914a8fcd8373f582a8b5e2))
