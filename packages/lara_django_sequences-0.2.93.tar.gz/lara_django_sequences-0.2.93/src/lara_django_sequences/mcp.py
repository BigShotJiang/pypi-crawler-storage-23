"""
LARAsuite lara_django_sequences Model Context Protocol (MCP) handler.

:PROJECT: LARAsuite

*lara_django_sequences Model Context Protocol (MCP) handler *

:details: lara_django_sequences Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import (
    BlockchainHashes,
    ExtraData,
    OrderedSequencesSubset,
    Sequence,
    SequenceClass,
    SequencesSubset,
)


class BlockchainHashesQueryTool(ModelQueryToolset):
    """MCP query tool for BlockchainHashes model."""

    model = BlockchainHashes


class ExtraDataQueryTool(ModelQueryToolset):
    """MCP query tool for ExtraData model."""

    model = ExtraData


class SequenceClassQueryTool(ModelQueryToolset):
    """MCP query tool for SequenceClass model."""

    model = SequenceClass


class SequenceQueryTool(ModelQueryToolset):
    """MCP query tool for Sequence model."""

    model = Sequence


class SequencesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool for SequencesSubset model."""

    model = SequencesSubset


class OrderedSequencesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool for OrderedSequencesSubset model."""

    model = OrderedSequencesSubset
