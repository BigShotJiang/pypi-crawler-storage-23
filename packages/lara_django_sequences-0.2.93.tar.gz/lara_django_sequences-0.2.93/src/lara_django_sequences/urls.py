"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_sequences urls *

:details: lara_django_sequences urls module.
         - add app specific urls here
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.urls import path
from django_socio_grpc.settings import grpc_settings

from . import views

# Add your {cookiecutter.project_slug}} urls here.


# !! this sets the apps namespace to be used in the template
app_name = "lara_django_sequences"

# companies and institutions should also be added
# the 'name' attribute is used in templates to address the url independent of the view


urlpatterns = [
    path("sequence/list/", views.SequenceSingleTableView.as_view(), name="sequence-list"),
    path("sequence/create/", views.SequenceCreateView.as_view(), name="sequence-create"),
    path("sequence/update/<uuid:pk>", views.SequenceUpdateView.as_view(), name="sequence-update"),
    path("sequence/delete/<uuid:pk>", views.SequenceDeleteView.as_view(), name="sequence-delete"),
    path("sequence/<uuid:pk>/", views.SequenceDetailView.as_view(), name="sequence-detail"),
    path("", views.SequenceSingleTableView.as_view(), name="sequence-root"),
    #     path('', views.EntitySingleTableView.as_view(), name='entity-list-root'),
    #     path('entities/list/', views.EntitySingleTableView.as_view(), name='entity-list'),
    #     path('addresses/list/', views.AddressesListView.as_view(), name='address-list'),
    #     path('addresses/create/', views.AddressCreateView.as_view(),
    #          name='address-create'),
    #     path('addresses/update/<uuid:pk>', views.AddressUpdateView.as_view(),
    #          name='address-update'),
    #     path('addresses/delete/<uuid:pk>', views.AddressDeleteView.as_view(),
    #          name='address-delete'),
]

# register handlers in settings
grpc_settings.user_settings["GRPC_HANDLERS"] += ["lara_django_sequences.grpc.handlers.grpc_handlers"]
