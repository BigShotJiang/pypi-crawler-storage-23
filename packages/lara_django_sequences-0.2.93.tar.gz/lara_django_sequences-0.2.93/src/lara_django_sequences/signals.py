import logging

from django.contrib.postgres.search import SearchVector
from django.db.models.signals import post_save
from django.dispatch import receiver
from lara_django_base.decorators import postgres_only

from .models import ExtraData

logger = logging.getLogger(__name__)


@receiver(post_save, sender=ExtraData)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    """
    Update the search vector for ExtraData instances after saving.

    This function is triggered by the post_save signal and updates the
    search_vector field of the ExtraData instance with a combination of
    SearchVector fields, each assigned a weight.
    """
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("description", weight="C")
        )
    )


# @receiver(post_save, sender=Sequence)
# @postgres_only
# def update_search_vector(sender, instance, **kwargs):
#     sender.objects.filter(pk=instance.pk).update(
#         search_vector=(
#             SearchVector('name', weight='A') +
#             SearchVector('name_full', weight='B')
#         )
#     )

# @receiver(post_save, sender=Sequence)
# def semantics_data_handler(sender, instance, created, **kwargs):
#     """Semantic data post_save signal handler.

#        This function is triggered after an instance of the Evaluation model is saved.
#        It calls the insert_semantics function to handle the semantic data insertion
#        into the triplestore, running asynchronously as celery task.
#     """
#     logger.debug("post_save_handler1: %s, %s ", sender, instance)

#     insert_semantic_data(sender, instance, **kwargs)
