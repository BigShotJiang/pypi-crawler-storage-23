"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django_filters.rest_framework import FilterSet

from .models import ExtraData, Sequence, SequenceClass, SequencesSubset


class ExtraDataFilterSet(FilterSet):
    """FilterSet for ExtraData model."""

    class Meta:  # noqa: D106
        model = ExtraData
        fields = {  # noqa: RUF012
            "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class SequenceClassFilterSet(FilterSet):
    """FilterSet for SequenceClass model."""

    class Meta:  # noqa: D106
        model = SequenceClass
        fields = {  # noqa: RUF012
            "name": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class SequenceFilterSet(FilterSet):
    """FilterSet for Sequence model."""

    class Meta:  # noqa: D106
        model = Sequence
        fields = {  # noqa: RUF012
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "version": ["exact", "contains"],
            # "sequence": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class SequencesSubsetFilterSet(FilterSet):
    """FilterSet for SequencesSubset model."""

    class Meta:  # noqa: D106
        model = SequencesSubset
        fields = {  # noqa: RUF012
            "name": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }
