"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_sequences views *

:details: lara_django_sequences views module.
         - add app specific urls here

:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from django.views.generic import CreateView, DeleteView, DetailView, UpdateView
from django_tables2 import SingleTableView

from .forms import SequenceCreateForm, SequenceUpdateForm
from .models import Sequence
from .tables import SequenceTable

# Create your lara_django_sequences views here.


@dataclass
class SequencesMenu:
    """Navigation menu for sequence-related views."""

    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Sequences", "path": "lara_django_sequences:sequence-list"},
        ]
    )


class SequenceSingleTableView(SingleTableView):
    """View for displaying a list of sequences in a table."""

    model = Sequence
    table_class = SequenceTable

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode',
    # 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual',
    # 'service_manual', 'icon', 'image', 'description', 'sequence_id', 'sequence_class', 'shape')

    template_name = "lara_django_sequences/list.html"
    success_url = "/sequences/sequence/list"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        """Get context data for the template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Sequence - List"
        context["create_link"] = "lara_django_sequences:sequence-create"
        context["menu_items"] = SequencesMenu().menu_items
        return context


class SequenceDetailView(DetailView):
    """View for displaying detailed information about a sequence."""

    model = Sequence

    template_name = "lara_django_sequences/sequence_detail.html"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        """Get context data for the template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Sequence - Details"
        context["update_link"] = "lara_django_sequences:sequence-update"
        context["menu_items"] = SequencesMenu().menu_items
        return context


class SequenceCreateView(CreateView):
    """View for creating a new sequence."""

    model = Sequence

    template_name = "lara_django_sequences/create_form.html"
    form_class = SequenceCreateForm
    success_url = "/sequences/sequence/list"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        """Get context data for the template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Sequence - Create"
        return context


class SequenceUpdateView(UpdateView):
    """View for updating an existing sequence."""

    model = Sequence

    template_name = "lara_django_sequences/update_form.html"
    form_class = SequenceUpdateForm
    success_url = "/sequences/sequence/list"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        """Get context data for the template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Sequence - Update"
        context["delete_link"] = "lara_django_sequences:sequence-delete"
        return context


class SequenceDeleteView(DeleteView):
    """View for deleting a sequence."""

    model = Sequence

    template_name = "lara_django_sequences/delete_form.html"
    success_url = "/sequences/sequence/list"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        """Get context data for the template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Sequence - Delete"
        context["delete_link"] = "lara_django_sequences:sequence-delete"
        return context
