"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_sequences gRPC services*

:details: lara_django_sequences gRPC services.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_sequences  (LARA-version)

from django_socio_grpc import generics, mixins
from lara_django_base.grpc.mixins import AsyncDownloadModelMixin, AsyncRetrieveByNameModelMixin, AsyncUploadModelMixin
from lara_django_sequences_grpc.v1 import lara_django_sequences_pb2

from lara_django_sequences.models import ExtraData, Sequence, SequenceClass, SequencesSubset

from ..filters import ExtraDataFilterSet, SequenceClassFilterSet, SequenceFilterSet, SequencesSubsetFilterSet
from .serializers import (
    ExtraDataProtoSerializer,
    SequenceClassProtoSerializer,
    SequenceFullProtoSerializer,
    SequenceProtoSerializer,
    SequencesSubsetProtoSerializer,
)


class ExtraDataService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    """Service for handling ExtraData model operations."""

    pb2 = lara_django_sequences_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    filterset_class = ExtraDataFilterSet


class SequenceClassService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    """Service for handling SequenceClass model operations."""

    queryset = SequenceClass.objects.all()
    serializer_class = SequenceClassProtoSerializer
    filterset_class = SequenceClassFilterSet


class SequenceService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    """Service for handling Sequence model operations."""

    pb2 = lara_django_sequences_pb2
    queryset = Sequence.objects.all()
    serializer_class = SequenceProtoSerializer
    filterset_class = SequenceFilterSet
    lookup_field = "sequence_id"


# class SequenceByNameService(generics.GenericService, mixins.AsyncListModelMixin, mixins.AsyncRetrieveModelMixin):
#     queryset = Sequence.objects.all()
#     serializer_class = SequenceByNameProtoSerializer
#     filterset_class = SequenceFilterSet
#     lookup_field = "name"


class SequenceFullService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    """Service for handling full Sequence model operations."""

    pb2 = lara_django_sequences_pb2
    queryset = Sequence.objects.all()
    serializer_class = SequenceFullProtoSerializer
    filterset_class = SequenceFilterSet
    search_fields = (
        "name",
        "description",
    )


class SequencesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    """Service for handling SequencesSubset model operations."""

    queryset = SequencesSubset.objects.all()
    serializer_class = SequencesSubsetProtoSerializer
    filterset_class = SequencesSubsetFilterSet
    search_fields = (
        "name",
        "description",
    )
