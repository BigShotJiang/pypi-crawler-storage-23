"""
LARAsuite lara_django_myproj gRPC serializer.

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_sequences  (LARA-version)

from django_socio_grpc import proto_serializers
from lara_django_base.grpc.serializers import (
    ItemStatusProtoSerializer,
    MediaTypeProtoSerializer,
    NamespaceProtoSerializer,
)
from lara_django_base.models import DataType, ItemStatus, MediaType, Namespace, Tag
from lara_django_people.models import Entity, Group
from lara_django_sequences_grpc.v1 import lara_django_sequences_pb2
from rest_framework.serializers import PrimaryKeyRelatedField, UUIDField

from lara_django_sequences.models import ExtraData, Sequence, SequenceClass, SequencesSubset


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    """Proto serializer for ExtraData model."""

    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        """Meta configuration for ExtraDataProtoSerializer."""

        model = ExtraData
        proto_class = lara_django_sequences_pb2.ExtraDataResponse

        proto_class_list = lara_django_sequences_pb2.ExtraDataListResponse

        # [data_type', namespace', URI', text', XML', JSON', bin', media_type',
        # IRI', URL', description', image', file']
        fields = "__all__"


class SequenceClassProtoSerializer(proto_serializers.ModelProtoSerializer):
    """Proto serializer for SequenceClass model."""

    class Meta:
        """Meta configuration for SequenceClassProtoSerializer."""

        model = SequenceClass
        proto_class = lara_django_sequences_pb2.SequenceClassResponse

        proto_class_list = lara_django_sequences_pb2.SequenceClassListResponse

        fields = "__all__"  # [name', description']


class SequenceProtoSerializer(proto_serializers.ModelProtoSerializer):
    """Proto serializer for Sequence model."""

    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    sequence_class = PrimaryKeyRelatedField(
        queryset=SequenceClass.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        """Meta configuration for SequenceProtoSerializer."""

        model = Sequence
        proto_class = lara_django_sequences_pb2.SequenceResponse

        proto_class_list = lara_django_sequences_pb2.SequenceListResponse

        # [namespace', name', name_full', UUID', hash_sha256', sequence_class',
        # sequence', media_type', sequence_file', status', description', URI', IRI']
        fields = "__all__"


class SequenceByNameProtoSerializer(proto_serializers.ModelProtoSerializer):
    """Proto serializer for Sequence model by name."""

    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    sequence_class = PrimaryKeyRelatedField(
        queryset=SequenceClass.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        """Meta configuration for SequenceByNameProtoSerializer."""

        model = Sequence
        proto_class = lara_django_sequences_pb2.SequenceResponse

        proto_class_list = lara_django_sequences_pb2.SequenceListResponse

        # [namespace', name', name_full', UUID', hash_sha256', sequence_class',
        # sequence', media_type', sequence_file', status', description', URI', IRI']
        fields = "__all__"


class SequencesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    """Proto serializer for SequencesSubset model."""

    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    sequences = PrimaryKeyRelatedField(
        queryset=Sequence.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        """Meta configuration for SequencesSubsetProtoSerializer."""

        model = SequencesSubset
        proto_class = lara_django_sequences_pb2.SequencesSubsetResponse

        proto_class_list = lara_django_sequences_pb2.SequencesSubsetListResponse

        fields = "__all__"


class SequenceFullProtoSerializer(proto_serializers.ModelProtoSerializer):
    """Proto serializer for full Sequence model with nested serializers."""

    namespace = NamespaceProtoSerializer(read_only=True)
    sequence_class = SequenceClassProtoSerializer(read_only=True)
    media_type = MediaTypeProtoSerializer(read_only=True)
    status = ItemStatusProtoSerializer(read_only=True)

    class Meta:
        """Meta configuration for SequenceFullProtoSerializer."""

        model = Sequence
        proto_class = lara_django_sequences_pb2.SequenceFullResponse

        proto_class_list = lara_django_sequences_pb2.SequenceFullListResponse

        # [namespace', name', name_full', UUID', hash_sha256', sequence_class',
        # sequence', media_type', sequence_file', status', description', URI', IRI']
        fields = "__all__"
