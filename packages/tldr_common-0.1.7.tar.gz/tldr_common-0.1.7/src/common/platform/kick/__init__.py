"""
Kick API integration module.

This module provides classes and functions for interacting with the Kick API.
"""

from .api import KickApi, KickApiConfig
from . import model as _model
from . import webhook as _webhook

__all__ = ["KickApi", "KickApiConfig", *_model.__all__, *_webhook.__all__]

globals().update({name: getattr(_model, name) for name in _model.__all__})
globals().update({name: getattr(_webhook, name) for name in _webhook.__all__})
