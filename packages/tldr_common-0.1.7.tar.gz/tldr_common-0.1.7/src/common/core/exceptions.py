"""Common exceptions for the TL;DR.tv platform."""


class CommonError(Exception):
    """Base exception for all common module errors."""

    pass


class DatabaseError(CommonError):
    """Raised when database operations fail."""

    pass


class PlatformError(CommonError):
    """Base exception for platform-specific errors."""

    pass


class TwitchError(PlatformError):
    """Raised when Twitch API operations fail."""

    pass


class KickError(PlatformError):
    """Raised when Kick API operations fail."""

    pass


class ValidationError(CommonError):
    """Raised when data validation fails."""

    pass


class AuthenticationError(CommonError):
    """Raised when authentication fails."""

    pass


class RateLimitError(PlatformError):
    """Raised when API rate limits are exceeded."""

    pass


class WebhookError(PlatformError):
    """Raised when webhook operations fail."""

    pass


class MessageQueueError(CommonError):
    """Raised when message queue operations fail."""

    pass
