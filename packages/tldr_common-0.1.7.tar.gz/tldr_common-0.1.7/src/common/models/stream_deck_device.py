from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class StreamDeckDevice(BaseModel):
    id: int
    user_id: int
    device_id: str
    created_at: datetime
    deleted_at: Optional[datetime] = None
