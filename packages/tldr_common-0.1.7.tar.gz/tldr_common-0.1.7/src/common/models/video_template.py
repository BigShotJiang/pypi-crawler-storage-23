"""Pydantic models for video templates."""

from datetime import datetime
from enum import Enum
from typing import Any, List, Optional

from pydantic import BaseModel, Field, ConfigDict


class TierLevel(str, Enum):
    """User tier levels for access control."""

    BASIC = "basic"
    PRO = "pro"
    ENTERPRISE = "enterprise"


class ModifiableFieldType(str, Enum):
    """Types of modifiable fields in templates."""

    TEXT = "text"
    VIDEO = "video"
    IMAGE = "image"
    COLOR = "color"
    FONT = "font"
    NUMBER = "number"
    BOOLEAN = "boolean"


class ModifiableField(BaseModel):
    """Definition of a customizable field in a template."""

    name: str = Field(..., description="Creatomate path (e.g., 'Title.text')")
    label: str = Field(..., description="Human-readable label")
    type: ModifiableFieldType = Field(..., description="Field data type")
    default: Optional[Any] = Field(default=None, description="Default value")
    required: bool = Field(default=False, description="Whether field is required")

    # Type-specific constraints
    max_length: Optional[int] = Field(
        default=None, description="Max length for text fields"
    )
    min_value: Optional[float] = Field(
        default=None, description="Min value for number fields"
    )
    max_value: Optional[float] = Field(
        default=None, description="Max value for number fields"
    )
    allowed_values: Optional[List[str]] = Field(
        default=None, description="Enumerated options"
    )


class VideoTemplateBase(BaseModel):
    """Base fields for video template."""

    creatomate_template_id: str = Field(..., description="Creatomate template ID")
    name: str = Field(..., max_length=255, description="Template name")
    description: Optional[str] = Field(default=None, description="Template description")
    thumbnail_url: Optional[str] = Field(
        default=None, description="Preview thumbnail URL"
    )

    is_global: bool = Field(default=False, description="System-wide template flag")
    tier_required: TierLevel = Field(
        default=TierLevel.BASIC, description="Minimum tier required"
    )
    category: Optional[str] = Field(
        default=None, max_length=100, description="Template category"
    )

    output_width: int = Field(default=1080, gt=0, description="Output width in pixels")
    output_height: int = Field(
        default=1920, gt=0, description="Output height in pixels"
    )
    output_format: str = Field(
        default="mp4", description="Output format (mp4, gif, jpg, png)"
    )

    modifiable_fields: List[ModifiableField] = Field(
        default_factory=list, description="List of customizable fields"
    )


class VideoTemplateCreate(VideoTemplateBase):
    """Data required to create a new video template."""

    user_id: Optional[int] = Field(
        default=None, description="Owner user ID (null for global)"
    )


class VideoTemplateUpdate(BaseModel):
    """Data for updating a video template."""

    name: Optional[str] = Field(default=None, max_length=255)
    description: Optional[str] = None
    thumbnail_url: Optional[str] = None
    tier_required: Optional[TierLevel] = None
    category: Optional[str] = Field(default=None, max_length=100)
    output_width: Optional[int] = Field(default=None, gt=0)
    output_height: Optional[int] = Field(default=None, gt=0)
    output_format: Optional[str] = None
    modifiable_fields: Optional[List[ModifiableField]] = None


class VideoTemplate(VideoTemplateBase):
    """Complete video template model from database."""

    id: int
    user_id: Optional[int] = None
    use_count: int = 0
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class UserTemplatePreferencesBase(BaseModel):
    """Base fields for user template preferences."""

    default_clip_template_id: Optional[int] = Field(
        default=None, description="Default for clips"
    )
    default_highlight_template_id: Optional[int] = Field(
        default=None, description="Default for highlights"
    )
    default_story_template_id: Optional[int] = Field(
        default=None, description="Default for stories"
    )


class UserTemplatePreferencesCreate(UserTemplatePreferencesBase):
    """Data for creating user template preferences."""

    user_id: int


class UserTemplatePreferencesUpdate(UserTemplatePreferencesBase):
    """Data for updating user template preferences."""

    pass


class UserTemplatePreferences(UserTemplatePreferencesBase):
    """Complete user template preferences from database."""

    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
