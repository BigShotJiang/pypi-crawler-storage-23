"""Core shared common package for TL;DR.tv services."""


def package_name() -> str:
    """Return a stable package identifier for diagnostics."""
    return "common"


def distribution_name() -> str:
    """Return the published distribution name for shared package metadata."""
    return "tldr-common"


def validation_marker() -> str:
    """Return a static marker used for CI release-flow validation changes."""
    return "common-drone-e2e-validation"
