"""Gatana LangChain - A toolkit for building LangChain applications."""

from importlib.metadata import version

__version__: str = version("gatana-langchain")

__all__ = ["__version__"]
