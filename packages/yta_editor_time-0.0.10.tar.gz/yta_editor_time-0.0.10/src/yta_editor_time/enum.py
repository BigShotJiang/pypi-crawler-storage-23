from yta_constants.enum import YTAEnum as Enum


# TODO: By now we are not implementing the 'anchor'
# because it complicates the logic a lot...
# class Anchor(Enum):
#     """
#     The part of the element the settings are anchored
#     to and must be considered when calculating
#     according to the context given.
#     """

#     START = 'start'
#     """
#     Anchored to the `start` of the element and depending
#     on it.
#     """
#     END = 'end'
#     """
#     Anchored to the `end` of the element and depending on
#     it.
#     """

# TODO: Move inside 'specifications'
class SpecificationRequirement(Enum):
    """
    Enum class to define the requirements a
    specification has.
    """

    FPS = 'fps'
    TOTAL_FRAMES = 'total_frames'
    DURATION = 'duration'
