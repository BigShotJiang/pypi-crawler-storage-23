from yta_editor_time.specifications.types import FrameIndex
from dataclasses import dataclass


@dataclass(frozen = True)
class FrameIndexSpecificationResolved:
    """
    A frame index specification that has been
    resolved according to a specific evaluation
    context.

    This resolved specification will indicate the
    frames range in which the transformations
    should be applied, from the `start_frame` to
    the `end_frame`.
    """

    start_frame: FrameIndex
    """
    The frame in which the modifications should
    start being applied.
    """
    end_frame: FrameIndex  # exclusive
    """
    The frame in which the modifications should
    stop being applied, including it not.
    """
