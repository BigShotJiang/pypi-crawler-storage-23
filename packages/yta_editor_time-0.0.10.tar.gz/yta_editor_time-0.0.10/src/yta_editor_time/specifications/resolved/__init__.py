from yta_editor_time.specifications.resolved.frame import FrameIndexSpecificationResolved


__all__ = [
    'FrameIndexSpecificationResolved'
]


"""
A full flow resolving:

# Datos del clip
fps = Fraction(60)
total_frames = FrameCount(150)

# Contexto actual (frame 50)
context = EvaluationContext(
    fps=fps,
    total_frames=total_frames,
    frame_index=FrameIndex(50)
)

# “Aplica del frame 40 al 80”
spec = FrameIndexSpecification(
    start=FrameIndex(40),
    end=FrameIndex(80),
    length=None
)

# Resolución (una sola vez)
resolved = resolve_frame_index_spec(spec, total_frames)

# Evaluación por frame
active = is_active(context, resolved)

print(active)  # True
"""