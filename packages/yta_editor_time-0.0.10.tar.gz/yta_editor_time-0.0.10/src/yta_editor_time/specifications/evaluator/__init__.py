from yta_editor_time.specifications.types import FrameIndex
from yta_editor_time.specifications.resolved import FrameIndexSpecificationResolved


class SpecificationEvaluator:
    """
    Class to simplify the way we evaluate if a
    `frame_index` is active or not according to
    a specification that has been previously
    resolved.
    """

    @staticmethod
    def is_active(
        frame_index: FrameIndex,
        frame_index_specification_resolved: FrameIndexSpecificationResolved
    ) -> bool:
        """
        Check if the `frame_index` provided is active for
        the `frame_index_specification_resolved` provided.
        """
        return int(frame_index_specification_resolved.start_frame) <= int(frame_index) < int(frame_index_specification_resolved.end_frame)