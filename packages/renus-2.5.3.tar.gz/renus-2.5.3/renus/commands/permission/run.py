from app.extension.codenus.permission.middleware import PermissionMiddleware
from app.extension.codenus.permission.model import Permission

from renus.core.routing import Router


def run():
    all=Router().all
    names=set()
    names.add('delete_storage')
    for a in all:
        for method in all[a]:
            for route in all[a][method]:
                for md in route['middlewares']:
                    if isinstance(md,PermissionMiddleware):
                        print(route['path'], md.names)
                        for name in md.names:
                            names.add(name)

    for name in names:
        Permission('').where({
            'name':name
        }).update({},True)

    print('done')