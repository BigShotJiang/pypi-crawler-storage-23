from .__response_structured import JsonResponse
