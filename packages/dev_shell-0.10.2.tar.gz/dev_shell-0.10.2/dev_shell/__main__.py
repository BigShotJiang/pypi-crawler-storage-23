"""
Allow dev_shell to be executable
through `python -m dev_shell`.
"""

from dev_shell.dev_shell_app import main


if __name__ == '__main__':
    main()
