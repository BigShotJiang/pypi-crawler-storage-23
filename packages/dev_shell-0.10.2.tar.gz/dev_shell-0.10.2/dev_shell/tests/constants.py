from dev_shell.constants import DEV_SHELL_PKG_PATH


DEV_SHELL_PACKAGE_ROOT = DEV_SHELL_PKG_PATH.parent
