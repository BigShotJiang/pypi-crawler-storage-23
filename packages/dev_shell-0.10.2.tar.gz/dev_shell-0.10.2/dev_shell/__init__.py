"""
dev_shell
Developer shell for easy startup...
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.10.2'
__author__ = 'Jens Diemer <dev-shell@jensdiemer.de>'
