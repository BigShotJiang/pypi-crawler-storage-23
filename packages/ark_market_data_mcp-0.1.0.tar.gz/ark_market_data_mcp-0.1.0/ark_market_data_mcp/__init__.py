"""Ark Market Data MCP Server - Stream market data via WebSocket"""

__version__ = "0.1.0"
__author__ = "arkhamides"
