Run Server
`python3 src/server.py`

MCP Inspector
`npx @modelcontextprotocol/inspector`

### Roadmap
  - Users run your MCP server on their machine
  - Your MCP server connects to your hosted websocket (e.g., ws://your-server.com/market-data)
  - Users just use the MCP; you handle the data streaming
  - ✅ Simpler for users
  - ❌ You host and pay for the infrastructure


## Should I use grok http? If so, Will I need to turn my MCP responses to HTTP too?



## How to use 
claude mcp add ark-market-data sh -c "WS_URI=wss://abc123.ngrok.io python -m ark_market_data_mcp"