"""Core runtime components for agentnotify."""
