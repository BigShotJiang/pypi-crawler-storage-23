import fire

from pycytominer.cyto_utils.cell_locations import CellLocation

if __name__ == "__main__":
    fire.Fire(CellLocation)
