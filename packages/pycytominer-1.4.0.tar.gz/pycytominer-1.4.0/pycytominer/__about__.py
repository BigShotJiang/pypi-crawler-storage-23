__project__ = "pycytominer"
# These version placeholders are updated during build by poetry-dynamic-versioning
__version__ = "1.4.0"
__version_tuple__ = (1, 4, 0)
__license__ = "BSD 3-Clause License"
__author__ = "Pycytominer Contributors"
