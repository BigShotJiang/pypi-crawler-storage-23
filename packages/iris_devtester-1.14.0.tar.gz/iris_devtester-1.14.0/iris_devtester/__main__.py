"""
Entry point for python -m iris_devtester.
"""

from iris_devtester.cli import main

if __name__ == "__main__":
    main()
