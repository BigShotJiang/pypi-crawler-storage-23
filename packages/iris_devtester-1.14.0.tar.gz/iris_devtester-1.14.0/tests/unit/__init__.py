"""Unit tests with mocked dependencies."""
