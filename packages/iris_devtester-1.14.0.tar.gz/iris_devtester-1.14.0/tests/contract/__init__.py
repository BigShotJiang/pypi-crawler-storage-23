"""Contract tests validating API interfaces."""
