"""
Grok (xAI) provider for Grok models.

Uses the official xai_sdk Python SDK for interacting with xAI's Grok models.
Requires the XAI_API_KEY environment variable or an explicit api_key parameter.
"""

import asyncio
import json
import uuid
from typing import Any, Dict, List, Optional

from google.genai import types

from em_agent_framework.config.settings import ModelConfig

from .provider import ModelProvider, ProviderResponse


class GrokProvider(ModelProvider):
    """
    Provider for xAI Grok models.

    Uses the xai_sdk (official xAI Python SDK) for interacting with Grok models.
    Authentication is handled via the XAI_API_KEY environment variable by default,
    or through an explicit api_key parameter.

    The provider converts between the framework's google.genai.types.Content history
    format and the xai_sdk's message format for each API call.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        system_instruction: str,
        api_key: Optional[str] = None,
        timeout: float = 10.0,
    ):
        """
        Initialize Grok provider.

        Args:
            model_config: Configuration for the model
            system_instruction: System instruction/prompt
            api_key: Optional xAI API key (defaults to XAI_API_KEY env var)
            timeout: Request timeout in seconds
        """
        self.model_config = model_config
        self.system_instruction = system_instruction
        self.timeout = timeout
        self._tools = None
        self._history = []
        self._last_input_tokens = 0
        self._last_output_tokens = 0

        # Initialize xAI async client
        from xai_sdk import AsyncClient

        client_kwargs = {"timeout": int(timeout)}
        if api_key:
            client_kwargs["api_key"] = api_key
        self._client = AsyncClient(**client_kwargs)

    @property
    def model_name(self) -> str:
        """Get the current model name."""
        return self.model_config.name

    @property
    def provider_type(self) -> str:
        """Get the provider type."""
        return "grok"

    def is_grok_model(self) -> bool:
        """Check if current model is a Grok model."""
        return True

    def initialize_chat(
        self, history: List[types.Content], tools: Optional[List[Any]] = None
    ) -> None:
        """
        Initialize or reinitialize the chat session.

        Args:
            history: Initial conversation history
            tools: Optional tools available to the model
        """
        self._tools = tools
        self._history = history or []

    # ---- Tool conversion -----------------------------------------------------

    def _convert_tools_to_grok_format(
        self, tools: Optional[List[Any]] = None
    ) -> Optional[List[Any]]:
        """
        Convert framework tool declarations to xai_sdk tool format.

        Args:
            tools: Tools in framework format (FunctionDeclaration objects)

        Returns:
            Tools in xai_sdk format, or None
        """
        if not tools:
            return None

        from xai_sdk.chat import tool as grok_tool

        grok_tools = []
        for t in tools:
            grok_tools.append(
                grok_tool(
                    name=t.name,
                    description=t.description,
                    parameters=t.parameters,
                )
            )
        return grok_tools

    # ---- Chat creation & history replay --------------------------------------

    def _create_grok_chat(self, tools: Optional[List[Any]] = None):
        """
        Create a fresh xai_sdk chat session with system instruction and tools.

        A new chat is created for each API call because the xai_sdk manages
        conversation state internally, and we need to sync with the framework's
        Content-based history.

        Args:
            tools: Optional tools in framework format

        Returns:
            xai_sdk Chat object
        """
        from xai_sdk.chat import system

        create_kwargs = {
            "model": self.model_config.name,
            "messages": [system(self.system_instruction)],
        }

        grok_tools = self._convert_tools_to_grok_format(tools)
        if grok_tools:
            create_kwargs["tools"] = grok_tools

        if self.model_config.temperature is not None:
            create_kwargs["temperature"] = self.model_config.temperature

        return self._client.chat.create(**create_kwargs)

    def _replay_history_into_chat(self, chat, history: List[types.Content]) -> None:
        """
        Replay Content history into an xai_sdk chat session.

        Converts google.genai.types.Content objects to xai_sdk messages
        and appends them to the chat in order.

        Args:
            chat: xai_sdk Chat object to replay into
            history: Conversation history in Content format
        """
        from xai_sdk.chat import user as grok_user, tool_result as grok_tool_result

        # Track tool_call IDs from model responses for matching with tool results
        pending_tool_call_ids: Dict[str, List[str]] = {}

        for content in history:
            if content.role == "user":
                text_parts = []
                tool_responses = []

                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        text_parts.append(part.text)
                    elif hasattr(part, "function_response") and part.function_response:
                        fr = part.function_response
                        result = fr.response
                        result_str = (
                            json.dumps(result) if isinstance(result, dict) else str(result)
                        )

                        # Get tool_call_id - prefer stored ID, fallback to map
                        tool_call_id = getattr(fr, "id", None)
                        if not tool_call_id:
                            if (
                                fr.name in pending_tool_call_ids
                                and pending_tool_call_ids[fr.name]
                            ):
                                tool_call_id = pending_tool_call_ids[fr.name].pop(0)
                        else:
                            # Consume the map entry even when we have a stored ID
                            if (
                                fr.name in pending_tool_call_ids
                                and pending_tool_call_ids[fr.name]
                            ):
                                pending_tool_call_ids[fr.name].pop(0)

                        tool_responses.append((result_str, tool_call_id))

                if text_parts:
                    chat.append(grok_user("\n".join(text_parts)))
                for result_str, tool_call_id in tool_responses:
                    chat.append(grok_tool_result(result_str, tool_call_id=tool_call_id))

            elif content.role == "model":
                text_parts = []
                tool_calls_data = []

                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        text_parts.append(part.text)
                    elif hasattr(part, "function_call") and part.function_call:
                        fc = part.function_call
                        tc_id = getattr(fc, "id", None)

                        # Track the tool_call ID for matching with results
                        if tc_id:
                            func_name = fc.name
                            if func_name not in pending_tool_call_ids:
                                pending_tool_call_ids[func_name] = []
                            pending_tool_call_ids[func_name].append(tc_id)

                        tool_calls_data.append(
                            {
                                "name": fc.name,
                                "args": dict(fc.args),
                                "id": tc_id,
                            }
                        )

                text = "\n".join(text_parts) if text_parts else ""
                self._append_assistant_message(
                    chat, text, tool_calls_data if tool_calls_data else None
                )

    def _append_assistant_message(
        self,
        chat,
        text: str,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """
        Append an assistant message (potentially with tool calls) to the chat.

        Uses the xai_sdk proto types to construct assistant messages with tool calls.
        Falls back to the simple assistant() helper for text-only messages.

        Args:
            chat: xai_sdk Chat object
            text: Text content of the assistant message
            tool_calls: Optional list of tool call dicts with 'name', 'args', 'id'
        """
        try:
            from xai_sdk.proto import chat_pb2

            content_parts = []
            if text:
                content_parts.append(
                    chat_pb2.Content(
                        type=chat_pb2.ContentType.CONTENT_TYPE_TEXT,
                        text=text,
                    )
                )

            msg_kwargs = {
                "role": chat_pb2.MessageRole.ROLE_ASSISTANT,
            }
            if content_parts:
                msg_kwargs["content"] = content_parts

            if tool_calls:
                tc_protos = []
                for tc in tool_calls:
                    tc_proto = chat_pb2.ToolCall(
                        id=tc.get("id", "") or "",
                        function=chat_pb2.FunctionCall(
                            name=tc["name"],
                            arguments=json.dumps(tc["args"]),
                        ),
                    )
                    tc_protos.append(tc_proto)
                msg_kwargs["tool_calls"] = tc_protos

            msg = chat_pb2.Message(**msg_kwargs)
            chat.append(msg)
        except Exception:
            # Fallback: use assistant() for text-only messages.
            # Tool calls won't be perfectly replayed in the fallback path,
            # but the conversation can still continue.
            from xai_sdk.chat import assistant as grok_assistant

            if text:
                chat.append(grok_assistant(text))

    def _compress_history(self, history: List[types.Content]) -> str:
        """
        Compress conversation history into a text summary.

        Used as a fallback when history from another provider cannot be
        faithfully replayed (e.g., missing tool_call IDs or incompatible formats).

        Args:
            history: Conversation history in Content format

        Returns:
            Text summary of the conversation
        """
        if not history:
            return ""

        summary_parts = ["Previous conversation summary:"]

        for content in history:
            role_label = "User" if content.role == "user" else "Assistant"

            for part in content.parts:
                if hasattr(part, "text") and part.text:
                    summary_parts.append(f"{role_label}: {part.text}")
                elif hasattr(part, "function_call") and part.function_call:
                    summary_parts.append(
                        f"{role_label} called tool '{part.function_call.name}' "
                        f"with args: {dict(part.function_call.args)}"
                    )
                elif hasattr(part, "function_response") and part.function_response:
                    summary_parts.append(
                        f"Tool '{part.function_response.name}' returned: "
                        f"{part.function_response.response}"
                    )

        return "\n".join(summary_parts)

    # ---- API calls -----------------------------------------------------------

    async def send_message(
        self,
        message: str,
        history: List[types.Content],
        tools: Optional[List[Any]] = None,
    ) -> ProviderResponse:
        """
        Send a message to Grok.

        Args:
            message: The message to send
            history: Current conversation history
            tools: Optional tools available to the model

        Returns:
            ProviderResponse with model output
        """
        # Update internal state
        if tools != self._tools:
            self._tools = tools
        self._history = history or []

        # Create fresh chat and replay history
        chat = self._create_grok_chat(tools)
        if history:
            self._replay_history_into_chat(chat, history)

        # Append new user message
        from xai_sdk.chat import user as grok_user

        chat.append(grok_user(message))

        # Sample response with timeout
        response = await asyncio.wait_for(
            chat.sample(),
            timeout=self.timeout,
        )

        return self._parse_response(response)

    async def send_function_response(
        self,
        function_response_parts: List[Any],
        history: List[types.Content],
    ) -> ProviderResponse:
        """
        Send function execution results back to Grok.

        The function responses are already included in the history (appended by
        the agent before calling this method). This method replays the full
        history and samples the next response.

        Args:
            function_response_parts: List of function response parts (already in history)
            history: Current conversation history (includes function responses)

        Returns:
            ProviderResponse with model's next response
        """
        self._history = history or []

        # Create fresh chat and replay full history (which includes function responses)
        chat = self._create_grok_chat(self._tools)
        if history:
            self._replay_history_into_chat(chat, history)

        # Sample response with timeout
        response = await asyncio.wait_for(
            chat.sample(),
            timeout=self.timeout,
        )

        return self._parse_response(response)

    # ---- Response parsing ----------------------------------------------------

    def _parse_response(self, response: Any) -> ProviderResponse:
        """
        Parse xai_sdk response into standardized ProviderResponse.

        Args:
            response: Raw response from xai_sdk

        Returns:
            Standardized ProviderResponse
        """
        text = ""
        function_calls = []
        finish_reason = None

        if response:
            # Extract text content
            text = getattr(response, "content", "") or ""

            # Extract finish reason
            finish_reason = getattr(response, "finish_reason", None)

            # Extract and track token usage from latest call
            usage = getattr(response, "usage", None)
            if usage:
                self._last_input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                self._last_output_tokens = getattr(usage, "completion_tokens", 0) or 0

            # Extract tool calls
            tool_calls = getattr(response, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    try:
                        args_str = tc.function.arguments
                        args = (
                            json.loads(args_str) if isinstance(args_str, str) else args_str
                        )
                    except (json.JSONDecodeError, AttributeError):
                        args = {}

                    function_calls.append(
                        {
                            "name": tc.function.name,
                            "args": args,
                            "id": getattr(tc, "id", None),
                            "raw": tc,
                        }
                    )

        return ProviderResponse(
            text=text,
            function_calls=function_calls,
            raw_response=response,
            finish_reason=finish_reason,
        )

    def is_malformed_response(self, response: Any) -> bool:
        """
        Check if response is malformed.

        Args:
            response: Response to check

        Returns:
            True if response is malformed
        """
        if not response:
            return True

        # Check for basic response validity
        if hasattr(response, "content") and response.content:
            return False
        if hasattr(response, "tool_calls") and response.tool_calls:
            return False

        return True

    def count_tokens(
        self, messages: List[Dict[str, Any]], tools: Optional[List[Any]] = None
    ) -> int:
        """
        Count tokens based on actual usage from the latest response.

        Args:
            messages: List of messages (not used, kept for interface compatibility)
            tools: Optional tools (not used, kept for interface compatibility)

        Returns:
            Total token count from latest API call
        """
        return self._last_input_tokens + self._last_output_tokens

    def get_chat_history(self) -> List[types.Content]:
        """Get current chat history."""
        return self._history

    def get_last_input_tokens(self) -> int:
        """Get input tokens from the latest API call."""
        return self._last_input_tokens

    def get_last_output_tokens(self) -> int:
        """Get output tokens from the latest API call."""
        return self._last_output_tokens

    def update_system_instruction(
        self, new_instruction: str, history: List[types.Content]
    ) -> None:
        """
        Update system instruction and reinitialize chat.

        Args:
            new_instruction: New system instruction
            history: Current conversation history to preserve
        """
        self.system_instruction = new_instruction
        self.initialize_chat(history, self._tools)
