"""
Conversation history manager with summarization support.
"""

from typing import Any, Dict, List, Optional

from google import genai
from google.genai import types


class ConversationManager:
    """
    Manages conversation history with automatic summarization.
    """

    def __init__(
        self,
        token_threshold: int = 100000,
        summarization_prompt: Optional[str] = None,
        model_name: str = "gemini-2.5-flash",
        verbose: bool = True,
        project_id: Optional[str] = None,
        location: str = "global",
    ):
        """
        Initialize conversation manager.

        Args:
            token_threshold: Token count threshold for auto-summarization
            summarization_prompt: Custom prompt for summarization
            model_name: Model to use for summarization
            verbose: Whether to print detailed logs
            project_id: Google Cloud project ID
            location: Google Cloud location
        """
        self.token_threshold = token_threshold
        self.model_name = model_name
        self.verbose = verbose
        self.project_id = project_id
        self.location = location
        self.history: List[types.Content] = []
        self.summary: Optional[str] = None

        # Create genai client for summarization
        self._client = genai.Client(
            vertexai=True,
            project=project_id,
            location=location,
        )

        self.summarization_prompt = summarization_prompt or (
            "Pay attention to the task and the progress defined in the conversation history. "
            "Create a concise summary of the conversation so far without losing any information relevant for the task. "
            "Keep the summary brief and focused on key points, decisions, and outcomes."
        )

    def add_message(self, role: str, content: str) -> None:
        """
        Add a message to history.

        Args:
            role: 'user' or 'model'
            content: Message content
        """
        self.history.append(types.Content(role=role, parts=[types.Part(text=content)]))

    def add_content(self, content: types.Content) -> None:
        """
        Add a Content object directly to history.

        Args:
            content: genai Content object
        """
        self.history.append(content)

    def get_history(self) -> List[types.Content]:
        """Get conversation history."""
        return self.history

    def clear_history(self) -> None:
        """Clear conversation history."""
        self.history = []
        self.summary = None

    async def check_and_summarize_if_needed(
        self,
        client: genai.Client,
        model_name: str,
        tools: Optional[List[Any]] = None,
        new_message: Optional[str] = None,
    ) -> bool:
        """
        Check token count and summarize if threshold is exceeded.

        Note: Token counting for summarization is currently disabled as it only works
        reliably with Gemini models. For Claude models, automatic summarization based
        on token count is not available.

        Args:
            client: genai Client instance (kept for interface compatibility)
            model_name: Model name (kept for interface compatibility)
            tools: Optional tools (kept for interface compatibility)
            new_message: Optional new message (kept for interface compatibility)

        Returns:
            Always False (summarization disabled)
        """
        # Token counting for automatic summarization is disabled
        # Providers now track tokens internally for metrics, but not for this feature
        # TODO: Implement provider-agnostic token counting for summarization
        return False

    async def _summarize_conversation(self) -> None:
        """Summarize the conversation history and replace with summary."""
        try:
            if not self.history:
                return

            # Build conversation text
            conversation_text = self._build_conversation_text()
            if not conversation_text.strip():
                return

            # Create summarization prompt
            full_prompt = (
                f"{self.summarization_prompt}\n\nConversation history:\n{conversation_text}"
            )

            # Generate summary using genai client
            config = types.GenerateContentConfig(
                temperature=0.1,
                max_output_tokens=1000,
                system_instruction="You are a helpful assistant that creates concise, accurate summaries.",
            )

            summary_response = await self._client.aio.models.generate_content(
                model=self.model_name,
                contents=[types.Content(role="user", parts=[types.Part(text=full_prompt)])],
                config=config,
            )

            summary_text = self._extract_text_from_response(summary_response)

            if summary_text:
                # Print summary
                print("\n" + "=" * 80)
                print("[ConversationManager] CONVERSATION SUMMARY:")
                print("=" * 80)
                print(summary_text)
                print("=" * 80 + "\n")

                # Store summary and clear history
                self.summary = summary_text
                self.history = []

                if self.verbose:
                    print("[ConversationManager] Conversation summarized")

        except Exception as e:
            if self.verbose:
                print(f"[ConversationManager] Summarization error: {e}")

    def get_summary(self) -> Optional[str]:
        """Get the current conversation summary."""
        return self.summary

    def has_summary(self) -> bool:
        """Check if a summary exists."""
        return self.summary is not None

    def prepend_summary_to_message(self, message: str) -> str:
        """
        Prepend summary to a message if summary exists.

        Args:
            message: Original message

        Returns:
            Message with summary prepended (if summary exists)
        """
        if self.summary:
            return f"[Context: {self.summary}]\n\n{message}"
        return message

    def _convert_history_for_counting(self) -> List[Dict[str, Any]]:
        """Convert history to format for token counting."""
        messages = []
        for entry in self.history:
            if isinstance(entry, types.Content) or (
                hasattr(entry, "role") and hasattr(entry, "parts")
            ):
                parts = []
                if hasattr(entry, "parts") and entry.parts:
                    for part in entry.parts:
                        if hasattr(part, "text") and part.text:
                            parts.append({"text": part.text})
                if parts:
                    messages.append({"role": entry.role, "parts": parts})
        return messages

    def _build_conversation_text(self) -> str:
        """Build conversation text from history."""
        text = ""
        for entry in self.history:
            if isinstance(entry, types.Content) or (
                hasattr(entry, "role") and hasattr(entry, "parts")
            ):
                content = ""
                if hasattr(entry, "parts") and entry.parts:
                    content = "".join(
                        part.text for part in entry.parts if hasattr(part, "text") and part.text
                    )
                if content:
                    text += f"{entry.role.upper()}: {content}\n\n"
        return text

    def _extract_text_from_response(self, response) -> str:
        """Extract text content from LLM response."""
        if not response or not response.candidates:
            return ""

        candidate = response.candidates[0]
        if not candidate.content or not candidate.content.parts:
            return ""

        text_parts = [
            part.text for part in candidate.content.parts if hasattr(part, "text") and part.text
        ]
        return "\n".join(text_parts)
