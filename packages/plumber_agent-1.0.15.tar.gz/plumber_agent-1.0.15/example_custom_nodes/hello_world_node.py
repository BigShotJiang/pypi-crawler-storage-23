"""
Example Custom Node: Hello World

HOW TO USE:
1. Copy this file to: ~/plumber/custom_nodes/
2. The agent will auto-detect it within 2 seconds
3. The node appears in Plumber's TabMenu under "Examples" category

IMPORTANT - NO IMPORTS NEEDED:
The following classes are automatically available (injected by the executor):
- Node          : Base class for all custom nodes
- Property      : Define editable properties (shown in PropertyPanel)
- Input         : Define input ports (receive data from other nodes)
- Output        : Define output ports (send data to other nodes)
- ExecutionContext : Access to logging, progress reporting, etc.
"""


class HelloWorldNode(Node):
    """A simple hello world node that greets the user."""

    # ═══════════════════════════════════════════════════════════════════════
    # NODE METADATA - How the node appears in the UI
    # ═══════════════════════════════════════════════════════════════════════
    _category = "Examples"          # Category in TabMenu
    _icon = "Smile"                 # Icon name (Lucide icons)
    _description = "A simple greeting node"
    _color = "#10b981"              # Node header color (hex)

    # ═══════════════════════════════════════════════════════════════════════
    # PROPERTIES - Editable fields shown in PropertyPanel
    # ═══════════════════════════════════════════════════════════════════════
    name: str = Property(
        default="World",
        label="Your Name",
        tooltip="Enter your name for a personalized greeting"
    )

    excitement: int = Property(
        default=1,
        min_value=1,
        max_value=5,
        label="Excitement Level",
        tooltip="How many exclamation marks?"
    )

    # ═══════════════════════════════════════════════════════════════════════
    # INPUT PORTS - Receive data from connected nodes
    # ═══════════════════════════════════════════════════════════════════════
    prefix: str = Input(
        type=str,
        required=False,             # Optional input
        label="Prefix",
        description="Optional prefix for the greeting"
    )

    # ═══════════════════════════════════════════════════════════════════════
    # OUTPUT PORTS - Send data to connected nodes
    # ═══════════════════════════════════════════════════════════════════════
    greeting: str = Output(
        type=str,
        label="Greeting",
        description="The generated greeting message"
    )

    # ═══════════════════════════════════════════════════════════════════════
    # EXECUTE - Your node logic goes here
    # ═══════════════════════════════════════════════════════════════════════
    def execute(self, context: ExecutionContext) -> dict:
        """
        Main execution method. Called when the workflow runs.

        Args:
            context: Provides logging, progress reporting, and metadata

        Returns:
            dict of {output_port_name: value}
        """
        # Report progress (0.0 to 1.0)
        context.report_progress(0.0, "Starting greeting...")

        # Get input value (returns None if not connected)
        prefix = self.get_input("prefix") or "Hello"

        # Access properties directly as attributes
        exclamation = "!" * self.excitement
        greeting = f"{prefix}, {self.name}{exclamation}"

        # Log messages (appear in Output Window)
        context.log_info(f"Generated greeting: {greeting}")

        context.report_progress(1.0, "Done!")

        # Return outputs as a dict
        return {"greeting": greeting}
