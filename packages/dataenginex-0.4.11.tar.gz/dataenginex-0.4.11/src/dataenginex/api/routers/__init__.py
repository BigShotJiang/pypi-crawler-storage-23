"""API routers package."""

from __future__ import annotations
