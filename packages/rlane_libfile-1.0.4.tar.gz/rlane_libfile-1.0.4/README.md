## libfile

Libfile.

This module offers a class that combines pathlib.Path, os.walk,
cached os.struct_stat, debug/trace logging, and the ability to execute
a --dry-run through 'most' of the code without changing the filesystem.

File(object) represents a filesystem item, such as a file or folder, which
may or may not exist when the object is initialized.  This differs
from os.DirEntry(object), which is only instantiated for an existing item.

File has nothing to do with input/output... yet.

For you old unix cats like me, a 'folder' is a 'directory', and this
module enjoys the 50% reduction in the number of syllables required,
the 3-fewer keystrokes for singular, 4 for plural, and non-collision
with python built-in 'dir'. Embrace the technology!



### class File

Represent a filesystem item such as a file or folder.

The path argument to the constructor, and other methods that take a
path argument, accept either a string, or an object implementing the
os.PathLike interface which returns a string, or another path object.

See: https://docs.python.org/3/library/pathlib.html#pure-paths


