"""Charter daemon — background governance service."""
