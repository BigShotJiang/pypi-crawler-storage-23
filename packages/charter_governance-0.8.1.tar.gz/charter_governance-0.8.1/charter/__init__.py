"""Charter — AI governance layer."""

__version__ = "0.8.1"
