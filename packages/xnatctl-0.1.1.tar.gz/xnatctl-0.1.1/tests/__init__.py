# xnatctl tests
