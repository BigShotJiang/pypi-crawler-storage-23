"""Centralized timeout defaults for xnatctl."""

DEFAULT_HTTP_TIMEOUT_SECONDS = 21600
