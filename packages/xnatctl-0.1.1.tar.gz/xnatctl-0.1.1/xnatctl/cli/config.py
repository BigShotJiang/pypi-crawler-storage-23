"""Backward-compatible wrapper for config commands."""

from __future__ import annotations

from xnatctl.cli.config_cmd import config

__all__ = ["config"]
