"""CLI module for xnatctl."""

from __future__ import annotations

from xnatctl.cli.main import cli

__all__ = ["cli"]
