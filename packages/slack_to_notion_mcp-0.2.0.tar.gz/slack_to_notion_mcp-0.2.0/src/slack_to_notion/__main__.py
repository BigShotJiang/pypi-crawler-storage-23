"""python -m slack_to_notion 실행을 지원한다."""

from slack_to_notion.mcp_server import main

main()
