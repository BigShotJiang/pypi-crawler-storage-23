from rest_framework import serializers


class InviteSerializer(serializers.Serializer):

    user_first_name = serializers.CharField(max_length=200)
    user_last_name = serializers.CharField(max_length=200)
    user_email = serializers.CharField(max_length=200)
    invite_type = serializers.CharField(max_length=200)
    action_url = serializers.CharField(max_length=200, allow_null=True)
    resource_id = serializers.IntegerField(allow_null=True)
