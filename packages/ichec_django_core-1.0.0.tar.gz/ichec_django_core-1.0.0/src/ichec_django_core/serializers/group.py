from django.contrib.auth.models import Group

from rest_framework import serializers

from ..models import Member


class GroupListSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = Group
        fields = ["url", "name", "id"]
        read_only_fields = ("url", "name", "id")


class GroupDetailSerializer(GroupListSerializer):
    user_set = serializers.HyperlinkedRelatedField(
        many=True, view_name="member-detail", queryset=Member.objects.all()
    )

    class Meta:
        model = Group
        fields = GroupListSerializer.Meta.fields + ["user_set"]
        read_only_fiels = GroupListSerializer.Meta.read_only_fields
