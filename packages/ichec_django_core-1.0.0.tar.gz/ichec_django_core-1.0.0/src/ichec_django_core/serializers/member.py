from rest_framework import serializers

from ..models import Member, MemberIdentifier, MemberPreferences

from .core import SERIALIZER_BASE_FIELDS


class MemberIdentifierSerializer(serializers.ModelSerializer):

    # Needs explicit inclusion to use in Member list serializer updates
    id = serializers.IntegerField(required=False)

    class Meta:
        model = MemberIdentifier
        fields = ("id", "id_type", "value")


class MemberPreferencesSerializer(serializers.ModelSerializer):

    id = serializers.IntegerField(required=False)

    class Meta:
        model = MemberPreferences
        fields = (
            "id",
            "notifications",
        )
        read_only_fiels = ("id",)


class MemberBaseSerializer(serializers.HyperlinkedModelSerializer):

    identifiers = MemberIdentifierSerializer(many=True)

    class Meta:
        model = Member
        fields = SERIALIZER_BASE_FIELDS + (
            "username",
            "email",
            "first_name",
            "last_name",
            "phone",
            "profile",
            "identifiers",
            "verified",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS + ("profile",)

    def create(self, validated_data):
        ids = validated_data.pop("identifiers")

        instance = super().create(validated_data)
        MemberIdentifier.objects.bulk_create(
            [MemberIdentifier(member=instance, **eachId) for eachId in ids]
        )
        return instance

    def get_existing(self, id: str, collection: list):
        for c in collection:
            if c.id == id:
                return c
        raise RuntimeError("Requested non-existing entry")

    def update(self, instance, validated_data):
        incoming_ids = validated_data.pop("identifiers")

        instance = super().update(instance, validated_data)

        all_existing = instance.identifiers.all()

        # If any ids no longer exist delete them
        incoming_ids_ids = [
            incoming["id"] for incoming in incoming_ids if "id" in incoming
        ]
        existing_ids = [existing.id for existing in all_existing]
        for existing in existing_ids:
            if existing not in incoming_ids_ids:
                MemberIdentifier.objects.get(id=existing).delete()

        # If there is an id do an update, else do a create
        serializer = MemberIdentifierSerializer()
        for eachId in incoming_ids:
            if "id" not in eachId:
                MemberIdentifier.objects.create(member=instance, **eachId)
            else:
                serializer.update(self.get_existing(eachId["id"], all_existing), eachId)
        return instance


class MemberResponseSerializer(MemberBaseSerializer):
    """
    Member responses are distinct from requests as they
    contain extra read-only fields with image urls
    """

    profile = serializers.HyperlinkedIdentityField(
        read_only=True, view_name="member-profile"
    )
    profile_thumbnail = serializers.HyperlinkedIdentityField(
        read_only=True, view_name="member-profile-thumbnail"
    )

    class Meta:
        model = Member
        fields = MemberBaseSerializer.Meta.fields + ("profile_thumbnail",)
        read_only_fields = ("profile", "profile_thumbnail")

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        if not instance.profile:
            rep["profile"] = None
        if not instance.profile_thumbnail:
            rep["profile_thumbnail"] = None
        return rep


class MemberListSerializer(MemberBaseSerializer):
    """
    Fields that all logged in users can see when listing members
    """

    class Meta:
        model = Member
        fields = MemberBaseSerializer.Meta.fields
        read_only_fields = MemberBaseSerializer.Meta.read_only_fields

    def to_representation(self, instance):
        return MemberResponseSerializer(context=self.context).to_representation(
            instance
        )


class MemberDetailSerializer(MemberBaseSerializer):
    """
    Fields when a member detail is shown
    """

    class Meta:
        model = Member
        fields = MemberBaseSerializer.Meta.fields
        read_only_fields = MemberBaseSerializer.Meta.read_only_fields

    def to_representation(self, instance):
        return MemberResponseSerializer(context=self.context).to_representation(
            instance
        )


class MemberSelfDetailResponseSerializer(MemberResponseSerializer):
    """
    Fields when a member looks at their own profile. The response
    has extra image fields.
    """

    permissions = serializers.SerializerMethodField("get_all_permissions")
    preferences = MemberPreferencesSerializer()

    class Meta:
        model = Member
        fields = MemberResponseSerializer.Meta.fields + ("permissions", "preferences")
        read_only_fields = MemberResponseSerializer.Meta.read_only_fields + (
            "permissions",
        )

    def get_all_permissions(self, obj):
        return obj.get_all_permissions()


class MemberSelfDetailSerializer(MemberBaseSerializer):
    """
    Fields when a member looks at their own profile.
    """

    preferences = MemberPreferencesSerializer(required=False)

    class Meta:
        model = Member
        fields = MemberBaseSerializer.Meta.fields + ("preferences",)
        read_only_fields = MemberBaseSerializer.Meta.read_only_fields

    def to_representation(self, instance):
        return MemberSelfDetailResponseSerializer(
            context=self.context
        ).to_representation(instance)

    def create(self, validated_data):
        preferences = validated_data.pop("preferences")
        instance = super().create(validated_data)
        if preferences:
            instance.preferences = MemberPreferences.objects.create(**preferences)
        return instance

    def update(self, instance, validated_data):
        preferences = validated_data.pop("preferences")
        instance = super().update(instance, validated_data)

        if not preferences:
            return instance

        if instance.preferences:
            for attr, value in preferences.items():
                setattr(instance.preferences, attr, value)
            instance.preferences.save()
        else:
            instance.preferences = MemberPreferences.objects.create(**preferences)
        instance.save()
        return instance
