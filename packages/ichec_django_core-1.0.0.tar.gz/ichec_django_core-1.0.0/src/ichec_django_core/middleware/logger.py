import logging

logger = logging.getLogger(__name__)


class RequestLoggerMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        logger.info("Request path", request.path)
        logger.info("Request host", request.get_host())
        logger.info("Request Cookies", request.COOKIES)
        logger.ingo("Request Headers", request.headers)

        response = self.get_response(request)

        logger.info("Response headers", response.headers)
        logger.info("Response cookies", response.cookies)
        logger.info("Response status", response.status_code)
        return response


class SensitivePathFilter(logging.Filter):

    paths = ("GET /oidc/callback",)

    def filter(self, record):
        for path in self.paths:
            if path in record.getMessage():
                return False
        return True
