import typing

from django.db import models
from django.utils import timezone


class TimesStampMixin(models.Model):
    created_at = models.DateTimeField(default=timezone.now, editable=False)
    updated_at = models.DateTimeField(default=timezone.now)

    class Meta:
        abstract = True


class SoftDeleteMixin(models.Model):
    """
    A resource can be soft-deleted by setting active to false and setting a
    deletion time.

    This is filtered on in Querysets to disable resource visibility and interaction,
    but the resource still remains.

    Resources can be 'un-deleted' by resetting the active field.

    You could run a scheduled task to do full delete after some time period.

    Typing disabled as MyPy doesn't like duplicate Meta class definition
    but needed to stop Django generating DB fields
    """

    active = models.BooleanField(default=True)
    deleted_at = models.DateTimeField(default=timezone.now, null=True)

    class Meta:
        abstract = True


@typing.no_type_check
class DefaultPrivateMixin(models.Model):
    """
    Allows a resource to be set to being 'public'. In that case
    it can be viewed by anonymous users.

    Typing disabled as MyPy doesn't like duplicate Meta class definition
    but needed to stop Django generating DB fields
    """

    public = models.BooleanField(default=False)

    class Meta:
        abstract = True


@typing.no_type_check
class DefaultPublicMixin(models.Model):
    """
    Allows a resource to be set to being 'public'. In that case
    it can be viewed by anonymous users.

    Typing disabled as MyPy doesn't like duplicate Meta class definition
    but needed to stop Django generating DB fields
    """

    public = models.BooleanField(default=True)

    class Meta:
        abstract = True
