from django.urls import include, path
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.conf import settings

from .views import (
    MemberViewSet,
    MemberSelfView,
    MemberProfileUploadView,
    GroupViewSet,
    OrganizationViewSet,
    FeedbackViewSet,
    NotificationViewSet,
    CustomAuthToken,
    GetAuthToken,
)
from .views.core import server_manifest
from .views.login import register
from .views.auth import NoRedirectOIDCLogoutView
from .views.invite import InviteUserView


def register_drf_views(router):
    router.register(r"groups", GroupViewSet)
    router.register(r"organizations", OrganizationViewSet)
    router.register(r"members", MemberViewSet)
    router.register(r"feedback", FeedbackViewSet)
    router.register(r"notifications", NotificationViewSet)
    return router


urlpatterns = [
    path("api-token-auth/", CustomAuthToken.as_view()),
    path(f"{settings.API_AUTH_URL}/", include("rest_framework.urls")),
    path(f"{settings.ADMIN_URL}/", admin.site.urls),
    path(
        r"manifest",
        server_manifest,
        name="manifest",
    ),
    path("accounts/invite", InviteUserView.as_view(), name="user_invite"),
    path(
        r"api/self/",
        MemberSelfView.as_view(),
        name="member_self",
    ),
    path(
        r"api/token/",
        GetAuthToken.as_view(),
        name="token",
    ),
    path(
        r"api/members/<int:pk>/profile/upload",
        MemberProfileUploadView.as_view(),
        name="member_profiles_upload",
    ),
    path("", include("django_prometheus.urls")),
]

if settings.WITH_OIDC:
    urlpatterns += [
        path("oidc/logout/", NoRedirectOIDCLogoutView.as_view(), name="oidc_logout"),
        path("oidc/", include("mozilla_django_oidc.urls")),
    ]

if settings.WITH_USER_LOGIN:
    urlpatterns += [
        path(
            "accounts/login",
            auth_views.LoginView.as_view(
                template_name="ichec_django_core/registration/login.html"
            ),
        ),
        path("accounts/", include("django.contrib.auth.urls")),
        path("accounts/register", register, name="register"),
    ]
