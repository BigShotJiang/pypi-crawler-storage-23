import importlib
import uuid
import os
from pathlib import Path
import logging

from PIL import Image
from django.core.exceptions import PermissionDenied
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from rest_framework import status
from rest_framework.request import Request
from rest_framework.permissions import (
    DjangoObjectPermissions,
    IsAuthenticated,
    DjangoModelPermissions,
)
from rest_framework.parsers import FileUploadParser
from rest_framework.response import Response
from rest_framework.generics import GenericAPIView

from django_downloadview import ObjectDownloadView

rest_auth = importlib.import_module("rest_framework.authentication")

_AUTH_CLASSES = []
for c in settings.REST_FRAMEWORK["DEFAULT_AUTHENTICATION_CLASSES"]:
    modname = ".".join(c.split(".")[:-1])
    mod = importlib.import_module(modname)
    _AUTH_CLASSES.append(getattr(mod, c.split(".")[-1]))


DEFAULT_IMAGE_FORMATS = (".png", ".jpg", ".jpeg")

logger = logging.getLogger(__name__)


def upload_file(request, instance, model_name: str, field: str, extensions):

    media_root = Path(settings.MEDIA_ROOT)
    storage_dir = Path(f"{model_name}/{field}")
    os.makedirs(media_root / storage_dir, exist_ok=True)

    filename = request.data["file"].name

    _, ext = os.path.splitext(filename)

    if ext.lower() not in extensions:
        logger.warning("Suspicious extension in file upload: %s", ext)
        return Response(
            {"reason": "File extension not supported"},
            status=status.HTTP_400_BAD_REQUEST,
        )

    if ext.lower() in DEFAULT_IMAGE_FORMATS:
        try:
            image = Image.open(request.data["file"])
            image.verify()
            if image.format:
                getattr(instance, field).content_type = Image.MIME.get(image.format)
        except Exception as e:
            logger.warning("Suspicious file content in upload: %s", str(e))
            return Response(
                {"reason": "Image could not be verified"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    file_path = f"{uuid.uuid4()}{ext}"
    written_path = FileSystemStorage(location=media_root / storage_dir).save(
        file_path, request.data["file"]
    )

    getattr(instance, field).original_file_name = filename
    getattr(instance, field).name = str(storage_dir / written_path)
    instance.save()

    return Response(status=204)


class ObjectFileUploadView(GenericAPIView):

    parser_classes = [FileUploadParser]
    permission_classes = [
        IsAuthenticated,
        DjangoModelPermissions,
    ]

    def put(self, request, *args, **kwargs):
        return upload_file(
            request,
            self.get_object(),
            self.model._meta.model_name,
            self.file_field,
            self.extensions,
        )


class ObjectFileDownloadView(ObjectDownloadView):

    permissions_class = DjangoObjectPermissions

    def authenticate(self, request) -> None:
        for auth_class in _AUTH_CLASSES:
            auth_resp = auth_class().authenticate(Request(request))
            if auth_resp is not None:
                request.user = auth_resp[0]
                return

    def has_permission(self, request) -> None:

        instance = self.get_object()
        permissions = self.permissions_class()
        if not (
            permissions.has_permission(request, self)
            and permissions.has_object_permission(request, self, instance)
        ):
            raise PermissionDenied()

    def get_basename(self):
        filename = getattr(self.object, self.file_field).name
        return str(self.file_field + "." + filename.split(".")[-1])

    def get(self, request, *args, **kwargs):
        self.authenticate(request)
        self.has_permission(request)
        return super().get(request, *args, **kwargs)
