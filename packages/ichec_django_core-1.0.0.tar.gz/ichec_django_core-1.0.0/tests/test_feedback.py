from ichec_django_core.models import Feedback

from ichec_django_core.client import FeedbackCreate
from ichec_django_core.test import (
    setup_default_users_and_groups,
    setup_default_feedback,
    add_group_permissions,
    AuthAPITestCase,
)


class TestFeedbackView(AuthAPITestCase):

    template = FeedbackCreate(comments="This is some feedback")
    update_template = {"comments": "This is some edited feedback"}

    def setUp(self):
        self.url = "/api/feedback/"

        setup_default_users_and_groups()
        setup_default_feedback(self.get_user("regular_user"))

        add_group_permissions(
            "admins",
            Feedback,
            ["add_feedback", "view_feedback"],
        )

        add_group_permissions(
            "regular_users",
            Feedback,
            ["add_feedback"],
        )

        add_group_permissions(
            "members",
            Feedback,
            ["add_feedback"],
        )

    def test_list_access(self):

        scenarios = (
            ["", 0, 401, "Public can't list feedback"],
            ["regular_user", 0, 403, "Registered can't list feedback"],
            ["member", 0, 403, "Member can't list feedback"],
            ["admin_user", 3, 200, "Admin can list feedback"],
        )

        for user, count, status, msg in scenarios:
            if user:
                response = self.assert_status(self.auth_list(user), status, msg)
            else:
                response = self.assert_status(self.public_list(), status, msg)

            if status < 400:
                self.assertEqual(response.body.count, count, msg)

    def test_detail_access(self):

        self.assert_201(self.auth_create("regular_user", self.template))

        scenarios = (
            ["", 1, 401, "Public can't view detail"],
            ["regular_user", 1, 403, "Regular user can't view detail"],
            ["member", 1, 403, "Member can't view detail"],
            ["admin_user", 1, 200, "Admin can view detail"],
        )

        for user, item, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_detail(user, item), status, msg)
            else:
                self.assert_status(self.detail(item), status, msg)

    def test_create_permissions(self):

        scenarios = (
            ["", 401, "Public can't create, no auth"],
            ["regular_user", 201, "Registered can create"],
            ["member", 201, "Member can create"],
            ["admin_user", 201, "Admin can create"],
        )

        for user, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_create(user, self.template), status, msg)
            else:
                self.assert_status(self.create(self.template), status, msg)
