from rest_framework import status
from rest_framework.test import APITestCase

from django.contrib.auth.models import User

from ichec_django_core.test import (
    AuthAPITestCase,
    setup_default_users_and_groups,
)


class TopLevelViews(AuthAPITestCase):
    def setUp(self):

        setup_default_users_and_groups()
        User.objects.create_user("token_user")

    def test_top_level_not_authenticated(self):
        response = self.client.get("/api/", format="json")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_manifest(self):
        response = self.client.get("/manifest", format="json")
        self.assertEqual(response.status_code, 200)

    def test_api_auth(self):
        self.assert_200(self.auth_raw_get("token_user", "/api/token/"))
