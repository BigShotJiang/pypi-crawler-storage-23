from ichec_django_core.models import Notification

from ichec_django_core.test import (
    setup_default_users_and_groups,
    setup_default_notifications,
    add_group_permissions,
    AuthAPITestCase,
)


class TestNotificationView(AuthAPITestCase):

    update_template = {"comments": "This is some edited feedback"}

    def setUp(self):
        self.url = "/api/notifications/"

        setup_default_users_and_groups()
        setup_default_notifications(self.get_user("regular_user"))

    def test_list_access(self):

        scenarios = (
            ["", 0, 401, "Public can't list notifications"],
            ["regular_user", 3, 200, "Registered can list own notifications"],
            ["member", 0, 200, "Member can't list other notifications"],
        )

        for user, count, status, msg in scenarios:
            if user:
                response = self.assert_status(self.auth_list(user), status, msg)
            else:
                response = self.assert_status(self.public_list(), status, msg)

            if status < 400:
                self.assertEqual(response.body.count, count, msg)

    def test_detail_access(self):

        scenarios = (
            ["", 1, 401, "Public can't view detail"],
            ["regular_user", 1, 200, "Regular user can view own notification"],
            ["member", 1, 404, "Member can't view other's notifications"],
        )

        for user, item, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_detail(user, item), status, msg)
            else:
                self.assert_status(self.detail(item), status, msg)
