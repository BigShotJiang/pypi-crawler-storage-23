Miscellanous models
===================

This folder contains smaller models which have not been designed as part of a larger engineering system. Many of them are documented with GPkit's MarkDown literate programming framework, using the shell script and latex template in this directory.
