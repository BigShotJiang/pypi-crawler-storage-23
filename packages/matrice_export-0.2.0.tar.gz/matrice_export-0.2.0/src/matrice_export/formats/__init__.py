"""Export format implementations.

All concrete exporters inherit from :class:`BaseExporter` and are discoverable
via :func:`get_all_exporters`.  Individual exporter classes are imported lazily
so that ``import matrice_export.formats`` does **not** pull in ``torch`` or any
other heavy dependency.
"""

from matrice_export.formats.base import BaseExporter

# Registry: (module_path, class_name) — resolved lazily on first access.
_EXPORTER_REGISTRY = [
    ("matrice_export.formats.torchscript", "TorchScriptExporter"),
    ("matrice_export.formats.onnx_export", "OnnxExporter"),
    ("matrice_export.formats.openvino", "OpenVinoExporter"),
    ("matrice_export.formats.tensorrt", "TensorRTExporter"),
    ("matrice_export.formats.coreml", "CoreMLExporter"),
    ("matrice_export.formats.tf_saved", "TFSavedModelExporter"),
    ("matrice_export.formats.tf_graphdef", "TFGraphDefExporter"),
    ("matrice_export.formats.tflite", "TFLiteExporter"),
    ("matrice_export.formats.edgetpu", "EdgeTPUExporter"),
    ("matrice_export.formats.tfjs", "TFJSExporter"),
    ("matrice_export.formats.paddle", "PaddlePaddleExporter"),
]


def get_all_exporters() -> list[type[BaseExporter]]:
    """Lazily import and return all exporter classes."""
    import importlib

    exporters: list[type[BaseExporter]] = []
    for module_path, class_name in _EXPORTER_REGISTRY:
        mod = importlib.import_module(module_path)
        exporters.append(getattr(mod, class_name))
    return exporters


def __getattr__(name: str):
    # Allow lazy access to individual exporter classes by name.
    for module_path, class_name in _EXPORTER_REGISTRY:
        if class_name == name:
            import importlib

            mod = importlib.import_module(module_path)
            return getattr(mod, class_name)
    if name == "ALL_EXPORTERS":
        return get_all_exporters()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "BaseExporter",
    "get_all_exporters",
    "TorchScriptExporter",
    "OnnxExporter",
    "OpenVinoExporter",
    "TensorRTExporter",
    "CoreMLExporter",
    "TFSavedModelExporter",
    "TFGraphDefExporter",
    "TFLiteExporter",
    "EdgeTPUExporter",
    "TFJSExporter",
    "PaddlePaddleExporter",
    "ALL_EXPORTERS",
]
