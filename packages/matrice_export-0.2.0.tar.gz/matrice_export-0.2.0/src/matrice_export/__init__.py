"""matrice_export — Unified model export SDK for Matrice.

Supports three model input types:
- PyTorch (torch.nn.Module)
- ONNX (file path to .onnx)
- Ultralytics YOLO (ultralytics.YOLO object)

All heavy dependencies (torch, numpy, onnxruntime, etc.) are imported lazily
so that ``import matrice_export`` succeeds with a minimal installation.
"""

__all__ = ["ExportPipeline", "ExportTracker"]


def __getattr__(name: str):
    if name == "ExportPipeline":
        from matrice_export.pipeline import ExportPipeline

        return ExportPipeline
    if name == "ExportTracker":
        from matrice_export.tracking import ExportTracker

        return ExportTracker
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
