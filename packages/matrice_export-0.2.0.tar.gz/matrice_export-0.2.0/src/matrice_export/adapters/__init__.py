"""Model adapters for different input types (Ultralytics, ONNX)."""

from matrice_export.adapters.onnx_input import OnnxInputAdapter
from matrice_export.adapters.ultralytics import UltralyticsAdapter

__all__ = ["OnnxInputAdapter", "UltralyticsAdapter"]
