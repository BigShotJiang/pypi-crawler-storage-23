"""Export validation tools.

All concrete validators inherit from :class:`BaseValidator` and are
discoverable via :func:`get_all_validators`.  Individual validator classes
are imported lazily so that ``import matrice_export.validators`` does **not**
pull in ``numpy``, ``onnxruntime``, ``openvino``, or any other heavy
dependency.
"""

from matrice_export.validators.base import BaseValidator

# Registry: format_name -> (module_path, class_name) — resolved lazily.
_VALIDATOR_REGISTRY: dict[str, tuple[str, str]] = {
    "onnx": ("matrice_export.validators.onnx_val", "OnnxValidator"),
    "torchscript": ("matrice_export.validators.torchscript", "TorchScriptValidator"),
    "openvino": ("matrice_export.validators.openvino", "OpenVinoValidator"),
    "tensorrt": ("matrice_export.validators.tensorrt", "TensorRTValidator"),
}


def get_all_validators() -> dict[str, type[BaseValidator]]:
    """Lazily import and return all validator classes keyed by format name."""
    import importlib

    validators: dict[str, type[BaseValidator]] = {}
    for fmt_name, (module_path, class_name) in _VALIDATOR_REGISTRY.items():
        mod = importlib.import_module(module_path)
        validators[fmt_name] = getattr(mod, class_name)
    return validators


def __getattr__(name: str):
    # Allow lazy access to individual validator classes by name.
    for _fmt, (module_path, class_name) in _VALIDATOR_REGISTRY.items():
        if class_name == name:
            import importlib

            mod = importlib.import_module(module_path)
            return getattr(mod, class_name)
    if name == "ALL_VALIDATORS":
        return get_all_validators()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "BaseValidator",
    "get_all_validators",
    "OnnxValidator",
    "TorchScriptValidator",
    "OpenVinoValidator",
    "TensorRTValidator",
    "ALL_VALIDATORS",
]
