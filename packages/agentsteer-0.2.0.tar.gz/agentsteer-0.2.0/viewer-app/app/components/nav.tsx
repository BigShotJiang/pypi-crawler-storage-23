"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LogoFull } from "./logo";

export function Nav() {
  const pathname = usePathname();
  const isEnterprise = pathname.startsWith("/enterprise");
  const isDocs = pathname.startsWith("/docs");
  return (
    <nav
      style={{
        background: "var(--bg)",
        borderBottom: "1px solid var(--border)",
        padding: "0 24px",
        height: 56,
        display: "flex",
        alignItems: "center",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}
    >
      <Link
        href="/"
        style={{
          textDecoration: "none",
          display: "inline-flex",
          alignItems: "center",
          height: "100%",
        }}
      >
        <LogoFull height={24} />
      </Link>
      <div
        style={{
          marginLeft: "auto",
          display: "flex",
          alignItems: "center",
          gap: 24,
          fontSize: 14,
          height: "100%",
        }}
      >
        <Link
          href="/enterprise/"
          style={{
            color: isEnterprise ? "var(--accent)" : "var(--text-dim)",
            fontWeight: isEnterprise ? 600 : 400,
            textDecoration: "none",
          }}
        >
          Enterprise
        </Link>
        <Link
          href="/docs/"
          style={{
            color: isDocs ? "var(--accent)" : "var(--text-dim)",
            fontWeight: isDocs ? 600 : 400,
            textDecoration: "none",
          }}
        >
          Docs
        </Link>
        <a
          href="https://github.com/AgentSteer/AgentSteer"
          style={{ color: "var(--text-dim)", textDecoration: "none" }}
        >
          GitHub
        </a>
        <Link
          href="/auth/"
          style={{
            color: "#fff",
            background: "var(--accent)",
            padding: "6px 16px",
            borderRadius: 6,
            fontWeight: 600,
            textDecoration: "none",
            fontSize: 13,
            lineHeight: 1.4,
          }}
        >
          Login
        </Link>
      </div>
    </nav>
  );
}
