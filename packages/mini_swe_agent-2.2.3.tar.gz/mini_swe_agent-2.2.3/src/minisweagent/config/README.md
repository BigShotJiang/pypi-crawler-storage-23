# Configs

* `mini.yaml` - Default config for `mini`/`agents/interactive.py` agent.
* `default.yaml` - Default config for the `default.py` agent.

## Benchmarks

* `benchmarks/swebench.yaml` - Config for the `run/benchmarks/swebench.py` entry point.
