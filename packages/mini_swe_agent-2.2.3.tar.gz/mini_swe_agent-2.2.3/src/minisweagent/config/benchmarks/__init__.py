"""Extra configuration files for mini-SWE-agent."""
