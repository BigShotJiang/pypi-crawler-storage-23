"""
Tests for the petal
"""
