from .mixin import ClassIngestMixin

__all__ = ["ClassIngestMixin"]
