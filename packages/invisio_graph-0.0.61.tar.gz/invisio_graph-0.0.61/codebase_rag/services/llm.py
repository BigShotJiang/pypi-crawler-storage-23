from __future__ import annotations

import asyncio
import random
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

from loguru import logger
from pydantic_ai import Agent, DeferredToolRequests, Tool
from pydantic_ai.exceptions import ModelHTTPError, UnexpectedModelBehavior
from pydantic_ai.models.groq import GroqModelSettings

from .. import constants as cs
from .. import exceptions as ex
from .. import logs as ls
from ..config import ModelConfig, settings
from ..prompts import (
    CYPHER_SYSTEM_PROMPT,
    LOCAL_CYPHER_SYSTEM_PROMPT,
    build_rag_orchestrator_prompt,
)
from ..providers.base import get_provider_from_config

if TYPE_CHECKING:
    from pydantic_ai.models import Model
    from pydantic_ai.settings import ModelSettings


def _create_provider_model(config: ModelConfig) -> Model:
    provider = get_provider_from_config(config)
    return provider.create_model(config.model_id)


def _is_rate_limit_error(error: Exception) -> bool:
    if isinstance(error, ModelHTTPError):
        return error.status_code == 429
    if isinstance(error, UnexpectedModelBehavior):
        message = str(error).lower()
        return "429" in message or "rate limit" in message or "too many requests" in message
    return False


def _build_model_settings(config: ModelConfig) -> ModelSettings | None:
    if config.provider != cs.Provider.GROQ:
        return None

    groq_settings: GroqModelSettings = {
        "parallel_tool_calls": bool(getattr(settings, "GROQ_PARALLEL_TOOL_CALLS", False)),
        "temperature": float(getattr(settings, "GROQ_TEMPERATURE", 0.0)),
    }

    max_tokens = getattr(settings, "GROQ_MAX_TOKENS", None)
    if max_tokens:
        groq_settings["max_tokens"] = int(max_tokens)

    return groq_settings


async def run_agent_with_rate_limit_retry[T](
    run_factory: Callable[[], Awaitable[T]],
    *,
    operation_name: str,
) -> T:
    max_retries = int(getattr(settings, "MODEL_RATE_LIMIT_RETRIES", 5))
    base_delay = float(getattr(settings, "MODEL_RATE_LIMIT_BASE_DELAY", 1.0))
    max_delay = float(getattr(settings, "MODEL_RATE_LIMIT_MAX_DELAY", 20.0))

    for attempt in range(max_retries + 1):
        try:
            return await run_factory()
        except Exception as e:
            if not _is_rate_limit_error(e) or attempt >= max_retries:
                raise

            delay = min(max_delay, base_delay * (2**attempt)) + random.uniform(0, 0.25)
            logger.warning(
                "Rate limited during {} (attempt {}/{}). Retrying in {:.2f}s.",
                operation_name,
                attempt + 1,
                max_retries + 1,
                delay,
            )
            await asyncio.sleep(delay)

    # Unreachable: loop either returns or raises, but mypy needs a final raise.
    raise RuntimeError("Rate-limit retry loop exited unexpectedly")


def _clean_cypher_response(response_text: str) -> str:
    query = response_text.strip().replace(cs.CYPHER_BACKTICK, "")
    if query.startswith(cs.CYPHER_PREFIX):
        query = query[len(cs.CYPHER_PREFIX) :].strip()
    if not query.endswith(cs.CYPHER_SEMICOLON):
        query += cs.CYPHER_SEMICOLON
    return query


class CypherGenerator:
    def __init__(self) -> None:
        try:
            config = settings.active_cypher_config
            llm = _create_provider_model(config)

            system_prompt = (
                LOCAL_CYPHER_SYSTEM_PROMPT
                if config.provider == cs.Provider.OLLAMA
                else CYPHER_SYSTEM_PROMPT
            )

            self.agent = Agent(
                model=llm,
                system_prompt=system_prompt,
                output_type=str,
                retries=settings.AGENT_RETRIES,
                model_settings=_build_model_settings(config),
            )
        except Exception as e:
            raise ex.LLMGenerationError(ex.LLM_INIT_CYPHER.format(error=e)) from e

    async def generate(self, natural_language_query: str) -> str:
        logger.info(ls.CYPHER_GENERATING.format(query=natural_language_query))
        try:
            result = await run_agent_with_rate_limit_retry(
                lambda: self.agent.run(natural_language_query),
                operation_name="cypher generation",
            )
            if (
                not isinstance(result.output, str)
                or cs.CYPHER_MATCH_KEYWORD not in result.output.upper()
            ):
                raise ex.LLMGenerationError(
                    ex.LLM_INVALID_QUERY.format(output=result.output)
                )

            query = _clean_cypher_response(result.output)
            logger.info(ls.CYPHER_GENERATED.format(query=query))
            return query
        except Exception as e:
            logger.error(ls.CYPHER_ERROR.format(error=e))
            raise ex.LLMGenerationError(ex.LLM_GENERATION_FAILED.format(error=e)) from e


def create_rag_orchestrator(tools: list[Tool]) -> Agent:
    try:
        config = settings.active_orchestrator_config
        llm = _create_provider_model(config)

        return Agent(
            model=llm,
            system_prompt=build_rag_orchestrator_prompt(tools),
            tools=tools,
            retries=settings.AGENT_RETRIES,
            output_retries=settings.ORCHESTRATOR_OUTPUT_RETRIES,
            output_type=[str, DeferredToolRequests],
            model_settings=_build_model_settings(config),
        )
    except Exception as e:
        raise ex.LLMGenerationError(ex.LLM_INIT_ORCHESTRATOR.format(error=e)) from e
