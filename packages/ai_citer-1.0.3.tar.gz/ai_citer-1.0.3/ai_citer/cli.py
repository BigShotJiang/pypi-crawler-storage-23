"""CLI entry point — `ai-citer serve` starts the FastAPI server."""
import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(prog="ai-citer")
    sub = parser.add_subparsers(dest="command")

    serve = sub.add_parser("serve", help="Start the HTTP API server")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=3001)
    serve.add_argument("--reload", action="store_true")

    sub.add_parser("mcp", help="Start the MCP stdio server")

    args = parser.parse_args()

    if args.command == "serve" or args.command is None:
        import uvicorn
        host = getattr(args, "host", "0.0.0.0")
        port = getattr(args, "port", 3001)
        reload = getattr(args, "reload", False)
        uvicorn.run("app.main:app", host=host, port=port, reload=reload)

    elif args.command == "mcp":
        import asyncio
        import importlib
        mcp_mod = importlib.import_module("mcp_server")
        asyncio.run(mcp_mod.main())

    else:
        parser.print_help()
        sys.exit(1)
