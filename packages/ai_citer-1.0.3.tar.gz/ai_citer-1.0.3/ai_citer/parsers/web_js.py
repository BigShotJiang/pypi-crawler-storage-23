from __future__ import annotations
from bs4 import BeautifulSoup
from ..models import DocumentContent, TextSegment


async def _launch_and_get_html(
    url: str,
    wait_for_selector: str | None,
    wait_ms: int,
) -> str:
    """Shared Playwright logic: launch browser, navigate, return rendered HTML."""
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise ImportError(
            "playwright is required for JS web fetching. "
            "Install it with: pip install 'ai-citer[js]' && playwright install chromium"
        )

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        try:
            page = await browser.new_page()
            await page.goto(url, wait_until="networkidle", timeout=60_000)

            if wait_for_selector:
                await page.wait_for_selector(wait_for_selector, timeout=30_000)

            if wait_ms:
                await page.wait_for_timeout(wait_ms)

            return await page.content()
        finally:
            await browser.close()


async def get_page_html_js(
    url: str,
    wait_for_selector: str | None = None,
    wait_ms: int = 0,
) -> str:
    """Fetch a URL using a headless Chromium browser and return the raw rendered HTML.

    Use this when you need the full rendered HTML of a JS SPA — for example, to
    extract ``<a href>`` links, parse tables, or navigate a JS-rendered site
    structure.  For plain text extraction, use :func:`parse_web_js` instead.

    Requires the ``js`` extra::

        pip install ai-citer[js]
        playwright install chromium

    Parameters
    ----------
    url:
        The URL to fetch.
    wait_for_selector:
        Optional CSS selector to wait for before capturing the HTML.
        Useful for pages that lazy-load content into a specific element.
    wait_ms:
        Additional milliseconds to wait after navigation / selector match.
        Use for pages that animate or defer content rendering.

    Returns
    -------
    str
        The fully rendered HTML of the page after JavaScript execution.

    Example
    -------
    .. code-block:: python

        from ai_citer import get_page_html_js
        from bs4 import BeautifulSoup

        html = await get_page_html_js(
            "https://etariff.ferc.gov/TariffBrowser.aspx?tid=1731",
            wait_ms=2000,
        )
        soup = BeautifulSoup(html, "html.parser")
        for a in soup.find_all("a", href=True):
            print(a["href"])
    """
    return await _launch_and_get_html(url, wait_for_selector, wait_ms)


async def parse_web_js(
    url: str,
    wait_for_selector: str | None = None,
    wait_ms: int = 0,
) -> tuple[str, DocumentContent]:
    """Fetch a URL using a headless Chromium browser (Playwright).

    Use this instead of ``parse_web`` when the target page requires JavaScript
    to render its content (SPAs, AJAX-loaded text, DevExpress portals, etc.).

    Requires the ``js`` extra::

        pip install ai-citer[js]
        playwright install chromium

    Parameters
    ----------
    url:
        The URL to fetch.
    wait_for_selector:
        Optional CSS selector to wait for before extracting text.
        Useful for pages that lazy-load content into a specific element.
    wait_ms:
        Additional milliseconds to wait after navigation / selector match.
        Use for pages that animate or defer content rendering.
    """
    html = await _launch_and_get_html(url, wait_for_selector, wait_ms)
    soup = BeautifulSoup(html, "html.parser")

    title_tag = soup.find("title")
    title = title_tag.get_text().strip() if title_tag else url

    for tag in soup(["script", "style", "noscript", "nav", "footer", "header"]):
        tag.decompose()

    text_parts: list[str] = []
    for el in soup.find_all(["p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "td"]):
        text = el.get_text().strip()
        if text:
            text_parts.append(text)

    segments: list[TextSegment] = []
    raw_text = ""
    for text in text_parts:
        segments.append(TextSegment(text=text, charOffset=len(raw_text)))
        raw_text += text + "\n\n"

    return title, DocumentContent(rawText=raw_text.rstrip(), segments=segments)
