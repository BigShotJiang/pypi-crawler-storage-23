from ..models import DocumentContent, TextSegment


def parse_text(content: str, doc_type: str = "text") -> DocumentContent:
    paragraphs = content.split("\n\n") if "\n\n" in content else content.split("\n")
    segments: list[TextSegment] = []
    char_offset = 0

    for paragraph in paragraphs:
        trimmed = paragraph.strip()
        if not trimmed:
            idx = content.find(paragraph, char_offset)
            if idx >= 0:
                char_offset = idx + len(paragraph)
            continue

        idx = content.find(trimmed, char_offset)
        if idx >= 0:
            segments.append(TextSegment(text=trimmed, charOffset=idx))
            char_offset = idx + len(trimmed)

    return DocumentContent(rawText=content, segments=segments)
