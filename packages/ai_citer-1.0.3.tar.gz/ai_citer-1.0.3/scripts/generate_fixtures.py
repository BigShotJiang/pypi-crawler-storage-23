"""
Regenerate Claude-generated fact extraction fixtures for pytest accuracy tests.

Usage (from server/ directory):
    python scripts/generate_fixtures.py
"""
from __future__ import annotations
import asyncio
import json
import sys
from pathlib import Path

# Allow running from the server/ directory
sys.path.insert(0, str(Path(__file__).parent.parent))

import anthropic

from ai_citer.config import settings
from ai_citer.ai.claude import extract_facts

FIXTURES_DIR = Path(__file__).parent.parent / "tests" / "fixtures"

FIXTURE_PAIRS = [
    ("article.txt", "article-facts.json"),
    ("policy.txt", "policy-facts.json"),
]


async def generate() -> None:
    client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)

    for txt_file, json_file in FIXTURE_PAIRS:
        txt_path = FIXTURES_DIR / txt_file
        json_path = FIXTURES_DIR / json_file

        if not txt_path.exists():
            print(f"Skipping {txt_file} — file not found")
            continue

        text = txt_path.read_text(encoding="utf-8")
        print(f"Extracting facts from {txt_file}…")

        extraction, usage = await extract_facts(client, text)

        facts_data = [
            {
                "fact": f.fact,
                "citations": [{"exact_quote": c.exact_quote} for c in f.citations],
            }
            for f in extraction.facts
        ]

        json_path.write_text(json.dumps(facts_data, indent=2), encoding="utf-8")
        print(f"  → {len(facts_data)} facts written to {json_file}")
        print(f"  → tokens: {usage.inputTokens} in / {usage.outputTokens} out / ${usage.costUsd:.4f}")

    print("Done.")


if __name__ == "__main__":
    asyncio.run(generate())
