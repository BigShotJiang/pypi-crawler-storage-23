---
tags:
  category: system
  context: tag-value
---
# status: `withdrawn`

Cancelled by the originator. The speaker retracts their commitment, request, or offer. Terminal state — no further action expected.

## Prompt

The speaker took back their own commitment or request. Look for "never mind", "changed my mind", "cancelled", "retracted".
