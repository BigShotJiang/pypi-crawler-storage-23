# Copyright (c) Metis. All rights reserved.

"""Credential redaction utilities for safe logging."""

from __future__ import annotations

from urllib.parse import urlparse, urlunparse


def redact_url(url: str) -> str:
    """Mask password in URLs like redis://:secret@host:port.

    Returns the URL with the password replaced by asterisks.
    If no password is present, returns the URL unchanged.
    """
    parsed = urlparse(url)
    if parsed.password:
        netloc = f":{('*' * 8)}@{parsed.hostname}"
        if parsed.port:
            netloc += f":{parsed.port}"
        return urlunparse(parsed._replace(netloc=netloc))
    return url
