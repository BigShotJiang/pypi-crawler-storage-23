# Copyright (c) Metis. All rights reserved.

"""Platform utilities for Mantis agent registration, algorithm compatibility, and orchestration."""

from mantisdk.platform.compatibility import compute_compatible_algorithms
from mantisdk.platform.manifest import AgentManifest, TaskSchema, parse_manifest
from mantisdk.platform.registry import discover_algorithms, get_algorithm_by_name, list_algorithms

__all__ = [
    "AgentManifest",
    "TaskSchema",
    "parse_manifest",
    "compute_compatible_algorithms",
    "discover_algorithms",
    "get_algorithm_by_name",
    "list_algorithms",
]
