# Copyright (c) Metis. All rights reserved.

"""Span processors for MantisDK tracing.

This module provides SpanProcessor implementations that inject context
into spans automatically. The TracingContextSpanProcessor reads from
context variables and injects attributes into every span.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, SpanProcessor
from opentelemetry.trace import Span

from . import semconv

logger = logging.getLogger(__name__)


class TracingContextSpanProcessor(SpanProcessor):
    """Injects all tracing context into spans automatically.

    This processor runs on every span creation and injects context from:

    1. Run module (run_id, session_id from current run/rollout)
    2. Context module (call_type, tags, environment)

    Attributes injected:
        - insight.run.id: Current run ID (from mantisdk.run)
        - insight.run.name: Current run name (from mantisdk.run)
        - insight.session.id: Current rollout session ID (from mantisdk.run)
        - mantis.call_type: Call type (e.g., "agent-call", "judge-call")
        - insight.trace.tags: JSON-encoded list of tags
        - insight.environment: Environment name

    Example::

        from opentelemetry.sdk.trace import TracerProvider
        from mantisdk.tracing.processors import TracingContextSpanProcessor

        provider = TracerProvider()
        provider.add_span_processor(TracingContextSpanProcessor())

        # All spans will now have context injected automatically
    """

    def on_start(
        self, span: Span, parent_context: Optional[Context] = None
    ) -> None:
        """Called when a span is started.

        Injects context attributes from run module and context module.
        Failures are logged at debug level and do not raise exceptions.
        """
        if not span.is_recording():
            return

        try:
            self._inject_run_context(span)
        except ImportError:
            # run module not available, skip run context injection
            pass
        except Exception as e:
            logger.debug(f"Could not inject run context: {e}")

        try:
            self._inject_tracing_context(span)
        except ImportError:
            # context module not available, skip tracing context injection
            pass
        except Exception as e:
            logger.debug(f"Could not inject tracing context: {e}")

    def _inject_run_context(self, span: Span) -> None:
        """Inject run and rollout context into span."""
        from mantisdk.run import get_current_rollout, get_current_run

        # Run context
        current_run = get_current_run()
        if current_run is not None:
            if current_run.id:
                span.set_attribute(semconv.RUN_ID, current_run.id)
            if current_run.name:
                span.set_attribute(semconv.RUN_NAME, current_run.name)

        # Rollout context -> session_id + trace_id capture
        current_rollout = get_current_rollout()
        if current_rollout is not None and current_rollout.session_id:
            span.set_attribute(semconv.SESSION_ID, current_rollout.session_id)

            # Capture the trace_id from this span onto the Rollout so that
            # rollout.score() can link scores to the correct trace even
            # after instrumented spans have ended.
            span_context = span.get_span_context()
            if span_context and span_context.is_valid:
                trace_id_hex = format(span_context.trace_id, "032x")
                current_rollout._capture_trace_id(trace_id_hex)
        else:
            # Fallback: proxy-specific session (set by RolloutAttemptMiddleware)
            from .context import get_proxy_session_id

            proxy_session = get_proxy_session_id()
            if proxy_session:
                span.set_attribute(semconv.SESSION_ID, proxy_session)

    def _inject_tracing_context(self, span: Span) -> None:
        """Inject call_type, tags, and environment context into span."""
        from .context import (
            get_current_call_type,
            get_current_environment,
            get_current_tags,
        )

        # Call type (from @gepa.agent, @gepa.judge, etc.)
        call_type = get_current_call_type()
        if call_type:
            span.set_attribute("mantis.call_type", call_type)

        # Tags
        tags = get_current_tags()
        if tags:
            span.set_attribute(semconv.TRACE_TAGS, json.dumps(tags))

        # Environment
        environment = get_current_environment()
        if environment:
            span.set_attribute(semconv.ENVIRONMENT, environment)

    def on_end(self, span: ReadableSpan) -> None:
        """Called when a span is ended. No-op for this processor."""
        pass

    def shutdown(self) -> None:
        """Called when the TracerProvider is shut down. No-op for this processor."""
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush any buffered data. Always returns True for this processor."""
        return True


class AnnotationFilterSpanProcessor(SpanProcessor):
    """Wraps another SpanProcessor, filtering out mantisdk.annotation spans.

    Reward annotations are internal to mantisdk (used by the store's
    ``find_final_reward()``). They are also sent as proper Langfuse Scores
    via the API by ``InsightRunListener``. Exporting them as OTLP traces
    creates noise (null input, undefined output) without adding value.

    This processor drops ``mantisdk.annotation`` spans before they reach the
    wrapped exporter while letting all other spans pass through.

    Example::

        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from mantisdk.tracing.processors import AnnotationFilterSpanProcessor

        inner = BatchSpanProcessor(exporter)
        filtered = AnnotationFilterSpanProcessor(inner)
        provider.add_span_processor(filtered)
    """

    _FILTERED_NAME = "mantisdk.annotation"

    def __init__(self, inner: SpanProcessor) -> None:
        self._inner = inner

    def on_start(
        self, span: Span, parent_context: Optional[Context] = None
    ) -> None:
        self._inner.on_start(span, parent_context)

    def on_end(self, span: ReadableSpan) -> None:
        if span.name == self._FILTERED_NAME:
            return  # Drop reward annotation spans from OTLP export
        self._inner.on_end(span)

    def shutdown(self) -> None:
        self._inner.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._inner.force_flush(timeout_millis)
