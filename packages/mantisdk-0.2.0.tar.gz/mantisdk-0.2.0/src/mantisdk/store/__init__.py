# Copyright (c) Microsoft. All rights reserved.

from .base import LightningStore, LightningStoreCapabilities, LightningStoreStatistics
from .client_server import LightningStoreClient, LightningStoreServer
from .collection_based import CollectionBasedLightningStore
from .insight import (
    InsightLightningStore,
    InsightTracker,
    create_platform_store_client_from_env,
    create_platform_store_from_env,  # Deprecated, kept for backward compat
)
from .insight_listener import InsightRunListener
from .listener import StorageListener
from .memory import InMemoryLightningStore
from .threading import LightningStoreThreaded

# RedisStreamLightningStore is deprecated but kept importable for backward compat.
# Import lazily to avoid requiring redis as a hard dependency.
try:
    from .redis_stream import RedisStreamLightningStore
except ImportError:
    pass

# Deprecated alias kept for backward compat
try:
    from .insight import RedisStreamInsightLightningStore
except ImportError:
    pass

__all__ = [
    "LightningStore",
    "LightningStoreCapabilities",
    "LightningStoreStatistics",
    "LightningStoreClient",
    "LightningStoreServer",
    "InMemoryLightningStore",
    "InsightLightningStore",
    "InsightTracker",  # Deprecated
    "InsightRunListener",
    "StorageListener",
    "CollectionBasedLightningStore",
    "LightningStoreThreaded",
    "create_platform_store_client_from_env",
    "create_platform_store_from_env",  # Deprecated
]
