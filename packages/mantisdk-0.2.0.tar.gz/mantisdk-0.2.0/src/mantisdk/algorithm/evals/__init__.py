# Copyright (c) Metis. All rights reserved.

"""Evals algorithm — single-pass agent evaluation."""

from .evals import Evals

__all__ = ["Evals"]
