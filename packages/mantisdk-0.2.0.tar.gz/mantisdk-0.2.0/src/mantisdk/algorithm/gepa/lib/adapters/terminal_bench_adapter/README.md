### Terminal-bench adapter

This adapter is used to optimize the system prompt/terminal-use instruction for the default Terminus agent through custom a `GEPAAdapter` implementation.

To run this example, you need to install `pip install terminal-bench` and run the following command:

```bash
python src/gepa/examples/terminal-bench/train_terminus.py --model_name=gpt-5-mini
```