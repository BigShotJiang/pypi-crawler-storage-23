"""
Unified command orchestrator for deduplication.
This is the SINGLE source of truth for business logic — used by both GUI and CLI.
No Qt/PySide6 dependencies — pure Python.
"""
import time
from typing import List, Optional, Callable, Tuple
from onlyone.core.models import DuplicateGroup, DeduplicationStats, DeduplicationParams, File
from onlyone.core.scanner import FileScanner
from onlyone.core.deduplicator import Deduplicator

import logging
logger = logging.getLogger(__name__)

class DeduplicationCommand:
    """
    Orchestrates the entire deduplication workflow:
    1. Initialize app with root directory
    2. Set favourite directories
    3. Execute find_duplicates with progress/cancellation support

    Usage:
        # For GUI (with progress UI updates):
        params = DeduplicationParams(...)
        command = DeduplicationCommand()
        groups, stats = command.execute(
            params,
            progress_callback=qt_progress_adapter,
            stopped_flag=qt_cancellation_check
        )

        # For CLI (with console progress):
        groups, stats = command.execute(
            params,
            progress_callback=cli_progress_printer,
            stopped_flag=signal_handler_check
        )
    """

    def __init__(self):
        self._deduplicator = Deduplicator()
        self._files: List[File] = []  # Local state storage (not in app/api layer)

    def execute(
            self,
            params: DeduplicationParams,
            progress_callback: Optional[Callable[[str, int, Optional[int]], None]] = None,
            stopped_flag: Optional[Callable[[], bool]] = None
    ) -> Tuple[List[DuplicateGroup], DeduplicationStats]:
        """
        Execute deduplication with given parameters.

        Args:
            params: Validated deduplication parameters
            progress_callback: (stage: str, current: int, total: Optional[int]) -> None
            stopped_flag: () -> bool (returns True if operation should stop)

        Returns:
            Tuple of (duplicate_groups, statistics)

        Raises:
            ValueError: If parameters are invalid
            RuntimeError: If scanning/deduplication fails
        """
        # Step 1: Scan files using core scanner directly
        scanner = FileScanner(params=params)

        # Measure scanning time
        scan_start = time.time()
        self._files = scanner.scan(
            stopped_flag=stopped_flag,
            progress_callback=progress_callback
        )
        scan_duration = time.time() - scan_start

        if not self._files:
            logger.warning("No files found matching filters")
            raise RuntimeError("No files found matching filters")

        # Step 2: Find duplicates using core onlyone directly
        groups, stats = self._deduplicator.find_duplicates(
            self._files,
            params,  # Unified params object with sort_order, mode, etc.
            stopped_flag=stopped_flag,
            progress_callback=progress_callback
        )

        # Update statistics with scanning time
        stats.scan_time = scan_duration
        stats.total_time = scan_duration + stats.grouping_time

        return groups, stats

    def get_files(self) -> List[File]:
        """Get scanned files after execution."""
        return self._files.copy()  # Return copy to prevent external mutation