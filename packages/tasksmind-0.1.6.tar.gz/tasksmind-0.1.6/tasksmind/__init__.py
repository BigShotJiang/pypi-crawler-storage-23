"""
TasksMind Python SDK
====================

The AI Engineer for Developers on Call.

Quick start::

    import os
    from tasksmind import TasksMind

    client = TasksMind(api_key=os.environ["TASKSMIND_API_KEY"])

    # Create a run
    run = client.runs.create(
        repo_url="https://github.com/my-org/my-repo",
        repo_ref="main",
        payload={"intent": "review_pr", "target": {"pr_number": 42}},
    )

    # Wait for it to finish
    result = client.runs.wait(run.id, timeout_s=600)
    if result.is_success():
        print(result.output)
"""

from __future__ import annotations

import os
from typing import Optional

from ._http import HTTPClient, _DEFAULT_BASE_URL, _DEFAULT_TIMEOUT
from .exceptions import APIError, AuthError, NotFoundError, RateLimitError, TasksMindError, TimeoutError
from .resources import Run, RunsResource

__version__ = "0.1.6"
__all__ = [
    "TasksMind",
    "Run",
    # Exceptions
    "TasksMindError",
    "AuthError",
    "NotFoundError",
    "APIError",
    "RateLimitError",
    "TimeoutError",
]


class TasksMind:
    """
    TasksMind API client.

    Args:
        api_key: Your TasksMind API key. Falls back to the ``TASKSMIND_API_KEY``
            environment variable when not provided.
        base_url: Override the API base URL. Defaults to ``https://api.tasksmind.com``.
            Can also be set via the ``TASKSMIND_API_BASE_URL`` environment variable.
        timeout: HTTP request timeout in seconds (default: 60).

    Raises:
        :exc:`ValueError`: If no API key is provided and ``TASKSMIND_API_KEY`` is not set.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        resolved_key = api_key or os.environ.get("TASKSMIND_API_KEY", "")
        if not resolved_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the TASKSMIND_API_KEY environment variable."
            )
        resolved_base = (
            base_url
            or os.environ.get("TASKSMIND_API_BASE_URL", "")
            or _DEFAULT_BASE_URL
        )
        self._http = HTTPClient(api_key=resolved_key, base_url=resolved_base, timeout=timeout)
        self.runs = RunsResource(self._http)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "TasksMind":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"TasksMind(base_url={self._http._base_url!r})"
