"""
tasksmind CLI — run tasks against the TasksMind API from your terminal.

Usage:
    tasksmind run "add a /ping endpoint" --repo https://github.com/org/repo
    tasksmind run "review PR #42"         --repo https://github.com/org/repo --intent review_pr --pr 42
    tasksmind run "fix CI on PR 7"        --repo https://github.com/org/repo --intent fix_ci --pr 7
    tasksmind status <run-id>
    tasksmind logs <run-id>
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from typing import Optional


_SPINNER = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

_INTENT_LABELS = {
    "implement_feature": "implement feature",
    "review_pr":         "review PR",
    "fix_ci":            "fix CI",
    "fix_bug":           "fix bug",
    "summarize_repo":    "summarize repo",
    "root_cause":        "root cause analysis",
}

_STATUS_LABELS = {
    "queued":      "queued",
    "running":     "running",
    "analyzing":   "analyzing",
    "planning":    "planning",
    "executing":   "executing",
    "creating_pr": "opening PR",
    "completed":   "done",
    "succeeded":   "done",
    "failed":      "failed",
    "error":       "error",
    "cancelled":   "cancelled",
}


def _client():
    from . import TasksMind
    return TasksMind()


def _elapsed(seconds: float) -> str:
    if seconds < 60:
        return f"{int(seconds)}s"
    return f"{int(seconds // 60)}m{int(seconds % 60)}s"


def cmd_run(args: argparse.Namespace) -> int:
    from .exceptions import TasksMindError

    # Validate everything upfront before printing or hitting the network.
    if not os.environ.get("TASKSMIND_API_KEY"):
        print("error: TASKSMIND_API_KEY is not set", file=sys.stderr)
        return 1

    repo_url = args.repo or os.environ.get("TASKSMIND_REPO", "")
    if not repo_url:
        print("error: --repo is required (or set TASKSMIND_REPO)", file=sys.stderr)
        return 1

    if args.intent == "review_pr" and not args.pr:
        print("error: --pr NUMBER is required when using --intent review_pr", file=sys.stderr)
        return 1

    payload: dict = {"raw_text": args.description, "intent": args.intent}
    if args.intent == "review_pr":
        payload["target"] = {"pr_number": int(args.pr)}
    elif args.intent == "fix_ci":
        payload["target"] = {"branch": args.ref, **({"pr_number": int(args.pr)} if args.pr else {})}
    elif args.intent == "implement_feature":
        payload["target"] = {"feature": args.description}

    label = _INTENT_LABELS.get(args.intent, args.intent)
    print(f"  {label}: {args.description!r}")
    print(f"  repo:   {repo_url}  [{args.ref}]")

    try:
        client = _client()
        run = client.runs.create(
            repo_url=repo_url,
            repo_ref=args.ref,
            payload=payload,
        )
    except (TasksMindError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print(f"  run:    {run.id}")
    if args.no_wait:
        print(f"\nRun queued. Check status with:\n  tasksmind status {run.id}")
        return 0

    print()  # blank line before spinner
    start = time.monotonic()
    spin = 0
    terminal = {"completed", "succeeded", "failed", "error", "cancelled"}
    last_status = ""

    try:
        while True:
            run = client.runs.get(run.id)
            elapsed = _elapsed(time.monotonic() - start)
            status_label = _STATUS_LABELS.get(run.status, run.status)

            if run.status in terminal:
                print(f"\r  {status_label:<16} [{elapsed}]")
                break

            if run.status != last_status:
                last_status = run.status

            spin_char = _SPINNER[spin % len(_SPINNER)]
            print(f"\r{spin_char} {status_label:<16} [{elapsed}]", end="", flush=True)
            spin += 1
            time.sleep(2)
    except KeyboardInterrupt:
        print(f"\n\nInterrupted — run is still executing in the background: {run.id}")
        print(f"  tasksmind status {run.id}")
        return 1

    if run.is_success():
        elapsed_total = _elapsed(time.monotonic() - start)
        print(f"\nCompleted in {elapsed_total}")
        if run.pr_url:
            print(f"\n  PR:  {run.pr_url}")
        if run.output:
            print(f"\n{run.output}")
        return 0
    else:
        err = run.error or run.output or "unknown error"
        print(f"\nFailed: {err}", file=sys.stderr)
        return 1


def cmd_status(args: argparse.Namespace) -> int:
    from .exceptions import TasksMindError
    try:
        run = _client().runs.get(args.run_id)
    except TasksMindError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print(f"id:      {run.id}")
    print(f"status:  {run.status}")
    if run.pr_url:
        print(f"pr:      {run.pr_url}")
    if run.error:
        print(f"error:   {run.error}")
    if run.output:
        print(f"\noutput:\n{run.output}")
    return 0


def cmd_logs(args: argparse.Namespace) -> int:
    from .exceptions import TasksMindError
    try:
        run = _client().runs.get(args.run_id)
    except TasksMindError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if run.error:
        print(f"[error]\n{run.error}")
    if run.output:
        print(f"[output]\n{run.output}")
    if not run.error and not run.output:
        print(f"No output yet. Status: {run.status}")
    return 0


def main(argv: Optional[list] = None) -> None:
    parser = argparse.ArgumentParser(
        prog="tasksmind",
        description="The AI Engineer for Developers on Call.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""examples:
  tasksmind run "add a /health endpoint"   --repo https://github.com/org/repo
  tasksmind run "review this PR"           --repo https://github.com/org/repo --intent review_pr --pr 42
  tasksmind run "fix failing tests on CI"  --repo https://github.com/org/repo --intent fix_ci --pr 42
  tasksmind run "why is prod OOMing"       --repo https://github.com/org/repo --intent root_cause
  tasksmind status <run-id>
  tasksmind logs   <run-id>

environment:
  TASKSMIND_API_KEY   your API key (required)
  TASKSMIND_REPO      default repo URL (avoids passing --repo every time)
""",
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    # tasksmind run
    p_run = sub.add_parser("run", help="Start a new run")
    p_run.add_argument("description", help='What to do, e.g. "add a /ping endpoint"')
    p_run.add_argument("--repo", metavar="URL",
                       help="GitHub repo URL (or set TASKSMIND_REPO env var)")
    p_run.add_argument("--ref", default="main", metavar="BRANCH",
                       help="Branch / ref to target (default: main)")
    p_run.add_argument("--intent", default="implement_feature",
                       choices=["implement_feature", "review_pr", "fix_ci",
                                "fix_bug", "summarize_repo", "root_cause"],
                       help="What kind of task to run (default: implement_feature)")
    p_run.add_argument("--pr", metavar="NUMBER",
                       help="PR number — required for review_pr, optional for fix_ci")
    p_run.add_argument("--no-wait", action="store_true",
                       help="Print run ID and exit without waiting for completion")

    # tasksmind status
    p_status = sub.add_parser("status", help="Get the status of a run")
    p_status.add_argument("run_id", metavar="RUN_ID")

    # tasksmind logs
    p_logs = sub.add_parser("logs", help="Print output / error of a run")
    p_logs.add_argument("run_id", metavar="RUN_ID")

    args = parser.parse_args(argv)

    if args.command == "run":
        sys.exit(cmd_run(args))
    elif args.command == "status":
        sys.exit(cmd_status(args))
    elif args.command == "logs":
        sys.exit(cmd_logs(args))
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
