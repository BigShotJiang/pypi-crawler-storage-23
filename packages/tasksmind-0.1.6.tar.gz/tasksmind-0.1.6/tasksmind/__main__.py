from tasksmind._cli import main

main()
