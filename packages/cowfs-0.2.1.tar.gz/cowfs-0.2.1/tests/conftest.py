"""Shared test fixtures for COWFS tests."""
