"""COWFS — Copy-on-Write Filesystem."""

__version__ = "0.1.0"
