from setuptools import setup, find_packages

setup(
    name="disposable-exec",
    version="0.1.0",
    description="Sandbox runtime for executing AI-generated Python code",
    author="Your Name",
    packages=find_packages(),
    install_requires=[
        "requests",
        "fastapi",
        "uvicorn"
    ],
    python_requires=">=3.9",
)