from fastapi import FastAPI
import subprocess
import tempfile
import os

app = FastAPI()

@app.post("/run")
def run_code(data: dict):

    code = data["script"]

    with tempfile.NamedTemporaryFile(delete=False, suffix=".py") as f:
        f.write(code.encode())
        path = f.name

    try:

        result = subprocess.run(
            ["python", path],
            capture_output=True,
            text=True,
            timeout=10
        )

        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "exit_code": result.returncode
        }

    finally:
        os.remove(path)