import re

from labels.model.package import Ecosystem


def format_exception(exc: str) -> str:
    return re.sub(r"^\s*For further information.*(?:\n|$)", "", exc, flags=re.MULTILINE)


def normalize_python_package_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name)


def normalize_name(name: str, ecosystem: Ecosystem) -> str:
    if ecosystem == Ecosystem.NUGET:
        return name.lower()

    if ecosystem == Ecosystem.PYPI:
        return normalize_python_package_name(name.lower())

    return name
