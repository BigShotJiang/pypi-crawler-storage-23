def format_ruby_version_constraints(constraints: list[str]) -> str:
    if not constraints:
        return ""

    cleaned = [c.replace(" ", "") for c in constraints]
    first = cleaned[0]

    if "~>" not in first:
        return first if len(cleaned) == 1 else " ".join(cleaned)

    if len(cleaned) == 1:
        return first.replace("~>", "^" if first.count(".") <= 1 else "~")

    pessimistic_version = _format_pessimistic_with_bound(first, cleaned[1])

    return pessimistic_version if pessimistic_version else " ".join(cleaned)


def _format_pessimistic_with_bound(pessimistic: str, bound: str) -> str:
    if ">=" in bound:
        return bound.replace(">=", "^")
    if "!=" in bound:
        first_ver = pessimistic.replace("~>", "")
        second_ver = bound.replace("!=", "")
        return f">={first_ver} <{second_ver} || >{second_ver}"
    return ""
