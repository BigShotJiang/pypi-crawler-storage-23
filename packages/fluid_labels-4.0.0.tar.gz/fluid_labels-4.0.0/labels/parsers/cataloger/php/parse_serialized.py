import phpserialize

from labels.model.file import LocationReadCloser
from labels.model.package import Package
from labels.model.package_manager import PackageManager
from labels.model.relationship import Relationship
from labels.model.release import Environment
from labels.model.resolver import Resolver
from labels.parsers.cataloger.php.package_builder import new_package_from_pecl
from labels.parsers.cataloger.utils import get_enriched_location


def parse_pecl_serialized(
    _resolver: Resolver | None,
    _environment: Environment | None,
    reader: LocationReadCloser,
) -> tuple[list[Package], list[Relationship]]:
    unserialized_data = phpserialize.loads(reader.read_closer.read().encode(), decode_strings=True)

    packages = _collect_packages(unserialized_data, reader)

    return packages, []


def _collect_packages(
    unserialized_data: dict[str, object], reader: LocationReadCloser
) -> list[Package]:
    packages: list[Package] = []

    name = str(unserialized_data.get("name", "")) or None

    version_data = unserialized_data.get("version")
    version = (
        (str(version_data.get("release", "")) or None) if isinstance(version_data, dict) else None
    )

    new_location = get_enriched_location(
        reader.location,
        package_manager=PackageManager.COMPOSER,
    )

    package = new_package_from_pecl(name=name, version=version, location=new_location)
    if package:
        packages.append(package)

    return packages
