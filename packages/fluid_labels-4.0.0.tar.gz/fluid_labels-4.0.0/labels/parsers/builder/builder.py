from collections.abc import Callable

from labels.model.package import Ecosystem, Package
from labels.model.syft_sbom import SyftArtifact
from labels.parsers.builder.alpine.builder_apk import builder as builder_apk_pkg
from labels.parsers.builder.arch.builder_alpm import builder as builder_alpm_pkg
from labels.parsers.builder.debian.builder_deb import builder as builder_deb_pkg
from labels.parsers.builder.generic_builder import builder as generic_builder
from labels.parsers.builder.java.builder_java import builder as builder_java_pkg
from labels.parsers.builder.python.builder_python import builder as builder_python_pkg
from labels.parsers.builder.redhat.builder_rpm import builder as builder_rpmdb_pkg

BUILDERS: dict[Ecosystem, Callable[[SyftArtifact, Ecosystem], Package | None]] = {
    Ecosystem.DEBIAN: builder_deb_pkg,
    Ecosystem.ALPINE: builder_apk_pkg,
    Ecosystem.ALPM: builder_alpm_pkg,
    Ecosystem.RPM: builder_rpmdb_pkg,
    Ecosystem.PYPI: builder_python_pkg,
    Ecosystem.MAVEN: builder_java_pkg,
    Ecosystem.NPM: generic_builder,
    Ecosystem.NUGET: generic_builder,
    Ecosystem.RUBYGEMS: generic_builder,
    Ecosystem.PACKAGIST: generic_builder,
    Ecosystem.PUB: generic_builder,
    Ecosystem.SWIFTURL: generic_builder,
}


def build_package(
    artifact: SyftArtifact,
    ecosystem: Ecosystem,
) -> Package | None:
    if builder := BUILDERS.get(ecosystem):
        return builder(artifact, ecosystem)
    return None
