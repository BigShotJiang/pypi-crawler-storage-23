from enum import StrEnum


class PackageManager(StrEnum):
    UNKNOWN = "unknown"
    PIP = "pip"
    POETRY = "poetry"
    PIPENV = "pipenv"
    UV = "uv"
    NPM = "npm"
    YARN = "yarn"
    PNPM = "pnpm"
    BUN = "bun"
    MAVEN = "maven"
    GRADLE = "gradle"
    SBT = "sbt"
    BUNDLER = "bundler"
    COMPOSER = "composer"
    COCOAPODS = "cocoapods"
    SWIFT_PM = "swift_pm"
    GO_MOD = "go_mod"
    NUGET = "nuget"
    PUB = "pub"
