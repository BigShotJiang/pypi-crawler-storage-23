"""Async HTTP client for the Prodigy REST API."""

from __future__ import annotations

import logging
from typing import Any

import anyio
import httpx

logger = logging.getLogger(__name__)

MAX_RETRIES = 5


class ProdigyClient:
    """Async wrapper around a Prodigy annotation server."""

    def __init__(self, base_url: str, session: str):
        self.base_url = base_url.rstrip("/")
        self.session = session
        self.http = httpx.AsyncClient(base_url=self.base_url, timeout=30)

    async def aclose(self) -> None:
        await self.http.aclose()

    async def __aenter__(self) -> ProdigyClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def get_config(self) -> dict[str, Any]:
        """Fetch the project config from the Prodigy server."""
        resp = await self.http.get("/project")
        resp.raise_for_status()
        return resp.json()

    async def get_tasks(self) -> tuple[list[dict[str, Any]], float]:
        """Fetch the next batch of tasks. Returns (tasks, progress)."""
        resp = await self.http.post(
            "/get_session_questions",
            json={"session_id": self.session},
        )
        resp.raise_for_status()
        data = resp.json()
        progress = data.get("progress")
        return data["tasks"], progress if progress is not None else 0.0

    async def submit_answers(self, answers: list[dict[str, Any]]) -> float:
        """Submit annotated answers with retry logic. Returns progress."""
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                resp = await self.http.post(
                    "/give_answers",
                    json={"answers": answers},
                )
                resp.raise_for_status()
                progress = resp.json().get("progress")
                return progress if progress is not None else 0.0
            except httpx.HTTPError:
                logger.warning(
                    "Submit attempt %d/%d failed",
                    attempt,
                    MAX_RETRIES,
                    exc_info=True,
                )
                await anyio.sleep(attempt)
        logger.error("Submit failed after %d retries — dropping batch.", MAX_RETRIES)
        return 0.0
