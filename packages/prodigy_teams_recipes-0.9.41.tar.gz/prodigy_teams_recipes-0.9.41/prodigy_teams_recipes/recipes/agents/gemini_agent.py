"""Gemini annotation agent recipe."""

import logging
from functools import partial

import anyio
from prodigy_teams_recipes_sdk import (
    FloatProps,
    IntProps,
    Secret,
    TextProps,
    agent_recipe,
)
from prodigy_teams_recipes_sdk.prodigy_teams_pam_sdk.recipe_client import Settings

from .event_loop import run
from .llm import Gemini


@agent_recipe(
    title="Gemini Annotation Agent",
    description="Autonomous annotation agent powered by Google Gemini",
    field_props={
        "model": TextProps(title="Gemini model name"),
        "poll_interval": FloatProps(title="Poll interval (seconds)", min=0.1),
        "thinking_budget": IntProps(title="Thinking token budget (0 = off)", min=0),
    },
)
def gemini_agent(
    *,
    api_key: Secret,
    model: str = "gemini-2.0-flash",
    poll_interval: float = 1.0,
    thinking_budget: int = 0,
) -> None:
    settings = Settings()
    session = f"agent-{settings.job_id}"
    gemini_key = api_key.get_secret_value("GEMINI_API_KEY")
    llm = Gemini(api_key=gemini_key, model_name=model, thinking=thinking_budget)
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
    )
    anyio.run(partial(run, llm, poll_interval, session))
