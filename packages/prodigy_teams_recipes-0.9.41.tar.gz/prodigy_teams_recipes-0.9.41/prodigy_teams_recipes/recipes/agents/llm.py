"""LLM connection abstraction with async interface."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod

import httpx
from anyio.to_thread import run_sync
from google import genai
from google.genai import errors as genai_errors
from google.genai import types as genai_types

logger = logging.getLogger(__name__)


class LLMError(Exception):
    """An LLM request failed (network, rate limit, empty/blocked response)."""


class LLM(ABC):
    """Abstract base for async LLM connections."""

    model_name: str

    @abstractmethod
    async def ask(self, prompt: str) -> str: ...


class Gemini(LLM):
    """Google Gemini LLM connection."""

    def __init__(
        self,
        api_key: str,
        model_name: str = "gemini-2.0-flash",
        thinking: int = 0,
    ):
        self.client = genai.Client(api_key=api_key)
        self.model_name = model_name
        self.thinking_budget = thinking

    async def ask(self, prompt: str) -> str:
        return await run_sync(self._request, prompt)

    def _request(self, prompt: str) -> str:
        config: genai_types.GenerateContentConfig | None = None
        if self.thinking_budget:
            config = genai_types.GenerateContentConfig(
                thinking_config=genai_types.ThinkingConfig(
                    include_thoughts=True,
                    thinking_budget=self.thinking_budget,
                )
            )
        try:
            response = self.client.models.generate_content(
                model=self.model_name, contents=prompt, config=config
            )
        except (
            genai_errors.ClientError,
            genai_errors.ServerError,
            httpx.HTTPError,
        ) as exc:
            raise LLMError(str(exc)) from exc
        if response.text is None:
            raise LLMError("Gemini returned an empty response")
        return response.text
