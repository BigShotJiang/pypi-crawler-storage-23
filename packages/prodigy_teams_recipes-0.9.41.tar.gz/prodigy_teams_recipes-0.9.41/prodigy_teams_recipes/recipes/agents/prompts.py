"""Task-type detection, prompt formatting, and LLM response parsing."""

from __future__ import annotations

import json
import re
from typing import Any, Callable, Literal

AnnotationMode = Literal[
    "choice", "ner_binary", "spans_manual", "textcat_binary", "binary"
]

_VIEW_ID_TO_MODE: dict[str, AnnotationMode] = {
    "choice": "choice",
    "classification": "textcat_binary",
    "ner": "ner_binary",
    "ner_manual": "spans_manual",
    "spans": "ner_binary",
    "spans_manual": "spans_manual",
}


# ---------------------------------------------------------------------------
# Task-type detection
# ---------------------------------------------------------------------------


def detect_task_type(task: dict[str, Any]) -> AnnotationMode:
    """Infer the annotation mode from the task's ``_view_id`` or keys."""
    view_id = task.get("_view_id")
    if view_id is not None:
        return _VIEW_ID_TO_MODE.get(view_id, "binary")
    if "options" in task:
        return "choice"
    if "tokens" in task:
        return "spans_manual"
    if "spans" in task:
        return "ner_binary"
    if "label" in task:
        return "textcat_binary"
    return "binary"


# ---------------------------------------------------------------------------
# Prompt formatting
# ---------------------------------------------------------------------------


def _format_choice(task: dict[str, Any], config: dict[str, Any]) -> str:
    options_text = "\n".join(
        f"  - {opt['id']}: {opt.get('text', opt['id'])}" for opt in task["options"]
    )
    multiple = config.get("choice_style") == "multiple"
    verb = "one or more options" if multiple else "exactly one option"
    return (
        f"You are an annotation assistant. Read the text and select {verb}.\n\n"
        f"Text: {task['text']}\n\n"
        f"Options:\n{options_text}\n\n"
        'Respond with JSON: {"selected": ["<option_id>", ...], "reason": "..."}'
    )


def _format_ner_binary(task: dict[str, Any], config: dict[str, Any]) -> str:
    spans_text = "\n".join(
        f"  - \"{task['text'][s['start']:s['end']]}\" "
        f"({s['label']}, chars {s['start']}-{s['end']})"
        for s in task["spans"]
    )
    return (
        "You are an annotation assistant. The text below has highlighted entity "
        "spans. Decide whether the spans are correctly labelled.\n\n"
        f"Text: {task['text']}\n\n"
        f"Spans:\n{spans_text}\n\n"
        'Respond with JSON: {"answer": "accept" or "reject", "reason": "..."}'
    )


def _format_spans_manual(task: dict[str, Any], config: dict[str, Any]) -> str:
    tokens_text = "\n".join(
        f"  - {t['id']}: \"{t['text']}\" (chars {t['start']}-{t['end']})"
        for t in task["tokens"]
    )
    labels = config.get("labels", [])
    labels_text = ", ".join(labels) if labels else "(no labels provided)"
    view_id = task.get("_view_id")
    overlap = (
        " Spans may overlap."
        if view_id == "spans_manual"
        else " Spans must not overlap."
    )
    parts = [
        "You are an annotation assistant. Identify all labelled spans "
        f"matching the label scheme.{overlap}\n",
        f"Text: {task['text']}\n",
        f"Tokens:\n{tokens_text}\n",
        f"Labels: {labels_text}\n",
    ]
    if task.get("spans"):
        existing = "\n".join(
            f"  - \"{task['text'][s['start']:s['end']]}\" "
            f"({s['label']}, chars {s['start']}-{s['end']})"
            for s in task["spans"]
        )
        parts.append(f"Existing spans:\n{existing}\n")
    parts.append(
        "Respond with JSON: "
        '{"spans": [{"token_start": <int>, "token_end": <int>, '
        '"label": "<LABEL>"}, ...]}\n'
        "token_start and token_end are inclusive token IDs."
    )
    return "\n".join(parts)


def _format_textcat_binary(task: dict[str, Any], config: dict[str, Any]) -> str:
    return (
        "You are an annotation assistant. Decide whether the text matches "
        f"the label \"{task['label']}\".\n\n"
        f"Text: {task['text']}\n\n"
        'Respond with JSON: {"answer": "accept" or "reject", "reason": "..."}'
    )


def _format_binary(task: dict[str, Any], config: dict[str, Any]) -> str:
    return (
        "You are an annotation assistant. Read the text and decide "
        "whether to accept or reject it.\n\n"
        f"Text: {task['text']}\n\n"
        'Respond with JSON: {"answer": "accept" or "reject", "reason": "..."}'
    )


_FORMATTERS: dict[AnnotationMode, Callable[[dict, dict], str]] = {
    "choice": _format_choice,
    "ner_binary": _format_ner_binary,
    "spans_manual": _format_spans_manual,
    "textcat_binary": _format_textcat_binary,
    "binary": _format_binary,
}


def format_prompt(
    task: dict[str, Any],
    task_type: AnnotationMode,
    config: dict[str, Any],
) -> str:
    """Build the LLM prompt for the given task and type."""
    formatter = _FORMATTERS.get(task_type)
    if formatter is None:
        raise ValueError(f"Unknown task type: {task_type!r}")
    return formatter(task, config)


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------

_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


def _extract_json(raw: str) -> dict[str, Any]:
    """Parse JSON from raw LLM output, stripping markdown fences if present."""
    m = _FENCE_RE.search(raw)
    text = m.group(1) if m else raw.strip()
    return json.loads(text)


def parse_response(
    raw: str,
    task: dict[str, Any],
    task_type: AnnotationMode,
    *,
    model_name: str = "",
) -> dict[str, Any]:
    """Parse the LLM response and merge the decision into the task.

    Returns a shallow copy — the original task is not mutated.
    """
    parsed = _extract_json(raw)
    result = {**task}

    if task_type == "choice":
        result["accept"] = parsed.get("selected", [])
        result["answer"] = "accept"
    elif task_type == "spans_manual":
        tokens = task.get("tokens", [])
        token_by_id = {t["id"]: t for t in tokens}
        spans = []
        for s in parsed.get("spans", []):
            ts = token_by_id.get(s["token_start"])
            te = token_by_id.get(s["token_end"])
            if ts is None or te is None:
                continue
            spans.append(
                {
                    "start": ts["start"],
                    "end": te["end"],
                    "token_start": s["token_start"],
                    "token_end": s["token_end"],
                    "label": s["label"],
                }
            )
        result["spans"] = spans
        result["answer"] = "accept"
    else:
        answer = parsed.get("answer", "").lower()
        if answer not in ("accept", "reject"):
            raise ValueError(f"Unexpected answer value: {answer!r}")
        result["answer"] = answer

    if model_name:
        result["_annotator_id"] = model_name
        result["_session_id"] = model_name

    return result
