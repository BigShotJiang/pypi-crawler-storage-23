from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Literal

import prodigy.recipes.llm.textcat
import srsly
from cloudpathlib import AnyPath
from prodigy.components.db import connect
from prodigy_teams_recipes_sdk import (
    Asset,
    Dataset,
    Input,
    Secret,
    action_recipe,
    teams_type,
)

from .util import make_tempdir


@teams_type(
    "config",
    title="spaCy config file",
    description="Remote path to a loadable spaCy config file",
)
class Config(Asset[Literal["config"]]):
    kind = "config"

    @contextmanager
    def localize(self) -> Iterator[Path]:
        """Download the remote config to a local temp file and yield its path.

        The temp directory is removed when the context manager exits.

        Contract:
            Raises:
                OSError / cloud storage errors: From ``AnyPath(self.path).open()``
                    if the remote config file is inaccessible (not caught).
                OSError: From ``make_tempdir()`` if the system temp directory
                    is not writable (not caught).

            Silences:
                - ``PermissionError`` during temp directory cleanup
                  (inherited from ``make_tempdir()``; emits a warning).
        """
        # TODO: Do this more elegantly
        path = AnyPath(self.path)
        with make_tempdir() as tmp:
            output = tmp / path.parts[-1]
            with path.open("r") as in_file:
                data = in_file.read()
                with output.open("w") as out_file:
                    out_file.write(data)
            yield output


@action_recipe(
    title="Textcat LLM fetch",
    description="Gather text categorization predictions from an LLM",
)
def llm_fetch_textcat(
    output: Dataset,
    config: Config,
    input: Input,
    *,
    openai_key: Secret,
    resume: bool = False,
) -> None:
    """Fetch text categorization predictions from an LLM and store them.

    Writes the LLM output to a JSONL file named ``output.name`` in the
    working directory (via the upstream Prodigy recipe), then reads it
    back and inserts the examples into the database.

    Contract:
        Preconditions:
            - ``openai_key`` must be a valid secret injected into the
              environment by the SDK. If the API key is missing or
              invalid, the upstream ``llm_fetch_textcat`` call will
              fail with an API authentication error (not caught).
            - ``input.path`` must reference an accessible data source.

        Raises:
            Database errors from ``connect()``, ``db.add_dataset()``,
                and ``db.add_examples()`` (not caught).
            OSError: From ``config.localize()`` if the remote config is
                inaccessible (not caught).
            LLM API errors from
                ``prodigy.recipes.llm.textcat.llm_fetch_textcat()``
                (not caught).
            FileNotFoundError: From ``srsly.read_jsonl(output.name)``
                if the upstream recipe did not write the output file
                (not caught).
    """
    db = connect()
    db.add_dataset(output.name)
    with config.localize() as config_path:
        # This will write to a file {output.name}
        prodigy.recipes.llm.textcat.llm_fetch_textcat(
            config_path=config_path,
            source=input.path,
            output=output.name,
            resume=resume,
            loader=input.meta.get("loader"),
        )
    examples = list(srsly.read_jsonl(output.name))
    db.add_examples(examples, [output.name])  # type: ignore
