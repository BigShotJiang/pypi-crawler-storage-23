from .models import Model, Prediction  # noqa
