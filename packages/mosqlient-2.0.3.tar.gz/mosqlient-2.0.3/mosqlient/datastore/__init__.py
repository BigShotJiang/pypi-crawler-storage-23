from .models import Climate, Infodengue  # noqa
