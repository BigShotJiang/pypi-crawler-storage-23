"""Command-line entry point for migration execution."""

from __future__ import annotations


def main() -> None:
    """Entry point invoked when migrations package is executed as a script."""

    raise SystemExit("Migration CLI is not implemented yet")


if __name__ == "__main__":
    main()
