"""Propagation rule for select_n operations."""

import numpy as np
from jax._src.core import JaxprEqn, Var

from ._commons import (
    IndexSet,
    StateBounds,
    StateConsts,
    StateIndices,
    atom_const_val,
    atom_numel,
    empty_index_set,
    index_sets,
)


def prop_select_n(
    eqn: JaxprEqn,
    state_indices: StateIndices,
    state_consts: StateConsts,
    state_bounds: StateBounds | None = None,
) -> None:
    """select_n(which, *cases) picks case values element-wise.

    ``which`` is a boolean or integer selector (scalar or array).
    All cases must have identical shapes.
    The selector has zero derivative,
    so only value-case state_indices contribute to the sparsity pattern.

    Also propagates value bounds through the selected branch
    when the predicate is a known constant.

    Jaxpr:
        invars[0]: which (boolean or integer, scalar or array)
        invars[1:]: value cases (on_false, on_true, ...)

    https://docs.jax.dev/en/latest/_autosummary/jax.lax.select_n.html
    """
    out_var = eqn.outvars[0]
    out_size = atom_numel(out_var)
    cases = eqn.invars[1:]  # value cases (which is invars[0])

    # Element-wise union across value cases.
    # The selector has zero derivative, so we skip it.
    case_indices = [index_sets(state_indices, c) for c in cases]

    out_indices: list[IndexSet] = []
    for i in range(out_size):
        merged: IndexSet = empty_index_set()
        for c_idx in case_indices:
            merged |= c_idx[i]
        out_indices.append(merged)

    state_indices[out_var] = out_indices

    # When all inputs are statically known, compute the concrete result
    # so state_consts tracking isn't broken by this op.
    which_val = atom_const_val(eqn.invars[0], state_consts)
    case_vals = [atom_const_val(c, state_consts) for c in cases]
    if which_val is not None and all(v is not None for v in case_vals):
        state_consts[out_var] = np.choose(
            which_val, [v for v in case_vals if v is not None]
        )

    # Propagate value bounds from the selected branch
    # when the predicate is a known constant.
    if (
        state_bounds is not None
        and which_val is not None
        and len(cases) == 2
        and which_val.dtype == bool
    ):
        if not np.any(which_val):
            selected = eqn.invars[1]
        elif np.all(which_val):
            selected = eqn.invars[2]
        else:
            return
        if isinstance(selected, Var) and selected in state_bounds:
            state_bounds[out_var] = state_bounds[selected]
