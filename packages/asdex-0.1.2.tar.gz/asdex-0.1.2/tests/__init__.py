"""asdex test suite."""
