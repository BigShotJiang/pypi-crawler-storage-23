# 中文注释：
# 文件：echobot/bus/__init__.py
# 说明：消息总线与事件模型。

"""Message bus module for decoupled channel-agent communication."""

from echobot.bus.events import InboundMessage, OutboundMessage
from echobot.bus.queue import MessageBus

__all__ = ["MessageBus", "InboundMessage", "OutboundMessage"]
