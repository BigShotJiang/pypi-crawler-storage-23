#!/usr/bin/env python3
# 中文注释：
# 文件：echobot/skills/siyuan/scripts/__init__.py
# 说明：SiYuan Skill 的工具元数据导出与统一执行入口。
"""
SiYuan Notes Skill for Clawdbot
"""

from .client import SiYuanClient
from .tools import SiYuanTools

try:
    from .runner import execute_tool as _execute_tool_impl
except ImportError:  # pragma: no cover - allow direct script execution
    from runner import execute_tool as _execute_tool_impl


def get_tools():
    """Get all SiYuan tools"""
    return [
        {
            "name": "siyuan_search",
            "description": "Search notes and blocks in SiYuan",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "limit": {"type": "integer", "description": "Max results", "default": 20},
                    "type": {"type": "string", "description": "Type: blocks or notes", "default": "blocks"}
                },
                "required": ["query"]
            }
        },
        {
            "name": "siyuan_get_notebooks",
            "description": "Get all notebooks",
            "parameters": {"type": "object", "properties": {}}
        },
        {
            "name": "siyuan_get_recent_docs",
            "description": "Get recent documents",
            "parameters": {
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "description": "Max results", "default": 10}
                }
            }
        },
        {
            "name": "siyuan_get_dailies",
            "description": "Get daily notes by date range",
            "parameters": {
                "type": "object",
                "properties": {
                    "start_date": {"type": "string", "description": "Start date (YYYY-MM-DD)"},
                    "end_date": {"type": "string", "description": "End date (YYYY-MM-DD)"}
                },
                "required": ["start_date", "end_date"]
            }
        },
        {
            "name": "siyuan_get_document",
            "description": "Get document content by ID",
            "parameters": {
                "type": "object",
                "properties": {
                    "doc_id": {"type": "string", "description": "Document ID"}
                },
                "required": ["doc_id"]
            }
        },
        {
            "name": "siyuan_create_document",
            "description": "Create a new document",
            "parameters": {
                "type": "object",
                "properties": {
                    "notebook_id": {"type": "string", "description": "Notebook ID"},
                    "path": {"type": "string", "description": "Path (e.g., /)"},
                    "title": {"type": "string", "description": "Document title"},
                    "content": {"type": "string", "description": "Markdown content"}
                },
                "required": ["notebook_id", "path", "title"]
            }
        },
        {
            "name": "siyuan_update_document",
            "description": "Update document content",
            "parameters": {
                "type": "object",
                "properties": {
                    "doc_id": {"type": "string", "description": "Document ID"},
                    "content": {"type": "string", "description": "New markdown content"}
                },
                "required": ["doc_id", "content"]
            }
        },
        {
            "name": "siyuan_query_sql",
            "description": "Execute SQL query on SiYuan database",
            "parameters": {
                "type": "object",
                "properties": {
                    "sql": {"type": "string", "description": "SQL query"}
                },
                "required": ["sql"]
            }
        },
        {
            "name": "siyuan_query_blocks",
            "description": "Query blocks using HSQL",
            "parameters": {
                "type": "object",
                "properties": {
                    "hsql": {"type": "string", "description": "HSQL query"},
                    "limit": {"type": "integer", "description": "Max results", "default": 100}
                },
                "required": ["hsql"]
            }
        },
    ]


def execute_tool(tool_name: str, arguments: dict) -> str:
    """Execute a SiYuan tool"""
    return _execute_tool_impl(tool_name=tool_name, arguments=arguments)
