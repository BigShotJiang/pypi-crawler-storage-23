# 中文注释：
# 文件：echobot/agent/tools/create_agent.py
# 说明：动态创建 Agent 工具。
"""Create Agent Tool - 动态创建 Agent"""

from pathlib import Path
from typing import Any

from echobot.agent.tools.base import Tool


class CreateAgentTool(Tool):
    """
    动态创建新 Agent 工具

    允许当前 Agent 动态创建新的 Agent 实例。
    新 Agent 会自动添加到 agents.json 并热加载到运行时。
    """

    def __init__(
        self,
        create_agent_callback,
        get_available_agents_callback,
        current_agent_id: str,
        instance_name: str | None = None,
        default_workspace_base: str | None = None,
    ):
        """
        Initialize CreateAgentTool.

        Args:
            create_agent_callback: 创建 Agent 的回调函数
            get_available_agents_callback: 获取可用 Agent 列表的回调
            current_agent_id: 当前 Agent 的 ID
            instance_name: 当前实例名称
            default_workspace_base: 默认工作区基础路径
        """
        self._create_agent = create_agent_callback
        self._get_available_agents = get_available_agents_callback
        self._current_agent_id = current_agent_id
        self._instance_name = instance_name
        self._default_workspace_base = default_workspace_base

    @property
    def name(self) -> str:
        return "create_agent"

    @property
    def description(self) -> str:
        return """Create a new agent dynamically. Use this to spawn specialized agents for specific tasks.
The new agent will be added to agents.json and loaded at runtime.
Required: agent_id, name, role. Optional: token, workspace, exec_allowed_dirs."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "agent_id": {
                    "type": "string",
                    "description": "Unique ID for the new agent (e.g., 'coder', 'reviewer', 'data_analyst')",
                },
                "name": {
                    "type": "string",
                    "description": "Display name for the agent (e.g., 'Coder', 'Reviewer')",
                },
                "role": {
                    "type": "string",
                    "description": "Role name for the agent (e.g., 'coder', 'default', 'orchestrator'). Use 'default' if unsure.",
                },
                "token": {
                    "type": "string",
                    "description": "Telegram bot token for this agent (optional, only needed if agent needs its own Telegram identity)",
                },
                "workspace": {
                    "type": "string",
                    "description": "Workspace directory path (optional, defaults to ~/.echobot/agents/<agent_id>)",
                },
                "exec_allowed_dirs": {
                    "type": "string",
                    "description": "Comma-separated additional directories this agent can execute commands in (optional)",
                },
            },
            "required": ["agent_id", "name", "role"],
        }

    async def execute(
        self,
        agent_id: str,
        name: str,
        role: str = "default",
        token: str = "",
        workspace: str = "",
        exec_allowed_dirs: str = "",
        **kwargs,
    ) -> str:
        """Execute agent creation."""
        if self._create_agent is None:
            return "Error: Agent creation is not available in this context"

        try:
            # Parse exec_allowed_dirs
            parsed_dirs = []
            if exec_allowed_dirs:
                parsed_dirs = [d.strip() for d in exec_allowed_dirs.split(",") if d.strip()]

            # Use default workspace if not provided
            if not workspace:
                if self._instance_name:
                    workspace = f"~/.echobot/instances/{self._instance_name}/agents/{agent_id}"
                else:
                    workspace = f"~/.echobot/agents/{agent_id}"

            result = await self._create_agent(
                caller_id=self._current_agent_id,
                agent_id=agent_id,
                name=name,
                role=role,
                token=token,
                workspace=workspace,
                exec_allowed_dirs=parsed_dirs,
            )
            return result
        except Exception as e:
            return f"Error creating agent: {str(e)}"
