# 中文注释：
# 文件：echobot/agent/__init__.py
# 说明：智能体核心逻辑，包括主循环、上下文、记忆与任务队列。

"""
Agent 核心模块
=================================================

此模块是 echobot Agent 系统的核心入口，提供了 Agent 运行所需的主要组件：

主要组件：
1. AgentLoop: 核心处理引擎
   - 负责接收消息、构建上下文、调用 LLM、执行工具
   - 支持多轮对话和工具调用循环

2. ContextBuilder: 上下文构建器
   - 组装系统提示词、记忆、技能
   - 支持渐进式技能加载

3. MemoryStore: 记忆管理系统
   - 短期记忆：每日笔记 (memory/YYYY-MM-DD.md)
   - 长期记忆：MEMORY.md
   - 自动检索相关记忆

4. SkillsLoader: 技能加载器
   - 加载和管理 Agent 技能（Markdown 格式）
   - 支持渐进式加载，只在需要时加载完整技能

子模块：
- agent/tools/: 工具实现（文件系统、Shell、Web、消息等）
- agent/subagent.py: 后台子任务管理

使用示例：
    from echobot.agent import AgentLoop, ContextBuilder, MemoryStore

    agent = AgentLoop(bus, provider, workspace)
    await agent.run()
"""

from echobot.agent.loop import AgentLoop
from echobot.agent.context import ContextBuilder
from echobot.agent.memory import MemoryStore
from echobot.agent.memory_auto import MemoryAutoWriter
from echobot.agent.skills import SkillsLoader

__all__ = ["AgentLoop", "ContextBuilder", "MemoryStore", "MemoryAutoWriter", "SkillsLoader"]
