# 中文注释：
# 文件：echobot/providers/__init__.py
# 说明：模型提供商适配层，统一不同 LLM 的调用接口。

"""LLM provider abstraction module."""

from echobot.providers.base import LLMProvider, LLMResponse
from echobot.providers.litellm_provider import LiteLLMProvider

__all__ = ["LLMProvider", "LLMResponse", "LiteLLMProvider"]
