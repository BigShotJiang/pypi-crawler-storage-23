"""Gems service: manage custom system prompts (Gems)."""

from __future__ import annotations

import json
from dataclasses import dataclass

from gemini_web_mcp_cli.core.client import GeminiClient
from gemini_web_mcp_cli.core.constants import RPC
from gemini_web_mcp_cli.core.parser import get_nested


@dataclass
class Gem:
    """A Gemini Gem (custom system prompt)."""

    id: str
    name: str
    description: str = ""
    prompt: str = ""
    predefined: bool = False


class GemsService:
    """Service for managing Gemini Gems (custom system prompts).

    Uses batchexecute RPCs for all CRUD operations.
    """

    def __init__(self, client: GeminiClient):
        self.client = client

    async def list_gems(self, predefined: bool = False) -> list[Gem]:
        """List available gems. Set predefined=True for system gems."""
        gem_type = 0 if predefined else 1
        payload = json.dumps([None, gem_type])

        results = await self.client.execute_rpc(
            rpc_id=RPC.LIST_GEMS,
            payload=payload,
        )

        gems = []
        for result in results:
            if result.data and isinstance(result.data, list):
                gem_list = get_nested(result.data, [2]) or []
                for gem_data in gem_list:
                    if isinstance(gem_data, list):
                        gems.append(Gem(
                            id=get_nested(gem_data, [0], ""),
                            name=get_nested(gem_data, [1, 0], ""),
                            description=get_nested(gem_data, [1, 1], ""),
                            prompt=get_nested(gem_data, [2, 0], ""),
                            predefined=predefined,
                        ))
        return gems

    async def create(self, name: str, description: str, prompt: str) -> dict:
        """Create a new custom gem."""
        payload = json.dumps(
            [name, description, prompt, None, None, None, None, None, 1]
        )
        results = await self.client.execute_rpc(
            rpc_id=RPC.CREATE_GEM,
            payload=payload,
        )
        return {"status": "created", "data": results[0].data if results else None}

    async def update(
        self, gem_id: str, name: str, description: str, prompt: str
    ) -> dict:
        """Update an existing custom gem."""
        payload = json.dumps(
            [gem_id, [name, description, prompt, None, None, None, None, None, 1]]
        )
        results = await self.client.execute_rpc(
            rpc_id=RPC.UPDATE_GEM,
            payload=payload,
        )
        return {"status": "updated", "data": results[0].data if results else None}

    async def delete(self, gem_id: str) -> dict:
        """Delete a custom gem."""
        payload = json.dumps([gem_id])
        results = await self.client.execute_rpc(
            rpc_id=RPC.DELETE_GEM,
            payload=payload,
        )
        return {"status": "deleted", "data": results[0].data if results else None}
