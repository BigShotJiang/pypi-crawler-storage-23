# File Upload Protocol

## Overview

Files (images, PDFs, documents, audio) are uploaded to Google's content push
service and return an identifier that can be referenced in chat messages.

## Endpoint

```
POST https://content-push.googleapis.com/upload
```

## Request

| Aspect | Details |
|--------|---------|
| Method | POST |
| Content-Type | multipart/form-data |
| Header | `Push-ID: feeds/mcudyrk2a4khkz` |
| HTTP/2 | Required |
| Field name | `file` |
| Field value | `(filename, file_bytes)` |

## Response

Plain text body containing the file identifier:

```
/contrib_service/ttl_1d/1709764705i7wdlyx3mdzndme3a767pluckv4flj
```

## Usage in Chat

The file identifier is included in the StreamGenerate request payload:

```python
# inner_req_list[0] = [prompt, 0, None, file_data, None, None, 0]
# where file_data = [[file_identifier, 1, file_name]]
file_data = [["/contrib_service/ttl_1d/...", 1, "document.pdf"]]
```

## Bard Activity Prerequisite

Before the first file upload in a session, enable Bard activity:

```python
# batchexecute with ESY5D RPC
rpc_id = "ESY5D"
payload = "[1]"
```

## Supported File Types

Based on gemini-webapi usage:
- Images (PNG, JPEG, GIF, WebP)
- PDFs
- Documents (text files)
- Audio files

## File Identifier Lifetime

The identifier path includes `ttl_1d`, suggesting files expire after 1 day.
Files should be uploaded close to when they'll be used in chat.
