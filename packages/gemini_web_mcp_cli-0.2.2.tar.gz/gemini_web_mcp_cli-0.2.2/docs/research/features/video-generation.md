# Video Generation (Veo)

## Status: NOT CAPTURED -- Manual RPC capture required

## Overview

Gemini can generate short videos using Google's Veo model. This is triggered
through the chat interface similar to image generation.

## What We Know

- Video generation is done through the Gemini web UI
- Uses Google's Veo video generation model
- gemini-webapi does NOT implement this
- Videos are likely short clips (seconds to ~1 minute)
- Generation probably takes longer than image generation

## Capture Plan

1. Open Chrome DevTools > Network tab
2. Filter to Fetch/XHR
3. Request a video in Gemini (e.g., "Generate a video of a sunset over the ocean")
4. Watch for:
   - The initial request (is it through StreamGenerate or a separate RPC?)
   - Any polling requests for video generation progress
   - The final response with video URL or data
5. Export HAR file to `captures/har/video-generation.har`
6. Extract cURL commands to `captures/curl/video-generation.sh`

## Questions to Answer During Capture

- Is video generation triggered through regular chat (StreamGenerate) or a separate RPC?
- Is it async (start + poll) like Deep Research might be?
- What does the video URL look like? Does it require auth cookies to download?
- What video formats are returned (MP4)?
- Can you specify video parameters (duration, style, resolution)?
- Where does the video URL appear in the response structure?
