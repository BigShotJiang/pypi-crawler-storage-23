"""
Main HTTP session module
"""

import functools

from contextlib import contextmanager
from http import HTTPStatus
from typing import Any
from typing import Callable
from typing import FrozenSet
from typing import Generator
from typing import Iterable

from requests import Session
from requests.adapters import HTTPAdapter
from urllib3 import Retry

from http_utils.hooks import check_for_errors
from http_utils.hooks import log_response
from http_utils.settings import HTTP_BACKOFF_FACTOR
from http_utils.settings import HTTP_RETRIES
from http_utils.settings import HTTP_STATUS_FORCELIST
from http_utils.settings import HTTP_TIMEOUT


@contextmanager
def request_session(
    allowed_http_error_status_list: list[int] | None = None,
    total: int = HTTP_RETRIES,
    backoff_factor: float = HTTP_BACKOFF_FACTOR,
    status_forcelist: Iterable[int | str | HTTPStatus] = HTTP_STATUS_FORCELIST,
    allowed_methods: FrozenSet | None = Retry.DEFAULT_ALLOWED_METHODS,
    hooks: list[Callable] | None = None,
    **kwargs: Any,
) -> Generator[Session, None, None]:
    """
    Generate a requests session that allows retries and raises HTTP errors (status code >= 400).
    Uses the same arguments as the class Retry from urllib3
    """

    session = Session()
    session.request = functools.partial(session.request, timeout=HTTP_TIMEOUT)  # type: ignore[method-assign]

    # Adds the default log_response hook if no hooks are provided.
    if hooks is None:
        hooks = [log_response]
    # Adds the [allowed_http_error_status_list] to the check for errors hook.
    error_hook = functools.partial(
        check_for_errors,
        allowed_http_error_status_list=allowed_http_error_status_list,
    )
    session.hooks.update(response=[*hooks, error_hook])

    adapter = HTTPAdapter(
        max_retries=Retry(
            total=total,
            backoff_factor=backoff_factor,
            allowed_methods=allowed_methods,
            status_forcelist=status_forcelist,
            **kwargs,
        )
    )

    session.mount("https://", adapter)
    session.mount("http://", adapter)

    try:
        yield session
    finally:
        session.close()
