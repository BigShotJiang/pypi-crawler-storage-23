from typing import Optional, Union
from uuid import UUID

from radicli import Arg
from wasabi import msg

from ..cli import cli
from ..config import global_config_dir
from ..errors import CLIError
from ..messages import Messages
from ..query import resolve_action_id, resolve_project_id, resolve_task_id
from ..util import URL
from ._state import get_root_cfg, get_saved_settings


@cli.subcommand("config", "reset")
def reset() -> None:
    """Reset all caching and configuration."""
    queue = list(global_config_dir().iterdir())
    for subpath in queue:
        if subpath.is_dir():
            queue.extend(list(subpath.iterdir()))
        else:
            msg.info(Messages.T021.format(subpath=subpath))
            subpath.unlink()


@cli.subcommand(
    "config",
    "project",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="project")),
)
def project(name_or_id: Union[str, UUID]) -> UUID:
    """Set the default project."""
    root_cfg = get_root_cfg()
    project_id = resolve_project_id(name_or_id)
    settings = get_saved_settings()
    settings.update("project", project_id)
    settings.save(root_cfg.saved_settings_path)
    msg.good(Messages.T019.format(noun="project", name=project_id))
    return project_id


@cli.subcommand(
    "config",
    "task",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="task")),
    project_id=Arg(help=Messages.project_id.format(noun="task")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="task")),
)
def task(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[UUID] = None,
    project_id: Optional[UUID] = None,
) -> UUID:
    """Set the default task."""
    root_cfg = get_root_cfg()
    task_id = resolve_task_id(name_or_id, project_id=project_id, broker_id=cluster_id)
    settings = get_saved_settings()
    settings.update("task", task_id)
    settings.save(root_cfg.saved_settings_path)
    msg.good(Messages.T019.format(noun="task", name=task_id))
    return task_id


@cli.subcommand(
    "config",
    "action",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="action")),
    project_id=Arg(help=Messages.project_id.format(noun="action")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="action")),
)
def action(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[UUID] = None,
    project_id: Optional[UUID] = None,
) -> UUID:
    """Set the default action."""
    root_cfg = get_root_cfg()
    action_id = resolve_action_id(
        name_or_id, project_id=project_id, broker_id=cluster_id
    )
    settings = get_saved_settings()
    settings.update("action", action_id)
    settings.save(root_cfg.saved_settings_path)

    msg.good(Messages.T019.format(noun="action", name=action_id))
    return action_id


@cli.subcommand(
    "config",
    "set-cluster-host",
    host=Arg(help=Messages.cluster_host_config),
)
def set_broker_host(host: str) -> None:
    """Set the broker cluster host."""
    root_cfg = get_root_cfg()
    host_url = URL.parse(host)
    settings = get_saved_settings()
    settings.update("broker_host", str(host_url))
    settings.save(root_cfg.saved_settings_path)
    msg.good(Messages.T019.format(noun="cluster host", name=host))


@cli.subcommand(
    "config",
    "set-pam-host",
    host=Arg(help=Messages.pam_host_config),
)
def set_pam_host(host: str) -> None:
    """Set the PAM host."""
    root_cfg = get_root_cfg()
    host_url = URL.parse(host)
    settings = get_saved_settings()
    settings.update("pam_host", str(host_url))
    settings.save(root_cfg.saved_settings_path)
    msg.good(Messages.T019.format(noun="PAM host", name=host))


@cli.subcommand(
    "config",
    "set-recipes-file",
    path=Arg(help="Path to a local recipes YAML file"),
    clear=Arg("--clear", help="Clear the recipes file setting"),
)
def set_recipes_file(path: Optional[str] = None, clear: bool = False) -> None:
    """Set or clear a local recipes file for PAM-free recipe discovery."""
    root_cfg = get_root_cfg()
    settings = get_saved_settings()
    if clear:
        settings.update("recipes_file", None)
        settings.save(root_cfg.saved_settings_path)
        msg.good("Cleared recipes file setting")
        return
    if path is None:
        raise CLIError("Provide a path to a recipes file, or use --clear to remove it")
    from pathlib import Path as _Path

    resolved = str(_Path(path).resolve())
    settings.update("recipes_file", resolved)
    settings.save(root_cfg.saved_settings_path)
    msg.good(Messages.T019.format(noun="recipes file", name=resolved))
