# pyhausbus

Python based library for accessing haus-bus.de modules. Intended to be used in a Home Assistant integration.
