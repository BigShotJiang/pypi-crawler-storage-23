# Study Plan: Tools (Chapter 4.6 - 4.6.4)

## Goal
Build a complete understanding of tool abstractions and developer ergonomics from Chapter 4.6-4.6.4 and picoagents implementation. This document serves as both learning material and implementation guide with actual code examples for building Agentbyte's tool system.

---

## Part 1: Learning from the Book (Chapter 4.6 - 4.6.4)

### 4.6 Adding Tools - Core Concepts

**What are Tools?**
Tools transform agents from text generators into action-taking entities. With structured output working (4.5), agents can now produce reliable, parseable data. Tools leverage this capability to enable agents to:
- Check weather
- Query databases  
- Perform calculations
- Call REST APIs
- Execute code

**From Structured Output to Tool Calling:**
```python
# Without tools: fragile text parsing
"Please call the get_weather function with location set to Paris"

# With structured output + tools: reliable JSON
{
  "name": "get_weather",
  "arguments": {"location": "Paris", "date_range": "next 4 days"}
}
```

### 4.6.1 Function Calling (Tool Calling) in LLMs

**Tool calling** is structured output applied to function execution. The LLM generates precisely formatted JSON requests that match predefined tool schemas.

**Multi-step pattern:**
1. **Define tools**: Provide function schemas (name, description, parameters) to the LLM
2. **Tool calls**: LLM generates structured requests to use specific tools
3. **Tool execution**: Application executes the function and generates outputs
4. **Tool outputs**: Results are sent back to the LLM for integration

**Example from book:**
User: "What is the weather going to be like in San Francisco over the next 4 days?"
LLM generates: `get_weather(location="San Francisco", date_range="next 4 days")`

### 4.6.2 Tool Categories

**General-purpose tools**: Broad capabilities (code interpreters, UI drivers)
- Maximum flexibility
- Require careful sandboxing (Chapter 5)
- Introduce uncertainty

**Task-specific tools**: Focused capabilities (send email, query DB, generate images)
- Predictable behavior
- Constrained decision space
- Limited to predefined functions

### 4.6.3 The BaseTool Class

The book emphasizes that while you could pass functions directly to agents, a **common interface** enables:
- REST API tools
- Database tools  
- MCP tools connecting to external services
- All without changing agent code

**Key responsibilities from book:**
- `parameters`: JSON schema defining expected inputs
- `execute`: Execute the tool with given parameters
- `to_llm_format`: Convert to OpenAI function calling format

### 4.6.4 FunctionTool: Developer Ergonomics

This section is our primary focus. The book states:

> "The most common tool type wraps Python functions. Rather than manually implementing the BaseTool interface for every function, a common practice is to provide a FunctionTool abstraction that automatically handles the conversion."

**Developer experience goal:**
```python
def get_weather(location: str, days: int = 1) -> str:
    """Get weather forecast for a location."""
    return f"Weather in {location}: sunny"

# This function automatically becomes a tool
agent = Agent(tools=[get_weather], ...)
```

**FunctionTool handles conversion automatically:**
1. **Function Inspection**: Extracts signature, parameter names, and type hints
2. **Schema Generation**: Converts Python types to LLM-compatible JSON schema
3. **Execution Wrapper**: Handles both sync and async functions with error handling
4. **Result Formatting**: Converts function outputs to structured ToolResult objects

**Key insight**: "This approach prioritizes developer ergonomics - you write functions naturally and the framework handles agent integration."

---

## Part 2: Learning from picoagents Implementation

### Understanding ToolResult (from types.py)

```python
class ToolResult(BaseModel):
    """Standardized tool execution result."""
    success: bool = Field(..., description="Whether tool execution succeeded")
    result: Any = Field(..., description="The actual result data")
    error: Optional[str] = Field(None, description="Error message if failed")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Execution time, etc."
    )
    
    class Config:
        frozen = True  # Immutable after creation
```

**Key learnings:**
- Pydantic BaseModel for validation
- `frozen = True` makes it immutable
- Metadata dict enables extensibility
- Clear success/error separation

### Understanding BaseTool (from tools/_base.py)

**Core interface contract:**
```python
class ApprovalMode(Enum):
    """Tool approval requirements."""
    NEVER = "never_require"
    ALWAYS = "always_require"

class BaseTool(ComponentBase[BaseModel], ABC):
    def __init__(
        self,
        name: str,
        description: str,
        version: str = "1.0.0",
        approval_mode: ApprovalMode = ApprovalMode.NEVER,
    ):
        self.name = name
        self.description = description
        self.version = version
        self.approval_mode = approval_mode
    
    @property
    @abstractmethod
    def parameters(self) -> Dict[str, Any]:
        """JSON schema defining expected inputs."""
        pass
    
    @abstractmethod
    async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
        """Execute the tool with the given parameters."""
        pass
```

**Key learnings:**
- Async-first design (all execution is async)
- Versioning support for tool evolution
- Approval mode for enterprise safety
- Abstract properties enforce interface contracts

**Validation logic:**
```python
def validate_parameters(self, params: Dict[str, Any]) -> bool:
    """Validate that provided parameters match the tool's schema."""
    try:
        schema = self.parameters
        required_fields = schema.get("required", [])
        
        # Check required fields are present
        for field in required_fields:
            if field not in params:
                return False
        
        # Check parameter types if specified in schema
        properties = schema.get("properties", {})
        for param_name, param_value in params.items():
            if param_name in properties:
                expected_type = properties[param_name].get("type")
                if expected_type and not self._check_type(param_value, expected_type):
                    return False
        
        return True
    except Exception:
        return False
```

**to_llm_format pattern:**
```python
def to_llm_format(self) -> Dict[str, Any]:
    """Convert tool to OpenAI function calling format."""
    # Anthropic pattern: include version in name for v != "1.0.0"
    versioned_name = (
        f"{self.name}_v{self.version}" 
        if self.version != "1.0.0" 
        else self.name
    )
    
    return {
        "type": "function",
        "function": {
            "name": versioned_name,
            "description": self.description,
            "parameters": self.parameters,
        },
    }
```

**Streaming support pattern:**
```python
async def execute_stream(
    self,
    parameters: Dict[str, Any],
    cancellation_token: Optional["CancellationToken"] = None,
) -> AsyncGenerator[Union["Message", "AgentEvent", ToolResult], None]:
    """Execute the tool with streaming output support."""
    # Default implementation wraps execute()
    result = await self.execute(parameters)
    yield result

def supports_streaming(self) -> bool:
    """Check if this tool supports streaming execution."""
    # Check if execute_stream was overridden
    return type(self).execute_stream is not BaseTool.execute_stream
```

### Understanding FunctionTool (from tools/_base.py)

**Initialization and metadata extraction:**
```python
class FunctionTool(BaseTool):
    def __init__(
        self,
        func: Callable,
        name: Optional[str] = None,
        description: Optional[str] = None,
        version: str = "1.0.0",
        approval_mode: ApprovalMode = ApprovalMode.NEVER,
    ):
        self.func = func
        tool_name = name or func.__name__
        tool_description = (
            description or 
            func.__doc__ or 
            f"Execute {func.__name__} function"
        )
        
        super().__init__(tool_name, tool_description, version, approval_mode)
        
        # Extract function metadata for schema generation
        self.signature = inspect.signature(func)
        self.type_hints = get_type_hints(func)
        self._parameters_schema = self._build_parameters_schema()
```

**Key learnings:**
- Uses `inspect.signature()` to extract parameters
- Uses `get_type_hints()` for type annotations
- Builds schema once during init (performance)
- Falls back to function name/docstring if not provided

**Schema generation logic:**
```python
def _build_parameters_schema(self) -> Dict[str, Any]:
    """Build JSON schema from function signature and type hints."""
    schema = {
        "type": "object",
        "properties": {},
        "required": []
    }
    
    for param_name, param in self.signature.parameters.items():
        # Skip 'self' parameter
        if param_name == "self":
            continue
        
        # Get parameter type from type hints
        param_type = self.type_hints.get(param_name)
        json_type = self._python_type_to_json_type(param_type)
        
        property_schema = {"type": json_type}
        
        # Add enum constraint for Literal types
        enum_values = self._extract_enum_values(param_type)
        if enum_values:
            property_schema["enum"] = enum_values
        
        schema["properties"][param_name] = property_schema
        
        # Add to required if no default value
        if param.default == inspect.Parameter.empty:
            schema["required"].append(param_name)
    
    return schema
```

**Type mapping:**
```python
def _python_type_to_json_type(self, python_type: Any) -> str:
    """Convert Python type hints to JSON schema types."""
    if python_type is None or python_type == type(None):
        return "null"
    elif python_type == str:
        return "string"
    elif python_type == int:
        return "integer"
    elif python_type == float:
        return "number"
    elif python_type == bool:
        return "boolean"
    elif python_type == list or (
        hasattr(python_type, "__origin__") and 
        python_type.__origin__ == list
    ):
        return "array"
    elif python_type == dict or (
        hasattr(python_type, "__origin__") and 
        python_type.__origin__ == dict
    ):
        return "object"
    else:
        # For Union types, complex types, etc., default to string
        return "string"
```

**Enum value extraction (Literal and Enum support):**
```python
def _extract_enum_values(self, param_type: Any) -> Optional[List[Any]]:
    """Extract enum values from Literal types or Enum classes."""
    # Handle typing.Literal (Python 3.8+)
    if hasattr(param_type, "__origin__"):
        try:
            from typing import Literal, get_args, get_origin
            
            if get_origin(param_type) is Literal:
                return list(get_args(param_type))
        except (ImportError, AttributeError):
            pass
        
        # Fallback for older Python
        if hasattr(param_type, "__args__"):
            type_name = str(param_type.__origin__) if param_type.__origin__ else str(param_type)
            if "Literal" in type_name:
                return list(param_type.__args__)
    
    # Handle Enum classes
    try:
        from enum import Enum
        
        if isinstance(param_type, type) and issubclass(param_type, Enum):
            return [e.value for e in param_type]
    except (TypeError, AttributeError):
        pass
    
    return None
```

**Execute implementation:**
```python
async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
    """Execute the wrapped function with validated parameters."""
    try:
        # Validate parameters before execution
        if not self.validate_parameters(parameters):
            return ToolResult(
                success=False,
                result=None,
                error="Invalid parameters provided",
                metadata={"tool_name": self.name},
            )
        
        # Execute function (handle both sync and async)
        if inspect.iscoroutinefunction(self.func):
            result = await self.func(**parameters)
        else:
            result = self.func(**parameters)
        
        return ToolResult(
            success=True,
            result=result,
            error=None,
            metadata={"tool_name": self.name},
        )
    
    except Exception as e:
        return ToolResult(
            success=False,
            result=None,
            error=str(e),
            metadata={
                "tool_name": self.name,
                "exception_type": type(e).__name__
            },
        )
```

**Key learnings:**
- Validates before execution
- Uses `inspect.iscoroutinefunction()` to detect async
- Catches all exceptions and returns ToolResult
- Metadata includes exception type for debugging

**Callable wrapper for testing:**
```python
def __call__(self, *args, **kwargs):
    """Make the tool callable like the original function."""
    return self.func(*args, **kwargs)
```

This enables:
```python
@tool
def get_weather(city: str) -> str:
    return f"Weather in {city}"

# Can still call directly for testing
result = get_weather("Seattle")  # Works!
```

### Understanding @tool Decorator (from tools/_decorator.py)

```python
def tool(
    func: Optional[Callable[..., T]] = None,
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
    approval_mode: Union[str, ApprovalMode] = "never_require",
) -> Union[FunctionTool, Callable[[Callable[..., T]], FunctionTool]]:
    """Decorator to create a tool from a function."""
    
    def decorator(f: Callable[..., T]) -> FunctionTool:
        # Convert string to enum if needed
        mode = (
            ApprovalMode(approval_mode)
            if isinstance(approval_mode, str)
            else approval_mode
        )
        
        tool_name = name or f.__name__
        tool_desc = description or f.__doc__ or ""
        
        return FunctionTool(
            func=f,
            name=tool_name,
            description=tool_desc,
            approval_mode=mode,
        )
    
    # If func is provided, we're being used without parentheses
    if func is not None:
        return decorator(func)
    
    # Otherwise, we're being used with parentheses
    return decorator
```

**Key learnings:**
- Supports both `@tool` and `@tool(...)`
- String-to-enum conversion for ergonomics
- TypeVar `T` preserves function signature
- Returns FunctionTool instance

### Sync/Async Function Support

The `@tool` decorator supports **both sync and async functions by default**. The decorator itself is simple—it just stores the function reference. The **real magic** happens in `FunctionTool.execute()`:

```python
async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
    # ... validation ...
    
    # Detect if original function is async, then handle accordingly
    if inspect.iscoroutinefunction(self.func):
        result = await self.func(**parameters)  # Await async
    else:
        result = self.func(**parameters)  # Call sync normally
    
    return ToolResult(success=True, result=result)
```

**Why this works:**
- Python's `inspect.iscoroutinefunction()` natively detects async functions
- `FunctionTool.execute()` is always async, enabling uniform agent calling
- Agents call `await tool.execute(...)` without caring about underlying type
- Both sync and async functions support the same interface

Example:
```python
@tool
def add(x: int, y: int) -> int:
    return x + y

@tool
async def fetch_data(url: str) -> str:
    await asyncio.sleep(0.1)
    return f"Data from {url}"

# Both work the same way:
await add.execute({"x": 5, "y": 3})
await fetch_data.execute({"url": "https://api.example.com"})
```

---

## Part 3: Implementation Guide for Agentbyte

### Step 1: Create Package Structure

```bash
mkdir -p src/agentbyte/tools
touch src/agentbyte/tools/__init__.py
touch src/agentbyte/tools/base.py
touch src/agentbyte/tools/function.py
touch src/agentbyte/tools/decorator.py
touch src/agentbyte/types.py  # If doesn't exist
```

### Step 2: Implement ToolResult (types.py)

**File**: `src/agentbyte/types.py`

```python
"""
Core types for Agentbyte framework.
"""
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field


class ToolResult(BaseModel):
    """
    Standardized result from tool execution.
    
    Provides consistent error handling across all tools.
    
    Attributes:
        success: Whether tool executed successfully
        result: The actual output from the tool (can be any type)
        error: Error message if execution failed
        metadata: Additional context (tool name, timing, exception type, etc.)
    
    Example:
        # Success case
        ToolResult(
            success=True,
            result="Weather in Paris: sunny",
            error=None,
            metadata={"tool_name": "get_weather"}
        )
        
        # Error case
        ToolResult(
            success=False,
            result=None,
            error="City not found",
            metadata={"tool_name": "get_weather", "exception_type": "ValueError"}
        )
    """
    success: bool = Field(..., description="Whether tool executed successfully")
    result: Any = Field(None, description="Tool output data")
    error: Optional[str] = Field(None, description="Error message if failed")
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional execution context"
    )
    
    class Config:
        """Pydantic configuration."""
        arbitrary_types_allowed = True  # Allow any Python type in result
        frozen = True  # Make immutable after creation


__all__ = ["ToolResult"]
```

### Step 3: Implement BaseTool (tools/base.py)

**File**: `src/agentbyte/tools/base.py`

```python
"""
Base tool classes and interfaces for Agentbyte framework.

This module defines the abstract base class that all tools must implement,
providing a unified interface for tool discovery, validation, and execution.
"""
import inspect
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from enum import Enum
from typing import Any, Dict, Optional, Union

from ..types import ToolResult


class ApprovalMode(Enum):
    """
    Tool approval requirements for enterprise safety.
    
    NEVER: Execute immediately without approval (default for safe operations)
    ALWAYS: Require human approval before execution (for sensitive operations)
    
    Example:
        @tool(approval_mode="always_require")
        def delete_database(name: str) -> str:
            '''Delete a database - requires approval.'''
            ...
    """
    NEVER = "never_require"
    ALWAYS = "always_require"


class BaseTool(ABC):
    """
    Abstract base class that all tools must implement.
    
    Defines the interface for tools that agents can use to perform actions
    beyond text generation. Tools can be simple functions, REST API calls,
    database queries, or any external system integration.
    
    The base tool provides:
    - Metadata (name, description, version) for LLM discovery
    - Schema definition via JSON Schema format
    - Validation of parameters before execution
    - Async execution with error handling
    - Optional streaming support
    - Conversion to LLM function-calling format
    
    Example:
        class WeatherTool(BaseTool):
            @property
            def parameters(self) -> Dict[str, Any]:
                return {
                    "type": "object",
                    "properties": {
                        "city": {"type": "string"}
                    },
                    "required": ["city"]
                }
            
            async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
                city = parameters["city"]
                # ... fetch weather ...
                return ToolResult(success=True, result=weather_data)
    """
    
    def __init__(
        self,
        name: str,
        description: str,
        version: str = "1.0.0",
        approval_mode: ApprovalMode = ApprovalMode.NEVER,
    ):
        """
        Initialize the base tool.
        
        Args:
            name: Unique tool identifier (used by LLM to call the tool)
            description: What the tool does (helps LLM decide when to use it)
            version: Tool version following semantic versioning (e.g., "1.0.0")
            approval_mode: Whether human approval is required before execution
        """
        self.name = name
        self.description = description
        self.version = version
        self.approval_mode = approval_mode
    
    @property
    @abstractmethod
    def parameters(self) -> Dict[str, Any]:
        """
        JSON schema defining expected inputs for this tool.
        
        Must return a dictionary in JSON Schema format with:
        - type: "object"
        - properties: dict mapping parameter names to schemas
        - required: list of required parameter names
        
        Returns:
            JSON schema dictionary describing tool parameters
        
        Example:
            {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "City name"
                    },
                    "days": {
                        "type": "integer",
                        "description": "Number of days"
                    }
                },
                "required": ["city"]
            }
        """
        pass
    
    @abstractmethod
    async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
        """
        Execute the tool with the given parameters.
        
        This method should:
        1. Validate parameters (base validation happens before this)
        2. Perform the tool's action
        3. Return a ToolResult with success/result/error
        
        Args:
            parameters: Tool input parameters matching the schema
        
        Returns:
            ToolResult containing execution outcome
        
        Example:
            async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
                try:
                    result = await some_operation(parameters)
                    return ToolResult(success=True, result=result)
                except Exception as e:
                    return ToolResult(success=False, error=str(e))
        """
        pass
    
    async def execute_stream(
        self,
        parameters: Dict[str, Any],
        cancellation_token: Optional[Any] = None,
    ) -> AsyncGenerator[Union[ToolResult, Any], None]:
        """
        Execute the tool with streaming output support.
        
        Tools can override this to provide streaming capabilities for
        long-running operations. The default implementation wraps execute()
        for backward compatibility.
        
        Args:
            parameters: Tool input parameters
            cancellation_token: Optional token for cancelling execution
        
        Yields:
            Messages, events during execution, and final ToolResult
        
        Example (streaming implementation):
            async def execute_stream(self, parameters, cancellation_token=None):
                for i in range(10):
                    yield {"progress": i * 10}
                    await asyncio.sleep(0.1)
                
                final_result = await self.execute(parameters)
                yield final_result
        """
        # Default implementation: just call execute and yield result
        result = await self.execute(parameters)
        yield result
    
    def supports_streaming(self) -> bool:
        """
        Check if this tool supports streaming execution.
        
        Returns:
            True if tool has overridden execute_stream, False otherwise
        """
        # Check if execute_stream was overridden from the base class
        return type(self).execute_stream is not BaseTool.execute_stream
    
    def validate_parameters(self, params: Dict[str, Any]) -> bool:
        """
        Validate that provided parameters match the tool's schema.
        
        Performs basic validation:
        - Checks all required fields are present
        - Validates parameter types match schema expectations
        
        Subclasses can override for more sophisticated validation
        (e.g., range checks, format validation, etc.).
        
        Args:
            params: Parameters to validate
        
        Returns:
            True if parameters are valid, False otherwise
        """
        try:
            schema = self.parameters
            required_fields = schema.get("required", [])
            
            # Check required fields are present
            for field in required_fields:
                if field not in params:
                    return False
            
            # Check parameter types if specified in schema
            properties = schema.get("properties", {})
            for param_name, param_value in params.items():
                if param_name in properties:
                    expected_type = properties[param_name].get("type")
                    if expected_type and not self._check_type(
                        param_value, expected_type
                    ):
                        return False
            
            return True
        except Exception:
            return False
    
    def _check_type(self, value: Any, expected_type: str) -> bool:
        """
        Check if value matches expected JSON schema type.
        
        Maps JSON schema types to Python types:
        - string -> str
        - integer -> int
        - number -> int or float
        - boolean -> bool
        - array -> list
        - object -> dict
        
        Args:
            value: Value to check
            expected_type: JSON schema type string
        
        Returns:
            True if value matches expected type
        """
        type_mapping = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        
        expected_python_type = type_mapping.get(expected_type)
        if expected_python_type is None:
            return True  # Unknown type, assume valid
        
        return isinstance(value, expected_python_type)
    
    def to_llm_format(self) -> Dict[str, Any]:
        """
        Convert tool to OpenAI function calling format.
        
        This format is compatible with most modern LLM providers that
        support function calling (OpenAI, Anthropic, Bedrock, etc.).
        
        Version tracking pattern from Anthropic: include version in name
        for tools with version != "1.0.0" (e.g., "tool_name_v2.1.0").
        This enables tracking tool evolution and compatibility.
        
        Returns:
            Dictionary in OpenAI function calling format
        
        Example:
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "Get current weather",
                    "parameters": {...}
                }
            }
        """
        # Include version in tool name for compatibility tracking
        versioned_name = (
            f"{self.name}_v{self.version}" 
            if self.version != "1.0.0" 
            else self.name
        )
        
        return {
            "type": "function",
            "function": {
                "name": versioned_name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }
    
    def __str__(self) -> str:
        return f"{self.__class__.__name__}(name='{self.name}')"
    
    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"name='{self.name}', "
            f"description='{self.description}')"
        )


__all__ = ["ApprovalMode", "BaseTool"]
```

### Step 4: Implement FunctionTool (tools/function.py)

**File**: `src/agentbyte/tools/function.py`

```python
"""
Function tool implementation for wrapping Python functions as tools.

Automatically converts Python functions into tools by inspecting signatures,
extracting type hints, and generating JSON schemas for LLM function calling.
"""
import inspect
from typing import Any, Callable, Dict, List, Optional, get_type_hints

from .base import ApprovalMode, BaseTool
from ..types import ToolResult


class FunctionTool(BaseTool):
    """
    Tool that wraps a Python function for use by agents.
    
    Automatically extracts function metadata (name, docstring, parameters)
    and provides parameter validation based on type hints. Supports both
    sync and async functions transparently.
    
    The FunctionTool inspects the function signature at initialization time
    and builds a JSON schema that can be sent to the LLM. When executed,
    it validates parameters and handles both synchronous and asynchronous
    function calls with proper error handling.
    
    Example:
        def calculate_sum(a: int, b: int) -> int:
            '''Add two numbers.'''
            return a + b
        
        tool = FunctionTool(calculate_sum)
        result = await tool.execute({"a": 5, "b": 3})
        # result.success == True, result.result == 8
    """
    
    def __init__(
        self,
        func: Callable,
        name: Optional[str] = None,
        description: Optional[str] = None,
        version: str = "1.0.0",
        approval_mode: ApprovalMode = ApprovalMode.NEVER,
    ):
        """
        Create a tool from a Python function.
        
        Args:
            func: The function to wrap as a tool
            name: Optional custom name (defaults to function name)
            description: Optional custom description (defaults to docstring)
            version: Tool version following semantic versioning
            approval_mode: Whether approval is required before execution
        """
        self.func = func
        tool_name = name or func.__name__
        tool_description = (
            description or 
            func.__doc__ or 
            f"Execute {func.__name__} function"
        )
        
        super().__init__(tool_name, tool_description, version, approval_mode)
        
        # Extract function metadata for schema generation
        self.signature = inspect.signature(func)
        self.type_hints = get_type_hints(func)
        self._parameters_schema = self._build_parameters_schema()
    
    @property
    def parameters(self) -> Dict[str, Any]:
        """Get JSON schema for function parameters."""
        return self._parameters_schema
    
    def __call__(self, *args, **kwargs):
        """
        Make the tool callable like the original function.
        
        This allows decorated functions to be called directly for testing:
        
            @tool
            def get_weather(city: str) -> str:
                return f"Weather in {city}"
            
            # Can still call directly!
            result = get_weather("Seattle")
        """
        return self.func(*args, **kwargs)
    
    async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
        """
        Execute the wrapped function with validated parameters.
        
        Handles both sync and async functions transparently. Validates
        parameters before execution and catches all exceptions, returning
        them as ToolResult with success=False.
        
        Args:
            parameters: Function arguments as dictionary
        
        Returns:
            ToolResult with function execution outcome
        """
        try:
            # Validate parameters before execution
            if not self.validate_parameters(parameters):
                return ToolResult(
                    success=False,
                    result=None,
                    error="Invalid parameters provided",
                    metadata={"tool_name": self.name},
                )
            
            # Execute function (handle both sync and async)
            if inspect.iscoroutinefunction(self.func):
                result = await self.func(**parameters)
            else:
                result = self.func(**parameters)
            
            return ToolResult(
                success=True,
                result=result,
                error=None,
                metadata={"tool_name": self.name},
            )
        
        except Exception as e:
            return ToolResult(
                success=False,
                result=None,
                error=str(e),
                metadata={
                    "tool_name": self.name,
                    "exception_type": type(e).__name__
                },
            )
    
    def _build_parameters_schema(self) -> Dict[str, Any]:
        """
        Build JSON schema from function signature and type hints.
        
        This is the core schema generation logic that converts Python
        type hints into JSON Schema format for LLMs. It:
        1. Iterates through function parameters
        2. Extracts type hints for each parameter
        3. Converts Python types to JSON Schema types
        4. Identifies required vs optional parameters
        5. Extracts enum values from Literal types
        
        Returns:
            JSON schema dictionary
        """
        schema = {
            "type": "object",
            "properties": {},
            "required": []
        }
        
        for param_name, param in self.signature.parameters.items():
            # Skip 'self' parameter for methods
            if param_name == "self":
                continue
            
            # Get parameter type from type hints
            param_type = self.type_hints.get(param_name)
            json_type = self._python_type_to_json_type(param_type)
            
            property_schema = {"type": json_type}
            
            # Add enum constraint for Literal types or Enum classes
            enum_values = self._extract_enum_values(param_type)
            if enum_values:
                property_schema["enum"] = enum_values
            
            # Add description from docstring if available
            # (Simplified - full implementation would parse docstrings)
            if hasattr(param, "annotation") and hasattr(
                param.annotation, "__doc__"
            ):
                property_schema["description"] = param.annotation.__doc__
            
            schema["properties"][param_name] = property_schema
            
            # Add to required if no default value
            if param.default == inspect.Parameter.empty:
                schema["required"].append(param_name)
        
        return schema
    
    def _python_type_to_json_type(self, python_type: Any) -> str:
        """
        Convert Python type hints to JSON schema types.
        
        Type mapping:
        - str -> "string"
        - int -> "integer"
        - float -> "number"
        - bool -> "boolean"
        - list/List -> "array"
        - dict/Dict -> "object"
        - None/Optional -> "null"
        - Unknown/Union -> "string" (fallback)
        
        Args:
            python_type: Python type annotation
        
        Returns:
            JSON schema type string
        """
        if python_type is None or python_type == type(None):
            return "null"
        elif python_type == str:
            return "string"
        elif python_type == int:
            return "integer"
        elif python_type == float:
            return "number"
        elif python_type == bool:
            return "boolean"
        elif python_type == list or (
            hasattr(python_type, "__origin__") and 
            python_type.__origin__ == list
        ):
            return "array"
        elif python_type == dict or (
            hasattr(python_type, "__origin__") and 
            python_type.__origin__ == dict
        ):
            return "object"
        else:
            # For Union types, complex types, etc., default to string
            return "string"
    
    def _extract_enum_values(self, param_type: Any) -> Optional[List[Any]]:
        """
        Extract enum values from Literal types or Enum classes.
        
        Supports:
        - typing.Literal["a", "b", "c"]
        - enum.Enum classes
        
        Args:
            param_type: Python type annotation
        
        Returns:
            List of enum values or None
        """
        # Handle typing.Literal (Python 3.8+)
        if hasattr(param_type, "__origin__"):
            origin = getattr(param_type, "__origin__", None)
            
            # Check for Literal type
            try:
                from typing import Literal, get_args, get_origin
                
                if get_origin(param_type) is Literal:
                    return list(get_args(param_type))
            except (ImportError, AttributeError):
                pass
            
            # Fallback for older Python or typing_extensions
            if hasattr(param_type, "__args__"):
                type_name = str(origin) if origin else str(param_type)
                if "Literal" in type_name:
                    return list(param_type.__args__)
        
        # Handle Enum classes
        try:
            from enum import Enum
            
            if isinstance(param_type, type) and issubclass(param_type, Enum):
                return [e.value for e in param_type]
        except (TypeError, AttributeError):
            pass
        
        return None


__all__ = ["FunctionTool"]
```

### Step 5: Implement @tool Decorator (tools/decorator.py)

**File**: `src/agentbyte/tools/decorator.py`

```python
"""
Tool decorator for creating tools from functions with ergonomic syntax.

Provides the @tool decorator that converts Python functions into FunctionTool
instances, supporting both @tool and @tool(...) syntaxes.
"""
from typing import Callable, Optional, TypeVar, Union

from .base import ApprovalMode
from .function import FunctionTool

T = TypeVar("T")


def tool(
    func: Optional[Callable[..., T]] = None,
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
    approval_mode: Union[str, ApprovalMode] = "never_require",
) -> Union[FunctionTool, Callable[[Callable[..., T]], FunctionTool]]:
    """
    Decorator to create a tool from a function with approval support.
    
    This decorator can be used in three ways:
    
    1. Without parentheses (uses all defaults):
        @tool
        def get_weather(city: str) -> str:
            '''Get weather for a city.'''
            return f"Weather in {city}: Sunny"
    
    2. With approval required:
        @tool(approval_mode="always_require")
        def delete_file(path: str) -> str:
            '''Delete a file from the filesystem.'''
            os.remove(path)
            return f"Deleted {path}"
    
    3. With custom name and description:
        @tool(name="weather_tool", description="Gets weather info")
        def my_weather_func(city: str) -> str:
            return f"Weather in {city}"
    
    Args:
        func: The function to wrap (when used without parentheses)
        name: Tool name (defaults to function name)
        description: Tool description (defaults to docstring)
        approval_mode: When to require approval ("always_require" or "never_require")
    
    Returns:
        FunctionTool instance or decorator function
    """
    
    def decorator(f: Callable[..., T]) -> FunctionTool:
        # Convert string to enum if needed
        mode = (
            ApprovalMode(approval_mode)
            if isinstance(approval_mode, str)
            else approval_mode
        )
        
        tool_name = name or f.__name__
        tool_desc = description or f.__doc__ or ""
        
        return FunctionTool(
            func=f,
            name=tool_name,
            description=tool_desc,
            approval_mode=mode,
        )
    
    # If func is provided, we're being used without parentheses
    if func is not None:
        return decorator(func)
    
    # Otherwise, we're being used with parentheses
    return decorator


__all__ = ["tool"]
```

### Step 6: Export Public API (tools/__init__.py)

**File**: `src/agentbyte/tools/__init__.py`

```python
"""
Tool system for Agentbyte framework.

This module provides the foundation for tools that agents can use to
interact with the world beyond text generation.

Example usage:
    from agentbyte.tools import tool, BaseTool, FunctionTool, ApprovalMode
    
    # Simple function tool
    @tool
    def get_weather(city: str) -> str:
        '''Get current weather for a city.'''
        return f"Weather in {city}: sunny"
    
    # Tool requiring approval
    @tool(approval_mode="always_require")
    def delete_file(path: str) -> str:
        '''Delete a file (requires approval).'''
        os.remove(path)
        return f"Deleted {path}"
    
    # Custom tool implementation
    class DatabaseTool(BaseTool):
        @property
        def parameters(self):
            return {"type": "object", "properties": {"query": {"type": "string"}}}
        
        async def execute(self, parameters):
            # ... database logic ...
            return ToolResult(success=True, result=data)
"""

from .base import ApprovalMode, BaseTool
from .decorator import tool
from .function import FunctionTool

__all__ = [
    "ApprovalMode",
    "BaseTool",
    "FunctionTool",
    "tool",
]
```

---

## Part 4: Usage Examples & Validation

### Example 1: Simple Function Tool

```python
from agentbyte.tools import tool
import asyncio

@tool
def calculate_sum(a: int, b: int) -> int:
    """Add two numbers together."""
    return a + b

# Can still be called directly
result = calculate_sum(5, 3)
print(result)  # Output: 8

# Check tool metadata
print(calculate_sum.name)  # Output: "calculate_sum"
print(calculate_sum.description)  # Output: "Add two numbers together."

# Get JSON schema for LLM
schema = calculate_sum.to_llm_format()
print(schema)
# Output:
# {
#     "type": "function",
#     "function": {
#         "name": "calculate_sum",
#         "description": "Add two numbers together.",
#         "parameters": {
#             "type": "object",
#             "properties": {
#                 "a": {"type": "integer"},
#                 "b": {"type": "integer"}
#             },
#             "required": ["a", "b"]
#         }
#     }
# }

# Execute as a tool
async def test_tool():
    result = await calculate_sum.execute({"a": 5, "b": 3})
    print(f"Success: {result.success}")  # True
    print(f"Result: {result.result}")    # 8
    print(f"Error: {result.error}")      # None

asyncio.run(test_tool())
```

### Example 2: Async Function Tool

```python
import asyncio
from agentbyte.tools import tool

@tool
async def fetch_data(url: str) -> str:
    """Fetch data from a URL (simulated)."""
    await asyncio.sleep(0.1)  # Simulate network delay
    return f"Data from {url}"

async def test_async_tool():
    result = await fetch_data.execute({"url": "https://api.example.com"})
    print(f"Success: {result.success}")
    print(f"Result: {result.result}")

asyncio.run(test_async_tool())
```

### Example 3: Tool with Literal Types

```python
from agentbyte.tools import tool
from typing import Literal

@tool
def process_action(action: Literal["start", "stop", "pause"]) -> str:
    """Process an action."""
    return f"Processing: {action}"

# Check schema includes enum
schema = process_action.parameters
print(schema["properties"]["action"])
# Output: {"type": "string", "enum": ["start", "stop", "pause"]}
```

### Example 4: Custom Tool Implementation

```python
from agentbyte.tools import BaseTool
from agentbyte.types import ToolResult
from typing import Dict, Any

class DatabaseQueryTool(BaseTool):
    """Custom tool that queries a database."""
    
    def __init__(self, connection_string: str):
        super().__init__(
            name="database_query",
            description="Execute SQL queries on the database",
            version="1.0.0"
        )
        self.connection_string = connection_string
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "SQL query to execute"
                }
            },
            "required": ["query"]
        }
    
    async def execute(self, parameters: Dict[str, Any]) -> ToolResult:
        query = parameters["query"]
        
        try:
            # Simulated database query
            results = f"Results for: {query}"
            
            return ToolResult(
                success=True,
                result=results,
                error=None,
                metadata={"tool_name": self.name, "query": query}
            )
        except Exception as e:
            return ToolResult(
                success=False,
                result=None,
                error=str(e),
                metadata={"tool_name": self.name}
            )
```

### Validation Test Script

```python
"""
Comprehensive test script to validate tool implementation.
Run this to verify all functionality works correctly.
"""
import asyncio
from agentbyte.tools import tool, FunctionTool, ApprovalMode
from typing import Literal


# Test 1: Simple sync function
@tool
def add_numbers(x: int, y: int) -> int:
    """Add two numbers."""
    return x + y


# Test 2: Async function
@tool
async def async_operation(delay: float) -> str:
    """Perform an async operation."""
    await asyncio.sleep(delay)
    return f"Completed after {delay}s"


# Test 3: Function with optional parameters
@tool
def greet(name: str, greeting: str = "Hello") -> str:
    """Greet someone."""
    return f"{greeting}, {name}!"


# Test 4: Function with Literal types
@tool
def process_action(action: Literal["start", "stop", "pause"]) -> str:
    """Process an action."""
    return f"Processing: {action}"


async def run_tests():
    print("=== Test 1: Simple Function ===")
    result1 = await add_numbers.execute({"x": 5, "y": 3})
    assert result1.success == True
    assert result1.result == 8
    print(f"✓ Result: {result1.result}")
    
    print("\n=== Test 2: Async Function ===")
    result2 = await async_operation.execute({"delay": 0.1})
    assert result2.success == True
    assert "Completed after 0.1s" in result2.result
    print(f"✓ Result: {result2.result}")
    
    print("\n=== Test 3: Optional Parameters ===")
    result3a = await greet.execute({"name": "Alice"})
    assert result3a.success == True
    assert result3a.result == "Hello, Alice!"
    print(f"✓ Default greeting: {result3a.result}")
    
    result3b = await greet.execute({"name": "Bob", "greeting": "Hi"})
    assert result3b.success == True
    assert result3b.result == "Hi, Bob!"
    print(f"✓ Custom greeting: {result3b.result}")
    
    print("\n=== Test 4: Schema Validation ===")
    schema = add_numbers.parameters
    assert schema["type"] == "object"
    assert "x" in schema["properties"]
    assert "y" in schema["properties"]
    assert set(schema["required"]) == {"x", "y"}
    print(f"✓ Schema valid: {schema}")
    
    print("\n=== Test 5: LLM Format ===")
    llm_format = add_numbers.to_llm_format()
    assert llm_format["type"] == "function"
    assert llm_format["function"]["name"] == "add_numbers"
    assert "parameters" in llm_format["function"]
    print(f"✓ LLM Format: {llm_format}")
    
    print("\n=== Test 6: Error Handling ===")
    result6 = await add_numbers.execute({"x": "invalid", "y": 3})
    assert result6.success == False
    assert result6.error is not None
    print(f"✓ Error handled: {result6.error[:50]}...")
    
    print("\n=== Test 7: Enum Values (Literal) ===")
    schema7 = process_action.parameters
    assert "enum" in schema7["properties"]["action"]
    assert set(schema7["properties"]["action"]["enum"]) == {"start", "stop", "pause"}
    print(f"✓ Enum values: {schema7['properties']['action']['enum']}")
    
    print("\n=== Test 8: Direct Calling ===")
    direct_result = add_numbers(10, 20)
    assert direct_result == 30
    print(f"✓ Direct call works: {direct_result}")
    
    print("\n=== Test 9: Missing Required Parameter ===")
    result9 = await add_numbers.execute({"x": 5})
    assert result9.success == False
    assert "Invalid parameters" in result9.error
    print(f"✓ Validation works: {result9.error}")
    
    print("\n✅ All tests passed!")


if __name__ == "__main__":
    asyncio.run(run_tests())
```

---

## Part 5: Parity Checklist with picoagents

### ✅ BaseTool Interface
- [x] `name`, `description`, `version` attributes
- [x] `approval_mode` enum (NEVER, ALWAYS)
- [x] `parameters` property returning JSON schema
- [x] `execute()` async method returning ToolResult
- [x] `execute_stream()` for streaming support
- [x] `supports_streaming()` detection method
- [x] `validate_parameters()` for parameter checking
- [x] `to_llm_format()` for OpenAI function calling format
- [x] Versioned tool names (name_v2.0.0 pattern)

### ✅ FunctionTool Implementation
- [x] Function signature inspection via `inspect.signature()`
- [x] Type hint extraction via `typing.get_type_hints()`
- [x] JSON schema generation from Python types
- [x] Handles sync and async functions via `inspect.iscoroutinefunction()`
- [x] Literal type support for enum values
- [x] Enum class support
- [x] Required vs optional parameter detection
- [x] Error handling with ToolResult
- [x] `__call__` method for direct invocation

### ✅ Decorator Ergonomics
- [x] `@tool` without parentheses
- [x] `@tool(name=..., description=..., approval_mode=...)`
- [x] String-to-enum conversion for approval_mode
- [x] Preserves function callability via `__call__`

### ✅ ToolResult Structure
- [x] `success` boolean flag
- [x] `result` field for any output type
- [x] `error` field for failure messages
- [x] `metadata` dict for extensibility
- [x] Pydantic BaseModel with validation
- [x] `frozen = True` for immutability

---

## Summary

This study document provides:

1. **Chapter Understanding**: Key concepts from 4.6-4.6.4 about tools, function calling, and developer ergonomics
2. **Implementation Learning**: Deep dive into picoagents code with explanations of design decisions
3. **Complete Implementation**: Full code for Agentbyte's tool system with detailed comments
4. **Usage Examples**: Practical demonstrations of all features
5. **Validation**: Test script to verify correctness
6. **Parity Checklist**: Verification that Agentbyte matches picoagents capabilities

The implementation is ready to be added to `src/agentbyte/tools/` following the code provided in Part 3.
