"""
Authentication utility functions for creating token providers.

This module provides helper functions for setting up various authentication
methods with Azure OpenAI and other Azure services. Each function returns
a callable token provider that can be passed to AsyncAzureOpenAI.

Authentication Methods Supported:
1. DefaultAzureCredential: Automatic credential detection (recommended for production)
2. CertificateCredential: X.509 certificate-based authentication
3. Direct Token: Pre-authenticated token for reuse
"""

from typing import Callable


def get_default_token_provider() -> Callable[[], str]:
    """
    Create a token provider using DefaultAzureCredential.

    DefaultAzureCredential automatically tries multiple authentication methods
    in sequence (environment variables, managed identity, Azure CLI, etc.).
    Recommended for production environments.

    Returns:
        Callable that provides a bearer token string

    Raises:
        ImportError: If azure-identity is not installed
        azure.identity.CredentialUnavailableError: If no credentials found

    Example:
        >>> from agentbyte.llm import AzureOpenAIChatCompletionClient
        >>> from agentbyte.llm.auth import get_default_token_provider
        >>> from openai import AsyncAzureOpenAI
        >>>
        >>> token_provider = get_default_token_provider()
        >>> azure_client = AsyncAzureOpenAI(
        ...     azure_endpoint="https://myresource.openai.azure.com/",
        ...     azure_ad_token_provider=token_provider,
        ...     api_version="2024-10-21"
        ... )
        >>> llm = AzureOpenAIChatCompletionClient(
        ...     model="gpt-4",
        ...     client=azure_client
        ... )
    """
    try:
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
    except ImportError:
        raise ImportError(
            "azure-identity is required for DefaultAzureCredential. "
            "Install with: pip install azure-identity"
        )

    credentials = DefaultAzureCredential()
    token_provider = get_bearer_token_provider(
        credentials, "https://cognitiveservices.azure.com/.default"
    )
    return token_provider


def get_certificate_token_provider(
    tenant_id: str,
    client_id: str,
    certificate_data: bytes,
    scope: str = "https://cognitiveservices.azure.com/.default",
) -> Callable[[], str]:
    """
    Create a token provider using X.509 certificate authentication.

    Certificate-based authentication is ideal for:
    - Service principals in automated systems
    - Non-interactive authentication with strong security
    - Scenarios where you need deterministic auth (no user interaction)

    Args:
        tenant_id: Azure AD tenant ID
        client_id: Service principal client ID (application ID)
        certificate_data: Certificate data in PEM format (bytes)
                         Can include private key and certificate chain
        scope: Token scope (default: cognitiveservices scope for Azure OpenAI)

    Returns:
        Callable that provides a bearer token string

    Raises:
        ImportError: If azure-identity is not installed
        ValueError: If certificate_data is invalid
        azure.identity.CredentialUnavailableError: If authentication fails

    Example:
        >>> from agentbyte.llm.auth import get_certificate_token_provider
        >>> from openai import AsyncAzureOpenAI
        >>> import os
        >>>
        >>> # Load certificate from environment or file
        >>> cert_data = os.environ["PRIVATE_CERT_KEY"].encode()
        >>>
        >>> token_provider = get_certificate_token_provider(
        ...     tenant_id=os.environ["TENANT_ID"],
        ...     client_id=os.environ["CLIENT_ID"],
        ...     certificate_data=cert_data
        ... )
        >>>
        >>> azure_client = AsyncAzureOpenAI(
        ...     azure_endpoint="https://myresource.openai.azure.com/",
        ...     azure_ad_token_provider=token_provider,
        ...     api_version="2024-10-21"
        ... )
    """
    try:
        from azure.identity import CertificateCredential
    except ImportError:
        raise ImportError(
            "azure-identity is required for CertificateCredential. "
            "Install with: pip install azure-identity"
        )

    credential = CertificateCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        certificate_data=certificate_data,
    )

    def token_provider() -> str:
        """Get a fresh token from the certificate credential."""
        token = credential.get_token(scope)
        return token.token

    return token_provider


def create_token_provider_from_string(
    token: str,
) -> Callable[[], str]:
    """
    Create a simple token provider from a pre-authenticated token.

    Useful for:
    - Testing and development
    - Using pre-generated tokens
    - Scenarios where you manage token lifecycle externally

    Args:
        token: Azure AD bearer token string

    Returns:
        Callable that always returns the provided token

    Warning:
        This approach has limitations:
        - Token must be manually refreshed before expiration
        - No automatic token refresh
        - Use get_default_token_provider() for production instead

    Example:
        >>> from agentbyte.llm.auth import create_token_provider_from_string
        >>> from openai import AsyncAzureOpenAI
        >>> import os
        >>>
        >>> # Get token from environment (e.g., from CI/CD system)
        >>> token = os.environ["AZURE_AD_TOKEN"]
        >>>
        >>> token_provider = create_token_provider_from_string(token)
        >>> azure_client = AsyncAzureOpenAI(
        ...     azure_endpoint="https://myresource.openai.azure.com/",
        ...     azure_ad_token_provider=token_provider,
        ...     api_version="2024-10-21"
        ... )
    """

    def token_provider() -> str:
        """Return the static token."""
        return token

    return token_provider


__all__ = [
    "get_default_token_provider",
    "get_certificate_token_provider",
    "create_token_provider_from_string",
]
