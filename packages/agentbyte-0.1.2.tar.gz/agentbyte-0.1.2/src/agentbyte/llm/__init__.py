"""
LLM client implementations for Agentbyte framework.

This module provides abstract interfaces and implementations for
communicating with various LLM providers (OpenAI, Anthropic, etc.).

Core Components:
    - BaseChatCompletionClient: Abstract base class for all LLM providers
    - Message Types: SystemMessage, UserMessage, AssistantMessage, ToolMessage
    - Response Types: ChatCompletionResult, ChatCompletionChunk
    - Exception Types: ModelClientError, RateLimitError, AuthenticationError

Example:
    from agentbyte.llm import (
        BaseChatCompletionClient,
        SystemMessage,
        UserMessage
    )

    # Use with any concrete provider implementation
    messages = [
        SystemMessage(content="You are helpful."),
        UserMessage(content="What is 2+2?")
    ]
"""

from .base import (
    BaseChatCompletionClient,
    BaseChatCompletionClientConfig,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)
from .openai import OpenAIChatCompletionClient, OpenAIChatCompletionClientConfig
from .azure_openai import (
    AzureOpenAIChatCompletionClient,
    AzureOpenAIChatCompletionClientConfig,
)
from .auth import (
    get_default_token_provider,
    get_certificate_token_provider,
    create_token_provider_from_string,
)
# Import message types and usage from root module (picoagents-aligned)
from agentbyte.messages import (
    BaseMessage,
    Message,
    SystemMessage,
    UserMessage,
    AssistantMessage,
    ToolMessage,
    ToolCallRequest,
    MultiModalMessage,
    Usage,
)
# Import LLM response types from this module
from .types import (
    ChatCompletionChunk,
    ChatCompletionResult,
    ModelClientError,
)

__all__ = [
    # Base classes
    "BaseChatCompletionClient",
    "BaseChatCompletionClientConfig",
    # Provider implementations
    "OpenAIChatCompletionClient",
    "OpenAIChatCompletionClientConfig",
    "AzureOpenAIChatCompletionClient",
    "AzureOpenAIChatCompletionClientConfig",
    # Authentication utilities
    "get_default_token_provider",
    "get_certificate_token_provider",
    "create_token_provider_from_string",
    # Exception types
    "ModelClientError",
    "RateLimitError",
    "AuthenticationError",
    "InvalidRequestError",
    # Message types (from agentbyte.messages)
    "BaseMessage",
    "Message",
    "SystemMessage",
    "UserMessage",
    "AssistantMessage",
    "ToolMessage",
    "ToolCallRequest",
    "MultiModalMessage",
    # Result types
    "Usage",
    "ChatCompletionResult",
    "ChatCompletionChunk",
]
