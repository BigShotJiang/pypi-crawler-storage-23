# """Core settings module for loading environment variables."""

# from pathlib import Path
# from typing import Optional, TypeVar

# from pydantic import Field
# from pydantic_settings import BaseSettings, SettingsConfigDict

# T = TypeVar("T", bound="AgentbyteBaseSettings")


# class AgentbyteBaseSettings(BaseSettings):
#     """Base settings class for all agentbyte configuration.

#     This class provides common functionality for loading environment variables
#     from a specific path, useful for notebooks and custom configurations.
#     All agentbyte settings classes should inherit from this base class.
#     """

#     @classmethod
#     def from_env_file(cls: type[T], env_path: Path) -> T:
#         """Load settings from a specific .env file path.

#         Args:
#             env_path: Path to the .env file

#         Returns:
#             Settings instance with loaded environment variables

#         Raises:
#             FileNotFoundError: If the specified .env file does not exist
#         """
#         env_path = Path(env_path) if not isinstance(env_path, Path) else env_path
#         if not env_path.exists():
#             raise FileNotFoundError(f"Environment file not found: {env_path}")
#         return cls(_env_file=str(env_path))


# class AppSettings(AgentbyteBaseSettings):
#     """Application-level configuration settings.

#     Environment variables should use the APP_ prefix.
#     Example: APP_LOG_LEVEL, APP_ENVIRONMENT

#     Usage:
#         settings = AppSettings()
#         # Or from custom path:
#         settings = AppSettings.from_env_file(Path("/path/to/.env"))
#     """

#     log_level: str = Field("INFO", description="Logging level for the application")
#     environment: str = Field("local", description="Application environment (local, dev, staging, prod)")

#     model_config = SettingsConfigDict(
#         env_prefix="APP_",
#         env_file=".env",
#         env_file_encoding="utf-8",
#         case_sensitive=False,
#         extra="ignore",
#     )


# class PostgresSettings(AgentbyteBaseSettings):
#     """PostgreSQL database configuration settings.

#     All PostgreSQL-related environment variables should use the POSTGRES_ prefix.
#     Example: POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_HOST, etc.

#     Usage:
#         # Default usage (loads from .env in current directory)
#         settings = PostgresSettings()

#         # Load from custom path (useful in notebooks)
#         from pathlib import Path
#         settings = PostgresSettings.from_env_file(Path("/path/to/.env"))
#     """

#     user: Optional[str] = Field(None, description="PostgreSQL username")
#     password: Optional[str] = Field(None, description="PostgreSQL password")
#     host: Optional[str] = Field("localhost", description="PostgreSQL host")
#     port: Optional[int] = Field(5432, description="PostgreSQL port")
#     db: Optional[str] = Field(None, description="PostgreSQL database name")

#     model_config = SettingsConfigDict(
#         env_prefix="POSTGRES_",
#         env_file=".env",
#         env_file_encoding="utf-8",
#         case_sensitive=False,
#         extra="ignore",
#     )

#     @property
#     def url(self) -> Optional[str]:
#         """Generate PostgreSQL connection URL if all required fields are present."""
#         if all([self.user, self.password, self.host, self.db]):
#             return (
#                 f"postgresql://{self.user}:{self.password}"
#                 f"@{self.host}:{self.port}/{self.db}"
#             )
#         return None


# class OpenAISettings(AgentbyteBaseSettings):
#     """OpenAI configuration settings.

#     Environment variables should use the OPENAI_ prefix.
#     Example: OPENAI_API_KEY

#     Usage:
#         settings = OpenAISettings()
#         # Or from custom path:
#         settings = OpenAISettings.from_env_file(Path("/path/to/.env"))
#     """

#     api_key: str = Field(..., description="OpenAI API key")

#     model_config = SettingsConfigDict(
#         env_prefix="OPENAI_",
#         env_file=".env",
#         env_file_encoding="utf-8",
#         case_sensitive=False,
#         extra="ignore",
#     )