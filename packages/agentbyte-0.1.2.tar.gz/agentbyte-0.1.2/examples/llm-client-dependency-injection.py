"""
Example: LLM Client Dependency Injection

Demonstrates how to use dependency injection with BaseChatCompletionClient
to support different authentication methods and client configurations.

This pattern enables:
- Multiple authentication methods (API keys, OAuth, service principals, etc.)
- Different environments (dev, staging, prod) with different credentials
- Custom client configurations (proxies, timeouts, base URLs, etc.)
- Easy testing with mock clients
- Sync/async API adapters

Key Concepts:
    1. Create and configure an HTTP client (e.g., AsyncOpenAI) with your auth method
    2. Inject it into an agentbyte LLM client when initializing
    3. agentbyte doesn't need to know about authentication details
"""

import asyncio
from typing import Any, Dict

# Note: These examples show the pattern. Actual providers (OpenAIChatCompletionClient,
# etc.) will be implemented in src/agentbyte/llm/openai.py, etc.


# ============================================================================
# Example 1: OpenAI with API Key (Most Common)
# ============================================================================

async def example_openai_api_key():
    """Basic OpenAI setup with API key."""
    from openai import AsyncOpenAI
    # Placeholder for when OpenAIChatCompletionClient is implemented
    # from agentbyte.llm import OpenAIChatCompletionClient, UserMessage

    # Step 1: Create configured OpenAI client
    openai_client = AsyncOpenAI(api_key="sk-...")

    # Step 2: Inject into agentbyte (when implemented)
    # llm = OpenAIChatCompletionClient(
    #     model="gpt-4.1-mini",
    #     client=openai_client
    # )
    #
    # # Use it
    # result = await llm.create(
    #     messages=[UserMessage(content="Hello!")]
    # )
    # print(result.message.content)

    print("✓ Example 1: OpenAI with API key - Pattern shown")


# ============================================================================
# Example 2: OpenAI with Organization ID
# ============================================================================

async def example_openai_with_organization():
    """OpenAI with organization billing."""
    from openai import AsyncOpenAI

    # Configure client with organization
    openai_client = AsyncOpenAI(
        api_key="sk-...",
        organization="org-123"  # Billing to specific organization
    )

    # Inject into agentbyte
    # llm = OpenAIChatCompletionClient(
    #     model="gpt-4.1-mini",
    #     client=openai_client
    # )

    print("✓ Example 2: OpenAI with organization ID - Pattern shown")


# ============================================================================
# Example 3: Custom Proxy and Timeout Configuration
# ============================================================================

async def example_openai_with_proxy():
    """OpenAI with custom proxy and timeout."""
    from openai import AsyncOpenAI

    # Configure client with proxy and timeout
    openai_client = AsyncOpenAI(
        api_key="sk-...",
        base_url="https://corporate-proxy.company.com/openai",  # Via proxy
        timeout=60.0
    )

    # Inject with default config
    # llm = OpenAIChatCompletionClient(
    #     model="gpt-4.1-mini",
    #     client=openai_client,
    #     config={"temperature": 0.7, "max_tokens": 2000}
    # )

    print("✓ Example 3: Custom proxy and timeout - Pattern shown")


# ============================================================================
# Example 4: Environment-Based Configuration
# ============================================================================

async def example_environment_based():
    """Different configurations per environment."""
    import os
    from openai import AsyncOpenAI

    env = os.getenv("ENVIRONMENT", "development")

    # Different configuration per environment
    configs = {
        "development": {
            "api_key": "sk-dev-...",
            "base_url": None,  # Use default
            "timeout": 30.0
        },
        "staging": {
            "api_key": "sk-staging-...",
            "base_url": "https://staging-proxy.company.com/openai",
            "timeout": 45.0
        },
        "production": {
            "api_key": "sk-prod-...",
            "base_url": "https://prod-proxy.company.com/openai",
            "timeout": 60.0
        }
    }

    config = configs[env]
    openai_client = AsyncOpenAI(**config)

    # Inject into agentbyte
    # llm = OpenAIChatCompletionClient(
    #     model="gpt-4.1-mini",
    #     client=openai_client
    # )

    print(f"✓ Example 4: Environment-based ({env}) - Pattern shown")


# ============================================================================
# Example 5: Custom Adapter for Non-OpenAI Clients
# ============================================================================

class CustomHttpClientAdapter:
    """Adapter for custom HTTP clients to match agentbyte's interface."""

    def __init__(self, custom_client: Any):
        """Wrap a custom HTTP client."""
        self.custom_client = custom_client

    async def chat_completions_create(self, **kwargs):
        """Adapt custom client to expected interface."""
        # Transform kwargs as needed for your custom client
        return await self.custom_client.make_completion(**kwargs)


async def example_custom_adapter():
    """Using custom HTTP client via adapter."""

    class MyCustomHttpClient:
        """Example custom HTTP client."""

        async def make_completion(self, **kwargs):
            """Mock implementation."""
            return {"choices": [{"message": {"content": "Hello!"}}]}

    # Create custom client
    custom_client = MyCustomHttpClient()

    # Wrap with adapter
    adapter = CustomHttpClientAdapter(custom_client)

    # Inject adapted client
    # llm = CustomChatCompletionClient(
    #     model="my-model",
    #     client=adapter
    # )

    print("✓ Example 5: Custom adapter - Pattern shown")


# ============================================================================
# Example 6: OAuth/Token-Based Authentication
# ============================================================================

class OAuthTokenProvider:
    """Example OAuth token provider."""

    def __init__(self, client_id: str, client_secret: str, token_url: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token_url = token_url
        self.token = None

    async def get_token(self) -> str:
        """Get valid OAuth token (with refresh if needed)."""
        # In real implementation:
        # - Check if token is expired
        # - Refresh if needed via token_url
        # - Return valid token
        if not self.token:
            await self._refresh_token()
        return self.token

    async def _refresh_token(self):
        """Refresh OAuth token."""
        # Make request to token_url with client_id/secret
        self.token = "oauth_token_..."


class OAuthHttpClientAdapter:
    """HTTP client that injects OAuth tokens."""

    def __init__(self, base_client, token_provider: OAuthTokenProvider):
        self.base_client = base_client
        self.token_provider = token_provider

    async def chat_completions_create(self, **kwargs):
        """Add OAuth token to request headers."""
        token = await self.token_provider.get_token()

        # Inject token into headers
        if "headers" not in kwargs:
            kwargs["headers"] = {}
        kwargs["headers"]["Authorization"] = f"Bearer {token}"

        return await self.base_client.chat_completions_create(**kwargs)


async def example_oauth():
    """Using OAuth for authentication."""

    # Create OAuth token provider
    token_provider = OAuthTokenProvider(
        client_id="client-123",
        client_secret="secret-...",
        token_url="https://auth.company.com/oauth/token"
    )

    # Create base HTTP client (would be your actual HTTP client)
    # base_client = create_http_client()

    # Wrap with OAuth adapter
    # oauth_adapter = OAuthHttpClientAdapter(base_client, token_provider)

    # Inject into agentbyte
    # llm = CustomChatCompletionClient(
    #     model="...",
    #     client=oauth_adapter
    # )

    print("✓ Example 6: OAuth/Token authentication - Pattern shown")


# ============================================================================
# Example 7: Sync to Async Adapter
# ============================================================================

class SyncToAsyncAdapter:
    """Adapter for sync HTTP clients to async interface."""

    def __init__(self, sync_client):
        """Wrap a sync HTTP client."""
        self.sync_client = sync_client

    async def chat_completions_create(self, **kwargs):
        """Run sync call in executor to make it async."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.sync_client.chat.completions.create(**kwargs)
        )


async def example_sync_to_async():
    """Using sync HTTP client with async agentbyte."""
    # Note: In real code you'd use:
    # from openai import OpenAI  # sync client
    # sync_client = OpenAI(api_key="sk-...")
    # adapter = SyncToAsyncAdapter(sync_client)
    #
    # llm = OpenAIChatCompletionClient(
    #     model="gpt-4.1-mini",
    #     client=adapter
    # )

    print("✓ Example 7: Sync to async adapter - Pattern shown")


# ============================================================================
# Example 8: Multi-Provider Configuration
# ============================================================================

async def example_multi_provider():
    """Configure multiple LLM providers."""
    from openai import AsyncOpenAI

    # Create clients for different providers
    openai_client = AsyncOpenAI(api_key="sk-...")
    # anthropic_client = AsyncAnthropic(api_key="...")  # When available
    # azure_client = AsyncAzureOpenAI(...)              # When available

    # Create agentbyte instances for each
    # openai_llm = OpenAIChatCompletionClient(
    #     model="gpt-4.1-mini",
    #     client=openai_client
    # )
    # anthropic_llm = AnthropicChatCompletionClient(
    #     model="claude-3-sonnet",
    #     client=anthropic_client
    # )
    # azure_llm = AzureOpenAIChatCompletionClient(
    #     model="gpt-4",
    #     client=azure_client
    # )

    # Use different providers for different tasks based on cost/capability
    # result1 = await openai_llm.create(messages=...)  # High quality
    # result2 = await anthropic_llm.create(messages=...)  # Good quality
    # result3 = await azure_llm.create(messages=...)  # Enterprise

    print("✓ Example 8: Multi-provider configuration - Pattern shown")


# ============================================================================
# Example 9: Testing with Mock Client
# ============================================================================

class MockHttpClient:
    """Mock HTTP client for testing."""

    def __init__(self, response: Dict[str, Any]):
        self.response = response

    async def chat_completions_create(self, **kwargs):
        """Return mock response."""
        return self.response


async def example_testing_with_mock():
    """Using mock client for testing."""

    # Create mock response
    mock_response = {
        "choices": [
            {
                "message": {"content": "Test response"},
                "finish_reason": "stop"
            }
        ],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 5
        },
        "model": "mock-model"
    }

    # Create mock client
    mock_client = MockHttpClient(mock_response)

    # Inject for testing
    # llm = TestableChatCompletionClient(
    #     model="mock-model",
    #     client=mock_client
    # )
    #
    # result = await llm.create(messages=[...])
    # assert result.message.content == "Test response"

    print("✓ Example 9: Testing with mock client - Pattern shown")


# ============================================================================
# Example 10: Configuration-Driven Initialization
# ============================================================================

async def example_config_driven():
    """Initialize from configuration file or environment."""
    from openai import AsyncOpenAI

    # Example config (would typically come from config file, env vars, etc.)
    llm_config = {
        "provider": "openai",
        "model": "gpt-4.1-mini",
        "api_key": "sk-...",
        "organization": "org-123",
        "base_url": None,
        "timeout": 60.0,
        "default_config": {
            "temperature": 0.7,
            "max_tokens": 2000
        }
    }

    # Factory function to create configured client
    def create_llm_client(config):
        if config["provider"] == "openai":
            from openai import AsyncOpenAI
            # Placeholder: from agentbyte.llm import OpenAIChatCompletionClient

            http_client = AsyncOpenAI(
                api_key=config["api_key"],
                organization=config.get("organization"),
                base_url=config.get("base_url"),
                timeout=config.get("timeout", 30.0)
            )

            # return OpenAIChatCompletionClient(
            #     model=config["model"],
            #     client=http_client,
            #     config=config.get("default_config", {})
            # )

        # elif config["provider"] == "anthropic":
        #     ...

        raise ValueError(f"Unknown provider: {config['provider']}")

    # Create client from config
    # llm = create_llm_client(llm_config)

    print("✓ Example 10: Configuration-driven initialization - Pattern shown")


# ============================================================================
# Main: Run All Examples
# ============================================================================

async def main():
    """Run all examples."""
    print("\n" + "=" * 70)
    print("LLM Client Dependency Injection Examples")
    print("=" * 70 + "\n")

    examples = [
        ("API Key", example_openai_api_key),
        ("Organization ID", example_openai_with_organization),
        ("Proxy & Timeout", example_openai_with_proxy),
        ("Environment-Based", example_environment_based),
        ("Custom Adapter", example_custom_adapter),
        ("OAuth/Token Auth", example_oauth),
        ("Sync to Async", example_sync_to_async),
        ("Multi-Provider", example_multi_provider),
        ("Testing with Mock", example_testing_with_mock),
        ("Config-Driven", example_config_driven),
    ]

    for name, example_func in examples:
        print(f"\n{name}:")
        try:
            await example_func()
        except Exception as e:
            print(f"  ✗ Error: {e}")

    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70 + "\n")

    print("Key Takeaways:")
    print("  1. Create/configure HTTP client (e.g., AsyncOpenAI)")
    print("  2. Inject into agentbyte LLM client at initialization")
    print("  3. agentbyte doesn't handle authentication details")
    print("  4. Enables flexible auth, testing, multi-provider support")
    print("  5. Easy to add adapters for custom or sync clients")
    print()


if __name__ == "__main__":
    asyncio.run(main())
