"""
FunctionTool Example: Comprehensive demonstration of Agentbyte's tool system.

This example shows how to:
1. Wrap Python functions as tools using FunctionTool
2. Use the @tool decorator
3. Execute tools with parameter validation
4. Get LLM-compatible schemas
5. Handle errors
6. Work with async functions
7. Use Literal types for enums

Run with: uv run python examples/function-tool-example.py
"""
import asyncio
from typing import Literal

from agentbyte.tools import ApprovalMode, FunctionTool, tool
from agentbyte.types import ToolResult


# ============================================================================
# Part 1: Direct FunctionTool Usage (Programmatic)
# ============================================================================
def calculate_tax(amount: float, tax_rate: float = 0.1) -> float:
    """Calculate tax for a given amount."""
    return amount * tax_rate


def format_currency(amount: float, currency: str = "USD") -> str:
    """Format an amount as currency string."""
    symbols = {"USD": "$", "EUR": "€", "GBP": "£"}
    symbol = symbols.get(currency, currency)
    return f"{symbol}{amount:.2f}"


# Create tools programmatically
tax_tool = FunctionTool(
    func=calculate_tax,
    name="calculate_tax",
    description="Calculate tax amount for a given value",
)

currency_tool = FunctionTool(
    func=format_currency,
    name="format_currency",
    description="Format currency values",
)


# ============================================================================
# Part 2: @tool Decorator (Cleaner syntax)
# ============================================================================
@tool
def convert_temperature(fahrenheit: float) -> float:
    """Convert Fahrenheit to Celsius."""
    return (fahrenheit - 32) * 5 / 9


@tool(description="Get information about a city")
def get_city_info(city: str) -> str:
    """Get basic information about a city."""
    cities_info = {
        "Paris": "Capital of France, known for the Eiffel Tower",
        "Tokyo": "Capital of Japan, largest metropolitan area",
        "New York": "Largest city in USA, known as the Big Apple",
    }
    return cities_info.get(city, "City not found in database")


@tool(approval_mode=ApprovalMode.ALWAYS)
def delete_resource(resource_id: str) -> str:
    """Delete a resource (requires approval)."""
    return f"Resource {resource_id} deleted successfully"


@tool
def process_action(action: Literal["start", "stop", "pause", "resume"]) -> str:
    """Process a system action."""
    return f"Action '{action}' executed successfully"


# ============================================================================
# Part 3: Async Functions as Tools
# ============================================================================
@tool
async def fetch_remote_data(endpoint: str, timeout: float = 5.0) -> str:
    """Simulate fetching data from a remote endpoint."""
    await asyncio.sleep(0.1)  # Simulate network delay
    return f"Data from {endpoint} (timeout: {timeout}s)"


# ============================================================================
# Demonstration Functions
# ============================================================================
async def demonstrate_direct_tool_usage():
    """Show direct FunctionTool usage."""
    print("\n" + "=" * 70)
    print("PART 1: Direct FunctionTool Usage")
    print("=" * 70)

    # Check tool metadata
    print(f"\nTool Name: {tax_tool.name}")
    print(f"Description: {tax_tool.description}")
    print(f"Version: {tax_tool.version}")

    # Get schema
    schema = tax_tool.parameters
    print(f"\nTool Schema:")
    import json
    print(json.dumps(schema, indent=2))

    # Get LLM format
    print(f"\nLLM Format (for OpenAI/Anthropic):")
    llm_format = tax_tool.to_llm_format()
    print(json.dumps(llm_format, indent=2))

    # Execute tool
    print(f"\nExecuting: tax_tool.execute({{'amount': 100, 'tax_rate': 0.15}})")
    result = await tax_tool.execute({"amount": 100, "tax_rate": 0.15})
    print(f"Success: {result.success}")
    print(f"Result: {result.result}")
    print(f"Error: {result.error}")
    print(f"Metadata: {result.metadata}")


async def demonstrate_decorator_usage():
    """Show @tool decorator usage."""
    print("\n" + "=" * 70)
    print("PART 2: Decorator Usage")
    print("=" * 70)

    # Simple tool
    print(f"\n--- Temperature Converter ---")
    result1 = await convert_temperature.execute({"fahrenheit": 86})
    print(f"86°F = {result1.result:.1f}°C")

    # Tool with custom description
    print(f"\n--- City Info Tool ---")
    result2 = await get_city_info.execute({"city": "Paris"})
    print(f"Paris: {result2.result}")

    # Tool with Literal type
    print(f"\n--- Process Action Tool ---")
    schema = process_action.parameters
    print(f"Available actions: {schema['properties']['action']['enum']}")
    result3 = await process_action.execute({"action": "start"})
    print(f"Result: {result3.result}")


async def demonstrate_async_tools():
    """Show async function tools."""
    print("\n" + "=" * 70)
    print("PART 3: Async Functions as Tools")
    print("=" * 70)

    print(f"\nExecuting async tool...")
    result = await fetch_remote_data.execute({
        "endpoint": "/api/users",
        "timeout": 10.0
    })
    print(f"Success: {result.success}")
    print(f"Result: {result.result}")


async def demonstrate_direct_calling():
    """Show that decorated tools remain callable."""
    print("\n" + "=" * 70)
    print("PART 4: Direct Function Calling (for testing)")
    print("=" * 70)

    # Tools are still functions!
    print(f"\nDirect call: convert_temperature(98.6)")
    celsius = convert_temperature(98.6)
    print(f"Result: {celsius:.1f}°C")


async def demonstrate_error_handling():
    """Show error handling."""
    print("\n" + "=" * 70)
    print("PART 5: Error Handling")
    print("=" * 70)

    # Missing required parameter
    print(f"\nMissing required parameter 'fahrenheit':")
    result = await convert_temperature.execute({})
    print(f"Success: {result.success}")
    print(f"Error: {result.error}")

    # Invalid parameter type (validation catches this)
    print(f"\nInvalid parameter type (string instead of float):")
    result = await convert_temperature.execute({"fahrenheit": "not a number"})
    print(f"Success: {result.success}")
    print(f"Error: {result.error}")


async def demonstrate_approval_mode():
    """Show approval mode in tool metadata."""
    print("\n" + "=" * 70)
    print("PART 6: Approval Modes")
    print("=" * 70)

    # Tool without approval requirement
    print(f"\n--- Tax Calculator (no approval needed) ---")
    print(f"Approval Mode: {tax_tool.approval_mode}")

    # Tool with approval requirement
    print(f"\n--- Delete Resource (approval required) ---")
    print(f"Approval Mode: {delete_resource.approval_mode}")
    print(f"Note: In production, execution would require human approval")


async def demonstrate_tool_collection():
    """Show multiple tools ready for an agent."""
    print("\n" + "=" * 70)
    print("PART 7: Tool Collection for Agents")
    print("=" * 70)

    tools = [
        tax_tool,
        currency_tool,
        convert_temperature,
        get_city_info,
        process_action,
        fetch_remote_data,
    ]

    print(f"\nTools available for agent:")
    for idx, t in enumerate(tools, 1):
        print(f"{idx:2}. {t.name:20} - {t.description}")

    print(f"\nAgent can ask LLM to choose from these tools using schemas:")
    print(f"Available as: [tool.to_llm_format() for tool in tools]")


# ============================================================================
# Main
# ============================================================================
async def main():
    """Run all demonstrations."""
    print("\n" + "=" * 70)
    print("AGENTBYTE FUNCTIONTOOL EXAMPLE")
    print("=" * 70)

    await demonstrate_direct_tool_usage()
    await demonstrate_decorator_usage()
    await demonstrate_async_tools()
    await demonstrate_direct_calling()
    await demonstrate_error_handling()
    await demonstrate_approval_mode()
    await demonstrate_tool_collection()

    print("\n" + "=" * 70)
    print("✅ Example complete!")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
