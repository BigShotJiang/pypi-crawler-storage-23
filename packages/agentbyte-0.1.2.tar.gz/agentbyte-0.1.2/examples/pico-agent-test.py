from picoagents import Agent, OpenAIChatCompletionClient
from pydantic_settings import BaseSettings, SettingsConfigDict

class AppSettings(BaseSettings):
    OPENAI_API_KEY: str

    model_config = SettingsConfigDict(
        env_file=".env", 
        env_file_encoding="utf-8",
        extra="ignore"
    )

settings = AppSettings()

def get_weather(location: str) -> str:
    # Dummy implementation for example purposes
    return f"The weather in {location} is sunny with a high of 75°F."


agent = Agent(
    name="Assistant",
    description="A helpful assistant.",
    instructions="you are helpful. Use tools when appropriate and based on the tool results you provide some advice to the user.",
    model_client=OpenAIChatCompletionClient(
        model="gpt-4.1-mini",
        api_key=settings.OPENAI_API_KEY,
    ),
    tools=[get_weather],
    summarize_tool_result=True
)


async def main():
    async for event in agent.run_stream("What's the weather like in Paris?"):
        print(event)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())