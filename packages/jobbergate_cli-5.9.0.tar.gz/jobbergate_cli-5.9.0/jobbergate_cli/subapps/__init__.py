"""
Subapps that are added to the base ``Typer`` application.
"""
