from common.tracing.setup import configure_tracing

__all__ = ["configure_tracing"]
