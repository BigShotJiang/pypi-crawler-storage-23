from enum import Enum
from typing import List, Union
from common.config import common_settings


class ActionType(str, Enum):
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    MANAGE = "manage"

    @classmethod
    def all(cls) -> List["ActionType"]:
        return [
            cls.CREATE,
            cls.READ,
            cls.UPDATE,
            cls.DELETE,
            cls.MANAGE,
        ]

    @classmethod
    def crud(cls) -> List["ActionType"]:
        return [
            cls.CREATE,
            cls.READ,
            cls.UPDATE,
            cls.DELETE,
        ]

    @classmethod
    def rud(cls) -> List["ActionType"]:
        return [
            cls.READ,
            cls.UPDATE,
            cls.DELETE,
        ]


class ContactType(str, Enum):
    PHONE = "phone"
    EMAIL = "email"
    WHATSAPP = "whatsapp"  # Add WhatsApp contact type

    @property
    def details_key(self) -> str:
        return {
            ContactType.PHONE: "phone_number",
            ContactType.EMAIL: "email",
            ContactType.WHATSAPP: "phone_number",  # WhatsApp also uses phone_number
        }[self]

    @property
    def webhook_url(self) -> str:
        return {
            ContactType.PHONE: common_settings.services.comms.sms_send_url,
            ContactType.EMAIL: common_settings.services.comms.email_send_url,
            ContactType.WHATSAPP: common_settings.services.comms.sms_send_url,  # Or create a whatsapp_send_url if needed
        }[self]

    @property
    def recipient_key(self) -> str:
        return {
            ContactType.PHONE: "phone_number",
            ContactType.EMAIL: "email_address",
            ContactType.WHATSAPP: "phone_number",  # WhatsApp also uses phone_number
        }[self]


class ContactPrincipalType(str, Enum):
    GROUP = "group"
    USER = "user"


class Oauth2PrincipalType(str, Enum):
    USER = "user"
    GROUP = "group"


class SecretPrincipalType(str, Enum):
    USER = "user"


class UsageSessionTokenType(str, Enum):
    ACCESS = "access"
    REFRESH = "refresh"
