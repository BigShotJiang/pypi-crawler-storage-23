
class DatabaseRowUnavailable(ValueError):
    pass
