"""
Prometheus metrics utilities for TASC-Stack services.

This module provides:
- create_instrumentator: Factory for FastAPI service instrumentation
- start_metrics_server: Lightweight HTTP server for consumer workers
- Centralized metric definitions for custom business metrics
"""

from common.metrics.instrumentator import create_instrumentator
from common.metrics.consumer_server import start_metrics_server
from common.metrics.definitions import enable_process_metrics
from common.metrics.definitions import (
    # LLM metrics
    LLM_TOKENS_INPUT,
    LLM_TOKENS_OUTPUT,
    LLM_REQUEST_DURATION,
    LLM_ERRORS,
    # Embedding metrics
    EMBEDDING_REQUEST_DURATION,
    EMBEDDING_ERRORS,
    # Task metrics
    TASK_COMPLETIONS,
    TASK_DURATION,
    # Code assistant metrics
    CODE_ASSISTANT_INVOCATIONS,
    CODE_ASSISTANT_DURATION,
    CODE_ASSISTANT_OUTPUT_FILES,
    # Trigger metrics
    TRIGGER_PULLS,
    # Email metrics
    EMAILS_SENT,
    EMAIL_REPLIES,
    EMAIL_UNSUBSCRIBES,
    # Queue metrics
    QUEUE_DEPTH,
    JOBS_PROCESSED,
    JOB_PROCESSING_DURATION,
    JOB_RETRIES,
    # Message metrics
    USER_MESSAGES,
    AGENT_MESSAGES,
    # Wake cycle metrics
    WAKE_CYCLE_DURATION,
    WAKE_CYCLE_STEPS,
    WAKE_TO_FIRST_LLM,
    STATE_BUILD_DURATION,
    STATE_COMMIT_DURATION,
    TOOL_CALL_DURATION,
    # Database metrics
    DB_QUERY_DURATION,
    DB_QUERY_ERRORS,
    DB_POOL_SIZE,
    DB_POOL_CHECKOUT_TIME,
    # Redis metrics
    REDIS_COMMAND_DURATION,
    REDIS_ERRORS,
    # Auth metrics
    AUTH_ATTEMPTS,
    PERMISSION_CHECKS,
    AUTH_ERRORS,
    # Service-to-service metrics
    SERVICE_CALL_DURATION,
    SERVICE_CALL_ERRORS,
    # Agent session metrics
    ACTIVE_AGENT_SESSIONS,
    # Session creation metrics
    SESSIONS_CREATED,
    # Plugin hook metrics
    PLUGIN_HOOK_DURATION,
    # Bot tool call metrics
    BOT_TOOL_INVOCATIONS,
    BOT_TOOL_DURATION,
)

__all__ = [
    "create_instrumentator",
    "start_metrics_server",
    "enable_process_metrics",
    # LLM metrics
    "LLM_TOKENS_INPUT",
    "LLM_TOKENS_OUTPUT",
    "LLM_REQUEST_DURATION",
    "LLM_ERRORS",
    # Embedding metrics
    "EMBEDDING_REQUEST_DURATION",
    "EMBEDDING_ERRORS",
    # Task metrics
    "TASK_COMPLETIONS",
    "TASK_DURATION",
    # Code assistant metrics
    "CODE_ASSISTANT_INVOCATIONS",
    "CODE_ASSISTANT_DURATION",
    "CODE_ASSISTANT_OUTPUT_FILES",
    # Trigger metrics
    "TRIGGER_PULLS",
    # Email metrics
    "EMAILS_SENT",
    "EMAIL_REPLIES",
    "EMAIL_UNSUBSCRIBES",
    # Queue metrics
    "QUEUE_DEPTH",
    "JOBS_PROCESSED",
    "JOB_PROCESSING_DURATION",
    "JOB_RETRIES",
    # Message metrics
    "USER_MESSAGES",
    "AGENT_MESSAGES",
    # Wake cycle metrics
    "WAKE_CYCLE_DURATION",
    "WAKE_CYCLE_STEPS",
    "WAKE_TO_FIRST_LLM",
    "STATE_BUILD_DURATION",
    "STATE_COMMIT_DURATION",
    "TOOL_CALL_DURATION",
    # Database metrics
    "DB_QUERY_DURATION",
    "DB_QUERY_ERRORS",
    "DB_POOL_SIZE",
    "DB_POOL_CHECKOUT_TIME",
    # Redis metrics
    "REDIS_COMMAND_DURATION",
    "REDIS_ERRORS",
    # Auth metrics
    "AUTH_ATTEMPTS",
    "PERMISSION_CHECKS",
    "AUTH_ERRORS",
    # Service-to-service metrics
    "SERVICE_CALL_DURATION",
    "SERVICE_CALL_ERRORS",
    # Agent session metrics
    "ACTIVE_AGENT_SESSIONS",
    # Session creation metrics
    "SESSIONS_CREATED",
    # Plugin hook metrics
    "PLUGIN_HOOK_DURATION",
    # Bot tool call metrics
    "BOT_TOOL_INVOCATIONS",
    "BOT_TOOL_DURATION",
]
