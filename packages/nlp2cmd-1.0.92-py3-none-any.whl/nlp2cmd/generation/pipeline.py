"""
Iteration 3: Rule-Based Pipeline.

Combines KeywordIntentDetector, RegexEntityExtractor, and TemplateGenerator
into a complete NL → DSL pipeline without LLM.
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any, Optional

from nlp2cmd.utils.data_files import data_file_write_path
from nlp2cmd.generation.keywords.keyword_detector import KeywordIntentDetector, DetectionResult
from nlp2cmd.generation.regex import RegexEntityExtractor, ExtractionResult
from nlp2cmd.generation.template_generator import TemplateGenerator, TemplateResult
from nlp2cmd.generation.pipeline_components import (
    PipelineResult,
    PipelineMetrics,
    SimpleExecutionPlan,
    _create_default_extractor,
    _DEFAULT_USE_ENHANCED_CONTEXT,
)


class RuleBasedPipeline:
    """
    Complete rule-based NL → DSL pipeline.
    
    Combines intent detection, entity extraction, and template generation
    to transform natural language into domain-specific commands.
    """
    
    def __init__(
        self,
        *,
        use_enhanced_context: Optional[bool] = None,
        persist_results: bool = False,
        metrics: Optional[PipelineMetrics] = None,
        confidence_threshold: Optional[float] = None,
        patterns: Optional[dict] = None,
    ):
        self.use_enhanced_context = (
            use_enhanced_context if use_enhanced_context is not None 
            else _DEFAULT_USE_ENHANCED_CONTEXT
        )
        self.persist_results = persist_results
        self.metrics = metrics or PipelineMetrics()
        self.confidence_threshold = confidence_threshold if confidence_threshold is not None else 0.3
        self.patterns = patterns  # Store for backward compatibility
        
        # Initialize components
        self.detector = KeywordIntentDetector(confidence_threshold=self.confidence_threshold)
        self.extractor = _create_default_extractor()
        self.template_generator = TemplateGenerator()
        
        # Multi-step components (lazy loaded)
        self._complex_detector = None
        self._complex_detector_loaded = False
        self._action_planner = None
        self._action_planner_loaded = False
        self._evolutionary_cache = None
        self._evolutionary_cache_loaded = False
        
        # Enhanced context detector (lazy loaded)
        self._enhanced_detector = None
        self._enhanced_detector_loaded = False
    
    @property
    def complex_detector(self):
        """Lazy load ComplexQueryDetector."""
        if self._complex_detector_loaded:
            return self._complex_detector
        try:
            from nlp2cmd.generation.complex_detector import ComplexQueryDetector
            self._complex_detector = ComplexQueryDetector()
        except ImportError:
            pass
        self._complex_detector_loaded = True
        return self._complex_detector

    @property
    def action_planner(self):
        """Lazy load ActionPlanner."""
        if self._action_planner_loaded:
            return self._action_planner
        try:
            from nlp2cmd.automation.action_planner import ActionPlanner
            self._action_planner = ActionPlanner()
        except ImportError:
            pass
        self._action_planner_loaded = True
        return self._action_planner

    @property
    def evolutionary_cache(self):
        """Lazy load EvolutionaryCache."""
        if self._evolutionary_cache_loaded:
            return self._evolutionary_cache
        try:
            from nlp2cmd.generation.evolutionary_cache import EvolutionaryCache
            self._evolutionary_cache = EvolutionaryCache(enable_llm=False)
        except ImportError:
            pass
        self._evolutionary_cache_loaded = True
        return self._evolutionary_cache

    @property
    def enhanced_detector(self):
        """Lazy load enhanced context detector."""
        if self._enhanced_detector_loaded:
            return self._enhanced_detector
        
        if not self.use_enhanced_context:
            self._enhanced_detector_loaded = True
            return None
        
        try:
            from nlp2cmd.generation.enhanced_context import EnhancedContextDetector
            self._enhanced_detector = EnhancedContextDetector()
        except ImportError:
            pass
        
        self._enhanced_detector_loaded = True
        return self._enhanced_detector
    
    def process(self, text: str) -> PipelineResult:
        """
        Process natural language text through the pipeline.
        
        Args:
            text: Natural language input
            
        Returns:
            PipelineResult with generated command and metadata
        """
        start_time = time.time()
        
        result = PipelineResult(input_text=text)

        # If this clearly looks like a browser/navigation query, do not route it through
        # multi-step cache / decomposer. Those layers can misclassify (e.g. openrouter.ai -> "route").
        # Exception: allow multi-step planner for API-key/.env setup workflows.
        text_lower = str(text or "").lower()
        force_single_step_browser = False
        is_canvas_workflow = False
        try:
            import re as _re

            is_key_env_workflow = (
                (".env" in text_lower)
                and any(w in text_lower for w in ["klucz", "key", "api", "token"])
            )

            wants_existing_firefox = (
                ("firefox" in text_lower)
                and any(p in text_lower for p in ["już", "juz", "otwart", "otwarty", "otwarte", "existing", "already open"])
            )

            is_canvas_workflow = (
                ("jspaint" in text_lower or "jspaint.app" in text_lower or "excalidraw" in text_lower)
                and any(w in text_lower for w in ["narys", "rysuj", "draw", "rysunek", "paint"])
            )

            browser_phrases = [
                r"otw[oó]rz\s+przegl[aą]dark",
                r"uruchom\s+przegl[aą]dark",
                r"w[łl][aą]cz\s+przegl[aą]dark",
                r"(?:wejd[zź]|przejd[zź]|id[zź])\s+na\s+stron",
                r"otw[oó]rz\s+stron",
                r"firefox|chrome|chromium|safari|edge",
            ]
            has_browser_phrase = any(_re.search(p, text_lower) for p in browser_phrases)
            has_url = bool(_re.search(r"\bhttps?://[^\s'\"]+", text_lower))
            has_domain = bool(
                _re.search(
                    r"\b[a-zA-Z0-9][\w\-]*\.(?:com|org|net|io|ai|dev|pl|app|co|de|uk|eu)(?:/[^\s'\"]*)?\b",
                    text_lower,
                )
            )

            # Check for multi-step chain signals (don't force single-step for these)
            chain_signals = [
                r"\bi\b",                    # "otwórz X i Y"
                r"\bpotem\b",
                r"\bnast[eę]pnie\b",
                r"\ba\s+potem\b",
                r"\bpo\s+czym\b",
                r"\bthen\b",
                r"\band\s+then\b",
            ]
            has_chain_signal = any(_re.search(p, text_lower) for p in chain_signals)

            if (has_browser_phrase or has_url or has_domain) and (not is_key_env_workflow) and (not has_chain_signal) and (not is_canvas_workflow):
                force_single_step_browser = True
        except Exception:
            force_single_step_browser = False
            is_canvas_workflow = False
        
        try:
            # ═══ LAYER 0: Multi-Step Schema Cache ═══
            if self.evolutionary_cache and (not force_single_step_browser) and (not wants_existing_firefox) and (not is_canvas_workflow):
                cached_plan = self.evolutionary_cache.lookup_multistep(text)
                if cached_plan:
                    # Safety/compatibility: ignore stale cached plans for API-key workflows
                    # (older cache entries may contain extract_api_key, which we no longer execute).
                    try:
                        if (".env" in text_lower) and any(w in text_lower for w in ["klucz", "key", "api", "token"]):
                            if any(getattr(s, "action", "") == "extract_api_key" for s in (cached_plan.steps or [])):
                                cached_plan = None
                    except Exception:
                        pass

                if cached_plan:
                    result.domain = "multi_step"
                    result.intent = "cached_plan"
                    result.action_plan = cached_plan
                    result.confidence = cached_plan.confidence
                    result.detection_confidence = cached_plan.confidence
                    result.success = True
                    result.source = "multistep_cache"
                    result.latency_ms = (time.time() - start_time) * 1000
                    self.metrics.record_result(result)
                    return result

            # ═══ LAYER 0.5: Complex Query Detection ═══
            if self.complex_detector and (not force_single_step_browser):
                complexity = self.complex_detector.analyze(text)
                if complexity.is_complex and self.action_planner:
                    # ═══ LAYER 0.7: Action Planner ═══
                    plan = self.action_planner.decompose_sync(
                        text, complexity.intents
                    )
                    if plan and plan.steps:
                        # ═══ LAYER 0.9: Auto-cache schema ═══
                        if self.evolutionary_cache:
                            self.evolutionary_cache.store_multistep(text, plan)

                        result.domain = "multi_step"
                        result.intent = plan.source
                        result.action_plan = plan
                        result.confidence = plan.confidence
                        result.detection_confidence = plan.confidence
                        result.success = True
                        result.source = plan.source
                        result.latency_ms = (time.time() - start_time) * 1000
                        self.metrics.record_result(result)
                        return result

            # ═══ LAYER 1-11: Standard single-command pipeline ═══
            # Step 1: Intent detection
            detection = self.detector.detect(text)
            if not detection.matched:
                # Fallback for completely unknown input
                result.command = "echo 'Unknown command - could not parse intent'"
                result.success = False
                result.errors.append("No intent detected")
                return result
            
            result.domain = detection.domain
            result.intent = detection.intent
            result.detection_confidence = detection.confidence
            
            # Step 2: Enhanced context (if available)
            if self.enhanced_detector:
                enhanced_result = self.enhanced_detector.enhance(detection, text)
                if enhanced_result:
                    detection = enhanced_result
                    result.metadata["enhanced_context"] = True
            
            # Step 3: Entity extraction
            extraction = self._process_with_detection(text, detection)
            if extraction:
                result.entities = extraction.entities
                result.metadata.update(extraction.metadata or {})
            else:
                # Fallback: use entities from detection if extraction fails
                result.entities = detection.entities or {}
            
            # Step 4: Command generation
            # For complex domains like browser, use the adapter if possible
            if result.domain == 'browser':
                try:
                    from nlp2cmd.adapters import BrowserAdapter
                    adapter = BrowserAdapter()
                    plan = {
                        "text": text,
                        "intent": result.intent,
                        "entities": result.entities,
                        "confidence": result.detection_confidence
                    }
                    result.command = adapter.generate(plan)
                    result.success = True
                    result.confidence = result.detection_confidence
                    result.source = "adapter"
                    return result
                except Exception as adapter_err:
                    result.warnings.append(f"Browser adapter failed, falling back to template: {adapter_err}")

            # Map unsupported domains to shell for basic functionality
            effective_domain = result.domain
            if effective_domain not in self.template_generator.templates:
                effective_domain = 'shell'
                result.warnings.append(f"Mapped unsupported domain '{result.domain}' to 'shell'")
            
            template_result = self.template_generator.generate(
                intent=result.intent,
                entities=result.entities,
                domain=effective_domain,
            )
            
            if template_result.success:
                result.command = template_result.command
                result.template_used = template_result.template_used
                result.success = True
                result.confidence = min(detection.confidence, template_result.confidence)
            else:
                # Fallback for unknown intents - provide a basic response
                if result.domain == "unknown" or result.intent == "unknown":
                    result.command = "echo 'Unknown command - could not parse intent'"
                    result.success = False
                else:
                    result.errors.extend(template_result.errors)
                    result.warnings.extend(template_result.warnings)
            
        except Exception as e:
            result.errors.append(f"Pipeline error: {e}")
        
        # Calculate latency
        result.latency_ms = (time.time() - start_time) * 1000
        
        # Record metrics
        self.metrics.record_result(result)
        
        # Persist results if enabled
        if self.persist_results and result.success:
            self._persist_result(result)
        
        return result
    
    def process_steps(self, text: str) -> list[PipelineResult]:
        """Process text step by step for multi-step commands."""
        sentences = self._split_sentences(text)
        if len(sentences) <= 1:
            return [self.process(text)]
        
        results = []
        context_entities = {}
        
        for i, sentence in enumerate(sentences):
            # Add context from previous steps
            enhanced_text = sentence
            if context_entities:
                context_str = ", ".join(f"{k}: {v}" for k, v in context_entities.items())
                enhanced_text = f"{sentence} (context: {context_str})"
            
            result = self.process(enhanced_text)
            result.metadata["step"] = i + 1
            result.metadata["total_steps"] = len(sentences)
            
            # Update context with new entities
            if result.success:
                context_entities.update(result.entities)
            
            results.append(result)
        
        return results
    
    def _process_with_detection(
        self,
        text: str,
        detection: DetectionResult,
    ) -> Optional[ExtractionResult]:
        """Process entity extraction with detection context."""
        try:
            import os as _os
            from nlp2cmd.generation.pipeline_components import _should_use_semantic_extractor
            # Re-check extractor mode at call time (env var may be set after __init__)
            if _should_use_semantic_extractor():
                from nlp2cmd.generation.semantic_entities import SemanticEntityExtractor
                extractor = SemanticEntityExtractor()
            else:
                extractor = self.extractor
            domain = detection.domain if hasattr(detection, "domain") else str(detection)
            result = extractor.extract(text, domain)
            # Attach shadow metadata from extractor attributes
            mode = _os.environ.get("NLP2CMD_ENTITY_EXTRACTOR_MODE", "").strip().lower()
            if mode in ("shadow", "semantic"):
                meta = result.metadata if hasattr(result, "metadata") and result.metadata is not None else {}
                if not meta.get("entity_extractor_mode"):
                    meta["entity_extractor_mode"] = mode
                sem_entities = getattr(extractor, "last_semantic_entities", None)
                if sem_entities is not None:
                    meta["shadow_entities"] = sem_entities
                if hasattr(result, "metadata"):
                    result.metadata = meta
            return result
        except Exception as e:
            # Log error but don't fail the pipeline
            return None
    
    def _split_sentences(self, text: str) -> list[str]:
        """Split text into sentences."""
        # Simple sentence splitting - can be enhanced
        sentences = re.split(r'[.!?]+', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _persist_result(self, result: PipelineResult) -> None:
        """Persist successful result to file."""
        try:
            output_path = data_file_write_path("pipeline_results.jsonl")
            
            with open(output_path, "a", encoding="utf-8") as f:
                record = {
                    "timestamp": time.time(),
                    "input": result.input_text,
                    "domain": result.domain,
                    "intent": result.intent,
                    "command": result.command,
                    "confidence": result.confidence,
                    "latency_ms": result.latency_ms,
                }
                f.write(json.dumps(record) + "\n")
        except Exception:
            pass  # Don't fail pipeline for persistence issues
    
    def process_with_llm_repair(
        self,
        text: str,
        *,
        llm_client: Any,
        persist: bool = False,
        max_repairs: int = 2,
    ) -> PipelineResult:
        """Process with LLM repair for failed results."""
        result = self.process(text)
        
        if result.success or max_repairs <= 0:
            return result
        
        # Try LLM repair
        try:
            repair_prompt = self._build_repair_prompt(result)
            repair_response = llm_client.generate(repair_prompt)
            
            if repair_response:
                # Parse repair response
                repaired_command = self._parse_repair_response(repair_response)
                if repaired_command:
                    result.command = repaired_command
                    result.success = True
                    result.source = "llm_repair"
                    result.metadata["repair_attempts"] = 1
                    
                    # Try recursive repair if still needed
                    if max_repairs > 1:
                        return self.process_with_llm_repair(
                            text,
                            llm_client=llm_client,
                            persist=persist,
                            max_repairs=max_repairs - 1,
                        )
        except Exception as e:
            result.errors.append(f"LLM repair failed: {e}")
        
        return result
    
    def _build_repair_prompt(self, result: PipelineResult) -> str:
        """Build repair prompt for LLM."""
        return f"""
Please fix this failed command generation:

Input: {result.input_text}
Detected intent: {result.intent}
Detected domain: {result.domain}
Entities: {result.entities}
Failed command: {result.command}
Errors: {result.errors}

Please provide a corrected command that accomplishes the user's intent.
Respond with only the corrected command, no explanation.
"""
    
    def _parse_repair_response(self, response: str) -> Optional[str]:
        """Parse LLM repair response."""
        response = response.strip()
        
        # Remove common prefixes
        prefixes = ["Command:", "Corrected command:", "Fixed command:"]
        for prefix in prefixes:
            if response.startswith(prefix):
                response = response[len(prefix):].strip()
        
        # Remove quotes if present
        if response.startswith('"') and response.endswith('"'):
            response = response[1:-1]
        elif response.startswith("'") and response.endswith("'"):
            response = response[1:-1]
        
        return response if response else None
    
    def process_batch(self, texts: list[str]) -> list[PipelineResult]:
        """Process multiple texts."""
        results = []
        for text in texts:
            result = self.process(text)
            results.append(result)
        return results
    
    def get_supported_domains(self) -> list[str]:
        """Get list of supported domains."""
        return self.detector.get_supported_domains()
    
    def get_supported_intents(self, domain: Optional[str] = None) -> list[str]:
        """Get list of supported intents."""
        if domain:
            return self.detector.get_supported_intents(domain)
        return self.detector.get_supported_intents()
    
    def get_metrics(self) -> dict[str, Any]:
        """Get pipeline metrics."""
        return self.metrics.get_summary()
    
    def reset_metrics(self) -> None:
        """Reset pipeline metrics."""
        self.metrics = PipelineMetrics()


def create_pipeline(
    confidence_threshold: float = 0.3,  # Lower threshold for better test compatibility
    custom_patterns: Optional[dict] = None,
    **kwargs
) -> RuleBasedPipeline:
    """Create a RuleBasedPipeline with default configuration."""
    from nlp2cmd.generation.keywords.keyword_patterns import KeywordPatterns
    
    patterns = custom_patterns if custom_patterns else None
    
    return RuleBasedPipeline(
        confidence_threshold=confidence_threshold,
        **kwargs
    )
