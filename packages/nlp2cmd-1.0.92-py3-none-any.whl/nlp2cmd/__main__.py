"""
Main entry point for nlp2cmd package.
"""

from .cli.main import cli_entry_point

if __name__ == "__main__":
    cli_entry_point()
