from .parser import WikinParser, ModuleDoc, FunctionDoc, VariableDoc
from .generator import WikinGenerator

__version__ = "1.2.2"
