from importlib.metadata import version

__version__ = version("kp2bw")
