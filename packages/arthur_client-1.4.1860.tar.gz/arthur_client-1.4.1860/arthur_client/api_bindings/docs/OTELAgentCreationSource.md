# OTELAgentCreationSource

Creation source for OTEL-discovered agents (auto-created from traces).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'OTEL']
**service_names** | **List[str]** | Service names associated with this agent | [optional] 

## Example

```python
from arthur_client.api_bindings.models.otel_agent_creation_source import OTELAgentCreationSource

# TODO update the JSON string below
json = "{}"
# create an instance of OTELAgentCreationSource from a JSON string
otel_agent_creation_source_instance = OTELAgentCreationSource.from_json(json)
# print the JSON string representation of the object
print(OTELAgentCreationSource.to_json())

# convert the object into a dict
otel_agent_creation_source_dict = otel_agent_creation_source_instance.to_dict()
# create an instance of OTELAgentCreationSource from a dict
otel_agent_creation_source_from_dict = OTELAgentCreationSource.from_dict(otel_agent_creation_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


