# PatchUnregisteredAgentRequest

Request body for partially updating an unregistered agent.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**muted_until** | **datetime** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.patch_unregistered_agent_request import PatchUnregisteredAgentRequest

# TODO update the JSON string below
json = "{}"
# create an instance of PatchUnregisteredAgentRequest from a JSON string
patch_unregistered_agent_request_instance = PatchUnregisteredAgentRequest.from_json(json)
# print the JSON string representation of the object
print(PatchUnregisteredAgentRequest.to_json())

# convert the object into a dict
patch_unregistered_agent_request_dict = patch_unregistered_agent_request_instance.to_dict()
# create an instance of PatchUnregisteredAgentRequest from a dict
patch_unregistered_agent_request_from_dict = PatchUnregisteredAgentRequest.from_dict(patch_unregistered_agent_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


