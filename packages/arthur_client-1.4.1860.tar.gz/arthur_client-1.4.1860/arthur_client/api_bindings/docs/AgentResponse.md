# AgentResponse

Response model for a registered agent.  Extends the structure of EnrichedTaskResponse with agent-specific fields and database-assigned IDs for nested entities.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Timestamp when this agent was created. | 
**updated_at** | **datetime** | Timestamp when this agent was last updated. | 
**name** | **str** | Name of the agent. | 
**data_plane_id** | **str** | UUID of the data plane where this agent was detected. | 
**task_id** | **str** | UUID of the associated task. | 
**creation_source** | [**AgentCreationSource**](AgentCreationSource.md) | Information about how this agent was created. | 
**model_id** | **str** |  | [optional] 
**num_spans** | **int** | Number of spans associated with this agent. | [optional] [default to 0]
**is_autocreated** | **bool** | Whether this agent was auto-created from traces. | [optional] [default to True]
**rules** | [**List[RuleResponse]**](RuleResponse.md) | Rules associated with this agent&#39;s task. | [optional] 
**last_fetched** | **datetime** |  | [optional] 
**muted_until** | **datetime** |  | [optional] 
**id** | **str** | Agent ID. | 
**workspace_id** | **str** | UUID of the workspace this agent belongs to. | 
**tools** | [**List[ToolResponse]**](ToolResponse.md) | Tools used by this agent. | [optional] 
**sub_agents** | [**List[SubAgentResponse]**](SubAgentResponse.md) | Sub-agents used by this agent. | [optional] 
**llm_models** | [**List[LLMModelResponse]**](LLMModelResponse.md) | LLM models used by this agent. | [optional] 
**data_sources** | [**List[DataSourceResponse]**](DataSourceResponse.md) | Data sources used by this agent. | [optional] 
**infrastructure** | [**Infrastructure**](Infrastructure.md) | Infrastructure where this agent is running (derived from creation_source). | 

## Example

```python
from arthur_client.api_bindings.models.agent_response import AgentResponse

# TODO update the JSON string below
json = "{}"
# create an instance of AgentResponse from a JSON string
agent_response_instance = AgentResponse.from_json(json)
# print the JSON string representation of the object
print(AgentResponse.to_json())

# convert the object into a dict
agent_response_dict = agent_response_instance.to_dict()
# create an instance of AgentResponse from a dict
agent_response_from_dict = AgentResponse.from_dict(agent_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


