# arthur_client.api_bindings.AgentsV1Api

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_registered_agent_by_id**](AgentsV1Api.md#get_registered_agent_by_id) | **GET** /api/v1/agents/registered/{agent_id} | Get A Registered Agent By Its Id.
[**list_agents_for_workspace**](AgentsV1Api.md#list_agents_for_workspace) | **GET** /api/v1/workspaces/{workspace_id}/agents/registered | List All Agents For A Workspace.
[**list_data_sources_for_workspace**](AgentsV1Api.md#list_data_sources_for_workspace) | **GET** /api/v1/workspaces/{workspace_id}/agents/registered/data_sources | List All Registered Agent Data Sources For A Workspace.
[**list_llm_models_for_workspace**](AgentsV1Api.md#list_llm_models_for_workspace) | **GET** /api/v1/workspaces/{workspace_id}/agents/registered/llm_models | List All Registered Agent Llm Models For A Workspace.
[**list_sub_agents_for_workspace**](AgentsV1Api.md#list_sub_agents_for_workspace) | **GET** /api/v1/workspaces/{workspace_id}/agents/registered/subagents | List All Registered Agent Sub-Agents For A Workspace.
[**list_tools_for_workspace**](AgentsV1Api.md#list_tools_for_workspace) | **GET** /api/v1/workspaces/{workspace_id}/agents/registered/tools | List All Registered Agent Tools For A Workspace.
[**list_unregistered_agents_for_workspace**](AgentsV1Api.md#list_unregistered_agents_for_workspace) | **GET** /api/v1/workspaces/{workspace_id}/agents/unregistered | List All Unregistered Agents For A Workspace.
[**put_agents**](AgentsV1Api.md#put_agents) | **PUT** /api/v1/workspaces/{workspace_id}/agents | Upsert Agents.
[**update_unregistered_agent**](AgentsV1Api.md#update_unregistered_agent) | **PATCH** /api/v1/agents/unregistered/{agent_id} | Update An Unregistered Agent.


# **get_registered_agent_by_id**
> AgentResponse get_registered_agent_by_id(agent_id)

Get A Registered Agent By Its Id.

Get a single registered agent by ID. Requires agent_read permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.agent_response import AgentResponse
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    agent_id = 'agent_id_example' # str | 

    try:
        # Get A Registered Agent By Its Id.
        api_response = api_instance.get_registered_agent_by_id(agent_id)
        print("The response of AgentsV1Api->get_registered_agent_by_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->get_registered_agent_by_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **agent_id** | **str**|  | 

### Return type

[**AgentResponse**](AgentResponse.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_agents_for_workspace**
> ResourceListAgentResponse list_agents_for_workspace(workspace_id, sort=sort, order=order, name_filter=name_filter, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, sub_agent_names=sub_agent_names, tool_names=tool_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, page=page, page_size=page_size)

List All Agents For A Workspace.

List all agents for a workspace. Requires workspace_list_agents permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.agent_sort import AgentSort
from arthur_client.api_bindings.models.resource_list_agent_response import ResourceListAgentResponse
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    sort = arthur_client.api_bindings.AgentSort() # AgentSort | The field to sort the agents by. (optional)
    order = arthur_client.api_bindings.SortOrder() # SortOrder | The order to sort the agents by. (optional)
    name_filter = 'name_filter_example' # str | Filter agents by name. (optional)
    agent_ids = ['agent_ids_example'] # List[str] | Filter agents by agent IDs. (optional)
    model_ids = ['model_ids_example'] # List[str] | Filter agents by model IDs. (optional)
    task_ids = ['task_ids_example'] # List[str] | Filter agents by task IDs. (optional)
    sub_agent_names = ['sub_agent_names_example'] # List[str] | Filter agents that use any of these sub-agent names. (optional)
    tool_names = ['tool_names_example'] # List[str] | Filter agents that use any of these tool names. (optional)
    llm_model_names = ['llm_model_names_example'] # List[str] | Filter agents that use any of these llm model names. (optional)
    data_source_urls = ['data_source_urls_example'] # List[str] | Filter agents that use any of these data source URLs. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List All Agents For A Workspace.
        api_response = api_instance.list_agents_for_workspace(workspace_id, sort=sort, order=order, name_filter=name_filter, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, sub_agent_names=sub_agent_names, tool_names=tool_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, page=page, page_size=page_size)
        print("The response of AgentsV1Api->list_agents_for_workspace:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->list_agents_for_workspace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **sort** | [**AgentSort**](.md)| The field to sort the agents by. | [optional] 
 **order** | [**SortOrder**](.md)| The order to sort the agents by. | [optional] 
 **name_filter** | **str**| Filter agents by name. | [optional] 
 **agent_ids** | [**List[str]**](str.md)| Filter agents by agent IDs. | [optional] 
 **model_ids** | [**List[str]**](str.md)| Filter agents by model IDs. | [optional] 
 **task_ids** | [**List[str]**](str.md)| Filter agents by task IDs. | [optional] 
 **sub_agent_names** | [**List[str]**](str.md)| Filter agents that use any of these sub-agent names. | [optional] 
 **tool_names** | [**List[str]**](str.md)| Filter agents that use any of these tool names. | [optional] 
 **llm_model_names** | [**List[str]**](str.md)| Filter agents that use any of these llm model names. | [optional] 
 **data_source_urls** | [**List[str]**](str.md)| Filter agents that use any of these data source URLs. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListAgentResponse**](ResourceListAgentResponse.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_data_sources_for_workspace**
> ResourceListDataSource list_data_sources_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, tool_names=tool_names, sub_agent_names=sub_agent_names, llm_model_names=llm_model_names, page=page, page_size=page_size)

List All Registered Agent Data Sources For A Workspace.

List all data sources for a workspace. Requires workspace_list_agent_data_sources permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_data_source import ResourceListDataSource
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    order = arthur_client.api_bindings.SortOrder() # SortOrder | The order to sort the agents by. (optional)
    name_filter = 'name_filter_example' # str | Filter data sources by URL. (optional)
    agent_names = ['agent_names_example'] # List[str] | Filter data sources by their associated agent names. (optional)
    agent_ids = ['agent_ids_example'] # List[str] | Filter data sources by their associated agent IDs. (optional)
    model_ids = ['model_ids_example'] # List[str] | Filter data sources by any model IDs their associated agents are attached to. (optional)
    task_ids = ['task_ids_example'] # List[str] | Filter data sources on their associated task IDs. (optional)
    tool_names = ['tool_names_example'] # List[str] | Filter data sources on their associated tool names. (optional)
    sub_agent_names = ['sub_agent_names_example'] # List[str] | Filter data sources on agents containing any of these sub-agent names. (optional)
    llm_model_names = ['llm_model_names_example'] # List[str] | Filter data sources on agents containing any of these llm model names. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List All Registered Agent Data Sources For A Workspace.
        api_response = api_instance.list_data_sources_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, tool_names=tool_names, sub_agent_names=sub_agent_names, llm_model_names=llm_model_names, page=page, page_size=page_size)
        print("The response of AgentsV1Api->list_data_sources_for_workspace:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->list_data_sources_for_workspace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **order** | [**SortOrder**](.md)| The order to sort the agents by. | [optional] 
 **name_filter** | **str**| Filter data sources by URL. | [optional] 
 **agent_names** | [**List[str]**](str.md)| Filter data sources by their associated agent names. | [optional] 
 **agent_ids** | [**List[str]**](str.md)| Filter data sources by their associated agent IDs. | [optional] 
 **model_ids** | [**List[str]**](str.md)| Filter data sources by any model IDs their associated agents are attached to. | [optional] 
 **task_ids** | [**List[str]**](str.md)| Filter data sources on their associated task IDs. | [optional] 
 **tool_names** | [**List[str]**](str.md)| Filter data sources on their associated tool names. | [optional] 
 **sub_agent_names** | [**List[str]**](str.md)| Filter data sources on agents containing any of these sub-agent names. | [optional] 
 **llm_model_names** | [**List[str]**](str.md)| Filter data sources on agents containing any of these llm model names. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListDataSource**](ResourceListDataSource.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_llm_models_for_workspace**
> ResourceListLLMModel list_llm_models_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, tool_names=tool_names, sub_agent_names=sub_agent_names, data_source_urls=data_source_urls, page=page, page_size=page_size)

List All Registered Agent Llm Models For A Workspace.

List all llm models for a workspace. Requires workspace_list_agent_llm_models permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_llm_model import ResourceListLLMModel
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    order = arthur_client.api_bindings.SortOrder() # SortOrder | The order to sort the agents by. (optional)
    name_filter = 'name_filter_example' # str | Filter llm models by name. (optional)
    agent_names = ['agent_names_example'] # List[str] | Filter llm models by their associated agent names. (optional)
    agent_ids = ['agent_ids_example'] # List[str] | Filter llm models by their associated agent IDs. (optional)
    model_ids = ['model_ids_example'] # List[str] | Filter llm models by any model IDs their associated agents are attached to. (optional)
    task_ids = ['task_ids_example'] # List[str] | Filter llm models on their associated task IDs. (optional)
    tool_names = ['tool_names_example'] # List[str] | Filter llm models on their associated tool names. (optional)
    sub_agent_names = ['sub_agent_names_example'] # List[str] | Filter llm models on agents containing any of these sub-agent names. (optional)
    data_source_urls = ['data_source_urls_example'] # List[str] | Filter llm models on agents containing any of these data source URLs. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List All Registered Agent Llm Models For A Workspace.
        api_response = api_instance.list_llm_models_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, tool_names=tool_names, sub_agent_names=sub_agent_names, data_source_urls=data_source_urls, page=page, page_size=page_size)
        print("The response of AgentsV1Api->list_llm_models_for_workspace:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->list_llm_models_for_workspace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **order** | [**SortOrder**](.md)| The order to sort the agents by. | [optional] 
 **name_filter** | **str**| Filter llm models by name. | [optional] 
 **agent_names** | [**List[str]**](str.md)| Filter llm models by their associated agent names. | [optional] 
 **agent_ids** | [**List[str]**](str.md)| Filter llm models by their associated agent IDs. | [optional] 
 **model_ids** | [**List[str]**](str.md)| Filter llm models by any model IDs their associated agents are attached to. | [optional] 
 **task_ids** | [**List[str]**](str.md)| Filter llm models on their associated task IDs. | [optional] 
 **tool_names** | [**List[str]**](str.md)| Filter llm models on their associated tool names. | [optional] 
 **sub_agent_names** | [**List[str]**](str.md)| Filter llm models on agents containing any of these sub-agent names. | [optional] 
 **data_source_urls** | [**List[str]**](str.md)| Filter llm models on agents containing any of these data source URLs. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListLLMModel**](ResourceListLLMModel.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_sub_agents_for_workspace**
> ResourceListSubAgent list_sub_agents_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, tool_names=tool_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, page=page, page_size=page_size)

List All Registered Agent Sub-Agents For A Workspace.

List all sub-agents for a workspace. Requires workspace_list_agent_sub_agents permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_sub_agent import ResourceListSubAgent
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    order = arthur_client.api_bindings.SortOrder() # SortOrder | The order to sort the agents by. (optional)
    name_filter = 'name_filter_example' # str | Filter sub-agents by name. (optional)
    agent_names = ['agent_names_example'] # List[str] | Filter sub-agents by their associated agent names. (optional)
    agent_ids = ['agent_ids_example'] # List[str] | Filter sub-agents by their associated agent IDs. (optional)
    model_ids = ['model_ids_example'] # List[str] | Filter sub-agents by any model IDs their associated agents are attached to. (optional)
    task_ids = ['task_ids_example'] # List[str] | Filter sub-agents on their associated task IDs. (optional)
    tool_names = ['tool_names_example'] # List[str] | Filter sub-agents on their associated tool names. (optional)
    llm_model_names = ['llm_model_names_example'] # List[str] | Filter tools on agents containing any of these llm model names. (optional)
    data_source_urls = ['data_source_urls_example'] # List[str] | Filter sub-agents on agents containing any of these data source URLs. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List All Registered Agent Sub-Agents For A Workspace.
        api_response = api_instance.list_sub_agents_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, tool_names=tool_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, page=page, page_size=page_size)
        print("The response of AgentsV1Api->list_sub_agents_for_workspace:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->list_sub_agents_for_workspace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **order** | [**SortOrder**](.md)| The order to sort the agents by. | [optional] 
 **name_filter** | **str**| Filter sub-agents by name. | [optional] 
 **agent_names** | [**List[str]**](str.md)| Filter sub-agents by their associated agent names. | [optional] 
 **agent_ids** | [**List[str]**](str.md)| Filter sub-agents by their associated agent IDs. | [optional] 
 **model_ids** | [**List[str]**](str.md)| Filter sub-agents by any model IDs their associated agents are attached to. | [optional] 
 **task_ids** | [**List[str]**](str.md)| Filter sub-agents on their associated task IDs. | [optional] 
 **tool_names** | [**List[str]**](str.md)| Filter sub-agents on their associated tool names. | [optional] 
 **llm_model_names** | [**List[str]**](str.md)| Filter tools on agents containing any of these llm model names. | [optional] 
 **data_source_urls** | [**List[str]**](str.md)| Filter sub-agents on agents containing any of these data source URLs. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListSubAgent**](ResourceListSubAgent.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tools_for_workspace**
> ResourceListTool list_tools_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, sub_agent_names=sub_agent_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, page=page, page_size=page_size)

List All Registered Agent Tools For A Workspace.

List all tools for a workspace. Requires workspace_list_agent_tools permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_tool import ResourceListTool
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    order = arthur_client.api_bindings.SortOrder() # SortOrder | The order to sort the agents by. (optional)
    name_filter = 'name_filter_example' # str | Filter tools by name. (optional)
    agent_names = ['agent_names_example'] # List[str] | Filter tools by their associated agent names. (optional)
    agent_ids = ['agent_ids_example'] # List[str] | Filter tools by their associated agent IDs. (optional)
    model_ids = ['model_ids_example'] # List[str] | Filter tools by any model IDs their associated agents are attached to. (optional)
    task_ids = ['task_ids_example'] # List[str] | Filter tools on their associated task IDs. (optional)
    sub_agent_names = ['sub_agent_names_example'] # List[str] | Filter tools on agents containing any of these sub-agent names. (optional)
    llm_model_names = ['llm_model_names_example'] # List[str] | Filter tools on agents containing any of these llm model names. (optional)
    data_source_urls = ['data_source_urls_example'] # List[str] | Filter tools on agents containing any of these data source URLs. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List All Registered Agent Tools For A Workspace.
        api_response = api_instance.list_tools_for_workspace(workspace_id, order=order, name_filter=name_filter, agent_names=agent_names, agent_ids=agent_ids, model_ids=model_ids, task_ids=task_ids, sub_agent_names=sub_agent_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, page=page, page_size=page_size)
        print("The response of AgentsV1Api->list_tools_for_workspace:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->list_tools_for_workspace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **order** | [**SortOrder**](.md)| The order to sort the agents by. | [optional] 
 **name_filter** | **str**| Filter tools by name. | [optional] 
 **agent_names** | [**List[str]**](str.md)| Filter tools by their associated agent names. | [optional] 
 **agent_ids** | [**List[str]**](str.md)| Filter tools by their associated agent IDs. | [optional] 
 **model_ids** | [**List[str]**](str.md)| Filter tools by any model IDs their associated agents are attached to. | [optional] 
 **task_ids** | [**List[str]**](str.md)| Filter tools on their associated task IDs. | [optional] 
 **sub_agent_names** | [**List[str]**](str.md)| Filter tools on agents containing any of these sub-agent names. | [optional] 
 **llm_model_names** | [**List[str]**](str.md)| Filter tools on agents containing any of these llm model names. | [optional] 
 **data_source_urls** | [**List[str]**](str.md)| Filter tools on agents containing any of these data source URLs. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListTool**](ResourceListTool.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_unregistered_agents_for_workspace**
> ResourceListAgentResponse list_unregistered_agents_for_workspace(workspace_id, sort=sort, order=order, name_filter=name_filter, agent_ids=agent_ids, task_ids=task_ids, sub_agent_names=sub_agent_names, tool_names=tool_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, show_muted=show_muted, page=page, page_size=page_size)

List All Unregistered Agents For A Workspace.

List all unregistered agents for a workspace. Requires workspace_list_unregistered_agents permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.agent_sort import AgentSort
from arthur_client.api_bindings.models.resource_list_agent_response import ResourceListAgentResponse
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    sort = arthur_client.api_bindings.AgentSort() # AgentSort | The field to sort the agents by. (optional)
    order = arthur_client.api_bindings.SortOrder() # SortOrder | The order to sort the agents by. (optional)
    name_filter = 'name_filter_example' # str | Filter agents by name. (optional)
    agent_ids = ['agent_ids_example'] # List[str] | Filter agents by agent IDs. (optional)
    task_ids = ['task_ids_example'] # List[str] | Filter agents by task IDs. (optional)
    sub_agent_names = ['sub_agent_names_example'] # List[str] | Filter agents that use any of these sub-agent names. (optional)
    tool_names = ['tool_names_example'] # List[str] | Filter agents that use any of these tool names. (optional)
    llm_model_names = ['llm_model_names_example'] # List[str] | Filter agents that use any of these llm model names. (optional)
    data_source_urls = ['data_source_urls_example'] # List[str] | Filter agents that use any of these data source URLs. (optional)
    show_muted = True # bool | Filter agents that are muted. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List All Unregistered Agents For A Workspace.
        api_response = api_instance.list_unregistered_agents_for_workspace(workspace_id, sort=sort, order=order, name_filter=name_filter, agent_ids=agent_ids, task_ids=task_ids, sub_agent_names=sub_agent_names, tool_names=tool_names, llm_model_names=llm_model_names, data_source_urls=data_source_urls, show_muted=show_muted, page=page, page_size=page_size)
        print("The response of AgentsV1Api->list_unregistered_agents_for_workspace:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->list_unregistered_agents_for_workspace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **sort** | [**AgentSort**](.md)| The field to sort the agents by. | [optional] 
 **order** | [**SortOrder**](.md)| The order to sort the agents by. | [optional] 
 **name_filter** | **str**| Filter agents by name. | [optional] 
 **agent_ids** | [**List[str]**](str.md)| Filter agents by agent IDs. | [optional] 
 **task_ids** | [**List[str]**](str.md)| Filter agents by task IDs. | [optional] 
 **sub_agent_names** | [**List[str]**](str.md)| Filter agents that use any of these sub-agent names. | [optional] 
 **tool_names** | [**List[str]**](str.md)| Filter agents that use any of these tool names. | [optional] 
 **llm_model_names** | [**List[str]**](str.md)| Filter agents that use any of these llm model names. | [optional] 
 **data_source_urls** | [**List[str]**](str.md)| Filter agents that use any of these data source URLs. | [optional] 
 **show_muted** | **bool**| Filter agents that are muted. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListAgentResponse**](ResourceListAgentResponse.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_agents**
> PutAgentsResponse put_agents(workspace_id, put_agents)

Upsert Agents.

Create or update agents in the workspace. Deduplicates by (workspace_id, data_plane_id, task_id). Performs full replacement on match. Requires workspace_upsert_agents permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.put_agents import PutAgents
from arthur_client.api_bindings.models.put_agents_response import PutAgentsResponse
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    put_agents = arthur_client.api_bindings.PutAgents() # PutAgents | 

    try:
        # Upsert Agents.
        api_response = api_instance.put_agents(workspace_id, put_agents)
        print("The response of AgentsV1Api->put_agents:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->put_agents: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **put_agents** | [**PutAgents**](PutAgents.md)|  | 

### Return type

[**PutAgentsResponse**](PutAgentsResponse.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_unregistered_agent**
> AgentResponse update_unregistered_agent(agent_id, patch_unregistered_agent_request)

Update An Unregistered Agent.

Update an unregistered agent. Requires unregistered_agent_patch permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.agent_response import AgentResponse
from arthur_client.api_bindings.models.patch_unregistered_agent_request import PatchUnregisteredAgentRequest
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.AgentsV1Api(api_client)
    agent_id = 'agent_id_example' # str | 
    patch_unregistered_agent_request = arthur_client.api_bindings.PatchUnregisteredAgentRequest() # PatchUnregisteredAgentRequest | 

    try:
        # Update An Unregistered Agent.
        api_response = api_instance.update_unregistered_agent(agent_id, patch_unregistered_agent_request)
        print("The response of AgentsV1Api->update_unregistered_agent:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AgentsV1Api->update_unregistered_agent: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **agent_id** | **str**|  | 
 **patch_unregistered_agent_request** | [**PatchUnregisteredAgentRequest**](PatchUnregisteredAgentRequest.md)|  | 

### Return type

[**AgentResponse**](AgentResponse.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

