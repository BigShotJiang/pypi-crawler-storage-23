# build-your-own

> **[CMDOP Skill](https://cmdop.com/skills/build-your-own/)** — install and use via [CMDOP agent](https://cmdop.com):
> ```
> cmdop-skill install build-your-own
> ```
Implement any technology from scratch — Git, Redis, Shell, Docker, and more.

*"What I cannot create, I do not understand" — Richard Feynman*

## Usage

```bash
cmdop run build-your-own "implement a redis server in Go"
```

## What it does

An interactive skill that walks you through implementing a technology from scratch:

1. **Intake dialog** — picks what to build, language, scope, output directory
2. **Implementation** — writes real, working code files step by step
3. **Verification** — runs the result to confirm it works

Supports any technology: Git, Redis, Shell, Docker, Web Server, Database, Neural Network, and more.
