from cmdop_skill import SkillConfig

config = SkillConfig()
