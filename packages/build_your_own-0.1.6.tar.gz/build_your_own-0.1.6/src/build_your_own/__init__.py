"""build-your-own — Implement any technology from scratch."""
