# gr_school_helper

Βοηθητικές συναρτήσεις για ελληνικά σχολεία — Helper utilities for Greek schools.

Note: the library is intended for use strictly with the greek public school IT ecosystem (myschool.sch.gr etc.). As such all documentation below is in the greek language.

Συλλογή Python modules για την αυτοματοποίηση συνηθισμένων διαχειριστικών εργασιών σε ελληνικά σχολεία.

---

## Εγκατάσταση

```bash
pip install gr_school_helper
```

---

## Modules

### `sch`

Σκόρπιες μικρές βοηθητικές συναρτήσεις ή ορισμοί, γίνεται imported από όλα τα άλλα

```python
from gr_school_helper import sch

# Παράδειγμα - μενού επιλογής
```python
from gr_school_helper.myschool import sch
choices = ["ένα","δύο","τρία"]
choice = sch.set_option_select(choices)

### `myschool`

Αυτοματοποιεί την αλληλεπίδραση με την πλατφόρμα myschool.edu.gr μέσω διαχειριζόμενου προγράμματος περιήγησης Firefox. Το geckodriver κατεβαίνει και αποθηκεύεται αυτόματα την πρώτη φορά.

```python
from gr_school_helper.myschool import webriver

# Ως context manager (προτείνεται)
with webriver() as driver:
    driver.some_helper_function()

# Ή χειροκίνητα
driver = webriver()
driver.some_helper_function()
driver.close()
```

### `mailer`

Αποστολή email μέσω SMTP. Χρήσιμο για αυτοματοποιημένες ειδοποιήσεις σε γονείς, προσωπικό ή μαθητές.

```python
from gr_school_helper import mailer

# TODO: προσθήκη παραδείγματος χρήσης
```

### `rlab`

Διάφορες βοηθητικές συναρτήσεις για δημιουργία αναφορών με το reportlab

---

## Απαιτήσεις

- Python >= 3.8
- Εγκατεστημένος Firefox στο σύστημα (για το module `myschool`)
- Πρόσβαση στο διαδίκτυο την πρώτη εκτέλεση (το geckodriver κατεβαίνει αυτόματα)

---

## Εξαρτήσεις

| Πακέτο | Χρήση |
|---|---|
| `selenium` | Αυτοματοποίηση προγράμματος περιήγησης |
| `webdriver-manager` | Αυτόματη διαχείριση geckodriver |
| `openpyxl` | Διαχείριση αρχείων Excel |
| `babel` | Μορφοποίηση ημερομηνιών και locale |
| `beaupy` | Terminal UI (prompts, spinners) |
| `reportlab` | Δημιουργία PDF |

---

## Ρυθμίσεις

TODO: περιγραφή αρχείων ρυθμίσεων (π.χ. `.ini` αρχεία που διαβάζονται από το `configparser`).

---

## Σημειώσεις

- Η βιβλιοθήκη αναπτύχθηκε για χρήση με ελληνικά σχολικά πληροφοριακά συστήματα.
- Το module `myschool` στοχεύει στην πλατφόρμα myschool.sch.gr. Αλλαγές στην πλατφόρμα ενδέχεται να απαιτήσουν ενημέρωση της βιβλιοθήκης.

---

## Άδεια Χρήσης

GPLv3 (αρχείο LICENSE)

---

## Συγγραφέας

shortmanikos
shortmanikos@gmail.com

