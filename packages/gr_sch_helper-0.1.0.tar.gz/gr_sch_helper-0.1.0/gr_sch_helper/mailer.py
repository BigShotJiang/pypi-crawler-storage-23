# βιβλιοθήκη για αποστολή email μέσω σχολικού δικτύου

import configparser
import smtplib
import ssl
import time
from email.message import EmailMessage
from email.utils import formatdate


configParser = configparser.RawConfigParser()                                
configParser.read("../general.config")                                          
port = configParser.get('Mail', 'Port')                                    
smtp_server = configParser.get('Mail', 'Url')                              
username= configParser.get('Mail', 'Username')                             
password = configParser.get('Mail', 'Password')
    
context = ssl.create_default_context()

# αποστολή απλών μυνημάτων - χωρίς συνημμένα
# το EpalAuto = True αντιστοιχεί σε φίλτρο που
# μεταφέρει τα μυνήματα εκτός inbox
def sendMail(messages):
    with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
        server.login(username, password)
        for message in messages:
            msg = EmailMessage()
            msg.set_content(message['body'])
            msg["Date"] = formatdate(localtime=True)
            msg['Subject'] = message['subject']
            msg['From'] = "1ο ΕΠΑ.Λ. Καλαμαριάς <1epal-kalam@sch.gr>"
            msg['To'] = message['to']
            msg['Bcc'] = message['bcc']
            msg['EpalAuto']="True"
            print("sending to " + message['to'])
            server.send_message(msg)
            print("sent")
            time.sleep(2)

# απλή κλάση για να γίνεται αυτόματα το login/logout στον smtp server
# χωρίς να ασχολούμαστε κάθε φορά με τις ρυθμίσεις 
class MyMailer:
    def __enter__(self):
        self.smtp = smtplib.SMTP_SSL(smtp_server, port, context=context)
        self.smtp.login(username,password)
        return self.smtp

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.smtp.quit()
        return False

