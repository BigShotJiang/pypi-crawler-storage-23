# Διάφορα στυλ για αναφορές pdf

from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm, mm 
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, PageBreak, Paragraph, Spacer
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase.pdfmetrics import registerFont, registerFontFamily

# add pagenumbers to a report lab generated pdf page - it presupposes that a variable named last_page is defined and equal with the total number of pages in the document
# called in doc.build( elements, onFirstPage=addPageNumber, onLaterPages=addPageNumber)
def setlast(last):
    global last_page
    last_page = last

def addPageNumber(canvas, doc):
    canvas.setFont('DejaVu', 8)
    page_num = canvas.getPageNumber()
    text = "%s / %s" % (page_num,last_page)
    canvas.drawRightString(285*mm, 200*mm, text)

# στυλ για τη μορφοποίηση πινάκων του reportlab
# TODO να γίνουν πιο περιγραφικά τα ονόματα
def style(id):
    styles = getSampleStyleSheet()

    pdfmetrics.registerFont(TTFont('DejaVu', 'DejaVuSerif.ttf'))
    pdfmetrics.registerFont(TTFont('DejaVu-Bold', 'DejaVuSerif-Bold.ttf'))
    pdfmetrics.registerFont(TTFont('VeraIt', 'DejaVuSerif-Italic.ttf'))
    pdfmetrics.registerFont(TTFont('VeraBI', 'DejaVuSerif-BoldItalic.ttf'))
    pdfmetrics.registerFont(TTFont('Vera', 'DejaVuSerif.ttf'))
    registerFontFamily('DejaVu',normal='DejaVu',bold='DejaVu-Bold',italic='VeraIt',boldItalic='VeraBI')

    match id: 
        case "taxi tmima header":
            return ParagraphStyle('normal style',
                fontName='DejaVu',
                spaceAfter=2,
                parent=styles['Normal'],
                )
        case "1":
            return TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),('BOX', (0,0), (-1,0), 1.25, colors.black),('BOX', (0,0), (-1,-1), 1.25, colors.black),('FONT', (0, 1), (-1, -1), 'DejaVu'), ('FONT', (0, 0), (-1, 0), 'DejaVu-Bold'), ('FONTSIZE', (0,1), (-1,-1), 10), ('ALIGN', (0, 0), (1, -1), 'CENTER') ])
        case "Align Justified":
            return ParagraphStyle('normal style',
                parent=styles['Normal'],
                fontName='DejaVu',
                alignment=1,
                )
        case "Align Left":
            return ParagraphStyle('normal style',
                parent=styles['Normal'],
                fontName='DejaVu',
                alignment=0,
                )
        case "Headings (1)":
            return ParagraphStyle('heading1 style',
                fontName="DejaVu-Bold",
                parent=styles['Heading1'],
                )
        case "Table-Year-Date":
            return TableStyle([('FONT', (0, 0), (-1, -1), 'DejaVu'),('FONTSIZE', (0,0), (-1,-1), 8), ('ALIGN',(0,0),(-1,-1),'RIGHT'),])
        case "Tbl4":
            return TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),('BOX', (0,0), (-1,0), 1.25, colors.black),('BOX', (0,0), (-1,-1), 1.25, colors.black),('FONT', (0, 1), (-1, -1), 'DejaVu'), ('FONT', (0, 0), (-1, 0), 'DejaVu-Bold'), ('FONTSIZE', (0,1), (-1,-1), 10), ('ALIGN', (0, 0), (0, -1), 'CENTER'), ('ALIGN', (1, 0), (2, -1), 'LEFT'), ('ALIGN', (3, 0), (5, 0), 'CENTER'), ('ALIGN', (3, 1), (5, -1), 'LEFT'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE') ])
        case "TblHeaders1":
            return TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),('BOX', (0,0), (-1,0), 1.25, colors.black),('BOX', (0,0), (-1,-1), 1.25, colors.black),('FONT', (0, 1), (-1, -1), 'DejaVu'), ('FONT', (0, 0), (-1, 0), 'DejaVu-Bold'), ('FONTSIZE', (0,1), (-1,-1), 10), ('ALIGN', (0, 0), (0, -1), 'CENTER'), ('ALIGN', (1, 0), (2, -1), 'LEFT'), ('ALIGN', (3, 0), (3, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE') ])
