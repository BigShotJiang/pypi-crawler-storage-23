#include "../internal.h"
#include <stdlib.h>

PH_API ph_error_t ph_compute_ahash(ph_context_t *ctx, uint64_t *out_hash) {
    if (!ctx || !ctx->is_loaded || !out_hash) {
        return PH_ERR_INVALID_ARGUMENT;
    }

    size_t gray_size = (size_t)ctx->width * ctx->height;
    uint8_t *gray_full = ph_get_scratchpad(ctx, gray_size);
    if (!gray_full) {
        return PH_ERR_ALLOCATION_FAILED;
    }
    ph_to_grayscale(ctx, ctx->data, ctx->width, ctx->height, ctx->channels, gray_full);

    uint8_t hash_input[PH_CORE_HASH_SIZE * PH_CORE_HASH_SIZE];
    ph_resize_bilinear(gray_full, ctx->width, ctx->height, hash_input, PH_CORE_HASH_SIZE, PH_CORE_HASH_SIZE);

    uint64_t total_sum = 0;
    int num_pixels = PH_CORE_HASH_SIZE * PH_CORE_HASH_SIZE;
    for (int i = 0; i < num_pixels; i++) {
        total_sum += hash_input[i];
    }
    uint8_t avg = (uint8_t)(total_sum / num_pixels);

    uint64_t hash = 0;
    for (int i = 0; i < num_pixels; i++) {
        if (hash_input[i] >= avg) {
            hash |= (1ULL << i);
        }
    }

    *out_hash = hash;
    return PH_SUCCESS;
}
