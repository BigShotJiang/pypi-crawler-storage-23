"""Commune CLI — official command-line interface for the Commune email API."""

__version__ = "0.1.2"
