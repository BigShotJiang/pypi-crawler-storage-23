"""commune delivery — delivery metrics, events, and suppressions."""

from __future__ import annotations

from typing import Optional

import typer

from ..client import CommuneClient
from ..errors import api_error, auth_required_error, network_error
from ..output import print_list, print_record
from ..state import AppState

app = typer.Typer(help="Delivery metrics, events, and suppressions.", no_args_is_help=True)

PERIOD_HELP = "Time period: 1d, 7d, 30d (default: 7d)."


@app.command("metrics")
def delivery_metrics(
    ctx: typer.Context,
    domain_id: Optional[str] = typer.Option(None, "--domain-id", help="Filter by domain ID."),
    inbox_id: Optional[str] = typer.Option(None, "--inbox-id", help="Filter by inbox ID."),
    period: Optional[str] = typer.Option(None, "--period", help=PERIOD_HELP),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get delivery metrics (sent, delivered, bounced, spam). GET /v1/delivery/metrics."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/delivery/metrics", params={
            "domainId": domain_id,
            "inboxId": inbox_id,
            "period": period,
        })
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_record(r.json(), json_output=json_output or state.should_json(), title="Delivery Metrics")


@app.command("events")
def delivery_events(
    ctx: typer.Context,
    domain_id: Optional[str] = typer.Option(None, "--domain-id", help="Filter by domain ID."),
    inbox_id: Optional[str] = typer.Option(None, "--inbox-id", help="Filter by inbox ID."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Maximum results to return."),
    cursor: Optional[str] = typer.Option(None, "--cursor", help="Pagination cursor."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get delivery events (sent, bounce, complaint, open, click). GET /v1/delivery/events."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/delivery/events", params={
            "domainId": domain_id,
            "inboxId": inbox_id,
            "limit": limit,
            "cursor": cursor,
        })
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title="Delivery Events",
        columns=[
            ("Type", "type"),
            ("Email", "email"),
            ("Message ID", "messageId"),
            ("Timestamp", "timestamp"),
        ],
    )


@app.command("suppressions")
def delivery_suppressions(
    ctx: typer.Context,
    domain_id: Optional[str] = typer.Option(None, "--domain-id", help="Filter by domain ID."),
    inbox_id: Optional[str] = typer.Option(None, "--inbox-id", help="Filter by inbox ID."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Maximum results."),
    cursor: Optional[str] = typer.Option(None, "--cursor", help="Pagination cursor."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """List suppressed email addresses (bounces + spam complaints). GET /v1/delivery/suppressions."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/delivery/suppressions", params={
            "domainId": domain_id,
            "inboxId": inbox_id,
            "limit": limit,
            "cursor": cursor,
        })
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title="Suppressed Addresses",
        columns=[
            ("Email", "email"),
            ("Reason", "reason"),
            ("Suppressed At", "suppressedAt"),
        ],
    )
