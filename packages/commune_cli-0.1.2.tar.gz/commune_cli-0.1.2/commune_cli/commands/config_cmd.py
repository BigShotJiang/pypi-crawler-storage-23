"""commune config — manage ~/.commune/config.toml."""

from __future__ import annotations

from typing import Optional

import typer

from ..config import KNOWN_KEYS, config_path, delete_value, get_value, load_config, mask, set_value
from ..output import print_kv, print_success, print_value, print_warning

app = typer.Typer(help="Manage CLI configuration.", no_args_is_help=True)


@app.command("set")
def config_set(
    key: str = typer.Argument(..., help=f"Config key. Known keys: {', '.join(KNOWN_KEYS)}."),
    value: str = typer.Argument(..., help="Value to store."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Set a config key and persist to ~/.commune/config.toml."""
    if key not in KNOWN_KEYS:
        known = ", ".join(KNOWN_KEYS)
        print_warning(f"Unknown key '{key}'. Known keys: {known}")
    set_value(key, value)
    display = mask(value) if key == "api_key" else value
    print_success(f"Set {key} = {display}  ({config_path()})")
    if json_output:
        from ..output import print_json
        print_json({"key": key, "set": True})


@app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Config key to retrieve."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get a single config value."""
    value = get_value(key)
    if value is None:
        print_warning(f"Key '{key}' is not set in config.")
        raise typer.Exit(1)
    # Mask api_key in terminal display
    display = mask(value) if key == "api_key" else value
    print_value(display, json_output=json_output, key=key)


@app.command("show")
def config_show(
    reveal: bool = typer.Option(False, "--reveal", help="Show full api_key (not masked)."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Print all config values. Masks api_key unless --reveal is passed."""
    cfg = load_config()
    if not cfg:
        print_warning(f"No config file found at {config_path()}")
        raise typer.Exit(0)

    pairs: dict[str, str] = {}
    for k, v in cfg.items():
        if k == "api_key" and not reveal:
            pairs[k] = mask(v)
        else:
            pairs[k] = str(v)

    print_kv(pairs, json_output=json_output, title=f"Config  {config_path()}")


@app.command("unset")
def config_unset(
    key: str = typer.Argument(..., help="Config key to remove."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Remove a key from config."""
    removed = delete_value(key)
    if removed:
        print_success(f"Removed '{key}' from config.")
    else:
        print_warning(f"Key '{key}' was not set.")
    if json_output:
        from ..output import print_json
        print_json({"key": key, "removed": removed})


@app.command("path")
def config_path_cmd() -> None:
    """Print the path to the config file."""
    import sys
    sys.stdout.write(str(config_path()) + "\n")
