"""Test project config package."""
