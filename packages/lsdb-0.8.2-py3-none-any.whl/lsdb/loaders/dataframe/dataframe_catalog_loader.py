from __future__ import annotations

import re
import warnings

import astropy.units as u
import hats as hc
import hats.pixel_math.healpix_shim as hp
import nested_pandas as npd
import numpy as np
import pandas as pd
import pyarrow as pa
from hats.catalog import CatalogType, TableProperties
from hats.io.size_estimates import get_mem_size_per_row
from hats.pixel_math import HealpixPixel, generate_histogram
from hats.pixel_math.healpix_pixel_function import get_pixel_argsort
from hats.pixel_math.sparse_histogram import supplemental_count_histogram
from hats.pixel_math.spatial_index import (
    SPATIAL_INDEX_COLUMN,
    SPATIAL_INDEX_ORDER,
    compute_spatial_index,
    healpix_to_spatial_index,
)
from mocpy import MOC

import lsdb.nested as nd
from lsdb.catalog.catalog import Catalog
from lsdb.io.common import new_provenance_properties
from lsdb.io.schema import get_arrow_schema
from lsdb.loaders.dataframe.from_dataframe_utils import _generate_dask_dataframe, _has_named_index
from lsdb.types import DaskDFPixelMap

pd.options.mode.chained_assignment = None  # default='warn'


class DataframeCatalogLoader:
    """Creates a HATS formatted Catalog from a Pandas Dataframe"""

    # pylint: disable=too-many-arguments
    def __init__(
        self,
        dataframe: pd.DataFrame,
        *,
        ra_column: str | None = None,
        dec_column: str | None = None,
        lowest_order: int = 0,
        highest_order: int = 7,
        drop_empty_siblings: bool = False,
        partition_rows: int | None = None,
        partition_bytes: int | None = None,
        should_generate_moc: bool = True,
        moc_max_order: int = 10,
        use_pyarrow_types: bool = True,
        schema: pa.Schema | None = None,
        **kwargs,
    ) -> None:
        """Initializes a DataframeCatalogLoader

        Parameters
        ----------
        dataframe : pd.Dataframe
            Catalog Pandas Dataframe.
        ra_column : str or None
            The name of the right ascension column.
            By default, case-insensitive versions of 'ra' are detected.
        dec_column : str or None
            The name of the declination column.
            By default, case-insensitive versions of 'dec' are detected.
        lowest_order : int, default 0
            The lowest partition order.
        highest_order : int, default 7
            The highest partition order.
        drop_empty_siblings : bool, default False
            When determining final partitionining, if 3 of 4 pixels are empty,
            keep only the non-empty pixel
        partition_rows : int or None, default None
            The maximum partition size, in number of rows. If specified,
            'partition_bytes' must be None.
        partition_bytes : int or None, default None
            The maximum partition size, in bytes. If specified,
            'partition_rows' must be None.
        should_generate_moc : bool, default True
            Should we generate a MOC (multi-order coverage map) of the data.
            It can improve performance when joining/crossmatching to other hats-sharded datasets.
        moc_max_order : int, default 10
            If generating a MOC, what to use as the max order.
        use_pyarrow_types : bool, default True
            If True, the data is backed by pyarrow, otherwise we keep the original data types.
        schema : pa.Schema or None
            The arrow schema to create the catalog with. If None, the schema is
            automatically inferred from the provided DataFrame using `pa.Schema.from_pandas`.
        **kwargs
            Arguments to pass to the creation of the catalog info.
        """
        self.dataframe = npd.NestedFrame(dataframe)
        self.lowest_order = lowest_order
        self.highest_order = highest_order
        self.drop_empty_siblings = drop_empty_siblings
        self.partition_rows, self.partition_bytes = self._calculate_threshold(partition_rows, partition_bytes)

        if ra_column is None:
            ra_column = self._find_column("ra")
        if dec_column is None:
            dec_column = self._find_column("dec")

        # Validate RA/Dec columns.
        if dataframe[ra_column].isna().any() or dataframe[dec_column].isna().any():
            raise ValueError(f"NaN values found in {ra_column}/{dec_column} columns")

        # Don't allow deprecated arguments.
        for deprecated_arg in ["threshold", "partition_size"]:
            if deprecated_arg in kwargs:
                raise ValueError(
                    f"'{deprecated_arg}' is deprecated; use 'partition_rows' or 'partition_bytes' instead."
                )

        # Don't allow users to specify hats_max_rows or hats_max_bytes directly.
        for invalid_arg in ["hats_max_rows", "hats_max_bytes"]:
            if invalid_arg in kwargs:
                raise ValueError(
                    f"{invalid_arg} should not be provided in kwargs; "
                    "use 'partition_rows' or 'partition_bytes' instead"
                )

        # Set partitioning kwarg to pass to catalog info creation.
        if self.partition_rows is not None:
            kwargs = dict(kwargs, hats_max_rows=self.partition_rows)
        elif self.partition_bytes is not None:
            kwargs = dict(kwargs, hats_max_bytes=self.partition_bytes)

        self.catalog_info = self._create_catalog_info(
            ra_column=ra_column,
            dec_column=dec_column,
            total_rows=len(self.dataframe),
            **kwargs,
        )
        self.should_generate_moc = should_generate_moc
        self.moc_max_order = moc_max_order
        self.use_pyarrow_types = use_pyarrow_types
        self.schema = schema

    def _find_column(self, search_term: str) -> str:
        """Finds the column in the data frame matching the search term.

        The search is case-insensitive and unambiguous. An error is raised
        if there are zero or multiple matches."""
        matches = [
            c for c in self.dataframe.columns if re.fullmatch(re.escape(search_term), c, re.IGNORECASE)
        ]
        n_matches = len(matches)
        if n_matches == 0:
            raise ValueError(f"No column found for {search_term}")
        if n_matches > 1:
            raise ValueError(f"Found {n_matches} possible columns for {search_term}")
        return matches[0]

    def _calculate_threshold(
        self,
        partition_rows: int | None = None,
        partition_bytes: int | None = None,
    ) -> tuple[int | None, int | None]:
        """Verifies partition thresholds and sets default if necessary.

        If partition_rows is provided, no partition exceeds the maximum number of rows;
        if partition_bytes is provided, no partition exceeds the maximum memory size.

        If neither partition_rows nor partition_bytes is provided, a default
        partition size of approximately 1 GiB is used.

        Parameters
        ----------
        partition_rows : int or None, default None
            The desired partition size maximum, in number of rows.
        partition_bytes : int or None, default None
            The desired partition size maximum, in bytes.

        Returns
        -------
        tuple[int or None, int or None]
            The validated partition_rows and partition_bytes.

        Raises
        ------
        ValueError
            If both partition_rows and partition_bytes are specified.
        """
        self.df_total_memory = self.dataframe.memory_usage(deep=True).sum()
        if self.df_total_memory > (1 << 30) or len(self.dataframe) > 1_000_000:
            warnings.warn(
                "from_dataframe is not intended for large datasets. "
                "Consider using hats-import: https://hats-import.readthedocs.io/",
                RuntimeWarning,
            )

        if partition_rows is not None and partition_bytes is not None:
            raise ValueError("Specify only one: partition_rows or partition_bytes")
        if partition_rows is None and partition_bytes is None:
            # Default to 1 GiB partitions
            partition_bytes = 1 << 30
        return partition_rows, partition_bytes

    def _create_catalog_info(
        self,
        catalog_name: str = "from_lsdb_dataframe",
        ra_column: str = "ra",
        dec_column: str = "dec",
        catalog_type: CatalogType = CatalogType.OBJECT,
        **kwargs,
    ) -> TableProperties:
        """Creates the catalog info object

        Parameters
        ----------
        catalog_name : str, default 'from_lsdb_dataframe'
            It is recommended to provide a new name for your catalog
        ra_column : str, default 'ra'
            Column to find right ascension coordinate
        dec_column : str, default 'dec'
            Column to find declination coordinate
        catalog_type : str, default 'object'
            Type of table being created (e.g. OBJECT, SOURCE, MAP)
        **kwargs
            Arguments to pass to the creation of the catalog info

        Returns
        -------
        hats.catalog.TableProperties
            The catalog info object
        """
        if kwargs is None:
            kwargs = {}
        kwargs = kwargs | new_provenance_properties(hats_estsize=self.df_total_memory)
        if catalog_type and catalog_type not in (CatalogType.OBJECT, CatalogType.SOURCE, CatalogType.MAP):
            raise ValueError(f"Cannot create {catalog_type} type catalog via from_dataframe.")
        return TableProperties(
            catalog_name=catalog_name,
            ra_column=ra_column,
            dec_column=dec_column,
            catalog_type=catalog_type,
            healpix_column=SPATIAL_INDEX_COLUMN,
            healpix_order=SPATIAL_INDEX_ORDER,
            **kwargs,
        )

    def load_catalog(self) -> Catalog:
        """Load a catalog from a Pandas Dataframe

        Returns
        -------
        Catalog
            Catalog object with data from the source given at loader initialization.
        """
        self._set_spatial_index()
        pixel_list = self._compute_pixel_list()
        ddf, ddf_pixel_map, total_rows = self._generate_dask_df_and_map(pixel_list)
        self.catalog_info.total_rows = total_rows
        moc = self._generate_moc() if self.should_generate_moc else None
        schema = self.schema if self.schema is not None else get_arrow_schema(ddf)
        hc_structure = hc.catalog.Catalog(self.catalog_info, pixel_list, moc=moc, schema=schema)

        # Recover NestedDtype (https://github.com/astronomy-commons/lsdb/issues/730)
        if len(self.dataframe.nested_columns) > 0:
            ddf = ddf.astype({col: self.dataframe[col].dtype for col in self.dataframe.nested_columns})

        return Catalog(ddf, ddf_pixel_map, hc_structure)

    def _set_spatial_index(self):
        """Generates the spatial indices for each data point and assigns
        the spatial index column as the Dataframe index."""
        if _has_named_index(self.dataframe):
            self.dataframe.reset_index(inplace=True)
        self.dataframe[SPATIAL_INDEX_COLUMN] = compute_spatial_index(
            ra_values=self.dataframe[self.catalog_info.ra_column].to_numpy(),
            dec_values=self.dataframe[self.catalog_info.dec_column].to_numpy(),
        )
        self.dataframe.set_index(SPATIAL_INDEX_COLUMN, inplace=True)

    def _compute_pixel_list(self) -> list[HealpixPixel]:
        """Compute object histogram and generate the sorted list of
        HEALPix pixels. The pixels are sorted by ascending spatial index.

        Returns
        -------
        list[HealpixPixel]
            HEALPix pixels for the final partitioning.
        """
        # Generate histograms.
        if self.partition_rows is not None:
            row_count_histogram = generate_histogram(
                self.dataframe,
                highest_order=self.highest_order,
                ra_column=self.catalog_info.ra_column,
                dec_column=self.catalog_info.dec_column,
            )
            mem_size_histogram = None
        else:
            row_mem_sizes = get_mem_size_per_row(self.dataframe)
            mapped_pixels = hp.radec2pix(
                self.highest_order,
                self.dataframe[self.catalog_info.ra_column].values,
                self.dataframe[self.catalog_info.dec_column].values,
            )
            row_count_sparse_histo, mem_size_sparse_histo = supplemental_count_histogram(
                mapped_pixels,
                row_mem_sizes,
                highest_order=self.highest_order,
            )
            row_count_histogram = row_count_sparse_histo.to_array()
            mem_size_histogram = mem_size_sparse_histo.to_array()

        # Generate alignment.
        alignment = hc.pixel_math.generate_alignment(
            row_count_histogram,
            highest_order=self.highest_order,
            lowest_order=self.lowest_order,
            threshold=(self.partition_rows if self.partition_rows is not None else self.partition_bytes),
            drop_empty_siblings=self.drop_empty_siblings,
            mem_size_histogram=mem_size_histogram,
        )
        pixel_list = list({HealpixPixel(tup[0], tup[1]) for tup in alignment if not tup is None})
        return list(np.array(pixel_list)[get_pixel_argsort(pixel_list)])

    def _generate_dask_df_and_map(
        self, pixel_list: list[HealpixPixel]
    ) -> tuple[nd.NestedFrame, DaskDFPixelMap, int]:
        """Load Dask DataFrame from HEALPix pixel Dataframes and
        generate a mapping of HEALPix pixels to HEALPix Dataframes

        Returns
        -------
        tuple[nd.NestedFrame, DaskDFPixelMap, int]
            Tuple containing the Dask Dataframe, the mapping of HEALPix pixels
            to the respective Pandas Dataframes and the total number of rows.
        """
        # Dataframes for each destination HEALPix pixel
        pixel_dfs: list[npd.NestedFrame] = []

        # Mapping HEALPix pixels to the respective Dataframe indices
        ddf_pixel_map: dict[HealpixPixel, int] = {}

        for hp_pixel_index, hp_pixel in enumerate(pixel_list):
            # Store HEALPix pixel in map
            ddf_pixel_map[hp_pixel] = hp_pixel_index
            # Obtain Dataframe for current HEALPix pixel, using NESTED characteristics.
            left_bound = healpix_to_spatial_index(hp_pixel.order, hp_pixel.pixel)
            right_bound = healpix_to_spatial_index(hp_pixel.order, hp_pixel.pixel + 1)
            pixel_df = self.dataframe.loc[
                (self.dataframe.index >= left_bound) & (self.dataframe.index < right_bound)
            ]
            pixel_dfs.append(pixel_df)

        # Generate Dask Dataframe with the original schema and desired backend
        ddf, total_rows = _generate_dask_dataframe(pixel_dfs, pixel_list, self.use_pyarrow_types)
        return ddf, ddf_pixel_map, total_rows

    def _generate_moc(self):
        lon = self.dataframe[self.catalog_info.ra_column].to_numpy() * u.deg
        lat = self.dataframe[self.catalog_info.dec_column].to_numpy() * u.deg
        return MOC.from_lonlat(lon=lon, lat=lat, max_norder=self.moc_max_order)
