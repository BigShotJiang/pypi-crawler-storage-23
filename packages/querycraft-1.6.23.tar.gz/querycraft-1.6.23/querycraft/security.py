# querycraft/sql_security.py
import re
import html
from querycraft.logger import get_logger


class SQLSecurityValidator:
    """Validateur de sécurité pour les requêtes SQL"""

    # Commandes SQL dangereuses interdites en contexte pédagogique
    FORBIDDEN_KEYWORDS = [
        'DROP', 'DELETE', 'INSERT', 'UPDATE', 'ALTER', 'CREATE',
        'TRUNCATE', 'REPLACE', 'GRANT', 'REVOKE', 'EXECUTE',
        'EXEC', 'CALL', 'MERGE', 'RENAME', 'COMMENT'
    ]

    # Patterns d'injection SQL classiques
    INJECTION_PATTERNS = [
        r";\s*(DROP|DELETE|INSERT|UPDATE|ALTER|CREATE)",  # Commandes multiples
        r"--\s*$",  # Commentaires en fin de ligne (autorisés mais surveillés)
        r"/\*.*\*/",  # Commentaires multi-lignes
        r"UNION\s+SELECT",  # UNION-based injection
        r"OR\s+['\"]?1['\"]?\s*=\s*['\"]?1",  # OR 1=1
        r"OR\s+['\"]?true['\"]?",  # OR true
        r";\s*WAITFOR\s+DELAY",  # Time-based injection (SQL Server)
        r";\s*SLEEP\s*\(",  # Time-based injection (MySQL)
        r";\s*pg_sleep\s*\(",  # Time-based injection (PostgreSQL)
        r"xp_cmdshell",  # Command execution (SQL Server)
        r"load_file\s*\(",  # File reading (MySQL)
        r"into\s+outfile",  # File writing (MySQL)
        r"into\s+dumpfile",  # File writing (MySQL)
    ]

    @staticmethod
    def validate_sql(sql_query: str, allow_comments=True) -> tuple[bool, str]:
        """
        Valide une requête SQL pour détecter les injections

        Args:
            sql_query: La requête SQL à valider
            allow_comments: Autoriser les commentaires SQL

        Returns:
            (is_safe: bool, message: str)
        """
        log = get_logger("security")

        if not sql_query or not sql_query.strip():
            return False, "Requête SQL vide"

        # Normalisation
        sql_upper = sql_query.upper()
        sql_normalized = ' '.join(sql_query.split())

        # 1. Vérification des mots-clés interdits
        for keyword in SQLSecurityValidator.FORBIDDEN_KEYWORDS:
            # Recherche le mot-clé comme token isolé
            pattern = r'\b' + keyword + r'\b'
            if re.search(pattern, sql_upper):
                log.warning(f"Mot-clé SQL interdit détecté: {keyword}")
                return False, f"[Sécurité] Commande SQL interdite détectée : {keyword}. Seules les requêtes SELECT sont autorisées."

        # 2. Vérification des patterns d'injection
        for pattern in SQLSecurityValidator.INJECTION_PATTERNS:
            if re.search(pattern, sql_upper, re.IGNORECASE):
                log.warning(f"Pattern d'injection SQL détecté: {pattern}")
                return False, f"[Sécurité] Pattern suspect détecté dans la requête SQL. Vérifiez votre syntaxe."

        # 3. Vérification des commentaires (si non autorisés)
        if not allow_comments:
            if '--' in sql_query or '/*' in sql_query:
                return False, "[Sécurité] Les commentaires SQL ne sont pas autorisés dans ce contexte"

        # 4. Validation basique du type de requête
        try:
            # Extraction du premier mot-clé SQL significatif
            # Ignore les espaces et commentaires au début
            sql_stripped = re.sub(r'^\s*(--[^\n]*\n|\s)+', '', sql_normalized, flags=re.IGNORECASE).strip()

            if not sql_stripped:
                return False, "Requête SQL vide après nettoyage"

            # Récupère le premier mot-clé
            first_keyword_match = re.match(r'^(\w+)', sql_stripped, re.IGNORECASE)
            if not first_keyword_match:
                return False, "Impossible de déterminer le type de requête"

            first_keyword = first_keyword_match.group(1).upper()

            # Vérification que c'est bien un SELECT ou WITH (CTE)
            if first_keyword not in ['SELECT', 'WITH']:
                return False, f"Seules les requêtes SELECT sont autorisées (détecté: {first_keyword})"

        except Exception as e:
            log.error(f"Erreur lors de la validation SQL: {e}")
            return False, f"Erreur de validation SQL: {str(e)}"

        # 5. Vérification de la longueur (protection contre les requêtes monstrueuses)
        if len(sql_query) > 2000:
            return False, "[Sécurité] Requête SQL trop longue (maximum 2000 caractères)"

        return True, "Requête SQL validée"

    @staticmethod
    def sanitize_sql_for_display(sql_query: str) -> str:
        """
        Nettoie une requête SQL pour l'affichage sécurisé en HTML. Laisse toutefois les quotes qui sont nécessaires pour la syntaxe SQL.
        """
        return html.escape(sql_query, False)
