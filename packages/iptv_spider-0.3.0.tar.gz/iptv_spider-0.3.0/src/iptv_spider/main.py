# -*- coding: utf-8 -*-
# pylint: disable=line-too-long
# pylint: disable=broad-exception-caught
"""
Entry module for iptv_spider.

This script downloads and processes an M3U8 playlist, filters channels using a regex pattern,
and outputs the best-performing channels to both a JSON file and an M3U file.
"""

import os
from datetime import datetime
import json

from iptv_spider.m3u import M3U8
from iptv_spider.logger import logger
from iptv_spider.utils import arg_parser, load_config


def main(
    m3u_url: str,
    regex_filter: str,
    output_dir: str,
    speed_threshold_mb: float = 0.3,
    speed_limit_mb: float = 2,
    max_retries: int = 3,
    request_timeout: int = 30
) -> dict:
    """
    Main function to process an IPTV playlist.

    Steps:
    1. Download or read the M3U8 file.
    2. Filter channels by name using the regex pattern.
    3. Select the fastest URL for each unique channel name.
    4. Save results to JSON and M3U files.

    Args:
        m3u_url (str): URL or local path of the M3U8 file.
        regex_filter (str): Regular expression to filter channel names.
        output_dir (str): Directory to save the output files.
        speed_threshold_mb (float): Minimum speed threshold in MB/s for output.
        speed_limit_mb (float): Speed limit in MB/s for early termination.
        max_retries (int): Maximum retry attempts for network requests.
        request_timeout (int): Timeout in seconds for HTTP requests.

    Returns:
        dict: Statistics about the test results.
    """
    # Ensure the output directory exists
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        logger.info(f"Output directory created: {output_dir}")

    # Create an M3U8 object and load channels
    logger.info(f"Processing M3U8 playlist from: {m3u_url}")
    m3u8 = M3U8(
        path=m3u_url,
        regex_filter=regex_filter,
        max_retries=max_retries,
        request_timeout=request_timeout
    )

    logger.info(f"Total channels filtered: {len(m3u8.channels)}")
    best_channels_dict = m3u8.get_best_channels(speed_limit=int(speed_limit_mb))

    # Prepare results for saving
    best_channels = {}
    speed_threshold_bytes = speed_threshold_mb * 1024 * 1024
    valid_channels = 0

    for channel_name, channel in best_channels_dict.items():
        if channel.speed > speed_threshold_bytes:
            valid_channels += 1
            best_channels[channel_name] = {
                "name": channel.channel_name,
                "meta": channel.meta,
                "media_url": channel.media_url,
                "speed": channel.speed,
                "speed_mbps": round(channel.speed / (1024 * 1024), 2),
                "resolution": channel.resolution
            }

    # Save filtered channels to a JSON file
    json_filename = os.path.join(output_dir, f"best_channels_{datetime.today().strftime('%Y-%m-%d')}.json")
    with open(json_filename, 'w', encoding='utf-8') as json_file:
        json.dump(best_channels, json_file, indent=4, ensure_ascii=False)
    logger.info(f"Filtered channel details saved to: {json_filename}")

    # Save results to an M3U file
    m3u_filename = os.path.join(output_dir, 'best_channels.m3u')
    with open(m3u_filename, 'w', encoding='utf-8') as m3u_file:
        for channel_name, channel_info in best_channels.items():
            m3u_file.write(f"{channel_info['meta']},{channel_info['name']}\n")
            m3u_file.write(f"{channel_info['media_url']}\n")
    logger.info(f"Filtered M3U playlist saved to: {m3u_filename}")

    # Calculate and return statistics
    stats = {
        "total_channels_filtered": len(m3u8.channels),
        "best_channels_tested": len(best_channels_dict),
        "valid_channels_output": valid_channels,
        "speed_threshold_mb": speed_threshold_mb,
        "output_files": [json_filename, m3u_filename]
    }

    return stats


def entrypoint() -> None:
    """
    Entry point for the IPTV Spider program.
    """
    # Parse command-line arguments
    args = arg_parser()
    config = load_config()
    config.update(args.__dict__)

    # Run the main program with provided arguments
    logger.info("Starting IPTV Spider...")
    stats = main(
        m3u_url=str(config.get("url_or_path", "https://live.iptv365.org/live.m3u")),
        regex_filter=str(config.get("filter", r"\b(cctv|CCTV)-?(?:[1-9]|1[0-7]|5\+?)\b")),
        output_dir=str(config.get("output_dir", ".")),
        speed_threshold_mb=config.get("speed_threshold_mb", 0.3),
        speed_limit_mb=config.get("speed_limit_mb", 2),
        max_retries=config.get("max_retries", 3),
        request_timeout=config.get("request_timeout", 30)
    )

    # Log statistics
    logger.info("=" * 50)
    logger.info("IPTV Spider Test Summary:")
    logger.info(f"Total channels filtered: {stats['total_channels_filtered']}")
    logger.info(f"Best channels tested: {stats['best_channels_tested']}")
    logger.info(f"Valid channels output: {stats['valid_channels_output']}")
    logger.info(f"Speed threshold: {stats['speed_threshold_mb']} MB/s")
    logger.info(f"Output files: {', '.join(stats['output_files'])}")
    logger.info("=" * 50)
    logger.info("IPTV Spider finished execution.")


if __name__ == "__main__":
    # Parse command-line arguments
    args = arg_parser()
    config = load_config()
    config.update(args.__dict__)

    # Run the main program with provided arguments
    logger.info("Starting IPTV Spider...")
    stats = main(
        m3u_url=str(config.get("url_or_path", "https://live.iptv365.org/live.m3u")),
        regex_filter=str(config.get("filter", r"\b(cctv|CCTV)-?(?:[1-9]|1[0-7]|5\+?)\b")),
        output_dir=str(config.get("output_dir", ".")),
        speed_threshold_mb=config.get("speed_threshold_mb", 0.3),
        speed_limit_mb=config.get("speed_limit_mb", 2),
        max_retries=config.get("max_retries", 3),
        request_timeout=config.get("request_timeout", 30)
    )

    # Log statistics
    logger.info("=" * 50)
    logger.info("IPTV Spider Test Summary:")
    logger.info(f"Total channels filtered: {stats['total_channels_filtered']}")
    logger.info(f"Best channels tested: {stats['best_channels_tested']}")
    logger.info(f"Valid channels output: {stats['valid_channels_output']}")
    logger.info(f"Speed threshold: {stats['speed_threshold_mb']} MB/s")
    logger.info(f"Output files: {', '.join(stats['output_files'])}")
    logger.info("=" * 50)
    logger.info("IPTV Spider finished execution.")
