"""Gitrama MCP Server — AI-powered Git intelligence for your IDE."""

__version__ = "1.1.4"
