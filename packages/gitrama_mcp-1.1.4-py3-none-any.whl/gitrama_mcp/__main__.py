"""Allow running with: python -m gitrama_mcp"""
from gitrama_mcp.server import main

main()
