"""Voice Coding — Private voice-to-text for developers."""
