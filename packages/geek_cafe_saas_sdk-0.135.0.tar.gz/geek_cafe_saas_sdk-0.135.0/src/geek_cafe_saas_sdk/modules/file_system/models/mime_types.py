"""
Common MIME type mappings by file extension.

Usage:
    from geek_cafe_saas_sdk.modules.file_system.models.mime_types import get_mime_type

    mime = get_mime_type(".csv")   # "text/csv"
    mime = get_mime_type("csv")    # "text/csv"
    mime = get_mime_type(".xyz")   # "application/octet-stream"
"""

MIME_TYPES: dict[str, str] = {
    # Text
    ".csv": "text/csv",
    ".txt": "text/plain",
    ".html": "text/html",
    ".htm": "text/html",
    ".css": "text/css",
    ".js": "text/javascript",
    ".xml": "text/xml",
    ".md": "text/markdown",
    ".rtf": "application/rtf",
    ".tsv": "text/tab-separated-values",
    # JSON / YAML
    ".json": "application/json",
    ".yaml": "application/x-yaml",
    ".yml": "application/x-yaml",
    # PDF / Documents
    ".pdf": "application/pdf",
    ".doc": "application/msword",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xls": "application/vnd.ms-excel",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".ppt": "application/vnd.ms-powerpoint",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    # Images
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".tiff": "image/tiff",
    ".tif": "image/tiff",
    # Archives
    ".zip": "application/zip",
    ".gz": "application/gzip",
    ".tar": "application/x-tar",
    ".7z": "application/x-7z-compressed",
    ".rar": "application/vnd.rar",
    # Audio
    ".mp3": "audio/mpeg",
    ".wav": "audio/wav",
    ".ogg": "audio/ogg",
    # Video
    ".mp4": "video/mp4",
    ".avi": "video/x-msvideo",
    ".mov": "video/quicktime",
    ".webm": "video/webm",
    # Data / Science
    ".parquet": "application/vnd.apache.parquet",
    ".sas7bdat": "application/x-sas-data",
    ".xpt": "application/x-sas-xport",
    ".sav": "application/x-spss-sav",
    ".dta": "application/x-stata-dta",
    ".rds": "application/x-r-data",
    ".h5": "application/x-hdf5",
    ".hdf5": "application/x-hdf5",
}

DEFAULT_MIME_TYPE = "application/octet-stream"


def get_mime_type(extension: str) -> str:
    """
    Look up the MIME type for a file extension.

    Args:
        extension: File extension with or without leading dot (e.g., ".csv" or "csv")

    Returns:
        MIME type string, or "application/octet-stream" if unknown.
    """
    if not extension:
        return DEFAULT_MIME_TYPE

    ext = extension if extension.startswith(".") else f".{extension}"
    return MIME_TYPES.get(ext.lower(), DEFAULT_MIME_TYPE)
