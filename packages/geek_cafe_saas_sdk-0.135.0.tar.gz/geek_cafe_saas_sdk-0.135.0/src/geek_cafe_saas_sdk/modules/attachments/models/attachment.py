"""
Attachment model for linking resources to parent entities.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from boto3_assist.dynamodb.dynamodb_index import DynamoDBIndex, DynamoDBKey
from typing import Dict, Any, Optional
from geek_cafe_saas_sdk.core.models.base_tenant_user_model import BaseTenantUserModel


class Attachment(BaseTenantUserModel):
    """
    Generic attachment model for linking resources to parent entities.
    
    Use cases:
    - Execution inputs/outputs
    - File references
    - Inline data storage
    - Linking any resource to a parent entity
    
    Examples:
        # Track execution output file
        attachment = Attachment()
        attachment.parent_id = execution_id
        attachment.parent_type = "execution"
        attachment.attachment_type = "output"
        attachment.category = "cleaned"
        attachment.reference_type = "file"
        attachment.reference_id = file_id
        
        # Store inline data
        attachment = Attachment()
        attachment.parent_id = execution_id
        attachment.parent_type = "execution"
        attachment.attachment_type = "output"
        attachment.reference_type = "inline"
        attachment.inline_data = {"key": "value"}
    """

    def __init__(self) -> None:
        super().__init__()
        
        # Parent entity this attaches to
        self.parent_id: Optional[str] = None
        self.parent_type: Optional[str] = None
        
        # Attachment metadata
        self.attachment_type: Optional[str] = None  # "input", "output", "reference", etc.
        self.name: Optional[str] = None  # Descriptive name
        self.category: Optional[str] = None  # e.g., "cleaned", "raw", "results"
        self.description: Optional[str] = None
        
        # Content (one of these will be populated based on reference_type)
        self.reference_type: Optional[str] = None  # "file", "inline", "url"
        self.reference_id: Optional[str] = None  # file_id if type="file", url if type="url"
        self.inline_data: Optional[Dict[str, Any]] = None  # For small inline data
        
        # Ordering and additional metadata
        self.sequence: Optional[int] = None  # Order of attachments
        
        self._setup_indexes()

    def _setup_indexes(self):
        """Setup DynamoDB indexes for querying attachments."""
        
        primary: DynamoDBIndex = DynamoDBIndex()
        primary.name = "primary"
        primary.partition_key.attribute_name = "pk"
        primary.partition_key.value = lambda: DynamoDBKey.build_key(
            ("attachment", self.id)
        )
        primary.sort_key.attribute_name = "sk"
        primary.sort_key.value = lambda: DynamoDBKey.build_key(("attachment", self.id))
        self.indexes.add_primary(primary)

        # GSI1: Query by parent (parent_type#parent_id) and attachment_type
        gsi1 = DynamoDBIndex("gsi1")
        gsi1.partition_key.attribute_name = "gsi1_pk"
        gsi1.partition_key.value = lambda: DynamoDBKey.build_key(
            ("parent_type", self.parent_type),
            ("parent_id", self.parent_id),
        )
        gsi1.sort_key.attribute_name = "gsi1_sk"
        gsi1.sort_key.value = lambda: DynamoDBKey.build_key(
            ("attachment_type", self.attachment_type),
            ("category", self.category),
            ("sequence", self.sequence),
            ("id", self.id),
        )
        self.indexes.add_secondary(gsi1)
        
        # GSI2: Query by tenant and parent type
        gsi2 = DynamoDBIndex("gsi2")
        gsi2.partition_key.attribute_name = "gsi2_pk"
        gsi2.partition_key.value = lambda: DynamoDBKey.build_key(
            ("tenant", self.tenant_id),
            ("parent_type", self.parent_type),
        )
        gsi2.sort_key.attribute_name = "gsi2_sk"
        gsi2.sort_key.value = lambda: DynamoDBKey.build_key(
            ("parent_id", self.parent_id),
            ("attachment_type", self.attachment_type),
            ("id", self.id),
        )
        self.indexes.add_secondary(gsi2)
        
        # GSI3: Query by reference (for finding what references a specific resource)
        gsi3 = DynamoDBIndex("gsi3")
        gsi3.partition_key.attribute_name = "gsi3_pk"
        gsi3.partition_key.value = lambda: DynamoDBKey.build_key(
            ("tenant", self.tenant_id),
            ("reference_type", self.reference_type),
            ("reference_id", self.reference_id),
        )
        gsi3.sort_key.attribute_name = "gsi3_sk"
        gsi3.sort_key.value = lambda: DynamoDBKey.build_key(
            ("parent_type", self.parent_type),
            ("parent_id", self.parent_id),
            ("id", self.id),
        )
        self.indexes.add_secondary(gsi3)
