"""
Hierarchy coordination service for managing wrapper executions and child coordination.

Provides concrete implementation of hierarchical workflow coordination using
the established DatabaseService patterns with proper atomic operations.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Optional, Dict, Any, List
from aws_lambda_powertools import Logger

from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.core.error_codes import ErrorCode
from geek_cafe_saas_sdk.core.request_context import RequestContext
from geek_cafe_saas_sdk.lambda_handlers._base.decorators import service_method
from boto3_assist.dynamodb.dynamodb import DynamoDB

from ..models.hierarchy_execution import (
    WrapperExecution, 
    HierarchyCoordinationRecord,
    HierarchyStatus
)
from ..models.execution import Workflow, WorkflowStatus
from .hierarchy_repository import WrapperExecutionService, HierarchyCoordinationService

logger = Logger()


class HierarchyWrapperExecutionService(DatabaseService[WrapperExecution], WrapperExecutionService):
    """
    Service for managing wrapper executions.
    
    Extends DatabaseService to provide CRUD operations for wrapper executions
    with proper hierarchical coordination support.
    """

    def __init__(
        self,
        *,
        dynamodb: Optional[DynamoDB] = None,
        table_name: Optional[str] = None,
        request_context: Optional[RequestContext] = None,
        **kwargs,
    ):
        super().__init__(
            dynamodb=dynamodb,
            table_name=table_name,
            request_context=request_context,
            **kwargs,
        )

    # Required DatabaseService abstract methods
    def create(self, tenant_id: str, user_id: str, **kwargs) -> ServiceResult[WrapperExecution]:
        """Create wrapper execution - delegates to create_wrapper_execution."""
        return self.create_wrapper_execution(
            name=kwargs.get("name", ""),
            user_request=kwargs.get("user_request", {}),
            child_execution_plan=kwargs.get("child_execution_plan", []),
            description=kwargs.get("description"),
            correlation_id=kwargs.get("correlation_id"),
            metadata=kwargs.get("metadata")
        )

    def get_by_id(self, resource_id: str, tenant_id: str, user_id: str) -> ServiceResult[WrapperExecution]:
        """Get wrapper execution by ID."""
        return self.get_wrapper_execution(resource_id)

    def update(self, resource_id: str, tenant_id: str, user_id: str, updates: dict) -> ServiceResult[WrapperExecution]:
        """Update wrapper execution - use specific methods like update_wrapper_status."""
        status = updates.get("status")
        error_message = updates.get("error_message")
        if resource_id and status:
            return self.update_wrapper_status(resource_id, status, error_message)
        return ServiceResult.error_result(
            "Use specific wrapper methods like update_wrapper_status() instead of generic update",
            ErrorCode.INVALID_INPUT
        )

    def delete(self, resource_id: str, tenant_id: str, user_id: str) -> ServiceResult[bool]:
        """Delete wrapper execution."""
        # Wrapper executions should not be deleted - they're audit trail
        return ServiceResult.error_result(
            "Wrapper executions cannot be deleted - they are part of the audit trail",
            ErrorCode.INVALID_INPUT
        )

    @service_method("create_wrapper_execution")
    def create_wrapper_execution(
        self,
        name: str,
        user_request: Dict[str, Any],
        child_execution_plan: List[Dict[str, Any]],
        description: Optional[str] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> ServiceResult[WrapperExecution]:
        """
        Create top-level wrapper execution and plan child executions.
        
        Args:
            name: Human-readable name for the wrapper execution
            user_request: The original user request payload
            child_execution_plan: List of planned child executions
            description: Optional description
            correlation_id: Optional correlation ID for tracking
            metadata: Optional additional metadata
            
        Returns:
            ServiceResult[WrapperExecution]: The created wrapper execution
        """
        try:
            # Validate inputs
            if not name:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Wrapper execution name is required"
                )
            
            if not child_execution_plan:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Child execution plan cannot be empty"
                )
            
            # Create wrapper execution
            wrapper = WrapperExecution.create_new(
                tenant_id=self.request_context.target_tenant_id,
                user_id=self.request_context.target_user_id,
                name=name,
                original_request=user_request,
                child_execution_plan=child_execution_plan,
                description=description,
                correlation_id=correlation_id,
                metadata=metadata
            )
            
            # Save to database
            wrapper.prep_for_save()
            save_result = self._save_model(wrapper)
            if not save_result.success:
                return ServiceResult.error_result(
                    error_code=ErrorCode.DATABASE_ERROR,
                    message=f"Failed to save wrapper execution: {save_result.message}"
                )
            
            logger.info(f"Created wrapper execution {wrapper.id} with {len(child_execution_plan)} planned children")
            
            return ServiceResult.success_result(wrapper)
            
        except Exception as e:
            logger.error(f"Error creating wrapper execution: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to create wrapper execution: {str(e)}"
            )

    @service_method("get_wrapper_execution")
    def get_wrapper_execution(self, wrapper_id: str) -> ServiceResult[Workflow]:
        """
        Get wrapper execution by ID.
        
        NOTE: Wrappers are currently created as Workflow objects with execution_type="workflow",
        not as WrapperExecution objects. So we fetch using the Workflow model.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[Workflow]: The wrapper execution
        """
        try:
            if not wrapper_id:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Wrapper ID is required"
                )
            
            # Fetch wrapper as Workflow object (not WrapperExecution) since that's how they're created
            # Use _fetch_model_raw which is raw DB fetch with no security checks
            wrapper_model = Workflow()
            wrapper_model.id = wrapper_id
            wrapper = self._fetch_model_raw(wrapper_model)
            
            if not wrapper:
                return ServiceResult.error_result(
                    error_code=ErrorCode.NOT_FOUND,
                    message=f"Wrapper execution not found: {wrapper_id}"
                )
            
            return ServiceResult.success_result(wrapper)
            
        except Exception as e:
            logger.error(f"Error getting wrapper execution {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to get wrapper execution: {str(e)}"
            )

    @service_method("update_wrapper_status")
    def update_wrapper_status(
        self,
        wrapper_id: str,
        status: str,
        error_message: Optional[str] = None
    ) -> ServiceResult[Workflow]:
        """
        Update wrapper execution status.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            status: New execution status (WorkflowStatus value)
            error_message: Error message if status is FAILED
            
        Returns:
            ServiceResult[Workflow]: Updated wrapper execution
        """
        try:
            if not wrapper_id:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Wrapper ID is required"
                )
            
            if status not in WorkflowStatus.ALL:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message=f"Invalid status: {status}"
                )
            
            # Get existing wrapper
            get_result = self.get_wrapper_execution(wrapper_id)
            if not get_result.success:
                return get_result
            
            wrapper = get_result.data
            
            # Update status
            wrapper.status = status
            if error_message:
                wrapper.error_message = error_message
            
            # Update completion timestamp for terminal states
            if status in WorkflowStatus.TERMINAL:
                wrapper.completed_utc_ts = wrapper.modified_utc_ts
            
            # Save updated wrapper
            wrapper.prep_for_save()
            save_result = self._save_model(wrapper)
            if not save_result.success:
                return ServiceResult.error_result(
                    error_code=ErrorCode.DATABASE_ERROR,
                    message=f"Failed to update wrapper status: {save_result.message}"
                )
            
            logger.info(f"Updated wrapper {wrapper_id} status to {status}")
            
            return ServiceResult.success_result(wrapper)
            
        except Exception as e:
            logger.error(f"Error updating wrapper status {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to update wrapper status: {str(e)}"
            )

    @service_method("complete_wrapper_execution")
    def complete_wrapper_execution(self, wrapper_id: str) -> ServiceResult[Workflow]:
        """
        Mark wrapper as complete when all children finish.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[Workflow]: Updated wrapper execution
        """
        return self.update_wrapper_status(wrapper_id, WorkflowStatus.SUCCEEDED)

    @service_method("fail_wrapper_execution")
    def fail_wrapper_execution(
        self, 
        wrapper_id: str, 
        error_message: str
    ) -> ServiceResult[Workflow]:
        """
        Mark wrapper as failed with error details.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            error_message: Description of the failure
            
        Returns:
            ServiceResult[Workflow]: Updated wrapper execution
        """
        if not error_message:
            return ServiceResult.error_result(
                error_code=ErrorCode.INVALID_INPUT,
                message="Error message is required when failing wrapper execution"
            )
        
        return self.update_wrapper_status(wrapper_id, WorkflowStatus.FAILED, error_message)


class HierarchyCoordinationServiceImpl(DatabaseService[HierarchyCoordinationRecord], HierarchyCoordinationService):
    """
    Service for coordinating hierarchy completion tracking.
    
    Provides atomic operations for tracking child execution completion
    and determining when wrapper executions should complete.
    """

    def __init__(
        self,
        *,
        dynamodb: Optional[DynamoDB] = None,
        table_name: Optional[str] = None,
        request_context: Optional[RequestContext] = None,
        **kwargs,
    ):
        super().__init__(
            dynamodb=dynamodb,
            table_name=table_name,
            request_context=request_context,
            **kwargs,
        )

    # Required DatabaseService abstract methods
    def create(self, tenant_id: str, user_id: str, **kwargs) -> ServiceResult[HierarchyCoordinationRecord]:
        """Create coordination record - delegates to create_coordination_record."""
        wrapper_id = kwargs.get("wrapper_id")
        expected_child_count = kwargs.get("expected_child_count", 0)
        return self.create_coordination_record(wrapper_id, expected_child_count)

    def get_by_id(self, resource_id: str, tenant_id: str, user_id: str) -> ServiceResult[HierarchyCoordinationRecord]:
        """Get coordination record by wrapper_id."""
        # Use internal _get_by_id which handles security automatically
        return ServiceResult.success_result(
            self._get_by_id(resource_id, HierarchyCoordinationRecord)
        )

    def update(self, resource_id: str, tenant_id: str, user_id: str, updates: dict) -> ServiceResult[HierarchyCoordinationRecord]:
        """Update coordination record - use specific methods like notify_child_completion."""
        return ServiceResult.error_result(
            message="Use specific coordination methods like notify_child_completion() instead of generic update",
            error_code=ErrorCode.INVALID_INPUT
        )

    def delete(self, resource_id: str, tenant_id: str, user_id: str) -> ServiceResult[bool]:
        """Delete coordination record."""
        # Coordination records should not be deleted - they're audit trail
        return ServiceResult.error_result(
            message="Coordination records cannot be deleted - they are part of the audit trail",
            error_code=ErrorCode.INVALID_INPUT
        )

    @service_method("create_coordination_record")
    def create_coordination_record(
        self,
        wrapper_id: str,
        expected_child_count: int
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Create hierarchy coordination record.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            expected_child_count: Number of child executions expected
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: The created coordination record
        """
        try:
            if not wrapper_id:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Wrapper ID is required"
                )
            
            if expected_child_count < 0:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Expected child count cannot be negative"
                )
            
            # Create coordination record
            record = HierarchyCoordinationRecord.create_new(
                wrapper_id=wrapper_id,
                tenant_id=self.request_context.target_tenant_id,
                user_id=self.request_context.target_user_id,
                expected_child_count=expected_child_count
            )
            
            # Save to database
            record.prep_for_save()
            save_result = self._save_model(record)
            if not save_result.success:
                return ServiceResult.error_result(
                    error_code=ErrorCode.DATABASE_ERROR,
                    message=f"Failed to save coordination record: {save_result.message}"
                )
            
            logger.info(f"Created coordination record for wrapper {wrapper_id} expecting {expected_child_count} children")
            
            return ServiceResult.success_result(record)
            
        except Exception as e:
            logger.error(f"Error creating coordination record for {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to create coordination record: {str(e)}"
            )

    @service_method("register_child_execution")
    def register_child_execution(
        self,
        wrapper_id: str,
        child_execution_id: str,
        execution_type: str,
        phase: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Register a child execution with its wrapper.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            child_execution_id: Unique identifier for the child execution
            execution_type: Type of execution
            phase: Execution phase
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Updated coordination record
        """
        try:
            if not all([wrapper_id, child_execution_id, execution_type, phase]):
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="All parameters are required for child registration"
                )
            
            # Get coordination record
            get_result = self.get_coordination_record(wrapper_id)
            if not get_result.success:
                return get_result
            
            record = get_result.data
            
            # Add child execution info
            child_info = {
                "child_execution_id": child_execution_id,
                "execution_type": execution_type,
                "phase": phase,
                "status": WorkflowStatus.PENDING,
                "registered_utc": record.modified_utc_ts
            }
            
            record.add_child_execution(child_execution_id, child_info)
            
            # Save updated record
            record.prep_for_save()
            save_result = self._save_model(record)
            if not save_result.success:
                return ServiceResult.error_result(
                    error_code=ErrorCode.DATABASE_ERROR,
                    message=f"Failed to register child execution: {save_result.message}"
                )
            
            logger.info(f"Registered child {child_execution_id} with wrapper {wrapper_id}")
            
            return ServiceResult.success_result(record)
            
        except Exception as e:
            logger.error(f"Error registering child {child_execution_id} with wrapper {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to register child execution: {str(e)}"
            )

    @service_method("notify_child_completion")
    def notify_child_completion(
        self,
        wrapper_id: str,
        child_execution_id: str,
        status: str,
        error_message: Optional[str] = None
    ) -> ServiceResult[Dict[str, Any]]:
        """
        Notify wrapper of child completion with atomic counter update.
        
        Uses DynamoDB atomic ADD operation to safely increment counters even with
        concurrent child completions from multiple Lambda invocations.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            child_execution_id: Unique identifier for the child execution
            status: Final status of the child execution (WorkflowStatus value)
            error_message: Error message if status is FAILED
            
        Returns:
            ServiceResult[Dict[str, Any]]: Coordination state with completion info
        """
        try:
            if not all([wrapper_id, child_execution_id, status]):
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Wrapper ID, child ID, and status are required"
                )
            
            if status not in WorkflowStatus.ALL:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message=f"Invalid status: {status}"
                )
            
            # Get coordination record to get the key and validate it exists
            get_result = self.get_coordination_record(wrapper_id)
            if not get_result.success:
                return get_result
            
            record = get_result.data
            
            # Idempotency check: if this child has already been recorded as
            # terminal (succeeded/failed), skip the counter increment to prevent
            # duplicate SQS deliveries from over-counting.
            child_info = record.child_executions.get(child_execution_id, {})
            existing_status = child_info.get("status")
            if existing_status in WorkflowStatus.TERMINAL:
                logger.warning(
                    f"Duplicate completion notification for child {child_execution_id} "
                    f"(already {existing_status}), skipping counter increment"
                )
                # Return current coordination state without modifying counters
                should_complete = record.should_complete_wrapper()
                should_fail = record.should_fail_wrapper()
                is_complete = record.is_complete()
                coordination_state = {
                    "wrapper_id": wrapper_id,
                    "child_execution_id": child_execution_id,
                    "child_status": existing_status,
                    "should_complete_wrapper": should_complete,
                    "should_fail_wrapper": should_fail,
                    "is_hierarchy_complete": is_complete,
                    "completed_children": record.completed_child_count,
                    "failed_children": record.failed_child_count,
                    "expected_children": record.expected_child_count,
                    "coordination_status": record.coordination_status,
                    "duplicate": True,
                }
                return ServiceResult.success_result(coordination_state)
            
            # Get key for atomic operation
            key = record.get_atomic_increment_key()
            
            # Determine which counter to increment based on status
            # Only include child status update if the child is registered in child_executions
            # (otherwise the nested DynamoDB path won't exist)
            cid_for_expr = child_execution_id if child_execution_id in record.child_executions else None
            if status == WorkflowStatus.SUCCEEDED:
                update_expr = HierarchyCoordinationRecord.get_atomic_completed_increment_expression(cid_for_expr)
            elif status == WorkflowStatus.FAILED:
                update_expr = HierarchyCoordinationRecord.get_atomic_failed_increment_expression(cid_for_expr)
            else:
                # Non-terminal status, no counter update needed
                logger.warning(f"Child {child_execution_id} completed with non-terminal status {status}")
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message=f"notify_child_completion should only be called for terminal statuses, got: {status}"
                )
            
            # Perform atomic counter increment using DynamoDB ADD operation.
            # Use return_values="ALL_NEW" to get the post-increment state in the
            # same round-trip, avoiding a separate strongly-consistent read and
            # eliminating the race window between the ADD and the read-back.
            try:
                response = self.dynamodb.update_item(
                    table_name=self.table_name,
                    key=key,
                    return_values="ALL_NEW",
                    **update_expr
                )
                logger.info(f"Atomically incremented counter for wrapper {wrapper_id} (child {child_execution_id} status: {status})")
            except Exception as e:
                logger.error(f"Failed to atomically update counter: {e}")
                return ServiceResult.error_result(
                    error_code=ErrorCode.DATABASE_ERROR,
                    message=f"Failed to atomically update completion counter: {str(e)}"
                )
            
            # Parse the returned attributes (atomic with the increment)
            updated_record = HierarchyCoordinationRecord()
            updated_record.map(response.get("Attributes", {}))
            
            # Determine coordination state
            should_complete = updated_record.should_complete_wrapper()
            should_fail = updated_record.should_fail_wrapper()
            is_complete = updated_record.is_complete()
            
            # Update coordination status if needed using atomic update to avoid overwriting counters
            if should_fail and updated_record.coordination_status != HierarchyStatus.FAILED:
                try:
                    from decimal import Decimal
                    import time
                    self.dynamodb.update_item(
                        table_name=self.table_name,
                        key=key,
                        update_expression="SET coordination_status = :status, modified_utc_ts = :ts",
                        expression_attribute_values={
                            ":status": HierarchyStatus.FAILED,
                            ":ts": Decimal(str(time.time()))
                        }
                    )
                except Exception as e:
                    logger.warning(f"Failed to update coordination status to FAILED: {e}")
            elif should_complete and updated_record.coordination_status != HierarchyStatus.COMPLETED:
                try:
                    from decimal import Decimal
                    import time
                    self.dynamodb.update_item(
                        table_name=self.table_name,
                        key=key,
                        update_expression="SET coordination_status = :status, modified_utc_ts = :ts",
                        expression_attribute_values={
                            ":status": HierarchyStatus.COMPLETED,
                            ":ts": Decimal(str(time.time()))
                        }
                    )
                except Exception as e:
                    logger.warning(f"Failed to update coordination status to COMPLETED: {e}")
            
            logger.info(
                f"Child {child_execution_id} completed with status {status} for wrapper {wrapper_id} "
                f"({updated_record.completed_child_count}/{updated_record.expected_child_count} completed, "
                f"{updated_record.failed_child_count} failed)"
            )
            
            # Return coordination state
            coordination_state = {
                "wrapper_id": wrapper_id,
                "child_execution_id": child_execution_id,
                "child_status": status,
                "should_complete_wrapper": should_complete,
                "should_fail_wrapper": should_fail,
                "is_hierarchy_complete": is_complete,
                "completed_children": updated_record.completed_child_count,
                "failed_children": updated_record.failed_child_count,
                "expected_children": updated_record.expected_child_count,
                "coordination_status": updated_record.coordination_status
            }
            
            return ServiceResult.success_result(coordination_state)
            
        except Exception as e:
            logger.error(f"Error notifying child completion for {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to notify child completion: {str(e)}"
            )

    @service_method("get_coordination_record")
    def get_coordination_record(
        self, 
        wrapper_id: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Get current coordination state for wrapper.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Current coordination record
        """
        try:
            if not wrapper_id:
                return ServiceResult.error_result(
                    error_code=ErrorCode.INVALID_INPUT,
                    message="Wrapper ID is required"
                )
            
            # Get coordination record directly using DynamoDB
            # The record uses wrapper_id as its id
            # Use the model's get_key method to get the correct key structure
            temp_record = HierarchyCoordinationRecord()
            temp_record.id = wrapper_id
            key = temp_record.get_key("primary").key()
            
            result = self.dynamodb.get(
                table_name=self.table_name,
                key=key,
                strongly_consistent=True
            )
            
            if not result or "Item" not in result:
                return ServiceResult.error_result(
                    error_code=ErrorCode.NOT_FOUND,
                    message=f"Coordination record not found for wrapper: {wrapper_id}"
                )
            
            # Map the result to a model
            fetched_record = HierarchyCoordinationRecord()
            fetched_record.map(result["Item"])
            
            return ServiceResult.success_result(fetched_record)
            
        except Exception as e:
            logger.error(f"Error getting coordination record for {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to get coordination record: {str(e)}"
            )

    @service_method("increment_completed_children")
    def increment_completed_children(
        self, 
        wrapper_id: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Atomically increment completed child counter using DynamoDB ADD operation.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Updated coordination record
        """
        try:
            # Get coordination record to get key and validate it exists
            get_result = self.get_coordination_record(wrapper_id)
            if not get_result.success:
                return get_result
            
            record = get_result.data
            key = record.get_atomic_increment_key()
            update_expr = HierarchyCoordinationRecord.get_atomic_completed_increment_expression()
            
            # Perform atomic increment
            try:
                self.dynamodb.update_item(
                    table_name=self.table_name,
                    key=key,
                    **update_expr
                )
            except Exception as e:
                logger.error(f"Failed to atomically increment completed children: {e}")
                return ServiceResult.error_result(
                    error_code=ErrorCode.DATABASE_ERROR,
                    message=f"Failed to atomically increment completed children: {str(e)}"
                )
            
            # Read back updated record
            updated_result = self.get_coordination_record(wrapper_id)
            if not updated_result.success:
                return updated_result
            
            updated_record = updated_result.data
            
            logger.info(f"Incremented completed children for wrapper {wrapper_id} to {updated_record.completed_child_count}")
            
            return ServiceResult.success_result(updated_record)
            
        except Exception as e:
            logger.error(f"Error incrementing completed children for {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to increment completed children: {str(e)}"
            )

    @service_method("increment_failed_children")
    def increment_failed_children(
        self, 
        wrapper_id: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Atomically increment failed child counter using DynamoDB ADD operation.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Updated coordination record
        """
        try:
            # Get coordination record to get key and validate it exists
            get_result = self.get_coordination_record(wrapper_id)
            if not get_result.success:
                return get_result
            
            record = get_result.data
            key = record.get_atomic_increment_key()
            update_expr = HierarchyCoordinationRecord.get_atomic_failed_increment_expression()
            
            # Perform atomic increment
            try:
                self.dynamodb.update_item(
                    table_name=self.table_name,
                    key=key,
                    **update_expr
                )
            except Exception as e:
                logger.error(f"Failed to atomically increment failed children: {e}")
                return ServiceResult.error_result(
                    error_code=ErrorCode.DATABASE_ERROR,
                    message=f"Failed to atomically increment failed children: {str(e)}"
                )
            
            # Read back updated record
            updated_result = self.get_coordination_record(wrapper_id)
            if not updated_result.success:
                return updated_result
            
            updated_record = updated_result.data
            
            logger.info(f"Incremented failed children for wrapper {wrapper_id} to {updated_record.failed_child_count}")
            
            return ServiceResult.success_result(updated_record)
            
        except Exception as e:
            logger.error(f"Error incrementing failed children for {wrapper_id}: {e}")
            return ServiceResult.error_result(
                error_code=ErrorCode.INTERNAL_ERROR,
                message=f"Failed to increment failed children: {str(e)}"
            )