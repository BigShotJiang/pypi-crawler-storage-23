"""
Workflow Lineage Service for tracking cross-workflow parent-child relationships.

Provides CRUD and query methods for WorkflowLineage records that track
relationships between independently submitted workflows.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from datetime import datetime, UTC
from typing import Optional, Dict, Any, List

from aws_lambda_powertools import Logger
from boto3_assist.dynamodb.dynamodb import DynamoDB

from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.core.error_codes import ErrorCode
from geek_cafe_saas_sdk.core.request_context import RequestContext
from geek_cafe_saas_sdk.lambda_handlers._base.decorators import service_method
from ..models.workflow_lineage import WorkflowLineage

logger = Logger()


class WorkflowLineageService(DatabaseService[WorkflowLineage]):
    """
    Service for managing cross-workflow lineage tracking.
    
    This service manages WorkflowLineage records that track parent-child
    relationships between independently submitted workflows. This is
    separate from the internal execution hierarchy (root_id/parent_id)
    which handles coordination within a single workflow.
    """

    def __init__(
        self,
        *,
        dynamodb: Optional[DynamoDB] = None,
        table_name: Optional[str] = None,
        request_context: Optional[RequestContext] = None,
        **kwargs,
    ):
        super().__init__(
            dynamodb=dynamodb,
            table_name=table_name,
            request_context=request_context,
            **kwargs,
        )

    # =========================================================================
    # Create Operations
    # =========================================================================

    @service_method("create_lineage_root")
    def create_root(
        self,
        execution_id: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ServiceResult[WorkflowLineage]:
        """
        Create a lineage record for the first workflow in a chain.
        
        Args:
            execution_id: This workflow's root/wrapper execution ID
            metadata: Optional context about this workflow
            
        Returns:
            ServiceResult with created WorkflowLineage
        """
        try:
            tenant_id = self.request_context.authenticated_tenant_id
            user_id = self.request_context.authenticated_user_id

            lineage = WorkflowLineage.create_root(
                execution_id=execution_id,
                tenant_id=tenant_id,
                user_id=user_id,
                metadata=metadata,
            )

            lineage.prep_for_save()
            result = self._save_model(lineage)

            if result.success:
                logger.info(
                    f"Created lineage root for execution {execution_id}",
                    extra={"execution_id": execution_id},
                )

            return result

        except Exception as e:
            logger.exception(f"Error creating lineage root: {e}")
            return ServiceResult.error_result(
                message=str(e), error_code=ErrorCode.INTERNAL_ERROR
            )

    @service_method("create_lineage_child")
    def create_child(
        self,
        execution_id: str,
        parent_workflow_id: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ServiceResult[WorkflowLineage]:
        """
        Create a lineage record for a child workflow in a chain.
        
        Automatically resolves the lineage_root_id and sequence_number
        from the parent's lineage record.
        
        Args:
            execution_id: This workflow's root/wrapper execution ID
            parent_workflow_id: Parent workflow's root/wrapper execution ID
            metadata: Optional context about this child workflow
            
        Returns:
            ServiceResult with created WorkflowLineage
        """
        try:
            tenant_id = self.request_context.authenticated_tenant_id
            user_id = self.request_context.authenticated_user_id

            # Look up parent's lineage to get root and sequence
            parent_lineage = self._get_lineage(parent_workflow_id)

            if parent_lineage:
                lineage_root_id = parent_lineage.lineage_root_id
                sequence_number = parent_lineage.sequence_number + 1
            else:
                # Parent has no lineage record — treat parent as the root
                logger.warning(
                    f"No lineage record found for parent {parent_workflow_id}, "
                    f"treating parent as lineage root"
                )
                lineage_root_id = parent_workflow_id
                sequence_number = 1

            lineage = WorkflowLineage.create_child(
                execution_id=execution_id,
                parent_workflow_id=parent_workflow_id,
                lineage_root_id=lineage_root_id,
                sequence_number=sequence_number,
                tenant_id=tenant_id,
                user_id=user_id,
                metadata=metadata,
            )

            lineage.prep_for_save()
            result = self._save_model(lineage)

            if result.success:
                logger.info(
                    f"Created lineage child for execution {execution_id} "
                    f"(parent={parent_workflow_id}, root={lineage_root_id}, "
                    f"seq={sequence_number})",
                    extra={
                        "execution_id": execution_id,
                        "parent_workflow_id": parent_workflow_id,
                        "lineage_root_id": lineage_root_id,
                        "sequence_number": sequence_number,
                    },
                )

            return result

        except Exception as e:
            logger.exception(f"Error creating lineage child: {e}")
            return ServiceResult.error_result(
                message=str(e), error_code=ErrorCode.INTERNAL_ERROR
            )

    # =========================================================================
    # Query Operations
    # =========================================================================

    @service_method("get_lineage")
    def get_lineage(
        self,
        execution_id: str,
    ) -> ServiceResult[WorkflowLineage]:
        """
        Get the lineage record for a specific execution.
        
        Args:
            execution_id: Execution ID to look up
            
        Returns:
            ServiceResult with WorkflowLineage or not-found error
        """
        try:
            lineage = self._get_lineage(execution_id)
            if not lineage:
                return ServiceResult.error_result(
                    message=f"No lineage record found for execution {execution_id}",
                    error_code=ErrorCode.NOT_FOUND,
                )
            return ServiceResult.success_result(lineage)

        except Exception as e:
            logger.exception(f"Error getting lineage: {e}")
            return ServiceResult.error_result(
                message=str(e), error_code=ErrorCode.INTERNAL_ERROR
            )

    @service_method("get_workflow_chain")
    def get_workflow_chain(
        self,
        lineage_root_id: str,
        limit: int = 50,
    ) -> ServiceResult[List[WorkflowLineage]]:
        """
        Get all workflows in a lineage chain, ordered by sequence number.
        
        Args:
            lineage_root_id: The original ancestor workflow ID
            limit: Maximum results
            
        Returns:
            ServiceResult with list of WorkflowLineage records, ordered by sequence
        """
        try:
            tenant_id = self.request_context.authenticated_tenant_id
            user_id = self.request_context.authenticated_user_id

            query_model = WorkflowLineage()
            query_model.tenant_id = tenant_id
            query_model.owner_id = user_id
            query_model._lineage_root_id = lineage_root_id

            # Note: skip_security_check=True because the GSI1 PK already
            # includes tenant_id and owner_id, providing tenant isolation.
            # Standard security filtering would incorrectly reject child
            # records whose execution_id differs from the query model's id.
            return self._query_by_index(
                query_model, "gsi1", limit=limit, ascending=True,
                skip_security_check=True,
            )

        except Exception as e:
            logger.exception(f"Error getting workflow chain: {e}")
            return ServiceResult.error_result(
                message=str(e), error_code=ErrorCode.INTERNAL_ERROR
            )

    # =========================================================================
    # Internal Helpers
    # =========================================================================

    def _get_lineage(self, execution_id: str) -> Optional[WorkflowLineage]:
        """
        Internal helper to fetch a lineage record by execution_id.
        
        Args:
            execution_id: Execution ID to look up
            
        Returns:
            WorkflowLineage or None if not found
        """
        return self._get_by_id(execution_id, WorkflowLineage)

    # =========================================================================
    # Abstract Method Implementations (required by DatabaseService)
    # =========================================================================

    def create(self, **kwargs) -> ServiceResult[WorkflowLineage]:
        """Create a lineage record (abstract method implementation)."""
        execution_id = kwargs.get("execution_id")
        parent_workflow_id = kwargs.get("parent_workflow_id")
        metadata = kwargs.get("metadata")

        if parent_workflow_id:
            return self.create_child(
                execution_id=execution_id,
                parent_workflow_id=parent_workflow_id,
                metadata=metadata,
            )
        return self.create_root(execution_id=execution_id, metadata=metadata)

    def get_by_id(self, **kwargs) -> ServiceResult[WorkflowLineage]:
        """Get lineage by execution ID (abstract method implementation)."""
        execution_id = kwargs.get("execution_id") or kwargs.get("id")
        return self.get_lineage(execution_id)

    def update(self, **kwargs) -> ServiceResult[WorkflowLineage]:
        """Update lineage record (abstract method implementation)."""
        return ServiceResult.error_result(
            message="Lineage records are immutable",
            error_code=ErrorCode.VALIDATION_ERROR,
        )

    def delete(self, **kwargs) -> ServiceResult[bool]:
        """Delete lineage record (abstract method implementation)."""
        return ServiceResult.error_result(
            message="Lineage records cannot be deleted",
            error_code=ErrorCode.VALIDATION_ERROR,
        )
