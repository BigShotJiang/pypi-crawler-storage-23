"""
Message serialization utilities for workflow messaging.

Provides type-safe serialization/deserialization for all workflow message types.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Any, Dict, Type, TypeVar
import json
from dataclasses import is_dataclass

from geek_cafe_saas_sdk.utilities.sqs_helpers import parse_sqs_message_body

T = TypeVar('T')


class MessageSerializer:
    """
    Centralized serialization for workflow messages.
    
    Handles conversion between dataclass models and JSON for SQS messages.
    """
    
    @staticmethod
    def serialize(message: Any) -> str:
        """
        Serialize a message dataclass to JSON string.
        
        Args:
            message: Dataclass instance to serialize
            
        Returns:
            JSON string for SQS message body
            
        Raises:
            ValueError: If message is not a dataclass or lacks to_dict()
        """
        if not is_dataclass(message):
            raise ValueError(f"Expected dataclass, got {type(message)}")
        
        if not hasattr(message, 'to_dict'):
            raise ValueError(f"{type(message).__name__} must implement to_dict()")
        
        return json.dumps(message.to_dict(), default=str)
    
    @staticmethod
    def deserialize(data: str | Dict[str, Any], message_class: Type[T]) -> T:
        """
        Deserialize JSON to message dataclass.
        
        Args:
            data: JSON string or dict from SQS message body
            message_class: Target dataclass type
            
        Returns:
            Deserialized message instance
            
        Raises:
            ValueError: If message_class doesn't implement from_dict()
        """
        if isinstance(data, str):
            data = json.loads(data)
        
        if not hasattr(message_class, 'from_dict'):
            raise ValueError(f"{message_class.__name__} must implement from_dict()")
        
        return message_class.from_dict(data)
    
    @staticmethod
    def from_sqs_record(record: Dict[str, Any], message_class: Type[T]) -> T:
        """
        Extract and deserialize message from SQS event record.
        
        Args:
            record: SQS event record
            message_class: Target dataclass type
            
        Returns:
            Deserialized message instance
        """
        body = parse_sqs_message_body(record)
        return MessageSerializer.deserialize(body, message_class)


# Convenience functions for cleaner imports
def serialize_message(message: Any) -> str:
    """
    Serialize message to JSON string.
    
    Args:
        message: Dataclass message instance
        
    Returns:
        JSON string for SQS message body
    """
    return MessageSerializer.serialize(message)


def deserialize_message(data: str | Dict[str, Any], message_class: Type[T]) -> T:
    """
    Deserialize JSON to message dataclass.
    
    Args:
        data: JSON string or dict
        message_class: Target dataclass type
        
    Returns:
        Deserialized message instance
    """
    return MessageSerializer.deserialize(data, message_class)
