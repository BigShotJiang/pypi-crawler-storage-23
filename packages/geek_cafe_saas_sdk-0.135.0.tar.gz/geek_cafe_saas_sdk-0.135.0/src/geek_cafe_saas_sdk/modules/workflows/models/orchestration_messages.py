"""
Orchestration Messages for Workflow Coordination.

These dataclasses define message formats used for workflow orchestration,
including step completion events, orchestration triggers, and step results.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from dataclasses import dataclass, field
from datetime import datetime, UTC
from typing import Any, Dict, List, Optional
from enum import Enum
import json

from geek_cafe_saas_sdk.utilities.sqs_helpers import parse_sqs_message_body


class WaitType(str, Enum):
    """Type of wait condition for the coordinator."""
    STEPS = "steps"                    # Wait for WorkflowStep records
    BATCHES = "batches"                # Wait for BatchRecord records (calculations)
    COUNTER = "counter"                # Wait for CoordinationRecord atomic counters (scalable)
    CHILD_EXECUTIONS = "child_executions"  # Wait for child Execution records (validation)


class CompletionStatus(str, Enum):
    """Status of the completed step."""
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class StepCompletionEvent:
    """
    Event sent when a step completes.
    
    The orchestrator (coordinator) receives this and:
    1. Updates the WorkflowStep record status
    2. Finds dependent steps from the workflow graph
    3. Checks if all dependencies are satisfied
    4. Dispatches ready steps to their queues
    """
    
    # Required fields
    execution_id: str
    step_id: str
    step_type: str
    tenant_id: str
    user_id: str
    
    # Status
    status: CompletionStatus = CompletionStatus.COMPLETED
    
    # Wait type (STEPS default, BATCHES/COUNTER for calculations)
    wait_type: WaitType = WaitType.STEPS
    
    # Coordination metadata (for COUNTER wait type)
    # Must contain 'step_type' key indicating which step is being coordinated
    coordination_metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Output/Error
    output_payload: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None
    error_code: Optional[str] = None
    
    # Polling state (for BATCHES wait type)
    poll_count: int = 0
    max_poll_count: int = 120
    
    # Timestamp
    completed_utc: Optional[str] = None
    
    def __post_init__(self):
        if self.completed_utc is None:
            self.completed_utc = datetime.now(UTC).isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for SQS message body."""
        return {
            "execution_id": self.execution_id,
            "step_id": self.step_id,
            "step_type": self.step_type,
            "tenant_id": self.tenant_id,
            "user_id": self.user_id,
            "status": self.status.value if isinstance(self.status, CompletionStatus) else self.status,
            "wait_type": self.wait_type.value if isinstance(self.wait_type, WaitType) else self.wait_type,
            "coordination_metadata": self.coordination_metadata,
            "output_payload": self.output_payload,
            "error_message": self.error_message,
            "error_code": self.error_code,
            "poll_count": self.poll_count,
            "max_poll_count": self.max_poll_count,
            "completed_utc": self.completed_utc,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StepCompletionEvent":
        """Create from dictionary (SQS message body)."""
        status = data.get("status", CompletionStatus.COMPLETED)
        if isinstance(status, str):
            status = CompletionStatus(status)
        
        wait_type = data.get("wait_type", WaitType.STEPS)
        if isinstance(wait_type, str):
            wait_type = WaitType(wait_type)
        
        # Handle both 'error_message' and 'error' field names
        error_msg = data.get("error_message") or data.get("error")
        
        return cls(
            execution_id=data["execution_id"],
            step_id=data["step_id"],
            step_type=data["step_type"],
            tenant_id=data["tenant_id"],
            user_id=data["user_id"],
            status=status,
            wait_type=wait_type,
            coordination_metadata=data.get("coordination_metadata", {}),
            output_payload=data.get("output_payload", {}),
            error_message=error_msg,
            error_code=data.get("error_code"),
            poll_count=data.get("poll_count", 0),
            max_poll_count=data.get("max_poll_count", 120),
            completed_utc=data.get("completed_utc"),
        )
    
    @classmethod
    def from_sqs_record(cls, record: Dict[str, Any]) -> "StepCompletionEvent":
        """Create from SQS record."""
        body = parse_sqs_message_body(record)
        return cls.from_dict(body)
    
    def to_json(self) -> str:
        """Convert to JSON string for SQS message body."""
        return json.dumps(self.to_dict())
    
    def increment_poll(self) -> "StepCompletionEvent":
        """Return new event with incremented poll count."""
        return StepCompletionEvent(
            execution_id=self.execution_id,
            step_id=self.step_id,
            step_type=self.step_type,
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            status=self.status,
            wait_type=self.wait_type,
            coordination_metadata=self.coordination_metadata,
            output_payload=self.output_payload,
            error_message=self.error_message,
            error_code=self.error_code,
            poll_count=self.poll_count + 1,
            max_poll_count=self.max_poll_count,
            completed_utc=self.completed_utc,
        )
    
    @property
    def is_expired(self) -> bool:
        """Check if polling has exceeded max attempts."""
        return self.poll_count >= self.max_poll_count
    
    @property
    def is_success(self) -> bool:
        """Check if step completed successfully."""
        return self.status == CompletionStatus.COMPLETED
    
    @property
    def is_failure(self) -> bool:
        """Check if step failed."""
        return self.status == CompletionStatus.FAILED


@dataclass
class OrchestrationTriggerMessage:
    """
    Message sent to trigger workflow orchestration.
    
    This is sent from workflow-builder to step-processor to initiate
    workflow execution. It signals the orchestrator to dispatch all
    initial steps (steps with no dependencies).
    
    This message type is distinct from StepCompletionMessage - it's a
    trigger to start the workflow, not a completion notification.
    """
    
    # Identifiers
    execution_id: str
    """Root execution ID to orchestrate."""
    
    tenant_id: str
    """Tenant ID for multi-tenancy."""
    
    user_id: str
    """User who initiated the execution."""
    
    # Message metadata (for consistency with other message types)
    orchestration_trigger: bool = True
    """Flag to identify this as an orchestration trigger message."""
    
    # These fields are included for consistency with StepCompletionMessage
    # so that handlers can handle both message types uniformly
    status: str = "trigger"
    """Status field for compatibility (always 'trigger')."""
    
    step_type: str = "orchestration"
    """Step type for compatibility (always 'orchestration')."""
    
    # Timestamp
    created_utc: Optional[str] = None
    """ISO timestamp when message was created."""
    
    def __post_init__(self):
        """Set defaults after initialization."""
        if self.created_utc is None:
            self.created_utc = datetime.now(UTC).isoformat()
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "OrchestrationTriggerMessage":
        """Create from dictionary."""
        return cls(
            execution_id=data["execution_id"],
            tenant_id=data["tenant_id"],
            user_id=data["user_id"],
            orchestration_trigger=data.get("orchestration_trigger", True),
            status=data.get("status", "trigger"),
            step_type=data.get("step_type", "orchestration"),
            created_utc=data.get("created_utc"),
        )
    
    @classmethod
    def from_sqs_record(cls, record: Dict[str, Any]) -> "OrchestrationTriggerMessage":
        """Create from an SQS event record."""
        body = parse_sqs_message_body(record)
        return cls.from_dict(body)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "orchestration_trigger": self.orchestration_trigger,
            "execution_id": self.execution_id,
            "tenant_id": self.tenant_id,
            "user_id": self.user_id,
            "status": self.status,
            "step_type": self.step_type,
            "created_utc": self.created_utc,
        }
    
    def to_json(self) -> str:
        """Convert to JSON string for SQS message body."""
        return json.dumps(self.to_dict())


@dataclass
class StepResult:
    """
    Standard result from step execution.
    
    This provides a unified result format for all step handlers.
    Step-specific data should be placed in output_payload as a flexible
    dictionary, similar to how StepMessage uses input_payload.
    """
    
    success: bool
    """Whether the step completed successfully."""
    
    error_message: Optional[str] = None
    """Error message if success is False."""
    
    output_files: Optional[List[str]] = None
    """List of output file paths created by the step."""
    
    output_payload: Optional[Dict[str, Any]] = None
    """
    Flexible dictionary for step-specific output data.
    Examples:
    - For profile splitting: {"profile_count": 10, "validation_summary": {...}}
    - For plotting: {"plot_results": [...]}
    - For tables: {"table_results": [...], "generator_info": {...}}
    """
    
    @classmethod
    def success_result(
        cls,
        output_files: Optional[List[str]] = None,
        output_payload: Optional[Dict[str, Any]] = None,
    ) -> "StepResult":
        """Factory method for successful results."""
        return cls(
            success=True,
            output_files=output_files,
            output_payload=output_payload,
        )
    
    @classmethod
    def failure_result(
        cls,
        error_message: str,
        output_payload: Optional[Dict[str, Any]] = None,
    ) -> "StepResult":
        """Factory method for failed results."""
        return cls(
            success=False,
            error_message=error_message,
            output_payload=output_payload,
        )

    @classmethod
    def error_result(
        cls,
        error_message: str,
        output_payload: Optional[Dict[str, Any]] = None,
    ) -> "StepResult":
        """Factory method for error results (alias for failure_result)."""
        return cls(
            success=False,
            error_message=error_message,
            output_payload=output_payload,
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "success": self.success,
        }
        
        if self.error_message:
            result["error_message"] = self.error_message
        if self.output_files:
            result["output_files"] = self.output_files
        if self.output_payload:
            result["output_payload"] = self.output_payload
            
        return result
