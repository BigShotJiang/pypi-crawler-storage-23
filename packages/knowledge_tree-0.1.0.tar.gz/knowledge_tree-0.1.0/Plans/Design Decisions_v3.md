# Knowledge Tree — Design Decisions v3

*Created: 2026-02-22 | Status: Approved (post-discussion)*
*Supersedes: DESIGN_v2.md with 17 additional decisions from design discussion*

---

## Table of Contents

1. [Vision & Principles](#1-vision--principles)
2. [Architecture Overview](#2-architecture-overview)
3. [Two-Tier Registry Model](#3-two-tier-registry-model)
4. [Data Model](#4-data-model)
5. [Hierarchy Semantics](#5-hierarchy-semantics)
6. [Knowledge Materialization](#6-knowledge-materialization)
7. [Contribution Workflow](#7-contribution-workflow)
8. [Promotion & Curation](#8-promotion--curation)
9. [Git Workflow](#9-git-workflow)
10. [Distribution Strategy](#10-distribution-strategy)
11. [CLI Commands](#11-cli-commands)
12. [Agent Integration](#12-agent-integration)
13. [Implementation Status](#13-implementation-status)
14. [Decision Log](#14-decision-log)

---

## 1. Vision & Principles

### What Knowledge Tree Is

Knowledge Tree is a **crowdsourced knowledge management system** for AI agent context. It enables teams to collaboratively build, curate, and distribute knowledge that AI coding agents use to understand codebases, tools, services, and organizational conventions.

- A **git-native** knowledge registry that anyone can contribute to
- A **CLI tool** (`kt`) distributed via **pip** for consuming and contributing knowledge
- A **two-tier system** with zero-friction contribution and curated promotion
- A **composable** system where users select which knowledge they need

### What It Is NOT

- Not a wiki (humans rarely read it — AI agents consume it)
- Not a SaaS platform (no server, no database, no hosting)
- Not LegacyTool v2 (independent tool, no migration, no coupling)
- Not necessarily hierarchical (flat collections are fine too)

### Core Principle

> **Knowledge should be easy to contribute, controlled to accept, and effortless to consume.**

### Design Philosophy

1. **Zero friction to contribute** — Users dump knowledge into the community pool without worrying about placement, naming, or structure
2. **Curated to promote** — An LLM-powered process (run by a maintainer) decides where knowledge belongs in the main registry
3. **Selective to consume** — Users pick packages from the registry; only `depends_on` is auto-included
4. **Git-native** — Everything is standard git operations; no proprietary protocols or services
5. **Provider-agnostic** — Works with GitLab, GitHub, Bitbucket, or any git host

---

## 2. Architecture Overview

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                    KNOWLEDGE TREE SYSTEM                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────┐         ┌──────────────────────────┐  │
│  │  Registry Repo   │         │  User's Project          │  │
│  │  (Any Git Host)  │         │                          │  │
│  │                  │  clone  │  .kt/                    │  │
│  │  packages/       │───────► │    kt.yaml (config)      │  │
│  │  community/      │  pull   │    registry_cache/       │  │
│  │  registry.yaml   │ ◄────── │  .knowledge/             │  │
│  │                  │  push   │    base/                  │  │
│  └──────────────────┘         │    acme/             │  │
│           ▲                   │    KNOWLEDGE_MANIFEST.md  │  │
│           │ MR/PR             └──────────────────────────┘  │
│           │                              ▲                   │
│  ┌──────────────────┐         ┌──────────────────────────┐  │
│  │  Contributors    │         │  CLI Tool (kt)           │  │
│  │                  │         │                          │  │
│  │  • Add to        │         │  • kt init               │  │
│  │    community/    │         │  • kt add / remove       │  │
│  │  • Review MRs    │         │  • kt update             │  │
│  │                  │         │  • kt contribute         │  │
│  └──────────────────┘         │  • kt list / search      │  │
│                               │  • kt tree / info        │  │
│  ┌──────────────────┐         │  • kt status / validate  │  │
│  │  Maintainer      │         └──────────────────────────┘  │
│  │  (with LLM)      │                                       │
│  │                  │                                       │
│  │  • Promote       │                                       │
│  │    community →   │                                       │
│  │    packages      │                                       │
│  │  • LLM-assisted  │                                       │
│  │    curation      │                                       │
│  └──────────────────┘                                       │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Two Separate Repos

| Repo | Purpose | Who Uses It | How |
|------|---------|------------|-----|
| **knowledge-tree** | CLI tool source code | Tool developers | `pip install knowledge-tree` |
| **knowledge-tree-registry** | Knowledge content (packages + community) | Everyone | `kt init --from <url>` |

The tool repo is what gets published via pip. The registry repo is what gets cloned when users run `kt init`.

---

## 3. Two-Tier Registry Model

### Overview

The registry has two tiers within a single git repo:

```
knowledge-tree-registry/
├── packages/                     ← MAIN REGISTRY (curated)
│   ├── base/
│   │   ├── package.yaml
│   │   ├── safe-deletion.md
│   │   └── file-management.md
│   ├── git-conventions/
│   │   ├── package.yaml
│   │   └── commit-messages.md
│   └── acme-services/
│       ├── package.yaml
│       ├── authentication.md
│       └── service-access.md
├── community/                    ← COMMUNITY POOL (uncurated)
│   ├── docker-tips/
│   │   ├── package.yaml
│   │   └── docker-debugging.md
│   └── bobs-terraform-notes/
│       ├── package.yaml
│       └── terraform-patterns.md
├── registry.yaml                 ← Auto-generated index
├── CONTRIBUTING.md               ← How to contribute
└── .gitlab-ci.yml                ← CI validation
```

### Main Registry (`packages/`)

- **Curated, structured, quality-gated**
- Organized as a tree (packages can have `parent` relationships)
- Only modified through promotion from community or direct maintainer edits
- All packages have proper metadata, naming, and classification
- Indexed in `registry.yaml`

### Community Pool (`community/`)

- **Uncurated, flat, zero friction**
- Anyone can add content via MR
- Append-only model: users add new nodes or child nodes, never edit existing ones
- Minimal validation: valid `package.yaml`, at least one content file
- Classification is always `seasonal` by default
- Packages can be installed by users (with the understanding they're uncurated)

### Why Same Repo?

- Simplest approach — one clone, one MR workflow
- If it gets too big/dirty, that means good adoption — split later
- Promotion is just moving files within the same repo

### Why Two Tiers?

- **Zero friction contribution** — users never think about placement or naming conventions
- **Quality gate at promotion** — the LLM-powered curation ensures the main registry stays clean
- **No edit conflicts** — append-only community means no merge conflicts
- **Audit trail** — community nodes are marked as "promoted", not deleted

---

## 4. Data Model

### 4.1 Knowledge Package (`package.yaml`)

A knowledge package is the atomic unit — a directory containing markdown files and a `package.yaml` manifest.

```yaml
# package.yaml — Full schema
name: "cloud-aws"                    # Unique identifier (kebab-case, required)
description: "AWS patterns for BE3"  # Human-readable description (required)
authors:                             # Contributors (at least one required)
  - "kbisla"
  - "jdoe"
classification: "evergreen"          # "evergreen" | "seasonal" (required)
                                     # evergreen = stable, recommended
                                     # seasonal = experimental, opt-in

# Relationships (all optional)
parent: "cloud"                      # Organizational parent (for tree browsing)
depends_on:                          # Functional dependencies (auto-included)
  - "auth-basics"
suggests:                            # Recommended companions (informational only)
  - "cloud-gcp"
tags:                                # For search and filtering
  - "cloud"
  - "aws"
audience:                            # Target audience (optional)
  - "backend-engineers"

# Content files (order matters — first file is the overview)
content:
  - aws-overview.md
  - aws-iam-patterns.md
  - aws-deployment.md

# Dates (optional)
created: "2026-01-15"
updated: "2026-02-20"

# Community-only fields
status: "pending"                    # pending | promoted | archived
promoted_to: null                    # set when promoted: target package name
promoted_date: null                  # set when promoted
```

### 4.2 Registry Index (`registry.yaml`)

Auto-generated index of all packages in the main registry. Enables fast lookups without scanning the filesystem.

```yaml
# registry.yaml — Auto-generated by `kt registry rebuild`
packages:
  base:
    description: "Universal agent conventions"
    classification: evergreen
    tags: [conventions, safety, universal]
    path: packages/base

  git-conventions:
    description: "Git commit message format and branching conventions"
    classification: evergreen
    tags: [git, conventions, commits]
    parent: base
    path: packages/git-conventions

  acme-services:
    description: "Acme Corp. internal services"
    classification: evergreen
    tags: [acme, services, enterprise]
    depends_on: [base]
    path: packages/acme-services
```

### 4.3 Project Configuration (`kt.yaml`)

Each project that uses Knowledge Tree has a `kt.yaml` in `.kt/`:

```yaml
# .kt/kt.yaml — Project knowledge configuration
registry: "git@gitlab.example.com:team/kt-registry.git"
registry_ref: "main"

packages:
  - name: base
    ref: "abc123f"                   # Git commit hash (not semver)
  - name: acme-services
    ref: "abc123f"

telemetry:
  enabled: false
  anonymous_id: "a1b2c3d4"
```

### 4.4 Naming Conventions

- **Package names**: kebab-case, lowercase, alphanumeric + hyphens (`cloud-aws`, `acme-services`)
- **Content files**: kebab-case markdown files (`aws-iam-patterns.md`)
- **No semver**: Packages are pinned to git refs (commit hashes), not semantic versions
- **Classification**: `evergreen` (stable, recommended) or `seasonal` (experimental, opt-in)

---

## 5. Hierarchy Semantics

### `parent` vs `depends_on` — The Critical Distinction

These are two fundamentally different relationships:

| Field | Meaning | Purpose | Auto-included on install? |
|-------|---------|---------|--------------------------|
| `parent` | "I'm organized under this category" | Tree browsing, navigation, discovery | **No** |
| `depends_on` | "I require this knowledge to be useful" | Functional dependency | **Yes** |

### Why `parent` Does NOT Auto-Include

The `parent` field is **organizational** — it's how the registry is structured for browsing. It's like a folder structure in a file manager. Three scenarios illustrate why forcing parent inclusion is wrong:

1. **Wasteful**: `cloud-aws-lambda` under `cloud` — an AWS expert doesn't need the generic cloud overview
2. **Wrong**: `python-fastapi` under `languages` — the `languages` node is just an organizational category
3. **Correct via depends_on**: If `auth-okta` truly needs `acme` context, the author declares `depends_on: [acme]`

### Package Author Responsibility

Package authors decide what's truly required:

```yaml
# auth-okta needs LegacyTool context → declare it explicitly
name: auth-okta
parent: auth              # organizational: under auth in the tree
depends_on: [acme]   # functional: needs LegacyTool context

# cloud-aws-lambda is self-contained → no dependencies
name: cloud-aws-lambda
parent: cloud-aws         # organizational: under cloud-aws
depends_on: []            # functional: self-contained
```

### Hierarchy = Scope/Context, Not Override

The tree position tells you the **scope/context** of knowledge, not its priority:

```
base                    → universal knowledge (applies everywhere)
└── acme           → LegacyTool-specific context
    └── auth            → authentication within LegacyTool
        └── auth-okta   → Okta setup within LegacyTool auth
```

`auth-okta` doesn't *override* `auth` — it *adds to it* within a specific context. There could be a completely different Okta package about Okta in general (not LegacyTool-specific):

```
base
├── acme
│   └── auth
│       └── auth-okta        ← Okta at Acme Corp
└── auth-general
    └── okta                 ← Okta in general
```

These are **different knowledge** about the same technology. The tree position tells you "which world" the knowledge belongs to.

### Desirable Tree Shape

Based on realistic growth predictions, the desirable outcome is a **shallow, wide, well-curated registry**:

- **Depth 0**: `base` (1 package — universal)
- **Depth 1**: 8-12 top-level categories (cloud, auth, languages, tools, teams, products)
- **Depth 2**: 30-50 specific packages under those categories
- **Depth 3**: Rare — only for genuinely deep specializations
- **Max depth**: 3 (beyond that, the tree becomes hard to navigate)

---

## 6. Knowledge Materialization

### Where Knowledge Lives on the User's Computer

```
my-project/
├── .kt/                             ← Knowledge Tree metadata
│   ├── kt.yaml                      ← project config (COMMITTED)
│   └── registry_cache/              ← full clone of registry (GITIGNORED)
│       ├── packages/
│       ├── community/
│       └── registry.yaml
├── .knowledge/                      ← materialized knowledge (COMMITTED)
│   ├── base/
│   │   ├── safe-deletion.md
│   │   └── file-management.md
│   ├── acme-services/
│   │   ├── authentication.md
│   │   └── service-access.md
│   └── KNOWLEDGE_MANIFEST.md        ← auto-generated for AI agents
├── src/                             ← actual project code
└── ...
```

### Key Decisions

| Item | Committed? | Rationale |
|------|-----------|-----------|
| `.kt/kt.yaml` | **Yes** | Records which packages are installed, which registry |
| `.kt/registry_cache/` | **No** (gitignored) | Recreated by `kt update`; just a local cache |
| `.knowledge/` | **Yes** | AI agent reads these files directly; must be in repo |
| `.knowledge/KNOWLEDGE_MANIFEST.md` | **Yes** (auto-generated) | Agent's entry point to understand installed knowledge |

### Flat Filesystem + Enhanced Manifest

Knowledge files are materialized **flat** (not nested), with the manifest carrying the tree semantics:

```
.knowledge/
├── base/           ← scope: universal
├── acme/      ← scope: acme
├── auth/           ← scope: acme > auth
├── auth-okta/      ← scope: acme > auth > okta
└── KNOWLEDGE_MANIFEST.md  ← explains scoping and relationships
```

**Why flat?**
- Simple filesystem, no deep nesting
- Easy to reference files
- Moving a package in the tree doesn't change file paths
- Each package is self-contained

**Why manifest?**
- Communicates scope/context to the AI agent
- Shows the tree structure (which packages are related)
- Provides reading guidance (general → specific)
- The agent reads the manifest first, then specific files

### Manifest Format

The `KNOWLEDGE_MANIFEST.md` communicates scope, not override:

```markdown
# Knowledge Manifest

*Auto-generated by Knowledge Tree on 2026-02-22 10:30 UTC*

**Installed packages:** 4
**Registry:** git@gitlab.example.com:team/kt-registry.git

## Installed Knowledge

### Scope: Universal
- 🌲 **base** — Universal agent conventions

### Scope: Acme Corp.
- 🌲 **acme** — Company-wide services and access patterns
  - 🌲 **auth** — LegacyTool authentication patterns
    - 🌲 **auth-okta** — Okta SSO integration for LegacyTool services

## Context Notes
- Knowledge under "Acme Corp." assumes LegacyTool infrastructure
- auth-okta describes Okta as configured at Acme Corp, not generic Okta

## Files
### 🌲 base
- [safe-deletion.md](.knowledge/base/safe-deletion.md) (15 lines)
- [file-management.md](.knowledge/base/file-management.md) (20 lines)

### 🌲 auth-okta
- [okta-setup.md](.knowledge/auth-okta/okta-setup.md) (45 lines)
```

---

## 7. Contribution Workflow

### User Contribution (Zero Friction)

Users contribute to the **community pool only**. They never touch `packages/`.

```bash
# Contribute new knowledge
kt contribute my-notes.md --name "docker-tips"
# → Creates community/docker-tips/ with package.yaml + content
# → Pushes branch, prints MR URL
# → MR gets reviewed (basic validation) and merged

# Add to existing community node (as a child, not an edit)
kt contribute my-additions.md --to docker-tips --name "docker-networking"
# → Creates community/docker-tips/docker-networking/
# → Same branch → push → MR flow
```

### Append-Only Model

The community directory is **append-only**:
- Users **add new nodes** or **add child nodes** under existing ones
- Users **never edit** existing community nodes
- This eliminates merge conflicts and edit wars
- When Bob wants to add to Alice's `docker-tips`, he adds a child node:

```
community/
├── docker-tips/                    ← Alice contributed this
│   ├── package.yaml
│   ├── docker-debugging.md
│   └── docker-networking/          ← Bob added this as a child
│       ├── package.yaml
│       └── docker-networking.md
```

### MR Review (Light Touch)

Community contributions have a low review bar:
- ✅ Valid `package.yaml` (name, description, author)?
- ✅ At least one content file exists?
- ✅ Name doesn't collide with existing packages?
- ✅ No changes to `packages/` (main registry)?

CI automates all checks. The human reviewer just confirms it's not spam/garbage.

---

## 8. Promotion & Curation

### Overview

Promotion moves knowledge from the community pool to the main registry. It is:
- **Maintainer-driven** — not a user operation
- **LLM-assisted** — the maintainer uses their local LLM (VS Code/LegacyTool) to analyze and decide
- **MR-based** — all promotion changes go through a merge request for review

### Promotion Flow

```
COMMUNITY NODE
      │
      ▼
MAINTAINER analyzes (using LLM in VS Code)
      │
      ├──→ 1. MERGE into existing package (most common)
      │       Content absorbed into packages/docker/
      │       Contributor credited in authors list
      │
      ├──→ 2. CREATE new package (less common)
      │       Moved to packages/ with proper placement
      │       Assigned parent, classification, metadata
      │
      ├──→ 3. ARCHIVE (sometimes)
      │       Low quality, duplicate, or too niche
      │       Marked as archived in community/
      │
      └──→ All paths: Community node marked as "promoted"
           (not deleted — preserves audit trail)
```

### Why Merge Is More Common Than Create

Most contributions won't be entirely new topics — they'll be additions to existing knowledge. Someone's "docker-tips" community contribution is probably best merged into the existing `docker` package in the main registry, not promoted as a separate package.

This means the registry grows in **depth** (richer packages) rather than **width** (more packages), which keeps it manageable.

### LLM Curation Details

The LLM is **not in the `kt` CLI**. It lives in the maintainer's local development environment (VS Code with LegacyTool/Claude). The maintainer's workflow:

1. Run `kt list --community` to see pending contributions
2. Open VS Code, use the LLM to analyze:
   - "Look at community/docker-tips. Should this merge into packages/docker or become a new package?"
   - "Generate the file changes needed."
3. LLM generates the changes (file moves, metadata updates)
4. Maintainer reviews, adjusts, commits
5. Run `kt registry rebuild` to update `registry.yaml`
6. Push as MR, review, merge to main

### Why LLM Is External

- Cloud LLM integration is not ready yet
- The maintainer already has LLM access via VS Code
- Keeps the `kt` CLI simple — it handles plumbing, not intelligence
- The LLM can be upgraded independently of the tool

### Community Node Status Tracking

```yaml
# community/docker-tips/package.yaml (after promotion)
name: docker-tips
description: "Docker debugging tips"
authors: [alice]
classification: seasonal
status: promoted              # pending | promoted | archived
promoted_to: docker           # target package in main registry
promoted_date: "2026-03-15"   # when it was promoted
```

---

## 9. Git Workflow

### Contributing (User)

```bash
# 1. User has kt installed and project initialized
cd my-project
kt init --from git@gitlab.example.com:team/kt-registry.git

# 2. User writes some knowledge
vim my-docker-notes.md

# 3. User contributes (goes to community pool)
kt contribute my-docker-notes.md --name "docker-tips"

# Behind the scenes:
# a. Pulls latest registry into .kt/registry_cache/
# b. Creates branch: contribute/docker-tips
# c. Creates community/docker-tips/package.yaml (auto-generated)
# d. Copies my-docker-notes.md → community/docker-tips/docker-tips.md
# e. Commits and pushes branch
# f. Prints MR URL for the user to open in browser
```

### Promoting (Maintainer)

```bash
# 1. Maintainer reviews community contributions
kt list --community

# 2. Uses LLM (in VS Code) to analyze and generate changes
# 3. Makes the changes (file moves, metadata updates)
# 4. Rebuilds registry
kt registry rebuild

# 5. Commits and pushes as MR
# 6. Reviews and merges
```

### Branch Naming Convention

| Operation | Branch Name | Example |
|-----------|------------|---------|
| User contribution | `contribute/<package-name>` | `contribute/docker-tips` |
| Maintainer promotion | `promote/<package-name>` | `promote/docker-tips-to-docker` |
| Registry maintenance | `maint/<description>` | `maint/rebuild-registry` |

### CI Validation

The registry repo should have CI that validates on every MR:

```yaml
# .gitlab-ci.yml
validate:
  script:
    - pip install knowledge-tree
    - kt validate --all              # Check all packages
    - kt registry rebuild --check    # Verify registry is up to date
  rules:
    - if: $CI_MERGE_REQUEST_ID

# Validation checks:
# ✓ package.yaml is valid YAML with required fields
# ✓ All content files referenced in package.yaml exist
# ✓ No circular dependencies
# ✓ Package name is unique and kebab-case
# ✓ No file exceeds 500 lines (warning)
# ✓ No package exceeds 2000 lines total (warning)
# ✓ Community contributions don't touch packages/
```

---

## 10. Distribution Strategy

### Open Source Release

Knowledge Tree is an **open source project** distributed via public PyPI.

### The CLI Tool

The `kt` CLI is a Python package:

```toml
# pyproject.toml
[project]
name = "knowledge-tree"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = ["click>=8.1", "ruamel.yaml>=0.18", "rich>=13.0"]

[project.scripts]
kt = "knowledge_tree.cli:cli"
```

### Installation

```bash
# From PyPI (primary)
pip install knowledge-tree

# From source
pip install git+https://github.com/org/knowledge-tree.git
```

### The Registry Repo

The registry is a separate git repo, not distributed via pip:

```bash
# Users access it via kt init, pointing to any git host
kt init --from git@github.com:org/kt-registry.git
```

---

## 11. CLI Commands

### Phase 1 Commands (Implemented ✅)

| Command | Description | Status |
|---------|-------------|--------|
| `kt init --from <url>` | Initialize project with knowledge registry | ✅ |
| `kt add <package>` | Add a package (+ dependencies) | ✅ |
| `kt remove <package>` | Remove a package | ✅ |
| `kt list` | List installed packages | ✅ |
| `kt list --available` | List all available packages | ✅ |
| `kt search <query>` | Search packages by name/description/tags | ✅ |
| `kt tree` | Show package dependency tree | ✅ |
| `kt update` | Pull latest registry, re-materialize packages | ✅ |
| `kt status` | Show project knowledge status | ✅ |
| `kt info <package>` | Show detailed package information | ✅ |
| `kt validate <path>` | Validate a package directory | ✅ |

### Phase 2 Commands (To Build)

| Command | Description | Priority |
|---------|-------------|----------|
| `kt contribute <file> --name <name>` | Create community contribution + MR | P0 |
| `kt contribute <file> --to <existing>` | Add to existing community node | P0 |
| `kt list --community` | List community pool packages | P0 |
| `kt registry rebuild` | Regenerate registry.yaml from packages/ | P0 |
| `kt validate --all` | Validate all packages in registry | P1 |

### Commands NOT in CLI (By Design)

| Operation | Why Not in CLI | How It's Done |
|-----------|---------------|---------------|
| `kt promote` | Requires LLM intelligence | Maintainer uses VS Code + LLM manually |
| `kt merge` | Complex content merging | Maintainer uses git + LLM manually |
| `kt archive` | Rare, needs judgment | Maintainer edits package.yaml directly |

---

## 12. Agent Integration

### How AI Agents Discover Knowledge

The agent discovers knowledge through a **convention in `agents.md`**:

```markdown
# In the project's agents.md or equivalent
Read `.knowledge/KNOWLEDGE_MANIFEST.md` for project-specific knowledge context.
```

The agent reads the manifest first, which provides:
- List of installed packages with descriptions
- Scope/context information (which world each package belongs to)
- Links to individual knowledge files

### No LegacyTool Integration

Knowledge Tree is **independent of LegacyTool**:
- No migration from LegacyTool profiles
- No coupling between the tools
- They can coexist: LegacyTool for operational config, Knowledge Tree for knowledge content
- But they are not required to work together

### Content Guidelines for AI Consumption

Since the primary consumer is an AI agent, content should be:
- **Precise and actionable** — instructions and patterns, not prose
- **Example-rich** — code snippets, config examples, command sequences
- **Context-aware** — state when something applies and when it doesn't
- **Self-contained** — each file should be useful on its own
- **Concise** — AI context windows are limited; don't waste tokens

### Content Size Limits

- Individual files: **max 500 lines** (soft limit, warning)
- Package total: **max 2000 lines** across all files (soft limit, warning)
- If a package grows too large, split it into sub-packages

---

## 13. Implementation Status

> **Note:** As of 2026-02-22, no source code has been written. The design is complete; implementation starts now.

### Phase 1: Foundation (Designed, Not Yet Built)

| Component | File | Status |
|-----------|------|--------|
| Data models | `src/knowledge_tree/models.py` | 🔲 Not started |
| Core engine | `src/knowledge_tree/engine.py` | 🔲 Not started |
| CLI interface | `src/knowledge_tree/cli.py` | 🔲 Not started |
| Git operations | `src/knowledge_tree/git_ops.py` | 🔲 Not started |
| Tests | `tests/` | 🔲 Not started |
| Sample registry | `workspace/sample-registry/` | 🔲 Not started |
| Package config | `pyproject.toml` | 🔲 Not started |

### Phase 2: Contribution

| Component | Description | Status |
|-----------|-------------|--------|
| `kt contribute` command | Create community contribution + push branch + print MR URL | 🔲 Not started |
| `kt list --community` | List community pool packages | 🔲 Not started |
| `kt registry rebuild` | Regenerate registry.yaml from packages/ | 🔲 Not started |
| `kt validate --all` | Validate all packages in registry | 🔲 Not started |
| CI templates | GitHub Actions for validation | 🔲 Not started |
| CONTRIBUTING.md | Template for contributors | 🔲 Not started |
| Community directory | Add `community/` to sample registry | 🔲 Not started |
| Status tracking | Add `status`, `promoted_to`, `promoted_date` to models | 🔲 Not started |

### Phase 2 Implementation Notes

Key changes needed in existing code:

1. **`models.py`**: Add `status`, `promoted_to`, `promoted_date` fields to `PackageMetadata`
2. **`engine.py`**: Add `contribute()` method, `list_community()`, `registry_rebuild()`
3. **`cli.py`**: Add `contribute`, `list --community` commands
4. **`git_ops.py`**: Already has `create_branch()`, `push_branch()`, `get_mr_url()` — ready for contribute
5. **Registry**: Add `community/` directory to sample registry structure

---

## 14. Decision Log

All design decisions made during the Phase 2 discussion, in chronological order:

| # | Decision | Choice | Rationale |
|---|----------|--------|-----------|
| 1 | **Name** | Knowledge Tree / `kt` | Tree metaphor works for registry organization; `kt` is short and memorable |
| 2 | **Filesystem** | Flat `.knowledge/` + enhanced manifest | Manifest carries scope/context; files stay flat and simple |
| 3 | **`parent` vs `depends_on`** | `parent` = organizational, `depends_on` = functional | Parent for browsing only; depends_on for auto-inclusion |
| 4 | **Registry model** | Two-tier: Main Registry + Community Pool | Zero friction to contribute, curated to promote |
| 5 | **Storage** | Same repo, two directories (`packages/` + `community/`) | Simple; split later if adoption warrants it |
| 6 | **Community model** | Append-only (no edits, add children) | No merge conflicts, audit trail preserved |
| 7 | **Promotion** | LLM-powered, maintainer-driven, via MR | LLM decides merge vs create; human reviews |
| 8 | **LLM location** | External (VS Code/LegacyTool), not in CLI | Cloud LLM not ready; keeps CLI simple |
| 9 | **Curation** | Automated CI + LLM + manual review | CI validates structure; LLM suggests placement; human confirms |
| 10 | **Hierarchy semantics** | Scope/context, not override | Tree position = "which world"; not CSS-style specificity |
| 11 | **Distribution** | Open source, public PyPI | `pip install knowledge-tree` from day one |
| 12 | **LegacyTool integration** | None — independent tool | No migration, no coupling; can coexist but not required |
| 13 | **Buy-in** | Grassroots | Build value first; adoption follows |
| 14 | **Community installable** | Yes, marked as seasonal | Users accept risk of uncurated content |
| 15 | **Agent discovery** | Convention in agents.md | "Read `.knowledge/KNOWLEDGE_MANIFEST.md`" |
| 16 | **Desirable tree shape** | Shallow (max depth 3), wide, curated | Most packages at depth 1-2; depth 3 is rare |
| 17 | **Promotion outcomes** | Merge (common), Create (less common), Archive | Most contributions enrich existing packages |
| 18 | **Implementation status** | No existing code — building from scratch | Phase 1 was fully designed but never implemented |
| 19 | **License** | MIT | Simplest permissive license |
| 20 | **Sample packages** | Generic (not company-specific) | Open source needs universal examples |
| 21 | **GitHub** | `kBisla9/knowledge-tree` (private initially) | Ship privately first, open source when ready |

---

*Updated 2026-02-22. This document captures 21 design decisions. It supersedes DESIGN_v2.md for architectural guidance.*
