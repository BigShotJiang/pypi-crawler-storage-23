# Knowledge Tree v2 — Architecture Design

*Created: 2026-02-22 | Status: Draft*

---

## 1. Vision

**Knowledge Tree** is a **crowdsourced knowledge management system** for AI agent context. It enables teams to collaboratively build, curate, and distribute knowledge that AI coding agents use to understand codebases, tools, services, and organizational conventions.

### What It Is

- A **git-native** knowledge repository that anyone can contribute to
- A **CLI tool** (`kt`) distributed via **pip** for consuming and contributing knowledge
- A **controlled growth** system where contributions are reviewed before acceptance
- A **composable** system where users select which knowledge they need

### What It Is NOT

- Not a wiki (humans rarely read it — AI agents consume it)
- Not a SaaS platform (no server, no database, no hosting)
- Not LegacyTool v2 (fresh design, different philosophy)
- Not necessarily hierarchical (flat collections are fine too)

### Core Principle

> **Knowledge should be easy to contribute, controlled to accept, and effortless to consume.**

---

## 2. Key Insight: Rethinking the Hierarchy

The original design centered on a strict tree hierarchy. After reflection, the hierarchy is a **useful organizational tool** but not the core value proposition. The core value is:

1. **Crowdsourced growth** — Many people contribute knowledge
2. **Controlled acceptance** — Contributions are reviewed (like code PRs)
3. **Selective consumption** — Users pick what they need
4. **Composability** — Knowledge units can be mixed and matched

The hierarchy helps with #3 and #4 (organizing and selecting), but it shouldn't constrain #1 and #2.

### Revised Model: Knowledge Packages

Instead of rigid tree nodes, we use **knowledge packages** — self-contained units of knowledge that can optionally declare relationships:

```yaml
# package.yaml — metadata for a knowledge package
name: "cloud-aws"
description: "AWS service patterns, authentication, and deployment guides"
version: "1.2.0"
authors: ["kbisla", "jdoe"]
tags: ["cloud", "aws", "infrastructure"]
classification: "evergreen"        # or "seasonal"

# Optional hierarchy (not required)
parent: "cloud"                    # belongs under the "cloud" package
depends_on: ["auth-basics"]        # requires knowledge from another package

# Content files
content:
  - aws-setup.md
  - aws-iam-patterns.md
  - aws-deployment.md
```

This is more like **pip packages** or **npm modules** than a rigid tree. Packages CAN form a tree (via `parent`), but they can also be flat, or form a graph (via `depends_on`).

---

## 3. Architecture

### 3.1 The Big Picture

```
┌─────────────────────────────────────────────────────────────┐
│                    KNOWLEDGE TREE SYSTEM                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────┐         ┌──────────────────────────┐  │
│  │  Central Repo    │         │  Local Project           │  │
│  │  (Any Git Host)  │         │  (.kt/ directory)        │  │
│  │                  │  clone  │                           │  │
│  │  • packages/     │───────► │  • Selected packages     │  │
│  │  • registry.yaml │  pull   │  • kt.yaml (selections)  │  │
│  │  • CONTRIBUTING  │ ◄────── │  • Local overrides       │  │
│  │                  │  push   │                           │  │
│  └──────────────────┘         └──────────────────────────┘  │
│           ▲                              ▲                   │
│           │ MR/PR                        │                   │
│           │                              │                   │
│  ┌──────────────────┐         ┌──────────────────────────┐  │
│  │  Contributors    │         │  CLI Tool (kt)           │  │
│  │                  │         │                           │  │
│  │  • Add packages  │         │  • kt init               │  │
│  │  • Update content│         │  • kt add <package>      │  │
│  │  • Review MRs    │         │  • kt update             │  │
│  │                  │         │  • kt contribute          │  │
│  └──────────────────┘         │  • kt list               │  │
│                               │  • kt search             │  │
│                               │  • kt status             │  │
│                               └──────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Components

#### Component 1: Central Repository (Any Git Host)

A single git repository that serves as the **source of truth** for all knowledge packages. This can be hosted on GitLab, GitHub, Bitbucket, or any git server.

**Repository structure:**

```
knowledge-tree-registry/
├── registry.yaml              # Package index (auto-generated)
├── CONTRIBUTING.md            # How to contribute
├── packages/
│   ├── base/
│   │   ├── package.yaml       # Package metadata
│   │   ├── safe-deletion.md   # Knowledge content
│   │   ├── git-conventions.md
│   │   └── ...
│   ├── cloud/
│   │   ├── package.yaml
│   │   ├── cloud-overview.md
│   │   └── ...
│   ├── cloud-aws/
│   │   ├── package.yaml       # parent: cloud
│   │   ├── aws-setup.md
│   │   └── ...
│   ├── python-be3/
│   │   ├── package.yaml
│   │   ├── coding-rules.md
│   │   ├── pyxdr-guide.md
│   │   └── ...
│   └── ...
└── .kt/
    ├── hooks/                 # Git hooks for validation
    └── templates/             # Templates for new packages
```

**Why a single repo?**
- Simple to clone, search, and browse
- Single MR/PR workflow for all contributions
- Easy to set up CI/CD for validation
- Works with any git host
- No package registry infrastructure needed

**Why not multiple repos?**
- Adds complexity without clear benefit at this scale
- Cross-package references become harder
- Discovery requires a separate registry service

#### Component 2: CLI Tool (`kt`)

A Python CLI tool distributed via **pip**. This is the primary interface for users.

```bash
pip install knowledge-tree    # or: pip install kt
```

**Commands:**

```bash
# Setup
kt init                       # Initialize a project with knowledge
kt init --from <url>          # Use a specific knowledge registry

# Consuming knowledge
kt add <package>              # Add a package to your project
kt add cloud-aws              # Example: add AWS knowledge
kt add cloud-aws --depth 1    # Only top-level content (no sub-packages)
kt remove <package>           # Remove a package
kt update                     # Pull latest changes from registry
kt list                       # List installed packages
kt list --available           # List all available packages
kt search <query>             # Search across all packages

# Contributing knowledge
kt contribute <path>          # Package local knowledge for contribution
kt contribute --to <package>  # Add content to an existing package
kt validate                   # Validate package structure

# Info
kt status                     # Show project knowledge status
kt tree                       # Show package dependency tree
kt info <package>             # Show package details

# Telemetry (opt-in)
kt telemetry --enable         # Enable anonymous usage reporting
kt telemetry --disable        # Disable telemetry
kt telemetry --status         # Show telemetry status
```

#### Component 3: Local Project Integration

When a user runs `kt init` or `kt add`, knowledge is materialized into the project:

```
my-project/
├── .kt/
│   ├── kt.yaml               # Project knowledge configuration
│   ├── registry.lock          # Pinned versions (like package-lock.json)
│   └── packages/              # Cached package metadata
├── .knowledge/                # Materialized knowledge (gitignored or committed)
│   ├── base/
│   │   ├── safe-deletion.md
│   │   └── git-conventions.md
│   ├── cloud-aws/
│   │   ├── aws-setup.md
│   │   └── aws-iam-patterns.md
│   └── ...
└── ... (rest of project)
```

**Key design decision:** Should `.knowledge/` be gitignored or committed?

| Option | Pros | Cons |
|--------|------|------|
| **Gitignored** (like `node_modules/`) | Smaller repo, always fresh on `kt update` | Requires `kt` installed to work, not portable |
| **Committed** (like vendored deps) | Portable, works without `kt`, visible in code review | Larger repo, can drift from registry |

**Recommendation:** Default to **committed** (like LegacyTool's copy-on-init model). Knowledge is small (markdown files), and portability matters for AI agent context. The agent needs to read these files directly — they must be present in the repo.

---

## 4. Data Model

### 4.1 Knowledge Package

A knowledge package is the atomic unit. It's a directory containing markdown files and a `package.yaml` manifest.

```yaml
# package.yaml — Full schema
name: "cloud-aws"                    # Unique identifier (kebab-case)
description: "AWS patterns for BE3"  # Human-readable description
version: "1.2.0"                     # Semver
authors:                             # Contributors
  - "kbisla"
  - "jdoe"
created: "2026-01-15"               # Creation date
updated: "2026-02-20"               # Last update date

# Classification
classification: "evergreen"          # "evergreen" | "seasonal"
                                     # evergreen = stable, recommended by default
                                     # seasonal = experimental, opt-in

# Relationships (all optional)
parent: "cloud"                      # Organizational parent
depends_on:                          # Required knowledge
  - "auth-basics"
suggests:                            # Recommended companions
  - "cloud-gcp"
  - "cloud-azure"

# Tags for search and filtering
tags:
  - "cloud"
  - "aws"
  - "infrastructure"
  - "deployment"

# Target audience (optional, for filtering)
audience:
  - "backend-engineers"
  - "devops"

# Content files (order matters — first file is the overview)
content:
  - aws-overview.md                  # Always start with overview
  - aws-iam-patterns.md
  - aws-deployment.md
  - aws-troubleshooting.md
```

### 4.2 Registry Index

The `registry.yaml` at the repo root is an auto-generated index of all packages. It enables fast lookups without scanning the filesystem.

```yaml
# registry.yaml — Auto-generated by CI or `kt registry rebuild`
version: "2026-02-22"
packages:
  base:
    description: "Universal agent conventions"
    classification: evergreen
    tags: [conventions, git, safety]
    parent: null
    version: "1.0.0"
    path: packages/base

  cloud:
    description: "Cloud infrastructure overview"
    classification: evergreen
    tags: [cloud, infrastructure]
    parent: base
    version: "1.1.0"
    path: packages/cloud

  cloud-aws:
    description: "AWS patterns for BE3"
    classification: evergreen
    tags: [cloud, aws, infrastructure]
    parent: cloud
    depends_on: [auth-basics]
    version: "1.2.0"
    path: packages/cloud-aws

  # ... more packages
```

### 4.3 Project Configuration

Each project that uses Knowledge Tree has a `kt.yaml`:

```yaml
# .kt/kt.yaml — Project knowledge configuration
registry: "git@gitlab.example.com:team/knowledge-tree-registry.git"
registry_ref: "main"                 # Branch/tag to track

# Selected packages
packages:
  - name: base
    version: "1.0.0"                # Pinned version
    depth: -1                        # -1 = all content, N = top N files only
  - name: cloud-aws
    version: "1.2.0"
    depth: 2
  - name: python-be3
    version: "2.0.0"
    depth: -1

# Local overrides (optional)
overrides:
  base:
    exclude:
      - "git-conventions.md"         # Don't need this one
  cloud-aws:
    extra:
      - "local/aws-custom-setup.md"  # Add project-specific knowledge

# Telemetry
telemetry:
  enabled: true
  anonymous_id: "a1b2c3d4"          # Random ID, no PII
```

---

## 5. Knowledge Content Format

### 5.1 Markdown with YAML Frontmatter

Each knowledge file is markdown with optional YAML frontmatter for metadata:

```markdown
---
title: "AWS IAM Patterns"
summary: "Common IAM patterns for service accounts and cross-account access"
updated: "2026-02-15"
author: "kbisla"
tags: ["aws", "iam", "security"]
---

# AWS IAM Patterns

## Service Account Setup

When creating service accounts for BE3 microservices...

## Cross-Account Access

For accessing resources in the shared-services account...
```

### 5.2 Content Guidelines

Since the primary consumer is an AI agent, content should be:

- **Precise and actionable** — Not prose, but instructions and patterns
- **Example-rich** — Code snippets, config examples, command sequences
- **Context-aware** — State when something applies and when it doesn't
- **Self-contained** — Each file should be useful on its own
- **Concise** — AI context windows are limited; don't waste tokens

### 5.3 Content Size Limits

To keep packages manageable:
- Individual files: **max 500 lines** (soft limit)
- Package total: **max 2000 lines** across all files (soft limit)
- If a package grows too large, split it into sub-packages

---

## 6. Contribution Workflow

### 6.1 How Knowledge Gets Added

```
Developer has useful knowledge
         │
         ▼
┌─────────────────────┐
│  kt contribute      │  CLI packages it into a proper
│  --to cloud-aws     │  knowledge package format
│  my-notes.md        │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Fork/Branch +      │  Standard git workflow
│  Merge Request      │  (works with any git host)
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Review             │  Maintainers review:
│  • Content quality  │  - Is it accurate?
│  • Classification   │  - Evergreen or seasonal?
│  • Placement        │  - Right package?
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Merge + Registry   │  CI auto-updates registry.yaml
│  Update             │  Consumers get it on next `kt update`
└─────────────────────┘
```

### 6.2 Contribution Types

| Type | Command | What Happens |
|------|---------|-------------|
| **Add to existing package** | `kt contribute --to cloud-aws my-notes.md` | Creates MR adding content to existing package |
| **Create new package** | `kt contribute --new my-package/ ` | Creates MR with new package directory |
| **Update existing content** | `kt contribute --update cloud-aws/aws-setup.md` | Creates MR updating specific file |
| **Promote seasonal → evergreen** | `kt promote cloud-experimental` | Creates MR changing classification |

### 6.3 Quality Gates (CI/CD)

The central repo should have CI that validates contributions:

```yaml
# .gitlab-ci.yml or .github/workflows/validate.yml
validate:
  script:
    - kt validate --all              # Check all packages
    - kt registry rebuild --check    # Verify registry is up to date
  rules:
    - if: $CI_MERGE_REQUEST_ID       # Run on MRs only

# Validation checks:
# ✓ package.yaml is valid YAML with required fields
# ✓ All content files referenced in package.yaml exist
# ✓ No circular dependencies
# ✓ Package name is unique and kebab-case
# ✓ Content files have frontmatter
# ✓ No file exceeds 500 lines (warning)
# ✓ No package exceeds 2000 lines total (warning)
```

---

## 7. Telemetry Design

### 7.1 Philosophy

- **Non-intrusive**: Opt-in, anonymous, minimal data
- **No server required**: Telemetry data stored locally, aggregated via git
- **Transparent**: Users can see exactly what's collected

### 7.2 What We Collect

Only two metrics (as specified):

1. **User count** — How many unique users have `kt` installed and active
2. **Usage frequency** — How often `kt` commands are run

### 7.3 Implementation: Git-Based Telemetry

Since we can't justify a server, telemetry uses the git repo itself:

**Option A: Telemetry Branch**

A special branch in the central repo (`telemetry`) where the CLI pushes anonymous usage data:

```
telemetry branch:
└── usage/
    ├── 2026-02/
    │   ├── a1b2c3d4.yaml    # Anonymous user ID
    │   ├── e5f6g7h8.yaml
    │   └── ...
    └── 2026-03/
        └── ...
```

Each file:
```yaml
# usage/2026-02/a1b2c3d4.yaml
anonymous_id: "a1b2c3d4"
period: "2026-02"
commands:
  init: 2
  add: 5
  update: 12
  search: 8
  contribute: 1
packages_installed: 7
last_active: "2026-02-20"
```

**Aggregation:** A simple script (or CI job) reads all files and produces a summary:

```yaml
# telemetry-summary.yaml (auto-generated)
period: "2026-02"
unique_users: 47
total_commands: 1,234
most_used_commands: [update, search, add]
most_installed_packages: [base, cloud-aws, python-be3]
adoption_trend: [12, 18, 25, 33, 47]  # users per week
```

**Option B: Anonymous Ping File**

Even simpler — each `kt update` appends a line to a shared file:

```
# telemetry.log (append-only)
2026-02-20T10:30:00Z|a1b2c3d4|update|7_packages
2026-02-20T11:15:00Z|e5f6g7h8|add|cloud-aws
```

This has git merge conflict issues at scale, so Option A (per-user files) is better.

**Option C: No Git Telemetry — Local Only**

Store usage data locally in `~/.kt/telemetry.yaml`. Periodically, a maintainer can ask users to share their stats voluntarily. Simplest, but least useful for tracking adoption.

**Recommendation:** Start with **Option C** (local-only) for v1. Add **Option A** (telemetry branch) in v2 if adoption tracking becomes important enough to justify the complexity.

---

## 8. Technology Decisions

### 8.1 CLI Tool: Python + Click

| Decision | Choice | Rationale |
|----------|--------|-----------|
| **Language** | Python 3.10+ | Already standard at Acme Corp, pip distribution, rich ecosystem |
| **CLI framework** | Click | Battle-tested, composable, auto-generates help |
| **Git operations** | GitPython or subprocess | GitPython for complex ops, subprocess for simple ones |
| **YAML parsing** | PyYAML or ruamel.yaml | ruamel.yaml preserves comments and formatting |
| **Search** | Simple text search (whoosh or built-in) | No external dependencies needed |
| **Packaging** | setuptools + pyproject.toml | Standard Python packaging |
| **Distribution** | PyPI (public) or internal pip index | pip install knowledge-tree |

### 8.2 Why Python Over Go?

Go would give us a single binary (easier distribution), but:
- Python is the lingua franca at Acme Corp engineering
- pip distribution is simpler than managing binary releases
- The tool doesn't need Go's performance characteristics
- Contributors are more likely to submit PRs in Python
- Rich library ecosystem for YAML, markdown, git operations

### 8.3 Git Provider Abstraction

The CLI must work with any git host. This means:

```python
# Abstract git operations — no provider-specific API calls
class KnowledgeRegistry:
    """All operations use standard git — no GitLab/GitHub API needed."""

    def clone(self, url: str, ref: str = "main"):
        """Clone the registry repo."""
        # Uses: git clone <url>

    def pull(self):
        """Pull latest from registry."""
        # Uses: git pull

    def create_branch(self, name: str):
        """Create a contribution branch."""
        # Uses: git checkout -b <name>

    def push_branch(self, name: str):
        """Push contribution branch."""
        # Uses: git push origin <name>
        # User then creates MR/PR manually via web UI
```

The only provider-specific step is creating the MR/PR, which the user does manually via the web UI. The CLI can print a helpful URL:

```
✓ Branch 'contribute/cloud-aws-update' pushed to origin.

Create a merge request:
  GitLab: https://gitlab.example.com/team/kt-registry/-/merge_requests/new?source_branch=contribute/cloud-aws-update
  GitHub: https://github.com/team/kt-registry/compare/contribute/cloud-aws-update
```

---

## 9. Distribution Strategy

### 9.1 The CLI Tool

```bash
# Install from PyPI (or internal index)
pip install knowledge-tree

# Or from git directly
pip install git+https://gitlab.example.com/team/knowledge-tree.git

# Verify installation
kt --version
kt --help
```

### 9.2 The Knowledge Registry

The registry is just a git repo. Teams set it up once:

```bash
# Create the registry repo on your git host
# Then initialize it:
kt registry init https://gitlab.example.com/team/kt-registry.git

# This creates the standard structure:
# packages/, registry.yaml, CONTRIBUTING.md, CI config
```

### 9.3 Onboarding Flow

For a new user joining the organization:

```bash
# 1. Install the tool
pip install knowledge-tree

# 2. Initialize their project
cd my-project
kt init --from git@gitlab.example.com:team/kt-registry.git

# 3. Interactive selection
kt init
> Fetching registry from git@gitlab.example.com:team/kt-registry.git...
> Found 42 packages (38 evergreen, 4 seasonal)
>
> Select packages to install:
>   [x] base (Universal conventions) — evergreen
>   [x] acme (Company-wide services) — evergreen
>   [ ] cloud-aws (AWS patterns) — evergreen
>   [ ] cloud-gcp (GCP patterns) — evergreen
>   [x] python-be3 (BE3 coding rules) — evergreen
>   [ ] terraform (Terraform patterns) — seasonal
>   ...
>
> Install 3 packages? [Y/n] y
> ✓ Installed 3 packages (12 knowledge files, 847 lines)
```

### 9.4 Backstage Integration (Future)

Since Acme Corp. uses Backstage, a future Backstage plugin could:
- Show the knowledge tree in the Backstage catalog
- Let users browse and select packages via web UI
- Display telemetry dashboards
- Integrate with TechDocs for rendering knowledge content

This is a **v2+ feature** — not needed for initial launch.

---

## 10. Comparison: Knowledge Tree vs LegacyTool

| Aspect | LegacyTool (Current) | Knowledge Tree (Proposed) |
|--------|---------------|--------------------------|
| **Storage** | Local filesystem (`~/.agent-project-profiles/`) | Git repo (any host) |
| **Sharing** | Not shareable (single machine) | Shared via git clone/pull |
| **Collaboration** | Single user | Multi-user via MR/PR workflow |
| **Distribution** | Bash scripts, manual PATH setup | pip install |
| **Discovery** | Must know profile names | Search, tags, browse |
| **Structure** | Rigid tree (parent required) | Flexible (tree optional, flat OK) |
| **Classification** | None | Evergreen vs seasonal |
| **Telemetry** | None | Opt-in anonymous usage tracking |
| **Content format** | Mixed (rules, tools, services, knowledge) | Knowledge only (markdown) |
| **Versioning** | Git on profile store | Semver per package |
| **Updates** | `legacytool update` (diff-based) | `kt update` (version-based) |
| **Contribution** | `legacytool promote` (local only) | `kt contribute` (creates MR/PR) |
| **Validation** | None | CI/CD quality gates |
| **Git provider** | N/A (local) | Any (GitLab, GitHub, Bitbucket) |

---

## 11. Phased Roadmap

### Phase 1: Foundation (Weeks 1-2)
**Goal:** Working CLI that can consume knowledge from a git registry.

| Deliverable | Description | Priority |
|-------------|-------------|----------|
| Package schema | `package.yaml` spec and validation | P0 |
| Registry structure | Repo layout, `registry.yaml` format | P0 |
| `kt init` | Initialize project from registry | P0 |
| `kt add` / `kt remove` | Add/remove packages | P0 |
| `kt list` | List installed and available packages | P0 |
| `kt update` | Pull latest from registry | P0 |
| `kt status` | Show project knowledge status | P1 |
| pip packaging | `pyproject.toml`, installable via pip | P0 |

### Phase 2: Contribution (Weeks 3-4)
**Goal:** Enable crowdsourced knowledge growth.

| Deliverable | Description | Priority |
|-------------|-------------|----------|
| `kt contribute` | Package and push contributions | P0 |
| `kt validate` | Validate package structure | P0 |
| CI templates | GitLab CI / GitHub Actions for validation | P1 |
| `kt registry rebuild` | Regenerate registry.yaml | P0 |
| CONTRIBUTING.md template | Guide for contributors | P1 |

### Phase 3: Discovery & Polish (Weeks 5-6)
**Goal:** Make it easy to find the right knowledge.

| Deliverable | Description | Priority |
|-------------|-------------|----------|
| `kt search` | Full-text search across packages | P0 |
| `kt tree` | Visual tree of package relationships | P1 |
| `kt info` | Detailed package information | P1 |
| Depth selection | `--depth N` flag for selective install | P1 |
| Evergreen/seasonal filtering | Default to evergreen, opt-in seasonal | P0 |

### Phase 4: Telemetry & Adoption (Weeks 7-8)
**Goal:** Track and demonstrate adoption.

| Deliverable | Description | Priority |
|-------------|-------------|----------|
| Local telemetry | Track usage in `~/.kt/telemetry.yaml` | P1 |
| `kt telemetry` | View and manage telemetry settings | P1 |
| Adoption report script | Aggregate telemetry for reporting | P2 |
| Seed content | Migrate key LegacyTool knowledge to packages | P0 |

---

## 12. Success Metrics

| Metric | Target (3 months) | Target (6 months) |
|--------|-------------------|-------------------|
| **Users** | 10 active users | 50 active users |
| **Packages** | 15 knowledge packages | 40 knowledge packages |
| **Contributions** | 5 MRs from non-maintainers | 20 MRs from non-maintainers |
| **Projects** | 5 projects using `kt` | 20 projects using `kt` |
| **Update frequency** | Weekly `kt update` by 50% of users | Weekly `kt update` by 70% of users |

---

## 13. Open Design Decisions

These can be decided during implementation:

| Decision | Options | Leaning Toward |
|----------|---------|---------------|
| Package naming | kebab-case vs dot-notation (`cloud.aws`) | kebab-case (simpler) |
| Version pinning | Exact pin vs range (`^1.0.0`) | Exact pin (predictable) |
| Content materialization | Copy files vs symlinks | Copy files (portable) |
| Registry format | YAML vs TOML vs JSON | YAML (human-readable) |
| Dependency resolution | Flat vs nested | Flat (like pip, not npm) |
| Default branch | `main` vs configurable | Configurable, default `main` |
| `.knowledge/` location | Root vs `.kt/knowledge/` | Root `.knowledge/` (visible) |

---

## 14. What This Document Does NOT Cover (Future Work)

- **Web UI** — Progressive reveal browser, package explorer
- **Backstage plugin** — Integration with internal developer portal
- **AI-powered search** — Semantic search across knowledge
- **Automatic knowledge extraction** — Mining knowledge from Slack, Confluence, etc.
- **Access control** — Fine-grained permissions per package
- **Multi-registry** — Consuming from multiple knowledge registries
- **Knowledge quality scoring** — Automated freshness/relevance scoring

---

*This design is intentionally minimal. Build the simplest thing that works, validate with real users, then iterate.*
