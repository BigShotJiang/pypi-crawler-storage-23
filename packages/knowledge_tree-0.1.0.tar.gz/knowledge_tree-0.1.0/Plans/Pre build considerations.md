# Pre-Build Considerations

*Things to resolve or be aware of before writing code.*

---

## 1. The "Knowledge for AI Agents" Problem is Deeper Than It Looks

The design says "humans rarely read this — AI agents consume it." This has profound implications:

### How do AI agents actually consume knowledge today?

In the current LegacyTool model, knowledge files are **injected into the agent's system prompt** via `agents.md` concatenation. The agent reads them at session start.

But with Knowledge Tree, we need to answer:
- **When** does the agent read the knowledge? At session start? On demand? Continuously?
- **How** does the agent know which knowledge files to read? Does it read everything in `.knowledge/`? Or is there a manifest?
- **What format** is optimal for AI consumption? Raw markdown? Or should we pre-process it (strip headers, compress, summarize)?
- **Context window limits** — If a user installs 20 packages with 100 files, that could be 50,000+ tokens. Most agents can't consume that all at once.

### Recommendation: Define the "Agent Integration Contract"

Before building, we should specify exactly how `kt` output integrates with AI agents. Options:

**Option A: File-based (like LegacyTool)**
- Knowledge files are copied to `.knowledge/` 
- Agent rules reference them: "Read files in `.knowledge/` for context"
- Simple, but doesn't scale (too many files = too many tokens)

**Option B: Manifest-based**
- `kt` generates a single `KNOWLEDGE_MANIFEST.md` that summarizes all installed packages
- Agent reads the manifest first, then reads specific files on demand
- Better for large knowledge bases

**Option C: Agent-aware CLI**
- `kt context` command outputs a single concatenated document optimized for AI consumption
- Respects token budgets: `kt context --max-tokens 10000`
- Can prioritize by relevance to current task

**I'd lean toward Option B + C combined.** The manifest gives the agent an overview, and `kt context` gives a token-budget-aware dump when needed.

---

## 2. The Relationship Between Knowledge Tree and LegacyTool

The design says "not LegacyTool v2" — but in practice, users will have both. We need to think about coexistence:

### Can they coexist?
- LegacyTool manages: rules, modes, tools, commands, services, templates, AND knowledge
- Knowledge Tree manages: knowledge only

So they're complementary, not competing. A project could use LegacyTool for operational config and Knowledge Tree for knowledge content.

### Should Knowledge Tree eventually absorb LegacyTool's knowledge layer?
- LegacyTool's `knowledge/` directory could be replaced by `.knowledge/` from `kt`
- LegacyTool's `promote` command maps to `kt contribute`
- LegacyTool's `update` command maps to `kt update`

### Recommendation
Design Knowledge Tree to be **LegacyTool-compatible** — it should be possible to use `kt` as the knowledge backend for LegacyTool projects. But don't couple them. They should work independently.

---

## 3. The "Any Git" Promise Has Nuances

The design says "works with any git host." But there are practical differences:

### Authentication
- **GitLab**: SSH keys, personal access tokens, deploy tokens
- **GitHub**: SSH keys, personal access tokens, GitHub Apps, fine-grained tokens
- **Bitbucket**: SSH keys, app passwords, OAuth
- **Self-hosted**: Could be anything

`kt` needs to handle auth gracefully. The simplest approach: **delegate to git**. If `git clone <url>` works on the user's machine, `kt` works. No auth logic in `kt` itself.

### MR/PR Creation
The design says users create MRs manually. But we could detect the provider and generate the right URL:

```python
def get_mr_url(remote_url: str, branch: str) -> str:
    if "gitlab" in remote_url:
        return f"{base_url}/-/merge_requests/new?source_branch={branch}"
    elif "github" in remote_url:
        return f"{base_url}/compare/{branch}"
    elif "bitbucket" in remote_url:
        return f"{base_url}/pull-requests/new?source={branch}"
    else:
        return f"Create a merge request for branch '{branch}' on your git host"
```

### CI/CD Templates
We should provide CI templates for the major providers:
- `.gitlab-ci.yml` for GitLab
- `.github/workflows/validate.yml` for GitHub Actions
- `bitbucket-pipelines.yml` for Bitbucket

### Recommendation
Keep the core git-agnostic. Add provider-specific **convenience features** (URL generation, CI templates) as optional extras.

---

## 4. Package Versioning: Do We Really Need Semver?

The design uses semver (`1.2.0`) for packages. But knowledge isn't software:

- Knowledge doesn't have "breaking changes" in the same way
- Knowledge doesn't have "APIs" that consumers depend on
- Knowledge is additive — new content rarely breaks old content

### Alternative: Date-based versioning
```yaml
version: "2026-02-22"  # Last updated date
```

### Alternative: Git-based versioning (no explicit version)
```yaml
# No version field — use git commit hash
# kt.yaml pins to a commit:
packages:
  - name: cloud-aws
    ref: "abc123f"  # Git commit hash
```

### Recommendation
**Use git refs (commit hashes or tags) instead of semver.** This is simpler, more honest (knowledge doesn't have API contracts), and leverages git's built-in versioning. The `registry.yaml` can include a `last_updated` date for human readability.

---

## 5. The "Depth" Concept Needs Clarification

The original design has depth selection (`-1 = all, 1 = top-level, N = N levels`). But in the package model, "depth" is ambiguous:

### What does depth mean for packages?

**Interpretation A: File depth within a package**
- Depth 1 = only the overview file
- Depth 2 = overview + second-level files
- This requires ordering files by importance

**Interpretation B: Package tree depth**
- Depth 1 = only this package, not its children
- Depth 2 = this package + direct child packages
- This requires the `parent` hierarchy

**Interpretation C: Content detail level**
- Depth 1 = summary/overview content
- Depth 2 = detailed content
- This requires content to be structured by detail level

### Recommendation
**Start without depth selection.** It adds complexity and the use case isn't clear yet. Users can simply add/remove individual packages. If depth becomes needed, add it in v2 based on real user feedback.

---

## 6. Naming: "Knowledge Tree" vs Alternatives

"Knowledge Tree" is good but let's consider:

| Name | Pros | Cons |
|------|------|------|
| **Knowledge Tree** (`kt`) | Matches the metaphor, memorable | Implies hierarchy is central |
| **Knowledge Pack** (`kp`) | Emphasizes packages, modular | Less evocative |
| **Context Tree** (`ctx`) | Emphasizes AI context, technical | Less intuitive |
| **Know** (`know`) | Short, verb-like ("know add cloud") | Too generic, hard to search |
| **Dendron** | Already exists | Taken |
| **Grove** (`grove`) | Tree metaphor, collaborative feel | Might be taken |
| **Canopy** (`canopy`) | Tree metaphor, covers everything | Nice but obscure |

### Recommendation
**Stick with "Knowledge Tree" / `kt`**. The name is clear, the CLI is short, and the tree metaphor still applies even if hierarchy is optional (packages can still form a tree).

---

## 7. First Package: What Do We Seed With?

The knowledge tree is only useful if it has content. We need to seed it with initial packages from LegacyTool:

### Candidate seed packages (from existing LegacyTool profiles):

| Package | Source | Classification |
|---------|--------|---------------|
| `base` | LegacyTool base/rules/agents.md | Evergreen |
| `acme-services` | LegacyTool acme/services/ | Evergreen |
| `python-be3` | LegacyTool be3/ | Evergreen |
| `terraform` | LegacyTool terraform/knowledge/ | Seasonal |
| `git-conventions` | LegacyTool base/rules/ | Evergreen |

### Recommendation
Seed with 3-5 packages from LegacyTool on day one. This gives immediate value and demonstrates the system.

---

## 8. Testing Strategy

Before building, decide how to test:

- **Unit tests**: Package validation, registry parsing, YAML handling
- **Integration tests**: Git clone/pull/push operations (need a test repo)
- **End-to-end tests**: Full `kt init` → `kt add` → `kt update` workflow
- **CI**: Run tests on every commit to the `kt` tool repo

### Recommendation
Use **pytest** with fixtures that create temporary git repos. No external dependencies for testing.

---

## 9. Error Handling Philosophy

The CLI needs to handle failures gracefully:

- **No network**: `kt update` should fail gracefully with cached state
- **Invalid package**: `kt add nonexistent` should suggest similar packages
- **Merge conflicts**: `kt update` when local changes conflict with upstream
- **Corrupt state**: `.kt/` directory is damaged or inconsistent

### Recommendation
Follow the **"be helpful on failure"** principle. Every error message should include:
1. What went wrong
2. Why it might have happened
3. What to do about it

---

## 10. The Biggest Risk

The biggest risk is **not getting contributions**. The system is only valuable if people contribute knowledge. To mitigate:

1. **Make contributing trivially easy** — `kt contribute my-notes.md` should be a one-liner
2. **Lower the quality bar initially** — Accept seasonal packages freely, curate later
3. **Lead by example** — Seed with high-quality packages that demonstrate the value
4. **Integrate into existing workflows** — If someone writes a good Slack message or Confluence page, it should be easy to turn it into a knowledge package
5. **Celebrate contributions** — Show contributor stats, acknowledge in team meetings

---

*These considerations should be discussed before writing the first line of code. Some can be deferred (depth selection, telemetry details), but others (agent integration contract, versioning model, seed content) should be decided upfront.*
