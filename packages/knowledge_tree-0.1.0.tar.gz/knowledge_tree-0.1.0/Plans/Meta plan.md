# Knowledge Tree: Plan for a Plan

## Meta-Plan — How to Design This Right

*Created: 2026-02-22 | Status: Draft for Discussion*

---

## 1. What We're Actually Building

Before jumping into architecture, let's be precise about the problem.

### The Core Insight (from the voice memo)

You observed a fundamental difference between **git source code trees** and **knowledge trees**:

| Property | Git Tree | Knowledge Tree |
|----------|----------|----------------|
| **Flow direction** | Knowledge flows UP (merge to parent) | Knowledge flows DOWN (inherit from parent) |
| **Branch lifecycle** | Temporary — branches merge and disappear | Permanent — nodes accumulate forever |
| **Convergence** | Converges to `dev`/`main` | Diverges — tree only grows |
| **Scaling** | Self-limiting (branches merge away) | Unbounded growth (scaling challenge) |

### The Problem Statement

> How do you manage a hierarchical knowledge base that only grows, where knowledge inherits downward, and where 1,000+ nodes need to be navigable by new users without information overload?

### What Acme Corp Proved (and Where It Falls Short)

LegacyTool was a successful prototype that validated:
- ✅ Hierarchical profiles work (base → acme → be3)
- ✅ Inheritance is the right model (child knows everything parent knows)
- ✅ `promote` (pushing knowledge up) is a natural workflow
- ✅ `update` (pulling knowledge down) is opt-in and safe

But LegacyTool has structural limitations:
- ❌ **Local-only** — lives in `~/.agent-project-profiles/`, not shareable
- ❌ **Single-user** — no collaboration, no shared tree
- ❌ **No discovery** — you must know what profiles exist to use them
- ❌ **No progressive reveal** — flat list, no depth control
- ❌ **No core/ephemeral** — all nodes are equal, no classification
- ❌ **No telemetry** — no way to know adoption or usage patterns
- ❌ **Bash scripts** — fragile, hard to extend, no API

---

## 2. Industry Landscape — What Already Exists?

Before designing from scratch, we should understand what's out there. This is the most important research phase.

### 2a. Direct Analogues (Hierarchical Knowledge Systems)

| System | How It Works | Relevance |
|--------|-------------|-----------|
| **Confluence Spaces + Page Trees** | Hierarchical pages, inheritance via space permissions, labels for classification | Similar tree structure, but no downward inheritance of content |
| **Notion Databases + Templates** | Hierarchical pages, templates for reuse, relational databases | Good UX for progressive reveal, but no formal inheritance |
| **Obsidian + Dataview** | Graph-based knowledge, tags, backlinks, community plugins | Graph > tree, but the vault model is interesting |
| **GitBook / Docusaurus** | Versioned docs, hierarchical sidebar, search | Good for static knowledge, no dynamic inheritance |
| **Backstage (Spotify)** | Software catalog with hierarchical ownership, TechDocs, plugins | Closest enterprise analogue — catalog + docs + plugins |
| **Dendron (VS Code)** | Hierarchical note-taking with schema, lookup, refactoring | **Very close** — hierarchical notes with inheritance-like schemas |

### 2b. Conceptual Analogues (Inheritance/Composition Systems)

| System | Pattern | Relevance |
|--------|---------|-----------|
| **CSS Cascade** | Specificity-based inheritance, most specific wins | Exact model for knowledge inheritance |
| **OOP Class Hierarchy** | Parent → child inheritance, override, extend | Direct analogue to profile chains |
| **Terraform Modules** | Composable, parameterized, versioned modules | Good model for reusable knowledge units |
| **Helm Charts + Values** | Base chart + overlay values per environment | Similar to base profile + overrides |
| **Nix/NixOS** | Declarative, composable, reproducible configurations | Interesting for deterministic knowledge assembly |
| **Kubernetes Kustomize** | Base + overlays, hierarchical patching | Very similar to profile inheritance |

### 2c. Enterprise Knowledge Management Platforms

| Platform | Strengths | Weaknesses for Our Use Case |
|----------|-----------|----------------------------|
| **Guru** | Card-based, verification workflows, Slack integration | Not hierarchical, no inheritance |
| **Tettra** | Team wikis, Slack integration, verification | Flat structure |
| **Slite** | Collaborative docs, channels, search | No formal hierarchy |
| **Slab** | Unified search, topics, integrations | No inheritance model |
| **Stack Overflow for Teams** | Q&A format, tags, voting | Not hierarchical |

### 2d. The Gap

**No existing system combines all of:**
1. Hierarchical knowledge with downward inheritance
2. Core vs. ephemeral classification
3. Progressive reveal with depth control
4. Merge request workflow for knowledge changes
5. Non-intrusive telemetry for adoption tracking
6. Enterprise distribution (not just single-user)

This confirms: **we need to build something new**, but we should build it **on top of existing platforms** rather than from scratch.

---

## 3. The Key Design Questions (What the Full Plan Must Answer)

This is the heart of the meta-plan. These are the questions that, if answered well, will lead to a great design.

### Q1: What is the fundamental data model?

- Is a "knowledge node" a file? A database record? A page in a wiki? A git repo?
- What metadata does each node carry? (depth, core/ephemeral, owner, version, tags)
- How is inheritance actually implemented? (copy-on-read? materialized views? lazy resolution?)
- What's the schema for a node? Is it rigid or flexible?

**Why this matters:** The data model determines everything — storage, querying, versioning, collaboration.

### Q2: Where does the knowledge live?

Options spectrum:

```
Local files ←————————————————————————→ Cloud service
(LegacyTool today)                          (SaaS platform)

  Git repo    →  GitLab/GitHub  →  Database  →  Full SaaS
  on disk        with API          + API         (Backstage-like)
```

Each point on this spectrum has tradeoffs:
- **Git repo**: Version control for free, but no real-time collaboration, no API, no search
- **GitLab/GitHub**: Collaboration via MRs, but knowledge-as-code is awkward for non-engineers
- **Database + API**: Full flexibility, but need to build everything
- **Full SaaS**: Best UX, but most effort to build and maintain

### Q3: How do users interact with it?

- CLI only? (like LegacyTool today)
- Web UI? (like Backstage)
- IDE extension? (like Dendron)
- Chat interface? (Slack bot)
- All of the above?

**The answer should be:** Start with one, design for extensibility to others.
### Q4: How is the tree shared across an organization?

This is the distribution question. Options:

| Approach | How It Works | Pros | Cons |
|----------|-------------|------|------|
| **Git repo (monorepo)** | Single repo with all knowledge, clone/pull | Simple, versioned, familiar | Doesn't scale to 1000s of users, no fine-grained access |
| **Git repo (per-profile)** | Each profile is its own repo, composed via submodules or registry | Modular, team-owned | Complex dependency management |
| **Package registry** | Profiles published as packages (npm, pip, or custom) | Versioned, discoverable, cacheable | Overhead of packaging, not great for docs |
| **API + Database** | Central server, clients pull knowledge on demand | Real-time, searchable, access control | Need to build and host a service |
| **GitLab/GitHub Pages + API** | Knowledge as markdown in repos, served via Pages, API for metadata | Leverages existing infra, readable | Limited interactivity |

**My initial instinct:** A **Git-based registry** (like LegacyTool but hosted on GitLab) combined with a **lightweight API service** for metadata, search, and telemetry. Knowledge content stays in git (version controlled, reviewable via MRs). The API handles the tree structure, search, and analytics.

### Q5: What does the merge request workflow look like?

Two types from the original design:
1. **Update node content** — "Add this knowledge to this node"
2. **Add new node** — "Add this node to the tree at this location"

But in practice, we also need:
3. **Promote node** — "Move this ephemeral node to core"
4. **Merge nodes** — "Combine this child into its parent"
5. **Deprecate node** — "Mark this node as outdated"
6. **Move node** — "Relocate this node in the tree"

**Key question:** Do we use GitLab MRs directly (knowledge-as-code), or build a custom review workflow?

### Q6: How does progressive reveal work at scale?

The original design describes:
- Start with top-level nodes, all selected
- Expand to see children, deselect what you don't need
- Per-node depth selector (-1 = all, 1 = top-level, N = N levels)
- Core nodes selected by default, ephemeral not

**Implementation questions:**
- Is this a web UI? CLI wizard? IDE panel?
- How do you persist a user's selection? (per-project? per-user? per-team?)
- Can selections be shared? ("Use the same knowledge profile as Team X")
- How do you handle conflicts when a node is promoted/deprecated?

### Q7: What telemetry do we need, and how do we keep it non-intrusive?

**What we want to know:**
- How many teams/users are using the knowledge tree?
- Which nodes are most/least used?
- How often are nodes updated?
- What's the adoption curve over time?
- Which nodes are selected together? (affinity analysis)

**Non-intrusive principles:**
- No PII collection
- Aggregate metrics only
- Opt-out available
- Transparent about what's collected
- Data stays within the organization (no external services)

**Implementation options:**
- Lightweight event logging to a central endpoint
- GitLab CI pipeline that aggregates usage from project configs
- Periodic survey of `.agent-profiles/profile` files across repos

### Q8: What's the naming and taxonomy?

The original design flagged naming as important:
- "Knowledge Profiles" not "Agent Profiles" ✓
- "Core" vs "Ephemeral" — need better names
- What do we call the tree itself? Knowledge Tree? Knowledge Graph? Knowledge Catalog?

**Naming candidates for core/ephemeral:**

| Core | Ephemeral | Feel |
|------|-----------|------|
| Foundation / Experimental | Engineering | 
| Stable / Incubating | Software lifecycle |
| Standard / Custom | Enterprise |
| Shared / Personal | Collaboration |
| Canonical / Draft | Publishing |
| Evergreen / Seasonal | Nature (matches "tree") |

**My recommendation:** **Evergreen** vs **Seasonal** — it matches the tree metaphor perfectly. Evergreen nodes are always present (like evergreen trees). Seasonal nodes come and go (like deciduous leaves).

---

## 4. Proposed Plan Structure

Here's what the full design plan should contain, in order:

### Phase 0: Foundations (Week 1)
**Goal:** Lock down the data model and storage decisions.

| Deliverable | Description |
|-------------|-------------|
| **Data Model Spec** | Node schema, inheritance rules, metadata fields |
| **Storage Decision** | Where knowledge lives (git, DB, hybrid) |
| **Naming Convention** | Final names for all concepts |
| **Technology Selection** | Languages, frameworks, platforms |

### Phase 1: Core Engine (Weeks 2-3)
**Goal:** Build the tree operations without any UI.

| Deliverable | Description |
|-------------|-------------|
| **Tree CRUD** | Create, read, update, delete nodes |
| **Inheritance Engine** | Resolve knowledge for any node (walk up the tree) |
| **Classification System** | Evergreen vs. seasonal, promotion/demotion |
| **Merge Operations** | Node content merge, node addition, node consolidation |
| **CLI Tool** | Command-line interface for all operations |

### Phase 2: Collaboration (Weeks 4-5)
**Goal:** Make it shareable across the organization.

| Deliverable | Description |
|-------------|-------------|
| **Central Registry** | Hosted tree that teams can pull from |
| **Change Request Workflow** | Submit, review, approve/reject knowledge changes |
| **Access Control** | Who can modify which parts of the tree |
| **Distribution Mechanism** | How projects consume knowledge from the tree |

### Phase 3: Discovery & UX (Weeks 6-7)
**Goal:** Make it easy to find and select knowledge.

| Deliverable | Description |
|-------------|-------------|
| **Progressive Reveal UI** | Web-based tree browser with depth selection |
| **Search** | Full-text search across all knowledge nodes |
| **Recommendations** | "Teams like yours also use these nodes" |
| **Selection Profiles** | Save and share knowledge selections |

### Phase 4: Telemetry & Analytics (Week 8)
**Goal:** Understand adoption and usage patterns.

| Deliverable | Description |
|-------------|-------------|
| **Event Collection** | Non-intrusive usage tracking |
| **Dashboard** | Adoption metrics, popular nodes, growth trends |
| **Health Metrics** | Stale nodes, orphaned nodes, coverage gaps |

### Phase 5: Migration & Rollout (Weeks 9-10)
**Goal:** Move from LegacyTool to Knowledge Tree.

| Deliverable | Description |
|-------------|-------------|
| **LegacyTool Migration** | Import existing profiles into the new tree |
| **Pilot Program** | Roll out to 2-3 teams, gather feedback |
| **Documentation** | User guides, admin guides, contribution guides |
| **Org-wide Launch** | Communication, training, support |
---

## 5. My Opinionated Recommendation (For Discussion)

After studying the problem deeply, here's where I'd start. This is intentionally opinionated to give us something concrete to react to.

### Architecture: "Git-Native Knowledge Tree with a Thin API Layer"

```
┌─────────────────────────────────────────────────────────────────┐
│                    KNOWLEDGE TREE ARCHITECTURE                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────┐  │
│  │   GitLab     │    │  Tree API    │    │   Web UI         │  │
│  │   (Storage)  │◄──►│  (Metadata)  │◄──►│   (Discovery)    │  │
│  │              │    │              │    │                    │  │
│  │  • Knowledge │    │  • Tree ops  │    │  • Browse tree    │  │
│  │    as .md    │    │  • Search    │    │  • Select nodes   │  │
│  │  • MRs for   │    │  • Telemetry │    │  • Depth control  │  │
│  │    changes   │    │  • Auth      │    │  • Core/seasonal  │  │
│  │  • Version   │    │              │    │                    │  │
│  │    history   │    │              │    │                    │  │
│  └──────────────┘    └──────────────┘    └──────────────────┘  │
│         ▲                   ▲                     ▲             │
│         │                   │                     │             │
│         ▼                   ▼                     ▼             │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                      CLI Tool                             │  │
│  │  kt init | kt pull | kt push | kt browse | kt status     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Why This Architecture?

1. **GitLab as storage** — We already have GitLab. Knowledge as markdown files means:
   - Version control for free
   - MRs for change requests (already understood by engineers)
   - Code review workflow for knowledge review
   - Blame/history for every knowledge change
   - No new infrastructure to host

2. **Thin API layer** — A lightweight service (Python FastAPI or Go) that:
   - Reads the git repo and builds a tree index
   - Provides search across all knowledge
   - Collects anonymous telemetry events
   - Handles authentication via existing SSO
   - Can be deployed as a simple container

3. **Web UI for discovery** — A React/Next.js app that:
   - Renders the tree with progressive reveal
   - Lets users select nodes with depth control
   - Shows core vs. seasonal classification
   - Generates a "knowledge profile" config file
   - Could be embedded in Backstage if the org uses it

4. **CLI for daily use** — A `kt` command (like `legacytool` but better) that:
   - Initializes projects with selected knowledge
   - Pulls updates from the tree
   - Pushes new knowledge back up
   - Works offline (git-based)

### Technology Choices (Preliminary)

| Component | Technology | Rationale |
|-----------|-----------|-----------|
| **Storage** | GitLab repo (internal) | Already available, version controlled, MR workflow |
| **Knowledge format** | Markdown + YAML frontmatter | Human-readable, git-friendly, parseable |
| **Tree metadata** | `tree.yaml` at repo root | Single source of truth for tree structure |
| **API** | Python (FastAPI) or Go | Fast, typed, easy to deploy |
| **Web UI** | React + TypeScript | Standard, component-based, good tree libraries |
| **CLI** | Python (Click) or Go | Cross-platform, single binary distribution |
| **Telemetry** | Simple event log → internal analytics | Lightweight, non-intrusive |
| **Distribution** | GitLab Package Registry or simple `curl` | Leverage existing infra |

### Alternative Approaches Considered

#### Alt 1: "Build on Confluence"
Use Confluence's existing page tree as the knowledge tree. Add a plugin for depth selection and core/seasonal classification.

- **Pro:** Zero new infrastructure, everyone already has access
- **Con:** Confluence's API is painful, no real inheritance model, can't version control, plugin development is slow, Confluence is not designed for this

#### Alt 2: "Build on Backstage"
Use Spotify's Backstage as the platform. Knowledge nodes become catalog entities with a custom plugin for the tree UI.

- **Pro:** Enterprise-grade, plugin ecosystem, already used by some teams
- **Con:** Heavy infrastructure (Kubernetes, PostgreSQL), steep learning curve, may be overkill for knowledge management

#### Alt 3: "Pure Git (Enhanced LegacyTool)"
Keep everything in git repos, enhance LegacyTool with better tooling, add a web viewer.

- **Pro:** Simplest, builds on what works, no new services
- **Con:** Doesn't solve collaboration, discovery, or telemetry well. Still fundamentally single-user.

#### Alt 4: "Graph Database (Neo4j)"
Model the knowledge tree as a graph. Use Neo4j for storage, Cypher for queries.

- **Pro:** Natural fit for tree/graph operations, powerful querying
- **Con:** New infrastructure, team needs to learn graph DB, overkill for a tree (graphs are for when you need many-to-many relationships)

---

## 6. Open Questions for Discussion

Before creating the full plan, I'd like your input on these:

### Strategic Questions

1. **Scope of "knowledge"** — Is this only for AI agent context (rules, guides, service docs)? Or should it also cover team runbooks, onboarding docs, architecture decisions? The broader the scope, the more value but also more complexity.

2. **Target audience** — Engineers only? Or also PMs, managers, new hires? This affects the UI investment significantly.

3. **Organizational buy-in** — Is this a grassroots tool (bottom-up adoption) or a top-down initiative? This affects distribution strategy.

4. **Timeline pressure** — Is there a deadline or milestone driving this? Or is this a "build it right" long-term investment?

5. **Team size** — How many people would contribute to and maintain this? Just you? A small team? The whole org?

### Technical Questions

6. **GitLab vs. GitHub** — You're on GitLab internally. Is that the definitive platform, or could this be platform-agnostic?

7. **Existing Backstage** — Does your org use Backstage? If so, building as a Backstage plugin could be the fastest path to adoption.

8. **Deployment constraints** — Can you deploy a small service (API + DB)? Or does everything need to be serverless/static?

9. **Authentication** — SSO/SAML? LDAP? Or simpler (GitLab tokens)?

10. **Content format** — Is markdown sufficient? Or do you need rich content (diagrams, code snippets with execution, interactive elements)?

---

## 7. What Happens Next

Once we align on the strategic and technical questions above, the full plan will be structured as:

```
plans/
├── DESIGN_v2.md              ← Complete architecture document
│   ├── 1. Vision & Principles
│   ├── 2. Data Model
│   ├── 3. Architecture
│   ├── 4. Technology Decisions
│   ├── 5. Distribution Strategy
│   ├── 6. Telemetry Design
│   ├── 7. Migration from LegacyTool
│   ├── 8. Phased Roadmap
│   └── 9. Success Metrics
└── DESIGN_v2_DECISIONS.md     ← Decision log (ADRs)
```

The full plan will be actionable — each phase will have specific deliverables, acceptance criteria, and estimated effort.

---

*This meta-plan is a conversation starter. Challenge any assumption. Redirect any direction. The goal is to think before we build.*
