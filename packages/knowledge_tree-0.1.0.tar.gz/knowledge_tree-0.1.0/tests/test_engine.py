"""Tests for knowledge_tree.engine."""

from __future__ import annotations

from pathlib import Path

import pytest

from knowledge_tree.engine import KnowledgeTreeEngine, KnowledgeTreeError


class TestInit:
    def test_init_creates_directories(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        result = engine.init(str(sample_registry), branch="main")

        assert (project_dir / ".kt" / "kt.yaml").exists()
        assert (project_dir / ".kt" / "cache").is_dir()
        assert (project_dir / ".knowledge").is_dir()
        assert (project_dir / ".knowledge" / "KNOWLEDGE_MANIFEST.md").exists()

    def test_init_returns_package_counts(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        result = engine.init(str(sample_registry), branch="main")

        assert result["total_packages"] == 3
        assert result["evergreen"] == 3
        assert result["seasonal"] == 0

    def test_init_twice_fails(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        with pytest.raises(KnowledgeTreeError, match="Already initialized"):
            engine.init(str(sample_registry), branch="main")


class TestAddRemove:
    def test_add_package(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        result = engine.add_package("base")

        assert "base" in result["installed"]
        assert (project_dir / ".knowledge" / "base" / "safe-deletion.md").exists()
        assert (project_dir / ".knowledge" / "base" / "file-management.md").exists()

    def test_add_with_deps(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        result = engine.add_package("python-patterns")

        # Should install both base (dependency) and python-patterns
        assert "base" in result["installed"]
        assert "python-patterns" in result["installed"]

    def test_add_already_installed(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        engine.add_package("base")

        with pytest.raises(KnowledgeTreeError, match="already installed"):
            engine.add_package("base")

    def test_add_nonexistent(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        with pytest.raises(KnowledgeTreeError, match="not found"):
            engine.add_package("nonexistent-pkg")

    def test_remove_package(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        engine.add_package("base")
        result = engine.remove_package("base")

        assert result["removed"] == "base"
        assert not (project_dir / ".knowledge" / "base").exists()

    def test_remove_not_installed(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        with pytest.raises(KnowledgeTreeError, match="not installed"):
            engine.remove_package("base")

    def test_remove_with_dependents_fails(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        engine.add_package("python-patterns")  # installs base + python-patterns

        with pytest.raises(KnowledgeTreeError, match="required by"):
            engine.remove_package("base")


class TestList:
    def test_list_installed(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        engine.add_package("base")

        packages = engine.list_packages()
        assert len(packages) == 1
        assert packages[0]["name"] == "base"

    def test_list_available(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        packages = engine.list_available()
        assert len(packages) == 3
        names = [p["name"] for p in packages]
        assert "base" in names
        assert "git-conventions" in names
        assert "python-patterns" in names


class TestSearch:
    def test_search_by_name(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        results = engine.search("python")
        assert len(results) == 1
        assert results[0]["name"] == "python-patterns"

    def test_search_by_tag(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        results = engine.search("git")
        names = [r["name"] for r in results]
        assert "git-conventions" in names

    def test_search_no_results(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        results = engine.search("nonexistent")
        assert len(results) == 0


class TestStatus:
    def test_status(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        engine.add_package("base")

        status = engine.get_status()
        assert status["installed_packages"] == 1
        assert status["available_packages"] == 3
        assert status["total_files"] == 2  # safe-deletion.md + file-management.md
        assert status["total_lines"] > 0


class TestInfo:
    def test_info(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        info = engine.get_info("base")
        assert info["name"] == "base"
        assert info["classification"] == "evergreen"
        assert "safe-deletion.md" in info["content"]

    def test_info_not_found(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        with pytest.raises(KnowledgeTreeError, match="not found"):
            engine.get_info("nonexistent")


class TestManifest:
    def test_manifest_generated_on_init(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        manifest = project_dir / ".knowledge" / "KNOWLEDGE_MANIFEST.md"
        assert manifest.exists()
        content = manifest.read_text()
        assert "Knowledge Manifest" in content

    def test_manifest_updated_on_add(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")
        engine.add_package("base")

        manifest = project_dir / ".knowledge" / "KNOWLEDGE_MANIFEST.md"
        content = manifest.read_text()
        assert "base" in content
        assert "safe-deletion.md" in content


class TestValidate:
    def test_validate_valid_package(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        pkg_dir = engine.cache_dir / "packages" / "base"
        errors = engine.validate_package(pkg_dir)
        assert errors == []

    def test_validate_missing_package_yaml(self, tmp_path: Path):
        engine = KnowledgeTreeEngine(tmp_path)
        empty_dir = tmp_path / "empty-pkg"
        empty_dir.mkdir()

        errors = engine.validate_package(empty_dir)
        assert any("Missing package.yaml" in e for e in errors)


class TestRegistryRebuild:
    def test_rebuild(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        result = engine.registry_rebuild()
        assert result["total_packages"] == 3

    def test_validate_all(self, project_dir: Path, sample_registry: Path):
        engine = KnowledgeTreeEngine(project_dir)
        engine.init(str(sample_registry), branch="main")

        result = engine.validate_all()
        assert result["packages_checked"] == 3
        assert result["packages_with_errors"] == 0
