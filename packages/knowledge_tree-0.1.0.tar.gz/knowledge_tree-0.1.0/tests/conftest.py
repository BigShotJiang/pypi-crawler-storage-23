"""Shared test fixtures for Knowledge Tree tests."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


@pytest.fixture
def sample_registry(tmp_path: Path) -> Path:
    """Create a sample registry as a bare git repo with seed packages.

    Returns the path to the bare repo (can be used as a remote URL).
    """
    # Create registry content in a work dir
    work_dir = tmp_path / "registry-work"
    work_dir.mkdir()

    # Create packages/base
    base_dir = work_dir / "packages" / "base"
    base_dir.mkdir(parents=True)
    (base_dir / "package.yaml").write_text(
        "name: base\n"
        "description: Universal agent conventions\n"
        "classification: evergreen\n"
        "version: '0.1.0'\n"
        "tags:\n  - conventions\n  - safety\n"
        "content:\n  - safe-deletion.md\n  - file-management.md\n"
    )
    (base_dir / "safe-deletion.md").write_text(
        "# Safe Deletion\n\nAlways confirm before deleting files.\n"
    )
    (base_dir / "file-management.md").write_text(
        "# File Management\n\nUse kebab-case for filenames.\n"
    )

    # Create packages/git-conventions
    git_dir = work_dir / "packages" / "git-conventions"
    git_dir.mkdir(parents=True)
    (git_dir / "package.yaml").write_text(
        "name: git-conventions\n"
        "description: Git commit conventions\n"
        "classification: evergreen\n"
        "version: '0.1.0'\n"
        "parent: base\n"
        "tags:\n  - git\n"
        "content:\n  - commit-messages.md\n"
    )
    (git_dir / "commit-messages.md").write_text(
        "# Commit Messages\n\nUse conventional commits.\n"
    )

    # Create packages/python-patterns
    py_dir = work_dir / "packages" / "python-patterns"
    py_dir.mkdir(parents=True)
    (py_dir / "package.yaml").write_text(
        "name: python-patterns\n"
        "description: Python coding patterns\n"
        "classification: evergreen\n"
        "version: '0.1.0'\n"
        "depends_on:\n  - base\n"
        "tags:\n  - python\n"
        "content:\n  - project-structure.md\n"
    )
    (py_dir / "project-structure.md").write_text(
        "# Project Structure\n\nUse src/ layout for Python projects.\n"
    )

    # Create community dir
    (work_dir / "community").mkdir()
    (work_dir / "community" / ".gitkeep").touch()

    # Create registry.yaml
    (work_dir / "registry.yaml").write_text(
        "version: '2026-02-22'\n"
        "packages:\n"
        "  base:\n"
        "    description: Universal agent conventions\n"
        "    classification: evergreen\n"
        "    tags:\n      - conventions\n      - safety\n"
        "    version: '0.1.0'\n"
        "    path: packages/base\n"
        "  git-conventions:\n"
        "    description: Git commit conventions\n"
        "    classification: evergreen\n"
        "    tags:\n      - git\n"
        "    parent: base\n"
        "    version: '0.1.0'\n"
        "    path: packages/git-conventions\n"
        "  python-patterns:\n"
        "    description: Python coding patterns\n"
        "    classification: evergreen\n"
        "    tags:\n      - python\n"
        "    depends_on:\n      - base\n"
        "    version: '0.1.0'\n"
        "    path: packages/python-patterns\n"
    )

    # Initialize as git repo, commit, then create a bare clone
    subprocess.run(["git", "init", "-b", "main"], cwd=work_dir, check=True, capture_output=True)
    subprocess.run(["git", "add", "."], cwd=work_dir, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial registry"],
        cwd=work_dir, check=True, capture_output=True,
        env={**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@test.com",
             "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@test.com"},
    )

    # Create bare clone
    bare_repo = tmp_path / "registry.git"
    subprocess.run(
        ["git", "clone", "--bare", str(work_dir), str(bare_repo)],
        check=True, capture_output=True,
    )

    return bare_repo


@pytest.fixture
def project_dir(tmp_path: Path) -> Path:
    """Create an empty project directory for testing."""
    project = tmp_path / "my-project"
    project.mkdir()
    return project
