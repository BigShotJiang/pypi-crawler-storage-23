"""Tests for knowledge_tree.models."""

from __future__ import annotations

from pathlib import Path

import pytest

from knowledge_tree.models import (
    InstalledPackage,
    PackageMetadata,
    ProjectConfig,
    Registry,
    RegistryEntry,
    _is_kebab_case,
)


# ---------------------------------------------------------------------------
# PackageMetadata
# ---------------------------------------------------------------------------


class TestPackageMetadata:
    def test_valid_package(self):
        pkg = PackageMetadata(name="my-package", description="A test package")
        assert pkg.validate() == []

    def test_missing_name(self):
        pkg = PackageMetadata(name="", description="A test package")
        errors = pkg.validate()
        assert any("name is required" in e for e in errors)

    def test_invalid_name_not_kebab(self):
        pkg = PackageMetadata(name="MyPackage", description="test")
        errors = pkg.validate()
        assert any("kebab-case" in e for e in errors)

    def test_missing_description(self):
        pkg = PackageMetadata(name="my-pkg", description="")
        errors = pkg.validate()
        assert any("description is required" in e for e in errors)

    def test_invalid_classification(self):
        pkg = PackageMetadata(
            name="my-pkg", description="test", classification="unknown"
        )
        errors = pkg.validate()
        assert any("Classification" in e for e in errors)

    def test_invalid_status(self):
        pkg = PackageMetadata(
            name="my-pkg", description="test", status="invalid"
        )
        errors = pkg.validate()
        assert any("Status" in e for e in errors)

    def test_default_dates_set(self):
        pkg = PackageMetadata(name="my-pkg", description="test")
        assert pkg.created != ""
        assert pkg.updated != ""

    def test_default_classification(self):
        pkg = PackageMetadata(name="my-pkg", description="test")
        assert pkg.classification == "seasonal"

    def test_to_dict_round_trip(self):
        pkg = PackageMetadata(
            name="my-pkg",
            description="test",
            authors=["alice"],
            classification="evergreen",
            tags=["python"],
            content=["guide.md"],
            parent="base",
            depends_on=["other"],
        )
        d = pkg.to_dict()
        pkg2 = PackageMetadata.from_dict(d)
        assert pkg2.name == pkg.name
        assert pkg2.parent == pkg.parent
        assert pkg2.depends_on == pkg.depends_on
        assert pkg2.tags == pkg.tags

    def test_save_and_load(self, tmp_path: Path):
        pkg = PackageMetadata(
            name="test-pkg",
            description="Test package",
            authors=["bob"],
            tags=["test"],
            content=["readme.md"],
        )
        yaml_path = tmp_path / "package.yaml"
        pkg.save(yaml_path)
        assert yaml_path.exists()

        loaded = PackageMetadata.load(yaml_path)
        assert loaded.name == "test-pkg"
        assert loaded.description == "Test package"
        assert loaded.authors == ["bob"]

    def test_phase2_fields(self):
        pkg = PackageMetadata(
            name="my-pkg",
            description="test",
            status="pending",
            promoted_to="curated-pkg",
            promoted_date="2026-03-01",
        )
        d = pkg.to_dict()
        assert d["status"] == "pending"
        assert d["promoted_to"] == "curated-pkg"
        assert d["promoted_date"] == "2026-03-01"

    def test_active_status_omitted_from_dict(self):
        pkg = PackageMetadata(name="my-pkg", description="test", status="active")
        d = pkg.to_dict()
        assert "status" not in d  # active is the default, omitted


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class TestRegistry:
    def _make_registry(self) -> Registry:
        return Registry(
            version="2026-02-22",
            packages={
                "base": RegistryEntry(
                    description="Base conventions",
                    classification="evergreen",
                    tags=["conventions"],
                    path="packages/base",
                ),
                "git": RegistryEntry(
                    description="Git conventions",
                    classification="evergreen",
                    tags=["git"],
                    parent="base",
                    path="packages/git",
                ),
                "python": RegistryEntry(
                    description="Python patterns",
                    classification="evergreen",
                    tags=["python"],
                    depends_on=["base"],
                    path="packages/python",
                ),
                "experimental": RegistryEntry(
                    description="Experimental stuff",
                    classification="seasonal",
                    tags=["experimental"],
                    path="packages/experimental",
                ),
            },
        )

    def test_get(self):
        reg = self._make_registry()
        assert reg.get("base") is not None
        assert reg.get("nonexistent") is None

    def test_get_children(self):
        reg = self._make_registry()
        children = reg.get_children("base")
        assert "git" in children
        assert "python" not in children  # python depends_on base but parent is None

    def test_resolve_deps_simple(self):
        reg = self._make_registry()
        deps = reg.resolve_deps("base")
        assert deps == ["base"]

    def test_resolve_deps_with_dependency(self):
        reg = self._make_registry()
        deps = reg.resolve_deps("python")
        assert deps == ["base", "python"]

    def test_resolve_deps_no_circular(self):
        reg = self._make_registry()
        # Even if we call on base, it should not loop
        deps = reg.resolve_deps("base")
        assert deps == ["base"]

    def test_search_by_name(self):
        reg = self._make_registry()
        results = reg.search("python")
        assert "python" in results

    def test_search_by_description(self):
        reg = self._make_registry()
        results = reg.search("conventions")
        assert "base" in results

    def test_search_by_tag(self):
        reg = self._make_registry()
        results = reg.search("git")
        assert "git" in results

    def test_search_case_insensitive(self):
        reg = self._make_registry()
        results = reg.search("PYTHON")
        assert "python" in results

    def test_save_and_load(self, tmp_path: Path):
        reg = self._make_registry()
        path = tmp_path / "registry.yaml"
        reg.save(path)
        assert path.exists()

        loaded = Registry.load(path)
        assert len(loaded.packages) == 4
        assert loaded.get("base") is not None
        assert loaded.packages["python"].depends_on == ["base"]

    def test_rebuild_from_directory(self, tmp_path: Path):
        # Create minimal packages
        pkg_dir = tmp_path / "packages" / "test-pkg"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.yaml").write_text(
            "name: test-pkg\n"
            "description: A test\n"
            "content:\n  - readme.md\n"
        )
        (pkg_dir / "readme.md").write_text("# Test\n")

        reg = Registry.rebuild_from_directory(tmp_path)
        assert "test-pkg" in reg.packages
        assert reg.packages["test-pkg"].path == "packages/test-pkg"


# ---------------------------------------------------------------------------
# ProjectConfig
# ---------------------------------------------------------------------------


class TestProjectConfig:
    def test_add_and_remove_package(self):
        config = ProjectConfig(registry="https://example.com/reg.git")
        config.add_package("base", "abc123")
        assert config.is_installed("base")
        assert config.get_installed("base").ref == "abc123"

        config.remove_package("base")
        assert not config.is_installed("base")

    def test_add_package_idempotent(self):
        config = ProjectConfig()
        config.add_package("base")
        config.add_package("base")
        assert len(config.packages) == 1

    def test_save_and_load(self, tmp_path: Path):
        config = ProjectConfig(
            registry="git@github.com:test/reg.git",
            registry_ref="main",
            telemetry_enabled=True,
        )
        config.add_package("base", "abc")
        config.add_package("python", "def")

        path = tmp_path / "kt.yaml"
        config.save(path)
        assert path.exists()

        loaded = ProjectConfig.load(path)
        assert loaded.registry == "git@github.com:test/reg.git"
        assert loaded.is_installed("base")
        assert loaded.is_installed("python")
        assert loaded.telemetry_enabled is True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestHelpers:
    @pytest.mark.parametrize(
        "name,expected",
        [
            ("my-package", True),
            ("base", True),
            ("cloud-aws-3", True),
            ("MyPackage", False),
            ("my_package", False),
            ("", False),
            ("my package", False),
            ("MY-PACKAGE", False),
        ],
    )
    def test_is_kebab_case(self, name: str, expected: bool):
        assert _is_kebab_case(name) == expected
