# Contributing to Knowledge Tree Registry

Thank you for contributing knowledge! This guide explains how to add new
knowledge packages or improve existing ones.

## Quick Start

```bash
# Install kt
pip install knowledge-tree

# Initialize your project
kt init --from <registry-url>

# Contribute a new package
kt contribute my-notes.md --name my-package-name --description "What this knowledge covers"

# Preview before pushing
kt contribute my-notes.md --name my-package-name --dry-run
```

## What Makes Good Knowledge?

Knowledge packages are consumed by **AI coding agents**, not humans. Content should be:

- **Precise and actionable** — Instructions and patterns, not prose
- **Example-rich** — Code snippets, config examples, command sequences
- **Context-aware** — State when something applies and when it doesn't
- **Self-contained** — Each file should be useful on its own
- **Concise** — AI context windows are limited; don't waste tokens

## Package Structure

Each package is a directory with a `package.yaml` manifest and one or more
markdown content files:

```
my-package/
├── package.yaml        # Required: package metadata
├── overview.md         # First file = overview
├── patterns.md         # Additional content
└── troubleshooting.md  # More content
```

### package.yaml

```yaml
name: my-package              # kebab-case, unique
description: What this covers  # One-line summary
authors:
  - your-username
classification: seasonal       # "seasonal" for new contributions
tags:
  - relevant
  - tags
content:
  - overview.md               # List files in reading order
  - patterns.md
```

## Content Guidelines

| Guideline | Limit |
|-----------|-------|
| Individual files | Max 500 lines (soft limit) |
| Package total | Max 2000 lines across all files (soft limit) |
| Filenames | kebab-case, `.md` extension |

## Contribution Types

| Type | How |
|------|-----|
| **New package** | `kt contribute files.md --name new-topic` |
| **Add to existing** | `kt contribute more.md --to existing-package --name addition-name` |

## Review Process

1. Your contribution lands in the `community/` directory as a "seasonal" package
2. Maintainers review for accuracy and quality
3. Good contributions get promoted to the curated `packages/` directory as "evergreen"

## Questions?

Open an issue on GitHub or reach out to the maintainers.
