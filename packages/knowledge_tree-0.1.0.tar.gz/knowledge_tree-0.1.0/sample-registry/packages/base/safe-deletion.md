---
title: Safe Deletion Practices
summary: Rules for safely deleting files and directories to prevent data loss
updated: '2026-02-22'
author: kbisla
tags: [safety, deletion, conventions]
---

# Safe Deletion Practices

## Never Delete Without Confirmation

Before deleting any file or directory, always:

1. **List what will be deleted** — Show the user exactly what will be removed
2. **Check for unsaved changes** — Warn if files have uncommitted modifications
3. **Prefer moves over deletes** — Move to a `.trash/` directory when possible

## Safe Deletion Commands

```bash
# Instead of rm -rf, use trash:
trash-put ./old-directory/

# Or move to a timestamped backup:
mv ./old-file "./old-file.bak.$(date +%s)"
```

## Git-Tracked Files

For files under version control:
- Use `git rm` instead of `rm` to properly track the deletion
- Commit deletions separately from other changes for clean history
- Never force-delete (`git rm -f`) without verifying the file isn't needed elsewhere
