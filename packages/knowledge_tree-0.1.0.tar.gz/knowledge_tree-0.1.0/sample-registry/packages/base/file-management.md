---
title: File Management Conventions
summary: Standard practices for creating, organizing, and managing project files
updated: '2026-02-22'
author: kbisla
tags: [conventions, files, organization]
---

# File Management Conventions

## File Naming

- Use **kebab-case** for all filenames: `my-component.ts`, not `MyComponent.ts`
- Use descriptive names that explain the file's purpose
- Keep filenames under 50 characters

## Directory Structure

Organize files by feature, not by type:

```
# Good: feature-based
src/
├── auth/
│   ├── login.ts
│   ├── login.test.ts
│   └── auth-service.ts
└── dashboard/
    ├── dashboard.ts
    └── dashboard.test.ts

# Avoid: type-based
src/
├── components/
├── services/
└── tests/
```

## Temporary Files

- Never commit temporary files (`*.tmp`, `*.bak`, `*.swp`)
- Add common temp file patterns to `.gitignore`
- Clean up temp files after operations complete
