---
title: Python Error Handling
summary: Patterns for clean, helpful error handling in Python
updated: '2026-02-22'
author: kbisla
tags: [python, errors, exceptions]
---

# Python Error Handling

## Custom Exception Hierarchy

Define a base exception for your package, then specific exceptions that inherit from it:

```python
class MyAppError(Exception):
    """Base exception for this application."""

class NotFoundError(MyAppError):
    """Raised when a requested resource doesn't exist."""

class ValidationError(MyAppError):
    """Raised when input fails validation."""
```

## Error Messages Should Be Helpful

Every error message should answer three questions:

1. **What** went wrong
2. **Why** it might have happened
3. **What to do** about it

```python
# Bad
raise FileNotFoundError("Config not found")

# Good
raise FileNotFoundError(
    f"Config file not found at {path}. "
    f"Run 'my-tool init' to create one, or check that "
    f"you're in the right directory."
)
```

## Never Silently Swallow Exceptions

```python
# Bad — hides bugs
try:
    do_something()
except Exception:
    pass

# Good — log and re-raise, or handle specifically
try:
    do_something()
except ValueError as e:
    logger.warning(f"Invalid value, using default: {e}")
    result = default_value
```
