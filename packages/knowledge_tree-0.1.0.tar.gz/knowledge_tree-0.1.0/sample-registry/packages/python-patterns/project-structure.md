---
title: Python Project Structure
summary: Standard directory layout for Python projects
updated: '2026-02-22'
author: kbisla
tags: [python, structure, project]
---

# Python Project Structure

## Recommended Layout

```
my-project/
├── pyproject.toml          # Project metadata and dependencies
├── README.md
├── LICENSE
├── src/
│   └── my_package/
│       ├── __init__.py
│       ├── core.py         # Core logic
│       └── cli.py          # CLI entry point
├── tests/
│   ├── conftest.py         # Shared fixtures
│   ├── test_core.py
│   └── test_cli.py
└── docs/
    └── index.md
```

## Key Principles

1. **Use `src/` layout** — prevents accidental imports from the project root
2. **Use `pyproject.toml`** — not `setup.py` or `setup.cfg` (PEP 621)
3. **Mirror source in tests** — `src/pkg/core.py` → `tests/test_core.py`
4. **Keep `__init__.py` minimal** — only version string and public API exports
