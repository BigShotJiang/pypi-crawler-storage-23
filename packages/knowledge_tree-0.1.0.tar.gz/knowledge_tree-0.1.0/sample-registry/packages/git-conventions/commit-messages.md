---
title: Git Commit Message Conventions
summary: How to write clear, useful commit messages
updated: '2026-02-22'
author: kbisla
tags: [git, commits, conventions]
---

# Git Commit Message Conventions

## Format

```
<type>: <short summary>

<optional body>
```

## Types

| Type | When to Use |
|------|-------------|
| `feat` | New feature or capability |
| `fix` | Bug fix |
| `docs` | Documentation changes |
| `refactor` | Code restructuring (no behavior change) |
| `test` | Adding or updating tests |
| `chore` | Build, CI, or tooling changes |

## Examples

```
feat: add user authentication via OAuth2

fix: prevent null pointer when user has no email

docs: update API reference for /users endpoint

refactor: extract validation logic into shared module
```

## Rules

1. **Keep the summary under 72 characters**
2. **Use imperative mood** — "add feature" not "added feature"
3. **Reference issue numbers** when applicable: `fix: handle timeout (#123)`
4. **Separate subject from body** with a blank line
5. **One logical change per commit** — don't mix unrelated changes
