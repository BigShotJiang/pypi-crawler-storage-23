# Knowledge Tree: The Complete Project Overview  
  
*A comprehensive guide to what Knowledge Tree is, why it exists, how it works, and where it's going.*  
⸻  
⸻  
## Part 1: The Problem — Why Does This Project Exist?  
  
### The Rise of AI Coding Agents  
  
In 2025-2026, AI coding agents became a standard part of software engineering workflows. Tools like Cursor, GitHub Copilot, Windsurf, and Roo Code (formerly Cline) sit inside your IDE and help you write, debug, and refactor code. These agents are remarkably capable — but they have a fundamental limitation: **they don't know anything about your organization.**  
  
An AI agent can write excellent Python code. But it doesn't know that your company uses a specific authentication pattern for AWS. It doesn't know that your team has a convention for git commit messages. It doesn't know that deleting files should use the ==trash== command instead of ==rm== because your ops team had an incident last year. It doesn't know about your internal services, your deployment pipelines, or your coding standards.  
  
This organizational knowledge — the stuff that lives in people's heads, in Confluence pages nobody reads, in Slack threads that scroll away — is exactly what AI agents need to be truly useful in an enterprise setting.  
  
Consider a concrete example. A developer at Acme Corp. asks their AI agent to "add a new API endpoint." The agent writes perfectly valid Python code. But it doesn't use the team's standard authentication middleware. It doesn't follow the team's error handling patterns. It doesn't know about the internal service mesh configuration. It doesn't use the right logging format. The developer ends up spending more time correcting the AI's output than they would have spent writing it themselves. The AI is technically correct but contextually wrong.  
  
Now imagine the same scenario, but the AI agent has been given a set of knowledge files that describe the team's authentication patterns, error handling conventions, service mesh configuration, and logging standards. The agent reads these files at the start of the session and produces code that fits the organization perfectly. The developer reviews it, makes minor tweaks, and ships it. The AI went from being a generic code generator to being a team-aware coding partner.  
  
This is the gap that Knowledge Tree fills. It's the infrastructure for getting that organizational knowledge into AI agents' hands, reliably and at scale.  
  
### The First Attempt: LegacyTool — What Worked and What Didn't  
  
Before Knowledge Tree, there was a tool called LegacyTool. LegacyTool was a prototype built as a set of bash scripts that managed "agent profiles" — collections of rules, knowledge, and configuration that get injected into an AI agent's context window.  
  
### How LegacyTool Actually Worked  
  
LegacyTool stored profiles in a hidden directory on the developer's machine: ==~/.agent-project-profiles/==. Each profile was a directory containing several types of content:  
  
- **Rules** — Instructions for the AI agent (like "always use ==trash== instead of ==rm==")  
- **Knowledge** — Domain-specific information (like "here's how our AWS authentication works")  
- **Services** — Integration configurations (like "here's how to access JIRA, Confluence, and GitLab")  
- **Tools** — Custom tool definitions for the AI agent  
- **Modes** — Custom operating modes for the AI agent  
- **Templates** — Boilerplate for common tasks  
  
These profiles were hierarchical. A project would declare its profile chain — for example, ==base → acme → be3==. This meant:  
  
1. The ==base== profile contained universal rules that apply everywhere (safe deletion, git conventions, general best practices)  
2. The ==acme== profile extended ==base== with company-specific knowledge (internal services, authentication patterns, enterprise tools)  
3. The ==be3== profile extended ==acme== with team-specific standards (Python coding rules, specific framework patterns, team conventions)  
  
When LegacyTool initialized a project, it would walk up this chain and concatenate all the relevant content into an ==agents.md== file that the AI agent would read at session start. The agent would then know everything from all three levels of the hierarchy.  
  
### What Acme Corp Proved  
  
LegacyTool was used in production for several months and validated several critical hypotheses:  
  
1. **Hierarchical inheritance works.** The base → company → team model is natural and intuitive. Knowledge at higher levels applies broadly, and teams can specialize without duplicating foundational content.  
  
2. **The "promote" workflow is natural.** When a team discovers a useful pattern, they naturally want to share it upward. LegacyTool had a ==promote== command that moved knowledge from a child profile to a parent, making it available to sibling teams. This happened organically — teams would realize "this isn't just useful for us, everyone should know this."  
  
3. **The "update" workflow must be opt-in.** When a parent profile changes, child profiles should be able to pull those changes at their own pace. LegacyTool's ==update== command let teams pull changes when they were ready, rather than having changes forced on them. This was important for stability.  
  
4. **AI agents genuinely improve with organizational context.** This was the most important validation. Agents with LegacyTool profiles produced noticeably better code — code that followed team conventions, used the right patterns, and required fewer corrections. The improvement was significant enough that developers actively wanted to maintain and improve their profiles.  
  
5. **People will contribute knowledge if the mechanism exists.** Even with LegacyTool's clunky bash-script interface, developers contributed knowledge. They would add new rules, document patterns they discovered, and share service configurations. The desire to improve the AI agent's context was a strong motivator.  
  
### Where LegacyTool Fell Short  
  
Despite its success, LegacyTool had fundamental structural limitations:  
  
1. **Local-only storage.** Profiles lived in ==~/.agent-project-profiles/== on each developer's machine. There was no way to share profiles across machines or with teammates. If you set up a great profile on your laptop, your desktop didn't have it. If a new team member joined, they had to manually copy profiles from someone else's machine.  
  
2. **Single-user design.** There was no collaboration model. Two people couldn't work on the same profile simultaneously. There was no review process for changes. There was no way to know if someone else had already documented a pattern you were about to document.  
  
3. **No discovery mechanism.** You had to know that a profile existed to use it. There was no search, no browsing, no way to find out what knowledge was available. New users would ask "what profiles should I use?" and the answer was always "ask someone who knows."  
  
4. **Bash script fragility.** LegacyTool was implemented as bash scripts. This made it hard to extend, hard to test, hard to distribute, and hard to maintain. Error handling was minimal. Edge cases caused cryptic failures. There was no proper API that other tools could integrate with.  
  
5. **No quality control.** Anyone could put anything in a profile. There was no validation, no review process, no way to ensure that knowledge was accurate, up-to-date, or well-structured. Over time, profiles could accumulate stale or incorrect information.  
  
6. **No usage telemetry.** There was no way to know how many people were using LegacyTool, which profiles were popular, or whether the tool was actually improving productivity. This made it hard to justify investment in the tool or to identify which knowledge was most valuable.  
  
7. **Mixed concerns.** LegacyTool profiles contained everything — rules, knowledge, tools, services, modes, templates. This made profiles large and hard to manage. Knowledge Tree deliberately focuses on knowledge only, leaving the other concerns to LegacyTool or similar tools.  
  
### The Industry Landscape — What Already Exists?  
  
Before designing Knowledge Tree, an extensive survey of existing tools and systems was conducted. The goal was to understand what's already out there and identify the gap that Knowledge Tree needs to fill.  
  
### Direct Analogues: Hierarchical Knowledge Systems  
  
Several existing systems organize knowledge hierarchically:  
  
- **Confluence Spaces and Page Trees** — Confluence uses hierarchical pages within spaces. It has a tree structure and supports labels for classification. However, it has no concept of downward inheritance (a child page doesn't automatically "know" what its parent page says), and it's designed for human reading, not AI consumption.  
  
- **Notion Databases and Templates** — Notion offers hierarchical pages with templates for reuse and relational databases for linking content. It has good UX for progressive reveal, but no formal inheritance model and no package/distribution system.  
  
- **Obsidian with Dataview** — Obsidian uses a graph-based knowledge model with tags, backlinks, and community plugins. It's more graph than tree, but the vault model (a directory of markdown files) is conceptually similar to Knowledge Tree's package model. However, Obsidian is designed for personal knowledge management, not organizational distribution.  
  
- **GitBook and Docusaurus** — These are versioned documentation platforms with hierarchical sidebars and search. They're good for static knowledge but have no dynamic inheritance, no package model, and no contribution workflow beyond standard git.  
  
- **Backstage by Spotify** — This is the closest enterprise analogue. Backstage is a developer portal with a software catalog, TechDocs for documentation, and a plugin ecosystem. It supports hierarchical ownership and has a rich UI. However, it requires significant infrastructure (Kubernetes, PostgreSQL) and is designed as a full platform, not a lightweight knowledge distribution tool.  
  
- **Dendron** — A VS Code extension for hierarchical note-taking with schemas, lookup, and refactoring. It's the closest conceptual match to Knowledge Tree's hierarchical model. However, Dendron is designed for personal use, not organizational distribution, and it doesn't have a crowdsourcing or review model.  
  
### Conceptual Analogues: Inheritance and Composition Systems  
  
Several systems from software engineering use patterns similar to Knowledge Tree's inheritance model:  
  
- **CSS Cascade** — CSS uses specificity-based inheritance where the most specific rule wins. This is conceptually similar to how knowledge inheritance works: a team-specific rule overrides a company-wide rule, which overrides a universal rule.  
  
- **Object-Oriented Inheritance** — The parent-child class hierarchy in OOP is a direct analogue to profile chains. A child class inherits all methods from its parent and can override or extend them.  
  
- **Terraform Modules** — Terraform uses composable, parameterized, versioned modules. This is similar to how knowledge packages can be composed and versioned.  
  
- **Helm Charts with Values** — Helm uses a base chart with overlay values per environment. This is similar to how a base knowledge profile can be customized per team.  
  
- **Kubernetes Kustomize** — Kustomize uses base configurations with overlays for hierarchical patching. This is very similar to Knowledge Tree's inheritance model.  
  
### Enterprise Knowledge Management Platforms  
  
Several enterprise platforms manage organizational knowledge:  
  
- **Guru** — Card-based knowledge with verification workflows and Slack integration. Not hierarchical, no inheritance.  
- **Tettra** — Team wikis with Slack integration and verification. Flat structure.  
- **Slite** — Collaborative docs with channels and search. No formal hierarchy.  
- **Slab** — Unified search across topics with integrations. No inheritance model.  
- **Stack Overflow for Teams** — Q&A format with tags and voting. Not hierarchical.  
  
### The Gap  
  
After surveying all of these systems, a clear gap emerged. **No existing system combines all of:**  
  
1. Hierarchical knowledge with downward inheritance  
2. Classification of knowledge by stability (core vs. experimental)  
3. Progressive reveal with depth control for managing scale  
4. A merge request workflow for reviewing knowledge changes  
5. Package-based composition with dependency resolution  
6. Git-native storage requiring no new infrastructure  
7. AI-agent-optimized content format and distribution  
8. CLI-based consumption via standard package managers  
  
This confirmed that a new tool was needed — but one that should be built on top of existing platforms (git, pip) rather than from scratch.  
  
### The Core Insight: Git Trees vs. Knowledge Trees  
  
The breakthrough insight that led to Knowledge Tree came from observing a fundamental difference between how git manages code and how knowledge should be managed. This insight was captured in a voice memo and later formalized into the design.  
  
Here are the key differences between git source code trees and knowledge trees:  
  
**Flow direction.** In git, knowledge flows upward. You create a feature branch, do work on it, and merge it back into the main branch. The work converges toward a single point. In a knowledge tree, knowledge flows downward. A parent node contains foundational knowledge, and child nodes inherit everything the parent knows, plus their own specialized knowledge.  
  
**Branch lifecycle.** In git, branches are temporary. They exist to isolate work, and then they merge away and disappear. In a knowledge tree, nodes are permanent. Once a piece of knowledge is added, it stays. The tree only grows; it never shrinks naturally.  
  
**Convergence vs. divergence.** Git converges — all branches eventually merge back into ==dev== or ==main==. A knowledge tree diverges — new nodes are added, new specializations are created, and the tree expands outward. There's no natural convergence mechanism.  
  
**Scaling behavior.** Git is self-limiting because branches merge away. The number of active branches at any time is bounded by the number of active developers and features. A knowledge tree has unbounded growth. Every new team, every new technology, every new convention adds nodes. At 10 nodes, it's manageable. At 100 nodes, you need organization. At 1,000 nodes, you need progressive reveal, classification, and search — or new users will be overwhelmed by the sheer volume of available knowledge.  
  
This insight shaped every design decision in Knowledge Tree. The classification system (evergreen vs. seasonal) exists to manage unbounded growth. The package model (instead of rigid tree nodes) exists to allow flexible organization. The search and tagging system exists to make large knowledge bases navigable. The manifest-based agent integration exists to handle the case where there's more knowledge available than an AI agent can consume at once.  
⸻  
⸻  
## Part 2: The Solution — What Is Knowledge Tree?  
  
### The Elevator Pitch  
  
Knowledge Tree is a **crowdsourced knowledge management system for AI agent context**. It lets teams collaboratively build, curate, and distribute the knowledge that AI coding agents need to understand codebases, tools, services, and organizational conventions.  
  
Think of it like npm or pip, but for knowledge instead of code. You install knowledge packages into your project, and your AI agent automatically has access to that knowledge. Just as ==pip install requests== gives your Python code the ability to make HTTP requests, ==kt add cloud-aws== gives your AI agent the knowledge of how your organization uses AWS.  
  
### The Core Principles  
  
Three principles guide the entire design:  
  
1. **Easy to contribute** — If someone has useful knowledge, it should take one command to package it and submit it for review. The friction of contributing must be lower than the friction of not contributing. If it's easier to just tell your teammate in Slack than to add it to the knowledge tree, people won't contribute. So the contribution workflow must be simpler than a Slack message — ideally, a single command that takes a markdown file and turns it into a proper knowledge package.  
  
2. **Controlled to accept** — Contributions go through a review process, just like code pull requests. This ensures quality and prevents the knowledge base from becoming a dumping ground. Without quality control, knowledge bases inevitably fill with outdated, incorrect, or poorly written content. The merge request workflow provides a natural review checkpoint where maintainers can verify accuracy, check classification, and ensure the knowledge is in the right package.  
  
3. **Effortless to consume** — Installing knowledge should be as simple as ==pip install==. The AI agent should be able to find and use the knowledge without any manual configuration. The developer shouldn't have to think about knowledge management at all — they install the packages their project needs, and the AI agent automatically becomes smarter about their context.  
  
### How It Works: The Big Picture  
  
Knowledge Tree has three main components that work together:  
  
**Component 1: The Central Registry**  
  
This is a git repository — hosted on GitLab, GitHub, Bitbucket, or any git server — that serves as the source of truth for all knowledge. It contains "knowledge packages," which are directories of markdown files with metadata. The registry has a standard structure:  
  
```
knowledge-tree-registry/
├── registry.yaml              # Index of all packages (auto-generated)
├── CONTRIBUTING.md            # How to contribute knowledge
├── packages/
│   ├── base/                  # Universal conventions
│   │   ├── package.yaml       # Package metadata
│   │   ├── safe-deletion.md   # Knowledge content
│   │   └── file-management.md
│   ├── git-conventions/       # Git-specific knowledge
│   │   ├── package.yaml
│   │   └── commit-messages.md
│   └── acme-services/    # Company-specific services
│       ├── package.yaml
│       ├── service-access.md
│       └── authentication.md

```
  
  
The key insight here is that **knowledge lives in git**. This gives you version control for free, merge request workflows for reviewing contributions, blame history for every change, and no new infrastructure to host. Any organization that uses git already has everything they need.  
  
Why a single repository rather than multiple repositories? Simplicity. A single repo means a single clone, a single search scope, a single merge request workflow, and a single CI/CD pipeline for validation. Cross-package references are easy because everything is in one place. Discovery is straightforward because you can browse the entire knowledge base in one directory listing. At the scale Knowledge Tree is designed for (tens to hundreds of packages, not thousands), a single repo is the right choice. If the system ever grows to thousands of packages, a multi-repo model could be introduced later.  
  
**Component 2: The CLI Tool**  
  
Knowledge Tree provides a command-line tool called ==kt==, distributed via ==pip install knowledge-tree==. This is the primary interface for both consuming and contributing knowledge.  
  
The CLI is built with Python's Click framework for command parsing and the Rich library for beautiful terminal output. It uses tables, trees, colored output, and emoji to make the terminal experience pleasant and informative.  
  
Here are all the commands, grouped by purpose:  
  
Setup and initialization:  
- ==kt init --from <url>== — Initialize a project by connecting it to a knowledge registry. This clones the registry, creates the ==.kt/== configuration directory, and sets up the ==.knowledge/== directory where content will be materialized.  
  
Package management (consuming knowledge):  
- ==kt add <package>== — Install a knowledge package and all its dependencies. The package's content files are copied into ==.knowledge/<package>/== and the manifest is regenerated.  
- ==kt remove <package>== — Uninstall a package. Removes its files from ==.knowledge/== and updates the configuration.  
- ==kt update== — Pull the latest version of the registry and re-materialize all installed packages with the newest content. This is how you get updates when someone contributes new knowledge.  
  
Discovery and information:  
- ==kt list== — Show all installed packages in a formatted table with name, description, classification, and git ref.  
- ==kt list --available== — Show all packages in the registry, indicating which ones are already installed.  
- ==kt search <query>== — Search packages by name, description, or tags. Returns matching packages in a formatted table.  
- ==kt tree== — Display a visual tree of all packages and their parent-child relationships, using Rich's tree rendering.  
- ==kt info <package>== — Show detailed information about a specific package, including its dependencies, tags, children, and content files.  
- ==kt status== — Show project-level statistics: how many packages are installed, how many are available, total knowledge files, total lines of content, and telemetry status.  
  
Quality and validation:  
- ==kt validate <path>== — Validate a package directory. Checks that ==package.yaml== exists and is valid, all referenced content files exist, the package name follows conventions, and content is within size guidelines.  
  
**Component 3: Local Project Integration**  
  
When you run ==kt add==, the knowledge files are "materialized" — copied from the registry cache into a ==.knowledge/== directory in your project. The AI agent reads these files directly. A ==KNOWLEDGE_MANIFEST.md== file is auto-generated that gives the agent an overview of all installed knowledge.  
  
```
my-project/
├── .kt/
│   ├── kt.yaml               # What packages are installed, which registry
│   └── registry_cache/       # Cached shallow clone of the registry
├── .knowledge/
│   ├── KNOWLEDGE_MANIFEST.md  # Auto-generated overview for AI agents
│   ├── base/
│   │   ├── safe-deletion.md
│   │   └── file-management.md
│   └── acme-services/
│       ├── service-access.md
│       └── authentication.md

```
  
  
The ==.knowledge/== directory is committed to git (like vendored dependencies), so the knowledge is always available — even without ==kt== installed. This is important because AI agents need to read these files directly from the repository.  
  
The ==.kt/== directory contains the configuration and the registry cache. The registry cache is a shallow git clone (depth 1) of the central registry, which keeps it small and fast to clone. The ==kt.yaml== file tracks which registry URL to use, which branch to track, and which packages are installed with their git refs.  
  
### The Onboarding Experience  
  
Here's what it looks like for a new developer joining a team that uses Knowledge Tree:  
  
Step 1: Install the tool.  
```
pip install knowledge-tree

```
  
  
Step 2: Initialize their project.  
```
cd my-project
kt init --from git@gitlab.example.com:team/kt-registry.git

```
  
  
The CLI outputs:  
```
Initializing Knowledge Tree...
  Registry: git@gitlab.example.com:team/kt-registry.git
  Branch:   main

✓ Initialized successfully!
  Config:   .kt/kt.yaml
  Packages available: 42

Evergreen packages available:
  🌲 base — Universal agent conventions
  🌲 acme-services — Internal service access patterns
  🌲 python-be3 — BE3 Python coding standards

Seasonal packages (4 available — use 'kt list --available' to see all)

Next: run 'kt add <package>' to install knowledge packages.

```
  
  
Step 3: Add the packages they need.  
```
kt add acme-services

```
  
  
The CLI outputs:  
```
Adding package 'acme-services'...
  ✓ Installed: base (dependency)
  ✓ Installed: acme-services

✓ 2 package(s) installed.

```
  
  
Notice that ==base== was automatically installed because ==acme-services== depends on it. The developer didn't have to know about this dependency — it was resolved automatically.  
  
Step 4: The AI agent now has context. The next time the developer opens their IDE and starts an AI agent session, the agent reads the ==KNOWLEDGE_MANIFEST.md== and the knowledge files in ==.knowledge/==. It now knows about safe deletion practices, file management conventions, internal service access patterns, and authentication methods — all without the developer having to explain anything.  
⸻  
⸻  
## Part 3: Key Design Decisions — Why It Works This Way  
  
This section explains the seven most important design decisions in Knowledge Tree, including the alternatives that were considered and why each decision was made.  
  
### Decision 1: Knowledge Packages, Not Tree Nodes  
  
The original design centered on a strict tree hierarchy where every piece of knowledge was a "node" in a tree, and every node had to have a parent. After extensive reflection, this was changed to a more flexible package model.  
  
The problem with a strict tree is that it forces artificial hierarchy. Not all knowledge fits neatly into a parent-child relationship. For example, "AWS authentication patterns" could logically be a child of "AWS" or a child of "authentication" — forcing it into one place creates an arbitrary organizational decision that different people would make differently.  
  
Instead, Knowledge Tree uses **packages** — self-contained units that can optionally declare three types of relationships:  
  
- A ==parent== field creates a tree structure for organizational purposes. This is optional. A package without a parent is a root-level package.  
- A ==depends_on== field declares that one package requires another. This is functional — if you install a package, its dependencies are automatically installed too.  
- A ==suggests== field recommends companion packages. This is advisory — the CLI shows suggestions but doesn't auto-install them.  
  
This is more like pip packages or npm modules than a rigid tree. Packages CAN form a tree (via ==parent==), but they can also be flat (no parent), or form a directed acyclic graph (via ==depends_on==). This flexibility means the system works for small teams with 5 packages and large organizations with 500.  
  
The practical impact is significant. When a new contributor wants to add knowledge, they don't have to figure out where it fits in a tree. They create a package, optionally declare relationships, and submit it. The organizational structure emerges organically rather than being imposed top-down.  
  
### Decision 2: Evergreen vs. Seasonal Classification  
  
Every package is classified as either **Evergreen** or **Seasonal**. This is one of the most important design decisions in the entire system because it directly addresses the unbounded growth problem identified in the git-vs-knowledge-tree analysis.  
  
**Evergreen** packages (🌲) contain stable, well-established knowledge. They're recommended by default when a user initializes a project. Examples include: coding conventions that have been used for years, authentication patterns that are unlikely to change, deployment guides for established infrastructure, and universal best practices like safe file deletion.  
  
**Seasonal** packages (🍂) contain experimental or temporary knowledge. They're opt-in — shown in the registry but not recommended by default. Examples include: a guide for a new framework the team is evaluating, a migration guide that will be obsolete once the migration is complete, a workaround for a bug that will be fixed in the next release, or experimental patterns that haven't been validated yet.  
  
The naming comes from the tree metaphor, which is central to the project's identity. Evergreen trees keep their leaves year-round — they're always present, always relevant. Deciduous trees lose their leaves seasonally — they come and go with the seasons. This metaphor was chosen over several alternatives that were considered:  
  
- "Foundation / Experimental" — too engineering-jargon  
- "Stable / Incubating" — too software-lifecycle-specific  
- "Standard / Custom" — too enterprise-sounding  
- "Shared / Personal" — implies ownership rather than stability  
- "Canonical / Draft" — too publishing-oriented  
  
"Evergreen / Seasonal" won because it matches the tree metaphor perfectly, is intuitive to non-technical users, and accurately describes the lifecycle of knowledge.  
  
The classification serves a critical function for managing scale. When a registry has 50 packages, a new user shouldn't have to evaluate all 50 to decide which ones to install. The evergreen classification acts as a curated recommendation — "these are the packages most people should have." Seasonal packages are there for people who need them, but they don't clutter the default experience.  
  
Over time, the best seasonal packages get promoted to evergreen as they prove their value. Seasonal packages that become obsolete can be deprecated or removed. This creates a natural lifecycle for knowledge that prevents the registry from becoming a graveyard of outdated content.  
  
### Decision 3: Git-Native, Provider-Agnostic  
  
A critical design decision was to make Knowledge Tree work with **any git host** — not just GitLab, not just GitHub, not just Bitbucket. The tool uses standard git operations (clone, pull, push) and never calls provider-specific APIs for its core functionality.  
  
This decision was driven by several factors:  
  
1. **No vendor lock-in.** Organizations change git providers. A tool that only works with GitLab becomes useless if the organization moves to GitHub. By using standard git, Knowledge Tree works everywhere.  
  
2. **No API tokens needed.** Provider-specific APIs require authentication tokens, which add setup friction and security concerns. Standard git operations use whatever authentication the user already has configured (SSH keys, credential helpers).  
  
3. **Simpler implementation.** Each git provider has a different API with different authentication, pagination, rate limiting, and error handling. By avoiding all of them, the codebase stays simple and maintainable.  
  
4. **Works with self-hosted git.** Many enterprises use self-hosted GitLab or Gitea instances. Provider-specific APIs might not be available or might have different versions. Standard git works with any server that speaks the git protocol.  
  
The only provider-specific feature is a convenience: generating merge request URLs. When you contribute knowledge and push a branch, ==kt== detects whether you're using GitLab, GitHub, or Bitbucket from the remote URL and generates the appropriate URL for creating a merge request in the web UI. If the provider can't be detected, it falls back to a generic message telling you to create a merge request manually.  
  
The git abstraction layer in the codebase uses Python's ==subprocess== module to call git commands directly, rather than using a library like GitPython. This was another deliberate choice — subprocess is simpler, has no dependencies, and makes it obvious exactly what git commands are being run.  
  
### Decision 4: Automatic Dependency Resolution  
  
When you install a package, its dependencies are automatically resolved and installed. For example, if ==acme-services== declares ==depends_on: [base]==, running ==kt add acme-services== will install both ==base== and ==acme-services==.  
  
Dependencies are resolved transitively. If package A depends on B, and B depends on C, installing A will install all three in the correct order (C first, then B, then A). The resolution algorithm walks the dependency graph depth-first, tracking visited nodes to avoid cycles, and produces a flat installation order.  
  
The resolution is flat, like pip, not nested like npm. This means there's only one copy of each package, regardless of how many other packages depend on it. This keeps the ==.knowledge/== directory simple and avoids deeply nested duplicate content.  
  
Circular dependencies are detected and reported as validation errors. The dependency resolution algorithm handles this gracefully by tracking visited nodes.  
  
### Decision 5: The Agent Integration Contract  
  
The most important design decision is how AI agents actually consume the knowledge. This was extensively debated during the design phase, with three options considered:  
  
**Option A: File-based (like LegacyTool).** Knowledge files are copied to ==.knowledge/== and the agent's rules simply say "read files in ==.knowledge/== for context." This is simple but doesn't scale — if a user installs 20 packages with 100 files totaling 50,000 tokens, most agents can't consume that all at once.  
  
**Option B: Manifest-based.** A single ==KNOWLEDGE_MANIFEST.md== file is auto-generated that summarizes all installed packages. The agent reads the manifest first to understand what knowledge is available, then reads specific files on demand. This scales better because the manifest is a compact table of contents.  
  
**Option C: Agent-aware CLI.** A ==kt context== command outputs a single concatenated document optimized for AI consumption, with a token budget: ==kt context --max-tokens 10000==. This would prioritize the most relevant content and truncate the rest.  
  
Knowledge Tree implements **Option B** (manifest-based) as the primary integration, with Option C planned for a future release. The manifest approach was chosen because:  
  
1. It works with any AI agent framework — the manifest is just a markdown file that any agent can read  
2. It gives the agent agency — the agent decides which files to read based on the current task  
3. It scales naturally — the manifest stays small even as the number of packages grows  
4. It's transparent — developers can read the manifest themselves to understand what knowledge is available  
  
The manifest is regenerated every time packages are added, removed, or updated. It includes the package name, description, classification (with emoji: 🌲 for evergreen, 🍂 for seasonal), and a list of content files with their line counts. This gives the agent enough information to decide which files are relevant to the current task.  
  
### Decision 6: Committed Knowledge (Not Gitignored)  
  
The ==.knowledge/== directory is committed to the project's git repository, not gitignored. This was a deliberate choice with significant implications.  
  
The alternative — gitignoring ==.knowledge/== like ==node_modules/== — would mean the knowledge files are only present when ==kt== is installed and ==kt add== has been run. This creates a bootstrap problem: the AI agent needs the knowledge files to be present in the repo, but they're only present if the developer has run the right commands.  
  
By committing ==.knowledge/==, the knowledge is always available:  
  
- **Portability:** The project works without ==kt== installed. A developer can clone the repo and the AI agent immediately has context, even if they've never heard of Knowledge Tree.  
- **Visibility:** Changes to knowledge are visible in code review. When someone runs ==kt update== and the knowledge files change, those changes appear in the git diff. This is a feature — it means knowledge changes are reviewed just like code changes.  
- **Reliability:** There's no risk of the knowledge being out of sync with what the developer expects. The files in the repo are the files the agent reads.  
- **Size impact:** Knowledge files are markdown — they're tiny compared to code. Even 20 packages with 100 files might total 50KB. This is negligible in any git repository.  
  
The tradeoff is that ==kt update== creates diffs in the consuming project's git history. For teams with many packages that update frequently, this could be noisy. However, in practice, knowledge doesn't change as frequently as code, so this is rarely a problem.  
  
### Decision 7: Git Refs Instead of Semver  
  
The design document originally specified semver versioning for packages (e.g., ==version: "1.2.0"==). During implementation, this was changed to git refs (commit hashes).  
  
The reasoning: knowledge doesn't have "breaking changes" in the same way software APIs do. When you update a knowledge file, you're adding or refining information — you're not changing a function signature that other code depends on. Semver implies a contract (major = breaking, minor = feature, patch = fix) that doesn't map well to knowledge content.  
  
Git refs are simpler and more honest. When you install a package, the ==kt.yaml== records the git commit hash of the registry at that point. When you run ==kt update==, it pulls the latest commit and re-materializes everything. There's no version comparison, no range resolution, no compatibility matrix — just "you have this commit, the latest is that commit, do you want to update?"  
  
This also avoids the overhead of maintaining version numbers. Contributors don't have to decide whether their change is a "major" or "minor" update to a knowledge file. They just make the change, and the git history tracks what changed and when.  
⸻  
⸻  
## Part 4: The Data Model — How Knowledge Is Structured  
  
### Package Metadata (package.yaml)  
  
Every knowledge package has a ==package.yaml== file that describes it:  
  
```
name: "cloud-aws"                    # Unique identifier, kebab-case
description: "AWS patterns for BE3"  # Human-readable description
authors:                             # Who created/maintains this
  - "kbisla"
  - "jdoe"
classification: "evergreen"          # "evergreen" or "seasonal"

# Relationships
parent: "cloud"                      # Organizational parent (optional)
depends_on:                          # Required packages (optional)
  - "auth-basics"
suggests:                            # Recommended companions (optional)
  - "cloud-gcp"

# Discovery
tags:                                # For search and filtering
  - "cloud"
  - "aws"
  - "infrastructure"

# Content files (order matters — first file is the overview)
content:
  - aws-overview.md
  - aws-iam-patterns.md
  - aws-deployment.md

```
  
  
### Knowledge Content (Markdown with Frontmatter)  
  
Each knowledge file is markdown with optional YAML frontmatter:  
  
```
---
title: "AWS IAM Patterns"
summary: "Common IAM patterns for service accounts"
author: "kbisla"
tags: ["aws", "iam", "security"]
---

# AWS IAM Patterns

## Service Account Setup
When creating service accounts for microservices...

```
  
  
Content is written for AI consumption, not human reading. This means it should be:  
- Precise and actionable (instructions, not prose)  
- Example-rich (code snippets, config examples, commands)  
- Context-aware (state when something applies and when it doesn't)  
- Self-contained (each file useful on its own)  
- Concise (AI context windows are limited)  
  
### Size Guidelines  
  
To keep packages manageable:  
- Individual files: maximum 500 lines (soft limit)  
- Package total: maximum 2,000 lines across all files (soft limit)  
- If a package grows too large, split it into sub-packages  
  
### Registry Index (registry.yaml)  
  
The ==registry.yaml== at the registry root is an index of all packages. It enables fast lookups without scanning the filesystem:  
  
```
packages:
  base:
    description: "Universal agent conventions"
    classification: evergreen
    tags: [conventions, safety, universal]
    path: packages/base
  git-conventions:
    description: "Git commit message conventions"
    classification: evergreen
    parent: base
    path: packages/git-conventions

```
  
  
This file can be auto-generated by scanning all ==package.yaml== files, or maintained manually.  
  
### Project Configuration (kt.yaml)  
  
Each project that uses Knowledge Tree has a ==.kt/kt.yaml== file:  
  
```
registry: "git@gitlab.example.com:team/kt-registry.git"
registry_ref: "main"
packages:
  - name: base
    ref: "abc123f"    # Git commit hash when installed
  - name: cloud-aws
    ref: "abc123f"
telemetry:
  enabled: false
  anonymous_id: "a1b2c3d4"

```
  
  
Packages are pinned to git commit refs (not semver versions). This was a deliberate choice — knowledge doesn't have "breaking changes" like software APIs do, and git refs are simpler and more honest than semver for this use case.  
⸻  
## Part 5: The Contribution Workflow — How Knowledge Grows  
  
### The Crowdsourcing Model  
  
Knowledge Tree is designed for crowdsourced growth. The workflow mirrors how open-source software contributions work. This is deliberate — the open-source model has proven to be the most successful way to build and maintain large bodies of knowledge collaboratively.  
  
Here's the full contribution lifecycle:  
  
**Step 1: Someone has useful knowledge.** This is the trigger. Maybe a developer figured out a tricky AWS IAM configuration after hours of debugging. Maybe a team lead documented a convention that keeps getting forgotten. Maybe someone wrote a great Slack message explaining how the internal service mesh works. The knowledge exists — it just needs to be captured.  
  
**Step 2: They package it using ==kt contribute==.** The ==kt contribute== command takes a markdown file (or a directory of files) and turns it into a proper knowledge package. It generates the ==package.yaml== manifest, prompts for metadata (description, tags, classification), and creates the correct directory structure. The goal is to make this step take less than 60 seconds.  
  
There are several contribution types:  
- **Add to an existing package:** ==kt contribute --to cloud-aws my-notes.md== — adds a new file to an existing package  
- **Create a new package:** ==kt contribute --new my-package/== — creates a brand new package from a directory  
- **Update existing content:** ==kt contribute --update cloud-aws/aws-setup.md== — updates a specific file in an existing package  
- **Promote classification:** ==kt promote cloud-experimental== — changes a package from seasonal to evergreen  
  
**Step 3: They submit it for review.** The ==kt contribute== command creates a git branch (named something like ==contribute/cloud-aws-update==), commits the changes, and pushes the branch to the registry's remote. It then prints a URL for creating a merge request on the git host. The contributor clicks the URL, fills in a description, and submits the merge request.  
  
**Step 4: Maintainers review it.** This is where quality control happens. Maintainers review the merge request just like they would review a code change. They check:  
- Is the content accurate and up-to-date?  
- Is it in the right package, or should it be in a different one?  
- Should it be classified as evergreen or seasonal?  
- Does it follow the content guidelines (actionable, example-rich, concise)?  
- Are there any conflicts with existing knowledge?  
  
The CI/CD pipeline also runs automated validation checks on the merge request.  
  
**Step 5: It gets merged.** Once approved, the merge request is merged into the main branch. The CI pipeline automatically rebuilds the ==registry.yaml== index. The next time any user runs ==kt update==, they get the new knowledge.  
  
### Quality Gates (CI/CD Validation)  
  
The central registry should have CI/CD that validates every contribution automatically. The ==kt validate== command is designed to be run in CI pipelines. Here's what it checks:  
  
**Structural validation:**  
- ==package.yaml== exists and is valid YAML  
- All required fields are present (name, description, authors, classification)  
- Package name follows kebab-case convention (lowercase, alphanumeric, hyphens only)  
- All content files referenced in ==package.yaml== actually exist on disk  
- No markdown files exist in the package directory that aren't listed in ==package.yaml==  
  
**Relationship validation:**  
- No circular dependencies (A depends on B depends on A)  
- All referenced dependencies actually exist in the registry  
- Parent packages (if declared) exist in the registry  
  
**Content validation:**  
- Individual files don't exceed 500 lines (soft limit, generates a warning)  
- Package total doesn't exceed 2,000 lines (soft limit, generates a warning)  
  
**Registry validation:**  
- ==registry.yaml== is consistent with the actual package directories  
- No duplicate package names  
- All paths in ==registry.yaml== point to existing directories  
  
### The Biggest Risk and How to Mitigate It  
  
The biggest risk for Knowledge Tree is **not getting contributions**. The system is only valuable if people contribute knowledge. Every knowledge management system in history has faced this challenge, and most have failed.  
  
Here are the specific mitigation strategies:  
  
1. **Make contributing trivially easy.** The ==kt contribute== command should take a markdown file and turn it into a proper package in under 60 seconds. If it takes longer than that, people won't do it. The command should handle all the boilerplate — generating ==package.yaml==, creating the directory structure, committing, pushing, and generating the merge request URL.  
  
2. **Lower the quality bar initially.** Accept seasonal packages freely. Don't require perfect formatting, comprehensive metadata, or polished prose. The goal is to get knowledge into the system. It can be refined later. A rough seasonal package is infinitely more valuable than knowledge that stays in someone's head.  
  
3. **Lead by example.** Seed the registry with high-quality packages that demonstrate the value. When people see that the AI agent is noticeably better with knowledge packages, they'll want to contribute their own. The three seed packages (base, git-conventions, acme-services) serve this purpose.  
  
4. **Integrate into existing workflows.** Make it easy to turn existing content into knowledge packages. If someone writes a great Slack message, it should be easy to capture it. If there's a useful Confluence page, it should be easy to convert it. The ==kt contribute== command should accept raw markdown and handle the packaging.  
  
5. **Celebrate contributions.** Show contributor names in package metadata. Acknowledge contributions in team meetings. Create a leaderboard of top contributors. Social recognition is a powerful motivator.  
  
6. **Make the value visible.** When an AI agent uses knowledge from a package, it should be obvious. The manifest shows which packages are installed. Over time, developers will notice that projects with more knowledge packages produce better AI output, and they'll want to contribute to that improvement.  
⸻  
## Part 6: What's Been Built (Phase 1 — Complete)  
  
Phase 1 focused on the consumer experience — making it easy to install and use knowledge packages. The goal was to build a working end-to-end system that a developer could use to install knowledge into their project and have their AI agent benefit from it immediately. Here's a detailed breakdown of everything that was built.  
  
### The CLI Tool (cli.py — 491 lines)  
  
All consumer-facing commands are implemented and working. The CLI is built with Click for command parsing and Rich for terminal output. Every command follows a consistent pattern: parse arguments, create an engine instance, perform the operation, display results with Rich formatting, and handle errors gracefully.  
  
The commands in detail:  
  
- ==kt init --from <url>== — Clones the registry into ==.kt/registry_cache/==, creates the ==.kt/kt.yaml== configuration file with a random anonymous telemetry ID, creates the ==.knowledge/== directory, and displays all available evergreen packages. This is the entry point for new users.  
  
- ==kt add <package>== — Resolves the package's dependency chain (transitive), checks which dependencies are already installed, materializes each new package by copying its content files from the registry cache to ==.knowledge/<package>/==, updates ==kt.yaml== with the new packages and their git refs, and regenerates the ==KNOWLEDGE_MANIFEST.md==. If the package doesn't exist, it searches for similar names and suggests alternatives.  
  
- ==kt remove <package>== — Removes the package's files from ==.knowledge/<package>/==, removes it from ==kt.yaml==, and regenerates the manifest. Note: it does not remove packages that were installed as dependencies — this is a deliberate choice to avoid accidentally breaking other packages that depend on them.  
  
- ==kt list== / ==kt list --available== — Displays packages in Rich tables with columns for name, description, classification (with emoji), tags, and installation status. The ==--available== flag shows all registry packages; without it, only installed packages are shown.  
  
- ==kt search <query>== — Searches package names, descriptions, and tags for the query string (case-insensitive). Returns results in a Rich table showing whether each result is already installed.  
  
- ==kt tree== — Builds a visual tree using Rich's Tree widget. Root packages (those with no parent) are shown at the top level, and children are nested underneath. Each node shows the classification emoji, package name, installation status, and description.  
  
- ==kt update== — Pulls the latest registry (git fetch + checkout + pull), re-materializes all installed packages with the newest content, updates git refs in ==kt.yaml==, and reports any new evergreen packages that have been added to the registry since the last update.  
  
- ==kt status== — Counts installed packages, available packages, total knowledge files, and total lines of content. Displays registry URL, branch, and telemetry status.  
  
- ==kt info <package>== — Shows detailed information: description, classification, parent, tags, dependencies, children, and (if installed) a list of content files with line counts.  
  
- ==kt validate <path>== — Runs all validation checks on a package directory and reports errors and warnings. Warnings (like size limits) don't cause a non-zero exit code; real errors do.  
  
### The Data Model (models.py — 340 lines)  
  
Four core data classes, all using Python dataclasses with YAML serialization via ruamel.yaml:  
  
**PackageMetadata** — Represents the contents of a ==package.yaml== file. Fields: name, description, authors, classification, tags, parent, depends_on, suggests, audience, content, created, updated. Has a ==validate()== method that checks for required fields, valid package name format (kebab-case regex), valid classification values, and at least one author. Can be loaded from and saved to YAML files.  
  
**RegistryEntry** — A lightweight representation of a package in the registry index. Contains the essential fields needed for search and dependency resolution without loading the full package metadata. Used in ==registry.yaml==.  
  
**Registry** — The full registry index. Contains a dictionary of RegistryEntry objects. Has methods for: searching by name/description/tags, getting children of a package, resolving transitive dependency chains, and rebuilding the index by scanning all ==package.yaml== files in a packages directory. The ==rebuild_from_packages()== method walks the packages directory, loads each ==package.yaml==, and creates corresponding registry entries.  
  
**ProjectConfig** — The project's ==kt.yaml== configuration. Tracks the registry URL, branch, installed packages (as InstalledPackage objects with name and git ref), and telemetry settings. Has methods for adding and removing packages.  
  
**InstalledPackage** — A simple data class tracking a package name and its git ref (the commit hash of the registry when the package was installed).  
  
### The Engine (engine.py — 405 lines)  
  
The ==KnowledgeTreeEngine== class is the core of the system. It orchestrates all operations by coordinating between the data model, git operations, and the filesystem.  
  
Key methods:  
  
- ==init()== — Creates directories, clones the registry (shallow clone, depth 1), generates a random telemetry ID, and saves the initial configuration.  
  
- ==add_package()== — The most complex operation. Loads config and registry, validates the package exists (with fuzzy suggestions if not), resolves the full dependency chain, skips already-installed packages, materializes each new package, updates config, and regenerates the manifest.  
  
- ==_materialize_package()== — Copies content files from the registry cache to ==.knowledge/<name>/==. Loads the package's ==package.yaml== to get the content file list. If no content list is specified, falls back to copying all ==.md== files. Removes any existing materialized files first (clean re-materialization).  
  
- ==_generate_manifest()== — Creates the ==KNOWLEDGE_MANIFEST.md== file. Iterates over installed packages, looks up their registry entries for descriptions and classifications, lists all content files with line counts, and writes the result as a formatted markdown document with a timestamp.  
  
- ==update()== — Pulls the latest registry, re-materializes all installed packages, updates git refs, and identifies new evergreen packages that weren't available before.  
  
- ==validate_package()== — Runs comprehensive validation on a package directory, checking metadata, content files, and size limits.  
  
### Git Operations (git_ops.py — 161 lines)  
  
A clean abstraction layer over git commands using Python's subprocess module. Every function calls ==git== directly via subprocess, with a 120-second timeout and proper error handling.  
  
Key functions:  
  
- ==clone()== — Clones a repository with configurable branch and depth. Uses shallow clones (depth 1) by default for speed.  
- ==pull()== — Fetches, checks out, and pulls a specific branch. Returns the new HEAD commit hash.  
- ==get_head_ref()== / ==get_short_ref()== — Gets the current commit hash (full or short).  
- ==is_git_repo()== — Checks if a directory is a git repository.  
- ==create_branch()== / ==push_branch()== — For the contribution workflow (Phase 2).  
- ==add_and_commit()== — Stages files and commits with a message.  
- ==detect_provider()== — Detects GitLab, GitHub, or Bitbucket from a remote URL.  
- ==get_mr_url()== — Generates a merge/pull request URL for a given branch, specific to the detected provider.  
- ==_remote_to_web_url()== — Converts SSH or HTTPS git remote URLs to web URLs (handles both ==git@host:org/repo.git== and ==https://host/org/repo.git== formats).  
  
### Sample Registry  
  
A working sample registry in ==workspace/sample-registry/== with three seed packages that demonstrate the system:  
  
**base** — Universal agent conventions. Contains two knowledge files: ==safe-deletion.md== (always use ==trash== instead of ==rm==) and ==file-management.md== (keep temporary files in ==temp_files/== directory). Classified as evergreen. No parent, no dependencies. This is the foundational package that most other packages depend on.  
  
**git-conventions** — Git commit message format and branching conventions. Contains one knowledge file: ==commit-messages.md==. Classified as evergreen. Declares ==base== as its parent (organizational relationship). This demonstrates the parent-child hierarchy.  
  
**acme-services** — Acme Corp. internal services. Contains two knowledge files: ==service-access.md== (how to access Glean, JIRA, Confluence, GitLab) and ==authentication.md== (token management, SSH keys). Classified as evergreen. Declares ==base== as a dependency (functional relationship). This demonstrates the dependency system — installing ==acme-services== automatically installs ==base==.  
  
### Test Suite  
  
52 tests passing across two test files, using pytest with fixtures that create temporary directories and mock git repositories:  
  
**test_models.py** — Tests for all data model classes: PackageMetadata validation (valid names, invalid names, missing fields, classification values), Registry operations (loading from YAML, searching, dependency chain resolution, child lookup, rebuild from packages), ProjectConfig operations (loading, saving, adding/removing packages), and YAML serialization round-trips.  
  
**test_engine.py** — Tests for the KnowledgeTreeEngine: initialization, adding packages with dependency resolution, removing packages, updating packages, listing installed and available packages, searching, status reporting, manifest generation, and validation. Uses a conftest.py that creates temporary registry structures for testing.  
⸻  
## Part 7: What's Next (Phase 2 and Beyond)  
  
### Phase 2: Contribution (Not Yet Started)  
  
The next phase focuses on enabling crowdsourced growth. This is the most critical phase because without contributions, the knowledge base stagnates and the tool loses its value.  
  
**==kt contribute== command** — This is the centerpiece of Phase 2. It needs to handle several workflows:  
- Taking a raw markdown file and packaging it into a proper knowledge package with generated ==package.yaml==  
- Adding content to an existing package  
- Creating a git branch, committing the changes, and pushing to the registry remote  
- Generating a merge request URL for the user's git provider  
- A key technical challenge: the registry cache in ==.kt/registry_cache/== is a shallow clone (depth 1), which cannot push. The ==kt contribute== command will need to either do a full clone of the registry into a temporary directory, or unshallow the existing cache before pushing.  
  
**CI templates** — Pre-built CI configuration files for the major git providers:  
- ==.gitlab-ci.yml== for GitLab CI — runs ==kt validate --all== on merge requests  
- ==.github/workflows/validate.yml== for GitHub Actions — same validation  
- ==bitbucket-pipelines.yml== for Bitbucket Pipelines — same validation  
- These templates should also auto-rebuild ==registry.yaml== after merges to main  
  
**==kt registry rebuild==** — A CLI command that scans all ==package.yaml== files in the packages directory and regenerates ==registry.yaml==. The ==Registry.rebuild_from_packages()== method already exists in the data model — this command just needs to expose it via the CLI. This is important for CI pipelines that need to keep the registry index in sync with the actual packages.  
  
**CONTRIBUTING.md template** — A guide for new contributors that explains: how to structure a knowledge package, what makes good AI-consumable content, how to choose between evergreen and seasonal classification, and the merge request review process.  
  
### Phase 3: Discovery and Polish  
  
Making it easy to find the right knowledge becomes important as the registry grows beyond 10-20 packages.  
  
**Enhanced search** — The current search is simple string matching on names, descriptions, and tags. Future improvements could include: fuzzy matching (finding "aws" when searching for "amazon"), relevance ranking (exact name matches ranked higher than tag matches), and potentially semantic search using embeddings (finding packages about "cloud infrastructure" when searching for "deployment").  
  
**Better tree visualization** — The current ==kt tree== command shows the parent-child hierarchy. Improvements could include: showing dependency relationships alongside parent relationships, filtering by classification, highlighting recently updated packages, and showing package sizes.  
  
**Depth selection** — The ==--depth N== flag for selective install was in the original design but deferred. The concept is that depth controls how many files from a package are installed: depth 1 = only the overview file, depth 2 = overview + second-level files, etc. This requires content files to be ordered by importance in ==package.yaml==, which they already are (first file is the overview).  
  
**Evergreen/seasonal filtering** — Better filtering in ==kt list== and ==kt search== to show only evergreen packages, only seasonal packages, or both. Currently, the classification is shown but not filterable.  
  
### Phase 4: Telemetry and Adoption  
  
Understanding how the tool is being used is important for justifying continued investment and identifying which knowledge is most valuable.  
  
**Local telemetry** — Track usage data locally in ==~/.kt/telemetry.yaml==. This would record: which commands are run and how often, which packages are installed across projects, when ==kt update== is run, and basic system information (OS, Python version). This data stays on the user's machine unless they choose to share it.  
  
**Adoption reporting** — A script or command that aggregates telemetry data for reporting. This could produce metrics like: number of active users, most popular packages, update frequency, and adoption trends over time.  
  
**Package popularity metrics** — Understanding which packages are most installed helps prioritize maintenance and identify gaps. This could be implemented as a simple counter in the registry, or as an aggregation of local telemetry data.  
  
### Future Vision  
  
These are longer-term possibilities that are not yet planned but represent the direction the project could evolve:  
  
**Web UI** — A browser-based tree explorer with progressive reveal. Users could browse the knowledge tree, expand/collapse nodes, select packages, and generate a ==kt.yaml== configuration file. This would make the system accessible to non-CLI users and provide a visual overview of the entire knowledge base.  
  
**Backstage plugin** — Integration with Spotify's Backstage developer portal. Since Acme Corp. uses Backstage, a plugin could show the knowledge tree in the Backstage catalog, let users browse and select packages via web UI, display telemetry dashboards, and integrate with TechDocs for rendering knowledge content.  
  
**AI-powered search** — Semantic search across all knowledge using embeddings. Instead of keyword matching, users could search by meaning: "how do I authenticate with AWS" would find packages about IAM patterns even if they don't contain the exact word "authenticate."  
  
**Automatic knowledge extraction** — Mining knowledge from existing sources like Slack messages, Confluence pages, and code comments. An AI could identify useful patterns in these sources and suggest them as knowledge package contributions.  
  
**Multi-registry support** — Consuming packages from multiple registries simultaneously. For example, an organization might have a company-wide registry and team-specific registries. The ==kt.yaml== would list multiple registry URLs, and packages from all registries would be available.  
  
**==kt context== command** — A token-budget-aware output command for AI consumption. Instead of the agent reading individual files, ==kt context --max-tokens 10000== would output a single concatenated document that fits within the specified token budget, prioritizing the most relevant content for the current task.  
  
**Knowledge quality scoring** — Automated freshness and relevance scoring for packages. Packages that haven't been updated in a long time would be flagged as potentially stale. Packages that are rarely installed would be flagged as potentially irrelevant. This helps maintainers focus their attention on the most impactful improvements.  
  
**Package deprecation and archival** — A formal lifecycle for packages that become obsolete. A ==deprecated== classification (in addition to evergreen and seasonal) would warn users that a package is no longer maintained. Deprecated packages could be automatically excluded from search results and ==kt list --available== output.  
⸻  
⸻  
## Part 8: How Knowledge Tree Compares to Alternatives  
  
This section provides a detailed comparison between Knowledge Tree and every alternative that was evaluated during the design phase.  
  
### vs. LegacyTool (the predecessor)  
  
LegacyTool and Knowledge Tree are complementary, not competing. LegacyTool manages the full agent configuration (rules, tools, services, modes, templates, AND knowledge), while Knowledge Tree focuses exclusively on knowledge. A project could use LegacyTool for operational configuration and Knowledge Tree for knowledge content. In fact, Knowledge Tree was designed to be LegacyTool-compatible — it should be possible to use ==kt== as the knowledge backend for LegacyTool projects.  

| Aspect | LegacyTool | Knowledge Tree |
| -------------- | ---------------------------------------------- | --------------------------------- |
| Storage | Local filesystem (~/.agent-project-profiles/) | Any git repository |
| Sharing | Not shareable (single machine) | Shared via git clone/pull |
| Collaboration | Single user | Multi-user via merge requests |
| Distribution | Bash scripts, manual PATH setup | pip install knowledge-tree |
| Discovery | Must know profile names | Search, tags, browse, tree |
| Structure | Rigid tree (parent required) | Flexible (tree optional, flat OK) |
| Classification | None | Evergreen vs. Seasonal |
| Validation | None | CI/CD quality gates |
| Content scope | Everything (rules, tools, services, knowledge) | Knowledge only (focused) |
| Versioning | Git on profile store | Git refs per package |
| Updates | legacytool update (diff-based) | kt update (version-based) |
| Contribution | legacytool promote (local only) | kt contribute (creates MR/PR) |
| Git provider | N/A (local) | Any (GitLab, GitHub, Bitbucket) |
  
  
### vs. Confluence / Notion / Wikis  
  
Wikis are designed for humans to read. Knowledge Tree is designed for AI agents to consume. This fundamental difference affects everything:  
  
- **Content format:** Wikis use rich text with formatting, images, and embedded media. Knowledge Tree uses plain markdown optimized for AI parsing — concise, actionable, example-rich.  
- **Distribution:** Wikis require a browser and an account. Knowledge Tree distributes content via git and pip — it works offline, in CI/CD pipelines, and in any environment where git is available.  
- **Structure:** Wikis have pages in spaces. Knowledge Tree has packages with dependencies. Wikis don't have the concept of "installing" a subset of content into a project.  
- **Inheritance:** Wikis don't have downward inheritance. A child page in Confluence doesn't automatically "know" what its parent page says. In Knowledge Tree, installing a package automatically installs its dependencies.  
- **Quality control:** Wiki pages can be edited by anyone at any time. Knowledge Tree contributions go through a merge request review process.  
- **Versioning:** Wikis have page-level version history. Knowledge Tree has package-level versioning via git refs, with the ability to pin to specific commits.  
  
### vs. Backstage (Spotify)  
  
Backstage is the closest enterprise-grade alternative. It's a full developer portal with a software catalog, TechDocs for documentation, and a plugin ecosystem. Here's a detailed comparison:  
  
- **Infrastructure:** Backstage requires Kubernetes, PostgreSQL, and significant DevOps effort to deploy and maintain. Knowledge Tree requires only git and pip — zero infrastructure.  
- **Scope:** Backstage is a platform for everything developer-related (services, APIs, documentation, CI/CD, cloud resources). Knowledge Tree is focused exclusively on AI agent knowledge.  
- **Content model:** Backstage uses TechDocs (MkDocs-based documentation). Knowledge Tree uses knowledge packages with metadata, dependencies, and classification.  
- **Contribution model:** Backstage contributions require understanding the Backstage plugin system and React/TypeScript. Knowledge Tree contributions are just markdown files with a YAML manifest.  
- **Adoption path:** Backstage requires organizational buy-in and a dedicated team to maintain. Knowledge Tree can be adopted bottom-up by individual developers.  
  
That said, Backstage and Knowledge Tree are not mutually exclusive. A Backstage plugin could be built that renders the knowledge tree in the Backstage UI, providing a web-based browser for knowledge packages. This is listed as a future vision item.  
  
### vs. Dendron  
  
Dendron is a VS Code extension for hierarchical note-taking. It's the closest conceptual match to Knowledge Tree's hierarchical model:  
  
- **Hierarchy:** Both use hierarchical organization. Dendron uses dot-notation (e.g., ==cloud.aws.iam==) while Knowledge Tree uses kebab-case package names with optional parent declarations.  
- **Schemas:** Dendron has schemas that define the structure of notes. Knowledge Tree has ==package.yaml== manifests that define package metadata.  
- **Scope:** Dendron is designed for personal knowledge management — one person's notes. Knowledge Tree is designed for organizational knowledge distribution — many people contributing and consuming.  
- **Distribution:** Dendron vaults are local directories. Knowledge Tree packages are distributed via git registries.  
- **Collaboration:** Dendron has no built-in collaboration model. Knowledge Tree uses merge requests for contributions.  
  
### vs. Terraform Modules / Helm Charts  
  
These infrastructure-as-code tools have a similar composition model:  
  
- **Composability:** Like Terraform modules and Helm charts, Knowledge Tree packages can be composed and parameterized. You select the packages you need, and they're assembled into your project.  
- **Versioning:** Terraform modules use semver. Helm charts use semver. Knowledge Tree uses git refs (simpler, more appropriate for knowledge content).  
- **Registry:** Terraform has the Terraform Registry. Helm has Helm Hub. Knowledge Tree has a git-based registry (simpler, no hosting required).  
- **Key difference:** Terraform and Helm produce infrastructure configurations. Knowledge Tree produces AI agent context. The consumption model is fundamentally different.  
  
### The Gap Knowledge Tree Fills  
  
After evaluating all alternatives, the gap is clear. No existing system combines all of:  
  
1. **Hierarchical knowledge with optional inheritance** — packages can form trees, graphs, or be flat  
2. **Evergreen vs. seasonal classification** — managing unbounded growth with curated recommendations  
3. **Crowdsourced contribution with review workflow** — merge request-based quality control  
4. **Package-based composition with dependency resolution** — automatic transitive dependency installation  
5. **Git-native storage** — no new infrastructure, works with any git host  
6. **AI-agent-optimized content format** — markdown designed for machine consumption, not human reading  
7. **CLI-based distribution via pip** — standard Python packaging, zero-friction installation  
8. **Manifest-based agent integration** — scalable approach to feeding knowledge to AI agents  
⸻  
## Part 9: The Philosophy — Why This Matters  
  
### Knowledge Is the Bottleneck for AI Agents  
  
As AI coding agents become more capable, the bottleneck shifts. In 2023, the bottleneck was "can the AI write code at all?" By 2025, the bottleneck became "does the AI know enough about our context to write the RIGHT code?"  
  
Consider the progression:  
- **Level 1: Generic code.** The AI writes syntactically correct code that follows general best practices. This is what you get with a vanilla AI agent — no organizational context.  
- **Level 2: Framework-aware code.** The AI knows which frameworks and libraries your project uses (from reading ==requirements.txt== or ==package.json==). This is what you get with agents that analyze your project structure.  
- **Level 3: Organization-aware code.** The AI knows your team's conventions, your infrastructure patterns, your service authentication methods, and your coding standards. This is what you get with Knowledge Tree.  
- **Level 4: Task-aware code.** The AI knows not just the general patterns but the specific context of the current task — related tickets, previous implementations, architectural decisions. This is the future.  
  
Knowledge Tree moves AI agents from Level 2 to Level 3. The jump from Level 2 to Level 3 is where the most practical value lies, because organizational conventions are the things that cause the most rework when the AI gets them wrong.  
  
### The Crowdsourcing Bet  
  
The most ambitious aspect of Knowledge Tree is the crowdsourcing model. Most knowledge management systems fail because they rely on a small group of people to create and maintain all the content. This creates a bottleneck — the knowledge base grows slowly, becomes stale, and eventually gets abandoned.  
  
Knowledge Tree bets that if you make contributing easy enough and reviewing structured enough, knowledge will grow organically — just like open-source code does. This bet is based on several observations:  
  
1. **Developers already document patterns informally.** They write Slack messages, Confluence pages, code comments, and README files. The knowledge exists — it just needs a better container.  
  
2. **AI agent improvement is a strong motivator.** When developers see that their AI agent produces better code with knowledge packages, they're motivated to contribute more knowledge. This creates a positive feedback loop.  
  
3. **The seasonal classification lowers the barrier.** By allowing experimental, unpolished knowledge to enter the system as "seasonal," you remove the perfectionism barrier. Contributors don't have to worry about getting it perfect — they just need to capture the knowledge. It can be refined later.  
  
4. **The merge request model is familiar.** Every developer knows how to create a merge request. The contribution workflow doesn't require learning a new tool or process — it's the same workflow they use for code.  
  
5. **Open-source has proven the model works.** Linux, Python, Kubernetes, and thousands of other projects are maintained by communities of contributors. The key ingredients are: low friction to contribute, structured review, and visible impact. Knowledge Tree provides all three.  
  
### Build the Simplest Thing That Works  
  
The design philosophy is deliberately minimal. No database, no server, no web UI — just git and a CLI. This isn't because those things aren't valuable; it's because the core value proposition needs to be validated first.  
  
The reasoning is straightforward: if people don't contribute knowledge, no amount of infrastructure will save the project. A beautiful web UI with zero content is useless. A sophisticated search engine with nothing to search is pointless. But if people DO contribute knowledge, the infrastructure can be added incrementally — a web UI can be built later, search can be enhanced later, telemetry can be added later.  
  
The entire system is built on technologies that every engineering organization already has:  
- **Git** — for storage, versioning, and collaboration  
- **Pip** — for distribution  
- **Markdown** — for content  
- **YAML** — for metadata  
- **Python** — for the CLI tool  
  
There are no new tools to learn, no new services to deploy, no new accounts to create, no new infrastructure to maintain. A developer can go from zero to a working knowledge-enhanced AI agent in under 5 minutes: ==pip install knowledge-tree==, ==kt init==, ==kt add base==, done.  
  
This is intentional. The biggest risk is adoption, and the biggest barrier to adoption is friction. Knowledge Tree minimizes friction at every step, betting that simplicity and low friction will drive adoption, and adoption will drive contributions, and contributions will drive value, and value will justify future investment in more sophisticated infrastructure.  
  
### The Relationship Between Knowledge Tree and LegacyTool  
  
Knowledge Tree and LegacyTool are designed to coexist, not compete. They serve different purposes:  
  
- **LegacyTool** manages the full agent configuration: rules (behavioral instructions), modes (operating modes like architect, code, debug), tools (custom tool definitions), services (integration configurations), templates (boilerplate), AND knowledge.  
- **Knowledge Tree** manages knowledge only: domain-specific information that helps AI agents understand organizational context.  
  
The vision is that Acme Corp's knowledge layer could eventually be replaced by Knowledge Tree. LegacyTool's ==knowledge/== directory would become ==.knowledge/== managed by ==kt==. LegacyTool's ==promote== command maps to ==kt contribute==. LegacyTool's ==update== command maps to ==kt update==. But the two tools would remain independent — you could use Knowledge Tree without LegacyTool, and you could use LegacyTool without Knowledge Tree.  
  
### Success Metrics  
  
The project has defined concrete success metrics to track whether it's achieving its goals:  

| Metric                             | Target (3 months) | Target (6 months) |
| ---------------------------------- | ----------------- | ----------------- |
| Active users                       | 10                | 50                |
| Knowledge packages                 | 15                | 40                |
| Contributions from non-maintainers | 5 MRs             | 20 MRs            |
| Projects using kt                  | 5                 | 20                |
| Weekly kt update usage             | 50% of users      | 70% of users      |
  
  
These metrics focus on adoption and contribution — the two factors that determine whether the project succeeds or fails.  
⸻  
⸻  
## Part 10: Technical Architecture Summary  
  
### Technology Stack and Rationale  
  
Each technology choice was made deliberately, with alternatives considered:  
  
**Language: Python 3.10+**   
Python was chosen over Go, Rust, and Node.js for several reasons. Python is the lingua franca at Acme Corp. engineering — most developers can read and contribute to Python code. Pip distribution is simpler than managing binary releases (which Go or Rust would require). The tool doesn't need the performance characteristics of compiled languages — it's doing file I/O and git operations, not computation-heavy work. And Python has the richest ecosystem for YAML parsing, markdown processing, and CLI frameworks.  
  
**CLI Framework: Click (with Rich for terminal formatting)**   
Click was chosen over argparse, Typer, and Fire. Click is battle-tested, composable (commands can be grouped and nested), auto-generates help text, and has excellent documentation. Rich was added for terminal formatting — it provides tables, trees, colored output, progress bars, and emoji support that make the CLI experience pleasant and informative.  
  
**YAML Parsing: ruamel.yaml**   
ruamel.yaml was chosen over PyYAML because it preserves comments and formatting when reading and writing YAML files. This matters because knowledge packages are human-edited — if ==kt== rewrites a ==package.yaml== file, it should preserve the author's comments and formatting, not strip them out.  
  
**Git Operations: subprocess**   
Python's subprocess module was chosen over GitPython (a popular Python git library). The reasoning: subprocess is simpler, has zero dependencies, makes it obvious exactly what git commands are being run (important for debugging), and avoids the complexity of GitPython's object model. The tradeoff is less Pythonic code, but for the simple git operations Knowledge Tree needs (clone, pull, push, branch), subprocess is more than adequate.  
  
**Packaging: setuptools with pyproject.toml**   
Standard Python packaging using the modern ==pyproject.toml== format. This allows distribution via PyPI (==pip install knowledge-tree==) and direct installation from git (==pip install git+https://...==). The ==kt== command is registered as a console script entry point.  
  
**Testing: pytest with temporary directory fixtures**   
pytest was chosen for its simplicity, fixture system, and rich plugin ecosystem. Tests use temporary directories (via ==tmp_path== fixture) to create isolated test environments with mock registry structures. No external services or network access is needed for testing.  
  
### Architecture Diagram  
  
```
┌─────────────────────────────────────────────────────────────┐
│                    KNOWLEDGE TREE SYSTEM                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────┐         ┌──────────────────────────┐  │
│  │  Central Repo    │         │  Local Project           │  │
│  │  (Any Git Host)  │         │  (.kt/ directory)        │  │
│  │                  │  clone  │                           │  │
│  │  • packages/     │───────► │  • Selected packages     │  │
│  │  • registry.yaml │  pull   │  • kt.yaml config        │  │
│  │  • CONTRIBUTING  │ ◄────── │  • Local overrides       │  │
│  │                  │  push   │                           │  │
│  └──────────────────┘         └──────────────────────────┘  │
│           ▲                              ▲                   │
│           │ MR/PR                        │                   │
│           │                              │                   │
│  ┌──────────────────┐         ┌──────────────────────────┐  │
│  │  Contributors    │         │  CLI Tool (kt)           │  │
│  │                  │         │                           │  │
│  │  • Add packages  │         │  • kt init               │  │
│  │  • Update content│         │  • kt add / remove       │  │
│  │  • Review MRs    │         │  • kt update / status    │  │
│  │                  │         │  • kt search / tree      │  │
│  └──────────────────┘         │  • kt contribute         │  │
│                               └──────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘

```
  
  
### Code Structure  
  
The codebase is organized into four modules, each with a clear responsibility:  
  
```
src/knowledge_tree/
├── __init__.py      # Version string and package metadata
├── models.py        # Data models — 340 lines
│                    #   PackageMetadata, RegistryEntry, Registry,
│                    #   InstalledPackage, ProjectConfig
│                    #   All YAML serialization/deserialization
│                    #   Validation logic, search, dependency resolution
├── engine.py        # Core engine — 405 lines
│                    #   KnowledgeTreeEngine class
│                    #   init, add, remove, update, status, search
│                    #   Package materialization
│                    #   Manifest generation
│                    #   Registry caching
├── git_ops.py       # Git abstraction — 161 lines
│                    #   clone, pull, push, branch operations
│                    #   Provider detection (GitLab/GitHub/Bitbucket)
│                    #   MR/PR URL generation
│                    #   Remote URL parsing
└── cli.py           # CLI interface — 491 lines
                     #   Click command group with 10 commands
                     #   Rich formatting (tables, trees, colors)
                     #   Error handling and user-facing messages

```
  
  
Total: approximately 1,400 lines of production code, plus approximately 800 lines of tests.  
  
### Data Flow  
  
Here's the complete data flow for each major operation:  
  
**1. Init Flow:**  
```
User runs: kt init --from git@host:org/registry.git
  → Engine creates .kt/ directory
  → Engine creates .knowledge/ directory
  → git clone --branch main --depth 1 <url> .kt/registry_cache/
  → Engine generates random telemetry ID
  → Engine saves kt.yaml with registry URL, branch, empty package list
  → CLI displays available evergreen packages

```
  
  
**2. Add Flow:**  
```
User runs: kt add acme-services
  → Engine loads kt.yaml
  → Engine loads registry.yaml from cache
  → Engine looks up "acme-services" in registry
  → If not found: search for similar names, suggest alternatives, exit
  → Engine resolves dependency chain: [base, acme-services]
  → For each package not already installed:
    → Load package.yaml from cache to get content file list
    → Create .knowledge/<name>/ directory
    → Copy each content file from cache to .knowledge/<name>/
    → Add package to kt.yaml with current git ref
  → Regenerate KNOWLEDGE_MANIFEST.md
  → Save updated kt.yaml
  → CLI displays installed packages

```
  
  
**3. Update Flow:**  
```
User runs: kt update
  → Engine loads kt.yaml
  → git fetch origin main (in registry cache)
  → git checkout main (in registry cache)
  → git pull origin main (in registry cache)
  → For each installed package:
    → Re-materialize (copy latest content files)
    → Update git ref in kt.yaml
  → Check for new evergreen packages not yet installed
  → Regenerate KNOWLEDGE_MANIFEST.md
  → Save updated kt.yaml
  → CLI displays updated packages and new available packages

```
  
  
**4. Agent Consumption Flow:**  
```
AI agent starts session in project
  → Agent reads KNOWLEDGE_MANIFEST.md
  → Manifest lists all packages with descriptions and file paths
  → Agent identifies relevant packages for current task
  → Agent reads specific .knowledge/<package>/*.md files
  → Agent incorporates knowledge into its responses

```
  
  
### Error Handling Philosophy  
  
Every error message in Knowledge Tree follows the "be helpful on failure" principle. Each error includes:  
1. **What went wrong** — a clear description of the error  
2. **Why it might have happened** — context about common causes  
3. **What to do about it** — actionable next steps  
  
For example, if a package isn't found:  
```
Error: Package 'aws-cloud' not found in registry.
Did you mean: cloud-aws, cloud-gcp?

```
  
  
If the project isn't initialized:  
```
Error: This project is not initialized with Knowledge Tree.
Run 'kt init --from <registry-url>' to get started.

```
  
⸻  
****Appendix A: Glossary****  

| Term | Definition |
| -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Knowledge Package | A self-contained unit of knowledge — a directory with a package.yaml manifest and one or more markdown content files. The atomic unit of the Knowledge Tree system. |
| Registry | A git repository that serves as the source of truth for all knowledge packages. Contains a packages/ directory and a registry.yaml index. |
| Evergreen 🌲 | A package classification meaning stable, well-established, and recommended by default. Evergreen packages are highlighted during kt init and represent curated, high-quality knowledge. |
| Seasonal 🍂 | A package classification meaning experimental, temporary, or opt-in. Seasonal packages are available but not recommended by default. They represent knowledge that may change, be replaced, or become obsolete. |
| Materialization | The process of copying knowledge files from the registry cache into the project's .knowledge/ directory. This makes the knowledge available for AI agents to read directly from the project. |
| Manifest | The auto-generated KNOWLEDGE_MANIFEST.md file that gives AI agents an overview of all installed knowledge. Acts as a table of contents that the agent reads first before diving into specific files. |
| kt.yaml | The project configuration file stored in .kt/kt.yaml. Tracks which registry to use, which branch to follow, which packages are installed (with git refs), and telemetry settings. |
| registry.yaml | The index file in the central registry that lists all available packages with their metadata. Can be auto-generated by scanning all package.yaml files. |
| package.yaml | The manifest file for a knowledge package. Contains the package name, description, authors, classification, tags, relationships (parent, depends_on, suggests), and content file list. |
| Dependency chain | The full set of packages required by a given package, resolved transitively. If A depends on B and B depends on C, the dependency chain for A is [C, B, A]. |
| Registry cache | A shallow git clone of the central registry stored in .kt/registry_cache/. Used for fast lookups and package materialization without requiring network access for every operation. |
| LegacyTool | The predecessor tool that validated the concept of hierarchical knowledge profiles for AI agents. Built as bash scripts, local-only, single-user. Knowledge Tree is its spiritual successor for the knowledge layer. |
| Contribution | The process of adding new knowledge to the registry. Involves creating a branch, committing changes, pushing, and creating a merge request for review. |
| Promote | The process of changing a package's classification from seasonal to evergreen, indicating it has proven its value and should be recommended by default. |
| Agent Integration Contract | The specification for how AI agents consume knowledge from Knowledge Tree. Currently manifest-based: agents read KNOWLEDGE_MANIFEST.md first, then specific files on demand. |
| Progressive Reveal | A UX concept for managing large knowledge bases. Instead of showing all packages at once, show top-level packages first and let users drill down. Implemented via the kt tree command and the evergreen/seasonal classification. |
  
  
## Appendix B: Open Design Questions  
  
These are questions that have been identified but not yet resolved. They represent areas where the design could evolve based on real-world usage:  
  
1. **Package deprecation:** Should there be a ==deprecated== classification in addition to evergreen and seasonal? What happens to projects that have a deprecated package installed?  
  
2. **Multi-registry support:** Should ==kt.yaml== support multiple registry URLs? How would package name conflicts be resolved across registries?  
  
3. **The ==kt context== command:** How should token budgets be allocated across packages? Should the user specify which packages to prioritize, or should the system infer relevance from the current task?  
  
4. **Content depth selection:** The ==--depth N== flag was deferred from Phase 1. Is it actually needed, or is the package-level granularity sufficient?  
  
5. **Telemetry implementation:** Should telemetry data be stored locally only, or should there be a mechanism for aggregating usage data across an organization?  
  
6. **The ==.knowledge/== commit strategy:** For teams with many packages that update frequently, should there be an option to gitignore ==.knowledge/== and treat it like ==node_modules/==?  
  
7. **Package ownership and maintenance:** Who is responsible for keeping a package up to date? Should packages have designated maintainers with special permissions?  
  
8. **Conflict resolution:** What happens when ==kt update== changes a file that the user has manually edited in ==.knowledge/==? Should there be a merge strategy, or should the update always overwrite?  
⸻  
*This document was created on 2026-02-22 as a comprehensive overview of the Knowledge Tree project. It synthesizes information from the META_PLAN.md (industry analysis and alternatives), DESIGN_v2.md (full architecture specification), PRE_BUILD_CONSIDERATIONS.md (10 pre-build decisions), and the complete Phase 1 source code implementation. It is intended for use with Google NotebookLM for audio summary generation.*  
