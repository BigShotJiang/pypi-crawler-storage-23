# Knowledge Trees vs. Git Trees: Hierarchical Knowledge Management at Scale  
  
That's the difference between a **git source code tree** and a **knowledge tree** that we are building.  
  
## Git Source Code Tree vs. Knowledge Tree  
  
In a git source code tree, the child branch — when you create an MR — the child branch is expected to eventually move its changes all the way up to dev. Changes — you can think of it as knowledge — but the child branch knowledge trickles up and eventually goes to dev and forever persists there.  
  
In the case of our **knowledge tree** solution, it has some differences from git source code management tree:  
  
- If I create a child off of a parent knowledge node, the child knows everything that the parent knows, and the grandparent, and the great-grandparent. The child knows all of that knowledge, and then some.  
- Which is fine. There is no problem so far.  
  
## The Merge Request Difference  
  
But what happens when we want to persist some new knowledge to a particular node? I create a merge request to merge this new knowledge to a particular node. Even after the merge request is accepted and approved, that knowledge almost never makes it all the way to the great-grandparent — the base node in the knowledge tree — because we are not supposed to do that. The knowledge is supposed to be hierarchical, permanently.  
  
So that's a slight difference from **source code tree** versus **knowledge tree**.  
  
## How We Update a Knowledge Tree  
  
So, is it a problem? Does it create a problem when we are updating a knowledge tree?  
  
The method of updating a knowledge tree is:  
  
1. I will create a new child node off of some node in the knowledge tree  
2. Add my new information in that node  
3. Create a merge request to merge the knowledge in this node into the parent node  
  
That merge request could be accepted or rejected. The merge request is basically a **change request**. We might be doing a change request to:  
  
- Change the structure of the knowledge tree permanently, or  
- Request to add a new node to the knowledge tree permanently  
  
That is our merge request: "Hey, update this node with this new knowledge," or "Hey, update the tree with this new node at this location."  
  
I will always say: **"Update this tree."** The update to this tree can be:  
  
- Add this knowledge to this node, or  
- Add my node to the knowledge tree, please, so that others can continue working off of that node  
  
## Scaling Concerns  
  
If the merge request is accepted, over time we can anticipate the knowledge tree to have a lot of nodes. Because there is no eventual merging happening — just like in a source code git tree — the number of nodes in this knowledge tree is expected to keep growing forever. That can be a **scaling issue**.  
  
Well, the knowledge keeps growing forever in the knowledge tree, and that is fine — adding more and more knowledge is the entire point of the knowledge base tree. But having more and more **nodes** makes it difficult.  
  
If there is a very large number of nodes, it makes it very difficult when starting up a new project and I have to decide: "Hey, what knowledge do you want to port over into your new project?" And the number of nodes is very huge — it becomes a problem to choose which ones I want.  
  
## Progressive Reveal Solution  
  
It can be simplified. We can present the entire tree structure, but it has to be **progressively revealed**. Otherwise, it can be information overload and very difficult to select which knowledge I want to have in my project.  
  
Over time, let's say the tree is huge and it has 1,000+ nodes in various formats. What am I expecting the user to do — go through all 1,000 nodes and select or deselect?  
  
What if I want to have all the knowledge and I don't really want to constrain myself? Like, "Give me all the knowledge in BE3." That can be an operation — it can be a tree-looking thing. You put a checkmark on BE3 and everything is selected under BE3. You will be able to see progressive revealing — click on that, open up the tree, and show me what is inside, and maybe I will deselect something.  
  
## Default Selection Behavior  
  
When you first reveal the knowledge tree and ask the user to choose which knowledge they want:  
  
- You select the base  
- Selecting the base means putting a checkmark on all the nodes under it  
- Then you progressively reveal under each node: "Hey, in this node, I really want these 3 children out of 8"  
- When I select a child, all the child nodes under it are selected  
  
## Depth Selection  
  
But over time, if the number of nodes grows and a node is very deep in the knowledge tree, selecting all the nodes can be a problem. So I can maybe have a **depth selector** — how deep do you want to go from the grandparent to default-select all the nodes under it.  
  
From the top, you select all of these nodes and you get all the knowledge and information. Then you can choose: "Hey, only high-level knowledge about NetSec, and a little bit more deep knowledge about BE3."  
  
So every node can have a **default depth selector** — this is how deep I want to go in each node:  
  
- ==-1== means "I want to go as deep as we recurse — select everything" (and everything is selected)  
- You basically don't want that, but this is a default  
- You can double-click, look further, and then deselect NetSec, or for NetSec you can say "only go one level deep"  
- For BE3, you can say "go 6 levels deep and select everything"  
  
## Core vs. Ephemeral Knowledge  
  
Plus, the merge request may be accepted, but the new nodes that we are creating — those new nodes can be marked as:  
  
- **Core knowledge** — permanent, long-lived  
- **Ephemeral knowledge** — project-specific, temporary  
  
*(Look for better names for these.)*  
  
When we check out off of that default selector, it will select all the **core knowledge** nodes. The non-core (ephemeral) knowledge nodes will not be selected.  
  
This way we can be **less restrictive about accepting merge requests**. I will accept your merge request and have your node exist on my branch, but I will mark it as ephemeral knowledge — so it does not get selected into everybody's knowledge base by default.  
  
But if something is very useful, I can:  
  
- Mark that node as **core** — a permanently lived, long-lived node, or  
- Merge that node into the parent permanently, turning them into one bigger node with knowledge from both the parent and the child  
  
And the tree **converges a little bit over time**.  
  
## Conclusion  
  
That is a good solution. That is a scalable solution for the knowledge tree.  
  
**Next steps:** Have the knowledge tree that I have built so far — keep them. This is **knowledge profiles** (not "agent profiles" — look for a better name to imply this is a knowledge profile). The knowledge profile will only contain knowledge, not agent modes or operational stuff. It will have knowledge stuff. Service guides are not a perfect fit — there may be more specific documentation that is a better fit.  
  
This way, we can let the tree grow bigger and more complex while we retain a handle on how complex or big the tree is **by default** for any new user who comes in. After that, you can double-click and go deeper, and the node can be a **core node** or an **ephemeral node** (look for better names). But this can be a good solution.  
