# Knowledge Trees vs. Git Trees  
# Knowledge Trees vs. Git Trees  
### A Scalable Architecture for Hierarchical Knowledge Management  
### A Scalable Architecture for Hierarchical Knowledge Management  
⸻  
⸻  
## Visual 1: The Fundamental Difference  
## Visual 1: The Fundamental Difference  
  
**Git trees converge** — child branch knowledge trickles up and merges into the parent, eventually reaching ==dev== where it persists forever.  
**Git trees converge** — child branch knowledge trickles up and merges into the parent, eventually reaching ==dev== where it persists forever.  
  
**Knowledge trees diverge** — children inherit parent knowledge downward, but new knowledge added to a child node does NOT propagate back up. The hierarchy is permanent.  
**Knowledge trees diverge** — children inherit parent knowledge downward, but new knowledge added to a child node does NOT propagate back up. The hierarchy is permanent.  
  
[Git Tree vs Knowledge Tree](visuals/01_git_vs_knowledge_tree.svg)  
[Git Tree vs Knowledge Tree](visuals/01_git_vs_knowledge_tree.svg)  
  
**Key takeaway:** In a git tree, branches are temporary — they merge and disappear. In a knowledge tree, nodes are permanent — they accumulate and the tree only grows.  
**Key takeaway:** In a git tree, branches are temporary — they merge and disappear. In a knowledge tree, nodes are permanent — they accumulate and the tree only grows.  
⸻  
⸻  
## Visual 2: How Merge Requests Work in a Knowledge Tree  
## Visual 2: How Merge Requests Work in a Knowledge Tree  
  
A merge request in the knowledge tree is a **change request** that says: *"Update this tree."*  
A merge request in the knowledge tree is a **change request** that says: *"Update this tree."*  
  
There are two types:  
There are two types:  
1. **Update node content** — Add new knowledge to an existing node (e.g., add Azure setup docs to the Cloud node)  
2. **Update node content** — Add new knowledge to an existing node (e.g., add Azure setup docs to the Cloud node)  
3. **Add new node** — Insert a new node at a specific location in the tree (e.g., add an "Inventory" node under BE3)  
4. **Add new node** — Insert a new node at a specific location in the tree (e.g., add an "Inventory" node under BE3)  
  
[Merge Request Flow](visuals/02_merge_request_flow.svg)  
[Merge Request Flow](visuals/02_merge_request_flow.svg)  
  
**Critical difference from git:** After a merge request is accepted, the new knowledge stays at that node level. It does NOT propagate upward to the root. This means the tree keeps growing — creating a scaling challenge.  
**Critical difference from git:** After a merge request is accepted, the new knowledge stays at that node level. It does NOT propagate upward to the root. This means the tree keeps growing — creating a scaling challenge.  
⸻  
⸻  
## Visual 3: Solving the Selection Problem  
## Visual 3: Solving the Selection Problem  
  
With 1,000+ nodes, how does a new user choose what knowledge they need? The answer is **progressive reveal** combined with **depth selection**.  
With 1,000+ nodes, how does a new user choose what knowledge they need? The answer is **progressive reveal** combined with **depth selection**.  
  
**Progressive Reveal:**  
**Progressive Reveal:**  
1. Start by showing only top-level nodes — all selected by default  
2. Start by showing only top-level nodes — all selected by default  
3. User expands nodes to see children and deselect what they don't need  
4. User expands nodes to see children and deselect what they don't need  
5. Selecting a parent auto-selects all children beneath it  
6. Selecting a parent auto-selects all children beneath it  
  
**Depth Selector:**  
**Depth Selector:**  
- Each node gets a depth control: how many levels deep to auto-select  
- Each node gets a depth control: how many levels deep to auto-select  
- ==1== = top-level only (high-level knowledge)  
- ==1== = top-level only (high-level knowledge)  
- ==6== = deep selection (detailed knowledge)  
- ==6== = deep selection (detailed knowledge)  
- ==-1== = recursive, select everything  
- ==-1== = recursive, select everything  
  
[Progressive Reveal & Depth Selection](visuals/03_progressive_reveal_depth.svg)  
[Progressive Reveal & Depth Selection](visuals/03_progressive_reveal_depth.svg)  
  
**Example:** "Give me only high-level NetSec knowledge (depth: 1), but deep BE3 knowledge (depth: 6), and everything about Platform (depth: -1)."  
**Example:** "Give me only high-level NetSec knowledge (depth: 1), but deep BE3 knowledge (depth: 6), and everything about Platform (depth: -1)."  
⸻  
⸻  
## Visual 4: Core vs. Ephemeral Classification  
## Visual 4: Core vs. Ephemeral Classification  
  
Not all knowledge nodes are equal. New nodes from merge requests can be classified as:  
Not all knowledge nodes are equal. New nodes from merge requests can be classified as:  
  
- **🏛️ Core** — Permanent, long-lived, foundational knowledge. Selected by default for all new projects.  
- **🏛️ Core** — Permanent, long-lived, foundational knowledge. Selected by default for all new projects.  
- **⏳ Ephemeral** — Project-specific, experimental, or temporary knowledge. NOT selected by default.  
- **⏳ Ephemeral** — Project-specific, experimental, or temporary knowledge. NOT selected by default.  
  
[Core vs Ephemeral Nodes](visuals/04_core_vs_ephemeral.svg)  
[Core vs Ephemeral Nodes](visuals/04_core_vs_ephemeral.svg)  
  
**Why this matters:**  
**Why this matters:**  
- **Less restrictive MR acceptance** — Accept more merge requests without polluting everyone's default knowledge base. Just mark new nodes as ephemeral.  
- **Less restrictive MR acceptance** — Accept more merge requests without polluting everyone's default knowledge base. Just mark new nodes as ephemeral.  
- **Clean default experience** — New users get only core knowledge. No noise.  
- **Clean default experience** — New users get only core knowledge. No noise.  
- **Promotion path** — Ephemeral nodes that prove useful can be promoted to core, or merged into their parent node permanently.  
- **Promotion path** — Ephemeral nodes that prove useful can be promoted to core, or merged into their parent node permanently.  
⸻  
⸻  
## Visual 5: How the Tree Evolves Over Time  
## Visual 5: How the Tree Evolves Over Time  
  
The knowledge tree goes through three phases:  
The knowledge tree goes through three phases:  

| Phase | Timeline | What Happens |
| ------------ | --------- | ------------------------------------------------------------------------------------------------------ |
| Early Growth | Month 1 | Few nodes, all core. Simple tree. |
| Rapid Growth | Month 6 | Many MRs accepted. Ephemeral nodes appear. Tree expands. |
| Convergence | Month 12+ | Useful ephemeral nodes promoted to core or merged into parents. Tree gets richer but stays manageable. |
  
  
[Tree Convergence Over Time](visuals/05_tree_convergence.svg)  
[Tree Convergence Over Time](visuals/05_tree_convergence.svg)  
  
**The key insight:** The *total* number of nodes grows forever, but the *effective* size (what new users see by default) stays controlled through:  
**The key insight:** The *total* number of nodes grows forever, but the *effective* size (what new users see by default) stays controlled through:  
1. Core vs. ephemeral classification  
2. Core vs. ephemeral classification  
3. Depth-based default selection  
4. Depth-based default selection  
5. Periodic merging of child nodes into parents  
6. Periodic merging of child nodes into parents  
⸻  
⸻  
## Summary: The Complete Solution  
## Summary: The Complete Solution  
  
```
┌─────────────────────────────────────────────────────────┐
│                  KNOWLEDGE TREE DESIGN                  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  1. STRUCTURE                                           │
│     • Hierarchical, permanent (unlike git)              │
│     • Children inherit parent knowledge downward        │
│     • No upward propagation                             │
│                                                         │
│  2. CHANGE REQUESTS (Merge Requests)                    │
│     • "Update this tree" with new knowledge or nodes    │
│     • Two types: update content OR add node             │
│                                                         │
│  3. SCALABILITY CONTROLS                                │
│     • Progressive reveal UI                             │
│     • Per-node depth selector (-1 to N)                 │
│     • Core vs. ephemeral classification                 │
│                                                         │
│  4. LIFECYCLE                                           │
│     • New nodes start as ephemeral                      │
│     • Proven nodes promoted to core                     │
│     • Mature nodes merged into parents                  │
│     • Tree converges over time                          │
│                                                         │
│  5. NAMING                                              │
│     • "Knowledge Profiles" (not "Agent Profiles")       │
│     • Contains knowledge only, not operational config   │
│     • Better names needed for core/ephemeral            │
│                                                         │
└─────────────────────────────────────────────────────────┘

```
  
⸻  
⸻  
*Generated from voice memo — February 2026*  
