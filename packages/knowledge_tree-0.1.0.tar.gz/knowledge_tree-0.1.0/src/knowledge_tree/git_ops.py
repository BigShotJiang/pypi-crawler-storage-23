"""Git operations for Knowledge Tree.

Provider-agnostic git abstraction using subprocess. No GitPython dependency.
All operations delegate to the system git binary.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


class GitError(Exception):
    """Raised when a git operation fails."""


def _run(
    args: list[str],
    cwd: Path | str | None = None,
    *,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Run a git command and return the result."""
    cmd = ["git"] + args
    try:
        return subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=check,
        )
    except subprocess.CalledProcessError as e:
        raise GitError(
            f"git {' '.join(args)} failed (exit {e.returncode}):\n{e.stderr.strip()}"
        ) from e


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------


def is_git_repo(path: Path) -> bool:
    """Check if a directory is inside a git repository."""
    result = _run(["rev-parse", "--git-dir"], cwd=path, check=False)
    return result.returncode == 0


def get_head_ref(repo_path: Path) -> str:
    """Get the full HEAD commit hash."""
    result = _run(["rev-parse", "HEAD"], cwd=repo_path)
    return result.stdout.strip()


def get_short_ref(repo_path: Path) -> str:
    """Get the short (7-char) HEAD commit hash."""
    result = _run(["rev-parse", "--short", "HEAD"], cwd=repo_path)
    return result.stdout.strip()


def get_remote_url(repo_path: Path, remote: str = "origin") -> str:
    """Get the URL of a remote."""
    result = _run(["remote", "get-url", remote], cwd=repo_path)
    return result.stdout.strip()


# ---------------------------------------------------------------------------
# Clone / Pull
# ---------------------------------------------------------------------------


def clone(
    url: str,
    dest: Path,
    *,
    branch: str = "main",
    shallow: bool = True,
) -> None:
    """Clone a repository.

    Args:
        url: Git remote URL.
        dest: Local directory to clone into.
        branch: Branch to checkout.
        shallow: If True, clone with depth=1 for speed.
    """
    args = ["clone", "--branch", branch]
    if shallow:
        args += ["--depth", "1"]
    args += [url, str(dest)]
    _run(args)


def pull(repo_path: Path, *, remote: str = "origin", branch: str = "main") -> str:
    """Pull latest changes. Returns the new HEAD ref."""
    _run(["fetch", remote, branch], cwd=repo_path)
    _run(["checkout", branch], cwd=repo_path)
    _run(["reset", "--hard", f"{remote}/{branch}"], cwd=repo_path)
    return get_head_ref(repo_path)


def unshallow(repo_path: Path) -> None:
    """Convert a shallow clone to a full clone (needed before push)."""
    result = _run(
        ["rev-parse", "--is-shallow-repository"], cwd=repo_path, check=False
    )
    if result.stdout.strip() == "true":
        _run(["fetch", "--unshallow"], cwd=repo_path)


# ---------------------------------------------------------------------------
# Branch / Commit / Push
# ---------------------------------------------------------------------------


def create_branch(repo_path: Path, branch_name: str) -> None:
    """Create and checkout a new branch."""
    _run(["checkout", "-b", branch_name], cwd=repo_path)


def add_and_commit(repo_path: Path, message: str, paths: list[str] | None = None) -> str:
    """Stage files and commit. Returns the commit hash.

    Args:
        repo_path: Repository root.
        message: Commit message.
        paths: Specific paths to add. If None, adds all changes.
    """
    if paths:
        _run(["add"] + paths, cwd=repo_path)
    else:
        _run(["add", "."], cwd=repo_path)
    _run(["commit", "-m", message], cwd=repo_path)
    return get_head_ref(repo_path)


def push_branch(
    repo_path: Path,
    branch_name: str,
    *,
    remote: str = "origin",
    set_upstream: bool = True,
) -> None:
    """Push a branch to the remote."""
    args = ["push"]
    if set_upstream:
        args += ["--set-upstream"]
    args += [remote, branch_name]
    _run(args, cwd=repo_path)


# ---------------------------------------------------------------------------
# Provider detection + MR/PR URL generation
# ---------------------------------------------------------------------------


def detect_provider(remote_url: str) -> str:
    """Detect the git provider from a remote URL.

    Returns one of: 'github', 'gitlab', 'bitbucket', 'unknown'.
    """
    url_lower = remote_url.lower()
    if "github.com" in url_lower or "github" in url_lower:
        return "github"
    if "gitlab" in url_lower:
        return "gitlab"
    if "bitbucket" in url_lower:
        return "bitbucket"
    return "unknown"


def get_mr_url(remote_url: str, branch: str) -> str:
    """Generate a merge/pull request creation URL for the given branch.

    Returns a URL string or a helpful message for unknown providers.
    """
    base_url = _remote_url_to_https(remote_url)
    provider = detect_provider(remote_url)

    if provider == "gitlab":
        return f"{base_url}/-/merge_requests/new?merge_request[source_branch]={branch}"
    elif provider == "github":
        return f"{base_url}/compare/{branch}?expand=1"
    elif provider == "bitbucket":
        return f"{base_url}/pull-requests/new?source={branch}"
    else:
        return f"Create a merge/pull request for branch '{branch}' on your git host"


def _remote_url_to_https(url: str) -> str:
    """Convert a git remote URL (SSH or HTTPS) to an HTTPS base URL.

    Examples:
        git@github.com:user/repo.git -> https://github.com/user/repo
        https://github.com/user/repo.git -> https://github.com/user/repo
    """
    # SSH format: git@host:user/repo.git
    ssh_match = re.match(r"git@([^:]+):(.+?)(?:\.git)?$", url)
    if ssh_match:
        host, path = ssh_match.groups()
        return f"https://{host}/{path}"

    # HTTPS format: https://host/user/repo.git
    https_match = re.match(r"(https?://.+?)(?:\.git)?$", url)
    if https_match:
        return https_match.group(1)

    return url
