"""Data models for Knowledge Tree.

Defines the core data structures: PackageMetadata, RegistryEntry, Registry,
InstalledPackage, and ProjectConfig. All models support YAML serialization
via ruamel.yaml.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

yaml = YAML()
yaml.default_flow_style = False
yaml.preserve_quotes = True


# ---------------------------------------------------------------------------
# PackageMetadata — contents of a package.yaml
# ---------------------------------------------------------------------------


@dataclass
class PackageMetadata:
    """Represents a knowledge package's metadata (package.yaml)."""

    name: str
    description: str
    authors: list[str] = field(default_factory=list)
    classification: str = "seasonal"  # "evergreen" | "seasonal"
    version: str = "0.1.0"
    created: str = ""
    updated: str = ""

    # Relationships
    parent: str | None = None
    depends_on: list[str] = field(default_factory=list)
    suggests: list[str] = field(default_factory=list)

    # Discovery
    tags: list[str] = field(default_factory=list)
    audience: list[str] = field(default_factory=list)

    # Content
    content: list[str] = field(default_factory=list)

    # Phase 2 — contribution tracking
    status: str = "active"  # "active" | "pending" | "promoted" | "archived"
    promoted_to: str | None = None
    promoted_date: str | None = None

    def __post_init__(self) -> None:
        today = date.today().isoformat()
        if not self.created:
            self.created = today
        if not self.updated:
            self.updated = today

    # -- Validation ----------------------------------------------------------

    def validate(self) -> list[str]:
        """Return a list of validation error strings. Empty = valid."""
        errors: list[str] = []

        if not self.name:
            errors.append("Package name is required")
        elif not _is_kebab_case(self.name):
            errors.append(
                f"Package name '{self.name}' must be kebab-case "
                "(lowercase letters, numbers, hyphens)"
            )

        if not self.description:
            errors.append("Package description is required")

        if self.classification not in ("evergreen", "seasonal"):
            errors.append(
                f"Classification must be 'evergreen' or 'seasonal', "
                f"got '{self.classification}'"
            )

        if self.status not in ("active", "pending", "promoted", "archived"):
            errors.append(
                f"Status must be one of: active, pending, promoted, archived — "
                f"got '{self.status}'"
            )

        return errors

    # -- Serialization -------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dict for YAML serialization."""
        d: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "authors": self.authors,
            "created": self.created,
            "updated": self.updated,
            "classification": self.classification,
            "tags": self.tags,
            "content": self.content,
        }
        if self.parent:
            d["parent"] = self.parent
        if self.depends_on:
            d["depends_on"] = self.depends_on
        if self.suggests:
            d["suggests"] = self.suggests
        if self.audience:
            d["audience"] = self.audience
        if self.status != "active":
            d["status"] = self.status
        if self.promoted_to:
            d["promoted_to"] = self.promoted_to
        if self.promoted_date:
            d["promoted_date"] = self.promoted_date
        return d

    def save(self, path: Path) -> None:
        """Write this package metadata to a YAML file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(self.to_dict(), f)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PackageMetadata:
        """Create from a plain dict (parsed YAML)."""
        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            authors=data.get("authors", []),
            classification=data.get("classification", "seasonal"),
            version=data.get("version", "0.1.0"),
            created=data.get("created", ""),
            updated=data.get("updated", ""),
            parent=data.get("parent"),
            depends_on=data.get("depends_on", []),
            suggests=data.get("suggests", []),
            tags=data.get("tags", []),
            audience=data.get("audience", []),
            content=data.get("content", []),
            status=data.get("status", "active"),
            promoted_to=data.get("promoted_to"),
            promoted_date=data.get("promoted_date"),
        )

    @classmethod
    def load(cls, path: Path) -> PackageMetadata:
        """Load from a YAML file."""
        with open(path) as f:
            data = yaml.load(f)
        return cls.from_dict(data)


# ---------------------------------------------------------------------------
# RegistryEntry — lightweight entry in registry.yaml
# ---------------------------------------------------------------------------


@dataclass
class RegistryEntry:
    """A single package entry in the registry index."""

    description: str = ""
    classification: str = "seasonal"
    tags: list[str] = field(default_factory=list)
    parent: str | None = None
    depends_on: list[str] = field(default_factory=list)
    version: str = "0.1.0"
    path: str = ""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "description": self.description,
            "classification": self.classification,
            "tags": self.tags,
            "version": self.version,
            "path": self.path,
        }
        if self.parent:
            d["parent"] = self.parent
        if self.depends_on:
            d["depends_on"] = self.depends_on
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RegistryEntry:
        return cls(
            description=data.get("description", ""),
            classification=data.get("classification", "seasonal"),
            tags=data.get("tags", []),
            parent=data.get("parent"),
            depends_on=data.get("depends_on", []),
            version=data.get("version", "0.1.0"),
            path=data.get("path", ""),
        )

    @classmethod
    def from_package(cls, pkg: PackageMetadata, rel_path: str) -> RegistryEntry:
        """Create a registry entry from a full PackageMetadata."""
        return cls(
            description=pkg.description,
            classification=pkg.classification,
            tags=pkg.tags,
            parent=pkg.parent,
            depends_on=pkg.depends_on,
            version=pkg.version,
            path=rel_path,
        )


# ---------------------------------------------------------------------------
# Registry — the full registry.yaml index
# ---------------------------------------------------------------------------


@dataclass
class Registry:
    """The package registry index (registry.yaml)."""

    version: str = ""
    packages: dict[str, RegistryEntry] = field(default_factory=dict)

    def get(self, name: str) -> RegistryEntry | None:
        """Look up a package by name."""
        return self.packages.get(name)

    def get_children(self, parent_name: str) -> list[str]:
        """Return names of packages whose parent is *parent_name*."""
        return [
            name
            for name, entry in self.packages.items()
            if entry.parent == parent_name
        ]

    def resolve_deps(self, name: str, *, include_suggests: bool = False) -> list[str]:
        """Resolve all transitive dependencies for a package.

        Returns a list of package names in installation order (deps first).
        """
        resolved: list[str] = []
        seen: set[str] = set()

        def _walk(pkg_name: str) -> None:
            if pkg_name in seen:
                return
            seen.add(pkg_name)
            entry = self.packages.get(pkg_name)
            if entry is None:
                return
            for dep in entry.depends_on:
                _walk(dep)
            resolved.append(pkg_name)

        _walk(name)
        return resolved

    def search(self, query: str) -> list[str]:
        """Search packages by name, description, or tags. Case-insensitive."""
        query_lower = query.lower()
        results: list[str] = []
        for name, entry in self.packages.items():
            if query_lower in name.lower():
                results.append(name)
            elif query_lower in entry.description.lower():
                results.append(name)
            elif any(query_lower in tag.lower() for tag in entry.tags):
                results.append(name)
        return results

    def save(self, path: Path) -> None:
        """Write the registry index to a YAML file."""
        data: dict[str, Any] = {
            "version": self.version,
            "packages": {
                name: entry.to_dict() for name, entry in self.packages.items()
            },
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(data, f)

    @classmethod
    def load(cls, path: Path) -> Registry:
        """Load registry from a YAML file."""
        with open(path) as f:
            data = yaml.load(f)
        if data is None:
            return cls()
        packages = {}
        for name, entry_data in (data.get("packages") or {}).items():
            packages[name] = RegistryEntry.from_dict(entry_data)
        return cls(
            version=data.get("version", ""),
            packages=packages,
        )

    @classmethod
    def rebuild_from_directory(cls, registry_root: Path) -> Registry:
        """Scan packages/ and community/ dirs to rebuild the registry index."""
        registry = cls(version=date.today().isoformat())

        for directory in ("packages", "community"):
            pkg_dir = registry_root / directory
            if not pkg_dir.is_dir():
                continue
            for package_yaml in sorted(pkg_dir.rglob("package.yaml")):
                pkg = PackageMetadata.load(package_yaml)
                rel_path = str(package_yaml.parent.relative_to(registry_root))
                registry.packages[pkg.name] = RegistryEntry.from_package(pkg, rel_path)

        return registry


# ---------------------------------------------------------------------------
# InstalledPackage — tracks what's installed locally
# ---------------------------------------------------------------------------


@dataclass
class InstalledPackage:
    """A package installed in the local project."""

    name: str
    ref: str = ""  # git commit hash at time of install

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "ref": self.ref}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> InstalledPackage:
        return cls(name=data.get("name", ""), ref=data.get("ref", ""))


# ---------------------------------------------------------------------------
# ProjectConfig — .kt/kt.yaml
# ---------------------------------------------------------------------------


@dataclass
class ProjectConfig:
    """Local project configuration stored in .kt/kt.yaml."""

    registry: str = ""
    registry_ref: str = "main"
    packages: list[InstalledPackage] = field(default_factory=list)
    telemetry_enabled: bool = False

    def get_installed(self, name: str) -> InstalledPackage | None:
        """Find an installed package by name."""
        for pkg in self.packages:
            if pkg.name == name:
                return pkg
        return None

    def is_installed(self, name: str) -> bool:
        return self.get_installed(name) is not None

    def add_package(self, name: str, ref: str = "") -> None:
        """Add a package to the installed list (no-op if already present)."""
        if not self.is_installed(name):
            self.packages.append(InstalledPackage(name=name, ref=ref))

    def remove_package(self, name: str) -> bool:
        """Remove a package. Returns True if it was found and removed."""
        for i, pkg in enumerate(self.packages):
            if pkg.name == name:
                self.packages.pop(i)
                return True
        return False

    def save(self, path: Path) -> None:
        """Write config to YAML file."""
        data: dict[str, Any] = {
            "registry": self.registry,
            "registry_ref": self.registry_ref,
            "packages": [p.to_dict() for p in self.packages],
            "telemetry": {"enabled": self.telemetry_enabled},
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(data, f)

    @classmethod
    def load(cls, path: Path) -> ProjectConfig:
        """Load config from YAML file."""
        with open(path) as f:
            data = yaml.load(f)
        if data is None:
            return cls()
        telemetry = data.get("telemetry") or {}
        return cls(
            registry=data.get("registry", ""),
            registry_ref=data.get("registry_ref", "main"),
            packages=[
                InstalledPackage.from_dict(p) for p in (data.get("packages") or [])
            ],
            telemetry_enabled=telemetry.get("enabled", False),
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_kebab_case(name: str) -> bool:
    """Check if a string is valid kebab-case (lowercase, digits, hyphens)."""
    if not name:
        return False
    return all(c.isalnum() or c == "-" for c in name) and name == name.lower()
