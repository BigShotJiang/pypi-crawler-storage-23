"""Knowledge Tree — A crowdsourced knowledge management system for AI coding agents."""

__version__ = "0.1.0"
