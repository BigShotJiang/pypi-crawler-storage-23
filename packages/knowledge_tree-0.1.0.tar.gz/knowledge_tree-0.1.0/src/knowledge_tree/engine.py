"""Core engine for Knowledge Tree.

The KnowledgeTreeEngine orchestrates all operations: init, add, remove, update,
search, contribute, and registry management. It coordinates between models,
git_ops, and the filesystem.
"""

from __future__ import annotations

import shutil
from datetime import date
from pathlib import Path
from typing import Any

from knowledge_tree import git_ops
from knowledge_tree.models import (
    InstalledPackage,
    PackageMetadata,
    ProjectConfig,
    Registry,
    RegistryEntry,
)


class KnowledgeTreeError(Exception):
    """Base exception for engine errors."""


class KnowledgeTreeEngine:
    """Core engine for all Knowledge Tree operations.

    Directory layout for a project using kt:
        project/
        ├── .kt/
        │   ├── kt.yaml          ← project config
        │   └── cache/            ← cloned registry repo
        └── .knowledge/           ← materialized knowledge files
            ├── KNOWLEDGE_MANIFEST.md
            └── <package-name>/
                └── <content-files>.md
    """

    KT_DIR = ".kt"
    CONFIG_FILE = "kt.yaml"
    CACHE_DIR = "cache"
    KNOWLEDGE_DIR = ".knowledge"
    MANIFEST_FILE = "KNOWLEDGE_MANIFEST.md"
    REGISTRY_FILE = "registry.yaml"
    PACKAGES_DIR = "packages"
    COMMUNITY_DIR = "community"

    def __init__(self, project_root: Path | str) -> None:
        self.project_root = Path(project_root).resolve()
        self.kt_dir = self.project_root / self.KT_DIR
        self.config_path = self.kt_dir / self.CONFIG_FILE
        self.cache_dir = self.kt_dir / self.CACHE_DIR
        self.knowledge_dir = self.project_root / self.KNOWLEDGE_DIR

    # -- Helpers -------------------------------------------------------------

    def _load_config(self) -> ProjectConfig:
        if not self.config_path.exists():
            raise KnowledgeTreeError(
                "Not a Knowledge Tree project. Run 'kt init' first."
            )
        return ProjectConfig.load(self.config_path)

    def _load_registry(self) -> Registry:
        registry_path = self.cache_dir / self.REGISTRY_FILE
        if not registry_path.exists():
            raise KnowledgeTreeError(
                "Registry cache not found. Run 'kt init' or 'kt update'."
            )
        return Registry.load(registry_path)

    def _get_package_dir(self, registry: Registry, name: str) -> Path:
        """Get the filesystem path of a package in the registry cache."""
        entry = registry.get(name)
        if entry is None:
            raise KnowledgeTreeError(f"Package '{name}' not found in registry.")
        return self.cache_dir / entry.path

    # ======================================================================
    # Phase 1: Consumer operations
    # ======================================================================

    def init(self, registry_url: str, *, branch: str = "main") -> dict[str, Any]:
        """Initialize a project with knowledge from a registry.

        Returns a summary dict with counts.
        """
        if self.config_path.exists():
            raise KnowledgeTreeError(
                f"Already initialized. Config exists at {self.config_path}"
            )

        # Create directories
        self.kt_dir.mkdir(parents=True, exist_ok=True)
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)

        # Clone registry
        git_ops.clone(registry_url, self.cache_dir, branch=branch)

        # Load registry to count packages
        registry = self._load_registry()
        evergreen_count = sum(
            1
            for e in registry.packages.values()
            if e.classification == "evergreen"
        )
        seasonal_count = sum(
            1
            for e in registry.packages.values()
            if e.classification == "seasonal"
        )

        # Save project config
        config = ProjectConfig(registry=registry_url, registry_ref=branch)
        config.save(self.config_path)

        # Generate initial manifest
        self._generate_manifest(config, registry)

        return {
            "total_packages": len(registry.packages),
            "evergreen": evergreen_count,
            "seasonal": seasonal_count,
        }

    def add_package(self, name: str) -> dict[str, Any]:
        """Add a package (and its dependencies) to the project.

        Returns a summary dict.
        """
        config = self._load_config()
        registry = self._load_registry()

        if config.is_installed(name):
            raise KnowledgeTreeError(f"Package '{name}' is already installed.")

        if registry.get(name) is None:
            # Suggest similar packages
            similar = registry.search(name)
            msg = f"Package '{name}' not found in registry."
            if similar:
                msg += f" Did you mean: {', '.join(similar[:5])}?"
            raise KnowledgeTreeError(msg)

        # Resolve dependencies
        to_install = registry.resolve_deps(name)

        installed: list[str] = []
        for pkg_name in to_install:
            if config.is_installed(pkg_name):
                continue
            self._materialize_package(registry, pkg_name)
            ref = git_ops.get_short_ref(self.cache_dir)
            config.add_package(pkg_name, ref)
            installed.append(pkg_name)

        config.save(self.config_path)
        self._generate_manifest(config, registry)

        return {
            "installed": installed,
            "total_files": sum(
                len(list((self.knowledge_dir / n).glob("*.md")))
                for n in installed
                if (self.knowledge_dir / n).is_dir()
            ),
        }

    def remove_package(self, name: str) -> dict[str, Any]:
        """Remove a package from the project."""
        config = self._load_config()
        registry = self._load_registry()

        if not config.is_installed(name):
            raise KnowledgeTreeError(f"Package '{name}' is not installed.")

        # Check if any installed package depends on this one
        dependents = [
            pkg.name
            for pkg in config.packages
            if pkg.name != name
            and name in (registry.get(pkg.name) or RegistryEntry()).depends_on
        ]
        if dependents:
            raise KnowledgeTreeError(
                f"Cannot remove '{name}': required by {', '.join(dependents)}. "
                f"Remove those packages first."
            )

        # Remove materialized files
        pkg_dir = self.knowledge_dir / name
        if pkg_dir.is_dir():
            shutil.rmtree(pkg_dir)

        config.remove_package(name)
        config.save(self.config_path)
        self._generate_manifest(config, registry)

        return {"removed": name}

    def update(self) -> dict[str, Any]:
        """Pull latest registry and re-materialize all packages."""
        config = self._load_config()

        # Pull latest
        new_ref = git_ops.pull(self.cache_dir, branch=config.registry_ref)
        registry = self._load_registry()

        # Re-materialize all installed packages
        updated: list[str] = []
        for pkg in config.packages:
            old_ref = pkg.ref
            self._materialize_package(registry, pkg.name)
            pkg.ref = git_ops.get_short_ref(self.cache_dir)
            if pkg.ref != old_ref:
                updated.append(pkg.name)

        # Check for new packages
        new_packages = [
            name
            for name in registry.packages
            if not config.is_installed(name)
        ]

        config.save(self.config_path)
        self._generate_manifest(config, registry)

        return {
            "updated": updated,
            "new_available": new_packages,
            "ref": new_ref[:7],
        }

    def list_packages(self) -> list[dict[str, str]]:
        """List installed packages with their refs."""
        config = self._load_config()
        registry = self._load_registry()
        result = []
        for pkg in config.packages:
            entry = registry.get(pkg.name)
            result.append(
                {
                    "name": pkg.name,
                    "ref": pkg.ref,
                    "classification": entry.classification if entry else "unknown",
                    "description": entry.description if entry else "",
                }
            )
        return result

    def list_available(self) -> list[dict[str, str]]:
        """List all available packages in the registry."""
        config = self._load_config()
        registry = self._load_registry()
        result = []
        for name, entry in registry.packages.items():
            result.append(
                {
                    "name": name,
                    "installed": "✓" if config.is_installed(name) else "",
                    "classification": entry.classification,
                    "description": entry.description,
                }
            )
        return result

    def search(self, query: str) -> list[dict[str, str]]:
        """Search packages by name, description, or tags."""
        config = self._load_config()
        registry = self._load_registry()
        matches = registry.search(query)
        return [
            {
                "name": name,
                "installed": "✓" if config.is_installed(name) else "",
                "classification": registry.packages[name].classification,
                "description": registry.packages[name].description,
            }
            for name in matches
        ]

    def get_status(self) -> dict[str, Any]:
        """Get project knowledge status."""
        config = self._load_config()
        registry = self._load_registry()

        total_files = 0
        total_lines = 0
        for pkg in config.packages:
            pkg_dir = self.knowledge_dir / pkg.name
            if pkg_dir.is_dir():
                for f in pkg_dir.glob("*.md"):
                    total_files += 1
                    total_lines += len(f.read_text().splitlines())

        return {
            "registry": config.registry,
            "registry_ref": config.registry_ref,
            "installed_packages": len(config.packages),
            "available_packages": len(registry.packages),
            "total_files": total_files,
            "total_lines": total_lines,
            "telemetry": "enabled" if config.telemetry_enabled else "disabled",
        }

    def get_info(self, name: str) -> dict[str, Any]:
        """Get detailed information about a package."""
        registry = self._load_registry()
        config = self._load_config()

        entry = registry.get(name)
        if entry is None:
            raise KnowledgeTreeError(f"Package '{name}' not found in registry.")

        # Try to load full metadata from cache
        pkg_dir = self.cache_dir / entry.path
        pkg_yaml = pkg_dir / "package.yaml"
        if pkg_yaml.exists():
            meta = PackageMetadata.load(pkg_yaml)
            return {
                "name": meta.name,
                "description": meta.description,
                "version": meta.version,
                "classification": meta.classification,
                "authors": meta.authors,
                "tags": meta.tags,
                "parent": meta.parent or "none",
                "depends_on": meta.depends_on or [],
                "suggests": meta.suggests or [],
                "content": meta.content,
                "created": meta.created,
                "updated": meta.updated,
                "installed": config.is_installed(name),
                "children": registry.get_children(name),
            }

        # Fallback to registry entry only
        return {
            "name": name,
            "description": entry.description,
            "version": entry.version,
            "classification": entry.classification,
            "installed": config.is_installed(name),
        }

    def validate_package(self, package_dir: Path) -> list[str]:
        """Validate a single package directory. Returns list of errors."""
        errors: list[str] = []
        pkg_yaml = package_dir / "package.yaml"

        if not pkg_yaml.exists():
            errors.append(f"Missing package.yaml in {package_dir}")
            return errors

        meta = PackageMetadata.load(pkg_yaml)
        errors.extend(meta.validate())

        # Check that listed content files exist
        for content_file in meta.content:
            if not (package_dir / content_file).exists():
                errors.append(
                    f"Content file '{content_file}' listed in package.yaml "
                    f"but not found in {package_dir}"
                )

        # Warnings (returned as "WARN: ..." strings)
        for content_file in meta.content:
            fpath = package_dir / content_file
            if fpath.exists():
                lines = len(fpath.read_text().splitlines())
                if lines > 500:
                    errors.append(
                        f"WARN: {content_file} has {lines} lines "
                        f"(recommended max: 500)"
                    )

        return errors

    # -- Materialization -----------------------------------------------------

    def _materialize_package(self, registry: Registry, name: str) -> None:
        """Copy content files from registry cache to .knowledge/<name>/."""
        pkg_dir = self._get_package_dir(registry, name)
        pkg_yaml = pkg_dir / "package.yaml"

        if not pkg_yaml.exists():
            raise KnowledgeTreeError(
                f"Package '{name}' has no package.yaml in registry cache."
            )

        meta = PackageMetadata.load(pkg_yaml)
        dest_dir = self.knowledge_dir / name
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Copy content files
        for content_file in meta.content:
            src = pkg_dir / content_file
            if src.exists():
                shutil.copy2(src, dest_dir / content_file)

    def _generate_manifest(self, config: ProjectConfig, registry: Registry) -> None:
        """Generate KNOWLEDGE_MANIFEST.md summarizing installed knowledge."""
        lines = [
            "# Knowledge Manifest",
            "",
            "This file is auto-generated by `kt`. It summarizes all installed",
            "knowledge packages. AI agents should read this file first for an",
            "overview of available knowledge.",
            "",
            f"**Registry:** {config.registry}",
            f"**Packages installed:** {len(config.packages)}",
            "",
            "---",
            "",
        ]

        for pkg in config.packages:
            entry = registry.get(pkg.name)
            if entry is None:
                continue
            lines.append(f"## {pkg.name}")
            lines.append("")
            lines.append(f"*{entry.description}*")
            lines.append("")
            lines.append(f"- **Classification:** {entry.classification}")
            if entry.tags:
                lines.append(f"- **Tags:** {', '.join(entry.tags)}")
            lines.append(f"- **Location:** `.knowledge/{pkg.name}/`")

            # List content files
            pkg_dir = self.knowledge_dir / pkg.name
            if pkg_dir.is_dir():
                md_files = sorted(pkg_dir.glob("*.md"))
                if md_files:
                    lines.append("- **Files:**")
                    for f in md_files:
                        lines.append(f"  - `{f.name}`")

            lines.append("")

        manifest_path = self.knowledge_dir / self.MANIFEST_FILE
        manifest_path.write_text("\n".join(lines) + "\n")

    # ======================================================================
    # Phase 2: Contributor operations
    # ======================================================================

    def contribute(
        self,
        content_paths: list[Path],
        *,
        name: str,
        description: str = "",
        tags: list[str] | None = None,
        to_existing: str | None = None,
    ) -> dict[str, Any]:
        """Create a community contribution.

        If `to_existing` is provided, creates a child node under that community
        package. Otherwise creates a new top-level community package.

        Returns a dict with branch name and MR URL.
        """
        config = self._load_config()
        registry = self._load_registry()

        # Validate content files exist
        for p in content_paths:
            if not p.exists():
                raise KnowledgeTreeError(f"Content file not found: {p}")
            if not p.suffix == ".md":
                raise KnowledgeTreeError(
                    f"Content files must be markdown (.md): {p}"
                )

        # Determine contribution directory
        if to_existing:
            # Add as child node under existing community package
            community_path = self.cache_dir / self.COMMUNITY_DIR / to_existing / name
        else:
            community_path = self.cache_dir / self.COMMUNITY_DIR / name

        if community_path.exists():
            raise KnowledgeTreeError(
                f"Community package '{name}' already exists at {community_path}"
            )

        # Unshallow the cache so we can push
        git_ops.unshallow(self.cache_dir)

        # Create branch
        branch_name = f"contribute/{name}"
        git_ops.create_branch(self.cache_dir, branch_name)

        # Create package directory + metadata
        community_path.mkdir(parents=True, exist_ok=True)

        content_filenames = [p.name for p in content_paths]
        meta = PackageMetadata(
            name=name,
            description=description or f"Community contribution: {name}",
            authors=[],  # User can fill in later
            classification="seasonal",
            status="pending",
            tags=tags or [],
            content=content_filenames,
            parent=to_existing,
        )
        meta.save(community_path / "package.yaml")

        # Copy content files
        for p in content_paths:
            shutil.copy2(p, community_path / p.name)

        # Commit
        git_ops.add_and_commit(
            self.cache_dir,
            f"contribute: add {name} to community pool",
        )

        # Push
        git_ops.push_branch(self.cache_dir, branch_name)

        # Generate MR URL
        remote_url = git_ops.get_remote_url(self.cache_dir)
        mr_url = git_ops.get_mr_url(remote_url, branch_name)

        return {
            "package": name,
            "branch": branch_name,
            "path": str(community_path.relative_to(self.cache_dir)),
            "files": content_filenames,
            "mr_url": mr_url,
        }

    def list_community(self) -> list[dict[str, str]]:
        """List packages in the community pool."""
        community_dir = self.cache_dir / self.COMMUNITY_DIR
        if not community_dir.is_dir():
            return []

        result = []
        for pkg_yaml in sorted(community_dir.rglob("package.yaml")):
            meta = PackageMetadata.load(pkg_yaml)
            result.append(
                {
                    "name": meta.name,
                    "description": meta.description,
                    "status": meta.status,
                    "classification": meta.classification,
                    "path": str(pkg_yaml.parent.relative_to(self.cache_dir)),
                }
            )
        return result

    def registry_rebuild(self, registry_root: Path | None = None) -> dict[str, Any]:
        """Rebuild registry.yaml from the packages/ and community/ directories.

        If registry_root is None, uses the cache directory.
        """
        root = registry_root or self.cache_dir
        registry = Registry.rebuild_from_directory(root)
        registry.save(root / self.REGISTRY_FILE)

        return {
            "total_packages": len(registry.packages),
            "registry_path": str(root / self.REGISTRY_FILE),
        }

    def validate_all(self, registry_root: Path | None = None) -> dict[str, Any]:
        """Validate all packages in the registry. Returns errors and warnings."""
        root = registry_root or self.cache_dir
        all_errors: dict[str, list[str]] = {}
        packages_checked = 0

        for directory in (self.PACKAGES_DIR, self.COMMUNITY_DIR):
            pkg_dir = root / directory
            if not pkg_dir.is_dir():
                continue
            for pkg_yaml in sorted(pkg_dir.rglob("package.yaml")):
                package_dir = pkg_yaml.parent
                errors = self.validate_package(package_dir)
                packages_checked += 1
                if errors:
                    rel_path = str(package_dir.relative_to(root))
                    all_errors[rel_path] = errors

        return {
            "packages_checked": packages_checked,
            "packages_with_errors": len(all_errors),
            "errors": all_errors,
        }
