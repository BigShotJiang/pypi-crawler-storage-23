"""CLI interface for Knowledge Tree.

Provides the `kt` command group with all user-facing commands.
Built with Click for command parsing and Rich for terminal formatting.
"""

from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table
from rich.tree import Tree as RichTree

from knowledge_tree import __version__
from knowledge_tree.engine import KnowledgeTreeEngine, KnowledgeTreeError

console = Console()
err_console = Console(stderr=True)


def _get_engine() -> KnowledgeTreeEngine:
    return KnowledgeTreeEngine(Path.cwd())


def _handle_error(e: KnowledgeTreeError) -> None:
    err_console.print(f"[bold red]Error:[/] {e}")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Main group
# ---------------------------------------------------------------------------


@click.group()
@click.version_option(__version__, prog_name="kt")
def cli() -> None:
    """Knowledge Tree — crowdsourced knowledge for AI coding agents.

    Manage knowledge packages that give AI agents context about your
    codebase, tools, services, and conventions.
    """


# ---------------------------------------------------------------------------
# Phase 1: Consumer commands
# ---------------------------------------------------------------------------


@cli.command()
@click.option(
    "--from", "registry_url", required=True,
    help="Git URL of the knowledge registry.",
)
@click.option(
    "--branch", default="main",
    help="Branch to track (default: main).",
)
def init(registry_url: str, branch: str) -> None:
    """Initialize a project with knowledge from a registry."""
    engine = _get_engine()
    try:
        with console.status("Cloning registry..."):
            result = engine.init(registry_url, branch=branch)
        console.print(f"[bold green]✓[/] Initialized Knowledge Tree")
        console.print(
            f"  Found [bold]{result['total_packages']}[/] packages "
            f"([green]{result['evergreen']} evergreen[/], "
            f"[yellow]{result['seasonal']} seasonal[/])"
        )
        console.print()
        console.print("Next steps:")
        console.print("  [dim]kt list --available[/]  — see all packages")
        console.print("  [dim]kt add <package>[/]     — install a package")
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
@click.argument("package")
def add(package: str) -> None:
    """Add a knowledge package to your project."""
    engine = _get_engine()
    try:
        result = engine.add_package(package)
        installed = result["installed"]
        if len(installed) == 1:
            console.print(f"[bold green]✓[/] Installed [bold]{installed[0]}[/]")
        else:
            console.print(
                f"[bold green]✓[/] Installed [bold]{len(installed)}[/] packages:"
            )
            for name in installed:
                console.print(f"  • {name}")
        console.print(
            f"  {result['total_files']} knowledge files materialized"
        )
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
@click.argument("package")
def remove(package: str) -> None:
    """Remove a knowledge package from your project."""
    engine = _get_engine()
    try:
        result = engine.remove_package(package)
        console.print(f"[bold green]✓[/] Removed [bold]{result['removed']}[/]")
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command(name="list")
@click.option("--available", is_flag=True, help="Show all available packages.")
@click.option("--community", is_flag=True, help="Show community pool packages.")
def list_cmd(available: bool, community: bool) -> None:
    """List knowledge packages."""
    engine = _get_engine()
    try:
        if community:
            # Phase 2: community listing
            packages = engine.list_community()
            if not packages:
                console.print("[dim]No community packages found.[/]")
                return
            table = Table(title="Community Pool")
            table.add_column("Package", style="cyan")
            table.add_column("Description")
            table.add_column("Status", style="yellow")
            for pkg in packages:
                table.add_row(pkg["name"], pkg["description"], pkg["status"])
            console.print(table)
        elif available:
            packages = engine.list_available()
            if not packages:
                console.print("[dim]No packages in registry.[/]")
                return
            table = Table(title="Available Packages")
            table.add_column("", width=2)
            table.add_column("Package", style="cyan")
            table.add_column("Type", style="green")
            table.add_column("Description")
            for pkg in packages:
                table.add_row(
                    pkg["installed"],
                    pkg["name"],
                    pkg["classification"],
                    pkg["description"],
                )
            console.print(table)
        else:
            packages = engine.list_packages()
            if not packages:
                console.print(
                    "[dim]No packages installed. "
                    "Run [bold]kt add <package>[/] to get started.[/]"
                )
                return
            table = Table(title="Installed Packages")
            table.add_column("Package", style="cyan")
            table.add_column("Type", style="green")
            table.add_column("Ref", style="dim")
            table.add_column("Description")
            for pkg in packages:
                table.add_row(
                    pkg["name"], pkg["classification"], pkg["ref"], pkg["description"]
                )
            console.print(table)
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
@click.argument("query")
def search(query: str) -> None:
    """Search for knowledge packages."""
    engine = _get_engine()
    try:
        results = engine.search(query)
        if not results:
            console.print(f"[dim]No packages matching '{query}'.[/]")
            return
        table = Table(title=f"Search: '{query}'")
        table.add_column("", width=2)
        table.add_column("Package", style="cyan")
        table.add_column("Type", style="green")
        table.add_column("Description")
        for pkg in results:
            table.add_row(
                pkg["installed"], pkg["name"],
                pkg["classification"], pkg["description"],
            )
        console.print(table)
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
def tree() -> None:
    """Show the package dependency tree."""
    engine = _get_engine()
    try:
        registry = engine._load_registry()
        config = engine._load_config()

        rich_tree = RichTree("[bold]Knowledge Tree[/]")

        # Find root packages (no parent)
        roots = [
            name for name, entry in registry.packages.items()
            if entry.parent is None
        ]

        def _add_children(parent_tree: RichTree, parent_name: str) -> None:
            children = registry.get_children(parent_name)
            for child in sorted(children):
                entry = registry.packages[child]
                installed = "✓ " if config.is_installed(child) else "  "
                style = "green" if config.is_installed(child) else "dim"
                label = (
                    f"[{style}]{installed}{child}[/] "
                    f"[dim]({entry.classification})[/]"
                )
                child_tree = parent_tree.add(label)
                _add_children(child_tree, child)

        for root in sorted(roots):
            entry = registry.packages[root]
            installed = "✓ " if config.is_installed(root) else "  "
            style = "green" if config.is_installed(root) else "dim"
            label = (
                f"[{style}]{installed}{root}[/] "
                f"[dim]({entry.classification})[/]"
            )
            root_tree = rich_tree.add(label)
            _add_children(root_tree, root)

        console.print(rich_tree)
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
def update() -> None:
    """Pull latest knowledge from the registry."""
    engine = _get_engine()
    try:
        with console.status("Updating from registry..."):
            result = engine.update()
        if result["updated"]:
            console.print(
                f"[bold green]✓[/] Updated {len(result['updated'])} packages:"
            )
            for name in result["updated"]:
                console.print(f"  • {name}")
        else:
            console.print("[bold green]✓[/] All packages are up to date.")
        if result["new_available"]:
            console.print(
                f"\n[yellow]{len(result['new_available'])} new packages "
                f"available:[/]"
            )
            for name in result["new_available"][:5]:
                console.print(f"  • {name}")
            if len(result["new_available"]) > 5:
                console.print(
                    f"  ... and {len(result['new_available']) - 5} more. "
                    f"Run [bold]kt list --available[/] to see all."
                )
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
def status() -> None:
    """Show project knowledge status."""
    engine = _get_engine()
    try:
        s = engine.get_status()
        console.print("[bold]Knowledge Tree Status[/]")
        console.print()
        console.print(f"  Registry:   {s['registry']}")
        console.print(f"  Branch:     {s['registry_ref']}")
        console.print(
            f"  Packages:   {s['installed_packages']} installed / "
            f"{s['available_packages']} available"
        )
        console.print(
            f"  Knowledge:  {s['total_files']} files, "
            f"{s['total_lines']:,} lines"
        )
        console.print(f"  Telemetry:  {s['telemetry']}")
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
@click.argument("package")
def info(package: str) -> None:
    """Show detailed information about a package."""
    engine = _get_engine()
    try:
        i = engine.get_info(package)
        console.print(f"[bold]{i['name']}[/]")
        console.print(f"  {i['description']}")
        console.print()
        console.print(f"  Version:        {i.get('version', 'n/a')}")
        console.print(f"  Classification: {i['classification']}")
        installed = "[green]yes[/]" if i["installed"] else "[dim]no[/]"
        console.print(f"  Installed:      {installed}")
        if i.get("authors"):
            console.print(f"  Authors:        {', '.join(i['authors'])}")
        if i.get("tags"):
            console.print(f"  Tags:           {', '.join(i['tags'])}")
        if i.get("parent") and i["parent"] != "none":
            console.print(f"  Parent:         {i['parent']}")
        if i.get("depends_on"):
            console.print(f"  Depends on:     {', '.join(i['depends_on'])}")
        if i.get("suggests"):
            console.print(f"  Suggests:       {', '.join(i['suggests'])}")
        if i.get("children"):
            console.print(f"  Children:       {', '.join(i['children'])}")
        if i.get("content"):
            console.print(f"  Content files:  {len(i['content'])}")
            for f in i["content"]:
                console.print(f"    • {f}")
    except KnowledgeTreeError as e:
        _handle_error(e)


@cli.command()
@click.argument("path", type=click.Path(exists=True), default=".")
@click.option("--all", "validate_all", is_flag=True, help="Validate all packages in the registry.")
def validate(path: str, validate_all: bool) -> None:
    """Validate a knowledge package or the entire registry."""
    engine = _get_engine()
    try:
        if validate_all:
            result = engine.validate_all(Path(path) if path != "." else None)
            console.print(
                f"Checked [bold]{result['packages_checked']}[/] packages"
            )
            if result["packages_with_errors"] == 0:
                console.print("[bold green]✓[/] All packages are valid!")
            else:
                console.print(
                    f"[bold red]✗[/] {result['packages_with_errors']} packages "
                    f"have issues:"
                )
                for pkg_path, errors in result["errors"].items():
                    console.print(f"\n  [bold]{pkg_path}[/]")
                    for error in errors:
                        if error.startswith("WARN:"):
                            console.print(f"    [yellow]⚠ {error}[/]")
                        else:
                            console.print(f"    [red]✗ {error}[/]")
        else:
            errors = engine.validate_package(Path(path))
            if not errors:
                console.print("[bold green]✓[/] Package is valid!")
            else:
                for error in errors:
                    if error.startswith("WARN:"):
                        console.print(f"[yellow]⚠ {error}[/]")
                    else:
                        console.print(f"[red]✗ {error}[/]")
    except KnowledgeTreeError as e:
        _handle_error(e)


# ---------------------------------------------------------------------------
# Phase 2: Contributor commands
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option("--name", required=True, help="Name for the knowledge package (kebab-case).")
@click.option("--description", "-d", default="", help="Package description.")
@click.option("--to", "to_existing", default=None, help="Add as child of existing community package.")
@click.option("--tag", "-t", multiple=True, help="Tags for discovery (repeatable).")
@click.option("--dry-run", is_flag=True, help="Preview what will be created without pushing.")
def contribute(
    files: tuple[str, ...],
    name: str,
    description: str,
    to_existing: str | None,
    tag: tuple[str, ...],
    dry_run: bool,
) -> None:
    """Contribute knowledge to the community pool.

    Examples:

        kt contribute my-tips.md --name docker-tips

        kt contribute guide.md --name aws-tips --to docker-tips

        kt contribute notes.md --name my-pkg --dry-run
    """
    engine = _get_engine()
    content_paths = [Path(f) for f in files]

    if dry_run:
        console.print("[bold]Dry run — nothing will be pushed.[/]")
        console.print()
        console.print(f"  Package name:  [cyan]{name}[/]")
        console.print(f"  Description:   {description or '(auto-generated)'}")
        if to_existing:
            console.print(f"  Parent:        {to_existing}")
        console.print(f"  Files:         {', '.join(f.name for f in content_paths)}")
        if tag:
            console.print(f"  Tags:          {', '.join(tag)}")
        console.print(f"  Branch:        contribute/{name}")
        console.print(f"  Location:      community/{name}/")
        return

    try:
        with console.status("Creating contribution..."):
            result = engine.contribute(
                content_paths,
                name=name,
                description=description,
                tags=list(tag),
                to_existing=to_existing,
            )
        console.print(f"[bold green]✓[/] Contribution created!")
        console.print()
        console.print(f"  Package:  [cyan]{result['package']}[/]")
        console.print(f"  Branch:   {result['branch']}")
        console.print(f"  Files:    {', '.join(result['files'])}")
        console.print()
        console.print("[bold]Create a merge request:[/]")
        console.print(f"  {result['mr_url']}")
    except KnowledgeTreeError as e:
        _handle_error(e)


# ---------------------------------------------------------------------------
# Registry management
# ---------------------------------------------------------------------------


@cli.group()
def registry() -> None:
    """Manage the knowledge registry."""


@registry.command()
@click.argument("path", type=click.Path(exists=True), default=".")
def rebuild(path: str) -> None:
    """Rebuild registry.yaml from package directories.

    Run this in the root of a knowledge registry repo.
    """
    engine = _get_engine()
    try:
        result = engine.registry_rebuild(Path(path))
        console.print(
            f"[bold green]✓[/] Registry rebuilt with "
            f"[bold]{result['total_packages']}[/] packages"
        )
        console.print(f"  Written to: {result['registry_path']}")
    except KnowledgeTreeError as e:
        _handle_error(e)
