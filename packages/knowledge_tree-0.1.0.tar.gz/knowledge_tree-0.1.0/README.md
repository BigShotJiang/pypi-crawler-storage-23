# Knowledge Tree 🌲

**Crowdsourced knowledge management for AI coding agents.**

Knowledge Tree (`kt`) lets teams collaboratively build, curate, and distribute knowledge that AI coding agents use to understand codebases, tools, services, and conventions.

## Why?

AI coding agents (Copilot, Cursor, Cline, etc.) are powerful but lack **organizational context** — your team's conventions, service architectures, known pitfalls, and best practices. Knowledge Tree solves this by providing a shared, versioned, searchable knowledge base that agents can read.

## Install

```bash
# From PyPI (recommended)
pip install knowledge-tree

# With pipx (isolated install)
pipx install knowledge-tree

# Zero-install with uvx
uvx knowledge-tree kt --help
```

## Quick Start

```bash
# 1. Initialize your project with a knowledge registry
kt init --from git@github.com:your-org/kt-registry.git

# 2. Browse available packages
kt list --available

# 3. Install packages you need
kt add base
kt add python-patterns    # auto-installs dependencies

# 4. Check what you have
kt status
kt tree

# 5. AI agents read .knowledge/KNOWLEDGE_MANIFEST.md for context
```

## Commands

### Consuming Knowledge

| Command | Description |
|---------|-------------|
| `kt init --from <url>` | Initialize project with a registry |
| `kt add <package>` | Install a package (with dependencies) |
| `kt remove <package>` | Remove a package |
| `kt update` | Pull latest from registry |
| `kt list` | List installed packages |
| `kt list --available` | List all available packages |
| `kt search <query>` | Search by name, description, or tags |
| `kt tree` | Show package hierarchy |
| `kt status` | Show project knowledge status |
| `kt info <package>` | Detailed package information |
| `kt validate` | Validate a package |

### Contributing Knowledge

| Command | Description |
|---------|-------------|
| `kt contribute <files> --name <name>` | Create a new community package |
| `kt contribute <files> --name <name> --to <existing>` | Add to an existing package |
| `kt contribute --dry-run` | Preview without pushing |
| `kt list --community` | List community pool packages |
| `kt registry rebuild` | Regenerate registry index |
| `kt validate --all` | Validate all packages |

## How It Works

```
            ┌─────────────────┐
            │  Git Registry   │ ← Single repo with all packages
            │  (Any git host) │
            └────────┬────────┘
                     │ clone / pull
                     ▼
            ┌─────────────────┐
            │  kt CLI         │ ← pip install knowledge-tree
            │  init/add/update│
            └────────┬────────┘
                     │ materialize
                     ▼
            ┌─────────────────┐
            │  .knowledge/    │ ← Markdown files for AI agents
            │  MANIFEST.md    │
            │  base/          │
            │  python-patterns│
            └─────────────────┘
```

**Knowledge flows down, contributions flow up.** Users install curated packages. Contributors push to the community pool, which gets reviewed and promoted.

## Creating a Registry

A knowledge registry is a git repo with this structure:

```
my-registry/
├── registry.yaml      # Auto-generated package index
├── CONTRIBUTING.md     # How to contribute
├── packages/           # Curated, evergreen packages
│   ├── base/
│   │   ├── package.yaml
│   │   └── conventions.md
│   └── python-patterns/
│       ├── package.yaml
│       └── patterns.md
└── community/          # Uncurated, seasonal contributions
```

## License

MIT — see [LICENSE](LICENSE).
