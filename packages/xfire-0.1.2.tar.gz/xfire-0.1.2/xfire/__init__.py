"""xfire — Multiple agents. One verdict. Zero blind spots."""

__version__ = "0.1.2"
