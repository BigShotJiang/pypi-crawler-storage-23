"""VM runtime for agent execution in Firecracker VMs."""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from pathlib import Path
from typing import TYPE_CHECKING

from opentelemetry import trace
from pydantic import BaseModel

from plato.agents.runtime.base import AgentContext, OTelContext, PreparedAgent, Runtime
from plato.agents.runtime.workspace import Workspace, rsync_to
from plato.v2 import Env
from plato.v2.types import SimConfigCompute

if TYPE_CHECKING:
    from plato.v2.async_.environment import Environment
    from plato.v2.async_.session import Session

logger = logging.getLogger(__name__)


class VMConfig(BaseModel):
    """Configuration for agent VMs."""

    cpus: int = 1
    memory: int = 2048
    disk: int = 10240
    timeout: int = 1800
    """Job timeout in seconds. The VM is killed after this duration (default: 1800 = 30 min)."""


class PlatoVMRuntime(Runtime):
    """Run agents in Firecracker VMs.

    Supports two modes:
    - Dev mode (dev_mode=True): Syncs SDK and agent code from world VM to agent VMs
      for hot-reload development
    - Non-dev mode (dev_mode=False): Uses code from Docker image, only syncs workspace

    Agent code syncing flow (dev mode only):
    1. Dev runner syncs code from local machine → world VM at /agents/<name>/
    2. World calls run_agent() with agent_code_path=/agents/<name>/ and dev_mode=True
    3. PlatoVMRuntime creates agent VM and syncs /agents/<name>/ → /app on agent VM
    4. Agent runs with the synced code
    """

    def __init__(
        self,
        session: Session,
        ssh_key_path: Path | None = None,
        vm_config: VMConfig | None = None,
        workspace: Workspace | None = None,
    ):
        """Initialize VM runtime.

        Args:
            session: Plato session for creating VMs
            ssh_key_path: Path to SSH private key for rsync (optional, only needed for dev mode)
            vm_config: VM resource configuration
            workspace: Workspace implementation for sharing files with agent VMs
        """
        self.session = session
        self.ssh_key_path = ssh_key_path
        self.vm_config = vm_config or VMConfig()
        self.workspace = workspace
        self._agent_envs: dict[str, Environment] = {}

    async def run(self, ctx: AgentContext) -> str:
        """Run an agent in a Firecracker VM: create → setup → execute → cleanup."""
        prepared = await self.prepare(ctx)
        try:
            await self.execute(prepared, ctx)
        except Exception:
            await self.cleanup(prepared.agent_id, error=True)
            raise
        else:
            await self.cleanup(prepared.agent_id)
        return prepared.agent_id

    async def prepare(self, ctx: AgentContext) -> PreparedAgent:
        """Start agent VM with desktop/Chrome but without running the task.

        Creates the VM, sets up networking and SSH, syncs code/workspace,
        but does NOT execute the agent command.
        """
        agent_alias = f"agent-{uuid.uuid4().hex[:8]}"

        agent_env = await self._create_vm(ctx.image, agent_alias)
        self._agent_envs[agent_alias] = agent_env

        try:
            await self._setup_network()

            # Fetch mesh IP once for all SSH/rsync operations
            mesh_ip = await agent_env.get_mesh_ip()
            if not mesh_ip:
                raise RuntimeError(f"Failed to get mesh IP for agent VM {agent_alias}")

            await self._sync_code(ctx, agent_env, mesh_ip)
        except Exception:
            await self.cleanup(agent_alias, error=True)
            raise

        return PreparedAgent(
            agent_id=agent_alias,
            hostname=mesh_ip,
            runtime=self,
        )

    async def execute(self, prepared: PreparedAgent, ctx: AgentContext) -> None:
        """Execute agent task in a prepared VM via SSH."""
        agent_env = self._agent_envs.get(prepared.agent_id)
        if not agent_env:
            raise RuntimeError(f"No VM found for agent {prepared.agent_id}")

        await self._execute_agent(ctx, agent_env, prepared.hostname)

        # Sync workspace back after execution
        await self._sync_workspace_back(ctx, agent_env, prepared.hostname)

    async def cleanup(self, agent_id: str, error: bool = False) -> None:
        """Clean up an agent VM."""
        # agent_id could be job_id or alias, check both
        agent_env = self._agent_envs.pop(agent_id, None)
        if not agent_env:
            # Try to find by job_id
            for alias, env in list(self._agent_envs.items()):
                if env.job_id == agent_id:
                    agent_env = self._agent_envs.pop(alias)
                    break

        if agent_env:
            try:
                logger.info(f"Cleaning up agent VM: {agent_env.job_id}")
                await self.session.remove_env(agent_env)
            except Exception as e:
                logger.warning(f"Failed to clean up agent VM: {e}")

    async def _create_vm(self, image: str, alias: str) -> Environment:
        """Create an agent VM."""
        logger.info(
            f"Creating agent VM: {alias} (image: {image}, cpus={self.vm_config.cpus}, mem={self.vm_config.memory}MB)"
        )
        logger.info("  This may take a moment if the image needs to be pulled...")

        agent_env = await self.session.add_env(
            Env.resource(
                simulator=alias,
                sim_config=SimConfigCompute(
                    cpus=self.vm_config.cpus,
                    memory=self.vm_config.memory,
                    disk=self.vm_config.disk,
                ),
                alias=alias,
                docker_image_url=image,
                upload_rootfs=False,
                rootfs_storage_backend="snapshot-store",
            ),
            timeout=self.vm_config.timeout,
        )

        logger.debug(f"Agent VM ready: {agent_env.job_id}")
        return agent_env

    async def _setup_network(self) -> None:
        """Setup network connectivity to agent VM."""
        await self.session.connect_network()

        if not self.ssh_key_path:
            raise RuntimeError("ssh_key_path must be set before running agents")

        # Re-add SSH key so the newly created agent VM gets it
        pub_key = Path(str(self.ssh_key_path) + ".pub").read_text().strip()
        await self.session.add_ssh_key(pub_key)

    def _parse_image_url(self, image: str) -> tuple[str, str]:
        """Extract package name and version from image URL.

        Format: .../plato-agents/claude-code:0.0.0.dev9
        Returns: (package_name, version)
        """
        # Get the last part: claude-code:0.0.0.dev9
        last_part = image.split("/")[-1]
        if ":" in last_part:
            name, version = last_part.rsplit(":", 1)
            return name, version
        return last_part, "latest"

    async def _sync_code(self, ctx: AgentContext, agent_env: Environment, hostname: str) -> None:
        """Sync workspace and install agent code on VM.

        Dev mode is detected by presence of /sdk on world VM (set up by DevRunner).
        In dev mode: syncs SDK and agent code for hot-reload development.
        In non-dev mode: installs agent package from PyPI.
        """

        # Sync workspace via workspace abstraction
        if self.workspace:
            await self.workspace.setup_agent(agent_env, hostname)

        # Dev mode is detected by /sdk existing (DevRunner syncs it to world VM)
        sdk_path = Path("/sdk")
        is_dev_mode = sdk_path.exists()

        if is_dev_mode:
            if not self.ssh_key_path:
                raise RuntimeError("ssh_key_path required for dev mode code sync")

            # Dev mode: sync SDK and agent code, then install together
            # Installing together lets uv resolve the editable SDK as satisfying
            # the agent's pinned plato-sdk-v2 dependency.
            editable_paths: list[str] = []

            logger.debug(f"Syncing SDK: {sdk_path} -> /sdk")
            await rsync_to(
                self.ssh_key_path,
                sdk_path,
                "/sdk",
                hostname,
                chown="superman:superman",
            )
            editable_paths.append("/sdk")

            # Auto-detect agent code: DevRunner syncs it to /agents/<name>/
            agent_code_path = ctx.agent_code_path
            if not agent_code_path:
                agents_dir = Path("/agents")
                if agents_dir.exists():
                    agent_dirs = [d for d in agents_dir.iterdir() if d.is_dir() and (d / "pyproject.toml").exists()]
                    if agent_dirs:
                        agent_code_path = agent_dirs[0]

            if agent_code_path and agent_code_path.exists():
                logger.debug(f"Syncing agent code: {agent_code_path} -> /app")
                await rsync_to(
                    self.ssh_key_path,
                    agent_code_path,
                    "/app",
                    hostname,
                    chown="superman:superman",
                )
                editable_paths.append("/app")

            editables = " ".join(f"-e {p}" for p in editable_paths)
            logger.debug(f"Installing packages in editable mode: {editable_paths}")
            exit_code, stdout, stderr = await self._run_ssh(
                hostname, f"uv pip install --system {editables}", timeout=300
            )
            if exit_code != 0:
                raise RuntimeError(f"Failed to install packages: {stderr or stdout}")
        else:
            # Production mode: install agent package from PyPI
            package_name, version = self._parse_image_url(ctx.image)
            logger.debug(f"Installing agent package: {package_name}=={version}")

            # Fix uv cache/tools ownership (may have been created by root)
            await self._run_ssh(
                hostname,
                "rm -rf /home/superman/.cache/uv /home/superman/.local/share/uv && "
                "mkdir -p /home/superman/.cache/uv /home/superman/.local/share/uv /home/superman/.local/bin && "
                "chown -R superman:superman /home/superman/.cache /home/superman/.local",
                timeout=30,
            )

            api_key = os.environ.get("PLATO_API_KEY", "")
            pypi_url = f"https://__token__:{api_key}@plato.so/api/v2/pypi/agents/simple/"

            install_cmd = (
                f"uv tool install plato-sdk-v2 --python 3.12 "
                f"--with '{package_name}=={version}' "
                f"--index-url 'https://pypi.org/simple/' "
                f"--extra-index-url '{pypi_url}' "
                f"--index-strategy unsafe-best-match --prerelease allow --refresh --force"
            )
            exit_code, stdout, stderr = await self._run_ssh(hostname, install_cmd, user="superman", timeout=300)
            if exit_code != 0:
                raise RuntimeError(f"Failed to install agent package: {stderr or stdout}")

    async def _execute_agent(self, ctx: AgentContext, agent_env: Environment, hostname: str) -> None:
        """Execute the agent on the VM."""
        # Ensure localhost resolves (VM may not have it in /etc/hosts)
        exit_code, stdout, stderr = await self._run_ssh(
            hostname,
            "grep -q localhost /etc/hosts && echo 'ALREADY_EXISTS' || (echo '127.0.0.1 localhost' >> /etc/hosts && echo 'ADDED')",
            timeout=10,
        )
        result = stdout.strip()
        if result == "ADDED":
            logger.info(f"Added localhost to /etc/hosts on {hostname}")
        else:
            logger.info(f"localhost already in /etc/hosts on {hostname}")

        # Build environment variables
        env_vars = [
            "HOME=/home/superman",
            "USER=superman",
            "NVM_DIR=/home/superman/.nvm",
            "PATH=/home/superman/.local/bin:/usr/local/bin:/usr/bin:/bin",
            f"AGENT_CONFIG_B64={ctx.config_b64}",
        ]
        if ctx.runtime_b64:
            env_vars.append(f"AGENT_RUNTIME_B64={ctx.runtime_b64}")

        # Add OTel context
        otel = OTelContext.from_env()
        env_vars.extend(otel.to_env_vars())

        logger.info(f"Agent config keys: {list(ctx.config.keys())}")
        logger.info(f"OTEL URL: {otel.otel_url}")

        # Build command
        env_exports = " ".join(f'export {k}="{v}";' for var in env_vars for k, v in [var.split("=", 1)])
        agent_cmd = f'{env_exports} cd /workspace && plato-agent-runner run --instruction-b64 "{ctx.instruction_b64}"'

        # Execute via SSH as superman user (with streaming output)
        logger.info("Executing agent command on VM via SSH as 'superman' user...")
        exit_code = await self._run_ssh_streaming(
            hostname=hostname,
            command=agent_cmd,
            user="superman",
        )

        logger.info(f"Agent command completed with exit code: {exit_code}")

        if exit_code != 0:
            raise RuntimeError(f"Agent failed with exit code {exit_code}")

    async def _sync_workspace_back(self, ctx: AgentContext, agent_env: Environment, hostname: str) -> None:
        """Sync workspace back from agent VM to world VM after agent completes."""
        if not self.workspace:
            return

        await self.workspace.sync_back(agent_env, hostname)

    async def _run_ssh(
        self,
        hostname: str,
        command: str,
        user: str = "root",
        timeout: int = 300,
    ) -> tuple[int, str, str]:
        """Run a command via SSH and return exit code, stdout, stderr."""
        if user != "root":
            escaped_cmd = command.replace("\\", "\\\\").replace('"', '\\"')
            command = f'su - {user} -c "{escaped_cmd}"'

        ssh_cmd = [
            "ssh",
            "-i",
            str(self.ssh_key_path),
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            "-o",
            "LogLevel=ERROR",
            "-o",
            "ServerAliveInterval=30",
            "-o",
            "ServerAliveCountMax=3",
            f"root@{hostname}",
            command,
        ]

        logger.debug(f"SSH running command as {user}: {command[:200]}...")

        process = await asyncio.create_subprocess_exec(
            *ssh_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            process.kill()
            raise RuntimeError(f"SSH command timed out after {timeout}s")

        exit_code = process.returncode or 0
        stdout_str = stdout.decode("utf-8", errors="replace")
        stderr_str = stderr.decode("utf-8", errors="replace")

        if exit_code != 0:
            logger.warning(f"SSH command failed: exit_code={exit_code}")
            if stdout_str:
                logger.warning(f"SSH stdout: {stdout_str}")
            if stderr_str:
                logger.warning(f"SSH stderr: {stderr_str}")
        else:
            logger.debug(f"SSH command finished: exit_code={exit_code}")

        return exit_code, stdout_str, stderr_str

    async def _run_ssh_streaming(
        self,
        hostname: str,
        command: str,
        user: str = "root",
    ) -> int:
        """Run a command via SSH with real-time output streaming."""
        if user != "root":
            escaped_cmd = command.replace("\\", "\\\\").replace('"', '\\"')
            command = f'su - {user} -c "{escaped_cmd}"'

        ssh_cmd = [
            "ssh",
            "-i",
            str(self.ssh_key_path),
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            "-o",
            "LogLevel=ERROR",
            "-o",
            "ServerAliveInterval=30",
            "-o",
            "ServerAliveCountMax=3",
            f"root@{hostname}",
            command,
        ]

        logger.debug(f"SSH running command as {user}: {command[:200]}...")

        process = await asyncio.create_subprocess_exec(
            *ssh_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        tracer = trace.get_tracer(__name__)
        output_lines: list[str] = []
        stdout = process.stdout
        if stdout:
            with tracer.start_as_current_span("agent.execution.output") as span:
                span.set_attribute("agent.user", user)
                span.set_attribute("agent.hostname", hostname)
                while True:
                    line = await stdout.readline()
                    if not line:
                        break
                    output_lines.append(line.decode("utf-8", errors="replace").rstrip())
                span.set_attribute("agent.lines_read", len(output_lines))

        await process.wait()

        # Log agent output as a single block
        if output_lines:
            output_block = "\n".join(output_lines)
            logger.info(f"Agent output ({len(output_lines)} lines):\n{output_block}")

        logger.info(f"Agent command finished: exit_code={process.returncode}")
        return process.returncode or 0
