"""Plato Chronos CLI - Launch and manage Chronos jobs."""

from plato.cli.chronos.main import chronos_app

__all__ = ["chronos_app"]
