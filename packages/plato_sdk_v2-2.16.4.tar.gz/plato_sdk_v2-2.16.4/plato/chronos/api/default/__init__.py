"""API endpoints."""

from . import health

__all__ = [
    "health",
]
