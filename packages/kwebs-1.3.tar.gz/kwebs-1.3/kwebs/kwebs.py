from .common import *
from kunapi import kunapi
import os,shutil
def cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr='kwebs'):
    "脚本入口"
    
    cmd_par=kunapi.get_cmd_par(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
    if cmd_par and not cmd_par['project']:
        cmd_par['project']='kwebs'
    if cmd_par and cmd_par['install'] and not cmd_par['help']:#插入 应用、模块、插件
        if cmd_par['appname']:
            remppath=os.path.split(os.path.realpath(__file__))[0]
            if not os.path.exists(cmd_par['project']+'/'+cmd_par['appname']) and not os.path.exists(cmd_par['appname']):
                shutil.copytree(remppath+'/tempfile/kwebs',cmd_par['project'])
                print('kwebs项目创建成功')
            else:
                return kunapi.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
        else:
            return kunapi.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
    elif cmd_par:
        return kunapi.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)