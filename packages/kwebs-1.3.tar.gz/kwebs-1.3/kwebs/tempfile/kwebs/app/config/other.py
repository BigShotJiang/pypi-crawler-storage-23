# -*- coding: utf-8 -*-
from kwebs.config import *