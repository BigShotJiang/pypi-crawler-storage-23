# 📚 CODE

class CODE_CODES:

    @classmethod
    def COLLECTOR(cls) -> str:
        '''🧩 Allows trust relationships between Sellers and Collectors.
        * https://quip.com/HyzNATeThi0Q/-PayNLWEBorg#temp:C:VGK14086dfbb4124ce9ac0938412'''
        return 'nlweb.org/PAY/COLLECTOR'

    @classmethod
    def EPHEMERAL(cls) -> str:
        '''🧩 Generates temporary pins to force users to touch locators.'''
        return 'nlweb.org/DEVICES/EPHEMERAL'

    @classmethod
    def HOST(cls) -> str:
        '''🧩 Code for login.'''
        return 'nlweb.org/HOST'

    @classmethod
    def PAYER(cls) -> str:
        '''🧩 A domain that pays on behalf of others.
         * https://quip.com/HyzNATeThi0Q#temp:C:VGK51ec801c0467435d936031358'''
        return 'nlweb.org/PAY/PAYER'

    @classmethod
    def PAYMENT(cls) -> str:
        '''🧩 A payment.
        * https://quip.com/HyzNATeThi0Q#temp:C:VGKd1f4d27ff87749418add494a9'''
        return 'nlweb.org/PAY/PAYMENT'

    @classmethod
    def SELFIE(cls) -> str:
        '''🧩 Validate the face biometrics of users.
        * https://quip.com/wNPSADRFLC9s/-Selfie'''
        return 'nlweb.org/IDENTITY/SELFIE'

    @classmethod
    def TRANSCRIBE(cls) -> str:
        '''🧩 Records a message from the user.
        * https://quip.com/ggYBAWuO9Gkb/-Transcriber'''
        return 'nlweb.org/TRANSCRIBE'

    @classmethod
    def BIND(cls) -> str:
        '''🧩 Bind nlweb.org/VAULT/BIND'''
        return 'nlweb.org/VAULT/BIND'
