"""Compatibility loader for the PollyWeb utilities module."""

import PW_UTILS as nl

__all__ = ["nl"]
