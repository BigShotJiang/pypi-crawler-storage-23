# PollyWeb Domain

Domain manifests and message helpers for PollyWeb.

## Installation

```bash
pip install pollyweb-domain
```

## Development

```bash
make test
```

```bash
./scripts/publish.sh
```
