import secrets
import traceback as tb

from southstar import context, sanitizer, shipper


def init_southstar(app, api_key: str, service_name: str = 'flask-app', environment: str = 'production'):
    from southstar import db, http
    db.install_all()
    http.install_all()
    shipper.start_worker(api_key)

    cfg = {
        'service_name': service_name,
        'stack': 'flask',
        'environment': environment,
        'framework_version': '',
        'async_mode': False,
        'orm': 'sqlalchemy',
    }

    @app.before_request
    def _before():
        from flask import g
        g.southstar_ctx = context.TraceContext(trace_id=secrets.token_hex(16))
        context.set_current(g.southstar_ctx)

    @app.after_request
    def _after(response):
        from flask import g, request
        ctx = getattr(g, 'southstar_ctx', None)
        if ctx:
            span = sanitizer.build_span(ctx, cfg, request.method, request.path, response.status_code)
            shipper.enqueue(span)
            context.set_current(None)
        return response

    @app.teardown_request
    def _teardown(exc):
        from flask import g
        ctx = getattr(g, 'southstar_ctx', None)
        if ctx is None:
            return
        if exc is not None and ctx.error is None:
            frames = [
                {'file': f.filename, 'line': f.lineno, 'function': f.name}
                for f in tb.extract_tb(exc.__traceback__)
            ]
            ctx.set_error(type(exc).__name__, frames[-1]['file'] if frames else '', frames[-1]['line'] if frames else None, frames)
            # Ship the error span — after_request does NOT run on unhandled exceptions,
            # so this is the only chance to capture the error.
            from flask import request
            span = sanitizer.build_span(ctx, cfg, request.method, request.path, 500)
            shipper.enqueue(span)
            context.set_current(None)
