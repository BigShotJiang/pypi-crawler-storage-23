"""
Ships spans to either the local daemon (preferred) or South Star API directly.
All shipping is async — never blocks the customer's request.
"""
import logging
import os
import threading
import queue

logger = logging.getLogger(__name__)

LOCAL_DAEMON_URL = 'http://localhost:9999'
# M7: Make API URL configurable via env var
SOUTHSTAR_API_URL = os.getenv(
    'SOUTHSTAR_API_URL',
    'https://southstar.app/api/v1/ingest/traces/',
)
SHIP_TIMEOUT_S = 1.0
BATCH_SIZE = 50

_queue: queue.Queue = queue.Queue(maxsize=5000)
_worker_started = False
_lock = threading.Lock()


def _ship_batch(spans: list, api_key: str):
    import requests as req
    payload = {'spans': spans}
    headers = {'Content-Type': 'application/json'}

    # Try local daemon first — zero network latency
    try:
        r = req.post(LOCAL_DAEMON_URL, json=payload, timeout=0.3)
        if r.ok:
            return
    except Exception:
        pass

    # Fall back to South Star API directly
    try:
        req.post(
            SOUTHSTAR_API_URL,
            json=payload,
            headers={**headers, 'X-API-Key': api_key},
            timeout=SHIP_TIMEOUT_S,
        )
    except Exception as exc:
        logger.debug('South Star shipper: %s', exc)


def _worker(api_key: str):
    batch = []
    while True:
        try:
            span = _queue.get(timeout=5)
            batch.append(span)
            if len(batch) >= BATCH_SIZE:
                _ship_batch(batch, api_key)
                batch = []
        except queue.Empty:
            if batch:
                _ship_batch(batch, api_key)
                batch = []


def start_worker(api_key: str):
    global _worker_started
    with _lock:
        if not _worker_started:
            t = threading.Thread(target=_worker, args=(api_key,), daemon=True, name='southstar-shipper')
            t.start()
            _worker_started = True


def enqueue(span: dict):
    """Non-blocking. If queue is full, drop silently — never break the customer's app."""
    try:
        _queue.put_nowait(span)
    except queue.Full:
        pass
