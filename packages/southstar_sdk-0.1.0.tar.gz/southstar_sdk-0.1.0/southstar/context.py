"""
Thread-safe and async-safe trace context.
Uses contextvars.ContextVar so it works with both sync (threading) and async (asyncio/anyio).
"""
import hashlib
import time
from collections import Counter
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Optional

_current_trace: ContextVar[Optional["TraceContext"]] = ContextVar("southstar_trace", default=None)

SLOW_QUERY_THRESHOLD_MS = 100


@dataclass
class QueryRecord:
    raw_sql: str
    duration_ms: float
    rows_examined: int
    db_driver: str

    @property
    def query_hash(self) -> str:
        return hashlib.sha256(self._normalize(self.raw_sql).encode()).hexdigest()[:16]

    @property
    def normalized_sql(self) -> str:
        return self._normalize(self.raw_sql)

    @property
    def query_type(self) -> str:
        first = self.normalized_sql.strip().split()[0].upper() if self.normalized_sql.strip() else ""
        if first in ("SELECT", "WITH"):
            return "SELECT"
        if first == "INSERT":
            return "INSERT"
        if first == "UPDATE":
            return "UPDATE"
        if first == "DELETE":
            return "DELETE"
        return "OTHER"

    @staticmethod
    def _normalize(sql: str) -> str:
        import re
        sql = re.sub(r"'[^']*'", "?", sql)
        sql = re.sub(r'\b\d+\b', "?", sql)
        sql = " ".join(sql.lower().split())
        return sql[:2000]


@dataclass
class OutboundCallRecord:
    host: str
    path: str
    method: str
    status_code: int
    duration_ms: float


@dataclass
class ErrorRecord:
    error_type: str
    error_file: str
    error_line: Optional[int]
    stack_frames: list = field(default_factory=list)


@dataclass
class TraceContext:
    trace_id: str
    start_time: float = field(default_factory=time.time)
    queries: list = field(default_factory=list)
    outbound_calls: list = field(default_factory=list)
    error: Optional[ErrorRecord] = None
    concurrent_requests: int = 0

    def add_query(self, sql: str, duration_ms: float, rows_examined: int, db_driver: str):
        self.queries.append(QueryRecord(
            raw_sql=sql,
            duration_ms=duration_ms,
            rows_examined=rows_examined,
            db_driver=db_driver,
        ))

    def add_outbound_call(self, host: str, path: str, method: str, status_code: int, duration_ms: float):
        self.outbound_calls.append(OutboundCallRecord(
            host=host, path=path, method=method,
            status_code=status_code, duration_ms=duration_ms,
        ))

    def set_error(self, error_type: str, error_file: str, error_line: Optional[int], stack_frames: list):
        self.error = ErrorRecord(
            error_type=error_type,
            error_file=error_file,
            error_line=error_line,
            stack_frames=stack_frames,
        )

    @property
    def elapsed_ms(self) -> float:
        return (time.time() - self.start_time) * 1000

    @property
    def db_select_count(self) -> int:
        return sum(1 for q in self.queries if q.query_type == "SELECT")

    @property
    def db_write_count(self) -> int:
        return sum(1 for q in self.queries if q.query_type in ("INSERT", "UPDATE", "DELETE"))

    @property
    def has_slow_query(self) -> bool:
        return any(q.duration_ms > SLOW_QUERY_THRESHOLD_MS for q in self.queries)

    @property
    def slowest_query_ms(self) -> float:
        return max((q.duration_ms for q in self.queries), default=0.0)

    @property
    def outbound_duplicate_count(self) -> int:
        host_counts = Counter(c.host for c in self.outbound_calls)
        return sum(1 for count in host_counts.values() if count > 1)


def get_current() -> Optional[TraceContext]:
    return _current_trace.get()


def set_current(ctx: Optional[TraceContext]):
    _current_trace.set(ctx)
