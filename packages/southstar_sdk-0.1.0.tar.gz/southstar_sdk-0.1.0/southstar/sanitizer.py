PAYMENT_PATTERNS = ["/payment", "/checkout", "/billing", "/stripe", "/invoice", "/card", "/refund"]


def is_payment_route(route: str) -> bool:
    r = route.lower()
    return any(p in r for p in PAYMENT_PATTERNS)


def build_span(
    trace_ctx,
    config: dict,
    http_method: str,
    http_route: str,
    http_status_code: int,
    source_file: str = "",
    source_function: str = "",
    source_line: int = None,
) -> dict:
    """Assemble the final sanitized span from a completed TraceContext."""
    # Payment blackout
    if is_payment_route(http_route):
        http_route = "[PAYMENT ENDPOINT]"
        db_queries = []
        outbound_calls = []
        error = None
        # Reset computed stats for payment routes
        db_select_count = db_write_count = 0
        has_slow_query = False
        slowest_query_ms = 0.0
        outbound_duplicate_count = 0
    else:
        db_queries = [
            {
                "query_hash": q.query_hash,
                "normalized_sql": q.normalized_sql,
                "duration_ms": round(q.duration_ms, 2),
                "rows_examined": q.rows_examined,
                "db_driver": q.db_driver,
                "query_type": q.query_type,
            }
            for q in trace_ctx.queries
        ]
        outbound_calls = [
            {
                "host": c.host,
                "path": c.path,
                "method": c.method,
                "status_code": c.status_code,
                "duration_ms": round(c.duration_ms, 2),
            }
            for c in trace_ctx.outbound_calls
        ]
        err = trace_ctx.error
        error = {
            "error_type": err.error_type,
            "error_file": err.error_file,
            "error_line": err.error_line,
            "stack_frames": err.stack_frames,
        } if err else None
        db_select_count = trace_ctx.db_select_count
        db_write_count = trace_ctx.db_write_count
        has_slow_query = trace_ctx.has_slow_query
        slowest_query_ms = round(trace_ctx.slowest_query_ms, 2)
        outbound_duplicate_count = trace_ctx.outbound_duplicate_count

    return {
        "trace_id": trace_ctx.trace_id,
        "service_name": config["service_name"],
        "stack": config["stack"],
        "language": "python",
        "framework_version": config.get("framework_version", ""),
        "async_mode": config.get("async_mode", False),
        "orm": config.get("orm", "unknown"),
        "environment": config.get("environment", "production"),
        "timestamp_ms": int(trace_ctx.start_time * 1000),
        "duration_ms": round(trace_ctx.elapsed_ms, 2),
        "source_location": {
            "file": source_file,
            "function": source_function,
            "line": source_line,
        },
        "attributes": {
            "http.method": http_method,
            "http.route": http_route,
            "http.status_code": http_status_code,
            "db_queries": db_queries,
            "outbound_calls": outbound_calls,
            "error": error,
            # Computed signals for the AI context assembler
            "db_select_count": db_select_count,
            "db_write_count": db_write_count,
            "has_slow_query": has_slow_query,
            "slowest_query_ms": slowest_query_ms,
            "outbound_duplicate_count": outbound_duplicate_count,
            "concurrent_requests": trace_ctx.concurrent_requests,
        },
    }
