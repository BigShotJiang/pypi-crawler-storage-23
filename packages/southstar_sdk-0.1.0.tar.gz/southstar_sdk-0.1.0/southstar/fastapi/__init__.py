import secrets
import traceback as tb

from southstar import context, sanitizer, shipper


class SouthStarMiddleware:
    def __init__(self, app, api_key: str, service_name: str = 'fastapi-app', environment: str = 'production'):
        self.app = app
        self.config = {
            'service_name': service_name,
            'stack': 'fastapi',
            'environment': environment,
            'framework_version': '',
            'async_mode': True,
            'orm': 'sqlalchemy',
        }
        from southstar import db, http
        db.install_all()
        http.install_all()
        shipper.start_worker(api_key)

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            await self.app(scope, receive, send)
            return

        ctx = context.TraceContext(trace_id=secrets.token_hex(16))
        context.set_current(ctx)

        status_code = 500
        # Prefer the route pattern (/users/{id}) over the concrete path (/users/123).
        # Starlette/FastAPI populates scope['route'] on matched routes.
        starlette_route = scope.get('route')
        route = getattr(starlette_route, 'path', None) if starlette_route else None
        if not route:
            route = scope.get('path', '')

        class _StatusCapture:
            async def __call__(inner_self, message):
                nonlocal status_code
                if message['type'] == 'http.response.start':
                    status_code = message.get('status', 500)
                await send(message)

        try:
            await self.app(scope, receive, _StatusCapture())
        except Exception as exc:
            frames = [
                {'file': f.filename, 'line': f.lineno, 'function': f.name}
                for f in tb.extract_tb(exc.__traceback__)
            ]
            ctx.set_error(type(exc).__name__, frames[-1]['file'] if frames else '', frames[-1]['line'] if frames else None, frames)
            raise
        finally:
            method = scope.get('method', 'GET')
            span = sanitizer.build_span(ctx, self.config, method, route, status_code)
            shipper.enqueue(span)
            context.set_current(None)
