from django.apps import AppConfig


class SouthStarConfig(AppConfig):
    name = 'southstar.django'
    label = 'southstar_sdk'
    verbose_name = 'South Star SDK'

    def ready(self):
        from django.conf import settings
        cfg = getattr(settings, 'SOUTHSTAR', {})
        if not cfg.get('api_key'):
            import warnings
            warnings.warn('SOUTHSTAR["api_key"] not set — SDK disabled.', stacklevel=2)
            return

        from southstar import db, http, shipper
        db.install_all()
        http.install_all()
        shipper.start_worker(cfg['api_key'])
