import secrets
import threading
import traceback as tb

from django.conf import settings

from southstar import context, sanitizer, shipper

# Thread-safe counter tracking in-flight requests on this process.
# Captured at request entry so the AI knows how loaded the server was.
_concurrent_count = 0
_concurrent_lock = threading.Lock()


def _increment_concurrent() -> int:
    global _concurrent_count
    with _concurrent_lock:
        _concurrent_count += 1
        return _concurrent_count


def _decrement_concurrent() -> None:
    global _concurrent_count
    with _concurrent_lock:
        _concurrent_count = max(0, _concurrent_count - 1)


def _resolve_route(request):
    """
    Resolve the URL pattern (e.g. /api/users/<int:pk>/) and view location.
    Returns (route_pattern, source_file, source_function).
    Falls back to request.path if resolution fails.
    """
    try:
        from django.urls import resolve
        match = resolve(request.path_info)
        func = match.func
        view_cls = getattr(func, "view_class", None)
        actual = view_cls or func
        source_file = getattr(actual, "__module__", "").replace(".", "/") + ".py"
        source_func = getattr(actual, "__name__", "")
        route_pattern = match.route if hasattr(match, 'route') else request.path
        return route_pattern, source_file, source_func
    except Exception:
        return request.path, "", ""


class SouthStarMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        cfg = getattr(settings, "SOUTHSTAR", {})
        self.config = {
            "service_name": cfg.get("service_name", "django-app"),
            "stack": "django",
            "environment": cfg.get("environment", "production"),
            "framework_version": "",
            "async_mode": False,
            "orm": "django_orm",
        }

    def __call__(self, request):
        concurrent = _increment_concurrent()
        ctx = context.TraceContext(
            trace_id=secrets.token_hex(16),
            concurrent_requests=concurrent,
        )
        context.set_current(ctx)

        route_pattern, source_file, source_func = _resolve_route(request)
        response = None
        try:
            response = self.get_response(request)
            return response
        except Exception as exc:
            frames = [
                {"file": f.filename, "line": f.lineno, "function": f.name}
                for f in tb.extract_tb(exc.__traceback__)
            ]
            ctx.set_error(
                type(exc).__name__,
                frames[-1]["file"] if frames else "",
                frames[-1]["line"] if frames else None,
                frames,
            )
            raise
        finally:
            _decrement_concurrent()
            status = response.status_code if response else 500
            span = sanitizer.build_span(
                trace_ctx=ctx,
                config=self.config,
                http_method=request.method,
                http_route=route_pattern,
                http_status_code=status,
                source_file=source_file,
                source_function=source_func,
            )
            shipper.enqueue(span)
            context.set_current(None)
