"""
Monkey-patches psycopg2's cursor.execute to capture per-query timing and structure.
"""
import logging
import time

logger = logging.getLogger(__name__)

_patched = False


def _extract_sql(query, cursor=None) -> str:
    """Safely extract SQL string from various psycopg2 query types."""
    if isinstance(query, bytes):
        return query.decode('utf-8', errors='replace')
    if isinstance(query, str):
        return query
    # psycopg2.sql.Composed and sql.SQL objects
    if hasattr(query, 'as_string') and cursor is not None:
        try:
            return query.as_string(cursor)
        except Exception:
            pass
    return str(query)


def install():
    global _patched
    if _patched:
        return
    try:
        import psycopg2.extensions as ext
        from southstar.context import get_current

        _orig_execute = ext.cursor.execute
        _orig_executemany = ext.cursor.executemany

        def _execute(self, query, vars=None):
            ctx = get_current()
            if ctx is None:
                return _orig_execute(self, query, vars)
            start = time.perf_counter()
            try:
                result = _orig_execute(self, query, vars)
                return result
            finally:
                elapsed = (time.perf_counter() - start) * 1000
                try:
                    sql = _extract_sql(query, self)
                    ctx.add_query(sql, elapsed, self.rowcount or 0, 'psycopg2')
                except Exception:
                    logger.debug('Failed to record query', exc_info=True)

        def _executemany(self, query, vars_list):
            ctx = get_current()
            if ctx is None:
                return _orig_executemany(self, query, vars_list)
            start = time.perf_counter()
            try:
                result = _orig_executemany(self, query, vars_list)
                return result
            finally:
                elapsed = (time.perf_counter() - start) * 1000
                try:
                    sql = _extract_sql(query, self)
                    ctx.add_query(f'[executemany] {sql}', elapsed, 0, 'psycopg2')
                except Exception:
                    logger.debug('Failed to record query', exc_info=True)

        ext.cursor.execute = _execute
        ext.cursor.executemany = _executemany
        _patched = True
    except ImportError:
        pass  # psycopg2 not installed — skip silently
