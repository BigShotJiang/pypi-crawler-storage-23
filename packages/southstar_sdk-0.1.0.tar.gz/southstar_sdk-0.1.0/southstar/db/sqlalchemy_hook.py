"""
Uses SQLAlchemy's built-in event system to capture per-query timing.
Works for both sync and async SQLAlchemy (via before_cursor_execute / after_cursor_execute).
"""
import logging
import time

logger = logging.getLogger(__name__)

_patched = False


def install():
    global _patched
    if _patched:
        return
    try:
        from sqlalchemy import event
        from sqlalchemy.engine import Engine
        from southstar.context import get_current

        @event.listens_for(Engine, 'before_cursor_execute')
        def _before(conn, cursor, statement, parameters, context, executemany):
            context._southstar_start = time.perf_counter()

        @event.listens_for(Engine, 'after_cursor_execute')
        def _after(conn, cursor, statement, parameters, context, executemany):
            ctx = get_current()
            if ctx is None:
                return
            try:
                start = getattr(context, '_southstar_start', None)
                if start is None:
                    return
                elapsed = (time.perf_counter() - start) * 1000
                ctx.add_query(statement, elapsed, cursor.rowcount or 0, 'sqlalchemy')
            except Exception:
                logger.debug('Failed to record query', exc_info=True)

        _patched = True
    except ImportError:
        pass
