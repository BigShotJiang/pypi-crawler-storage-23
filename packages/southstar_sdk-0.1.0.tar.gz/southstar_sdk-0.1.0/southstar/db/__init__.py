def install_all():
    from southstar.db import psycopg2_hook, sqlalchemy_hook
    psycopg2_hook.install()
    sqlalchemy_hook.install()
