"""
Monkey-patches requests.Session.send to capture outbound HTTP call timings.
"""
import logging
import time
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

_patched = False

# Hosts that belong to South Star — skip to avoid recursive instrumentation
_SKIP_HOSTS = frozenset(['localhost', '127.0.0.1', '::1'])


def _is_southstar_request(url: str) -> bool:
    try:
        parsed = urlparse(url)
        host = parsed.hostname or ''
        return host in _SKIP_HOSTS or 'southstar' in host
    except Exception:
        return False


def install():
    global _patched
    if _patched:
        return
    try:
        from requests import Session
        from southstar.context import get_current

        _orig_send = Session.send

        def _send(self, request, **kwargs):
            ctx = get_current()
            if ctx is None or _is_southstar_request(request.url):
                return _orig_send(self, request, **kwargs)

            start = time.perf_counter()
            response = _orig_send(self, request, **kwargs)
            elapsed = (time.perf_counter() - start) * 1000

            try:
                parsed = urlparse(request.url)
                ctx.add_outbound_call(
                    host=parsed.netloc,
                    path=parsed.path,
                    method=request.method,
                    status_code=response.status_code,
                    duration_ms=elapsed,
                )
            except Exception:
                logger.debug('Failed to record outbound call', exc_info=True)

            return response

        Session.send = _send
        _patched = True
    except ImportError:
        pass
