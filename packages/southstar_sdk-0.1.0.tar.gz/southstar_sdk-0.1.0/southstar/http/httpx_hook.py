"""
Patches httpx.Client.send and httpx.AsyncClient.send to capture outbound call timings.
"""
import logging
import time
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

_patched = False

_SKIP_HOSTS = frozenset(['localhost', '127.0.0.1', '::1'])


def _is_southstar_request(url: str) -> bool:
    try:
        parsed = urlparse(url)
        host = parsed.hostname or ''
        return host in _SKIP_HOSTS or 'southstar' in host
    except Exception:
        return False


def install():
    global _patched
    if _patched:
        return
    try:
        import httpx
        from southstar.context import get_current

        _orig_send = httpx.Client.send

        def _sync_send(self, request, **kwargs):
            url_str = str(request.url)
            ctx = get_current()
            if ctx is None or _is_southstar_request(url_str):
                return _orig_send(self, request, **kwargs)

            start = time.perf_counter()
            response = _orig_send(self, request, **kwargs)
            elapsed = (time.perf_counter() - start) * 1000

            try:
                parsed = urlparse(url_str)
                ctx.add_outbound_call(parsed.netloc, parsed.path, request.method, response.status_code, elapsed)
            except Exception:
                logger.debug('Failed to record outbound call', exc_info=True)

            return response

        httpx.Client.send = _sync_send

        # Async client
        _orig_async_send = httpx.AsyncClient.send

        async def _async_send(self, request, **kwargs):
            url_str = str(request.url)
            ctx = get_current()
            if ctx is None or _is_southstar_request(url_str):
                return await _orig_async_send(self, request, **kwargs)

            start = time.perf_counter()
            response = await _orig_async_send(self, request, **kwargs)
            elapsed = (time.perf_counter() - start) * 1000

            try:
                parsed = urlparse(url_str)
                ctx.add_outbound_call(parsed.netloc, parsed.path, request.method, response.status_code, elapsed)
            except Exception:
                logger.debug('Failed to record outbound call', exc_info=True)

            return response

        httpx.AsyncClient.send = _async_send
        _patched = True
    except ImportError:
        pass
