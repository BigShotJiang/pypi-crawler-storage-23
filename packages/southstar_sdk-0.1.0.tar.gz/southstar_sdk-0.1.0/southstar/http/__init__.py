def install_all():
    from southstar.http import requests_hook, httpx_hook
    requests_hook.install()
    httpx_hook.install()
