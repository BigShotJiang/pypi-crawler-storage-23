"""Validator executor handler for Hybrid Orchestrator.

This module handles VALIDATOR actions from the server. It executes a
server-compiled prompt on the client and returns a validated ValidatorResult.

The execution process:
    1. Receive ValidatorRequest with compiled_prompt and provenance
    2. Execute LLM call locally with timeout
    3. Parse strict JSON output (or SOUND sentinel)
    4. Validate schema (toggleable)
    5. Return ValidatorResult to server
"""

from __future__ import annotations

import json
import logging
import re
import time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeout
from pathlib import Path
from typing import Any, cast

from obra.api.protocol import (
    ValidatorRequest,
    ValidatorResult,
    validate_validator_result,
)
from obra.display.observability import ProgressEmitter
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.hybrid.validators.sense_check_intent import parse_intent_response
from obra.hybrid.validators.sense_check_plan import parse_plan_response
from obra.hybrid.validators.sense_check_review_filter import (
    parse_review_filter_response,
)
from obra.llm.cli_runner import invoke_llm_via_cli
from obra.model_registry import get_default_model

logger = logging.getLogger(__name__)

# Stage names for SenseCheck prompts (used for console output)
_SENSECHECK_STAGES = {
    "sensecheck.intent": "intent",
    "sensecheck.plan": "plan",
    "sensecheck.review_filter": "review_filter",
}

_JSON_BLOCK_PATTERN = re.compile(r"```(?:json)?\s*\n?(.*?)\n?```", re.DOTALL)


class ValidatorExecutionError(RuntimeError):
    """Raised when validator execution or parsing fails."""


class ValidatorExecutor:
    """Handler for VALIDATOR action.

    Executes a server-compiled validator prompt locally and returns a
    structured ValidatorResult. Parsing is strict and schema validation can
    be toggled via request.config['schema_validation'].
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        progress_emitter: ProgressEmitter | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._emitter = progress_emitter

    def handle(self, request: ValidatorRequest) -> ValidatorResult:
        """Execute validator request and return structured result.

        Args:
            request: ValidatorRequest from server

        Returns:
            ValidatorResult from parsed LLM output

        Raises:
            ValidatorExecutionError: When execution or parsing fails
        """
        start_time = time.time()
        stage = _SENSECHECK_STAGES.get(request.prompt_id or "", request.stage or "validator")

        # Emit "running" message
        if self._emitter:
            self._emitter.validator_started(stage)

        prompt_provenance = bool(request.config.get("prompt_provenance", True))
        if prompt_provenance:
            if not request.prompt_id:
                raise ValidatorExecutionError("prompt_id is required")
            if not request.prompt_version:
                raise ValidatorExecutionError("prompt_version is required")

        if not request.compiled_prompt:
            raise ValidatorExecutionError("compiled_prompt is required")

        schema_validation = bool(request.config.get("schema_validation", True))

        try:
            result = self._execute_with_template(
                request,
                schema_validation=schema_validation,
            )
        except ValidatorExecutionError:
            try:
                raw_response = self._execute_prompt(request)
                result = self._parse_response(
                    raw_response,
                    request=request,
                    schema_validation=schema_validation,
                )
            except ValidatorExecutionError as exc:
                duration_s = time.time() - start_time
                if self._emitter:
                    self._emitter.validator_error(stage, str(exc), duration_s=duration_s)
                raise

        if prompt_provenance:
            result.provenance.setdefault("prompt_id", request.prompt_id)
            result.provenance.setdefault("prompt_version", request.prompt_version)

        duration_s = time.time() - start_time
        result.provenance.setdefault("duration_s", duration_s)

        # Emit completion message with result summary
        if self._emitter:
            count = self._get_result_count(result, stage)
            self._emitter.validator_completed(
                stage, result.sound, count=count, duration_s=duration_s
            )

        return result

    def _get_result_count(self, result: ValidatorResult, stage: str) -> int | None:
        """Extract count of items from result based on stage."""
        if result.sound:
            return None
        if stage == "intent":
            return len(result.constraints) if result.constraints else 0
        if stage == "plan":
            return len(result.issues) if result.issues else 0
        if stage == "review_filter":
            return len(result.decisions) if result.decisions else 0
        return None

    def _execute_prompt(self, request: ValidatorRequest) -> str:
        provider = self._llm_config.get("provider", "anthropic")
        model = self._llm_config.get("model") or get_default_model(provider)
        if not model:
            raise ValidatorExecutionError("No model configured for validator execution")
        thinking_level = self._llm_config.get("thinking_level", "standard")
        auth_method = self._llm_config.get("auth_method", "oauth")
        codex_config = cast(dict[str, Any], self._llm_config.get("codex", {}))
        approval_mode = codex_config.get("approval_mode")
        bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
        skip_git_check = self._llm_config.get("git", {}).get("skip_check", True)

        def _invoke() -> str:
            return invoke_llm_via_cli(
                prompt=request.compiled_prompt,
                cwd=self._working_dir,
                provider=provider,
                model=model,
                thinking_level=thinking_level,
                auth_method=auth_method,
                timeout_s=request.timeout_s,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                call_site="validator",
                skip_git_check=skip_git_check,
                bypass_sandbox=bypass_sandbox,
                approval_mode=approval_mode,
                response_format="text",
            )

        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(_invoke)
            try:
                return future.result(timeout=request.timeout_s)
            except FutureTimeout as exc:
                future.cancel()
                raise ValidatorExecutionError("Validator execution timed out") from exc
            except Exception as exc:
                raise ValidatorExecutionError(str(exc)) from exc

    def _execute_with_template(
        self,
        request: ValidatorRequest,
        *,
        schema_validation: bool,
    ) -> ValidatorResult:
        stage_key = _SENSECHECK_STAGES.get(request.prompt_id or "", request.stage or "")
        if stage_key not in {"intent", "plan", "review_filter"}:
            raise ValidatorExecutionError(
                f"Template pipeline not configured for stage: {stage_key}"
            )

        template_schema, validator_fn, fallback_fn = self._get_template_schema(stage_key)
        pipeline = TemplateEditPipeline(
            self._working_dir,
            action_name=f"validator_{stage_key}",
            log_event=self._log_event,
        )
        llm_config = self._build_llm_config()

        data, _meta = pipeline.execute(
            base_prompt=request.compiled_prompt,
            template_content=template_schema,
            validator=validator_fn,
            fallback_fn=fallback_fn,
            llm_config=llm_config,
            timeout_s=request.timeout_s,
        )

        json_payload = json.dumps(data)
        if stage_key == "intent":
            return parse_intent_response(json_payload)
        if stage_key == "plan":
            return parse_plan_response(json_payload)
        if stage_key == "review_filter":
            return parse_review_filter_response(json_payload)

        return self._coerce_validator_result(
            data,
            schema_validation=schema_validation,
        )

    def _build_llm_config(self) -> dict[str, Any]:
        provider = self._llm_config.get("provider", "anthropic")
        model = self._llm_config.get("model") or get_default_model(provider)
        if not model:
            raise ValidatorExecutionError("No model configured for validator execution")
        thinking_level = self._llm_config.get("thinking_level", "standard")
        auth_method = self._llm_config.get("auth_method", "oauth")
        return {
            "provider": provider,
            "model": model,
            "thinking": thinking_level,
            "auth": auth_method,
        }

    def _get_template_schema(self, stage_key: str) -> tuple[dict[str, Any], Any, Any]:
        if stage_key == "intent":
            schema = {
                "constraints": [],
                "warnings": [],
                "_instructions": (
                    "Edit this JSON template only. Populate constraints and warnings as arrays of "
                    "strings. If the intent is sound, leave both arrays empty."
                ),
            }

            def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
                if not isinstance(data, dict):
                    return (False, "Response must be a JSON object")
                if not isinstance(data.get("constraints"), list):
                    return (False, "constraints must be a list")
                if not isinstance(data.get("warnings"), list):
                    return (False, "warnings must be a list")
                return (True, None)

            def fallback() -> dict[str, Any]:
                return {"constraints": [], "warnings": []}

            return schema, validator, fallback

        if stage_key == "plan":
            schema = {
                "should_auto_revise": False,
                "issues": [],
                "_instructions": (
                    "Edit this JSON template only. If issues exist, add objects to issues and set "
                    "should_auto_revise accordingly. If sound, leave issues empty and keep "
                    "should_auto_revise=false."
                ),
            }

            def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
                if not isinstance(data, dict):
                    return (False, "Response must be a JSON object")
                if not isinstance(data.get("issues"), list):
                    return (False, "issues must be a list")
                if not isinstance(data.get("should_auto_revise"), bool):
                    return (False, "should_auto_revise must be a bool")
                return (True, None)

            def fallback() -> dict[str, Any]:
                return {"should_auto_revise": False, "issues": []}

            return schema, validator, fallback

        schema = {
            "decisions": [],
            "_instructions": (
                "Edit this JSON template only. Populate decisions with objects describing filter "
                "actions. If no changes needed, leave decisions empty."
            ),
        }

        def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
            if not isinstance(data, dict):
                return (False, "Response must be a JSON object")
            if not isinstance(data.get("decisions"), list):
                return (False, "decisions must be a list")
            return (True, None)

        def fallback() -> dict[str, Any]:
            return {"decisions": []}

        return schema, validator, fallback

    def _parse_response(
        self,
        response: str,
        *,
        request: ValidatorRequest,
        schema_validation: bool,
    ) -> ValidatorResult:
        if not response or not response.strip():
            raise ValidatorExecutionError("Validator response was empty")

        stripped = response.strip()
        if request.prompt_id == "sensecheck.intent":
            intent_result = self._maybe_parse_intent_response(
                stripped,
                schema_validation=schema_validation,
            )
            if intent_result is not None:
                return intent_result
        if request.prompt_id == "sensecheck.plan":
            plan_result = self._maybe_parse_plan_response(
                stripped,
                schema_validation=schema_validation,
            )
            if plan_result is not None:
                return plan_result
        if request.prompt_id == "sensecheck.review_filter":
            filter_result = self._maybe_parse_review_filter_response(
                stripped,
                schema_validation=schema_validation,
            )
            if filter_result is not None:
                return filter_result

        if stripped.upper() == "SOUND":
            return ValidatorResult(sound=True)

        json_str = self._extract_json(stripped)
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError as exc:
            raise ValidatorExecutionError(f"Validator output was not valid JSON: {exc!s}") from exc

        if not isinstance(data, dict):
            raise ValidatorExecutionError("Validator JSON output must be an object")

        return self._coerce_validator_result(data, schema_validation=schema_validation)

    def _maybe_parse_intent_response(
        self,
        response: str,
        *,
        schema_validation: bool,
    ) -> ValidatorResult | None:
        if response.upper() == "SOUND":
            return parse_intent_response(response)

        json_str = self._extract_json(response)
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return None

        if not isinstance(data, dict):
            return None

        if "sound" in data:
            return None

        if "constraints" not in data and "warnings" not in data:
            return None

        result = parse_intent_response(json_str)
        if schema_validation:
            is_valid, error = validate_validator_result(result)
            if not is_valid:
                raise ValidatorExecutionError(error)
        return result

    def _maybe_parse_plan_response(
        self,
        response: str,
        *,
        schema_validation: bool,
    ) -> ValidatorResult | None:
        if response.upper() == "SOUND":
            return parse_plan_response(response)

        json_str = self._extract_json(response)
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return None

        if not isinstance(data, dict):
            return None

        if "issues" not in data and "should_auto_revise" not in data:
            return None

        result = parse_plan_response(json_str)
        if schema_validation:
            is_valid, error = validate_validator_result(result)
            if not is_valid:
                raise ValidatorExecutionError(error)
        return result

    def _maybe_parse_review_filter_response(
        self,
        response: str,
        *,
        schema_validation: bool,
    ) -> ValidatorResult | None:
        if response.upper() == "SOUND":
            return parse_review_filter_response(response)

        json_str = self._extract_json(response)
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return None

        if not isinstance(data, dict):
            return None

        if "filter_decisions" not in data and "decisions" not in data:
            return None

        result = parse_review_filter_response(json_str)
        if schema_validation:
            is_valid, error = validate_validator_result(result)
            if not is_valid:
                raise ValidatorExecutionError(error)
        return result

    def _extract_json(self, response: str) -> str:
        match = _JSON_BLOCK_PATTERN.search(response)
        if match:
            trailing = _JSON_BLOCK_PATTERN.sub("", response).strip()
            if trailing:
                raise ValidatorExecutionError("Validator response contained non-JSON content")
            return match.group(1).strip()
        return response.strip()

    def _coerce_validator_result(
        self,
        data: dict[str, Any],
        *,
        schema_validation: bool,
    ) -> ValidatorResult:
        sound = data.get("sound")
        issues = data.get("issues")
        constraints = data.get("constraints")
        decisions = data.get("decisions")
        version = data.get("version", "v1")
        provenance = data.get("provenance", {})

        if schema_validation:
            if not isinstance(sound, bool):
                raise ValidatorExecutionError("sound must be a bool")
            if not isinstance(issues, list):
                raise ValidatorExecutionError("issues must be a list")
            if not isinstance(constraints, list):
                raise ValidatorExecutionError("constraints must be a list")
            if not isinstance(decisions, list):
                raise ValidatorExecutionError("decisions must be a list")
            if not isinstance(provenance, dict):
                raise ValidatorExecutionError("provenance must be a dict")
        else:
            sound = self._coerce_bool(sound, issues, constraints, decisions)
            issues = self._coerce_list(issues)
            constraints = self._coerce_list(constraints)
            decisions = self._coerce_list(decisions)
            if not isinstance(provenance, dict):
                provenance = {}

        result = ValidatorResult(
            sound=cast(bool, sound),
            issues=cast(list[dict[str, Any]], issues),
            constraints=cast(list[str], constraints),
            decisions=cast(list[dict[str, Any]], decisions),
            version=str(version) if version is not None else "v1",
            provenance=cast(dict[str, Any], provenance),
        )

        if schema_validation:
            is_valid, error = validate_validator_result(result)
            if not is_valid:
                raise ValidatorExecutionError(error)

        return result

    @staticmethod
    def _coerce_list(value: Any) -> list[Any]:
        if value is None:
            return []
        if isinstance(value, list):
            return value
        return [value]

    @staticmethod
    def _coerce_bool(
        value: Any,
        issues: Any,
        constraints: Any,
        decisions: Any,
    ) -> bool:
        if isinstance(value, bool):
            return value
        if value is None:
            has_issues = bool(issues) or bool(constraints) or bool(decisions)
            return not has_issues
        return bool(value)
