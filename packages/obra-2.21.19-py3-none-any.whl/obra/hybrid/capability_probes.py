"""Capability probe registry for Story0 prerequisite detection.

Uses decorator-based registration (Rule 6) consistent with
dependency_verifier.py pattern. Probes determine if a system
capability is available, regardless of the LLM-assigned category.

Seeded with probes for: python_runtime, tkinter, display, audio,
filesystem_write. The ``unknown_behavior`` config policy provides
a safety net for prerequisites that don't match any registered probe.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Probe registry
# ---------------------------------------------------------------------------

_CAPABILITY_PROBE_REGISTRY: dict[str, _ProbeSpec] = {}


@dataclass(frozen=True)
class _ProbeSpec:
    """Internal registration record for a capability probe."""

    name: str
    indicators: list[str]
    probe_fn: Callable[[], tuple[str, str]]


@dataclass(frozen=True)
class ProbeResult:
    """Outcome of a capability probe check."""

    matched: bool
    probe_name: str
    status: str  # "installed" | "missing" | "unverified"
    detail: str


def register_capability_probe(
    name: str,
    indicators: list[str],
) -> Callable[
    [Callable[[], tuple[str, str]]],
    Callable[[], tuple[str, str]],
]:
    """Decorator to register a capability probe.

    The decorated function must accept no arguments and return
    ``(status, detail)`` where *status* is ``installed`` or ``missing``.

    Args:
        name: Canonical probe name (e.g. ``"tkinter"``).
        indicators: Substring patterns to match against prerequisite names.
            Matching is case-insensitive.
    """

    def decorator(
        fn: Callable[[], tuple[str, str]],
    ) -> Callable[[], tuple[str, str]]:
        _CAPABILITY_PROBE_REGISTRY[name] = _ProbeSpec(
            name=name,
            indicators=[ind.lower() for ind in indicators],
            probe_fn=fn,
        )
        return fn

    return decorator


def match_capability_probe(prereq_name: str) -> str | None:
    """Return the probe name if *prereq_name* matches a registered probe.

    Returns ``None`` if no probe matches.
    """
    lower = prereq_name.lower()
    for probe_name, spec in _CAPABILITY_PROBE_REGISTRY.items():
        if any(ind in lower for ind in spec.indicators):
            return probe_name
    return None


def run_capability_probe(probe_name: str) -> ProbeResult:
    """Execute a registered capability probe by name.

    Returns a ``ProbeResult`` with match status and detail.
    Raises ``KeyError`` if the probe name is not registered.
    """
    spec = _CAPABILITY_PROBE_REGISTRY[probe_name]
    try:
        status, detail = spec.probe_fn()
        return ProbeResult(
            matched=True,
            probe_name=probe_name,
            status=status,
            detail=detail,
        )
    except Exception as exc:
        logger.warning("Capability probe %s raised: %s", probe_name, exc)
        return ProbeResult(
            matched=True,
            probe_name=probe_name,
            status="unverified",
            detail=f"probe raised: {exc}",
        )


def probe_prerequisite(prereq_name: str) -> ProbeResult | None:
    """Check a prerequisite name against all registered probes.

    Returns a ``ProbeResult`` if a probe matches and was executed,
    or ``None`` if no probe matched.
    """
    probe_name = match_capability_probe(prereq_name)
    if probe_name is None:
        return None
    return run_capability_probe(probe_name)


# ---------------------------------------------------------------------------
# Registered probes — seeded with known capabilities
# ---------------------------------------------------------------------------


def _run_cmd(cmd: list[str], timeout: int = 5) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd, capture_output=True, text=True, timeout=timeout, check=False,
    )


@register_capability_probe(
    "python_runtime",
    indicators=["python interpreter", "python 3 interpreter", "python3 interpreter",
                "python runtime", "python 3 runtime", "python3 runtime"],
)
def _probe_python_runtime() -> tuple[str, str]:
    for binary in ("python3", "python"):
        if shutil.which(binary):
            result = _run_cmd([binary, "--version"])
            if result.returncode == 0:
                return ("installed", f"{binary}: {result.stdout.strip()}")
    return ("missing", "python3/python not found on PATH")


@register_capability_probe(
    "tkinter",
    indicators=["tkinter", "tk gui", "tk bindings", "python3-tk"],
)
def _probe_tkinter() -> tuple[str, str]:
    for binary in ("python3", "python"):
        if shutil.which(binary):
            result = _run_cmd([binary, "-c", "import tkinter"])
            if result.returncode == 0:
                return ("installed", f"tkinter available via {binary}")
            return ("missing", f"import tkinter failed ({binary}): {result.stderr.strip()}")
    return ("missing", "python3/python not found; cannot check tkinter")


@register_capability_probe(
    "display",
    indicators=["gui", "display", "window", "screen", "graphical",
                "gui display server"],
)
def _probe_display() -> tuple[str, str]:
    if sys.platform == "darwin":
        return ("installed", "display always available on macOS")
    if sys.platform == "win32":
        return ("installed", "display always available on Windows")
    # Linux: check DISPLAY or WAYLAND_DISPLAY
    display = os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")
    if display:
        return ("installed", f"display detected: DISPLAY={display}")
    return ("missing", "no DISPLAY or WAYLAND_DISPLAY set")


@register_capability_probe(
    "audio",
    indicators=["audio", "sound", "speaker", "microphone"],
)
def _probe_audio() -> tuple[str, str]:
    if sys.platform == "darwin":
        return ("installed", "audio always available on macOS")
    if sys.platform == "win32":
        return ("installed", "audio always available on Windows")
    pulse = os.environ.get("PULSE_SERVER") or os.environ.get("ALSA_CARD")
    if pulse:
        return ("installed", f"audio detected via env: {pulse}")
    # Check if pulseaudio or pipewire is running
    for binary in ("pactl", "pw-cli"):
        if shutil.which(binary):
            result = _run_cmd([binary, "info"])
            if result.returncode == 0:
                return ("installed", f"audio detected via {binary}")
    return ("missing", "no audio server detected")


@register_capability_probe(
    "filesystem_write",
    indicators=["write permission", "writable", "filesystem"],
)
def _probe_filesystem_write() -> tuple[str, str]:
    return ("installed", "filesystem write always available on local machines")
