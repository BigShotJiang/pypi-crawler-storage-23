"""API contract registry for client/server compatibility checks.

Defines request/response contract mappings used by schema sync validation
and contract tests. This module is intended for tooling and CI, not runtime.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, Iterable
import sys

from obra.api.protocol import (
    ActionType,
    DeriveRequest,
    DerivedPlan,
    EscalationNotice,
    ExaminationReport,
    ExamineRequest,
    ExecutionResult,
    ExecutionRequest,
    FixReport,
    FixRequest,
    IntentRequest,
    ReviewRequest,
    RevisedPlan,
    RevisionRequest,
    SessionStart,
    StoryPreflightRequest,
    ValidatorRequest,
)

_SERVER_PATH = Path(__file__).resolve().parents[2] / "functions"
if _SERVER_PATH.exists() and str(_SERVER_PATH) not in sys.path:
    sys.path.insert(0, str(_SERVER_PATH))

try:
    from functions.src.schemas.request_schemas import (
        DerivedPlanSchema,
        ExaminationReportSchema,
        ExecutionReportSchema,
        FixReportSchema,
        ReviewReportSchema,
        RevisedPlanSchema,
        SessionStartSchema,
    )
except Exception as exc:  # pragma: no cover - only hit outside repo context
    DerivedPlanSchema = None  # type: ignore[assignment]
    ExaminationReportSchema = None  # type: ignore[assignment]
    ExecutionReportSchema = None  # type: ignore[assignment]
    FixReportSchema = None  # type: ignore[assignment]
    ReviewReportSchema = None  # type: ignore[assignment]
    RevisedPlanSchema = None  # type: ignore[assignment]
    SessionStartSchema = None  # type: ignore[assignment]
    _SERVER_IMPORT_ERROR: Exception | None = exc
else:
    _SERVER_IMPORT_ERROR = None


@dataclass(frozen=True)
class ContractSpec:
    """Defines a client/server API contract mapping."""

    name: str
    client_request_type: type[Any] | None
    server_request_schema: type[Any] | None
    client_response_type: type[Any] | None = None
    server_response_type: type[Any] | None = None
    allow_server_superset: bool = False
    client_fields: set[str] | None = None
    field_aliases: dict[str, str] | None = None
    fixture_name: str | None = None
    endpoint: str | None = None


@dataclass(frozen=True)
class ActionContractSpec:
    """Defines a server-action payload contract for client parsing."""

    name: str
    action_type: str
    client_payload_type: type[Any]
    fixture_name: str
    required_payload_fields: set[str] = field(default_factory=set)
    parse_kwargs: dict[str, Any] = field(default_factory=dict)
    payload_field_aliases: dict[str, str] = field(default_factory=dict)
    allowed_extra_payload_fields: set[str] = field(default_factory=set)


REQUEST_CONTRACTS: list[ContractSpec] = [
    ContractSpec(
        name="session_start",
        client_request_type=SessionStart,
        server_request_schema=SessionStartSchema,
        fixture_name="session_start",
        endpoint="hybrid_orchestrate",
    ),
    ContractSpec(
        name="report_derivation",
        client_request_type=DerivedPlan,
        server_request_schema=DerivedPlanSchema,
        fixture_name="report_derivation",
        endpoint="report_derivation",
    ),
    ContractSpec(
        name="report_examination",
        client_request_type=ExaminationReport,
        server_request_schema=ExaminationReportSchema,
        fixture_name="report_examination",
        endpoint="report_examination",
    ),
    ContractSpec(
        name="report_revision",
        client_request_type=RevisedPlan,
        server_request_schema=RevisedPlanSchema,
        fixture_name="report_revision",
        endpoint="report_revision",
    ),
    ContractSpec(
        name="report_execution",
        client_request_type=ExecutionResult,
        server_request_schema=ExecutionReportSchema,
        fixture_name="report_execution",
        endpoint="report_execution",
    ),
    ContractSpec(
        name="report_review",
        client_request_type=None,
        server_request_schema=ReviewReportSchema,
        client_fields={
            "session_id",
            "item_id",
            "agent_reports",
            "iteration",
            "progress_cursor",
        },
        fixture_name="report_review",
        endpoint="report_review",
    ),
    ContractSpec(
        name="report_fix",
        client_request_type=FixReport,
        server_request_schema=FixReportSchema,
        fixture_name="report_fix",
        endpoint="report_fix",
    ),
]


ACTION_CONTRACTS: list[ActionContractSpec] = [
    ActionContractSpec(
        name="action_intent_payload",
        action_type=ActionType.INTENT.value,
        client_payload_type=IntentRequest,
        fixture_name="action_intent_payload",
        required_payload_fields={"objective", "userplan_id", "userplan_version"},
    ),
    ActionContractSpec(
        name="action_derive_payload",
        action_type=ActionType.DERIVE.value,
        client_payload_type=DeriveRequest,
        fixture_name="action_derive_payload",
        required_payload_fields={"objective", "userplan_id", "userplan_version"},
    ),
    ActionContractSpec(
        name="action_examine_payload",
        action_type=ActionType.EXAMINE.value,
        client_payload_type=ExamineRequest,
        fixture_name="action_examine_payload",
        required_payload_fields={"plan_version_id", "plan_items"},
    ),
    ActionContractSpec(
        name="action_revise_payload",
        action_type=ActionType.REVISE.value,
        client_payload_type=RevisionRequest,
        fixture_name="action_revise_payload",
        required_payload_fields={
            "issues",
            "blocking_issues",
            "current_plan_version_id",
            "batch_index",
            "total_batches",
            "batches_remaining",
        },
    ),
    ActionContractSpec(
        name="action_execute_payload",
        action_type=ActionType.EXECUTE.value,
        client_payload_type=ExecutionRequest,
        fixture_name="action_execute_payload",
        required_payload_fields={"plan_items", "execution_index"},
    ),
    ActionContractSpec(
        name="action_story_preflight_payload",
        action_type=ActionType.STORY_PREFLIGHT.value,
        client_payload_type=StoryPreflightRequest,
        fixture_name="action_story_preflight_payload",
        required_payload_fields={"story_item", "plan_items"},
    ),
    ActionContractSpec(
        name="action_review_payload",
        action_type=ActionType.REVIEW.value,
        client_payload_type=ReviewRequest,
        fixture_name="action_review_payload",
        required_payload_fields={"item_id", "review_agents", "changed_files"},
        payload_field_aliases={"review_agents": "agents_to_run"},
    ),
    ActionContractSpec(
        name="action_fix_payload",
        action_type=ActionType.FIX.value,
        client_payload_type=FixRequest,
        fixture_name="action_fix_payload",
        required_payload_fields={"item_id", "issues_to_fix", "issue_details", "fix_history"},
    ),
    ActionContractSpec(
        name="action_escalate_payload",
        action_type=ActionType.ESCALATE.value,
        client_payload_type=EscalationNotice,
        fixture_name="action_escalate_payload",
        required_payload_fields={"reason", "blocking_issues", "convergence_diagnostic"},
    ),
    ActionContractSpec(
        name="action_validator_payload",
        action_type=ActionType.VALIDATOR.value,
        client_payload_type=ValidatorRequest,
        fixture_name="action_validator_payload",
        required_payload_fields={
            "stage",
            "subject_type",
            "subject_payload",
            "prompt_id",
            "prompt_version",
            "compiled_prompt",
            "timeout_s",
            "config",
        },
        parse_kwargs={"schema_validation": False},
    ),
]


def ensure_server_imports() -> None:
    """Raise a clear error if server schemas are unavailable."""

    if _SERVER_IMPORT_ERROR is not None:
        raise RuntimeError(
            "Server schema imports unavailable. Run from repo root with "
            "functions/ available in PYTHONPATH."
        ) from _SERVER_IMPORT_ERROR


def client_field_names(spec: ContractSpec) -> set[str]:
    """Return client request field names for a contract spec."""

    if spec.client_fields:
        return set(spec.client_fields)
    if spec.client_request_type and is_dataclass(spec.client_request_type):
        return {field.name for field in fields(spec.client_request_type)}
    return set()


def apply_field_aliases(
    field_names: Iterable[str], aliases: dict[str, str] | None
) -> set[str]:
    """Apply alias mapping to a field set."""

    names = set(field_names)
    if not aliases:
        return names
    for client_name, server_name in aliases.items():
        if client_name in names:
            names.add(server_name)
    return names
