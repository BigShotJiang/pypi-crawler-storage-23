"""Validation helpers for hierarchical derivation items."""

from __future__ import annotations

from typing import Any

from obra.config.loaders import get_plan_item_validation_config

VAGUE_CRITERIA_PATTERNS = [
    "works correctly",
    "code is clean",
    "looks good",
    "is working",
    "no issues",
    "properly handled",
]

COMPOUND_TITLE_WORDS = ["and", "then", "after"]


def validate_plan_item(
    item: dict[str, Any],
    level: str,
    level_config: dict[str, Any] | None = None,
) -> list[str]:
    """Validate a plan item against size/quality rules for a level.

    Args:
        item: Plan item dict (title/description/acceptance_criteria)
        level: One of epic, story, task, subtask
        level_config: Optional level config dict with thresholds

    Returns:
        List of violation messages (empty if compliant)
    """
    # Get validation config defaults (CHORE-CONFIG-DEFAULTS-001-E3 S3)
    validation_defaults = get_plan_item_validation_config()
    config = level_config or {}
    violations: list[str] = []

    title = str(item.get("title", "")).strip()
    description = str(item.get("description", "")).strip()
    acceptance = item.get("acceptance_criteria", [])
    if not isinstance(acceptance, list):
        acceptance = [acceptance]
    context = item.get("context", {})
    if not isinstance(context, dict):
        context = {}

    max_acceptance = int(
        config.get("max_acceptance_criteria", validation_defaults["max_acceptance_criteria"])
    )
    max_desc_words = int(
        config.get("max_description_words", validation_defaults["max_description_words"])
    )
    forbid_compound = bool(config.get("forbid_compound_titles", False))

    if forbid_compound and title:
        title_lower = title.lower()
        for word in COMPOUND_TITLE_WORDS:
            if f" {word} " in f" {title_lower} ":
                violations.append(f"Title contains compound action word ('{word}')")
                break

    if description:
        word_count = len(description.split())
        if word_count > max_desc_words:
            violations.append(f"Description too long ({word_count} words, max {max_desc_words})")

    if acceptance and len(acceptance) > max_acceptance:
        violations.append(f"Too many acceptance criteria ({len(acceptance)}, max {max_acceptance})")

    if acceptance:
        for criterion in acceptance:
            criterion_text = str(criterion).lower()
            for pattern in VAGUE_CRITERIA_PATTERNS:
                if pattern in criterion_text:
                    violations.append(f"Vague acceptance criterion: '{str(criterion)[:50]}...'")
                    break

    if level == "story":
        if not acceptance:
            violations.append("Story must include acceptance criteria")
        if context.get("user_visible") is not True:
            violations.append("Story must include context.user_visible=true")
        tasks = item.get("tasks", [])
        max_tasks = int(config.get("max_tasks", validation_defaults["max_tasks"]))
        if isinstance(tasks, list) and len(tasks) > max_tasks:
            violations.append(f"Too many tasks in story ({len(tasks)}, max {max_tasks})")

    if level in {"task", "subtask"}:
        size_estimates = context.get("size_estimates")
        if not isinstance(size_estimates, dict):
            violations.append("Missing size_estimates for task/subtask")
        else:
            files = size_estimates.get("files")
            loc = size_estimates.get("loc")
            words = size_estimates.get("words")
            max_files = int(config.get("max_files", validation_defaults["max_files_per_task"]))
            max_loc = int(config.get("max_loc", validation_defaults["max_loc"]))
            max_words = int(config.get("max_words", max_desc_words))
            if not isinstance(files, int):
                violations.append("size_estimates.files must be an integer")
            elif files > max_files:
                violations.append(f"Too many files ({files}, max {max_files})")
            if not isinstance(loc, int):
                violations.append("size_estimates.loc must be an integer")
            elif loc > max_loc:
                violations.append(f"Too many LOC ({loc}, max {max_loc})")
            if not isinstance(words, int):
                violations.append("size_estimates.words must be an integer")
            elif words > max_words:
                violations.append(f"Too many words ({words}, max {max_words})")

    return violations


__all__ = ["COMPOUND_TITLE_WORDS", "validate_plan_item"]
