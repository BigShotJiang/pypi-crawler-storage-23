"""Git utility functions for Obra SaaS CLI.

Provides git repository detection and validation for hybrid orchestration.
This module is duplicated from src/utils/git_utils.py per Rule 21 (Package Isolation).

GIT-HARD-001: Centralized git validation for SaaS CLI package.
"""

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


# Default .gitignore content for auto-initialized repositories
_DEFAULT_GITIGNORE = """\
# Environment and secrets
.env
.env.*

# Python bytecode
*.pyc
__pycache__/

# Obra internal files (prompts, logs, caches)
.obra/

# OS-specific
.DS_Store
"""


def ensure_gitignore_has_obra(workspace_path: Path) -> bool:
    """Ensure .obra/ is in .gitignore for existing git repositories.

    If the workspace is a git repository and has a .gitignore file,
    appends '.obra/' if not already present. If no .gitignore exists
    but it's a git repo, creates one with just '.obra/'.

    This prevents Obra's internal files (prompts, caches, logs) from
    being tracked by git and accidentally included in review analysis.

    Args:
        workspace_path: Path to the workspace/project root directory

    Returns:
        True if .gitignore was modified or created, False if no changes needed
    """
    gitignore_path = workspace_path / ".gitignore"

    # Check if this is a git repository
    if not is_git_repository(workspace_path):
        logger.debug("Not a git repository, skipping gitignore update: %s", workspace_path)
        return False

    obra_pattern = ".obra/"

    if gitignore_path.exists():
        content = gitignore_path.read_text(encoding="utf-8")
        lines = content.splitlines()

        # Check if .obra/ is already ignored (exact match or with comment)
        for line in lines:
            stripped = line.strip()
            if stripped in (obra_pattern, ".obra"):
                logger.debug(".obra/ already in .gitignore")
                return False

        # Append .obra/ to existing .gitignore
        # Add newline before if file doesn't end with one
        if content and not content.endswith("\n"):
            content += "\n"
        content += f"\n# Obra internal files\n{obra_pattern}\n"
        gitignore_path.write_text(content, encoding="utf-8")
        logger.info("Added .obra/ to existing .gitignore: %s", gitignore_path)
        return True
    # Create minimal .gitignore with just .obra/
    gitignore_path.write_text(f"# Obra internal files\n{obra_pattern}\n", encoding="utf-8")
    logger.info("Created .gitignore with .obra/: %s", gitignore_path)
    return True


def is_git_repository(path: str | Path) -> bool:
    """Check if path is within a git repository.

    Checks for .git directory in the given path or any parent directory.

    Args:
        path: Directory path to check

    Returns:
        True if path is within a git repository, False otherwise

    Example:
        >>> is_git_repository("/home/user/my-project")
        True  # if /home/user/my-project/.git exists
        >>> is_git_repository("/tmp/scratch")
        False  # no .git in path or parents
    """
    path = Path(path).resolve()

    # Check if .git exists in this directory
    if (path / ".git").exists():
        return True

    # Check parent directories
    return any((parent / ".git").exists() for parent in path.parents)


def is_safe_for_auto_git_init(path: Path, config: dict) -> tuple[bool, str]:
    """Check if path is safe for automatic git initialization.

    Safety checks:
    - Blocks dangerous system paths (blacklist)
    - Requires minimum depth (prevents shallow paths like ~/ or /tmp/)
    - Blocks directories with many existing files (prevents polluting existing projects)

    Symlink handling: path.resolve() follows symlinks before checking.
    If symlink resolves outside home directory, absolute depth check applies.

    Args:
        path: Directory to check (will be resolved to follow symlinks)
        config: Config dict with llm.git.auto_init_* settings

    Returns:
        (is_safe, reason_if_unsafe)

    Example:
        >>> is_safe_for_auto_git_init(Path("~/projects/myapp"), config)
        (True, "")  # Safe - depth 2 from home
        >>> is_safe_for_auto_git_init(Path("~/myapp"), config)
        (False, "Path too shallow...")  # Unsafe - depth 1
    """
    path = path.resolve()  # Follow symlinks

    # Get config values (with defaults)
    git_config = config.get("llm", {}).get("git", {})
    require_depth = git_config.get("auto_init_require_depth", 2)
    max_files = git_config.get("auto_init_max_files", 1000)
    additional_blacklist = git_config.get("auto_init_blacklist", [])

    # 1. Blacklist check
    dangerous_paths = [
        Path.home(),
        Path("/"),
        Path("/tmp"),
        Path("/var"),
        Path("/usr"),
        Path("/etc"),
        Path("/opt"),
        Path("/home"),
        Path("/root"),
        Path("/mnt"),
        Path("/media"),
        Path("/srv"),
    ] + [Path(p) for p in additional_blacklist]

    for dangerous in dangerous_paths:
        if path == dangerous:
            return False, f"Cannot auto-init in {dangerous} (blacklisted directory)"

    # 2. Depth check
    try:
        # Path under home directory
        rel_to_home = path.relative_to(Path.home())
        depth_from_home = len(rel_to_home.parts)
        if depth_from_home < require_depth:
            return False, (
                f"Path too shallow from home (depth={depth_from_home}, need >={require_depth}): {path}\n"
                f"  Safe example: ~/projects/myapp (depth=2)\n"
                f"  To fix:\n"
                f'    1. Use deeper path: obra run --dir ~/projects/myapp "..."\n'
                f"    2. Initialize manually: cd {path} && git init\n"
                f"    3. Disable check: obra config set llm.git.auto_init_require_depth 1"
            )
    except ValueError:
        # Not under home - check absolute depth
        abs_depth = len(path.parts)
        if abs_depth < 4:
            return False, (
                f"Path too shallow from root (depth={abs_depth}, need >=4): {path}\n"
                f"  Use a deeper path or place under your home directory"
            )

    # 3. File count check (only for existing directories)
    if path.exists() and path.is_dir():
        file_count = 0
        for item in path.rglob("*"):
            if item.is_file():
                file_count += 1
                if file_count > max_files:
                    # Early exit - don't count further
                    return False, (
                        f"Directory has >{max_files} files\n"
                        f"  This appears to be an existing project, not a new one.\n"
                        f"  To override: Run 'git init' manually in this directory"
                    )

        logger.debug("Auto-init safety check passed: %d files in %s", file_count, path)

    return True, ""


def ensure_git_repository(
    path: str | Path,
    auto_init: bool = False,
    config: dict | None = None,
) -> bool:
    """Ensure path is or becomes a git repository.

    Checks if the path is a git repository. If not and auto_init is True,
    initializes a new git repository with a default .gitignore file.

    When auto_init is True, safety checks are performed to prevent
    initializing git in dangerous locations (home directory, system paths,
    directories with many files). Safety checks are configurable via
    llm.git.auto_init_* settings.

    GIT-HARD-001: Provides centralized git validation for SaaS CLI.

    Args:
        path: Directory path to check/initialize
        auto_init: If True, auto-initialize git when not in a repository.
                   If False, raise GitValidationError when not in a repository.
        config: Optional config dict for auto-init safety checks.
                If None, uses default safety settings.

    Returns:
        True if the path is (or became) a git repository

    Raises:
        GitValidationError: If not in a git repository and auto_init is False
        GitAutoInitSafetyError: If auto_init is True but path fails safety checks
        subprocess.CalledProcessError: If git init fails

    Example:
        >>> ensure_git_repository("/home/user/my-project", auto_init=True)
        True  # Initialized git and created .gitignore
        >>> ensure_git_repository("/home/user/git-project", auto_init=False)
        True  # Already a git repo
        >>> ensure_git_repository("/tmp/scratch", auto_init=False)
        GitValidationError  # Not a git repo, auto_init disabled
        >>> ensure_git_repository("/home/user", auto_init=True)
        GitAutoInitSafetyError  # Too shallow, fails safety check
    """
    path = Path(path).resolve()

    # Check if already in a git repository
    if is_git_repository(path):
        logger.debug("Path is already a git repository: %s", path)
        return True

    # Not in a git repo - handle based on auto_init setting
    if not auto_init:
        raise GitValidationError(path)

    # Auto-initialize git repository (with safety checks)
    # Use empty dict if config is None (fallback to function defaults)
    config = config or {}
    is_safe, reason = is_safe_for_auto_git_init(path, config)

    if not is_safe:
        raise GitAutoInitSafetyError(path, reason)

    logger.info("Auto-initializing git repository: %s", path)

    try:
        # Run git init
        result = subprocess.run(
            ["git", "init"],
            cwd=path,
            capture_output=True,
            text=True,
            check=True,
        )
        logger.debug("git init output: %s", result.stdout.strip())

        # Create default .gitignore if it doesn't exist
        gitignore_path = path / ".gitignore"
        if not gitignore_path.exists():
            gitignore_path.write_text(_DEFAULT_GITIGNORE)
            logger.info("Created default .gitignore: %s", gitignore_path)

        logger.info("Git repository initialized successfully: %s", path)
        return True

    except subprocess.CalledProcessError as e:
        logger.exception("Failed to initialize git repository: %s", e.stderr)
        raise


class GitValidationError(Exception):
    """Error raised when git repository validation fails.

    Provides clear error message following R7 template with actionable recovery steps.

    GIT-HARD-001: User-facing error for missing git repositories.
    """

    def __init__(self, path: str | Path):
        """Initialize GitValidationError.

        Args:
            path: Path that failed git validation
        """
        self.path = Path(path).resolve()

        # R7 template: Clear error with 3 fix options and help link
        message = (
            f"GitValidationError: Git repository required\n"
            f"  Location: {self.path}\n"
            f"\n"
            f"  To fix:\n"
            f"    1. Initialize git: cd {self.path} && git init\n"
            f'    2. Skip this session: obra run --skip-git-check "your objective"\n'
            f"    3. Skip always: Add 'llm.git.skip_check: true' to config\n"
            f"\n"
            f"  More info: obra help git"
        )
        super().__init__(message)


class GitAutoInitSafetyError(Exception):
    """Error raised when auto-init fails safety checks.

    Prevents automatic git initialization in dangerous locations
    (home directory, system paths, large existing directories).

    GIT-HARD-001: Safety guard for auto-init feature.
    """

    def __init__(self, path: str | Path, reason: str):
        """Initialize GitAutoInitSafetyError.

        Args:
            path: Path that failed safety check
            reason: Detailed reason from safety check
        """
        self.path = Path(path).resolve()
        self.reason = reason

        # R7 template: Clear error with reason and fix options
        message = (
            f"GitAutoInitSafetyError: Cannot auto-initialize git\n"
            f"  Location: {self.path}\n"
            f"\n"
            f"  Reason:\n"
            f"  {reason}\n"
            f"\n"
            f"  Config options:\n"
            f"    llm.git.auto_init_require_depth: Minimum depth from home (default: 2)\n"
            f"    llm.git.auto_init_max_files: Max files in directory (default: 1000)\n"
            f"    llm.git.auto_init_blacklist: Additional paths to block (default: [])\n"
        )
        super().__init__(message)
