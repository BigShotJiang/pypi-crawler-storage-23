"""
Error domain message templates.

Templates for session errors, authentication errors, network issues,
configuration problems, and execution failures.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    ErrorCategory,
    MessageDomain,
    MessageTemplate,
)

__all__ = [
    "TEMPLATES",
    "get_error",
]

# =============================================================================
# Error Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Session Category
    # -------------------------------------------------------------------------
    "error.session.not_found": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.SESSION,
        template="Session not found: {session_id}",
        verbose_template=(
            "Session not found: {session_id}\nThe session may have expired or been completed."
        ),
        placeholders=("session_id",),
    ),
    "error.session.expired": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.SESSION,
        template="Session expired after 24 hours of inactivity.",
        verbose_template=(
            "Session expired after 24 hours of inactivity.\n"
            "Sessions automatically expire to free up resources."
        ),
    ),
    "error.session.invalid_state": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.SESSION,
        template="Cannot {action} - session is in {state} state.",
        verbose_template=(
            "Cannot {action} - session is in {state} state.\n"
            "Check session status with 'obra status' to see current state."
        ),
        placeholders=("action", "state"),
    ),
    # -------------------------------------------------------------------------
    # Auth Category
    # -------------------------------------------------------------------------
    "error.auth.expired": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.AUTH,
        template="Session expired. Run 'obra login' to re-authenticate.",
        verbose_template=(
            "Your authentication session has expired.\n"
            "Run 'obra login' to re-authenticate with your Obra account."
        ),
    ),
    "error.auth.required": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.AUTH,
        template="You must be logged in to use this command.",
        verbose_template=(
            "Authentication required.\n"
            "You must be logged in to use this command.\n"
            "Run 'obra login' to authenticate."
        ),
    ),
    "error.auth.terms_not_accepted": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.AUTH,
        template="You must accept the beta terms to continue.",
        verbose_template=(
            "Beta terms not yet accepted.\n"
            "You must accept the beta terms of service to continue.\n"
            "Run 'obra setup' to review and accept terms."
        ),
    ),
    "error.auth.beta_denied": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.AUTH,
        template="Your email is not on the beta allowlist.",
        verbose_template=(
            "Beta access denied.\n"
            "Your email is not on the beta allowlist.\n"
            "Request access at obra.dev/beta or contact support."
        ),
    ),
    # -------------------------------------------------------------------------
    # Network Category
    # -------------------------------------------------------------------------
    "error.network.error": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.NETWORK,
        template="Connection lost. Your work is saved locally.",
        verbose_template=(
            "Connection to server lost.\n"
            "Your work is saved locally and will sync when connection is restored.\n"
            "Check your network connection and try again."
        ),
    ),
    "error.network.rate_limited": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.NETWORK,
        template="Rate limit reached. Try again in {retry_after} seconds.",
        verbose_template=(
            "Rate limit reached.\n"
            "Too many requests in a short period.\n"
            "Wait {retry_after} seconds before trying again."
        ),
        placeholders=("retry_after",),
    ),
    "error.network.server_error": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.NETWORK,
        template="Server error. Your work is saved.",
        verbose_template=(
            "A server error occurred.\n"
            "Your work is saved locally.\n"
            "The issue has been logged. Please try again."
        ),
    ),
    # -------------------------------------------------------------------------
    # Config Category
    # -------------------------------------------------------------------------
    "error.config.invalid": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.CONFIG,
        template="Configuration is invalid or missing.",
        verbose_template=(
            "Configuration error.\n"
            "The configuration is invalid or a required setting is missing.\n"
            "Run 'obra config' to review and fix configuration."
        ),
    ),
    "error.config.llm_not_found": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.CONFIG,
        template="No LLM CLI found: claude, gemini, or codex.",
        verbose_template=(
            "No LLM CLI found.\n"
            "Obra requires an LLM CLI to be installed.\n"
            "Install claude, gemini, or codex and ensure it's in your PATH."
        ),
    ),
    "error.config.version_mismatch": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.CONFIG,
        template="Client version is not compatible with server.",
        verbose_template=(
            "Version mismatch.\n"
            "Your Obra client version is not compatible with the server.\n"
            "Run 'pip install --upgrade obra' to update."
        ),
    ),
    # -------------------------------------------------------------------------
    # Execution Category
    # -------------------------------------------------------------------------
    "error.execution.timeout": MessageTemplate(
        domain=MessageDomain.ERROR,
        category=ErrorCategory.EXECUTION,
        template="The task took too long to complete.",
        verbose_template=(
            "Execution timeout.\n"
            "The task took too long to complete.\n"
            "Try breaking the task into smaller steps or running with --stream."
        ),
    ),
}


# =============================================================================
# Builder Functions (FR-3)
# =============================================================================


def get_error(key: str, **kwargs: Any) -> str:
    """
    Get an error message with automatic domain prefix.

    Args:
        key: Key without 'error.' prefix (e.g., 'session.not_found')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"error.{key}", **kwargs)
