"""
Guidance domain message templates.

Templates for requirements, options, hints, validation messages, and user inputs.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    FORMATTING_PRIMITIVES,
    GuidanceCategory,
    MessageDomain,
    MessageTemplate,
)

__all__ = [
    "TEMPLATES",
    "build_options_list",
    "build_requirement_message",
    "build_usage_hint",
    "get_guidance",
]

# =============================================================================
# Guidance Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Requirement Category
    # -------------------------------------------------------------------------
    "guidance.requirement.select_project": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.REQUIREMENT,
        template="You must select a project before running obra.",
        verbose_template=(
            "Project selection required.\n"
            "You must select a project before running obra.\n"
            "Use 'obra projects list' to see available projects."
        ),
    ),
    "guidance.requirement.accept_terms": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.REQUIREMENT,
        template="You must accept terms before continuing.",
        verbose_template=(
            "Terms acceptance required.\n"
            "You must accept the terms of service before continuing.\n"
            "Run 'obra setup' to review and accept terms."
        ),
    ),
    "guidance.requirement.login_required": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.REQUIREMENT,
        template="You must be logged in to use this feature.",
        verbose_template=(
            "Authentication required.\n"
            "You must be logged in to use this feature.\n"
            "Run 'obra login' to authenticate."
        ),
    ),
    # -------------------------------------------------------------------------
    # Options Category
    # -------------------------------------------------------------------------
    "guidance.options.project_selection": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.OPTIONS,
        template="Select a project:",
        verbose_template="Select a project from the list below:",
    ),
    "guidance.options.directory_choice": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.OPTIONS,
        template="Select a directory:",
        verbose_template="Select a directory from the available options:",
    ),
    # -------------------------------------------------------------------------
    # Hint Category
    # -------------------------------------------------------------------------
    "guidance.hint.use_command": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.HINT,
        template="Use '{command}' to {description}.",
        verbose_template=("Tip: You can use '{command}' to {description}."),
        placeholders=("command", "description"),
    ),
    "guidance.hint.tip": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.HINT,
        template="Tip: {message}",
        placeholders=("message",),
    ),
    # -------------------------------------------------------------------------
    # Validation Category
    # -------------------------------------------------------------------------
    "guidance.validation.invalid_choice": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.VALIDATION,
        template="Invalid choice. Enter {min} to {max}.",
        verbose_template=("Invalid choice.\nPlease enter a number between {min} and {max}."),
        placeholders=("min", "max"),
    ),
    "guidance.validation.invalid_input": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.VALIDATION,
        template="Invalid input: {details}",
        verbose_template=("Invalid input received.\nDetails: {details}"),
        placeholders=("details",),
    ),
    # -------------------------------------------------------------------------
    # Input Category
    # -------------------------------------------------------------------------
    "guidance.input.provide_plan": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.INPUT,
        template="Provide the plan source:",
        verbose_template=(
            "Plan input required.\nProvide the plan source (file path, URL, or inline content):"
        ),
    ),
    "guidance.input.provide_objective": MessageTemplate(
        domain=MessageDomain.GUIDANCE,
        category=GuidanceCategory.INPUT,
        template="Provide the objective:",
        verbose_template=("Objective required.\nProvide the objective or task description:"),
    ),
}


# =============================================================================
# Builder Functions (FR-3)
# =============================================================================


def get_guidance(key: str, **kwargs: Any) -> str:
    """
    Get a guidance message with automatic domain prefix.

    Args:
        key: Key without 'guidance.' prefix (e.g., 'requirement.select_project')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"guidance.{key}", **kwargs)


def build_options_list(options: list[tuple[str, str]]) -> str:
    """
    Build a numbered options list.

    Args:
        options: List of (label, description) tuples

    Returns:
        Formatted numbered list string
    """
    fmt = FORMATTING_PRIMITIVES["numbered_list_format"]
    lines = []
    for i, (label, description) in enumerate(options, 1):
        prefix = str(fmt).format(i)
        lines.append(f"{prefix}{label} - {description}")
    return "\n".join(lines)


def build_usage_hint(command: str, description: str) -> str:
    """
    Build a usage hint message.

    Args:
        command: The command to use
        description: What the command does

    Returns:
        Formatted hint message
    """
    from obra.messages.registry import get_message

    return get_message("guidance.hint.use_command", command=command, description=description)


def build_requirement_message(requirement: str) -> str:
    """
    Build a requirement message by looking up the template.

    Args:
        requirement: Requirement type (e.g., 'select_project', 'accept_terms')

    Returns:
        Formatted requirement message
    """
    from obra.messages.registry import get_message

    return get_message(f"guidance.requirement.{requirement}")
