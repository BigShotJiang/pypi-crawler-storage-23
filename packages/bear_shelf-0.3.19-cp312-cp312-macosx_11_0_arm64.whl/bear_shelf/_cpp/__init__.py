# bear_shelf._cpp - C++ extension modules
# The 'core' submodule contains C++ implementations of core types
from .core import HeaderDataBase

type HeaderDataSerialized = dict[str, str | list[str]]


__all__ = ["HeaderDataBase", "HeaderDataSerialized"]
