// header_data.hpp - Database header metadata for bear-shelf
// Ported from header_data.pxd/pyx (Cython) to C++20

#ifndef BEAR_SHELF_HEADER_DATA_HPP
#define BEAR_SHELF_HEADER_DATA_HPP

#include <algorithm>
#include <functional>
#include <string>
#include <string_view>
#include <vector>
#include "_version.hpp"

namespace bear_shelf {

    inline const std::string_view DEFAULT_VERSION = UNITED_DATA_VERSION_STR;
    inline const std::string_view DEFAULT_SCHEMA_VERSION = SCHEMA_VERSION_STR;

    // =============================================================================
    // HeaderData - Database header metadata
    // =============================================================================

    class HeaderData
    {
    public:
        // Constructors
        HeaderData()
            : version_(DEFAULT_VERSION), schema_version_(DEFAULT_SCHEMA_VERSION), tables_(), cached_hash_(0), hash_valid_(false) {}

        HeaderData(
            std::string_view version,
            std::string_view schema_version,
            std::vector<std::string> tables = {})
            : version_(version), schema_version_(schema_version), tables_(std::move(tables)), cached_hash_(0), hash_valid_(false) {}

        // Version property
        [[nodiscard]] const std::string &version() const noexcept { return version_; }
        void set_version(std::string_view value)
        {
            version_ = value;
            invalidate_hash();
        }

        // Schema version property
        [[nodiscard]] const std::string &schema_version() const noexcept { return schema_version_; }
        void set_schema_version(std::string_view value)
        {
            schema_version_ = value;
            invalidate_hash();
        }

        // Tables property
        [[nodiscard]] const std::vector<std::string> &tables() const noexcept { return tables_; }
        void set_tables(std::vector<std::string> value)
        {
            tables_ = std::move(value);
            invalidate_hash();
        }

        // Check if table exists
        [[nodiscard]] bool contains(std::string_view table_name) const noexcept
        {
            return std::find(tables_.begin(), tables_.end(), table_name) != tables_.end();
        }

        // Add table (if not already present)
        void add(std::string_view table_name)
        {
            if (!contains(table_name))
            {
                tables_.emplace_back(table_name);
                invalidate_hash();
            }
        }

        // Remove table (if present)
        void remove(std::string_view table_name)
        {
            auto it = std::find(tables_.begin(), tables_.end(), table_name);
            if (it != tables_.end())
            {
                tables_.erase(it);
                invalidate_hash();
            }
        }

        // Number of tables
        [[nodiscard]] std::size_t num_tables() const noexcept
        {
            return tables_.size();
        }

        // Hash computation (cached)
        [[nodiscard]] std::size_t hash() const
        {
            if (!hash_valid_)
            {
                compute_hash();
            }
            return cached_hash_;
        }

        // Equality based on hash
        [[nodiscard]] bool operator==(const HeaderData &other) const
        {
            return hash() == other.hash();
        }

        [[nodiscard]] bool operator!=(const HeaderData &other) const
        {
            return !(*this == other);
        }

    private:
        std::string version_;
        std::string schema_version_;
        std::vector<std::string> tables_;

        mutable std::size_t cached_hash_;
        mutable bool hash_valid_;

        void invalidate_hash() const noexcept
        {
            hash_valid_ = false;
        }

        void compute_hash() const
        {
            // Combine hashes of version, schema_version, and all table names
            std::size_t h = 0;
            auto hash_combine = [&h](std::size_t value)
            {
                // boost::hash_combine formula
                h ^= value + 0x9e3779b9 + (h << 6) + (h >> 2);
            };

            hash_combine(std::hash<std::string>{}(version_));
            hash_combine(std::hash<std::string>{}(schema_version_));

            for (const auto &table : tables_)
            {
                hash_combine(std::hash<std::string>{}(table));
            }

            cached_hash_ = h;
            hash_valid_ = true;
        }
};

}  // namespace bear_shelf

// std::hash specialization for HeaderData
template <>
struct std::hash<bear_shelf::HeaderData> {
    std::size_t operator()(const bear_shelf::HeaderData& hd) const {
        return hd.hash();
    }
};

#endif  // BEAR_SHELF_HEADER_DATA_HPP
