// core.cpp - Raw CPython API bindings for bear-shelf C++ types
// This creates a Python extension module: bear_shelf._cpp.core

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "structmember.h"

#include "header_data.hpp"

// =============================================================================
// HeaderDataBase - Python type wrapping bear_shelf::HeaderData
// =============================================================================

typedef struct HeaderDataBaseObject {
    PyObject_HEAD
    bear_shelf::HeaderData* data;
} HeaderDataBaseObject;

/**
 * @brief Deallocate a HeaderDataBaseObject instance.
 * @param self Pointer to the HeaderDataBaseObject instance.
*/
static void HeaderDataBase_dealloc(HeaderDataBaseObject* self) {
    delete self->data;
    Py_TYPE(self)->tp_free((PyObject*)self);
}

/**
 * @brief Create a new HeaderDataBaseObject instance.
 * @param type Pointer to the type object.
 * @param args Positional arguments.
 * @param kwds Keyword arguments.
 * @return New HeaderDataBaseObject instance or NULL on failure.
*/
static PyObject* HeaderDataBase_new(PyTypeObject* type, PyObject* args, PyObject* kwds) {
    HeaderDataBaseObject* self = (HeaderDataBaseObject*)type->tp_alloc(type, 0);
    if (self != NULL) {
        self->data = nullptr;
    }
    return (PyObject*)self;
}

/**
 * @brief Initialize a HeaderDataBaseObject instance.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param args Positional arguments (version, schema_version, tables).
 * @param kwds Keyword arguments.
 * @return 0 on success, -1 on failure.
*/
static int HeaderDataBase_init(HeaderDataBaseObject* self, PyObject* args, PyObject* kwds) {
    static const char* kwlist[] = {"version", "schema_version", "tables", NULL};

    const char* version = nullptr;
    const char* schema_version = nullptr;
    PyObject* tables_obj = nullptr;

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "|zzO", const_cast<char**>(kwlist),
                                     &version, &schema_version, &tables_obj)) {
        return -1;
    }

    std::vector<std::string> tables;
    Py_ssize_t length;
    const char* table_name;
    if (tables_obj != nullptr && tables_obj != Py_None) {
        if (!PyList_Check(tables_obj)) {
            PyErr_SetString(PyExc_TypeError, "tables must be a list");
            return -1;
        }
        Py_ssize_t size = PyList_Size(tables_obj);
        tables.reserve(size);
        for (Py_ssize_t i = 0; i < size; i++) {
            PyObject* item = PyList_GetItem(tables_obj, i);
            if (!PyUnicode_Check(item)) {
                PyErr_SetString(PyExc_TypeError, "tables must contain strings");
                return -1;
            }
            table_name = PyUnicode_AsUTF8AndSize(item, &length);
            tables.emplace_back(table_name, length);
        }
    }


    if (version && schema_version) {
        self->data = new bear_shelf::HeaderData(version, schema_version, std::move(tables));
    } else if (version) {
        self->data = new bear_shelf::HeaderData(version, bear_shelf::DEFAULT_SCHEMA_VERSION, std::move(tables));
    } else if (schema_version) {
        self->data = new bear_shelf::HeaderData(bear_shelf::DEFAULT_VERSION, schema_version, std::move(tables));
    } else {
        self->data = new bear_shelf::HeaderData();
        if (!tables.empty()) {
            self->data->set_tables(std::move(tables));
        }
    }
    return 0;
}

/**
 * @brief Get the version property of the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param closure Unused.
 * @return New reference to the version string.
*/
static PyObject* HeaderDataBase_get_version(HeaderDataBaseObject* self, void* closure) {
    return PyUnicode_FromString(self->data->version().c_str());
}

/**
 * @brief Set the version property of the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param value New value for the version property (must be a string).
 * @param closure Unused.
 * @return 0 on success, -1 on failure.
*/
static int HeaderDataBase_set_version(HeaderDataBaseObject* self, PyObject* value, void* closure) {
    if (value == NULL || !PyUnicode_Check(value)) {
        PyErr_SetString(PyExc_TypeError, "version must be a string");
        return -1;
    }
    self->data->set_version(PyUnicode_AsUTF8(value));
    return 0;
}

/**
 * @brief Get the schema_version property of the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param closure Unused.
 * @return New reference to the schema_version string.
*/
static PyObject* HeaderDataBase_get_schema_version(HeaderDataBaseObject* self, void* closure) {
    return PyUnicode_FromString(self->data->schema_version().c_str());
}

static int HeaderDataBase_set_schema_version(HeaderDataBaseObject* self, PyObject* value, void* closure) {
    if (value == NULL || !PyUnicode_Check(value)) {
        PyErr_SetString(PyExc_TypeError, "schema_version must be a string");
        return -1;
    }
    self->data->set_schema_version(PyUnicode_AsUTF8(value));
    return 0;
}

/**
 * @brief Get the tables property of the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param closure Unused.
 * @return New reference to a list of table names.
*/
static PyObject* HeaderDataBase_get_tables(HeaderDataBaseObject* self, void* closure) {
    const auto& tables = self->data->tables();
    PyObject* list = PyList_New(tables.size());
    if (list == NULL) return NULL;

    for (size_t i = 0; i < tables.size(); i++) {
        PyObject* str = PyUnicode_FromString(tables[i].c_str());
        if (str == NULL) {
            Py_DECREF(list);
            return NULL;
        }
        PyList_SET_ITEM(list, i, str);
    }
    return list;
}

/**
 * @brief Set the tables property of the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param value New value for the tables property (must be a list of strings).
 * @param closure Unused.
 * @return 0 on success, -1 on failure.
*/
static int HeaderDataBase_set_tables(HeaderDataBaseObject* self, PyObject* value, void* closure) {
    if (value == NULL || !PyList_Check(value)) {
        PyErr_SetString(PyExc_TypeError, "tables must be a list");
        return -1;
    }

    std::vector<std::string> tables;
    const char* table_name;
    Py_ssize_t length;
    Py_ssize_t size = PyList_Size(value);
    tables.reserve(size);

    for (Py_ssize_t i = 0; i < size; i++) {
        PyObject* item = PyList_GetItem(value, i);
        if (!PyUnicode_Check(item)) {
            PyErr_SetString(PyExc_TypeError, "tables must contain strings");
            return -1;
        }
        table_name = PyUnicode_AsUTF8AndSize(item, &length);
        tables.emplace_back(table_name, length);
    }

    self->data->set_tables(std::move(tables));
    return 0;
}

/**
 * @brief Add a table name to the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param args Positional arguments (table_name).
 * @return Py_None on success, NULL on failure.
*/
static PyObject* HeaderDataBase_add(HeaderDataBaseObject* self, PyObject* args) {
    const char* table_name;
    if (!PyArg_ParseTuple(args, "s", &table_name)) {
        return NULL;
    }
    self->data->add(table_name);
    Py_RETURN_NONE;
}

/**
 * @brief Remove a table name from the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param args Positional arguments (table_name).
 * @return Py_None on success, NULL on failure.
*/
static PyObject* HeaderDataBase_remove(HeaderDataBaseObject* self, PyObject* args) {
    const char* table_name;
    if (!PyArg_ParseTuple(args, "s", &table_name)) {
        return NULL;
    }
    self->data->remove(table_name);
    Py_RETURN_NONE;
}

/**
 * @brief Return a dictionary representation of the HeaderDataBaseObject.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param args Positional arguments.
 * @param kwds Keyword arguments.
 * @return New dictionary object or NULL on failure.
*/
static PyObject* HeaderDataBase_model_dump(HeaderDataBaseObject* self, PyObject* args, PyObject* kwds) {
    // exclude_none is accepted but ignored (we always include all fields)
    static const char* kwlist[] = {"exclude_none", NULL};
    int exclude_none = 1;

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "|p", const_cast<char**>(kwlist), &exclude_none)) {
        return NULL;
    }

    PyObject* dict = PyDict_New();
    if (dict == NULL) return NULL;

    PyObject* version = PyUnicode_FromString(self->data->version().c_str());
    PyObject* schema_version = PyUnicode_FromString(self->data->schema_version().c_str());
    PyObject* tables = HeaderDataBase_get_tables(self, NULL);

    if (version == NULL || schema_version == NULL || tables == NULL) {
        Py_XDECREF(version);
        Py_XDECREF(schema_version);
        Py_XDECREF(tables);
        Py_DECREF(dict);
        return NULL;
    }

    PyDict_SetItemString(dict, "version", version);
    PyDict_SetItemString(dict, "schema_version", schema_version);
    PyDict_SetItemString(dict, "tables", tables);

    Py_DECREF(version);
    Py_DECREF(schema_version);
    Py_DECREF(tables);
    return dict;
}

/**
 * @brief Return the items of the HeaderDataBaseObject as a list of tuples.
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param ignored Unused.
 * @return New list of tuples or NULL on failure.
*/
static PyObject* HeaderDataBase_items(HeaderDataBaseObject* self, PyObject* Py_UNUSED(ignored)) {
    PyObject* dict = HeaderDataBase_model_dump(self, PyTuple_New(0), NULL);
    if (dict == NULL) return NULL;

    PyObject* items = PyDict_Items(dict);
    Py_DECREF(dict);
    return items;
}

/**
 * @brief Check if a table name exists in the HeaderDataBaseObject. (sq_contains method)
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @param key Table name to check (must be a string).
 * @return 1 if exists, 0 if not, -1 on error.
*/  
static int HeaderDataBase_contains(HeaderDataBaseObject* self, PyObject* key) {
    if (!PyUnicode_Check(key)) {
        PyErr_SetString(PyExc_TypeError, "table name must be a string");
        return -1;
    }
    return self->data->contains(PyUnicode_AsUTF8(key)) ? 1 : 0;
}

/**
 * @brief Hash function for HeaderDataBaseObject. (__hash__ method)
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @return Hash value.
*/
static Py_hash_t HeaderDataBase_hash(HeaderDataBaseObject* self) {
    return static_cast<Py_hash_t>(self->data->hash());
}

/**
 * @brief Representation of HeaderDataBaseObject. (__repr__ method)
 * @param self Pointer to the HeaderDataBaseObject instance.
 * @return New string object representing the HeaderDataBaseObject.
*/
static PyObject* HeaderDataBase_repr(HeaderDataBaseObject* self) {
    PyObject* tables = HeaderDataBase_get_tables(self, NULL);
    if (tables == NULL) return NULL;

    PyObject* tables_repr = PyObject_Repr(tables);
    Py_DECREF(tables);
    if (tables_repr == NULL) return NULL;

    PyObject* result = PyUnicode_FromFormat(
        "HeaderDataBase(version=%s, schema_version=%s, tables=%U)",
        self->data->version().c_str(),
        self->data->schema_version().c_str(),
        tables_repr
    );
    Py_DECREF(tables_repr);
    return result;
}

/**
 * @brief Rich comparison for HeaderDataBaseObject.
 * @param self_obj Pointer to the HeaderDataBaseObject instance.
 * @param other Pointer to the other object to compare.
 * @param op Comparison operation.
 * @return Py_True or Py_False for equality/inequality, or NotImplemented.
*/
static PyObject* HeaderDataBase_richcompare(PyObject* self_obj, PyObject* other, int op) {
    if (op != Py_EQ && op != Py_NE) {
        Py_RETURN_NOTIMPLEMENTED;
    }

    // Check if other is same type or subtype
    if (Py_TYPE(other) != Py_TYPE(self_obj) &&
        !PyType_IsSubtype(Py_TYPE(other), Py_TYPE(self_obj))) {
        Py_RETURN_NOTIMPLEMENTED;
    }

    HeaderDataBaseObject* self = (HeaderDataBaseObject*)self_obj;
    HeaderDataBaseObject* other_hd = (HeaderDataBaseObject*)other;
    bool equal = (*self->data == *other_hd->data);

    if (op == Py_EQ) {
        return PyBool_FromLong(equal);
    } else {
        return PyBool_FromLong(!equal);
    }
}

/**
 * @brief Sequence methods for HeaderDataBaseType.
*/
static PySequenceMethods HeaderDataBase_as_sequence = {
    0,                                    // sq_length
    0,                                    // sq_concat
    0,                                    // sq_repeat
    0,                                    // sq_item
    0,                                    // was_sq_slice
    0,                                    // sq_ass_item
    0,                                    // was_sq_ass_slice
    (objobjproc)HeaderDataBase_contains,  // sq_contains
    0,                                    // sq_inplace_concat
    0,                                    // sq_inplace_repeat
};

/**
 * @brief Property definitions for HeaderDataBaseType.
*/
static PyGetSetDef HeaderDataBase_getsetters[] = {
    {"version", (getter)HeaderDataBase_get_version, (setter)HeaderDataBase_set_version, "Database version", NULL},
    {"schema_version", (getter)HeaderDataBase_get_schema_version, (setter)HeaderDataBase_set_schema_version, "Schema version", NULL},
    {"tables", (getter)HeaderDataBase_get_tables, (setter)HeaderDataBase_set_tables, "List of table names", NULL},
    {NULL}
};

/**
 * @brief Method definitions for HeaderDataBaseType.
*/
static PyMethodDef HeaderDataBase_methods[] = {
    {"add", (PyCFunction)HeaderDataBase_add, METH_VARARGS, "Add a table name"},
    {"remove", (PyCFunction)HeaderDataBase_remove, METH_VARARGS, "Remove a table name"},
    {"model_dump", (PyCFunction)HeaderDataBase_model_dump, METH_VARARGS | METH_KEYWORDS, "Return dict representation"},
    {"items", (PyCFunction)HeaderDataBase_items, METH_NOARGS, "Return items as list of tuples"},
    {NULL}
};

/**
 * @brief HeaderDataBaseType definition.
*/

static PyTypeObject HeaderDataBaseType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "bear_shelf._cpp.core.HeaderDataBase",        // tp_name
    sizeof(HeaderDataBaseObject),                 // tp_basicsize
    0,                                            // tp_itemsize
    (destructor)HeaderDataBase_dealloc,           // tp_dealloc
    0,                                            // tp_vectorcall_offset
    0,                                            // tp_getattr
    0,                                            // tp_setattr
    0,                                            // tp_as_async
    (reprfunc)HeaderDataBase_repr,                // tp_repr
    0,                                            // tp_as_number
    &HeaderDataBase_as_sequence,                  // tp_as_sequence
    0,                                            // tp_as_mapping
    (hashfunc)HeaderDataBase_hash,                // tp_hash
    0,                                            // tp_call
    0,                                            // tp_str
    0,                                            // tp_getattro
    0,                                            // tp_setattro
    0,                                            // tp_as_buffer
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,     // tp_flags
    "HeaderData base class (C++ implementation)", // tp_doc
    0,                                            // tp_traverse
    0,                                            // tp_clear
    (richcmpfunc)HeaderDataBase_richcompare,      // tp_richcompare
    0,                                            // tp_weaklistoffset
    0,                                            // tp_iter
    0,                                            // tp_iternext
    HeaderDataBase_methods,                       // tp_methods
    0,                                            // tp_members
    HeaderDataBase_getsetters,                    // tp_getset
    0,                                            // tp_base
    0,                                            // tp_dict
    0,                                            // tp_descr_get
    0,                                            // tp_descr_set
    0,                                            // tp_dictoffset
    (initproc)HeaderDataBase_init,                // tp_init
    0,                                            // tp_alloc
    HeaderDataBase_new,                           // tp_new
};

// =============================================================================
// Module definition
// =============================================================================

static PyModuleDef coremodule = {
    PyModuleDef_HEAD_INIT,
    "bear_shelf._cpp.core",                       // m_name
    "C++ core types for bear-shelf",              // m_doc
    -1,                                           // m_size
};

/**
 * @brief Module initialization function.
 * @return New module object or NULL on failure.
*/
PyMODINIT_FUNC PyInit_core(void) {
    if (PyType_Ready(&HeaderDataBaseType) < 0) {
        return NULL;
    }

    PyObject* m = PyModule_Create(&coremodule);
    if (m == NULL) {
        return NULL;
    }

    Py_INCREF(&HeaderDataBaseType);
    if (PyModule_AddObject(m, "HeaderDataBase", (PyObject*)&HeaderDataBaseType) < 0) {
        Py_DECREF(&HeaderDataBaseType);
        Py_DECREF(m);
        return NULL;
    }

    return m;
}
