#pragma once
#include <string_view>
/* AUTO-GENERATED FILE - DO NOT EDIT, EDIT bear_build.toml INSTEAD */
namespace bear_shelf {
    struct Version {
        int major;
        int minor;
        int patch;
        constexpr Version(int maj, int min, int pat) : major(maj), minor(min), patch(pat) {}
    };
    constexpr Version UNITED_DATA_VERSION{ 1, 1, 0 };
    constexpr Version SCHEMA_VERSION{ 1, 0, 0 };
    inline constexpr std::string_view UNITED_DATA_VERSION_STR = "1.1.0";
    inline constexpr std::string_view SCHEMA_VERSION_STR = "1.0.0";
}
