// common.hpp - Buffer utilities and TOML string escaping for bear-shelf
// Ported from common.pxd/pyx (Cython) to C++20

#ifndef BEAR_SHELF_COMMON_HPP
#define BEAR_SHELF_COMMON_HPP

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace bear_shelf {

// =============================================================================
// Constants
// =============================================================================

inline constexpr std::size_t INITIAL_BUFFER_SIZE = 65536;  // 64KB
inline constexpr std::size_t BYTES_PER_RECORD = 2000;
inline constexpr std::size_t BYTES_PER_TABLE = 500;
inline constexpr std::size_t MIN_BUFFER_SIZE = 4096;

inline constexpr char32_t CHAR_BACKSLASH = U'\\';
inline constexpr char32_t CHAR_DOUBLE_QUOTE = U'"';
inline constexpr char32_t CHAR_NEWLINE = U'\n';
inline constexpr char32_t CHAR_CARRIAGE_RETURN = U'\r';
inline constexpr char32_t CHAR_TAB = U'\t';
inline constexpr char32_t CHAR_BACKSPACE = U'\b';
inline constexpr char32_t CHAR_FORMFEED = U'\f';

inline constexpr std::string_view ESCAPED_BACKSLASH = "\\\\";
inline constexpr std::string_view ESCAPED_DOUBLE_QUOTE = "\\\"";
inline constexpr std::string_view ESCAPED_NEWLINE = "\\n";
inline constexpr std::string_view ESCAPED_CARRIAGE_RETURN = "\\r";
inline constexpr std::string_view ESCAPED_TAB = "\\t";
inline constexpr std::string_view ESCAPED_BACKSPACE = "\\b";
inline constexpr std::string_view ESCAPED_FORMFEED = "\\f";

// =============================================================================
// Buffer - Dynamic byte buffer using std::vector
// =============================================================================

/**
 * @brief Dynamic byte buffer for efficient writing of bytes and strings
*/
class Buffer {
public:
    explicit Buffer(std::size_t initial_capacity = INITIAL_BUFFER_SIZE) {
        data_.reserve(initial_capacity);
    }

    /**
     * @brief Write raw bytes to the buffer
     * @param s Pointer to bytes
     * @param length Number of bytes to write
    */
    void write(const char* s, std::size_t length) {
        data_.insert(data_.end(), s, s + length);
    }

    /**
     * @brief Write a string_view to the buffer
     * @param sv string_view to write
    */
    void write(std::string_view sv) {
        data_.insert(data_.end(), sv.begin(), sv.end());
    }

    /**
     * @brief Write a single character to the buffer
     * @param c Character to write
    */
    void write_char(char c) {
        data_.push_back(c);
    }

    /**
     * @brief Get current position (size) in the buffer
     * @return Current size of the buffer
    */
    [[nodiscard]] std::size_t pos() const noexcept {
        return data_.size();
    }

    /**
     * @brief Get current capacity of the buffer
     * @return Current capacity of the buffer
    */
    [[nodiscard]] std::size_t capacity() const noexcept {
        return data_.capacity();
    }

    /**
     * @brief Get raw data pointer
     * @return Pointer to the buffer's data
    */
    [[nodiscard]] const char* data() const noexcept {
        return data_.data();
    }

    /**
     * @brief Get as string_view (no copy)
     * @return string_view of the buffer's contents
    */
    [[nodiscard]] std::string_view view() const noexcept {
        return {data_.data(), data_.size()};
    }

    /**
     * @brief Convert buffer contents to std::string (makes a copy)
     * @return std::string containing the buffer's data
    */
    [[nodiscard]] std::string to_string() const {
        return {data_.begin(), data_.end()};
    }

    /**
     * @brief Reserve additional capacity in the buffer
     * @param new_capacity New capacity to reserve
    */
    void reserve(std::size_t new_capacity) {
        data_.reserve(new_capacity);
    }

    /**
     * @brief Clear the buffer contents
    */
    void clear() noexcept {
        data_.clear();
    }

private:
    std::vector<char> data_;
};

// =============================================================================
// UTF-8 Encoding - Convert Unicode codepoint to UTF-8 bytes
// =============================================================================

/**
 * @brief Result of UTF-8 encoding
*/
struct Utf8Result {
    char bytes[4];
    std::size_t length;
};

/**
 * @brief Encode a Unicode codepoint into UTF-8 bytes
 * @param codepoint Unicode codepoint to encode
 * @return Utf8Result containing the bytes and length
*/
[[nodiscard]] inline constexpr Utf8Result encode_utf8(char32_t codepoint) noexcept {
    Utf8Result result{};

    if (codepoint < 0x80) {
        // 1-byte: 0xxxxxxx
        result.bytes[0] = static_cast<char>(codepoint);
        result.length = 1;
    } else if (codepoint < 0x800) {
        // 2-byte: 110xxxxx 10xxxxxx
        result.bytes[0] = static_cast<char>(0xC0 | (codepoint >> 6));
        result.bytes[1] = static_cast<char>(0x80 | (codepoint & 0x3F));
        result.length = 2;
    } else if (codepoint < 0x10000) {
        // 3-byte: 1110xxxx 10xxxxxx 10xxxxxx
        result.bytes[0] = static_cast<char>(0xE0 | (codepoint >> 12));
        result.bytes[1] = static_cast<char>(0x80 | ((codepoint >> 6) & 0x3F));
        result.bytes[2] = static_cast<char>(0x80 | (codepoint & 0x3F));
        result.length = 3;
    } else {
        // 4-byte: 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
        result.bytes[0] = static_cast<char>(0xF0 | (codepoint >> 18));
        result.bytes[1] = static_cast<char>(0x80 | ((codepoint >> 12) & 0x3F));
        result.bytes[2] = static_cast<char>(0x80 | ((codepoint >> 6) & 0x3F));
        result.bytes[3] = static_cast<char>(0x80 | (codepoint & 0x3F));
        result.length = 4;
    }

    return result;
}

// =============================================================================
// TOML String Escaping
// =============================================================================

/**
 * @brief Get the TOML escape sequence for a given Unicode codepoint
 * @param codepoint Unicode codepoint to check
 * @return Optional string_view of the escape sequence, or nullopt if none
*/
[[nodiscard]] inline constexpr std::optional<std::string_view> get_toml_escape(char32_t codepoint) noexcept {
    switch (codepoint) {
        case CHAR_BACKSLASH:       return ESCAPED_BACKSLASH;
        case CHAR_DOUBLE_QUOTE:    return ESCAPED_DOUBLE_QUOTE;
        case CHAR_NEWLINE:         return ESCAPED_NEWLINE;
        case CHAR_CARRIAGE_RETURN: return ESCAPED_CARRIAGE_RETURN;
        case CHAR_TAB:             return ESCAPED_TAB;
        case CHAR_BACKSPACE:       return ESCAPED_BACKSPACE;
        case CHAR_FORMFEED:        return ESCAPED_FORMFEED;
        default:
            // Control characters (0x00-0x1F) except those handled above need \uXXXX escaping
            // But we handle that separately since it requires dynamic formatting
            return std::nullopt;
    }
}

/**
 * @brief Determine if a Unicode codepoint needs to be escaped as \uXXXX
 * @param codepoint Unicode codepoint to check
 * @return true if it needs \uXXXX escaping, false otherwise
*/
[[nodiscard]] inline constexpr bool needs_unicode_escape(char32_t codepoint) noexcept {
    /* Control chars 0x00-0x1F, excluding those with named escapes */
    if (codepoint >= 0x20) return false;
    switch (codepoint) {
        case CHAR_NEWLINE:
        case CHAR_CARRIAGE_RETURN:
        case CHAR_TAB:
        case CHAR_BACKSPACE:
        case CHAR_FORMFEED:
            return false;  // These have named escapes
        default:
            return true;   // Other control chars need \uXXXX
    }
}

/**
 * @brief Write a Unicode codepoint as a \uXXXX escape sequence into the buffer
 * @param buf Buffer to write into
 * @param codepoint Unicode codepoint to escape
*/
inline void write_unicode_escape(Buffer& buf, char32_t codepoint) {
    char escape[7];  // \uXXXX + null
    std::snprintf(escape, sizeof(escape), "\\u%04X", static_cast<unsigned int>(codepoint));
    buf.write(escape, 6);
}

/**
 * @brief Escape a UTF-8 string for TOML and write to buffer
 * @param buf Buffer to write escaped string into
 * @param input UTF-8 encoded input string
*/
inline void escape_toml_to_buf(Buffer& buf, std::string_view input) {
    const char* ptr = input.data();
    const char* end = ptr + input.size();
    while (ptr < end) {
        char32_t codepoint;         // Decode UTF-8 to get codepoint
        std::size_t char_len;

        auto byte = static_cast<unsigned char>(*ptr);
        if (byte < 0x80) {
            // 1-byte (ASCII)
            codepoint = byte;
            char_len = 1;
        } else if ((byte & 0xE0) == 0xC0) {
            // 2-byte
            codepoint = (byte & 0x1F) << 6;
            codepoint |= (static_cast<unsigned char>(ptr[1]) & 0x3F);
            char_len = 2;
        } else if ((byte & 0xF0) == 0xE0) {
            // 3-byte
            codepoint = (byte & 0x0F) << 12;
            codepoint |= (static_cast<unsigned char>(ptr[1]) & 0x3F) << 6;
            codepoint |= (static_cast<unsigned char>(ptr[2]) & 0x3F);
            char_len = 3;
        } else {
            // 4-byte
            codepoint = (byte & 0x07) << 18;
            codepoint |= (static_cast<unsigned char>(ptr[1]) & 0x3F) << 12;
            codepoint |= (static_cast<unsigned char>(ptr[2]) & 0x3F) << 6;
            codepoint |= (static_cast<unsigned char>(ptr[3]) & 0x3F);
            char_len = 4;
        }

        if (auto escaped = get_toml_escape(codepoint)) {
            buf.write(*escaped);
        } else if (needs_unicode_escape(codepoint)) {
            write_unicode_escape(buf, codepoint);
        } else {
            buf.write(ptr, char_len);
        }
        ptr += char_len;
    }
}

}  // namespace bear_shelf

#endif  // BEAR_SHELF_COMMON_HPP
