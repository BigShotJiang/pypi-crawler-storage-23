// record.hpp - Record data structure for bear-shelf
// Ported from record.pxd/pyx (Cython) to C++20
//
// This header can be used from Cython via: cdef extern from "record.hpp"
// Or from pure C++ code directly.

#ifndef BEAR_SHELF_RECORD_HPP
#define BEAR_SHELF_RECORD_HPP

#include <frozen_cub/utils.h>

// Function pointer type for list getters (keys/values/items)
typedef PyObject* (*ListCallable)(void* rec);

// =============================================================================
// GenericRecord struct - The core record data structure
// Extends HashableDict layout from frozen_cub
// =============================================================================

struct GenericRecord {
    // Hash caching (same layout as BaseHashableStruct from frozen_cub)
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable get_hash;
    HashCallable hasher;

    // Record data (same layout as HashableDict after this point)
    PyObject* data;           // The dict itself

    // Primary key tracking
    PyObject* pk_name;
    PyObject* pk_value;

    // Fast membership checks
    PyObject* keys_set;

    // Cached keys/values/items with lazy computation
    PyObject* _cached_keys;
    ListCallable keys_func;
    PyObject* _cached_values;
    ListCallable values_func;
    PyObject* _cached_items;
    ListCallable items_func;

    // Serialization optimization flag
    int dirty;  // using int for C compatibility (bint in Cython)
};

// =============================================================================
// Cache getter functions (self-swapping pattern)
// =============================================================================

static inline PyObject* get_keys_cached(void* rec) {
    GenericRecord* record = (GenericRecord*)rec;
    return record->_cached_keys;
}

static inline PyObject* get_values_cached(void* rec) {
    GenericRecord* record = (GenericRecord*)rec;
    return record->_cached_values;
}

static inline PyObject* get_items_cached(void* rec) {
    GenericRecord* record = (GenericRecord*)rec;
    return record->_cached_items;
}

// Forward declarations for uncached versions
static inline PyObject* get_keys_uncached(void* rec);
static inline PyObject* get_values_uncached(void* rec);
static inline PyObject* get_items_uncached(void* rec);

// =============================================================================
// Cache invalidation
// =============================================================================

static inline void invalidate_caches(GenericRecord* rec) {
    rec->_cached_keys = NULL;
    rec->keys_func = &get_keys_uncached;
    rec->_cached_values = NULL;
    rec->values_func = &get_values_uncached;
    rec->_cached_items = NULL;
    rec->items_func = &get_items_uncached;
    rec->cached_hash = FC_NOT_SET_SENTINEL;
    rec->get_hash = &get_cached_hash_cond;
    rec->dirty = FC_TRUE;
}

// =============================================================================
// Uncached getters (compute and cache)
// =============================================================================

static inline PyObject* get_keys_uncached(void* rec) {
    GenericRecord* record = (GenericRecord*)rec;
    PyObject* keys = PyDict_Keys(record->data);
    Py_INCREF(keys);
    record->_cached_keys = keys;
    record->keys_func = &get_keys_cached;
    return record->_cached_keys;
}

static inline PyObject* get_values_uncached(void* rec) {
    GenericRecord* record = (GenericRecord*)rec;
    PyObject* values = PyDict_Values(record->data);
    Py_INCREF(values);
    record->_cached_values = values;
    record->values_func = &get_values_cached;
    return record->_cached_values;
}

static inline PyObject* get_items_uncached(void* rec) {
    GenericRecord* record = (GenericRecord*)rec;
    PyObject* items = PyDict_Items(record->data);
    Py_INCREF(items);
    record->_cached_items = items;
    record->items_func = &get_items_cached;
    return record->_cached_items;
}

// =============================================================================
// Record operations
// =============================================================================

static inline PyObject* record_get(GenericRecord* rec, PyObject* key, PyObject* default_val) {
    PyObject* value = PyDict_GetItem(rec->data, key);
    if (value == NULL) {
        return default_val;
    }
    return value;
}

static inline void record_set(GenericRecord* rec, PyObject* key, PyObject* value) {
    PyDict_SetItem(rec->data, key, value);
    PySet_Add(rec->keys_set, key);
    rec->data_size = PyDict_Size(rec->data);
    invalidate_caches(rec);
}

static inline void record_del(GenericRecord* rec, PyObject* key) {
    PyDict_DelItem(rec->data, key);
    PySet_Discard(rec->keys_set, key);
    rec->data_size = PyDict_Size(rec->data);
    invalidate_caches(rec);
}

static inline void record_update(GenericRecord* rec, PyObject* other) {
    PyDict_Update(rec->data, other);
    // Add all keys from other to keys_set
    PyObject* keys = PyDict_Keys(other);
    Py_ssize_t size = PyList_Size(keys);
    for (Py_ssize_t i = 0; i < size; ++i) {
        PySet_Add(rec->keys_set, PyList_GetItem(keys, i));
    }
    Py_DECREF(keys);
    rec->data_size = PyDict_Size(rec->data);
    invalidate_caches(rec);
}

static inline void record_set_root(GenericRecord* rec, PyObject* new_root) {
    PyObject* keys = PySet_New(PyDict_Keys(new_root));

    // Decref old values before replacing
    Py_XDECREF(rec->data);
    Py_XDECREF(rec->keys_set);

    // Set new values
    Py_INCREF(new_root);
    rec->data = new_root;
    rec->keys_set = keys;  // keys already has refcount from PySet_New
    rec->data_size = PyDict_Size(new_root);
    invalidate_caches(rec);
}

// =============================================================================
// Record lifecycle
// =============================================================================

static inline void record_init(GenericRecord* rec, PyObject* root) {
    PyObject* keys = PySet_New(PyDict_Keys(root));

    Py_INCREF(root);
    rec->data = root;
    rec->keys_set = keys;  // PySet_New already gives us a new reference
    rec->data_size = PyDict_Size(root);

    rec->_cached_keys = NULL;
    rec->_cached_values = NULL;
    rec->_cached_items = NULL;
    rec->keys_func = &get_keys_uncached;
    rec->values_func = &get_values_uncached;
    rec->items_func = &get_items_uncached;

    rec->pk_name = NULL;
    rec->pk_value = NULL;
    rec->dirty = FC_FALSE;

    // Set up hash functions
    rec->cached_hash = FC_NOT_SET_SENTINEL;
    rec->hasher = &compute_dict_hash;
    rec->get_hash = &get_cached_hash_cond;
}

static inline void record_dealloc(GenericRecord* rec) {
    Py_XDECREF(rec->data);
    Py_XDECREF(rec->keys_set);
    Py_XDECREF(rec->_cached_keys);
    Py_XDECREF(rec->_cached_values);
    Py_XDECREF(rec->_cached_items);
    Py_XDECREF(rec->pk_name);
    Py_XDECREF(rec->pk_value);
}

// =============================================================================
// Records collection operations (uses HashableValuesList from frozen_cub)
// =============================================================================

static inline void records_set_data(HashableValuesList* rec, PyObject* frozen_values) {
    Py_INCREF(frozen_values);
    rec->values = frozen_values;
    rec->data_size = PyTuple_GET_SIZE(frozen_values);
}

static inline long compute_records_hash(void* ptr) {
    HashableValuesList* hashable = (HashableValuesList*)ptr;
    long result = FC_LONG_ZERO;

    if (hashable->values != NULL) {
        PyObject* values_tuple = hashable->values;
        for (Py_ssize_t i = 0; i < hashable->data_size; ++i) {
            result ^= PyObject_Hash(PyTuple_GET_ITEM(values_tuple, i));
        }
    }
    return result;
}

// Pre-computed hash for NullRecords (constant)
static const long NULL_RECORDS_HASH = 0x4E554C4C5245434FL;  // "NULLRECO" as hex :P

static inline long null_records_hash(void* ptr) {
    (void)ptr;  // unused
    return NULL_RECORDS_HASH;
}

static inline void records_dealloc(HashableValuesList* rec) {
    Py_XDECREF(rec->values);
    Py_XDECREF(rec->op);
}

// Initialize a Records collection
static inline void records_init(HashableValuesList* rec, PyObject* frozen_values) {
    create_hashable((BaseHashableStruct*)rec, &compute_records_hash);
    records_set_data(rec, frozen_values);
    rec->op = NULL;
}

// Initialize a NullRecords collection (always empty)
static inline void null_records_init(HashableValuesList* rec) {
    create_hashable((BaseHashableStruct*)rec, &null_records_hash);
    // Empty tuple for NullRecords
    PyObject* empty = PyTuple_New(0);
    rec->values = empty;  // PyTuple_New gives us a new ref
    rec->data_size = 0;
    rec->op = NULL;
}

// Get first element or NULL if empty
static inline PyObject* records_first(HashableValuesList* rec) {
    if (rec->data_size == 0) {
        return NULL;
    }
    return PyTuple_GET_ITEM(rec->values, 0);
}

// Get last element or NULL if empty
static inline PyObject* records_last(HashableValuesList* rec) {
    if (rec->data_size == 0) {
        return NULL;
    }
    return PyTuple_GET_ITEM(rec->values, rec->data_size - 1);
}

#endif  // BEAR_SHELF_RECORD_HPP
