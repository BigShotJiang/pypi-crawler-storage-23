from __future__ import annotations

import sys

from ._cmds import ExitCode, _ReturnedArgs, args_inject, bump_version, debug_info, get_args, get_version


@args_inject(process=get_args)
def main(args: _ReturnedArgs) -> ExitCode:
    """Entry point for the CLI application.

    This function is executed when you type `bear-shelf` or `python -m bear-shelf`.

    Parameters:
        args: Arguments passed from the command line.

    Returns:
        An exit code.
    """
    match args.cmd:
        case "version":
            return get_version(args.version_name)
        case "bump":
            return bump_version(args.bump_type)
        case "debug":
            return debug_info(no_color=args.no_color)
        case _:
            print("Unknown command.", file=sys.stderr)
            return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
