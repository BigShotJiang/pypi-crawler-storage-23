from __future__ import annotations

from enum import IntEnum
from typing import Final, Literal, NamedTuple

type _BumpType = Literal["major", "minor", "patch"]
_VALIDS: Final[list[_BumpType]] = ["major", "minor", "patch"]
_NULL_VER: Final = "0.0.0"
_NULL_TUP: Final = (0, 0, 0)
_PART_COUNT: Final = 3

try:
    from ._version import (
        __database_schema_version__ as _dsv,
        __united_data_version__ as _udv,
    )
except ImportError, ModuleNotFoundError:
    _udv: tuple[int, int, int] = _NULL_TUP
    _dsv: tuple[int, int, int] = _NULL_TUP


PACKAGE_NAME: Literal["bear-shelf"] = "bear-shelf"
PROJECT_NAME: Literal["bear_shelf"] = "bear_shelf"
PROJECT_UPPER: Literal["BEAR_SHELF"] = "BEAR_SHELF"
ENV_VARIABLE: Literal["BEAR_SHELF_ENV"] = "BEAR_SHELF_ENV"
DATABASE_SCHEMA_VERSION: tuple[int, int, int] = _dsv
UNITED_DATA_VERSION: tuple[int, int, int] = _udv


class ExitCode(IntEnum):
    """An enumeration of common exit codes used in shell commands."""

    SUCCESS = 0
    """An exit code indicating success."""
    FAILURE = 1
    """An exit code indicating a general error."""
    MISUSE_OF_SHELL_COMMAND = 2
    """An exit code indicating misuse of a shell command."""
    COMMAND_CANNOT_EXECUTE = 126
    """An exit code indicating that the command invoked cannot execute."""
    COMMAND_NOT_FOUND = 127
    """An exit code indicating that the command was not found."""
    INVALID_ARGUMENT_TO_EXIT = 128
    """An exit code indicating an invalid argument to exit."""
    SCRIPT_TERMINATED_BY_CONTROL_C = 130
    """An exit code indicating that the script was terminated by Control-C."""
    PROCESS_KILLED_BY_SIGKILL = 137
    """An exit code indicating that the process was killed by SIGKILL (9)."""
    SEGMENTATION_FAULT = 139
    """An exit code indicating a segmentation fault (core dumped)."""
    PROCESS_TERMINATED_BY_SIGTERM = 143
    """An exit code indicating that the process was terminated by SIGTERM (15)."""
    EXIT_STATUS_OUT_OF_RANGE = 255
    """An exit code indicating that the exit status is out of range."""


class VersionParts(IntEnum):  # pragma: no cover
    """Enumeration for version parts."""

    MAJOR = 0
    MINOR = 1
    PATCH = 2


class _Version(NamedTuple):  # pragma: no cover
    """Model to represent a version string."""

    major: int
    minor: int = 0
    patch: int = 0

    def new_version(self, bump_type: str) -> _Version:
        """Return a new version string based on the bump type."""
        bump_part: VersionParts = VersionParts[bump_type.upper()]
        match bump_part:
            case VersionParts.MAJOR:
                return _Version(major=self.major + 1, minor=0, patch=0)
            case VersionParts.MINOR:
                return _Version(major=self.major, minor=self.minor + 1, patch=0)
            case VersionParts.PATCH:
                return _Version(major=self.major, minor=self.minor, patch=self.patch + 1)
            case _:
                raise ValueError(f"Invalid bump type: {bump_type}")

    @classmethod
    def from_string(cls, version_str: str) -> _Version:
        """Create a Version instance from a version string."""
        parts: list[str] = version_str.split(".")
        default: list[int] = list(_NULL_TUP)
        for i in range(min(len(parts), _PART_COUNT)):
            default[i] = int(parts[i])
        return cls(*default)

    @classmethod
    def default(cls) -> _Version:
        """Return the default version (0.0.0)."""
        return cls(major=0, minor=0, patch=0)

    def __repr__(self) -> str:
        """Return a string representation of the Version instance."""
        return f"{self.major}.{self.minor}.{self.patch}"

    def __str__(self) -> str:
        """Return a string representation of the Version instance."""
        return self.__repr__()


def _get_version(dist: str) -> str:
    """Get version of the given distribution or the current package.

    Parameters:
        dist: A distribution name.

    Returns:
        A version number.
    """
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version(dist)
    except PackageNotFoundError:
        return "0.0.0"


def _get_description(dist: str) -> str:
    """Get description of the given distribution or the current package.

    Parameters:
        dist: A distribution name.

    Returns:
        A description string.
    """
    from importlib.metadata import PackageNotFoundError, distribution

    try:
        return distribution(dist).metadata.get("summary", "No description available.")
    except PackageNotFoundError:
        return "No description available."


class _Package(NamedTuple):  # pragma: no cover
    """Model to represent package information."""

    name: str
    """Package name."""
    version: str = "0.0.0"
    """Package version."""
    version_tuple: _Version = _Version.default()
    """Package version as a tuple."""
    description: str = "No description available."
    """Package description."""

    def __str__(self) -> str:
        """String representation of the package information."""
        return f"{self.name} v{self.version}: {self.description}"

    @classmethod
    def new(cls, name: str) -> _Package:
        """Create a new Package instance with the given name."""
        version: str = _get_version(name)
        version_tuple: _Version = _Version.from_string(version)
        description: str = _get_description(name)
        return cls(name=name, version=version, version_tuple=version_tuple, description=description)

    @classmethod
    def _package_info(cls, name: str) -> _Package:
        """Get a string representation of the package information."""
        from importlib.util import find_spec

        if find_spec(f"{PROJECT_NAME}._internal._version"):
            from ._version import __version__ as v, __version_tuple__

            vp = _Version(*__version_tuple__)
        else:
            v: str = _get_version(name)
            vp: _Version = _Version.from_string(v)

        description: str = _get_description(name)
        return cls(name=name, version=v, version_tuple=vp, description=description)


_PACKAGE: Final[_Package] = _Package._package_info(name=PACKAGE_NAME)


class _ProjectMetadata(NamedTuple):
    """Dataclass to store the current project metadata."""

    version: str = _PACKAGE.version
    version_tuple: _Version = _PACKAGE.version_tuple
    description: str = _PACKAGE.description

    united_data_version: _Version = _Version(*UNITED_DATA_VERSION)
    database_schema_version: _Version = _Version(*DATABASE_SCHEMA_VERSION)

    @property
    def full_version(self) -> str:
        """Get the full version string."""
        return f"{self.name} v{self.version}"

    @property
    def name(self) -> Literal["bear-shelf"]:
        """Get the package distribution name."""
        return PACKAGE_NAME

    @property
    def name_upper(self) -> Literal["BEAR_SHELF"]:
        """Get the project name in uppercase with underscores."""
        return PROJECT_UPPER

    @property
    def project_name(self) -> Literal["bear_shelf"]:
        """Get the project name."""
        return PROJECT_NAME

    @property
    def env_variable(self) -> Literal["BEAR_SHELF_ENV"]:
        """Get the environment variable name for the project.

        Used to check if the project is running in a specific environment.
        """
        return ENV_VARIABLE

    def __str__(self) -> str:
        """String representation of the project metadata."""
        return f"{self.full_version}: {self.description}"


METADATA = _ProjectMetadata()


__all__ = ["METADATA"]

# ruff: noqa: PLC0415
