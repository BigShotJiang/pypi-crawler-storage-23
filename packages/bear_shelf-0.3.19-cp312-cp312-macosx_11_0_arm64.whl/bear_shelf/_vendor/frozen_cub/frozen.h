/*
 * MIT License
 *
 * Copyright (c) 2026 Chaz
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* frozen.h - C header for frozen_cub freeze functions */

#ifndef FROZEN_CUB_FROZEN_H
#define FROZEN_CUB_FROZEN_H

#include <Python.h>
#include "utils.h"

/* ============================================================================
 * Forward declarations
 * ============================================================================ */

static inline PyObject* inline_freeze(PyObject* obj, int return_tuples);
static inline PyObject* to_frozen_dict(PyObject* obj, int return_tuples, PyObject* FrozenDictType);
static inline PyObject* to_frozen_list(PyObject* obj);
static inline PyObject* to_frozen_set(PyObject* obj);
static inline PyObject* freeze_tuple_items(PyObject* obj);

/* ============================================================================
 * Helper functions
 * ============================================================================ */

static inline int already_frozen(PyObject* obj, PyObject* BasicHashableType) {
    return PyObject_IsInstance(obj, BasicHashableType);
}

/* ============================================================================
 * Freeze functions
 * ============================================================================ */

static inline PyObject* freeze_tuple_items(PyObject* obj) {
    Py_ssize_t size = PyTuple_Size(obj);
    Py_ssize_t index = 0;
    PyObject* frozen_items = PyTuple_New(size);
    if (frozen_items == NULL) return NULL;

    while (index < size) {
        PyObject* item = PyTuple_GET_ITEM(obj, index);
        PyObject* frozen_item = inline_freeze(item, FC_FALSE);
        if (frozen_item == NULL) {
            Py_DECREF(frozen_items);
            return NULL;
        }
        PyTuple_SET_ITEM(frozen_items, index, frozen_item);
        index++;
    }
    return frozen_items;
}

static inline PyObject* to_frozen_list(PyObject* obj) {
    Py_ssize_t size = PyList_Size(obj);
    Py_ssize_t index = 0;
    PyObject* items = PyTuple_New(size);
    if (items == NULL) return NULL;

    while (index < size) {
        PyObject* item = PyList_GET_ITEM(obj, index);
        PyObject* frozen_item = inline_freeze(item, FC_FALSE);
        if (frozen_item == NULL) {
            Py_DECREF(items);
            return NULL;
        }
        PyTuple_SET_ITEM(items, index, frozen_item);
        index++;
    }
    return items;
}

static inline PyObject* to_frozen_set(PyObject* obj) {
    Py_ssize_t size = PySet_Size(obj);
    Py_ssize_t index = 0;
    PyObject* frozen_items = PyTuple_New(size);
    if (frozen_items == NULL) return NULL;

    PyObject* iterator = PyObject_GetIter(obj);
    if (iterator == NULL) {
        Py_DECREF(frozen_items);
        return NULL;
    }

    PyObject* item;
    while ((item = PyIter_Next(iterator)) != NULL) {
        PyObject* frozen_item = inline_freeze(item, FC_FALSE);
        Py_DECREF(item);
        if (frozen_item == NULL) {
            Py_DECREF(iterator);
            Py_DECREF(frozen_items);
            return NULL;
        }
        PyTuple_SET_ITEM(frozen_items, index, frozen_item);
        index++;
    }
    Py_DECREF(iterator);

    if (PyErr_Occurred()) {
        Py_DECREF(frozen_items);
        return NULL;
    }

    PyObject* result = PyFrozenSet_New(frozen_items);
    Py_DECREF(frozen_items);
    return result;
}

static inline PyObject* to_frozen_dict(PyObject* obj, int return_tuples, PyObject* FrozenDictType) {
    Py_ssize_t pos = 0;
    Py_ssize_t index = 0;
    Py_ssize_t size = PyDict_Size(obj);
    PyObject* key_ptr;
    PyObject* value_ptr;

    PyObject* items = PyTuple_New(size);
    if (items == NULL) return NULL;

    while (PyDict_Next(obj, &pos, &key_ptr, &value_ptr)) {
        PyObject* item = PyTuple_New(2);
        if (item == NULL) {
            Py_DECREF(items);
            return NULL;
        }

        Py_INCREF(key_ptr);
        PyTuple_SET_ITEM(item, 0, key_ptr);

        PyObject* frozen_value = inline_freeze(value_ptr, FC_FALSE);
        if (frozen_value == NULL) {
            Py_DECREF(item);
            Py_DECREF(items);
            return NULL;
        }
        PyTuple_SET_ITEM(item, 1, frozen_value);

        PyTuple_SET_ITEM(items, index, item);
        index++;
    }

    if (return_tuples) {
        return items;
    }

    /* Create FrozenDict from items tuple */
    PyObject* args = PyTuple_Pack(1, items);
    Py_DECREF(items);
    if (args == NULL) return NULL;

    PyObject* result = PyObject_Call(FrozenDictType, args, NULL);
    Py_DECREF(args);
    return result;
}

static inline PyObject* inline_freeze(PyObject* obj, int return_tuples) {
    /* Check primitives first */
    if (obj_is_primitive(obj)) {
        Py_INCREF(obj);
        return obj;
    }

    /* Check type and dispatch */
    if (PyTuple_Check(obj)) {
        return freeze_tuple_items(obj);
    }
    if (PyDict_Check(obj)) {
        /* Note: This version can't create FrozenDict - use Cython wrapper */
        /* For pure C, we'd need the FrozenDict type passed in */
        /* Return frozen tuple of items instead */
        return to_frozen_dict(obj, FC_TRUE, NULL);
    }
    if (PyList_Check(obj)) {
        return to_frozen_list(obj);
    }
    if (PySet_Check(obj)) {
        return to_frozen_set(obj);
    }

    /* Unknown type - return as-is */
    Py_INCREF(obj);
    return obj;
}

#endif /* FROZEN_CUB_FROZEN_H */
