/*
 * MIT License
 *
 * Copyright (c) 2026 Chaz
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* utils.h - C header for frozen_cub utility functions and structs */

#ifndef FROZEN_CUB_UTILS_H
#define FROZEN_CUB_UTILS_H

#include <Python.h>

/* ============================================================================
 * Constants (should match common.pxd)
 * ============================================================================ */

#define FC_FALSE 0
#define FC_TRUE 1
#define FC_NOT_OWNED -1
#define FC_PY_ZERO 0
#define FC_LONG_ZERO 0L
#define FC_NOT_SET_SENTINEL ((long)(-1))

/* ============================================================================
 * Type Definitions
 * ============================================================================ */

typedef long (*HashCallable)(void* ptr);
typedef void (*CommonCallable)(void* ptr);

/* ============================================================================
 * Structs
 * ============================================================================ */

typedef struct {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable get_hash;
    HashCallable hasher;
} BaseHashableStruct;

typedef struct {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable get_hash;
    HashCallable hasher;
    PyObject* value1;
    PyObject* value2;
} HashableCacheKey;

typedef struct {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable get_hash;
    HashCallable hasher;
    PyObject* data;
} HashableDict;

typedef struct {
    long cached_hash;
    Py_ssize_t data_size;
    HashCallable get_hash;
    HashCallable hasher;
    PyObject* values;  /* list of hashable items */
    PyObject* op;      /* optional operation identifier */
} HashableValuesList;

typedef struct {
    PyThread_type_lock lock;
    long owner;
    int count;
    CommonCallable acquire_lock;
    CommonCallable release_lock;
} RLock;

/* ============================================================================
 * Inline Utility Functions
 * ============================================================================ */

static inline void NOOP(void* ptr) {
    (void)ptr;  /* Suppress unused parameter warning */
}

static inline long Hash_Object(PyObject* obj) {
    return PyObject_Hash(obj);
}

static inline PyObject* Get_PyObject_INCREF(PyObject* obj) {
    Py_INCREF(obj);
    return obj;
}

static inline void Tuple_Set_INCREF(PyObject* tuple_obj, Py_ssize_t index, PyObject* item) {
    Py_INCREF(item);
    PyTuple_SET_ITEM(tuple_obj, index, item);
}

static inline long Alt_XOR_Combine(long a, long b, long current) {
    current ^= (b + 0x9e3779b9L + (a << 6) + (a >> 2)) & 0x7FFFFFFFFFFFFFFFL;
    return current;
}

static inline long XOR_Combine(long a, long b, long current) {
    current ^= a ^ ((b << 5) - b);
    return current;
}

static inline int obj_is_primitive(PyObject* obj) {
    if (Py_IsNone(obj)) return FC_TRUE;
    if (PyBool_Check(obj)) return FC_TRUE;
    if (PyUnicode_Check(obj)) return FC_TRUE;
    if (PyBytes_Check(obj)) return FC_TRUE;
    if (PyLong_Check(obj)) return FC_TRUE;
    if (PyFloat_Check(obj)) return FC_TRUE;
    return FC_FALSE;
}

/* ============================================================================
 * Hash Functions (forward declarations needed for circular refs)
 * ============================================================================ */

static inline long get_cached_hash(void* ptr);
static inline long get_cached_hash_cond(void* ptr);

static inline long NOT_SET_NOOP(void* ptr) {
    (void)ptr;
    return FC_NOT_SET_SENTINEL;
}

static inline long get_cached_hash(void* ptr) {
    BaseHashableStruct* hashable = (BaseHashableStruct*)ptr;
    return hashable->cached_hash;
}

static inline long get_cached_hash_cond(void* ptr) {
    BaseHashableStruct* hashable = (BaseHashableStruct*)ptr;
    if (hashable->cached_hash == FC_NOT_SET_SENTINEL) {
        hashable->cached_hash = hashable->hasher(ptr);
        hashable->get_hash = &get_cached_hash;
    }
    return hashable->cached_hash;
}

static inline void create_hashable(BaseHashableStruct* hashable, HashCallable hasher) {
    hashable->cached_hash = FC_NOT_SET_SENTINEL;
    hashable->data_size = FC_PY_ZERO;
    hashable->get_hash = &get_cached_hash_cond;
    hashable->hasher = &NOT_SET_NOOP;
    if (hasher != NULL) {
        hashable->hasher = hasher;
    }
}

static inline long compute_cache_key_hash(void* ptr) {
    HashableCacheKey* hashable = (HashableCacheKey*)ptr;
    return PyObject_Hash(hashable->value1) ^ PyObject_Hash(hashable->value2);
}

static inline int CacheKey_EQ(HashableCacheKey* key1, HashableCacheKey* key2) {
    if (key1->data_size != key2->data_size) return FC_FALSE;
    return PyObject_RichCompareBool(key1->value1, key2->value1, Py_EQ) &&
           PyObject_RichCompareBool(key1->value2, key2->value2, Py_EQ);
}

static inline int CacheKey_NE(HashableCacheKey* key1, HashableCacheKey* key2) {
    if (key1->data_size != key2->data_size) return FC_TRUE;
    return PyObject_RichCompareBool(key1->value1, key2->value1, Py_NE) ||
           PyObject_RichCompareBool(key1->value2, key2->value2, Py_NE);
}

static inline long compute_dict_hash(void* ptr) {
    HashableDict* hashable = (HashableDict*)ptr;
    Py_ssize_t pos = 0;
    long result = 0;
    PyObject* key_ptr;
    PyObject* value_ptr;

    if (hashable->data_size == 0) {
        return PyObject_Hash(PyTuple_New(0));
    }

    while (PyDict_Next(hashable->data, &pos, &key_ptr, &value_ptr)) {
        result = XOR_Combine(Hash_Object(key_ptr), Hash_Object(value_ptr), result);
    }
    return result;
}

static inline int Dict_EQ(HashableDict* dict1, HashableDict* dict2) {
    if (dict1->data_size != dict2->data_size) return FC_FALSE;
    return PyObject_RichCompareBool(dict1->data, dict2->data, Py_EQ);
}

static inline int Dict_NE(HashableDict* dict1, HashableDict* dict2) {
    if (dict1->data_size != dict2->data_size) return FC_TRUE;
    return PyObject_RichCompareBool(dict1->data, dict2->data, Py_NE);
}

/* ============================================================================
 * RLock Functions
 * ============================================================================ */

/* Forward declarations for circular refs */
static inline void Acquire_RLock(void* ptr);
static inline void Release_RLock(void* ptr);

static inline void RLock_New(RLock* r_lock, int enabled) {
    r_lock->lock = PyThread_allocate_lock();
    r_lock->owner = FC_NOT_OWNED;
    r_lock->count = 0;
    r_lock->acquire_lock = &NOOP;
    r_lock->release_lock = &NOOP;
    if (enabled) {
        r_lock->acquire_lock = &Acquire_RLock;
        r_lock->release_lock = &Release_RLock;
    }
}

static inline void RLock_Free(RLock* r_lock) {
    if (r_lock->lock) {
        PyThread_free_lock(r_lock->lock);
    }
}

static inline void Acquire_RLock(void* ptr) {
    RLock* l = (RLock*)ptr;
    long me = PyThread_get_thread_ident();
    if (l->owner == me) {
        l->count += 1;
        return;
    }
    PyThread_acquire_lock(l->lock, 1);
    l->owner = me;
    l->count = 1;
}

static inline void Release_RLock(void* ptr) {
    RLock* l = (RLock*)ptr;
    l->count -= 1;
    if (l->count == 0) {
        l->owner = FC_NOT_OWNED;
        PyThread_release_lock(l->lock);
    }
}

#endif /* FROZEN_CUB_UTILS_H */
