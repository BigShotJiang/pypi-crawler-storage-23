"""TOML storage backend for the datastore.

Provides TOML file storage using the unified data format.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from lazy_bear import lazy
from pydantic import ValidationError

from ._common import Storage

if TYPE_CHECKING:
    from logging import Logger
    from pathlib import Path
    from tomllib import loads as tomllib_loads

    from bear_shelf._logger import get_logger
    from bear_shelf.datastore.adapter.toml.toml_encoder import encode_unified_data
    from bear_shelf.datastore.record import Record
    from bear_shelf.datastore.unified_data import UnifiedDataFormat
    from codec_cub.general.helpers import touch
    from codec_cub.text.file_handler import TextFileHandler
    from funcy_bear.ops.strings.manipulation import truncate
else:
    UnifiedDataFormat = lazy("bear_shelf.datastore.unified_data", "UnifiedDataFormat")
    TextFileHandler = lazy("codec_cub.text.file_handler", "TextFileHandler")
    touch = lazy("codec_cub.general.helpers", "touch")
    truncate = lazy("funcy_bear.ops.strings.manipulation", "truncate")
    tomllib_loads = lazy("tomllib", "loads")
    get_logger = lazy("bear_shelf._logger", "get_logger")
    UnifiedDataFormat = lazy("bear_shelf.datastore.unified_data", "UnifiedDataFormat")
    Record = lazy("bear_shelf.datastore.record", "Record")
    encode_unified_data = lazy("bear_shelf.datastore.adapter.toml.toml_encoder", "encode_unified_data")


class TomlStorage(Storage):
    """A TOML file storage backend using the unified data format."""

    def __init__(self, file: str | Path, file_mode: str = "r+", encoding: str = "utf-8") -> None:
        """Initialize TOML storage.

        Args:
            file: Path to the TOML file
            file_mode: File mode for opening (default: "r+" for read/write)
            encoding: Text encoding to use (default: "utf-8")
        """
        super().__init__()
        self.logger: Logger = get_logger("TomlStorage")
        self.file: Path = touch(file, mkdir=True, create_file=True)
        self.handler: TextFileHandler = TextFileHandler(self.file, mode=file_mode, encoding=encoding)
        self.logger.debug(f"TomlStorage initialized with file: {self.file}")

    def read(self) -> UnifiedDataFormat | None:
        """Read data from TOML file.

        Returns:
            UnifiedDataFormat instance or None if empty.

        Note:
            Extra fields in records not matching the schema columns are filtered out.
        """
        try:
            text: str = self.handler.read()
            self.logger.debug(f"Raw text read from TOML file {self.file}: {truncate(text, max_length=50)}")
            if text.strip():
                data: dict[str, Any] = tomllib_loads(text)
                unified: UnifiedDataFormat = UnifiedDataFormat.model_validate(data)
                self.logger.debug(f"Read data from TOML storage at {self.file}: {unified}")
                for table_data in unified.tables.values():
                    valid_columns: set[str] = {col.name for col in table_data.columns}
                    filtered_records: list[Record] = []
                    for record in table_data.records:
                        filtered_record: dict[str, Any] = {k: v for k, v in record.items() if k in valid_columns}
                        filtered_records.append(Record(**filtered_record))
                    table_data.records = filtered_records
                return unified
            return UnifiedDataFormat()
        except (ValueError, OSError, ValidationError) as e:
            self.logger.error(f"Error reading TOML storage from {self.file}: {e}")
            return None

    def write(self, data: UnifiedDataFormat) -> None:
        """Write data to TOML file with pretty inline formatting.

        We use a specialized Cython encoder for performance.

        Args:
            data: UnifiedDataFormat instance to write.
        """
        self.logger.debug(f"Writing data to TOML storage at {self.file}")
        self.handler.write(encode_unified_data(data))

    def to_string(self, data: UnifiedDataFormat) -> str:
        """Convert UnifiedDataFormat to TOML string.

        Args:
            data: UnifiedDataFormat instance to convert.

        Returns:
            TOML string representation of the data.
        """
        return encode_unified_data(data)

    def close(self) -> None:
        """Close the file handle."""
        self.logger.debug(f"Closing TomlStorage for file: {self.file}: {self.closed=}")
        if self.closed:
            return
        self.handler.close()

    @property
    def closed(self) -> bool:
        """Check if the storage is closed."""
        return self.handler.closed


__all__ = ["TomlStorage"]
