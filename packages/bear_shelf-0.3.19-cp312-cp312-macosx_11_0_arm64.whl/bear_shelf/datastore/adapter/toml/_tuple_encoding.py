"""Tuple-based encoding structures for caching static parts of UnifiedDataFormat.

DESIGN NOTES - Header & Column Caching Strategy
================================================

Problem:
    Current encoding benchmarks show ~125µs baseline overhead for 0 records. This is
    header + columns encoding that happens every single write, even though these parts
    almost never change. For WAL appends (single record writes), this dominates the cost.

Key Insight:
    - Header (version, schema_version, table_names) is static after creation
    - Columns are static after table creation - schema doesn't change during normal ops
    - Only records actually change between writes
    - When users edit TOML manually and reload, fresh objects = fresh cache = automatic invalidation

The Pattern:
    1. First encode: No cached bytes → encode header/columns → cache the bytes
    2. Subsequent encodes: Cached bytes exist → memcpy → skip encoding entirely
    3. Only records get encoded fresh each time (the only thing that changes)

Implementation Approach:
    - NamedTuple with `as_bytes` as first field for fast cache-hit checking
    - If as_bytes is not None → use it directly, ignore other fields
    - If as_bytes is None → encode from fields, then cache result back
    - One `getattr` call to get the full package, minimal Python↔C boundary crossings
    - Cython accesses by index [0], [1], etc. for speed while Python uses named access

Cache Storage:
    - `Columns._columns_as_bytes: bytes | None` on each column (already exists)
    - `TableData._cached_columns_section: bytes | None` for entire columns = [...] block
    - `UnifiedDataFormat._cached_header_bytes: bytes | None` for [header] section

Encoder Changes Needed:
    - Accept structured tuple package instead of raw objects
    - Check as_bytes first, use if present
    - After encoding, call back to set_*_as_bytes() methods to populate cache
    - Subsequent calls skip encoding, just memcpy cached bytes

Expected Gains:
    - First encode: Same speed (still encoding everything)
    - Subsequent encodes: Near-zero cost for header/columns, only records encoded
    - For single-record WAL appends: Could reduce 125µs → ~5-10µs (just record encoding)

Applicability:
    This pattern works for ANY storage backend (TOML, YAML, JSON, etc.) since the
    cache is on the model objects themselves. The encoding format is irrelevant -
    once we've serialized header/columns to bytes for a given format, reuse them.

Status: NOT YET IMPLEMENTED - Design notes for future optimization.
"""

from typing import Any, NamedTuple


class ColumnsTuple(NamedTuple):
    """A named tuple representation of a column."""

    as_bytes: bytes | None = None
    name: str | None = None
    type: str | None = None
    unique: bool | None = None
    comment: str | None = None
    foreign_key: str | None = None
    ondelete: str | None = None
    onupdate: str | None = None
    default: Any = None
    nullable: bool | None = None
    primary_key: bool | None = None
    autoincrement: bool | None = None

    @property
    def has_bytes(self) -> bool:
        """Check if the as_bytes field is set."""
        return self.as_bytes is not None


class HeadersTuple(NamedTuple):
    """A named tuple representation of header data."""

    as_bytes: bytes | None = None
    version: str | None = None
    schema_version: str | None = None

    @property
    def has_bytes(self) -> bool:
        """Check if the as_bytes field is set."""
        return self.as_bytes is not None


class TableDataTuple(NamedTuple):
    """A named tuple representation of table data."""

    name: str
    columns: tuple[ColumnsTuple]
    records: tuple[tuple[Any, ...]]


class UnifiedDataTuple(NamedTuple):
    """A named tuple representation of the unified data format."""

    header: HeadersTuple
    table_names: tuple[str, ...]
    tables: tuple[TableDataTuple, ...]
