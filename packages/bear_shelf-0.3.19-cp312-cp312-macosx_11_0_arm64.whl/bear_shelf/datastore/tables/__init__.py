"""All table-related components of the datastore."""
