"""HeaderData with Pydantic integration.

This module provides HeaderData, a Python class that wraps the C++ HeaderDataBase
and adds Pydantic validation/serialization support.
"""

from typing import TYPE_CHECKING, Any, Self, overload

from frozen_cub.frozen import FrozenDict, freeze
from pydantic_core import core_schema

from bear_shelf._cpp import HeaderDataBase, HeaderDataSerialized

if TYPE_CHECKING:
    from pydantic import GetCoreSchemaHandler


class HeaderData(HeaderDataBase):
    """Database header metadata with Pydantic integration.

    Inherits all functionality from C++ HeaderDataBase and adds:
    - Pydantic validation via __get_pydantic_core_schema__
    - model_validate classmethod
    - frozen_dump for immutable serialization

    Attributes:
        version: str
        schema_version: str
        tables: list[str]
    """

    def frozen_dump(self) -> FrozenDict[str, str | list[str]]:
        """Return a frozen (hashable) representation of the header."""
        return freeze(self.model_dump())

    @classmethod
    @overload
    def model_validate(cls, value: dict) -> Self: ...

    @classmethod
    @overload
    def model_validate(cls, value: HeaderDataBase) -> Self: ...

    @classmethod
    def model_validate(cls, value: Any) -> Self:
        """Validate and convert input to HeaderData."""
        if isinstance(value, cls):
            return value
        if isinstance(value, HeaderDataBase):
            return cls(
                version=value.version,
                schema_version=value.schema_version,
                tables=value.tables,
            )
        if isinstance(value, dict):
            return cls(
                version=value.get("version"),
                schema_version=value.get("schema_version"),
                tables=value.get("tables"),
            )
        raise ValueError(f"Cannot validate {type(value)} as HeaderData")

    @classmethod
    def __get_pydantic_core_schema__(
        cls,
        source_type,
        handler: GetCoreSchemaHandler,
    ) -> core_schema.PlainValidatorFunctionSchema:
        return core_schema.no_info_plain_validator_function(
            cls._validate,
            serialization=core_schema.plain_serializer_function_ser_schema(
                cls._serialize,
                info_arg=False,
            ),
        )

    @classmethod
    def _validate(cls, value: dict | HeaderData) -> HeaderData:
        """Internal validation for Pydantic."""
        return cls.model_validate(value)

    def _serialize(self) -> HeaderDataSerialized:
        """Internal serialization for Pydantic."""
        return self.model_dump()

    def __repr__(self) -> str:
        return f"HeaderData(version={self.version}, schema_version={self.schema_version}, tables={self.tables})"


# ruff: noqa: ANN001
