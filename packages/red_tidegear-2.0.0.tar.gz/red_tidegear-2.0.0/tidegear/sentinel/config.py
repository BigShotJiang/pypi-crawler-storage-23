# SPDX-FileCopyrightText: 2025 cswimr <copyright@csw.im>
# SPDX-License-Identifier: MPL-2.0

"""Configuration schema for Sentinel."""

from enum import StrEnum
from typing import TYPE_CHECKING, Annotated, Any, ClassVar, Self

import discord
import pydantic
from annotated_types import Interval, MultipleOf
from red_commons import logging
from redbot.core import config as red_config
from typing_extensions import override

from tidegear.config import (
    BaseConfigSchema,
    ConfigMeta,
    CustomConfigGroup,
    CustomConfigOption,
    GuildConfigOption,
    JsonableType,
    MemberConfigOption,
)
from tidegear.pydantic import BaseModel, HttpUrl

if TYPE_CHECKING:
    from tidegear.sentinel.moderation_type import ModerationType

__all__ = [
    "MAX_HISTORY_PAGE_SIZE",
    "Pagesize",
    "ButtonConfig",
    "ButtonOverrideBehavior",
    "SentinelConfigSchema",
]

MAX_HISTORY_PAGE_SIZE: Annotated[int, MultipleOf(3)] = 12

Pagesize = Annotated[int, Interval(ge=1, le=MAX_HISTORY_PAGE_SIZE)]


_ModerationTypeGroup = CustomConfigGroup(name="types", identifiers=["guild_id", "moderation_type"])


class ButtonConfig(BaseModel):
    """Schema for a button configuration."""

    label: Annotated[str, pydantic.StringConstraints(max_length=80)]
    """The contents of the button's label."""
    url: HttpUrl
    """The link that clicking the button should send the user to."""
    emoji: discord.PartialEmoji | discord.Emoji | None = None
    """The emoji to use for the button."""

    @pydantic.field_validator("emoji", mode="before")
    @classmethod
    def _validate_emoji(cls, value: Any) -> discord.PartialEmoji | discord.Emoji | None:
        if value is None:
            return None
        if isinstance(value, (discord.PartialEmoji, discord.Emoji)):
            return value
        if isinstance(value, str):
            return discord.PartialEmoji.from_str(value)
        msg = f"Expected a value of type 'discord.PartialEmoji', 'discord.Emoji', or 'str'. Got value of type: {type(value)!r}"
        raise ValueError(msg)

    @pydantic.field_serializer("emoji")
    def _serialize_emoji(self, value: discord.PartialEmoji | discord.Emoji | None) -> str | None:  # noqa: PLR6301
        return str(value) if value else None

    def to_button(self) -> discord.ui.Button:
        """Create a button object from this button configuration.

        Returns:
            The created button object, ready to be attached to a row component.
        """
        return discord.ui.Button(label=self.label, emoji=self.emoji, url=str(self.url))


class ButtonOverrideBehavior(StrEnum):
    """Determines how guild and type buttons interact / override."""

    APPEND = "append"
    """Type buttons will be appended onto guild buttons, if present."""
    OVERRIDE = "override"
    """Type buttons will completely override and replace guild buttons, if present."""


class SentinelConfigSchema(BaseConfigSchema):
    """Sentinel's internal configuration.

    This is accessible within cogs utilizing Sentinel through [`self.sentinel_config`][tidegear.sentinel.cog.SentinelCog].
    """

    version: ClassVar[int] = 2
    _cog_name: ClassVar[str] = "TidegearSentinel"
    _identifier: ClassVar[int] = 294518358420750336

    default_reason: Annotated[GuildConfigOption[str], ConfigMeta(default="No reason provided.")]
    """The default reason to use for moderations when no reason is provided by the moderator."""
    show_moderator: Annotated[GuildConfigOption[bool], ConfigMeta(default=True)]
    """Whether or not to provide the name/ID of the moderator when sending a moderation case embed to a moderated user."""
    use_discord_permissions: Annotated[GuildConfigOption[bool], ConfigMeta(default=True)]
    """Whether or not Discord role permissions should be taken into account when determining if someone can moderate another user.

    When this is enabled, moderators must have the permissions required by the given moderation type to moderate a user.

    When this is disabled, these permission requirements are removed for the moderator.
    The bot must still have the required permissions.
    """
    respect_hierarchy: Annotated[GuildConfigOption[bool], ConfigMeta(default=True)]
    """Whether or not Discord role positions should be taken into account when determining if someone can moderate another user.

    When this is disabled, moderators can moderate anyone whose top role is beneath the bot's top role,
    assuming they pass the other required checks.
    """
    dm_users: Annotated[GuildConfigOption[bool], ConfigMeta(default=True)]
    """Whether or not to direct message users when they're moderated. Can be overridden by individual moderation invocations."""
    log_channel: Annotated[GuildConfigOption[int | None], ConfigMeta(default=None)]
    """The guild channel that should be used for logging moderations."""
    immune_roles: Annotated[GuildConfigOption[list[int]], ConfigMeta(default=[])]
    """A list of role IDs that should be immune from moderation actions in this guild."""
    auto_evidenceformat: Annotated[GuildConfigOption[bool], ConfigMeta(default=False)]
    """Whether or not to automatically send an ephemeral message
    to the moderator containing information about the moderation action.

    If the moderation command being used is not an Application Command,
    the message will be sent to the moderator's direct messages.
    """
    support_message: Annotated[GuildConfigOption[str | None], ConfigMeta(default=None)]
    """A custom message to include in the embed sent to users when they are moderated."""
    buttons: Annotated[GuildConfigOption[list[ButtonConfig]], ConfigMeta(default=[])]
    """Buttons to show underneath the embed that is sent to users when they are moderated."""

    # History - Guild
    history_inline: Annotated[GuildConfigOption[bool], ConfigMeta(default=True)]
    history_default_pagesize: Annotated[GuildConfigOption[Pagesize], ConfigMeta(default=5)]
    history_default_inline_pagesize: Annotated[GuildConfigOption[Pagesize], ConfigMeta(default=6)]

    # History - Member
    member_history_inline: Annotated[MemberConfigOption[bool | None], ConfigMeta(default=None)]
    member_history_default_pagesize: Annotated[MemberConfigOption[Pagesize | None], ConfigMeta(default=None)]
    member_history_default_inline_pagesize: Annotated[MemberConfigOption[Pagesize | None], ConfigMeta(default=None)]

    # Types
    type_default_reason: Annotated[CustomConfigOption[str | None], ConfigMeta(default=None), _ModerationTypeGroup]
    """A default reason to apply specifically for this moderation type.

    If set, this value overrides the global `default_reason` when a moderator does not provide one.
    """

    type_show_in_history: Annotated[
        CustomConfigOption[bool],
        ConfigMeta(default=True, help="Whether or not to show moderations of this type in history invocations by default."),
        _ModerationTypeGroup,
    ]
    """Whether or not to show moderations of this type in history invocations by default.

    Note that passing `True` to [`sentinel_history`][tidegear.sentinel.cog.SentinelCog.sentinel_history]'s
    `types` parameter will show moderations of any type, including those where this option is set to `False`.
    """

    type_show_moderator: Annotated[CustomConfigOption[bool | None], ConfigMeta(default=None), _ModerationTypeGroup]
    """Whether or not the moderator should be shown for this specific moderation type.

    If set, this value overrides the global `show_moderator` setting.
    """

    type_use_discord_permissions: Annotated[CustomConfigOption[bool | None], ConfigMeta(default=None), _ModerationTypeGroup]
    """Whether or not Discord role permissions should be considered for this moderation type.

    If set, this value overrides the global `use_discord_permissions` setting.
    """

    type_dm_users: Annotated[CustomConfigOption[bool | None], ConfigMeta(default=None), _ModerationTypeGroup]
    """Whether or not users should be directly messaged for this moderation type.

    If set, this value overrides the global `dm_users` setting.
    """

    type_support_message: Annotated[CustomConfigOption[str | None], ConfigMeta(default=None), _ModerationTypeGroup]
    """A custom message to include in moderation embeds for this specific moderation type.

    If set, this value overrides the global `support_message` setting.
    """

    type_buttons: Annotated[CustomConfigOption[list[ButtonConfig]], ConfigMeta(default=[]), _ModerationTypeGroup]
    """Buttons to show underneath the embed that is sent to users when they are moderated."""

    type_button_override_behavior: Annotated[
        CustomConfigOption[ButtonOverrideBehavior], ConfigMeta(default=ButtonOverrideBehavior.APPEND), _ModerationTypeGroup
    ]
    """The behavior to use when handling buttons for this moderation type.

    This option has no effect if buttons are not configured both for this guild and this moderation type.

    If this is set to `APPEND`, buttons configured for this moderation type will be shown after buttons configured for this guild.
    If this is set to `OVERRIDE`, only buttons configured for this moderation type will be shown.
    """

    @override
    @classmethod
    async def init(cls, *, logger: logging.RedTraceLogger | None = None) -> Self:  # pyright: ignore[reportIncompatibleMethodOverride]
        return await super().init(cls._cog_name, cls._identifier, logger=logger)

    @override
    async def run_migrations(self, version: int, group: red_config.Group) -> None:
        if version == 1:
            config_data = await group.all()

            if guild_data := config_data.get("GUILD"):
                for guild in guild_data.values():
                    guild: dict[str, Any]
                    button_label = guild.pop("button_label", None)
                    button_url = guild.pop("button_url", None)
                    if button_label and button_url:
                        guild["buttons"] = [ButtonConfig(label=button_label, url=HttpUrl(button_url)).model_dump(mode="json")]

            if types_data := config_data.get(_ModerationTypeGroup.name):
                for guild in types_data.values():
                    for moderation_type in guild.values():
                        moderation_type: dict[str, Any]
                        button_label = moderation_type.pop("type_button_label", None)
                        button_url = moderation_type.pop("type_button_url", None)
                        if button_label and button_url:
                            moderation_type["type_buttons"] = [
                                ButtonConfig(label=button_label, url=HttpUrl(button_url)).model_dump(mode="json")
                            ]

            config_data["GLOBAL"]["config_version"] = 2
            version = 2
            await group.set(config_data)

    async def get_buttons_for_type(
        self, guild: discord.Guild | int, moderation_type: "type[ModerationType] | ModerationType | str"
    ) -> list[discord.ui.Button]:
        """Get a list of buttons to add to messages sent to end users when they are moderated.

        Returns:
            A list of buttons.
        """
        if isinstance(guild, discord.Guild):
            guild = guild.id
        if not isinstance(moderation_type, str):
            moderation_type = moderation_type.key

        button_override_behavior = await self.type_button_override_behavior.get(
            guild_id=str(guild), moderation_type=moderation_type
        )
        buttons: list[discord.ui.Button] = []
        if button_override_behavior == ButtonOverrideBehavior.APPEND:
            buttons.extend([button_config.to_button() for button_config in await self.buttons.get(guild)])
        buttons.extend([
            button_config.to_button()
            for button_config in await self.type_buttons.get(guild_id=str(guild), moderation_type=moderation_type)
        ])
        return buttons

    async def get_member_config_with_fallback(
        self, config: GuildConfigOption[JsonableType], *, guild: discord.Guild | int, member: discord.Member | int
    ) -> JsonableType:
        """Return the configuration value for a specific member, falling back to the guild-level value when the member-specific option is None.

        Args:
            config: The [guild-scoped][tidegear.config.options.GuildConfigOption] configuration option you want to retrieve a value for.
                The [member-scoped][tidegear.config.options.MemberConfigOption] configuration option must be named `member_{config.key}`.
            guild: The guild you're looking up a configuration value for.
            member: The member you're looking up a configuration value for

        Raises:
            AttributeError: If the `member_{config.key}` attribute does not exist on the parent configuration schema.
            TypeError: If `member_{config.key}` does exist, but is either not a [`MemberConfigOption`][tidegear.config.options.MemberConfigOption],
                or does not have a matching annotation with `config`. A "matching annotation" is the generic annotation of `config`,
                with `| None` appended. Note that type aliases such as [`Optional[T]`][typing.Optional] or [`Union[T, None]`][typing.Union]
                will not be treated as equal here, because the comparison is structural rather than semantic.

        Returns:
            The retrieved value, typed accordingly to `config`'s generic type.
        """  # noqa: E501
        member_attr_name = f"member_{config.key}"
        member_config = getattr(self, member_attr_name, None)
        if not member_config:
            msg = f"This configuration schema does not have a configuration option named {member_attr_name!r}."
            raise AttributeError(msg)
        if not isinstance(member_config, MemberConfigOption):
            msg = f"The {member_attr_name!r} attribute exists on this configuration schema, but is not a MemberConfigOption."
            raise TypeError(msg)
        if member_config.__pydantic_fields__["default"].annotation != config.__pydantic_fields__["default"].annotation | None:  # pyright: ignore[reportOptionalOperand]
            msg = (
                f"The {member_attr_name!r} attribute exists on this configuration schema, "
                f"but does not have matching annotations with {config.key!r}."
            )
            raise TypeError(msg)

        member_value = await member_config.get(member, guild=guild)
        if member_value is not None:
            return member_value

        return await config.get(guild)

    async def get_type_config_with_fallback(
        self,
        config: GuildConfigOption[JsonableType],
        *,
        guild: discord.Guild | int,
        moderation_type: "type[ModerationType] | ModerationType | str",
    ) -> JsonableType:
        """Return the configuration value for a specific moderation type, falling back to the guild-level value when the type-specific option is None.

        Args:
            config: The [guild-scoped][tidegear.config.options.GuildConfigOption] configuration option you want to retrieve a value for.
                The [type-scoped][tidegear.config.CustomConfigOption] configuration option must be named `type_{config.key}`.
            guild: The guild you're looking up a configuration value for.
            moderation_type: The moderation type you're looking up a configuration value for.
                If this is a string, it must be the key of the moderation type.

        Raises:
            AttributeError: If the `type_{config.key}` attribute does not exist on the parent configuration schema.
            TypeError: If `type_{config.key}` does exist, but is either not a [`CustomConfigOption`][tidegear.config.CustomConfigOption],
                or does not have a matching annotation with `config`. A "matching annotation" is the generic annotation of `config`,
                with `| None` appended. Note that type aliases such as [`Optional[T]`][typing.Optional] or [`Union[T, None]`][typing.Union]
                will not be treated as equal here, because the comparison is structural rather than semantic.
            ValueError: If `type_{config.key}` does exist, but does not have the correct group.

        Returns:
            The retrieved value, typed accordingly to `config`'s generic type.
        """  # noqa: E501
        type_attr_name = f"type_{config.key}"
        type_config = getattr(self, type_attr_name, None)
        if not type_config:
            msg = f"This configuration schema does not have a configuration option named {type_attr_name!r}."
            raise AttributeError(msg)
        if not isinstance(type_config, CustomConfigOption):
            msg = f"The {type_attr_name!r} attribute exists on this configuration schema, but is not a CustomConfigOption."
            raise TypeError(msg)
        if type_config.group != _ModerationTypeGroup:
            msg = (
                f"The {type_attr_name!r} attribute exists on this configuration schema "
                "and is a CustomConfigOption, but is not part of the correct custom group."
            )
            raise ValueError(msg)
        if type_config.__pydantic_fields__["default"].annotation != config.__pydantic_fields__["default"].annotation | None:  # pyright: ignore[reportOptionalOperand]
            msg = (
                f"The {type_attr_name!r} attribute exists on this configuration schema, "
                f"but does not have matching annotations with {config.key!r}."
            )
            raise TypeError(msg)

        if isinstance(guild, discord.Guild):
            guild_id = str(guild.id)
        elif isinstance(guild, int):
            guild_id = str(guild)

        if not isinstance(moderation_type, str):
            moderation_type = moderation_type.key

        type_value = await type_config.get(guild_id=guild_id, moderation_type=moderation_type)
        if type_value is not None:
            return type_value

        return await config.get(guild)
