"""mcpx-go distribution package."""

__version__ = "0.1.14"
