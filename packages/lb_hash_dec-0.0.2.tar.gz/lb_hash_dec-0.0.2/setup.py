from setuptools import setup

setup(
	name='lb-hash-dec',
	version='0.0.2',
	py_modules=['lb_hash_dec'],
	description='lib made for lazy, by lazy',
	long_description=open('README.md').read(),
	long_description_content_type='text/markdown',
	author='logic-break',
	author_email="abibasqabiba@gmail.com", # ASCII only!
	url='https://github.com/logic-break/logic-break/tree/main/libraries/lb_hash_dec',
	license='MIT', 
	classifiers=[
		'Programming Language :: Python :: 3',
		'Operating System :: OS Independent',
	],
	python_requires='>=3.6',
)