"""Windows App Automation Module

A command-line tool for Windows desktop application automation.
Use via execute_script: python -m jarvis.jarvis_windows.cli <command>

Platform: Windows only.
"""
