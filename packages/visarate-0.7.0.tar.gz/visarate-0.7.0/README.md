# visarate

## Installation

```sh
pip install visarate
```


## Usage

See [example.py](./example.py).
