# hwp-to-md

Convert Korean HWP (Hangul Word Processor) files to Markdown format.

## Installation

```bash
pip install hwp-to-md
```

## Usage

### Command Line

```bash
# Convert single file
hwp-to-md convert document.hwp

# Convert with custom output path
hwp-to-md convert document.hwp -o output.md

# Convert all HWP files in directory
hwp-to-md convert ./documents/

# Check dependencies
hwp-to-md check

# Install dependencies
hwp-to-md install
```

### Python API

```python
from hwp_to_md import convert_hwp, batch_convert

# Single file
success, message = convert_hwp("document.hwp")

# Batch convert
results = batch_convert("./documents/")
for file_path, success, message in results:
    print(f"{file_path}: {'✓' if success else '✗'} {message}")
```

## Requirements

- Python 3.8+
- pyhwp (hwp5html)
- html2text

## How it works

1. **HWP → HTML**: Uses `hwp5html` from pyhwp to extract HTML
2. **HTML → Markdown**: Uses `html2text` to convert to Markdown

## License

MIT
