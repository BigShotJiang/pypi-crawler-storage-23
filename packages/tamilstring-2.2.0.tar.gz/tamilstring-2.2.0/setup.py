from setuptools import setup, find_packages
import subprocess
import re

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="tamilstring",
    version="2.2.0",
    author="boopalan",
    author_email="contact.boopalan@gmail.com",
    description="tamilstring helps to handle tamil unicode characters lot more easier",
    license="MIT",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/boopalan-dev/tamilstring",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.6",
)