"""Wrapper to start the Maintenance Page."""

from pyxecm_maintenance_page import run_maintenance_page

if __name__ == "__main__":
    run_maintenance_page()
