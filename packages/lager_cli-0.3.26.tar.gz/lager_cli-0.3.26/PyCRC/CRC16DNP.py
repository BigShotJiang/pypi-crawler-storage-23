# -*- coding: utf-8 -*-
"""Backward compatibility stub - moved to cli/vendor/PyCRC/CRC16DNP.py."""

from ..vendor.PyCRC.CRC16DNP import CRC16DNP

__all__ = ["CRC16DNP"]
