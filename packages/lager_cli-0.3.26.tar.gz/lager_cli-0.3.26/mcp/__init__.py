"""Lager MCP (Model Context Protocol) server for AI assistant integration."""
