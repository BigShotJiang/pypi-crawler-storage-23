"""Allow running the MCP server with: python -m cli.mcp"""
from .server import main

main()
