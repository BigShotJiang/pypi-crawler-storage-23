"""
status module - Status monitoring interfaces for lager-cli
"""