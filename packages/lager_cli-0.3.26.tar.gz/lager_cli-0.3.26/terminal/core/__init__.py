"""
Core module - command parsing and execution
"""
from .executor import execute_command

__all__ = ["execute_command"]
