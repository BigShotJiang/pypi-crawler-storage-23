core-dev-tools
===============================================================================

This library provides common tools used for development, allowing projects
to use them without needing to define them individually, providing a set of tools
across the code ecosystem...

===============================================================================

.. image:: https://img.shields.io/pypi/pyversions/core-dev-tools.svg
    :target: https://pypi.org/project/core-dev-tools/
    :alt: Python Versions

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-dev-tools/-/blob/main/LICENSE
    :alt: License

.. image:: https://gitlab.com/bytecode-solutions/core/core-dev-tools/badges/release/pipeline.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-dev-tools/-/pipelines
    :alt: Pipeline Status

.. image:: https://readthedocs.org/projects/core-dev-tools/badge/?version=latest
    :target: https://readthedocs.org/projects/core-dev-tools/
    :alt: Docs Status

.. image:: https://img.shields.io/badge/security-bandit-yellow.svg
    :target: https://github.com/PyCQA/bandit
    :alt: Security

|


Installation
===============================================================================

Install from PyPI using pip:

.. code-block:: bash

    pip install core-dev-tools
    uv pip install core-tests  # Or using UV...


Getting Started
===============================================================================

Once installed, all the tools will be available in your environment. Each
tool can be invoked directly from the command line.

For detailed documentation, visit: https://core-dev-tools.readthedocs.io/


Available Tools
===============================================================================

UV
-------------------------------------------------------------------------------
An extremely fast Python package and project manager, written in Rust.

More information: https://docs.astral.sh/uv/

.. code-block:: bash

    uv [OPTIONS] <COMMAND>


Ruff Linter
-------------------------------------------------------------------------------
The Ruff Linter is an extremely fast Python linter designed as 
a drop-in replacement for Flake8 (plus dozens of plugins), isort, 
pydocstyle, pyupgrade, autoflake, and more.

More information: https://docs.astral.sh/ruff/linter/

.. code-block:: bash

    ruff check                  # Lint files in the current directory.
    ruff check --fix            # Lint files in the current directory and fix any fixable errors.
    ruff check --watch          # Lint files in the current directory and re-lint on change.
    ruff check path/to/code/    # Lint files in `path/to/code`.


PyLint
-------------------------------------------------------------------------------
Pylint is a tool that checks for errors in Python code, tries to 
enforce a coding standard (stricter/static code analyzer (if you want more 
opinions than ruff)) and looks for bad code smells.

More information: https://docs.pylint.org/

.. code-block:: bash

    pylint <module_or_package>


Mypy
-------------------------------------------------------------------------------
Mypy is an optional static type checker for Python that aims to combine 
the benefits of dynamic (or "duck") typing and static typing.

More information:

* https://mypy-lang.org/
* https://mypy.readthedocs.io/en/stable/

.. code-block:: bash

    mypy .


Pyright
-------------------------------------------------------------------------------
Pyright is a full-featured, standards-compliant static type 
checker for Python. It is designed for high performance 
and can be used with large Python source bases.

More information: https://microsoft.github.io/pyright

.. code-block:: bash

    pyright


Bandit
-------------------------------------------------------------------------------
Bandit is a tool designed to find common security issues in Python 
code. To do this Bandit processes each file, builds an AST from 
it, and runs appropriate plugins against the AST nodes. Once Bandit 
has finished scanning all the files it generates a report.

More information: https://pypi.org/project/bandit/

.. code-block:: bash

    bandit -r <path>


click
-------------------------------------------------------------------------------
Click is a Python package for creating beautiful command line interfaces
in a composable way with as little code as necessary. It is highly
configurable and comes with sensible defaults out of the box.

More information: https://click.palletsprojects.com/

.. code-block:: python

    @click.command()
    @click.option("--name", prompt="Your name", help="The person to greet.")
    def hello(name):
        click.echo(f"Hello {name}!")


coverage
-------------------------------------------------------------------------------
coverage.py measures code coverage of Python programs. It monitors which
lines of your program are executed and which are not, making it easy to
identify untested code.

More information: https://coverage.readthedocs.io/

.. code-block:: bash

    coverage run -m pytest     # Run tests and measure coverage.
    coverage report            # Print coverage summary to terminal.
    coverage html              # Generate HTML coverage report.


environs
-------------------------------------------------------------------------------
environs is a Python library for parsing environment variables. It makes
it easy to define expected types, default values, and validation rules
for environment-based configuration, with support for ``.env`` files.

More information: https://github.com/sloria/environs

.. code-block:: python

    from environs import Env

    env = Env()
    env.read_env()              # Read .env file if it exists.
    DEBUG = env.bool("DEBUG")   # Parse and cast to bool.
    PORT = env.int("PORT", 5000)  # With a default value.


pip-audit
-------------------------------------------------------------------------------
It is a tool for scanning Python environments for packages with known
vulnerabilities. It uses the Python Packaging Advisory Database (https://github.com/pypa/advisory-database)
via the PyPI JSON API as a source of vulnerability reports.

More information: https://pypi.org/project/pip-audit/

.. code-block:: bash

    pip-audit


pre-commit
-------------------------------------------------------------------------------
pre-commit is a framework for managing and maintaining multi-language
pre-commit hooks. It integrates with git to automatically run checks
(linters, formatters, security scanners) before each commit.

More information: https://pre-commit.com/

.. code-block:: bash

    pre-commit install         # Install hooks into the git repository.
    pre-commit run --all-files # Run all hooks against all files.
    pre-commit autoupdate      # Update hook versions to latest.


pytest
-------------------------------------------------------------------------------
pytest is a mature, full-featured Python testing framework. It makes it
easy to write small, readable tests and scales to support complex functional
testing for applications and libraries.

More information: https://docs.pytest.org/

.. code-block:: bash

    pytest                     # Run all tests.
    pytest tests/test_foo.py   # Run a single test file.
    pytest -k "test_name"      # Run tests matching a keyword expression.
    pytest -v                  # Run with verbose output.


pytest-cov
-------------------------------------------------------------------------------
pytest-cov is a pytest plugin that measures code coverage during test runs.
It integrates with the ``coverage`` package and supports parallel test
execution via pytest-xdist.

More information: https://pytest-cov.readthedocs.io/

.. code-block:: bash

    pytest --cov=<source>                       # Run tests with coverage report.
    pytest --cov=<source> --cov-report=html     # Generate HTML coverage report.
    pytest --cov=<source> --cov-report=term     # Print coverage summary to terminal.


pytest-xdist
-------------------------------------------------------------------------------
pytest-xdist is a pytest plugin that extends pytest with distributed and
parallel test execution modes. It allows tests to run across multiple CPUs
or even remote machines.

More information: https://pytest-xdist.readthedocs.io/

.. code-block:: bash

    pytest -n auto          # Run tests in parallel using all available CPUs.
    pytest -n <num>         # Run tests in parallel using <num> workers.


Tox
-------------------------------------------------------------------------------
It aims to automate and standardize testing in Python. It is part of a 
larger vision of easing the packaging, testing and release process 
of Python software (alongside pytest and devpi).

More information:

* https://pypi.org/project/tox/
* https://tox.wiki

.. code-block:: bash

    tox


taskipy
-------------------------------------------------------------------------------
The complementary task runner for python.

More information: https://pypi.org/project/taskipy/

.. code-block:: bash

    task <task-name>


sphinx-copybutton
-------------------------------------------------------------------------------
sphinx-copybutton adds a small "copy" button to all code blocks in
Sphinx documentation, allowing readers to copy code snippets with a
single click.

More information: https://sphinx-copybutton.readthedocs.io/

No CLI usage — enabled by adding ``sphinx_copybutton`` to ``extensions``
in ``docs/conf.py``.


Sphinx
-------------------------------------------------------------------------------
Sphinx makes it easy to create intelligent and beautiful documentation.

More information: https://www.sphinx-doc.org/

.. code-block:: bash

    sphinx-quickstart docs
    cd docs
    make html


Build
-------------------------------------------------------------------------------
A simple, correct Python packaging build frontend. It manages
pyproject.toml-based builds, invoking build-backend hooks as appropriate
to build a distribution package. It is a simple build tool and
does not perform any dependency management.

More information: https://pypi.org/project/build/

.. code-block:: bash

    python -m build


Twine
-------------------------------------------------------------------------------
Twine is a utility for publishing Python packages to PyPI and other
repositories. It provides build system independent uploads of source and
binary distribution artifacts for both new and existing projects.

More information: https://twine.readthedocs.io/en/stable/

.. code-block:: bash

    twine check dist/*
    twine upload -u USER -p PASSWORD dist/*


ty
-------------------------------------------------------------------------------
ty is an extremely fast Python type checker and language server written
in Rust, developed by Astral (the creators of Ruff and uv). It is designed
to be a high-performance alternative to mypy and pyright.

More information: https://docs.astral.sh/ty/

.. code-block:: bash

    ty check            # Type-check the current project.
    ty check <path>     # Type-check a specific file or directory.


Contributing
===============================================================================

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass: ``pytest -n auto``
5. Run linting: ``pylint .``
6. Run security checks: ``bandit .``
7. Submit a pull request


License
===============================================================================

This project is licensed under the MIT License. See the LICENSE file for details.


Links
===============================================================================

* **Documentation:** https://core-dev-tools.readthedocs.io/en/latest/
* **Repository:** https://gitlab.com/bytecode-solutions/core/core-dev-tools
* **Issues:** https://gitlab.com/bytecode-solutions/core/core-dev-tools/-/issues
* **Changelog:** https://gitlab.com/bytecode-solutions/core/core-dev-tools/-/blob/master/CHANGELOG.md
* **PyPI:** https://pypi.org/project/core-dev-tools/


Support
===============================================================================

For questions or support, please open an issue on GitLab or contact the maintainers.


Authors
===============================================================================

* **Alejandro Cora González** - *Initial work* - alek.cora.glez@gmail.com
