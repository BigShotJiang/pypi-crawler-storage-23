.. :changelog:

Changelog
=========

2.0.0 (2026-02-18)
------------------

- Drop support for Python < 3.8
- Drop support for Django < 4.2.
- Add support for Django 4.2, 5.0, 5.1, 5.2, and 6.0.
- Add support for Python 3.10, 3.11, 3.12, 3.13, and 3.14.


1.3.0 (2018-09-04)
------------------

- Add support for Django 2.1. Remove support for Django < 1.11.


1.2.0 (2016-02-29)
------------------

- Add absolutize filter. This deprecates the absolutize tag. [#4]


1.1.0 (2015-03-23)
------------------

- Added ABSOLUTEURI_PROTOCOL settings. [#1]
- Documented sites framework requirement.


1.0.0 (2015-03-17)
------------------

- First release on PyPI.
