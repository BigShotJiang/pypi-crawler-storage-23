# How to contribute

I'm really glad you're reading this. You are probably much further into this, than I am.

_This is very much work in progress._

In the meantime, look at the [issue templates](.github/ISSUE_TEMPLATE/).

Thanks,
Marcin
