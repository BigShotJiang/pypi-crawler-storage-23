# Copyright (c) 2026 Marcin Zdun
# This code is licensed under MIT license (see LICENSE for details)
