"""
Mermaid diagram export for CxBlueprint flows.

Converts a Flow's block graph into a Mermaid flowchart string
that can be rendered in GitHub, VS Code, or any Mermaid-compatible viewer.
"""

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .blocks.base import FlowBlock

# --- Node shape mapping ---

# Terminal blocks: stadium shape (["label"])
_TERMINAL_TYPES = {
    "DisconnectParticipant",
    "EndFlowExecution",
    "TransferToFlow",
    "TransferContactToQueue",
    "TransferContactToAgent",
    "CompleteOutboundCall",
    "EndFlowModuleExecution",
    "DequeueContactAndTransferToQueue",
}

# Branching/decision blocks: diamond shape {"label"}
_BRANCHING_TYPES = {
    "GetParticipantInput",
    "CheckHoursOfOperation",
    "Compare",
    "DistributeByPercentage",
    "ConnectParticipantWithLexBot",
    "CheckOutboundCallStatus",
    "CheckMetricData",
    "CheckVoiceId",
    "Loop",
    "ShowView",
}

# Integration blocks: hexagon shape [["label"]]
_INTEGRATION_TYPES = {
    "InvokeLambdaFunction",
    "CreateCallbackContact",
    "InvokeFlowModule",
    "CreateTask",
    "CreateWisdomSession",
}

# --- Human-readable type names ---

_TYPE_DISPLAY = {
    "MessageParticipant": "Play Prompt",
    "MessageParticipantIteratively": "Play Prompt (Loop)",
    "GetParticipantInput": "Get Input",
    "DisconnectParticipant": "Disconnect",
    "EndFlowExecution": "End Flow",
    "TransferToFlow": "Transfer Flow",
    "TransferContactToQueue": "Transfer Queue",
    "TransferContactToAgent": "Transfer Agent",
    "ConnectParticipantWithLexBot": "Lex Bot",
    "InvokeLambdaFunction": "Lambda",
    "CheckHoursOfOperation": "Check Hours",
    "Compare": "Compare",
    "DistributeByPercentage": "A/B Split",
    "UpdateContactAttributes": "Set Attributes",
    "UpdateContactRecordingBehavior": "Recording",
    "UpdateContactTargetQueue": "Set Queue",
    "Wait": "Wait",
    "ShowView": "Show View",
    "Loop": "Loop",
    "CreateCallbackContact": "Create Callback",
    "CreateTask": "Create Task",
    "TagContact": "Tag Contact",
    "UnTagContact": "Untag Contact",
    "InvokeFlowModule": "Flow Module",
    "EndFlowModuleExecution": "End Module",
    "CompleteOutboundCall": "Complete Call",
    "DequeueContactAndTransferToQueue": "Dequeue Transfer",
    "UpdateContactCallbackNumber": "Set Callback #",
    "StartVoiceIdStream": "Voice ID",
}

# --- Short error names ---

_ERROR_DISPLAY = {
    "InputTimeLimitExceeded": "Timeout",
    "NoMatchingCondition": "No Match",
    "NoMatchingError": "Error",
    "InvalidPhoneNumber": "Invalid Phone",
    "TimeLimitExceeded": "Timeout",
    "ConnectionTimeLimitExceeded": "Timeout",
    "QueueAtCapacity": "Queue Full",
}


# --- Public API ---


def flow_to_mermaid(
    blocks: list["FlowBlock"],
    start_action: str | None,
    flow_name: str = "",
) -> str:
    """Convert a list of flow blocks into a Mermaid flowchart string.

    Args:
        blocks: List of FlowBlock instances.
        start_action: UUID of the entry block.
        flow_name: Optional flow name for the diagram title.

    Returns:
        Mermaid flowchart string (flowchart TB direction).
    """
    if not blocks or not start_action:
        return "flowchart TB\n    empty[No blocks]"

    id_map = _build_id_map(blocks)
    lines: list[str] = []

    # Header
    lines.append("flowchart TB")
    if flow_name:
        lines.append(f"    %% Flow: {flow_name}")

    # Start marker
    start_mid = id_map.get(start_action, "unknown")
    lines.append(f"    _start(( )) --> {start_mid}")

    # Node declarations
    for block in blocks:
        mid = id_map[block.identifier]
        label = _block_label(block)
        shape = _shape_for(block.type)
        lines.append(_format_node(mid, label, shape))

    # Edge declarations
    lines.append("")
    for block in blocks:
        src = id_map[block.identifier]
        trans = block.transitions
        has_conditions = bool(trans.get("Conditions"))

        # NextAction edge
        next_action = trans.get("NextAction")
        if next_action and next_action in id_map:
            dst = id_map[next_action]
            if has_conditions:
                lines.append(f'    {src} -->|"Default"| {dst}')
            else:
                lines.append(f"    {src} --> {dst}")

        # Condition edges
        for cond in trans.get("Conditions", []):
            next_id = cond.get("NextAction")
            if next_id and next_id in id_map:
                dst = id_map[next_id]
                label = _edge_label_for_condition(block.type, cond)
                safe = _escape_mermaid(label)
                lines.append(f'    {src} -->|"{safe}"| {dst}')

        # Error edges (dotted)
        for err in trans.get("Errors", []):
            next_id = err.get("NextAction")
            if next_id and next_id in id_map:
                dst = id_map[next_id]
                label = _error_label(err.get("ErrorType", "Error"))
                safe = _escape_mermaid(label)
                lines.append(f'    {src} -.->|"{safe}"| {dst}')

    # CSS class styling
    lines.append("")
    lines.append("    classDef terminal fill:#f96,stroke:#333,stroke-width:2px;")
    lines.append("    classDef branching fill:#bbf,stroke:#333,stroke-width:2px;")
    lines.append("    classDef integration fill:#bfb,stroke:#333,stroke-width:2px;")

    terminal_ids = [id_map[b.identifier] for b in blocks if b.type in _TERMINAL_TYPES]
    branching_ids = [id_map[b.identifier] for b in blocks if b.type in _BRANCHING_TYPES]
    integration_ids = [
        id_map[b.identifier] for b in blocks if b.type in _INTEGRATION_TYPES
    ]

    if terminal_ids:
        lines.append(f"    class {','.join(terminal_ids)} terminal;")
    if branching_ids:
        lines.append(f"    class {','.join(branching_ids)} branching;")
    if integration_ids:
        lines.append(f"    class {','.join(integration_ids)} integration;")

    return "\n".join(lines)


# --- Internal helpers ---


def _build_id_map(blocks: list["FlowBlock"]) -> dict[str, str]:
    """Map block UUIDs to Mermaid-safe node IDs."""
    id_map: dict[str, str] = {}
    used: set = set()
    for block in blocks:
        short = "n_" + block.identifier.replace("-", "")[:8]
        while short in used:
            short += "x"
        used.add(short)
        id_map[block.identifier] = short
    return id_map


def _shape_for(block_type: str) -> str:
    """Return the Mermaid shape name for a block type."""
    if block_type in _TERMINAL_TYPES:
        return "stadium"
    if block_type in _BRANCHING_TYPES:
        return "diamond"
    if block_type in _INTEGRATION_TYPES:
        return "hexagon"
    return "rect"


def _format_node(node_id: str, label: str, shape: str) -> str:
    """Format a Mermaid node declaration with the given shape."""
    safe = _escape_mermaid(label).replace("\n", "<br/>")
    if shape == "stadium":
        return f'    {node_id}(["{safe}"])'
    if shape == "diamond":
        return f'    {node_id}{{"{safe}"}}'
    if shape == "hexagon":
        return f'    {node_id}[["{safe}"]]'
    # Default: rounded rectangle
    return f'    {node_id}["{safe}"]'


def _block_label(block: "FlowBlock") -> str:
    """Build a human-readable label for a block node."""
    type_name = _TYPE_DISPLAY.get(block.type, _split_camel(block.type))
    detail = _extract_detail(block)
    if detail:
        return f"{type_name}\n{detail}"
    return type_name


def _extract_detail(block: "FlowBlock") -> str:
    """Extract the most informative parameter for the node label."""
    params = block.parameters

    # Text-based blocks
    text = params.get("Text", "")
    if text:
        return f"'{_truncate(text, 35)}'"

    # Lambda ARN — show just the function name
    arn = params.get("LambdaFunctionARN", "") or params.get("LambdaFunctionArn", "")
    if arn:
        func_name = arn.split(":")[-1] if ":" in arn else arn
        return f"[{_truncate(func_name, 30)}]"

    # Compare — show the comparison value
    comp_val = params.get("ComparisonValue", "")
    if comp_val:
        return _truncate(comp_val, 30)

    # Wait — show seconds
    time_limit = params.get("TimeLimitSeconds", "")
    if time_limit:
        return f"{time_limit}s"

    # Transfer to flow — show flow ID
    flow_id = params.get("ContactFlowId", "")
    if flow_id:
        return f"[{_truncate(flow_id, 25)}]"

    # Loop count
    loop_count = params.get("LoopCount", "")
    if loop_count:
        return f"x{loop_count}"

    return ""


def _edge_label_for_condition(block_type: str, condition: dict) -> str:
    """Build a human-readable label for a condition edge."""
    operands = condition.get("Condition", {}).get("Operands", [])
    value = operands[0] if operands else "?"

    if block_type == "CheckHoursOfOperation":
        return "In Hours" if value == "True" else "After Hours"
    if block_type == "Loop":
        return "Looping" if value == "ContinueLooping" else "Done"

    return value


def _error_label(error_type: str) -> str:
    """Return a short display name for an error type."""
    return _ERROR_DISPLAY.get(error_type, _truncate(error_type, 20))


def _truncate(text: str, max_len: int) -> str:
    """Truncate text with ellipsis if it exceeds max_len."""
    if len(text) > max_len:
        return text[: max_len - 3] + "..."
    return text


def _split_camel(name: str) -> str:
    """Convert CamelCase to 'Camel Case'."""
    return re.sub(r"(?<=[a-z])(?=[A-Z])", " ", name)


def _escape_mermaid(text: str) -> str:
    """Escape characters that have special meaning in Mermaid labels."""
    return (
        text.replace('"', "'")
        .replace("#", "&#35;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
