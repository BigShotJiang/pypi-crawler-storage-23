"""
InvokeFlowModule - Invoke a reusable flow module.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-invokeflowmodule.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class InvokeFlowModule(FlowBlock):
    """
    Invoke a reusable flow module.

    Results:
        None.

    Errors:
        - NoMatchingError - if no other Error matches

    Restrictions:
        - Can be used in any flow type
        - Module must be published before it can be invoked
    """

    flow_module_id: Optional[str] = None

    def __post_init__(self):
        self.type = "InvokeFlowModule"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.flow_module_id is not None:
            params["FlowModuleId"] = self.flow_module_id
        self.parameters = params

    def __repr__(self) -> str:
        if self.flow_module_id:
            return f"InvokeFlowModule(flow_module_id='{self.flow_module_id}')"
        return "InvokeFlowModule()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "InvokeFlowModule":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            flow_module_id=params.get("FlowModuleId"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
