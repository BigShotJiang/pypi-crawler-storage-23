"""
UpdateRoutingCriteria - Set routing criteria for queue-based routing.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-updateroutingcriteria.html
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
import uuid
from ..base import FlowBlock


@dataclass
class UpdateRoutingCriteria(FlowBlock):
    """
    Set routing criteria steps for the contact. Criteria remain inactive until
    Transfer to queue block is executed.

    Parameters:
        - RoutingCriteria: Object containing Steps list
          - Steps: List of routing steps, each with:
            - Expression: AttributeCondition with Name, Value, ProficiencyLevel, ComparisonOperator
            - Expiry: DurationInSeconds before moving to next step

    Results:
        - No conditions supported

    Errors:
        - NoMatchingError - No other error matches

    Restrictions:
        - Use with Transfer to queue block to activate criteria
        - Up to 8 attributes per AND condition
        - Up to 3 OR conditions per step
        - Does not work with agent queue transfers
    """

    routing_criteria: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        self.type = "UpdateRoutingCriteria"
        self._build_parameters()

    def _build_parameters(self):
        if self.routing_criteria:
            self.parameters = {
                "RoutingCriteria": self.routing_criteria
            }

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    def __repr__(self) -> str:
        if self.routing_criteria and "Steps" in self.routing_criteria:
            return f"UpdateRoutingCriteria(steps={len(self.routing_criteria['Steps'])})"
        return "UpdateRoutingCriteria()"

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateRoutingCriteria":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            routing_criteria=params.get("RoutingCriteria"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
