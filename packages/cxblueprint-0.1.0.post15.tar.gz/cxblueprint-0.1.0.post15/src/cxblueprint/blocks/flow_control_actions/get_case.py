"""
GetCase - Get case details from Amazon Connect Cases.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-getcase.html
"""

from dataclasses import dataclass
from typing import Optional, Dict, List
import uuid
from ..base import FlowBlock
from ..serialization import to_aws_bool


@dataclass
class GetCase(FlowBlock):
    """
    Get case details from Amazon Connect Cases.

    Results:
        None.

    Errors:
        - NoMatchingError - Error finding the case
        - ContactNotLinked - Contact not linked after retrieval
        - MultipleFound - Multiple cases match search criteria
        - NoneFound - No cases match search criteria

    Restrictions:
        None (all channels, all flow types)
    """

    link_contact_to_case: bool = False
    get_last_updated_case: bool = False
    customer_id: Optional[str] = None
    case_request_fields: Optional[Dict[str, str]] = None
    case_response_fields: Optional[List[str]] = None

    def __post_init__(self):
        self.type = "GetCase"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        params["LinkContactToCase"] = to_aws_bool(self.link_contact_to_case)
        params["GetLastUpdatedCase"] = to_aws_bool(self.get_last_updated_case)
        if self.customer_id is not None:
            params["CustomerId"] = self.customer_id
        if self.case_request_fields is not None:
            params["CaseRequestFields"] = self.case_request_fields
        if self.case_response_fields is not None:
            params["CaseResponseFields"] = self.case_response_fields
        self.parameters = params

    def __repr__(self) -> str:
        return f"GetCase(customer_id='{self.customer_id}')"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "GetCase":
        params = data.get("Parameters", {})
        link = params.get("LinkContactToCase", "False")
        last_updated = params.get("GetLastUpdatedCase", "False")
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            link_contact_to_case=(link == "True"),
            get_last_updated_case=(last_updated == "True"),
            customer_id=params.get("CustomerId"),
            case_request_fields=params.get("CaseRequestFields"),
            case_response_fields=params.get("CaseResponseFields"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
