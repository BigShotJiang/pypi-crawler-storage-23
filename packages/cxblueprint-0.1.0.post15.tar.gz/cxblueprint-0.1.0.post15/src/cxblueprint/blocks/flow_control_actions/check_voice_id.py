"""
CheckVoiceId - Check Voice ID authentication result.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-checkvoiceid.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class CheckVoiceId(FlowBlock):
    """
    Check the enrollment status, voice authentication, or fraud detection results from Voice ID.

    Results:
        For enrollmentStatus:
            - Enrolled - Caller is enrolled
            - Not enrolled - Caller is not enrolled
            - Opted out - Caller opted out

        For voiceAuthentication:
            - Authenticated - Authentication score >= threshold
            - Not authenticated - Authentication score < threshold
            - Inconclusive - Unable to analyze
            - Not enrolled - Caller not enrolled
            - Opted out - Caller opted out

        For fraudDetection:
            - High risk - Risk score >= threshold
            - Low risk - Risk score < threshold
            - Inconclusive - Unable to analyze

    Errors:
        - NoMatchingError - No condition matches

    Restrictions:
        - Voice channel only
        - Not supported on Chat or Task channels
    """

    check_voice_id_option: Optional[str] = None  # enrollmentStatus, voiceAuthentication, fraudDetection

    def __post_init__(self):
        self.type = "CheckVoiceId"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.check_voice_id_option is not None:
            params["CheckVoiceIdOption"] = self.check_voice_id_option
        self.parameters = params

    def __repr__(self) -> str:
        return f"CheckVoiceId(check_voice_id_option='{self.check_voice_id_option}')"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "CheckVoiceId":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            check_voice_id_option=params.get("CheckVoiceIdOption"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
