"""
StartVoiceIdStream - Start Voice ID audio streaming for authentication.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-startvoiceidstream.html

NOTE: AWS will end support for Amazon Connect Voice ID on May 20, 2026.
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class StartVoiceIdStream(FlowBlock):
    """
    Start streaming audio to Voice ID for authentication and fraud detection.

    Parameters:
        - VoiceIdDomainId: The Voice ID domain ID
        - AuthenticationThreshold (Optional): Threshold for authentication (default 90)
        - AuthenticationResponseTime (Optional): Response time in seconds (5-10)
        - FraudThreshold (Optional): Threshold for fraud detection (default 50)
        - FraudWatchlistId (Optional): Watchlist ID for known fraudsters

    Results:
        - No conditions supported, routes to next action

    Errors:
        - NoMatchingError - No other error matches

    Restrictions:
        - Voice channel only
        - Requires Voice ID enabled on instance
        - CustomerSpeakerId must be set via contact attributes before use
    """

    def __post_init__(self):
        self.type = "StartVoiceIdStream"

    def __repr__(self) -> str:
        return "StartVoiceIdStream()"

    @classmethod
    def from_dict(cls, data: dict) -> "StartVoiceIdStream":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
