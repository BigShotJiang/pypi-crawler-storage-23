"""
GetMetricData - Retrieve queue metrics data and store in attributes.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-getmetricdata.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class GetMetricData(FlowBlock):
    """
    Retrieve queue metrics and store them as contact attributes for routing decisions.
    Returns near real-time queue metrics with a 5-10 second delay.

    Parameters:
        - QueueId (Optional): Queue ID or ARN. If AgentId specified, this may not be used.
        - AgentId (Optional): Agent ID or ARN for agent queue metrics.
        - MetricType: NumberOfAgentsAvailable, NumberOfAgentsStaffed, NumberOfAgentsOnline,
                      OldestContactInQueueAgeSeconds, NumberOfContactsInQueue
        - Channel (Optional): Filter by channel (VOICE, CHAT, TASK)

    Results:
        - Metrics returned as attributes accessible via $.Metrics path

    Errors:
        - NoMatchingError - No other error matches

    Restrictions:
        - Only usable in flows, queue and agent transfers, and customer queue flows
        - Not available in whisper or hold flows
    """

    def __post_init__(self):
        self.type = "GetMetricData"

    def __repr__(self) -> str:
        return "GetMetricData()"

    @classmethod
    def from_dict(cls, data: dict) -> "GetMetricData":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
