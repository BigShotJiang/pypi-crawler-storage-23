"""
UpdateFlowLoggingBehavior - Configure flow logging.
https://docs.aws.amazon.com/connect/latest/APIReference/flow-control-actions-updateflowloggingbehavior.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class UpdateFlowLoggingBehavior(FlowBlock):
    """
    Enable or disable flow logging behavior.

    Results:
        None.

    Errors:
        None.

    Restrictions:
        - Available in all flow types
        - Dynamic values not supported
    """

    flow_logging_behavior: Optional[str] = None  # "Enabled" or "Disabled"

    def __post_init__(self):
        self.type = "UpdateFlowLoggingBehavior"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.flow_logging_behavior is not None:
            params["FlowLoggingBehavior"] = self.flow_logging_behavior
        self.parameters = params

    def __repr__(self) -> str:
        return f"UpdateFlowLoggingBehavior(flow_logging_behavior='{self.flow_logging_behavior}')"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateFlowLoggingBehavior":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            flow_logging_behavior=params.get("FlowLoggingBehavior"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
