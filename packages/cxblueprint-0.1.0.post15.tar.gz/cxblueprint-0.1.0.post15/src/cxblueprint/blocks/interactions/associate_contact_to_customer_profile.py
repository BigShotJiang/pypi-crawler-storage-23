"""
AssociateContactToCustomerProfile - Associate a contact to a customer profile.
https://docs.aws.amazon.com/connect/latest/APIReference/interactions-associatecontacttocustomerprofile.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class AssociateContactToCustomerProfile(FlowBlock):
    """
    Associate a contact to a customer profile.
    Customer Profiles must be enabled for your Amazon Connect instance.

    Results:
        - No conditions supported

    Errors:
        - NoMatchingError - if no other error matches

    Restrictions:
        - Customer Profiles must be enabled for your Amazon Connect instance
        - Both ProfileId and ContactId must be present in parameters
    """

    def __post_init__(self):
        self.type = "AssociateContactToCustomerProfile"

    def __repr__(self) -> str:
        return "AssociateContactToCustomerProfile()"

    @classmethod
    def from_dict(cls, data: dict) -> "AssociateContactToCustomerProfile":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
