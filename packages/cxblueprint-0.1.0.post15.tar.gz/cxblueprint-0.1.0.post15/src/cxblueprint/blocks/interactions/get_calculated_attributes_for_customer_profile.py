"""
GetCalculatedAttributesForCustomerProfile - Retrieve computed profile attributes.
https://docs.aws.amazon.com/connect/latest/APIReference/interactions-getcalculatedattributesforcustomerprofile.html
"""

from dataclasses import dataclass
from typing import Optional, List
import uuid
from ..base import FlowBlock


@dataclass
class GetCalculatedAttributesForCustomerProfile(FlowBlock):
    """
    Retrieve calculated attributes for a customer profile. Calculated attributes
    are computed values based on profile object data.

    Parameters:
        - ProfileId: The profile ID (required, use Get profile block first)
        - CalculatedAttributeNames: List of calculated attribute names to retrieve

    Results:
        - Calculated attribute values available under $.Customer path

    Errors:
        - NoneFoundError - No profiles found for the search key
        - NoMatchingError - No other error matches

    Restrictions:
        - Customer Profiles must be enabled
        - Calculated attributes must be defined in your domain
        - ProfileId must be provided (use GetCustomerProfile first)
    """

    profile_id: Optional[str] = None
    calculated_attribute_names: Optional[List[str]] = None

    def __post_init__(self):
        self.type = "GetCalculatedAttributesForCustomerProfile"
        self._build_parameters()

    def _build_parameters(self):
        params = {}
        if self.profile_id:
            params["ProfileId"] = self.profile_id
        if self.calculated_attribute_names:
            params["CalculatedAttributeNames"] = self.calculated_attribute_names
        if params:
            self.parameters = params

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    def __repr__(self) -> str:
        if self.calculated_attribute_names:
            return f"GetCalculatedAttributesForCustomerProfile(attrs={self.calculated_attribute_names})"
        return "GetCalculatedAttributesForCustomerProfile()"

    @classmethod
    def from_dict(cls, data: dict) -> "GetCalculatedAttributesForCustomerProfile":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            profile_id=params.get("ProfileId"),
            calculated_attribute_names=params.get("CalculatedAttributeNames"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
