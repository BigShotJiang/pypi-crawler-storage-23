"""
CreateCustomerProfile - Create a customer profile.
https://docs.aws.amazon.com/connect/latest/APIReference/interactions-createcustomerprofile.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class CreateCustomerProfile(FlowBlock):
    """
    Create a customer profile. Customer Profiles must be enabled for your Amazon Connect instance.

    Results:
        - No conditions supported
        - If no error occurs, response attributes are available dynamically under $.Customer path
        - Newly created profile ID is persisted under $.Customer.ProfileId

    Errors:
        - NoMatchingError - if no other error matches

    Restrictions:
        - Customer Profiles must be enabled for your Amazon Connect instance
    """

    def __post_init__(self):
        self.type = "CreateCustomerProfile"

    def __repr__(self) -> str:
        return "CreateCustomerProfile()"

    @classmethod
    def from_dict(cls, data: dict) -> "CreateCustomerProfile":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
