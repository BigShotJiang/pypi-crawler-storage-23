"""
UpdateContactTextToSpeechVoice - Set TTS voice for contact.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-updatecontacttexttospeechvoice.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class UpdateContactTextToSpeechVoice(FlowBlock):
    """
    Update the Amazon Polly voice used for text-to-speech.

    Errors:
        - NoMatchingError - Default error handler (also for invalid voice/engine)

    Restrictions:
        - Supported on all channels and all flow types
        - Defaults to "Joanna" if never set
    """

    text_to_speech_voice: Optional[str] = None
    text_to_speech_engine: Optional[str] = None
    text_to_speech_style: Optional[str] = None

    def __post_init__(self):
        self.type = "UpdateContactTextToSpeechVoice"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.text_to_speech_voice is not None:
            params["TextToSpeechVoice"] = self.text_to_speech_voice
        if self.text_to_speech_engine is not None:
            params["TextToSpeechEngine"] = self.text_to_speech_engine
        if self.text_to_speech_style is not None:
            params["TextToSpeechStyle"] = self.text_to_speech_style
        self.parameters = params

    def __repr__(self) -> str:
        if self.text_to_speech_voice:
            parts = [f"voice='{self.text_to_speech_voice}'"]
            if self.text_to_speech_engine:
                parts.append(f"engine='{self.text_to_speech_engine}'")
            return f"UpdateContactTextToSpeechVoice({', '.join(parts)})"
        return "UpdateContactTextToSpeechVoice()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateContactTextToSpeechVoice":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            text_to_speech_voice=params.get("TextToSpeechVoice"),
            text_to_speech_engine=params.get("TextToSpeechEngine"),
            text_to_speech_style=params.get("TextToSpeechStyle"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
