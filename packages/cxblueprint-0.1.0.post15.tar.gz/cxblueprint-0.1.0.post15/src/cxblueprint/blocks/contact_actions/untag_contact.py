"""
UnTagContact - Remove user-defined tags from a contact.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-untagcontact.html
"""

from dataclasses import dataclass
from typing import List, Optional
import uuid
from ..base import FlowBlock


@dataclass
class UnTagContact(FlowBlock):
    """
    Remove user-defined tags from a contact.

    Results:
        None.

    Errors:
        - NoMatchingError - if no other Error matches

    Restrictions:
        None. Can be used in any flow type and any channel.
    """

    tag_keys: Optional[List[str]] = None

    def __post_init__(self):
        self.type = "UnTagContact"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.tag_keys is not None:
            params["TagKeys"] = self.tag_keys
        self.parameters = params

    def __repr__(self) -> str:
        if self.tag_keys:
            return f"UnTagContact(tag_keys={self.tag_keys})"
        return "UnTagContact()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "UnTagContact":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            tag_keys=params.get("TagKeys"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
