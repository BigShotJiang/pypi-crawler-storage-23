"""
UpdatePreviousContactParticipantState - Update previous participant state.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-updatepreviouscontactparticipantstate.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class UpdatePreviousContactParticipantState(FlowBlock):
    """
    Control the state of the previous participant during contact transfer.

    Errors:
        - NoMatchingError - Default error handler

    Restrictions:
        - Inbound contact flows and transfer flows only
        - Voice contacts only
        - Commonly used to disconnect initiating agent or place agent on hold during secure transfers
    """

    previous_contact_participant_state: Optional[str] = None

    def __post_init__(self):
        self.type = "UpdatePreviousContactParticipantState"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.previous_contact_participant_state is not None:
            params["PreviousContactParticipantState"] = self.previous_contact_participant_state
        self.parameters = params

    def __repr__(self) -> str:
        if self.previous_contact_participant_state:
            return f"UpdatePreviousContactParticipantState(state='{self.previous_contact_participant_state}')"
        return "UpdatePreviousContactParticipantState()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "UpdatePreviousContactParticipantState":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            previous_contact_participant_state=params.get("PreviousContactParticipantState"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
