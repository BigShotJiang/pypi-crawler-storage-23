"""
UpdateContactMediaProcessing - Configure custom Lambda processing for chat messages.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-updatecontactmediaprocessing.html
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
import uuid
from ..base import FlowBlock


@dataclass
class UpdateContactMediaProcessing(FlowBlock):
    """
    Configure bring-your-own-processor Lambda for chat channel message processing.

    Parameters:
        - ChatProcessor: Object containing:
          - ProcessingEnabled: "True" or "False" (static only)
          - LambdaProcessorARN: Lambda function ARN (static only)
          - ChatProcessorSettings:
            - DeliverUnprocessedMessages: "True" or "False" (static only)

    Results:
        - No conditions supported

    Errors:
        - ChannelMismatch - Media channel doesn't match defined action
        - NoMatchingError - No other error matches

    Restrictions:
        - Chat channel only
        - All parameters must be set statically
    """

    chat_processor: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        self.type = "UpdateContactMediaProcessing"
        self._build_parameters()

    def _build_parameters(self):
        if self.chat_processor:
            self.parameters = {
                "ChatProcessor": self.chat_processor
            }

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    def __repr__(self) -> str:
        if self.chat_processor and self.chat_processor.get("ProcessingEnabled") == "True":
            return "UpdateContactMediaProcessing(enabled=True)"
        return "UpdateContactMediaProcessing()"

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateContactMediaProcessing":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            chat_processor=params.get("ChatProcessor"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
