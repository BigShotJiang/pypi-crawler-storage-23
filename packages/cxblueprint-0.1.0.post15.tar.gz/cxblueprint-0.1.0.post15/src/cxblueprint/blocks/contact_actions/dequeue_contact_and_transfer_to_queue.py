"""
DequeueContactAndTransferToQueue - Dequeue and transfer to another queue.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-dequeuecontactandtransfertoqueue.html
"""

from dataclasses import dataclass
from typing import Optional
import uuid
from ..base import FlowBlock


@dataclass
class DequeueContactAndTransferToQueue(FlowBlock):
    """
    Dequeue contact and transfer to another queue (queue-to-queue transfer).

    Results:
        None.

    Errors:
        - QueueAtCapacity - Thrown if the destination queue is at capacity
        - NoMatchingError - Thrown if no other error matches

    Restrictions:
        - This action is only supported in the customer queue flow
        - Not supported in any other type of flow
    """

    queue_id: Optional[str] = None
    agent_id: Optional[str] = None

    def __post_init__(self):
        self.type = "DequeueContactAndTransferToQueue"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.queue_id is not None:
            params["QueueId"] = self.queue_id
        if self.agent_id is not None:
            params["AgentId"] = self.agent_id
        if params:
            self.parameters.update(params)

    def __repr__(self) -> str:
        if self.queue_id:
            return f"DequeueContactAndTransferToQueue(queue_id='{self.queue_id}')"
        if self.agent_id:
            return f"DequeueContactAndTransferToQueue(agent_id='{self.agent_id}')"
        return "DequeueContactAndTransferToQueue()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "DequeueContactAndTransferToQueue":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            queue_id=params.get("QueueId"),
            agent_id=params.get("AgentId"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
