"""
TransferContactToAgent - Transfer contact to a specific agent.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-transfercontacttoagent.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class TransferContactToAgent(FlowBlock):
    """
    Transfer contact to a specific agent.

    Results:
        None.

    Errors:
        - NoMatchingError - if no other Error matches

    Restrictions:
        - Only supported in Agent Whisper flow and Customer Queue flow
    """

    def __post_init__(self):
        self.type = "TransferContactToAgent"

    def __repr__(self) -> str:
        return "TransferContactToAgent()"

    @classmethod
    def from_dict(cls, data: dict) -> "TransferContactToAgent":
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=data.get("Parameters", {}),
            transitions=data.get("Transitions", {}),
        )
