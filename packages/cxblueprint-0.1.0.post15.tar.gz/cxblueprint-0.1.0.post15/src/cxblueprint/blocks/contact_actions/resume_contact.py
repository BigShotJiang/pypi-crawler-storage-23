"""
ResumeContact - Resume a paused contact.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-resumecontact.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class ResumeContact(FlowBlock):
    """
    Resume a contact from a paused state.

    Results:
        None.

    Errors:
        - NoMatchingError - if no other Error matches

    Restrictions:
        None. This action can be used in any type of flow and any channel.
    """

    def __post_init__(self):
        self.type = "ResumeContact"

    def __repr__(self) -> str:
        return "ResumeContact()"

    @classmethod
    def from_dict(cls, data: dict) -> "ResumeContact":
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=data.get("Parameters", {}),
            transitions=data.get("Transitions", {}),
        )
