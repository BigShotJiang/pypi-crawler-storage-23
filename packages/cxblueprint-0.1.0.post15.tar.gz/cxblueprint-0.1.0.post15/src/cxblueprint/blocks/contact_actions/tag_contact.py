"""
TagContact - Add user-defined tags to a contact.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-tagcontact.html
"""

from dataclasses import dataclass, field
from typing import Dict, Optional
import uuid
from ..base import FlowBlock


@dataclass
class TagContact(FlowBlock):
    """
    Add user-defined tags to a contact.

    Results:
        None.

    Errors:
        - NoMatchingError - if no other Error matches

    Restrictions:
        None. Can be used in any flow type and any channel.
    """

    tags: Optional[Dict[str, str]] = None

    def __post_init__(self):
        self.type = "TagContact"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.tags is not None:
            params["Tags"] = self.tags
        self.parameters = params

    def __repr__(self) -> str:
        if self.tags:
            return f"TagContact(tags={self.tags})"
        return "TagContact()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "TagContact":
        params = data.get("Parameters", {})
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            tags=params.get("Tags"),
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
