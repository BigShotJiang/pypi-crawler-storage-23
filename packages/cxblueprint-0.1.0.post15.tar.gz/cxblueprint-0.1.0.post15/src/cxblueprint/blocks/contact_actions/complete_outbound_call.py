"""
CompleteOutboundCall - Complete an outbound call.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-completeoutboundcall.html
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
import uuid
from ..base import FlowBlock


@dataclass
class CompleteOutboundCall(FlowBlock):
    """
    Complete an outbound call.

    Results:
        None.

    Errors:
        None.

    Restrictions:
        This action can be used only when the contact is in the process of making
        an outbound call, but has not yet called the outbound number.
    """

    caller_id: Optional[str] = None
    voice_connector: Optional[Dict[str, Any]] = None
    connection_time_limit_seconds: Optional[int] = None

    def __post_init__(self):
        self.type = "CompleteOutboundCall"
        self._build_parameters()

    def _build_parameters(self):
        """Build parameters dict from typed attributes."""
        params = {}
        if self.caller_id is not None:
            params["CallerId"] = {"Number": self.caller_id}
        if self.voice_connector is not None:
            params["VoiceConnector"] = self.voice_connector
        if self.connection_time_limit_seconds is not None:
            params["ConnectionTimeLimitSeconds"] = str(self.connection_time_limit_seconds)
        if params:
            self.parameters.update(params)

    def __repr__(self) -> str:
        parts = []
        if self.caller_id:
            parts.append(f"caller_id='{self.caller_id}'")
        if self.voice_connector:
            parts.append("voice_connector=...")
        if self.connection_time_limit_seconds:
            parts.append(f"timeout={self.connection_time_limit_seconds}")
        if parts:
            return f"CompleteOutboundCall({', '.join(parts)})"
        return "CompleteOutboundCall()"

    def to_dict(self) -> dict:
        self._build_parameters()
        return super().to_dict()

    @classmethod
    def from_dict(cls, data: dict) -> "CompleteOutboundCall":
        params = data.get("Parameters", {})
        caller_id = None
        if "CallerId" in params and "Number" in params["CallerId"]:
            caller_id = params["CallerId"]["Number"]
        connection_time = None
        if "ConnectionTimeLimitSeconds" in params:
            connection_time = int(params["ConnectionTimeLimitSeconds"])
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            caller_id=caller_id,
            voice_connector=params.get("VoiceConnector"),
            connection_time_limit_seconds=connection_time,
            parameters=params,
            transitions=data.get("Transitions", {}),
        )
