"""
StartOutboundChatContact - Start an outbound chat contact.
https://docs.aws.amazon.com/connect/latest/APIReference/contact-actions-startoutboundchatcontact.html
"""

from dataclasses import dataclass
import uuid
from ..base import FlowBlock


@dataclass
class StartOutboundChatContact(FlowBlock):
    """
    Start an outbound chat contact (SMS).

    Results:
        None.

    Errors:
        - NoMatchingError - if no other error matches

    Restrictions:
        - Only connect:SMS is supported as the ContactSubtype
        - Only CONNECT_PHONENUMBER_ARN is supported as the SourceEndpoint Type
        - Only TELEPHONE_NUMBER is supported as the DestinationEndpoint Type
        - Only SMS chats are supported (no voice or other chat types)
    """

    def __post_init__(self):
        self.type = "StartOutboundChatContact"

    def __repr__(self) -> str:
        return "StartOutboundChatContact()"

    @classmethod
    def from_dict(cls, data: dict) -> "StartOutboundChatContact":
        return cls(
            identifier=data.get("Identifier", str(uuid.uuid4())),
            parameters=data.get("Parameters", {}),
            transitions=data.get("Transitions", {}),
        )
