"""
CxBlueprint MCP Server

Exposes cxblueprint documentation as MCP resources and provides
tools for AI-assisted contact flow generation, validation, and analysis.

Install: pip install cxblueprint[mcp]
Run:     cxblueprint-mcp
"""

import importlib.resources
import json
import threading
import uuid as _uuid

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "cxblueprint",
    instructions=(
        "CxBlueprint is a Python DSL for generating Amazon Connect contact flows. "
        "Read the cxblueprint://model-instructions resource first to understand "
        "the API, then use the compile_flow tool to build and compile flows."
    ),
)


def _read_bundled_doc(filename: str) -> str:
    """Read a documentation file bundled with the cxblueprint package."""
    docs_path = importlib.resources.files("cxblueprint") / "docs" / filename
    return docs_path.read_text(encoding="utf-8")


# --- Resources ---


@mcp.resource("cxblueprint://model-instructions")
def get_model_instructions() -> str:
    """Complete instructions for building Amazon Connect flows with cxblueprint.
    Read this first to understand the API, rules, and patterns."""
    return _read_bundled_doc("MODEL_INSTRUCTIONS.md")


@mcp.resource("cxblueprint://api-reference")
def get_api_reference() -> str:
    """Detailed API reference for all cxblueprint block types and methods."""
    return _read_bundled_doc("API_REFERENCE.md")


# --- Sandbox ---


class _Timeout(Exception):
    pass


def _uuid4_str() -> str:
    """Generate a UUID4 string, safe to expose in the sandbox."""
    return str(_uuid.uuid4())


def _make_sandboxed_flow_class():
    """Create a sandboxed Flow class that blocks file operations."""
    from .flow_builder import Flow

    class SandboxedFlow(Flow):
        @classmethod
        def decompile(cls, filepath: str = "", debug: bool = False):
            raise PermissionError(
                "Flow.decompile() is not available in the MCP sandbox. "
                "Use the decompile_flow tool instead."
            )

        @classmethod
        def load(cls, filepath: str = "", debug: bool = False):
            raise PermissionError(
                "Flow.load() is not available in the MCP sandbox. "
                "Use the decompile_flow tool instead."
            )

        def compile_to_file(self, filepath: str = ""):
            raise PermissionError(
                "Flow.compile_to_file() is not available in the MCP sandbox. "
                "Use the compile_flow tool which returns JSON directly."
            )

    return SandboxedFlow


def _make_safe_globals():
    """Build a restricted globals dict for code execution.

    Security measures:
    - No raw module objects (prevents __builtins__ traversal)
    - No getattr/hasattr (prevents attribute traversal attacks)
    - No file I/O (Flow.decompile/compile_to_file blocked)
    - All 57 block classes exposed by name for flow.add() patterns
    """
    import cxblueprint

    from .blocks.base import FlowBlock
    from .flow_builder import BLOCK_TYPE_MAP

    SandboxedFlow = _make_sandboxed_flow_class()

    safe_builtins = {
        "True": True,
        "False": False,
        "None": None,
        "print": print,
        "len": len,
        "str": str,
        "int": int,
        "float": float,
        "bool": bool,
        "list": list,
        "dict": dict,
        "tuple": tuple,
        "set": set,
        "range": range,
        "enumerate": enumerate,
        "zip": zip,
        "map": map,
        "filter": filter,
        "sorted": sorted,
        "reversed": reversed,
        "isinstance": isinstance,
        "type": type,
    }

    safe_globals = {
        "__builtins__": safe_builtins,
        # Core classes
        "Flow": SandboxedFlow,
        "FlowAnalyzer": cxblueprint.FlowAnalyzer,
        "FlowBlock": FlowBlock,
        # Type classes
        "LexV2Bot": cxblueprint.LexV2Bot,
        "LexBot": cxblueprint.LexBot,
        "ViewResource": cxblueprint.ViewResource,
        "Media": cxblueprint.Media,
        "InputValidation": cxblueprint.InputValidation,
        "InputEncryption": cxblueprint.InputEncryption,
        "DTMFConfiguration": cxblueprint.DTMFConfiguration,
        "PhoneNumberValidation": cxblueprint.PhoneNumberValidation,
        "CustomValidation": cxblueprint.CustomValidation,
        # Helpers (not raw modules)
        "json_dumps": json.dumps,
        "json_loads": json.loads,
        "uuid4": _uuid4_str,
    }

    # Expose all 57 block classes by their AWS type name
    for type_name, block_class in BLOCK_TYPE_MAP.items():
        safe_globals[type_name] = block_class

    return safe_globals


def _find_flow(local_vars: dict):
    """Find the Flow instance in the local variables after code runs."""
    from .flow_builder import Flow

    flows = [v for v in local_vars.values() if isinstance(v, Flow)]
    if not flows:
        return None
    return flows[-1]


def _run_sandboxed(python_code: str) -> tuple:
    """Run code in sandbox, return (safe_globals, local_vars) or raise."""
    safe_globals = _make_safe_globals()
    local_vars = {}

    code_obj = compile(python_code, "<mcp_input>", "exec")  # noqa: S102
    _safe_run(code_obj, safe_globals, local_vars)

    return safe_globals, local_vars


def _run_user_code(python_code: str) -> dict:
    """Run cxblueprint Python code in a sandboxed environment and return results.

    Uses a cross-platform threading-based timeout (works on both Unix and Windows).
    """
    result_holder = {"value": None, "error": None}

    def _execute():
        try:
            _safe_globals, local_vars = _run_sandboxed(python_code)

            flow = _find_flow(local_vars)
            if flow is None:
                result_holder["error"] = (
                    "No Flow instance found. "
                    "Create one with: flow = Flow.build('Name')"
                )
                return

            compiled = flow.compile()
            result_holder["value"] = {
                "flow_name": flow.name,
                "total_blocks": len(compiled.get("Actions", [])),
                "contact_flow_json": compiled,
            }
        except Exception as e:
            result_holder["error"] = f"{type(e).__name__}: {e}"

    thread = threading.Thread(target=_execute)
    thread.daemon = True
    thread.start()
    thread.join(timeout=10)

    if thread.is_alive():
        return {"error": "Code timed out after 10 seconds"}

    if result_holder["error"]:
        return {"error": result_holder["error"]}

    return result_holder["value"] or {"error": "No result produced"}


def _run_user_code_for_flow(python_code: str):
    """Run user code and return the Flow instance, or a dict with error."""
    result_holder = {"flow": None, "error": None}

    def _execute():
        try:
            _safe_globals, local_vars = _run_sandboxed(python_code)
            flow = _find_flow(local_vars)
            if flow is None:
                result_holder["error"] = (
                    "No Flow instance found. "
                    "Create one with: flow = Flow.build('Name')"
                )
                return
            result_holder["flow"] = flow
        except Exception as e:
            result_holder["error"] = f"{type(e).__name__}: {e}"

    thread = threading.Thread(target=_execute)
    thread.daemon = True
    thread.start()
    thread.join(timeout=10)

    if thread.is_alive():
        return {"error": "Code timed out after 10 seconds"}

    if result_holder["error"]:
        return {"error": result_holder["error"]}

    return result_holder["flow"]


# Intentional dynamic code execution for sandboxed DSL evaluation.
# The sandbox restricts builtins (no __import__, no os/sys/file access).
_run_fn = exec  # noqa: S102


def _safe_run(code_obj, globals_dict, locals_dict):
    """Run compiled code in the sandboxed globals/locals."""
    _run_fn(code_obj, globals_dict, locals_dict)


# --- Tools ---


@mcp.tool()
def compile_flow(python_code: str) -> str:
    """Compile CxBlueprint Python code into Amazon Connect contact flow JSON.

    Write Python code using the cxblueprint DSL. The following are available:

    Core: Flow, FlowAnalyzer, FlowBlock
    Types: LexV2Bot, LexBot, ViewResource, Media, InputValidation, etc.
    Blocks: All 57 AWS block classes by name (Compare, Wait, TagContact, etc.)
    Helpers: uuid4(), json_dumps(), json_loads()

    Note: Flow.decompile() and Flow.compile_to_file() are not available.
    Use the decompile_flow tool and this tool's JSON output instead.

    The code should create a Flow instance using Flow.build("name").
    The last Flow instance created will be compiled and returned.

    Example:
        flow = Flow.build("Simple Greeting")
        welcome = flow.play_prompt("Hello, thanks for calling!")
        disconnect = flow.disconnect()
        welcome.then(disconnect)

    Returns the compiled Amazon Connect JSON, or an error message.
    """
    result = _run_user_code(python_code)
    return json.dumps(result, indent=2)


@mcp.tool()
def validate_flow(python_code: str) -> str:
    """Validate CxBlueprint Python code without full compilation.

    Runs the code, then checks the resulting flow for structural issues:
    - Orphaned blocks (unreachable from start)
    - Missing error handlers on GetParticipantInput blocks
    - Unterminated paths (blocks without exits)

    Also returns flow statistics (block counts, error handler coverage).

    Returns validation results as JSON.
    """
    flow_or_error = _run_user_code_for_flow(python_code)

    if isinstance(flow_or_error, dict):
        return json.dumps(flow_or_error, indent=2)

    flow = flow_or_error
    try:
        issues = flow.analyze()
        stats = flow.stats()
        return json.dumps(
            {
                "flow_name": flow.name,
                "validation": issues,
                "stats": stats,
                "has_issues": bool(
                    issues["orphaned_blocks"]
                    or issues["missing_error_handlers"]
                    or issues["unterminated_paths"]
                ),
            },
            indent=2,
        )
    except Exception as e:
        return json.dumps({"error": f"Validation failed: {type(e).__name__}: {e}"})


@mcp.tool()
def decompile_flow(json_string: str) -> str:
    """Convert existing AWS Connect flow JSON into flow metadata for analysis.

    Takes an AWS Connect flow JSON string (not a file path) and returns
    flow metadata: name, block count, block types, and validation status.

    Use this to understand an existing flow before modifying it.

    Returns flow information as JSON.
    """
    from .flow_builder import Flow

    try:
        flow_dict = json.loads(json_string)
    except json.JSONDecodeError as e:
        return json.dumps({"error": f"Invalid JSON: {e}"})

    try:
        flow = Flow.decompile_from_dict(flow_dict)
        stats = flow.stats()
        issues = flow.analyze()
        block_types = {}
        for block in flow.blocks:
            block_types[block.type] = block_types.get(block.type, 0) + 1

        return json.dumps(
            {
                "flow_name": flow.name,
                "total_blocks": len(flow.blocks),
                "block_types": block_types,
                "stats": stats,
                "validation": issues,
            },
            indent=2,
        )
    except Exception as e:
        return json.dumps({"error": f"Decompilation failed: {type(e).__name__}: {e}"})


@mcp.tool()
def list_block_types() -> str:
    """List all available AWS Connect block types and their categories.

    Returns all 57 block types with their category and whether they have
    a convenience method on the Flow class (e.g., flow.play_prompt()).
    """
    from .flow_builder import BLOCK_TYPE_MAP

    convenience_methods = {
        "MessageParticipant": "play_prompt(text)",
        "GetParticipantInput": "get_input(text, timeout)",
        "DisconnectParticipant": "disconnect()",
        "TransferToFlow": "transfer_to_flow(contact_flow_id)",
        "ConnectParticipantWithLexBot": "lex_bot(text, lex_v2_bot, ...)",
        "InvokeLambdaFunction": "invoke_lambda(function_arn, timeout_seconds)",
        "CheckHoursOfOperation": "check_hours(hours_of_operation_id)",
        "UpdateContactAttributes": "update_attributes(**attrs)",
        "ShowView": "show_view(view_resource, ...)",
        "EndFlowExecution": "end_flow()",
        "TransferContactToQueue": "transfer_to_queue()",
        "UpdateContactTargetQueue": "set_queue(queue_id)",
        "Wait": "wait(seconds)",
        "UpdateContactRecordingBehavior": "pause_recording() / resume_recording()",
        "Compare": "compare(comparison_value)",
        "DistributeByPercentage": "distribute_by_percentage(percentages)",
    }

    categories = {
        "Participant Actions": [
            "DisconnectParticipant",
            "MessageParticipant",
            "MessageParticipantIteratively",
            "GetParticipantInput",
            "ConnectParticipantWithLexBot",
            "ShowView",
        ],
        "Flow Control": [
            "EndFlowExecution",
            "TransferToFlow",
            "Compare",
            "CheckHoursOfOperation",
            "CheckOutboundCallStatus",
            "Wait",
            "DistributeByPercentage",
            "CheckMetricData",
            "CheckVoiceId",
            "EndFlowModuleExecution",
            "GetMetricData",
            "InvokeFlowModule",
            "Loop",
            "SetVoiceId",
            "StartVoiceIdStream",
            "UpdateFlowAttributes",
            "UpdateFlowLoggingBehavior",
            "UpdateRoutingCriteria",
        ],
        "Contact Actions": [
            "UpdateContactRecordingBehavior",
            "UpdateContactAttributes",
            "UpdateContactTargetQueue",
            "TransferContactToQueue",
            "UpdateContactCallbackNumber",
            "UpdateContactEventHooks",
            "UpdateContactMediaProcessing",
            "UpdateContactRecordingAndAnalyticsBehavior",
            "UpdateContactRoutingBehavior",
            "CreateTask",
            "CreateWisdomSession",
            "CompleteOutboundCall",
            "DequeueContactAndTransferToQueue",
            "ResumeContact",
            "StartOutboundChatContact",
            "TagContact",
            "TransferContactToAgent",
            "UnTagContact",
            "UpdateContactData",
            "UpdateContactMediaStreamingBehavior",
            "UpdateContactTextToSpeechVoice",
            "UpdatePreviousContactParticipantState",
            "CreateCase",
            "GetCase",
            "UpdateCase",
        ],
        "Interactions": [
            "InvokeLambdaFunction",
            "CreateCallbackContact",
            "AssociateContactToCustomerProfile",
            "CreateCustomerProfile",
            "GetCalculatedAttributesForCustomerProfile",
            "GetCustomerProfile",
            "GetCustomerProfileObject",
            "UpdateCustomerProfile",
        ],
    }

    result = {"total_types": len(BLOCK_TYPE_MAP), "categories": {}}

    for category, types in categories.items():
        result["categories"][category] = []
        for type_name in types:
            entry = {
                "type": type_name,
                "convenience_method": convenience_methods.get(type_name),
            }
            result["categories"][category].append(entry)

    return json.dumps(result, indent=2)


@mcp.tool()
def get_flow_stats(python_code: str) -> str:
    """Get statistics for a CxBlueprint flow without full compilation.

    Returns block counts, block types, error handler coverage,
    and validation status. Lighter than compile_flow.
    """
    flow_or_error = _run_user_code_for_flow(python_code)

    if isinstance(flow_or_error, dict):
        return json.dumps(flow_or_error, indent=2)

    flow = flow_or_error
    try:
        stats = flow.stats()
        return json.dumps(
            {"flow_name": flow.name, **stats},
            indent=2,
        )
    except Exception as e:
        return json.dumps({"error": f"Stats failed: {type(e).__name__}: {e}"})


@mcp.tool()
def flow_to_mermaid(python_code: str) -> str:
    """Generate a Mermaid flowchart diagram from CxBlueprint Python code.

    Runs the code, builds the flow, and returns a Mermaid flowchart string.
    The output can be rendered in GitHub READMEs, VS Code, or any Mermaid viewer.

    Node shapes indicate block types:
    - Diamonds: decision blocks (menus, hours check, compare)
    - Rounded rectangles: action blocks (prompts, attributes)
    - Stadiums: terminal blocks (disconnect, transfer, end flow)
    - Hexagons: integration blocks (Lambda, callbacks)

    Edge styles indicate transition types:
    - Solid arrows: normal flow and conditions (labeled with values)
    - Dotted arrows: error handlers (labeled with error type)

    The code should create a Flow instance using Flow.build("name").
    Does NOT require the flow to pass validation — useful for visualizing
    work-in-progress flows.

    Returns the Mermaid diagram string, or an error message as JSON.
    """
    flow_or_error = _run_user_code_for_flow(python_code)

    if isinstance(flow_or_error, dict):
        return json.dumps(flow_or_error)

    return flow_or_error.to_mermaid()


# --- Entry point ---


def main():
    """Entry point for the cxblueprint-mcp console script."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
