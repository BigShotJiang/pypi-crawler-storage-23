"""Tests for Mermaid diagram export."""

import uuid

from cxblueprint import Flow
from cxblueprint.blocks.base import FlowBlock
from cxblueprint.blocks.interactions import InvokeLambdaFunction
from cxblueprint.blocks.participant_actions import (
    DisconnectParticipant,
    MessageParticipant,
)
from cxblueprint.mermaid_export import (
    _block_label,
    _build_id_map,
    _edge_label_for_condition,
    _error_label,
    _escape_mermaid,
    _format_node,
    _shape_for,
)


class TestNodeIdSanitization:
    """Tests for UUID to Mermaid ID mapping."""

    def test_ids_have_no_hyphens(self, simple_flow):
        id_map = _build_id_map(simple_flow.blocks)
        for mermaid_id in id_map.values():
            assert "-" not in mermaid_id

    def test_ids_are_unique(self, simple_flow):
        id_map = _build_id_map(simple_flow.blocks)
        assert len(set(id_map.values())) == len(id_map)

    def test_ids_start_with_letter(self, simple_flow):
        id_map = _build_id_map(simple_flow.blocks)
        for mermaid_id in id_map.values():
            assert mermaid_id[0].isalpha()

    def test_collision_handling(self):
        """Two blocks whose UUIDs share the first 8 hex chars get unique IDs."""
        b1 = MessageParticipant(
            identifier="aaaaaaaa-1111-2222-3333-444444444444", text="A"
        )
        b2 = MessageParticipant(
            identifier="aaaaaaaa-5555-6666-7777-888888888888", text="B"
        )
        id_map = _build_id_map([b1, b2])
        ids = list(id_map.values())
        assert ids[0] != ids[1]


class TestNodeShapes:
    """Tests for block type to Mermaid shape mapping."""

    def test_terminal_blocks_get_stadium(self):
        assert _shape_for("DisconnectParticipant") == "stadium"
        assert _shape_for("EndFlowExecution") == "stadium"
        assert _shape_for("TransferToFlow") == "stadium"
        assert _shape_for("TransferContactToQueue") == "stadium"

    def test_branching_blocks_get_diamond(self):
        assert _shape_for("GetParticipantInput") == "diamond"
        assert _shape_for("CheckHoursOfOperation") == "diamond"
        assert _shape_for("Compare") == "diamond"
        assert _shape_for("DistributeByPercentage") == "diamond"

    def test_integration_blocks_get_hexagon(self):
        assert _shape_for("InvokeLambdaFunction") == "hexagon"
        assert _shape_for("CreateCallbackContact") == "hexagon"
        assert _shape_for("CreateTask") == "hexagon"

    def test_default_blocks_get_rect(self):
        assert _shape_for("MessageParticipant") == "rect"
        assert _shape_for("UpdateContactAttributes") == "rect"
        assert _shape_for("Wait") == "rect"
        assert _shape_for("UnknownBlockType") == "rect"


class TestFormatNode:
    """Tests for Mermaid node declaration formatting."""

    def test_stadium_shape(self):
        result = _format_node("n_abc", "Disconnect", "stadium")
        assert '(["Disconnect"])' in result

    def test_diamond_shape(self):
        result = _format_node("n_abc", "Get Input", "diamond")
        assert '{"Get Input"}' in result

    def test_hexagon_shape(self):
        result = _format_node("n_abc", "Lambda", "hexagon")
        assert '[["Lambda"]]' in result

    def test_rect_shape(self):
        result = _format_node("n_abc", "Play Prompt", "rect")
        assert '["Play Prompt"]' in result

    def test_newline_becomes_br(self):
        result = _format_node("n_abc", "Play Prompt\n'Hello'", "rect")
        assert "<br/>" in result
        assert "\n" not in result.split("\n")[-1]  # no raw newline in the node decl


class TestNodeLabels:
    """Tests for block label extraction."""

    def test_message_shows_text(self):
        block = MessageParticipant(identifier=str(uuid.uuid4()), text="Hello, welcome!")
        label = _block_label(block)
        assert "Play Prompt" in label
        assert "'Hello, welcome!'" in label

    def test_long_text_truncated(self):
        block = MessageParticipant(
            identifier=str(uuid.uuid4()),
            text="This is a very long prompt text that exceeds the truncation limit",
        )
        label = _block_label(block)
        assert "..." in label

    def test_disconnect_has_no_detail(self):
        block = DisconnectParticipant(identifier=str(uuid.uuid4()))
        label = _block_label(block)
        assert label == "Disconnect"

    def test_lambda_shows_function_name(self):
        block = InvokeLambdaFunction(
            identifier=str(uuid.uuid4()),
            lambda_function_arn="arn:aws:lambda:us-east-1:123456789:function:myFunc",
        )
        label = _block_label(block)
        assert "Lambda" in label
        assert "myFunc" in label

    def test_unknown_type_splits_camel(self):
        block = FlowBlock(identifier=str(uuid.uuid4()))
        block.type = "SomeFutureBlockType"
        block.parameters = {}
        label = _block_label(block)
        assert "Some Future Block Type" in label


class TestEdgeLabels:
    """Tests for edge label generation."""

    def test_condition_shows_operand(self):
        cond = {
            "NextAction": "x",
            "Condition": {"Operator": "Equals", "Operands": ["1"]},
        }
        assert _edge_label_for_condition("GetParticipantInput", cond) == "1"

    def test_check_hours_true(self):
        cond = {
            "NextAction": "x",
            "Condition": {"Operator": "Equals", "Operands": ["True"]},
        }
        assert _edge_label_for_condition("CheckHoursOfOperation", cond) == "In Hours"

    def test_check_hours_false(self):
        cond = {
            "NextAction": "x",
            "Condition": {"Operator": "Equals", "Operands": ["False"]},
        }
        assert _edge_label_for_condition("CheckHoursOfOperation", cond) == "After Hours"

    def test_loop_continue(self):
        cond = {
            "NextAction": "x",
            "Condition": {"Operator": "Equals", "Operands": ["ContinueLooping"]},
        }
        assert _edge_label_for_condition("Loop", cond) == "Looping"

    def test_loop_done(self):
        cond = {
            "NextAction": "x",
            "Condition": {"Operator": "Equals", "Operands": ["DoneLooping"]},
        }
        assert _edge_label_for_condition("Loop", cond) == "Done"

    def test_empty_operands(self):
        cond = {"NextAction": "x", "Condition": {"Operator": "Equals", "Operands": []}}
        assert _edge_label_for_condition("Compare", cond) == "?"


class TestErrorLabels:
    """Tests for error edge label shortening."""

    def test_timeout(self):
        assert _error_label("InputTimeLimitExceeded") == "Timeout"

    def test_no_match(self):
        assert _error_label("NoMatchingCondition") == "No Match"

    def test_generic_error(self):
        assert _error_label("NoMatchingError") == "Error"

    def test_unknown_error_truncated(self):
        result = _error_label("SomeVeryLongCustomErrorTypeName")
        assert len(result) <= 20


class TestEscapeMermaid:
    """Tests for Mermaid special character escaping."""

    def test_double_quotes(self):
        assert _escape_mermaid('say "hello"') == "say 'hello'"

    def test_angle_brackets(self):
        assert "&lt;" in _escape_mermaid("<html>")
        assert "&gt;" in _escape_mermaid("<html>")

    def test_hash(self):
        assert "&#35;" in _escape_mermaid("color #red")


class TestFlowToMermaid:
    """End-to-end integration tests using test fixtures."""

    def test_simple_flow(self, simple_flow):
        result = simple_flow.to_mermaid()
        assert result.startswith("flowchart TB")
        assert "Play Prompt" in result
        assert "Disconnect" in result
        assert "-->" in result

    def test_menu_flow_has_conditions(self, menu_flow):
        result = menu_flow.to_mermaid()
        # DTMF condition labels
        assert '"1"' in result
        assert '"2"' in result
        # Error edges (dotted)
        assert "-.->|" in result

    def test_branching_flow(self, branching_flow):
        result = branching_flow.to_mermaid()
        assert '"1"' in result
        assert '"2"' in result
        assert '"3"' in result

    def test_empty_flow(self):
        flow = Flow.build("Empty")
        result = flow.to_mermaid()
        assert "flowchart TB" in result
        assert "No blocks" in result

    def test_flow_name_in_comment(self, simple_flow):
        result = simple_flow.to_mermaid()
        assert "Simple Test Flow" in result

    def test_start_marker(self, simple_flow):
        result = simple_flow.to_mermaid()
        assert "_start(( ))" in result

    def test_default_label_when_conditions_present(self, menu_flow):
        result = menu_flow.to_mermaid()
        assert '"Default"' in result


class TestClassStyling:
    """Tests for CSS class assignment in Mermaid output."""

    def test_terminal_class(self, simple_flow):
        result = simple_flow.to_mermaid()
        assert "classDef terminal" in result
        assert "class " in result and "terminal;" in result

    def test_branching_class(self, menu_flow):
        result = menu_flow.to_mermaid()
        assert "classDef branching" in result
        assert "branching;" in result

    def test_integration_class(self):
        flow = Flow.build("Lambda Flow")
        prompt = flow.play_prompt("Hello")
        lam = flow.invoke_lambda("arn:aws:lambda:us-east-1:123:function:test")
        dc = flow.disconnect()
        prompt.then(lam)
        lam.then(dc)
        result = flow.to_mermaid()
        assert "classDef integration" in result
        assert "integration;" in result


class TestDeduplication:
    """Tests for multiple blocks pointing to the same target."""

    def test_multiple_edges_to_same_target(self):
        flow = Flow.build("Converging Flow")
        a = flow.play_prompt("Path A")
        b = flow.play_prompt("Path B")
        dc = flow.disconnect()
        a.then(dc)
        b.then(dc)
        result = flow.to_mermaid()
        # Disconnect node should appear only once as a declaration
        lines = result.split("\n")
        dc_id = None
        for block in flow.blocks:
            if block.type == "DisconnectParticipant":
                dc_id = block.identifier.replace("-", "")[:8]
                break
        node_decl_count = sum(
            1 for line in lines if f"n_{dc_id}" in line and '(["' in line
        )
        assert node_decl_count == 1


class TestMcpFlowToMermaidTool:
    """Tests for the flow_to_mermaid MCP tool."""

    def test_valid_code_returns_mermaid(self):
        from cxblueprint.mcp_server import flow_to_mermaid

        code = """
flow = Flow.build("Test")
p = flow.play_prompt("Hello")
d = flow.disconnect()
p.then(d)
"""
        result = flow_to_mermaid(code)
        assert "flowchart TB" in result
        assert "Play Prompt" in result

    def test_bad_code_returns_error(self):
        import json

        from cxblueprint.mcp_server import flow_to_mermaid

        result = flow_to_mermaid("x = 1")
        parsed = json.loads(result)
        assert "error" in parsed

    def test_tool_registered(self):
        from cxblueprint.mcp_server import mcp

        tools = list(mcp._tool_manager._tools.keys())
        assert "flow_to_mermaid" in tools
