"""Tests for the CxBlueprint MCP server."""

import json

import pytest

from cxblueprint.mcp_server import (
    _make_safe_globals,
    _read_bundled_doc,
    _run_user_code,
    mcp,
)


class TestResources:
    """Test MCP resource loading."""

    def test_model_instructions_loads(self):
        content = _read_bundled_doc("MODEL_INSTRUCTIONS.md")
        assert len(content) > 1000
        assert "CxBlueprint" in content

    def test_api_reference_loads(self):
        content = _read_bundled_doc("API_REFERENCE.md")
        assert len(content) > 500
        assert "API" in content or "Flow" in content

    def test_missing_doc_raises(self):
        with pytest.raises(Exception):
            _read_bundled_doc("nonexistent.md")

    def test_resources_registered(self):
        resources = list(mcp._resource_manager._resources.keys())
        assert "cxblueprint://model-instructions" in resources
        assert "cxblueprint://api-reference" in resources


class TestCompileFlow:
    """Test the compile_flow tool's code execution."""

    def test_simple_flow(self):
        result = _run_user_code(
            'flow = Flow.build("Test")\n'
            'w = flow.play_prompt("Hi")\n'
            "d = flow.disconnect()\n"
            "w.then(d)"
        )
        assert "error" not in result
        assert result["flow_name"] == "Test"
        assert result["total_blocks"] == 2
        assert "Actions" in result["contact_flow_json"]

    def test_menu_flow(self):
        result = _run_user_code(
            'flow = Flow.build("Menu")\n'
            'menu = flow.get_input("Press 1 or 2", timeout=10)\n'
            'opt1 = flow.play_prompt("Option 1")\n'
            'opt2 = flow.play_prompt("Option 2")\n'
            "d = flow.disconnect()\n"
            'menu.when("1", opt1).when("2", opt2).otherwise(d)\n'
            'menu.on_error("InputTimeLimitExceeded", d)\n'
            'menu.on_error("NoMatchingCondition", d)\n'
            'menu.on_error("NoMatchingError", d)\n'
            "opt1.then(d)\n"
            "opt2.then(d)"
        )
        assert "error" not in result
        assert result["flow_name"] == "Menu"
        assert result["total_blocks"] == 4

    def test_no_flow_instance(self):
        result = _run_user_code("x = 1 + 2")
        assert "error" in result
        assert "No Flow instance" in result["error"]

    def test_syntax_error(self):
        result = _run_user_code("def foo(")
        assert "error" in result
        assert "SyntaxError" in result["error"]

    def test_runtime_error(self):
        result = _run_user_code("x = 1 / 0")
        assert "error" in result
        assert "ZeroDivisionError" in result["error"]

    def test_import_blocked(self):
        result = _run_user_code("import os")
        assert "error" in result

    def test_subprocess_blocked(self):
        result = _run_user_code("import subprocess")
        assert "error" in result

    def test_dunder_import_blocked(self):
        result = _run_user_code("__import__('os')")
        assert "error" in result

    def test_open_blocked(self):
        result = _run_user_code("f = open('/etc/passwd')")
        assert "error" in result

    def test_empty_code(self):
        result = _run_user_code("")
        assert "error" in result
        assert "No Flow instance" in result["error"]

    def test_compiled_json_is_valid(self):
        result = _run_user_code(
            'flow = Flow.build("JSON Test")\n'
            'w = flow.play_prompt("Hello")\n'
            "d = flow.disconnect()\n"
            "w.then(d)"
        )
        flow_json = result["contact_flow_json"]
        assert flow_json["Version"] == "2019-10-30"
        assert len(flow_json["Actions"]) == 2
        assert "StartAction" in flow_json
        assert "Metadata" in flow_json


class TestSandboxSecurity:
    """Test sandbox security measures."""

    def test_getattr_not_available(self):
        """getattr is removed from builtins to prevent attribute traversal."""
        safe_globals = _make_safe_globals()
        assert "getattr" not in safe_globals["__builtins__"]

    def test_hasattr_not_available(self):
        """hasattr is removed from builtins to prevent attribute traversal."""
        safe_globals = _make_safe_globals()
        assert "hasattr" not in safe_globals["__builtins__"]

    def test_raw_cxblueprint_module_not_in_scope(self):
        """The raw cxblueprint module must not be exposed (has __builtins__)."""
        safe_globals = _make_safe_globals()
        assert "cxblueprint" not in safe_globals

    def test_raw_json_module_not_in_scope(self):
        """The raw json module must not be exposed (has __builtins__)."""
        safe_globals = _make_safe_globals()
        assert "json" not in safe_globals

    def test_json_dumps_available(self):
        """json_dumps should be available as a safe alternative."""
        safe_globals = _make_safe_globals()
        assert "json_dumps" in safe_globals

    def test_json_loads_available(self):
        """json_loads should be available as a safe alternative."""
        safe_globals = _make_safe_globals()
        assert "json_loads" in safe_globals

    def test_flow_decompile_raises_permission_error(self):
        """Flow.decompile() must be blocked in sandbox."""
        result = _run_user_code('Flow.decompile("some_file.json")')
        assert "error" in result
        assert "PermissionError" in result["error"]

    def test_flow_load_raises_permission_error(self):
        """Flow.load() must be blocked in sandbox."""
        result = _run_user_code('Flow.load("some_file.json")')
        assert "error" in result
        assert "PermissionError" in result["error"]

    def test_flow_compile_to_file_raises_permission_error(self):
        """Flow.compile_to_file() must be blocked in sandbox."""
        result = _run_user_code(
            'flow = Flow.build("Test")\n'
            'w = flow.play_prompt("Hi")\n'
            "d = flow.disconnect()\n"
            "w.then(d)\n"
            'flow.compile_to_file("/tmp/evil.json")'
        )
        assert "error" in result
        assert "PermissionError" in result["error"]

    def test_builtins_traversal_via_getattr_blocked(self):
        """Attempting getattr() to traverse builtins should fail."""
        result = _run_user_code("getattr(Flow, '__module__')")
        assert "error" in result

    def test_dunder_builtins_access_blocked(self):
        """Direct __builtins__ access should not give real builtins."""
        safe_globals = _make_safe_globals()
        builtins = safe_globals["__builtins__"]
        assert "__import__" not in builtins
        assert "open" not in builtins


class TestBlockClassAccess:
    """Test that block classes are properly exposed in the sandbox."""

    def test_block_classes_in_safe_globals(self):
        """All block classes from BLOCK_TYPE_MAP should be accessible."""
        from cxblueprint.flow_builder import BLOCK_TYPE_MAP

        safe_globals = _make_safe_globals()
        for type_name in BLOCK_TYPE_MAP:
            assert type_name in safe_globals, f"{type_name} not in safe_globals"

    def test_compare_block_accessible(self):
        """Compare block should be usable directly by name."""
        result = _run_user_code(
            'flow = Flow.build("Compare Test")\n'
            'prompt = flow.play_prompt("Checking...")\n'
            "check = flow.compare('$.Attributes.tier')\n"
            'premium = flow.play_prompt("Premium!")\n'
            "d = flow.disconnect()\n"
            "prompt.then(check)\n"
            'check.when("premium", premium).otherwise(d)\n'
            "premium.then(d)"
        )
        assert "error" not in result
        assert result["total_blocks"] == 4

    def test_flow_add_with_block_class(self):
        """flow.add(BlockClass(...)) should work for any block type."""
        result = _run_user_code(
            'flow = Flow.build("Add Test")\n'
            'prompt = flow.play_prompt("Hello")\n'
            "tag = TagContact(identifier=uuid4())\n"
            "flow.add(tag)\n"
            "d = flow.disconnect()\n"
            "prompt.then(tag)\n"
            "tag.then(d)"
        )
        assert "error" not in result
        assert result["total_blocks"] == 3

    def test_uuid4_returns_string(self):
        """uuid4() helper should return a valid UUID string."""
        from cxblueprint.mcp_server import _uuid4_str

        result = _uuid4_str()
        assert isinstance(result, str)
        assert len(result) == 36  # UUID format: 8-4-4-4-12
        assert result.count("-") == 4

    def test_uuid4_available_in_sandbox(self):
        """uuid4() should be callable from sandbox code."""
        safe_globals = _make_safe_globals()
        assert "uuid4" in safe_globals
        assert callable(safe_globals["uuid4"])

    def test_json_dumps_works_in_sandbox(self):
        """json_dumps should serialize dicts to JSON strings."""
        result = _run_user_code(
            'flow = Flow.build("JSON Test")\n'
            'data = json_dumps({"key": "value"})\n'
            "w = flow.play_prompt(data)\n"
            "d = flow.disconnect()\n"
            "w.then(d)"
        )
        assert "error" not in result

    def test_json_loads_works_in_sandbox(self):
        """json_loads should parse JSON strings to dicts."""
        result = _run_user_code(
            'flow = Flow.build("JSON Test")\n'
            """data = json_loads('{"key": "value"}')\n"""
            "w = flow.play_prompt(str(data))\n"
            "d = flow.disconnect()\n"
            "w.then(d)"
        )
        assert "error" not in result

    def test_flowblock_base_accessible(self):
        """FlowBlock base class should be accessible."""
        safe_globals = _make_safe_globals()
        assert "FlowBlock" in safe_globals

    def test_type_classes_accessible(self):
        """Type classes (LexV2Bot, Media, etc.) should be accessible."""
        safe_globals = _make_safe_globals()
        for name in [
            "LexV2Bot",
            "LexBot",
            "ViewResource",
            "Media",
            "InputValidation",
            "InputEncryption",
            "DTMFConfiguration",
            "PhoneNumberValidation",
            "CustomValidation",
        ]:
            assert name in safe_globals, f"{name} not in safe_globals"


class TestTimeout:
    """Test code execution timeout."""

    def test_infinite_loop_times_out(self):
        """An infinite loop should be caught by the threading timeout."""
        result = _run_user_code("while True: pass")
        assert "error" in result
        assert (
            "timed out" in result["error"].lower()
            or "timeout" in result["error"].lower()
        )


class TestValidateFlowTool:
    """Test the validate_flow MCP tool."""

    def test_valid_flow_no_issues(self):
        """A well-formed flow should have no validation issues."""
        from cxblueprint.mcp_server import validate_flow

        result_json = validate_flow(
            'flow = Flow.build("Valid")\n'
            'w = flow.play_prompt("Hello")\n'
            "d = flow.disconnect()\n"
            "w.then(d)"
        )
        result = json.loads(result_json)
        assert "error" not in result
        assert result["flow_name"] == "Valid"
        assert result["has_issues"] is False
        assert result["validation"]["orphaned_blocks"] == []
        assert not result["validation"]["missing_error_handlers"]

    def test_flow_with_missing_error_handlers(self):
        """A flow with missing error handlers should report issues."""
        from cxblueprint.mcp_server import validate_flow

        result_json = validate_flow(
            'flow = Flow.build("Invalid")\n'
            'menu = flow.get_input("Press 1", timeout=10)\n'
            "d = flow.disconnect()\n"
            'menu.when("1", d)'
        )
        result = json.loads(result_json)
        assert "error" not in result
        assert result["has_issues"] is True
        assert len(result["validation"]["missing_error_handlers"]) > 0

    def test_validate_returns_stats(self):
        """validate_flow should include stats in the response."""
        from cxblueprint.mcp_server import validate_flow

        result_json = validate_flow(
            'flow = Flow.build("Stats")\n'
            'w = flow.play_prompt("Hi")\n'
            "d = flow.disconnect()\n"
            "w.then(d)"
        )
        result = json.loads(result_json)
        assert "stats" in result
        assert "total_blocks" in result["stats"]

    def test_validate_with_bad_code(self):
        """Invalid code should return an error."""
        from cxblueprint.mcp_server import validate_flow

        result_json = validate_flow("def foo(")
        result = json.loads(result_json)
        assert "error" in result


class TestDecompileFlowTool:
    """Test the decompile_flow MCP tool."""

    def test_valid_json(self):
        """Valid AWS Connect JSON should return flow metadata."""
        from cxblueprint.mcp_server import decompile_flow

        flow_json = {
            "Version": "2019-10-30",
            "StartAction": "block-1",
            "Actions": [
                {
                    "Identifier": "block-1",
                    "Type": "MessageParticipant",
                    "Parameters": {"Text": "Hello"},
                    "Transitions": {"NextAction": "block-2"},
                },
                {
                    "Identifier": "block-2",
                    "Type": "DisconnectParticipant",
                    "Parameters": {},
                    "Transitions": {},
                },
            ],
            "Metadata": {},
        }
        result_json = decompile_flow(json.dumps(flow_json))
        result = json.loads(result_json)
        assert "error" not in result
        assert result["total_blocks"] == 2
        assert "MessageParticipant" in result["block_types"]
        assert "DisconnectParticipant" in result["block_types"]

    def test_invalid_json(self):
        """Invalid JSON should return an error."""
        from cxblueprint.mcp_server import decompile_flow

        result_json = decompile_flow("not valid json {{{")
        result = json.loads(result_json)
        assert "error" in result
        assert "Invalid JSON" in result["error"]

    def test_returns_validation(self):
        """decompile_flow should include validation results."""
        from cxblueprint.mcp_server import decompile_flow

        flow_json = {
            "Version": "2019-10-30",
            "StartAction": "block-1",
            "Actions": [
                {
                    "Identifier": "block-1",
                    "Type": "MessageParticipant",
                    "Parameters": {"Text": "Hello"},
                    "Transitions": {},
                },
            ],
            "Metadata": {},
        }
        result_json = decompile_flow(json.dumps(flow_json))
        result = json.loads(result_json)
        assert "validation" in result
        assert "stats" in result


class TestListBlockTypesTool:
    """Test the list_block_types MCP tool."""

    def test_returns_all_types(self):
        """Should return all block types from BLOCK_TYPE_MAP."""
        from cxblueprint.mcp_server import list_block_types

        result_json = list_block_types()
        result = json.loads(result_json)
        assert result["total_types"] == 57

    def test_has_categories(self):
        """Should organize block types into categories."""
        from cxblueprint.mcp_server import list_block_types

        result_json = list_block_types()
        result = json.loads(result_json)
        categories = result["categories"]
        assert "Participant Actions" in categories
        assert "Flow Control" in categories
        assert "Contact Actions" in categories
        assert "Interactions" in categories

    def test_includes_convenience_methods(self):
        """Should indicate which types have convenience methods."""
        from cxblueprint.mcp_server import list_block_types

        result_json = list_block_types()
        result = json.loads(result_json)
        # Find MessageParticipant entry
        participant_types = result["categories"]["Participant Actions"]
        msg_type = next(
            t for t in participant_types if t["type"] == "MessageParticipant"
        )
        assert msg_type["convenience_method"] == "play_prompt(text)"


class TestGetFlowStatsTool:
    """Test the get_flow_stats MCP tool."""

    def test_returns_stats(self):
        """Should return flow statistics."""
        from cxblueprint.mcp_server import get_flow_stats

        result_json = get_flow_stats(
            'flow = Flow.build("Stats Test")\n'
            'w = flow.play_prompt("Hi")\n'
            "d = flow.disconnect()\n"
            "w.then(d)"
        )
        result = json.loads(result_json)
        assert "error" not in result
        assert result["flow_name"] == "Stats Test"
        assert result["total_blocks"] == 2

    def test_bad_code_returns_error(self):
        """Invalid code should return an error."""
        from cxblueprint.mcp_server import get_flow_stats

        result_json = get_flow_stats("x = 1")
        result = json.loads(result_json)
        assert "error" in result


class TestServerRegistration:
    """Test MCP server tool and resource registration."""

    def test_server_name(self):
        assert mcp.name == "cxblueprint"

    def test_compile_flow_tool_registered(self):
        tools = list(mcp._tool_manager._tools.keys())
        assert "compile_flow" in tools

    def test_validate_flow_tool_registered(self):
        tools = list(mcp._tool_manager._tools.keys())
        assert "validate_flow" in tools

    def test_decompile_flow_tool_registered(self):
        tools = list(mcp._tool_manager._tools.keys())
        assert "decompile_flow" in tools

    def test_list_block_types_tool_registered(self):
        tools = list(mcp._tool_manager._tools.keys())
        assert "list_block_types" in tools

    def test_get_flow_stats_tool_registered(self):
        tools = list(mcp._tool_manager._tools.keys())
        assert "get_flow_stats" in tools

    def test_resources_count(self):
        resources = list(mcp._resource_manager._resources.keys())
        assert len(resources) == 2

    def test_tools_count(self):
        tools = list(mcp._tool_manager._tools.keys())
        assert len(tools) == 6

    def test_flow_to_mermaid_tool_registered(self):
        tools = list(mcp._tool_manager._tools.keys())
        assert "flow_to_mermaid" in tools
