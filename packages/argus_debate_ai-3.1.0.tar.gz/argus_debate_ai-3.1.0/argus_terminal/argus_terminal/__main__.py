"""Entry point for running argus_terminal as a module: python -m argus_terminal."""

from argus_terminal import main

if __name__ == "__main__":
    main()
