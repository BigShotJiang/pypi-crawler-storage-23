"""Utils package for Argus Terminal."""
