"""Allow running argus_viz as a module: python -m argus_viz."""
from argus_viz import main

if __name__ == "__main__":
    main()
