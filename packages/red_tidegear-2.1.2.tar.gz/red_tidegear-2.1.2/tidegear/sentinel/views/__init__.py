# SPDX-FileCopyrightText: 2025 cswimr <copyright@csw.im>
# SPDX-License-Identifier: MPL-2.0

"""Views provided for use with Sentinel."""

from tidegear.sentinel.views.history import HistoryView

__all__ = ["HistoryView"]
