# SPDX-FileCopyrightText: 2025 cswimr <copyright@csw.im>
# SPDX-License-Identifier: MPL-2.0

"""History view for use by cogs consuming Sentinel."""

import time
from datetime import date, datetime
from math import ceil
from typing import Literal, Self, cast

import discord
import pydantic
from class_registry.base import RegistryKeyError
from discord.utils import utcnow
from redbot.core import commands
from redbot.core.i18n import Translator, set_contextual_locales_from_guild
from typing_extensions import override

from tidegear import TRANSLATOR_COG_NAME, cf
from tidegear.exceptions import ContextError, NotFoundError
from tidegear.pydantic import BaseModel, truncate_string
from tidegear.sentinel import Moderation, ModerationType, PartialTargetable, PartialUser, SentinelCog, Targetable
from tidegear.sentinel.config import Pagesize
from tidegear.sentinel.exceptions import UnsetError
from tidegear.utils import seconds_to_milliseconds, send_error, title

__all__ = ["HistoryView"]

_ = Translator(TRANSLATOR_COG_NAME, __file__)


class _HistoryOpts(BaseModel):
    cog: SentinelCog
    ctx: commands.GuildContext
    targets: list[Targetable | PartialTargetable] | None
    moderators: list[discord.abc.User | PartialUser] | None
    on: date | None
    before: datetime
    after: datetime | None
    expired: bool | None
    external: bool | None
    resolved: bool | None
    types: Literal[True] | list[ModerationType | type[ModerationType]] | None
    pagesize: Pagesize
    page: pydantic.PositiveInt
    inline: bool
    ephemeral: bool

    target_user: discord.User | discord.Member | None = None

    last_moderations: list[Moderation] | None = None
    total_moderation_count: int = 0
    total_page_count: int = 0

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.pagesize

    async def fetch_moderations(self, reverse: bool = False) -> list[Moderation]:
        self.last_moderations = await self.cog.sentinel_history(
            self.ctx.guild,
            targets=self.targets,
            moderators=self.moderators,
            on=self.on,
            before=self.before,
            after=self.after,
            expired=self.expired,
            external=self.external,
            resolved=self.resolved,
            types=self.types,
            limit=self.pagesize,
            offset=self.offset,
            reverse=reverse,
            last_moderations=self.last_moderations,
        )
        return self.last_moderations

    async def fetch_count(self) -> int:
        self.total_moderation_count = await self.cog._sentinel_history_count(  # noqa: SLF001
            self.ctx.guild,
            targets=self.targets,
            moderators=self.moderators,
            on=self.on,
            before=self.before,
            after=self.after,
            expired=self.expired,
            external=self.external,
            resolved=self.resolved,
            types=self.types,
        )
        self.total_page_count = ceil(self.total_moderation_count / self.pagesize)
        return self.total_moderation_count


class HistoryView(discord.ui.View):
    """A filtered, paginated view representing a list of moderation cases."""

    def __init__(
        self,
        opts: _HistoryOpts,
        *,
        timeout: float | None = 180,
    ) -> None:
        super().__init__(timeout=timeout)
        self.opts: _HistoryOpts = opts

        self.__done: bool = False
        self.message: discord.Message | None = None

    @override
    async def on_timeout(self) -> None:
        if self.message and not self.__done:
            try:
                await self.message.edit(view=None)
            except discord.NotFound:
                pass
            self.__done = True

    @override
    async def interaction_check(self, interaction: discord.Interaction, /) -> bool:
        if interaction.user.id != (self.opts.target_user if self.opts.target_user else self.opts.ctx.author).id:
            await send_error(interaction, content=_("You cannot use this menu."))
            return False
        return True

    async def _close_button_callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(thinking=False)

        if not self.message:
            msg = "View was not properly initialized."
            raise ValueError(msg)

        await self.message.delete()
        self.__done = True

    async def _first_button_callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(thinking=False)

        if not self.message:
            msg = "View was not properly initialized."
            raise ValueError(msg)

        self.opts.page = 1
        self.opts.last_moderations = None

        await self._edit()

    async def _next_button_callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(thinking=False)

        if not self.message:
            msg = "View was not properly initialized."
            raise ValueError(msg)

        if self.opts.page == self.opts.total_page_count:
            self.opts.page = 1
            self.opts.last_moderations = None
        else:
            self.opts.page += 1

        await self._edit()

    async def _back_button_callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(thinking=False)

        if not self.message:
            msg = "View was not properly initialized."
            raise ValueError(msg)

        if self.opts.page == 1:
            self.opts.page = self.opts.total_page_count
            self.opts.last_moderations = None
        else:
            self.opts.page -= 1

        await self._edit(reverse=True)

    async def _last_button_callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(thinking=False)

        if not self.message:
            msg = "View was not properly initialized."
            raise ValueError(msg)

        self.opts.page = self.opts.total_page_count
        self.opts.last_moderations = None

        await self._edit()

    async def _jump_button_callback(self, interaction: discord.Interaction) -> None:
        modal = _HistoryPageModal(title=_("Jump to Page"), view=self)
        modal.page_input.label = _("Page Number")
        modal.page_input.placeholder = cf.humanize_number(self.opts.page)
        await interaction.response.send_modal(modal)

    async def _edit(self, *, reverse: bool = False) -> Self | discord.Message:
        return await self._send_opts(self.opts, reverse=reverse, message=self.message)

    @classmethod
    async def _send_opts(
        cls, opts: _HistoryOpts, *, reverse: bool = False, message: discord.Message | None = None
    ) -> Self | discord.Message:
        await set_contextual_locales_from_guild(opts.cog.bot, opts.ctx.guild)

        before_queries = time.perf_counter()
        if opts.total_moderation_count == 0 or opts.total_page_count == 0:
            await opts.fetch_count()

        if opts.total_moderation_count == 0 or opts.total_page_count == 0:
            return await send_error(
                opts.ctx, content=_("No moderations could be found for the provided query."), edit_original=True, reply=True
            )

        moderations = await opts.fetch_moderations(reverse)

        total_queries = time.perf_counter() - before_queries

        before_construction = time.perf_counter()
        icon_url = None
        if opts.ctx.guild.icon:
            icon_url = opts.ctx.guild.icon.url
        elif opts.cog.me.avatar:
            icon_url = opts.cog.me.avatar.url

        embed = discord.Embed(color=await opts.ctx.embed_color(), timestamp=utcnow())
        embed.set_author(name=_("Infraction History"), icon_url=icon_url)
        embed.set_footer(
            text=_("Page {current} of {total} • {result_count} {plural_results}").format(
                current=cf.humanize_number(opts.page),
                total=cf.humanize_number(opts.total_page_count),
                result_count=cf.humanize_number(opts.total_moderation_count),
                plural_results=_("Result") if opts.total_moderation_count == 1 else _("Results"),
            )
        )

        moderation_times: dict[int, float] = {}

        for moderation in moderations:
            before_moderation = time.perf_counter()
            try:
                target = await moderation.target()
            except UnsetError:
                opts.cog._sentinel_logger.exception("Moderation %i does not have a target!", moderation.id)  # noqa: SLF001
                continue
            except NotFoundError:
                opts.cog._sentinel_logger.exception("Could not find target for moderation %i!", moderation.id)  # noqa: SLF001
                continue

            try:
                moderator = await moderation.moderator()
            except UnsetError:
                opts.cog._sentinel_logger.exception("Moderation %i does not have a moderator!", moderation.id)  # noqa: SLF001
                continue
            except NotFoundError:
                opts.cog._sentinel_logger.exception("Could not find moderator for moderation %i!", moderation.id)  # noqa: SLF001
                continue

            field_strings: list[str] = [
                _("**Target:** {target} (`{id}`)").format(
                    target=target.mention if target.in_guild(opts.ctx.guild) else cf.inline(text=target.name),
                    id=target.discord_id,
                ),
                _("**Moderator**: {moderator} (`{id}`)").format(
                    moderator=moderator.mention if moderator.in_guild(opts.ctx.guild) else cf.inline(text=moderator.name),
                    id=moderator.discord_id,
                ),
                _("**Reason:** {reason}").format(
                    reason=cf.inline(text=truncate_string(string=moderation.reason or _("No reason provided."), max_length=140))
                ),
                _("**Timestamp:** {timestamp} ({relative})").format(
                    timestamp=cf.format_datetime(dt=moderation.timestamp, style=cf.TimestampStyle.SHORT_DATE_AND_TIME),
                    relative=cf.format_datetime(dt=moderation.timestamp, style=cf.TimestampStyle.RELATIVE),
                ),
            ]

            if moderation.duration:
                if moderation.expired:
                    _value = _("**Duration:** {timedelta} (Expired)").format(
                        timedelta=cf.humanize_timedelta(value=moderation.duration)
                    )
                elif moderation.end_timestamp:
                    _value = _("**Duration:** {timedelta} ({end_timestamp})").format(
                        timedelta=cf.humanize_timedelta(value=moderation.duration),
                        end_timestamp=cf.format_datetime(dt=moderation.end_timestamp, style=cf.TimestampStyle.RELATIVE),
                    )
                else:
                    _value = _("**Duration:** {timedelta}").format(timedelta=cf.humanize_timedelta(value=moderation.duration))
                field_strings.append(_value)

            if moderation.external:
                field_strings.append(_("**External:** True"))

            if moderation.resolved:
                field_strings.extend([
                    _("**Resolved:** True"),
                    _("**Resolve Reason:** `{reason}`").format(
                        reason=truncate_string(string=moderation.resolve_reason or "No reason provided.", max_length=140)
                    ),
                ])

            try:
                moderation_type = moderation.type
            except RegistryKeyError:
                moderation_type = None

            if moderation_type:
                field_strings.extend([
                    f"**{title(meta.human_name)}:** {meta_value}"
                    for meta in [meta for meta in moderation_type.metadata if meta.show_in_history]
                    if (meta_value := await meta.fetch_from_moderation(moderation, opts.cog.bot))
                ])

            embed.add_field(
                name=_("Case {id} ({type})").format(id=cf.humanize_number(moderation.id), type=title(moderation.type_key)),
                value="\n".join(field_strings),
                inline=opts.inline,
            )

            moderation_times[moderation.id] = time.perf_counter() - before_moderation

        view = cls(opts)

        close_button = discord.ui.Button(emoji=opts.cog.get_application_emoji("close"), style=discord.ButtonStyle.danger, row=1)
        close_button.callback = view._close_button_callback
        view.add_item(close_button)

        if opts.total_page_count > 1:
            first_button = discord.ui.Button(
                emoji=opts.cog.get_application_emoji("left-to-bracket"),
                label=_("Newest"),
                style=discord.ButtonStyle.grey,
                row=0,
            )
            first_button.callback = view._first_button_callback
            first_button.disabled = opts.page == 1
            view.add_item(first_button)

            back_button = discord.ui.Button(
                emoji=opts.cog.get_application_emoji("left"), label=_("Newer"), style=discord.ButtonStyle.gray, row=0
            )
            back_button.callback = view._back_button_callback
            back_button.disabled = opts.page == 1
            view.add_item(back_button)

            next_button = discord.ui.Button(
                emoji=opts.cog.get_application_emoji("right"), label=_("Older"), style=discord.ButtonStyle.gray, row=0
            )
            next_button.callback = view._next_button_callback
            next_button.disabled = opts.page == opts.total_page_count
            view.add_item(next_button)

            last_button = discord.ui.Button(
                emoji=opts.cog.get_application_emoji("right-to-bracket"),
                label=_("Oldest"),
                style=discord.ButtonStyle.gray,
                row=0,
            )
            last_button.callback = view._last_button_callback
            last_button.disabled = opts.page == opts.total_page_count
            view.add_item(last_button)

            jump_button = discord.ui.Button(label=_("Jump to Page"), style=discord.ButtonStyle.blurple, row=1)
            jump_button.callback = view._jump_button_callback
            view.add_item(jump_button)

        total_construction = time.perf_counter() - before_construction

        before_message = time.perf_counter()
        if message:
            view.message = await message.edit(embed=embed, view=view)
        elif opts.target_user:
            try:
                view.message = await opts.target_user.send(
                    content=_("{mention} sent you a moderation history menu.").format(mention=opts.ctx.author.mention),
                    embed=embed,
                    view=view,
                )
                await send_error(
                    opts.ctx,
                    content=_("Sent history menu to {mention}.").format(mention=opts.target_user.mention),
                    func=cf.success,
                )
            except (discord.HTTPException, discord.Forbidden):
                await send_error(
                    opts.ctx,
                    content=_(
                        "Couldn't send the history menu to {mention}. "
                        "They may have me blocked or have their direct messages closed."
                    ).format(mention=opts.target_user.mention),
                )
        else:
            view.message = await opts.ctx.send(embed=embed, view=view, ephemeral=opts.ephemeral)
        total_message = time.perf_counter() - before_message

        total = total_queries + total_construction + total_message
        total_moderation_time = sum(moderation_times.values())
        moderation_average = total_moderation_time / len(moderation_times)
        moderation_highest_id, moderation_highest_time = max(moderation_times.items(), key=lambda kv: kv[1], default=(0, 0))

        opts.cog._sentinel_logger.trace(  # noqa: SLF001
            (
                "History menu creation completed in %f seconds with %i moderations retrieved. "
                "Query time: '%f milliseconds' "
                "Moderation iteration time: '%f milliseconds' "
                "Longest moderation interaction: 'Moderation %i with %f milliseconds' "
                "Avg. time per moderation: '%f milliseconds' "
                "Message send time: '%f milliseconds'"
            ),
            total,  # intentionally kept as seconds
            len(moderations),
            seconds_to_milliseconds(total_queries),
            seconds_to_milliseconds(total_moderation_time),
            moderation_highest_id,
            seconds_to_milliseconds(moderation_highest_time),
            seconds_to_milliseconds(moderation_average),
            seconds_to_milliseconds(total_message),
        )

        return view

    @classmethod
    async def send(  # noqa: D417
        cls,
        *,
        cog: SentinelCog,
        ctx: commands.Context | discord.Interaction,
        targets: list[Targetable | PartialTargetable] | None = None,
        moderators: list[discord.abc.User | PartialUser] | None = None,
        on: date | None = None,
        before: datetime | None = None,
        after: datetime | None = None,
        expired: bool | None = None,
        external: bool | None = None,
        resolved: bool | None = None,
        types: Literal[True] | list[ModerationType | type[ModerationType]] | None = None,
        pagesize: Pagesize | None = None,
        page: int = 1,
        inline: bool | None = None,
        ephemeral: bool = True,
        target_user: discord.User | discord.Member | None = None,
    ) -> Self | discord.Message:
        """Create and send a paginated history menu with the given filters and options.

        Info:
            Some arguments of this function are intentionally undocumented. See the docstring of the
            [`sentinel_history`][tidegear.sentinel.cog.SentinelCog.sentinel_history] method for more information.

        Args:
            cog: The cog to use for fetching configuration settings and such.
            ctx: The context or interaction object to use.
            pagesize: How many moderaitons to include in the page.
            page: What page to start on. Similar to `offset`.
            inline: Whether or not to use inline embed fields.
            ephemeral: Whether or not the message should be ephemeral, if possible.
            target_user: The user to send the message to, instead of sending it in the current channel.

        Raises:
            ContextError: When used outside of a guild context.

        Returns:
            Either the created view, or a Message object corresponding to an error message.
        """
        await set_contextual_locales_from_guild(cog.bot, ctx.guild)

        if isinstance(ctx, discord.Interaction):
            ctx = await commands.Context.from_interaction(ctx)
        if not ctx.guild:
            msg = _("History can not be used outside of guild contexts.")
            raise ContextError(msg)
        ctx = cast(commands.GuildContext, ctx)

        if target_user:
            ephemeral = False

        if inline is None:
            inline = await cog.sentinel_config.get_member_config_with_fallback(
                cog.sentinel_config.history_inline, guild=ctx.guild, member=ctx.author
            )

        if pagesize is None:
            if inline is True:
                config = cog.sentinel_config.history_default_inline_pagesize
            else:
                config = cog.sentinel_config.history_default_pagesize
            pagesize = await cog.sentinel_config.get_member_config_with_fallback(config, guild=ctx.guild, member=ctx.author)
        else:  # make sure the value passed in is not violating constraints
            cog.sentinel_config.history_default_pagesize.validate_field("default", pagesize)

        opts = _HistoryOpts(
            cog=cog,
            ctx=ctx,
            targets=targets,
            moderators=moderators,
            on=on,
            # if `before` is not passed, default to the current time.
            # this fixes a potential issue with how we calculate moderation & page count later.
            # means each successive pagination cycle after the first one only has to query moderations, not count rows.
            before=before or utcnow(),
            after=after,
            expired=expired,
            external=external,
            resolved=resolved,
            types=types,
            pagesize=pagesize,
            page=page,
            inline=inline,
            ephemeral=ephemeral,
            target_user=target_user,
        )
        return await cls._send_opts(opts)


class _HistoryPageModal(discord.ui.Modal):
    page_input = discord.ui.TextInput(min_length=1, max_length=100, style=discord.TextStyle.short)

    def __init__(self, *, title: str, view: HistoryView, timeout: float = 180) -> None:
        super().__init__(title=title, timeout=timeout)
        self.view: HistoryView = view

    @override
    async def on_submit(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(thinking=False)

        try:
            string_value = self.page_input.value.replace(".", "").replace(",", "").rstrip()
            value = int(string_value)
        except ValueError:
            await send_error(
                interaction, content=_("`{input}` is not a valid number.").format(input=cf.escape(self.page_input.value))
            )
            return

        if value == self.view.opts.page:
            return
        if value > self.view.opts.total_page_count:
            await send_error(interaction, content=_("oops"))
            return
        if value < 1:
            await send_error(interaction, content=_("oops"))
            return

        self.view.opts.page = value

        await self.view._edit()  # noqa: SLF001
