# SPDX-FileCopyrightText: 2025 cswimr <copyright@csw.im>
# SPDX-License-Identifier: MPL-2.0

# ruff: noqa: E402

from tidegear._constants import Constants

constants = Constants

TRANSLATOR_COG_NAME = "TidegearCog"

from tidegear import chat_formatting
from tidegear import chat_formatting as cf
from tidegear.cog import Cog
from tidegear.version import __version__, meta, version

__all__ = [
    "__version__",
    "Cog",
    "Constants",
    "constants",
    "meta",
    "version",
    "chat_formatting",
    "cf",
    "TRANSLATOR_COG_NAME",
]
