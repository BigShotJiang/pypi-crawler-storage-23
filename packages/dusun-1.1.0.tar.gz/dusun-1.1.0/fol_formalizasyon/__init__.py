"""
fol_formalizasyon — FOL Lens (Lens #3 of 7).

First-order logic / axiom extraction instrument for the multi-lens
analytical apparatus defined in AGENTS.md §4.1.

  Lens: FOL | Faculty: — | Domain: First-order logic // axiom extraction

This lens provides:
  - A typed Formula AST for first-order logic
  - Complete registry of all 66 axioms (59 defined, 7 gap),
    18 theorems (15 defined, 3 gap), and 8 kavaid
  - Model checking for formula evaluation
  - Axiom reference extraction from text
  - Convergence scoring per KV₄ / T6

Public API:
  Types:       Sort, Variable, Constant, FunctionApplication, Term,
               Predicate, Formula, Atomic, Equals, Not, And, Or,
               Implies, ForAll, Exists, Axiom, Theorem, Kavaid
  Helpers:     is_well_formed, free_variables, formula_depth,
               SORT_CARDINALITY
  Registry:    get_axiom, get_theorem, get_kavaid,
               axioms_by_layer, axioms_by_tag,
               list_all_axioms, list_all_theorems, list_all_kavaid,
               defined_axiom_ids, gap_axiom_ids, gap_theorem_ids,
               theorem_dependencies, check_dependency_closure,
               INFERENCE_CHAINS, HUB_NODES
  Inference:   Model, ModelChecker, extract_axiom_refs,
               count_axiom_coverage, check_axiom_in_model,
               check_all_axioms, yakinlasma,
               verify_inference_chain, verify_all_chains,
               framework_summary
  Constraints: axiom_coverage, theorem_derivable, kavaid_all_pass,
               well_formed_formulas, fol_convergence_bound,
               sort_grounded, valid_fol_entry
"""

# Types
from fol_formalizasyon.types import (
    Sort, SORT_CARDINALITY,
    Variable, Constant, FunctionApplication, Term,
    Predicate,
    Atomic, Equals, Not, And, Or, Implies, ForAll, Exists,
    Formula,
    Axiom, Theorem, Kavaid,
    is_well_formed, free_variables, formula_depth,
)

# Registry
from fol_formalizasyon.axioms import (
    get_axiom, get_theorem, get_kavaid,
    axioms_by_layer, axioms_by_tag,
    list_all_axioms, list_all_theorems, list_all_kavaid,
    defined_axiom_ids, gap_axiom_ids, gap_theorem_ids,
    theorem_dependencies, check_dependency_closure,
    INFERENCE_CHAINS, HUB_NODES,
)

# Inference & Model Checking
from fol_formalizasyon.inference import (
    Model, ModelChecker,
    extract_axiom_refs, count_axiom_coverage,
    check_axiom_in_model, check_all_axioms,
    yakinlasma,
    verify_inference_chain, verify_all_chains,
    framework_summary,
)

# Constraints
from fol_formalizasyon.constraints import (
    axiom_coverage,
    theorem_derivable,
    kavaid_all_pass,
    well_formed_formulas,
    fol_convergence_bound,
    sort_grounded,
    valid_fol_entry,
)

__all__ = [
    # Types
    "Sort", "SORT_CARDINALITY",
    "Variable", "Constant", "FunctionApplication", "Term",
    "Predicate",
    "Atomic", "Equals", "Not", "And", "Or", "Implies", "ForAll", "Exists",
    "Formula",
    "Axiom", "Theorem", "Kavaid",
    "is_well_formed", "free_variables", "formula_depth",
    # Registry
    "get_axiom", "get_theorem", "get_kavaid",
    "axioms_by_layer", "axioms_by_tag",
    "list_all_axioms", "list_all_theorems", "list_all_kavaid",
    "defined_axiom_ids", "gap_axiom_ids", "gap_theorem_ids",
    "theorem_dependencies", "check_dependency_closure",
    "INFERENCE_CHAINS", "HUB_NODES",
    # Inference
    "Model", "ModelChecker",
    "extract_axiom_refs", "count_axiom_coverage",
    "check_axiom_in_model", "check_all_axioms",
    "yakinlasma",
    "verify_inference_chain", "verify_all_chains",
    "framework_summary",
    # Constraints
    "axiom_coverage",
    "theorem_derivable",
    "kavaid_all_pass",
    "well_formed_formulas",
    "fol_convergence_bound",
    "sort_grounded",
    "valid_fol_entry",
]
