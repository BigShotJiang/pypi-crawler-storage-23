"""
bileshke — Composite Convergence Engine (Phase D).

Formula: bileshke(t) = Σᵢ wᵢ · yakinlasma(mᵢ, t), Σwᵢ = 1, result ∈ [0, 1)

Combines all 7 lens yakinlasma scores into a single composite
convergence score with full quality assessment (Q-1..Q-4).

Key constraints:
  T6/KV₄: composite < 1.0 (strict)
  AX52:    multiplicative gate — zero in any dimension collapses the gate
  AX53:    Ahfâ permanently unmapped
  AX55:    dual coverage gate (latife₆ ∧ medium₃)
  AX56:    max grade = İlmelyakîn
  T17:     max completeness = 6/7
  KV₇:     no imports from individual lens packages
"""

# --- types ---
from bileshke.types import (
    clamp_score,
    Latife,
    Ortam,
    EpistemicGrade,
    LensId,
    TESCIL,
    LENS_TO_LATIFE,
    LENS_PACKAGE,
    LENS_ORDER,
    ALL_LATIFELER,
    ALL_ORTAM,
    NUM_LATIFELER,
    NUM_ORTAM,
    NUM_LENSES,
    MAX_ACCESSIBLE_LATIFE,
    MAX_COMPLETENESS_RATIO,
    LatifeVektor,
    OrtamVektor,
    LensResult,
    QualityReport,
    LensCorrelation,
    FunnelDiagnostic,
)

# --- engine ---
from bileshke.engine import (
    DEFAULT_WEIGHTS,
    validate_weights,
    bileshke,
    compute_latife_vektor,
    compute_coverage_gate,
    detect_kv4_warning,
    compute_aggregate_grade,
    run_bileshke,
    white_light_summary,
    compute_funnel_diagnostic,
    validate_lens_independence,
)

# --- quality ---
from bileshke.quality import (
    ALL_KAVAID,
    KAVAID_DESCRIPTIONS,
    compute_q1_coverage,
    compute_q2_epistemic,
    compute_q3_kavaid,
    compute_q4_completeness,
    build_quality_report,
    framework_summary,
)

__all__ = [
    # types
    "clamp_score",
    "Latife",
    "Ortam",
    "EpistemicGrade",
    "LensId",
    "TESCIL",
    "LENS_TO_LATIFE",
    "LENS_PACKAGE",
    "LENS_ORDER",
    "ALL_LATIFELER",
    "ALL_ORTAM",
    "NUM_LATIFELER",
    "NUM_ORTAM",
    "NUM_LENSES",
    "MAX_ACCESSIBLE_LATIFE",
    "MAX_COMPLETENESS_RATIO",
    "LatifeVektor",
    "OrtamVektor",
    "LensResult",
    "QualityReport",
    "LensCorrelation",
    "FunnelDiagnostic",
    # engine
    "DEFAULT_WEIGHTS",
    "validate_weights",
    "bileshke",
    "compute_latife_vektor",
    "compute_coverage_gate",
    "detect_kv4_warning",
    "compute_aggregate_grade",
    "run_bileshke",
    "white_light_summary",
    "compute_funnel_diagnostic",
    "validate_lens_independence",
    # quality
    "ALL_KAVAID",
    "KAVAID_DESCRIPTIONS",
    "compute_q1_coverage",
    "compute_q2_epistemic",
    "compute_q3_kavaid",
    "compute_q4_completeness",
    "build_quality_report",
    "framework_summary",
]
