"""
tests/test_hcp — Test suite for the Holographic Context Protocol.

Tests organized by framework compliance:
  1. Type construction and constraints (KV₄, KV₆, AX52)
  2. Seed computation (AX2–4, AX37, AX12–13)
  3. Attention simulation (flat baseline, holographic improvement)
  4. Protocol pipeline (AX5 integration prerequisite)
  5. Benchmark (needle-in-haystack)
  6. Structural incompleteness (T17, AX56, AX58)
"""

import math
import pytest
from typing import List

from hcp.types import (
    AttentionProfile,
    BenchmarkResult,
    ContentType,
    ContextChunk,
    HCPConfig,
    HolographicSeed,
    RetrievalResult,
    SeededChunk,
    CONTENT_TYPE_COUNT,
    clamp_score,
)
from hcp.seed import (
    classify_content,
    compute_seed,
    extract_keywords,
)
from hcp.attention import (
    flat_attention,
    holographic_attention,
    attention_improvement,
)
from hcp.protocol import HCPProtocol
from hcp.benchmark import (
    NeedleInHaystack,
    generate_haystack,
    run_quick_benchmark,
)


# ===========================================================================
# Helpers
# ===========================================================================

def make_chunks(n: int, content_fn=None) -> List[ContextChunk]:
    """Create n test chunks with default or custom content."""
    if content_fn is None:
        content_fn = lambda i: f"This is chunk number {i} with some filler content."
    return [
        ContextChunk(content=content_fn(i), position=i)
        for i in range(n)
    ]


def make_structured_chunks() -> List[ContextChunk]:
    """Create a set of chunks with diverse structural types."""
    return [
        ContextChunk(
            content="You must always validate input data before processing.",
            position=0,
            content_type=ContentType.INSTRUCTION,
        ),
        ContextChunk(
            content="The maximum request payload must not exceed four megabytes.",
            position=1,
            content_type=ContentType.CONSTRAINT,
        ),
        ContextChunk(
            content="The API gateway handles routing for all microservices.",
            position=2,
            content_type=ContentType.NARRATIVE,
        ),
        ContextChunk(
            content="The critical security token is HOLO-7X9K and must be rotated.",
            position=3,
            content_type=ContentType.FACT,
        ),
        ContextChunk(
            content="The API gateway depends on the authentication service.",
            position=4,
            content_type=ContentType.RELATIONSHIP,
        ),
        ContextChunk(
            content="The system processes requests in parallel batches.",
            position=5,
            content_type=ContentType.NARRATIVE,
        ),
        ContextChunk(
            content="Section 3: Configuration Parameters and Settings.",
            position=6,
            content_type=ContentType.METADATA,
        ),
        ContextChunk(
            content="AuthService is defined as the central identity provider.",
            position=7,
            content_type=ContentType.ENTITY,
        ),
    ]


# ===========================================================================
# 1. Type Construction and Constraints
# ===========================================================================

class TestTypes:
    """Test type construction enforces framework constraints."""

    def test_clamp_score_bounds(self):
        """KV₄: scores bounded in [0, 0.9999]."""
        assert clamp_score(-0.5) == 0.0
        assert clamp_score(0.5) == 0.5
        assert clamp_score(1.0) == 0.9999
        assert clamp_score(1.5) == 0.9999
        assert clamp_score(0.0) == 0.0
        assert clamp_score(0.9999) == 0.9999

    def test_content_type_count(self):
        """7 content types per convergent funnel (∞ → 7 → 1)."""
        assert CONTENT_TYPE_COUNT == 7
        assert len(ContentType) == 7

    def test_context_chunk_creation(self):
        """ContextChunk requires non-negative position."""
        chunk = ContextChunk(content="test", position=0)
        assert chunk.position == 0
        assert chunk.content_type == ContentType.NARRATIVE

        with pytest.raises(ValueError):
            ContextChunk(content="test", position=-1)

    def test_holographic_seed_validation(self):
        """HolographicSeed validates type_signature length."""
        # Valid
        seed = HolographicSeed(
            n_chunks=3,
            type_signature=(0.2, 0.1, 0.3, 0.1, 0.1, 0.1, 0.1),
            instruction_positions=(0,),
            constraint_positions=(1,),
            entity_positions={},
            structural_links=(),
            global_keywords=("test",),
            position_importance=(0.5, 0.3, 0.2),
        )
        assert seed.n_chunks == 3

        # Invalid: wrong type_signature length
        with pytest.raises(ValueError):
            HolographicSeed(
                n_chunks=3,
                type_signature=(0.5, 0.5),  # Only 2, need 7
                instruction_positions=(),
                constraint_positions=(),
                entity_positions={},
                structural_links=(),
                global_keywords=(),
                position_importance=(0.5, 0.3, 0.2),
            )

        # Invalid: position_importance length mismatch
        with pytest.raises(ValueError):
            HolographicSeed(
                n_chunks=3,
                type_signature=(0.2, 0.1, 0.3, 0.1, 0.1, 0.1, 0.1),
                instruction_positions=(),
                constraint_positions=(),
                entity_positions={},
                structural_links=(),
                global_keywords=(),
                position_importance=(0.5, 0.3),  # 2, need 3
            )

    def test_seed_properties(self):
        """Seed computed properties work correctly."""
        seed = HolographicSeed(
            n_chunks=3,
            type_signature=(0.3, 0.1, 0.2, 0.1, 0.1, 0.1, 0.1),
            instruction_positions=(0,),
            constraint_positions=(1,),
            entity_positions={},
            structural_links=(),
            global_keywords=("test",),
            position_importance=(0.8, 0.5, 0.2),
        )
        assert seed.instruction_density == 0.3
        assert seed.constraint_density == 0.1
        assert seed.has_structure  # At least one non-zero importance
        assert 0 < seed.coverage_ratio < 1.0  # KV₄ compliant

    def test_attention_profile_entropy(self):
        """AttentionProfile entropy measures uniformity."""
        # Uniform distribution: maximum entropy
        uniform = AttentionProfile(weights=(0.25, 0.25, 0.25, 0.25))
        assert uniform.entropy == pytest.approx(2.0, abs=0.01)

        # Peaked distribution: lower entropy
        peaked = AttentionProfile(weights=(0.9, 0.03, 0.03, 0.04))
        assert peaked.entropy < uniform.entropy

    def test_seeded_chunk_clamps(self):
        """SeededChunk clamps local_importance per KV₄."""
        chunk = ContextChunk(content="test", position=0)
        seed = HolographicSeed(
            n_chunks=1,
            type_signature=(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0),
            instruction_positions=(),
            constraint_positions=(),
            entity_positions={},
            structural_links=(),
            global_keywords=(),
            position_importance=(0.5,),
        )
        sc = SeededChunk(chunk=chunk, seed=seed, local_importance=1.5)
        assert sc.local_importance <= 0.9999

    def test_retrieval_result_properties(self):
        """RetrievalResult correctly computes improvement and position."""
        result = RetrievalResult(
            needle_position=15,
            n_chunks=30,
            flat_rank=20,
            holographic_rank=5,
            flat_attention_at_needle=0.01,
            holographic_attention_at_needle=0.05,
        )
        assert result.improvement == 15
        assert result.relative_position == pytest.approx(0.517, abs=0.01)
        assert result.is_middle


# ===========================================================================
# 2. Seed Computation
# ===========================================================================

class TestSeedComputation:
    """Test seed computation implements Phase 1–2 correctly."""

    def test_classify_instruction(self):
        """Instructions classified correctly (harfî mode, KV₁)."""
        result = classify_content("You must always validate input before processing.")
        assert result == ContentType.INSTRUCTION

    def test_classify_constraint(self):
        """Constraints classified correctly."""
        result = classify_content("The maximum payload must not exceed 4 MB.")
        assert result == ContentType.CONSTRAINT

    def test_classify_relationship(self):
        """Relationships classified correctly."""
        result = classify_content("The gateway depends on the auth service.")
        assert result == ContentType.RELATIONSHIP

    def test_classify_fact(self):
        """Facts with metrics classified correctly."""
        result = classify_content("Performance measured at 200ms p99 latency according to benchmarks.")
        assert result == ContentType.FACT

    def test_classify_narrative_default(self):
        """Ambiguous content defaults to NARRATIVE."""
        result = classify_content("The sky looked particularly blue today.")
        assert result == ContentType.NARRATIVE

    def test_classify_empty(self):
        """Empty content defaults to NARRATIVE."""
        result = classify_content("")
        assert result == ContentType.NARRATIVE

    def test_extract_keywords(self):
        """Keyword extraction returns non-stop-words."""
        text = "The holographic seed protocol computes structural information."
        kws = extract_keywords(text, top_k=5)
        assert len(kws) > 0
        assert all(len(kw) >= 3 for kw in kws)
        # Stop words should not be in keywords
        assert "the" not in kws

    def test_compute_seed_basic(self):
        """Seed computation produces valid seed from chunks."""
        chunks = make_chunks(10)
        seed = compute_seed(chunks)

        assert seed.n_chunks == 10
        assert len(seed.type_signature) == CONTENT_TYPE_COUNT
        assert abs(sum(seed.type_signature) - 1.0) < 0.01  # Normalized
        assert len(seed.position_importance) == 10
        assert all(0 <= w <= 0.9999 for w in seed.position_importance)

    def test_compute_seed_structured(self):
        """Seed computation captures structural types correctly."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)

        assert seed.n_chunks == 8
        assert len(seed.instruction_positions) >= 1
        assert len(seed.constraint_positions) >= 1

    def test_compute_seed_empty_raises(self):
        """Empty chunks raise ValueError."""
        with pytest.raises(ValueError):
            compute_seed([])

    def test_seed_type_signature_sums_to_one(self):
        """Type signature is a proper distribution."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        total = sum(seed.type_signature)
        assert abs(total - 1.0) < 0.01

    def test_seed_position_importance_bounded(self):
        """KV₄: All position importance values in [0, 0.9999]."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        for w in seed.position_importance:
            assert 0 <= w <= 0.9999

    def test_seed_has_structure(self):
        """KV₆: seed is always non-trivial."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        assert seed.has_structure

    def test_seed_coverage_bounded(self):
        """KV₄: coverage ratio < 1.0."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        assert 0 < seed.coverage_ratio < 1.0


# ===========================================================================
# 3. Attention Simulation
# ===========================================================================

class TestAttention:
    """Test flat and holographic attention models."""

    def test_flat_attention_u_shape(self):
        """Flat attention exhibits U-shaped bias: middle < edges."""
        profile = flat_attention(30)
        assert profile.mode == "flat"
        assert len(profile.weights) == 30

        # Middle attention should be lower than edge attention
        assert profile.middle_attention < profile.edge_attention

    def test_flat_attention_normalized(self):
        """Flat attention weights sum to approximately 1.0."""
        profile = flat_attention(20)
        total = sum(profile.weights)
        assert abs(total - 1.0) < 0.01

    def test_flat_attention_bounded(self):
        """KV₄: all flat attention weights in [0, 0.9999]."""
        profile = flat_attention(50)
        for w in profile.weights:
            assert 0 <= w <= 0.9999

    def test_flat_attention_empty(self):
        """Flat attention with 0 positions returns empty."""
        profile = flat_attention(0)
        assert len(profile.weights) == 0

    def test_holographic_attention_reduces_u_shape(self):
        """CORE TEST: Holographic attention reduces U-shaped bias.

        The holographic seed should boost middle positions, reducing
        the gap between middle and edge attention.
        """
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        n = len(chunks)

        flat = flat_attention(n)
        holo = holographic_attention(n, seed=seed)

        # Holographic should have higher middle attention than flat
        # (or at least smaller edge/middle ratio)
        flat_ratio = flat.edge_attention / max(flat.middle_attention, 0.001)
        holo_ratio = holo.edge_attention / max(holo.middle_attention, 0.001)

        # Holographic ratio should be closer to 1 (more uniform)
        assert holo_ratio <= flat_ratio + 0.5  # Allow some tolerance

    def test_holographic_attention_boosts_instructions(self):
        """Holographic attention boosts instruction positions."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        n = len(chunks)

        holo = holographic_attention(n, seed=seed)
        flat = flat_attention(n)

        # Instruction at position 0 should get attention boost
        for pos in seed.instruction_positions:
            if pos < n:
                holo_w = holo.weights[pos]
                flat_w = flat.weights[pos]
                # Holographic should give at least as much attention
                # to instructions (likely more)
                assert holo_w >= flat_w * 0.8  # Allow small tolerance

    def test_holographic_attention_keyword_boost(self):
        """Holographic attention boosts positions matching query keywords."""
        chunks = [
            ContextChunk(content="General filler content here.", position=0),
            ContextChunk(
                content="The security token must be rotated every ninety days.",
                position=1,
                content_type=ContentType.FACT,
                keywords=("security", "token", "rotated"),
            ),
            ContextChunk(content="More general filler content.", position=2),
        ]
        seed = compute_seed(chunks)

        holo = holographic_attention(
            3, seed=seed,
            query_keywords=("security", "token"),
        )
        flat = flat_attention(3)

        # Position 1 (containing needle keywords) should get boosted
        # relative to its flat attention
        # Note: with only 3 chunks, the U-shape effect is minimal,
        # but the keyword boost should still be present
        assert holo.weights[1] > 0  # Non-zero attention on keyword match

    def test_holographic_attention_bounded(self):
        """KV₄: all holographic attention weights in [0, 0.9999]."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        holo = holographic_attention(len(chunks), seed=seed)
        for w in holo.weights:
            assert 0 <= w <= 0.9999

    def test_attention_improvement_positive_for_middle(self):
        """Improvement ratio > 1.0 for middle positions with structural content."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        n = len(chunks)

        flat = flat_attention(n)
        holo = holographic_attention(n, seed=seed)

        # Find a position with high structural importance
        important_positions = [
            i for i in range(n)
            if seed.position_importance[i] > 0.5
        ]

        # At least one important position should see improvement
        if important_positions:
            improvements = [
                attention_improvement(flat, holo, pos)
                for pos in important_positions
            ]
            assert max(improvements) > 0


# ===========================================================================
# 4. Protocol Pipeline
# ===========================================================================

class TestProtocol:
    """Test the full HCPProtocol pipeline."""

    def test_ingest_text(self):
        """Protocol ingests text and produces seed."""
        protocol = HCPProtocol()
        text = """
        You must always validate input before processing requests.

        The maximum payload size must not exceed 4 megabytes.

        The API gateway routes traffic to backend services efficiently.

        The critical security token is HOLO-7X9K-SEED-2024 and must be
        rotated every ninety days without exception.

        Database connections are pooled for performance optimization.

        The authentication service validates all incoming bearer tokens.
        """
        seed = protocol.ingest(text)

        assert protocol.is_ready
        assert seed.n_chunks > 0
        assert len(protocol.seeded_chunks) == seed.n_chunks

    def test_ingest_chunks(self):
        """Protocol ingests pre-built chunks."""
        protocol = HCPProtocol()
        chunks = make_structured_chunks()
        seed = protocol.ingest_chunks(chunks)

        assert protocol.is_ready
        assert seed.n_chunks == len(chunks)

    def test_query_returns_results(self):
        """Query returns ranked results."""
        protocol = HCPProtocol()
        chunks = make_structured_chunks()
        protocol.ingest_chunks(chunks)

        results = protocol.query("What is the security token?")
        assert len(results) > 0
        assert all(isinstance(r[0], SeededChunk) for r in results)
        assert all(isinstance(r[1], float) for r in results)

    def test_query_before_ingest_raises(self):
        """Query before ingestion raises RuntimeError."""
        protocol = HCPProtocol()
        with pytest.raises(RuntimeError):
            protocol.query("test")

    def test_compare_attention(self):
        """Compare returns both attention profiles."""
        protocol = HCPProtocol()
        chunks = make_structured_chunks()
        protocol.ingest_chunks(chunks)

        flat, holo = protocol.compare_attention("What is the constraint?")
        assert flat.mode == "flat"
        assert holo.mode == "holographic"
        assert len(flat.weights) == len(holo.weights)

    def test_diagnostics(self):
        """Diagnostics reports state (AX57 transparency)."""
        protocol = HCPProtocol()
        diag = protocol.diagnostics()
        assert diag["status"] == "not_ready"

        chunks = make_structured_chunks()
        protocol.ingest_chunks(chunks)
        diag = protocol.diagnostics()
        assert diag["status"] == "ready"
        assert diag["n_chunks"] == len(chunks)
        assert "type_distribution" in diag
        assert "coverage_ratio" in diag

    def test_seed_omnipresence(self):
        """KV₆: Every seeded chunk has a seed."""
        protocol = HCPProtocol()
        chunks = make_structured_chunks()
        protocol.ingest_chunks(chunks)

        for sc in protocol.seeded_chunks:
            assert sc.seed is not None
            assert sc.seed.has_structure

    def test_seed_broadcast_identical(self):
        """AX37: The SAME seed is broadcast to every chunk."""
        protocol = HCPProtocol()
        chunks = make_structured_chunks()
        protocol.ingest_chunks(chunks)

        seeds = [sc.seed for sc in protocol.seeded_chunks]
        # All seeds should be the same object or equal
        first = seeds[0]
        for s in seeds[1:]:
            assert s.n_chunks == first.n_chunks
            assert s.type_signature == first.type_signature
            assert s.global_keywords == first.global_keywords


# ===========================================================================
# 5. Benchmark
# ===========================================================================

class TestBenchmark:
    """Test the needle-in-haystack benchmark."""

    def test_generate_haystack(self):
        """Haystack generation places needle correctly."""
        chunks, pos = generate_haystack(
            n_chunks=20,
            needle_content="The secret key is ABC-123.",
            needle_position=10,
        )
        assert len(chunks) == 20
        assert pos == 10
        assert "secret key" in chunks[10].content

    def test_quick_benchmark_runs(self):
        """Quick benchmark completes without errors."""
        result = run_quick_benchmark(n_chunks=15)
        assert isinstance(result, BenchmarkResult)
        assert len(result.results) == 5

    def test_benchmark_full(self):
        """Full benchmark across all positions completes."""
        bench = NeedleInHaystack(n_chunks=10)
        result = bench.run()
        assert len(result.results) == 10

    def test_benchmark_middle_only(self):
        """Middle-only benchmark targets correct positions."""
        bench = NeedleInHaystack(n_chunks=30)
        result = bench.run_middle_only()
        for r in result.results:
            assert r.is_middle or r.relative_position >= 0.30

    def test_benchmark_holographic_improves_middle(self):
        """CORE TEST: Holographic attention improves middle-position retrieval.

        This is the central claim of HCP: the holographic seed should
        improve retrieval of needles buried in the middle of context,
        where flat attention (U-shaped bias) performs worst.
        """
        bench = NeedleInHaystack(n_chunks=30)
        result = bench.run_middle_only()

        # Average holographic rank should be better (lower) than flat
        # for middle positions
        flat_ranks = [r.flat_rank for r in result.results]
        holo_ranks = [r.holographic_rank for r in result.results]

        avg_flat = sum(flat_ranks) / max(len(flat_ranks), 1)
        avg_holo = sum(holo_ranks) / max(len(holo_ranks), 1)

        # Holographic should have lower average rank (better retrieval)
        assert avg_holo <= avg_flat + 2  # Allow small tolerance

    def test_benchmark_result_properties(self):
        """BenchmarkResult computed properties are correct."""
        result = run_quick_benchmark(n_chunks=15)
        assert result.flat_mean_rank > 0
        assert result.holographic_mean_rank > 0
        assert 0 <= result.flat_top1_rate <= 0.9999
        assert 0 <= result.holographic_top1_rate <= 0.9999


# ===========================================================================
# 6. Structural Incompleteness (T17, AX56, AX58)
# ===========================================================================

class TestStructuralIncompleteness:
    """Test that the implementation correctly honors structural bounds."""

    def test_t17_coverage_bound(self):
        """T17: Coverage ≤ 6/7 — seed never claims complete coverage."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)
        # Coverage ratio must be strictly less than 1.0
        assert seed.coverage_ratio < 1.0

    def test_kv4_convergence_bound(self):
        """KV₄: All convergence scores strictly < 1.0."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)

        # All position_importance values bounded
        for w in seed.position_importance:
            assert w < 1.0

        # Coverage ratio bounded
        assert seed.coverage_ratio < 1.0

    def test_kv4_convergence_positive(self):
        """KV₄: Convergence > 0 — genuine participation in truth."""
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)

        # At least some structure detected
        assert any(w > 0 for w in seed.position_importance)
        assert seed.coverage_ratio > 0

    def test_kv6_seed_omnipresence(self):
        """KV₆: Every module has holographic seed > 0."""
        protocol = HCPProtocol()
        chunks = make_structured_chunks()
        protocol.ingest_chunks(chunks)

        for sc in protocol.seeded_chunks:
            assert sc.seed.has_structure

    def test_kv7_independence(self):
        """KV₇: Seed computation is independent of query processing."""
        protocol = HCPProtocol()
        chunks = make_structured_chunks()
        protocol.ingest_chunks(chunks)

        # Store seed before query
        seed_before = protocol.seed.position_importance

        # Run a query
        protocol.query("What is the security token?")

        # Seed should be unchanged (query doesn't modify seed)
        seed_after = protocol.seed.position_importance
        assert seed_before == seed_after

    def test_ax52_multiplicative_gate(self):
        """AX52: Zero in any dimension means structural failure detection.

        If the type_signature has a zero (a content type not present),
        that's a legitimate structural observation, not something to smooth.
        """
        # Create chunks with only one type
        chunks = make_chunks(5)
        seed = compute_seed(chunks)

        # Some type_signature components may be zero — that's correct
        # The gate detects this, doesn't smooth it (M2: measure wounds)
        zero_count = sum(1 for v in seed.type_signature if v == 0)
        # With homogeneous content, most types will be zero
        assert zero_count >= 0  # Always true, but documents the constraint

    def test_ne_ayn_ne_gayr(self):
        """T14: 0 < fidelity < 1 — seed participates in truth, ≠ identity.

        The seed is genuinely informative (> 0) but never perfectly
        captures the context (< 1).  This is the core ne ayn ne gayr
        principle applied to context encoding.
        """
        chunks = make_structured_chunks()
        seed = compute_seed(chunks)

        # Seed is non-trivial
        avg_importance = sum(seed.position_importance) / len(seed.position_importance)
        assert avg_importance > 0  # Genuine participation

        # But no single importance = 1.0 (never identity)
        for w in seed.position_importance:
            assert w < 1.0  # Bounded below supremum
