"""
bayes_analiz — Bayes Lens (Lens #4 of 7).

Bayesian inference / probability update instrument for the multi-lens
analytical apparatus defined in AGENTS.md §4.1.

  Lens: Bayes | Faculty: Kalb | Domain: Bayesian inference / probability update

Public API:
  Types:        Hypothesis, Evidence, PosteriorEntry, BayesModel,
                EvidenceType, HypothesisStatus, CompositionMode, clamp_score
  Verification: check_prior_normalisation, check_likelihood_validity,
                check_evidence_independence, check_posterior_consistency,
                check_convergence_bound, check_tesanud_infirad,
                check_hypothesis_coverage, check_transparency,
                verify_all, yakinlasma, framework_summary
  Constraints:  valid_priors, valid_likelihoods, evidence_independence,
                posterior_consistency, convergence_bound, tesanud_infirad,
                model_transparency, bayes_convergence_score,
                valid_bayes_entry
"""

from bayes_analiz.types import (
    BayesModel,
    CompositionMode,
    Evidence,
    EvidenceType,
    Hypothesis,
    HypothesisStatus,
    PosteriorEntry,
    clamp_score,
)
from bayes_analiz.verification import (
    check_convergence_bound,
    check_evidence_independence,
    check_hypothesis_coverage,
    check_likelihood_validity,
    check_posterior_consistency,
    check_prior_normalisation,
    check_tesanud_infirad,
    check_transparency,
    framework_summary,
    verify_all,
    yakinlasma,
)
from bayes_analiz.constraints import (
    bayes_convergence_score,
    convergence_bound,
    evidence_independence,
    model_transparency,
    posterior_consistency,
    tesanud_infirad,
    valid_bayes_entry,
    valid_likelihoods,
    valid_priors,
)

__all__ = [
    # Types
    "Hypothesis",
    "Evidence",
    "PosteriorEntry",
    "BayesModel",
    "EvidenceType",
    "HypothesisStatus",
    "CompositionMode",
    "clamp_score",
    # Verification
    "check_prior_normalisation",
    "check_likelihood_validity",
    "check_evidence_independence",
    "check_posterior_consistency",
    "check_convergence_bound",
    "check_tesanud_infirad",
    "check_hypothesis_coverage",
    "check_transparency",
    "verify_all",
    "yakinlasma",
    "framework_summary",
    # Constraints
    "valid_priors",
    "valid_likelihoods",
    "evidence_independence",
    "posterior_consistency",
    "convergence_bound",
    "tesanud_infirad",
    "model_transparency",
    "bayes_convergence_score",
    "valid_bayes_entry",
]
