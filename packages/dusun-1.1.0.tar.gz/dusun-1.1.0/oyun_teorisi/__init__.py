"""
oyun_teorisi — Game Theory Lens (Lens #5 of 7).

Game-theoretic / strategic interaction instrument for the multi-lens
analytical apparatus defined in AGENTS.md §4.1.

  Lens: OyunTeorisi | Faculty: Nefs | Domain: Game theory // strategic interaction

Public API:
  Types:        NefsMakam, StrategyType, CompositionMode, Strategy, Player,
                PayoffEntry, GameOutcome, GameModel, MAKAM_ORDER, clamp_score
  Verification: check_station_validity, check_payoff_transformation,
                check_strategy_completeness, check_nash_consistency,
                check_convergence_bound, check_tesanud_infirad,
                check_independence, check_transparency,
                verify_all, yakinlasma, framework_summary
  Constraints:  station_validity, payoff_transformation,
                strategy_completeness, nash_consistency,
                game_convergence_bound, tesanud_infirad_asymmetry,
                game_independence, game_transparency,
                game_convergence_score, valid_game_entry
"""

from oyun_teorisi.types import (
    CompositionMode,
    GameModel,
    GameOutcome,
    MAKAM_ORDER,
    NefsMakam,
    PayoffEntry,
    Player,
    Strategy,
    StrategyType,
    clamp_score,
)
from oyun_teorisi.verification import (
    check_convergence_bound,
    check_independence,
    check_nash_consistency,
    check_payoff_transformation,
    check_station_validity,
    check_strategy_completeness,
    check_tesanud_infirad,
    check_transparency,
    framework_summary,
    verify_all,
    yakinlasma,
)
from oyun_teorisi.constraints import (
    game_convergence_bound,
    game_convergence_score,
    game_independence,
    game_transparency,
    nash_consistency,
    payoff_transformation,
    station_validity,
    strategy_completeness,
    tesanud_infirad_asymmetry,
    valid_game_entry,
)

__all__ = [
    # Types
    "NefsMakam",
    "StrategyType",
    "CompositionMode",
    "Strategy",
    "Player",
    "PayoffEntry",
    "GameOutcome",
    "GameModel",
    "MAKAM_ORDER",
    "clamp_score",
    # Verification
    "check_station_validity",
    "check_payoff_transformation",
    "check_strategy_completeness",
    "check_nash_consistency",
    "check_convergence_bound",
    "check_tesanud_infirad",
    "check_independence",
    "check_transparency",
    "verify_all",
    "yakinlasma",
    "framework_summary",
    # Constraints
    "station_validity",
    "payoff_transformation",
    "strategy_completeness",
    "nash_consistency",
    "game_convergence_bound",
    "tesanud_infirad_asymmetry",
    "game_independence",
    "game_transparency",
    "game_convergence_score",
    "valid_game_entry",
]
