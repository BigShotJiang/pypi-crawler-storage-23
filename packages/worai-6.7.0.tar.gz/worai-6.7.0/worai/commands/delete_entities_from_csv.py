"""CLI wrapper for delete-entities-from-csv."""

from __future__ import annotations

import typer

from worai.core.delete_entities_from_csv import DeleteEntitiesOptions, delete_entities
from worai.core.profile_loader import resolve_profile_api_key
from worai.errors import UsageError

app = typer.Typer(add_completion=False, no_args_is_help=True, invoke_without_command=True)


@app.callback(invoke_without_command=True)
def run(
    ctx: typer.Context,
    csv_file: str = typer.Argument(..., help="CSV file with IRIs (first column)."),
    batch_size: int = typer.Option(10, "--batch-size", help="Number of IRIs to delete per batch."),
) -> None:
    try:
        api_key, _, _ = resolve_profile_api_key(ctx)
    except ValueError as exc:
        raise UsageError(str(exc)) from exc
    if not api_key:
        raise UsageError("WORDLIFT_API_KEY is required (or set profiles.<name>.api_key in config).")

    options = DeleteEntitiesOptions(api_key=api_key, csv_file=csv_file, batch_size=batch_size)
    delete_entities(options)
