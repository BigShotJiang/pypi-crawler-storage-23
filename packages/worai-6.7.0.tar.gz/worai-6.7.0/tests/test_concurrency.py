from __future__ import annotations

import pytest

from worai.core.concurrency import classify_status_bucket, parse_concurrency
from worai.errors import UsageError


def test_parse_concurrency_fixed() -> None:
    settings = parse_concurrency("3")
    assert settings.mode == "fixed"
    assert settings.workers == 3
    assert settings.next_workers(["ok"]) == 3


def test_parse_concurrency_auto() -> None:
    settings = parse_concurrency(
        "auto",
        auto_default_workers=4,
        auto_min_workers=2,
        auto_max_workers=8,
    )
    assert settings.mode == "auto"
    assert settings.workers == 4
    assert settings.next_workers(["ok"]) == 5
    assert settings.next_workers(["throttle"]) == 3


def test_parse_concurrency_invalid() -> None:
    with pytest.raises(UsageError):
        parse_concurrency("invalid")
    with pytest.raises(UsageError):
        parse_concurrency("0")


def test_classify_status_bucket() -> None:
    assert classify_status_bucket(200) == "ok"
    assert classify_status_bucket(429) == "throttle"
    assert classify_status_bucket(503) == "server_error"
    assert classify_status_bucket(404) == "client_error"
    assert classify_status_bucket(None) == "error"
    assert classify_status_bucket(200, had_error=True) == "error"
