"""Unit tests for @waxell_agent decorator."""

import pytest
import httpx
import respx

from waxell_observe.client import WaxellObserveClient
from waxell_observe.decorator import waxell_agent


BASE_URL = "http://test.waxell.dev"


@pytest.fixture
def client():
    """Pre-configured test client."""
    return WaxellObserveClient(api_url=BASE_URL, api_key="wax_sk_test123")


@pytest.fixture
def mock_lifecycle():
    """Mock all observe lifecycle endpoints."""
    with respx.mock:
        respx.post(f"{BASE_URL}/api/v1/observe/policy-check/").mock(
            return_value=httpx.Response(200, json={"action": "allow", "reason": ""})
        )
        respx.post(f"{BASE_URL}/api/v1/observe/runs/start/").mock(
            return_value=httpx.Response(
                201,
                json={
                    "run_id": "run-dec-1",
                    "workflow_id": "wf-1",
                    "started_at": "2026-01-01T00:00:00Z",
                },
            )
        )
        respx.post(url__regex=r".*/runs/.*/llm-calls/$").mock(
            return_value=httpx.Response(
                202, json={"recorded": 1, "governance": {"action": "allow"}}
            )
        )
        respx.post(url__regex=r".*/runs/.*/steps/$").mock(
            return_value=httpx.Response(
                202, json={"recorded": 1, "governance": {"action": "allow"}}
            )
        )
        respx.post(url__regex=r".*/runs/.*/complete/$").mock(
            return_value=httpx.Response(
                200, json={"run_id": "run-dec-1", "duration": 1.0}
            )
        )
        respx.post(url__regex=r".*/runs/.*/spans/$").mock(
            return_value=httpx.Response(202, json={"recorded": 1})
        )
        yield


class TestAsyncDecorator:
    @pytest.mark.asyncio
    async def test_async_decorator(self, client, mock_lifecycle):
        """Async decorated function returns its value and makes HTTP calls."""

        @waxell_agent(agent_name="test-dec", client=client, enforce_policy=False)
        async def my_agent(query: str) -> str:
            return f"result for {query}"

        result = await my_agent("hello")

        assert result == "result for hello"

        # Verify HTTP calls were made (start + complete at minimum)
        start_calls = [c for c in respx.calls if "/runs/start/" in str(c.request.url)]
        complete_calls = [c for c in respx.calls if "/complete/" in str(c.request.url)]
        assert len(start_calls) == 1
        assert len(complete_calls) == 1


class TestSyncDecorator:
    def test_sync_decorator(self, client, mock_lifecycle):
        """Sync decorated function returns its value."""

        @waxell_agent(agent_name="test-sync", client=client, enforce_policy=False)
        def my_agent(query: str) -> str:
            return f"sync result for {query}"

        result = my_agent("hello")

        assert result == "sync result for hello"


class TestContextInjection:
    @pytest.mark.asyncio
    async def test_decorator_context_injection(self, client, mock_lifecycle):
        """Decorator injects waxell_ctx when function accepts it."""

        @waxell_agent(agent_name="test-ctx", client=client, enforce_policy=False)
        async def my_agent(query: str, waxell_ctx=None) -> str:
            if waxell_ctx:
                waxell_ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
            return "done"

        result = await my_agent("hello")

        assert result == "done"

        # Verify llm-calls endpoint was called
        llm_calls = [c for c in respx.calls if "/llm-calls/" in str(c.request.url)]
        assert len(llm_calls) == 1


class TestCaptureIO:
    @pytest.mark.asyncio
    async def test_decorator_captures_io(self, client, mock_lifecycle):
        """capture_io=True includes function inputs in start_run."""
        import json

        @waxell_agent(
            agent_name="test-io",
            client=client,
            enforce_policy=False,
            capture_io=True,
        )
        async def my_agent(query: str) -> str:
            return "result"

        await my_agent("test-input")

        start_calls = [c for c in respx.calls if "/runs/start/" in str(c.request.url)]
        body = json.loads(start_calls[0].request.content)
        assert body["inputs"] != {}

    @pytest.mark.asyncio
    async def test_decorator_no_capture_io(self, client, mock_lifecycle):
        """capture_io=False sends empty inputs."""
        import json

        @waxell_agent(
            agent_name="test-no-io",
            client=client,
            enforce_policy=False,
            capture_io=False,
        )
        async def my_agent(query: str) -> str:
            return "result"

        await my_agent("test-input")

        start_calls = [c for c in respx.calls if "/runs/start/" in str(c.request.url)]
        body = json.loads(start_calls[0].request.content)
        assert body["inputs"] == {}


class TestExceptionPropagation:
    @pytest.mark.asyncio
    async def test_decorator_exception_propagation(self, client, mock_lifecycle):
        """Exceptions propagate through decorator. Run completes with error."""
        import json

        @waxell_agent(agent_name="test-err", client=client, enforce_policy=False)
        async def my_agent() -> str:
            raise RuntimeError("something broke")

        with pytest.raises(RuntimeError, match="something broke"):
            await my_agent()

        # Verify complete was called with error status
        complete_calls = [c for c in respx.calls if "/complete/" in str(c.request.url)]
        assert len(complete_calls) == 1
        body = json.loads(complete_calls[0].request.content)
        assert body["status"] == "error"
        assert "something broke" in body["error"]
