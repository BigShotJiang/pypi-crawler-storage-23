"""Unit tests for ObserveConfig."""

from waxell_observe.config import ObserveConfig


class TestObserveConfigDefaults:
    def test_default_values(self):
        """Default ObserveConfig has empty strings and False bools."""
        config = ObserveConfig()

        assert config.api_url == ""
        assert config.api_key == ""
        assert config.otel_endpoint == ""
        assert config.debug is False
        assert config.capture_content is False
        assert config.prompt_guard is False
        assert config.prompt_guard_server is False
        assert config.prompt_guard_action == "block"

    def test_is_configured_false_when_empty(self):
        """is_configured returns False when api_url and api_key are empty."""
        config = ObserveConfig()

        assert config.is_configured is False

    def test_is_configured_false_with_only_url(self):
        """is_configured returns False when only api_url is set."""
        config = ObserveConfig(api_url="http://localhost:8000")

        assert config.is_configured is False

    def test_is_configured_false_with_only_key(self):
        """is_configured returns False when only api_key is set."""
        config = ObserveConfig(api_key="some-key")

        assert config.is_configured is False

    def test_is_configured_true_with_both(self):
        """is_configured returns True when both api_url and api_key are set."""
        config = ObserveConfig(api_url="http://localhost:8000", api_key="key")

        assert config.is_configured is True


class TestObserveConfigFromEnv:
    def test_from_env_reads_waxell_vars(self, monkeypatch):
        """from_env() reads WAXELL_API_URL and WAXELL_API_KEY."""
        monkeypatch.setenv("WAXELL_API_URL", "http://waxell.test:8000")
        monkeypatch.setenv("WAXELL_API_KEY", "waxell-secret")

        config = ObserveConfig.from_env()

        assert config.api_url == "http://waxell.test:8000"
        assert config.api_key == "waxell-secret"
        assert config.is_configured is True

    def test_from_env_reads_wax_fallback_vars(self, monkeypatch):
        """from_env() falls back to WAX_API_URL and WAX_API_KEY."""
        monkeypatch.delenv("WAXELL_API_URL", raising=False)
        monkeypatch.delenv("WAXELL_API_KEY", raising=False)
        monkeypatch.setenv("WAX_API_URL", "http://wax.test:9000")
        monkeypatch.setenv("WAX_API_KEY", "wax-secret")

        config = ObserveConfig.from_env()

        assert config.api_url == "http://wax.test:9000"
        assert config.api_key == "wax-secret"

    def test_from_env_waxell_takes_precedence_over_wax(self, monkeypatch):
        """WAXELL_ vars take precedence over WAX_ vars."""
        monkeypatch.setenv("WAXELL_API_URL", "http://primary.test")
        monkeypatch.setenv("WAXELL_API_KEY", "primary-key")
        monkeypatch.setenv("WAX_API_URL", "http://fallback.test")
        monkeypatch.setenv("WAX_API_KEY", "fallback-key")

        config = ObserveConfig.from_env()

        assert config.api_url == "http://primary.test"
        assert config.api_key == "primary-key"

    def test_from_env_empty_when_no_vars(self, monkeypatch):
        """from_env() returns empty config when no env vars are set."""
        monkeypatch.delenv("WAXELL_API_URL", raising=False)
        monkeypatch.delenv("WAXELL_API_KEY", raising=False)
        monkeypatch.delenv("WAX_API_URL", raising=False)
        monkeypatch.delenv("WAX_API_KEY", raising=False)

        config = ObserveConfig.from_env()

        assert config.api_url == ""
        assert config.api_key == ""
        assert config.is_configured is False

    def test_from_env_reads_debug_flag(self, monkeypatch):
        """from_env() reads WAXELL_DEBUG boolean flag."""
        monkeypatch.setenv("WAXELL_DEBUG", "true")

        config = ObserveConfig.from_env()

        assert config.debug is True

    def test_from_env_reads_capture_content_flag(self, monkeypatch):
        """from_env() reads WAXELL_CAPTURE_CONTENT boolean flag."""
        monkeypatch.setenv("WAXELL_CAPTURE_CONTENT", "1")

        config = ObserveConfig.from_env()

        assert config.capture_content is True

    def test_from_env_reads_prompt_guard_flag(self, monkeypatch):
        """from_env() reads WAXELL_PROMPT_GUARD boolean flag."""
        monkeypatch.setenv("WAXELL_PROMPT_GUARD", "yes")

        config = ObserveConfig.from_env()

        assert config.prompt_guard is True

    def test_from_env_reads_prompt_guard_action(self, monkeypatch):
        """from_env() reads WAXELL_PROMPT_GUARD_ACTION."""
        monkeypatch.setenv("WAXELL_PROMPT_GUARD_ACTION", "WARN")

        config = ObserveConfig.from_env()

        assert config.prompt_guard_action == "warn"


class TestObserveConfigIsConfigured:
    def test_is_configured_property(self):
        """is_configured is True when both api_url and api_key are non-empty."""
        config = ObserveConfig(api_url="http://x", api_key="k")

        assert config.is_configured is True

    def test_not_configured_without_url(self):
        """is_configured is False without api_url."""
        config = ObserveConfig(api_key="k")

        assert config.is_configured is False

    def test_not_configured_without_key(self):
        """is_configured is False without api_key."""
        config = ObserveConfig(api_url="http://x")

        assert config.is_configured is False
