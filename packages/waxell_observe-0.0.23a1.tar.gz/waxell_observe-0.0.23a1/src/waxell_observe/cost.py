"""Client-side LLM cost estimation.

Used as a fallback when the server doesn't have pricing for a model.
Server-side cost calculation (using ModelCostOverride + system defaults)
takes precedence over these estimates.
"""

# Cost per token in USD. Keyed by model name prefix.
# Values: {"input": cost_per_token, "output": cost_per_token}
MODEL_COSTS: dict[str, dict[str, float]] = {
    # OpenAI
    "gpt-4o": {
        "input": 2.50 / 1_000_000,
        "output": 10.00 / 1_000_000,
    },
    "gpt-4o-mini": {
        "input": 0.15 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "gpt-4-turbo": {
        "input": 10.00 / 1_000_000,
        "output": 30.00 / 1_000_000,
    },
    "gpt-4": {
        "input": 30.00 / 1_000_000,
        "output": 60.00 / 1_000_000,
    },
    "gpt-3.5-turbo": {
        "input": 0.50 / 1_000_000,
        "output": 1.50 / 1_000_000,
    },
    "o1": {
        "input": 15.00 / 1_000_000,
        "output": 60.00 / 1_000_000,
    },
    "o1-mini": {
        "input": 3.00 / 1_000_000,
        "output": 12.00 / 1_000_000,
    },
    "o3-mini": {
        "input": 1.10 / 1_000_000,
        "output": 4.40 / 1_000_000,
    },
    # Anthropic
    "claude-opus-4": {
        "input": 15.00 / 1_000_000,
        "output": 75.00 / 1_000_000,
    },
    "claude-sonnet-4": {
        "input": 3.00 / 1_000_000,
        "output": 15.00 / 1_000_000,
    },
    "claude-3-5-sonnet": {
        "input": 3.00 / 1_000_000,
        "output": 15.00 / 1_000_000,
    },
    "claude-3-5-haiku": {
        "input": 0.80 / 1_000_000,
        "output": 4.00 / 1_000_000,
    },
    "claude-3-haiku": {
        "input": 0.25 / 1_000_000,
        "output": 1.25 / 1_000_000,
    },
    # Google
    "gemini-2.0-flash": {
        "input": 0.10 / 1_000_000,
        "output": 0.40 / 1_000_000,
    },
    "gemini-1.5-pro": {
        "input": 1.25 / 1_000_000,
        "output": 5.00 / 1_000_000,
    },
    "gemini-1.5-flash": {
        "input": 0.075 / 1_000_000,
        "output": 0.30 / 1_000_000,
    },
    # Meta (via Groq/Together/etc.)
    "llama-3.3-70b": {
        "input": 0.59 / 1_000_000,
        "output": 0.79 / 1_000_000,
    },
    "llama-3.1-8b": {
        "input": 0.05 / 1_000_000,
        "output": 0.08 / 1_000_000,
    },
    # Mistral
    "mistral-large": {
        "input": 2.00 / 1_000_000,
        "output": 6.00 / 1_000_000,
    },
    "mistral-small": {
        "input": 0.10 / 1_000_000,
        "output": 0.30 / 1_000_000,
    },
    "mistral-medium": {
        "input": 2.70 / 1_000_000,
        "output": 8.10 / 1_000_000,
    },
    "codestral": {
        "input": 0.30 / 1_000_000,
        "output": 0.90 / 1_000_000,
    },
    "open-mistral-nemo": {
        "input": 0.15 / 1_000_000,
        "output": 0.15 / 1_000_000,
    },
    "pixtral": {
        "input": 0.15 / 1_000_000,
        "output": 0.15 / 1_000_000,
    },
    # Cohere
    "command-a-03-2025": {
        "input": 2.50 / 1_000_000,
        "output": 10.00 / 1_000_000,
    },
    "command-r-plus-08-2024": {
        "input": 2.50 / 1_000_000,
        "output": 10.00 / 1_000_000,
    },
    "command-r-08-2024": {
        "input": 0.15 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "command-r-plus": {
        "input": 2.50 / 1_000_000,
        "output": 10.00 / 1_000_000,
    },
    "command-r": {
        "input": 0.15 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "command-light": {
        "input": 0.30 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    # Google Gemini (additional models)
    "gemini-2.5-pro": {
        "input": 1.25 / 1_000_000,
        "output": 10.00 / 1_000_000,
    },
    "gemini-2.5-flash": {
        "input": 0.15 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    # AWS Bedrock (Anthropic models via Bedrock use same pricing)
    "amazon.titan-text-express": {
        "input": 0.20 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "amazon.titan-text-lite": {
        "input": 0.15 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    "amazon.nova-pro": {
        "input": 0.80 / 1_000_000,
        "output": 3.20 / 1_000_000,
    },
    "amazon.nova-lite": {
        "input": 0.06 / 1_000_000,
        "output": 0.24 / 1_000_000,
    },
    "amazon.nova-micro": {
        "input": 0.035 / 1_000_000,
        "output": 0.14 / 1_000_000,
    },
    "ai21.jamba-1-5-large": {
        "input": 2.00 / 1_000_000,
        "output": 8.00 / 1_000_000,
    },
    "ai21.jamba-1-5-mini": {
        "input": 0.20 / 1_000_000,
        "output": 0.40 / 1_000_000,
    },
    "meta.llama3-1-70b-instruct": {
        "input": 0.72 / 1_000_000,
        "output": 0.72 / 1_000_000,
    },
    "meta.llama3-1-8b-instruct": {
        "input": 0.22 / 1_000_000,
        "output": 0.22 / 1_000_000,
    },
    # Groq (hosted models — priced per Groq's pricing page)
    "llama-3.3-70b-versatile": {
        "input": 0.59 / 1_000_000,
        "output": 0.79 / 1_000_000,
    },
    "llama-3.1-70b-versatile": {
        "input": 0.59 / 1_000_000,
        "output": 0.79 / 1_000_000,
    },
    "llama-3.1-8b-instant": {
        "input": 0.05 / 1_000_000,
        "output": 0.08 / 1_000_000,
    },
    "llama3-70b-8192": {
        "input": 0.59 / 1_000_000,
        "output": 0.79 / 1_000_000,
    },
    "llama3-8b-8192": {
        "input": 0.05 / 1_000_000,
        "output": 0.08 / 1_000_000,
    },
    "mixtral-8x7b-32768": {
        "input": 0.24 / 1_000_000,
        "output": 0.24 / 1_000_000,
    },
    "gemma2-9b-it": {
        "input": 0.20 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    # DeepSeek
    "deepseek-r1-distill-llama-70b": {
        "input": 0.75 / 1_000_000,
        "output": 0.99 / 1_000_000,
    },
    "deepseek-chat": {
        "input": 0.14 / 1_000_000,
        "output": 0.28 / 1_000_000,
    },
    "deepseek-reasoner": {
        "input": 0.55 / 1_000_000,
        "output": 2.19 / 1_000_000,
    },
    # Together AI (native SDK model names use full org/model paths)
    "meta-llama/Llama-3.3-70B": {
        "input": 0.88 / 1_000_000,
        "output": 0.88 / 1_000_000,
    },
    "meta-llama/Meta-Llama-3.1-8B": {
        "input": 0.18 / 1_000_000,
        "output": 0.18 / 1_000_000,
    },
    # Fireworks AI
    "accounts/fireworks/models/llama-v3p3-70b-instruct": {
        "input": 0.90 / 1_000_000,
        "output": 0.90 / 1_000_000,
    },
    # vLLM / SGLang (local inference, zero cost)
    "vllm": {
        "input": 0.0,
        "output": 0.0,
    },
}

# Non-token-based pricing for multimodal APIs.
# DALL-E: per-image pricing. Whisper: per-minute pricing. TTS: per-character pricing.
MULTIMODAL_COSTS: dict[str, dict[str, float]] = {
    # OpenAI DALL-E 3 (per image)
    "dall-e-3-1024x1024-standard": 0.040,
    "dall-e-3-1024x1792-standard": 0.080,
    "dall-e-3-1792x1024-standard": 0.080,
    "dall-e-3-1024x1024-hd": 0.080,
    "dall-e-3-1024x1792-hd": 0.120,
    "dall-e-3-1792x1024-hd": 0.120,
    # OpenAI DALL-E 2 (per image)
    "dall-e-2-1024x1024": 0.020,
    "dall-e-2-512x512": 0.018,
    "dall-e-2-256x256": 0.016,
    # OpenAI Whisper (per minute of audio)
    "whisper-1": 0.006,
    # OpenAI TTS (per 1M characters)
    "tts-1": 15.00 / 1_000_000,
    "tts-1-hd": 30.00 / 1_000_000,
    # Groq Whisper (per minute — currently free in preview, placeholder)
    "whisper-large-v3": 0.0,
    "whisper-large-v3-turbo": 0.0,
    "distil-whisper-large-v3-en": 0.0,
}

# Embedding model costs: keyed by model name prefix.
# Values: cost per token in USD.
EMBEDDING_COSTS: dict[str, float] = {
    # OpenAI
    "text-embedding-3-large": 0.13 / 1_000_000,
    "text-embedding-3-small": 0.02 / 1_000_000,
    "text-embedding-ada-002": 0.10 / 1_000_000,
    # Cohere
    "embed-v4.0": 0.10 / 1_000_000,
    "embed-english-v3.0": 0.10 / 1_000_000,
    "embed-multilingual-v3.0": 0.10 / 1_000_000,
    "embed-english-light-v3.0": 0.10 / 1_000_000,
    # Voyage AI
    "voyage-3-large": 0.18 / 1_000_000,
    "voyage-3": 0.06 / 1_000_000,
    "voyage-3-lite": 0.02 / 1_000_000,
    "voyage-code-3": 0.18 / 1_000_000,
    # Jina AI
    "jina-embeddings-v3": 0.02 / 1_000_000,
    "jina-embeddings-v2": 0.02 / 1_000_000,
    # Google
    "text-embedding-005": 0.00 / 1_000_000,  # Free tier
    # Mistral
    "mistral-embed": 0.10 / 1_000_000,
    # AWS Bedrock Titan
    "amazon.titan-embed-text-v2": 0.02 / 1_000_000,
    "amazon.titan-embed-text-v1": 0.10 / 1_000_000,
    # Local / self-hosted
    "sentence-transformers": 0.0,
    "bge": 0.0,
    "e5": 0.0,
}

# Providers where all models are free (local inference).
_FREE_PROVIDERS: frozenset[str] = frozenset({"ollama", "local"})


def estimate_cost(
    model: str,
    tokens_in: int,
    tokens_out: int,
    provider: str = "",
) -> float:
    """Estimate the cost of an LLM call based on model and token counts.

    Args:
        model: Model name (exact or prefix-matchable).
        tokens_in: Number of input/prompt tokens.
        tokens_out: Number of output/completion tokens.
        provider: Optional provider name.  If the provider is in
            ``_FREE_PROVIDERS`` (e.g. ``"ollama"``, ``"local"``), the
            function returns ``0.0`` immediately.

    Tries exact match first, then prefix matching for versioned model names
    (e.g., "gpt-4o-2024-08-06" matches "gpt-4o").

    Returns 0.0 for unknown models or free providers.
    """
    # Free providers (local inference) -- always zero cost
    if provider and provider in _FREE_PROVIDERS:
        return 0.0

    # Normalize model name (Gemini API returns "models/gemini-2.5-flash")
    if model.startswith("models/"):
        model = model[len("models/") :]

    # Exact match
    costs = MODEL_COSTS.get(model)

    # Prefix match (longer prefixes first for specificity)
    if costs is None:
        for prefix in sorted(MODEL_COSTS.keys(), key=len, reverse=True):
            if model.startswith(prefix):
                costs = MODEL_COSTS[prefix]
                break

    if costs is None:
        return 0.0

    return tokens_in * costs["input"] + tokens_out * costs["output"]


def estimate_embedding_cost(
    model: str,
    tokens: int,
    provider: str = "",
) -> float:
    """Estimate the cost of an embedding call.

    Args:
        model: Embedding model name.
        tokens: Number of input tokens.
        provider: Optional provider name.

    Returns 0.0 for unknown models or free providers.
    """
    if provider and provider in _FREE_PROVIDERS:
        return 0.0

    # Exact match
    cost_per_token = EMBEDDING_COSTS.get(model)

    # Prefix match
    if cost_per_token is None:
        for prefix in sorted(EMBEDDING_COSTS.keys(), key=len, reverse=True):
            if model.startswith(prefix):
                cost_per_token = EMBEDDING_COSTS[prefix]
                break

    if cost_per_token is None:
        return 0.0

    return tokens * cost_per_token
