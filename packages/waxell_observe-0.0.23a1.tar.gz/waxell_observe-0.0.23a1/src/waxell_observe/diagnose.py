"""Introspection API for waxell-observe.

Helps users debug "why aren't my spans showing up?" by reporting
which instrumentors are active, which libraries were detected,
and the current SDK configuration.

Usage::

    import waxell_observe as waxell
    waxell.init()
    print(waxell.diagnose())
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)


def diagnose() -> dict:
    """Return instrumentation status, detected libraries, and config.

    This is the #1 debugging tool for "I called init() but I don't see
    spans". It reports everything the SDK knows about its current state
    without side effects.

    Returns:
        Dict with keys: sdk_version, initialized, active_instrumentors,
        detected_libraries, config, tracing.
    """
    from waxell_observe.__about__ import __version__
    from waxell_observe._init import _initialized

    result: dict = {
        "sdk_version": __version__,
        "initialized": _initialized,
        "active_instrumentors": [],
        "detected_libraries": {},
        "config": {
            "api_url": "",
            "api_key_set": False,
            "observe_enabled": True,
        },
        "tracing": {
            "otel_available": False,
            "tracing_enabled": False,
        },
    }

    # Check kill switch
    kill = os.environ.get("WAXELL_OBSERVE", "").lower()
    if kill in ("false", "0", "no"):
        result["config"]["observe_enabled"] = False

    # Check API key
    api_key = os.environ.get("WAXELL_API_KEY", "")
    result["config"]["api_key_set"] = bool(api_key)

    # Check API URL
    api_url = os.environ.get("WAXELL_API_URL", "")
    if not api_url:
        # Try fallback config file
        try:
            config_path = os.path.expanduser("~/.waxell/config")
            if os.path.exists(config_path):
                with open(config_path) as f:
                    for line in f:
                        if line.strip().startswith("api_url"):
                            api_url = (
                                line.split("=", 1)[-1].strip().strip('"').strip("'")
                            )
                            break
        except Exception:
            pass
    result["config"]["api_url"] = api_url or "(not set)"

    # Check OTel availability
    try:
        import opentelemetry  # noqa: F401

        result["tracing"]["otel_available"] = True
    except ImportError:
        pass

    # Check tracing status
    try:
        from waxell_observe.tracing import is_tracing_enabled

        result["tracing"]["tracing_enabled"] = is_tracing_enabled()
    except Exception:
        pass

    # Detect installed libraries
    try:
        from waxell_observe.instrumentors._detect import detect_installed_libraries

        result["detected_libraries"] = detect_installed_libraries()
    except Exception as exc:
        logger.debug("Could not detect installed libraries: %s", exc)

    # Check active instrumentors
    try:
        from waxell_observe.instrumentors import _REGISTRY, _registry_loaded

        if _registry_loaded:
            result["active_instrumentors"] = [
                name for name, inst in _REGISTRY.items() if inst.is_instrumented()
            ]
    except Exception as exc:
        logger.debug("Could not check instrumentor registry: %s", exc)

    return result
