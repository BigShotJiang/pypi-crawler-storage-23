"""Claude Code hook handler — reads JSON from stdin, dispatches to observe API.

This is the entry point called by Claude Code for all hook events.
It routes to the appropriate handler based on hook_event_name.

Usage (called by Claude Code hooks):
    echo '{"hook_event_name": "SessionStart", ...}' | wax observe claude-code hook
"""

import json
import logging
import sys
from datetime import datetime, timezone

from ...client import WaxellObserveClient
from .state import (
    SessionState,
    cleanup_stale_states,
    delete_state,
    find_cowork_peer,
    load_state,
    save_state,
)
from .transcript import parse_transcript

logger = logging.getLogger(__name__)


def handle_hook() -> None:
    """Main entry point — read hook JSON from stdin, dispatch by event."""
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return
        data = json.loads(raw)
    except (json.JSONDecodeError, IOError):
        return

    event = data.get("hook_event_name", "")

    try:
        if event == "SessionStart":
            result = _handle_session_start(data)
        elif event == "PreToolUse":
            result = _handle_pre_tool_use(data)
        elif event == "PostToolUse":
            result = _handle_post_tool_use(data)
        elif event == "PostToolUseFailure":
            result = _handle_post_tool_use_failure(data)
        elif event == "SubagentStart":
            result = _handle_subagent_start(data)
        elif event == "SubagentStop":
            result = _handle_subagent_stop(data)
        elif event == "TeammateIdle":
            result = _handle_teammate_idle(data)
        elif event == "Stop":
            result = _handle_stop(data)
        elif event == "SessionEnd":
            result = _handle_session_end(data)
        else:
            result = None

        if result:
            print(json.dumps(result))
    except Exception as e:
        # Never let hook errors break Claude Code
        logger.debug("Hook handler error for %s: %s", event, e)


def _get_client() -> WaxellObserveClient:
    """Get an observe client using standard config resolution."""
    return WaxellObserveClient()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# -----------------------------------------------------------------
# Event handlers
# -----------------------------------------------------------------


def _handle_session_start(data: dict) -> dict | None:
    """Create a new run for this Claude Code session."""
    session_id = data.get("session_id", "")
    if not session_id:
        return None

    # Clean up stale state files from old sessions
    cleanup_stale_states()

    # Check if this session already has state (resume)
    existing = load_state(session_id)
    if existing and existing.run_id:
        return None

    source = data.get("source", "startup")
    cwd = data.get("cwd", "")
    model = data.get("model", "")

    # Detect Cowork: another active session in the same directory
    peer = find_cowork_peer(cwd, session_id) if cwd else None
    is_cowork = peer is not None
    cowork_session_id = ""
    if peer:
        # Use the peer's cowork_session_id if it has one, otherwise use the peer's session_id
        cowork_session_id = peer.cowork_session_id or peer.session_id
        # Mark the peer as cowork too if not already
        if not peer.is_cowork:
            peer.is_cowork = True
            peer.cowork_session_id = cowork_session_id
            save_state(peer)

    client = _get_client()
    if not client.config.is_configured:
        return None

    metadata = {
        "source": "claude_code",
        "model": model,
        "permission_mode": data.get("permission_mode", ""),
    }
    if is_cowork:
        metadata["is_cowork"] = True
        metadata["cowork_session_id"] = cowork_session_id
        if peer:
            metadata["cowork_parent_run_id"] = peer.run_id

    try:
        run_info = client.start_run_sync(
            agent_name="claude-code",
            workflow_name=f"session:{source}",
            inputs={
                "cwd": cwd,
                "source": source,
            },
            metadata=metadata,
            session_id=session_id,
        )
    except Exception as e:
        logger.debug("Failed to start run: %s", e)
        return None

    state = SessionState(
        session_id=session_id,
        run_id=run_info.run_id,
        workflow_id=run_info.workflow_id,
        started_at=run_info.started_at or _now_iso(),
        cwd=cwd,
        model=model,
        is_cowork=is_cowork,
        cowork_session_id=cowork_session_id,
    )
    save_state(state)
    return None


def _handle_pre_tool_use(data: dict) -> dict | None:
    """Governance gate — local guard + server policy check before tool execution.

    Flow:
    1. Run local guard (instant, no network) — checks tool inputs
    2. If local guard denies → block immediately
    3. Run server-side policy check (budget, scheduling, kill switch)
    4. Combine warnings from both layers
    """
    session_id = data.get("session_id", "")
    state = load_state(session_id) if session_id else None
    if not state or not state.run_id:
        return None

    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input", {})
    warnings: list[str] = []

    # --- Layer 1: Local guard (instant, no network) ---
    try:
        from .guard import check_tool_use, load_config

        config = load_config(state.cwd)

        # Gather peer modified files for cowork conflict detection
        peer_modified: list[str] | None = None
        if state.is_cowork and config.detect_file_conflicts:
            peer = find_cowork_peer(state.cwd, state.session_id)
            if peer:
                peer_modified = peer.modified_files

        guard_result = check_tool_use(
            tool_name=tool_name,
            tool_input=tool_input,
            config=config,
            cwd=state.cwd,
            modified_files=state.modified_files,
            peer_modified_files=peer_modified,
        )

        if guard_result.action == "deny":
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": (
                        f"Waxell guard: {'; '.join(guard_result.violations)}"
                    ),
                }
            }

        if guard_result.action == "ask":
            warnings.extend(guard_result.violations)

    except Exception as e:
        logger.debug("Local guard error: %s", e)

    # --- Layer 2: Server-side policy check (budget, scheduling, kill switch) ---
    client = _get_client()
    if client.config.is_configured:
        try:
            policy_result = client.check_policy_sync(
                agent_name="claude-code",
                workflow_name=f"tool:{tool_name}",
                agent_id=state.run_id,
            )

            if policy_result.action == "block":
                return {
                    "hookSpecificOutput": {
                        "hookEventName": "PreToolUse",
                        "permissionDecision": "deny",
                        "permissionDecisionReason": (
                            f"Waxell policy blocked: {policy_result.reason or 'Policy violation'}"
                        ),
                    }
                }

            if policy_result.action == "warn":
                warnings.append(f"Policy warning: {policy_result.reason}")

        except Exception as e:
            logger.debug("Policy check failed: %s", e)

    # --- Combine warnings ---
    if warnings:
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "ask",
                "additionalContext": (
                    f"Waxell: {'; '.join(warnings)}"
                ),
            }
        }

    return None


def _handle_post_tool_use(data: dict) -> dict | None:
    """Record a tool call span (async, non-blocking)."""
    session_id = data.get("session_id", "")
    state = load_state(session_id) if session_id else None
    if not state or not state.run_id:
        return None

    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input", {})
    tool_response = data.get("tool_response", {})

    # Build input summary (truncated for safety)
    input_summary = _summarize_tool_input(tool_name, tool_input)
    output_summary = _summarize_tool_output(tool_name, tool_response)

    client = _get_client()
    if not client.config.is_configured:
        return None

    now = _now_iso()
    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[{
                "name": tool_name,
                "kind": "tool",
                "status": "ok",
                "start_time": now,
                "end_time": now,
                "attributes": {
                    "tool.name": tool_name,
                    "tool.input_summary": input_summary,
                    "tool.output_summary": output_summary,
                },
                "input_data": input_summary,
                "output_data": output_summary,
            }],
        )
    except Exception as e:
        logger.debug("Failed to record span: %s", e)
        return None

    # Track modified files for session scope + cowork conflict detection
    if tool_name in ("Write", "Edit"):
        file_path = tool_input.get("file_path", "")
        if file_path and file_path not in state.modified_files:
            state.modified_files.append(file_path)

    # Update span count
    state.span_count += 1
    save_state(state)
    return None


def _handle_post_tool_use_failure(data: dict) -> dict | None:
    """Record a failed tool call span."""
    session_id = data.get("session_id", "")
    state = load_state(session_id) if session_id else None
    if not state or not state.run_id:
        return None

    tool_name = data.get("tool_name", "")
    error = data.get("error", "")

    client = _get_client()
    if not client.config.is_configured:
        return None

    now = _now_iso()
    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[{
                "name": tool_name,
                "kind": "tool",
                "status": "error",
                "start_time": now,
                "end_time": now,
                "attributes": {
                    "tool.name": tool_name,
                    "error.message": error[:500],
                },
                "events": [{"name": "error", "message": error[:500]}] if error else [],
            }],
        )
    except Exception as e:
        logger.debug("Failed to record error span: %s", e)

    state.span_count += 1
    save_state(state)
    return None


def _handle_subagent_start(data: dict) -> dict | None:
    """Record the start of a subagent/Task tool invocation."""
    session_id = data.get("session_id", "")
    state = load_state(session_id) if session_id else None
    if not state or not state.run_id:
        return None

    agent_id = data.get("agent_id", "")
    agent_type = data.get("agent_type", "")

    # Store start time for this subagent
    state.pending_subagent_spans[agent_id] = {
        "agent_type": agent_type,
        "start_time": _now_iso(),
    }
    save_state(state)
    return None


def _handle_subagent_stop(data: dict) -> dict | None:
    """Record the end of a subagent and its token usage."""
    session_id = data.get("session_id", "")
    state = load_state(session_id) if session_id else None
    if not state or not state.run_id:
        return None

    agent_id = data.get("agent_id", "")
    agent_type = data.get("agent_type", "")
    transcript_path = data.get("agent_transcript_path", "")

    # Get start time from pending spans
    pending = state.pending_subagent_spans.pop(agent_id, {})
    start_time = pending.get("start_time", _now_iso())

    # Parse subagent transcript for token usage
    sub_summary = None
    if transcript_path:
        sub_summary = parse_transcript(transcript_path)

    client = _get_client()
    if not client.config.is_configured:
        save_state(state)
        return None

    now = _now_iso()
    attributes = {
        "agent.type": agent_type or pending.get("agent_type", ""),
        "agent.id": agent_id,
    }
    if sub_summary:
        attributes["agent.total_tokens"] = sub_summary.total_tokens_in + sub_summary.total_tokens_out
        attributes["agent.cost"] = round(sub_summary.total_cost, 6)
        attributes["agent.turns"] = sub_summary.total_turns

    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[{
                "name": f"subagent:{agent_type or 'unknown'}",
                "kind": "agent",
                "status": "ok",
                "start_time": start_time,
                "end_time": now,
                "attributes": attributes,
            }],
        )
    except Exception as e:
        logger.debug("Failed to record subagent span: %s", e)

    # Also record subagent LLM calls on the parent run
    if sub_summary and sub_summary.llm_calls:
        try:
            client.record_llm_calls_sync(
                run_id=state.run_id,
                calls=[{
                    "model": call.model,
                    "tokens_in": call.tokens_in,
                    "tokens_out": call.tokens_out,
                    "cost": call.cost,
                    "task": f"subagent:{agent_type}",
                } for call in sub_summary.llm_calls],
            )
        except Exception:
            pass

    state.span_count += 1
    save_state(state)
    return None


def _handle_teammate_idle(data: dict) -> dict | None:
    """Record a Cowork teammate idle event (coordination span)."""
    session_id = data.get("session_id", "")
    state = load_state(session_id) if session_id else None
    if not state or not state.run_id:
        return None

    # Mark this session as a Cowork session
    if not state.is_cowork:
        state.is_cowork = True
        if not state.cowork_session_id:
            state.cowork_session_id = session_id
        save_state(state)

    client = _get_client()
    if not client.config.is_configured:
        return None

    now = _now_iso()
    try:
        client.record_spans_sync(
            run_id=state.run_id,
            spans=[{
                "name": "teammate_idle",
                "kind": "custom",
                "status": "ok",
                "start_time": now,
                "end_time": now,
                "attributes": {
                    "cowork.event": "teammate_idle",
                    "cowork.session_id": state.cowork_session_id,
                },
            }],
        )
    except Exception:
        pass
    return None


def _handle_stop(data: dict) -> dict | None:
    """Session ending — parse transcript and complete the run."""
    session_id = data.get("session_id", "")
    state = load_state(session_id) if session_id else None
    if not state or not state.run_id:
        return None

    transcript_path = data.get("transcript_path", "")

    client = _get_client()
    if not client.config.is_configured:
        delete_state(session_id)
        return None

    # Parse full transcript for LLM call records
    summary = None
    if transcript_path:
        summary = parse_transcript(transcript_path)

    # Batch-record all LLM calls
    if summary and summary.llm_calls:
        try:
            client.record_llm_calls_sync(
                run_id=state.run_id,
                calls=[{
                    "model": call.model,
                    "tokens_in": call.tokens_in,
                    "tokens_out": call.tokens_out,
                    "cost": call.cost,
                    "task": call.task,
                } for call in summary.llm_calls],
            )
        except Exception as e:
            logger.debug("Failed to record LLM calls: %s", e)

    # Complete the run
    result_data = {}
    if summary:
        result_data = {
            "total_tokens_in": summary.total_tokens_in,
            "total_tokens_out": summary.total_tokens_out,
            "total_cost": round(summary.total_cost, 6),
            "total_turns": summary.total_turns,
            "models_used": summary.models_used,
            "tool_uses": summary.tool_uses + state.span_count,
        }

    if state.is_cowork:
        result_data["is_cowork"] = True
        result_data["cowork_session_id"] = state.cowork_session_id

    try:
        client.complete_run_sync(
            run_id=state.run_id,
            result=result_data,
            status="success",
        )
    except Exception as e:
        logger.debug("Failed to complete run: %s", e)

    # Clean up state
    delete_state(session_id)
    return None


def _handle_session_end(data: dict) -> dict | None:
    """Session fully terminated — ensure cleanup."""
    session_id = data.get("session_id", "")
    if session_id:
        # Stop handler may not have fired (e.g., force quit)
        state = load_state(session_id)
        if state and state.run_id:
            _handle_stop(data)
    return None


# -----------------------------------------------------------------
# Tool input/output summarization
# -----------------------------------------------------------------


def _summarize_tool_input(tool_name: str, tool_input: dict) -> str:
    """Create a brief summary of tool input for the span."""
    if not tool_input:
        return ""

    if tool_name == "Bash":
        cmd = tool_input.get("command", "")
        return cmd[:200] if cmd else ""
    elif tool_name in ("Read", "Write", "Edit"):
        return tool_input.get("file_path", "")
    elif tool_name == "Grep":
        pattern = tool_input.get("pattern", "")
        path = tool_input.get("path", "")
        return f"{pattern} in {path}" if path else pattern
    elif tool_name == "Glob":
        return tool_input.get("pattern", "")
    elif tool_name == "WebSearch":
        return tool_input.get("query", "")
    elif tool_name == "WebFetch":
        return tool_input.get("url", "")
    elif tool_name == "Task":
        desc = tool_input.get("description", "")
        agent_type = tool_input.get("subagent_type", "")
        return f"[{agent_type}] {desc}" if agent_type else desc
    else:
        # MCP tools or unknown — just show first key-value
        for k, v in tool_input.items():
            return f"{k}={str(v)[:100]}"
    return ""


def _summarize_tool_output(tool_name: str, tool_response: dict) -> str:
    """Create a brief summary of tool output for the span."""
    if not tool_response:
        return ""

    if isinstance(tool_response, str):
        return tool_response[:200]

    # Common patterns
    content = tool_response.get("content", "")
    if content and isinstance(content, str):
        return content[:200]

    file_path = tool_response.get("filePath", "")
    if file_path:
        return f"file:{file_path}"

    return str(tool_response)[:200]
