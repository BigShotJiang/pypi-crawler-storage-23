"""waxell-observe: Lightweight observability & governance for any AI agent framework.

Quick start — one line, everything auto-captured::

    import waxell_observe as waxell
    waxell.init()  # reads WAXELL_API_KEY & WAXELL_API_URL from env

    # Every OpenAI / Anthropic call is now traced automatically.
    response = openai.chat.completions.create(model="gpt-4o", messages=[...])

Three levels of control::

    # Level 1: Zero effort — just init()
    waxell.init()
    response = openai.chat.completions.create(...)  # auto-captured

    # Level 2: Decorator — adds structure + enrichment
    @waxell.observe(agent_name="my-chatbot")
    def chat(message):
        response = openai.chat.completions.create(...)
        waxell.score("helpfulness", 0.9)
        waxell.tag("intent", "question")
        return response

    # Level 3: Context manager — maximum control
    with waxell.context(agent_name="rag-pipeline", session_id="s1") as ctx:
        ctx.record_step("retrieval", output={"count": 5})
        response = openai.chat.completions.create(...)
        ctx.record_score("relevance", 0.85, data_type="numeric")

Drop-in import (alternative to init)::

    from waxell_observe.openai import openai      # patches on import
    from waxell_observe.anthropic import anthropic  # patches on import
"""

from waxell_observe.__about__ import __version__
from waxell_observe._init import init, shutdown
from waxell_observe.diagnose import diagnose
from waxell_observe.client import WaxellObserveClient
from waxell_observe.config import ObserveConfig
from waxell_observe.context import WaxellContext, generate_session_id

# Convenience alias so users can write ``waxell.context(...)``
context = WaxellContext
from waxell_observe.decorator import observe, waxell_agent
from waxell_observe.tool import tool
from waxell_observe.decision import decision
from waxell_observe.retrieval import retrieval
from waxell_observe.reasoning import reasoning as reasoning_dec
from waxell_observe.retry import retry as retry_dec
from waxell_observe.step import step as step_dec
from waxell_observe.errors import ConfigurationError, ObserveError, PolicyViolationError
from waxell_observe.instrumentors._context_var import _current_context
from waxell_observe.tracing import (
    flush_tracing,
    init_tracing,
    is_tracing_enabled,
    shutdown_tracing,
)
from waxell_observe.instrumentors._guard import PromptGuardError
from waxell_observe.types import (
    LlmCallInfo,
    PolicyCheckResult,
    PromptGuardResult,
    RunCompleteResult,
    RunInfo,
)


# ---------------------------------------------------------------------------
# Top-level convenience functions (delegate to the current WaxellContext)
# ---------------------------------------------------------------------------


def score(
    name: str,
    value: float | str | bool,
    data_type: str = "numeric",
    comment: str = "",
) -> None:
    """Record a score on the current context (if active).

    This is a shorthand for ``ctx.record_score(...)`` that works without
    an explicit reference to the context -- it looks up the current
    ``WaxellContext`` via the ContextVar set by ``__aenter__`` or the
    ``@observe`` decorator.

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_score(name, value, data_type, comment)


def tag(key: str, value: str) -> None:
    """Set a tag on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.set_tag(key, value)


def metadata(key: str, value) -> None:
    """Set metadata on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.set_metadata(key, value)


def decide(
    name: str,
    chosen: str,
    options: list[str] | None = None,
    reasoning: str = "",
    confidence: float | None = None,
) -> None:
    """Record a decision on the current context (if active).

    One-liner for any provider — use this when you don't have an
    auto-instrumentor or the ``@decision`` decorator::

        waxell.decide("route_task", chosen="research",
                       options=["direct", "research", "multi_agent"],
                       reasoning="Complex query needs synthesis")

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        kwargs = dict(
            name=name,
            options=options or [],
            chosen=chosen,
            reasoning=reasoning,
            instrumentation_type="manual",
        )
        if confidence is not None:
            kwargs["confidence"] = confidence
        ctx.record_decision(**kwargs)


def step(name: str, output: dict | None = None) -> None:
    """Record an execution step on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_step(name, output)


def reason(
    step: str,
    thought: str,
    evidence: list[str] | None = None,
    conclusion: str = "",
) -> None:
    """Record a reasoning step on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_reasoning(
            step=step, thought=thought, evidence=evidence, conclusion=conclusion
        )


def retrieve(
    query: str,
    documents: list[dict],
    source: str = "",
    scores: list[float] | None = None,
) -> None:
    """Record a retrieval operation on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_retrieval(
            query=query, documents=documents, source=source, scores=scores
        )


def retry(
    attempt: int,
    reason: str,
    strategy: str = "retry",
    original_error: str = "",
    fallback_to: str = "",
) -> None:
    """Record a retry/fallback event on the current context (if active).

    No-op if called outside a WaxellContext.
    """
    ctx = _current_context.get()
    if ctx:
        ctx.record_retry(
            attempt=attempt,
            reason=reason,
            strategy=strategy,
            original_error=original_error,
            fallback_to=fallback_to,
        )


def get_context():
    """Get the current WaxellContext, or None if not in a context."""
    return _current_context.get()


__all__ = [
    "__version__",
    "init",
    "shutdown",
    "WaxellObserveClient",
    "ObserveConfig",
    "WaxellContext",
    "context",
    "generate_session_id",
    "waxell_agent",
    "observe",
    # Decorators
    "tool",
    "decision",
    "retrieval",
    "reasoning_dec",
    "retry_dec",
    "step_dec",
    # Convenience functions
    "decide",
    "score",
    "tag",
    "metadata",
    "step",
    "reason",
    "retrieve",
    "retry",
    "get_context",
    "diagnose",
    # Errors
    "ConfigurationError",
    "ObserveError",
    "PolicyViolationError",
    # Types
    "LlmCallInfo",
    "PolicyCheckResult",
    "PromptGuardError",
    "PromptGuardResult",
    "RunCompleteResult",
    "RunInfo",
    # Tracing
    "init_tracing",
    "flush_tracing",
    "shutdown_tracing",
    "is_tracing_enabled",
]
