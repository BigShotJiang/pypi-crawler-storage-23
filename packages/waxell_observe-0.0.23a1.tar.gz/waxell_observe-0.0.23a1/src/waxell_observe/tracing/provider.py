"""TracerProvider lifecycle management.

Creates a LOCAL TracerProvider (not global) to avoid conflicts
with other OTel instrumentation in the same process.
"""

import logging

logger = logging.getLogger(__name__)

from ._compat import _HAS_OTEL

if _HAS_OTEL:
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
        SimpleSpanProcessor,
        ConsoleSpanExporter,
    )
    from opentelemetry.sdk.resources import Resource


def create_resource(
    service_name: str = "waxell-observe-sdk",
    service_version: str | None = None,
    resource_attributes: dict | None = None,
) -> "Resource":
    """Create an OTel Resource shared by trace and log providers."""
    if service_version is None:
        try:
            from waxell_observe.__about__ import __version__
            service_version = __version__
        except ImportError:
            service_version = "unknown"

    attrs = {
        "service.name": service_name,
        "service.version": service_version,
    }
    if resource_attributes:
        attrs.update(resource_attributes)

    return Resource.create(attrs)


def create_provider(
    endpoint: str,
    resource: "Resource | None" = None,
    service_name: str = "waxell-observe-sdk",
    service_version: str | None = None,
    resource_attributes: dict | None = None,
    debug: bool = False,
    headers: dict | None = None,
) -> "TracerProvider":
    """Create a local TracerProvider with BatchSpanProcessor.

    Args:
        endpoint: OTLP/HTTP endpoint URL.
        resource: Pre-built OTel Resource. If None, one is created.
        service_name: Service name for the OTel resource.
        service_version: Service version. Defaults to SDK version.
        resource_attributes: Extra resource attributes to include.
        debug: If True, also add a ConsoleSpanExporter for stderr output.
        headers: Extra HTTP headers for the OTLP exporter (e.g. auth).

    Returns:
        A configured TracerProvider instance.
    """
    from .exporter import create_exporter

    if resource is None:
        resource = create_resource(service_name, service_version, resource_attributes)

    provider = TracerProvider(resource=resource)

    exporter = create_exporter(endpoint, headers=headers)
    processor = BatchSpanProcessor(
        exporter,
        max_queue_size=2048,
        schedule_delay_millis=2000,
        max_export_batch_size=256,
        export_timeout_millis=15000,
    )
    provider.add_span_processor(processor)

    if debug:
        console_processor = SimpleSpanProcessor(ConsoleSpanExporter())
        provider.add_span_processor(console_processor)

    # Add WaxellSpanProcessor to bridge OTel spans into Django Span table
    try:
        from .span_processor import WaxellSpanProcessor as _WSP

        provider.add_span_processor(_WSP())
    except Exception:
        logger.debug("Failed to add WaxellSpanProcessor", exc_info=True)

    return provider


def create_waxell_only_provider(
    resource: "Resource | None" = None,
    debug: bool = False,
) -> "TracerProvider":
    """Create a TracerProvider with only the WaxellSpanProcessor (no OTLP exporter).

    Used when no OTel endpoint is configured — auto-instrumented spans still
    flow into the Django Span table via the HTTP observe API.
    """
    if resource is None:
        resource = create_resource()

    provider = TracerProvider(resource=resource)

    from .span_processor import WaxellSpanProcessor as _WSP

    provider.add_span_processor(_WSP())

    if debug:
        console_processor = SimpleSpanProcessor(ConsoleSpanExporter())
        provider.add_span_processor(console_processor)

    return provider


def create_log_provider(
    endpoint: str,
    resource: "Resource",
    headers: dict | None = None,
) -> "LoggerProvider":
    """Create a LoggerProvider that exports logs via OTLP/HTTP.

    Args:
        endpoint: OTLP/HTTP base endpoint URL (e.g. http://localhost:4318).
        resource: OTel Resource (shared with TracerProvider).
        headers: Extra HTTP headers for the OTLP exporter (e.g. auth).

    Returns:
        A configured LoggerProvider instance, or None if OTel logs unavailable.
    """
    from ._compat import _HAS_OTEL_LOGS

    if not _HAS_OTEL_LOGS:
        return None

    from opentelemetry.sdk._logs import LoggerProvider as LP
    from opentelemetry.sdk._logs.export import BatchLogRecordProcessor as BLRP
    from opentelemetry.exporter.otlp.proto.http._log_exporter import (
        OTLPLogExporter,
    )
    from .exporter import _normalize_logs_endpoint

    log_endpoint = _normalize_logs_endpoint(endpoint)
    exporter = OTLPLogExporter(endpoint=log_endpoint, headers=headers or {})

    provider = LP(resource=resource)
    provider.add_log_record_processor(
        BLRP(exporter, max_export_batch_size=256, schedule_delay_millis=2000)
    )
    return provider


def shutdown_provider(provider: "TracerProvider") -> None:
    """Shut down a TracerProvider, flushing pending spans."""
    try:
        provider.shutdown()
    except Exception as e:
        logger.debug("Error shutting down TracerProvider: %s", e)


def shutdown_log_provider(provider) -> None:
    """Shut down a LoggerProvider, flushing pending logs."""
    if provider is None:
        return
    try:
        provider.shutdown()
    except Exception as e:
        logger.debug("Error shutting down LoggerProvider: %s", e)
