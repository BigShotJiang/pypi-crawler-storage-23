"""WaxellSpanProcessor — bridges OTel auto-instrumented spans to the Django Span table.

Captures completed OTel spans and appends them to the active WaxellContext's
_spans buffer.  When the context flushes in __aexit__, these spans are POSTed
to the observe API alongside manually-recorded spans.

This processor is added to the local TracerProvider so it sees every span
from every auto-instrumentor (OpenAI, Anthropic, LangChain, vector DBs, etc.)
without any changes to the instrumentors themselves.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

try:
    from opentelemetry.sdk.trace import SpanProcessor, ReadableSpan

    _HAS_OTEL = True
except ImportError:
    _HAS_OTEL = False


# Map OTel SpanKind enum values to Django Span kind strings.
# CLIENT → "chain" for infra calls (HTTP, DB, Redis, etc.).
# @waxell.tool spans are identified by waxell.tool.name attribute,
# and LLM spans are promoted by GenAI attributes — both in _resolve_kind.
_OTEL_KIND_MAP = {
    0: "chain",      # INTERNAL
    1: "chain",      # SERVER
    2: "chain",      # CLIENT (HTTP/DB/API calls; promoted to "llm" by _resolve_kind)
    3: "chain",      # PRODUCER
    4: "chain",      # CONSUMER
}

# Map waxell.span_type attribute to Django Span kinds
_SPAN_TYPE_MAP = {
    "agent_execution": "agent",
    "llm_call": "llm",
    "tool_call": "tool",
    "workflow_step": "chain",
    "decision": "decision",
    "reasoning": "reasoning",
    "retrieval": "retriever",
    "embedding": "llm",
    "guardrail": "governance",
    "governance": "governance",
    "retry": "retry",
}


def _resolve_kind(span: "ReadableSpan") -> str:
    """Determine the Django Span kind from an OTel span."""
    attrs = span.attributes or {}

    # Use waxell.span_type if set (our span helpers set this)
    span_type = attrs.get("waxell.span_type", "")
    if span_type and span_type in _SPAN_TYPE_MAP:
        return _SPAN_TYPE_MAP[span_type]

    # @waxell.tool decorator sets waxell.tool.name (without waxell.span_type
    # so the processor doesn't skip it)
    if attrs.get("waxell.tool.name"):
        return "tool"

    # Infer from GenAI semantic conventions
    if attrs.get("gen_ai.system") or attrs.get("gen_ai.request.model"):
        return "llm"

    # Fall back to OTel SpanKind (use .value for enum→int comparison)
    kind_value = span.kind.value if hasattr(span.kind, "value") else span.kind
    return _OTEL_KIND_MAP.get(kind_value, "chain")


def _build_display_name(span_name: str, attrs: dict) -> str:
    """Build a human-readable display name for infrastructure spans.

    Transforms generic OTel span names into descriptive ones:
      "POST" → "POST api.openai.com"
      "GET"  → "redis GET"
      "SELECT" → "pg SELECT documents"
    """
    # @waxell.tool spans — use the tool name directly
    tool_name = attrs.get("waxell.tool.name")
    if tool_name:
        return tool_name

    db_system = attrs.get("db.system", "")
    http_method = attrs.get("http.request.method") or attrs.get("http.method", "")

    # HTTP spans — append the host for readability
    if http_method:
        url = (
            attrs.get("url.full")
            or attrs.get("http.url")
            or attrs.get("server.address", "")
        )
        if url:
            try:
                from urllib.parse import urlparse
                host = urlparse(url).hostname or url
            except Exception:
                host = url
            return f"{http_method} {host}"
        return span_name

    # Database spans — prefix with db system
    if db_system:
        # Shorten common db system names
        short_system = {
            "postgresql": "pg",
            "mysql": "mysql",
            "sqlite": "sqlite",
            "mongodb": "mongo",
            "redis": "redis",
            "memcached": "memcache",
            "elasticsearch": "es",
            "cassandra": "cassandra",
            "mssql": "mssql",
        }.get(db_system, db_system)

        statement = attrs.get("db.statement", "")
        if statement:
            # Extract the operation (first word/token before space or paren)
            stripped = statement.strip()
            # Split on whitespace or opening paren to get clean operation name
            import re
            match = re.match(r"(\w+)", stripped)
            op = match.group(1).upper() if match else ""
            return f"{short_system} {op}" if op else f"{short_system} {span_name}"
        return f"{short_system} {span_name}"

    # RPC spans (gRPC, AWS)
    rpc_system = attrs.get("rpc.system", "")
    if rpc_system:
        rpc_service = attrs.get("rpc.service", "")
        rpc_method = attrs.get("rpc.method", "")
        if rpc_service and rpc_method:
            return f"{rpc_system} {rpc_service}.{rpc_method}"

    # Messaging spans (Kafka, RabbitMQ, etc.)
    messaging_system = attrs.get("messaging.system", "")
    if messaging_system:
        destination = attrs.get("messaging.destination.name", "")
        if destination:
            return f"{messaging_system} {span_name} {destination}"

    return span_name


# URL patterns that indicate Waxell's own API calls — these should be excluded
# from tracing to prevent the tracing system from tracing itself.
_EXCLUDED_URL_PATTERNS = ("api/v1/observe", "api/v1/policy", "api/health")

# Hosts whose HTTP spans are pure infrastructure noise (model downloads,
# config fetches, etc.) and should be dropped to keep traces clean.
_NOISY_INFRA_HOSTS = (
    "huggingface.co",
    "cdn-lfs.huggingface.co",
    "cdn-lfs-us-1.huggingface.co",
)

# Known LLM provider API hosts.  HTTP spans to these URLs are suppressed
# because our provider-specific instrumentors (OpenAI, Anthropic, Groq, etc.)
# already record the full LLM call data with tokens, cost, and model info.
# Letting the raw httpx HTTP span through would create a duplicate "tool" span
# with no useful token/cost data.
_LLM_PROVIDER_HOSTS = (
    "api.openai.com",
    "api.anthropic.com",
    "api.groq.com",
    "api.mistral.ai",
    "generativelanguage.googleapis.com",
    "api.cohere.com",
    "bedrock-runtime.",  # AWS Bedrock (regional subdomains)
    "api.together.xyz",
    "api.fireworks.ai",
    "api.deepseek.com",
    "openrouter.ai",
)


def _is_waxell_api_call(attrs: dict) -> bool:
    """Check if a span represents a call to the Waxell API itself."""
    url = (
        attrs.get("url.full")
        or attrs.get("http.url")
        or attrs.get("http.target", "")
    )
    if not url:
        return False
    return any(pattern in url for pattern in _EXCLUDED_URL_PATTERNS)


def _is_llm_provider_http_call(attrs: dict) -> bool:
    """Check if an HTTP span targets a known LLM provider API.

    These are suppressed because our provider instrumentors already record
    the full LLM call with tokens, cost, and model information.
    """
    url = (
        attrs.get("url.full")
        or attrs.get("http.url")
        or attrs.get("server.address", "")
    )
    if not url:
        return False
    url_lower = url.lower()
    return any(host in url_lower for host in _LLM_PROVIDER_HOSTS)


def _is_noisy_infra_call(attrs: dict) -> bool:
    """Check if an HTTP span is infrastructure noise (model downloads, etc.)."""
    url = (
        attrs.get("url.full")
        or attrs.get("http.url")
        or attrs.get("server.address", "")
    )
    if not url:
        return False
    url_lower = url.lower()
    return any(host in url_lower for host in _NOISY_INFRA_HOSTS)


def _span_to_dict(span: "ReadableSpan") -> dict:
    """Convert a completed OTel ReadableSpan to the dict format expected by _spans."""
    attrs = dict(span.attributes or {})
    kind = _resolve_kind(span)

    # Extract timing
    start_ns = span.start_time or 0
    end_ns = span.end_time or 0
    duration_ms = int((end_ns - start_ns) / 1_000_000) if end_ns > start_ns else None

    # Build readable display name for infra spans
    display_name = _build_display_name(span.name, attrs)

    # Build a clean attributes dict (strip waxell internal prefixes for readability)
    clean_attrs = {}
    for k, v in attrs.items():
        # Promote well-known GenAI attributes to top-level keys
        if k.startswith("gen_ai.") or k.startswith("waxell."):
            # Strip prefix for cleaner display
            short_key = k.split(".", 1)[-1] if "." in k else k
            clean_attrs[short_key] = v
        else:
            clean_attrs[k] = v

    # Extract input/output data from attributes
    input_data = None
    output_data = None

    # For tool spans from @waxell.tool decorator, extract input/output
    if kind == "tool" and "waxell.tool.input" in attrs:
        import json as _json
        try:
            input_data = _json.loads(attrs.get("waxell.tool.input", "{}"))
        except Exception:
            pass
        try:
            output_data = _json.loads(attrs.get("waxell.tool.output", "{}"))
        except Exception:
            pass
        # Use tool status if set (override OTel status)
        tool_status = attrs.get("waxell.tool.status")
        if tool_status:
            status = tool_status

    # For LLM spans, extract previews
    if kind == "llm":
        model = attrs.get("gen_ai.request.model") or attrs.get("waxell.llm.model", "")
        tokens_in = attrs.get("gen_ai.usage.input_tokens") or attrs.get("waxell.llm.input_tokens", 0)
        tokens_out = attrs.get("gen_ai.usage.output_tokens") or attrs.get("waxell.llm.output_tokens", 0)
        cost = attrs.get("waxell.llm.cost", 0)

        clean_attrs["model"] = model
        clean_attrs["tokens_in"] = tokens_in
        clean_attrs["tokens_out"] = tokens_out
        clean_attrs["total_tokens"] = tokens_in + tokens_out
        clean_attrs["cost"] = cost

        # Include finish reasons if available
        finish_reasons = attrs.get("gen_ai.response.finish_reasons")
        if finish_reasons:
            clean_attrs["finish_reasons"] = finish_reasons

        response_model = attrs.get("gen_ai.response.model")
        if response_model and response_model != model:
            clean_attrs["response_model"] = response_model

    # Extract OTel trace/span IDs for correlation
    ctx = span.context
    otel_trace_id = ""
    otel_span_id = ""
    otel_parent_id = ""
    if ctx:
        otel_trace_id = format(ctx.trace_id, "032x")
        otel_span_id = format(ctx.span_id, "016x")
    if span.parent and span.parent.span_id:
        otel_parent_id = format(span.parent.span_id, "016x")

    # Determine status
    status = "ok"
    if span.status and span.status.status_code:
        from opentelemetry.trace import StatusCode
        if span.status.status_code == StatusCode.ERROR:
            status = "error"

    return {
        "name": display_name,
        "kind": kind,
        "status": status,
        "duration_ms": duration_ms,
        "attributes": clean_attrs,
        "input_data": input_data,
        "output_data": output_data,
        # Processor-sourced spans use absolute timestamps, not offsets.
        # The server-side handler will use these if start_offset_ms is absent.
        "_otel_start_ns": start_ns,
        "_otel_end_ns": end_ns,
        "_otel_trace_id": otel_trace_id,
        "_otel_span_id": otel_span_id,
        "_otel_parent_id": otel_parent_id,
        "_from_processor": True,
    }


if _HAS_OTEL:

    class WaxellSpanProcessor(SpanProcessor):
        """Captures completed OTel spans into the active WaxellContext._spans buffer."""

        def on_start(self, span: "ReadableSpan", parent_context=None) -> None:
            pass  # Nothing to do on start

        def on_end(self, span: "ReadableSpan") -> None:
            """Called when a span ends. Convert and buffer it."""
            try:
                from ..instrumentors._context_var import _current_context

                ctx = _current_context.get()
                if ctx is None or not ctx.run_id:
                    return  # No active context — drop the span

                attrs = span.attributes or {}

                # Skip spans created by our own span helpers (start_llm_span,
                # start_step_span, etc.) — these are already recorded in _spans
                # via record_llm_call(), record_step(), etc.
                if attrs.get("waxell.span_type"):
                    return

                # Skip Waxell API calls — prevents tracing the tracing system.
                # httpx instrumentor doesn't support excluded_urls, so we filter here.
                if _is_waxell_api_call(attrs):
                    return

                # Skip httpx HTTP spans to known LLM provider APIs.
                # Our provider instrumentors already record these as proper LLM
                # spans with tokens/cost/model; the raw HTTP span would appear
                # as a duplicate "tool" kind with no useful data.
                if _is_llm_provider_http_call(attrs):
                    return

                # Skip noisy infrastructure calls (model downloads, etc.)
                if _is_noisy_infra_call(attrs):
                    return

                span_dict = _span_to_dict(span)
                ctx._otel_spans.append(span_dict)
            except Exception:
                pass  # Never break the user's code

        def shutdown(self) -> None:
            pass

        def force_flush(self, timeout_millis: int = 30000) -> bool:
            return True

else:

    class WaxellSpanProcessor:  # type: ignore[no-redef]
        """No-op processor when OTel is not installed."""

        def on_start(self, span, parent_context=None):
            pass

        def on_end(self, span):
            pass

        def shutdown(self):
            pass

        def force_flush(self, timeout_millis=30000):
            return True
