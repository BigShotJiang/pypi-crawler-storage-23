"""OTel span attribute constants.

Uses raw strings instead of the semconv package constants,
since the OpenTelemetry semantic conventions package is beta
and constant names may change.
"""


class GenAIAttributes:
    """OpenTelemetry GenAI semantic convention attributes (gen_ai.*)."""

    OPERATION_NAME = "gen_ai.operation.name"
    PROVIDER_NAME = "gen_ai.provider.name"
    REQUEST_MODEL = "gen_ai.request.model"
    RESPONSE_MODEL = "gen_ai.response.model"
    REQUEST_TEMPERATURE = "gen_ai.request.temperature"
    REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
    USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"
    INPUT_MESSAGES = "gen_ai.input.messages"
    OUTPUT_MESSAGES = "gen_ai.output.messages"
    AGENT_NAME = "gen_ai.agent.name"
    AGENT_ID = "gen_ai.agent.id"
    TOOL_NAME = "gen_ai.tool.name"
    TOOL_TYPE = "gen_ai.tool.type"


class WaxellAttributes:
    """Waxell-specific span attributes (waxell.*).

    Aligned with infra's TenantAwareSpanProcessor attributes.
    """

    AGENT_NAME = "waxell.agent_name"
    AGENT_ID = "waxell.agent_id"
    WORKFLOW_NAME = "waxell.workflow_name"
    RUN_ID = "waxell.run_id"
    TOOL = "waxell.tool"
    STEP_NAME = "waxell.step_name"
    STEP_POSITION = "waxell.step_position"
    TENANT_ID = "waxell.tenant_id"
    POLICY_RESULT = "waxell.policy_result"
    SESSION_ID = "waxell.session_id"
    USER_ID = "waxell.user_id"
    USER_GROUP = "waxell.user_group"

    # Span type (required by all Grafana dashboards)
    SPAN_TYPE = "waxell.span_type"

    # LLM attributes (aligned with dashboard TraceQL queries)
    LLM_MODEL = "waxell.llm.model"
    LLM_COST = "waxell.llm.cost"
    LLM_INPUT_TOKENS = "waxell.llm.input_tokens"
    LLM_OUTPUT_TOKENS = "waxell.llm.output_tokens"
    LLM_TOTAL_TOKENS = "waxell.llm.total_tokens"

    # Embedding attributes
    EMBEDDING_MODEL = "waxell.embedding.model"
    EMBEDDING_DIMENSIONS = "waxell.embedding.dimensions"
    EMBEDDING_INPUT_TOKENS = "waxell.embedding.input_tokens"
    EMBEDDING_INPUT_COUNT = "waxell.embedding.input_count"
    EMBEDDING_COST = "waxell.embedding.cost"

    # Guardrail attributes
    GUARDRAIL_NAME = "waxell.guardrail.name"
    GUARDRAIL_PASSED = "waxell.guardrail.passed"
    GUARDRAIL_ACTION = "waxell.guardrail.action"

    # Evaluation attributes
    EVAL_FRAMEWORK = "waxell.eval.framework"
    EVAL_METRIC_NAME = "waxell.eval.metric_name"
    EVAL_SCORE = "waxell.eval.score"
    EVAL_THRESHOLD = "waxell.eval.threshold"
    EVAL_PASSED = "waxell.eval.passed"
    EVAL_REASON = "waxell.eval.reason"
    EVAL_TEST_CASES_COUNT = "waxell.eval.test_cases_count"
    EVAL_METRICS_COUNT = "waxell.eval.metrics_count"
    EVAL_PASS_RATE = "waxell.eval.pass_rate"

    # Custom tag/metadata prefixes (for user-defined searchable attributes)
    TAG_PREFIX = "waxell.tag."
    META_PREFIX = "waxell.meta."
