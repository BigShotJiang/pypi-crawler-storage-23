"""@waxell.step decorator for automatic execution step recording.

Wraps any function so that each invocation is automatically recorded as
an execution step on the current WaxellContext. The function's return
value is captured as the step output.

Usage::

    import waxell_observe as waxell

    @waxell.step(name="preprocess")
    async def preprocess_query(query: str) -> dict:
        cleaned = query.strip().lower()
        return {"original": query, "cleaned": cleaned}

    # Inside a WaxellContext, this call auto-records:
    #   step(step_name="preprocess", output={"original": "...", "cleaned": "..."})

    # Outside a WaxellContext, it just runs normally.
"""

import functools
import inspect
from typing import Optional

from .instrumentors._context_var import _current_context


def step(
    name: Optional[str] = None,
):
    """Decorator to auto-record function calls as execution steps.

    Args:
        name: Step name for telemetry. Defaults to the function name.
    """

    def decorator(func):
        _step_name = name or func.__name__
        _is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            ctx = _current_context.get()

            result = await func(*args, **kwargs)

            if ctx:
                ctx.record_step(_step_name, output=_safe_output(result))
            return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            ctx = _current_context.get()

            result = func(*args, **kwargs)

            if ctx:
                ctx.record_step(_step_name, output=_safe_output(result))
            return result

        return async_wrapper if _is_async else sync_wrapper

    return decorator


def _safe_output(result) -> dict:
    """Convert a function return value to a serializable dict."""
    if result is None:
        return {}
    if isinstance(result, dict):
        # Truncate large values for telemetry
        safe = {}
        for k, v in result.items():
            if isinstance(v, str) and len(v) > 500:
                safe[str(k)] = v[:500] + "..."
            elif isinstance(v, (list, tuple)) and len(v) > 10:
                safe[str(k)] = f"[{type(v).__name__} len={len(v)}]"
            elif isinstance(v, (str, int, float, bool, type(None))):
                safe[str(k)] = v
            else:
                safe[str(k)] = str(v)[:200]
        return safe
    if isinstance(result, (str, int, float, bool)):
        return {"result": result}
    return {"result": str(result)[:200]}
