"""@waxell.retrieval decorator for automatic retrieval recording.

Wraps any function that performs a search or retrieval operation so that
the query, returned documents, scores, and timing are automatically
recorded on the current WaxellContext.

Usage::

    import waxell_observe as waxell

    @waxell.retrieval(source="faiss")
    async def search_documents(query: str, top_k: int = 5) -> list[dict]:
        results = await vector_store.search(query, top_k=top_k)
        return [{"id": r.id, "title": r.title, "score": r.score} for r in results]

    # Returns the documents AND auto-records:
    #   retrieval(query="...", documents=[...], source="faiss", scores=[...])
"""

import functools
import inspect
import time
from typing import Optional

from .instrumentors._context_var import _current_context


def retrieval(
    source: str = "",
    name: Optional[str] = None,
):
    """Decorator to auto-record function calls as retrieval operations.

    Args:
        source: Data source name (e.g. "faiss", "pinecone", "elasticsearch").
        name: Override name for telemetry. Defaults to the function name.
    """

    def decorator(func):
        _name = name or func.__name__
        _is_async = inspect.iscoroutinefunction(func)
        _sig = inspect.signature(func)
        _params = list(_sig.parameters.keys())

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            t0 = time.perf_counter()

            result = await func(*args, **kwargs)

            duration_ms = int((time.perf_counter() - t0) * 1000)
            if ctx:
                _record(ctx, _name, source, _params, args, kwargs, result, duration_ms)
            return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            t0 = time.perf_counter()

            result = func(*args, **kwargs)

            duration_ms = int((time.perf_counter() - t0) * 1000)
            if ctx:
                _record(ctx, _name, source, _params, args, kwargs, result, duration_ms)
            return result

        return async_wrapper if _is_async else sync_wrapper

    return decorator


def _record(ctx, name, source, params, args, kwargs, result, duration_ms):
    """Extract retrieval fields from function args and result, then record."""
    # Extract query from first string argument
    query = ""
    for i, val in enumerate(args):
        if isinstance(val, str):
            query = val
            break
    if not query:
        for key in ("query", "q", "question", "search_query"):
            if key in kwargs and isinstance(kwargs[key], str):
                query = kwargs[key]
                break

    # Extract top_k from kwargs or args
    top_k = kwargs.get("top_k") or kwargs.get("k")
    if top_k is None:
        for i, p in enumerate(params):
            if p in ("top_k", "k") and i < len(args):
                top_k = args[i]
                break

    # Result should be a list of document dicts
    documents = []
    scores = []
    if isinstance(result, list):
        for item in result:
            if isinstance(item, dict):
                documents.append(item)
                if "score" in item:
                    scores.append(float(item["score"]))
            else:
                documents.append({"result": str(item)[:200]})
    elif isinstance(result, dict):
        documents = result.get("documents", [])
        scores = result.get("scores", [])

    ctx.record_retrieval(
        query=query,
        documents=documents,
        source=source,
        duration_ms=duration_ms,
        top_k=int(top_k) if top_k is not None else None,
        scores=scores or None,
    )
