"""Rich display utilities for wax CLI."""
from typing import Any, Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.text import Text
from rich.tree import Tree

console = Console()

STATUS_COLORS = {
    "active": "green",
    "enabled": "green",
    "running": "green",
    "completed": "green",
    "success": "green",
    "inactive": "dim",
    "disabled": "dim",
    "paused": "yellow",
    "pending": "yellow",
    "warning": "yellow",
    "failed": "red",
    "error": "red",
    "killed": "red",
    "triggered": "red",
}


def status_badge(status: str) -> Text:
    """Create a colored status badge."""
    color = STATUS_COLORS.get(status.lower(), "white")
    return Text(f" {status.upper()} ", style=f"bold {color} on {color}")


def status_dot(status: str) -> str:
    """Create a colored status dot."""
    color = STATUS_COLORS.get(status.lower(), "white")
    return f"[{color}]\u25cf[/{color}]"


def print_header(title: str, subtitle: Optional[str] = None):
    """Print a styled header."""
    console.print()
    console.print(f"[bold cyan]{title}[/bold cyan]")
    if subtitle:
        console.print(f"[dim]{subtitle}[/dim]")
    console.print()


def print_success(message: str):
    console.print(f"[green]\u2713[/green] {message}")


def print_error(message: str):
    console.print(f"[red]\u2717[/red] {message}")


def print_warning(message: str):
    console.print(f"[yellow]![/yellow] {message}")


def print_info(message: str):
    console.print(f"[blue]\u2139[/blue] {message}")


def loading_spinner(message: str = "Loading..."):
    """Create a loading spinner context manager."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        console=console,
        transient=True,
    )


def fmt_number(n: Any) -> str:
    """Format a number with commas."""
    if isinstance(n, (int, float)):
        if isinstance(n, float) and n == int(n):
            return f"{int(n):,}"
        return f"{n:,}"
    return str(n)


def fmt_cost(n: Any) -> str:
    """Format a dollar amount."""
    if isinstance(n, (int, float)):
        return f"${n:,.2f}"
    return str(n)


def fmt_tokens(n: Any) -> str:
    """Format token counts with K/M suffixes."""
    if isinstance(n, (int, float)):
        if n >= 1_000_000:
            return f"{n / 1_000_000:.1f}M"
        if n >= 1_000:
            return f"{n / 1_000:.1f}K"
        return fmt_number(n)
    return str(n)


def fmt_duration(seconds: Any) -> str:
    """Format a duration in seconds to human-readable."""
    if not isinstance(seconds, (int, float)):
        return str(seconds)
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    if seconds < 3600:
        mins = int(seconds // 60)
        secs = seconds % 60
        return f"{mins}m {secs:.0f}s"
    hours = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    return f"{hours}h {mins}m"


def pct_color(value: float, warn: float = 70, danger: float = 90) -> str:
    """Return Rich color name based on percentage thresholds."""
    if value < warn:
        return "green"
    if value < danger:
        return "yellow"
    return "red"


def trend_arrow(trend: Any) -> str:
    """Format a trend value with arrow."""
    if trend is None:
        return ""
    try:
        val = float(trend)
    except (TypeError, ValueError):
        return ""
    if val > 0:
        return f"[green]\u2191{val:+.1f}%[/green]"
    if val < 0:
        return f"[red]\u2193{val:+.1f}%[/red]"
    return "[dim]--[/dim]"


def usage_gauge(label: str, current: float, limit: float, width: int = 40):
    """Display a usage gauge."""
    pct = (current / limit * 100) if limit > 0 else 0
    filled = int((pct / 100) * width)
    empty = width - filled
    color = pct_color(pct)

    bar = f"[{color}]{'\u2588' * filled}[/{color}][dim]{'\u2591' * empty}[/dim]"
    console.print(f"{label}")
    console.print(f"  {bar} {pct:.1f}%")
    console.print(f"  [dim]{current:,.0f} / {limit:,.0f}[/dim]")
    console.print()


def print_tree(name: str, items: dict[str, Any], style: str = "cyan"):
    """Print a tree structure."""
    tree = Tree(f"[bold {style}]{name}[/bold {style}]")
    _add_tree_items(tree, items)
    console.print(tree)


def _add_tree_items(tree: Tree, items: dict[str, Any]):
    for key, value in items.items():
        if isinstance(value, dict):
            branch = tree.add(f"[bold]{key}[/bold]")
            _add_tree_items(branch, value)
        elif isinstance(value, list):
            branch = tree.add(f"[bold]{key}[/bold]")
            for item in value:
                if isinstance(item, dict):
                    _add_tree_items(branch, item)
                else:
                    branch.add(str(item))
        else:
            tree.add(f"[bold]{key}:[/bold] {value}")
