"""Agent fleet management commands."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    fmt_cost,
    fmt_duration,
    pct_color,
)
from rich.table import Table
from rich.panel import Panel


PERIOD_TO_HOURS = {"1h": 1, "24h": 24, "7d": 168, "30d": 720}


@click.group()
def agents():
    """Agent fleet management and analytics."""
    pass


@agents.command("list")
@click.option(
    "--period",
    type=click.Choice(["1h", "24h", "7d", "30d"]),
    default="24h",
    help="Time period for metrics.",
)
@click.option(
    "--sort",
    type=click.Choice(["-executions", "-error_rate", "-cost"]),
    default="-executions",
    help="Sort order.",
)
@click.option("--limit", type=int, default=25, help="Maximum agents to display.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def agents_list(ctx, period: str, sort: str, limit: int, output_format: str):
    """List all agents with execution metrics."""
    data = api_get(ctx, "/v1/observe/query/agents/", params={"period": period})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    agents_data = data.get("agents", [])
    if not agents_data:
        print_warning("No agents found for the selected period.")
        return

    # Sort
    sort_key = sort.lstrip("-")
    agents_data.sort(key=lambda a: a.get(sort_key, 0), reverse=True)
    agents_data = agents_data[:limit]

    print_header("Agent Fleet", f"Period: {period} | {len(agents_data)} agents")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Agent", style="bold")
    table.add_column("Executions", justify="right")
    table.add_column("Error Rate", justify="right")
    table.add_column("Avg Latency", justify="right")
    table.add_column("Cost ($)", justify="right")
    table.add_column("Users", justify="right")
    table.add_column("Sessions", justify="right")
    table.add_column("Last Run", style="dim")

    for agent in agents_data:
        error_rate = agent.get("error_rate", 0)
        error_color = pct_color(error_rate * 100 if error_rate < 1 else error_rate)
        error_pct = error_rate * 100 if error_rate < 1 else error_rate

        table.add_row(
            agent.get("name", "unknown"),
            fmt_number(agent.get("executions", 0)),
            f"[{error_color}]{error_pct:.1f}%[/{error_color}]",
            fmt_duration(agent.get("avg_latency", 0)),
            fmt_cost(agent.get("cost", 0)),
            fmt_number(agent.get("users", 0)),
            fmt_number(agent.get("sessions", 0)),
            str(agent.get("last_run", "-")),
        )

    console.print(table)
    console.print()


@agents.command("show")
@click.argument("name")
@click.option(
    "--period",
    type=click.Choice(["1h", "24h", "7d", "30d"]),
    default="24h",
    help="Time period for metrics.",
)
@click.pass_context
def agents_show(ctx, name: str, period: str):
    """Show detailed metrics for a specific agent."""
    data = api_get(
        ctx, "/v1/observe/query/agents/", params={"name": name, "period": period}
    )

    agents_data = data.get("agents", [])
    if not agents_data:
        print_warning(f"No data found for agent '{name}' in period {period}.")
        return

    agent = agents_data[0]
    print_header(f"Agent: {name}", f"Period: {period}")

    # KPI panel
    executions = fmt_number(agent.get("executions", 0))
    error_rate = agent.get("error_rate", 0)
    error_pct = error_rate * 100 if error_rate < 1 else error_rate
    cost = fmt_cost(agent.get("cost", 0))
    tokens = fmt_number(agent.get("total_tokens", 0))
    avg_dur = fmt_duration(agent.get("avg_duration", 0))

    kpi_text = (
        f"[bold]Executions:[/bold] {executions}    "
        f"[bold]Error Rate:[/bold] {error_pct:.1f}%    "
        f"[bold]Cost:[/bold] {cost}\n"
        f"[bold]Tokens:[/bold] {tokens}    "
        f"[bold]Avg Duration:[/bold] {avg_dur}"
    )
    console.print(Panel(kpi_text, title="KPIs", border_style="cyan"))
    console.print()

    # Cost by model
    models = agent.get("models", agent.get("cost_by_model", []))
    if models:
        model_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        model_table.add_column("Model", style="bold")
        model_table.add_column("Calls", justify="right")
        model_table.add_column("Cost", justify="right")
        model_table.add_column("Tokens", justify="right")

        for model in models:
            model_table.add_row(
                model.get("model", "unknown"),
                fmt_number(model.get("calls", 0)),
                fmt_cost(model.get("cost", 0)),
                fmt_number(model.get("tokens", 0)),
            )

        console.print(model_table)
        console.print()

    # Top users
    users = agent.get("top_users", [])
    if users:
        user_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        user_table.add_column("User", style="bold")
        user_table.add_column("Runs", justify="right")
        user_table.add_column("Cost", justify="right")

        for user in users[:10]:
            user_table.add_row(
                str(user.get("user_id", user.get("user", "unknown"))),
                fmt_number(user.get("runs", 0)),
                fmt_cost(user.get("cost", 0)),
            )

        console.print(user_table)
        console.print()
