"""Billing management commands."""
import json

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    fmt_cost,
    usage_gauge,
)


@click.group()
def billing():
    """View billing and subscription information."""


@billing.command("overview")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def billing_overview(ctx, fmt: str):
    """Show billing overview for the current period."""
    data = api_get(ctx, "/v1/observe/query/billing/", params={"hours": 720})

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    if not data:
        print_warning("No billing data available.")
        return

    print_header("Billing Overview")

    # Extract billing info -- handle various response shapes
    if isinstance(data, dict):
        billing_data = data.get("billing", data.get("summary", data))
    else:
        billing_data = {}

    plan = billing_data.get("plan", billing_data.get("plan_name", billing_data.get("current_plan", "-")))
    period = billing_data.get("billing_period", billing_data.get("period", "-"))
    total_cost = billing_data.get("total_cost", billing_data.get("cost", billing_data.get("amount", 0)))
    projected = billing_data.get("projected_cost", billing_data.get("projected", 0))

    lines = [
        f"[bold]Current Plan:[/bold]    {plan}",
        f"[bold]Billing Period:[/bold]  {period}",
        "",
        f"[bold]Total Cost:[/bold]      {fmt_cost(total_cost)}",
        f"[bold]Projected Cost:[/bold]  {fmt_cost(projected)}",
    ]

    # Cost breakdown
    breakdown = billing_data.get("breakdown", billing_data.get("cost_breakdown", {}))
    if breakdown and isinstance(breakdown, dict):
        lines.append("")
        lines.append("[bold]Cost Breakdown:[/bold]")
        for category, amount in breakdown.items():
            lines.append(f"  {category}: {fmt_cost(amount)}")

    # Invoice status
    invoice = billing_data.get("invoice", billing_data.get("latest_invoice", {}))
    if invoice and isinstance(invoice, dict):
        lines.append("")
        lines.append(f"[bold]Invoice Status:[/bold] {invoice.get('status', '-')}")
        lines.append(f"[bold]Invoice Date:[/bold]   {invoice.get('date', '-')}")

    console.print(Panel("\n".join(lines), title="Billing Summary", border_style="cyan"))

    # Usage limits
    limits = billing_data.get("limits", billing_data.get("usage_limits", {}))
    if limits and isinstance(limits, dict):
        console.print()
        console.print("[bold]Usage vs. Limits:[/bold]")
        console.print()
        for name, info in limits.items():
            if isinstance(info, dict):
                current = info.get("used", info.get("current", 0)) or 0
                limit = info.get("limit", info.get("max", 0)) or 0
                if limit > 0:
                    usage_gauge(name, float(current), float(limit))

    console.print()


@billing.command("usage")
@click.option("--hours", default=720, type=int, help="Look back N hours (default: 720 = ~30 days)")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def billing_usage(ctx, hours: int, fmt: str):
    """Show usage breakdown for billing."""
    data = api_get(ctx, "/v1/observe/query/billing/", params={"hours": hours})

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    if not data:
        print_warning("No usage data available.")
        return

    print_header("Billing Usage", f"Last {hours} hours")

    # Extract usage data
    if isinstance(data, dict):
        usage_data = data.get("usage", data.get("metrics", data))
    else:
        usage_data = {}

    if isinstance(usage_data, dict):
        items = usage_data.get("items", usage_data.get("metrics", []))
        if not isinstance(items, list):
            # Flat dict -- convert to table rows
            items = [{"metric": k, "value": v} for k, v in usage_data.items()
                     if k not in ("items", "metrics", "limits", "billing")]
    else:
        items = usage_data if isinstance(usage_data, list) else []

    if not items:
        # Try to display top-level numeric fields as usage metrics
        if isinstance(data, dict):
            items = []
            for k, v in data.items():
                if isinstance(v, (int, float)) and k not in ("hours", "status"):
                    items.append({"metric": k, "value": v})

    if not items:
        print_warning("No usage metrics found.")
        return

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Metric", style="bold")
    table.add_column("Used", justify="right")
    table.add_column("Limit", justify="right")
    table.add_column("Usage", justify="right")

    for item in items:
        if isinstance(item, dict):
            metric = item.get("metric", item.get("name", "-"))
            used = item.get("value", item.get("used", item.get("current", 0))) or 0
            limit = item.get("limit", item.get("max", 0)) or 0

            if limit > 0:
                pct = used / limit * 100
                if pct >= 90:
                    pct_str = f"[red]{pct:.1f}%[/red]"
                elif pct >= 70:
                    pct_str = f"[yellow]{pct:.1f}%[/yellow]"
                else:
                    pct_str = f"[green]{pct:.1f}%[/green]"
            else:
                pct_str = "-"

            table.add_row(
                metric,
                fmt_number(used),
                fmt_number(limit) if limit > 0 else "unlimited",
                pct_str,
            )

    console.print(table)
    console.print()

    # Visual gauge bars for items with limits
    for item in items:
        if isinstance(item, dict):
            limit = item.get("limit", item.get("max", 0)) or 0
            used = item.get("value", item.get("used", item.get("current", 0))) or 0
            if limit > 0:
                usage_gauge(
                    item.get("metric", item.get("name", "Usage")),
                    float(used),
                    float(limit),
                )
