"""Session browser commands."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
    fmt_number,
    fmt_cost,
    fmt_duration,
)
from rich.table import Table
from rich.panel import Panel


@click.group()
def sessions():
    """Session browser and analytics."""
    pass


@sessions.command("list")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option("--limit", type=int, default=25, help="Maximum sessions to display.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def sessions_list(ctx, hours: int, limit: int, output_format: str):
    """List recent sessions."""
    data = api_get(ctx, "/v1/observe/query/sessions/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    sessions_data = data.get("sessions", [])
    if not sessions_data:
        print_warning("No sessions found for the selected period.")
        return

    sessions_data = sessions_data[:limit]
    print_header("Sessions", f"Last {hours}h | {len(sessions_data)} sessions")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Session ID", style="bold", max_width=24)
    table.add_column("Runs", justify="right")
    table.add_column("Duration", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Agents")
    table.add_column("Last Activity", style="dim")

    for session in sessions_data:
        session_id = str(session.get("session_id", session.get("id", "")))
        agents_list = session.get("agents", [])
        agents_str = ", ".join(agents_list[:3]) if isinstance(agents_list, list) else str(agents_list)
        if isinstance(agents_list, list) and len(agents_list) > 3:
            agents_str += f" +{len(agents_list) - 3}"

        table.add_row(
            session_id,
            fmt_number(session.get("run_count", session.get("runs", 0))),
            fmt_duration(session.get("duration", session.get("total_duration", 0))),
            fmt_cost(session.get("cost", session.get("total_cost", 0))),
            agents_str,
            str(session.get("last_activity", session.get("last_seen", "-"))),
        )

    console.print(table)
    console.print()


@sessions.command("show")
@click.argument("session_id")
@click.option("--hours", type=int, default=168, help="Time window in hours.")
@click.pass_context
def sessions_show(ctx, session_id: str, hours: int):
    """Show all runs in a session timeline."""
    data = api_get(
        ctx,
        "/v1/observe/query/sessions/",
        params={"session_id": session_id, "hours": hours},
    )

    sessions_data = data.get("sessions", [])
    if not sessions_data:
        print_warning(f"Session '{session_id}' not found.")
        return

    session = sessions_data[0]
    print_header(f"Session: {session_id}")

    # Summary panel
    summary_lines = [
        f"[bold]Runs:[/bold]     {fmt_number(session.get('run_count', session.get('runs', 0)))}",
        f"[bold]Duration:[/bold] {fmt_duration(session.get('duration', session.get('total_duration', 0)))}",
        f"[bold]Cost:[/bold]     {fmt_cost(session.get('cost', session.get('total_cost', 0)))}",
    ]

    agents_list = session.get("agents", [])
    if agents_list:
        agents_str = ", ".join(agents_list) if isinstance(agents_list, list) else str(agents_list)
        summary_lines.append(f"[bold]Agents:[/bold]   {agents_str}")

    console.print(
        Panel("\n".join(summary_lines), title="Session Summary", border_style="cyan")
    )
    console.print()

    # Run timeline
    runs = session.get("runs", session.get("timeline", []))
    if runs:
        table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        table.add_column("#", justify="right", width=4)
        table.add_column("Run ID", style="bold", max_width=14)
        table.add_column("Agent")
        table.add_column("Status")
        table.add_column("Duration", justify="right")
        table.add_column("Cost", justify="right")
        table.add_column("Started", style="dim")

        for i, run in enumerate(runs, 1):
            run_status = run.get("status", "unknown")
            table.add_row(
                str(i),
                str(run.get("run_id", run.get("id", "")))[:12],
                run.get("agent_name", run.get("agent", "-")),
                f"{status_dot(run_status)} {run_status}",
                fmt_duration(run.get("duration", run.get("duration_seconds", 0))),
                fmt_cost(run.get("cost", 0)),
                str(run.get("started_at", run.get("created_at", "-"))),
            )

        console.print(table)
        console.print()
