"""Login command for wax CLI."""
import click
import httpx

from .._config import save_config
from .._display import (
    console,
    print_header,
    print_success,
    print_error,
    print_info,
)

DEFAULT_API_URL = "https://api.waxell.dev"
LOCAL_API_URL = "http://localhost:8001"


@click.command()
@click.option(
    "--profile",
    default=None,
    help="Profile name to save credentials under (default: 'default' for prod, 'local' for --local)",
)
@click.option(
    "--local",
    is_flag=True,
    help="Connect to local development server (localhost:8001)",
)
@click.option(
    "--url",
    default=None,
    help="Custom API URL (overrides --local)",
)
@click.pass_context
def login(ctx, profile: str, local: bool, url: str):
    """Authenticate with Waxell and save API key.

    By default connects to api.waxell.dev. Use --local for local development.
    Credentials are saved to separate profiles so they don't overwrite each other.
    """
    # Check both command-level and global flags
    global_local = ctx.obj.get("local", False) if ctx.obj else False
    global_profile = ctx.obj.get("profile") if ctx.obj else None
    is_local = local or global_local

    # Profile resolution: command-level > global --profile > --local > default
    if profile is None:
        if global_profile:
            profile = global_profile
        elif is_local:
            profile = "local"
        else:
            profile = "default"

    # Determine API URL
    if url:
        api_url = url
    elif is_local:
        api_url = LOCAL_API_URL
    else:
        api_url = DEFAULT_API_URL

    print_header("Waxell Login")

    if is_local:
        print_info(f"Connecting to local server: {api_url}")
        print_info("Get your API key from: http://localhost:3000/settings/api-keys")
    else:
        print_info("Get your API key from: https://app.waxell.dev/settings/api-keys")

    console.print()
    api_key = click.prompt("Paste your API key", hide_input=True)

    # Strip whitespace and any non-ASCII characters that might get pasted
    api_key = api_key.strip()
    api_key = "".join(c for c in api_key if ord(c) < 128)

    if not api_key:
        print_error("No API key provided.")
        raise SystemExit(1)

    # Validate the key by calling /auth/me (direct httpx since we don't have config yet)
    console.print()
    console.print("[dim]Validating API key...[/dim]")

    try:
        response = httpx.get(
            f"{api_url}/api/v1/auth/me",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10,
            verify=not is_local,
        )

        if response.status_code == 401:
            print_error("Invalid API key.")
            raise SystemExit(1)

        if response.status_code != 200:
            print_error(f"Validation failed: {response.status_code}")
            console.print(f"[dim]{response.text}[/dim]", highlight=False)
            raise SystemExit(1)

        user_data = response.json()
        tenant_name = user_data.get("tenant", {}).get("name", "Unknown")
        user_email = user_data.get("user", {}).get("email", "Unknown")

    except httpx.ConnectError:
        print_error(f"Could not connect to {api_url}")
        if is_local:
            print_info("Make sure your local server is running (docker-compose up)")
        else:
            print_info("Check your internet connection and try again.")
        raise SystemExit(1)
    except httpx.RequestError as e:
        print_error(f"Connection error: {e}")
        raise SystemExit(1)

    # Save to config file
    config_path = save_config(profile, api_url, api_key)

    console.print()
    print_success("Logged in successfully!")
    console.print(f"  [bold]Tenant:[/bold]  {tenant_name}")
    console.print(f"  [bold]User:[/bold]    {user_email}")
    console.print(f"  [bold]Profile:[/bold] {profile}")
    console.print(f"  [bold]Config:[/bold]  {config_path}")
    console.print()
