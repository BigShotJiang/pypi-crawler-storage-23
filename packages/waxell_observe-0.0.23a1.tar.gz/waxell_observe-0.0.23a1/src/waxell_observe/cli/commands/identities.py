"""Identity and SSO management commands."""
import json

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
)


def _normalize_items(data, key: str = "identities"):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get(key, data.get("identity_providers", data.get("results", data.get("items", data))))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


@click.group()
def identities():
    """Manage identity providers and SSO."""


@identities.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def identities_list(ctx, fmt: str):
    """List identity providers."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data)

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No identity providers configured.")
        return

    print_header("Identity Providers", f"{len(items)} providers")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Provider", style="bold")
    table.add_column("Status", justify="center")
    table.add_column("Users", justify="right")
    table.add_column("Domain")
    table.add_column("Protocol")

    for idp in items:
        is_active = idp.get("is_active", idp.get("enabled", idp.get("status", "") == "active"))
        status = "active" if is_active else "inactive"
        user_count = idp.get("user_count", idp.get("users_count", len(idp.get("users", []))))

        table.add_row(
            idp.get("provider", idp.get("name", "-")),
            status_dot(status),
            str(user_count),
            idp.get("domain", idp.get("email_domain", "-")),
            idp.get("protocol", idp.get("type", "-")),
        )

    console.print(table)
    console.print()


@identities.command("show")
@click.argument("id")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def identities_show(ctx, id: str, fmt: str):
    """Show identity provider details."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data)

    idp = None
    for item in items:
        if (str(item.get("id", "")) == id
                or item.get("provider", item.get("name", "")).lower() == id.lower()):
            idp = item
            break

    if not idp:
        print_warning(f'Identity provider "{id}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(idp, indent=2))
        return

    print_header(f"Identity Provider: {idp.get('provider', idp.get('name', '-'))}")

    is_active = idp.get("is_active", idp.get("enabled", idp.get("status", "") == "active"))
    status = "active" if is_active else "inactive"

    lines = [
        f"[bold]Provider:[/bold]    {idp.get('provider', idp.get('name', '-'))}",
        f"[bold]ID:[/bold]          {idp.get('id', '-')}",
        f"[bold]Status:[/bold]      {status_dot(status)} {status}",
        f"[bold]Protocol:[/bold]    {idp.get('protocol', idp.get('type', '-'))}",
        f"[bold]Domain:[/bold]      {idp.get('domain', idp.get('email_domain', '-'))}",
    ]

    # Configuration details
    config = idp.get("config", idp.get("configuration", {}))
    if config and isinstance(config, dict):
        lines.append("")
        lines.append("[bold]Configuration:[/bold]")
        for k, v in config.items():
            # Mask sensitive values
            display_val = str(v)
            if any(s in k.lower() for s in ("secret", "key", "password", "token")):
                display_val = display_val[:4] + "****" if len(display_val) > 4 else "****"
            lines.append(f"  {k}: {display_val}")

    # Users using this provider
    users = idp.get("users", [])
    if users:
        lines.append("")
        lines.append(f"[bold]Users:[/bold] {len(users)}")
        for u in users[:10]:
            if isinstance(u, dict):
                lines.append(f"  - {u.get('email', str(u))}")
            else:
                lines.append(f"  - {u}")
        if len(users) > 10:
            lines.append(f"  ... and {len(users) - 10} more")

    console.print(Panel("\n".join(lines), border_style="cyan"))
    console.print()
