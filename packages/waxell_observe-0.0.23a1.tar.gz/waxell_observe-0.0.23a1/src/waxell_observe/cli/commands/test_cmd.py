"""Connectivity test command for wax CLI."""
import time

import click
import httpx

from .._config import get_config_from_context, get_config_path
from .._display import (
    console,
    print_header,
    fmt_number,
)


def _step_pass(label: str, detail: str = ""):
    """Print a passing step."""
    if detail:
        console.print(f"  [green]\u2713[/green] {label} [dim]{detail}[/dim]")
    else:
        console.print(f"  [green]\u2713[/green] {label}")


def _step_fail(label: str, detail: str = ""):
    """Print a failing step."""
    if detail:
        console.print(f"  [red]\u2717[/red] {label} [dim]{detail}[/dim]")
    else:
        console.print(f"  [red]\u2717[/red] {label}")


def _step_warn(label: str, detail: str = ""):
    """Print a warning step."""
    if detail:
        console.print(f"  [yellow]![/yellow] {label} [dim]{detail}[/dim]")
    else:
        console.print(f"  [yellow]![/yellow] {label}")


@click.command(name="test")
@click.pass_context
def test(ctx):
    """Test connectivity and authentication with the Waxell API.

    Runs a multi-step check to verify your CLI configuration,
    API reachability, authentication, and data flow.
    """
    print_header("Waxell Connectivity Test")

    passed = 0
    failed = 0
    total_steps = 5

    # ── Step 1: Load configuration ──────────────────────────────────────
    console.print("[bold]1. Configuration[/bold]")

    try:
        config = get_config_from_context(ctx)
    except (ValueError, click.ClickException) as e:
        _step_fail("Load config", str(e))
        _step_fail("No API key found - run 'wax login' to authenticate")
        console.print()
        console.print(
            f"[dim]Config file: {get_config_path()}[/dim]"
        )
        raise SystemExit(1)

    _step_pass("Profile", config.profile)
    _step_pass("API URL", config.api_url)

    key_prefix = config.api_key[:8] + "..." if len(config.api_key) > 8 else "****"
    _step_pass("API Key", key_prefix)
    _step_pass("Config file", str(get_config_path()))
    passed += 1
    console.print()

    is_local = config.api_url.startswith("http://localhost") or config.api_url.startswith(
        "http://127.0.0.1"
    )

    # ── Step 2: API reachability ────────────────────────────────────────
    console.print("[bold]2. API Reachability[/bold]")

    try:
        start = time.monotonic()
        response = httpx.get(
            f"{config.api_url}/api/v1/observe/config/",
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=10,
            verify=not is_local,
        )
        latency_ms = (time.monotonic() - start) * 1000

        if response.status_code < 500:
            _step_pass("API reachable", f"{latency_ms:.0f}ms latency")
            passed += 1
        else:
            _step_fail("API returned server error", f"HTTP {response.status_code}")
            failed += 1
    except httpx.ConnectError:
        _step_fail(
            "Cannot connect to API",
            f"{config.api_url} - {'is your local server running?' if is_local else 'check your connection'}",
        )
        failed += 1
    except httpx.RequestError as e:
        _step_fail("Connection error", str(e))
        failed += 1

    console.print()

    # ── Step 3: Authentication ──────────────────────────────────────────
    console.print("[bold]3. Authentication[/bold]")

    tenant_name = None
    user_email = None

    try:
        response = httpx.get(
            f"{config.api_url}/api/v1/auth/me",
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=10,
            verify=not is_local,
        )

        if response.status_code == 200:
            data = response.json()
            user = data.get("user", {})
            tenant = data.get("tenant", {})
            tenant_name = tenant.get("name", "Unknown")
            user_email = user.get("email", "Unknown")
            plan = tenant.get("plan", tenant.get("plan_type", ""))

            _step_pass("Authenticated", user_email)
            _step_pass("Tenant", tenant_name)
            if plan:
                _step_pass("Plan", plan)
            passed += 1
        elif response.status_code == 401:
            _step_fail("Authentication failed", "invalid or expired API key")
            _step_warn("Run 'wax login' to re-authenticate")
            failed += 1
        elif response.status_code == 403:
            _step_fail("Permission denied", "API key lacks required permissions")
            failed += 1
        else:
            _step_fail("Auth check failed", f"HTTP {response.status_code}")
            failed += 1
    except httpx.RequestError as e:
        _step_fail("Auth request failed", str(e))
        failed += 1

    console.print()

    # ── Step 4: Data flow ───────────────────────────────────────────────
    console.print("[bold]4. Data Flow[/bold]")

    try:
        response = httpx.get(
            f"{config.api_url}/api/v1/observe/query/runs/",
            params={"hours": 24},
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=15,
            verify=not is_local,
        )

        if response.status_code == 200:
            data = response.json()
            total_runs = data.get("total_runs", data.get("total", 0))
            runs = data.get("runs", data.get("results", []))

            _step_pass("Observe query API", "reachable")

            if total_runs > 0:
                _step_pass(
                    "Runs (last 24h)",
                    fmt_number(total_runs),
                )
                if runs:
                    latest = runs[0]
                    latest_ts = latest.get("started_at", latest.get("created_at", ""))
                    if latest_ts:
                        _step_pass("Latest run", latest_ts[:19].replace("T", " "))
            else:
                _step_warn("No runs in last 24 hours", "send telemetry to see data here")
            passed += 1
        elif response.status_code in (401, 403):
            _step_fail("Observe API auth failed", "key may lack observe permissions")
            failed += 1
        else:
            _step_fail("Observe query failed", f"HTTP {response.status_code}")
            failed += 1
    except httpx.RequestError as e:
        _step_fail("Observe query error", str(e))
        failed += 1

    console.print()

    # ── Step 5: OTel endpoint ───────────────────────────────────────────
    console.print("[bold]5. Telemetry Endpoint[/bold]")

    otel_url = config.api_url.replace("://api.", "://otel.")
    if is_local:
        otel_url = config.api_url  # Same host for local dev

    _step_pass("OTel ingest endpoint", f"{otel_url}/v1/traces")
    _step_pass(
        "Observe ingest",
        f"{config.api_url}/api/v1/observe/ingest/runs/",
    )
    passed += 1

    console.print()

    # ── Summary ─────────────────────────────────────────────────────────
    console.print("[bold]Summary[/bold]")
    if failed == 0:
        console.print(
            f"  [bold green]All {passed} checks passed.[/bold green] "
            f"Your CLI is properly configured."
        )
    else:
        console.print(
            f"  [green]{passed} passed[/green], [red]{failed} failed[/red] "
            f"out of {total_steps} checks."
        )
        if failed > 0:
            console.print()
            console.print("  [dim]Troubleshooting:[/dim]")
            console.print("  [dim]  - Run 'wax login' to re-authenticate[/dim]")
            console.print("  [dim]  - Use 'wax --local test' for local development[/dim]")
            console.print(
                "  [dim]  - Check https://docs.waxell.dev/cli for help[/dim]"
            )

    console.print()

    if failed > 0:
        raise SystemExit(1)
