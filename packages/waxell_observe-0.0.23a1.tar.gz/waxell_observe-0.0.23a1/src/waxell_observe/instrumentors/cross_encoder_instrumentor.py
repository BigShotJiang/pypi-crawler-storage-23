"""CrossEncoder auto-instrumentor for waxell-observe.

Monkey-patches ``sentence_transformers.CrossEncoder.rank`` and
``sentence_transformers.CrossEncoder.predict`` to emit tool spans tracking
cross-encoder reranking operations.

Note: The existing ``sentence_transformers_instrumentor.py`` handles the
``SentenceTransformer.encode()`` embedding method.  This instrumentor is
SEPARATE and covers the CrossEncoder reranking model only.

CrossEncoder.rank() takes query + documents and returns ranked results.
CrossEncoder.predict() takes query-document pairs and returns scores.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class CrossEncoderInstrumentor(BaseInstrumentor):
    """Instrumentor for sentence-transformers CrossEncoder.

    Patches ``CrossEncoder.rank`` and ``CrossEncoder.predict`` to emit
    tool spans for reranking/scoring operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import sentence_transformers  # noqa: F401
        except ImportError:
            logger.debug("sentence_transformers package not installed -- skipping CrossEncoder instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping CrossEncoder instrumentation")
            return False

        patched = False

        # Patch CrossEncoder.rank
        try:
            wrapt.wrap_function_wrapper(
                "sentence_transformers",
                "CrossEncoder.rank",
                _sync_rank_wrapper,
            )
            patched = True
            logger.debug("CrossEncoder.rank patched")
        except Exception as exc:
            logger.debug("Could not patch CrossEncoder.rank: %s", exc)

        # Patch CrossEncoder.predict
        try:
            wrapt.wrap_function_wrapper(
                "sentence_transformers",
                "CrossEncoder.predict",
                _sync_predict_wrapper,
            )
            logger.debug("CrossEncoder.predict patched")
        except Exception as exc:
            logger.debug("Could not patch CrossEncoder.predict: %s", exc)

        if not patched:
            logger.debug("Could not find CrossEncoder methods to patch")
            return False

        self._instrumented = True
        logger.debug("CrossEncoder instrumented (rank + predict)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import sentence_transformers

            cls = getattr(sentence_transformers, "CrossEncoder", None)
            if cls is not None:
                for attr in ("rank", "predict"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("CrossEncoder uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a CrossEncoder instance.

    Tries several attribute paths used across different library versions.
    """
    # Try model_name attribute (common in newer versions)
    try:
        name = getattr(instance, "model_name", None)
        if name:
            return str(name)
    except Exception:
        pass

    # Try config.name_or_path (transformer model config)
    try:
        config = getattr(instance, "config", None)
        if config is not None:
            name = getattr(config, "name_or_path", None) or getattr(config, "_name_or_path", None)
            if name:
                return str(name)
    except Exception:
        pass

    # Try model.config.name_or_path (nested model attribute)
    try:
        model = getattr(instance, "model", None)
        if model is not None:
            config = getattr(model, "config", None)
            if config is not None:
                name = getattr(config, "name_or_path", None) or getattr(config, "_name_or_path", None)
                if name:
                    return str(name)
    except Exception:
        pass

    return "cross-encoder"


def _extract_rank_results(results) -> list:
    """Extract rank results (list of dicts with corpus_id, score, text)."""
    if isinstance(results, list):
        return results
    return []


def _extract_rank_top_score(results) -> float | None:
    """Extract the top score from CrossEncoder.rank results."""
    if not results:
        return None
    first = results[0]
    if isinstance(first, dict):
        score = first.get("score")
        if score is not None:
            return float(score)
    score = getattr(first, "score", None)
    if score is not None:
        return float(score)
    return None


def _extract_predict_scores(result) -> list[float]:
    """Extract scores from CrossEncoder.predict result (numpy array or list)."""
    try:
        import numpy as np

        if isinstance(result, np.ndarray):
            return [float(s) for s in result.tolist()]
    except (ImportError, Exception):
        pass

    if isinstance(result, list):
        return [float(s) for s in result]

    return []


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_rank_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``CrossEncoder.rank``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)
    query = kwargs.get("query", args[0] if args else "")
    documents = kwargs.get("documents", args[1] if len(args) > 1 else [])
    documents_count = len(documents) if isinstance(documents, list) else 0
    top_k = kwargs.get("top_k", None)

    try:
        span = start_tool_span(tool_name="cross_encoder.rank", tool_type="reranker")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            rank_results = _extract_rank_results(result)
            results_count = len(rank_results)
            top_score = _extract_rank_top_score(rank_results)

            span.set_attribute("waxell.rerank.system", "cross_encoder")
            span.set_attribute("waxell.rerank.model", model_name)
            span.set_attribute("waxell.rerank.query", str(query)[:200])
            span.set_attribute("waxell.rerank.documents_count", documents_count)
            span.set_attribute("waxell.rerank.results_count", results_count)
            if top_k is not None:
                span.set_attribute("waxell.rerank.top_k", top_k)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set CrossEncoder rank span attributes: %s", attr_exc)

        try:
            _record_http_cross_encoder(
                method="rank",
                model=model_name,
                query=query,
                documents_count=documents_count,
                results_count=results_count if "results_count" in dir() else 0,
                top_score=top_score if "top_score" in dir() else None,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_predict_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``CrossEncoder.predict``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)

    # predict takes a list of [query, doc] pairs
    sentences = args[0] if args else kwargs.get("sentences", [])
    pairs_count = len(sentences) if isinstance(sentences, list) else 0

    try:
        span = start_tool_span(tool_name="cross_encoder.predict", tool_type="reranker")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            scores = _extract_predict_scores(result)
            scores_count = len(scores)
            top_score = max(scores) if scores else None

            span.set_attribute("waxell.rerank.system", "cross_encoder")
            span.set_attribute("waxell.rerank.model", model_name)
            span.set_attribute("waxell.rerank.method", "predict")
            span.set_attribute("waxell.rerank.pairs_count", pairs_count)
            span.set_attribute("waxell.rerank.scores_count", scores_count)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set CrossEncoder predict span attributes: %s", attr_exc)

        try:
            _record_http_cross_encoder(
                method="predict",
                model=model_name,
                query="",
                documents_count=pairs_count,
                results_count=scores_count if "scores_count" in dir() else 0,
                top_score=top_score if "top_score" in dir() else None,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_cross_encoder(
    method: str,
    model: str,
    query: str,
    documents_count: int = 0,
    results_count: int = 0,
    top_score: float | None = None,
) -> None:
    """Record a CrossEncoder call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    score_str = f", top_score={top_score:.3f}" if top_score is not None else ""
    preview = f"rerank query: {query[:200]}" if query else f"predict {documents_count} pair(s)"
    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"rerank:cross_encoder.{method}",
        "prompt_preview": preview,
        "response_preview": f"{results_count} result(s) from {documents_count} input(s){score_str}",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
