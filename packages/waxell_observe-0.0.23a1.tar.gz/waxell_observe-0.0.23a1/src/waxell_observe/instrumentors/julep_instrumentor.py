"""Julep auto-instrumentor for waxell-observe.

Monkey-patches ``julep.Client.sessions.chat`` for LLM chat calls,
``julep.Client.tasks.create`` for task creation, and
``julep.Client.executions.create`` for task execution. Also patches
the async variants via ``julep.AsyncClient``.

Julep is a stateful AI platform that provides persistent sessions,
task workflows, and execution management for AI agents. It maintains
conversation state across interactions and supports multi-step task
execution with tool integration.

Response structures:
  - ``sessions.chat()`` returns a ChatResponse with choices, usage, model
  - ``tasks.create()`` returns a Task object with id, name, description
  - ``executions.create()`` returns an Execution object with id, status, output

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class JulepInstrumentor(BaseInstrumentor):
    """Instrumentor for the Julep AI platform (``julep`` package).

    Patches ``Client.sessions.chat``, ``Client.tasks.create``,
    ``Client.executions.create`` (sync), and their async counterparts
    on ``AsyncClient``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import julep  # noqa: F401
        except ImportError:
            logger.debug("julep not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Julep instrumentation")
            return False

        patched = False

        # Patch sync sessions.chat
        try:
            wrapt.wrap_function_wrapper(
                "julep.resources.sessions",
                "Sessions.chat",
                _sync_session_chat_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Sessions.chat: %s", exc)

        # Patch async sessions.chat
        try:
            wrapt.wrap_function_wrapper(
                "julep.resources.sessions",
                "AsyncSessions.chat",
                _async_session_chat_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch AsyncSessions.chat: %s", exc)

        # Patch sync tasks.create
        try:
            wrapt.wrap_function_wrapper(
                "julep.resources.tasks",
                "Tasks.create",
                _sync_task_create_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch Tasks.create: %s", exc)

        # Patch async tasks.create
        try:
            wrapt.wrap_function_wrapper(
                "julep.resources.tasks",
                "AsyncTasks.create",
                _async_task_create_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch AsyncTasks.create: %s", exc)

        # Patch sync executions.create
        try:
            wrapt.wrap_function_wrapper(
                "julep.resources.executions",
                "Executions.create",
                _sync_execution_create_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch Executions.create: %s", exc)

        # Patch async executions.create
        try:
            wrapt.wrap_function_wrapper(
                "julep.resources.executions",
                "AsyncExecutions.create",
                _async_execution_create_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch AsyncExecutions.create: %s", exc)

        if not patched:
            logger.debug("Could not find Julep methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "Julep instrumented (sessions.chat + tasks.create + executions.create, sync + async)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Uninstrument sync Sessions.chat
        try:
            from julep.resources.sessions import Sessions

            method = getattr(Sessions, "chat", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Sessions.chat = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument async AsyncSessions.chat
        try:
            from julep.resources.sessions import AsyncSessions

            method = getattr(AsyncSessions, "chat", None)
            if method is not None and hasattr(method, "__wrapped__"):
                AsyncSessions.chat = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument sync Tasks.create
        try:
            from julep.resources.tasks import Tasks

            method = getattr(Tasks, "create", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Tasks.create = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument async AsyncTasks.create
        try:
            from julep.resources.tasks import AsyncTasks

            method = getattr(AsyncTasks, "create", None)
            if method is not None and hasattr(method, "__wrapped__"):
                AsyncTasks.create = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument sync Executions.create
        try:
            from julep.resources.executions import Executions

            method = getattr(Executions, "create", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Executions.create = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument async AsyncExecutions.create
        try:
            from julep.resources.executions import AsyncExecutions

            method = getattr(AsyncExecutions, "create", None)
            if method is not None and hasattr(method, "__wrapped__"):
                AsyncExecutions.create = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Julep uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Julep responses
# ---------------------------------------------------------------------------


def _extract_chat_data(response, kwargs: dict) -> dict:
    """Extract model, tokens, cost, and content from a Julep chat response.

    Returns a dict with keys: model, tokens_in, tokens_out, cost,
    finish_reason, content, session_id.
    """
    model = kwargs.get("model", "unknown")
    tokens_in = 0
    tokens_out = 0
    finish_reason = ""
    content = ""
    session_id = kwargs.get("session_id", "")

    try:
        # ChatResponse may have usage attribute
        if hasattr(response, "usage") and response.usage:
            usage = response.usage
            tokens_in = getattr(usage, "prompt_tokens", 0) or 0
            tokens_out = getattr(usage, "completion_tokens", 0) or 0
    except Exception:
        pass

    try:
        # Extract model from response if available
        if hasattr(response, "model") and response.model:
            model = str(response.model)
    except Exception:
        pass

    try:
        # ChatResponse has choices list
        if hasattr(response, "choices") and response.choices:
            choice = response.choices[0]
            if hasattr(choice, "message") and choice.message:
                content = str(getattr(choice.message, "content", ""))
            if hasattr(choice, "finish_reason") and choice.finish_reason:
                finish_reason = str(choice.finish_reason)
    except Exception:
        pass

    # Try direct response content
    if not content:
        try:
            if hasattr(response, "response") and response.response:
                resp_list = response.response
                if isinstance(resp_list, list) and resp_list:
                    first = resp_list[0]
                    if hasattr(first, "content"):
                        content = str(first.content)
        except Exception:
            pass

    return {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,
        "finish_reason": finish_reason,
        "content": content,
        "session_id": str(session_id) if session_id else "",
    }


def _extract_task_data(response, kwargs: dict) -> dict:
    """Extract task details from a Julep task creation response."""
    task_id = ""
    task_name = kwargs.get("name", "")
    description = kwargs.get("description", "")

    try:
        if hasattr(response, "id") and response.id:
            task_id = str(response.id)
    except Exception:
        pass

    try:
        if hasattr(response, "name") and response.name:
            task_name = str(response.name)
    except Exception:
        pass

    try:
        if hasattr(response, "description") and response.description:
            description = str(response.description)
    except Exception:
        pass

    return {
        "task_id": task_id,
        "task_name": task_name,
        "description": description[:500] if description else "",
    }


def _extract_execution_data(response, kwargs: dict) -> dict:
    """Extract execution details from a Julep execution creation response."""
    execution_id = ""
    status = ""
    task_id = kwargs.get("task_id", "")
    output = ""

    try:
        if hasattr(response, "id") and response.id:
            execution_id = str(response.id)
    except Exception:
        pass

    try:
        if hasattr(response, "status") and response.status:
            status = str(response.status)
    except Exception:
        pass

    try:
        if hasattr(response, "output") and response.output:
            output = str(response.output)[:500]
    except Exception:
        pass

    return {
        "execution_id": execution_id,
        "task_id": str(task_id) if task_id else "",
        "status": status,
        "output": output,
    }


# ---------------------------------------------------------------------------
# Session chat wrappers
# ---------------------------------------------------------------------------


def _sync_session_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Julep ``Sessions.chat``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    try:
        span = start_llm_span(model=model, provider_name="julep")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_chat_data(response, kwargs)
            _set_chat_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_julep_chat(response, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_session_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Julep ``AsyncSessions.chat``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    try:
        span = start_llm_span(model=model, provider_name="julep")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_chat_data(response, kwargs)
            _set_chat_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_julep_chat(response, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Task create wrappers
# ---------------------------------------------------------------------------


def _sync_task_create_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Julep ``Tasks.create``."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    task_name = kwargs.get("name", "julep_task")

    try:
        span = start_agent_span(
            agent_name=task_name,
            workflow_name="julep_task_create",
        )
        span.set_attribute("waxell.agent.framework", "julep")
        span.set_attribute("waxell.julep.operation", "task_create")
        if kwargs.get("description"):
            span.set_attribute("waxell.julep.task_description", str(kwargs["description"])[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_task_data(result, kwargs)
            _set_task_span_attributes(span, data)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _async_task_create_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Julep ``AsyncTasks.create``."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    task_name = kwargs.get("name", "julep_task")

    try:
        span = start_agent_span(
            agent_name=task_name,
            workflow_name="julep_task_create",
        )
        span.set_attribute("waxell.agent.framework", "julep")
        span.set_attribute("waxell.julep.operation", "task_create")
        if kwargs.get("description"):
            span.set_attribute("waxell.julep.task_description", str(kwargs["description"])[:500])
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_task_data(result, kwargs)
            _set_task_span_attributes(span, data)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Execution create wrappers
# ---------------------------------------------------------------------------


def _sync_execution_create_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Julep ``Executions.create``."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    task_id = kwargs.get("task_id", "unknown")

    try:
        span = start_agent_span(
            agent_name=f"julep_execution:{task_id}",
            workflow_name="julep_execution_create",
        )
        span.set_attribute("waxell.agent.framework", "julep")
        span.set_attribute("waxell.julep.operation", "execution_create")
        span.set_attribute("waxell.julep.task_id", str(task_id))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_execution_data(result, kwargs)
            _set_execution_span_attributes(span, data)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _async_execution_create_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Julep ``AsyncExecutions.create``."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    task_id = kwargs.get("task_id", "unknown")

    try:
        span = start_agent_span(
            agent_name=f"julep_execution:{task_id}",
            workflow_name="julep_execution_create",
        )
        span.set_attribute("waxell.agent.framework", "julep")
        span.set_attribute("waxell.julep.operation", "execution_create")
        span.set_attribute("waxell.julep.task_id", str(task_id))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_execution_data(result, kwargs)
            _set_execution_span_attributes(span, data)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _set_chat_span_attributes(span, data: dict) -> None:
    """Set OTel span attributes from extracted Julep chat data."""
    from ..tracing.attributes import GenAIAttributes, WaxellAttributes

    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(GenAIAttributes.RESPONSE_MODEL, data["model"])
    if data["finish_reason"]:
        span.set_attribute(
            GenAIAttributes.RESPONSE_FINISH_REASONS, [data["finish_reason"]]
        )
    span.set_attribute(WaxellAttributes.LLM_MODEL, data["model"])
    span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(
        WaxellAttributes.LLM_TOTAL_TOKENS,
        data["tokens_in"] + data["tokens_out"],
    )
    span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
    if data["session_id"]:
        span.set_attribute(WaxellAttributes.SESSION_ID, data["session_id"])


def _set_task_span_attributes(span, data: dict) -> None:
    """Set span attributes for task creation."""
    if data["task_id"]:
        span.set_attribute("waxell.julep.task_id", data["task_id"])
    if data["task_name"]:
        span.set_attribute("waxell.julep.task_name", data["task_name"])
    if data["description"]:
        span.set_attribute("waxell.julep.task_description", data["description"])

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"julep:task_create:{data['task_name']}",
                output={
                    "task_id": data["task_id"],
                    "task_name": data["task_name"],
                },
            )
    except Exception:
        pass


def _set_execution_span_attributes(span, data: dict) -> None:
    """Set span attributes for execution creation."""
    if data["execution_id"]:
        span.set_attribute("waxell.julep.execution_id", data["execution_id"])
    if data["task_id"]:
        span.set_attribute("waxell.julep.task_id", data["task_id"])
    if data["status"]:
        span.set_attribute("waxell.julep.execution_status", data["status"])
    if data["output"]:
        span.set_attribute("waxell.julep.execution_output_preview", data["output"][:200])

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"julep:execution:{data['task_id']}",
                output={
                    "execution_id": data["execution_id"],
                    "status": data["status"],
                    "output_preview": data["output"][:500] if data["output"] else "",
                },
            )
    except Exception:
        pass


def _record_http_julep_chat(response, kwargs: dict) -> None:
    """Record a Julep chat call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    data = _extract_chat_data(response, kwargs)

    # Extract prompt preview from messages
    prompt_preview = ""
    messages = kwargs.get("messages", [])
    if messages and isinstance(messages, list):
        first = messages[0]
        if isinstance(first, dict):
            prompt_preview = str(first.get("content", ""))[:500]
        elif hasattr(first, "content"):
            prompt_preview = str(first.content)[:500]

    call_data = {
        "model": data["model"],
        "tokens_in": data["tokens_in"],
        "tokens_out": data["tokens_out"],
        "cost": 0.0,
        "task": "julep.sessions.chat",
        "prompt_preview": prompt_preview,
        "response_preview": str(data["content"])[:500] if data["content"] else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
