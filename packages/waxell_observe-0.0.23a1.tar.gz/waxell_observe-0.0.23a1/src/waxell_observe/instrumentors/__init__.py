"""Instrumentor registry for waxell-observe auto-instrumentation.

Public API:
    instrument_all()    -- Detect and instrument installed LLM libraries
    uninstrument_all()  -- Restore all patched libraries to their originals
"""

from __future__ import annotations

import logging
import os

from ._base import BaseInstrumentor
from ._detect import detect_installed_libraries

logger = logging.getLogger(__name__)

# Registry mapping library name -> instrumentor instance.
# Populated lazily by _ensure_registry().
_REGISTRY: dict[str, BaseInstrumentor] = {}
_registry_loaded: bool = False


def _ensure_registry() -> None:
    """Lazily populate the instrumentor registry.

    Each instrumentor module is imported inside a try/except so that
    missing dependencies (OTel, wrapt, etc.) do not cause import
    errors at module level.
    """
    global _registry_loaded
    if _registry_loaded:
        return

    _registry_loaded = True

    # OpenAI instrumentor (added by plan 03-02)
    try:
        from .openai_instrumentor import OpenAIInstrumentor

        _REGISTRY["openai"] = OpenAIInstrumentor()
    except Exception:
        logger.debug("OpenAI instrumentor not available")

    # Anthropic instrumentor (added by plan 03-02)
    try:
        from .anthropic_instrumentor import AnthropicInstrumentor

        _REGISTRY["anthropic"] = AnthropicInstrumentor()
    except Exception:
        logger.debug("Anthropic instrumentor not available")

    # LiteLLM instrumentor
    try:
        from .litellm_instrumentor import LiteLLMInstrumentor

        _REGISTRY["litellm"] = LiteLLMInstrumentor()
    except Exception:
        logger.debug("LiteLLM instrumentor not available")

    # Groq instrumentor
    try:
        from .groq_instrumentor import GroqInstrumentor

        _REGISTRY["groq"] = GroqInstrumentor()
    except Exception:
        logger.debug("Groq instrumentor not available (module not found)")

    # HuggingFace instrumentor
    try:
        from .huggingface_instrumentor import HuggingFaceInstrumentor

        _REGISTRY["huggingface"] = HuggingFaceInstrumentor()
    except Exception:
        logger.debug("HuggingFace instrumentor not available (module not found)")

    # Mistral AI instrumentor
    try:
        from .mistral_instrumentor import MistralInstrumentor

        _REGISTRY["mistral"] = MistralInstrumentor()
    except Exception:
        logger.debug("Mistral instrumentor not available (module not found)")

    # Cohere instrumentor
    try:
        from .cohere_instrumentor import CohereInstrumentor

        _REGISTRY["cohere"] = CohereInstrumentor()
    except Exception:
        logger.debug("Cohere instrumentor not available (module not found)")

    # Google Gemini instrumentor
    try:
        from .gemini_instrumentor import GeminiInstrumentor

        _REGISTRY["gemini"] = GeminiInstrumentor()
    except Exception:
        logger.debug("Gemini instrumentor not available (module not found)")

    # AWS Bedrock instrumentor
    try:
        from .bedrock_instrumentor import BedrockInstrumentor

        _REGISTRY["bedrock"] = BedrockInstrumentor()
    except Exception:
        logger.debug("Bedrock instrumentor not available (module not found)")

    # Pinecone instrumentor
    try:
        from .pinecone_instrumentor import PineconeInstrumentor

        _REGISTRY["pinecone"] = PineconeInstrumentor()
    except Exception:
        logger.debug("Pinecone instrumentor not available (module not found)")

    # ChromaDB instrumentor (catches Exception — chromadb can raise OTel errors on import)
    try:
        from .chroma_instrumentor import ChromaInstrumentor

        _REGISTRY["chroma"] = ChromaInstrumentor()
    except Exception:
        logger.debug("Chroma instrumentor not available")

    # Weaviate instrumentor
    try:
        from .weaviate_instrumentor import WeaviateInstrumentor

        _REGISTRY["weaviate"] = WeaviateInstrumentor()
    except Exception:
        logger.debug("Weaviate instrumentor not available (module not found)")

    # Qdrant instrumentor
    try:
        from .qdrant_instrumentor import QdrantInstrumentor

        _REGISTRY["qdrant"] = QdrantInstrumentor()
    except Exception:
        logger.debug("Qdrant instrumentor not available (module not found)")

    # CrewAI instrumentor
    try:
        from .crewai_instrumentor import CrewAIInstrumentor

        _REGISTRY["crewai"] = CrewAIInstrumentor()
    except Exception:
        logger.debug("CrewAI instrumentor not available (module not found)")

    # LangChain instrumentor
    try:
        from .langchain_instrumentor import LangChainInstrumentor

        _REGISTRY["langchain"] = LangChainInstrumentor()
    except Exception:
        logger.debug("LangChain instrumentor not available (module not found)")

    # MCP instrumentor
    try:
        from .mcp_instrumentor import MCPInstrumentor

        _REGISTRY["mcp"] = MCPInstrumentor()
    except Exception:
        logger.debug("MCP instrumentor not available (module not found)")

    # Ollama instrumentor
    try:
        from .ollama_instrumentor import OllamaInstrumentor

        _REGISTRY["ollama"] = OllamaInstrumentor()
    except Exception:
        logger.debug("Ollama instrumentor not available (module not found)")

    # Together AI instrumentor (native SDK)
    try:
        from .together_instrumentor import TogetherInstrumentor

        _REGISTRY["together"] = TogetherInstrumentor()
    except Exception:
        logger.debug("Together instrumentor not available (module not found)")

    # Haystack instrumentor
    try:
        from .haystack_instrumentor import HaystackInstrumentor

        _REGISTRY["haystack"] = HaystackInstrumentor()
    except Exception:
        logger.debug("Haystack instrumentor not available (module not found)")

    # DSPy instrumentor
    try:
        from .dspy_instrumentor import DSPyInstrumentor

        _REGISTRY["dspy"] = DSPyInstrumentor()
    except Exception:
        logger.debug("DSPy instrumentor not available (module not found)")

    # LlamaIndex instrumentor
    try:
        from .llamaindex_instrumentor import LlamaIndexInstrumentor

        _REGISTRY["llamaindex"] = LlamaIndexInstrumentor()
    except Exception:
        logger.debug("LlamaIndex instrumentor not available (module not found)")

    # PydanticAI instrumentor
    try:
        from .pydanticai_instrumentor import PydanticAIInstrumentor

        _REGISTRY["pydanticai"] = PydanticAIInstrumentor()
    except Exception:
        logger.debug("PydanticAI instrumentor not available (module not found)")

    # Instructor instrumentor
    try:
        from .instructor_instrumentor import InstructorInstrumentor

        _REGISTRY["instructor"] = InstructorInstrumentor()
    except Exception:
        logger.debug("Instructor instrumentor not available (module not found)")

    # OpenAI Agents SDK instrumentor
    try:
        from .openai_agents_instrumentor import OpenAIAgentsInstrumentor

        _REGISTRY["openai_agents"] = OpenAIAgentsInstrumentor()
    except Exception:
        logger.debug("OpenAI Agents instrumentor not available (module not found)")

    # AutoGen instrumentor
    try:
        from .autogen_instrumentor import AutoGenInstrumentor

        _REGISTRY["autogen"] = AutoGenInstrumentor()
    except Exception:
        logger.debug("AutoGen instrumentor not available (module not found)")

    # Semantic Kernel instrumentor
    try:
        from .semantic_kernel_instrumentor import SemanticKernelInstrumentor

        _REGISTRY["semantic_kernel"] = SemanticKernelInstrumentor()
    except Exception:
        logger.debug("Semantic Kernel instrumentor not available (module not found)")

    # Strands Agents instrumentor
    try:
        from .strands_instrumentor import StrandsInstrumentor

        _REGISTRY["strands"] = StrandsInstrumentor()
    except Exception:
        logger.debug("Strands instrumentor not available (module not found)")

    # Google ADK instrumentor
    try:
        from .google_adk_instrumentor import GoogleADKInstrumentor

        _REGISTRY["google_adk"] = GoogleADKInstrumentor()
    except Exception:
        logger.debug("Google ADK instrumentor not available (module not found)")

    # Bedrock Agents instrumentor
    try:
        from .bedrock_agents_instrumentor import BedrockAgentsInstrumentor

        _REGISTRY["bedrock_agents"] = BedrockAgentsInstrumentor()
    except Exception:
        logger.debug("Bedrock Agents instrumentor not available (module not found)")

    # Claude Agent SDK instrumentor
    try:
        from .claude_agents_instrumentor import ClaudeAgentsInstrumentor

        _REGISTRY["claude_agents"] = ClaudeAgentsInstrumentor()
    except Exception:
        logger.debug("Claude Agents instrumentor not available (module not found)")

    # Milvus instrumentor
    try:
        from .milvus_instrumentor import MilvusInstrumentor

        _REGISTRY["milvus"] = MilvusInstrumentor()
    except Exception:
        logger.debug("Milvus instrumentor not available (module not found)")

    # MongoDB Atlas Vector Search instrumentor
    try:
        from .mongodb_vector_instrumentor import MongoDBVectorInstrumentor

        _REGISTRY["mongodb_vector"] = MongoDBVectorInstrumentor()
    except Exception:
        logger.debug("MongoDB Vector instrumentor not available (module not found)")

    # Elasticsearch instrumentor
    try:
        from .elasticsearch_instrumentor import ElasticsearchInstrumentor

        _REGISTRY["elasticsearch"] = ElasticsearchInstrumentor()
    except Exception:
        logger.debug("Elasticsearch instrumentor not available (module not found)")

    # pgvector instrumentor (psycopg2 / asyncpg)
    try:
        from .pgvector_instrumentor import PgvectorInstrumentor

        _REGISTRY["pgvector"] = PgvectorInstrumentor()
    except Exception:
        logger.debug("pgvector instrumentor not available (module not found)")

    # Redis Vector Search instrumentor
    try:
        from .redis_vector_instrumentor import RedisVectorInstrumentor

        _REGISTRY["redis_vector"] = RedisVectorInstrumentor()
    except Exception:
        logger.debug("Redis Vector instrumentor not available (module not found)")

    # LanceDB instrumentor
    try:
        from .lancedb_instrumentor import LanceDBInstrumentor

        _REGISTRY["lancedb"] = LanceDBInstrumentor()
    except Exception:
        logger.debug("LanceDB instrumentor not available (module not found)")

    # Neo4j instrumentor (graph DB + vector search)
    try:
        from .neo4j_instrumentor import Neo4jInstrumentor

        _REGISTRY["neo4j"] = Neo4jInstrumentor()
    except Exception:
        logger.debug("Neo4j instrumentor not available (module not found)")

    # Mem0 instrumentor (memory layer)
    try:
        from .mem0_instrumentor import Mem0Instrumentor

        _REGISTRY["mem0"] = Mem0Instrumentor()
    except Exception:
        logger.debug("Mem0 instrumentor not available (module not found)")

    # Guardrails AI instrumentor
    try:
        from .guardrails_ai_instrumentor import GuardrailsAIInstrumentor

        _REGISTRY["guardrails_ai"] = GuardrailsAIInstrumentor()
    except Exception:
        logger.debug("Guardrails AI instrumentor not available (module not found)")

    # NeMo Guardrails instrumentor
    try:
        from .nemo_guardrails_instrumentor import NemoGuardrailsInstrumentor

        _REGISTRY["nemo_guardrails"] = NemoGuardrailsInstrumentor()
    except Exception:
        logger.debug("NeMo Guardrails instrumentor not available (module not found)")

    # LLM Guard instrumentor
    try:
        from .llm_guard_instrumentor import LLMGuardInstrumentor

        _REGISTRY["llm_guard"] = LLMGuardInstrumentor()
    except Exception:
        logger.debug("LLM Guard instrumentor not available (module not found)")

    # DeepEval instrumentor
    try:
        from .deepeval_instrumentor import DeepEvalInstrumentor

        _REGISTRY["deepeval"] = DeepEvalInstrumentor()
    except Exception:
        logger.debug("DeepEval instrumentor not available (module not found)")

    # Sentence Transformers instrumentor
    try:
        from .sentence_transformers_instrumentor import SentenceTransformersInstrumentor

        _REGISTRY["sentence_transformers"] = SentenceTransformersInstrumentor()
    except Exception:
        logger.debug("Sentence Transformers instrumentor not available (module not found)")

    # vLLM instrumentor
    try:
        from .vllm_instrumentor import VLLMInstrumentor

        _REGISTRY["vllm"] = VLLMInstrumentor()
    except Exception:
        logger.debug("vLLM instrumentor not available (module not found)")

    # Voyage AI instrumentor
    try:
        from .voyage_instrumentor import VoyageInstrumentor

        _REGISTRY["voyage"] = VoyageInstrumentor()
    except Exception:
        logger.debug("Voyage AI instrumentor not available (module not found)")

    # Jina AI reranker instrumentor
    try:
        from .jina_instrumentor import JinaInstrumentor

        _REGISTRY["jina"] = JinaInstrumentor()
    except Exception:
        logger.debug("Jina instrumentor not available (module not found)")

    # RAGAS evaluation instrumentor
    try:
        from .ragas_instrumentor import RagasInstrumentor

        _REGISTRY["ragas"] = RagasInstrumentor()
    except Exception:
        logger.debug("RAGAS instrumentor not available (module not found)")

    # OpenAI Moderation instrumentor
    try:
        from .openai_moderation_instrumentor import OpenAIModerationInstrumentor

        _REGISTRY["openai_moderation"] = OpenAIModerationInstrumentor()
    except Exception:
        logger.debug("OpenAI Moderation instrumentor not available (module not found)")

    # Agno instrumentor
    try:
        from .agno_instrumentor import AgnoInstrumentor

        _REGISTRY["agno"] = AgnoInstrumentor()
    except Exception:
        logger.debug("Agno instrumentor not available (module not found)")

    # smolagents instrumentor
    try:
        from .smolagents_instrumentor import SmolAgentsInstrumentor

        _REGISTRY["smolagents"] = SmolAgentsInstrumentor()
    except Exception:
        logger.debug("smolagents instrumentor not available (module not found)")

    # Nomic instrumentor
    try:
        from .nomic_instrumentor import NomicInstrumentor

        _REGISTRY["nomic"] = NomicInstrumentor()
    except Exception:
        logger.debug("Nomic instrumentor not available (module not found)")

    # FastEmbed instrumentor
    try:
        from .fastembed_instrumentor import FastEmbedInstrumentor

        _REGISTRY["fastembed"] = FastEmbedInstrumentor()
    except Exception:
        logger.debug("FastEmbed instrumentor not available (module not found)")

    # Voyage Rerank instrumentor
    try:
        from .voyage_rerank_instrumentor import VoyageRerankInstrumentor

        _REGISTRY["voyage_rerank"] = VoyageRerankInstrumentor()
    except Exception:
        logger.debug("Voyage Rerank instrumentor not available (module not found)")

    # FAISS instrumentor
    try:
        from .faiss_instrumentor import FAISSInstrumentor

        _REGISTRY["faiss"] = FAISSInstrumentor()
    except Exception:
        logger.debug("FAISS instrumentor not available (module not found)")

    # Letta instrumentor
    try:
        from .letta_instrumentor import LettaInstrumentor

        _REGISTRY["letta"] = LettaInstrumentor()
    except Exception:
        logger.debug("Letta instrumentor not available (module not found)")

    # Vertex AI instrumentor
    try:
        from .vertex_ai_instrumentor import VertexAIInstrumentor

        _REGISTRY["vertex_ai"] = VertexAIInstrumentor()
    except Exception:
        logger.debug("Vertex AI instrumentor not available (module not found)")

    # ── Phase 4B additions ──────────────────────────────────────────

    # AI21 Labs instrumentor
    try:
        from .ai21_instrumentor import AI21Instrumentor

        _REGISTRY["ai21"] = AI21Instrumentor()
    except Exception:
        logger.debug("AI21 instrumentor not available (module not found)")

    # Lakera Guard instrumentor
    try:
        from .lakera_guard_instrumentor import LakeraGuardInstrumentor

        _REGISTRY["lakera_guard"] = LakeraGuardInstrumentor()
    except Exception:
        logger.debug("Lakera Guard instrumentor not available (module not found)")

    # Presidio instrumentor
    try:
        from .presidio_instrumentor import PresidioInstrumentor

        _REGISTRY["presidio"] = PresidioInstrumentor()
    except Exception:
        logger.debug("Presidio instrumentor not available (module not found)")

    # Azure AI Content Safety instrumentor
    try:
        from .azure_content_safety_instrumentor import AzureContentSafetyInstrumentor

        _REGISTRY["azure_content_safety"] = AzureContentSafetyInstrumentor()
    except Exception:
        logger.debug("Azure Content Safety instrumentor not available (module not found)")

    # FlashRank instrumentor
    try:
        from .flashrank_instrumentor import FlashRankInstrumentor

        _REGISTRY["flashrank"] = FlashRankInstrumentor()
    except Exception:
        logger.debug("FlashRank instrumentor not available (module not found)")

    # Zep instrumentor
    try:
        from .zep_instrumentor import ZepInstrumentor

        _REGISTRY["zep"] = ZepInstrumentor()
    except Exception:
        logger.debug("Zep instrumentor not available (module not found)")

    # CAMEL instrumentor
    try:
        from .camel_instrumentor import CamelInstrumentor

        _REGISTRY["camel"] = CamelInstrumentor()
    except Exception:
        logger.debug("CAMEL instrumentor not available (module not found)")

    # Composio instrumentor
    try:
        from .composio_instrumentor import ComposioInstrumentor

        _REGISTRY["composio"] = ComposioInstrumentor()
    except Exception:
        logger.debug("Composio instrumentor not available (module not found)")

    # MixedBread instrumentor
    try:
        from .mixedbread_instrumentor import MixedbreadInstrumentor

        _REGISTRY["mixedbread"] = MixedbreadInstrumentor()
    except Exception:
        logger.debug("MixedBread instrumentor not available (module not found)")

    # BGE instrumentor
    try:
        from .bge_instrumentor import BGEInstrumentor

        _REGISTRY["bge"] = BGEInstrumentor()
    except Exception:
        logger.debug("BGE instrumentor not available (module not found)")

    # ── Phase 5 additions ──────────────────────────────────────────

    # HuggingFace Transformers (local inference)
    try:
        from .transformers_instrumentor import TransformersInstrumentor

        _REGISTRY["transformers"] = TransformersInstrumentor()
    except Exception:
        logger.debug("Transformers instrumentor not available (module not found)")

    # OpenSearch instrumentor
    try:
        from .opensearch_instrumentor import OpenSearchInstrumentor

        _REGISTRY["opensearch"] = OpenSearchInstrumentor()
    except Exception:
        logger.debug("OpenSearch instrumentor not available (module not found)")

    # Marqo instrumentor
    try:
        from .marqo_instrumentor import MarqoInstrumentor

        _REGISTRY["marqo"] = MarqoInstrumentor()
    except Exception:
        logger.debug("Marqo instrumentor not available (module not found)")

    # Turbopuffer instrumentor
    try:
        from .turbopuffer_instrumentor import TurbopufferInstrumentor

        _REGISTRY["turbopuffer"] = TurbopufferInstrumentor()
    except Exception:
        logger.debug("Turbopuffer instrumentor not available (module not found)")

    # DashScope instrumentor (Alibaba Cloud / Qwen)
    try:
        from .dashscope_instrumentor import DashScopeInstrumentor

        _REGISTRY["dashscope"] = DashScopeInstrumentor()
    except Exception:
        logger.debug("DashScope instrumentor not available (module not found)")

    # IBM WatsonX instrumentor
    try:
        from .watsonx_instrumentor import WatsonXInstrumentor

        _REGISTRY["watsonx"] = WatsonXInstrumentor()
    except Exception:
        logger.debug("WatsonX instrumentor not available (module not found)")

    # SGLang instrumentor
    try:
        from .sglang_instrumentor import SGLangInstrumentor

        _REGISTRY["sglang"] = SGLangInstrumentor()
    except Exception:
        logger.debug("SGLang instrumentor not available (module not found)")

    # llama.cpp instrumentor
    try:
        from .llamacpp_instrumentor import LlamaCppInstrumentor

        _REGISTRY["llamacpp"] = LlamaCppInstrumentor()
    except Exception:
        logger.debug("llama.cpp instrumentor not available (module not found)")

    # Firecrawl instrumentor
    try:
        from .firecrawl_instrumentor import FirecrawlInstrumentor

        _REGISTRY["firecrawl"] = FirecrawlInstrumentor()
    except Exception:
        logger.debug("Firecrawl instrumentor not available (module not found)")

    # Crawl4AI instrumentor
    try:
        from .crawl4ai_instrumentor import Crawl4AIInstrumentor

        _REGISTRY["crawl4ai"] = Crawl4AIInstrumentor()
    except Exception:
        logger.debug("Crawl4AI instrumentor not available (module not found)")

    # Pinecone Rerank instrumentor
    try:
        from .pinecone_rerank_instrumentor import PineconeRerankInstrumentor

        _REGISTRY["pinecone_rerank"] = PineconeRerankInstrumentor()
    except Exception:
        logger.debug("Pinecone Rerank instrumentor not available (module not found)")

    # CrossEncoder instrumentor (sentence-transformers)
    try:
        from .cross_encoder_instrumentor import CrossEncoderInstrumentor

        _REGISTRY["cross_encoder"] = CrossEncoderInstrumentor()
    except Exception:
        logger.debug("CrossEncoder instrumentor not available (module not found)")

    # PolyGuard instrumentor
    try:
        from .polyguard_instrumentor import PolyGuardInstrumentor

        _REGISTRY["polyguard"] = PolyGuardInstrumentor()
    except Exception:
        logger.debug("PolyGuard instrumentor not available (module not found)")

    # ── Phase 6 additions ──────────────────────────────────────────

    # HuggingFace TGI instrumentor (model serving)
    try:
        from .huggingface_tgi_instrumentor import HuggingFaceTGIInstrumentor

        _REGISTRY["huggingface_tgi"] = HuggingFaceTGIInstrumentor()
    except Exception:
        logger.debug("HuggingFace TGI instrumentor not available (module not found)")

    # ExLlamaV2 instrumentor (local inference)
    try:
        from .exllamav2_instrumentor import ExLlamaV2Instrumentor

        _REGISTRY["exllamav2"] = ExLlamaV2Instrumentor()
    except Exception:
        logger.debug("ExLlamaV2 instrumentor not available (module not found)")

    # FalkorDB instrumentor (graph DB)
    try:
        from .falkordb_instrumentor import FalkorDBInstrumentor

        _REGISTRY["falkordb"] = FalkorDBInstrumentor()
    except Exception:
        logger.debug("FalkorDB instrumentor not available (module not found)")

    # ArangoDB instrumentor (graph DB)
    try:
        from .arangodb_instrumentor import ArangoDBInstrumentor

        _REGISTRY["arangodb"] = ArangoDBInstrumentor()
    except Exception:
        logger.debug("ArangoDB instrumentor not available (module not found)")

    # Memgraph instrumentor (graph DB)
    try:
        from .memgraph_instrumentor import MemgraphInstrumentor

        _REGISTRY["memgraph"] = MemgraphInstrumentor()
    except Exception:
        logger.debug("Memgraph instrumentor not available (module not found)")

    # Amazon Neptune instrumentor (graph DB)
    try:
        from .neptune_instrumentor import NeptuneInstrumentor

        _REGISTRY["neptune"] = NeptuneInstrumentor()
    except Exception:
        logger.debug("Neptune instrumentor not available (module not found)")

    # Annoy instrumentor (vector library)
    try:
        from .annoy_instrumentor import AnnoyInstrumentor

        _REGISTRY["annoy"] = AnnoyInstrumentor()
    except Exception:
        logger.debug("Annoy instrumentor not available (module not found)")

    # hnswlib instrumentor (vector library)
    try:
        from .hnswlib_instrumentor import HnswlibInstrumentor

        _REGISTRY["hnswlib"] = HnswlibInstrumentor()
    except Exception:
        logger.debug("hnswlib instrumentor not available (module not found)")

    # USearch instrumentor (vector library)
    try:
        from .usearch_instrumentor import USearchInstrumentor

        _REGISTRY["usearch"] = USearchInstrumentor()
    except Exception:
        logger.debug("USearch instrumentor not available (module not found)")

    # ScaNN instrumentor (vector library)
    try:
        from .scann_instrumentor import ScaNNInstrumentor

        _REGISTRY["scann"] = ScaNNInstrumentor()
    except Exception:
        logger.debug("ScaNN instrumentor not available (module not found)")

    # Vespa instrumentor (vector DB)
    try:
        from .vespa_instrumentor import VespaInstrumentor

        _REGISTRY["vespa"] = VespaInstrumentor()
    except Exception:
        logger.debug("Vespa instrumentor not available (module not found)")

    # DuckDB Vector instrumentor (vector DB)
    try:
        from .duckdb_vector_instrumentor import DuckDBVectorInstrumentor

        _REGISTRY["duckdb_vector"] = DuckDBVectorInstrumentor()
    except Exception:
        logger.debug("DuckDB Vector instrumentor not available (module not found)")

    # Cassandra Vector instrumentor (vector DB)
    try:
        from .cassandra_vector_instrumentor import CassandraVectorInstrumentor

        _REGISTRY["cassandra_vector"] = CassandraVectorInstrumentor()
    except Exception:
        logger.debug("Cassandra Vector instrumentor not available (module not found)")

    # ColBERT instrumentor (reranker)
    try:
        from .colbert_instrumentor import ColBERTInstrumentor

        _REGISTRY["colbert"] = ColBERTInstrumentor()
    except Exception:
        logger.debug("ColBERT instrumentor not available (module not found)")

    # Braintrust instrumentor (eval framework)
    try:
        from .braintrust_instrumentor import BraintrustInstrumentor

        _REGISTRY["braintrust"] = BraintrustInstrumentor()
    except Exception:
        logger.debug("Braintrust instrumentor not available (module not found)")

    # TruLens instrumentor (eval framework)
    try:
        from .trulens_instrumentor import TruLensInstrumentor

        _REGISTRY["trulens"] = TruLensInstrumentor()
    except Exception:
        logger.debug("TruLens instrumentor not available (module not found)")

    # Giskard instrumentor (eval framework)
    try:
        from .giskard_instrumentor import GiskardInstrumentor

        _REGISTRY["giskard"] = GiskardInstrumentor()
    except Exception:
        logger.debug("Giskard instrumentor not available (module not found)")

    # Inspect AI instrumentor (eval framework)
    try:
        from .inspect_ai_instrumentor import InspectAIInstrumentor

        _REGISTRY["inspect_ai"] = InspectAIInstrumentor()
    except Exception:
        logger.debug("Inspect AI instrumentor not available (module not found)")

    # ControlFlow instrumentor (agentic framework)
    try:
        from .controlflow_instrumentor import ControlFlowInstrumentor

        _REGISTRY["controlflow"] = ControlFlowInstrumentor()
    except Exception:
        logger.debug("ControlFlow instrumentor not available (module not found)")

    # Llama Stack instrumentor (agentic framework)
    try:
        from .llama_stack_instrumentor import LlamaStackInstrumentor

        _REGISTRY["llama_stack"] = LlamaStackInstrumentor()
    except Exception:
        logger.debug("Llama Stack instrumentor not available (module not found)")

    # LiveKit Agents instrumentor (agentic framework)
    try:
        from .livekit_agents_instrumentor import LiveKitAgentsInstrumentor

        _REGISTRY["livekit_agents"] = LiveKitAgentsInstrumentor()
    except Exception:
        logger.debug("LiveKit Agents instrumentor not available (module not found)")

    # Langroid instrumentor (agentic framework)
    try:
        from .langroid_instrumentor import LangroidInstrumentor

        _REGISTRY["langroid"] = LangroidInstrumentor()
    except Exception:
        logger.debug("Langroid instrumentor not available (module not found)")

    # ── Phase 7 additions ──────────────────────────────────────────

    # Meta Llama (via llama-stack-client)
    try:
        from .meta_llama_instrumentor import MetaLlamaInstrumentor

        _REGISTRY["meta_llama"] = MetaLlamaInstrumentor()
    except Exception:
        logger.debug("Meta Llama instrumentor not available (module not found)")

    # SuperAGI instrumentor
    try:
        from .superagi_instrumentor import SuperAGIInstrumentor

        _REGISTRY["superagi"] = SuperAGIInstrumentor()
    except Exception:
        logger.debug("SuperAGI instrumentor not available (module not found)")

    # Agency Swarm instrumentor
    try:
        from .agency_swarm_instrumentor import AgencySwarmInstrumentor

        _REGISTRY["agency_swarm"] = AgencySwarmInstrumentor()
    except Exception:
        logger.debug("Agency Swarm instrumentor not available (module not found)")

    # Julep instrumentor
    try:
        from .julep_instrumentor import JulepInstrumentor

        _REGISTRY["julep"] = JulepInstrumentor()
    except Exception:
        logger.debug("Julep instrumentor not available (module not found)")

    # Pipecat instrumentor
    try:
        from .pipecat_instrumentor import PipecatInstrumentor

        _REGISTRY["pipecat"] = PipecatInstrumentor()
    except Exception:
        logger.debug("Pipecat instrumentor not available (module not found)")

    # Deepgram instrumentor (voice/speech)
    try:
        from .deepgram_instrumentor import DeepgramInstrumentor

        _REGISTRY["deepgram"] = DeepgramInstrumentor()
    except Exception:
        logger.debug("Deepgram instrumentor not available (module not found)")

    # ElevenLabs instrumentor (voice/speech)
    try:
        from .elevenlabs_instrumentor import ElevenLabsInstrumentor

        _REGISTRY["elevenlabs"] = ElevenLabsInstrumentor()
    except Exception:
        logger.debug("ElevenLabs instrumentor not available (module not found)")

    # AssemblyAI instrumentor (voice/speech)
    try:
        from .assemblyai_instrumentor import AssemblyAIInstrumentor

        _REGISTRY["assemblyai"] = AssemblyAIInstrumentor()
    except Exception:
        logger.debug("AssemblyAI instrumentor not available (module not found)")

    # Whisper.cpp instrumentor (voice/speech)
    try:
        from .whisper_cpp_instrumentor import WhisperCppInstrumentor

        _REGISTRY["whisper_cpp"] = WhisperCppInstrumentor()
    except Exception:
        logger.debug("Whisper.cpp instrumentor not available (module not found)")

    # PlayHT instrumentor (voice/speech)
    try:
        from .playht_instrumentor import PlayHTInstrumentor

        _REGISTRY["playht"] = PlayHTInstrumentor()
    except Exception:
        logger.debug("PlayHT instrumentor not available (module not found)")

    # E5 embeddings instrumentor
    try:
        from .e5_instrumentor import E5Instrumentor

        _REGISTRY["e5"] = E5Instrumentor()
    except Exception:
        logger.debug("E5 instrumentor not available (module not found)")

    # Instructor Embeddings instrumentor
    try:
        from .instructor_embeddings_instrumentor import InstructorEmbeddingsInstrumentor

        _REGISTRY["instructor_embeddings"] = InstructorEmbeddingsInstrumentor()
    except Exception:
        logger.debug("Instructor Embeddings instrumentor not available (module not found)")

    # TEI (Text Embeddings Inference) instrumentor
    try:
        from .tei_instrumentor import TEIInstrumentor

        _REGISTRY["tei"] = TEIInstrumentor()
    except Exception:
        logger.debug("TEI instrumentor not available (module not found)")

    # promptfoo instrumentor (eval)
    try:
        from .promptfoo_instrumentor import PromptfooInstrumentor

        _REGISTRY["promptfoo"] = PromptfooInstrumentor()
    except Exception:
        logger.debug("promptfoo instrumentor not available (module not found)")

    # Arize Phoenix instrumentor (eval)
    try:
        from .arize_phoenix_instrumentor import ArizePhoenixInstrumentor

        _REGISTRY["arize_phoenix"] = ArizePhoenixInstrumentor()
    except Exception:
        logger.debug("Arize Phoenix instrumentor not available (module not found)")

    # Opik instrumentor (eval)
    try:
        from .opik_instrumentor import OpikInstrumentor

        _REGISTRY["opik"] = OpikInstrumentor()
    except Exception:
        logger.debug("Opik instrumentor not available (module not found)")

    # LangSmith instrumentor (eval)
    try:
        from .langsmith_instrumentor import LangSmithInstrumentor

        _REGISTRY["langsmith"] = LangSmithInstrumentor()
    except Exception:
        logger.debug("LangSmith instrumentor not available (module not found)")

    # Langfuse instrumentor (eval)
    try:
        from .langfuse_instrumentor import LangfuseInstrumentor

        _REGISTRY["langfuse"] = LangfuseInstrumentor()
    except Exception:
        logger.debug("Langfuse instrumentor not available (module not found)")

    # Vapi instrumentor (voice platform)
    try:
        from .vapi_instrumentor import VapiInstrumentor

        _REGISTRY["vapi"] = VapiInstrumentor()
    except Exception:
        logger.debug("Vapi instrumentor not available (module not found)")

    # Retell AI instrumentor (voice platform)
    try:
        from .retell_instrumentor import RetellInstrumentor

        _REGISTRY["retell"] = RetellInstrumentor()
    except Exception:
        logger.debug("Retell instrumentor not available (module not found)")

    # Stable Diffusion instrumentor (image generation)
    try:
        from .stable_diffusion_instrumentor import StableDiffusionInstrumentor

        _REGISTRY["stable_diffusion"] = StableDiffusionInstrumentor()
    except Exception:
        logger.debug("Stable Diffusion instrumentor not available (module not found)")

    # Flux instrumentor (image generation)
    try:
        from .flux_instrumentor import FluxInstrumentor

        _REGISTRY["flux"] = FluxInstrumentor()
    except Exception:
        logger.debug("Flux instrumentor not available (module not found)")

    # Fal AI instrumentor (serverless inference)
    try:
        from .fal_instrumentor import FalInstrumentor

        _REGISTRY["fal"] = FalInstrumentor()
    except Exception:
        logger.debug("Fal instrumentor not available (module not found)")

    # Supabase instrumentor (vector DB)
    try:
        from .supabase_instrumentor import SupabaseInstrumentor

        _REGISTRY["supabase"] = SupabaseInstrumentor()
    except Exception:
        logger.debug("Supabase instrumentor not available (module not found)")

    # SingleStore instrumentor (vector DB)
    try:
        from .singlestore_instrumentor import SinglestoreInstrumentor

        _REGISTRY["singlestore"] = SinglestoreInstrumentor()
    except Exception:
        logger.debug("SingleStore instrumentor not available (module not found)")

    # GraphRAG instrumentor (RAG)
    try:
        from .graphrag_instrumentor import GraphragInstrumentor

        _REGISTRY["graphrag"] = GraphragInstrumentor()
    except Exception:
        logger.debug("GraphRAG instrumentor not available (module not found)")

    # LightRAG instrumentor (RAG)
    try:
        from .lightrag_instrumentor import LightragInstrumentor

        _REGISTRY["lightrag"] = LightragInstrumentor()
    except Exception:
        logger.debug("LightRAG instrumentor not available (module not found)")

    # Pathway instrumentor (RAG)
    try:
        from .pathway_instrumentor import PathwayInstrumentor

        _REGISTRY["pathway"] = PathwayInstrumentor()
    except Exception:
        logger.debug("Pathway instrumentor not available (module not found)")

    # RAGFlow instrumentor (RAG)
    try:
        from .ragflow_instrumentor import RagflowInstrumentor

        _REGISTRY["ragflow"] = RagflowInstrumentor()
    except Exception:
        logger.debug("RAGFlow instrumentor not available (module not found)")

    # R2R instrumentor (RAG)
    try:
        from .r2r_instrumentor import R2rInstrumentor

        _REGISTRY["r2r"] = R2rInstrumentor()
    except Exception:
        logger.debug("R2R instrumentor not available (module not found)")

    # Vectara instrumentor (RAG)
    try:
        from .vectara_instrumentor import VectaraInstrumentor

        _REGISTRY["vectara"] = VectaraInstrumentor()
    except Exception:
        logger.debug("Vectara instrumentor not available (module not found)")

    # TensorRT-LLM instrumentor (model serving)
    try:
        from .tensorrt_llm_instrumentor import TensorRTLLMInstrumentor

        _REGISTRY["tensorrt_llm"] = TensorRTLLMInstrumentor()
    except Exception:
        logger.debug("TensorRT-LLM instrumentor not available (module not found)")

    # Triton instrumentor (model serving)
    try:
        from .triton_instrumentor import TritonInstrumentor

        _REGISTRY["triton"] = TritonInstrumentor()
    except Exception:
        logger.debug("Triton instrumentor not available (module not found)")

    # LocalAI instrumentor (local inference via OpenAI-compatible)
    try:
        from .localai_instrumentor import LocalAIInstrumentor

        _REGISTRY["localai"] = LocalAIInstrumentor()
    except Exception:
        logger.debug("LocalAI instrumentor not available (module not found)")

    # llamafile instrumentor (local inference via OpenAI-compatible)
    try:
        from .llamafile_instrumentor import LlamafileInstrumentor

        _REGISTRY["llamafile"] = LlamafileInstrumentor()
    except Exception:
        logger.debug("llamafile instrumentor not available (module not found)")

    # BentoML instrumentor (model serving)
    try:
        from .bentoml_instrumentor import BentoMLInstrumentor

        _REGISTRY["bentoml"] = BentoMLInstrumentor()
    except Exception:
        logger.debug("BentoML instrumentor not available (module not found)")

    # A2A (Agent-to-Agent) protocol instrumentor
    try:
        from .a2a_instrumentor import A2AInstrumentor

        _REGISTRY["a2a"] = A2AInstrumentor()
    except Exception:
        logger.debug("A2A instrumentor not available (module not found)")

    # Computer Use instrumentor (Anthropic)
    try:
        from .computer_use_instrumentor import ComputerUseInstrumentor

        _REGISTRY["computer_use"] = ComputerUseInstrumentor()
    except Exception:
        logger.debug("Computer Use instrumentor not available (module not found)")

    # ── Phase 8 additions ──────────────────────────────────────────

    # Google Cloud STT instrumentor
    try:
        from .google_cloud_stt_instrumentor import GoogleCloudSTTInstrumentor

        _REGISTRY["google_cloud_stt"] = GoogleCloudSTTInstrumentor()
    except Exception:
        logger.debug("Google Cloud STT instrumentor not available (module not found)")

    # Azure Speech (STT) instrumentor
    try:
        from .azure_speech_instrumentor import AzureSpeechInstrumentor

        _REGISTRY["azure_speech"] = AzureSpeechInstrumentor()
    except Exception:
        logger.debug("Azure Speech instrumentor not available (module not found)")

    # AWS Transcribe instrumentor
    try:
        from .aws_transcribe_instrumentor import AWSTranscribeInstrumentor

        _REGISTRY["aws_transcribe"] = AWSTranscribeInstrumentor()
    except Exception:
        logger.debug("AWS Transcribe instrumentor not available (module not found)")

    # Faster Whisper instrumentor
    try:
        from .faster_whisper_instrumentor import FasterWhisperInstrumentor

        _REGISTRY["faster_whisper"] = FasterWhisperInstrumentor()
    except Exception:
        logger.debug("Faster Whisper instrumentor not available (module not found)")

    # Google Cloud TTS instrumentor
    try:
        from .google_cloud_tts_instrumentor import GoogleCloudTTSInstrumentor

        _REGISTRY["google_cloud_tts"] = GoogleCloudTTSInstrumentor()
    except Exception:
        logger.debug("Google Cloud TTS instrumentor not available (module not found)")

    # Azure TTS instrumentor
    try:
        from .azure_tts_instrumentor import AzureTTSInstrumentor

        _REGISTRY["azure_tts"] = AzureTTSInstrumentor()
    except Exception:
        logger.debug("Azure TTS instrumentor not available (module not found)")

    # AWS Polly instrumentor
    try:
        from .aws_polly_instrumentor import AWSPollyInstrumentor

        _REGISTRY["aws_polly"] = AWSPollyInstrumentor()
    except Exception:
        logger.debug("AWS Polly instrumentor not available (module not found)")

    # Cartesia instrumentor
    try:
        from .cartesia_instrumentor import CartesiaInstrumentor

        _REGISTRY["cartesia"] = CartesiaInstrumentor()
    except Exception:
        logger.debug("Cartesia instrumentor not available (module not found)")

    # Coqui TTS instrumentor
    try:
        from .coqui_tts_instrumentor import CoquiTTSInstrumentor

        _REGISTRY["coqui_tts"] = CoquiTTSInstrumentor()
    except Exception:
        logger.debug("Coqui TTS instrumentor not available (module not found)")

    # Mirascope instrumentor
    try:
        from .mirascope_instrumentor import MirascopeInstrumentor

        _REGISTRY["mirascope"] = MirascopeInstrumentor()
    except Exception:
        logger.debug("Mirascope instrumentor not available (module not found)")

    # Outlines instrumentor
    try:
        from .outlines_instrumentor import OutlinesInstrumentor

        _REGISTRY["outlines"] = OutlinesInstrumentor()
    except Exception:
        logger.debug("Outlines instrumentor not available (module not found)")

    # Guidance instrumentor
    try:
        from .guidance_instrumentor import GuidanceInstrumentor

        _REGISTRY["guidance"] = GuidanceInstrumentor()
    except Exception:
        logger.debug("Guidance instrumentor not available (module not found)")

    # Magentic instrumentor
    try:
        from .magentic_instrumentor import MagenticInstrumentor

        _REGISTRY["magentic"] = MagenticInstrumentor()
    except Exception:
        logger.debug("Magentic instrumentor not available (module not found)")

    # LMQL instrumentor
    try:
        from .lmql_instrumentor import LMQLInstrumentor

        _REGISTRY["lmql"] = LMQLInstrumentor()
    except Exception:
        logger.debug("LMQL instrumentor not available (module not found)")

    # Marvin instrumentor
    try:
        from .marvin_instrumentor import MarvinInstrumentor

        _REGISTRY["marvin"] = MarvinInstrumentor()
    except Exception:
        logger.debug("Marvin instrumentor not available (module not found)")

    # Azure AI Inference instrumentor
    try:
        from .azure_ai_inference_instrumentor import AzureAIInferenceInstrumentor

        _REGISTRY["azure_ai_inference"] = AzureAIInferenceInstrumentor()
    except Exception:
        logger.debug("Azure AI Inference instrumentor not available (module not found)")

    # ScrapeGraphAI instrumentor
    try:
        from .scrapegraphai_instrumentor import ScrapeGraphAIInstrumentor

        _REGISTRY["scrapegraphai"] = ScrapeGraphAIInstrumentor()
    except Exception:
        logger.debug("ScrapeGraphAI instrumentor not available (module not found)")

    # E2B Code Interpreter instrumentor
    try:
        from .e2b_instrumentor import E2BInstrumentor

        _REGISTRY["e2b"] = E2BInstrumentor()
    except Exception:
        logger.debug("E2B instrumentor not available (module not found)")


def instrument_all(
    libraries: list[str] | None = None,
) -> dict[str, bool]:
    """Detect and instrument installed LLM libraries.

    Args:
        libraries: Explicit list of library names to instrument.
            If None, auto-detects all installed libraries.

    Returns:
        Dict mapping library name to whether instrumentation succeeded.
    """
    # Defense-in-depth: respect kill switch even if called directly
    kill = os.environ.get("WAXELL_OBSERVE", "").lower()
    if kill in ("false", "0", "no"):
        logger.debug("WAXELL_OBSERVE disabled -- skipping instrumentation")
        return {}

    _ensure_registry()

    # Determine which libraries to instrument
    if libraries is None:
        detected = detect_installed_libraries()
        targets = [name for name, found in detected.items() if found]
        logger.debug("Auto-detected libraries: %s", detected)
    else:
        targets = list(libraries)

    results: dict[str, bool] = {}
    for name in targets:
        instrumentor = _REGISTRY.get(name)
        if instrumentor is None:
            logger.debug(
                "No instrumentor registered for '%s' -- skipping", name
            )
            results[name] = False
            continue

        if instrumentor.is_instrumented():
            logger.debug("'%s' already instrumented -- skipping", name)
            results[name] = True
            continue

        try:
            success = instrumentor.instrument()
            results[name] = success
            if success:
                logger.debug("Instrumented '%s'", name)
            else:
                logger.debug("Instrumentor for '%s' returned False", name)
        except Exception as exc:
            logger.warning("Failed to instrument '%s': %s", name, exc)
            results[name] = False

    return results


def uninstrument_all() -> None:
    """Restore all instrumented libraries to their original state."""
    _ensure_registry()

    for name, instrumentor in _REGISTRY.items():
        if instrumentor.is_instrumented():
            try:
                instrumentor.uninstrument()
                logger.debug("Uninstrumented '%s'", name)
            except Exception as exc:
                logger.warning("Failed to uninstrument '%s': %s", name, exc)


__all__ = [
    "instrument_all",
    "uninstrument_all",
    "BaseInstrumentor",
    "detect_installed_libraries",
]
