"""OpenAI Agents SDK auto-instrumentor for waxell-observe.

Monkey-patches ``agents.Runner.run`` and ``agents.Runner.run_sync``
to emit OTel spans and record to the Waxell HTTP API.

The OpenAI Agents SDK (package ``openai-agents``, import ``agents``)
provides Runner.run (async) and Runner.run_sync as primary entry points.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class OpenAIAgentsInstrumentor(BaseInstrumentor):
    """Instrumentor for OpenAI Agents SDK (``openai-agents`` package).

    Patches Runner.run (async) and Runner.run_sync.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import agents  # noqa: F401
        except ImportError:
            logger.debug("agents (openai-agents) not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping OpenAI Agents instrumentation")
            return False

        patched = False

        # Patch Runner.run (async)
        try:
            wrapt.wrap_function_wrapper(
                "agents",
                "Runner.run",
                _runner_run_async_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Runner.run: %s", exc)

        # Patch Runner.run_sync
        try:
            wrapt.wrap_function_wrapper(
                "agents",
                "Runner.run_sync",
                _runner_run_sync_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Runner.run_sync: %s", exc)

        if not patched:
            logger.debug("Could not find OpenAI Agents Runner methods to patch")
            return False

        self._instrumented = True
        logger.debug("OpenAI Agents SDK instrumented (Runner.run + Runner.run_sync)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import agents

            if hasattr(agents.Runner.run, "__wrapped__"):
                agents.Runner.run = agents.Runner.run.__wrapped__
            if hasattr(agents.Runner.run_sync, "__wrapped__"):
                agents.Runner.run_sync = agents.Runner.run_sync.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("OpenAI Agents SDK uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


async def _runner_run_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Runner.run``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    # Extract agent from args (Runner.run(agent, input=...))
    agent = args[0] if args else kwargs.get("agent", None)
    agent_name = _get_agent_name(agent)
    model_name = _get_model_name(agent)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="openai_agents_run",
        )
        if model_name:
            span.set_attribute("waxell.openai_agents.model", model_name)
        _set_agent_attributes(span, agent)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _runner_run_sync_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Runner.run_sync``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent = args[0] if args else kwargs.get("agent", None)
    agent_name = _get_agent_name(agent)
    model_name = _get_model_name(agent)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="openai_agents_run_sync",
        )
        if model_name:
            span.set_attribute("waxell.openai_agents.model", model_name)
        _set_agent_attributes(span, agent)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_agent_name(agent) -> str:
    """Extract agent name from an OpenAI Agent object."""
    if agent is None:
        return "openai_agents.agent"
    return getattr(agent, "name", None) or "openai_agents.agent"


def _get_model_name(agent) -> str:
    """Extract model name from an OpenAI Agent object."""
    try:
        if agent is None:
            return ""
        model = getattr(agent, "model", None)
        if model:
            return str(model)
    except Exception:
        pass
    return ""


def _set_agent_attributes(span, agent) -> None:
    """Set agent-specific attributes on the span."""
    if agent is None:
        return

    # Record handoffs
    try:
        handoffs = getattr(agent, "handoffs", None) or []
        if handoffs:
            handoff_names = []
            for h in handoffs:
                name = getattr(h, "name", None) or getattr(h, "agent_name", None) or str(h)
                handoff_names.append(name)
            span.set_attribute("waxell.openai_agents.handoffs", handoff_names)
            span.set_attribute("waxell.openai_agents.handoff_count", len(handoff_names))
    except Exception:
        pass

    # Record tools
    try:
        tools = getattr(agent, "tools", None) or []
        if tools:
            tool_names = []
            for t in tools:
                name = getattr(t, "name", None) or type(t).__name__
                tool_names.append(name)
            span.set_attribute("waxell.openai_agents.tools", tool_names)
            span.set_attribute("waxell.openai_agents.tool_count", len(tool_names))
    except Exception:
        pass


def _set_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span."""
    # Record tool calls from result
    tool_calls = []
    try:
        raw_responses = getattr(result, "raw_responses", None) or []
        for response in raw_responses:
            choices = getattr(response, "choices", [])
            for choice in choices:
                message = getattr(choice, "message", None)
                if message:
                    calls = getattr(message, "tool_calls", None) or []
                    for call in calls:
                        fn = getattr(call, "function", None)
                        if fn:
                            tool_calls.append(getattr(fn, "name", "unknown"))
    except Exception:
        pass

    if tool_calls:
        span.set_attribute("waxell.openai_agents.tool_calls_made", tool_calls)

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            final_output = getattr(result, "final_output", None)
            ctx.record_step(
                f"openai_agents:{agent_name}",
                output={
                    "result_preview": str(final_output)[:500] if final_output else "",
                    "tool_calls": tool_calls,
                },
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
