"""SGLang auto-instrumentor for waxell-observe.

Monkey-patches ``sglang.Engine.generate`` and ``sglang.Engine.encode``
to emit LLM call and embedding spans for SGLang model serving.

SGLang responses vary by mode but typically contain:
  - Completion text
  - Usage info (prompt_tokens, completion_tokens)
  - Model name from engine config

Also attempts to patch ``sglang.srt.server.Runtime`` if available
(OpenAI-compatible server client).

Cost is always 0.0 for local/self-hosted inference.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class SGLangInstrumentor(BaseInstrumentor):
    """Instrumentor for the SGLang library (``sglang`` package).

    Patches ``Engine.generate``, ``Engine.encode``, and optionally
    ``srt.server.Runtime`` methods.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import sglang  # noqa: F401
        except ImportError:
            logger.debug("sglang package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping SGLang instrumentation")
            return False

        patched = False

        # Patch Engine.generate
        try:
            wrapt.wrap_function_wrapper(
                "sglang",
                "Engine.generate",
                _sync_generate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch sglang.Engine.generate: %s", exc)

        # Patch Engine.encode (embedding/encode endpoint)
        try:
            wrapt.wrap_function_wrapper(
                "sglang",
                "Engine.encode",
                _sync_encode_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch sglang.Engine.encode: %s", exc)

        # Optionally patch srt.server.Runtime.generate if available
        try:
            wrapt.wrap_function_wrapper(
                "sglang.srt.server",
                "Runtime.generate",
                _sync_runtime_generate_wrapper,
            )
            patched = True
            logger.debug("SGLang srt.server.Runtime.generate patched")
        except Exception as exc:
            logger.debug(
                "Could not patch sglang.srt.server.Runtime.generate "
                "(may not exist in this version): %s",
                exc,
            )

        if not patched:
            logger.debug("Could not find any SGLang methods to patch")
            return False

        self._instrumented = True
        logger.debug("SGLang instrumented (Engine.generate + Engine.encode)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import sglang

            for attr in ("generate", "encode"):
                try:
                    method = getattr(sglang.Engine, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(sglang.Engine, attr, method.__wrapped__)
                except (AttributeError, TypeError):
                    pass
        except ImportError:
            pass

        # Uninstrument srt.server.Runtime if it was patched
        try:
            import sglang.srt.server as server_mod

            method = getattr(server_mod.Runtime, "generate", None)
            if method is not None and hasattr(method, "__wrapped__"):
                setattr(server_mod.Runtime, "generate", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("SGLang uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from SGLang responses
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from an SGLang Engine or Runtime instance.

    Tries several attribute paths used across different SGLang versions.
    """
    for attr in ("model_path", "model_name", "model_config", "served_model_name"):
        try:
            val = getattr(instance, attr, None)
            if val is None:
                continue

            if isinstance(val, str):
                return val

            # Nested config with a model attribute
            model_name = getattr(val, "model", None)
            if model_name and isinstance(model_name, str):
                return model_name
        except Exception:
            continue

    return "sglang-local"


def _extract_usage(response) -> tuple[int, int]:
    """Extract token counts from an SGLang response.

    SGLang responses can be dicts or objects with varying structures.
    Returns (tokens_in, tokens_out).
    """
    if response is None:
        return 0, 0

    try:
        # Dict-style response
        if isinstance(response, dict):
            usage = response.get("usage")
            if isinstance(usage, dict) and ("prompt_tokens" in usage or "completion_tokens" in usage):
                tokens_in = usage.get("prompt_tokens", 0) or 0
                tokens_out = usage.get("completion_tokens", 0) or 0
                return tokens_in, tokens_out

            # Flat token fields (no usage sub-dict, or usage was empty)
            tokens_in = response.get("prompt_tokens", 0) or 0
            tokens_out = response.get("completion_tokens", 0) or 0
            if tokens_in or tokens_out:
                return tokens_in, tokens_out

        # Object-style response
        usage = getattr(response, "usage", None)
        if usage is not None:
            tokens_in = getattr(usage, "prompt_tokens", 0) or 0
            tokens_out = getattr(usage, "completion_tokens", 0) or 0
            return tokens_in, tokens_out

        # Direct attributes
        tokens_in = getattr(response, "prompt_tokens", 0) or 0
        tokens_out = getattr(response, "completion_tokens", 0) or 0
        return tokens_in, tokens_out

    except Exception:
        return 0, 0


def _extract_response_text(response) -> str:
    """Extract text from an SGLang response for logging."""
    if response is None:
        return ""

    try:
        # Dict-style
        if isinstance(response, dict):
            # Check choices[0].message.content or choices[0].text
            choices = response.get("choices", [])
            if choices and isinstance(choices, list):
                first = choices[0]
                if isinstance(first, dict):
                    msg = first.get("message", {})
                    if isinstance(msg, dict) and msg.get("content"):
                        return str(msg["content"])[:500]
                    text = first.get("text", "")
                    if text:
                        return str(text)[:500]

            # Flat text field
            text = response.get("text", "")
            if text:
                return str(text)[:500]

        # Object-style
        choices = getattr(response, "choices", None)
        if choices and len(choices) > 0:
            first = choices[0]
            msg = getattr(first, "message", None)
            if msg:
                content = getattr(msg, "content", "")
                if content:
                    return str(content)[:500]
            text = getattr(first, "text", "")
            if text:
                return str(text)[:500]

        text = getattr(response, "text", "")
        if text:
            return str(text)[:500]

    except Exception:
        pass

    return ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``sglang.Engine.generate``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="sglang")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_usage(response)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_sglang(response, model, kwargs, task="generate")
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_encode_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``sglang.Engine.encode`` (embeddings)."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    # Count inputs
    input_data = kwargs.get("input", kwargs.get("text", ""))
    if args:
        input_data = args[0]
    if isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=model, provider_name="sglang", input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = 0
            # Dict response: {"data": [{"embedding": [0.1, ...]}], ...}
            if isinstance(response, dict):
                data_list = response.get("data", [])
                if data_list and isinstance(data_list, list):
                    first = data_list[0]
                    if isinstance(first, dict):
                        emb = first.get("embedding", [])
                        if emb and isinstance(emb, list):
                            dimensions = len(emb)
            # Object response
            elif hasattr(response, "data"):
                data_list = getattr(response, "data", [])
                if data_list and len(data_list) > 0:
                    first = data_list[0]
                    emb = getattr(first, "embedding", [])
                    if emb and isinstance(emb, list):
                        dimensions = len(emb)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, 0)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_sglang_embed(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_runtime_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``sglang.srt.server.Runtime.generate``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="sglang")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_usage(response)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_sglang(response, model, kwargs, task="runtime.generate")
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_sglang(
    response, request_model: str, kwargs: dict, task: str = "generate"
) -> None:
    """Record an SGLang LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens_in, tokens_out = _extract_usage(response)

    # Extract prompt preview
    prompt_preview = ""
    prompt = kwargs.get("prompt", kwargs.get("input", ""))
    if isinstance(prompt, str):
        prompt_preview = prompt[:500]
    elif isinstance(prompt, list) and prompt:
        prompt_preview = str(prompt[0])[:500]

    response_preview = _extract_response_text(response)

    call_data = {
        "model": request_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,  # Local inference is always free
        "task": f"sglang.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_sglang_embed(response, model: str, kwargs: dict) -> None:
    """Record an SGLang embedding call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "sglang.encode",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
