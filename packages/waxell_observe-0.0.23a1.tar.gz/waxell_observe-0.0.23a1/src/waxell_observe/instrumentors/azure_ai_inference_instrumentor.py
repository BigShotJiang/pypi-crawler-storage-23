"""Azure AI Inference auto-instrumentor for waxell-observe.

Monkey-patches ``azure.ai.inference.ChatCompletionsClient.complete`` (sync)
and ``azure.ai.inference.aio.ChatCompletionsClient.complete`` (async) to
emit OTel spans with GenAI semantic convention attributes.  Also patches
``azure.ai.inference.EmbeddingsClient.embed`` (sync + async) to emit
embedding spans.

The Azure AI Inference SDK has an OpenAI-like response format, so this
instrumentor follows a very similar pattern to the OpenAI instrumentor.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AzureAIInferenceInstrumentor(BaseInstrumentor):
    """Instrumentor for the Azure AI Inference SDK (``azure-ai-inference`` package).

    Patches ChatCompletionsClient.complete and EmbeddingsClient.embed
    for both sync and async clients.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import azure.ai.inference  # noqa: F401
        except ImportError:
            logger.debug("azure.ai.inference not installed -- skipping instrumentation")
            return False

        # Log detected version for diagnostics
        try:
            import azure.ai.inference as _pkg

            _version = getattr(_pkg, "__version__", "unknown")
            logger.debug("Detected azure-ai-inference version: %s", _version)
        except Exception:
            pass

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Azure AI Inference instrumentation")
            return False

        patched = False

        # Patch sync ChatCompletionsClient.complete
        try:
            wrapt.wrap_function_wrapper(
                "azure.ai.inference",
                "ChatCompletionsClient.complete",
                _sync_chat_wrapper,
            )
            patched = True
            logger.debug("Patched azure.ai.inference.ChatCompletionsClient.complete")
        except Exception as exc:
            logger.debug("Could not patch sync ChatCompletionsClient.complete: %s", exc)

        # Patch async ChatCompletionsClient.complete
        try:
            wrapt.wrap_function_wrapper(
                "azure.ai.inference.aio",
                "ChatCompletionsClient.complete",
                _async_chat_wrapper,
            )
            logger.debug("Patched azure.ai.inference.aio.ChatCompletionsClient.complete")
        except Exception as exc:
            logger.debug("Could not patch async ChatCompletionsClient.complete: %s", exc)

        # Patch sync EmbeddingsClient.embed
        try:
            wrapt.wrap_function_wrapper(
                "azure.ai.inference",
                "EmbeddingsClient.embed",
                _sync_embeddings_wrapper,
            )
            logger.debug("Patched azure.ai.inference.EmbeddingsClient.embed")
        except Exception as exc:
            logger.debug("Could not patch sync EmbeddingsClient.embed: %s", exc)

        # Patch async EmbeddingsClient.embed
        try:
            wrapt.wrap_function_wrapper(
                "azure.ai.inference.aio",
                "EmbeddingsClient.embed",
                _async_embeddings_wrapper,
            )
            logger.debug("Patched azure.ai.inference.aio.EmbeddingsClient.embed")
        except Exception as exc:
            logger.debug("Could not patch async EmbeddingsClient.embed: %s", exc)

        if not patched:
            logger.debug("Could not find Azure AI Inference methods to patch")
            return False

        self._instrumented = True
        logger.debug("Azure AI Inference instrumented (chat + embeddings)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore sync ChatCompletionsClient.complete
        try:
            from azure.ai.inference import ChatCompletionsClient

            if hasattr(ChatCompletionsClient.complete, "__wrapped__"):
                ChatCompletionsClient.complete = ChatCompletionsClient.complete.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore async ChatCompletionsClient.complete
        try:
            from azure.ai.inference.aio import ChatCompletionsClient as AsyncChatClient

            if hasattr(AsyncChatClient.complete, "__wrapped__"):
                AsyncChatClient.complete = AsyncChatClient.complete.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore sync EmbeddingsClient.embed
        try:
            from azure.ai.inference import EmbeddingsClient

            if hasattr(EmbeddingsClient.embed, "__wrapped__"):
                EmbeddingsClient.embed = EmbeddingsClient.embed.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore async EmbeddingsClient.embed
        try:
            from azure.ai.inference.aio import EmbeddingsClient as AsyncEmbClient

            if hasattr(AsyncEmbClient.embed, "__wrapped__"):
                AsyncEmbClient.embed = AsyncEmbClient.embed.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Azure AI Inference uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Chat completion wrappers
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ChatCompletionsClient.complete``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    try:
        span = start_llm_span(model=str(model), provider_name="azure")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_chat_span_attributes(span, response, model)
        except Exception as attr_exc:
            logger.debug("Failed to set Azure AI chat span attributes: %s", attr_exc)

        # Record to HTTP path
        try:
            _record_http_azure_chat(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``ChatCompletionsClient.complete``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    try:
        span = start_llm_span(model=str(model), provider_name="azure")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_chat_span_attributes(span, response, model)
        except Exception as attr_exc:
            logger.debug("Failed to set Azure AI chat span attributes: %s", attr_exc)

        # Record to HTTP path
        try:
            _record_http_azure_chat(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _set_chat_span_attributes(span, response, request_model: str) -> None:
    """Extract and set span attributes from an Azure AI chat response."""
    from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    from ..cost import estimate_cost

    tokens_in = 0
    tokens_out = 0
    if hasattr(response, "usage") and response.usage:
        tokens_in = getattr(response.usage, "prompt_tokens", 0) or 0
        tokens_out = getattr(response.usage, "completion_tokens", 0) or 0

    response_model = getattr(response, "model", request_model) or request_model
    cost = estimate_cost(str(response_model), tokens_in, tokens_out)

    finish_reasons = []
    if hasattr(response, "choices") and response.choices:
        finish_reasons = [
            c.finish_reason for c in response.choices if hasattr(c, "finish_reason") and c.finish_reason
        ]

    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
    span.set_attribute(GenAIAttributes.RESPONSE_MODEL, str(response_model))
    span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
    span.set_attribute(WaxellAttributes.LLM_MODEL, str(response_model))
    span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
    span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
    span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
    span.set_attribute(WaxellAttributes.LLM_COST, cost)


# ---------------------------------------------------------------------------
# Embeddings wrappers
# ---------------------------------------------------------------------------


def _sync_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``EmbeddingsClient.embed``."""
    try:
        from ..tracing.spans import start_embedding_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    # Count inputs
    input_data = kwargs.get("input", args[0] if args else [])
    if isinstance(input_data, str):
        input_count = 1
    elif isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=str(model), provider_name="azure", input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_embedding_span_attributes(span, response, model, input_count)
        except Exception as attr_exc:
            logger.debug("Failed to set Azure AI embedding span attributes: %s", attr_exc)

        # Record to HTTP path
        try:
            _record_http_azure_embedding(response, model)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``EmbeddingsClient.embed``."""
    try:
        from ..tracing.spans import start_embedding_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    input_data = kwargs.get("input", args[0] if args else [])
    if isinstance(input_data, str):
        input_count = 1
    elif isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=str(model), provider_name="azure", input_count=input_count)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_embedding_span_attributes(span, response, model, input_count)
        except Exception as attr_exc:
            logger.debug("Failed to set Azure AI embedding span attributes: %s", attr_exc)

        try:
            _record_http_azure_embedding(response, model)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _set_embedding_span_attributes(span, response, model: str, input_count: int) -> None:
    """Extract and set span attributes from an Azure AI embedding response."""
    from ..tracing.attributes import WaxellAttributes
    from ..cost import estimate_embedding_cost

    tokens = 0
    if hasattr(response, "usage") and response.usage:
        tokens = getattr(response.usage, "prompt_tokens", 0) or 0

    dimensions = 0
    if hasattr(response, "data") and response.data:
        try:
            dimensions = len(response.data[0].embedding)
        except (IndexError, AttributeError):
            pass

    cost = estimate_embedding_cost(model, tokens, "azure")

    span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
    span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
    span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
    span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
    span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_azure_chat(response, request_model: str, kwargs: dict) -> None:
    """Record an Azure AI chat call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    tokens_in = 0
    tokens_out = 0
    if hasattr(response, "usage") and response.usage:
        tokens_in = getattr(response.usage, "prompt_tokens", 0) or 0
        tokens_out = getattr(response.usage, "completion_tokens", 0) or 0

    response_model = getattr(response, "model", request_model) or request_model
    cost = estimate_cost(str(response_model), tokens_in, tokens_out)

    # Extract prompt preview
    prompt_preview = ""
    messages = kwargs.get("messages", [])
    if messages:
        try:
            first_msg = messages[0]
            if isinstance(first_msg, dict):
                prompt_preview = str(first_msg.get("content", ""))[:500]
            elif hasattr(first_msg, "content"):
                prompt_preview = str(first_msg.content)[:500]
        except Exception:
            pass

    # Extract response preview
    response_preview = ""
    if hasattr(response, "choices") and response.choices:
        try:
            msg = response.choices[0].message
            if msg and hasattr(msg, "content") and msg.content:
                response_preview = str(msg.content)[:500]
        except (IndexError, AttributeError):
            pass

    call_data = {
        "model": str(response_model),
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "azure.chat.completions",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_azure_embedding(response, model: str) -> None:
    """Record an Azure AI embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_embedding_cost

    tokens = 0
    if hasattr(response, "usage") and response.usage:
        tokens = getattr(response.usage, "prompt_tokens", 0) or 0

    cost = estimate_embedding_cost(model, tokens, "azure")

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "azure.embeddings",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span, setting status to ERROR."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
