"""Sentence Transformers auto-instrumentor for waxell-observe.

Monkey-patches SentenceTransformer.encode to emit embedding spans
tracking local embedding generation.

The ``sentence-transformers`` library provides a simple interface for
computing sentence embeddings using pre-trained models. Since these run
locally, cost is always 0.0.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class SentenceTransformersInstrumentor(BaseInstrumentor):
    """Instrumentor for the sentence-transformers library.

    Patches ``SentenceTransformer.encode`` to emit embedding spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import sentence_transformers  # noqa: F401
        except ImportError:
            logger.debug(
                "sentence_transformers package not installed -- skipping instrumentation"
            )
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping sentence-transformers instrumentation"
            )
            return False

        try:
            wrapt.wrap_function_wrapper(
                "sentence_transformers",
                "SentenceTransformer.encode",
                _sync_encode_wrapper,
            )

            self._instrumented = True
            logger.debug("SentenceTransformer instrumented (encode)")
            return True
        except Exception as exc:
            logger.warning(
                "Failed to instrument sentence-transformers (possibly incompatible version): %s",
                exc,
            )
            return False

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import sentence_transformers

            method = getattr(sentence_transformers.SentenceTransformer, "encode", None)
            if method is not None and hasattr(method, "__wrapped__"):
                sentence_transformers.SentenceTransformer.encode = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("SentenceTransformer uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a SentenceTransformer instance.

    Tries several attribute paths used across different library versions.
    """
    try:
        # Newer versions expose model_card_data with a model_name or base_model
        card = getattr(instance, "model_card_data", None)
        if card is not None:
            name = getattr(card, "model_name", None) or getattr(
                card, "base_model", None
            )
            if name:
                return str(name)
    except Exception:
        pass

    # Try the private _model_name attribute (used internally)
    try:
        name = getattr(instance, "_model_name", None)
        if name:
            return str(name)
    except Exception:
        pass

    # Try the first module's auto_model config (transformer model name)
    try:
        first_module = instance[0]
        auto_model = getattr(first_module, "auto_model", None)
        if auto_model is not None:
            config = getattr(auto_model, "config", None)
            if config is not None:
                name = getattr(config, "name_or_path", None) or getattr(
                    config, "_name_or_path", None
                )
                if name:
                    return str(name)
    except Exception:
        pass

    return "sentence-transformers"


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_encode_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``SentenceTransformer.encode``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)

    # Count inputs
    sentences = args[0] if args else kwargs.get("sentences", [])
    if isinstance(sentences, str):
        input_count = 1
    elif isinstance(sentences, list):
        input_count = len(sentences)
    else:
        input_count = 1

    # Estimate token count from input text (rough: ~1.3 tokens per word)
    tokens_in = 0
    try:
        if isinstance(sentences, str):
            tokens_in = int(len(sentences.split()) * 1.3)
        elif isinstance(sentences, list):
            tokens_in = int(
                sum(len(s.split()) * 1.3 for s in sentences if isinstance(s, str))
            )
    except Exception:
        pass

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="sentence_transformers",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        dimensions = 0
        try:
            # Get dimensions from result -- try numpy first, fall back to list
            try:
                import numpy as np

                _has_numpy = True
            except ImportError:
                _has_numpy = False

            if _has_numpy and isinstance(result, np.ndarray):
                dimensions = result.shape[-1] if result.ndim > 1 else result.shape[0]
            elif hasattr(result, "shape"):
                # Mock or array-like with .shape
                dimensions = (
                    result.shape[-1] if len(result.shape) > 1 else result.shape[0]
                )
            elif isinstance(result, list):
                dimensions = len(result[0]) if result else 0
            else:
                dimensions = 0

            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)  # Local, free
        except Exception:
            pass

        try:
            _record_http_embedding(model_name, input_count, dimensions, tokens_in)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_embedding(
    model: str,
    input_count: int,
    dimensions: int = 0,
    tokens_in: int = 0,
) -> None:
    """Record a sentence-transformers embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "sentence_transformers.encode",
        "prompt_preview": f"encode {input_count} sentence(s), dim={dimensions}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
