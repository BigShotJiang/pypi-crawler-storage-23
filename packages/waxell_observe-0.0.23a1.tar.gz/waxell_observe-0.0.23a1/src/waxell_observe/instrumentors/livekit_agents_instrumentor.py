"""LiveKit Agents auto-instrumentor for waxell-observe.

Monkey-patches ``livekit.agents.llm.LLM.chat``,
``livekit.agents.stt.STT.recognize``, ``livekit.agents.tts.TTS.synthesize``,
and ``livekit.agents.pipeline.VoicePipelineAgent.start`` to emit OTel spans
and record to the Waxell HTTP API.

LiveKit Agents is a framework for building real-time voice and video AI
agents with LLM, STT, and TTS capabilities.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LiveKitAgentsInstrumentor(BaseInstrumentor):
    """Instrumentor for LiveKit Agents (``livekit-agents`` package).

    Patches LLM.chat for LLM calls, STT.recognize for speech-to-text,
    TTS.synthesize for text-to-speech, and VoicePipelineAgent.start
    for pipeline execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import livekit.agents  # noqa: F401
        except ImportError:
            logger.debug("livekit.agents not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping LiveKit Agents instrumentation")
            return False

        patched = False

        # Patch LLM.chat
        try:
            wrapt.wrap_function_wrapper(
                "livekit.agents.llm",
                "LLM.chat",
                _llm_chat_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch livekit.agents.llm.LLM.chat: %s", exc)

        # Patch STT.recognize
        try:
            wrapt.wrap_function_wrapper(
                "livekit.agents.stt",
                "STT.recognize",
                _stt_recognize_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch livekit.agents.stt.STT.recognize: %s", exc)

        # Patch TTS.synthesize
        try:
            wrapt.wrap_function_wrapper(
                "livekit.agents.tts",
                "TTS.synthesize",
                _tts_synthesize_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch livekit.agents.tts.TTS.synthesize: %s", exc)

        # Patch VoicePipelineAgent.start
        try:
            wrapt.wrap_function_wrapper(
                "livekit.agents.pipeline",
                "VoicePipelineAgent.start",
                _pipeline_start_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch VoicePipelineAgent.start: %s", exc)

        if not patched:
            logger.debug("Could not find LiveKit Agents methods to patch")
            return False

        self._instrumented = True
        logger.debug("LiveKit Agents instrumented (LLM + STT + TTS + Pipeline)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore LLM.chat
        try:
            from livekit.agents.llm import LLM

            if hasattr(getattr(LLM, "chat", None), "__wrapped__"):
                LLM.chat = LLM.chat.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore STT.recognize
        try:
            from livekit.agents.stt import STT

            if hasattr(getattr(STT, "recognize", None), "__wrapped__"):
                STT.recognize = STT.recognize.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore TTS.synthesize
        try:
            from livekit.agents.tts import TTS

            if hasattr(getattr(TTS, "synthesize", None), "__wrapped__"):
                TTS.synthesize = TTS.synthesize.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore VoicePipelineAgent.start
        try:
            from livekit.agents.pipeline import VoicePipelineAgent

            if hasattr(getattr(VoicePipelineAgent, "start", None), "__wrapped__"):
                VoicePipelineAgent.start = VoicePipelineAgent.start.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("LiveKit Agents uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _llm_chat_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``LLM.chat`` -- LLM chat in LiveKit Agents."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _extract_model_name(instance)
    chat_ctx = kwargs.get("chat_ctx", None) or (args[0] if args else None)

    try:
        span = start_llm_span(
            model=model_name,
            provider_name="livekit_agents",
        )
        span.set_attribute("waxell.agent.framework", "livekit_agents")
        span.set_attribute("waxell.livekit.operation", "llm_chat")
        if chat_ctx:
            try:
                messages = getattr(chat_ctx, "messages", None)
                if messages:
                    span.set_attribute("waxell.livekit.message_count", len(messages))
            except Exception:
                pass
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_llm_result_attributes(span, result, model_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _stt_recognize_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``STT.recognize`` -- speech-to-text."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    stt_name = _extract_component_name(instance, "stt")

    try:
        span = start_step_span(step_name=f"stt:{stt_name}")
        span.set_attribute("waxell.agent.framework", "livekit_agents")
        span.set_attribute("waxell.livekit.operation", "stt_recognize")
        span.set_attribute("waxell.livekit.component", stt_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_stt_result_attributes(span, result, stt_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _tts_synthesize_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``TTS.synthesize`` -- text-to-speech."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    tts_name = _extract_component_name(instance, "tts")
    text = kwargs.get("text", "") or (args[0] if args else "")

    try:
        span = start_step_span(step_name=f"tts:{tts_name}")
        span.set_attribute("waxell.agent.framework", "livekit_agents")
        span.set_attribute("waxell.livekit.operation", "tts_synthesize")
        span.set_attribute("waxell.livekit.component", tts_name)
        if text:
            span.set_attribute("waxell.livekit.text_preview", str(text)[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_tts_result_attributes(span, result, tts_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _pipeline_start_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``VoicePipelineAgent.start`` -- pipeline execution."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    pipeline_name = _extract_component_name(instance, "voice_pipeline")

    try:
        span = start_agent_span(
            agent_name=pipeline_name,
            workflow_name="livekit_voice_pipeline",
        )
        span.set_attribute("waxell.agent.framework", "livekit_agents")
        span.set_attribute("waxell.livekit.operation", "pipeline_start")
        span.set_attribute("waxell.livekit.component", pipeline_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_pipeline_result_attributes(span, result, pipeline_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_model_name(instance) -> str:
    """Extract model name from an LLM instance."""
    try:
        model = getattr(instance, "model", None) or getattr(instance, "model_name", None)
        if model:
            return str(model)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "livekit.llm"


def _extract_component_name(instance, default: str) -> str:
    """Extract component name from a LiveKit instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return default


def _set_llm_result_attributes(span, result, model_name: str) -> None:
    """Set result attributes for LLM chat."""
    try:
        # LiveKit LLM chat may return a stream or a response
        content = getattr(result, "content", None)
        if content:
            span.set_attribute("waxell.livekit.response_preview", str(content)[:200])

        usage = getattr(result, "usage", None)
        if usage:
            input_tokens = getattr(usage, "prompt_tokens", None) or getattr(usage, "input_tokens", None)
            output_tokens = getattr(usage, "completion_tokens", None) or getattr(usage, "output_tokens", None)
            if input_tokens is not None:
                span.set_attribute("waxell.livekit.input_tokens", int(input_tokens))
            if output_tokens is not None:
                span.set_attribute("waxell.livekit.output_tokens", int(output_tokens))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                content = getattr(result, "content", None)
                if content:
                    result_preview = str(content)[:500]
            except Exception:
                pass
            ctx.record_step(
                "llm:livekit.chat",
                output={"model": model_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_stt_result_attributes(span, result, stt_name: str) -> None:
    """Set result attributes for STT recognition."""
    try:
        # STT result typically has text/transcript
        text = getattr(result, "text", None) or getattr(result, "transcript", None)
        if text:
            span.set_attribute("waxell.livekit.transcript_preview", str(text)[:200])

        # Audio duration if available
        duration = getattr(result, "duration", None)
        if duration is not None:
            span.set_attribute("waxell.livekit.audio_duration", float(duration))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            transcript = ""
            try:
                text = getattr(result, "text", None) or getattr(result, "transcript", "")
                transcript = str(text)[:500]
            except Exception:
                pass
            ctx.record_step(
                "step:livekit.stt",
                output={"component": stt_name, "transcript_preview": transcript},
            )
    except Exception:
        pass


def _set_tts_result_attributes(span, result, tts_name: str) -> None:
    """Set result attributes for TTS synthesis."""
    try:
        # TTS may return audio with duration
        duration = getattr(result, "duration", None)
        if duration is not None:
            span.set_attribute("waxell.livekit.audio_duration", float(duration))

        sample_rate = getattr(result, "sample_rate", None)
        if sample_rate is not None:
            span.set_attribute("waxell.livekit.sample_rate", int(sample_rate))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:livekit.tts",
                output={"component": tts_name},
            )
    except Exception:
        pass


def _set_pipeline_result_attributes(span, result, pipeline_name: str) -> None:
    """Set result attributes for pipeline start."""
    try:
        status = getattr(result, "status", None)
        if status:
            span.set_attribute("waxell.livekit.pipeline_status", str(status))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "agent:livekit.pipeline",
                output={"pipeline": pipeline_name},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
