"""ElevenLabs auto-instrumentor for waxell-observe.

Monkey-patches ElevenLabs SDK methods to emit OTel step spans for
text-to-speech (TTS) and speech-to-text (STT / Scribe) operations:
  - ``ElevenLabs.text_to_speech.convert``           -- TTS (returns audio bytes)
  - ``ElevenLabs.text_to_speech.convert_as_stream``  -- TTS streaming
  - ``ElevenLabs.speech_to_text.convert``            -- STT (Scribe v1)

The ElevenLabs Python SDK (``elevenlabs``) client methods accept:
  TTS:
    - ``voice_id`` (str) -- the voice to use
    - ``text`` (str) -- input text to synthesize
    - ``model_id`` (str) -- e.g. "eleven_multilingual_v2"
    - ``output_format`` (str) -- e.g. "mp3_44100_128"

  STT (Scribe):
    - ``audio`` (file-like or bytes) -- audio to transcribe
    - ``model_id`` (str) -- e.g. "scribe_v1"
    - ``language_code`` (str)

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ElevenLabsInstrumentor(BaseInstrumentor):
    """Instrumentor for the ElevenLabs Python SDK (``elevenlabs`` package).

    Patches ``ElevenLabs.text_to_speech.convert``,
    ``ElevenLabs.text_to_speech.convert_as_stream``, and
    ``ElevenLabs.speech_to_text.convert``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import elevenlabs  # noqa: F401
        except ImportError:
            logger.debug("elevenlabs package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping ElevenLabs instrumentation"
            )
            return False

        patched = False

        # Patch TTS convert (sync) — try new module path first, fall back to old
        for tts_module in ("elevenlabs.realtime_tts", "elevenlabs.text_to_speech"):
            for cls_name, wrapper in (
                ("RealtimeTextToSpeechClient.convert", _sync_tts_convert_wrapper),
                ("TextToSpeechClient.convert", _sync_tts_convert_wrapper),
                ("RealtimeTextToSpeechClient.stream", _sync_tts_stream_wrapper),
                ("TextToSpeechClient.convert_as_stream", _sync_tts_stream_wrapper),
            ):
                try:
                    wrapt.wrap_function_wrapper(tts_module, cls_name, wrapper)
                    patched = True
                except Exception:
                    pass

        # Patch async TTS — try new module path first, fall back to old
        for tts_module in ("elevenlabs.realtime_tts", "elevenlabs.text_to_speech"):
            for cls_name, wrapper in (
                ("AsyncRealtimeTextToSpeechClient.convert", _async_tts_convert_wrapper),
                ("AsyncTextToSpeechClient.convert", _async_tts_convert_wrapper),
                ("AsyncRealtimeTextToSpeechClient.stream", _async_tts_stream_wrapper),
                (
                    "AsyncTextToSpeechClient.convert_as_stream",
                    _async_tts_stream_wrapper,
                ),
            ):
                try:
                    wrapt.wrap_function_wrapper(tts_module, cls_name, wrapper)
                    patched = True
                except Exception:
                    pass

        # Patch speech_to_text.convert (sync STT / Scribe)
        try:
            wrapt.wrap_function_wrapper(
                "elevenlabs.speech_to_text",
                "SpeechToTextClient.convert",
                _sync_stt_convert_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch ElevenLabs STT convert: %s", exc)

        # Patch async speech_to_text.convert
        try:
            wrapt.wrap_function_wrapper(
                "elevenlabs.speech_to_text",
                "AsyncSpeechToTextClient.convert",
                _async_stt_convert_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch ElevenLabs async STT convert: %s", exc)

        if not patched:
            logger.debug("Could not find any ElevenLabs methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "ElevenLabs instrumented (TTS convert + convert_as_stream + STT convert, sync + async)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Uninstrument TTS
        try:
            from elevenlabs import text_to_speech

            for cls_name in ("TextToSpeechClient", "AsyncTextToSpeechClient"):
                cls = getattr(text_to_speech, cls_name, None)
                if cls is None:
                    continue
                for attr in ("convert", "convert_as_stream"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Uninstrument STT
        try:
            from elevenlabs import speech_to_text

            for cls_name in ("SpeechToTextClient", "AsyncSpeechToTextClient"):
                cls = getattr(speech_to_text, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "convert", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "convert", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("ElevenLabs uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# TTS Wrapper functions
# ---------------------------------------------------------------------------


def _sync_tts_convert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ElevenLabs ``TextToSpeechClient.convert``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    voice_id, text, model_id, output_format = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="elevenlabs.tts")
        _set_tts_request_attrs(span, voice_id, text, model_id, output_format)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.elevenlabs.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "elevenlabs.tts.convert", voice_id, text, model_id, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_tts_stream_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ElevenLabs ``TextToSpeechClient.convert_as_stream``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    voice_id, text, model_id, output_format = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="elevenlabs.tts")
        _set_tts_request_attrs(span, voice_id, text, model_id, output_format)
        span.set_attribute("waxell.elevenlabs.streaming", True)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.elevenlabs.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "elevenlabs.tts.convert_as_stream", voice_id, text, model_id, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_tts_convert_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ElevenLabs ``AsyncTextToSpeechClient.convert``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    voice_id, text, model_id, output_format = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="elevenlabs.tts")
        _set_tts_request_attrs(span, voice_id, text, model_id, output_format)
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.elevenlabs.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "elevenlabs.tts.convert", voice_id, text, model_id, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_tts_stream_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ElevenLabs ``AsyncTextToSpeechClient.convert_as_stream``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    voice_id, text, model_id, output_format = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="elevenlabs.tts")
        _set_tts_request_attrs(span, voice_id, text, model_id, output_format)
        span.set_attribute("waxell.elevenlabs.streaming", True)
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.elevenlabs.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "elevenlabs.tts.convert_as_stream", voice_id, text, model_id, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# STT Wrapper functions
# ---------------------------------------------------------------------------


def _sync_stt_convert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ElevenLabs ``SpeechToTextClient.convert`` (Scribe)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_id = kwargs.get("model_id", "scribe_v1")
    language_code = kwargs.get("language_code", "")

    try:
        span = start_step_span(step_name="elevenlabs.stt")
        span.set_attribute("waxell.elevenlabs.model_id", str(model_id))
        if language_code:
            span.set_attribute("waxell.elevenlabs.language", str(language_code))
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            _set_stt_response_attrs(span, response, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set ElevenLabs STT span attributes: %s", attr_exc)

        try:
            _record_stt_call("elevenlabs.stt.convert", model_id, response, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_stt_convert_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ElevenLabs ``AsyncSpeechToTextClient.convert`` (Scribe)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model_id = kwargs.get("model_id", "scribe_v1")
    language_code = kwargs.get("language_code", "")

    try:
        span = start_step_span(step_name="elevenlabs.stt")
        span.set_attribute("waxell.elevenlabs.model_id", str(model_id))
        if language_code:
            span.set_attribute("waxell.elevenlabs.language", str(language_code))
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            _set_stt_response_attrs(span, response, latency)
        except Exception as attr_exc:
            logger.debug(
                "Failed to set ElevenLabs async STT span attributes: %s", attr_exc
            )

        try:
            _record_stt_call("elevenlabs.stt.convert", model_id, response, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Parameter extraction helpers
# ---------------------------------------------------------------------------


def _extract_tts_params(args, kwargs) -> tuple:
    """Extract voice_id, text, model_id, output_format from TTS call args."""
    # ElevenLabs TTS: convert(voice_id, *, text=..., model_id=..., output_format=...)
    voice_id = ""
    if args:
        voice_id = str(args[0]) if args[0] else ""
    voice_id = kwargs.get("voice_id", voice_id)

    text = kwargs.get("text", "")
    model_id = kwargs.get("model_id", "")
    output_format = kwargs.get("output_format", "")

    return voice_id, str(text), str(model_id), str(output_format)


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_tts_request_attrs(
    span, voice_id: str, text: str, model_id: str, output_format: str
) -> None:
    """Set request attributes for a TTS span."""
    if voice_id:
        span.set_attribute("waxell.elevenlabs.voice_id", voice_id)
    if text:
        span.set_attribute("waxell.elevenlabs.text_length", len(text))
    if model_id:
        span.set_attribute("waxell.elevenlabs.model_id", model_id)
    if output_format:
        span.set_attribute("waxell.elevenlabs.output_format", output_format)


def _set_stt_response_attrs(span, response, latency: float) -> None:
    """Set response attributes for an STT (Scribe) span."""
    span.set_attribute("waxell.elevenlabs.latency_ms", round(latency * 1000, 2))

    if response is None:
        return

    # Extract transcript text from Scribe response
    text = ""
    language = ""
    if isinstance(response, dict):
        text = response.get("text", "")
        language = response.get("language_code", "")
    else:
        text = getattr(response, "text", "")
        language = getattr(response, "language_code", "")

    if text:
        span.set_attribute("waxell.elevenlabs.transcript_preview", str(text)[:500])
        word_count = len(str(text).split())
        span.set_attribute("waxell.elevenlabs.word_count", word_count)
    if language:
        span.set_attribute("waxell.elevenlabs.language", str(language))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tts_call(
    task: str, voice_id: str, text: str, model_id: str, latency: float
) -> None:
    """Record an ElevenLabs TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model_id or "elevenlabs-tts",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": str(text)[:500] if text else f"[voice={voice_id}]",
        "response_preview": f"[tts voice={voice_id} latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_stt_call(task: str, model_id: str, response, latency: float) -> None:
    """Record an ElevenLabs STT call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    transcript = ""
    if response is not None:
        if isinstance(response, dict):
            transcript = response.get("text", "")
        else:
            transcript = getattr(response, "text", "")

    call_data = {
        "model": model_id or "scribe_v1",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": "[audio input]",
        "response_preview": str(transcript)[:500] if transcript else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
