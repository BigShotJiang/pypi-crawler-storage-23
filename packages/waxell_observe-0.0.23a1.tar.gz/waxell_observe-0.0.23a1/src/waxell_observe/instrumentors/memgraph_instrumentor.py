"""Memgraph auto-instrumentor for waxell-observe.

Monkey-patches GQLAlchemy Memgraph.execute and Memgraph.execute_and_fetch
methods to emit retrieval spans for in-memory graph database queries.

Patched methods:
  - ``gqlalchemy.Memgraph.execute``           (retrieval span for Cypher queries)
  - ``gqlalchemy.Memgraph.execute_and_fetch`` (retrieval span for Cypher queries with results)

All wrapper code is wrapped in try/except -- never breaks the user's Memgraph calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MemgraphInstrumentor(BaseInstrumentor):
    """Instrumentor for GQLAlchemy's Memgraph driver.

    Patches ``Memgraph.execute`` for fire-and-forget queries and
    ``Memgraph.execute_and_fetch`` for queries that return results.
    All queries get retrieval spans since Memgraph is typically used
    for graph-based retrieval in agent pipelines.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import gqlalchemy  # noqa: F401
        except ImportError:
            logger.debug("gqlalchemy package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Memgraph instrumentation")
            return False

        patched_any = False

        # --- Memgraph.execute ---
        try:
            wrapt.wrap_function_wrapper(
                "gqlalchemy",
                "Memgraph.execute",
                _sync_execute_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch gqlalchemy Memgraph.execute: %s", exc)

        # --- Memgraph.execute_and_fetch ---
        try:
            wrapt.wrap_function_wrapper(
                "gqlalchemy",
                "Memgraph.execute_and_fetch",
                _sync_execute_and_fetch_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch gqlalchemy Memgraph.execute_and_fetch: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any gqlalchemy Memgraph methods")
            return False

        self._instrumented = True
        logger.debug("Memgraph instrumented (Memgraph.execute, Memgraph.execute_and_fetch)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore Memgraph.execute
        try:
            import gqlalchemy

            memgraph_cls = getattr(gqlalchemy, "Memgraph", None)
            if memgraph_cls is not None:
                method = getattr(memgraph_cls, "execute", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    memgraph_cls.execute = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore Memgraph.execute_and_fetch
        try:
            import gqlalchemy

            memgraph_cls = getattr(gqlalchemy, "Memgraph", None)
            if memgraph_cls is not None:
                method = getattr(memgraph_cls, "execute_and_fetch", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    memgraph_cls.execute_and_fetch = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Memgraph uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the Cypher query string from positional or keyword args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _truncate_query(query: str, max_len: int = 200) -> str:
    """Truncate a Cypher query for span labelling."""
    if len(query) > max_len:
        return query[:max_len] + "..."
    return query


def _extract_result_count(response) -> int:
    """Extract result count from a Memgraph execute_and_fetch response.

    execute_and_fetch returns an iterator of dicts, so we attempt to
    measure the length if the response is a list.
    """
    try:
        if hasattr(response, "__len__"):
            return len(response)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_execute_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for gqlalchemy Memgraph.execute -- instruments Cypher queries."""
    query = _extract_query(args, kwargs)
    return _sync_query_path(wrapped, args, kwargs, query)


def _sync_execute_and_fetch_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for gqlalchemy Memgraph.execute_and_fetch -- instruments queries with results."""
    query = _extract_query(args, kwargs)
    return _sync_fetch_path(wrapped, args, kwargs, query)


def _sync_query_path(wrapped, args, kwargs, query):
    """Handle Memgraph execute queries with a retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)

    try:
        span = start_retrieval_span(query=query_preview, source="memgraph")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "memgraph")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.source", "memgraph")
        except Exception as attr_exc:
            logger.debug("Failed to set memgraph execute span attributes: %s", attr_exc)

        try:
            _record_memgraph_retrieval(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_fetch_path(wrapped, args, kwargs, query):
    """Handle Memgraph execute_and_fetch queries with a retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)

    try:
        span = start_retrieval_span(query=query_preview, source="memgraph")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "memgraph")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.source", "memgraph")
            result_count = _extract_result_count(response)
            if result_count:
                span.set_attribute("db.memgraph.result_count", result_count)
        except Exception as attr_exc:
            logger.debug("Failed to set memgraph fetch span attributes: %s", attr_exc)

        try:
            _record_memgraph_retrieval(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_memgraph_retrieval(
    query: str,
) -> None:
    """Record a Memgraph retrieval operation to the context path.

    Memgraph retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="memgraph",
        )
