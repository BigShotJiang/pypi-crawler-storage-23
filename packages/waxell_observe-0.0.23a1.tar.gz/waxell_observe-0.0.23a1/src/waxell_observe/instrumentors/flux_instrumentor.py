"""Flux image generation auto-instrumentor for waxell-observe.

Monkey-patches ``FluxPipeline.__call__`` from the HuggingFace ``diffusers``
library for Flux model generation (Black Forest Labs), and optionally patches
the ``bfl`` client library if available for direct BFL API access.

Flux models include flux-dev, flux-schnell, and flux-pro, all based on
the Black Forest Labs architecture. When used via diffusers, they use
``FluxPipeline``; when accessed through the BFL API, they use the ``bfl``
client library.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FluxInstrumentor(BaseInstrumentor):
    """Instrumentor for Flux image generation (Black Forest Labs).

    Patches ``FluxPipeline.__call__`` from diffusers and optionally
    the ``bfl`` client library for direct BFL API access. Captures
    model variant, prompt, inference steps, guidance scale, dimensions,
    and seed.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Flux instrumentation")
            return False

        patched = False

        # Patch FluxPipeline.__call__ from diffusers
        try:
            import diffusers  # noqa: F401

            wrapt.wrap_function_wrapper(
                "diffusers",
                "FluxPipeline.__call__",
                _flux_pipeline_wrapper,
            )
            patched = True
            logger.debug("Flux: patched diffusers.FluxPipeline.__call__")
        except ImportError:
            logger.debug("diffusers not installed -- skipping FluxPipeline patch")
        except Exception as exc:
            logger.debug("Failed to patch FluxPipeline.__call__: %s", exc)

        # Patch BFL client library if available
        try:
            import bfl  # noqa: F401

            # Patch common BFL client methods
            try:
                wrapt.wrap_function_wrapper(
                    "bfl",
                    "Client.generate",
                    _bfl_generate_wrapper,
                )
                patched = True
                logger.debug("Flux: patched bfl.Client.generate")
            except Exception as exc:
                logger.debug("Failed to patch bfl.Client.generate: %s", exc)

            try:
                wrapt.wrap_function_wrapper(
                    "bfl",
                    "AsyncClient.generate",
                    _bfl_async_generate_wrapper,
                )
                logger.debug("Flux: patched bfl.AsyncClient.generate")
            except Exception as exc:
                logger.debug("Failed to patch bfl.AsyncClient.generate: %s", exc)
        except ImportError:
            logger.debug("bfl package not installed -- skipping BFL client patch")

        if not patched:
            logger.debug("Could not find Flux methods to patch (need diffusers or bfl)")
            return False

        self._instrumented = True
        logger.debug("Flux instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore FluxPipeline.__call__
        try:
            from diffusers import FluxPipeline

            if hasattr(getattr(FluxPipeline, "__call__", None), "__wrapped__"):
                FluxPipeline.__call__ = FluxPipeline.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore BFL client methods
        try:
            from bfl import Client

            if hasattr(getattr(Client, "generate", None), "__wrapped__"):
                Client.generate = Client.generate.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from bfl import AsyncClient

            if hasattr(getattr(AsyncClient, "generate", None), "__wrapped__"):
                AsyncClient.generate = AsyncClient.generate.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Flux uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions -- diffusers FluxPipeline
# ---------------------------------------------------------------------------


def _flux_pipeline_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``FluxPipeline.__call__`` -- Flux generation via diffusers."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract generation parameters
    prompt = kwargs.get("prompt", "") or (args[0] if args else "")
    num_inference_steps = kwargs.get("num_inference_steps", None)
    guidance_scale = kwargs.get("guidance_scale", None)
    width = kwargs.get("width", None)
    height = kwargs.get("height", None)
    num_images = kwargs.get("num_images_per_prompt", 1) or 1
    seed = _extract_seed(kwargs)
    model_id = _extract_flux_model_id(instance)

    # Determine Flux variant from model ID
    flux_variant = _infer_flux_variant(model_id)

    try:
        span = start_step_span(step_name="flux.generate")
        span.set_attribute("waxell.agent.framework", "diffusers")
        span.set_attribute("waxell.flux.operation", "generate")
        span.set_attribute("waxell.flux.backend", "diffusers")

        if model_id:
            span.set_attribute("waxell.flux.model", str(model_id))
        if flux_variant:
            span.set_attribute("waxell.flux.variant", flux_variant)
        if prompt:
            prompt_str = str(prompt) if not isinstance(prompt, list) else str(prompt[0])
            span.set_attribute("waxell.flux.prompt_preview", prompt_str[:200])
        if num_inference_steps is not None:
            span.set_attribute("waxell.flux.num_inference_steps", int(num_inference_steps))
        if guidance_scale is not None:
            span.set_attribute("waxell.flux.guidance_scale", float(guidance_scale))
        if width is not None:
            span.set_attribute("waxell.flux.width", int(width))
        if height is not None:
            span.set_attribute("waxell.flux.height", int(height))
        span.set_attribute("waxell.flux.num_images", int(num_images))
        if seed is not None:
            span.set_attribute("waxell.flux.seed", int(seed))
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            generation_time = time.time() - start_time
            span.set_attribute("waxell.flux.generation_time_seconds", round(generation_time, 2))
            _set_flux_result_attributes(span, result, model_id, flux_variant)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Wrapper functions -- BFL API client
# ---------------------------------------------------------------------------


def _bfl_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``bfl.Client.generate`` -- BFL API generation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "") or ""
    prompt = kwargs.get("prompt", "") or (args[0] if args else "")
    width = kwargs.get("width", None)
    height = kwargs.get("height", None)
    steps = kwargs.get("steps", None)
    guidance_scale = kwargs.get("guidance", None) or kwargs.get("guidance_scale", None)
    seed = kwargs.get("seed", None)
    flux_variant = _infer_flux_variant(model)

    try:
        span = start_step_span(step_name="flux.generate")
        span.set_attribute("waxell.agent.framework", "bfl")
        span.set_attribute("waxell.flux.operation", "generate")
        span.set_attribute("waxell.flux.backend", "bfl_api")

        if model:
            span.set_attribute("waxell.flux.model", str(model))
        if flux_variant:
            span.set_attribute("waxell.flux.variant", flux_variant)
        if prompt:
            span.set_attribute("waxell.flux.prompt_preview", str(prompt)[:200])
        if steps is not None:
            span.set_attribute("waxell.flux.num_inference_steps", int(steps))
        if guidance_scale is not None:
            span.set_attribute("waxell.flux.guidance_scale", float(guidance_scale))
        if width is not None:
            span.set_attribute("waxell.flux.width", int(width))
        if height is not None:
            span.set_attribute("waxell.flux.height", int(height))
        if seed is not None:
            span.set_attribute("waxell.flux.seed", int(seed))
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            generation_time = time.time() - start_time
            span.set_attribute("waxell.flux.generation_time_seconds", round(generation_time, 2))
            _set_bfl_result_attributes(span, result, model, flux_variant)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _bfl_async_generate_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``bfl.AsyncClient.generate`` -- BFL API generation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "") or ""
    prompt = kwargs.get("prompt", "") or (args[0] if args else "")
    width = kwargs.get("width", None)
    height = kwargs.get("height", None)
    steps = kwargs.get("steps", None)
    guidance_scale = kwargs.get("guidance", None) or kwargs.get("guidance_scale", None)
    seed = kwargs.get("seed", None)
    flux_variant = _infer_flux_variant(model)

    try:
        span = start_step_span(step_name="flux.generate")
        span.set_attribute("waxell.agent.framework", "bfl")
        span.set_attribute("waxell.flux.operation", "generate")
        span.set_attribute("waxell.flux.backend", "bfl_api")

        if model:
            span.set_attribute("waxell.flux.model", str(model))
        if flux_variant:
            span.set_attribute("waxell.flux.variant", flux_variant)
        if prompt:
            span.set_attribute("waxell.flux.prompt_preview", str(prompt)[:200])
        if steps is not None:
            span.set_attribute("waxell.flux.num_inference_steps", int(steps))
        if guidance_scale is not None:
            span.set_attribute("waxell.flux.guidance_scale", float(guidance_scale))
        if width is not None:
            span.set_attribute("waxell.flux.width", int(width))
        if height is not None:
            span.set_attribute("waxell.flux.height", int(height))
        if seed is not None:
            span.set_attribute("waxell.flux.seed", int(seed))
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            generation_time = time.time() - start_time
            span.set_attribute("waxell.flux.generation_time_seconds", round(generation_time, 2))
            _set_bfl_result_attributes(span, result, model, flux_variant)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_flux_model_id(instance) -> str:
    """Extract the model ID from a FluxPipeline instance."""
    try:
        config = getattr(instance, "config", None)
        if config and isinstance(config, dict):
            model_id = config.get("_name_or_path", "")
            if model_id:
                return str(model_id)

        name_or_path = getattr(instance, "name_or_path", None)
        if name_or_path:
            return str(name_or_path)

        return type(instance).__name__
    except Exception:
        return "flux"


def _infer_flux_variant(model_id: str) -> str:
    """Infer the Flux model variant (dev/schnell/pro) from model ID."""
    if not model_id:
        return ""
    model_lower = str(model_id).lower()
    if "schnell" in model_lower:
        return "flux-schnell"
    if "pro" in model_lower:
        return "flux-pro"
    if "dev" in model_lower:
        return "flux-dev"
    if "flux" in model_lower:
        return "flux"
    return ""


def _extract_seed(kwargs) -> int | None:
    """Extract the random seed from generator kwargs."""
    try:
        generator = kwargs.get("generator", None)
        if generator is not None:
            seed = getattr(generator, "initial_seed", None)
            if callable(seed):
                return int(seed())
    except Exception:
        pass
    return None


def _set_flux_result_attributes(span, result, model_id: str, flux_variant: str) -> None:
    """Set result attributes for FluxPipeline generation."""
    num_images = 0
    try:
        images = getattr(result, "images", None)
        if images is not None:
            if isinstance(images, list):
                num_images = len(images)
            else:
                num_images = 1
            span.set_attribute("waxell.flux.output_images", num_images)
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:flux.generate",
                output={
                    "model": model_id,
                    "variant": flux_variant,
                    "num_images": num_images,
                    "backend": "diffusers",
                },
            )
    except Exception:
        pass


def _set_bfl_result_attributes(span, result, model: str, flux_variant: str) -> None:
    """Set result attributes for BFL API generation."""
    try:
        # BFL API may return image URLs or base64 data
        if isinstance(result, dict):
            image_url = result.get("url", "") or result.get("image_url", "")
            if image_url:
                span.set_attribute("waxell.flux.has_output_url", True)

            request_id = result.get("id", "") or result.get("request_id", "")
            if request_id:
                span.set_attribute("waxell.flux.request_id", str(request_id))

            status = result.get("status", "")
            if status:
                span.set_attribute("waxell.flux.status", str(status))

        elif hasattr(result, "url"):
            span.set_attribute("waxell.flux.has_output_url", True)
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:flux.generate",
                output={
                    "model": model,
                    "variant": flux_variant,
                    "backend": "bfl_api",
                },
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
