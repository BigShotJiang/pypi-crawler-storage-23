"""PolyGuard auto-instrumentor for waxell-observe.

Monkey-patches ``polyguard.Guard.validate`` (and ``Guard.__call__`` if
available) to emit guardrail evaluation spans tracking validation results.

PolyGuard is a guardrails framework for validating LLM inputs/outputs.
The instrumentor is deliberately defensive with try/except blocks to handle
varying API signatures across different PolyGuard versions.

Key attributes captured:
  - guard name
  - passed/failed status
  - violation count and types (no PII or content stored in spans)

Cost is always 0.0 (local evaluation).

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PolyGuardInstrumentor(BaseInstrumentor):
    """Instrumentor for PolyGuard (``polyguard`` package).

    Patches ``Guard.validate`` and ``Guard.__call__`` to emit guardrail spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import polyguard  # noqa: F401
        except ImportError:
            logger.debug("polyguard not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping PolyGuard instrumentation")
            return False

        patched = False

        # Patch Guard.validate (primary validation entry point)
        try:
            wrapt.wrap_function_wrapper(
                "polyguard",
                "Guard.validate",
                _guard_validate_wrapper,
            )
            patched = True
            logger.debug("PolyGuard Guard.validate patched")
        except Exception as exc:
            logger.debug("Failed to patch PolyGuard Guard.validate: %s", exc)

        # Patch Guard.__call__ (alternative invocation)
        try:
            wrapt.wrap_function_wrapper(
                "polyguard",
                "Guard.__call__",
                _guard_call_wrapper,
            )
            logger.debug("PolyGuard Guard.__call__ patched")
        except Exception as exc:
            logger.debug("Failed to patch PolyGuard Guard.__call__: %s", exc)

        if not patched:
            logger.debug("Could not find PolyGuard Guard methods to patch")
            return False

        self._instrumented = True
        logger.debug("PolyGuard instrumented (Guard.validate + Guard.__call__)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from polyguard import Guard

            for attr in ("validate", "__call__"):
                method = getattr(Guard, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(Guard, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("PolyGuard uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_guard_name(instance) -> str:
    """Extract the guard name from a PolyGuard Guard instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass

    try:
        return type(instance).__name__
    except Exception:
        return "polyguard"


def _extract_passed(result) -> bool:
    """Extract the pass/fail status from a PolyGuard validation result.

    Tries multiple attribute names to handle different PolyGuard versions.
    """
    # Try .passed (primary)
    passed = getattr(result, "passed", None)
    if passed is not None:
        return bool(passed)

    # Try .is_valid
    is_valid = getattr(result, "is_valid", None)
    if is_valid is not None:
        return bool(is_valid)

    # Try .success
    success = getattr(result, "success", None)
    if success is not None:
        return bool(success)

    # Try dict-based result
    if isinstance(result, dict):
        return bool(result.get("passed", result.get("is_valid", result.get("success", True))))

    return True


def _extract_violations(result) -> list:
    """Extract violations list from a PolyGuard validation result.

    Returns list of violations (objects or dicts).
    """
    violations = getattr(result, "violations", None)
    if violations is not None and isinstance(violations, list):
        return violations

    # Try .errors as alternative attribute name
    errors = getattr(result, "errors", None)
    if errors is not None and isinstance(errors, list):
        return errors

    # Try dict-based result
    if isinstance(result, dict):
        v = result.get("violations", result.get("errors", []))
        if isinstance(v, list):
            return v

    return []


def _extract_violation_types(violations) -> list[str]:
    """Extract unique violation type names from violations list.

    Does NOT extract PII or content -- only type/category labels.
    """
    types = set()
    for v in violations:
        # Try .type, .category, .rule, .name attributes
        for attr in ("type", "category", "rule", "name"):
            val = getattr(v, attr, None)
            if val is not None:
                types.add(str(val))
                break
        else:
            # Try dict-based violation
            if isinstance(v, dict):
                for key in ("type", "category", "rule", "name"):
                    val = v.get(key)
                    if val is not None:
                        types.add(str(val))
                        break
    return sorted(types)


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _guard_validate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Guard.validate`` -- main validation entry point."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    guard_name = _get_guard_name(instance)

    try:
        span = start_guardrail_span(
            guardrail_name=guard_name,
            framework="polyguard",
        )
        span.set_attribute("waxell.guardrail.method", "validate")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_guard_result(span, instance, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _guard_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Guard.__call__`` -- alternative invocation."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    guard_name = _get_guard_name(instance)

    try:
        span = start_guardrail_span(
            guardrail_name=guard_name,
            framework="polyguard",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_guard_result(span, instance, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Result recording
# ---------------------------------------------------------------------------


def _record_guard_result(span, instance, result) -> None:
    """Extract PolyGuard results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    passed = _extract_passed(result)
    span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, passed)

    action = "pass" if passed else "fail"
    span.set_attribute(WaxellAttributes.GUARDRAIL_ACTION, action)

    violations = _extract_violations(result)
    violation_count = len(violations)
    span.set_attribute("waxell.guardrail.violation_count", violation_count)

    if violations:
        violation_types = _extract_violation_types(violations)
        if violation_types:
            span.set_attribute("waxell.guardrail.violation_types", ", ".join(violation_types))

    # Record to HTTP path
    try:
        _record_http_polyguard(instance, result, passed, action, violation_count)
    except Exception:
        pass


def _record_http_polyguard(
    instance, result, passed: bool, action: str, violation_count: int
) -> None:
    """Record a PolyGuard evaluation to the HTTP path."""
    from ._context_var import _current_context

    guard_name = _get_guard_name(instance)

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"guardrail:{guard_name}",
            output={
                "passed": passed,
                "action": action,
                "violation_count": violation_count,
            },
        )


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
