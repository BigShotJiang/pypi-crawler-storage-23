"""BGE (BAAI General Embedding) auto-instrumentor for waxell-observe.

Monkey-patches ``FlagModel.encode``, ``BGEM3FlagModel.encode``, and
``FlagReranker.compute_score`` to emit spans tracking local embedding
and reranking operations.

The ``FlagEmbedding`` package provides models like bge-large-en-v1.5,
bge-m3, and bge-reranker-v2-m3. All operations run locally, so cost
is always 0.0.

For FlagModel and BGEM3FlagModel, embedding spans are emitted.
For FlagReranker, step spans are emitted (reranking operation).

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class BGEInstrumentor(BaseInstrumentor):
    """Instrumentor for the FlagEmbedding library (``FlagEmbedding`` package).

    Patches ``FlagModel.encode``, ``BGEM3FlagModel.encode``, and
    ``FlagReranker.compute_score`` to emit spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import FlagEmbedding  # noqa: F401
        except ImportError:
            logger.debug("FlagEmbedding package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping BGE instrumentation")
            return False

        patched = False

        # FlagModel.encode (dense embeddings)
        try:
            wrapt.wrap_function_wrapper(
                "FlagEmbedding",
                "FlagModel.encode",
                _sync_flagmodel_encode_wrapper,
            )
            patched = True
            logger.debug("BGE FlagModel.encode patched")
        except Exception:
            pass

        # BGEM3FlagModel.encode (multi-vector: dense/sparse/colbert)
        try:
            wrapt.wrap_function_wrapper(
                "FlagEmbedding",
                "BGEM3FlagModel.encode",
                _sync_bgem3_encode_wrapper,
            )
            patched = True
            logger.debug("BGE BGEM3FlagModel.encode patched")
        except Exception:
            pass

        # FlagReranker.compute_score (reranking)
        try:
            wrapt.wrap_function_wrapper(
                "FlagEmbedding",
                "FlagReranker.compute_score",
                _sync_reranker_wrapper,
            )
            logger.debug("BGE FlagReranker.compute_score patched")
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find BGE FlagModel or BGEM3FlagModel to patch")
            return False

        self._instrumented = True
        logger.debug("BGE instrumented (FlagModel + BGEM3FlagModel + FlagReranker)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import FlagEmbedding

            for cls_name, method_name in [
                ("FlagModel", "encode"),
                ("BGEM3FlagModel", "encode"),
                ("FlagReranker", "compute_score"),
            ]:
                cls = getattr(FlagEmbedding, cls_name, None)
                if cls is not None:
                    method = getattr(cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("BGE uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a FlagModel/BGEM3FlagModel/FlagReranker instance."""
    for attr in ("model_name", "_model_name", "model_name_or_path", "model"):
        try:
            name = getattr(instance, attr, None)
            if name:
                return str(name)
        except Exception:
            pass
    return "bge"


def _get_dimensions_from_result(result) -> int:
    """Extract embedding dimensions from encode() result.

    FlagModel.encode returns numpy arrays (shape: (n, dim)).
    """
    try:
        if hasattr(result, "shape"):
            if len(result.shape) == 2:
                return int(result.shape[1])
            if len(result.shape) == 1:
                return int(result.shape[0])
        if isinstance(result, list):
            if len(result) > 0:
                first = result[0]
                if isinstance(first, list):
                    return len(first)
                if hasattr(first, "shape"):
                    return int(first.shape[-1]) if len(first.shape) > 0 else 0
    except Exception:
        pass
    return 0


def _get_input_count(args, kwargs) -> int:
    """Extract input count from encode() arguments.

    Signature: model.encode(sentences)
    """
    sentences = kwargs.get("sentences", args[0] if args else None)
    if sentences is None:
        return 0
    if isinstance(sentences, str):
        return 1
    if isinstance(sentences, list):
        return len(sentences)
    return 1


def _get_m3_embedding_type(result) -> str:
    """Detect the embedding type from BGEM3FlagModel.encode result.

    Returns dict with keys like 'dense_vecs', 'lexical_weights', 'colbert_vecs'.
    """
    if not isinstance(result, dict):
        return "dense"

    types = []
    if "dense_vecs" in result:
        types.append("dense")
    if "lexical_weights" in result:
        types.append("sparse")
    if "colbert_vecs" in result:
        types.append("colbert")

    return "+".join(types) if types else "dense"


def _get_m3_dimensions(result) -> int:
    """Extract embedding dimensions from BGEM3FlagModel.encode result dict."""
    if not isinstance(result, dict):
        return _get_dimensions_from_result(result)

    dense = result.get("dense_vecs", None)
    if dense is not None:
        return _get_dimensions_from_result(dense)

    return 0


def _get_reranker_pairs_count(args, kwargs) -> int:
    """Extract the number of query-passage pairs for reranking.

    Signature: reranker.compute_score(sentence_pairs)
    """
    pairs = kwargs.get("sentence_pairs", args[0] if args else None)
    if pairs is None:
        return 0
    if isinstance(pairs, list):
        # Could be a single pair ["query", "passage"] or list of pairs
        if len(pairs) > 0 and isinstance(pairs[0], str):
            return 1  # Single pair
        return len(pairs)
    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_flagmodel_encode_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``FlagModel.encode``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)
    input_count = _get_input_count(args, kwargs)

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="bge",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = _get_dimensions_from_result(result)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model_name)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)  # Local, free
        except Exception as attr_exc:
            logger.debug("Failed to set BGE FlagModel span attributes: %s", attr_exc)

        try:
            _record_http_bge_embed(model_name, input_count, dimensions)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_bgem3_encode_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``BGEM3FlagModel.encode``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)
    input_count = _get_input_count(args, kwargs)

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="bge",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            embedding_type = _get_m3_embedding_type(result)
            dimensions = _get_m3_dimensions(result)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model_name)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)  # Local, free
            span.set_attribute("waxell.embedding.type", embedding_type)
        except Exception as attr_exc:
            logger.debug("Failed to set BGE M3 span attributes: %s", attr_exc)

        try:
            _record_http_bge_embed(
                model_name, input_count, dimensions, embedding_type=embedding_type
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_reranker_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``FlagReranker.compute_score``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)
    num_pairs = _get_reranker_pairs_count(args, kwargs)

    try:
        span = start_step_span(step_name="bge.rerank")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # result can be a float (single pair) or list of floats (multiple pairs)
            if isinstance(result, (int, float)):
                scores = [float(result)]
            elif isinstance(result, list):
                scores = [float(s) for s in result]
            else:
                scores = []

            top_score = max(scores) if scores else None

            span.set_attribute("waxell.rerank.model", model_name)
            span.set_attribute("waxell.rerank.num_pairs", num_pairs)
            span.set_attribute("waxell.rerank.results_count", len(scores))
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set BGE rerank span attributes: %s", attr_exc)

        try:
            _record_http_bge_rerank(model_name, num_pairs, scores, top_score)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_bge_embed(
    model: str,
    input_count: int,
    dimensions: int = 0,
    embedding_type: str = "dense",
) -> None:
    """Record a BGE embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "embedding:bge",
        "prompt_preview": f"embed {input_count} text(s), dim={dimensions}, type={embedding_type}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_bge_rerank(
    model: str,
    num_pairs: int = 0,
    scores: list | None = None,
    top_score: float | None = None,
) -> None:
    """Record a BGE rerank call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    score_str = f", top_score={top_score:.3f}" if top_score is not None else ""
    results_count = len(scores) if scores else 0
    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "rerank:bge",
        "prompt_preview": f"rerank {num_pairs} pair(s)",
        "response_preview": f"{results_count} score(s){score_str}",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
