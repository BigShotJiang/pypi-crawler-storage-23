"""Cassandra/DataStax Astra vector search auto-instrumentor for waxell-observe.

Monkey-patches the cassandra-driver Python client to detect vector search
queries and emit OTel retrieval spans.

Only queries containing vector search patterns are instrumented:
  - ``ORDER BY`` with ``ANN OF`` (approximate nearest neighbor)
  - ``similarity_cosine``, ``similarity_dot_product``, ``similarity_euclidean``

Non-vector queries pass through without any span creation.

Patched methods:
  - ``cassandra.cluster.Session.execute``  (retrieval span for vector queries)

All wrapper code is wrapped in try/except -- never breaks the user's Cassandra calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Vector search patterns to detect in CQL queries
_VECTOR_PATTERNS = (
    "ann of",
    "similarity_cosine",
    "similarity_dot_product",
    "similarity_euclidean",
)


class CassandraVectorInstrumentor(BaseInstrumentor):
    """Instrumentor for Cassandra/DataStax Astra vector search (``cassandra-driver``).

    Patches ``cassandra.cluster.Session.execute`` to emit retrieval spans
    when vector search queries are detected.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import cassandra  # noqa: F401
        except ImportError:
            logger.debug("cassandra-driver package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Cassandra instrumentation")
            return False

        patched_any = False

        # --- Session.execute ---
        try:
            wrapt.wrap_function_wrapper(
                "cassandra.cluster",
                "Session.execute",
                _sync_execute_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch cassandra.cluster.Session.execute")

        if not patched_any:
            logger.debug("Could not patch any Cassandra methods")
            return False

        self._instrumented = True
        logger.debug("Cassandra vector instrumented (Session.execute)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from cassandra import cluster as cassandra_cluster

            cls = getattr(cassandra_cluster, "Session", None)
            if cls is not None:
                method = getattr(cls, "execute", None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(cls, "execute", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Cassandra vector uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_vector_query(query) -> bool:
    """Detect whether a CQL query contains vector search operations.

    Accepts string queries or SimpleStatement/PreparedStatement objects.
    """
    query_str = _extract_query_string(query)
    if not query_str:
        return False

    query_lower = query_str.lower()
    return any(pattern in query_lower for pattern in _VECTOR_PATTERNS)


def _extract_query_string(query) -> str:
    """Extract the CQL query string from various argument types.

    Cassandra execute() accepts:
      - Plain string queries
      - SimpleStatement objects (have .query_string)
      - PreparedStatement objects (have .query_string)
      - BoundStatement objects (have .prepared_statement.query_string)
    """
    if isinstance(query, str):
        return query

    # SimpleStatement / PreparedStatement
    query_string = getattr(query, "query_string", None)
    if query_string and isinstance(query_string, str):
        return query_string

    # BoundStatement -> prepared_statement.query_string
    prepared = getattr(query, "prepared_statement", None)
    if prepared is not None:
        query_string = getattr(prepared, "query_string", None)
        if query_string and isinstance(query_string, str):
            return query_string

    return ""


def _truncate_query(query_str: str, max_len: int = 500) -> str:
    """Truncate a CQL query string for span attributes."""
    if not query_str:
        return ""
    return query_str[:max_len]


def _extract_keyspace(instance) -> str:
    """Extract keyspace from a Cassandra Session instance."""
    try:
        keyspace = getattr(instance, "keyspace", None)
        if keyspace:
            return str(keyspace)
    except Exception:
        pass
    return ""


def _extract_result_count(result) -> int:
    """Extract result count from a Cassandra ResultSet.

    Cassandra ResultSet supports iteration and len() in some cases.
    We use current_rows when available to avoid consuming the result.
    """
    try:
        # ResultSet.current_rows is a list of the current page
        current_rows = getattr(result, "current_rows", None)
        if current_rows is not None and isinstance(current_rows, list):
            return len(current_rows)
    except Exception:
        pass

    try:
        # Some result types support len()
        if hasattr(result, "__len__"):
            return len(result)
    except Exception:
        pass

    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper functions
# ---------------------------------------------------------------------------


def _sync_execute_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Cassandra ``Session.execute``.

    Only creates spans for vector search queries; non-vector queries
    pass through without instrumentation.
    """
    # Extract query from first positional arg or keyword
    query = args[0] if args else kwargs.get("query", "")

    # Skip non-vector queries entirely
    if not _is_vector_query(query):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_str = _extract_query_string(query)
    query_truncated = _truncate_query(query_str)
    keyspace = _extract_keyspace(instance)

    query_preview = f"cassandra.execute({query_truncated!r}"
    if keyspace:
        query_preview += f", keyspace={keyspace!r}"
    query_preview += ")"

    try:
        span = start_retrieval_span(query=query_preview, source="cassandra")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(result)

            span.set_attribute("waxell.retrieval.source", "cassandra")
            span.set_attribute("waxell.retrieval.operation", "vector_search")
            span.set_attribute("waxell.retrieval.matches_count", result_count)
            span.set_attribute("db.system", "cassandra")
            span.set_attribute("db.statement", query_truncated)
            if keyspace:
                span.set_attribute("db.cassandra.keyspace", keyspace)
        except Exception as attr_exc:
            logger.debug("Failed to set Cassandra execute span attributes: %s", attr_exc)

        try:
            _record_cassandra_retrieval(
                query=query_preview,
                keyspace=keyspace,
                result_count=result_count if "result_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_cassandra_retrieval(
    query: str,
    keyspace: str,
    result_count: int,
) -> None:
    """Record a Cassandra vector retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"row_{i}"} for i in range(result_count)]
        ctx.record_retrieval(
            query=query,
            source="cassandra",
            documents=documents,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass
