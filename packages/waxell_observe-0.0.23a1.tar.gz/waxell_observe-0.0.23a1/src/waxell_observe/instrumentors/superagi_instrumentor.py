"""SuperAGI auto-instrumentor for waxell-observe.

Monkey-patches SuperAGI agent execution and tool execution methods to emit
OTel spans and record to the Waxell HTTP API.

SuperAGI is an autonomous agent framework that supports multi-agent
orchestration with tool execution capabilities. The framework uses
Agent classes that execute tasks autonomously and invoke tools during
their execution lifecycle.

Patched methods:
  - ``superagi.agent.super_agi.SuperAgi.execute``  — main agent execution loop
  - ``superagi.agent.agent_tool_step.AgentToolStepHandler.execute``  — tool execution
  - ``superagi.agent.super_agi.SuperAgi.execute_next_step``  — individual step execution

All wrapper code is wrapped in try/except -- never breaks the user's agent runs.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class SuperAGIInstrumentor(BaseInstrumentor):
    """Instrumentor for the SuperAGI framework (``superagi`` package).

    Patches agent execution methods and tool execution handlers to capture
    agent runs, task descriptions, tool calls, and results.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import superagi  # noqa: F401
        except ImportError:
            logger.debug("superagi not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping SuperAGI instrumentation")
            return False

        patched = False

        # Patch SuperAgi.execute (main agent execution loop)
        try:
            wrapt.wrap_function_wrapper(
                "superagi.agent.super_agi",
                "SuperAgi.execute",
                _agent_execute_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch SuperAgi.execute: %s", exc)

        # Patch AgentToolStepHandler.execute (tool execution)
        try:
            wrapt.wrap_function_wrapper(
                "superagi.agent.agent_tool_step",
                "AgentToolStepHandler.execute",
                _tool_step_execute_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch AgentToolStepHandler.execute: %s", exc)

        # Patch SuperAgi.execute_next_step (individual step execution)
        try:
            wrapt.wrap_function_wrapper(
                "superagi.agent.super_agi",
                "SuperAgi.execute_next_step",
                _execute_next_step_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch SuperAgi.execute_next_step: %s", exc)

        if not patched:
            logger.debug("Could not find SuperAGI methods to patch")
            return False

        self._instrumented = True
        logger.debug("SuperAGI instrumented (agent execute + tool step + next step)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from superagi.agent.super_agi import SuperAgi

            for attr in ("execute", "execute_next_step"):
                method = getattr(SuperAgi, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(SuperAgi, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        try:
            from superagi.agent.agent_tool_step import AgentToolStepHandler

            method = getattr(AgentToolStepHandler, "execute", None)
            if method is not None and hasattr(method, "__wrapped__"):
                AgentToolStepHandler.execute = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("SuperAGI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from SuperAGI instances
# ---------------------------------------------------------------------------


def _extract_agent_name(instance) -> str:
    """Extract agent name from a SuperAGI agent instance."""
    try:
        name = getattr(instance, "agent_name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        agent_config = getattr(instance, "agent_config", None)
        if agent_config and isinstance(agent_config, dict):
            name = agent_config.get("name", "")
            if name:
                return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "superagi.agent"


def _extract_task_description(instance) -> str:
    """Extract task description from a SuperAGI agent instance."""
    try:
        goals = getattr(instance, "agent_goals", None)
        if goals and isinstance(goals, list):
            return str(goals[0])[:500]
    except Exception:
        pass
    try:
        description = getattr(instance, "description", None)
        if description:
            return str(description)[:500]
    except Exception:
        pass
    try:
        task = getattr(instance, "current_task", None)
        if task:
            return str(task)[:500]
    except Exception:
        pass
    return ""


def _extract_tool_name(instance) -> str:
    """Extract tool name from a SuperAGI tool step handler."""
    try:
        tool_name = getattr(instance, "tool_name", None)
        if tool_name:
            return str(tool_name)
    except Exception:
        pass
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "superagi.tool"


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _agent_execute_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``SuperAgi.execute`` -- main agent execution loop."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = _extract_agent_name(instance)
    task_description = _extract_task_description(instance)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="superagi_agent_execute",
        )
        span.set_attribute("waxell.agent.framework", "superagi")
        span.set_attribute("waxell.agent.name", agent_name)
        if task_description:
            span.set_attribute("waxell.superagi.task_description", task_description)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_agent_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _tool_step_execute_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``AgentToolStepHandler.execute`` -- tool execution."""
    try:
        from ..tracing.spans import start_tool_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    tool_name = _extract_tool_name(instance)

    try:
        span = start_tool_span(tool_name=tool_name)
        span.set_attribute("waxell.agent.framework", "superagi")
        span.set_attribute("waxell.superagi.tool_name", tool_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_tool_result_attributes(span, result, tool_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _execute_next_step_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``SuperAgi.execute_next_step`` -- individual step execution."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = _extract_agent_name(instance)

    try:
        span = start_step_span(step_name=f"{agent_name}:next_step")
        span.set_attribute("waxell.agent.framework", "superagi")
        span.set_attribute("waxell.agent.name", agent_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            if result is not None:
                span.set_attribute("waxell.superagi.step_result_preview", str(result)[:200])
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _set_agent_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span for agent execution."""
    try:
        if result is not None:
            span.set_attribute("waxell.superagi.result_preview", str(result)[:200])
            span.set_attribute("waxell.superagi.status", "success")
        else:
            span.set_attribute("waxell.superagi.status", "completed")
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"superagi:agent:{agent_name}",
                output={"agent_name": agent_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_tool_result_attributes(span, result, tool_name: str) -> None:
    """Set result attributes on the span for tool execution."""
    try:
        if result is not None:
            span.set_attribute("waxell.superagi.tool_result_preview", str(result)[:200])
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"superagi:tool:{tool_name}",
                output={"tool_name": tool_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
