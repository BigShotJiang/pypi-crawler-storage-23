"""DashScope (Alibaba Cloud) auto-instrumentor for waxell-observe.

Monkey-patches ``dashscope.Generation.call`` (sync text generation) and
``dashscope.TextEmbedding.call`` (sync embedding generation) to emit OTel
spans and record to the Waxell HTTP API.

DashScope Generation.call() response format:
  - ``response.output.text`` (simple mode)
  - ``response.output.choices[0].message.content`` (message mode)
  - ``response.usage.input_tokens`` / ``output_tokens``
  - ``response.model`` (echoed model name)

DashScope TextEmbedding.call() response format:
  - ``response.output.embeddings`` — list of embedding dicts
  - ``response.usage.total_tokens``

Models: qwen-turbo, qwen-plus, qwen-max, qwen-vl-plus, etc.

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Cost estimates for DashScope / Qwen models (USD per token)
# ---------------------------------------------------------------------------

_DASHSCOPE_COSTS: dict[str, dict[str, float]] = {
    "qwen-turbo": {
        "input": 0.30 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "qwen-plus": {
        "input": 0.80 / 1_000_000,
        "output": 2.00 / 1_000_000,
    },
    "qwen-max": {
        "input": 2.40 / 1_000_000,
        "output": 9.60 / 1_000_000,
    },
    "qwen-max-longcontext": {
        "input": 2.40 / 1_000_000,
        "output": 9.60 / 1_000_000,
    },
    "qwen-vl-plus": {
        "input": 0.80 / 1_000_000,
        "output": 2.00 / 1_000_000,
    },
}

_DEFAULT_COST = {"input": 0.50 / 1_000_000, "output": 1.50 / 1_000_000}


def _estimate_dashscope_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """Estimate cost for a DashScope model call."""
    model_lower = model.lower()
    costs = _DEFAULT_COST
    for prefix, cost_info in _DASHSCOPE_COSTS.items():
        if model_lower.startswith(prefix):
            costs = cost_info
            break
    return (tokens_in * costs["input"]) + (tokens_out * costs["output"])


class DashScopeInstrumentor(BaseInstrumentor):
    """Instrumentor for the Alibaba Cloud DashScope SDK (``dashscope`` package).

    Patches ``dashscope.Generation.call`` for text generation and
    ``dashscope.TextEmbedding.call`` for embeddings.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import dashscope  # noqa: F401
        except ImportError:
            logger.debug("dashscope package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping DashScope instrumentation")
            return False

        patched = False

        # Patch Generation.call (class method for text generation)
        try:
            wrapt.wrap_function_wrapper(
                "dashscope",
                "Generation.call",
                _sync_generation_wrapper,
            )
            patched = True
            logger.debug("DashScope Generation.call instrumented")
        except Exception as exc:
            logger.debug("Could not patch dashscope.Generation.call: %s", exc)

        # Patch TextEmbedding.call (class method for embeddings)
        try:
            wrapt.wrap_function_wrapper(
                "dashscope",
                "TextEmbedding.call",
                _sync_embedding_wrapper,
            )
            logger.debug("DashScope TextEmbedding.call instrumented")
        except Exception as exc:
            logger.debug("Could not patch dashscope.TextEmbedding.call: %s", exc)

        if not patched:
            logger.debug("Could not find DashScope Generation methods to patch")
            return False

        self._instrumented = True
        logger.debug("DashScope Generation/TextEmbedding instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import dashscope

            if hasattr(dashscope.Generation.call, "__wrapped__"):
                dashscope.Generation.call = dashscope.Generation.call.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        try:
            import dashscope

            if hasattr(dashscope.TextEmbedding.call, "__wrapped__"):
                dashscope.TextEmbedding.call = dashscope.TextEmbedding.call.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("DashScope Generation/TextEmbedding uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _extract_generation_text(response) -> str:
    """Extract generated text from DashScope Generation response.

    Handles both simple mode (output.text) and message mode
    (output.choices[0].message.content).
    """
    try:
        output = getattr(response, "output", None)
        if output is None:
            return ""

        # Simple mode: output.text
        text = getattr(output, "text", None)
        if text:
            return str(text)

        # Message mode: output.choices[0].message.content
        choices = getattr(output, "choices", None)
        if choices and len(choices) > 0:
            first = choices[0]
            if isinstance(first, dict):
                msg = first.get("message", {})
                content = msg.get("content", "")
                return str(content)
            else:
                msg = getattr(first, "message", None)
                if msg:
                    return str(getattr(msg, "content", ""))

        return ""
    except Exception:
        return ""


def _extract_generation_usage(response):
    """Extract token counts from DashScope Generation response.

    Returns (input_tokens, output_tokens).
    """
    tokens_in, tokens_out = 0, 0
    try:
        usage = getattr(response, "usage", None)
        if usage is None:
            return tokens_in, tokens_out

        tokens_in = getattr(usage, "input_tokens", 0) or 0
        tokens_out = getattr(usage, "output_tokens", 0) or 0
    except Exception:
        pass
    return tokens_in, tokens_out


def _extract_embedding_usage(response) -> int:
    """Extract total tokens from DashScope TextEmbedding response."""
    try:
        usage = getattr(response, "usage", None)
        if usage is None:
            return 0
        return getattr(usage, "total_tokens", 0) or 0
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# Wrapper functions (module-level for wrapt compatibility)
# ---------------------------------------------------------------------------


def _sync_generation_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for DashScope ``Generation.call``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    try:
        span = start_llm_span(model=model, provider_name="dashscope")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_generation_usage(response)
            response_model = getattr(response, "model", model) or model
            cost = _estimate_dashscope_cost(response_model, tokens_in, tokens_out)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API
        try:
            _record_http_generation(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_embedding_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for DashScope ``TextEmbedding.call``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    # Count inputs
    input_data = kwargs.get("input", "")
    if isinstance(input_data, str):
        input_count = 1
    elif isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model, provider_name="dashscope", input_count=input_count
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens = _extract_embedding_usage(response)
            dimensions = 0
            output = getattr(response, "output", None)
            if output:
                embeddings = getattr(output, "embeddings", None)
                if embeddings and isinstance(embeddings, list) and len(embeddings) > 0:
                    first = embeddings[0]
                    emb = first.get("embedding", []) if isinstance(first, dict) else getattr(first, "embedding", [])
                    dimensions = len(emb) if emb else 0

            cost = tokens * (_DEFAULT_COST["input"])

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API
        try:
            _record_http_embedding(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_generation(response, request_model: str, kwargs: dict) -> None:
    """Record a DashScope Generation call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens_in, tokens_out = _extract_generation_usage(response)
    response_model = getattr(response, "model", request_model) or request_model
    cost = _estimate_dashscope_cost(response_model, tokens_in, tokens_out)

    # Extract prompt preview
    prompt_preview = ""
    prompt = kwargs.get("prompt", None)
    messages = kwargs.get("messages", None)
    if prompt:
        prompt_preview = str(prompt)[:500]
    elif messages and isinstance(messages, list) and len(messages) > 0:
        first = messages[0]
        if isinstance(first, dict):
            prompt_preview = str(first.get("content", ""))[:500]
        else:
            prompt_preview = str(getattr(first, "content", str(first)))[:500]

    response_preview = _extract_generation_text(response)[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "generation",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_embedding(response, model: str, kwargs: dict) -> None:
    """Record a DashScope TextEmbedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens = _extract_embedding_usage(response)
    cost = tokens * (_DEFAULT_COST["input"])

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embedding",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
