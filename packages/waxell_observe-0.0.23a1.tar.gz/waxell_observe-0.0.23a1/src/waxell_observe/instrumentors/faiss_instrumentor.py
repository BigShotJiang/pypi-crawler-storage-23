"""FAISS auto-instrumentor for waxell-observe.

Monkey-patches FAISS's Index methods to emit OTel spans and record
to the Waxell HTTP API.

Patched methods:
  - faiss.Index.search  (retrieval span -- base class covers all index types)
  - faiss.Index.add     (step span -- tracking index build operations)

All wrapper code is wrapped in try/except -- never breaks the user's FAISS calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FAISSInstrumentor(BaseInstrumentor):
    """Instrumentor for the FAISS library (``faiss-cpu`` / ``faiss-gpu``).

    Patches ``faiss.Index.search`` for retrieval spans and
    ``faiss.Index.add`` for step spans.  The base-class patch covers
    all index subclasses (IndexFlatL2, IndexFlatIP, IndexIVFFlat, etc.).
    """

    _instrumented: bool = False
    _originals: dict = {}  # (cls, method_name) -> original_method

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import faiss  # noqa: F401
        except ImportError:
            logger.debug("faiss package not installed -- skipping instrumentation")
            return False

        patched = False
        self._originals = {}

        # SWIG generates separate method descriptors for each class in the
        # hierarchy.  Patching faiss.Index.search has NO effect on subclasses
        # like IndexFlatL2, IndexIVFFlat, etc. — they dispatch directly to
        # their own C-level search.  We must patch every concrete class that
        # defines its own 'search' or 'add' method.
        for name in dir(faiss):
            try:
                cls = getattr(faiss, name)
            except Exception:
                continue
            if not isinstance(cls, type) or not issubclass(cls, faiss.Index):
                continue

            for method_name, wrapper_fn in (
                ("search", _search_wrapper),
                ("add", _add_wrapper),
            ):
                if method_name not in cls.__dict__:
                    continue  # Inherited — will be caught on the parent class
                try:
                    original = cls.__dict__[method_name]
                    self._originals[(cls, method_name)] = original

                    def make_patched(orig, wrapper):
                        def patched(self_inner, *args, **kwargs):
                            return wrapper(
                                lambda *a, **kw: orig(self_inner, *a, **kw),
                                self_inner,
                                args,
                                kwargs,
                            )

                        return patched

                    setattr(cls, method_name, make_patched(original, wrapper_fn))
                    patched = True
                except Exception as exc:
                    logger.debug("Could not patch %s.%s: %s", name, method_name, exc)

        if not patched:
            logger.debug("Could not find any FAISS Index methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "FAISS Index instrumented (search, add on %d classes)", len(self._originals)
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        for (cls, method_name), original in self._originals.items():
            try:
                setattr(cls, method_name, original)
            except Exception:
                pass

        self._originals = {}
        self._instrumented = False
        logger.debug("FAISS Index uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.search`` (nearest-neighbor retrieval).

    Args layout: index.search(query_vectors, k)
        query_vectors: numpy array of shape (nq, d)
        k: int, number of nearest neighbors
    Returns: (distances, indices) tuple of numpy arrays, each shape (nq, k)
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract search parameters safely
    nq = 0
    k = 0
    dimension = 0
    ntotal = 0
    index_type = "Index"

    try:
        if args:
            query_vectors = args[0]
            if hasattr(query_vectors, "shape"):
                nq = int(query_vectors.shape[0])
            if len(args) > 1:
                k = int(args[1])
        k = int(kwargs.get("k", k))
    except Exception:
        pass

    try:
        if instance is not None:
            dimension = int(getattr(instance, "d", 0))
            ntotal = int(getattr(instance, "ntotal", 0))
            index_type = type(instance).__name__
    except Exception:
        pass

    try:
        span = start_retrieval_span(query="faiss.search", source="faiss")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("gen_ai.tool.type", "vector_db")
            span.set_attribute("waxell.faiss.index_type", index_type)
            span.set_attribute("waxell.faiss.k", k)
            span.set_attribute("waxell.faiss.nq", nq)
            span.set_attribute("waxell.faiss.dimension", dimension)
            span.set_attribute("waxell.faiss.ntotal", ntotal)
            span.set_attribute("waxell.retrieval.results_count", nq * k)
        except Exception as attr_exc:
            logger.debug("Failed to set FAISS search span attributes: %s", attr_exc)

        try:
            _record_search(nq=nq, k=k, index_type=index_type, ntotal=ntotal)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _add_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.add`` (adding vectors to an index).

    Args layout: index.add(vectors)
        vectors: numpy array of shape (n, d)
    """
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    n_vectors = 0
    dimension = 0
    index_type = "Index"

    try:
        if args:
            vectors = args[0]
            if hasattr(vectors, "shape"):
                n_vectors = int(vectors.shape[0])
    except Exception:
        pass

    try:
        if instance is not None:
            dimension = int(getattr(instance, "d", 0))
            index_type = type(instance).__name__
    except Exception:
        pass

    try:
        span = start_step_span(step_name="faiss.add")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.faiss.index_type", index_type)
            span.set_attribute("waxell.faiss.n_vectors", n_vectors)
            span.set_attribute("waxell.faiss.dimension", dimension)
            span.set_attribute("waxell.faiss.operation", "add")
        except Exception as attr_exc:
            logger.debug("Failed to set FAISS add span attributes: %s", attr_exc)

        try:
            _record_add(n_vectors=n_vectors, index_type=index_type)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording helpers
# ---------------------------------------------------------------------------


def _record_search(nq: int, k: int, index_type: str, ntotal: int) -> None:
    """Record a FAISS search to the HTTP path (context or collector)."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query="faiss.search",
            source="faiss",
            results_count=nq * k,
        )


def _record_add(n_vectors: int, index_type: str) -> None:
    """Record a FAISS add operation to the context (if active)."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        try:
            ctx.record_step(
                "faiss.add",
                output={
                    "n_vectors": n_vectors,
                    "index_type": index_type,
                },
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
