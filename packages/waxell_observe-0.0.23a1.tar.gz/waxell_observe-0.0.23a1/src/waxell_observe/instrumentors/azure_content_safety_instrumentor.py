"""Azure AI Content Safety auto-instrumentor for waxell-observe.

Monkey-patches azure.ai.contentsafety.ContentSafetyClient.analyze_text
and ContentSafetyClient.analyze_image to emit guardrail evaluation spans
tracking content moderation results.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Default severity threshold for pass/fail determination
_DEFAULT_SEVERITY_THRESHOLD = 2


class AzureContentSafetyInstrumentor(BaseInstrumentor):
    """Instrumentor for Azure AI Content Safety.

    Patches ContentSafetyClient.analyze_text and ContentSafetyClient.analyze_image.
    """

    _instrumented: bool = False

    def __init__(self, severity_threshold: int = _DEFAULT_SEVERITY_THRESHOLD):
        """Initialize with configurable severity threshold.

        Args:
            severity_threshold: Severity level (0-6) at or above which
                content is considered flagged. Default is 2.
        """
        self._severity_threshold = severity_threshold

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import azure.ai.contentsafety  # noqa: F401
        except ImportError:
            logger.debug("azure-ai-contentsafety not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Azure Content Safety instrumentation")
            return False

        # Store threshold in module-level variable so wrappers can access it
        global _severity_threshold
        _severity_threshold = self._severity_threshold

        patched = False

        # Patch ContentSafetyClient.analyze_text
        try:
            wrapt.wrap_function_wrapper(
                "azure.ai.contentsafety",
                "ContentSafetyClient.analyze_text",
                _analyze_text_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch ContentSafetyClient.analyze_text: %s", exc)

        # Patch ContentSafetyClient.analyze_image
        try:
            wrapt.wrap_function_wrapper(
                "azure.ai.contentsafety",
                "ContentSafetyClient.analyze_image",
                _analyze_image_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch ContentSafetyClient.analyze_image: %s", exc)

        if not patched:
            logger.debug("Could not find Azure Content Safety methods to patch")
            return False

        self._instrumented = True
        logger.debug("Azure Content Safety instrumented (analyze_text + analyze_image)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from azure.ai.contentsafety import ContentSafetyClient

            if hasattr(ContentSafetyClient.analyze_text, "__wrapped__"):
                ContentSafetyClient.analyze_text = ContentSafetyClient.analyze_text.__wrapped__
            if hasattr(getattr(ContentSafetyClient, "analyze_image", None), "__wrapped__"):
                ContentSafetyClient.analyze_image = ContentSafetyClient.analyze_image.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Azure Content Safety uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# Module-level threshold (set by instrumentor instance)
_severity_threshold = _DEFAULT_SEVERITY_THRESHOLD


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _analyze_text_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ContentSafetyClient.analyze_text`` -- text moderation."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="azure_content_safety",
            framework="azure_content_safety",
        )
        span.set_attribute("waxell.guardrail.method", "analyze_text")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_text_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _analyze_image_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ContentSafetyClient.analyze_image`` -- image moderation."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="azure_content_safety",
            framework="azure_content_safety",
        )
        span.set_attribute("waxell.guardrail.method", "analyze_image")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_image_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_text_result(span, result) -> None:
    """Extract text analysis results and set span attributes.

    AnalyzeTextResult has categories_analysis: list of items with
    category (Hate, Violence, SelfHarm, Sexual) and severity (0-6).
    """
    _record_content_safety_result(span, result, modality="text")


def _record_image_result(span, result) -> None:
    """Extract image analysis results and set span attributes."""
    _record_content_safety_result(span, result, modality="image")


def _record_content_safety_result(span, result, modality: str = "text") -> None:
    """Shared logic for recording text/image content safety results."""
    from ..tracing.attributes import WaxellAttributes

    max_severity = 0
    detected_categories = []
    category_severities = {}

    try:
        categories_analysis = getattr(result, "categories_analysis", None)
        if categories_analysis:
            for item in categories_analysis:
                category = getattr(item, "category", None)
                severity = getattr(item, "severity", 0)

                # Convert category enum to string if needed
                cat_name = str(category) if category else "unknown"
                # Handle Azure enum values like TextCategory.HATE
                if hasattr(category, "value"):
                    cat_name = str(category.value)
                elif "." in cat_name:
                    cat_name = cat_name.split(".")[-1]

                cat_name = cat_name.lower()
                sev = int(severity) if severity is not None else 0

                category_severities[cat_name] = sev
                if sev > max_severity:
                    max_severity = sev
                if sev >= _severity_threshold:
                    detected_categories.append(cat_name)
    except Exception:
        pass

    # Determine pass/fail based on max severity vs threshold
    flagged = max_severity >= _severity_threshold

    try:
        span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, not flagged)
        span.set_attribute(
            WaxellAttributes.GUARDRAIL_ACTION,
            "fail" if flagged else "pass",
        )
        span.set_attribute("waxell.guardrail.max_severity", max_severity)
        span.set_attribute("waxell.guardrail.severity_threshold", _severity_threshold)
        span.set_attribute("waxell.guardrail.modality", modality)
        if detected_categories:
            span.set_attribute(
                "waxell.guardrail.detected_categories",
                ",".join(detected_categories),
            )
        span.set_attribute(
            "waxell.guardrail.detected_count", len(detected_categories)
        )
        # Record individual category severities
        for cat_name, sev in category_severities.items():
            try:
                span.set_attribute(
                    f"waxell.guardrail.severity.{cat_name}", sev
                )
            except Exception:
                pass
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_azure(
            modality=modality,
            flagged=flagged,
            max_severity=max_severity,
            detected_categories=detected_categories,
            category_severities=category_severities,
        )
    except Exception:
        pass


def _record_http_azure(
    modality: str,
    flagged: bool,
    max_severity: int,
    detected_categories: list,
    category_severities: dict,
) -> None:
    """Record an Azure Content Safety analysis to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"guardrail:azure_content_safety_{modality}",
            output={
                "passed": not flagged,
                "action": "fail" if flagged else "pass",
                "modality": modality,
                "max_severity": max_severity,
                "detected_categories": detected_categories,
                "category_severities": category_severities,
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
