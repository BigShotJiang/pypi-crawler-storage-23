"""Milvus auto-instrumentor for waxell-observe.

Monkey-patches PyMilvus Collection methods to emit OTel spans and record
to the Waxell HTTP API via the dual-path recording pattern.

Patched methods:
  - ``pymilvus.Collection.search``  (retrieval span)
  - ``pymilvus.Collection.query``   (retrieval span)
  - ``pymilvus.Collection.insert``  (tool span)
  - ``pymilvus.Collection.delete``  (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's Milvus calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MilvusInstrumentor(BaseInstrumentor):
    """Instrumentor for the PyMilvus SDK (``pymilvus`` package).

    Patches ``Collection.search``, ``Collection.query``, ``Collection.insert``,
    and ``Collection.delete`` to emit OTel spans and record retrieval/tool events
    to the Waxell observability backend.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pymilvus  # noqa: F401
        except ImportError:
            logger.debug("pymilvus package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping Milvus instrumentation"
            )
            return False

        # Patch the legacy Collection API
        try:
            wrapt.wrap_function_wrapper(
                "pymilvus", "Collection.search", _search_wrapper
            )
        except Exception:
            pass
        try:
            wrapt.wrap_function_wrapper("pymilvus", "Collection.query", _query_wrapper)
        except Exception:
            pass
        try:
            wrapt.wrap_function_wrapper(
                "pymilvus", "Collection.insert", _insert_wrapper
            )
        except Exception:
            pass
        try:
            wrapt.wrap_function_wrapper(
                "pymilvus", "Collection.delete", _delete_wrapper
            )
        except Exception:
            pass

        # Patch the newer MilvusClient API (used by most modern code)
        try:
            wrapt.wrap_function_wrapper(
                "pymilvus.milvus_client.milvus_client",
                "MilvusClient.search",
                _search_wrapper,
            )
        except Exception:
            pass
        try:
            wrapt.wrap_function_wrapper(
                "pymilvus.milvus_client.milvus_client",
                "MilvusClient.query",
                _query_wrapper,
            )
        except Exception:
            pass
        try:
            wrapt.wrap_function_wrapper(
                "pymilvus.milvus_client.milvus_client",
                "MilvusClient.insert",
                _insert_wrapper,
            )
        except Exception:
            pass

        self._instrumented = True
        logger.debug("Milvus Collection + MilvusClient instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import pymilvus

            # Restore Collection methods
            for method_name in ("search", "query", "insert", "delete"):
                method = getattr(pymilvus.Collection, method_name, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(pymilvus.Collection, method_name, method.__wrapped__)  # type: ignore[attr-defined]

            # Restore MilvusClient methods
            try:
                from pymilvus.milvus_client.milvus_client import MilvusClient

                for method_name in ("search", "query", "insert"):
                    method = getattr(MilvusClient, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(MilvusClient, method_name, method.__wrapped__)  # type: ignore[attr-defined]
            except (ImportError, AttributeError):
                pass
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Milvus Collection + MilvusClient uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Milvus ``Collection.search``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract search parameters
    # search(data, anns_field, param, limit, ...) -- positional or keyword
    top_k = kwargs.get("limit", None)
    if top_k is None and len(args) >= 4:
        top_k = args[3]
    anns_field = kwargs.get("anns_field", args[1] if len(args) >= 2 else "")

    # Get collection name from instance
    collection_name = ""
    try:
        collection_name = getattr(instance, "name", "") or getattr(
            instance, "_name", ""
        )
    except Exception:
        pass

    query_preview = f"milvus.search(collection={collection_name!r}, anns_field={anns_field!r}, limit={top_k})"

    try:
        span = start_retrieval_span(query=query_preview, source="milvus")
    except Exception:
        return wrapped(*args, **kwargs)

    results_count = 0

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Milvus search returns a list of Hits objects (one per query vector)
            if response is not None:
                if isinstance(response, list):
                    results_count = sum(len(hits) for hits in response)
                else:
                    results_count = len(response)

            span.set_attribute("gen_ai.tool.type", "vector_db")
            span.set_attribute(
                "waxell.retrieval.top_k", top_k if top_k is not None else 0
            )
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            if collection_name:
                span.set_attribute("db.milvus.collection_name", collection_name)
        except Exception as attr_exc:
            logger.debug("Failed to set Milvus search span attributes: %s", attr_exc)

        try:
            _record_milvus_retrieval(
                query=query_preview,
                top_k=top_k,
                collection_name=collection_name,
                results_count=results_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Milvus ``Collection.query``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # query(expr, ...) -- first positional or keyword
    expr = kwargs.get("expr", args[0] if args else "")

    collection_name = ""
    try:
        collection_name = getattr(instance, "name", "") or getattr(
            instance, "_name", ""
        )
    except Exception:
        pass

    query_preview = (
        f"milvus.query(collection={collection_name!r}, expr={str(expr)[:200]!r})"
    )

    try:
        span = start_retrieval_span(query=query_preview, source="milvus")
    except Exception:
        return wrapped(*args, **kwargs)

    results_count = 0

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # query() returns a list of dicts
            if response is not None and isinstance(response, list):
                results_count = len(response)

            span.set_attribute("gen_ai.tool.type", "vector_db")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            if collection_name:
                span.set_attribute("db.milvus.collection_name", collection_name)
        except Exception as attr_exc:
            logger.debug("Failed to set Milvus query span attributes: %s", attr_exc)

        try:
            _record_milvus_retrieval(
                query=query_preview,
                top_k=None,
                collection_name=collection_name,
                results_count=results_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _insert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Milvus ``Collection.insert``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # insert(data, ...) -- data is a list of dicts or list of lists
    data = kwargs.get("data", args[0] if args else [])
    insert_count = len(data) if data else 0

    collection_name = ""
    try:
        collection_name = getattr(instance, "name", "") or getattr(
            instance, "_name", ""
        )
    except Exception:
        pass

    try:
        span = start_tool_span(tool_name="milvus.insert", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # MutationResult has primary_keys and insert_count
            actual_count = getattr(response, "insert_count", insert_count)
            span.set_attribute("waxell.vectordb.operation", "insert")
            span.set_attribute("waxell.vectordb.vectors_count", actual_count)
            if collection_name:
                span.set_attribute("db.milvus.collection_name", collection_name)
        except Exception as attr_exc:
            logger.debug("Failed to set Milvus insert span attributes: %s", attr_exc)

        try:
            _record_milvus_write(
                operation="insert",
                vectors_count=insert_count,
                collection_name=collection_name,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _delete_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Milvus ``Collection.delete``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # delete(expr, ...) -- expression selecting entities to delete
    expr = kwargs.get("expr", args[0] if args else "")

    collection_name = ""
    try:
        collection_name = getattr(instance, "name", "") or getattr(
            instance, "_name", ""
        )
    except Exception:
        pass

    try:
        span = start_tool_span(tool_name="milvus.delete", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # MutationResult for delete
            delete_count = getattr(response, "delete_count", 0)
            span.set_attribute("waxell.vectordb.operation", "delete")
            span.set_attribute("waxell.vectordb.vectors_count", delete_count)
            if collection_name:
                span.set_attribute("db.milvus.collection_name", collection_name)
            if expr:
                span.set_attribute("waxell.vectordb.delete_expr", str(expr)[:200])
        except Exception as attr_exc:
            logger.debug("Failed to set Milvus delete span attributes: %s", attr_exc)

        try:
            _record_milvus_write(
                operation="delete",
                vectors_count=delete_count if "delete_count" in dir() else 0,
                collection_name=collection_name,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_milvus_retrieval(
    query: str,
    top_k: int | None,
    collection_name: str,
    results_count: int,
) -> None:
    """Record a Milvus retrieval operation to the context path.

    Vector DB retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector (no auto-run is created
    for vector DB ops).
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"match_{i}"} for i in range(results_count)]
        ctx.record_retrieval(
            query=query,
            source="milvus",
            documents=documents,
            top_k=top_k,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_milvus_write(
    operation: str,
    vectors_count: int,
    collection_name: str,
) -> None:
    """Record a Milvus write operation (insert/delete) to the context path.

    Write operations are recorded as tool calls within an active WaxellContext.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"milvus.{operation}",
            input={"vectors_count": vectors_count, "collection_name": collection_name},
            tool_type="vectordb",
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
