"""PydanticAI auto-instrumentor for waxell-observe.

Monkey-patches ``pydantic_ai.Agent.run`` and ``pydantic_ai.Agent.run_sync``
to emit OTel spans and record to the Waxell HTTP API.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PydanticAIInstrumentor(BaseInstrumentor):
    """Instrumentor for PydanticAI (``pydantic-ai`` package).

    Patches Agent.run (async) and Agent.run_sync.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pydantic_ai  # noqa: F401
        except ImportError:
            logger.debug("pydantic_ai not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping PydanticAI instrumentation")
            return False

        patched = False

        # Patch Agent.run (async)
        try:
            wrapt.wrap_function_wrapper(
                "pydantic_ai",
                "Agent.run",
                _agent_run_async_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Agent.run: %s", exc)

        # Patch Agent.run_sync
        try:
            wrapt.wrap_function_wrapper(
                "pydantic_ai",
                "Agent.run_sync",
                _agent_run_sync_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Agent.run_sync: %s", exc)

        if not patched:
            logger.debug("Could not find PydanticAI methods to patch")
            return False

        self._instrumented = True
        logger.debug("PydanticAI instrumented (Agent.run + Agent.run_sync)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import pydantic_ai

            if hasattr(pydantic_ai.Agent.run, "__wrapped__"):
                pydantic_ai.Agent.run = pydantic_ai.Agent.run.__wrapped__
            if hasattr(pydantic_ai.Agent.run_sync, "__wrapped__"):
                pydantic_ai.Agent.run_sync = pydantic_ai.Agent.run_sync.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("PydanticAI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


async def _agent_run_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Agent.run``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_name = getattr(instance, "name", None) or "pydantic_ai.agent"

    # Extract model info
    model_name = ""
    try:
        model = getattr(instance, "model", None)
        if model:
            model_name = str(getattr(model, "model_name", None) or getattr(model, "name", None) or model)
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="pydantic_ai_run",
        )
        if model_name:
            span.set_attribute("waxell.pydanticai.model", model_name)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_run_sync_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Agent.run_sync``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = getattr(instance, "name", None) or "pydantic_ai.agent"

    # Extract model info
    model_name = ""
    try:
        model = getattr(instance, "model", None)
        if model:
            model_name = str(getattr(model, "model_name", None) or getattr(model, "name", None) or model)
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="pydantic_ai_run_sync",
        )
        if model_name:
            span.set_attribute("waxell.pydanticai.model", model_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_result_attributes(span, result, agent_name: str) -> None:
    """Extract and set result attributes on the span."""
    # Extract tool calls if available
    tool_calls = []
    try:
        messages = getattr(result, "all_messages", None) or []
        for msg in messages:
            parts = getattr(msg, "parts", [])
            for part in parts:
                part_type = type(part).__name__
                if "ToolCall" in part_type:
                    tool_name = getattr(part, "tool_name", "unknown")
                    tool_calls.append(tool_name)
    except Exception:
        pass

    if tool_calls:
        span.set_attribute("waxell.pydanticai.tool_calls", tool_calls)
        span.set_attribute("waxell.pydanticai.tool_call_count", len(tool_calls))

    # Extract result type
    try:
        data = getattr(result, "data", None)
        if data is not None:
            span.set_attribute("waxell.pydanticai.result_type", type(data).__name__)
    except Exception:
        pass

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"pydantic_ai:{agent_name}",
                output={
                    "result_preview": str(getattr(result, "data", result))[:500],
                    "tool_calls": tool_calls,
                },
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
