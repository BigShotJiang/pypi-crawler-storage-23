"""E2B Code Interpreter auto-instrumentor for waxell-observe.

Monkey-patches ``e2b_code_interpreter.Sandbox.run_code`` and
``e2b_code_interpreter.AsyncSandbox.run_code`` to emit OTel tool spans
for remote code execution operations:
  - ``Sandbox.run_code``       -- sync code execution
  - ``AsyncSandbox.run_code``  -- async code execution

These are external tool operations (sandboxed code execution), so all spans
use ``start_tool_span()`` instead of ``start_llm_span()``.

Cost is tracked externally by E2B billing, so cost is always 0.0 here.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class E2BInstrumentor(BaseInstrumentor):
    """Instrumentor for the E2B Code Interpreter SDK.

    Patches ``Sandbox.run_code`` (sync) and ``AsyncSandbox.run_code`` (async).

    Tries ``e2b_code_interpreter`` package first, falls back to ``e2b``.
    """

    _instrumented: bool = False
    _module_name: str = ""

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Try e2b_code_interpreter first, then fall back to e2b
        module_name = ""
        try:
            import e2b_code_interpreter  # noqa: F401

            module_name = "e2b_code_interpreter"
        except ImportError:
            try:
                import e2b  # noqa: F401

                module_name = "e2b"
            except ImportError:
                logger.debug(
                    "Neither e2b_code_interpreter nor e2b package installed "
                    "-- skipping instrumentation"
                )
                return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping E2B instrumentation")
            return False

        patched = False

        # Patch Sandbox.run_code (sync)
        try:
            wrapt.wrap_function_wrapper(
                module_name,
                "Sandbox.run_code",
                _sync_run_code_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch %s.Sandbox.run_code: %s", module_name, exc)

        # Patch AsyncSandbox.run_code (async)
        try:
            wrapt.wrap_function_wrapper(
                module_name,
                "AsyncSandbox.run_code",
                _async_run_code_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug(
                "Could not patch %s.AsyncSandbox.run_code: %s", module_name, exc
            )

        if not patched:
            logger.debug("Could not find any E2B methods to patch")
            return False

        self._module_name = module_name
        self._instrumented = True
        logger.debug(
            "E2B instrumented via %s (Sandbox.run_code + AsyncSandbox.run_code)",
            module_name,
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        module_name = self._module_name or "e2b_code_interpreter"

        try:
            import importlib

            mod = importlib.import_module(module_name)

            for cls_name in ("Sandbox", "AsyncSandbox"):
                cls = getattr(mod, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "run_code", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "run_code", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        self._module_name = ""
        logger.debug("E2B uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from E2B responses
# ---------------------------------------------------------------------------


def _extract_code(args, kwargs) -> str:
    """Extract the code string from run_code arguments."""
    code = ""
    if args:
        code = str(args[0]) if args[0] else ""
    code = kwargs.get("code", code)
    if not isinstance(code, str):
        code = str(code) if code else ""
    return code


def _extract_language(kwargs) -> str:
    """Extract the programming language from kwargs."""
    lang = kwargs.get("language", "python")
    return str(lang) if lang else "python"


def _extract_output(result) -> str:
    """Extract stdout output from an E2B execution result.

    Tries multiple paths:
      - result.logs.stdout (list of strings or string)
      - result.text
      - str(result)
    """
    if result is None:
        return ""

    try:
        # Path 1: result.logs.stdout
        logs = getattr(result, "logs", None)
        if logs is not None:
            stdout = getattr(logs, "stdout", None)
            if stdout is not None:
                if isinstance(stdout, list):
                    text = "\n".join(str(line) for line in stdout)
                    return text[:500]
                if isinstance(stdout, str):
                    return stdout[:500]

        # Path 2: result.text
        text = getattr(result, "text", None)
        if text and isinstance(text, str):
            return text[:500]

        # Path 3: fallback to str(result)
        return str(result)[:500]
    except Exception:
        return ""


def _extract_error(result) -> str:
    """Extract error/stderr from an E2B execution result.

    Tries:
      - result.error
      - result.logs.stderr
    """
    if result is None:
        return ""

    try:
        # Path 1: result.error
        error = getattr(result, "error", None)
        if error:
            if isinstance(error, str):
                return error[:500]
            # Error might be an object with name/value/traceback
            name = getattr(error, "name", "")
            value = getattr(error, "value", "")
            if name or value:
                return f"{name}: {value}"[:500]
            return str(error)[:500]

        # Path 2: result.logs.stderr
        logs = getattr(result, "logs", None)
        if logs is not None:
            stderr = getattr(logs, "stderr", None)
            if stderr is not None:
                if isinstance(stderr, list):
                    text = "\n".join(str(line) for line in stderr)
                    return text[:500]
                if isinstance(stderr, str):
                    return stderr[:500]
    except Exception:
        pass

    return ""


def _extract_execution_count(result) -> int:
    """Extract the number of result items from an E2B execution result.

    Tries:
      - result.results (list)
      - len([result]) if result has content
    """
    if result is None:
        return 0

    try:
        results = getattr(result, "results", None)
        if isinstance(results, list) and len(results) > 0:
            return len(results)

        # If the result itself has content, count it as 1
        if getattr(result, "text", None) or getattr(result, "logs", None):
            return 1
    except Exception:
        pass

    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_run_code_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Sandbox.run_code``."""
    code = _extract_code(args, kwargs)
    language = _extract_language(kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="e2b.run_code", tool_type="code_execution")
        span.set_attribute("waxell.e2b.method", "run_code")
        span.set_attribute("waxell.e2b.language", language)
        if code:
            span.set_attribute("waxell.e2b.code_length", len(code))
            span.set_attribute("waxell.e2b.code_preview", code[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            output = _extract_output(response)
            if output:
                span.set_attribute("waxell.e2b.output_preview", output[:500])

            error = _extract_error(response)
            if error:
                span.set_attribute("waxell.e2b.error", error)

            exec_count = _extract_execution_count(response)
            span.set_attribute("waxell.e2b.execution_count", exec_count)
        except Exception:
            pass

        try:
            _record_tool_call(
                code=code,
                language=language,
                response=response,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_run_code_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncSandbox.run_code``."""
    code = _extract_code(args, kwargs)
    language = _extract_language(kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="e2b.run_code", tool_type="code_execution")
        span.set_attribute("waxell.e2b.method", "run_code")
        span.set_attribute("waxell.e2b.language", language)
        if code:
            span.set_attribute("waxell.e2b.code_length", len(code))
            span.set_attribute("waxell.e2b.code_preview", code[:200])
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            output = _extract_output(response)
            if output:
                span.set_attribute("waxell.e2b.output_preview", output[:500])

            error = _extract_error(response)
            if error:
                span.set_attribute("waxell.e2b.error", error)

            exec_count = _extract_execution_count(response)
            span.set_attribute("waxell.e2b.execution_count", exec_count)
        except Exception:
            pass

        try:
            _record_tool_call(
                code=code,
                language=language,
                response=response,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tool_call(
    code: str,
    language: str,
    response,
) -> None:
    """Record an E2B tool call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    output = _extract_output(response)
    error = _extract_error(response)
    exec_count = _extract_execution_count(response)

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        output_dict: dict = {}
        if output:
            output_dict["output_preview"] = output[:500]
        if error:
            output_dict["error"] = error[:500]
        if exec_count:
            output_dict["execution_count"] = exec_count

        ctx.record_tool_call(
            name="e2b.run_code",
            input={"language": language, "code_preview": code[:200]},
            output=output_dict,
            tool_type="code_execution",
            status="error" if error else "ok",
        )
    else:
        # Fall back to collector with an LLM-call-shaped dict
        call_data = {
            "model": "e2b",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost": 0.0,
            "task": "e2b.run_code",
            "prompt_preview": code[:200] if code else "",
            "response_preview": output[:500] if output else "",
        }
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
