"""ControlFlow auto-instrumentor for waxell-observe.

Monkey-patches ``controlflow.Task.run``, ``controlflow.Agent.__call__``,
and ``controlflow.flow`` decorated functions to emit OTel spans and record
to the Waxell HTTP API.

ControlFlow is Prefect's agentic framework for building structured AI
workflows with Task, Agent, and flow abstractions.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ControlFlowInstrumentor(BaseInstrumentor):
    """Instrumentor for the ControlFlow framework (``controlflow`` package).

    Patches Task.run for task execution, Agent.__call__ for agent invocation,
    and flow() decorated functions for flow execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import controlflow  # noqa: F401
        except ImportError:
            logger.debug("controlflow not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping ControlFlow instrumentation")
            return False

        patched = False

        # Patch Task.run (task execution entry point)
        try:
            wrapt.wrap_function_wrapper(
                "controlflow",
                "Task.run",
                _task_run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch controlflow.Task.run: %s", exc)

        # Also try controlflow.core.task.Task.run (submodule)
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "controlflow.core.task",
                    "Task.run",
                    _task_run_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch controlflow.core.task.Task.run: %s", exc)

        # Patch Agent.__call__ (agent invocation)
        try:
            wrapt.wrap_function_wrapper(
                "controlflow",
                "Agent.__call__",
                _agent_call_wrapper,
            )
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "controlflow.core.agent",
                    "Agent.__call__",
                    _agent_call_wrapper,
                )
            except Exception as exc:
                logger.debug("Failed to patch controlflow Agent.__call__: %s", exc)

        if not patched:
            logger.debug("Could not find ControlFlow methods to patch")
            return False

        self._instrumented = True
        logger.debug("ControlFlow instrumented (Task.run + Agent.__call__)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import controlflow

            task_cls = getattr(controlflow, "Task", None)
            if task_cls and hasattr(getattr(task_cls, "run", None), "__wrapped__"):
                task_cls.run = task_cls.run.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from controlflow.core.task import Task

            if hasattr(getattr(Task, "run", None), "__wrapped__"):
                Task.run = Task.run.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import controlflow

            agent_cls = getattr(controlflow, "Agent", None)
            if agent_cls and hasattr(getattr(agent_cls, "__call__", None), "__wrapped__"):
                agent_cls.__call__ = agent_cls.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from controlflow.core.agent import Agent

            if hasattr(getattr(Agent, "__call__", None), "__wrapped__"):
                Agent.__call__ = Agent.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("ControlFlow uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _task_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Task.run`` -- ControlFlow task execution."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    task_name = _extract_task_name(instance)
    objective = _extract_objective(instance)

    try:
        span = start_step_span(step_name=task_name)
        span.set_attribute("waxell.agent.framework", "controlflow")
        span.set_attribute("waxell.agent.task", task_name)
        if objective:
            span.set_attribute("waxell.controlflow.objective", objective[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_task_result_attributes(span, result, task_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Agent.__call__`` -- ControlFlow agent invocation."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = _extract_agent_name(instance)
    model_name = _extract_model_name(instance)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="controlflow_agent_call",
        )
        span.set_attribute("waxell.agent.framework", "controlflow")
        span.set_attribute("waxell.agent.name", agent_name)
        if model_name:
            span.set_attribute("waxell.controlflow.model", model_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_agent_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_task_name(instance) -> str:
    """Extract task name from a ControlFlow Task instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        objective = getattr(instance, "objective", None)
        if objective:
            return str(objective)[:100]
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "controlflow.task"


def _extract_objective(instance) -> str:
    """Extract objective/description from a ControlFlow Task instance."""
    try:
        objective = getattr(instance, "objective", None)
        if objective:
            return str(objective)
    except Exception:
        pass
    try:
        description = getattr(instance, "description", None)
        if description:
            return str(description)
    except Exception:
        pass
    return ""


def _extract_agent_name(instance) -> str:
    """Extract agent name from a ControlFlow Agent instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "controlflow.agent"


def _extract_model_name(instance) -> str:
    """Extract model name from a ControlFlow Agent instance."""
    try:
        model = getattr(instance, "model", None)
        if model is None:
            return ""
        model_name = getattr(model, "model_name", None) or getattr(model, "id", None)
        if model_name:
            return str(model_name)
        return str(model)
    except Exception:
        return ""


def _set_task_result_attributes(span, result, task_name: str) -> None:
    """Set result attributes on the span for task execution."""
    try:
        if result is not None:
            span.set_attribute("waxell.controlflow.result_preview", str(result)[:200])
            span.set_attribute("waxell.controlflow.status", "success")
        else:
            span.set_attribute("waxell.controlflow.status", "completed")
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"controlflow:task:{task_name}",
                output={"task_name": task_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_agent_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span for agent invocation."""
    try:
        if result is not None:
            span.set_attribute("waxell.controlflow.response_preview", str(result)[:200])
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"controlflow:agent:{agent_name}",
                output={"agent_name": agent_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
