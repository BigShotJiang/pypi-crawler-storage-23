"""Redis vector search auto-instrumentor for waxell-observe.

Monkey-patches redis.commands.search.Search.search and ft().search
to emit retrieval spans for RediSearch vector queries.

Also patches Redis memory operations (hset, hget, hgetall, Pipeline.execute)
to emit step spans when an active WaxellContext is present.  Memory operation
spans are context-gated: they only fire inside a WaxellContext with a run_id
to avoid noise from application-level Redis usage unrelated to agent runs.

Patched methods:
  - ``redis.commands.search.Search.search``       (retrieval span)
  - ``redis.commands.search.AsyncSearch.search``   (retrieval span, async)
  - ``redis.client.Redis.hset``                    (memory write span, context-gated)
  - ``redis.client.Redis.hget``                    (memory read span, context-gated)
  - ``redis.client.Redis.hgetall``                 (memory read span, context-gated)
  - ``redis.client.Pipeline.execute``              (pipeline span, context-gated)

All wrapper code is wrapped in try/except -- never breaks the user's Redis calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class RedisVectorInstrumentor(BaseInstrumentor):
    """Instrumentor for Redis vector search (``redis`` package with RediSearch).

    Patches ``Search.search`` (sync) and ``AsyncSearch.search`` (async) to emit
    retrieval spans for FT.SEARCH vector queries.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import redis.commands.search  # noqa: F401
        except ImportError:
            logger.debug("redis search module not installed -- skipping Redis vector instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Redis vector instrumentation")
            return False

        patched_any = False

        # --- Sync Search.search ---
        try:
            wrapt.wrap_function_wrapper(
                "redis.commands.search",
                "Search.search",
                _sync_search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch redis Search.search: %s", exc)

        # --- Async AsyncSearch.search (optional, may not be present) ---
        try:
            wrapt.wrap_function_wrapper(
                "redis.commands.search",
                "AsyncSearch.search",
                _async_search_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch redis AsyncSearch.search: %s", exc)

        # --- Memory operations (hash-based, used by LangChain RedisChatMessageHistory etc.) ---
        try:
            wrapt.wrap_function_wrapper("redis.client", "Redis.hset", _sync_memory_write_wrapper)
            wrapt.wrap_function_wrapper("redis.client", "Redis.hget", _sync_memory_read_wrapper)
            wrapt.wrap_function_wrapper("redis.client", "Redis.hgetall", _sync_memory_read_wrapper)
            wrapt.wrap_function_wrapper("redis.client", "Pipeline.execute", _sync_pipeline_wrapper)
        except Exception as exc:
            logger.debug("Could not patch Redis memory operations: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any Redis search methods")
            return False

        self._instrumented = True
        logger.debug(
            "Redis vector search instrumented "
            "(Search.search, AsyncSearch.search, hset, hget, hgetall, Pipeline.execute)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import redis.commands.search as search_mod

            # Sync Search
            search_cls = getattr(search_mod, "Search", None)
            if search_cls is not None:
                method = getattr(search_cls, "search", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    search_cls.search = method.__wrapped__  # type: ignore[attr-defined]

            # Async AsyncSearch
            async_cls = getattr(search_mod, "AsyncSearch", None)
            if async_cls is not None:
                method = getattr(async_cls, "search", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    async_cls.search = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore memory operation patches
        try:
            import redis.client as client_mod

            redis_cls = getattr(client_mod, "Redis", None)
            if redis_cls is not None:
                for method_name in ("hset", "hget", "hgetall"):
                    method = getattr(redis_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(redis_cls, method_name, method.__wrapped__)

            pipeline_cls = getattr(client_mod, "Pipeline", None)
            if pipeline_cls is not None:
                method = getattr(pipeline_cls, "execute", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    pipeline_cls.execute = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Redis vector search uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query_text(args, kwargs) -> str:
    """Extract the query string from Search.search arguments.

    ``Search.search(query)`` accepts a Query object or a raw string.
    We attempt to get a human-readable representation.
    """
    query = args[0] if args else kwargs.get("query", "")
    if query is None:
        return "<none>"

    # redis.commands.search.query.Query has a .query_string() method
    query_string = getattr(query, "query_string", None)
    if callable(query_string):
        try:
            return str(query_string())
        except Exception:
            pass

    # Fallback: convert to string directly
    return str(query)[:500]


def _extract_index_name(instance) -> str:
    """Extract the index name from a Search instance.

    Search objects hold a reference to the index name via ``index_name``
    or ``_name`` attribute.
    """
    try:
        name = getattr(instance, "index_name", None)
        if name:
            return str(name)
        name = getattr(instance, "_name", None)
        if name:
            return str(name)
    except Exception:
        pass
    return ""


def _count_results(response) -> int:
    """Count the number of results returned from a RediSearch response.

    RediSearch returns a Result object with a ``docs`` attribute (list of
    documents) and a ``total`` attribute (total matching count).
    """
    try:
        if response is None:
            return 0
        docs = getattr(response, "docs", None)
        if docs is not None:
            return len(docs)
        # Some versions return a list directly
        if isinstance(response, (list, tuple)):
            return len(response)
    except Exception:
        pass
    return 0


def _get_total_results(response) -> int:
    """Get the total count of matching results (before LIMIT)."""
    try:
        total = getattr(response, "total", None)
        if total is not None:
            return int(total)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper
# ---------------------------------------------------------------------------


def _sync_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Search.search`` (FT.SEARCH command)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_text = _extract_query_text(args, kwargs)
    index_name = _extract_index_name(instance)

    try:
        span = start_retrieval_span(query=query_text, source="redis-vector")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = _count_results(response)
            total_results = _get_total_results(response)

            span.set_attribute("waxell.retrieval.results_count", results_count)
            if total_results:
                span.set_attribute("waxell.retrieval.total_results", total_results)
            if index_name:
                span.set_attribute("waxell.retrieval.index_name", index_name)
            span.set_attribute("db.system", "redis")
        except Exception as attr_exc:
            logger.debug("Failed to set Redis search span attributes: %s", attr_exc)

        try:
            _record_redis_retrieval(
                query=query_text,
                index_name=index_name,
                results_count=results_count if 'results_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrapper
# ---------------------------------------------------------------------------


async def _async_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncSearch.search`` (FT.SEARCH command)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_text = _extract_query_text(args, kwargs)
    index_name = _extract_index_name(instance)

    try:
        span = start_retrieval_span(query=query_text, source="redis-vector")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = _count_results(response)
            total_results = _get_total_results(response)

            span.set_attribute("waxell.retrieval.results_count", results_count)
            if total_results:
                span.set_attribute("waxell.retrieval.total_results", total_results)
            if index_name:
                span.set_attribute("waxell.retrieval.index_name", index_name)
            span.set_attribute("db.system", "redis")
        except Exception as attr_exc:
            logger.debug("Failed to set Redis async search span attributes: %s", attr_exc)

        try:
            _record_redis_retrieval(
                query=query_text,
                index_name=index_name,
                results_count=results_count if 'results_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_redis_retrieval(
    query: str,
    index_name: str,
    results_count: int,
) -> None:
    """Record a Redis vector retrieval operation to the context path.

    Redis vector retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"match_{i}"} for i in range(results_count)]
        ctx.record_retrieval(
            query=query,
            source="redis-vector",
            documents=documents,
        )


# ---------------------------------------------------------------------------
# Memory operation helpers
# ---------------------------------------------------------------------------


def _get_active_context():
    """Return the active WaxellContext if it has a run_id, else None.

    Memory operation spans are context-gated: we only create them when
    inside an active WaxellContext to avoid noise from Redis usage
    unrelated to agent runs.
    """
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            return ctx
    except Exception:
        pass
    return None


def _extract_key_prefix(args) -> str:
    """Extract the Redis key from the first positional arg (truncated to 50 chars)."""
    try:
        if args:
            return str(args[0])[:50]
    except Exception:
        pass
    return ""


def _get_pipeline_command_count(instance) -> int:
    """Get the number of queued commands from a Pipeline instance.

    Pipeline stores queued commands in ``command_stack`` or
    ``_command_stack`` depending on the redis-py version.
    """
    try:
        stack = getattr(instance, "command_stack", None)
        if stack is None:
            stack = getattr(instance, "_command_stack", None)
        if stack is not None:
            return len(stack)
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# Memory write wrapper (hset)
# ---------------------------------------------------------------------------


def _sync_memory_write_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Redis.hset`` — context-gated memory write span."""
    ctx = _get_active_context()
    if ctx is None:
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    key_prefix = _extract_key_prefix(args)

    try:
        span = start_step_span("redis.memory.write")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "redis")
            span.set_attribute("waxell.redis.operation", "hset")
            if key_prefix:
                span.set_attribute("waxell.redis.key_prefix", key_prefix)
        except Exception as attr_exc:
            logger.debug("Failed to set Redis memory write span attributes: %s", attr_exc)

        try:
            _record_redis_memory_op(ctx, operation="hset", key_prefix=key_prefix)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Memory read wrapper (hget, hgetall)
# ---------------------------------------------------------------------------


def _sync_memory_read_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Redis.hget`` / ``Redis.hgetall`` — context-gated memory read span."""
    ctx = _get_active_context()
    if ctx is None:
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    key_prefix = _extract_key_prefix(args)

    # Determine operation name from the wrapped function
    operation = "hget"
    try:
        fn_name = getattr(wrapped, "__name__", "") or getattr(wrapped, "__qualname__", "")
        if "hgetall" in fn_name:
            operation = "hgetall"
    except Exception:
        pass

    try:
        span = start_step_span("redis.memory.read")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "redis")
            span.set_attribute("waxell.redis.operation", operation)
            if key_prefix:
                span.set_attribute("waxell.redis.key_prefix", key_prefix)
        except Exception as attr_exc:
            logger.debug("Failed to set Redis memory read span attributes: %s", attr_exc)

        try:
            _record_redis_memory_op(ctx, operation=operation, key_prefix=key_prefix)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Pipeline wrapper
# ---------------------------------------------------------------------------


def _sync_pipeline_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Pipeline.execute`` — context-gated pipeline span."""
    ctx = _get_active_context()
    if ctx is None:
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    command_count = _get_pipeline_command_count(instance)

    try:
        span = start_step_span("redis.pipeline.execute")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "redis")
            span.set_attribute("waxell.redis.operation", "pipeline")
            span.set_attribute("waxell.redis.command_count", command_count)
        except Exception as attr_exc:
            logger.debug("Failed to set Redis pipeline span attributes: %s", attr_exc)

        try:
            _record_redis_memory_op(
                ctx, operation="pipeline", key_prefix="", command_count=command_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path recording for memory operations
# ---------------------------------------------------------------------------


def _record_redis_memory_op(
    ctx,
    operation: str,
    key_prefix: str,
    command_count: int = 0,
) -> None:
    """Record a Redis memory operation as a step on the active WaxellContext.

    Only called when a context is already verified as active (has run_id).
    """
    output: dict = {
        "_kind": "redis_memory",
        "operation": operation,
    }
    if key_prefix:
        output["key_prefix"] = key_prefix
    if command_count:
        output["command_count"] = command_count
    ctx.record_step(f"redis.memory.{operation}", output=output)
