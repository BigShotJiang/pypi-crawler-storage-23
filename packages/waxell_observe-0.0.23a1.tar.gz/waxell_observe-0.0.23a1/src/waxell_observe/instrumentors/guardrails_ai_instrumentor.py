"""Guardrails AI auto-instrumentor for waxell-observe.

Monkey-patches guardrails.Guard.__call__ and Guard.validate to emit
guardrail evaluation spans tracking validator results.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GuardrailsAIInstrumentor(BaseInstrumentor):
    """Instrumentor for Guardrails AI (``guardrails`` package).

    Patches Guard.__call__ and Guard.validate.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import guardrails  # noqa: F401
        except ImportError:
            logger.debug("guardrails not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Guardrails AI instrumentation")
            return False

        patched = False

        # Patch Guard.__call__ (the main guard invocation)
        try:
            wrapt.wrap_function_wrapper(
                "guardrails.guard",
                "Guard.__call__",
                _guard_call_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Guard.__call__: %s", exc)

        # Patch Guard.validate (explicit validation)
        try:
            wrapt.wrap_function_wrapper(
                "guardrails.guard",
                "Guard.validate",
                _guard_validate_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch Guard.validate: %s", exc)

        if not patched:
            logger.debug("Could not find Guardrails AI methods to patch")
            return False

        self._instrumented = True
        logger.debug("Guardrails AI instrumented (Guard.__call__ + Guard.validate)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from guardrails.guard import Guard

            if hasattr(Guard.__call__, "__wrapped__"):
                Guard.__call__ = Guard.__call__.__wrapped__
            if hasattr(getattr(Guard, "validate", None), "__wrapped__"):
                Guard.validate = Guard.validate.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Guardrails AI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _guard_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Guard.__call__`` -- main guard invocation."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    guard_name = ""
    try:
        guard_name = getattr(instance, "name", None) or type(instance).__name__
    except Exception:
        guard_name = "guardrails_ai_guard"

    try:
        span = start_guardrail_span(
            guardrail_name=guard_name,
            framework="guardrails_ai",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_guard_result(span, instance, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _guard_validate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Guard.validate`` -- explicit validation call."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    guard_name = ""
    try:
        guard_name = getattr(instance, "name", None) or type(instance).__name__
    except Exception:
        guard_name = "guardrails_ai_validate"

    try:
        span = start_guardrail_span(
            guardrail_name=guard_name,
            framework="guardrails_ai",
        )
        span.set_attribute("waxell.guardrail.method", "validate")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_guard_result(span, instance, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_guard_result(span, instance, result) -> None:
    """Extract guardrail results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    # Determine if validation passed
    passed = True
    try:
        passed = bool(getattr(result, "validation_passed", True))
    except Exception:
        pass
    span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, passed)

    # Determine action: "pass", "fail", or "fix"
    action = "pass"
    try:
        if not passed:
            # Check if the output was reask/fix or just fail
            reask = getattr(result, "reask", None)
            validated_output = getattr(result, "validated_output", None)
            if reask is not None:
                action = "fix"
            elif validated_output is None:
                action = "fail"
            else:
                action = "fix"
        else:
            action = "pass"
    except Exception:
        action = "fail" if not passed else "pass"
    span.set_attribute(WaxellAttributes.GUARDRAIL_ACTION, action)

    # Count validators applied
    validators_count = 0
    try:
        validators = getattr(instance, "validators", None)
        if validators is not None:
            validators_count = len(validators)
    except Exception:
        pass
    span.set_attribute("waxell.guardrail.validators_count", validators_count)

    # Record to HTTP path
    try:
        _record_http_guardrail(instance, result, passed, action)
    except Exception:
        pass


def _record_http_guardrail(instance, result, passed: bool, action: str) -> None:
    """Record a guardrail evaluation to the HTTP path."""
    from ._context_var import _current_context

    guard_name = ""
    try:
        guard_name = getattr(instance, "name", None) or type(instance).__name__
    except Exception:
        guard_name = "guardrails_ai_guard"

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"guardrail:{guard_name}",
            output={
                "passed": passed,
                "action": action,
                "result_preview": str(result)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
