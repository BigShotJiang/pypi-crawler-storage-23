"""OpenAI auto-instrumentor for waxell-observe.

Monkey-patches ``openai.resources.chat.completions.Completions.create``
(sync) and ``AsyncCompletions.create`` (async) to emit OTel spans with
GenAI semantic convention attributes.  Also patches
``openai.resources.embeddings.Embeddings.create`` (sync + async) to emit
embedding spans.

Additionally patches:
  - ``openai.resources.images.Images.generate`` (sync + async) -- DALL-E 3
  - ``openai.resources.audio.transcriptions.Transcriptions.create`` (sync + async) -- Whisper
  - ``openai.resources.audio.speech.Speech.create`` (sync + async) -- TTS
  - ``openai.resources.responses.Responses.create`` (sync + async) -- Responses API

Streaming calls (``stream=True``) are wrapped to accumulate token counts
from the final chunk (using ``stream_options={"include_usage": True}``).
The wrapper classes proxy the stream iterator transparently and record
the LLM call on stream completion.

All wrapper code is wrapped in try/except at the top level -- if span
creation fails, the original method is still called.  Never breaks the
user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class OpenAIInstrumentor(BaseInstrumentor):
    """Instrumentor for the OpenAI Python SDK (``openai`` package).

    Patches ``chat.completions.create`` for both sync and async clients.
    """

    _instrumented: bool = False
    _originals: dict = {}

    def instrument(self) -> bool:
        """Apply monkey-patches to OpenAI SDK chat completion methods.

        Returns True if patches were applied, False if the ``openai``
        package is not installed.
        """
        if self._instrumented:
            return True

        try:
            import openai.resources.chat.completions  # noqa: F401
        except ImportError:
            logger.debug("openai package not installed -- skipping instrumentation")
            return False

        # Log detected version for diagnostics
        try:
            import openai
            _version = getattr(openai, "__version__", "unknown")
            logger.debug("Detected openai package version: %s", _version)
        except Exception:
            pass

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping OpenAI instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "openai.resources.chat.completions",
                "Completions.create",
                _sync_chat_wrapper,
            )

            wrapt.wrap_function_wrapper(
                "openai.resources.chat.completions",
                "AsyncCompletions.create",
                _async_chat_wrapper,
            )

            # Patch embeddings.create (sync + async)
            try:
                wrapt.wrap_function_wrapper(
                    "openai.resources.embeddings",
                    "Embeddings.create",
                    _sync_embeddings_wrapper,
                )
                wrapt.wrap_function_wrapper(
                    "openai.resources.embeddings",
                    "AsyncEmbeddings.create",
                    _async_embeddings_wrapper,
                )
                logger.debug("OpenAI embeddings.create instrumented (sync + async)")
            except Exception as emb_exc:
                logger.debug("Could not instrument OpenAI embeddings: %s", emb_exc)

            # Patch images.generate (sync + async) -- DALL-E 3
            try:
                wrapt.wrap_function_wrapper(
                    "openai.resources.images",
                    "Images.generate",
                    _sync_images_wrapper,
                )
                wrapt.wrap_function_wrapper(
                    "openai.resources.images",
                    "AsyncImages.generate",
                    _async_images_wrapper,
                )
                logger.debug("OpenAI images.generate instrumented (sync + async)")
            except Exception as img_exc:
                logger.debug("Could not instrument OpenAI images: %s", img_exc)

            # Patch audio.transcriptions.create (sync + async) -- Whisper
            try:
                wrapt.wrap_function_wrapper(
                    "openai.resources.audio.transcriptions",
                    "Transcriptions.create",
                    _sync_transcriptions_wrapper,
                )
                wrapt.wrap_function_wrapper(
                    "openai.resources.audio.transcriptions",
                    "AsyncTranscriptions.create",
                    _async_transcriptions_wrapper,
                )
                logger.debug("OpenAI audio.transcriptions.create instrumented (sync + async)")
            except Exception as stt_exc:
                logger.debug("Could not instrument OpenAI audio transcriptions: %s", stt_exc)

            # Patch audio.speech.create (sync + async) -- TTS
            try:
                wrapt.wrap_function_wrapper(
                    "openai.resources.audio.speech",
                    "Speech.create",
                    _sync_speech_wrapper,
                )
                wrapt.wrap_function_wrapper(
                    "openai.resources.audio.speech",
                    "AsyncSpeech.create",
                    _async_speech_wrapper,
                )
                logger.debug("OpenAI audio.speech.create instrumented (sync + async)")
            except Exception as tts_exc:
                logger.debug("Could not instrument OpenAI audio speech: %s", tts_exc)

            # Patch responses.create (sync + async) -- Responses API
            try:
                wrapt.wrap_function_wrapper(
                    "openai.resources.responses",
                    "Responses.create",
                    _sync_responses_wrapper,
                )
                wrapt.wrap_function_wrapper(
                    "openai.resources.responses",
                    "AsyncResponses.create",
                    _async_responses_wrapper,
                )
                logger.debug("OpenAI responses.create instrumented (sync + async)")
            except Exception as resp_exc:
                logger.debug("Could not instrument OpenAI responses: %s", resp_exc)

            self._instrumented = True
            logger.debug("OpenAI chat.completions instrumented (sync + async)")
            return True
        except Exception as exc:
            logger.warning(
                "Failed to instrument OpenAI SDK (possibly incompatible version): %s",
                exc,
            )
            return False

    def uninstrument(self) -> None:
        """Restore original OpenAI SDK methods."""
        if not self._instrumented:
            return

        try:
            import openai.resources.chat.completions as mod

            # wrapt stores the original as __wrapped__
            if hasattr(mod.Completions.create, "__wrapped__"):
                mod.Completions.create = mod.Completions.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(mod.AsyncCompletions.create, "__wrapped__"):
                mod.AsyncCompletions.create = mod.AsyncCompletions.create.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        try:
            import openai.resources.embeddings as emb_mod

            if hasattr(emb_mod.Embeddings.create, "__wrapped__"):
                emb_mod.Embeddings.create = emb_mod.Embeddings.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(emb_mod.AsyncEmbeddings.create, "__wrapped__"):
                emb_mod.AsyncEmbeddings.create = emb_mod.AsyncEmbeddings.create.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        # Restore images.generate
        try:
            import openai.resources.images as img_mod

            if hasattr(img_mod.Images.generate, "__wrapped__"):
                img_mod.Images.generate = img_mod.Images.generate.__wrapped__  # type: ignore[attr-defined]
            if hasattr(img_mod.AsyncImages.generate, "__wrapped__"):
                img_mod.AsyncImages.generate = img_mod.AsyncImages.generate.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        # Restore audio.transcriptions.create
        try:
            import openai.resources.audio.transcriptions as stt_mod

            if hasattr(stt_mod.Transcriptions.create, "__wrapped__"):
                stt_mod.Transcriptions.create = stt_mod.Transcriptions.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(stt_mod.AsyncTranscriptions.create, "__wrapped__"):
                stt_mod.AsyncTranscriptions.create = stt_mod.AsyncTranscriptions.create.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        # Restore audio.speech.create
        try:
            import openai.resources.audio.speech as tts_mod

            if hasattr(tts_mod.Speech.create, "__wrapped__"):
                tts_mod.Speech.create = tts_mod.Speech.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(tts_mod.AsyncSpeech.create, "__wrapped__"):
                tts_mod.AsyncSpeech.create = tts_mod.AsyncSpeech.create.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        # Restore responses.create
        try:
            import openai.resources.responses as resp_mod

            if hasattr(resp_mod.Responses.create, "__wrapped__"):
                resp_mod.Responses.create = resp_mod.Responses.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(resp_mod.AsyncResponses.create, "__wrapped__"):
                resp_mod.AsyncResponses.create = resp_mod.AsyncResponses.create.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("OpenAI chat.completions uninstrumented")

    def is_instrumented(self) -> bool:
        """Return True if OpenAI SDK is currently patched."""
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers: inject stream_options for usage in streaming responses
# ---------------------------------------------------------------------------


def _inject_stream_options(kwargs: dict) -> dict:
    """Ensure ``stream_options={"include_usage": True}`` is set.

    OpenAI only returns usage data in the final streaming chunk when
    this option is explicitly requested.  We inject it transparently
    so the user doesn't have to.
    """
    stream_options = kwargs.get("stream_options")
    if stream_options is None:
        kwargs["stream_options"] = {"include_usage": True}
    elif isinstance(stream_options, dict):
        # Only set if the user hasn't explicitly disabled it
        if "include_usage" not in stream_options:
            stream_options["include_usage"] = True
    return kwargs


# ---------------------------------------------------------------------------
# Wrapper functions (module-level so wrapt can pickle/reference them)
# ---------------------------------------------------------------------------


_PROVIDER_MAP = {
    "api.together.xyz": "together",
    "together.ai": "together",
    "api.fireworks.ai": "fireworks",
    "openrouter.ai": "openrouter",
    "api.deepseek.com": "deepseek",
    "api.replicate.com": "replicate",
    "api.cerebras.ai": "cerebras",
    "api.sambanova.ai": "sambanova",
    "api.perplexity.ai": "perplexity",
    "api.groq.com": "groq",
    "api.mistral.ai": "mistral",
    "generativelanguage.googleapis.com": "google",
    "api.x.ai": "xai",
    "api.deepinfra.com": "deepinfra",
    "api.novita.ai": "novita",
    "api.siliconflow.cn": "siliconflow",
    "api.friendli.ai": "friendliai",
    # Phase 5 additions
    "api.studio.nebius.ai": "nebius",
    "api.baseten.co": "baseten",
    "api.cloudflare.com": "cloudflare",
    "lepton.run": "lepton",
    "modal.run": "modal",
    "api.runpod.ai": "runpod",
    "snowflakecomputing.com": "snowflake",
    "databricks.com": "databricks",
    "api.writer.com": "writer",
    "localhost": "local",
    "127.0.0.1": "local",
    "0.0.0.0": "local",
    "lmstudio": "lm_studio",
}


def _detect_provider(instance) -> str:
    """Detect the actual provider from the OpenAI client's base_url.

    Supports OpenAI-compatible providers (Together, Fireworks, DeepSeek,
    OpenRouter, Replicate, Groq, Mistral, etc.) by inspecting the
    client's configured base URL.  Falls back to ``"openai"`` for the
    standard OpenAI API or when detection fails.
    """
    try:
        # The ``instance`` is the Completions/AsyncCompletions resource,
        # which holds a ``_client`` back-reference to the top-level
        # OpenAI/AsyncOpenAI object.
        client = getattr(instance, "_client", None)
        if client is None:
            return "openai"

        base_url = str(
            getattr(client, "_base_url", getattr(client, "base_url", ""))
        )
        if not base_url or "api.openai.com" in base_url:
            return "openai"

        # Check the provider map
        for domain, provider in _PROVIDER_MAP.items():
            if domain in base_url:
                return provider

        # Azure OpenAI
        if "openai.azure.com" in base_url or "azure" in base_url.lower():
            return "azure_openai"

        # Also check client class name for Azure wrappers
        client_cls = type(client).__name__
        if "Azure" in client_cls:
            return "azure_openai"

        return "openai"
    except Exception:
        return "openai"


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Completions.create``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        # If our tracing infrastructure fails to import, just call through
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)
    provider = _detect_provider(instance)

    try:
        span = start_llm_span(model=model, provider_name=provider)
    except Exception:
        # Span creation failed -- call original unmodified
        return wrapped(*args, **kwargs)

    if is_streaming:
        # Streaming: wrap the response to capture tokens on completion
        kwargs = _inject_stream_options(kwargs)
        stream = wrapped(*args, **kwargs)
        try:
            from ._stream_wrappers import OpenAISyncStreamWrapper

            return OpenAISyncStreamWrapper(stream, span, model)
        except Exception:
            # Wrap failure -- return original stream so user code isn't affected
            try:
                span.end()
            except Exception:
                pass
            return stream

    # Non-streaming: full instrumentation
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in = getattr(response.usage, 'prompt_tokens', getattr(response.usage, 'input_tokens', 0)) if response.usage else 0
            tokens_out = getattr(response.usage, 'completion_tokens', getattr(response.usage, 'output_tokens', 0)) if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reasons = (
                [c.finish_reason for c in response.choices if c.finish_reason]
                if response.choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API (never breaks the LLM call)
        try:
            _record_http_openai(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncCompletions.create``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)
    provider = _detect_provider(instance)

    try:
        span = start_llm_span(model=model, provider_name=provider)
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        # Streaming: wrap the async response to capture tokens on completion
        kwargs = _inject_stream_options(kwargs)
        stream = await wrapped(*args, **kwargs)
        try:
            from ._stream_wrappers import OpenAIAsyncStreamWrapper

            return OpenAIAsyncStreamWrapper(stream, span, model)
        except Exception:
            # Wrap failure -- return original stream so user code isn't affected
            try:
                span.end()
            except Exception:
                pass
            return stream

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in = getattr(response.usage, 'prompt_tokens', getattr(response.usage, 'input_tokens', 0)) if response.usage else 0
            tokens_out = getattr(response.usage, 'completion_tokens', getattr(response.usage, 'output_tokens', 0)) if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reasons = (
                [c.finish_reason for c in response.choices if c.finish_reason]
                if response.choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API (never breaks the LLM call)
        try:
            _record_http_openai(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_openai(response, request_model: str, kwargs: dict) -> None:
    """Record an OpenAI LLM call to the HTTP path (context or collector).

    This function is called AFTER the LLM call succeeds and OTel span
    attributes are set.  It MUST NOT raise -- callers wrap it in
    try/except.
    """
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    tokens_in = getattr(response.usage, 'prompt_tokens', getattr(response.usage, 'input_tokens', 0)) if response.usage else 0
    tokens_out = getattr(response.usage, 'completion_tokens', getattr(response.usage, 'output_tokens', 0)) if response.usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    messages = kwargs.get("messages", [])
    prompt_preview = ""
    if messages:
        first_content = messages[0].get("content", "") if isinstance(messages[0], dict) else ""
        prompt_preview = str(first_content)[:500]

    response_preview = ""
    if response.choices:
        msg = response.choices[0].message
        if msg and msg.content:
            response_preview = msg.content[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat.completions",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data, provider="openai", _auto_instrumented=True)
    else:
        _collector.record_call(call_data)

    # Auto-capture tool calls + decisions from response
    try:
        if response.choices:
            msg = response.choices[0].message
            if msg and hasattr(msg, "tool_calls") and msg.tool_calls:
                from ._auto_decision import record_tool_decisions, extract_tool_names_from_request

                tool_calls = []
                for tc in msg.tool_calls:
                    if hasattr(tc, "type") and tc.type == "function" and hasattr(tc, "function"):
                        tool_calls.append({
                            "name": tc.function.name,
                            "input": tc.function.arguments if hasattr(tc.function, "arguments") else "",
                            "id": getattr(tc, "id", ""),
                        })
                available = extract_tool_names_from_request(kwargs)
                record_tool_decisions(tool_calls=tool_calls, available_tools=available or None)
    except Exception:
        pass  # Never break user code


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span, setting status to ERROR."""
    try:
        span.record_exception(exc)
        # Use lazy import for StatusCode to handle missing OTel
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        # OTel not available or span is NoOp -- that's fine
        pass


# ---------------------------------------------------------------------------
# Embeddings wrappers
# ---------------------------------------------------------------------------


def _sync_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Embeddings.create``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    provider = _detect_provider(instance)

    # Count inputs
    input_data = kwargs.get("input", "")
    if isinstance(input_data, str):
        input_count = 1
    elif isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=model, provider_name=provider, input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens = getattr(response.usage, "total_tokens", 0) if response.usage else 0
            dimensions = len(response.data[0].embedding) if response.data else 0
            cost = estimate_embedding_cost(model, tokens, provider)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_embedding(response, model, kwargs, provider)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncEmbeddings.create``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    provider = _detect_provider(instance)

    input_data = kwargs.get("input", "")
    if isinstance(input_data, str):
        input_count = 1
    elif isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=model, provider_name=provider, input_count=input_count)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens = getattr(response.usage, "total_tokens", 0) if response.usage else 0
            dimensions = len(response.data[0].embedding) if response.data else 0
            cost = estimate_embedding_cost(model, tokens, provider)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_embedding(response, model, kwargs, provider)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _record_http_embedding(response, model: str, kwargs: dict, provider: str = "") -> None:
    """Record an embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_embedding_cost

    tokens = getattr(response.usage, "total_tokens", 0) if response.usage else 0
    cost = estimate_embedding_cost(model, tokens, provider)

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embeddings",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data, provider="openai", _auto_instrumented=True)
    else:
        _collector.record_call(call_data)


def _record_http_openai_images(model: str, kwargs: dict, response) -> None:
    """Record an OpenAI image generation call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    prompt = str(kwargs.get("prompt", ""))[:500]
    n = kwargs.get("n", 1) or 1

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "images.generate",
        "prompt_preview": prompt,
        "response_preview": f"[{n} image(s) generated]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_openai_transcription(model: str, kwargs: dict, transcript_text: str) -> None:
    """Record an OpenAI audio transcription call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "audio.transcribe",
        "prompt_preview": f"[{model} transcription]",
        "response_preview": str(transcript_text)[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_openai_speech(model: str, kwargs: dict) -> None:
    """Record an OpenAI TTS speech call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    input_text = str(kwargs.get("input", ""))[:500]

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "audio.speech",
        "prompt_preview": input_text,
        "response_preview": f"[{model} audio generated]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# DALL-E 3 (Images) wrappers
# ---------------------------------------------------------------------------


def _sync_images_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Images.generate`` -- DALL-E 3 image generation."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "dall-e-3")
    prompt = str(kwargs.get("prompt", ""))
    size = kwargs.get("size", "")
    quality = kwargs.get("quality", "")
    n = kwargs.get("n", 1) or 1
    style = kwargs.get("style", "")

    try:
        span = start_step_span(step_name="openai.images.generate")
        span.set_attribute("waxell.openai.image_model", str(model))
        if size:
            span.set_attribute("waxell.openai.image_size", str(size))
        if quality:
            span.set_attribute("waxell.openai.image_quality", str(quality))
        span.set_attribute("waxell.openai.image_count", int(n))
        if style:
            span.set_attribute("waxell.openai.image_style", str(style))
        if prompt:
            span.set_attribute("waxell.openai.prompt_preview", prompt[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_openai_images(model, kwargs, response)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_images_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncImages.generate`` -- DALL-E 3 image generation."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "dall-e-3")
    prompt = str(kwargs.get("prompt", ""))
    size = kwargs.get("size", "")
    quality = kwargs.get("quality", "")
    n = kwargs.get("n", 1) or 1
    style = kwargs.get("style", "")

    try:
        span = start_step_span(step_name="openai.images.generate")
        span.set_attribute("waxell.openai.image_model", str(model))
        if size:
            span.set_attribute("waxell.openai.image_size", str(size))
        if quality:
            span.set_attribute("waxell.openai.image_quality", str(quality))
        span.set_attribute("waxell.openai.image_count", int(n))
        if style:
            span.set_attribute("waxell.openai.image_style", str(style))
        if prompt:
            span.set_attribute("waxell.openai.prompt_preview", prompt[:200])
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_openai_images(model, kwargs, response)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Whisper (Audio Transcription) wrappers
# ---------------------------------------------------------------------------


def _sync_transcriptions_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Transcriptions.create`` -- Whisper STT."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "whisper-1")
    language = kwargs.get("language", "")
    response_format = kwargs.get("response_format", "")

    try:
        span = start_step_span(step_name="openai.audio.transcribe")
        span.set_attribute("waxell.openai.whisper_model", str(model))
        if language:
            span.set_attribute("waxell.openai.language", str(language))
        if response_format:
            span.set_attribute("waxell.openai.response_format", str(response_format))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        # Extract transcript text for preview
        transcript_text = ""
        try:
            if isinstance(response, str):
                transcript_text = response
            elif hasattr(response, "text"):
                transcript_text = str(response.text)
            else:
                transcript_text = str(response)
        except Exception:
            pass

        try:
            if transcript_text:
                span.set_attribute("waxell.openai.transcript_preview", transcript_text[:200])
        except Exception:
            pass

        try:
            _record_http_openai_transcription(model, kwargs, transcript_text)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_transcriptions_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncTranscriptions.create`` -- Whisper STT."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "whisper-1")
    language = kwargs.get("language", "")
    response_format = kwargs.get("response_format", "")

    try:
        span = start_step_span(step_name="openai.audio.transcribe")
        span.set_attribute("waxell.openai.whisper_model", str(model))
        if language:
            span.set_attribute("waxell.openai.language", str(language))
        if response_format:
            span.set_attribute("waxell.openai.response_format", str(response_format))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        transcript_text = ""
        try:
            if isinstance(response, str):
                transcript_text = response
            elif hasattr(response, "text"):
                transcript_text = str(response.text)
            else:
                transcript_text = str(response)
        except Exception:
            pass

        try:
            if transcript_text:
                span.set_attribute("waxell.openai.transcript_preview", transcript_text[:200])
        except Exception:
            pass

        try:
            _record_http_openai_transcription(model, kwargs, transcript_text)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# TTS (Audio Speech) wrappers
# ---------------------------------------------------------------------------


def _sync_speech_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Speech.create`` -- OpenAI TTS."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "tts-1")
    voice = kwargs.get("voice", "")
    input_text = kwargs.get("input", "")
    speed = kwargs.get("speed", None)
    response_format = kwargs.get("response_format", "")

    try:
        span = start_step_span(step_name="openai.audio.speech")
        span.set_attribute("waxell.openai.tts_model", str(model))
        if voice:
            span.set_attribute("waxell.openai.voice", str(voice))
        if input_text:
            span.set_attribute("waxell.openai.text_length", len(str(input_text)))
        if speed is not None:
            span.set_attribute("waxell.openai.speed", float(speed))
        if response_format:
            span.set_attribute("waxell.openai.response_format", str(response_format))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_openai_speech(model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_speech_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncSpeech.create`` -- OpenAI TTS."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "tts-1")
    voice = kwargs.get("voice", "")
    input_text = kwargs.get("input", "")
    speed = kwargs.get("speed", None)
    response_format = kwargs.get("response_format", "")

    try:
        span = start_step_span(step_name="openai.audio.speech")
        span.set_attribute("waxell.openai.tts_model", str(model))
        if voice:
            span.set_attribute("waxell.openai.voice", str(voice))
        if input_text:
            span.set_attribute("waxell.openai.text_length", len(str(input_text)))
        if speed is not None:
            span.set_attribute("waxell.openai.speed", float(speed))
        if response_format:
            span.set_attribute("waxell.openai.response_format", str(response_format))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_openai_speech(model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Responses API wrappers
# ---------------------------------------------------------------------------


def _extract_tools_used(output) -> list[str]:
    """Extract tool types used from a Responses API output list.

    The output list can contain items of different types:
    - ResponseOutputMessage (type="message")
    - Items with type like "web_search_call", "file_search_call",
      "code_interpreter_call", "computer_call", etc.

    Returns a deduplicated list of tool type strings found.
    """
    tools: list[str] = []
    seen: set[str] = set()
    try:
        if not output:
            return tools
        for item in output:
            item_type = getattr(item, "type", "")
            if item_type and item_type != "message" and item_type not in seen:
                seen.add(item_type)
                tools.append(item_type)
    except Exception:
        pass
    return tools


def _extract_response_text(response) -> str:
    """Extract text content from a Responses API response for preview.

    Tries ``response.output_text`` first (convenience property), then
    falls back to iterating output items.
    """
    try:
        output_text = getattr(response, "output_text", None)
        if output_text:
            return str(output_text)[:500]
    except Exception:
        pass

    try:
        for item in (getattr(response, "output", None) or []):
            if getattr(item, "type", "") == "message":
                for part in (getattr(item, "content", None) or []):
                    text = getattr(part, "text", "")
                    if text:
                        return str(text)[:500]
    except Exception:
        pass

    return ""


def _extract_input_preview(input_data) -> str:
    """Extract a preview string from the Responses API input.

    Input can be a plain string or a list of message dicts/objects.
    """
    try:
        if isinstance(input_data, str):
            return input_data[:500]
        if isinstance(input_data, list) and input_data:
            first = input_data[0]
            if isinstance(first, dict):
                content = first.get("content", "")
                return str(content)[:500]
            elif hasattr(first, "content"):
                return str(first.content)[:500]
            else:
                return str(first)[:500]
    except Exception:
        pass
    return ""


def _sync_responses_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Responses.create`` -- OpenAI Responses API."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    provider = _detect_provider(instance)

    try:
        span = start_llm_span(model=model, provider_name=provider)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in = getattr(response.usage, "input_tokens", 0) if response.usage else 0
            tokens_out = getattr(response.usage, "output_tokens", 0) if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)
            response_status = getattr(response, "status", "")
            tools_used = _extract_tools_used(getattr(response, "output", None))

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, [response_status] if response_status else [])
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
            span.set_attribute("waxell.openai.api_type", "responses")
            if response_status:
                span.set_attribute("waxell.openai.response_status", response_status)
            if tools_used:
                span.set_attribute("waxell.openai.tools_used", tools_used)
        except Exception as attr_exc:
            logger.debug("Failed to set responses span attributes: %s", attr_exc)

        try:
            _record_http_openai_responses(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_responses_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncResponses.create`` -- OpenAI Responses API."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    provider = _detect_provider(instance)

    try:
        span = start_llm_span(model=model, provider_name=provider)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in = getattr(response.usage, "input_tokens", 0) if response.usage else 0
            tokens_out = getattr(response.usage, "output_tokens", 0) if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)
            response_status = getattr(response, "status", "")
            tools_used = _extract_tools_used(getattr(response, "output", None))

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, [response_status] if response_status else [])
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
            span.set_attribute("waxell.openai.api_type", "responses")
            if response_status:
                span.set_attribute("waxell.openai.response_status", response_status)
            if tools_used:
                span.set_attribute("waxell.openai.tools_used", tools_used)
        except Exception as attr_exc:
            logger.debug("Failed to set async responses span attributes: %s", attr_exc)

        try:
            _record_http_openai_responses(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _record_http_openai_responses(response, request_model: str, kwargs: dict) -> None:
    """Record an OpenAI Responses API call to the HTTP path (context or collector).

    Follows the same dual-path pattern as ``_record_http_openai``.
    """
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    tokens_in = getattr(response.usage, "input_tokens", 0) if response.usage else 0
    tokens_out = getattr(response.usage, "output_tokens", 0) if response.usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    input_data = kwargs.get("input", "")
    prompt_preview = _extract_input_preview(input_data)
    response_preview = _extract_response_text(response)

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "responses.create",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data, provider="openai", _auto_instrumented=True)
    else:
        _collector.record_call(call_data)
