"""AWS Polly auto-instrumentor for waxell-observe.

Monkey-patches ``botocore.client.BaseClient._make_api_call`` to intercept
Polly ``SynthesizeSpeech`` operations, emitting OTel step spans and recording
to the Waxell HTTP API.

AWS Polly SynthesizeSpeech API parameters:
  - ``VoiceId`` (str) -- e.g. "Joanna", "Matthew"
  - ``Engine`` (str) -- "standard" or "neural"
  - ``OutputFormat`` (str) -- "mp3", "ogg_vorbis", "pcm"
  - ``Text`` (str) -- the text to synthesize
  - ``LanguageCode`` (str) -- e.g. "en-US"

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Operations we instrument on Polly
_POLLY_OPERATIONS = {"SynthesizeSpeech"}


class AWSPollyInstrumentor(BaseInstrumentor):
    """Instrumentor for AWS Polly via boto3/botocore.

    Patches ``BaseClient._make_api_call`` and filters to polly
    ``SynthesizeSpeech`` operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import botocore.client  # noqa: F401
        except ImportError:
            logger.debug("botocore not installed -- skipping Polly instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Polly instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "botocore.client",
                "BaseClient._make_api_call",
                _api_call_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch botocore for Polly: %s", exc)
            return False

        self._instrumented = True
        logger.debug("AWS Polly instrumented via botocore")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import botocore.client as mod

            if hasattr(mod.BaseClient._make_api_call, "__wrapped__"):
                mod.BaseClient._make_api_call = mod.BaseClient._make_api_call.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("AWS Polly uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_polly_service(instance) -> bool:
    """Check if the botocore client is a Polly client."""
    try:
        service_model = getattr(instance, "_service_model", None)
        if service_model:
            service_name = getattr(service_model, "service_name", "")
            return service_name == "polly"
        # Fallback: check endpoint URL
        endpoint = getattr(instance, "_endpoint", None)
        if endpoint:
            host = str(getattr(endpoint, "host", ""))
            return "polly" in host
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# Wrapper function
# ---------------------------------------------------------------------------


def _api_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``BaseClient._make_api_call``.

    Only instruments Polly SynthesizeSpeech operations.
    All other API calls pass through untouched.
    """
    # args[0] = operation_name, args[1] = api_params
    operation_name = args[0] if args else kwargs.get("operation_name", "")
    api_params = args[1] if len(args) > 1 else kwargs.get("api_params", {})

    # Only instrument Polly operations we care about
    if operation_name not in _POLLY_OPERATIONS or not _is_polly_service(instance):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract parameters
    voice_id, engine, output_format, text_length, language = _extract_params(api_params)

    try:
        span = start_step_span(step_name="aws.polly.synthesize")
        _set_request_attrs(span, voice_id, engine, output_format, text_length, language)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.aws_polly.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "aws.polly.synthesize", voice_id, engine, output_format, text_length, language, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Parameter extraction
# ---------------------------------------------------------------------------


def _extract_params(api_params: dict) -> tuple:
    """Extract TTS parameters from Polly SynthesizeSpeech API params."""
    voice_id = str(api_params.get("VoiceId", ""))
    engine = str(api_params.get("Engine", ""))
    output_format = str(api_params.get("OutputFormat", ""))
    text = api_params.get("Text", "")
    text_length = len(str(text)) if text else 0
    language = str(api_params.get("LanguageCode", ""))

    return voice_id, engine, output_format, text_length, language


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_request_attrs(
    span,
    voice_id: str,
    engine: str,
    output_format: str,
    text_length: int,
    language: str,
) -> None:
    """Set request attributes for an AWS Polly span."""
    if voice_id:
        span.set_attribute("waxell.aws_polly.voice_id", voice_id)
    if engine:
        span.set_attribute("waxell.aws_polly.engine", engine)
    if output_format:
        span.set_attribute("waxell.aws_polly.output_format", output_format)
    if text_length:
        span.set_attribute("waxell.aws_polly.text_length", text_length)
    if language:
        span.set_attribute("waxell.aws_polly.language", language)


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tts_call(
    task: str,
    voice_id: str,
    engine: str,
    output_format: str,
    text_length: int,
    language: str,
    latency: float,
) -> None:
    """Record an AWS Polly TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": f"aws-polly-{engine}" if engine else "aws-polly",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[tts text_length={text_length} voice={voice_id} lang={language}]",
        "response_preview": f"[tts voice={voice_id} engine={engine} latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
