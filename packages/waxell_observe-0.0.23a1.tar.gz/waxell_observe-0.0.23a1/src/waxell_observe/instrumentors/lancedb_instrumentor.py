"""LanceDB auto-instrumentor for waxell-observe.

Monkey-patches LanceDB table search and add operations to emit
retrieval and tool spans.

Patched methods:
  - ``lancedb.table.LanceTable.search``  (retrieval span)
  - ``lancedb.table.LanceTable.add``     (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's LanceDB calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LanceDBInstrumentor(BaseInstrumentor):
    """Instrumentor for the LanceDB Python SDK (``lancedb`` package).

    Patches ``LanceTable.search`` for retrieval spans and ``LanceTable.add``
    for tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import lancedb  # noqa: F401
        except ImportError:
            logger.debug("lancedb package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping LanceDB instrumentation")
            return False

        patched_any = False

        # --- LanceTable.search ---
        try:
            wrapt.wrap_function_wrapper(
                "lancedb.table",
                "LanceTable.search",
                _search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch LanceTable.search: %s", exc)

        # --- LanceTable.add ---
        try:
            wrapt.wrap_function_wrapper(
                "lancedb.table",
                "LanceTable.add",
                _add_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch LanceTable.add: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any LanceDB LanceTable methods")
            return False

        self._instrumented = True
        logger.debug("LanceDB LanceTable instrumented (search, add)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import lancedb.table as table_mod

            cls = getattr(table_mod, "LanceTable", None)
            if cls is not None:
                for method_name in ("search", "add"):
                    method = getattr(cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("LanceDB LanceTable uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_table_name(instance) -> str:
    """Extract the table name from a LanceTable instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
        name = getattr(instance, "_name", None)
        if name:
            return str(name)
    except Exception:
        pass
    return ""


def _describe_query(args, kwargs) -> str:
    """Build a human-readable description of the search query.

    LanceTable.search(query) accepts a vector (list/ndarray), a string
    (for full-text search), or None (for scanning).
    """
    query = args[0] if args else kwargs.get("query", None)
    if query is None:
        return "<scan>"

    if isinstance(query, str):
        return query[:500]

    # Vector queries: don't log raw float arrays
    try:
        if hasattr(query, "__len__"):
            return f"<vector dim={len(query)}>"
    except Exception:
        pass

    return "<query>"


def _count_data(args, kwargs) -> int:
    """Count the number of records being added.

    LanceTable.add(data) accepts a list of dicts, a pandas DataFrame,
    or a pyarrow Table.
    """
    data = args[0] if args else kwargs.get("data", None)
    if data is None:
        return 0

    try:
        return len(data)
    except (TypeError, AttributeError):
        pass

    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for LanceTable.search (vector similarity search)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    table_name = _get_table_name(instance)
    query_desc = _describe_query(args, kwargs)
    query_preview = f"lancedb.search(table={table_name!r}, query={query_desc})"

    try:
        span = start_retrieval_span(query=query_preview, source="lancedb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            if table_name:
                span.set_attribute("waxell.retrieval.collection", table_name)
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("db.system", "lancedb")
        except Exception as attr_exc:
            logger.debug("Failed to set LanceDB search span attributes: %s", attr_exc)

        try:
            _record_lancedb_retrieval(query=query_preview, table_name=table_name)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _add_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for LanceTable.add (insert records)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    table_name = _get_table_name(instance)
    record_count = _count_data(args, kwargs)

    try:
        span = start_tool_span(tool_name="lancedb.add", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "add")
            span.set_attribute("waxell.vectordb.documents_written", record_count)
            if table_name:
                span.set_attribute("waxell.retrieval.collection", table_name)
            span.set_attribute("db.system", "lancedb")
        except Exception as attr_exc:
            logger.debug("Failed to set LanceDB add span attributes: %s", attr_exc)

        try:
            _record_lancedb_write(
                operation="add",
                record_count=record_count,
                table_name=table_name,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_lancedb_retrieval(
    query: str,
    table_name: str,
) -> None:
    """Record a LanceDB retrieval operation to the context path.

    LanceDB retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="lancedb",
        )


def _record_lancedb_write(
    operation: str,
    record_count: int,
    table_name: str,
) -> None:
    """Record a LanceDB write operation to the context path.

    Write operations are recorded as tool calls within an active WaxellContext.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"lancedb.{operation}",
            input={"record_count": record_count, "table_name": table_name},
            tool_type="vectordb",
        )
