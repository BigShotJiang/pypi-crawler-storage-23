"""DSPy auto-instrumentor for waxell-observe.

Monkey-patches ``dspy.Module.__call__`` and ``dspy.Predict.__call__``
to emit OTel spans and record to the Waxell HTTP API.

Module calls produce agent spans; Predict calls produce LLM spans.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class DSPyInstrumentor(BaseInstrumentor):
    """Instrumentor for the DSPy framework (``dspy`` package).

    Patches Module.__call__ and Predict.__call__.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import dspy  # noqa: F401
        except ImportError:
            logger.debug("dspy not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping DSPy instrumentation")
            return False

        patched = False

        # Patch Module.__call__
        try:
            wrapt.wrap_function_wrapper(
                "dspy",
                "Module.__call__",
                _module_call_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Module.__call__: %s", exc)

        # Patch Predict.__call__
        try:
            wrapt.wrap_function_wrapper(
                "dspy",
                "Predict.__call__",
                _predict_call_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Predict.__call__: %s", exc)

        if not patched:
            logger.debug("Could not find DSPy methods to patch")
            return False

        self._instrumented = True
        logger.debug("DSPy instrumented (Module.__call__ + Predict.__call__)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import dspy

            if hasattr(dspy.Module.__call__, "__wrapped__"):
                dspy.Module.__call__ = dspy.Module.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import dspy

            if hasattr(dspy.Predict.__call__, "__wrapped__"):
                dspy.Predict.__call__ = dspy.Predict.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("DSPy uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _module_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Module.__call__`` -- top-level DSPy module execution."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    class_name = type(instance).__name__

    try:
        span = start_agent_span(
            agent_name=class_name,
            workflow_name="dspy_module_call",
        )
        span.set_attribute("waxell.dspy.module_class", class_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    f"dspy_module:{class_name}",
                    output={"result_preview": str(result)[:200]},
                )
        except Exception:
            pass
        return result
    finally:
        span.end()


def _predict_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Predict.__call__`` -- DSPy prediction (LLM call)."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    predict_class = type(instance).__name__

    # Try to get the current model from dspy settings
    model_name = "unknown"
    try:
        import dspy

        lm = getattr(dspy.settings, "lm", None)
        if lm:
            model_name = getattr(lm, "model_name", None) or getattr(lm, "model", None) or "unknown"
    except Exception:
        pass

    try:
        span = start_llm_span(model=str(model_name), provider_name="dspy")
        span.set_attribute("waxell.dspy.predict_class", predict_class)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            from ._context_var import _current_context
            from ._collector import _collector

            call_data = {
                "model": str(model_name),
                "tokens_in": 0,
                "tokens_out": 0,
                "cost": 0.0,
                "task": f"dspy.predict:{predict_class}",
                "prompt_preview": "",
                "response_preview": str(result)[:500],
            }

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_llm_call(**call_data)
            else:
                _collector.record_call(call_data)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
