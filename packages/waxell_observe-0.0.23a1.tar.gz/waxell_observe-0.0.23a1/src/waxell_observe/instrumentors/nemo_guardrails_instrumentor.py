"""NeMo Guardrails auto-instrumentor for waxell-observe.

Monkey-patches nemoguardrails.RailsConfig and LLMRails.generate to emit
guardrail evaluation spans.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class NemoGuardrailsInstrumentor(BaseInstrumentor):
    """Instrumentor for NVIDIA NeMo Guardrails (``nemoguardrails`` package).

    Patches LLMRails.generate and LLMRails.generate_async.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import nemoguardrails  # noqa: F401
        except ImportError:
            logger.debug("nemoguardrails not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping NeMo Guardrails instrumentation")
            return False

        patched = False

        # Patch LLMRails.generate (sync generation with rails)
        try:
            wrapt.wrap_function_wrapper(
                "nemoguardrails.rails.llm.llmrails",
                "LLMRails.generate",
                _generate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch LLMRails.generate: %s", exc)

        # Patch LLMRails.generate_async (async version)
        try:
            wrapt.wrap_function_wrapper(
                "nemoguardrails.rails.llm.llmrails",
                "LLMRails.generate_async",
                _generate_async_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch LLMRails.generate_async: %s", exc)

        if not patched:
            logger.debug("Could not find NeMo Guardrails methods to patch")
            return False

        self._instrumented = True
        logger.debug("NeMo Guardrails instrumented (LLMRails.generate + generate_async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from nemoguardrails.rails.llm.llmrails import LLMRails

            if hasattr(LLMRails.generate, "__wrapped__"):
                LLMRails.generate = LLMRails.generate.__wrapped__
            if hasattr(getattr(LLMRails, "generate_async", None), "__wrapped__"):
                LLMRails.generate_async = LLMRails.generate_async.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("NeMo Guardrails uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``LLMRails.generate``."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    rails_name = _get_rails_name(instance)

    try:
        span = start_guardrail_span(
            guardrail_name=rails_name,
            framework="nemo_guardrails",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_rails_result(span, instance, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _generate_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``LLMRails.generate_async``."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return await wrapped(*args, **kwargs)

    rails_name = _get_rails_name(instance)

    try:
        span = start_guardrail_span(
            guardrail_name=rails_name,
            framework="nemo_guardrails",
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_rails_result(span, instance, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_rails_name(instance) -> str:
    """Extract a human-readable name from the LLMRails instance."""
    try:
        config = getattr(instance, "config", None)
        if config is not None:
            model = getattr(config, "model", None)
            if model:
                return f"nemo_rails:{model}"
        return "nemo_rails"
    except Exception:
        return "nemo_rails"


def _record_rails_result(span, instance, result) -> None:
    """Extract rails results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    # Determine if generation passed without rail triggers
    passed = True
    rails_triggered: list[str] = []
    action = "allow"

    try:
        # NeMo Guardrails response can be a dict or an object
        if isinstance(result, dict):
            # Check for blocked/redirected responses
            log = result.get("log", None)
            output = result.get("content", "") or result.get("response", "")
        else:
            log = getattr(result, "log", None)
            output = getattr(result, "content", "") or getattr(result, "response", "")

        # Try to extract triggered rails from the log
        if log is not None:
            activated_rails = []
            try:
                if isinstance(log, dict):
                    activated_rails = log.get("activated_rails", [])
                else:
                    activated_rails = getattr(log, "activated_rails", [])
            except Exception:
                pass

            for rail in activated_rails:
                try:
                    rail_type = ""
                    if isinstance(rail, dict):
                        rail_type = rail.get("type", "")
                    else:
                        rail_type = getattr(rail, "type", "")
                    if rail_type:
                        rails_triggered.append(str(rail_type))
                except Exception:
                    pass

        # Determine action based on rails behavior
        if rails_triggered:
            passed = False
            # Check if output was blocked or redirected
            blocked_indicators = ("I'm sorry", "I cannot", "I can't", "not allowed")
            if output and any(indicator in str(output) for indicator in blocked_indicators):
                action = "block"
            else:
                action = "redirect"
        else:
            passed = True
            action = "allow"

    except Exception:
        pass

    try:
        span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, passed)
        span.set_attribute(WaxellAttributes.GUARDRAIL_ACTION, action)
        if rails_triggered:
            span.set_attribute("waxell.guardrail.rails_triggered", rails_triggered)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_rails(instance, result, passed, action, rails_triggered)
    except Exception:
        pass


def _record_http_rails(instance, result, passed: bool, action: str, rails_triggered: list[str]) -> None:
    """Record a NeMo Guardrails evaluation to the HTTP path."""
    from ._context_var import _current_context

    rails_name = _get_rails_name(instance)

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"guardrail:{rails_name}",
            output={
                "passed": passed,
                "action": action,
                "rails_triggered": rails_triggered,
                "result_preview": str(result)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
