"""Arize Phoenix auto-instrumentor for waxell-observe.

Monkey-patches ``phoenix.session.Session`` launch, trace/span creation
via ``phoenix.trace``, and evaluation runs via ``phoenix.evals`` to
emit step and guardrail spans tracking observability and eval operations.

Arize Phoenix (``arize-phoenix``) is an open-source observability tool for
LLM applications that provides tracing, evaluation, and dataset management.
This instrumentor captures Phoenix's own tracing and evaluation operations
as Waxell spans for unified observability.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ArizePhoenixInstrumentor(BaseInstrumentor):
    """Instrumentor for Arize Phoenix (``arize-phoenix`` package).

    Patches ``px.launch_app()``, trace utilities, and evaluation methods.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import phoenix  # noqa: F401
        except ImportError:
            logger.debug("phoenix (arize-phoenix) package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Arize Phoenix instrumentation")
            return False

        patched = False

        # Patch px.launch_app()
        try:
            wrapt.wrap_function_wrapper(
                "phoenix",
                "launch_app",
                _launch_app_wrapper,
            )
            patched = True
            logger.debug("phoenix.launch_app patched")
        except Exception as exc:
            logger.debug("Failed to patch phoenix.launch_app: %s", exc)

        # Patch phoenix.evals.run_evals if available
        try:
            wrapt.wrap_function_wrapper(
                "phoenix.evals",
                "run_evals",
                _run_evals_wrapper,
            )
            patched = True
            logger.debug("phoenix.evals.run_evals patched")
        except Exception as exc:
            logger.debug("Failed to patch phoenix.evals.run_evals: %s", exc)

        # Patch phoenix.evals.llm_classify if available
        try:
            wrapt.wrap_function_wrapper(
                "phoenix.evals",
                "llm_classify",
                _llm_classify_wrapper,
            )
            patched = True
            logger.debug("phoenix.evals.llm_classify patched")
        except Exception as exc:
            logger.debug("Failed to patch phoenix.evals.llm_classify: %s", exc)

        # Patch phoenix.trace.trace_span or using_project if available
        try:
            wrapt.wrap_function_wrapper(
                "phoenix.trace",
                "using_project",
                _using_project_wrapper,
            )
            patched = True
            logger.debug("phoenix.trace.using_project patched")
        except Exception as exc:
            logger.debug("Failed to patch phoenix.trace.using_project: %s", exc)

        if not patched:
            logger.debug("Could not find any Arize Phoenix methods to patch")
            return False

        self._instrumented = True
        logger.debug("Arize Phoenix instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import phoenix

            if hasattr(getattr(phoenix, "launch_app", None), "__wrapped__"):
                phoenix.launch_app = phoenix.launch_app.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import phoenix.evals as evals_module

            for attr in ("run_evals", "llm_classify"):
                method = getattr(evals_module, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(evals_module, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        try:
            import phoenix.trace as trace_module

            if hasattr(getattr(trace_module, "using_project", None), "__wrapped__"):
                trace_module.using_project = trace_module.using_project.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Arize Phoenix uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _launch_app_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``px.launch_app()`` -- Phoenix session initialization."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="phoenix.launch_app")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "arize_phoenix")
        span.set_attribute("waxell.phoenix.operation", "launch_app")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Extract session info
            session_url = getattr(result, "url", "") or ""
            if session_url:
                span.set_attribute("waxell.phoenix.session_url", str(session_url)[:500])
        except Exception:
            pass

        return result
    finally:
        span.end()


def _run_evals_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``phoenix.evals.run_evals`` -- batch evaluation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract eval config
    dataframe = args[0] if args else kwargs.get("dataframe", None)
    evaluators = args[1] if len(args) > 1 else kwargs.get("evaluators", [])
    dataset_size = 0
    evaluators_count = 0

    try:
        if dataframe is not None:
            dataset_size = len(dataframe)
    except Exception:
        pass

    try:
        evaluators_count = len(evaluators) if isinstance(evaluators, (list, tuple)) else 1
    except Exception:
        pass

    try:
        span = start_step_span(step_name="phoenix.run_evals")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "arize_phoenix")
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, dataset_size)
        span.set_attribute(WaxellAttributes.EVAL_METRICS_COUNT, evaluators_count)
        span.set_attribute("waxell.phoenix.operation", "run_evals")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_evals_result(span, result, dataset_size, evaluators_count)
        except Exception:
            pass

        try:
            _record_http_phoenix_eval(result, dataset_size, evaluators_count, "run_evals")
        except Exception:
            pass

        return result
    finally:
        span.end()


def _llm_classify_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``phoenix.evals.llm_classify`` -- LLM-based classification eval."""
    try:
        from ..tracing.spans import start_guardrail_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    dataframe = args[0] if args else kwargs.get("dataframe", None)
    model = args[1] if len(args) > 1 else kwargs.get("model", None)
    template = kwargs.get("template", None)

    dataset_size = 0
    try:
        if dataframe is not None:
            dataset_size = len(dataframe)
    except Exception:
        pass

    model_name = ""
    try:
        model_name = str(getattr(model, "model_name", "") or getattr(model, "model", "") or model or "")[:200]
    except Exception:
        pass

    try:
        span = start_guardrail_span(
            guardrail_name="phoenix.llm_classify",
            framework="arize_phoenix",
        )
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "arize_phoenix")
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, dataset_size)
        span.set_attribute("waxell.phoenix.operation", "llm_classify")
        if model_name:
            span.set_attribute("waxell.phoenix.eval_model", model_name)
        if template is not None:
            span.set_attribute("waxell.eval.prompt_template", str(template)[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Result is typically a DataFrame with classification labels
            result_count = len(result) if result is not None else 0
            span.set_attribute("waxell.phoenix.result_count", result_count)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _using_project_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``phoenix.trace.using_project`` -- project context."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    project_name = args[0] if args else kwargs.get("project_name", "default")

    try:
        span = start_step_span(step_name=f"phoenix.project:{project_name}")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "arize_phoenix")
        span.set_attribute("waxell.phoenix.operation", "using_project")
        span.set_attribute("waxell.phoenix.project_name", str(project_name)[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_evals_result(span, result, dataset_size: int, evaluators_count: int) -> None:
    """Extract evaluation results from phoenix.evals.run_evals output."""

    try:
        # Result is typically a list of DataFrames (one per evaluator)
        if isinstance(result, (list, tuple)):
            for idx, eval_result in enumerate(result):
                try:
                    if hasattr(eval_result, "columns"):
                        # DataFrame result -- check for label/score columns
                        cols = list(eval_result.columns)
                        if "label" in cols:
                            labels = eval_result["label"].value_counts().to_dict()
                            span.set_attribute(
                                f"waxell.phoenix.eval_{idx}_labels",
                                str(labels)[:500],
                            )
                except Exception:
                    pass
    except Exception:
        pass


def _record_http_phoenix_eval(result, dataset_size: int, evaluators_count: int,
                               operation: str) -> None:
    """Record a Phoenix eval to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"eval:phoenix.{operation}",
            output={
                "framework": "arize_phoenix",
                "dataset_size": dataset_size,
                "evaluators_count": evaluators_count,
                "result_preview": str(result)[:500],
            },
        )


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
