"""Meta Llama Stack auto-instrumentor for waxell-observe.

Monkey-patches ``llama_stack_client.LlamaStackClient.inference`` methods
(chat_completion, completion, embeddings) and agent methods (agents.create,
agents.session.create) to emit OTel spans and record to the Waxell HTTP API.

Llama Stack is Meta's standardized interface for building applications with
Llama models, providing inference, agents, safety, and memory APIs.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LlamaStackInstrumentor(BaseInstrumentor):
    """Instrumentor for Meta Llama Stack (``llama-stack-client`` package).

    Patches inference.chat_completion, inference.completion,
    inference.embeddings for LLM calls, and agents.create,
    agents.session.create for agent operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import llama_stack_client  # noqa: F401
        except ImportError:
            logger.debug("llama_stack_client not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Llama Stack instrumentation")
            return False

        patched = False

        # Patch inference.chat_completion
        try:
            wrapt.wrap_function_wrapper(
                "llama_stack_client.resources.inference",
                "InferenceResource.chat_completion",
                _chat_completion_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch inference.chat_completion: %s", exc)

        # Patch inference.completion
        try:
            wrapt.wrap_function_wrapper(
                "llama_stack_client.resources.inference",
                "InferenceResource.completion",
                _completion_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch inference.completion: %s", exc)

        # Patch inference.embeddings
        try:
            wrapt.wrap_function_wrapper(
                "llama_stack_client.resources.inference",
                "InferenceResource.embeddings",
                _embeddings_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch inference.embeddings: %s", exc)

        # Patch agents.create
        try:
            wrapt.wrap_function_wrapper(
                "llama_stack_client.resources.agents",
                "AgentsResource.create",
                _agent_create_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch agents.create: %s", exc)

        # Patch agents.session.create
        try:
            wrapt.wrap_function_wrapper(
                "llama_stack_client.resources.agents.session",
                "SessionResource.create",
                _agent_session_create_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch agents.session.create: %s", exc)

        if not patched:
            logger.debug("Could not find Llama Stack methods to patch")
            return False

        self._instrumented = True
        logger.debug("Llama Stack instrumented (inference + agents)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore inference methods
        try:
            from llama_stack_client.resources.inference import InferenceResource

            for method_name in ("chat_completion", "completion", "embeddings"):
                method = getattr(InferenceResource, method_name, None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(InferenceResource, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore agents.create
        try:
            from llama_stack_client.resources.agents import AgentsResource

            if hasattr(getattr(AgentsResource, "create", None), "__wrapped__"):
                AgentsResource.create = AgentsResource.create.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore agents.session.create
        try:
            from llama_stack_client.resources.agents.session import SessionResource

            if hasattr(getattr(SessionResource, "create", None), "__wrapped__"):
                SessionResource.create = SessionResource.create.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Llama Stack uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _chat_completion_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``inference.chat_completion`` -- LLM chat completion."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _extract_model_from_kwargs(kwargs)
    messages = kwargs.get("messages", [])

    try:
        span = start_llm_span(
            model=model_name,
            provider_name="llama_stack",
        )
        span.set_attribute("gen_ai.provider.name", "llama_stack")
        span.set_attribute("waxell.agent.framework", "llama_stack")
        span.set_attribute("waxell.llama_stack.operation", "chat_completion")
        if messages:
            span.set_attribute("waxell.llama_stack.message_count", len(messages))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_chat_result_attributes(span, result, model_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _completion_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``inference.completion`` -- LLM text completion."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _extract_model_from_kwargs(kwargs)

    try:
        span = start_llm_span(
            model=model_name,
            provider_name="llama_stack",
        )
        span.set_attribute("gen_ai.provider.name", "llama_stack")
        span.set_attribute("waxell.agent.framework", "llama_stack")
        span.set_attribute("waxell.llama_stack.operation", "completion")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_completion_result_attributes(span, result, model_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _embeddings_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``inference.embeddings`` -- embedding generation."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _extract_model_from_kwargs(kwargs)
    contents = kwargs.get("contents", [])

    try:
        span = start_llm_span(
            model=model_name,
            provider_name="llama_stack",
        )
        span.set_attribute("gen_ai.provider.name", "llama_stack")
        span.set_attribute("waxell.agent.framework", "llama_stack")
        span.set_attribute("waxell.llama_stack.operation", "embeddings")
        if contents:
            span.set_attribute("waxell.llama_stack.input_count", len(contents))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_embeddings_result_attributes(span, result, model_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_create_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``agents.create`` -- agent creation."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_config = kwargs.get("agent_config", {})
    agent_name = ""
    model_name = ""
    try:
        if isinstance(agent_config, dict):
            agent_name = agent_config.get("name", "") or agent_config.get("agent_name", "")
            model_name = agent_config.get("model", "")
        else:
            agent_name = getattr(agent_config, "name", "") or getattr(agent_config, "agent_name", "")
            model_name = getattr(agent_config, "model", "")
    except Exception:
        pass

    agent_name = agent_name or "llama_stack.agent"

    try:
        span = start_agent_span(
            agent_name=str(agent_name),
            workflow_name="llama_stack_agent_create",
        )
        span.set_attribute("gen_ai.provider.name", "llama_stack")
        span.set_attribute("waxell.agent.framework", "llama_stack")
        span.set_attribute("waxell.agent.name", str(agent_name))
        span.set_attribute("waxell.llama_stack.operation", "agent_create")
        if model_name:
            span.set_attribute("waxell.llama_stack.model", str(model_name))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_agent_create_result_attributes(span, result, str(agent_name))
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_session_create_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``agents.session.create`` -- session creation."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_id = kwargs.get("agent_id", "") or (args[0] if args else "")

    try:
        span = start_agent_span(
            agent_name=str(agent_id) or "llama_stack.session",
            workflow_name="llama_stack_session_create",
        )
        span.set_attribute("gen_ai.provider.name", "llama_stack")
        span.set_attribute("waxell.agent.framework", "llama_stack")
        span.set_attribute("waxell.llama_stack.operation", "session_create")
        if agent_id:
            span.set_attribute("waxell.llama_stack.agent_id", str(agent_id))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            session_id = getattr(result, "session_id", None)
            if session_id:
                span.set_attribute("waxell.llama_stack.session_id", str(session_id))
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_model_from_kwargs(kwargs) -> str:
    """Extract model name from kwargs."""
    try:
        model = kwargs.get("model", None) or kwargs.get("model_id", "")
        if model:
            return str(model)
    except Exception:
        pass
    return "llama_stack"


def _set_chat_result_attributes(span, result, model_name: str) -> None:
    """Set result attributes on the span for chat completion."""
    try:
        # Extract completion message content
        completion_message = getattr(result, "completion_message", None)
        if completion_message:
            content = getattr(completion_message, "content", None)
            if content:
                span.set_attribute("waxell.llama_stack.response_preview", str(content)[:200])
            stop_reason = getattr(completion_message, "stop_reason", None)
            if stop_reason:
                span.set_attribute("waxell.llama_stack.stop_reason", str(stop_reason))

        # Extract token usage
        usage = getattr(result, "usage", None) or getattr(result, "logprobs", None)
        if usage:
            input_tokens = getattr(usage, "prompt_tokens", None) or getattr(usage, "input_tokens", None)
            output_tokens = getattr(usage, "completion_tokens", None) or getattr(usage, "output_tokens", None)
            if input_tokens is not None:
                span.set_attribute("waxell.llama_stack.input_tokens", int(input_tokens))
            if output_tokens is not None:
                span.set_attribute("waxell.llama_stack.output_tokens", int(output_tokens))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                completion_message = getattr(result, "completion_message", None)
                if completion_message:
                    content = getattr(completion_message, "content", "")
                    result_preview = str(content)[:500]
            except Exception:
                pass
            ctx.record_step(
                "llm:llama_stack.chat_completion",
                output={"model": model_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_completion_result_attributes(span, result, model_name: str) -> None:
    """Set result attributes on the span for text completion."""
    try:
        content = getattr(result, "content", None) or getattr(result, "completion_text", None)
        if content:
            span.set_attribute("waxell.llama_stack.response_preview", str(content)[:200])

        stop_reason = getattr(result, "stop_reason", None)
        if stop_reason:
            span.set_attribute("waxell.llama_stack.stop_reason", str(stop_reason))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                content = getattr(result, "content", None) or getattr(result, "completion_text", "")
                result_preview = str(content)[:500]
            except Exception:
                pass
            ctx.record_step(
                "llm:llama_stack.completion",
                output={"model": model_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_embeddings_result_attributes(span, result, model_name: str) -> None:
    """Set result attributes on the span for embeddings."""
    try:
        embeddings = getattr(result, "embeddings", None)
        if embeddings:
            span.set_attribute("waxell.llama_stack.embedding_count", len(embeddings))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            count = 0
            try:
                embeddings = getattr(result, "embeddings", None)
                if embeddings:
                    count = len(embeddings)
            except Exception:
                pass
            ctx.record_step(
                "llm:llama_stack.embeddings",
                output={"model": model_name, "embedding_count": count},
            )
    except Exception:
        pass


def _set_agent_create_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span for agent creation."""
    try:
        agent_id = getattr(result, "agent_id", None)
        if agent_id:
            span.set_attribute("waxell.llama_stack.agent_id", str(agent_id))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            agent_id = ""
            try:
                agent_id = str(getattr(result, "agent_id", "") or "")
            except Exception:
                pass
            ctx.record_step(
                "agent:llama_stack.create",
                output={"agent_name": agent_name, "agent_id": agent_id},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
