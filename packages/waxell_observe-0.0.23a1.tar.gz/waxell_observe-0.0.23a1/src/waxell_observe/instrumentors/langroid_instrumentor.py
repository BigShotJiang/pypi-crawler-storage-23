"""Langroid auto-instrumentor for waxell-observe.

Monkey-patches ``langroid.agent.ChatAgent.llm_response`` and
``langroid.agent.task.Task.run`` to emit OTel spans and record
to the Waxell HTTP API.

Langroid is a multi-agent framework for building LLM-powered applications
with ChatAgent, Task, and Tool abstractions.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LangroidInstrumentor(BaseInstrumentor):
    """Instrumentor for the Langroid framework (``langroid`` package).

    Patches ChatAgent.llm_response for LLM calls and Task.run for
    task execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import langroid  # noqa: F401
        except ImportError:
            logger.debug("langroid not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Langroid instrumentation")
            return False

        patched = False

        # Patch ChatAgent.llm_response
        try:
            wrapt.wrap_function_wrapper(
                "langroid.agent",
                "ChatAgent.llm_response",
                _llm_response_wrapper,
            )
            patched = True
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "langroid.agent.chat_agent",
                    "ChatAgent.llm_response",
                    _llm_response_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch langroid ChatAgent.llm_response: %s", exc)

        # Patch Task.run
        try:
            wrapt.wrap_function_wrapper(
                "langroid.agent.task",
                "Task.run",
                _task_run_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch langroid.agent.task.Task.run: %s", exc)

        if not patched:
            logger.debug("Could not find Langroid methods to patch")
            return False

        self._instrumented = True
        logger.debug("Langroid instrumented (ChatAgent.llm_response + Task.run)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore ChatAgent.llm_response
        try:
            from langroid.agent import ChatAgent

            if hasattr(getattr(ChatAgent, "llm_response", None), "__wrapped__"):
                ChatAgent.llm_response = ChatAgent.llm_response.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from langroid.agent.chat_agent import ChatAgent

            if hasattr(getattr(ChatAgent, "llm_response", None), "__wrapped__"):
                ChatAgent.llm_response = ChatAgent.llm_response.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore Task.run
        try:
            from langroid.agent.task import Task

            if hasattr(getattr(Task, "run", None), "__wrapped__"):
                Task.run = Task.run.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Langroid uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _llm_response_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ChatAgent.llm_response`` -- LLM response generation."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = _extract_agent_name(instance)
    model_name = _extract_model_name(instance)

    # Extract message content preview from args
    message_preview = ""
    try:
        if args:
            msg = args[0]
            content = getattr(msg, "content", None) or str(msg)
            message_preview = str(content)[:200]
        elif "message" in kwargs:
            msg = kwargs["message"]
            content = getattr(msg, "content", None) or str(msg)
            message_preview = str(content)[:200]
    except Exception:
        pass

    try:
        span = start_llm_span(
            model=model_name or "langroid",
            provider_name="langroid",
        )
        span.set_attribute("waxell.agent.framework", "langroid")
        span.set_attribute("waxell.agent.name", agent_name)
        span.set_attribute("waxell.langroid.operation", "llm_response")
        if model_name:
            span.set_attribute("waxell.langroid.model", model_name)
        if message_preview:
            span.set_attribute("waxell.langroid.input_preview", message_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_llm_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _task_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Task.run`` -- Langroid task execution."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    task_name = _extract_task_name(instance)
    agent_name = _extract_task_agent_name(instance)

    try:
        span = start_agent_span(
            agent_name=agent_name or task_name,
            workflow_name="langroid_task_run",
        )
        span.set_attribute("waxell.agent.framework", "langroid")
        span.set_attribute("waxell.agent.name", agent_name or task_name)
        span.set_attribute("waxell.langroid.task_name", task_name)
        span.set_attribute("waxell.langroid.operation", "task_run")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_task_result_attributes(span, result, task_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_agent_name(instance) -> str:
    """Extract agent name from a Langroid ChatAgent instance."""
    try:
        config = getattr(instance, "config", None)
        if config:
            name = getattr(config, "name", None)
            if name:
                return str(name)
    except Exception:
        pass
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "langroid.agent"


def _extract_model_name(instance) -> str:
    """Extract model name from a Langroid ChatAgent instance."""
    try:
        config = getattr(instance, "config", None)
        if config:
            llm = getattr(config, "llm", None)
            if llm:
                chat_model = getattr(llm, "chat_model", None)
                if chat_model:
                    return str(chat_model)
    except Exception:
        pass
    try:
        llm = getattr(instance, "llm", None)
        if llm:
            model_name = getattr(llm, "model_name", None) or getattr(llm, "model", None)
            if model_name:
                return str(model_name)
    except Exception:
        pass
    return ""


def _extract_task_name(instance) -> str:
    """Extract task name from a Langroid Task instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "langroid.task"


def _extract_task_agent_name(instance) -> str:
    """Extract agent name from a Langroid Task instance."""
    try:
        agent = getattr(instance, "agent", None)
        if agent:
            return _extract_agent_name(agent)
    except Exception:
        pass
    return ""


def _set_llm_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span for LLM response."""
    try:
        # Langroid ChatDocument has .content
        content = getattr(result, "content", None)
        if content:
            span.set_attribute("waxell.langroid.response_preview", str(content)[:200])

        # Extract metadata if available
        metadata = getattr(result, "metadata", None)
        if metadata:
            if isinstance(metadata, dict):
                input_tokens = metadata.get("input_tokens") or metadata.get("prompt_tokens")
                output_tokens = metadata.get("output_tokens") or metadata.get("completion_tokens")
                if input_tokens is not None:
                    span.set_attribute("waxell.langroid.input_tokens", int(input_tokens))
                if output_tokens is not None:
                    span.set_attribute("waxell.langroid.output_tokens", int(output_tokens))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                content = getattr(result, "content", None)
                if content:
                    result_preview = str(content)[:500]
            except Exception:
                pass
            ctx.record_step(
                "llm:langroid.llm_response",
                output={"agent_name": agent_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _set_task_result_attributes(span, result, task_name: str) -> None:
    """Set result attributes on the span for task execution."""
    try:
        # Langroid Task.run returns a ChatDocument
        content = getattr(result, "content", None)
        if content:
            span.set_attribute("waxell.langroid.response_preview", str(content)[:200])
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                content = getattr(result, "content", None)
                if content:
                    result_preview = str(content)[:500]
            except Exception:
                pass
            ctx.record_step(
                "agent:langroid.task_run",
                output={"task_name": task_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
