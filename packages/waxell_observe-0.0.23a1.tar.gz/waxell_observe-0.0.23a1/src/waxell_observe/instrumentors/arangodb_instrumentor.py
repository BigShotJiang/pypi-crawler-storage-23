"""ArangoDB auto-instrumentor for waxell-observe.

Monkey-patches python-arango AQL execute, StandardCollection insert, and
StandardCollection find methods to emit retrieval and tool spans.

Patched methods:
  - ``arango.aql.AQL.execute``                    (retrieval span for AQL queries)
  - ``arango.collection.StandardCollection.insert``  (tool span for inserts)
  - ``arango.collection.StandardCollection.find``    (retrieval span for finds)

All wrapper code is wrapped in try/except -- never breaks the user's ArangoDB calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ArangoDBInstrumentor(BaseInstrumentor):
    """Instrumentor for the python-arango driver.

    Patches ``AQL.execute`` for AQL queries, ``StandardCollection.insert``
    for document inserts, and ``StandardCollection.find`` for document finds.
    Query and find operations get retrieval spans; inserts get tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import arango  # noqa: F401
        except ImportError:
            logger.debug("python-arango package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping ArangoDB instrumentation")
            return False

        patched_any = False

        # --- AQL.execute ---
        try:
            wrapt.wrap_function_wrapper(
                "arango.aql",
                "AQL.execute",
                _sync_aql_execute_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch arango AQL.execute: %s", exc)

        # --- StandardCollection.insert ---
        try:
            wrapt.wrap_function_wrapper(
                "arango.collection",
                "StandardCollection.insert",
                _sync_insert_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch arango StandardCollection.insert: %s", exc)

        # --- StandardCollection.find ---
        try:
            wrapt.wrap_function_wrapper(
                "arango.collection",
                "StandardCollection.find",
                _sync_find_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch arango StandardCollection.find: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any arango methods")
            return False

        self._instrumented = True
        logger.debug("ArangoDB instrumented (AQL.execute, StandardCollection.insert, StandardCollection.find)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore AQL.execute
        try:
            from arango.aql import AQL

            method = getattr(AQL, "execute", None)
            if method is not None and hasattr(method, "__wrapped__"):
                AQL.execute = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore StandardCollection.insert
        try:
            from arango.collection import StandardCollection

            method = getattr(StandardCollection, "insert", None)
            if method is not None and hasattr(method, "__wrapped__"):
                StandardCollection.insert = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore StandardCollection.find
        try:
            from arango.collection import StandardCollection

            method = getattr(StandardCollection, "find", None)
            if method is not None and hasattr(method, "__wrapped__"):
                StandardCollection.find = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("ArangoDB uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_aql_query(args, kwargs) -> str:
    """Extract the AQL query string from positional or keyword args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _truncate_query(query: str, max_len: int = 200) -> str:
    """Truncate an AQL query for span labelling."""
    if len(query) > max_len:
        return query[:max_len] + "..."
    return query


def _extract_collection_name(instance) -> str:
    """Extract the collection name from a StandardCollection instance."""
    try:
        if hasattr(instance, "name"):
            return str(instance.name)
        if hasattr(instance, "_name"):
            return str(instance._name)
    except Exception:
        pass
    return ""


def _extract_bind_vars_count(kwargs) -> int:
    """Extract the count of bind variables from kwargs."""
    try:
        bind_vars = kwargs.get("bind_vars", None)
        if bind_vars and isinstance(bind_vars, dict):
            return len(bind_vars)
    except Exception:
        pass
    return 0


def _extract_result_count(response) -> int:
    """Extract result count from an ArangoDB cursor response."""
    # Try ArangoDB cursor .count() (no-arg method) first
    try:
        if hasattr(response, "count") and callable(response.count):
            result = response.count()
            if isinstance(result, int):
                return result
    except Exception:
        pass
    # Try .count as a property
    try:
        if hasattr(response, "count") and not callable(response.count):
            return int(response.count)
    except Exception:
        pass
    # Fallback to __len__
    try:
        if hasattr(response, "__len__"):
            return len(response)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_aql_execute_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for arango AQL.execute -- instruments AQL queries."""
    query = _extract_aql_query(args, kwargs)
    return _sync_aql_path(wrapped, args, kwargs, query)


def _sync_aql_path(wrapped, args, kwargs, query):
    """Handle AQL queries with a retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)
    bind_vars_count = _extract_bind_vars_count(kwargs)

    try:
        span = start_retrieval_span(query=query_preview, source="arangodb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "arangodb")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.source", "arangodb")
            if bind_vars_count:
                span.set_attribute("db.arangodb.bind_vars_count", bind_vars_count)
            result_count = _extract_result_count(response)
            if result_count:
                span.set_attribute("db.arangodb.result_count", result_count)
        except Exception as attr_exc:
            logger.debug("Failed to set arangodb AQL span attributes: %s", attr_exc)

        try:
            _record_arangodb_retrieval(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_insert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for arango StandardCollection.insert -- instruments inserts."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    collection_name = _extract_collection_name(instance)

    try:
        span = start_tool_span(tool_name="arangodb.insert", tool_type="database")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "arangodb")
            span.set_attribute("waxell.retrieval.source", "arangodb")
            if collection_name:
                span.set_attribute("db.arangodb.collection", collection_name)
        except Exception as attr_exc:
            logger.debug("Failed to set arangodb insert span attributes: %s", attr_exc)

        try:
            _record_arangodb_insert(collection_name=collection_name)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_find_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for arango StandardCollection.find -- instruments finds."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    collection_name = _extract_collection_name(instance)

    try:
        span = start_retrieval_span(query=f"find in {collection_name}", source="arangodb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "arangodb")
            span.set_attribute("waxell.retrieval.source", "arangodb")
            if collection_name:
                span.set_attribute("db.arangodb.collection", collection_name)
            result_count = _extract_result_count(response)
            if result_count:
                span.set_attribute("db.arangodb.result_count", result_count)
        except Exception as attr_exc:
            logger.debug("Failed to set arangodb find span attributes: %s", attr_exc)

        try:
            _record_arangodb_retrieval(query=f"find in {collection_name}")
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_arangodb_retrieval(
    query: str,
) -> None:
    """Record an ArangoDB retrieval operation to the context path.

    ArangoDB retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="arangodb",
        )


def _record_arangodb_insert(
    collection_name: str = "",
) -> None:
    """Record an ArangoDB insert operation to the context path.

    Insert operations are recorded as tool calls within an active WaxellContext.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name="arangodb.insert",
            input={"collection": collection_name},
            tool_type="database",
        )
