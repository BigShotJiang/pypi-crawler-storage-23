"""DuckDB vector search auto-instrumentor for waxell-observe.

Monkey-patches DuckDB's ``execute()`` and ``sql()`` methods to detect
vector similarity search queries and emit OTel retrieval spans.

Only queries containing vector search functions are instrumented:
  - ``array_distance``
  - ``array_cosine_similarity``
  - ``array_inner_product``
  - VSS extension functions (``vss`` keyword in query)

Non-vector queries pass through without any span creation.

Patched methods:
  - ``duckdb.DuckDBPyConnection.execute``  (retrieval span for vector queries)
  - ``duckdb.DuckDBPyConnection.sql``      (retrieval span for vector queries)

All wrapper code is wrapped in try/except -- never breaks the user's DuckDB calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Vector search function patterns to detect in SQL queries
_VECTOR_PATTERNS = (
    "array_distance",
    "array_cosine_similarity",
    "array_inner_product",
    "vss",
)


class DuckDBVectorInstrumentor(BaseInstrumentor):
    """Instrumentor for DuckDB vector similarity search (``duckdb``).

    Patches ``DuckDBPyConnection.execute`` and ``DuckDBPyConnection.sql``
    to emit retrieval spans when vector search queries are detected.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import duckdb  # noqa: F401
        except ImportError:
            logger.debug("duckdb package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping DuckDB instrumentation")
            return False

        patched_any = False

        # --- DuckDBPyConnection.execute ---
        try:
            wrapt.wrap_function_wrapper(
                "duckdb",
                "DuckDBPyConnection.execute",
                _sync_execute_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch DuckDBPyConnection.execute")

        # --- DuckDBPyConnection.sql ---
        try:
            wrapt.wrap_function_wrapper(
                "duckdb",
                "DuckDBPyConnection.sql",
                _sync_sql_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch DuckDBPyConnection.sql")

        if not patched_any:
            logger.debug("Could not patch any DuckDB methods")
            return False

        self._instrumented = True
        logger.debug("DuckDB vector instrumented (execute, sql)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import duckdb

            cls = getattr(duckdb, "DuckDBPyConnection", None)
            if cls is not None:
                for method_name in ("execute", "sql"):
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("DuckDB vector uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_vector_query(query: str) -> bool:
    """Detect whether a SQL query contains vector search operations.

    Checks for known DuckDB vector similarity functions and the VSS
    extension keyword.
    """
    if not query or not isinstance(query, str):
        return False

    query_lower = query.lower()
    return any(pattern in query_lower for pattern in _VECTOR_PATTERNS)


def _truncate_query(query: str, max_len: int = 500) -> str:
    """Truncate a SQL query string for span attributes."""
    if not query or not isinstance(query, str):
        return ""
    return query[:max_len]


def _extract_result_count(result) -> int:
    """Extract result count from a DuckDB query result.

    DuckDB results support fetchall(), or may have shape attribute.
    We try several approaches without consuming the result.
    """
    try:
        # Try description (column info) -- if no results, description is None
        desc = getattr(result, "description", None)
        if desc is None:
            return 0

        # Try rowcount (some interfaces)
        rowcount = getattr(result, "rowcount", -1)
        if isinstance(rowcount, int) and rowcount >= 0:
            return rowcount
    except Exception:
        pass

    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper functions
# ---------------------------------------------------------------------------


def _sync_execute_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for DuckDB ``DuckDBPyConnection.execute``.

    Only creates spans for vector search queries; non-vector queries
    pass through without instrumentation.
    """
    # Extract query string from args
    query = args[0] if args else kwargs.get("query", "")
    if not isinstance(query, str):
        query = str(query) if query else ""

    # Skip non-vector queries entirely
    if not _is_vector_query(query):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_truncated = _truncate_query(query)
    query_preview = f"duckdb.execute({query_truncated!r})"

    try:
        span = start_retrieval_span(query=query_preview, source="duckdb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(result)

            span.set_attribute("waxell.retrieval.source", "duckdb")
            span.set_attribute("waxell.retrieval.operation", "vector_search")
            span.set_attribute("waxell.retrieval.matches_count", result_count)
            span.set_attribute("db.system", "duckdb")
            span.set_attribute("db.statement", query_truncated)
        except Exception as attr_exc:
            logger.debug("Failed to set DuckDB execute span attributes: %s", attr_exc)

        try:
            _record_duckdb_retrieval(
                query=query_preview,
                result_count=result_count if "result_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_sql_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for DuckDB ``DuckDBPyConnection.sql``.

    Only creates spans for vector search queries; non-vector queries
    pass through without instrumentation.
    """
    # Extract query string from args
    query = args[0] if args else kwargs.get("query", "")
    if not isinstance(query, str):
        query = str(query) if query else ""

    # Skip non-vector queries entirely
    if not _is_vector_query(query):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_truncated = _truncate_query(query)
    query_preview = f"duckdb.sql({query_truncated!r})"

    try:
        span = start_retrieval_span(query=query_preview, source="duckdb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(result)

            span.set_attribute("waxell.retrieval.source", "duckdb")
            span.set_attribute("waxell.retrieval.operation", "vector_search")
            span.set_attribute("waxell.retrieval.matches_count", result_count)
            span.set_attribute("db.system", "duckdb")
            span.set_attribute("db.statement", query_truncated)
        except Exception as attr_exc:
            logger.debug("Failed to set DuckDB sql span attributes: %s", attr_exc)

        try:
            _record_duckdb_retrieval(
                query=query_preview,
                result_count=result_count if "result_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_duckdb_retrieval(
    query: str,
    result_count: int,
) -> None:
    """Record a DuckDB vector retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"row_{i}"} for i in range(result_count)]
        ctx.record_retrieval(
            query=query,
            source="duckdb",
            documents=documents,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass
