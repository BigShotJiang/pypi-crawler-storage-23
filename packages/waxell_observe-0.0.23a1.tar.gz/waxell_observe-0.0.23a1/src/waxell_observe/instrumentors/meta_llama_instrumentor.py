"""Meta Llama Stack auto-instrumentor for waxell-observe.

Monkey-patches ``llama_stack_client.LlamaStackClient.inference.chat_completion``
(sync) and ``llama_stack_client.AsyncLlamaStackClient.inference.chat_completion``
(async) to emit OTel spans and record to the Waxell HTTP API.

The Llama Stack client returns structured response objects:
  - ``response.completion_message.content``  — completion text
  - ``response.model``                       — model identifier
  - ``response.logprobs``                    — optional log probabilities

Usage/token data may be available via response metadata depending on the
Llama Stack server implementation.

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MetaLlamaInstrumentor(BaseInstrumentor):
    """Instrumentor for the Meta Llama Stack client (``llama_stack_client`` package).

    Patches ``LlamaStackClient.inference.chat_completion`` (sync) and
    ``AsyncLlamaStackClient.inference.chat_completion`` (async).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import llama_stack_client  # noqa: F401
        except ImportError:
            logger.debug("llama_stack_client not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Meta Llama instrumentation")
            return False

        patched = False

        # Patch sync inference.chat_completion
        try:
            wrapt.wrap_function_wrapper(
                "llama_stack_client.resources.inference",
                "Inference.chat_completion",
                _sync_chat_completion_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Inference.chat_completion: %s", exc)

        # Patch async inference.chat_completion
        try:
            wrapt.wrap_function_wrapper(
                "llama_stack_client.resources.inference",
                "AsyncInference.chat_completion",
                _async_chat_completion_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch AsyncInference.chat_completion: %s", exc)

        if not patched:
            logger.debug("Could not find Meta Llama Stack methods to patch")
            return False

        self._instrumented = True
        logger.debug("Meta Llama Stack client instrumented (inference.chat_completion, sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from llama_stack_client.resources.inference import Inference

            method = getattr(Inference, "chat_completion", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Inference.chat_completion = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from llama_stack_client.resources.inference import AsyncInference

            method = getattr(AsyncInference, "chat_completion", None)
            if method is not None and hasattr(method, "__wrapped__"):
                AsyncInference.chat_completion = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Meta Llama Stack client uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Llama Stack responses
# ---------------------------------------------------------------------------


def _extract_llama_data(response, request_model: str, kwargs: dict) -> dict:
    """Extract model, tokens, cost, and content from a Llama Stack response.

    Returns a dict with keys: model, tokens_in, tokens_out, cost,
    finish_reason, content, temperature, max_tokens.
    """
    model = request_model
    tokens_in = 0
    tokens_out = 0
    finish_reason = ""
    content = ""

    try:
        # The response object may have varying structures depending on
        # the Llama Stack server version.
        if hasattr(response, "completion_message"):
            msg = response.completion_message
            if hasattr(msg, "content"):
                content = str(msg.content) if msg.content else ""
            if hasattr(msg, "stop_reason"):
                finish_reason = str(msg.stop_reason) if msg.stop_reason else ""
    except Exception:
        pass

    # Try to extract token usage if available
    try:
        if hasattr(response, "usage"):
            usage = response.usage
            if hasattr(usage, "prompt_tokens"):
                tokens_in = int(usage.prompt_tokens or 0)
            if hasattr(usage, "completion_tokens"):
                tokens_out = int(usage.completion_tokens or 0)
    except Exception:
        pass

    # Try to get model from response
    try:
        if hasattr(response, "model") and response.model:
            model = str(response.model)
    except Exception:
        pass

    temperature = kwargs.get("temperature", None)
    max_tokens = kwargs.get("max_tokens", None)

    return {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,
        "finish_reason": finish_reason,
        "content": content,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_chat_completion_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Llama Stack ``Inference.chat_completion``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", kwargs.get("model_id", "unknown"))

    try:
        span = start_llm_span(model=model, provider_name="meta")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_llama_data(response, model, kwargs)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_llama(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_completion_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Llama Stack ``AsyncInference.chat_completion``."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", kwargs.get("model_id", "unknown"))

    try:
        span = start_llm_span(model=model, provider_name="meta")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            data = _extract_llama_data(response, model, kwargs)
            _set_span_attributes(span, data)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_llama(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, data: dict) -> None:
    """Set OTel span attributes from extracted Llama Stack data."""
    from ..tracing.attributes import GenAIAttributes, WaxellAttributes

    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(GenAIAttributes.RESPONSE_MODEL, data["model"])
    if data["finish_reason"]:
        span.set_attribute(
            GenAIAttributes.RESPONSE_FINISH_REASONS, [data["finish_reason"]]
        )
    if data["temperature"] is not None:
        span.set_attribute(GenAIAttributes.REQUEST_TEMPERATURE, float(data["temperature"]))
    if data["max_tokens"] is not None:
        span.set_attribute(GenAIAttributes.REQUEST_MAX_TOKENS, int(data["max_tokens"]))
    span.set_attribute(WaxellAttributes.LLM_MODEL, data["model"])
    span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(
        WaxellAttributes.LLM_TOTAL_TOKENS,
        data["tokens_in"] + data["tokens_out"],
    )
    span.set_attribute(WaxellAttributes.LLM_COST, 0.0)


def _record_http_llama(
    response, request_model: str, kwargs: dict
) -> None:
    """Record a Meta Llama LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    data = _extract_llama_data(response, request_model, kwargs)

    # Extract prompt preview from messages
    prompt_preview = ""
    messages = kwargs.get("messages", [])
    if messages and isinstance(messages, list):
        first = messages[0]
        if isinstance(first, dict):
            prompt_preview = str(first.get("content", ""))[:500]
        elif hasattr(first, "content"):
            prompt_preview = str(first.content)[:500]

    call_data = {
        "model": data["model"],
        "tokens_in": data["tokens_in"],
        "tokens_out": data["tokens_out"],
        "cost": 0.0,
        "task": "meta_llama.chat_completion",
        "prompt_preview": prompt_preview,
        "response_preview": str(data["content"])[:500] if data["content"] else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
