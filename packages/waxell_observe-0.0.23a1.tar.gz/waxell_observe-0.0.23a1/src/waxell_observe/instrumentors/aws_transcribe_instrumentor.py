"""AWS Transcribe auto-instrumentor for waxell-observe.

Monkey-patches ``botocore.client.BaseClient._make_api_call`` to intercept
AWS Transcribe operations, emitting OTel step spans for:
  - ``StartTranscriptionJob``  -- start an async transcription job
  - ``GetTranscriptionJob``    -- check status of a transcription job

AWS Transcribe is async by nature -- ``StartTranscriptionJob`` returns
immediately with job metadata, and ``GetTranscriptionJob`` polls for
status. This instrumentor traces both API calls.

StartTranscriptionJob response:
  - ``response['TranscriptionJob']['TranscriptionJobName']``
  - ``response['TranscriptionJob']['TranscriptionJobStatus']``
  - ``response['TranscriptionJob']['MediaFormat']``
  - ``response['TranscriptionJob']['LanguageCode']``
  - ``response['TranscriptionJob']['ModelSettings']['LanguageModelName']``

GetTranscriptionJob response:
  - ``response['TranscriptionJob']['TranscriptionJobStatus']``  (IN_PROGRESS, COMPLETED, FAILED)

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Operations we instrument on transcribe
_TRANSCRIBE_OPERATIONS = {"StartTranscriptionJob", "GetTranscriptionJob"}


class AWSTranscribeInstrumentor(BaseInstrumentor):
    """Instrumentor for AWS Transcribe via boto3/botocore.

    Patches ``BaseClient._make_api_call`` and filters to transcribe
    service operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import botocore.client  # noqa: F401
        except ImportError:
            logger.debug("botocore not installed -- skipping AWS Transcribe instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping AWS Transcribe instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "botocore.client",
                "BaseClient._make_api_call",
                _api_call_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch botocore for AWS Transcribe: %s", exc)
            return False

        self._instrumented = True
        logger.debug("AWS Transcribe instrumented via botocore")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import botocore.client as mod

            if hasattr(mod.BaseClient._make_api_call, "__wrapped__"):
                mod.BaseClient._make_api_call = mod.BaseClient._make_api_call.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("AWS Transcribe uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_transcribe_service(instance) -> bool:
    """Check if the botocore client is a transcribe client."""
    try:
        service_model = getattr(instance, "_service_model", None)
        if service_model:
            service_name = getattr(service_model, "service_name", "")
            return service_name == "transcribe"
        # Fallback: check endpoint URL
        endpoint = getattr(instance, "_endpoint", None)
        if endpoint:
            host = str(getattr(endpoint, "host", ""))
            return "transcribe" in host
    except Exception:
        pass
    return False


def _extract_start_job_data(api_params: dict, response: dict) -> dict:
    """Extract data from StartTranscriptionJob request/response."""
    data = {
        "job_name": "",
        "media_format": "",
        "language": "",
        "model": "",
        "status": "",
    }

    try:
        data["job_name"] = api_params.get("TranscriptionJobName", "")
    except Exception:
        pass

    try:
        data["media_format"] = api_params.get("MediaFormat", "")
    except Exception:
        pass

    try:
        data["language"] = api_params.get("LanguageCode", "")
    except Exception:
        pass

    try:
        model_settings = api_params.get("ModelSettings", {})
        if isinstance(model_settings, dict):
            data["model"] = model_settings.get("LanguageModelName", "")
    except Exception:
        pass

    try:
        job = response.get("TranscriptionJob", {})
        if isinstance(job, dict):
            data["status"] = job.get("TranscriptionJobStatus", "")
            # Fill in from response if not in request
            if not data["job_name"]:
                data["job_name"] = job.get("TranscriptionJobName", "")
            if not data["media_format"]:
                data["media_format"] = job.get("MediaFormat", "")
            if not data["language"]:
                data["language"] = job.get("LanguageCode", "")
    except Exception:
        pass

    return data


def _extract_get_job_data(api_params: dict, response: dict) -> dict:
    """Extract data from GetTranscriptionJob request/response."""
    data = {
        "job_name": "",
        "media_format": "",
        "language": "",
        "model": "",
        "status": "",
    }

    try:
        data["job_name"] = api_params.get("TranscriptionJobName", "")
    except Exception:
        pass

    try:
        job = response.get("TranscriptionJob", {})
        if isinstance(job, dict):
            data["status"] = job.get("TranscriptionJobStatus", "")
            data["media_format"] = job.get("MediaFormat", "")
            data["language"] = job.get("LanguageCode", "")
            if not data["job_name"]:
                data["job_name"] = job.get("TranscriptionJobName", "")
            model_settings = job.get("ModelSettings", {})
            if isinstance(model_settings, dict):
                data["model"] = model_settings.get("LanguageModelName", "")
    except Exception:
        pass

    return data


# ---------------------------------------------------------------------------
# Wrapper function
# ---------------------------------------------------------------------------


def _api_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``BaseClient._make_api_call``.

    Only instruments transcribe StartTranscriptionJob and
    GetTranscriptionJob operations. All other API calls pass through
    untouched.
    """
    # args[0] = operation_name, args[1] = api_params
    operation_name = args[0] if args else kwargs.get("operation_name", "")
    api_params = args[1] if len(args) > 1 else kwargs.get("api_params", {})

    # Only instrument transcribe operations we care about
    if operation_name not in _TRANSCRIBE_OPERATIONS or not _is_transcribe_service(instance):
        return wrapped(*args, **kwargs)

    if operation_name == "StartTranscriptionJob":
        return _handle_start_job(wrapped, args, kwargs, api_params)
    elif operation_name == "GetTranscriptionJob":
        return _handle_get_job(wrapped, args, kwargs, api_params)

    return wrapped(*args, **kwargs)


def _handle_start_job(wrapped, args, kwargs, api_params: dict):
    """Handle StartTranscriptionJob instrumentation."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="aws.transcribe.start_job")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_start_job_data(api_params, response)
            _set_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set AWS Transcribe StartJob span attributes: %s", attr_exc)

        try:
            _record_stt_call("aws.transcribe.start_job", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _handle_get_job(wrapped, args, kwargs, api_params: dict):
    """Handle GetTranscriptionJob instrumentation."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="aws.transcribe.get_job")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_get_job_data(api_params, response)
            _set_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set AWS Transcribe GetJob span attributes: %s", attr_exc)

        try:
            _record_stt_call("aws.transcribe.get_job", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, data: dict, latency: float) -> None:
    """Set OTel span attributes for an AWS Transcribe operation."""
    if data["job_name"]:
        span.set_attribute("waxell.aws_transcribe.job_name", data["job_name"])
    if data["media_format"]:
        span.set_attribute("waxell.aws_transcribe.media_format", data["media_format"])
    if data["language"]:
        span.set_attribute("waxell.aws_transcribe.language", data["language"])
    if data["model"]:
        span.set_attribute("waxell.aws_transcribe.model", data["model"])
    if data["status"]:
        span.set_attribute("waxell.aws_transcribe.status", data["status"])
    span.set_attribute("waxell.aws_transcribe.latency_ms", round(latency * 1000, 2))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_stt_call(task: str, data: dict, latency: float) -> None:
    """Record an AWS Transcribe call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": data.get("model", "aws-transcribe"),
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[aws transcribe job={data.get('job_name', '')}, language={data.get('language', 'auto')}]",
        "response_preview": f"[status={data.get('status', 'unknown')}]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
