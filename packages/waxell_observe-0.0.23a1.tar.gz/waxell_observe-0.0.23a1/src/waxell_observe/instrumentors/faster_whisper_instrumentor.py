"""Faster Whisper auto-instrumentor for waxell-observe.

Monkey-patches the faster-whisper library to emit OTel step spans for
speech-to-text (STT) operations:
  - ``faster_whisper.WhisperModel.transcribe``  -- local STT inference

The faster-whisper ``transcribe`` method returns a tuple of
``(segments_generator, info)``:
  - ``info.language``              -- detected language code
  - ``info.language_probability``  -- confidence of language detection
  - ``info.duration``              -- audio duration in seconds

Segments are a lazy generator -- we do NOT consume them, only capture
the info object metadata.

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FasterWhisperInstrumentor(BaseInstrumentor):
    """Instrumentor for the faster-whisper library.

    Patches ``WhisperModel.transcribe`` to emit step spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import faster_whisper  # noqa: F401
        except ImportError:
            logger.debug("faster_whisper not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping faster-whisper instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "faster_whisper",
                "WhisperModel.transcribe",
                _transcribe_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch faster_whisper WhisperModel.transcribe: %s", exc)
            return False

        self._instrumented = True
        logger.debug("faster-whisper instrumented (WhisperModel.transcribe)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import faster_whisper

            cls = getattr(faster_whisper, "WhisperModel", None)
            if cls is not None:
                method = getattr(cls, "transcribe", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "transcribe", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("faster-whisper uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data
# ---------------------------------------------------------------------------


def _extract_model_size(instance) -> str:
    """Extract the model size from the WhisperModel instance."""
    try:
        # faster_whisper.WhisperModel stores model_size_or_path
        model_size = getattr(instance, "model_size_or_path", None)
        if model_size is not None:
            return str(model_size)
    except Exception:
        pass
    return ""


def _extract_info_data(info) -> dict:
    """Extract metadata from the TranscriptionInfo object."""
    data = {
        "language": "",
        "language_probability": 0.0,
        "duration_seconds": 0.0,
    }

    if info is None:
        return data

    try:
        data["language"] = getattr(info, "language", "") or ""
    except Exception:
        pass

    try:
        data["language_probability"] = float(getattr(info, "language_probability", 0.0) or 0.0)
    except Exception:
        pass

    try:
        data["duration_seconds"] = float(getattr(info, "duration", 0.0) or 0.0)
    except Exception:
        pass

    return data


# ---------------------------------------------------------------------------
# Wrapper function
# ---------------------------------------------------------------------------


def _transcribe_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``WhisperModel.transcribe``.

    ``transcribe`` returns ``(segments_generator, info)``. We capture
    metadata from the info object but do NOT consume the lazy segments
    generator.
    """
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="faster_whisper.transcribe")
    except Exception:
        return wrapped(*args, **kwargs)

    model_size = _extract_model_size(instance)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0

        # result is (segments_generator, info)
        segments = None
        info = None
        try:
            if isinstance(result, tuple) and len(result) >= 2:
                segments, info = result[0], result[1]
        except Exception:
            pass

        info_data = _extract_info_data(info)

        try:
            _set_span_attributes(span, model_size, info_data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set faster-whisper span attributes: %s", attr_exc)

        try:
            _record_stt_call("faster_whisper.transcribe", model_size, info_data, latency)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, model_size: str, info_data: dict, latency: float) -> None:
    """Set OTel span attributes for a faster-whisper transcription."""
    if model_size:
        span.set_attribute("waxell.faster_whisper.model_size", model_size)
    if info_data["language"]:
        span.set_attribute("waxell.faster_whisper.language", info_data["language"])
    if info_data["language_probability"]:
        span.set_attribute(
            "waxell.faster_whisper.language_probability",
            round(info_data["language_probability"], 4),
        )
    if info_data["duration_seconds"]:
        span.set_attribute(
            "waxell.faster_whisper.duration_seconds",
            round(info_data["duration_seconds"], 2),
        )
    span.set_attribute("waxell.faster_whisper.latency_ms", round(latency * 1000, 2))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_stt_call(task: str, model_size: str, info_data: dict, latency: float) -> None:
    """Record a faster-whisper STT call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model_size or "faster-whisper",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[faster-whisper, duration={info_data.get('duration_seconds', 0):.1f}s]",
        "response_preview": f"[language={info_data.get('language', 'unknown')}, "
        f"prob={info_data.get('language_probability', 0):.2f}]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
