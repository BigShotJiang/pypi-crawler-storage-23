"""Microsoft GraphRAG auto-instrumentor for waxell-observe.

Monkey-patches GraphRAG search methods (local_search, global_search) and
indexing operations to emit retrieval and step spans.

Patched methods:
  - ``graphrag.query.structured_search.local_search.LocalSearch.search``  (retrieval span)
  - ``graphrag.query.structured_search.global_search.GlobalSearch.search``  (retrieval span)
  - ``graphrag.query.structured_search.local_search.LocalSearch.asearch``  (retrieval span, async)
  - ``graphrag.query.structured_search.global_search.GlobalSearch.asearch``  (retrieval span, async)
  - ``graphrag.index.run.run_pipeline``  (step span for indexing)

All wrapper code is wrapped in try/except -- never breaks the user's GraphRAG calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GraphragInstrumentor(BaseInstrumentor):
    """Instrumentor for Microsoft GraphRAG.

    Patches local and global search methods to emit retrieval spans,
    and indexing pipeline runs to emit step spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import graphrag  # noqa: F401
        except ImportError:
            logger.debug("graphrag package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping GraphRAG instrumentation")
            return False

        patched_any = False

        # --- LocalSearch.search (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "graphrag.query.structured_search.local_search",
                "LocalSearch.search",
                _sync_local_search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch GraphRAG LocalSearch.search: %s", exc)

        # --- GlobalSearch.search (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "graphrag.query.structured_search.global_search",
                "GlobalSearch.search",
                _sync_global_search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch GraphRAG GlobalSearch.search: %s", exc)

        # --- LocalSearch.asearch (async) ---
        try:
            wrapt.wrap_function_wrapper(
                "graphrag.query.structured_search.local_search",
                "LocalSearch.asearch",
                _async_local_search_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch GraphRAG LocalSearch.asearch: %s", exc)

        # --- GlobalSearch.asearch (async) ---
        try:
            wrapt.wrap_function_wrapper(
                "graphrag.query.structured_search.global_search",
                "GlobalSearch.asearch",
                _async_global_search_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch GraphRAG GlobalSearch.asearch: %s", exc)

        # --- run_pipeline (indexing) ---
        try:
            wrapt.wrap_function_wrapper(
                "graphrag.index.run",
                "run_pipeline",
                _async_run_pipeline_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch GraphRAG run_pipeline: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any GraphRAG methods")
            return False

        self._instrumented = True
        logger.debug("GraphRAG instrumented (LocalSearch, GlobalSearch, run_pipeline)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore LocalSearch
        try:
            from graphrag.query.structured_search.local_search import LocalSearch

            for method_name in ("search", "asearch"):
                method = getattr(LocalSearch, method_name, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(LocalSearch, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore GlobalSearch
        try:
            from graphrag.query.structured_search.global_search import GlobalSearch

            for method_name in ("search", "asearch"):
                method = getattr(GlobalSearch, method_name, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(GlobalSearch, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore run_pipeline
        try:
            import graphrag.index.run as run_mod

            method = getattr(run_mod, "run_pipeline", None)
            if method is not None and hasattr(method, "__wrapped__"):
                run_mod.run_pipeline = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("GraphRAG uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the query string from search call args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate a string for span labelling."""
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


def _extract_community_level(instance) -> int:
    """Extract the community level from a search instance configuration."""
    try:
        # GraphRAG search instances may have community_level in their config
        if hasattr(instance, "community_level"):
            return int(instance.community_level)
        if hasattr(instance, "config") and hasattr(instance.config, "community_level"):
            return int(instance.config.community_level)
    except Exception:
        pass
    return 0


def _extract_result_count(result) -> int:
    """Extract the number of results from a GraphRAG search result."""
    try:
        if result is None:
            return 0
        # SearchResult objects typically have context_data or context_records
        if hasattr(result, "context_data") and isinstance(result.context_data, (list, dict)):
            if isinstance(result.context_data, list):
                return len(result.context_data)
            return len(result.context_data)
        if hasattr(result, "context_records") and isinstance(result.context_records, (list, dict)):
            if isinstance(result.context_records, list):
                return len(result.context_records)
            return len(result.context_records)
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_local_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for GraphRAG LocalSearch.search."""
    return _sync_search_path(wrapped, instance, args, kwargs, search_type="local")


def _sync_global_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for GraphRAG GlobalSearch.search."""
    return _sync_search_path(wrapped, instance, args, kwargs, search_type="global")


def _sync_search_path(wrapped, instance, args, kwargs, search_type: str):
    """Handle sync search queries with a retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)
    community_level = _extract_community_level(instance)

    try:
        span = start_retrieval_span(query=query_preview, source=f"graphrag-{search_type}")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(result)
            span.set_attribute("waxell.retrieval.search_type", search_type)
            span.set_attribute("waxell.retrieval.community_level", community_level)
            span.set_attribute("waxell.retrieval.results_count", result_count)
        except Exception as attr_exc:
            logger.debug("Failed to set GraphRAG %s search span attributes: %s", search_type, attr_exc)

        try:
            _record_graphrag_retrieval(
                query=query_preview,
                search_type=search_type,
                result_count=result_count if "result_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def _async_local_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for GraphRAG LocalSearch.asearch."""
    return await _async_search_path(wrapped, instance, args, kwargs, search_type="local")


async def _async_global_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for GraphRAG GlobalSearch.asearch."""
    return await _async_search_path(wrapped, instance, args, kwargs, search_type="global")


async def _async_search_path(wrapped, instance, args, kwargs, search_type: str):
    """Handle async search queries with a retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate(query)
    community_level = _extract_community_level(instance)

    try:
        span = start_retrieval_span(query=query_preview, source=f"graphrag-{search_type}")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = _extract_result_count(result)
            span.set_attribute("waxell.retrieval.search_type", search_type)
            span.set_attribute("waxell.retrieval.community_level", community_level)
            span.set_attribute("waxell.retrieval.results_count", result_count)
        except Exception as attr_exc:
            logger.debug("Failed to set GraphRAG async %s search span attributes: %s", search_type, attr_exc)

        try:
            _record_graphrag_retrieval(
                query=query_preview,
                search_type=search_type,
                result_count=result_count if "result_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_run_pipeline_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for GraphRAG run_pipeline -- indexing step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="graphrag.index.run_pipeline")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.graphrag.operation", "indexing")
        except Exception as attr_exc:
            logger.debug("Failed to set GraphRAG pipeline span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "graphrag_indexing",
                    output={"result_preview": str(result)[:200]},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_graphrag_retrieval(
    query: str,
    search_type: str,
    result_count: int = 0,
) -> None:
    """Record a GraphRAG retrieval operation to the context path.

    GraphRAG retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source=f"graphrag-{search_type}",
            results_count=result_count,
        )
