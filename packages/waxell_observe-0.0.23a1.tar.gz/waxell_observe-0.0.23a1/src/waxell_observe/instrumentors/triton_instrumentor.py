"""NVIDIA Triton Inference Server auto-instrumentor for waxell-observe.

Monkey-patches tritonclient.http.InferenceServerClient.infer and
tritonclient.grpc.InferenceServerClient.infer (plus async variants)
to emit LLM call spans for Triton model serving.

Triton client returns InferResult objects with:
  - ``get_output(name)``      -- retrieves named output tensor
  - ``as_numpy(name)``        -- retrieves output as numpy array
  - ``get_response()``        -- raw response metadata

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class TritonInstrumentor(BaseInstrumentor):
    """Instrumentor for NVIDIA Triton Inference Server clients.

    Patches ``InferenceServerClient.infer`` and ``InferenceServerClient.async_infer``
    for both HTTP (``tritonclient.http``) and gRPC (``tritonclient.grpc``) transports.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Triton instrumentation")
            return False

        patched = False

        # Patch HTTP client
        try:
            import tritonclient.http  # noqa: F401

            try:
                wrapt.wrap_function_wrapper(
                    "tritonclient.http",
                    "InferenceServerClient.infer",
                    _http_infer_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Could not patch tritonclient.http infer: %s", exc)

            try:
                wrapt.wrap_function_wrapper(
                    "tritonclient.http",
                    "InferenceServerClient.async_infer",
                    _http_async_infer_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Could not patch tritonclient.http async_infer: %s", exc)

        except ImportError:
            logger.debug("tritonclient.http not installed -- skipping HTTP patches")

        # Patch gRPC client
        try:
            import tritonclient.grpc  # noqa: F401

            try:
                wrapt.wrap_function_wrapper(
                    "tritonclient.grpc",
                    "InferenceServerClient.infer",
                    _grpc_infer_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Could not patch tritonclient.grpc infer: %s", exc)

            try:
                wrapt.wrap_function_wrapper(
                    "tritonclient.grpc",
                    "InferenceServerClient.async_infer",
                    _grpc_async_infer_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Could not patch tritonclient.grpc async_infer: %s", exc)

        except ImportError:
            logger.debug("tritonclient.grpc not installed -- skipping gRPC patches")

        if not patched:
            logger.debug("No Triton client methods found to patch")
            return False

        self._instrumented = True
        logger.debug("Triton Inference Server clients instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore HTTP client
        try:
            import tritonclient.http as http_mod

            for attr in ("infer", "async_infer"):
                method = getattr(http_mod.InferenceServerClient, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(http_mod.InferenceServerClient, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore gRPC client
        try:
            import tritonclient.grpc as grpc_mod

            for attr in ("infer", "async_infer"):
                method = getattr(grpc_mod.InferenceServerClient, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(grpc_mod.InferenceServerClient, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Triton Inference Server clients uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Triton requests/responses
# ---------------------------------------------------------------------------


def _extract_model_info(args, kwargs) -> tuple[str, str]:
    """Extract model name and version from infer arguments.

    Returns (model_name, model_version).
    """
    model_name = "unknown"
    model_version = ""

    if args:
        model_name = str(args[0]) if args[0] else "unknown"
    model_name = kwargs.get("model_name", model_name)
    model_version = str(kwargs.get("model_version", model_version))

    return model_name, model_version


def _extract_request_id(kwargs) -> str:
    """Extract the request ID if provided."""
    return str(kwargs.get("request_id", ""))


def _extract_input_shapes(kwargs) -> str:
    """Extract input tensor shapes as a descriptive string."""
    inputs = kwargs.get("inputs", [])
    if not inputs:
        return ""

    shapes = []
    try:
        for inp in inputs:
            name = getattr(inp, "name", getattr(inp, "_name", "?"))
            shape = getattr(inp, "shape", getattr(inp, "_shape", None))
            if shape is not None:
                shapes.append(f"{name}:{list(shape)}")
            else:
                shapes.append(str(name))
    except Exception:
        pass

    return ", ".join(shapes)[:500]


def _extract_output_shapes(result) -> str:
    """Extract output tensor shapes from the inference result."""
    if result is None:
        return ""

    shapes = []
    try:
        # Try to get response metadata for output names
        response = getattr(result, "get_response", lambda: None)()
        if response:
            outputs = getattr(response, "outputs", [])
            for out in outputs:
                name = getattr(out, "name", "?")
                shape = getattr(out, "shape", None)
                if shape is not None:
                    shapes.append(f"{name}:{list(shape)}")
                else:
                    shapes.append(str(name))
    except Exception:
        pass

    return ", ".join(shapes)[:500]


# ---------------------------------------------------------------------------
# HTTP wrapper functions
# ---------------------------------------------------------------------------


def _http_infer_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``tritonclient.http.InferenceServerClient.infer``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name, model_version = _extract_model_info(args, kwargs)

    try:
        span = start_llm_span(model=model_name, provider_name="triton")
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.monotonic()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - start_time
            request_id = _extract_request_id(kwargs)
            input_shapes = _extract_input_shapes(kwargs)
            output_shapes = _extract_output_shapes(result)

            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.triton.model_version", model_version)
            span.set_attribute("waxell.triton.transport", "http")
            span.set_attribute("waxell.triton.latency_s", latency)

            if request_id:
                span.set_attribute("waxell.triton.request_id", request_id)
            if input_shapes:
                span.set_attribute("waxell.triton.input_shapes", input_shapes)
            if output_shapes:
                span.set_attribute("waxell.triton.output_shapes", output_shapes)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_triton(model_name, model_version, kwargs, "http.infer")
        except Exception:
            pass

        return result
    finally:
        span.end()


def _http_async_infer_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``tritonclient.http.InferenceServerClient.async_infer``.

    Note: tritonclient.http async_infer uses callbacks, not Python async/await.
    """
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name, model_version = _extract_model_info(args, kwargs)

    try:
        span = start_llm_span(model=model_name, provider_name="triton")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        input_shapes = _extract_input_shapes(kwargs)

        span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model_name)
        span.set_attribute(WaxellAttributes.LLM_MODEL, model_name)
        span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
        span.set_attribute("waxell.triton.model_version", model_version)
        span.set_attribute("waxell.triton.transport", "http")
        span.set_attribute("waxell.triton.async", True)

        request_id = _extract_request_id(kwargs)
        if request_id:
            span.set_attribute("waxell.triton.request_id", request_id)
        if input_shapes:
            span.set_attribute("waxell.triton.input_shapes", input_shapes)
    except Exception:
        pass

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_triton(model_name, model_version, kwargs, "http.async_infer")
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# gRPC wrapper functions
# ---------------------------------------------------------------------------


def _grpc_infer_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``tritonclient.grpc.InferenceServerClient.infer``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name, model_version = _extract_model_info(args, kwargs)

    try:
        span = start_llm_span(model=model_name, provider_name="triton")
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.monotonic()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - start_time
            request_id = _extract_request_id(kwargs)
            input_shapes = _extract_input_shapes(kwargs)
            output_shapes = _extract_output_shapes(result)

            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.triton.model_version", model_version)
            span.set_attribute("waxell.triton.transport", "grpc")
            span.set_attribute("waxell.triton.latency_s", latency)

            if request_id:
                span.set_attribute("waxell.triton.request_id", request_id)
            if input_shapes:
                span.set_attribute("waxell.triton.input_shapes", input_shapes)
            if output_shapes:
                span.set_attribute("waxell.triton.output_shapes", output_shapes)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_triton(model_name, model_version, kwargs, "grpc.infer")
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _grpc_async_infer_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``tritonclient.grpc.InferenceServerClient.async_infer``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return await wrapped(*args, **kwargs)

    model_name, model_version = _extract_model_info(args, kwargs)

    try:
        span = start_llm_span(model=model_name, provider_name="triton")
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.monotonic()

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - start_time
            request_id = _extract_request_id(kwargs)
            input_shapes = _extract_input_shapes(kwargs)
            output_shapes = _extract_output_shapes(result)

            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model_name)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.triton.model_version", model_version)
            span.set_attribute("waxell.triton.transport", "grpc")
            span.set_attribute("waxell.triton.latency_s", latency)

            if request_id:
                span.set_attribute("waxell.triton.request_id", request_id)
            if input_shapes:
                span.set_attribute("waxell.triton.input_shapes", input_shapes)
            if output_shapes:
                span.set_attribute("waxell.triton.output_shapes", output_shapes)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_triton(model_name, model_version, kwargs, "grpc.async_infer")
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_triton(
    model_name: str, model_version: str, kwargs: dict, task: str
) -> None:
    """Record a Triton inference call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model_name,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"triton.{task}",
        "prompt_preview": f"model_version={model_version}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
