"""Guidance auto-instrumentor for waxell-observe.

Monkey-patches Guidance's model execution path to emit OTel spans
and record to the Waxell HTTP API.

Guidance uses template-based structured generation where programs are
composed of model calls interspersed with constrained generation
directives (``select``, ``gen``, etc.).  Since Guidance wraps underlying
LLM providers, the actual provider call may already be captured by our
provider-specific instrumentors.  This instrumentor captures the
Guidance-level context: program execution, model name, and template info.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GuidanceInstrumentor(BaseInstrumentor):
    """Instrumentor for Guidance (``guidance`` package).

    Patches Model.__call__ and/or the Engine execution path.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import guidance  # noqa: F401
        except ImportError:
            logger.debug("guidance not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Guidance instrumentation")
            return False

        patched = False

        # Attempt 1: Patch guidance.models.Model.__add__ (the + operator)
        # In Guidance, `model + program` is the primary execution API.
        # Model.__add__ triggers template execution.
        try:
            wrapt.wrap_function_wrapper(
                "guidance.models",
                "Model.__add__",
                _model_add_wrapper,
            )
            patched = True
            logger.debug("Patched guidance.models.Model.__add__")
        except Exception as exc:
            logger.debug("Could not patch Model.__add__: %s", exc)

        # Attempt 2: Patch Model.__call__ as alternative entry point
        try:
            wrapt.wrap_function_wrapper(
                "guidance.models",
                "Model.__call__",
                _model_call_wrapper,
            )
            patched = True
            logger.debug("Patched guidance.models.Model.__call__")
        except Exception as exc:
            logger.debug("Could not patch Model.__call__: %s", exc)

        # Attempt 3: Patch Chat model specifically
        try:
            wrapt.wrap_function_wrapper(
                "guidance.models",
                "Chat.__call__",
                _chat_call_wrapper,
            )
            logger.debug("Patched guidance.models.Chat.__call__")
        except Exception as exc:
            logger.debug("Could not patch Chat.__call__: %s", exc)

        # Attempt 4: Patch the gen() function -- core generation primitive
        try:
            wrapt.wrap_function_wrapper(
                "guidance.library",
                "gen",
                _gen_wrapper,
            )
            patched = True
            logger.debug("Patched guidance.library.gen")
        except Exception:
            # Try alternative location
            try:
                wrapt.wrap_function_wrapper(
                    "guidance",
                    "gen",
                    _gen_wrapper,
                )
                patched = True
                logger.debug("Patched guidance.gen")
            except Exception as exc:
                logger.debug("Could not patch guidance.gen: %s", exc)

        if not patched:
            logger.debug("Could not find Guidance methods to patch")
            return False

        self._instrumented = True
        logger.debug("Guidance instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore Model.__add__
        try:
            from guidance.models import Model

            if hasattr(Model.__add__, "__wrapped__"):
                Model.__add__ = Model.__add__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore Model.__call__
        try:
            from guidance.models import Model

            if hasattr(Model.__call__, "__wrapped__"):
                Model.__call__ = Model.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore Chat.__call__
        try:
            from guidance.models import Chat

            if hasattr(Chat.__call__, "__wrapped__"):
                Chat.__call__ = Chat.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore gen
        try:
            import guidance

            if hasattr(guidance.gen, "__wrapped__"):
                guidance.gen = guidance.gen.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from guidance import library

            if hasattr(library.gen, "__wrapped__"):
                library.gen = library.gen.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Guidance uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _model_add_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Model.__add__`` -- primary Guidance execution via + operator."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _extract_model_name(instance)

    # Extract prompt preview from the program being added
    prompt_preview = ""
    try:
        if args:
            program = args[0]
            if isinstance(program, str):
                prompt_preview = program[:200]
            elif hasattr(program, "__name__"):
                prompt_preview = f"[program:{program.__name__}]"
            else:
                prompt_preview = str(program)[:200]
    except Exception:
        pass

    try:
        span = start_step_span(step_name="guidance.execute")
        span.set_attribute("waxell.guidance.model_name", model_name)
        if prompt_preview:
            span.set_attribute("waxell.guidance.prompt_preview", prompt_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("waxell.guidance.latency_ms", latency_ms)

            # Capture output preview from the resulting model state
            output_preview = ""
            try:
                if hasattr(result, "text"):
                    output_preview = str(result.text)[:500]
                elif isinstance(result, str):
                    output_preview = result[:500]
                else:
                    output_preview = str(result)[:500]
            except Exception:
                pass
            if output_preview:
                span.set_attribute("waxell.guidance.output_preview", output_preview)
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_guidance(result, model_name, prompt_preview)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _model_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Model.__call__`` -- alternative Guidance execution path."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _extract_model_name(instance)

    prompt_preview = ""
    try:
        if args:
            prompt_preview = str(args[0])[:200]
    except Exception:
        pass

    try:
        span = start_step_span(step_name="guidance.execute")
        span.set_attribute("waxell.guidance.model_name", model_name)
        span.set_attribute("waxell.guidance.mode", "call")
        if prompt_preview:
            span.set_attribute("waxell.guidance.prompt_preview", prompt_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("waxell.guidance.latency_ms", latency_ms)

            output_preview = ""
            try:
                if hasattr(result, "text"):
                    output_preview = str(result.text)[:500]
                else:
                    output_preview = str(result)[:500]
            except Exception:
                pass
            if output_preview:
                span.set_attribute("waxell.guidance.output_preview", output_preview)
        except Exception:
            pass

        try:
            _record_http_guidance(result, model_name, prompt_preview)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _chat_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Chat.__call__`` -- Guidance chat model execution."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _extract_model_name(instance)

    prompt_preview = ""
    try:
        if args:
            prompt_preview = str(args[0])[:200]
    except Exception:
        pass

    try:
        span = start_step_span(step_name="guidance.execute")
        span.set_attribute("waxell.guidance.model_name", model_name)
        span.set_attribute("waxell.guidance.mode", "chat")
        if prompt_preview:
            span.set_attribute("waxell.guidance.prompt_preview", prompt_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("waxell.guidance.latency_ms", latency_ms)

            output_preview = ""
            try:
                if hasattr(result, "text"):
                    output_preview = str(result.text)[:500]
                else:
                    output_preview = str(result)[:500]
            except Exception:
                pass
            if output_preview:
                span.set_attribute("waxell.guidance.output_preview", output_preview)
        except Exception:
            pass

        try:
            _record_http_guidance(result, model_name, prompt_preview)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _gen_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``guidance.gen`` -- core generation primitive.

    ``gen()`` is called within Guidance programs to trigger text generation.
    Capturing it gives us visibility into individual generation steps
    within a larger program.
    """
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # gen() typically takes a name parameter and optional constraints
    gen_name = ""
    try:
        if args:
            gen_name = str(args[0]) if args[0] else ""
        elif "name" in kwargs:
            gen_name = str(kwargs["name"])
    except Exception:
        pass

    step_label = f"guidance.gen:{gen_name}" if gen_name else "guidance.gen"

    try:
        span = start_step_span(step_name=step_label)
        if gen_name:
            span.set_attribute("waxell.guidance.gen_name", gen_name)

        # Capture constraints if specified
        max_tokens = kwargs.get("max_tokens", None)
        stop = kwargs.get("stop", None)
        if max_tokens is not None:
            span.set_attribute("waxell.guidance.max_tokens", int(max_tokens))
        if stop is not None:
            span.set_attribute("waxell.guidance.stop", str(stop)[:100])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_model_name(instance) -> str:
    """Extract model name from a Guidance model instance."""
    try:
        # Try common attribute names
        for attr in ("model_name", "model", "name", "engine"):
            val = getattr(instance, attr, None)
            if val and isinstance(val, str):
                return val
            # If the attribute is an engine object, try to get its model name
            if val and hasattr(val, "model_name"):
                return str(val.model_name)
            if val and hasattr(val, "model"):
                return str(val.model)

        # Fallback to class name
        return type(instance).__name__
    except Exception:
        return "unknown"


def _record_http_guidance(result, model: str, prompt_preview: str) -> None:
    """Record a Guidance call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    output_preview = ""
    try:
        if hasattr(result, "text"):
            output_preview = str(result.text)[:500]
        else:
            output_preview = str(result)[:500]
    except Exception:
        pass

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "guidance.execute",
        "prompt_preview": prompt_preview,
        "response_preview": output_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
