"""Groq auto-instrumentor for waxell-observe.

Monkey-patches ``groq.resources.chat.completions.Completions.create``
(sync) and ``AsyncCompletions.create`` (async) to emit OTel spans and
record to the Waxell HTTP API.

Also patches ``groq.resources.audio.transcriptions.Transcriptions.create``
(sync) and ``AsyncTranscriptions.create`` (async) to emit step spans for
Whisper audio transcription.

The Groq SDK response format is OpenAI-compatible:
  - ``response.usage.prompt_tokens`` / ``completion_tokens``
  - ``response.choices[].finish_reason``
  - ``response.model``

Whisper transcription response format:
  - ``response.text`` -- the transcribed text
  - ``response.language`` -- detected language (when available)

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GroqInstrumentor(BaseInstrumentor):
    """Instrumentor for the Groq Python SDK (``groq`` package).

    Patches ``chat.completions.create`` for both sync and async clients,
    and ``audio.transcriptions.create`` for Whisper STT (sync + async).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import groq.resources.chat.completions  # noqa: F401
        except ImportError:
            logger.debug("groq package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Groq instrumentation")
            return False

        wrapt.wrap_function_wrapper(
            "groq.resources.chat.completions",
            "Completions.create",
            _sync_chat_wrapper,
        )

        wrapt.wrap_function_wrapper(
            "groq.resources.chat.completions",
            "AsyncCompletions.create",
            _async_chat_wrapper,
        )

        # Patch audio.transcriptions.create (sync Whisper) -- optional
        try:
            wrapt.wrap_function_wrapper(
                "groq.resources.audio.transcriptions",
                "Transcriptions.create",
                _sync_whisper_wrapper,
            )
        except Exception:
            logger.debug("Groq Transcriptions.create not found -- Whisper sync instrumentation skipped")

        # Patch audio.transcriptions.create (async Whisper) -- optional
        try:
            wrapt.wrap_function_wrapper(
                "groq.resources.audio.transcriptions",
                "AsyncTranscriptions.create",
                _async_whisper_wrapper,
            )
        except Exception:
            logger.debug("Groq AsyncTranscriptions.create not found -- Whisper async instrumentation skipped")

        self._instrumented = True
        logger.debug("Groq chat.completions + audio.transcriptions instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import groq.resources.chat.completions as mod

            if hasattr(mod.Completions.create, "__wrapped__"):
                mod.Completions.create = mod.Completions.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(mod.AsyncCompletions.create, "__wrapped__"):
                mod.AsyncCompletions.create = mod.AsyncCompletions.create.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        try:
            import groq.resources.audio.transcriptions as audio_mod

            if hasattr(audio_mod.Transcriptions.create, "__wrapped__"):
                audio_mod.Transcriptions.create = audio_mod.Transcriptions.create.__wrapped__  # type: ignore[attr-defined]
            if hasattr(audio_mod.AsyncTranscriptions.create, "__wrapped__"):
                audio_mod.AsyncTranscriptions.create = audio_mod.AsyncTranscriptions.create.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Groq chat.completions + audio.transcriptions uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Groq ``Completions.create``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="groq")
    except Exception:
        return wrapped(*args, **kwargs)

    if is_streaming:
        try:
            from ._stream_wrappers import OpenAISyncStreamWrapper

            stream = wrapped(*args, **kwargs)
            return OpenAISyncStreamWrapper(stream, span, model)
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Groq uses OpenAI-compatible response format
            tokens_in = response.usage.prompt_tokens if response.usage else 0
            tokens_out = response.usage.completion_tokens if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reasons = (
                [c.finish_reason for c in response.choices if c.finish_reason]
                if response.choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_groq(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Groq ``AsyncCompletions.create``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="groq")
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        try:
            from ._stream_wrappers import OpenAIAsyncStreamWrapper

            stream = await wrapped(*args, **kwargs)
            return OpenAIAsyncStreamWrapper(stream, span, model)
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in = response.usage.prompt_tokens if response.usage else 0
            tokens_out = response.usage.completion_tokens if response.usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reasons = (
                [c.finish_reason for c in response.choices if c.finish_reason]
                if response.choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_groq(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_groq(response, request_model: str, kwargs: dict) -> None:
    """Record a Groq LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    tokens_in = response.usage.prompt_tokens if response.usage else 0
    tokens_out = response.usage.completion_tokens if response.usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    messages = kwargs.get("messages", [])
    prompt_preview = ""
    if messages:
        first_content = messages[0].get("content", "") if isinstance(messages[0], dict) else ""
        prompt_preview = str(first_content)[:500]

    response_preview = ""
    if response.choices:
        msg = response.choices[0].message
        if msg and msg.content:
            response_preview = msg.content[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat.completions",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data, provider="groq", _auto_instrumented=True)
    else:
        _collector.record_call(call_data)

    # Auto-capture tool calls + decisions from response
    try:
        if response.choices:
            msg = response.choices[0].message
            if msg and hasattr(msg, "tool_calls") and msg.tool_calls:
                from ._auto_decision import record_tool_decisions, extract_tool_names_from_request

                tool_calls = []
                for tc in msg.tool_calls:
                    if hasattr(tc, "function") and tc.function:
                        tool_calls.append({
                            "name": tc.function.name,
                            "input": getattr(tc.function, "arguments", ""),
                            "id": getattr(tc, "id", ""),
                        })
                if tool_calls:
                    available = extract_tool_names_from_request(kwargs)
                    record_tool_decisions(tool_calls=tool_calls, available_tools=available or None)
    except Exception:
        pass  # Never break user code


# ---------------------------------------------------------------------------
# Whisper audio transcription wrappers
# ---------------------------------------------------------------------------


def _sync_whisper_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Groq ``Transcriptions.create`` (Whisper STT)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "whisper-large-v3")
    language = kwargs.get("language", "") or ""
    response_format = kwargs.get("response_format", "json") or "json"

    try:
        span = start_step_span(step_name="groq.audio.transcribe")
        span.set_attribute("waxell.groq.whisper_model", str(model))
        if language:
            span.set_attribute("waxell.groq.language", str(language))
        span.set_attribute("waxell.groq.response_format", str(response_format))
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - t0
            transcript_text = ""
            # response.text contains the transcribed text
            if hasattr(response, "text"):
                transcript_text = str(response.text)
            elif isinstance(response, str):
                transcript_text = response

            if transcript_text:
                span.set_attribute("waxell.groq.transcript_preview", transcript_text[:500])
            span.set_attribute("waxell.groq.latency_ms", round(latency * 1000, 2))
        except Exception as attr_exc:
            logger.debug("Failed to set Whisper span attributes: %s", attr_exc)

        try:
            _record_http_whisper(response, model, language, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_whisper_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Groq ``AsyncTranscriptions.create`` (Whisper STT)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "whisper-large-v3")
    language = kwargs.get("language", "") or ""
    response_format = kwargs.get("response_format", "json") or "json"

    try:
        span = start_step_span(step_name="groq.audio.transcribe")
        span.set_attribute("waxell.groq.whisper_model", str(model))
        if language:
            span.set_attribute("waxell.groq.language", str(language))
        span.set_attribute("waxell.groq.response_format", str(response_format))
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - t0
            transcript_text = ""
            if hasattr(response, "text"):
                transcript_text = str(response.text)
            elif isinstance(response, str):
                transcript_text = response

            if transcript_text:
                span.set_attribute("waxell.groq.transcript_preview", transcript_text[:500])
            span.set_attribute("waxell.groq.latency_ms", round(latency * 1000, 2))
        except Exception as attr_exc:
            logger.debug("Failed to set async Whisper span attributes: %s", attr_exc)

        try:
            _record_http_whisper(response, model, language, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _record_http_whisper(response, model: str, language: str, kwargs: dict) -> None:
    """Record a Groq Whisper transcription call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    transcript_text = ""
    try:
        if hasattr(response, "text"):
            transcript_text = str(response.text)
        elif isinstance(response, str):
            transcript_text = response
    except Exception:
        pass

    call_data = {
        "model": str(model),
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "audio.transcriptions",
        "prompt_preview": f"[whisper model={model}" + (f" lang={language}" if language else "") + "]",
        "response_preview": transcript_text[:500] if transcript_text else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
