"""Mistral AI auto-instrumentor for waxell-observe.

Monkey-patches ``mistralai.chat.Chat.complete`` (sync) and
``Chat.complete_async`` (async) to emit OTel spans and record to
the Waxell HTTP API.  Also patches ``Mistral.embeddings.create``
(v2.x) or ``Embeddings.create`` (v1.x) to emit embedding spans.

The Mistral SDK response format is OpenAI-compatible:
  - ``response.usage.prompt_tokens`` / ``completion_tokens``
  - ``response.choices[].finish_reason``
  - ``response.model``

Mistral embedding response format:
  - ``response.data[0].embedding`` for dimensions
  - ``response.usage.total_tokens`` / ``response.usage.prompt_tokens``

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MistralInstrumentor(BaseInstrumentor):
    """Instrumentor for the Mistral AI Python SDK (``mistralai`` package).

    Patches ``chat.complete`` for both sync and async paths, and
    ``embeddings.create`` for embedding instrumentation.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import mistralai  # noqa: F401
        except ImportError:
            logger.debug("mistralai package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Mistral instrumentation")
            return False

        # Mistral SDK v1.x: mistralai.chat.Chat.complete / complete_async
        # Mistral SDK v2.x (2025+): mistralai.client.MistralClient or
        #   mistralai.Mistral — we try both patterns.
        patched = False

        # Try v1.x path: mistralai.chat.Chat
        try:
            wrapt.wrap_function_wrapper(
                "mistralai.chat",
                "Chat.complete",
                _sync_chat_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "mistralai.chat",
                "Chat.complete_async",
                _async_chat_wrapper,
            )
            patched = True
        except Exception:
            pass

        # Try newer SDK path: mistralai.models.chat / client methods
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "mistralai",
                    "Mistral.chat.complete",
                    _sync_chat_wrapper,
                )
                wrapt.wrap_function_wrapper(
                    "mistralai",
                    "Mistral.chat.complete_async",
                    _async_chat_wrapper,
                )
                patched = True
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find Mistral chat methods to patch")
            return False

        # Patch embeddings
        try:
            wrapt.wrap_function_wrapper(
                "mistralai",
                "Mistral.embeddings.create",
                _sync_embeddings_wrapper,
            )
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "mistralai.embeddings",
                    "Embeddings.create",
                    _sync_embeddings_wrapper,
                )
            except Exception:
                logger.debug("Mistral embeddings.create not found -- embedding instrumentation skipped")

        self._instrumented = True
        logger.debug("Mistral chat.complete instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import mistralai.chat as mod

            if hasattr(mod.Chat.complete, "__wrapped__"):
                mod.Chat.complete = mod.Chat.complete.__wrapped__  # type: ignore[attr-defined]
            if hasattr(mod.Chat.complete_async, "__wrapped__"):
                mod.Chat.complete_async = mod.Chat.complete_async.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        try:
            from mistralai import Mistral

            if hasattr(Mistral.embeddings.create, "__wrapped__"):
                Mistral.embeddings.create = Mistral.embeddings.create.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Mistral chat.complete uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Mistral ``Chat.complete``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="mistral")
    except Exception:
        return wrapped(*args, **kwargs)

    if is_streaming:
        try:
            from ._stream_wrappers import OpenAISyncStreamWrapper

            stream = wrapped(*args, **kwargs)
            return OpenAISyncStreamWrapper(stream, span, model, provider="mistral")
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            choices = getattr(response, "choices", None)
            finish_reasons = (
                [c.finish_reason for c in choices if c.finish_reason]
                if choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_mistral(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Mistral ``Chat.complete_async``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="mistral")
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        try:
            from ._stream_wrappers import OpenAIAsyncStreamWrapper

            stream = await wrapped(*args, **kwargs)
            return OpenAIAsyncStreamWrapper(stream, span, model, provider="mistral")
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            choices = getattr(response, "choices", None)
            finish_reasons = (
                [c.finish_reason for c in choices if c.finish_reason]
                if choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_mistral(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_mistral(response, request_model: str, kwargs: dict) -> None:
    """Record a Mistral LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    usage = getattr(response, "usage", None)
    tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
    tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    messages = kwargs.get("messages", [])
    prompt_preview = ""
    if messages:
        first = messages[0]
        first_content = first.get("content", "") if isinstance(first, dict) else str(first)
        prompt_preview = str(first_content)[:500]

    response_preview = ""
    choices = getattr(response, "choices", None)
    if choices:
        msg = choices[0].message
        if msg and getattr(msg, "content", None):
            response_preview = msg.content[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat.complete",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)

    # Auto-capture tool calls + decisions from response
    try:
        if choices:
            msg = choices[0].message
            if msg and hasattr(msg, "tool_calls") and msg.tool_calls:
                from ._auto_decision import record_tool_decisions, extract_tool_names_from_request

                tool_calls = []
                for tc in msg.tool_calls:
                    if hasattr(tc, "function") and tc.function:
                        tool_calls.append({
                            "name": tc.function.name,
                            "input": getattr(tc.function, "arguments", ""),
                            "id": getattr(tc, "id", ""),
                        })
                if tool_calls:
                    available = extract_tool_names_from_request(kwargs)
                    record_tool_decisions(tool_calls=tool_calls, available_tools=available or None)
    except Exception:
        pass  # Never break user code


# ---------------------------------------------------------------------------
# Embedding wrappers
# ---------------------------------------------------------------------------


def _sync_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Mistral ``embeddings.create``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "mistral-embed")
    inputs = kwargs.get("inputs", kwargs.get("input", []))

    # Count inputs
    if isinstance(inputs, list):
        input_count = len(inputs)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=model, provider_name="mistral", input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Mistral embedding response: response.data[0].embedding for dimensions
            # response.usage.total_tokens or response.usage.prompt_tokens for tokens
            usage = getattr(response, "usage", None)
            tokens = getattr(usage, "total_tokens", 0) if usage else 0
            if not tokens and usage:
                tokens = getattr(usage, "prompt_tokens", 0) or 0

            data = getattr(response, "data", None)
            dimensions = 0
            if data and len(data) > 0:
                embedding = getattr(data[0], "embedding", None)
                if embedding:
                    dimensions = len(embedding)

            cost = estimate_embedding_cost(model, tokens, "mistral")

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_mistral_embed(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _record_http_mistral_embed(response, model: str, kwargs: dict) -> None:
    """Record a Mistral embedding call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_embedding_cost

    usage = getattr(response, "usage", None)
    tokens = getattr(usage, "total_tokens", 0) if usage else 0
    if not tokens and usage:
        tokens = getattr(usage, "prompt_tokens", 0) or 0
    cost = estimate_embedding_cost(model, tokens, "mistral")

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embeddings",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step("embedding:mistral", output=call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
