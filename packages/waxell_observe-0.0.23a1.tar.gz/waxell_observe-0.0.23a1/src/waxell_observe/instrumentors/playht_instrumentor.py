"""PlayHT auto-instrumentor for waxell-observe.

Monkey-patches PlayHT SDK methods to emit OTel step spans for
text-to-speech (TTS) voice generation operations:
  - ``Client.tts``     -- full TTS synthesis (returns audio bytes/iterator)
  - ``Client.stream``  -- streaming TTS synthesis

The PlayHT Python SDK (``pyht``) accepts:
  - ``text`` (str) -- input text to synthesize
  - ``voice`` (str) -- voice ID or voice engine URI
  - ``output_format`` (str) -- e.g. "mp3", "wav", "mulaw"
  - ``sample_rate`` (int) -- e.g. 24000, 44100
  - ``speed`` (float) -- playback speed multiplier
  - ``voice_engine`` (str) -- e.g. "PlayHT2.0", "PlayHT2.0-turbo"

Cost is tracked externally by PlayHT billing, so cost is always 0.0 here.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PlayHTInstrumentor(BaseInstrumentor):
    """Instrumentor for the PlayHT Python SDK (``pyht`` package).

    Patches ``Client.tts`` and ``Client.stream``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pyht  # noqa: F401
        except ImportError:
            logger.debug("pyht package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping PlayHT instrumentation")
            return False

        patched = False

        # Patch Client.tts (sync)
        try:
            wrapt.wrap_function_wrapper(
                "pyht",
                "Client.tts",
                _sync_tts_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch PlayHT Client.tts: %s", exc)

        # Patch Client.stream (sync streaming)
        try:
            wrapt.wrap_function_wrapper(
                "pyht",
                "Client.stream",
                _sync_stream_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch PlayHT Client.stream: %s", exc)

        # Patch async variants if they exist
        try:
            wrapt.wrap_function_wrapper(
                "pyht",
                "AsyncClient.tts",
                _async_tts_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch PlayHT AsyncClient.tts: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "pyht",
                "AsyncClient.stream",
                _async_stream_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch PlayHT AsyncClient.stream: %s", exc)

        if not patched:
            logger.debug("Could not find any PlayHT methods to patch")
            return False

        self._instrumented = True
        logger.debug("PlayHT instrumented (tts + stream, sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import pyht

            for cls_name in ("Client", "AsyncClient"):
                cls = getattr(pyht, cls_name, None)
                if cls is None:
                    continue
                for attr in ("tts", "stream"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("PlayHT uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting TTS parameters
# ---------------------------------------------------------------------------


def _extract_tts_params(args, kwargs) -> dict:
    """Extract voice, text, output_format, sample_rate, speed, voice_engine from call args.

    PlayHT Client.tts(text, voice=..., voice_engine=..., **options)
    or Client.tts(text, options=Options(...))
    """
    params = {
        "text": "",
        "voice": "",
        "voice_engine": "",
        "output_format": "",
        "sample_rate": 0,
        "speed": 0.0,
    }

    # Text is typically the first positional arg
    if args:
        arg0 = args[0]
        if isinstance(arg0, str):
            params["text"] = arg0
        elif isinstance(arg0, (list, tuple)) and arg0:
            # Some APIs accept list of text chunks
            params["text"] = " ".join(str(t) for t in arg0)

    # Override from kwargs
    if not params["text"]:
        params["text"] = kwargs.get("text", "")

    params["voice"] = kwargs.get("voice", "")
    params["voice_engine"] = kwargs.get("voice_engine", "")
    params["output_format"] = kwargs.get("output_format", kwargs.get("format", ""))
    params["sample_rate"] = kwargs.get("sample_rate", 0)
    params["speed"] = kwargs.get("speed", 0.0)

    # Check for Options object in kwargs
    options = kwargs.get("options", None)
    if options is not None:
        if not params["voice"]:
            params["voice"] = getattr(options, "voice", "") or ""
        if not params["voice_engine"]:
            params["voice_engine"] = getattr(options, "voice_engine", "") or ""
        if not params["output_format"]:
            params["output_format"] = getattr(options, "output_format", getattr(options, "format", "")) or ""
        if not params["sample_rate"]:
            params["sample_rate"] = getattr(options, "sample_rate", 0) or 0
        if not params["speed"]:
            params["speed"] = getattr(options, "speed", 0.0) or 0.0

    return params


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_tts_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for PlayHT ``Client.tts``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    params = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="playht.tts")
        _set_tts_request_attrs(span, params)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.playht.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("playht.tts", params, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_stream_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for PlayHT ``Client.stream``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    params = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="playht.tts")
        _set_tts_request_attrs(span, params)
        span.set_attribute("waxell.playht.streaming", True)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.playht.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("playht.stream", params, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_tts_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for PlayHT ``AsyncClient.tts``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    params = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="playht.tts")
        _set_tts_request_attrs(span, params)
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.playht.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("playht.tts", params, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_stream_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for PlayHT ``AsyncClient.stream``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    params = _extract_tts_params(args, kwargs)

    try:
        span = start_step_span(step_name="playht.tts")
        _set_tts_request_attrs(span, params)
        span.set_attribute("waxell.playht.streaming", True)
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.playht.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("playht.stream", params, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_tts_request_attrs(span, params: dict) -> None:
    """Set request attributes for a PlayHT TTS span."""
    text = params.get("text", "")
    voice = params.get("voice", "")
    voice_engine = params.get("voice_engine", "")
    output_format = params.get("output_format", "")
    sample_rate = params.get("sample_rate", 0)
    speed = params.get("speed", 0.0)

    if text:
        span.set_attribute("waxell.playht.text_length", len(str(text)))
    if voice:
        span.set_attribute("waxell.playht.voice_id", str(voice))
    if voice_engine:
        span.set_attribute("waxell.playht.voice_engine", str(voice_engine))
    if output_format:
        span.set_attribute("waxell.playht.output_format", str(output_format))
    if sample_rate:
        span.set_attribute("waxell.playht.sample_rate", int(sample_rate))
    if speed:
        span.set_attribute("waxell.playht.speed", float(speed))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tts_call(task: str, params: dict, latency: float) -> None:
    """Record a PlayHT TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    voice = params.get("voice", "")
    voice_engine = params.get("voice_engine", "")
    text = params.get("text", "")

    model_name = voice_engine if voice_engine else "playht"

    call_data = {
        "model": str(model_name),
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": str(text)[:500] if text else f"[voice={voice}]",
        "response_preview": f"[tts voice={voice} latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
