"""@waxell.tool decorator for automatic tool call recording.

Wraps any function so that each invocation is automatically timed and
recorded as a tool call on the current WaxellContext. No manual
``ctx.record_tool_call()`` needed.

The decorator creates an OTel span on the GLOBAL TracerProvider that wraps
the function execution.  Auto-instrumented calls within the tool (HTTP to
Elasticsearch, Redis commands, etc.) become children of this tool span in
the trace tree.  The span flows through WaxellSpanProcessor into the DB.

When OTel is not available, falls back to ``ctx.record_tool_call()``.

Usage::

    import waxell_observe as waxell

    @waxell.tool(tool_type="vector_db")
    def create_index(dim: int):
        import faiss
        return faiss.IndexFlatL2(dim)

    # Inside a WaxellContext, this call is auto-recorded:
    index = create_index(dim=384)

    # Outside a WaxellContext, it just runs normally.
"""

import functools
import inspect
import json
import time
from typing import Optional

from .instrumentors._context_var import _current_context


def tool(
    name: Optional[str] = None,
    tool_type: str = "function",
):
    """Decorator to auto-record function calls as tool invocations.

    Args:
        name: Tool name for telemetry. Defaults to the function name.
        tool_type: Classification (e.g. "function", "vector_db", "database",
            "embedding", "api"). Shows up in the tool call record.
    """

    def decorator(func):
        _tool_name = name or func.__name__
        _is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            if ctx is None:
                return func(*args, **kwargs)

            input_data = _build_input(func, args, kwargs)
            otel_span, otel_token = _start_otel_tool_span(_tool_name, tool_type)
            t0 = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                duration_ms = int((time.perf_counter() - t0) * 1000)
                output_data = _safe_output(result)
                if otel_span is not None:
                    # OTel span exists — set data as attributes, let processor
                    # convert to DB record.  Skip record_tool_call() to avoid
                    # duplicate spans.
                    _set_otel_tool_data(otel_span, input_data, output_data, "ok", duration_ms)
                else:
                    # No OTel — fall back to manual recording
                    ctx.record_tool_call(
                        name=_tool_name,
                        input=input_data,
                        output=output_data,
                        duration_ms=duration_ms,
                        status="ok",
                        tool_type=tool_type,
                    )
                return result
            except Exception as exc:
                duration_ms = int((time.perf_counter() - t0) * 1000)
                if otel_span is not None:
                    _set_otel_error(otel_span, exc)
                    _set_otel_tool_data(otel_span, input_data, {}, "error", duration_ms, error=str(exc))
                else:
                    ctx.record_tool_call(
                        name=_tool_name,
                        input=input_data,
                        output={},
                        duration_ms=duration_ms,
                        status="error",
                        tool_type=tool_type,
                        error=str(exc),
                    )
                raise
            finally:
                _end_otel_tool_span(otel_span, otel_token)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            if ctx is None:
                return await func(*args, **kwargs)

            input_data = _build_input(func, args, kwargs)
            otel_span, otel_token = _start_otel_tool_span(_tool_name, tool_type)
            t0 = time.perf_counter()
            try:
                result = await func(*args, **kwargs)
                duration_ms = int((time.perf_counter() - t0) * 1000)
                output_data = _safe_output(result)
                if otel_span is not None:
                    _set_otel_tool_data(otel_span, input_data, output_data, "ok", duration_ms)
                else:
                    ctx.record_tool_call(
                        name=_tool_name,
                        input=input_data,
                        output=output_data,
                        duration_ms=duration_ms,
                        status="ok",
                        tool_type=tool_type,
                    )
                return result
            except Exception as exc:
                duration_ms = int((time.perf_counter() - t0) * 1000)
                if otel_span is not None:
                    _set_otel_error(otel_span, exc)
                    _set_otel_tool_data(otel_span, input_data, {}, "error", duration_ms, error=str(exc))
                else:
                    ctx.record_tool_call(
                        name=_tool_name,
                        input=input_data,
                        output={},
                        duration_ms=duration_ms,
                        status="error",
                        tool_type=tool_type,
                        error=str(exc),
                    )
                raise
            finally:
                _end_otel_tool_span(otel_span, otel_token)

        return async_wrapper if _is_async else sync_wrapper

    return decorator


# ---------------------------------------------------------------------------
# OTel span helpers
# ---------------------------------------------------------------------------


def _start_otel_tool_span(tool_name: str, tool_type: str):
    """Start an OTel span on the GLOBAL provider and set it as current context.

    Uses the global TracerProvider (same provider auto-instrumentors use) so
    HTTP/DB spans created inside the tool become children of this span.

    Does NOT set ``waxell.span_type`` — that attribute tells
    WaxellSpanProcessor to skip the span (to avoid duplicates with
    record_tool_call).  Instead we use ``waxell.tool.name`` which the
    processor recognizes as a tool span and converts to kind="tool".

    Returns (span, token) where token restores the previous OTel context.
    Returns (None, None) if OTel is not available.
    """
    try:
        from opentelemetry import context as otel_context
        from opentelemetry import trace as trace_api
        from opentelemetry.trace import SpanKind

        tracer = trace_api.get_tracer("waxell.observe.tool")
        span = tracer.start_span(
            tool_name,
            kind=SpanKind.INTERNAL,
            attributes={
                "waxell.tool.name": tool_name,
                "waxell.tool.type": tool_type,
            },
        )
        ctx = trace_api.set_span_in_context(span)
        token = otel_context.attach(ctx)
        return span, token
    except Exception:
        return None, None


def _set_otel_tool_data(span, input_data, output_data, status, duration_ms, error=None):
    """Set tool execution data as OTel span attributes.

    WaxellSpanProcessor extracts these when converting to the DB record.
    """
    if span is None:
        return
    try:
        span.set_attribute("waxell.tool.input", json.dumps(input_data, default=str)[:4000])
        span.set_attribute("waxell.tool.output", json.dumps(output_data, default=str)[:4000])
        span.set_attribute("waxell.tool.status", status)
        span.set_attribute("waxell.tool.duration_ms", duration_ms)
        if error:
            span.set_attribute("waxell.tool.error", error)
            from opentelemetry.trace import StatusCode
            span.set_status(StatusCode.ERROR, error)
    except Exception:
        pass


def _end_otel_tool_span(span, token):
    """End the OTel span and restore the previous context."""
    if span is not None:
        try:
            span.end()
        except Exception:
            pass
    if token is not None:
        try:
            from opentelemetry import context as otel_context
            otel_context.detach(token)
        except Exception:
            pass


def _set_otel_error(span, exc: Exception):
    """Record an error on the OTel span."""
    if span is None:
        return
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


def _build_input(func, args: tuple, kwargs: dict) -> dict:
    """Build a serializable dict from function arguments."""
    sig = inspect.signature(func)
    params = list(sig.parameters.keys())
    data = {}
    for i, val in enumerate(args):
        key = params[i] if i < len(params) else f"arg{i}"
        data[key] = _safe_value(val)
    for key, val in kwargs.items():
        data[key] = _safe_value(val)
    return data


def _safe_value(v):
    """Convert a value to something JSON-safe for telemetry."""
    if isinstance(v, (str, int, float, bool, type(None))):
        return v
    if isinstance(v, (list, tuple)):
        if len(v) > 10:
            return f"[{type(v).__name__} len={len(v)}]"
        return [_safe_value(i) for i in v]
    if isinstance(v, dict):
        if len(v) > 10:
            return f"{{dict len={len(v)}}}"
        return {str(k): _safe_value(val) for k, val in v.items()}
    # numpy arrays, FAISS indices, model objects, etc.
    type_name = type(v).__name__
    if hasattr(v, "shape"):
        return f"<{type_name} shape={v.shape}>"
    if hasattr(v, "__len__"):
        return f"<{type_name} len={len(v)}>"
    return f"<{type_name}>"


def _safe_output(result) -> dict:
    """Convert a function return value to a serializable dict for telemetry."""
    if result is None:
        return {}
    if isinstance(result, dict):
        return {str(k): _safe_value(v) for k, v in result.items()}
    if isinstance(result, (str, int, float, bool)):
        return {"result": result}
    # Non-serializable (numpy array, FAISS index, etc.)
    return {"result": _safe_value(result)}
