"""@waxell.retry decorator for automatic retry recording.

Wraps a function with retry logic AND records each retry attempt on the
current WaxellContext. Combines functional retry behavior with
observability — no need for separate retry libraries.

Usage::

    import waxell_observe as waxell

    @waxell.retry(max_attempts=3, strategy="retry")
    async def call_llm(prompt: str) -> str:
        response = await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content

    # On failure, retries up to 3 times, recording each attempt.
    # After exhausting attempts, re-raises the last exception.

Fallback example::

    @waxell.retry(max_attempts=2, strategy="fallback", fallback_to="groq")
    async def call_primary(prompt: str) -> str:
        return await openai_client.chat.completions.create(...)

    # Records: retry(attempt=1, reason="...", strategy="fallback", fallback_to="groq")
"""

import asyncio
import functools
import inspect

from .instrumentors._context_var import _current_context


def retry(
    max_attempts: int = 3,
    strategy: str = "retry",
    fallback_to: str = "",
):
    """Decorator that retries a function on failure and records each attempt.

    Args:
        max_attempts: Maximum number of attempts (including the first).
        strategy: ``"retry"``, ``"fallback"``, or ``"circuit_break"``.
        fallback_to: Name of fallback target (model, agent, tool) when
            strategy is ``"fallback"``.
    """

    def decorator(func):
        _is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return await func(*args, **kwargs)
                except Exception as exc:
                    last_exc = exc
                    ctx = _current_context.get()
                    if ctx:
                        ctx.record_retry(
                            attempt=attempt,
                            reason=str(exc),
                            strategy=strategy,
                            original_error=f"{type(exc).__name__}: {exc}",
                            fallback_to=fallback_to,
                            max_attempts=max_attempts,
                        )
                    if attempt >= max_attempts:
                        raise
                    # Brief backoff before retry
                    await asyncio.sleep(0.1 * attempt)
            raise last_exc  # type: ignore[misc]

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as exc:
                    last_exc = exc
                    ctx = _current_context.get()
                    if ctx:
                        ctx.record_retry(
                            attempt=attempt,
                            reason=str(exc),
                            strategy=strategy,
                            original_error=f"{type(exc).__name__}: {exc}",
                            fallback_to=fallback_to,
                            max_attempts=max_attempts,
                        )
                    if attempt >= max_attempts:
                        raise
                    import time
                    time.sleep(0.1 * attempt)
            raise last_exc  # type: ignore[misc]

        return async_wrapper if _is_async else sync_wrapper

    return decorator
