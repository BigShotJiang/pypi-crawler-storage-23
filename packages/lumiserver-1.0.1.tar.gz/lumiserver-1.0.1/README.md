# LumiServer

LumiDesktop 的后端 API 服务，可作为独立的 CLI 工具使用。

## 安装

```bash
pipx install lumiserver
```

## 使用

### 初始化配置

```bash
lumi init
```

### 启动服务

```bash
lumi serve
```

### 查看帮助

```bash
lumi --help
```

## API 文档

服务启动后访问 `http://localhost:52341/docs` 查看完整 API 文档。
