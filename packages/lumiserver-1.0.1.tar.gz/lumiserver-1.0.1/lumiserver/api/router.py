"""主路由聚合"""

from fastapi import APIRouter

from . import chat, config, models, system

# 创建 API v1 路由
api_router = APIRouter(prefix="/api/v1")

# 注册子路由
api_router.include_router(system.router)
api_router.include_router(config.router)
api_router.include_router(models.router)
api_router.include_router(chat.router)
