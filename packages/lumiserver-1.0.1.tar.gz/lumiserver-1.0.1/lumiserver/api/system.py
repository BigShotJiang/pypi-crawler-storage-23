"""系统状态 API"""

import time
from datetime import datetime

from fastapi import APIRouter

from ..models.schemas import HealthResponse, SystemInfo

router = APIRouter(prefix="/system", tags=["系统状态"])

# 服务启动时间
_start_time = time.time()


@router.get("/health", response_model=HealthResponse, summary="健康检查")
async def health_check():
    """检查服务健康状态"""
    return HealthResponse(status="healthy", timestamp=datetime.now())


@router.get("/info", response_model=SystemInfo, summary="系统信息")
async def get_system_info():
    """获取系统信息"""
    from .. import __version__

    # 这些值将在 main.py 中通过依赖注入或全局变量设置
    return SystemInfo(
        version=__version__,
        api_port=52341,
        webui_port=52342,
        data_dir="./",
        uptime=time.time() - _start_time,
    )
