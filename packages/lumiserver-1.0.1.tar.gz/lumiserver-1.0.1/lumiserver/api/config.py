"""配置管理 API"""

from typing import Dict

from fastapi import APIRouter, HTTPException

from ..models.schemas import (
    AIProvider,
    AppSettings,
    ConfigResponse,
    ConfigUpdate,
    Live2DModel,
    PromptTemplate,
)
from ..services.config_service import ConfigService

router = APIRouter(prefix="/config", tags=["配置管理"])

# 全局配置服务实例（将在 main.py 中初始化）
config_service: ConfigService = None


def init_config_service(service: ConfigService):
    """初始化配置服务"""
    global config_service
    config_service = service


# ============================================================================
# 完整配置
# ============================================================================


@router.get("", response_model=ConfigResponse, summary="获取完整配置")
async def get_config():
    """获取完整的应用配置"""
    return config_service.get_config()


@router.put("", response_model=ConfigResponse, summary="更新配置")
async def update_config(update: ConfigUpdate):
    """部分更新应用配置"""
    return await config_service.update_config(update)


# ============================================================================
# AI 供应商管理
# ============================================================================


@router.get("/providers", response_model=Dict[str, AIProvider], summary="获取所有 AI 供应商")
async def get_providers():
    """获取所有 AI 供应商配置"""
    return await config_service.get_providers()


@router.post("/providers/{provider_id}", response_model=AIProvider, summary="添加或更新 AI 供应商")
async def add_or_update_provider(provider_id: str, provider: AIProvider):
    """添加或更新指定的 AI 供应商配置"""
    return await config_service.add_or_update_provider(provider_id, provider)


@router.delete("/providers/{provider_id}", summary="删除 AI 供应商")
async def delete_provider(provider_id: str):
    """删除指定的 AI 供应商"""
    success = await config_service.delete_provider(provider_id)
    if not success:
        raise HTTPException(status_code=404, detail=f"供应商不存在: {provider_id}")
    return {"message": f"供应商 {provider_id} 已删除"}


# ============================================================================
# 提示词管理
# ============================================================================


@router.get("/prompts", response_model=Dict[str, PromptTemplate], summary="获取所有提示词模板")
async def get_prompts():
    """获取所有角色提示词模板"""
    return await config_service.get_prompts()


@router.post("/prompts/{prompt_id}", response_model=PromptTemplate, summary="添加或更新提示词模板")
async def add_or_update_prompt(prompt_id: str, prompt: PromptTemplate):
    """添加或更新指定的提示词模板"""
    return await config_service.add_or_update_prompt(prompt_id, prompt)


@router.delete("/prompts/{prompt_id}", summary="删除提示词模板")
async def delete_prompt(prompt_id: str):
    """删除指定的提示词模板"""
    success = await config_service.delete_prompt(prompt_id)
    if not success:
        raise HTTPException(status_code=404, detail=f"提示词模板不存在: {prompt_id}")
    return {"message": f"提示词模板 {prompt_id} 已删除"}


# ============================================================================
# 应用设置
# ============================================================================


@router.get("/settings", response_model=AppSettings, summary="获取应用设置")
async def get_settings():
    """获取应用设置"""
    return await config_service.get_settings()


@router.put("/settings", response_model=AppSettings, summary="更新应用设置")
async def update_settings(settings: AppSettings):
    """更新应用设置"""
    return await config_service.update_settings(settings)
