"""Server: MCP server factory, execution routing, transport management."""
