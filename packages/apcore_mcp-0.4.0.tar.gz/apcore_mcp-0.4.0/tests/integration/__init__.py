"""Integration tests for apcore-mcp."""
