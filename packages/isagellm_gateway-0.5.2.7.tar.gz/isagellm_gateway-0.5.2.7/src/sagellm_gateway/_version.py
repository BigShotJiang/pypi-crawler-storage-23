"""Version information for sagellm-gateway."""

__version__ = "0.5.2.7"
