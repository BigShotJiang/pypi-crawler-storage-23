"""Tests for the config loader module."""

import os
from pathlib import Path

import pytest
from pydantic import BaseModel

from athena.config.loader import (
    DELETE_SENTINEL,
    ConfigLoadError,
    deep_merge,
    load_config,
    load_yaml,
    resolve_config,
)
from athena.config.resolver import (
    ReferenceError,
    resolve_references,
)

# ============================================================================
# Test models
# ============================================================================


class SimpleConfig(BaseModel):
    """Simple test config."""

    name: str
    value: int


class NestedConfig(BaseModel):
    """Config with nested fields."""

    outer: str
    inner: SimpleConfig


class OptionalConfig(BaseModel):
    """Config with optional fields."""

    required: str
    optional: str | None = None
    with_default: int = 42


# ============================================================================
# deep_merge tests
# ============================================================================


class TestDeepMerge:
    """Tests for deep_merge function."""

    def test_simple_merge(self) -> None:
        """Test merging simple dicts."""
        base = {"a": 1, "b": 2}
        overrides = {"b": 3, "c": 4}

        result = deep_merge(base, overrides)

        assert result == {"a": 1, "b": 3, "c": 4}

    def test_nested_merge(self) -> None:
        """Test merging nested dicts."""
        base = {"a": 1, "nested": {"x": 10, "y": 20}}
        overrides = {"nested": {"y": 30, "z": 40}}

        result = deep_merge(base, overrides)

        assert result == {"a": 1, "nested": {"x": 10, "y": 30, "z": 40}}

    def test_override_non_dict_with_dict(self) -> None:
        """Test that dict overrides non-dict value."""
        base = {"a": 1}
        overrides = {"a": {"nested": True}}

        result = deep_merge(base, overrides)

        assert result == {"a": {"nested": True}}

    def test_override_dict_with_non_dict(self) -> None:
        """Test that non-dict overrides dict value."""
        base = {"a": {"nested": True}}
        overrides = {"a": 1}

        result = deep_merge(base, overrides)

        assert result == {"a": 1}

    def test_empty_base(self) -> None:
        """Test merging into empty dict."""
        base = {}
        overrides = {"a": 1, "b": {"c": 2}}

        result = deep_merge(base, overrides)

        assert result == {"a": 1, "b": {"c": 2}}

    def test_empty_overrides(self) -> None:
        """Test merging with empty overrides."""
        base = {"a": 1, "b": {"c": 2}}
        overrides = {}

        result = deep_merge(base, overrides)

        assert result == {"a": 1, "b": {"c": 2}}

    def test_deeply_nested(self) -> None:
        """Test deeply nested merge."""
        base = {"l1": {"l2": {"l3": {"value": 1}}}}
        overrides = {"l1": {"l2": {"l3": {"other": 2}}}}

        result = deep_merge(base, overrides)

        assert result == {"l1": {"l2": {"l3": {"value": 1, "other": 2}}}}

    def test_base_unchanged(self) -> None:
        """Test that merge doesn't modify base."""
        base = {"a": {"b": 1}}
        overrides = {"a": {"b": 2, "c": 3}}

        deep_merge(base, overrides)

        assert base == {"a": {"b": 1}}

    def test_overrides_unchanged(self) -> None:
        """Test that merge doesn't modify overrides."""
        base = {"a": {"b": 1}}
        overrides = {"a": {"b": 2, "c": 3}}

        deep_merge(base, overrides)

        assert overrides == {"a": {"b": 2, "c": 3}}

    def test_delete_sentinel(self) -> None:
        """Test that delete sentinel removes key."""
        base = {"a": 1, "b": 2, "c": 3}
        overrides = {"b": DELETE_SENTINEL}

        result = deep_merge(base, overrides)

        assert result == {"a": 1, "c": 3}

    def test_delete_sentinel_nested(self) -> None:
        """Test delete sentinel in nested dict."""
        base = {"outer": {"a": 1, "b": 2}}
        overrides = {"outer": {"a": DELETE_SENTINEL}}

        result = deep_merge(base, overrides)

        assert result == {"outer": {"b": 2}}

    def test_delete_sentinel_missing_key(self) -> None:
        """Test delete sentinel on non-existent key is no-op."""
        base = {"a": 1}
        overrides = {"b": DELETE_SENTINEL}

        result = deep_merge(base, overrides)

        assert result == {"a": 1}


# ============================================================================
# load_yaml tests
# ============================================================================


class TestLoadYaml:
    """Tests for load_yaml function."""

    def test_simple_yaml(self, tmp_path: Path) -> None:
        """Test loading simple YAML file."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("name: test\nvalue: 42\n")

        result = load_yaml(config_file)

        assert result == {"name": "test", "value": 42}

    def test_nested_yaml(self, tmp_path: Path) -> None:
        """Test loading YAML with nested structure."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            """
outer:
  inner:
    value: 123
    items:
      - a
      - b
            """
        )

        result = load_yaml(config_file)

        assert result == {"outer": {"inner": {"value": 123, "items": ["a", "b"]}}}

    def test_empty_yaml(self, tmp_path: Path) -> None:
        """Test loading empty YAML file."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("")

        result = load_yaml(config_file)

        assert result == {}

    def test_include_directive(self, tmp_path: Path) -> None:
        """Test $include directive."""
        base_file = tmp_path / "base.yaml"
        base_file.write_text("name: base\nvalue: 1\n")

        override_file = tmp_path / "override.yaml"
        override_file.write_text("$include: base.yaml\nvalue: 2\n")

        result = load_yaml(override_file)

        assert result == {"name": "base", "value": 2}

    def test_nested_include(self, tmp_path: Path) -> None:
        """Test nested $include directives."""
        base_file = tmp_path / "base.yaml"
        base_file.write_text("name: base\nvalue: 1\n")

        mid_file = tmp_path / "mid.yaml"
        mid_file.write_text("$include: base.yaml\nvalue: 2\n")

        top_file = tmp_path / "top.yaml"
        top_file.write_text("$include: mid.yaml\nvalue: 3\n")

        result = load_yaml(top_file)

        assert result == {"name": "base", "value": 3}

    def test_include_in_nested_dict(self, tmp_path: Path) -> None:
        """Test $include in nested dict."""
        base_file = tmp_path / "base.yaml"
        base_file.write_text("x: 1\ny: 2\n")

        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            """
name: test
nested:
  $include: base.yaml
  y: 3
            """
        )

        result = load_yaml(config_file)

        assert result == {"name": "test", "nested": {"x": 1, "y": 3}}

    def test_include_relative_path(self, tmp_path: Path) -> None:
        """Test $include with relative path in subdirectory."""
        subdir = tmp_path / "subdir"
        subdir.mkdir()

        base_file = tmp_path / "base.yaml"
        base_file.write_text("value: 1\n")

        config_file = subdir / "config.yaml"
        config_file.write_text("$include: ../base.yaml\nvalue: 2\n")

        result = load_yaml(config_file)

        assert result == {"value": 2}

    def test_circular_include_raises(self, tmp_path: Path) -> None:
        """Test that circular includes raise error."""
        file_a = tmp_path / "a.yaml"
        file_b = tmp_path / "b.yaml"

        file_a.write_text("$include: b.yaml\n")
        file_b.write_text("$include: a.yaml\n")

        with pytest.raises(ConfigLoadError, match="Circular include"):
            load_yaml(file_a)

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        """Test that missing file raises error."""
        config_file = tmp_path / "nonexistent.yaml"

        with pytest.raises(ConfigLoadError, match="Cannot read"):
            load_yaml(config_file)

    def test_invalid_yaml_raises(self, tmp_path: Path) -> None:
        """Test that invalid YAML raises error."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("invalid: yaml: syntax:\n")

        with pytest.raises(ConfigLoadError, match="Invalid YAML"):
            load_yaml(config_file)

    def test_non_dict_yaml_raises(self, tmp_path: Path) -> None:
        """Test that non-dict YAML raises error."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("- item1\n- item2\n")

        with pytest.raises(ConfigLoadError, match="must contain a YAML mapping"):
            load_yaml(config_file)


# ============================================================================
# load_config tests
# ============================================================================


class TestLoadConfig:
    """Tests for load_config function."""

    def test_simple_config(self, tmp_path: Path) -> None:
        """Test loading config with schema validation."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("name: test\nvalue: 42\n")

        config = load_config(config_file, SimpleConfig)

        assert config.name == "test"
        assert config.value == 42

    def test_nested_config(self, tmp_path: Path) -> None:
        """Test loading nested config."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            """
outer: hello
inner:
  name: nested
  value: 123
            """
        )

        config = load_config(config_file, NestedConfig)

        assert config.outer == "hello"
        assert config.inner.name == "nested"
        assert config.inner.value == 123

    def test_optional_fields(self, tmp_path: Path) -> None:
        """Test config with optional fields."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("required: present\n")

        config = load_config(config_file, OptionalConfig)

        assert config.required == "present"
        assert config.optional is None
        assert config.with_default == 42

    def test_validation_error(self, tmp_path: Path) -> None:
        """Test that validation errors are raised."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("name: test\nvalue: not_an_int\n")

        with pytest.raises(ConfigLoadError, match="Config validation failed"):
            load_config(config_file, SimpleConfig)

    def test_missing_required_field(self, tmp_path: Path) -> None:
        """Test that missing required fields raise error."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("name: test\n")  # Missing 'value'

        with pytest.raises(ConfigLoadError, match="Config validation failed"):
            load_config(config_file, SimpleConfig)

    def test_with_include(self, tmp_path: Path) -> None:
        """Test loading config with $include and schema validation."""
        base_file = tmp_path / "base.yaml"
        base_file.write_text("name: base\nvalue: 1\n")

        override_file = tmp_path / "override.yaml"
        override_file.write_text("$include: base.yaml\nvalue: 999\n")

        config = load_config(override_file, SimpleConfig)

        assert config.name == "base"
        assert config.value == 999


# ============================================================================
# $extends tests
# ============================================================================


class TestExtends:
    """Tests for $extends directive."""

    def test_extends_basic(self, tmp_path: Path) -> None:
        """Test basic $extends inheritance."""
        parent = tmp_path / "parent.yaml"
        parent.write_text("name: parent\nvalue: 1\nextra: from_parent\n")

        child = tmp_path / "child.yaml"
        child.write_text("$extends: parent.yaml\nvalue: 2\n")

        result = load_yaml(child)

        assert result == {"name": "parent", "value": 2, "extra": "from_parent"}

    def test_extends_chain(self, tmp_path: Path) -> None:
        """Test chained $extends."""
        grandparent = tmp_path / "grandparent.yaml"
        grandparent.write_text("a: 1\nb: 1\nc: 1\n")

        parent = tmp_path / "parent.yaml"
        parent.write_text("$extends: grandparent.yaml\nb: 2\n")

        child = tmp_path / "child.yaml"
        child.write_text("$extends: parent.yaml\nc: 3\n")

        result = load_yaml(child)

        assert result == {"a": 1, "b": 2, "c": 3}

    def test_extends_with_include(self, tmp_path: Path) -> None:
        """Test $extends combined with $include."""
        parent = tmp_path / "parent.yaml"
        parent.write_text("base: from_parent\n")

        mixin = tmp_path / "mixin.yaml"
        mixin.write_text("mixin: from_mixin\n")

        child = tmp_path / "child.yaml"
        child.write_text("$extends: parent.yaml\n$include: mixin.yaml\nown: from_child\n")

        result = load_yaml(child)

        assert result == {"base": "from_parent", "mixin": "from_mixin", "own": "from_child"}

    def test_extends_circular_raises(self, tmp_path: Path) -> None:
        """Test circular $extends raises error."""
        file_a = tmp_path / "a.yaml"
        file_b = tmp_path / "b.yaml"

        file_a.write_text("$extends: b.yaml\n")
        file_b.write_text("$extends: a.yaml\n")

        with pytest.raises(ConfigLoadError, match="Circular extends"):
            load_yaml(file_a)


# ============================================================================
# $ref tests
# ============================================================================


class TestRef:
    """Tests for $ref directive."""

    def test_ref_basic(self, tmp_path: Path) -> None:
        """Test basic $ref loading."""
        block_config = tmp_path / "block.yaml"
        block_config.write_text("epochs: 100\nlr: 0.001\n")

        workflow = tmp_path / "workflow.yaml"
        workflow.write_text(
            """
blocks:
  TrainVAE:
    $ref: block.yaml
            """
        )

        result = load_yaml(workflow)

        assert result == {"blocks": {"TrainVAE": {"epochs": 100, "lr": 0.001}}}

    def test_ref_with_overrides(self, tmp_path: Path) -> None:
        """Test $ref with inline overrides."""
        block_config = tmp_path / "block.yaml"
        block_config.write_text("epochs: 100\nlr: 0.001\nbatch_size: 32\n")

        workflow = tmp_path / "workflow.yaml"
        workflow.write_text(
            """
blocks:
  TrainVAE:
    $ref: block.yaml
    epochs: 50
    custom: added
            """
        )

        result = load_yaml(workflow)

        assert result == {
            "blocks": {
                "TrainVAE": {
                    "epochs": 50,  # overridden
                    "lr": 0.001,  # from ref
                    "batch_size": 32,  # from ref
                    "custom": "added",  # added
                }
            }
        }

    def test_ref_multiple_blocks(self, tmp_path: Path) -> None:
        """Test multiple $ref in same file."""
        vae_config = tmp_path / "vae.yaml"
        vae_config.write_text("type: vae\nepochs: 100\n")

        ldm_config = tmp_path / "ldm.yaml"
        ldm_config.write_text("type: ldm\nepochs: 500\n")

        workflow = tmp_path / "workflow.yaml"
        workflow.write_text(
            """
blocks:
  TrainVAE:
    $ref: vae.yaml
  TrainLDM:
    $ref: ldm.yaml
            """
        )

        result = load_yaml(workflow)

        assert result == {
            "blocks": {
                "TrainVAE": {"type": "vae", "epochs": 100},
                "TrainLDM": {"type": "ldm", "epochs": 500},
            }
        }

    def test_ref_in_subdirectory(self, tmp_path: Path) -> None:
        """Test $ref with path in subdirectory."""
        blocks_dir = tmp_path / "blocks"
        blocks_dir.mkdir()

        block_config = blocks_dir / "train.yaml"
        block_config.write_text("epochs: 100\n")

        workflow = tmp_path / "workflow.yaml"
        workflow.write_text(
            """
blocks:
  Train:
    $ref: blocks/train.yaml
            """
        )

        result = load_yaml(workflow)

        assert result == {"blocks": {"Train": {"epochs": 100}}}


# ============================================================================
# $include with multiple files
# ============================================================================


class TestIncludeMultiple:
    """Tests for $include with multiple files."""

    def test_include_list(self, tmp_path: Path) -> None:
        """Test $include with list of files."""
        file_a = tmp_path / "a.yaml"
        file_a.write_text("a: 1\n")

        file_b = tmp_path / "b.yaml"
        file_b.write_text("b: 2\n")

        main = tmp_path / "main.yaml"
        main.write_text(
            """
$include:
  - a.yaml
  - b.yaml
own: 3
            """
        )

        result = load_yaml(main)

        assert result == {"a": 1, "b": 2, "own": 3}

    def test_include_list_order_matters(self, tmp_path: Path) -> None:
        """Test that $include list applies in order (later wins)."""
        file_a = tmp_path / "a.yaml"
        file_a.write_text("value: from_a\n")

        file_b = tmp_path / "b.yaml"
        file_b.write_text("value: from_b\n")

        main = tmp_path / "main.yaml"
        main.write_text(
            """
$include:
  - a.yaml
  - b.yaml
            """
        )

        result = load_yaml(main)

        assert result == {"value": "from_b"}


# ============================================================================
# Reference resolution tests
# ============================================================================


class TestResolveReferences:
    """Tests for ${...} reference resolution."""

    def test_simple_reference(self) -> None:
        """Test simple path reference."""
        config = {"shared": {"value": 42}, "block": {"value": "${shared.value}"}}

        result = resolve_references(config)

        assert result == {"shared": {"value": 42}, "block": {"value": 42}}

    def test_nested_reference(self) -> None:
        """Test nested path reference."""
        config = {
            "a": {"b": {"c": 100}},
            "target": "${a.b.c}",
        }

        result = resolve_references(config)

        assert result == {"a": {"b": {"c": 100}}, "target": 100}

    def test_chained_references(self) -> None:
        """Test references that depend on other references."""
        config = {
            "base": 10,
            "mid": "${base}",
            "top": "${mid}",
        }

        result = resolve_references(config)

        assert result == {"base": 10, "mid": 10, "top": 10}

    def test_env_reference(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test environment variable reference."""
        monkeypatch.setenv("TEST_VAR", "test_value")

        config = {"value": "${env:TEST_VAR}"}

        result = resolve_references(config)

        assert result == {"value": "test_value"}

    def test_env_reference_with_default(self) -> None:
        """Test environment variable with default."""
        # Ensure var doesn't exist
        os.environ.pop("NONEXISTENT_VAR", None)

        config = {"value": "${env:NONEXISTENT_VAR:default_val}"}

        result = resolve_references(config)

        assert result == {"value": "default_val"}

    def test_env_reference_missing_raises(self) -> None:
        """Test missing env var without default raises error."""
        os.environ.pop("DEFINITELY_NOT_SET", None)

        config = {"value": "${env:DEFINITELY_NOT_SET}"}

        with pytest.raises(ReferenceError, match="Environment variable not set"):
            resolve_references(config)

    def test_string_interpolation(self) -> None:
        """Test string with multiple/partial references."""
        config = {
            "host": "localhost",
            "port": 8080,
            "url": "http://${host}:${port}/api",
        }

        result = resolve_references(config)

        assert result == {
            "host": "localhost",
            "port": 8080,
            "url": "http://localhost:8080/api",
        }

    def test_preserves_type_for_full_reference(self) -> None:
        """Test that full references preserve type (not stringify)."""
        config = {
            "number": 42,
            "ref": "${number}",
        }

        result = resolve_references(config)

        assert result["ref"] == 42
        assert isinstance(result["ref"], int)

    def test_list_reference(self) -> None:
        """Test reference to list preserves list."""
        config = {
            "items": [1, 2, 3],
            "ref": "${items}",
        }

        result = resolve_references(config)

        assert result["ref"] == [1, 2, 3]
        assert isinstance(result["ref"], list)

    def test_reference_in_list(self) -> None:
        """Test reference inside a list."""
        config = {
            "value": "x",
            "items": ["${value}", "y", "z"],
        }

        result = resolve_references(config)

        assert result == {"value": "x", "items": ["x", "y", "z"]}

    def test_circular_reference_raises(self) -> None:
        """Test circular references raise error."""
        config = {
            "a": "${b}",
            "b": "${a}",
        }

        with pytest.raises(ReferenceError, match="Circular reference"):
            resolve_references(config)

    def test_missing_reference_raises(self) -> None:
        """Test missing reference raises error."""
        config = {"ref": "${nonexistent.path}"}

        with pytest.raises(ReferenceError, match="Reference not found"):
            resolve_references(config)


# ============================================================================
# resolve_config tests
# ============================================================================


class TestResolveConfig:
    """Tests for the full resolve_config pipeline."""

    def test_full_pipeline(self, tmp_path: Path) -> None:
        """Test loading + reference resolution together."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            """
shared:
  latent_dim: 64

blocks:
  vae:
    latent_dim: ${shared.latent_dim}
    epochs: 100
  ldm:
    latent_dim: ${blocks.vae.latent_dim}
            """
        )

        result = resolve_config(config_file)

        assert result == {
            "shared": {"latent_dim": 64},
            "blocks": {
                "vae": {"latent_dim": 64, "epochs": 100},
                "ldm": {"latent_dim": 64},
            },
        }

    def test_with_overrides(self, tmp_path: Path) -> None:
        """Test resolve_config with overrides."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("epochs: 100\nlr: 0.001\n")

        result = resolve_config(config_file, overrides={"epochs": 50})

        assert result == {"epochs": 50, "lr": 0.001}

    def test_with_dot_notation_overrides(self, tmp_path: Path) -> None:
        """Test resolve_config with dot-notation overrides."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            """
blocks:
  vae:
    epochs: 100
            """
        )

        result = resolve_config(config_file, overrides={"blocks.vae.epochs": 50})

        assert result == {"blocks": {"vae": {"epochs": 50}}}

    def test_with_extends_and_refs(self, tmp_path: Path) -> None:
        """Test full pipeline with $extends, $ref, and references."""
        # Base block config
        base_block = tmp_path / "base_block.yaml"
        base_block.write_text("epochs: 100\nlr: 0.001\n")

        # VAE extends base
        vae_config = tmp_path / "vae.yaml"
        vae_config.write_text("$extends: base_block.yaml\nlatent_dim: 64\n")

        # Workflow references VAE
        workflow = tmp_path / "workflow.yaml"
        workflow.write_text(
            """
shared:
  batch_size: 32

blocks:
  TrainVAE:
    $ref: vae.yaml
    batch_size: ${shared.batch_size}
            """
        )

        result = resolve_config(workflow)

        assert result == {
            "shared": {"batch_size": 32},
            "blocks": {
                "TrainVAE": {
                    "epochs": 100,  # from base
                    "lr": 0.001,  # from base
                    "latent_dim": 64,  # from vae
                    "batch_size": 32,  # resolved from shared
                }
            },
        }
