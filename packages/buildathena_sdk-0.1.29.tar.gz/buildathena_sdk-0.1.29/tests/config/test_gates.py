"""Tests for the YAML Gate DSL module."""

from pathlib import Path

import pytest

from athena._generated_schemas import (
    AfterStepPredicate,
    GateAction,
    MetricThresholdPredicate,
    MetricWindowPredicate,
)
from athena.config.gates import (
    GateLoadError,
    load_gate,
    load_gates_from_dir,
    load_gates_from_yaml,
    parse_gate_dict,
)
from athena.config.loader import ConfigLoadError

# ============================================================================
# parse_gate_dict tests
# ============================================================================


class TestParseGateDict:
    """Tests for parse_gate_dict function."""

    def test_after_step_predicate(self) -> None:
        """Test parsing after_step gate."""
        data = {
            "name": "pause_after_vae",
            "predicate": {
                "type": "after_step",
                "node_id": "TrainVAE",
            },
            "action": "pause",
        }

        gate = parse_gate_dict(data)

        assert gate.name == "pause_after_vae"
        assert gate.action == GateAction.PAUSE
        assert isinstance(gate.predicate, AfterStepPredicate)
        assert gate.predicate.node_id == "TrainVAE"
        assert gate.predicate.status == "succeeded"  # default

    def test_metric_threshold_predicate(self) -> None:
        """Test parsing metric_threshold gate."""
        data = {
            "name": "loss_too_high",
            "predicate": {
                "type": "metric_threshold",
                "metric": "train/loss",
                "op": ">",
                "value": 10.0,
            },
            "action": "kill",
        }

        gate = parse_gate_dict(data)

        assert gate.name == "loss_too_high"
        assert gate.action == GateAction.KILL
        assert isinstance(gate.predicate, MetricThresholdPredicate)
        assert gate.predicate.metric == "train/loss"
        assert gate.predicate.op == ">"
        assert gate.predicate.value == 10.0

    def test_metric_window_predicate(self) -> None:
        """Test parsing metric_window gate."""
        data = {
            "name": "plateau_loss",
            "predicate": {
                "type": "metric_window",
                "metric": "vae/recon_loss",
                "window": 3,
                "reducer": "slope",
                "op": ">",
                "value": -1e-5,
            },
            "action": "pause",
        }

        gate = parse_gate_dict(data)

        assert gate.name == "plateau_loss"
        assert gate.action == GateAction.PAUSE
        assert isinstance(gate.predicate, MetricWindowPredicate)
        assert gate.predicate.metric == "vae/recon_loss"
        assert gate.predicate.window == 3
        assert gate.predicate.reducer == "slope"

    def test_default_values(self) -> None:
        """Test that default values are applied."""
        data = {
            "predicate": {
                "type": "after_step",
                "node_id": "SomeStep",
            },
        }

        gate = parse_gate_dict(data)

        assert gate.name == "unnamed_gate"
        assert gate.action == GateAction.PAUSE  # default
        assert gate.is_enabled is True
        assert gate.action_params == {}

    def test_all_actions(self) -> None:
        """Test all valid action types."""
        actions = ["pause", "kill", "notify"]

        for action_str in actions:
            data = {
                "name": f"test_{action_str}",
                "predicate": {"type": "after_step", "node_id": "Step"},
                "action": action_str,
            }
            gate = parse_gate_dict(data)
            assert gate.action == GateAction(action_str)

    def test_with_description(self) -> None:
        """Test gate with description."""
        data = {
            "name": "my_gate",
            "description": "Pauses after training completes",
            "predicate": {"type": "after_step", "node_id": "Train"},
            "action": "pause",
        }

        gate = parse_gate_dict(data)

        assert gate.description == "Pauses after training completes"

    def test_with_action_params(self) -> None:
        """Test gate with action parameters."""
        data = {
            "name": "notify_slack",
            "predicate": {"type": "after_step", "node_id": "Train"},
            "action": "notify",
            "action_params": {
                "channel": "#ml-alerts",
                "message": "Training complete!",
            },
        }

        gate = parse_gate_dict(data)

        assert gate.action_params == {
            "channel": "#ml-alerts",
            "message": "Training complete!",
        }

    def test_disabled_gate(self) -> None:
        """Test gate with is_enabled=False."""
        data = {
            "name": "disabled_gate",
            "predicate": {"type": "after_step", "node_id": "Train"},
            "action": "pause",
            "is_enabled": False,
        }

        gate = parse_gate_dict(data)

        assert gate.is_enabled is False

    def test_missing_predicate_raises(self) -> None:
        """Test that missing 'predicate' field raises error."""
        data = {"name": "bad_gate", "action": "pause"}

        with pytest.raises(GateLoadError, match="missing 'predicate' field"):
            parse_gate_dict(data)

    def test_missing_predicate_type_raises(self) -> None:
        """Test that missing predicate type raises error."""
        data = {
            "name": "bad_gate",
            "predicate": {"step_id": "Train"},  # missing 'type'
            "action": "pause",
        }

        with pytest.raises(GateLoadError, match="missing 'type' field"):
            parse_gate_dict(data)

    def test_invalid_action_raises(self) -> None:
        """Test that invalid action raises error."""
        data = {
            "name": "bad_gate",
            "predicate": {"type": "after_step", "node_id": "Train"},
            "action": "invalid_action",
        }

        with pytest.raises(GateLoadError, match="Invalid action"):
            parse_gate_dict(data)

    def test_unknown_predicate_type_raises(self) -> None:
        """Test that unknown predicate type raises error."""
        data = {
            "name": "bad_gate",
            "predicate": {"type": "unknown_type", "node_id": "Train"},
            "action": "pause",
        }

        with pytest.raises(GateLoadError, match="Unknown predicate type"):
            parse_gate_dict(data)


# ============================================================================
# load_gate tests
# ============================================================================


class TestLoadGate:
    """Tests for load_gate function."""

    def test_load_gate_from_file(self, tmp_path: Path) -> None:
        """Test loading gate from YAML file."""
        gate_file = tmp_path / "pause_after_vae.yaml"
        gate_file.write_text(
            """
name: pause_after_vae
predicate:
  type: after_step
  node_id: TrainVAE
action: pause
"""
        )

        gate = load_gate(gate_file)

        assert gate.name == "pause_after_vae"
        assert isinstance(gate.predicate, AfterStepPredicate)
        assert gate.predicate.node_id == "TrainVAE"

    def test_load_complex_gate(self, tmp_path: Path) -> None:
        """Test loading complex gate with all fields."""
        gate_file = tmp_path / "complex.yaml"
        gate_file.write_text(
            """
name: plateau_detector
description: Detects when loss has plateaued
predicate:
  type: metric_window
  metric: vae/recon_loss
  window: 5
  reducer: slope
  op: ">"
  value: -0.00001
action: notify
action_params:
  channel: "#alerts"
is_enabled: true
"""
        )

        gate = load_gate(gate_file)

        assert gate.name == "plateau_detector"
        assert gate.description == "Detects when loss has plateaued"
        assert isinstance(gate.predicate, MetricWindowPredicate)
        assert gate.action == GateAction.NOTIFY
        assert gate.action_params == {"channel": "#alerts"}

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        """Test that missing file raises error."""
        with pytest.raises(ConfigLoadError, match="Cannot read"):
            load_gate(tmp_path / "nonexistent.yaml")


# ============================================================================
# load_gates_from_dir tests
# ============================================================================


class TestLoadGatesFromDir:
    """Tests for load_gates_from_dir function."""

    def test_load_gates_from_dir(self, tmp_path: Path) -> None:
        """Test loading all gates from a directory."""
        gates_dir = tmp_path / "gates"
        gates_dir.mkdir()

        # Create multiple gate files
        (gates_dir / "gate1.yaml").write_text(
            """
name: gate1
predicate:
  type: after_step
  node_id: Step1
action: pause
"""
        )
        (gates_dir / "gate2.yaml").write_text(
            """
name: gate2
predicate:
  type: after_step
  node_id: Step2
action: kill
"""
        )

        gates = load_gates_from_dir(gates_dir)

        assert len(gates) == 2
        names = {g.name for g in gates}
        assert names == {"gate1", "gate2"}

    def test_load_gates_sorted_by_name(self, tmp_path: Path) -> None:
        """Test that gates are loaded in sorted order."""
        gates_dir = tmp_path / "gates"
        gates_dir.mkdir()

        # Create files in reverse order
        (gates_dir / "z_gate.yaml").write_text(
            "name: z_gate\npredicate:\n  type: after_step\n  node_id: S\naction: pause\n"
        )
        (gates_dir / "a_gate.yaml").write_text(
            "name: a_gate\npredicate:\n  type: after_step\n  node_id: S\naction: pause\n"
        )

        gates = load_gates_from_dir(gates_dir)

        assert [g.name for g in gates] == ["a_gate", "z_gate"]

    def test_load_gates_with_pattern(self, tmp_path: Path) -> None:
        """Test loading gates with custom pattern."""
        gates_dir = tmp_path / "gates"
        gates_dir.mkdir()

        (gates_dir / "prod_gate.yml").write_text(
            "name: prod\npredicate:\n  type: after_step\n  node_id: S\naction: pause\n"
        )
        (gates_dir / "test_gate.yaml").write_text(
            "name: test\npredicate:\n  type: after_step\n  node_id: S\naction: pause\n"
        )

        gates = load_gates_from_dir(gates_dir, pattern="*.yml")

        assert len(gates) == 1
        assert gates[0].name == "prod"

    def test_load_gates_recursive(self, tmp_path: Path) -> None:
        """Test recursive loading from subdirectories."""
        gates_dir = tmp_path / "gates"
        gates_dir.mkdir()

        subdir = gates_dir / "subdir"
        subdir.mkdir()

        (gates_dir / "top.yaml").write_text(
            "name: top\npredicate:\n  type: after_step\n  node_id: S\naction: pause\n"
        )
        (subdir / "nested.yaml").write_text(
            "name: nested\npredicate:\n  type: after_step\n  node_id: S\naction: pause\n"
        )

        # Non-recursive should only find top-level
        gates = load_gates_from_dir(gates_dir, recursive=False)
        assert len(gates) == 1
        assert gates[0].name == "top"

        # Recursive should find both
        gates = load_gates_from_dir(gates_dir, recursive=True)
        assert len(gates) == 2
        names = {g.name for g in gates}
        assert names == {"top", "nested"}

    def test_empty_directory(self, tmp_path: Path) -> None:
        """Test loading from empty directory."""
        gates_dir = tmp_path / "empty"
        gates_dir.mkdir()

        gates = load_gates_from_dir(gates_dir)

        assert gates == []

    def test_nonexistent_directory_raises(self, tmp_path: Path) -> None:
        """Test that nonexistent directory raises error."""
        with pytest.raises(GateLoadError, match="not found"):
            load_gates_from_dir(tmp_path / "nonexistent")


# ============================================================================
# load_gates_from_yaml tests
# ============================================================================


class TestLoadGatesFromYaml:
    """Tests for load_gates_from_yaml function."""

    def test_load_multiple_gates(self, tmp_path: Path) -> None:
        """Test loading multiple gates from single file."""
        gates_file = tmp_path / "gates.yaml"
        gates_file.write_text(
            """
gates:
  - name: gate1
    predicate:
      type: after_step
      node_id: Step1
    action: pause

  - name: gate2
    predicate:
      type: metric_threshold
      metric: loss
      op: ">"
      value: 10.0
    action: kill
"""
        )

        gates = load_gates_from_yaml(gates_file)

        assert len(gates) == 2
        assert gates[0].name == "gate1"
        assert gates[1].name == "gate2"
        assert isinstance(gates[0].predicate, AfterStepPredicate)
        assert isinstance(gates[1].predicate, MetricThresholdPredicate)

    def test_load_single_gate_format(self, tmp_path: Path) -> None:
        """Test that single gate format works without 'gates' list."""
        gates_file = tmp_path / "single.yaml"
        gates_file.write_text(
            """
name: single_gate
predicate:
  type: after_step
  node_id: Train
action: pause
"""
        )

        gates = load_gates_from_yaml(gates_file)

        assert len(gates) == 1
        assert gates[0].name == "single_gate"

    def test_no_gates_key_no_predicate_raises(self, tmp_path: Path) -> None:
        """Test that file without 'gates' list and without 'predicate' raises."""
        gates_file = tmp_path / "invalid.yaml"
        gates_file.write_text(
            """
name: incomplete
action: pause
"""
        )

        with pytest.raises(GateLoadError, match="must contain 'gates' list"):
            load_gates_from_yaml(gates_file)

    def test_empty_gates_list(self, tmp_path: Path) -> None:
        """Test loading file with empty gates list."""
        gates_file = tmp_path / "empty.yaml"
        gates_file.write_text("gates: []\n")

        gates = load_gates_from_yaml(gates_file)

        assert gates == []
