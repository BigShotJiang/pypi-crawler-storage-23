"""YAML configuration loading with composition support.

This module provides YAML loading with:
- Schema validation via Pydantic
- `$include` directive for mixin composition (multiple files)
- `$extends` directive for single inheritance
- `$ref` directive for loading external config files
- Deep merging with delete sentinel (`___`)
- Reference resolution via `${...}` syntax

Directives:
    $include: path/to/file.yaml     # Mixin: merge file, then apply overrides
    $include:                        # Multiple mixins (applied in order)
      - path/to/file1.yaml
      - path/to/file2.yaml

    $extends: parent.yaml           # Inheritance: load parent, child overrides

    $ref: path/to/config.yaml       # Reference: load entire file as value

    ___                              # Delete sentinel: remove key from parent

Usage:
    from pathlib import Path
    from athena.config.loader import load_config, load_yaml

    class PipelineConfig(BaseModel):
        epochs: int
        learning_rate: float

    config = load_config(Path("config.yaml"), PipelineConfig)

YAML with $include:
    # base.yaml
    epochs: 100
    learning_rate: 0.001

    # override.yaml
    $include: base.yaml
    learning_rate: 0.0001  # Override just this value

YAML with $extends:
    # child.yaml
    $extends: base.yaml
    epochs: 200  # Override from parent

YAML with $ref:
    # workflow.yaml
    blocks:
      TrainVAE:
        $ref: blocks/train_vae.yaml
        epochs: 50  # Override from referenced file
"""

from pathlib import Path
from typing import Any, TypeVar

import yaml
from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)


class ConfigLoadError(Exception):
    """Error raised when config loading fails."""

    pass


def load_config(path: Path, schema: type[T]) -> T:
    """Load a YAML config and validate against a Pydantic schema.

    Args:
        path: Path to the YAML config file.
        schema: Pydantic model class to validate against.

    Returns:
        An instance of the schema populated with config values.

    Raises:
        ConfigLoadError: If the file cannot be read or parsed.
        ValidationError: If the config doesn't match the schema.
    """
    raw = load_yaml(path)
    try:
        return schema.model_validate(raw)
    except ValidationError as e:
        raise ConfigLoadError(f"Config validation failed for {path}:\n{e}") from e


def load_yaml(path: Path) -> dict[str, Any]:
    """Load a YAML file with $include support.

    Args:
        path: Path to the YAML file.

    Returns:
        Dict with resolved includes and merged values.

    Raises:
        ConfigLoadError: If the file cannot be read or parsed.
    """
    path = path.resolve()
    return _load_yaml_with_includes(path, seen={path})


def _load_yaml_with_includes(path: Path, seen: set[Path]) -> dict[str, Any]:
    """Load YAML with $include support.

    Args:
        path: Path to the YAML file (must be resolved/absolute).
        seen: Set of already-seen paths to detect cycles.

    Returns:
        Dict with resolved includes.

    Raises:
        ConfigLoadError: If the file cannot be read or parsed.
    """
    try:
        content = path.read_text(encoding="utf-8")
    except OSError as e:
        raise ConfigLoadError(f"Cannot read config file {path}: {e}") from e

    try:
        raw = yaml.safe_load(content)
    except yaml.YAMLError as e:
        raise ConfigLoadError(f"Invalid YAML in {path}: {e}") from e

    if raw is None:
        return {}

    if not isinstance(raw, dict):
        raise ConfigLoadError(
            f"Config file {path} must contain a YAML mapping, got {type(raw).__name__}"
        )

    return _resolve_includes(raw, path.parent, seen=seen)


def _resolve_includes(
    data: dict[str, Any],
    base_path: Path,
    seen: set[Path],
) -> dict[str, Any]:
    """Recursively resolve $include, $extends, and $ref directives.

    Directive precedence (applied in order):
    1. $extends - Load parent config as base
    2. $include - Merge in mixin configs
    3. $ref - Load referenced configs for specific keys
    4. Local overrides - Apply remaining keys

    Args:
        data: Dict to resolve.
        base_path: Base path for relative includes.
        seen: Set of already-seen paths to detect cycles.

    Returns:
        Dict with resolved includes.
    """
    result: dict[str, Any] = {}

    # 1. Handle $extends (single inheritance)
    if "$extends" in data:
        extends_path = base_path / data["$extends"]
        extends_path = extends_path.resolve()

        if extends_path in seen:
            raise ConfigLoadError(f"Circular extends detected: {extends_path}")

        seen.add(extends_path)
        result = _load_yaml_with_includes(extends_path, seen=seen)

    # 2. Handle $include (mixin composition)
    if "$include" in data:
        includes = data["$include"]
        # Normalize to list
        if isinstance(includes, str):
            includes = [includes]

        for include_spec in includes:
            include_path = base_path / include_spec
            include_path = include_path.resolve()

            if include_path in seen:
                raise ConfigLoadError(f"Circular include detected: {include_path}")

            seen.add(include_path)
            included = _load_yaml_with_includes(include_path, seen=seen)
            result = deep_merge(result, included)

    # 3. Process remaining keys, handling $ref for nested objects
    directives = {"$include", "$extends"}
    for key, value in data.items():
        if key in directives:
            continue

        resolved_value = _resolve_value(value, base_path, seen)

        # Handle $ref at the value level (for workflow block references)
        if isinstance(resolved_value, dict) and "$ref" in resolved_value:
            ref_path = base_path / resolved_value["$ref"]
            ref_path = ref_path.resolve()

            if ref_path in seen:
                raise ConfigLoadError(f"Circular ref detected: {ref_path}")

            seen.add(ref_path)
            ref_content = _load_yaml_with_includes(ref_path, seen=seen)

            # Merge $ref content with any overrides in the same dict
            ref_overrides = {k: v for k, v in resolved_value.items() if k != "$ref"}
            resolved_value = deep_merge(ref_content, ref_overrides)

        result = deep_merge(result, {key: resolved_value})

    return result


def _resolve_value(value: Any, base_path: Path, seen: set[Path]) -> Any:
    """Resolve a single value, handling nested dicts with $include.

    Args:
        value: Value to resolve.
        base_path: Base path for relative includes.
        seen: Set of already-seen paths.

    Returns:
        Resolved value.
    """
    if isinstance(value, dict):
        return _resolve_includes(value, base_path, seen)
    elif isinstance(value, list):
        return [_resolve_value(v, base_path, seen) for v in value]
    return value


def deep_merge(base: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    """Deep merge overrides into base.

    For nested dicts, the merge is recursive. For all other types,
    the override value replaces the base value.

    Special handling:
    - If override value is "___" (delete sentinel), the key is removed
    - Lists are replaced, not merged (use "___" to clear a list)

    Args:
        base: Base dict to merge into.
        overrides: Dict with values to override.

    Returns:
        New dict with merged values.
    """
    result = dict(base)

    for key, override_val in overrides.items():
        # Handle delete sentinel
        if override_val == DELETE_SENTINEL:
            result.pop(key, None)
            continue

        if key in result:
            base_val = result[key]
            if isinstance(base_val, dict) and isinstance(override_val, dict):
                # Recursive merge for nested dicts
                result[key] = deep_merge(base_val, override_val)
            else:
                # Override replaces base
                result[key] = override_val
        else:
            # New key
            result[key] = override_val

    return result


# Delete sentinel - when a value equals this, remove the key from parent
DELETE_SENTINEL = "___"


def resolve_config(
    path: Path,
    overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Load a config file and resolve all references.

    This is the main entry point for the full config resolution pipeline:
    1. Load YAML with $include, $extends, $ref directives
    2. Apply overrides (if provided)
    3. Resolve ${...} references
    4. Return fully resolved config

    Args:
        path: Path to the config file.
        overrides: Optional dict of overrides to apply before resolution.
                  Supports dot-notation keys (e.g., "blocks.TrainVAE.epochs").

    Returns:
        Fully resolved config dict.

    Raises:
        ConfigLoadError: If loading fails.
        ReferenceError: If reference resolution fails.
    """
    from athena.config.resolver import resolve_references

    # Load with directives
    config = load_yaml(path)

    # Apply overrides
    if overrides:
        config = _apply_overrides(config, overrides)

    # Resolve references
    config = resolve_references(config)

    return config


def _apply_overrides(config: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    """Apply overrides to a config, supporting dot-notation keys.

    Args:
        config: Base config dict.
        overrides: Dict of overrides. Keys can use dot notation:
                  {"blocks.TrainVAE.epochs": 100}

    Returns:
        Config with overrides applied.
    """
    result = dict(config)

    for key, value in overrides.items():
        if "." in key:
            # Dot notation - navigate and set
            parts = key.split(".")
            current = result

            # Navigate to parent
            for part in parts[:-1]:
                if part not in current or not isinstance(current[part], dict):
                    current[part] = {}
                current = current[part]

            # Set value
            current[parts[-1]] = value
        else:
            # Simple key
            result[key] = value

    return result
