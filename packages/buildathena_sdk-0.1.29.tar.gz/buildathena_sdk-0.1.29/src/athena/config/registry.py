"""Registry pattern for config object types.

The Registry provides a mapping from string names to implementation classes,
enabling:
- Type-safe lookups by name (vs arbitrary class paths)
- UI-friendly dropdown options via names() method
- Decorator-based registration for clean syntax

Usage:
    from athena.config import transforms

    @transforms.register("normalize")
    class NormalizeTransform:
        def __init__(self, mean: float, std: float):
            self.mean = mean
            self.std = std

    # Later, in config instantiation:
    cls = transforms.get("normalize")
    instance = cls(mean=0.5, std=0.1)
"""

from collections.abc import Callable
from typing import Any, TypeVar

T = TypeVar("T")


class RegistryError(Exception):
    """Error raised when registry lookup fails."""

    pass


class Registry:
    """A registry mapping names to implementation classes.

    Each registry is named (e.g., "transform", "dataset") and provides:
    - register(name): Decorator to register an implementation
    - get(name): Lookup implementation by name
    - names(): List all registered names (for UI dropdowns)
    - has(name): Check if a name is registered

    Example:
        transforms = Registry("transform")

        @transforms.register("log")
        class LogTransform:
            def __init__(self, base: float = 10):
                self.base = base

        # Lookup and instantiate
        cls = transforms.get("log")
        transform = cls(base=10)
    """

    def __init__(self, name: str) -> None:
        """Initialize the registry.

        Args:
            name: Human-readable name for the registry (e.g., "transform").
                  Used in error messages.
        """
        self.name = name
        self._registry: dict[str, type[Any]] = {}

    def register(self, name: str) -> Callable[[type[T]], type[T]]:
        """Decorator to register an implementation class.

        Args:
            name: The name to register the class under (e.g., "normalize").

        Returns:
            A decorator that registers the class and returns it unchanged.

        Raises:
            RegistryError: If the name is already registered.

        Example:
            @transforms.register("normalize")
            class NormalizeTransform:
                ...
        """

        def decorator(cls: type[T]) -> type[T]:
            if name in self._registry:
                existing = self._registry[name]
                raise RegistryError(
                    f"Cannot register {cls.__name__} as '{name}' in {self.name} registry: "
                    f"name already registered to {existing.__name__}"
                )
            self._registry[name] = cls
            return cls

        return decorator

    def register_class(self, name: str, cls: type[Any]) -> None:
        """Register a class directly (non-decorator form).

        Args:
            name: The name to register the class under.
            cls: The class to register.

        Raises:
            RegistryError: If the name is already registered.
        """
        if name in self._registry:
            existing = self._registry[name]
            raise RegistryError(
                f"Cannot register {cls.__name__} as '{name}' in {self.name} registry: "
                f"name already registered to {existing.__name__}"
            )
        self._registry[name] = cls

    def get(self, name: str) -> type[Any]:
        """Get an implementation class by name.

        Args:
            name: The registered name to look up.

        Returns:
            The registered class.

        Raises:
            RegistryError: If the name is not registered.
        """
        if name not in self._registry:
            available = ", ".join(sorted(self._registry.keys())) or "(none)"
            raise RegistryError(f"Unknown {self.name}: '{name}'. Available: {available}")
        return self._registry[name]

    def has(self, name: str) -> bool:
        """Check if a name is registered.

        Args:
            name: The name to check.

        Returns:
            True if the name is registered, False otherwise.
        """
        return name in self._registry

    def names(self) -> list[str]:
        """Return all registered names (for UI dropdowns).

        Returns:
            Sorted list of registered names.
        """
        return sorted(self._registry.keys())

    def __len__(self) -> int:
        """Return the number of registered implementations."""
        return len(self._registry)

    def __contains__(self, name: str) -> bool:
        """Check if a name is registered (supports `in` operator)."""
        return name in self._registry

    def __repr__(self) -> str:
        """Return a string representation of the registry."""
        return f"Registry('{self.name}', {len(self._registry)} entries)"

    def clear(self) -> None:
        """Clear all registered implementations.

        Primarily useful for testing.
        """
        self._registry.clear()
