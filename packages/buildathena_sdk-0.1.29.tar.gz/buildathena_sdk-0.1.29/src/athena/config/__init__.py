"""Configuration system for Athena.

This module provides:
- Registry pattern for any object types
- ObjectSpec for type-safe configuration with children support
- YAML loading with $include, $extends, $ref support
- Reference resolution via ${...} syntax
- Deep merging with delete sentinel
- Recursive instantiation of config trees
- YAML Gate DSL loading
"""

from athena.config.gates import (
    GateLoadError,
    load_gate,
    load_gates_from_dir,
    load_gates_from_yaml,
    parse_gate_dict,
)
from athena.config.instantiate import instantiate
from athena.config.loader import (
    DELETE_SENTINEL,
    ConfigLoadError,
    deep_merge,
    load_config,
    load_yaml,
    resolve_config,
)
from athena.config.registry import Registry
from athena.config.resolver import (
    ReferenceError,
    resolve_references,
)
from athena.config.specs import (
    CustomObjectSpec,
    ObjectSpec,
)

# Single global registry - users register all types here
objects = Registry("objects")

__all__ = [
    # Registry
    "Registry",
    # Global registry
    "objects",
    # Specs
    "ObjectSpec",
    "CustomObjectSpec",
    # Loading functions
    "load_config",
    "load_yaml",
    "resolve_config",
    "resolve_references",
    "deep_merge",
    # Errors
    "ConfigLoadError",
    "ReferenceError",
    # Constants
    "DELETE_SENTINEL",
    # Instantiation
    "instantiate",
    # Gate DSL
    "GateLoadError",
    "load_gate",
    "load_gates_from_dir",
    "load_gates_from_yaml",
    "parse_gate_dict",
]
