"""Athena SDK - Python SDK for building blocks."""

from athena.config import (
    CustomObjectSpec,
    ObjectSpec,
    Registry,
    instantiate,
    load_config,
    objects,
)
from athena.context import BlockContext
from athena.decorators import (
    block,
    get_block_spec,
    get_config_class,
)
from athena.handler import HandlerSpec, get_handler_spec, handler
from athena.inspector_backend import (
    InspectorBackendProtocol,
    InspectorContext,
    get_inspector_backend_marker,
    inspector_backend,
    is_inspector_backend,
)
from athena.types import (
    ArtifactRef,
    BlockConfig,
    BlockSpec,
    StorageBackend,
)

__all__ = [
    # Config
    "Registry",
    "objects",
    "ObjectSpec",
    "CustomObjectSpec",
    "load_config",
    "instantiate",
    # Context
    "BlockContext",
    # Decorators
    "block",
    "get_block_spec",
    "get_config_class",
    # Handler
    "handler",
    "HandlerSpec",
    "get_handler_spec",
    # Inspector
    "inspector_backend",
    "InspectorBackendProtocol",
    "InspectorContext",
    "get_inspector_backend_marker",
    "is_inspector_backend",
    # Types
    "ArtifactRef",
    "BlockConfig",
    "BlockSpec",
    "StorageBackend",
]

__version__ = "0.1.29"
