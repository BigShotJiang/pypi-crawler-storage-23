import re
from pathlib import Path

from setuptools import setup, find_packages

_ROOT = Path(__file__).parent


def _read_version() -> str:
    """Read __version__ from src/k4s/__init__.py without importing the package."""
    init = _ROOT / "src" / "k4s" / "__init__.py"
    match = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', init.read_text(), re.M)
    if not match:
        raise RuntimeError("Cannot find __version__ in src/k4s/__init__.py")
    return match.group(1)


def _read_readme() -> str:
    """Read long description from README.md for PyPI."""
    readme = _ROOT / "README.md"
    if readme.exists():
        return readme.read_text(encoding="utf-8")
    return ""


setup(
    name="k4s",
    version=_read_version(),
    description="A CLI tool for managing installations and Kubernetes operations",
    long_description=_read_readme(),
    long_description_content_type="text/markdown",
    python_requires=">=3.9",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    include_package_data=True,
    install_requires=[
        "click",
        "PyYAML",
        "requests",
        "tqdm",
        "paramiko",
        "rich",
        "cryptography",
        "packaging",
    ],
    entry_points={
        "console_scripts": [
            "k4s=k4s.cli.main:k4s",
            "k4=k4s.cli.main:k4s",
        ],
    },
    url="https://github.com/aliakts/k4s",
    author="Ali Aktaş",
    license="Proprietary",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: System :: Installation/Setup",
    ],
)