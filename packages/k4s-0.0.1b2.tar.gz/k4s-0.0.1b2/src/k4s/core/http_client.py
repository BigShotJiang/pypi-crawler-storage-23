"""Generic HTTP client for k4s REST API integrations.

Provides a thin, reusable wrapper around ``requests`` with consistent
authentication, error handling, and JSON serialisation.  Designed to be
composed (not subclassed) by service-specific clients such as future
Ranger / Ambari integrations.
"""

from __future__ import annotations

import json
from typing import Any

import requests
from requests.auth import HTTPBasicAuth


class HttpClientError(Exception):
    """Raised when an HTTP request fails or returns an error status code."""

    def __init__(self, message: str, status: int | None = None, body: str = "") -> None:
        super().__init__(message)
        self.status = status
        self.body = body


class HttpClient:
    """Thin HTTP client for REST API integrations.

    Supports API-key authentication (sent as HTTP Basic-auth password with an
    empty username) and explicit ``(user, password)`` basic-auth, covering the
    majority of self-hosted data-platform APIs (Dataiku DSS, Apache Ranger,
    Ambari, etc.).

    Args:
        base_url:   Service root URL, e.g. ``http://host:11200``.
        api_key:    Token or API key sent as the Basic-auth password with an
                    empty username.  Mutually exclusive with *basic_auth*.
        basic_auth: ``(username, password)`` tuple for standard Basic auth.
        timeout:    Per-request timeout in seconds (default 30).
        verify_ssl: Whether to verify TLS certificates (default ``True``).
    """

    def __init__(
        self,
        base_url: str,
        *,
        api_key: str | None = None,
        basic_auth: tuple[str, str] | None = None,
        timeout: int = 30,
        verify_ssl: bool = True,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._basic_auth = basic_auth
        self.timeout = timeout
        self.verify_ssl = verify_ssl

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _auth(self) -> HTTPBasicAuth | None:
        if self._basic_auth:
            return HTTPBasicAuth(*self._basic_auth)
        if self._api_key:
            # Convention used by DSS, Ranger and many others:
            # empty username, key as the password field.
            return HTTPBasicAuth("", self._api_key)
        return None

    def _headers(self) -> dict[str, str]:
        return {"Content-Type": "application/json", "Accept": "application/json"}

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _check_response(self, resp: requests.Response) -> None:
        if not resp.ok:
            raise HttpClientError(
                f"HTTP {resp.status_code} {resp.reason} — {resp.url}",
                status=resp.status_code,
                body=resp.text[:500],
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Send a GET request and return the parsed JSON response body."""
        resp = requests.get(
            self._url(path),
            params=params,
            auth=self._auth(),
            headers=self._headers(),
            timeout=self.timeout,
            verify=self.verify_ssl,
        )
        self._check_response(resp)
        return resp.json()

    def put(self, path: str, data: Any) -> Any:
        """Send a PUT request with a JSON body; return the parsed response (if any)."""
        resp = requests.put(
            self._url(path),
            data=json.dumps(data),
            auth=self._auth(),
            headers=self._headers(),
            timeout=self.timeout,
            verify=self.verify_ssl,
        )
        self._check_response(resp)
        return resp.json() if resp.text.strip() else {}

    def post(self, path: str, data: Any | None = None) -> Any:
        """Send a POST request with an optional JSON body."""
        resp = requests.post(
            self._url(path),
            data=json.dumps(data) if data is not None else None,
            auth=self._auth(),
            headers=self._headers(),
            timeout=self.timeout,
            verify=self.verify_ssl,
        )
        self._check_response(resp)
        return resp.json() if resp.text.strip() else {}
