"""Helm values file validation engine.

Provides generic and product-specific rules to catch common mistakes
before ``helm install`` / ``helm upgrade``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# Result model
# ---------------------------------------------------------------------------


class Severity(Enum):
    ERROR = "error"
    WARNING = "warning"


@dataclass
class Finding:
    severity: Severity
    path: str
    message: str


@dataclass
class ValidationResult:
    product: str | None = None
    findings: list[Finding] = field(default_factory=list)

    @property
    def errors(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == Severity.WARNING]

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


# ---------------------------------------------------------------------------
# Placeholder detection
# ---------------------------------------------------------------------------

_PLACEHOLDER_PATTERNS = [
    re.compile(r"CHANGE_ME"),
    re.compile(r"YOUR_\w+"),
    re.compile(r"^TODO$", re.IGNORECASE),
    re.compile(r"^REPLACE_ME$", re.IGNORECASE),
]


def _is_placeholder(value: str) -> bool:
    """Return True if *value* looks like an unfilled placeholder."""
    for pattern in _PLACEHOLDER_PATTERNS:
        if pattern.search(value):
            return True
    return False


# ---------------------------------------------------------------------------
# YAML tree helpers
# ---------------------------------------------------------------------------


def _walk(data: Any, prefix: str = "") -> list[tuple[str, Any]]:
    """Flatten a YAML tree into ``(dot_path, leaf_value)`` pairs."""
    items: list[tuple[str, Any]] = []
    if isinstance(data, dict):
        for key, value in data.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            items.extend(_walk(value, path))
    elif isinstance(data, list):
        for i, value in enumerate(data):
            items.extend(_walk(value, f"{prefix}[{i}]"))
    else:
        items.append((prefix, data))
    return items


def _deep_get(data: dict, dotpath: str) -> Any:
    """Retrieve a nested value by dot-separated key path."""
    current: Any = data
    for key in dotpath.split("."):
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return None
    return current


# ---------------------------------------------------------------------------
# Java properties helpers
# ---------------------------------------------------------------------------


def _is_properties_block(value: str) -> bool:
    """Heuristic: multi-line string with at least 2 key=value lines."""
    if "\n" not in value.strip():
        return False
    lines = value.strip().splitlines()
    kv_count = sum(1 for line in lines if "=" in line and not line.strip().startswith("#"))
    return kv_count >= 2


def _parse_properties(text: str) -> list[tuple[str, str]]:
    """Parse ``key=value`` lines from a Java properties block."""
    props: list[tuple[str, str]] = []
    for line in text.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            props.append((key.strip(), value.strip()))
    return props


_JDBC_RE = re.compile(r"jdbc:(\w+)://([^/:?]+):(\d+)(?:/(\S+))?")


# ---------------------------------------------------------------------------
# Generic checks
# ---------------------------------------------------------------------------


def _check_placeholders(data: dict, result: ValidationResult) -> None:
    """Flag unfilled placeholders in simple (non-properties) YAML values."""
    for path, value in _walk(data):
        if not isinstance(value, str):
            continue
        if _is_properties_block(value):
            continue
        if _is_placeholder(value):
            result.findings.append(
                Finding(Severity.ERROR, path, f'placeholder "{value}" must be replaced')
            )


def _check_properties_blocks(data: dict, result: ValidationResult) -> None:
    """Check Java properties blocks for placeholders and malformed JDBC URLs."""
    for yaml_path, value in _walk(data):
        if not isinstance(value, str) or not _is_properties_block(value):
            continue
        for key, val in _parse_properties(value):
            full_path = f"{yaml_path} > {key}"
            if _is_placeholder(val):
                result.findings.append(
                    Finding(Severity.ERROR, full_path, f'placeholder "{val}" must be replaced')
                )
            if val.startswith("jdbc:"):
                m = _JDBC_RE.match(val)
                if not m:
                    result.findings.append(
                        Finding(
                            Severity.WARNING,
                            full_path,
                            f'JDBC URL may be malformed: "{val}"',
                        )
                    )


# ---------------------------------------------------------------------------
# Starburst-specific checks
# ---------------------------------------------------------------------------


def _validate_starburst(data: dict, result: ValidationResult) -> None:
    image_tag = _deep_get(data, "image.tag")
    init_tag = _deep_get(data, "initImage.tag")
    if (
        image_tag
        and init_tag
        and not _is_placeholder(str(image_tag))
        and not _is_placeholder(str(init_tag))
        and str(image_tag) != str(init_tag)
    ):
        result.findings.append(
            Finding(
                Severity.WARNING,
                "image.tag / initImage.tag",
                f'image tags differ: "{image_tag}" vs "{init_tag}" -- usually these should match',
            )
        )

    shared = data.get("sharedSecret")
    if isinstance(shared, str) and not _is_placeholder(shared) and len(shared) < 20:
        result.findings.append(
            Finding(
                Severity.WARNING,
                "sharedSecret",
                f"only {len(shared)} characters -- use at least 20 for security",
            )
        )

    _check_jdbc_host_consistency(data, result)


def _check_jdbc_host_consistency(data: dict, result: ValidationResult) -> None:
    """Warn when JDBC URLs of the same driver type reference different hosts."""
    hosts_by_driver: dict[str, set[str]] = {}
    for _, value in _walk(data):
        if not isinstance(value, str) or not _is_properties_block(value):
            continue
        for _, val in _parse_properties(value):
            m = _JDBC_RE.match(val)
            if m and not _is_placeholder(m.group(2)):
                driver = m.group(1)
                hosts_by_driver.setdefault(driver, set()).add(m.group(2))
    for driver, hosts in hosts_by_driver.items():
        if len(hosts) > 1:
            host_list = ", ".join(sorted(hosts))
            result.findings.append(
                Finding(
                    Severity.WARNING,
                    f"JDBC URLs (jdbc:{driver})",
                    f"multiple hosts found ({host_list}) -- verify this is intentional",
                )
            )


# ---------------------------------------------------------------------------
# Datafloem-specific checks
# ---------------------------------------------------------------------------


_MONGO_URL_RE = re.compile(r"^mongodb(\+srv)?://")


def _validate_datafloem(data: dict, result: ValidationResult) -> None:
    # Warn if ingress is enabled but the host is still a placeholder.
    ingress_enabled = _deep_get(data, "frontend.ingress.enabled")
    if ingress_enabled:
        hosts = _deep_get(data, "frontend.ingress.hosts")
        if isinstance(hosts, list):
            for entry in hosts:
                host = entry.get("host") if isinstance(entry, dict) else None
                if host and _is_placeholder(str(host)):
                    result.findings.append(
                        Finding(
                            Severity.ERROR,
                            "frontend.ingress.hosts[].host",
                            f'placeholder "{host}" must be replaced with the actual hostname',
                        )
                    )

    # If a direct MongoDB URL is provided (not fromSecret), validate its format.
    db_url = _deep_get(data, "backend.database.url")
    if isinstance(db_url, str) and not _is_placeholder(db_url):
        if not _MONGO_URL_RE.match(db_url):
            result.findings.append(
                Finding(
                    Severity.WARNING,
                    "backend.database.url",
                    f'value "{db_url}" does not look like a MongoDB URL '
                    "(expected mongodb:// or mongodb+srv://)",
                )
            )

    # Warn when dbName is missing or looks like a placeholder.
    db_name = _deep_get(data, "backend.database.dbName")
    if not db_name:
        result.findings.append(
            Finding(
                Severity.WARNING,
                "backend.database.dbName",
                "MongoDB database name is not set; Datafloem will use the chart default",
            )
        )
    elif isinstance(db_name, str) and _is_placeholder(db_name):
        result.findings.append(
            Finding(
                Severity.ERROR,
                "backend.database.dbName",
                f'placeholder "{db_name}" must be replaced with the actual database name',
            )
        )


# ---------------------------------------------------------------------------
# Product detection
# ---------------------------------------------------------------------------

_PRODUCT_LABELS: dict[str, str] = {
    "starburst": "Starburst Enterprise",
    "datafloem": "Datafloem",
    "hive": "Hive Metastore",
    "ranger": "Ranger",
    "cache": "Cache Service",
}


def _detect_product(data: dict) -> str | None:
    if "starburstPlatformLicense" in data:
        return "starburst"
    if "frontend" in data and "backend" in data and "operator" in data:
        return "datafloem"
    if _deep_get(data, "database.external.jdbcUrl") and _deep_get(data, "objectStorage"):
        return "hive"
    if _deep_get(data, "admin.passwords"):
        return "ranger"
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def validate_values(path: Path, *, product: str | None = None) -> ValidationResult:
    """Validate a Helm values YAML file and return structured findings."""
    result = ValidationResult()

    try:
        text = path.read_text(encoding="utf-8")
    except OSError as e:
        result.findings.append(Finding(Severity.ERROR, "", f"Cannot read file: {e}"))
        return result

    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as e:
        result.findings.append(Finding(Severity.ERROR, "", f"Invalid YAML: {e}"))
        return result

    if not isinstance(data, dict):
        result.findings.append(Finding(Severity.ERROR, "", "Values file must be a YAML mapping"))
        return result

    detected = product or _detect_product(data)
    result.product = detected

    _check_placeholders(data, result)
    _check_properties_blocks(data, result)

    if detected == "starburst":
        _validate_starburst(data, result)
    elif detected == "datafloem":
        _validate_datafloem(data, result)

    return result


def product_label(product: str | None) -> str:
    """Return a human-friendly product label."""
    if product is None:
        return "Unknown"
    return _PRODUCT_LABELS.get(product, product)
