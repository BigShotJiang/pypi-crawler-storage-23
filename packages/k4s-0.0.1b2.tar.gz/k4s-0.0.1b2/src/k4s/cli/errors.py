from __future__ import annotations

import traceback

import click

from k4s.ui.ui import Ui, Verbosity

# Exception types whose message alone is always sufficient — no traceback needed
# even in debug mode.  Anything NOT in this list will have its full traceback
# printed via ui.debug() when verbosity >= debug (-vv).
_SUPPRESS_TRACEBACK_TYPES = (KeyError, click.ClickException)


def exit_with_error(ctx: click.Context, ui: Ui, exc: BaseException, *, code: int = 1) -> None:
    """Print a user-friendly error and exit.

    - All verbosities: concise error message.
    - debug (-vv): full Python traceback for all exceptions except the
      purely presentational ones in ``_SUPPRESS_TRACEBACK_TYPES``.
    """
    if isinstance(exc, KeyError) and exc.args:
        msg = exc.args[0]
    else:
        msg = str(exc)
    ui.error(msg)
    if ui.options.verbosity >= Verbosity.debug and not isinstance(exc, _SUPPRESS_TRACEBACK_TYPES):
        ui.debug(traceback.format_exc())
    ctx.exit(code)

