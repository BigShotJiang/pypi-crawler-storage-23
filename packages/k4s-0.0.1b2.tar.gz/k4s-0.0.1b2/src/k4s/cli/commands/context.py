"""CLI commands for managing connection contexts."""
import shlex
import subprocess

import click

from k4s.cli.state import CliState
from k4s.cli.errors import exit_with_error
from k4s.cli.verbosity import apply_command_ui_overrides
from k4s.core.context_store import Context
from k4s.core.executor import Executor


class AliasGroup(click.Group):
    """Click group that supports command aliases."""

    _aliases: dict = {
        "ls": "list",
        "rm": "remove",
    }

    def get_command(self, ctx, cmd_name):
        resolved = self._aliases.get(cmd_name, cmd_name)
        return super().get_command(ctx, resolved)

class ArgsFirstUsageCommand(click.Command):
    """Click command that prints usage as `NAME [OPTIONS]` (args first)."""

    def get_usage(self, ctx) -> str:
        usage = super().get_usage(ctx)
        # Default Click format is: "Usage: ... [OPTIONS] NAME"
        return usage.replace("[OPTIONS] NAME", "NAME [OPTIONS]")

    def format_usage(self, ctx, formatter) -> None:
        # Click's help output doesn't always use get_usage() for the usage line
        # (depending on Click version / command wiring), so enforce the same
        # `NAME [OPTIONS]` ordering here as well.
        pieces = self.collect_usage_pieces(ctx)
        if "[OPTIONS]" in pieces and "NAME" in pieces:
            pieces = [p for p in pieces if p not in ("[OPTIONS]", "NAME")]
            pieces.insert(0, "[OPTIONS]")
            pieces.insert(0, "NAME")
        formatter.write(f"Usage: {ctx.command_path} {' '.join(pieces)}\n")


@click.group(cls=AliasGroup)
@click.pass_context
def context(ctx):
    """Manage connection contexts (VM or Kubernetes)."""
    pass


@context.command("add", short_help="Add or update a connection context.", cls=ArgsFirstUsageCommand)
@click.argument("name", metavar="NAME", required=False, default=None)
@click.option("--type", "ctx_type", type=click.Choice(["vm", "k8s"], case_sensitive=False), default=None, help="Context type (auto-detected from flags when omitted).")
# VM options
@click.option("-h", "--host", default=None, help="Host (IP/hostname). Implies --type vm.")
@click.option("-u", "--username", default=None, help="SSH username.")
@click.option("-P", "--port", default=22, show_default=True, type=int, help="SSH port.")
@click.option("-i", "--identity-file", help="SSH private key path.")
@click.option("-ip", "--identity-passphrase", default=None, help="SSH key passphrase (stored encrypted).")
@click.option("-ips", "--identity-passphrase-stdin", "identity_passphrase_stdin", is_flag=True, help="Read SSH key passphrase from stdin (interactive prompt, stored encrypted).")
@click.option("-p", "--password", help="SSH password (discouraged; prefer keys).")
# K8s options
@click.option("--kubeconfig", default=None, help="Path to kubeconfig file. Implies --type k8s.")
@click.option("--kubecontext", "kubectl_context", default=None, help="Context name within the kubeconfig file. Implies --type k8s.")
@click.option("-n", "--namespace", default=None, help="Default namespace for Helm operations.")
# Common
@click.option("--current", is_flag=True, default=False, help="Set as current context.")
@click.pass_context
def add(ctx, name, ctx_type, host, username, port, identity_file, identity_passphrase,
        identity_passphrase_stdin, password, kubeconfig, kubectl_context, namespace, current):
    """Add or update a connection context.

    NAME is a label for this connection (e.g. 'prod', 'staging-k8s').
    Use --current to set it as the active context for subsequent commands.

    Type is auto-detected: --host implies VM, --kubeconfig or --kubecontext
    implies K8s. You can still pass --type explicitly if needed.

    \b
    Examples (VM):
      k4s context add prod --host 10.0.1.5 --username ubuntu -i ~/.ssh/id_rsa --current
      k4s context add dev --host 192.168.1.10 --username root --password secret

    \b
    Examples (K8s):
      k4s context add staging --kubeconfig ~/.kube/k4s/default.yaml --current
      k4s context add customer-x --kubecontext customer-x-aks --namespace starburst
    """
    if not name:
        click.echo("Usage: k4s context add NAME [OPTIONS]\n")
        click.echo("Error: Missing argument 'NAME'.")
        click.echo("Hint:  k4s context add <name> --host <ip> --username <user> -i <key>")
        click.echo("       k4s context add <name> --kubeconfig <path>")
        ctx.exit(2)

    state: CliState = ctx.obj["state"]
    ui = state.ui

    # Auto-detect type from flags when --type is not given.
    if ctx_type is None:
        has_k8s_flags = kubeconfig or kubectl_context
        has_vm_flags = host
        if has_k8s_flags and has_vm_flags:
            ui.error("Ambiguous flags: --host (VM) and --kubeconfig/--kubecontext (K8s) cannot be combined.")
            ctx.exit(2)
        if has_k8s_flags:
            ctx_type = "k8s"
        elif has_vm_flags:
            ctx_type = "vm"
        else:
            ui.error(
                "Cannot determine context type. Provide --host for VM or --kubeconfig/--kubecontext for K8s."
            )
            ctx.exit(2)

    if ctx_type == "k8s":
        if not kubeconfig and not kubectl_context:
            ui.error("K8s context requires --kubeconfig and/or --kubecontext.")
            ctx.exit(2)
        state.contexts.upsert(
            Context(
                name=name,
                type="k8s",
                kubeconfig=kubeconfig,
                kubectl_context=kubectl_context,
                namespace=namespace,
            ),
            make_current=current,
        )
    else:
        if not host:
            ui.error("VM context requires --host.")
            ctx.exit(2)
        if not username:
            ui.error("VM context requires --username.")
            ctx.exit(2)
        if not identity_file and not password:
            ui.error("Provide either --identity-file or --password.")
            ctx.exit(2)

        if identity_passphrase_stdin:
            if not identity_file:
                ui.error("--identity-passphrase-stdin requires --identity-file.")
                ctx.exit(2)
            identity_passphrase = click.prompt(
                "SSH key passphrase",
                hide_input=True,
                default="",
                show_default=False,
            )
        state.contexts.upsert(
            Context(
                name=name,
                type="vm",
                host=host,
                username=username,
                port=port,
                identity_file=identity_file,
                identity_passphrase=identity_passphrase or None,
                password=password,
            ),
            make_current=current,
        )

    msg = f"Context '{name}' ({ctx_type}) saved."
    if current:
        msg = f"Context '{name}' ({ctx_type}) saved and set as current."
    ui.success(msg)


@context.command("list", short_help="List all contexts.")
@click.pass_context
def list_(ctx):
    """List all saved contexts. The current context is marked with *."""
    state: CliState = ctx.obj["state"]
    current = state.contexts.get_current_name()
    contexts = state.contexts.list()
    if not contexts:
        state.ui.info("No contexts found. Run `k4s context add ...` to create one.")
        return
    for name, c in contexts.items():
        marker = "*" if name == current else " "
        if c.type == "k8s":
            parts = []
            if c.kubeconfig:
                parts.append(f"kubeconfig: {c.kubeconfig}")
            if c.kubectl_context:
                parts.append(f"kubecontext: {c.kubectl_context}")
            if c.namespace:
                parts.append(f"ns: {c.namespace}")
            detail = "  ".join(parts) or "-"
        else:
            host = c.host or "-"
            user = c.username or "-"
            detail = f"{user}@{host}:{c.port}"
        state.ui.info(f"{marker} {name:20} {detail}")


@context.command("use-context", short_help="Set the current context.")
@click.argument("name")
@click.pass_context
def use_context(ctx, name):
    """Set NAME as the current context.

    Commands that accept --context will use the current context when
    --context is omitted.
    """
    state: CliState = ctx.obj["state"]
    try:
        state.contexts.set_current(name)
    except KeyError as e:
        state.ui.error(str(e))
        ctx.exit(2)
    state.ui.success(f"Current context set to '{name}'.")


@context.command("show", short_help="Show context details.")
@click.argument("name", required=False, default=None)
@click.pass_context
def show(ctx, name):
    """Show context details.

    If NAME is given, shows that context. Otherwise shows the current context.
    """
    state: CliState = ctx.obj["state"]
    try:
        c = state.contexts.resolve(name)
    except KeyError as e:
        state.ui.error(str(e))
        ctx.exit(2)
    _print_context(state.ui, c)


def _print_context(ui, c: Context) -> None:
    """Print context details to the UI."""
    ui.info(f"name:            {c.name}")
    ui.info(f"type:            {c.type}")
    if c.type == "k8s":
        ui.info(f"kubeconfig:      {c.kubeconfig or '-'}")
        ui.info(f"kubecontext:     {c.kubectl_context or '-'}")
        ui.info(f"namespace:       {c.namespace or '-'}")
    else:
        ui.info(f"host:            {c.host}")
        ui.info(f"username:        {c.username}")
        ui.info(f"port:            {c.port}")
        ui.info(f"identity_file:   {c.identity_file or '-'}")
        ui.info(f"passphrase:      {'<set>' if c.identity_passphrase else '-'}")
        ui.info(f"password:        {'<set>' if c.password else '-'}")


@context.command("edit", short_help="Edit a context in $EDITOR.")
@click.argument("name")
@click.pass_context
def edit(ctx, name):
    """Edit an existing context using an editor.

    This edits non-sensitive fields only. Secrets (password/passphrase) are
    preserved from the existing context.
    """
    import os
    import tempfile
    import yaml

    state: CliState = ctx.obj["state"]
    ui = state.ui

    try:
        c = state.contexts.resolve(name)
    except KeyError as e:
        ui.error(str(e))
        ctx.exit(2)

    # Only expose non-sensitive fields for editing.
    data = {
        "name": c.name,
        "type": c.type,
    }
    if c.type == "k8s":
        data.update(
            {
                "kubeconfig": c.kubeconfig,
                "kubecontext": c.kubectl_context,
                "namespace": c.namespace,
            }
        )
    else:
        data.update(
            {
                "host": c.host,
                "username": c.username,
                "port": c.port,
                "identity_file": c.identity_file,
            }
        )

    editor = (
        os.environ.get("K4S_EDITOR")
        or os.environ.get("VISUAL")
        or os.environ.get("EDITOR")
        or "vi"
    )

    with tempfile.NamedTemporaryFile("w", delete=False, suffix=".yml") as f:
        path = f.name
        f.write("# Edit context fields and save. Close the editor to apply.\n")
        f.write("# Secrets are not editable here and will remain unchanged.\n\n")
        yaml.safe_dump(data, f, sort_keys=False)

    try:
        editor_cmd = shlex.split(editor) + [path]
        rc = subprocess.call(editor_cmd)
        if rc != 0:
            raise RuntimeError(f"Editor exited with code {rc}")
        with open(path, "r", encoding="utf-8") as rf:
            new_data = yaml.safe_load(rf) or {}
    except Exception as e:
        ui.error(str(e))
        import traceback as _tb
        ui.console.print(f"[dim]{_tb.format_exc()}[/dim]")
        ctx.exit(1)
        return
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass

    if not isinstance(new_data, dict):
        ui.error("Invalid YAML. Expected a mapping at the root.")
        ctx.exit(2)

    # Name/type are not editable.
    new_type = (new_data.get("type") or c.type)
    if new_type != c.type:
        ui.error("Context type cannot be changed via edit. Create a new context instead.")
        ctx.exit(2)

    if c.type == "k8s":
        updated = Context(
            name=c.name,
            type="k8s",
            kubeconfig=new_data.get("kubeconfig") or None,
            kubectl_context=new_data.get("kubecontext") or new_data.get("kubectl_context") or None,
            namespace=new_data.get("namespace") or None,
        )
    else:
        updated = Context(
            name=c.name,
            type="vm",
            host=new_data.get("host") or None,
            username=new_data.get("username") or None,
            port=int(new_data.get("port") or 22),
            identity_file=new_data.get("identity_file") or None,
            identity_passphrase=c.identity_passphrase,
            password=c.password,
        )

    state.contexts.upsert(updated, make_current=(state.contexts.get_current_name() == c.name))
    ui.success(f"Context '{c.name}' updated.")

@context.command("remove", short_help="Remove a context.")
@click.argument("name")
@click.pass_context
def remove(ctx, name):
    """Remove a saved context. Alias: rm"""
    state: CliState = ctx.obj["state"]
    try:
        state.contexts.remove(name)
    except KeyError as e:
        state.ui.error(str(e))
        ctx.exit(2)
    state.ui.success(f"Context '{name}' removed.")


@context.command("ping", short_help="Check connectivity.")
@click.argument("name", required=False)
@click.option("-q", "--quiet", is_flag=True, help="Only print final results and errors.")
@click.option("-v", "--verbose", count=True, help="Increase verbosity (-v logs, -vv debug).")
@click.option("-y", "--yes", is_flag=True, help="Skip context confirmation countdown.")
@click.pass_context
def ping(ctx, name, quiet, verbose, yes):
    """Check connectivity for a context (defaults to current).

    For VM contexts, tests SSH connectivity.
    For K8s contexts, runs 'kubectl get nodes' to verify cluster access.
    """
    state: CliState = ctx.obj["state"]
    apply_command_ui_overrides(ctx, state, quiet=quiet, verbose=verbose, yes=yes)
    ui = state.ui

    try:
        c = state.contexts.resolve(name)

        if c.type == "k8s":
            with ui.step("Checking cluster connectivity"):
                kube_args = c.to_kubectl_args()
                cmd = ["kubectl"] + kube_args + ["get", "nodes"]
                ui.log(f"Running: {' '.join(shlex.quote(a) for a in cmd)}")
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                if result.returncode != 0:
                    err_msg = result.stderr.strip() or result.stdout.strip()
                    raise RuntimeError(f"kubectl get nodes failed: {err_msg}")
            ui.success("Cluster connectivity OK.")
        else:
            with ui.step(f"Connecting to {c.username}@{c.host}:{c.port}"):
                with Executor(c.to_server_config()) as ex:
                    rc, out, err = ex.execute("whoami && hostname")
                    if rc != 0:
                        raise RuntimeError(f"SSH check failed: {err}")
            ui.success("SSH connectivity OK.")
    except Exception as e:
        exit_with_error(ctx, ui, e, code=1)
