"""CLI commands for validating configuration files (k4s validate ...)."""

from __future__ import annotations

from pathlib import Path

import click

from k4s.cli.state import CliState
from k4s.core.validate import ValidationResult, product_label, validate_values


class OrderedValidateGroup(click.Group):
    def list_commands(self, ctx):
        return list(self.commands)


@click.group(cls=OrderedValidateGroup)
@click.pass_context
def validate(ctx):
    """Validate configuration files."""
    pass


@validate.command("values")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--product",
    type=click.Choice(["starburst", "hive", "ranger", "cache", "datafloem"], case_sensitive=False),
    default=None,
    help="Product type (auto-detected if omitted).",
)
@click.pass_context
def values(ctx, file: str, product: str | None):
    """Validate a Helm values YAML file for common mistakes.

    Checks for unfilled placeholders, malformed JDBC URLs, image tag
    mismatches, and other product-specific issues.
    """
    state: CliState = ctx.obj["state"]
    ui = state.ui

    path = Path(file)
    result = validate_values(path, product=product)

    if result.product:
        ui.info(f"Detected product: {product_label(result.product)}")
        ui.info("")

    _print_findings(ui, result)

    if not result.ok:
        ctx.exit(1)


def _print_findings(ui, result: ValidationResult) -> None:
    """Render validation findings to the console."""
    errors = result.errors
    warnings = result.warnings

    if errors:
        ui.error(f"{len(errors)} error(s) found")
        for f in errors:
            path_prefix = f"  {f.path}: " if f.path else "  "
            ui.error(f"{path_prefix}{f.message}")

    if warnings:
        if errors:
            ui.info("")
        ui.warning(f"{len(warnings)} warning(s)")
        for f in warnings:
            path_prefix = f"  {f.path}: " if f.path else "  "
            ui.warning(f"{path_prefix}{f.message}")

    if not errors and not warnings:
        ui.success("Validation passed (0 errors, 0 warnings)")
    elif not errors:
        ui.info("")
        ui.success(f"No errors ({len(warnings)} warning(s) only)")
