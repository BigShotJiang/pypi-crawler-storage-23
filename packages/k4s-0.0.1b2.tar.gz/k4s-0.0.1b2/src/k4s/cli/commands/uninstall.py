"""CLI commands for uninstalling products (k4s uninstall <product>)."""

import click

from k4s.cli.errors import exit_with_error
from k4s.cli.state import CliState
from k4s.cli.target import resolve_k8s_target, kubeconfig_path_for
from k4s.cli.verbosity import apply_command_ui_overrides
from k4s.core.executor import Executor
from k4s.core.products import run_steps
from k4s.recipes.openebs.model import OpenEbsUninstallPlan, DEFAULT_OPENEBS_NAMESPACE
from k4s.recipes.openebs.uninstall import build_uninstall_steps as build_openebs_uninstall_steps


class OrderedUninstallGroup(click.Group):
    """Uninstall subgroup with stable command order in --help."""

    _order = ["openebs"]

    def list_commands(self, ctx):
        return self._order


@click.group(cls=OrderedUninstallGroup)
def uninstall():
    """Uninstall products from VMs or Kubernetes clusters."""
    pass


@uninstall.command("openebs")
@click.option("--context", "context_name", default=None, help="K8s context name. Uses current context if omitted.")
@click.option("--namespace", default=DEFAULT_OPENEBS_NAMESPACE, show_default=True, help="Kubernetes namespace where OpenEBS is installed.")
@click.option("--release-name", default="openebs", show_default=True, help="Helm release name to uninstall.")
@click.option(
    "--delete-namespace/--keep-namespace",
    "delete_namespace",
    default=False,
    show_default=True,
    help="Delete the OpenEBS namespace after Helm uninstall.",
)
@click.option("--dry-run", is_flag=True, help="Print the plan without applying changes.")
@click.option("-q", "--quiet", is_flag=True, help="Only print final results and errors.")
@click.option("-v", "--verbose", count=True, help="Increase verbosity (-v logs, -vv debug).")
@click.option("-y", "--yes", is_flag=True, help="Skip context confirmation countdown.")
@click.pass_context
def openebs(
    ctx,
    context_name,
    namespace,
    release_name,
    delete_namespace,
    dry_run,
    quiet,
    verbose,
    yes,
):
    """Uninstall OpenEBS LocalPV Hostpath from a Kubernetes cluster.

    Runs ``helm uninstall`` for the OpenEBS release. CRDs are intentionally
    left in place (Helm never auto-deletes CRDs) to avoid silently orphaning
    existing PersistentVolumes. Remove them manually if you are sure no PVCs
    depend on them.

    \b
    Examples:
      k4s uninstall openebs
      k4s uninstall openebs --delete-namespace
      k4s uninstall openebs --release-name openebs --namespace openebs
    """
    state: CliState = ctx.obj["state"]
    apply_command_ui_overrides(ctx, state, quiet=quiet, verbose=verbose, yes=yes)
    ui = state.ui

    try:
        c = resolve_k8s_target(state, context_name)
        kubeconfig = kubeconfig_path_for(c)

        plan = OpenEbsUninstallPlan(
            kubeconfig_path=kubeconfig,
            kubectl_context=c.kubectl_context,
            namespace=namespace,
            release_name=release_name,
            delete_namespace=delete_namespace,
        )

        ex = Executor()
        steps = build_openebs_uninstall_steps(ui, ex, plan)

        if dry_run:
            run_steps(ui, steps, dry_run=True)
        else:
            with ex:
                run_steps(ui, steps, dry_run=False)

        if not dry_run:
            state.history.append(
                action="uninstall",
                product="openebs",
                context=c.name,
                params={
                    "namespace": namespace,
                    "release_name": release_name,
                    "delete_namespace": delete_namespace,
                },
            )
            ui.success("OpenEBS uninstalled successfully.")
    except Exception as e:
        exit_with_error(ctx, ui, e, code=1)
