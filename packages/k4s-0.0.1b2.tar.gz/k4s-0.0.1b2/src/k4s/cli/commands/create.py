"""CLI commands for creating resources (verb-first: k4s create <resource>)."""
import traceback as _traceback
from pathlib import Path

import click

from k4s.cli.errors import exit_with_error
from k4s.cli.state import CliState
from k4s.cli.target import _context_countdown, context_label
from k4s.cli.verbosity import apply_command_ui_overrides
from k4s.core.cluster import Rke2ClusterCreator, build_nodes_from_contexts, run_preflight
from k4s.core.executor import Executor
from k4s.recipes.openebs.install import build_install_steps as build_openebs_steps
from k4s.recipes.openebs.model import OpenEbsInstallPlan, DEFAULT_OPENEBS_STORAGE_PATH
from k4s.core.products import run_steps
from k4s.ui.ui import Ui, Verbosity


class OrderedCreateGroup(click.Group):
    _order = ["cluster"]

    def list_commands(self, ctx):
        return self._order


@click.group(cls=OrderedCreateGroup)
def create():
    """Create Kubernetes clusters and other resources."""
    pass


@create.command("cluster")
@click.option("--type", "cluster_type", type=click.Choice(["rke2"], case_sensitive=False), default="rke2", show_default=True)
@click.option("--cp", "--control-plane", "control_planes", multiple=True, required=True, help="Context name for a control-plane node.")
@click.option("--worker", "-w", "workers", multiple=True, help="Context name for a worker node.")
@click.option("--cni", type=click.Choice(["canal", "cilium", "calico"], case_sensitive=False), default="canal", show_default=True)
@click.option(
    "--tls-san",
    "extra_tls_san",
    multiple=True,
    help=(
        "Extra IP or hostname to add to the RKE2 TLS SAN list (repeatable). "
        "The control-plane's host is always included automatically."
    ),
)
@click.option(
    "--export-kubeconfig",
    "export_context",
    default=None,
    help="VM context name to copy the kubeconfig to after cluster creation (e.g. the Dataiku machine).",
)
@click.option(
    "--export-path",
    default=None,
    help="Path on the target VM where the kubeconfig will be written (defaults to ~/.kube/config of the target user).",
)
@click.option(
    "--with-kubectl/--no-kubectl",
    "install_kubectl_flag",
    default=True,
    show_default=True,
    help="Install kubectl on all control-plane nodes after cluster creation.",
)
@click.option(
    "--with-openebs",
    is_flag=True,
    default=False,
    help="Install OpenEBS LocalPV Hostpath after cluster creation (for on-prem clusters without a StorageClass).",
)
@click.option(
    "--openebs-storage-path",
    default=DEFAULT_OPENEBS_STORAGE_PATH,
    show_default=True,
    help="Base directory for OpenEBS LocalPV volumes (used with --with-openebs).",
)
@click.option("--dry-run", is_flag=True, help="Print the plan without applying changes.")
@click.option("-q", "--quiet", is_flag=True, help="Only print final results and errors.")
@click.option("-v", "--verbose", count=True, help="Increase verbosity (-v logs, -vv debug).")
@click.option("-y", "--yes", is_flag=True, help="Skip context confirmation countdown.")
@click.pass_context
def cluster(
    ctx,
    cluster_type,
    control_planes,
    workers,
    cni,
    extra_tls_san,
    export_context,
    export_path,
    install_kubectl_flag,
    with_openebs,
    openebs_storage_path,
    dry_run,
    quiet,
    verbose,
    yes,
):
    """Create a Kubernetes cluster on the specified context nodes.

    Runs preflight checks, installs RKE2 on control-plane and worker nodes,
    and fetches the kubeconfig to ~/.kube/k4s/default.yaml.

    \b
    Examples:
      k4s create cluster --control-plane cp1 --worker w1 --worker w2
      k4s create cluster --control-plane cp1 --cni cilium --no-kubectl
      k4s create cluster --control-plane cp1 --tls-san my.domain.com --export-kubeconfig dataiku
      k4s create cluster --control-plane cp1 --with-openebs
    """
    state: CliState = ctx.obj["state"]
    apply_command_ui_overrides(ctx, state, quiet=quiet, verbose=verbose, yes=yes)
    ui = state.ui

    if cluster_type.lower() != "rke2":
        ui.error(f"Unsupported cluster type: {cluster_type}")
        ctx.exit(2)

    nodes = None
    kube_content = ""
    try:
        nodes = build_nodes_from_contexts(
            state.contexts, control_planes=list(control_planes), workers=list(workers)
        )

        cp_nodes = [n for n in nodes if n.role == "control-plane"]
        wk_nodes = [n for n in nodes if n.role == "worker"]
        cp_labels = ", ".join(context_label(n.context) for n in cp_nodes)
        wk_labels = ", ".join(context_label(n.context) for n in wk_nodes) if wk_nodes else "(none)"
        ui.info(f"Type: rke2 | CNI: {cni}")
        ui.info(f"Control-plane: {cp_labels}")
        ui.info(f"Workers: {wk_labels}")
        _context_countdown(state)
        ui.info("")

        run_preflight(ui, nodes=nodes)
        _, kube_content = Rke2ClusterCreator(ui=ui).create(
            name="default",
            nodes=nodes,
            cni=cni,
            tls_san=list(extra_tls_san) if extra_tls_san else None,
            dry_run=dry_run,
            install_kubectl=install_kubectl_flag,
        )
    except Exception as e:
        exit_with_error(ctx, ui, e, code=1)

    if dry_run:
        ui.info("Dry-run: cluster installation was not executed.")
        return

    primary_cp = next(n for n in nodes if n.role == "control-plane")
    kubeconfig_path = str(Path.home() / ".kube" / "k4s" / "default.yaml")

    # Wait for all nodes to reach Ready state using the local kubeconfig.
    # This is always done after cluster creation — OpenEBS (and Helm in general)
    # requires a fully initialised API server.
    with ui.step("Waiting for cluster to be ready"):
        ui.log("Checking all nodes reach Ready state (up to 5 minutes).")
        with Executor() as local_ex:
            rc, _, err = local_ex.execute(
                f"kubectl --kubeconfig {kubeconfig_path} "
                "wait --for=condition=Ready node --all --timeout=300s",
                use_sudo=False,
            )
            if rc != 0:
                ui.warning(
                    f"Nodes did not reach Ready state within 5 minutes.\n{err}\n"
                    "The cluster may still be initialising. "
                    "Check with: kubectl --kubeconfig "
                    f"{kubeconfig_path} get nodes"
                )

    # Install OpenEBS using the freshly created kubeconfig.
    if with_openebs:
        openebs_plan = OpenEbsInstallPlan(
            kubeconfig_path=kubeconfig_path,
            storage_path=openebs_storage_path,
        )
        openebs_ex = Executor()
        openebs_steps = build_openebs_steps(ui, openebs_ex, openebs_plan)
        try:
            with openebs_ex:
                run_steps(ui, openebs_steps, dry_run=False)
        except Exception as e:
            ui.warning(
                f"OpenEBS installation failed: {e}\n"
                "\n"
                "The cluster is running. You can retry OpenEBS installation after adding a k8s context:\n"
                f"  k4s context add <name> --type k8s --kubeconfig {kubeconfig_path} --current\n"
                "  k4s install openebs --context <name>"
            )

    exported = False
    if export_context:
        exported = _export_kubeconfig_to_vm(ui, state, primary_cp, export_context, export_path, kube_content)

    state.history.append(
        action="cluster-create",
        product="cluster",
        context=primary_cp.context.name,
        host=primary_cp.context.host,
        params={
            "type": "rke2",
            "cni": cni,
            "control_planes": list(control_planes),
            "workers": list(workers),
            "export_kubeconfig": export_context,
        },
    )

    ui.info("")
    if exported:
        ui.success(f"Cluster created successfully and kubeconfig exported to {export_context}.")
    else:
        ui.success("Cluster created successfully.")

    ui.info("Hint: Create a k8s context for Helm-based installs:")
    ui.info(f"  k4s context add <name> --type k8s --kubeconfig {kubeconfig_path} --current")
    ui.info("")


def _export_kubeconfig_to_vm(
    ui: Ui,
    state,
    primary_cp,
    export_context_name: str,
    export_path: str | None,
    content: str,
) -> bool:
    """Copy the cluster kubeconfig to a VM context.

    Uses the already-fetched kubeconfig content (with public IP) to avoid a
    redundant SSH read that would dump the raw YAML to the debug log.
    """
    try:
        target = state.contexts.resolve(export_context_name)
    except KeyError:
        ui.warning(
            f"Context '{export_context_name}' not found; skipping kubeconfig export.\n"
            f"  Add it with: k4s context add {export_context_name} ..."
        )
        return False

    target_user = target.username or "root"
    target_sudo = target_user.lower() not in {"root"}
    resolved_path = export_path or (
        f"/home/{target_user}/.kube/config" if target_sudo else "/root/.kube/config"
    )

    try:
        with ui.step(f"Export kubeconfig to {export_context_name} ({target.host})"):
            ui.log(f"Writing to {resolved_path}.")
            _sudo = "sudo -n " if target_sudo else ""
            with Executor(target.to_server_config()) as t_ex:
                kube_dir = str(Path(resolved_path).parent)
                t_ex.execute(f"{_sudo}mkdir -p {kube_dir}", use_sudo=False)
                t_ex.execute(f"{_sudo}chmod 700 {kube_dir}", use_sudo=False)
                if target_sudo:
                    t_ex.execute(
                        f"sudo -n chown {target_user}:{target_user} {kube_dir}", use_sudo=False
                    )

                rc, out, err = t_ex.execute(
                    f"{_sudo}tee {resolved_path} > /dev/null",
                    use_sudo=False,
                    stdin_data=content,
                )
                if rc != 0:
                    raise RuntimeError(
                        f"Failed to write kubeconfig to {resolved_path}: {err or out}"
                    )

                t_ex.execute(f"{_sudo}chmod 600 {resolved_path}", use_sudo=False)
                if target_sudo:
                    t_ex.execute(
                        f"sudo -n chown {target_user}:{target_user} {resolved_path}",
                        use_sudo=False,
                    )

                # Only persist KUBECONFIG in shell profiles for non-default paths.
                default_path = (
                    f"/home/{target_user}/.kube/config" if target_sudo else "/root/.kube/config"
                )
                if resolved_path != default_path:
                    export_line = f"export KUBECONFIG={resolved_path}"
                    for rc_file in ("~/.bashrc", "~/.profile"):
                        t_ex.execute(
                            f"grep -qF {export_line!r} {rc_file} 2>/dev/null "
                            f"|| echo {export_line!r} >> {rc_file}",
                            use_sudo=False,
                        )
    except Exception as e:
        # ui.step already showed ✖ for the step title; print the reason below it.
        ui.error(str(e))
        if ui.options.verbosity >= Verbosity.debug:
            ui.debug(_traceback.format_exc())
        return False

    return True
