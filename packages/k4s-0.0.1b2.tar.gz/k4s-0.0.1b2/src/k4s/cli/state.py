from __future__ import annotations

from dataclasses import dataclass

from k4s.core.context_store import ContextStore
from k4s.core.history import HistoryManager
from k4s.ui.ui import Ui


@dataclass
class CliState:
    ui: Ui
    contexts: ContextStore
    history: HistoryManager
    yes: bool = False
