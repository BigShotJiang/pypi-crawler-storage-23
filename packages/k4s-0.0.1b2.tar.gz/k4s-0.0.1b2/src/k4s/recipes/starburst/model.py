from __future__ import annotations

from dataclasses import dataclass


# OCI chart reference (official since Starburst docs 2025+)
DEFAULT_OCI_REGISTRY = "harbor.starburstdata.net"
DEFAULT_OCI_CHART = (
    "oci://harbor.starburstdata.net/starburstdata/charts/starburst-enterprise"
)


@dataclass(frozen=True)
class StarburstInstallPlan:
    """Plan inputs for installing Starburst Enterprise via Helm."""

    release_name: str
    namespace: str
    kubeconfig_path: str
    kubectl_context: str | None = None

    # OCI chart reference (replaces old helm-repo-add approach)
    oci_chart_ref: str = DEFAULT_OCI_CHART
    oci_registry: str = DEFAULT_OCI_REGISTRY
    chart_version: str | None = None

    # Harbor credentials (used for both OCI registry login and image pulls)
    repo_username: str | None = None
    repo_password: str | None = None

    values_files: list[str] | None = None
    set_values: list[str] | None = None

    # Common minimal config inputs (can be supplied via --set or values files)
    environment: str | None = None
    shared_secret: str | None = None

    # License bootstrap
    license_file: str | None = None
    license_secret_name: str | None = None  # secret contains starburstdata.license

    # Harbor image pull credentials shortcut (writes to registryCredentials.*)
    registry_username: str | None = None
    registry_password: str | None = None

    timeout: str = "20m"

    def kubectl_flags(self) -> list[str]:
        """Return kubectl flags for kubeconfig and context."""
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--context", self.kubectl_context]
        return flags

    def helm_flags(self) -> list[str]:
        """Return helm flags for kubeconfig and kube-context."""
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--kube-context", self.kubectl_context]
        return flags
