from __future__ import annotations

from dataclasses import dataclass


DEFAULT_REPO_NAME = "datafloem"
# Datafloem Helm repository (per internal convention / customer access)
DEFAULT_REPO_URL = "https://helm.repo.datafloem.com"
DEFAULT_CHART_NAME = "dfl-chart"
DEFAULT_REGISTRY_SERVER = "docker.repo.datafloem.com"
DEFAULT_IMAGE_PULL_SECRET = "dflregcred"
DEFAULT_JWT_SECRET_NAME = "dfl-jwt-secret"
DEFAULT_LICENSE_SECRET_NAME = "dfl-license"
DEFAULT_MONGO_DB_SECRET_NAME = "dfl-db-conn-secret"
DEFAULT_MONGO_DB_SECRET_KEY = "MONGO_DB_URL"
DEFAULT_MONGO_DB_NAME = "dfl"
_MONGO_INIT_IMAGE = "mongo:7"


@dataclass(frozen=True)
class DatafloemInstallPlan:
    """Plan inputs for installing Datafloem via Helm (repo-based chart)."""

    release_name: str
    namespace: str
    kubeconfig_path: str
    kubectl_context: str | None = None

    repo_name: str = DEFAULT_REPO_NAME
    repo_url: str = DEFAULT_REPO_URL
    chart_name: str = DEFAULT_CHART_NAME
    chart_version: str | None = None

    repo_username: str | None = None
    repo_password: str | None = None

    # Docker registry access for pulling images from private registry
    registry_server: str = DEFAULT_REGISTRY_SERVER
    registry_username: str | None = None
    registry_password: str | None = None
    image_pull_secret_name: str = DEFAULT_IMAGE_PULL_SECRET

    # JWT secret for backend authentication
    jwt_secret: str | None = None
    jwt_secret_name: str = DEFAULT_JWT_SECRET_NAME

    # License file for operator
    license_file: str | None = None
    license_secret_name: str = DEFAULT_LICENSE_SECRET_NAME

    # MongoDB connection URL; when provided k4s creates the K8s secret.
    mongo_url: str | None = None
    # When True, k4s initializes (creates) the database in MongoDB.
    init_mongo_db: bool = False
    # Resolved from values files or defaults.
    mongo_db_name: str = DEFAULT_MONGO_DB_NAME
    mongo_db_secret_name: str = DEFAULT_MONGO_DB_SECRET_NAME
    mongo_db_secret_key: str = DEFAULT_MONGO_DB_SECRET_KEY

    values_files: list[str] | None = None
    set_values: list[str] | None = None

    timeout: str = "20m"

    def kubectl_flags(self) -> list[str]:
        """Return kubectl flags for kubeconfig and context."""
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--context", self.kubectl_context]
        return flags

    def helm_flags(self) -> list[str]:
        """Return helm flags for kubeconfig and kube-context."""
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--kube-context", self.kubectl_context]
        return flags

