"""Dataiku DSS recipes."""

