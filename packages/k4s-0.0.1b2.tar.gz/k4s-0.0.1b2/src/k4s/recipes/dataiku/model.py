from __future__ import annotations

from dataclasses import dataclass


_DEFAULT_CGROUP_ROOT = "/sys/fs/cgroup"
_DEFAULT_CGROUP_CONTROLLERS = "cpu memory"


@dataclass(frozen=True)
class DataikuUifPlan:
    """Plan inputs for setting up the User Isolation Framework on Dataiku DSS."""

    os_user: str = "dataiku"
    data_dir: str = "/data/dataiku/DATA_DIR"

    # security-config.ini [users] section
    allowed_user_groups: str = "dataiku"
    auto_create_users: bool = True
    auto_created_users_group: str = "dataiku"
    auto_created_users_prefix: str = "dataiku_"

    # cgroups
    cgroup_version: int = 2                         # 1 or 2
    cgroup_root: str = _DEFAULT_CGROUP_ROOT         # /sys/fs/cgroup
    cgroup_name: str | None = None                  # None = auto-detect (dataiku.<nodetype>)
    cgroup_controllers: str = _DEFAULT_CGROUP_CONTROLLERS  # space-separated

    # User impersonation rule (pattern type)
    impersonation_source_pattern: str = "(.*)"
    impersonation_target_unix: str = "dataiku_$1"
    impersonation_target_hadoop: str = ""


@dataclass(frozen=True)
class DataikuInstallPlan:
    """Plan inputs for installing Dataiku DSS (Design, Automation, or Govern node)."""

    version: str
    os_user: str
    os_group: str
    root_dir: str
    install_dir: str
    data_dir: str
    dss_port: int
    node_type: str = "design"  # "design", "automation", or "govern"
    archive_path: str | None = None  # local file path for offline/air-gapped upload
    install_docker: bool = False
    docker_data_root: str | None = None
    install_r: bool = False
    r_repo: str | None = None  # CRAN mirror URL for proxy R installs
    r_pkg_dir: str | None = None  # local dir with pre-downloaded R packages (air-gapped)
    os_user_password: str | None = None  # password to set for the OS user

    install_kubectl: bool = True
    add_to_docker_group: bool = False

    # Govern node (requires PostgreSQL and a JDBC driver)
    with_jdbc: bool = False
    govern_jdbc_url: str | None = None
    govern_jdbc_user: str | None = None
    govern_jdbc_password: str | None = None  # discouraged; prefer prompting
    govern_init_db: bool = True
    encrypt_govern_password: bool = True

    # Spark integration (post-install, optional)
    install_spark: bool = False
    spark_home_name: str = "SPARK_HOME"  # directory name under root_dir where Spark is extracted
    spark_version: str | None = None  # None = auto-detect from download index; fallback "3.5.3"
    spark_flavor: str = "generic-hadoop3"  # used for Dataiku spark-standalone download
    spark_archive_path: str | None = None  # optional: local archive to upload + extract (air-gapped)

    # Hadoop standalone integration (post-install, optional)
    install_hadoop: bool = False
    hadoop_archive_path: str | None = None  # optional: local archive to upload (air-gapped)
    hadoop_flavor: str = "generic-hadoop3"  # standalone distribution identifier (generic-hadoop3)

    # User Isolation Framework + cgroups (post-install, optional)
    install_uif: bool = False
    uif_allowed_user_groups: str = "dataiku"
    uif_auto_create_users: bool = True
    uif_auto_created_users_group: str = "dataiku"
    uif_auto_created_users_prefix: str = "dataiku_"
    uif_cgroup_version: int = 2
    uif_cgroup_root: str = _DEFAULT_CGROUP_ROOT
    uif_cgroup_name: str | None = None  # None = auto-detect (dataiku.<nodetype>)
    uif_cgroup_controllers: str = _DEFAULT_CGROUP_CONTROLLERS

    @property
    def archive_url(self) -> str:
        """Auto-generated download URL from version (like Nexus pattern)."""
        return f"https://downloads.dataiku.com/public/dss/{self.version}/dataiku-dss-{self.version}.tar.gz"

    @property
    def archive_remote_path(self) -> str:
        return f"{self.install_dir.rstrip('/')}/dataiku-dss-{self.version}.tar.gz"

    @property
    def extracted_dir(self) -> str:
        return f"{self.install_dir.rstrip('/')}/dataiku-dss-{self.version}"

