"""Shared utility helpers for Dataiku DSS management.

These helpers are used by post-install integration recipes (Spark, Hadoop, R)
that need to stop/start an already-running DSS instance.
"""

from __future__ import annotations

from k4s.core.executor import Executor
from k4s.recipes.common.run import check, q, run
from k4s.ui.ui import Ui


def detect_dss_port(ex: Executor, data_dir: str) -> int | None:
    """Detect the DSS HTTP port from ``DATA_DIR/install.ini`` ``[server].port``.

    Returns None when the value cannot be determined (file missing, key absent,
    or the read value is not numeric).
    """
    install_ini = q(f"{data_dir}/install.ini")
    cmd = (
        f"sudo -n grep -E '^\\s*port\\s*=' {install_ini} 2>/dev/null "
        "| head -1 | cut -d= -f2 | tr -d ' \\t'"
    )
    rc, out, _ = ex.execute(cmd)
    val = out.strip() if rc == 0 else ""
    if val.isdigit():
        return int(val)
    return None


def detect_dss_version(ex: Executor, data_dir: str) -> str | None:
    """Detect the DSS version from the DSS data directory.

    Tries two sources in order:
    1. ``DATADIR/dss-version.json`` – present in DSS 10+ and the most reliable
       source (``product_version`` field).
    2. ``DATADIR/install.ini`` – fallback for older releases that embed the
       version there (whitespace-tolerant ``version`` or ``dss_version`` key).
    """
    version_json = q(f"{data_dir}/dss-version.json")
    install_ini = q(f"{data_dir}/install.ini")
    cmd = (
        # Try dss-version.json first.
        f"(test -f {version_json} && "
        f"grep '\"product_version\"' {version_json} | "
        f"sed 's/.*\"product_version\"[[:space:]]*:[[:space:]]*\"\\([^\"]*\\)\".*/\\1/' | tr -d ' \\t') "
        # Fall back to install.ini.
        f"|| (test -f {install_ini} && "
        f"grep -E '^\\s*(dss_version|version)\\s*=' {install_ini} | head -1 | cut -d= -f2 | tr -d ' \\t') "
        "|| true"
    )
    rc, out, _ = ex.execute(cmd)
    if rc == 0 and out.strip():
        return out.strip()
    return None


def detect_dss_service_for_datadir(ex: Executor, data_dir: str) -> str | None:
    """Detect the systemd service name for a given DSS data directory.

    When multiple DSS instances exist on the same host (design/automation/govern),
    we must target the service that corresponds to the provided ``data_dir``.

    Returns the matching systemd unit (e.g. ``dataiku.design``), or None if DSS
    was not registered as a systemd service.
    """
    # We intentionally search for any dataiku.* units, and select the one whose
    # unit file references the DSS datadir path.
    cmd = (
        "for svc in $(systemctl list-unit-files 'dataiku.*' --no-legend 2>/dev/null | awk '{print $1}'); do "
        f"  systemctl cat \"$svc\" 2>/dev/null | grep -F {q(data_dir)} >/dev/null 2>&1 && echo \"$svc\" && break; "
        "done"
    )
    rc, out, _ = ex.execute(cmd)
    if rc == 0 and out.strip():
        return out.strip()
    return None


def detect_dss_cgroup_name(ex: Executor, data_dir: str) -> str:
    """Return an appropriate cgroup directory name for this DSS instance.

    Resolution order:
    1. Systemd service name (e.g. ``dataiku.design``) — preferred because it
       uniquely identifies the node type and matches the naming used by DSS
       unit files.  The ``.service`` suffix is stripped if present.
    2. ``DATA_DIR/install.ini`` ``nodetype`` key — fallback when DSS is not yet
       registered as a systemd service.
    3. ``"DSS"`` — ultimate fallback when neither source is available.

    Using per-node names (``dataiku.design``, ``dataiku.automation``, …) prevents
    cgroup conflicts when multiple DSS node types share the same host.
    """
    svc = detect_dss_service_for_datadir(ex, data_dir)
    if svc:
        return svc.removesuffix(".service")

    install_ini = q(f"{data_dir}/install.ini")
    cmd = (
        f"sudo -n grep -Ei '^\\s*nodetype\\s*=' {install_ini} 2>/dev/null "
        "| head -1 | cut -d= -f2 | tr -d ' \\t'"
    )
    rc, out, _ = ex.execute(cmd)
    if rc == 0 and out.strip():
        return f"dataiku.{out.strip().lower()}"

    return "DSS"


def dss_stop(ex: Executor, ui: Ui, os_user: str, data_dir: str) -> None:
    """Stop DSS via systemd if possible, otherwise fall back to ./bin/dss stop.

    Using systemctl ensures the service state is tracked correctly and
    systemd lifecycle hooks (e.g. ExecStopPost) are executed.
    """
    svc = detect_dss_service_for_datadir(ex, data_dir)
    if svc:
        ui.log(f"Stopping {svc} via systemd.")
        rc, _, _ = ex.execute(f"sudo -n systemctl stop {q(svc)}")
        if rc != 0:
            ui.log(f"systemctl stop {svc} failed; falling back to ./bin/dss stop.")
            run(ex, f"sudo -n -u {q(os_user)} -i -- sh -c {q(f'{data_dir}/bin/dss stop')} || true")
            return

        # If systemd still considers the service active, fall back to dss stop.
        rc2, _, _ = ex.execute(f"systemctl is-active --quiet {q(svc)}")
        if rc2 == 0:
            ui.log(f"{svc} is still active; falling back to ./bin/dss stop.")
            run(ex, f"sudo -n -u {q(os_user)} -i -- sh -c {q(f'{data_dir}/bin/dss stop')} || true")
    else:
        ui.log("systemd service not found; stopping DSS via ./bin/dss stop.")
        run(ex, f"sudo -n -u {q(os_user)} -i -- sh -c {q(f'{data_dir}/bin/dss stop')}")


def dss_start(ex: Executor, ui: Ui, os_user: str, data_dir: str) -> None:
    """Start DSS via systemd if possible, otherwise fall back to ./bin/dss start.

    Using systemctl ensures ExecStartPre hooks in the unit file are executed,
    which is required for features like cgroups resource control configured via
    dataiku-boot.conf.
    """
    svc = detect_dss_service_for_datadir(ex, data_dir)
    if svc:
        ui.log(f"Starting {svc} via systemd.")
        check(
            ex,
            f"sudo -n systemctl start {q(svc)}",
            error_hint=(
                f"DSS failed to start. "
                f"Check: journalctl -xeu {svc}.service"
            ),
        )
        ui.log("Waiting for DSS to become ready.")
        run(ex, "sleep 15")
    else:
        ui.log("systemd service not found; starting DSS via ./bin/dss start.")
        check(ex, f"sudo -n -u {q(os_user)} -i -- sh -c {q(f'{data_dir}/bin/dss start')}")
        run(ex, "sleep 15")
