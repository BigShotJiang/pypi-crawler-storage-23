"""Shared helpers for recipes."""

