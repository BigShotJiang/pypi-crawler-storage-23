from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StarburstOciComponentInstallPlan:
    """Plan inputs for installing a Starburst OCI Helm chart (Ranger/Hive/Cache)."""

    component: str  # e.g. "ranger" | "hive" | "cache"
    release_name: str
    namespace: str
    kubeconfig_path: str
    kubectl_context: str | None = None

    oci_chart_ref: str = ""
    chart_version: str | None = None

    # Harbor credentials (used for OCI registry login and image pulls)
    repo_username: str | None = None
    repo_password: str | None = None

    # Optional image pull shortcut (writes to registryCredentials.*)
    registry_username: str | None = None
    registry_password: str | None = None

    values_files: list[str] | None = None
    set_values: list[str] | None = None

    timeout: str = "20m"

    def kubectl_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--context", self.kubectl_context]
        return flags

    def helm_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--kube-context", self.kubectl_context]
        return flags

