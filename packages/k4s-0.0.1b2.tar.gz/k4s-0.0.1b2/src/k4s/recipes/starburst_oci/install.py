"""Starburst OCI component installation recipe (Hive, Ranger, Cache)."""

from __future__ import annotations

import os
import shlex

from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.helm import (
    kube_cmd,
    mask_secret,
    postcheck_pods,
    release_exists,
    wait_for_rollout,
    which,
)
from k4s.recipes.common.run import check, q, run
from k4s.recipes.starburst_oci.model import StarburstOciComponentInstallPlan
from k4s.ui.ui import Ui


DEFAULT_OCI_REGISTRY = "harbor.starburstdata.net"


def build_plan_from_env(plan: StarburstOciComponentInstallPlan) -> StarburstOciComponentInstallPlan:
    """Fill credentials from environment variables when not provided."""
    user = plan.repo_username or os.environ.get("K4S_STARBURST_REPO_USERNAME")
    pw = plan.repo_password or os.environ.get("K4S_STARBURST_REPO_PASSWORD")
    reg_user = plan.registry_username or os.environ.get("K4S_STARBURST_REGISTRY_USERNAME") or user
    reg_pw = plan.registry_password or os.environ.get("K4S_STARBURST_REGISTRY_PASSWORD") or pw
    return StarburstOciComponentInstallPlan(
        **{
            **plan.__dict__,
            "repo_username": user,
            "repo_password": pw,
            "registry_username": reg_user,
            "registry_password": reg_pw,
        }
    )


# ---------------------------------------------------------------------------
# Shared helpers (used by both install.py and upgrade.py)
# ---------------------------------------------------------------------------

def build_helm_value_args(plan: StarburstOciComponentInstallPlan) -> list[str]:
    """Build Helm value/set arguments for Starburst OCI components."""
    args: list[str] = []
    if plan.values_files:
        for vf in plan.values_files:
            args += ["-f", vf]

    # Image pull credentials shortcut
    if plan.registry_username and plan.registry_password:
        args += ["--set", "registryCredentials.enabled=true"]
        args += ["--set", "registryCredentials.registry=harbor.starburstdata.net/starburstdata"]
        args += ["--set", f"registryCredentials.username={plan.registry_username}"]
        args += ["--set", f"registryCredentials.password={plan.registry_password}"]

    if plan.set_values:
        for s in plan.set_values:
            args += ["--set", s]
    return args


def build_common_steps(
    ui: Ui, ex: Executor, plan: StarburstOciComponentInstallPlan,
) -> list[Step]:
    """Build steps shared by install and upgrade (preflight, registry login)."""

    def _preflight():
        ui.log("Checking kubeconfig, local kubectl/helm, cluster access, and required credentials.")
        if not os.path.exists(plan.kubeconfig_path):
            raise ExecutorError(f"Kubeconfig not found: {plan.kubeconfig_path}")
        if not which(ex, "kubectl"):
            raise ExecutorError("kubectl is not installed. Install it and retry.")
        if not which(ex, "helm"):
            raise ExecutorError("helm is not installed. Install it and retry.")

        check(ex, kube_cmd(plan, "kubectl", "version", "--client"))
        rc, _, err = run(ex, kube_cmd(plan, "kubectl", "get", "nodes"))
        if rc != 0:
            raise ExecutorError(f"Cannot access cluster using kubeconfig: {err}")

        if not plan.repo_username or not plan.repo_password:
            raise ExecutorError(
                "Starburst Harbor credentials are required.\n"
                "Provide --repo-username/--repo-password "
                "(or env vars K4S_STARBURST_REPO_USERNAME/K4S_STARBURST_REPO_PASSWORD)."
            )
        if not plan.chart_version:
            raise ExecutorError("Chart version is required. Provide --chart-version (e.g. 453.0.0).")
        if not plan.oci_chart_ref:
            raise ExecutorError("Internal error: missing OCI chart reference.")

        ui.info(f"OCI chart: {plan.oci_chart_ref}")
        ui.info(f"Chart version: {plan.chart_version}")
        ui.info(f"Repo username: {plan.repo_username} | password: {mask_secret(plan.repo_password)}")

    def _registry_login():
        ui.log(f"Logging in to OCI registry {DEFAULT_OCI_REGISTRY}")
        cmd = (
            f"helm registry login {q(DEFAULT_OCI_REGISTRY)} "
            f"--username {q(plan.repo_username)} "
            f"--password-stdin"
        )
        check(ex, cmd, stdin_data=plan.repo_password)

    return [
        Step(title=f"Preflight ({plan.component})", run=_preflight),
        Step(title="Login to Starburst Harbor registry", run=_registry_login),
    ]


# ---------------------------------------------------------------------------
# Install
# ---------------------------------------------------------------------------

def build_install_steps(
    ui: Ui, ex: Executor, plan: StarburstOciComponentInstallPlan,
) -> list[Step]:
    """Build install steps for a Starburst OCI component using ``helm install``.

    If the release already exists, raises and hints ``k4s upgrade`` or uninstall + install.
    """
    steps = build_common_steps(ui, ex, plan)

    def _install():
        if release_exists(ex, plan):
            raise ExecutorError(
                f"Helm release '{plan.release_name}' already exists in namespace '{plan.namespace}'.\n"
                f"Use `k4s upgrade {plan.component}` to upgrade the existing release,\n"
                "or uninstall it first and rerun install:\n"
                f"  helm uninstall {plan.release_name} -n {plan.namespace}"
            )

        ui.log("Running helm install with OCI chart reference")
        cmd_parts: list[str] = [
            "helm", "install",
            plan.release_name, plan.oci_chart_ref,
            "--version", plan.chart_version,
            "--namespace", plan.namespace,
            "--create-namespace",
        ] + plan.helm_flags() + build_helm_value_args(plan)

        cmd = " ".join(shlex.quote(p) for p in cmd_parts)
        check(ex, cmd)

    steps.append(Step(
        title=f"Install {plan.component} release '{plan.release_name}'",
        run=_install,
    ))
    steps.append(Step(title="Wait for rollout to complete", run=lambda: wait_for_rollout(ui, ex, plan)))
    steps.append(Step(title="Post-check (pods)", run=lambda: postcheck_pods(ui, ex, plan)))
    return steps
