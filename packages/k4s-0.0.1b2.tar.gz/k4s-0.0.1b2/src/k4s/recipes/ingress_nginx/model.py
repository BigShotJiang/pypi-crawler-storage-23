from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class IngressNginxInstallPlan:
    """Plan inputs for installing ingress-nginx via Helm."""

    release_name: str
    namespace: str
    kubeconfig_path: str
    kubectl_context: str | None = None

    # Helm chart reference (repo-based)
    repo_name: str = "ingress-nginx"
    repo_url: str = "https://kubernetes.github.io/ingress-nginx"
    chart_name: str = "ingress-nginx"
    chart_version: str | None = None

    values_files: list[str] | None = None
    set_values: list[str] | None = None

    timeout: str = "10m"

    def kubectl_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--context", self.kubectl_context]
        return flags

    def helm_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--kube-context", self.kubectl_context]
        return flags

