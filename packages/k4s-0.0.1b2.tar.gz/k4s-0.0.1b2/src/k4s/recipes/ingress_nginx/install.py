"""ingress-nginx installation recipe (helm install)."""

from __future__ import annotations

import os
import shlex

from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.helm import (
    kube_cmd,
    postcheck_pods,
    release_exists,
    wait_for_rollout,
    which,
)
from k4s.recipes.common.run import check, q, run
from k4s.recipes.ingress_nginx.model import IngressNginxInstallPlan
from k4s.ui.ui import Ui


# ---------------------------------------------------------------------------
# Shared helpers (used by both install.py and upgrade.py)
# ---------------------------------------------------------------------------

def build_helm_value_args(plan: IngressNginxInstallPlan) -> list[str]:
    """Build Helm value/set arguments for ingress-nginx."""
    args: list[str] = []
    if plan.chart_version:
        args += ["--version", plan.chart_version]
    if plan.values_files:
        for vf in plan.values_files:
            args += ["-f", vf]
    if plan.set_values:
        for s in plan.set_values:
            args += ["--set", s]
    return args


def build_common_steps(ui: Ui, ex: Executor, plan: IngressNginxInstallPlan) -> list[Step]:
    """Build steps shared by install and upgrade (preflight, repo add/update)."""

    def _preflight():
        ui.log("Checking kubeconfig, local kubectl/helm, and cluster access.")
        if not os.path.exists(plan.kubeconfig_path):
            raise ExecutorError(f"Kubeconfig not found: {plan.kubeconfig_path}")
        if not which(ex, "kubectl"):
            raise ExecutorError("kubectl is not installed. Install it and retry.")
        if not which(ex, "helm"):
            raise ExecutorError("helm is not installed. Install it and retry.")

        # Cluster access (best-effort).
        check(ex, kube_cmd(plan, "kubectl", "version", "--client"))
        rc, _, err = run(ex, kube_cmd(plan, "kubectl", "get", "nodes"))
        if rc != 0:
            raise ExecutorError(f"Cannot access cluster using kubeconfig: {err}")

    def _repo_add_update():
        ui.log("Adding/updating ingress-nginx Helm repo and updating index.")
        cmd = f"helm repo add --force-update {q(plan.repo_name)} {q(plan.repo_url)}"
        check(ex, cmd)
        check(ex, "helm repo update")

    return [
        Step(title="Preflight (ingress-nginx)", run=_preflight),
        Step(title="Add/update Helm repository", run=_repo_add_update),
    ]


# ---------------------------------------------------------------------------
# Install
# ---------------------------------------------------------------------------

def build_install_steps(
    ui: Ui, ex: Executor, plan: IngressNginxInstallPlan,
) -> list[Step]:
    """Build ingress-nginx install steps using ``helm install``.

    If the release already exists, raises and hints ``k4s upgrade`` or uninstall + install.
    """
    steps = build_common_steps(ui, ex, plan)

    def _install():
        chart_ref = f"{plan.repo_name}/{plan.chart_name}"

        if release_exists(ex, plan):
            raise ExecutorError(
                f"Helm release '{plan.release_name}' already exists in namespace '{plan.namespace}'.\n"
                "Use `k4s upgrade ingress-nginx` to upgrade the existing release,\n"
                "or uninstall it first and rerun install:\n"
                f"  helm uninstall {plan.release_name} -n {plan.namespace}"
            )

        ui.log("Running helm install for ingress-nginx")
        cmd_parts: list[str] = [
            "helm", "install",
            plan.release_name, chart_ref,
            "--namespace", plan.namespace,
            "--create-namespace",
        ] + plan.helm_flags() + build_helm_value_args(plan)

        cmd = " ".join(shlex.quote(p) for p in cmd_parts)
        check(ex, cmd)

    steps.append(Step(title=f"Install ingress-nginx release '{plan.release_name}'", run=_install))
    steps.append(Step(title="Wait for rollout to complete", run=lambda: wait_for_rollout(ui, ex, plan)))
    steps.append(Step(title="Post-check (pods)", run=lambda: postcheck_pods(ui, ex, plan)))
    return steps
