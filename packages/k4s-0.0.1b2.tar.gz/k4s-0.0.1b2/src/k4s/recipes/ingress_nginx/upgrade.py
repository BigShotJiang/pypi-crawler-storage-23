"""ingress-nginx upgrade recipe (helm upgrade)."""

from __future__ import annotations

import shlex

from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.helm import (
    force_delete_pods,
    postcheck_pods,
    release_exists,
    snapshot_release_pods,
    wait_for_rollout,
)
from k4s.recipes.common.run import check
from k4s.recipes.ingress_nginx.install import build_common_steps, build_helm_value_args
from k4s.recipes.ingress_nginx.model import IngressNginxInstallPlan
from k4s.ui.ui import Ui


def build_upgrade_steps(
    ui: Ui, ex: Executor, plan: IngressNginxInstallPlan, *, force: bool = False,
) -> list[Step]:
    """Build ingress-nginx upgrade steps using ``helm upgrade``.

    If the release does not exist, raises an error.

    ``helm upgrade`` always runs without ``--wait``.  Readiness is verified
    via ``kubectl rollout status``.  When *force* is ``True``, pre-upgrade
    pods are additionally force-deleted before the rollout wait.
    """
    steps = build_common_steps(ui, ex, plan)

    _pre_upgrade_pods: list[str] = []

    def _upgrade():
        chart_ref = f"{plan.repo_name}/{plan.chart_name}"

        if not release_exists(ex, plan):
            raise ExecutorError(
                f"Helm release '{plan.release_name}' not found in namespace '{plan.namespace}'.\n"
                "Install first with `k4s install ingress-nginx`."
            )

        if force:
            _pre_upgrade_pods.extend(snapshot_release_pods(ui, ex, plan))

        ui.log("Running helm upgrade for ingress-nginx")
        cmd_parts: list[str] = [
            "helm", "upgrade",
            plan.release_name, chart_ref,
            "--namespace", plan.namespace,
        ] + plan.helm_flags() + build_helm_value_args(plan)

        cmd = " ".join(shlex.quote(p) for p in cmd_parts)
        check(ex, cmd)

    steps.append(Step(title=f"Upgrade ingress-nginx release '{plan.release_name}'", run=_upgrade))
    if force:
        steps.append(Step(
            title="Delete pods now (best-effort)",
            run=lambda: force_delete_pods(ui, ex, plan, _pre_upgrade_pods),
        ))
    steps.append(Step(title="Wait for rollout to complete", run=lambda: wait_for_rollout(ui, ex, plan)))
    steps.append(Step(title="Post-check (pods)", run=lambda: postcheck_pods(ui, ex, plan)))
    return steps
