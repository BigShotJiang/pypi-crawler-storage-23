"""Product recipes and shared helpers.

Recipes are deterministic, code-defined procedures that implement k4s operations
such as installing a product or enabling TLS.
"""

