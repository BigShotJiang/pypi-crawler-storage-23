# WeavexPy - 3.4.10 - RC

**0.0.1** -> **0.0.3** = not available

---
**1.0.0** = test launch

---
**1.0.1** = official Alpha version

---
**1.1.1** = In this version, we added a function that displays all the application console data (logs, errors, etc.) in the Python console, for example:

Web console:

Hello World

Python console:

DD/MM/YYYY HH:MM:SS - [console:log] - Hello World

---
**1.2.1** = In this version we can use `@keyframes` animations, and a simple object has been added that allows you to create a navigation menu when you right-click on the screen. To add it to the page, call ~~`NavMenu()`~~, which is basically a Brython script. In addition, you can create message boxes.

---
**1.3.1** = ~~new `WindowServer`.~~ *#Starting with version 0.1.1, WindowServer and the NavMenu was discontinued.*

---
**1.3.2** = + brython.

---
**1.3.3** = + ehtml.

---
**2.3.3** = up WeavexPy and - WindowServer.

---
**2.3.4** = up WeavexPy.

---
**2.3.5** = up weavexPy.

---

---
**2.3.6** = up weavexPy.

---

**2.3.7** = up weavexPy.

---
**2.3.8** = up weavxPy.

---
**3.3.8** = add repo.

---
**3.4.9** = add JavaScript.

---
**3.4.10** = up weavexPy.

---