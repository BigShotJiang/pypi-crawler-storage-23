from ._messagebox_ import *

class messagebox:
    def __init__(self):
        self.ifo = ifo
        self.erro = erro
        self.warning = warning
        self.CreateMessage = CreateMessage
        