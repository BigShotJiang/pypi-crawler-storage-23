library flet_android_notifications;

export "src/extension.dart" show Extension;
