"""Exposes the use cases for Yagra."""

from yagra.application.services import EdgeRuleIssue, collect_edge_rule_issues
from yagra.application.use_cases.state_graph_builder import (
    GraphBuildError,
    build_from_workflow_path,
    build_state_graph,
)
from yagra.application.use_cases.workflow_edit_session import (
    WorkflowChange,
    WorkflowDiffResult,
    WorkflowEditSession,
    build_workflow_diff,
    compute_workflow_revision,
    load_workflow_edit_session,
    resolve_ui_state_path,
)
from yagra.application.use_cases.workflow_explainer import explain_workflow
from yagra.application.use_cases.workflow_form_model import (
    WorkflowEdgeFormItem,
    WorkflowFormView,
    WorkflowNodeFormItem,
    build_workflow_form_view,
)
from yagra.application.use_cases.workflow_form_patcher import apply_form_edits
from yagra.application.use_cases.workflow_loader import load_graph_spec_from_workflow
from yagra.application.use_cases.workflow_persistence import (
    WorkflowRevisionConflictError,
    WorkflowRollbackResult,
    WorkflowSaveResult,
    rollback_workflow_from_backup,
    save_workflow_with_backup,
)
from yagra.application.use_cases.workflow_validation_reporter import (
    WorkflowValidationFailedError,
    WorkflowValidationIssue,
    WorkflowValidationReport,
    format_validation_report,
    load_validated_graph_spec,
    validate_workflow_for_ui,
    validate_workflow_payload_for_ui,
)

__all__ = [
    "EdgeRuleIssue",
    "GraphBuildError",
    "WorkflowChange",
    "WorkflowDiffResult",
    "WorkflowEdgeFormItem",
    "WorkflowEditSession",
    "WorkflowFormView",
    "WorkflowNodeFormItem",
    "WorkflowRevisionConflictError",
    "WorkflowRollbackResult",
    "WorkflowSaveResult",
    "WorkflowValidationFailedError",
    "WorkflowValidationIssue",
    "WorkflowValidationReport",
    "build_workflow_diff",
    "build_workflow_form_view",
    "build_from_workflow_path",
    "build_state_graph",
    "apply_form_edits",
    "collect_edge_rule_issues",
    "compute_workflow_revision",
    "explain_workflow",
    "format_validation_report",
    "load_workflow_edit_session",
    "load_validated_graph_spec",
    "load_graph_spec_from_workflow",
    "resolve_ui_state_path",
    "rollback_workflow_from_backup",
    "save_workflow_with_backup",
    "validate_workflow_payload_for_ui",
    "validate_workflow_for_ui",
]
