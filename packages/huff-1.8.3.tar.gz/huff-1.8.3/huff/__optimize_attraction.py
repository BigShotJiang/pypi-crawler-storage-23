def optimize_attraction(
        self,
        tolerance = 0.05,
        start_with: str = "max",
        update_estimates: bool = True,
        check_numbers: bool = True,
        check_df_vars: bool = True,
        verbose: bool = config.VERBOSE
        ):
        
        supply_locations = self.interaction_matrix.supply_locations
        if supply_locations is None:
            raise KeyError("HuffModel object does not contain supply locations")        
        if getattr(supply_locations, "metadata", None) is None:
            raise KeyError("Supply locations in HuffModel object lack metadata")
                
        if self.market_areas_df is None:
            raise KeyError("HuffModel object does not contain total market areas")
            
        market_areas_df = self.market_areas_df
        
        if "T_j" not in market_areas_df.columns:
            raise KeyError("Market areas data in HuffModel object do not contain total market area values")
        
        if verbose:
            print("Extracting and re-arranging supply locations data", " ... ")
        
        supply_locations_metadata = supply_locations.get_metadata()
        
        attraction_col = supply_locations_metadata["attraction_col"]
        unique_id = supply_locations_metadata["unique_id"]
        
        supply_locations_geodata_gpd_original = supply_locations.get_geodata_gpd_original()       
        
        attraction_col_first = attraction_col[0]        
        
        supply_locations_attraction_totals = pd.merge(
            supply_locations_geodata_gpd_original[[unique_id, attraction_col_first]],
            market_areas_df[["j", "T_j"]],
            how = "inner",
            left_on = unique_id,
            right_on = "j"
            )
        
        supply_locations_attraction_totals = supply_locations_attraction_totals.dropna(subset = "T_j")
        
        if start_with == "min":
            supply_locations_attraction_totals = supply_locations_attraction_totals.sort_values(
                by = attraction_col_first, 
                ascending=True
                )
        else:
            supply_locations_attraction_totals = supply_locations_attraction_totals.sort_values(
                by = attraction_col_first, 
                ascending=False
                )
        
        #print(supply_locations_attraction_totals) # TODO ?? RAUS
        
        if verbose:
            print("OK")
            print(f"NOTE: There are {len(supply_locations_attraction_totals)} supply locations with valid unique identifiers and total market areas.")
        
        if len(attraction_col) > 1:
            
            print(f"WARNING: There are {len(attraction_col)} attraction variables the HuffModel object. Only the first one '{attraction_col_first}' is used and all others will be deleted.")
            
            supply_locations_metadata["attraction_col"] = [attraction_col_first]
            
        else:
            if verbose:
                print(f"NOTE: Attraction variable '{attraction_col_first}' is used for optimization of attraction.")
        
        if verbose:
            print(f"Weighting function and parameter for attraction variable '{attraction_col_first}' of supply locations are reset", end = " ... ") # TODO ??
            
            self.interaction_matrix.supply_locations.metadata["weighting"] = {
                0: {
                    "name": attraction_col_first,
                    "func": "power", 
                    "param": -2
                    }
                }
            
            helper.add_timestamp(
                self.interaction_matrix.supply_locations,
                function="optimize_attraction",
                )
            
        if verbose:
            print("OK")
        
        
        
        #for i, row in supply_locations_attraction_totals.iterrows():
            
            # print(f"Laden {row['j']} hat einen attraction-Wert von {row[attraction_col_first]} und einen Echtumsatz von {row['T_j']}") # TODO ?? RAUS
            
        
        helper.add_timestamp(
            self,
            function="optimize_attraction",
            )
        
        # if attraction_col not in geodata_gpd_original.columns:
        #     raise KeyError (f"Error while defining attraction variable: Column {attraction_col} not in data")
        # else:
        #     metadata["attraction_col"][0] = attraction_col