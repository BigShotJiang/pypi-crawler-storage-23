## Summary
<!-- Brief description of changes -->

## Changes
- [ ] Change 1
- [ ] Change 2

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests pass
- [ ] mypy passes
- [ ] ruff passes

## Documentation
- [ ] Docstrings updated
- [ ] README updated (if applicable)
- [ ] CHANGELOG updated
