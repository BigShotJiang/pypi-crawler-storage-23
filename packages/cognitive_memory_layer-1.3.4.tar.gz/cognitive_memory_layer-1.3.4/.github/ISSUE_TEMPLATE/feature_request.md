---
name: Feature Request
about: Suggest a feature for py-cml
title: "[FEATURE] "
labels: enhancement
---

**Use Case**
What problem does this solve?

**Proposed API**
```python
# How should this look for developers?
```

**Alternatives**
Other approaches considered.
