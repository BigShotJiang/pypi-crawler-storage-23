"""End-to-end tests (require live server and optionally embedded)."""
