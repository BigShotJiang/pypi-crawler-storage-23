"""Embedded CML tests (require embedded extras)."""
