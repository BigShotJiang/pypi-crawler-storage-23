"""Tests for API client with mocked HTTP responses."""

import pytest
from unittest.mock import patch, MagicMock

from evercoast_cli.api import (
    APIError,
    BASE_HEADERS,
    EC_AGENT_HEADER,
    login,
    fetch_s3_credentials,
    _generate_bash_helper,
    _generate_powershell_helper,
)


class TestLogin:
    @patch("evercoast_cli.api.requests.post")
    def test_successful_login(self, mock_post, mock_login_response):
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: mock_login_response,
        )

        token = login("https://api.example.com/api/v1", "user@example.com", "password123")
        assert token == "abc123def456ghi789"

        # Verify request
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        assert call_args[0][0] == "https://api.example.com/api/v1/login/"
        assert call_args[1]["json"]["email"] == "user@example.com"
        assert call_args[1]["json"]["password"] == "password123"

    @patch("evercoast_cli.api.requests.post")
    def test_ec_agent_header_sent(self, mock_post, mock_login_response):
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: mock_login_response,
        )

        login("https://api.example.com/api/v1", "user@example.com", "pass")

        call_args = mock_post.call_args
        headers = call_args[1]["headers"]
        assert headers["EC-Agent"] == "CB"

    @patch("evercoast_cli.api.requests.post")
    def test_invalid_credentials(self, mock_post):
        mock_post.return_value = MagicMock(
            status_code=400,
            json=lambda: {"non_field_errors": ["Your credentials are invalid."]},
        )

        with pytest.raises(APIError, match="Your credentials are invalid"):
            login("https://api.example.com/api/v1", "user@example.com", "wrong")

    @patch("evercoast_cli.api.requests.post")
    def test_inactive_account(self, mock_post):
        mock_post.return_value = MagicMock(
            status_code=400,
            json=lambda: {"detail": "Your license has expired."},
        )

        with pytest.raises(APIError, match="license has expired"):
            login("https://api.example.com/api/v1", "user@example.com", "pass")

    @patch("evercoast_cli.api.requests.post")
    def test_connection_error(self, mock_post):
        import requests as req
        mock_post.side_effect = req.ConnectionError("Connection refused")

        with pytest.raises(APIError, match="Could not connect"):
            login("https://api.example.com/api/v1", "user@example.com", "pass")

    @patch("evercoast_cli.api.requests.post")
    def test_timeout(self, mock_post):
        import requests as req
        mock_post.side_effect = req.Timeout("Timed out")

        with pytest.raises(APIError, match="timed out"):
            login("https://api.example.com/api/v1", "user@example.com", "pass")

    @patch("evercoast_cli.api.requests.post")
    def test_no_token_in_response(self, mock_post):
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {"no_token_field": True},
        )

        with pytest.raises(APIError, match="no token"):
            login("https://api.example.com/api/v1", "user@example.com", "pass")


class TestFetchS3Credentials:
    @patch("evercoast_cli.api.requests.post")
    def test_successful_fetch(self, mock_post, mock_s3_response):
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: mock_s3_response,
        )

        result = fetch_s3_credentials("https://api.example.com/api/v1", "my-token")
        assert result["bucket"] == "test-company-bucket"
        assert result["access_key_id"] == "AKIAIOSFODNN7EXAMPLE"
        assert result["region"] == "us-east-1"

    @patch("evercoast_cli.api.requests.post")
    def test_ec_agent_header_sent(self, mock_post, mock_s3_response):
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: mock_s3_response,
        )

        fetch_s3_credentials("https://api.example.com/api/v1", "my-token")

        call_args = mock_post.call_args
        headers = call_args[1]["headers"]
        assert headers["EC-Agent"] == "CB"
        assert headers["Authorization"] == "Token my-token"

    @patch("evercoast_cli.api.requests.post")
    def test_expired_token(self, mock_post):
        mock_post.return_value = MagicMock(
            status_code=401,
            json=lambda: {"detail": "Invalid token."},
        )

        with pytest.raises(APIError, match="Run 'evercoast login'"):
            fetch_s3_credentials("https://api.example.com/api/v1", "expired-token")

    @patch("evercoast_cli.api.requests.post")
    def test_s3_not_enabled(self, mock_post):
        mock_post.return_value = MagicMock(
            status_code=403,
            json=lambda: {"error": "S3 direct upload is not enabled for your company."},
        )

        with pytest.raises(APIError, match="S3 direct upload"):
            fetch_s3_credentials("https://api.example.com/api/v1", "my-token")


class TestCredentialHelpers:
    def test_bash_helper_contains_token(self):
        script = _generate_bash_helper("https://api.example.com/api/v1", "my-token-123")
        assert "my-token-123" in script
        assert "EC-Agent: CB" in script
        assert "s3-credentials" in script
        assert "Version" in script

    def test_powershell_helper_contains_token(self):
        script = _generate_powershell_helper("https://api.example.com/api/v1", "my-token-123")
        assert "my-token-123" in script
        assert "EC-Agent" in script
        assert "s3-credentials" in script
        assert "Version" in script

    def test_bash_helper_uses_api_url(self):
        script = _generate_bash_helper("https://staging.api.com/api/v1", "tok")
        assert "https://staging.api.com/api/v1" in script

    def test_powershell_helper_uses_api_url(self):
        script = _generate_powershell_helper("https://staging.api.com/api/v1", "tok")
        assert "https://staging.api.com/api/v1" in script
