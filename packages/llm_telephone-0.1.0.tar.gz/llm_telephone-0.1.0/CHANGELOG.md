# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-27

### Added

- Initial release as a proper Python package (`llm-telephone`)
- `src/` layout with `hatchling` build backend
- `llm-telephone` CLI entry point powered by `click`
- Rich progress bar and results table via `rich`
- `--output-format json` for structured output
- `--return-lang` option to customise the chain's return language
- `OpenRouterClient` with retry logic (up to 3 attempts with backoff)
- `get_chain()` helper for programmatic chain construction
- Custom exception hierarchy: `LLMTelephoneError`, `APIError`, `ConfigError`
- 44 unit tests, 97% code coverage
- GitHub Actions CI matrix (Python 3.10 / 3.11 / 3.12)
- MIT License

### Notes

- Original single-file script (`llm_translate_20x.py`) is retained for backwards
  compatibility but is no longer the recommended interface.
