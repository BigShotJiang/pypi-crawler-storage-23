#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = "google/gemini-3-flash-preview"
API_KEY_ENV_CANDIDATES = [
    "OPENROUTER_API_KEY",
    "OPENROUTER_KEY",
]

# 20-step language chain. Last step returns to Simplified Chinese for easy comparison.
LANGUAGE_CHAIN = [
    "English",
    "Japanese",
    "French",
    "German",
    "Spanish",
    "Korean",
    "Arabic",
    "Russian",
    "Portuguese",
    "Hindi",
    "Italian",
    "Turkish",
    "Vietnamese",
    "Thai",
    "Dutch",
    "Polish",
    "Swedish",
    "Greek",
    "Indonesian",
    "Simplified Chinese",
]


def build_messages(text: str, target_language: str):
    system_prompt = (
        "You are a professional translator. "
        "Translate accurately and naturally. "
        "Output only the translated text, without notes, quotes, or explanations."
    )
    user_prompt = (
        f"Translate the following text into {target_language}.\n"
        f"Text: {text}"
    )
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]


def call_openrouter(api_key: str, model: str, messages, max_retries: int = 3):
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        # Optional but recommended by OpenRouter docs:
        "HTTP-Referer": "https://local.ssh",
        "X-Title": "translation-20x-test",
    }

    data = json.dumps(payload).encode("utf-8")

    last_err = None
    for attempt in range(1, max_retries + 1):
        req = urllib.request.Request(OPENROUTER_URL, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                body = resp.read().decode("utf-8")
                parsed = json.loads(body)
                return parsed["choices"][0]["message"]["content"].strip(), parsed
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore")
            last_err = RuntimeError(f"HTTP {e.code}: {err_body}")
        except Exception as e:
            last_err = e

        if attempt < max_retries:
            time.sleep(1.5 * attempt)

    raise RuntimeError(f"OpenRouter request failed after {max_retries} attempts: {last_err}")


def run_chain(
    initial_text: str,
    model: str,
    rounds: int,
    api_key: str,
    process_output: str | None,
    final_output: str | None,
):
    if rounds < 1:
        raise ValueError("rounds must be >= 1")

    if rounds > len(LANGUAGE_CHAIN):
        raise ValueError(f"rounds cannot exceed {len(LANGUAGE_CHAIN)} with current LANGUAGE_CHAIN")

    current_text = initial_text
    records = []
    process_lines = []

    print(f"Model: {model}")
    print(f"Initial: {current_text}\n")
    process_lines.append(f"Initial: {current_text}")

    for i in range(rounds):
        target_language = LANGUAGE_CHAIN[i]
        messages = build_messages(current_text, target_language)
        translated_text, raw_response = call_openrouter(api_key, model, messages)

        record = {
            "round": i + 1,
            "target_language": target_language,
            "input": current_text,
            "output": translated_text,
            "model": model,
            "raw_id": raw_response.get("id"),
        }
        records.append(record)

        line = f"Round {i + 1:02d} [{target_language}]: {translated_text}"
        print(line)
        process_lines.append(line)
        current_text = translated_text

    print("\nFinal:", current_text)

    if process_output:
        with open(process_output, "w", encoding="utf-8") as f:
            f.write("\n".join(process_lines) + "\n")
        print(f"Saved process to: {process_output}")

    if final_output:
        with open(final_output, "w", encoding="utf-8") as f:
            f.write(current_text + "\n")
        print(f"Saved final Chinese to: {final_output}")

    return records


def parse_args():
    parser = argparse.ArgumentParser(
        description="Translate one sentence repeatedly via OpenRouter (Gemini Flash by default)."
    )
    parser.add_argument(
        "text",
        nargs="?",
        help="Initial text to translate repeatedly.",
    )
    parser.add_argument(
        "--text-file",
        help="Read initial text from a UTF-8 text file.",
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"OpenRouter model id (default: {DEFAULT_MODEL})",
    )
    parser.add_argument(
        "--rounds",
        type=int,
        default=20,
        help="How many rounds to run (default: 20)",
    )
    parser.add_argument(
        "--process-output",
        default="translation_process.txt",
        help="Output text path for translation process (one round per line).",
    )
    parser.add_argument(
        "--final-output",
        default="translation_final_zh.txt",
        help="Output text path for final Chinese sentence.",
    )
    return parser.parse_args()


def resolve_initial_text(args):
    if args.text and args.text_file:
        raise ValueError("Use either positional text or --text-file, not both.")

    if args.text_file:
        try:
            with open(args.text_file, "r", encoding="utf-8") as f:
                text = f.read().strip()
        except FileNotFoundError as e:
            raise ValueError(f"text file not found: {args.text_file}") from e
        except OSError as e:
            raise ValueError(f"failed to read text file: {e}") from e

        if not text:
            raise ValueError("text file is empty.")
        return text

    if args.text:
        return args.text

    raise ValueError("Provide text as a positional argument or with --text-file.")


def resolve_api_key():
    for env_name in API_KEY_ENV_CANDIDATES:
        value = os.getenv(env_name)
        if value:
            return value
    return None


def main():
    args = parse_args()
    api_key = resolve_api_key()

    if not api_key:
        candidates = ", ".join(API_KEY_ENV_CANDIDATES)
        print(f"ERROR: OpenRouter API key not found in env vars: {candidates}", file=sys.stderr)
        sys.exit(1)

    try:
        initial_text = resolve_initial_text(args)
        run_chain(
            initial_text=initial_text,
            model=args.model,
            rounds=args.rounds,
            api_key=api_key,
            process_output=args.process_output,
            final_output=args.final_output,
        )
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
