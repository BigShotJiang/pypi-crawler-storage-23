"""llm-telephone: Pass text through a chain of LLM translations and watch the meaning drift."""

__version__ = "0.1.0"

from .exceptions import APIError, ConfigError, LLMTelephoneError
from .languages import DEFAULT_RETURN_LANG, LANGUAGE_POOL, SUPPORTED_RETURN_LANGS, get_chain
from .translator import run_chain

__all__ = [
    "__version__",
    "LLMTelephoneError",
    "APIError",
    "ConfigError",
    "LANGUAGE_POOL",
    "DEFAULT_RETURN_LANG",
    "SUPPORTED_RETURN_LANGS",
    "get_chain",
    "run_chain",
]
