"""Translation chain runner for llm-telephone."""

from __future__ import annotations

import json
import time

from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

from .api_client import OpenRouterClient
from .languages import DEFAULT_RETURN_LANG, get_chain

console = Console()


def run_chain(
    initial_text: str,
    client: OpenRouterClient,
    rounds: int = 20,
    return_lang: str = DEFAULT_RETURN_LANG,
    process_output: str | None = None,
    final_output: str | None = None,
    output_format: str = "text",
) -> list[dict]:
    """Run the translation telephone chain.

    Args:
        initial_text: The text to start translating.
        client: An initialised :class:`OpenRouterClient`.
        rounds: Number of translation rounds (default 20).
        return_lang: Language to end the chain with (default ``"Simplified Chinese"``).
        process_output: Optional path to write per-round text output.
        final_output: Optional path to write the final translated text.
        output_format: ``"text"`` (rich console) or ``"json"`` (structured stdout).

    Returns:
        A list of dicts, one per round, each containing:
        ``round``, ``target_language``, ``input``, ``output``, ``elapsed_s``.

    Raises:
        ValueError: If *rounds* is invalid.
        APIError: If any translation request fails.
    """
    chain = get_chain(rounds, return_lang)
    current_text = initial_text
    records: list[dict] = []

    if output_format == "text":
        console.print(f"[bold]Model:[/bold] {client.model}")
        console.print(f"[bold]Rounds:[/bold] {rounds}")
        console.print(f"[bold]Initial:[/bold] {current_text}\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
        transient=False,
        disable=(output_format == "json"),
    ) as progress:
        task = progress.add_task("Translating...", total=rounds)

        for i, target_language in enumerate(chain):
            progress.update(
                task,
                description=f"Round {i + 1:02d}/{rounds} → [cyan]{target_language}[/cyan]",
            )
            t0 = time.monotonic()
            translated_text = client.translate(current_text, target_language)
            elapsed = time.monotonic() - t0

            record = {
                "round": i + 1,
                "target_language": target_language,
                "input": current_text,
                "output": translated_text,
                "elapsed_s": round(elapsed, 3),
            }
            records.append(record)
            current_text = translated_text
            progress.advance(task)

    if output_format == "text":
        _print_results_table(records)
        console.print(f"\n[bold green]Final:[/bold green] {current_text}")
    elif output_format == "json":
        result = {
            "model": client.model,
            "rounds": rounds,
            "return_lang": return_lang,
            "initial_text": initial_text,
            "final_text": current_text,
            "chain": records,
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))

    if process_output:
        lines = [f"Initial: {initial_text}"]
        for r in records:
            lines.append(f"Round {r['round']:02d} [{r['target_language']}]: {r['output']}")
        with open(process_output, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        if output_format == "text":
            console.print(f"[dim]Saved process log to: {process_output}[/dim]")

    if final_output:
        with open(final_output, "w", encoding="utf-8") as f:
            f.write(current_text + "\n")
        if output_format == "text":
            console.print(f"[dim]Saved final text to: {final_output}[/dim]")

    return records


def _print_results_table(records: list[dict]) -> None:
    table = Table(title="Translation Chain Results", show_lines=False)
    table.add_column("Round", style="dim", width=6)
    table.add_column("Language", style="cyan", min_width=18)
    table.add_column("Output", overflow="fold")
    table.add_column("Time (s)", style="dim", width=8)

    for r in records:
        table.add_row(
            str(r["round"]),
            r["target_language"],
            r["output"],
            f"{r['elapsed_s']:.2f}",
        )

    console.print(table)
