"""Custom exceptions for llm-telephone."""


class LLMTelephoneError(Exception):
    """Base exception for all llm-telephone errors."""


class APIError(LLMTelephoneError):
    """Raised when the OpenRouter API call fails."""


class ConfigError(LLMTelephoneError):
    """Raised when configuration is missing or invalid (e.g., missing API key)."""
