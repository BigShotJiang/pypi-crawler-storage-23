"""Click CLI entry point for llm-telephone."""

from __future__ import annotations

import os
import sys

import click
from rich.console import Console

from .api_client import OpenRouterClient
from .exceptions import ConfigError, LLMTelephoneError
from .languages import DEFAULT_RETURN_LANG, SUPPORTED_RETURN_LANGS
from .translator import run_chain

console = Console(stderr=True)

DEFAULT_MODEL = "google/gemini-3-flash-preview"
API_KEY_ENV_CANDIDATES = ["OPENROUTER_API_KEY", "OPENROUTER_KEY"]


def _resolve_api_key() -> str | None:
    for env_name in API_KEY_ENV_CANDIDATES:
        value = os.getenv(env_name)
        if value:
            return value
    return None


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("text", required=False)
@click.option(
    "--model",
    default=DEFAULT_MODEL,
    show_default=True,
    help="OpenRouter model ID.",
)
@click.option(
    "--rounds",
    default=20,
    show_default=True,
    type=int,
    help="Number of translation rounds.",
)
@click.option(
    "--text-file",
    default=None,
    type=click.Path(exists=True, readable=True),
    help="Read initial text from a UTF-8 file instead of the TEXT argument.",
)
@click.option(
    "--process-output",
    default=None,
    help="Write per-round translation log to this file path.",
)
@click.option(
    "--final-output",
    default=None,
    help="Write the final translated text to this file path.",
)
@click.option(
    "--output-format",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    show_default=True,
    help="Output format: rich text table or JSON.",
)
@click.option(
    "--return-lang",
    default=DEFAULT_RETURN_LANG,
    show_default=True,
    help=(
        "Language to end the chain with. "
        f"Supported values: {', '.join(SUPPORTED_RETURN_LANGS)}"
    ),
)
@click.version_option(package_name="llm-telephone")
def main(
    text: str | None,
    model: str,
    rounds: int,
    text_file: str | None,
    process_output: str | None,
    final_output: str | None,
    output_format: str,
    return_lang: str,
) -> None:
    """Pass TEXT through a chain of LLM translations and watch the meaning drift.

    TEXT is the starting phrase.  Use --text-file to read it from a file instead.

    \b
    Examples:
      llm-telephone "The quick brown fox" --rounds 5
      llm-telephone --text-file origin.txt --output-format json
      llm-telephone "Hello world" --return-lang English --rounds 10
    """
    # --- resolve API key ---
    api_key = _resolve_api_key()
    if not api_key:
        candidates = " or ".join(API_KEY_ENV_CANDIDATES)
        console.print(
            f"[bold red]Error:[/bold red] OpenRouter API key not found.\n"
            f"Set the [bold]{candidates}[/bold] environment variable and try again.",
            highlight=False,
        )
        sys.exit(1)

    # --- resolve input text ---
    if text and text_file:
        console.print(
            "[bold red]Error:[/bold red] Provide TEXT argument or --text-file, not both."
        )
        sys.exit(1)

    if text_file:
        with open(text_file, encoding="utf-8") as f:
            initial_text = f.read().strip()
        if not initial_text:
            console.print("[bold red]Error:[/bold red] --text-file is empty.")
            sys.exit(1)
    elif text:
        initial_text = text.strip()
        if not initial_text:
            console.print("[bold red]Error:[/bold red] TEXT argument is empty.")
            sys.exit(1)
    else:
        console.print(
            "[bold red]Error:[/bold red] Provide a TEXT argument or --text-file."
        )
        sys.exit(1)

    # --- validate return-lang ---
    if return_lang not in SUPPORTED_RETURN_LANGS:
        console.print(
            f"[bold red]Error:[/bold red] --return-lang {return_lang!r} is not supported.\n"
            f"Supported values: {', '.join(SUPPORTED_RETURN_LANGS)}"
        )
        sys.exit(1)

    client = OpenRouterClient(api_key=api_key, model=model)

    try:
        run_chain(
            initial_text=initial_text,
            client=client,
            rounds=rounds,
            return_lang=return_lang,
            process_output=process_output,
            final_output=final_output,
            output_format=output_format,
        )
    except (LLMTelephoneError, ValueError) as exc:
        console.print(f"[bold red]Error:[/bold red] {exc}")
        sys.exit(2)


if __name__ == "__main__":
    main()
