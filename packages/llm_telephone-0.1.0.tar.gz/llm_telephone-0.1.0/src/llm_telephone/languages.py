"""Language pool and chain construction for llm-telephone."""

from __future__ import annotations

# Full pool of candidate languages (order determines default chain priority)
LANGUAGE_POOL: list[str] = [
    "English",
    "Japanese",
    "French",
    "German",
    "Spanish",
    "Korean",
    "Arabic",
    "Russian",
    "Portuguese",
    "Hindi",
    "Italian",
    "Turkish",
    "Vietnamese",
    "Thai",
    "Dutch",
    "Polish",
    "Swedish",
    "Greek",
    "Indonesian",
    "Simplified Chinese",
]

DEFAULT_RETURN_LANG = "Simplified Chinese"

# Languages that can be used as the return language (all languages in the pool)
SUPPORTED_RETURN_LANGS: list[str] = LANGUAGE_POOL.copy()


def get_chain(rounds: int, return_lang: str = DEFAULT_RETURN_LANG) -> list[str]:
    """Build a translation chain of *rounds* steps ending with *return_lang*.

    The intermediate languages are drawn from LANGUAGE_POOL (in order),
    excluding *return_lang* itself.  The final step is always *return_lang*.

    Args:
        rounds: Total number of translation rounds (must be >= 1).
        return_lang: Language to end the chain with.

    Returns:
        A list of language names of length *rounds*.

    Raises:
        ValueError: If *rounds* < 1 or *return_lang* is not in LANGUAGE_POOL,
                    or if *rounds* exceeds the available pool size.

    Examples:
        >>> get_chain(5, "English")
        ['Japanese', 'French', 'German', 'Spanish', 'English']
        >>> get_chain(3)
        ['English', 'Japanese', 'Simplified Chinese']
    """
    if rounds < 1:
        raise ValueError("rounds must be >= 1")
    if return_lang not in LANGUAGE_POOL:
        raise ValueError(
            f"return_lang {return_lang!r} is not in LANGUAGE_POOL. "
            f"Supported values: {SUPPORTED_RETURN_LANGS}"
        )

    intermediates = [lang for lang in LANGUAGE_POOL if lang != return_lang]

    max_rounds = len(intermediates) + 1  # intermediates + return_lang
    if rounds > max_rounds:
        raise ValueError(
            f"rounds ({rounds}) exceeds maximum ({max_rounds}) for return_lang={return_lang!r}"
        )

    chain = intermediates[: rounds - 1] + [return_lang]
    return chain
