"""OpenRouter API client for llm-telephone."""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request

from .exceptions import APIError

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
_HTTP_REFERER = "https://github.com/yymss/llm-telephone"
_X_TITLE = "llm-telephone"


class OpenRouterClient:
    """Thin wrapper around the OpenRouter chat completions API.

    Args:
        api_key: OpenRouter API key (Bearer token).
        model: Model identifier (e.g. ``"google/gemini-3-flash-preview"``).
        timeout: Request timeout in seconds (default 60).
        max_retries: Number of retry attempts on transient errors (default 3).
    """

    def __init__(
        self,
        api_key: str,
        model: str,
        timeout: int = 60,
        max_retries: int = 3,
    ) -> None:
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries

    def translate(self, text: str, target_language: str) -> str:
        """Translate *text* into *target_language* using the configured model.

        Args:
            text: The source text to translate.
            target_language: The target language name (e.g. ``"French"``).

        Returns:
            The translated text string.

        Raises:
            APIError: If the request fails after all retry attempts.
        """
        messages = self._build_messages(text, target_language)
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0,
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": _HTTP_REFERER,
            "X-Title": _X_TITLE,
        }
        data = json.dumps(payload).encode("utf-8")

        last_err: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            req = urllib.request.Request(
                OPENROUTER_URL, data=data, headers=headers, method="POST"
            )
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    body = resp.read().decode("utf-8")
                    return self._parse_response(body)
            except urllib.error.HTTPError as e:
                err_body = e.read().decode("utf-8", errors="ignore")
                last_err = APIError(f"HTTP {e.code}: {err_body}")
            except urllib.error.URLError as e:
                last_err = APIError(f"URL error: {e.reason}")
            except (KeyError, IndexError, json.JSONDecodeError) as e:
                # Malformed response — don't retry
                raise APIError(f"Unexpected API response format: {e}") from e

            if attempt < self.max_retries:
                time.sleep(1.5 * attempt)

        raise APIError(
            f"OpenRouter request failed after {self.max_retries} attempts: {last_err}"
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_messages(text: str, target_language: str) -> list[dict]:
        system_prompt = (
            "You are a professional translator. "
            "Translate accurately and naturally. "
            "Output only the translated text, without notes, quotes, or explanations."
        )
        user_prompt = (
            f"Translate the following text into {target_language}.\n"
            f"Text: {text}"
        )
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    @staticmethod
    def _parse_response(body: str) -> str:
        parsed = json.loads(body)
        choices = parsed.get("choices")
        if not choices:
            raise APIError(f"API response missing 'choices': {body[:200]}")
        content = choices[0].get("message", {}).get("content")
        if content is None:
            raise APIError(f"API response missing message content: {body[:200]}")
        return content.strip()
