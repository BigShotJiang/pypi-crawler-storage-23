# Contributing to llm-telephone

Thank you for your interest in contributing!

## Development setup

1. **Fork and clone** the repository:

   ```bash
   git clone https://github.com/yymss/llm-telephone.git
   cd llm-telephone
   ```

2. **Create a virtual environment** (recommended):

   ```bash
   python -m venv .venv
   source .venv/bin/activate   # Windows: .venv\Scripts\activate
   ```

3. **Install in editable mode** with dev dependencies:

   ```bash
   pip install -e ".[dev]"
   ```

4. **Run the test suite**:

   ```bash
   pytest
   ```

   Coverage report is printed automatically.

## Project structure

```
src/llm_telephone/
├── __init__.py       ← public API and version
├── exceptions.py     ← custom exception hierarchy
├── languages.py      ← language pool and chain builder
├── api_client.py     ← OpenRouter HTTP client
├── translator.py     ← chain runner with rich progress
└── cli.py            ← click CLI entry point
tests/
├── conftest.py
├── test_api_client.py
├── test_translator.py
└── test_cli.py
```

## Coding conventions

- Python 3.10+ syntax (`X | Y` unions, `match` statements, etc.)
- All public functions should have docstrings
- Keep `stdlib`-only HTTP calls in `api_client.py` (no `httpx`/`requests` dependency)
- Run `pytest` before submitting a PR; coverage must remain ≥ 70%

## Submitting a pull request

1. Create a feature branch: `git checkout -b feat/my-feature`
2. Make your changes and add tests
3. Ensure `pytest` passes
4. Push and open a PR against `main`

Please describe *what* your change does and *why* in the PR description.
