"""Tests for llm_telephone.translator."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from llm_telephone.api_client import OpenRouterClient
from llm_telephone.exceptions import APIError
from llm_telephone.translator import run_chain


def _make_client(translations: list[str]) -> OpenRouterClient:
    """Create a mock client whose translate() returns items from *translations* in order."""
    client = MagicMock(spec=OpenRouterClient)
    client.model = "test/model"
    client.translate.side_effect = translations
    return client


class TestRunChain:
    def test_returns_correct_number_of_records(self):
        translations = ["English", "Japanese", "Final Chinese"]
        client = _make_client(translations)
        records = run_chain("Hello", client, rounds=3, output_format="json")
        assert len(records) == 3

    def test_record_structure(self):
        client = _make_client(["Bonjour", "Hola", "最终"])
        records = run_chain("Hello", client, rounds=3, output_format="json")
        first = records[0]
        assert "round" in first
        assert "target_language" in first
        assert "input" in first
        assert "output" in first
        assert "elapsed_s" in first

    def test_chain_feeds_output_to_next_input(self):
        client = _make_client(["Step1", "Step2", "Step3"])
        records = run_chain("Start", client, rounds=3, output_format="json")
        assert records[0]["input"] == "Start"
        assert records[1]["input"] == "Step1"
        assert records[2]["input"] == "Step2"

    def test_final_output_is_last_translation(self):
        client = _make_client(["A", "B", "Final"])
        records = run_chain("Start", client, rounds=3, output_format="json")
        assert records[-1]["output"] == "Final"

    def test_invalid_rounds_raises(self):
        client = _make_client([])
        with pytest.raises(ValueError, match="rounds must be >= 1"):
            run_chain("Hello", client, rounds=0, output_format="json")

    def test_rounds_exceeds_pool_raises(self):
        client = _make_client([])
        with pytest.raises(ValueError, match="exceeds maximum"):
            run_chain("Hello", client, rounds=100, output_format="json")

    def test_process_output_written(self, tmp_path):
        out_file = tmp_path / "process.txt"
        client = _make_client(["T1", "T2", "T3"])
        run_chain(
            "Hello", client, rounds=3, process_output=str(out_file), output_format="json"
        )
        content = out_file.read_text(encoding="utf-8")
        assert "Initial: Hello" in content
        assert "T1" in content

    def test_final_output_written(self, tmp_path):
        out_file = tmp_path / "final.txt"
        client = _make_client(["T1", "T2", "T3"])
        run_chain(
            "Hello", client, rounds=3, final_output=str(out_file), output_format="json"
        )
        content = out_file.read_text(encoding="utf-8").strip()
        assert content == "T3"

    def test_api_error_propagates(self):
        client = MagicMock(spec=OpenRouterClient)
        client.model = "test/model"
        client.translate.side_effect = APIError("boom")
        with pytest.raises(APIError, match="boom"):
            run_chain("Hello", client, rounds=3, output_format="json")

    def test_text_output_format_does_not_raise(self, capsys):
        client = _make_client(["A", "B", "C"])
        records = run_chain("Hi", client, rounds=3, output_format="text")
        assert len(records) == 3

    def test_return_lang_applied(self):
        client = _make_client(["A", "B", "English result"])
        records = run_chain(
            "Hello", client, rounds=3, return_lang="English", output_format="json"
        )
        assert records[-1]["target_language"] == "English"

    def test_elapsed_s_is_non_negative(self):
        client = _make_client(["A", "B", "C"])
        records = run_chain("Hello", client, rounds=3, output_format="json")
        for r in records:
            assert r["elapsed_s"] >= 0
