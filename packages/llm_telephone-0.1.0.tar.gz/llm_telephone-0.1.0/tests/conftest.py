"""Shared fixtures for llm-telephone tests."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from llm_telephone.api_client import OpenRouterClient


def make_api_response(content: str, model: str = "test/model") -> bytes:
    """Build a minimal OpenRouter-style JSON response bytes."""
    response = {
        "id": "test-id-123",
        "model": model,
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": content,
                }
            }
        ],
    }
    return json.dumps(response).encode("utf-8")


@pytest.fixture
def api_key() -> str:
    return "test-api-key-abc"


@pytest.fixture
def client(api_key: str) -> OpenRouterClient:
    return OpenRouterClient(api_key=api_key, model="test/model", timeout=10)


@pytest.fixture
def mock_urlopen():
    """Patch urllib.request.urlopen to return a single successful response."""
    def _make_mock(content: str):
        mock_resp = MagicMock()
        mock_resp.read.return_value = make_api_response(content)
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("llm_telephone.api_client.urllib.request.urlopen", return_value=mock_resp) as m:
            yield m

    return _make_mock
