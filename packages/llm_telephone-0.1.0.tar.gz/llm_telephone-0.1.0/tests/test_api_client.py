"""Tests for llm_telephone.api_client."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch
import urllib.error

import pytest

from llm_telephone.api_client import OpenRouterClient
from llm_telephone.exceptions import APIError


def _mock_urlopen(content: str):
    """Return a context-manager-compatible mock that yields a response with *content*."""
    body = json.dumps({
        "id": "test-id",
        "choices": [{"message": {"role": "assistant", "content": content}}],
    }).encode("utf-8")
    mock_resp = MagicMock()
    mock_resp.read.return_value = body
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp


class TestOpenRouterClientInit:
    def test_stores_attributes(self, api_key):
        c = OpenRouterClient(api_key=api_key, model="my/model", timeout=30)
        assert c.api_key == api_key
        assert c.model == "my/model"
        assert c.timeout == 30

    def test_default_timeout(self, api_key):
        c = OpenRouterClient(api_key=api_key, model="x")
        assert c.timeout == 60
        assert c.max_retries == 3


class TestTranslate:
    def test_successful_translation(self, client):
        with patch("llm_telephone.api_client.urllib.request.urlopen", return_value=_mock_urlopen("Bonjour")):
            result = client.translate("Hello", "French")
        assert result == "Bonjour"

    def test_strips_whitespace(self, client):
        with patch("llm_telephone.api_client.urllib.request.urlopen", return_value=_mock_urlopen("  Hola  \n")):
            result = client.translate("Hello", "Spanish")
        assert result == "Hola"

    def test_http_error_triggers_retry(self, client):
        """HTTPError on first attempt should retry and succeed on second."""
        good_resp = _mock_urlopen("Ciao")
        http_err = urllib.error.HTTPError(
            url="http://x", code=429, msg="Too Many Requests", hdrs=None, fp=None
        )
        http_err.read = lambda: b"rate limit"

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise http_err
            return good_resp

        with patch("llm_telephone.api_client.urllib.request.urlopen", side_effect=side_effect):
            with patch("llm_telephone.api_client.time.sleep"):  # skip actual sleep
                result = client.translate("Hello", "Italian")

        assert result == "Ciao"
        assert call_count == 2

    def test_all_retries_exhausted_raises_api_error(self, client):
        http_err = urllib.error.HTTPError(
            url="http://x", code=500, msg="Server Error", hdrs=None, fp=None
        )
        http_err.read = lambda: b"internal error"

        with patch("llm_telephone.api_client.urllib.request.urlopen", side_effect=http_err):
            with patch("llm_telephone.api_client.time.sleep"):
                with pytest.raises(APIError, match="OpenRouter request failed"):
                    client.translate("Hello", "German")

    def test_url_error_raises_api_error(self, client):
        url_err = urllib.error.URLError("connection refused")

        with patch("llm_telephone.api_client.urllib.request.urlopen", side_effect=url_err):
            with patch("llm_telephone.api_client.time.sleep"):
                with pytest.raises(APIError, match="URL error"):
                    client.translate("Hello", "Dutch")

    def test_missing_choices_raises_api_error(self, client):
        body = json.dumps({"id": "x", "choices": []}).encode("utf-8")
        mock_resp = MagicMock()
        mock_resp.read.return_value = body
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("llm_telephone.api_client.urllib.request.urlopen", return_value=mock_resp):
            with pytest.raises(APIError, match="missing 'choices'"):
                client.translate("Hello", "Polish")

    def test_invalid_json_raises_api_error(self, client):
        mock_resp = MagicMock()
        mock_resp.read.return_value = b"not json {"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("llm_telephone.api_client.urllib.request.urlopen", return_value=mock_resp):
            with pytest.raises(APIError, match="Unexpected API response format"):
                client.translate("Hello", "Swedish")


class TestBuildMessages:
    def test_contains_target_language(self):
        msgs = OpenRouterClient._build_messages("Hello", "Japanese")
        user_content = msgs[1]["content"]
        assert "Japanese" in user_content
        assert "Hello" in user_content

    def test_has_system_and_user_roles(self):
        msgs = OpenRouterClient._build_messages("x", "y")
        assert msgs[0]["role"] == "system"
        assert msgs[1]["role"] == "user"


class TestParseResponse:
    def test_extracts_content(self):
        body = json.dumps({
            "choices": [{"message": {"content": "Translated!"}}]
        })
        assert OpenRouterClient._parse_response(body) == "Translated!"

    def test_missing_choices_raises(self):
        body = json.dumps({"choices": []})
        with pytest.raises(APIError, match="missing 'choices'"):
            OpenRouterClient._parse_response(body)

    def test_missing_content_raises(self):
        body = json.dumps({"choices": [{"message": {}}]})
        with pytest.raises(APIError, match="missing message content"):
            OpenRouterClient._parse_response(body)
