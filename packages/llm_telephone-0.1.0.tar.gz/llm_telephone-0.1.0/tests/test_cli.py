"""Tests for llm_telephone.cli."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from llm_telephone.cli import main
from llm_telephone.exceptions import APIError


def _run(args: list[str], env: dict | None = None):
    runner = CliRunner()
    env = env or {"OPENROUTER_API_KEY": "test-key"}
    return runner.invoke(main, args, env=env, catch_exceptions=False)


def _patch_run_chain(translations=None):
    """Patch run_chain to return a simple list of record dicts."""
    translations = translations or ["Result"]
    records = [
        {"round": 1, "target_language": "English", "input": "Hello", "output": t, "elapsed_s": 0.1}
        for t in translations
    ]
    return patch("llm_telephone.cli.run_chain", return_value=records)


class TestCLIBasic:
    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "TEXT" in result.output

    def test_version(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_no_args_exits_with_error(self):
        runner = CliRunner()
        result = runner.invoke(main, [], env={"OPENROUTER_API_KEY": "key"})
        assert result.exit_code != 0

    def test_missing_api_key_exits_1(self):
        runner = CliRunner()
        result = runner.invoke(main, ["Hello"], env={})
        assert result.exit_code == 1


class TestCLIText:
    def test_text_argument(self):
        with _patch_run_chain():
            result = _run(["Hello world", "--rounds", "3"])
        assert result.exit_code == 0

    def test_rounds_passed_correctly(self):
        with _patch_run_chain() as mock_run:
            _run(["Hi", "--rounds", "5"])
        _, kwargs = mock_run.call_args
        assert kwargs.get("rounds") == 5 or mock_run.call_args[0][2] == 5

    def test_model_passed_correctly(self):
        with _patch_run_chain() as mock_run:
            _run(["Hi", "--model", "custom/model"])
        # The model is set on the client, not run_chain — check via client arg
        call_args = mock_run.call_args
        client_arg = call_args[0][1] if len(call_args[0]) > 1 else call_args[1].get("client")
        assert client_arg.model == "custom/model"


class TestCLITextFile:
    def test_text_file_option(self, tmp_path):
        f = tmp_path / "input.txt"
        f.write_text("My test text", encoding="utf-8")
        with _patch_run_chain():
            result = _run(["--text-file", str(f), "--rounds", "2"])
        assert result.exit_code == 0

    def test_both_text_and_file_errors(self, tmp_path):
        f = tmp_path / "input.txt"
        f.write_text("text", encoding="utf-8")
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["Hello", "--text-file", str(f)],
            env={"OPENROUTER_API_KEY": "key"},
        )
        assert result.exit_code != 0

    def test_empty_file_errors(self, tmp_path):
        f = tmp_path / "empty.txt"
        f.write_text("   ", encoding="utf-8")
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["--text-file", str(f)],
            env={"OPENROUTER_API_KEY": "key"},
        )
        assert result.exit_code != 0


class TestCLIOutputFormat:
    def test_json_format_accepted(self):
        with _patch_run_chain():
            result = _run(["Hello", "--rounds", "2", "--output-format", "json"])
        assert result.exit_code == 0

    def test_invalid_format_rejected(self):
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["Hello", "--output-format", "xml"],
            env={"OPENROUTER_API_KEY": "key"},
        )
        assert result.exit_code != 0


class TestCLIReturnLang:
    def test_valid_return_lang(self):
        with _patch_run_chain():
            result = _run(["Hello", "--rounds", "3", "--return-lang", "English"])
        assert result.exit_code == 0

    def test_invalid_return_lang_exits(self):
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["Hello", "--return-lang", "Klingon"],
            env={"OPENROUTER_API_KEY": "key"},
        )
        assert result.exit_code != 0


class TestCLIOutputFiles:
    def test_process_output_arg(self, tmp_path):
        out = tmp_path / "proc.txt"
        with _patch_run_chain():
            result = _run(["Hello", "--rounds", "2", "--process-output", str(out)])
        assert result.exit_code == 0

    def test_final_output_arg(self, tmp_path):
        out = tmp_path / "final.txt"
        with _patch_run_chain():
            result = _run(["Hello", "--rounds", "2", "--final-output", str(out)])
        assert result.exit_code == 0


class TestCLIErrorHandling:
    def test_api_error_exits_2(self):
        with patch("llm_telephone.cli.run_chain", side_effect=APIError("boom")):
            runner = CliRunner()
            result = runner.invoke(
                main,
                ["Hello", "--rounds", "3"],
                env={"OPENROUTER_API_KEY": "key"},
                catch_exceptions=False,
            )
        assert result.exit_code == 2

    def test_value_error_exits_2(self):
        with patch("llm_telephone.cli.run_chain", side_effect=ValueError("bad rounds")):
            runner = CliRunner()
            result = runner.invoke(
                main,
                ["Hello", "--rounds", "3"],
                env={"OPENROUTER_API_KEY": "key"},
                catch_exceptions=False,
            )
        assert result.exit_code == 2
