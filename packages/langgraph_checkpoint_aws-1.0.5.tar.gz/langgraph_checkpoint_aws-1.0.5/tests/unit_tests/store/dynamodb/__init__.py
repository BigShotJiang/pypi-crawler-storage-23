"""Test module initialization."""
