#!/bin/bash
# Pre-push hook: Run pytest

echo "🧪 Running tests..."

cd "$(dirname "$0")/.." && uv run pytest

if [ $? -ne 0 ]; then
    echo "❌ Tests failed! Push aborted."
    exit 1
fi

echo "✅ Tests passed!"
