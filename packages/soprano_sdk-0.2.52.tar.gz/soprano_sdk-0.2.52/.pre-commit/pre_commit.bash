#!/bin/bash
# Pre-commit hook: Run ruff linting

echo "🔍 Running ruff lint..."

cd "$(dirname "$0")/.." && uv run ruff check .

if [ $? -ne 0 ]; then
    echo "❌ Linting failed!"
    exit 1
fi

echo "✅ Linting passed!"
