import json
from unittest.mock import MagicMock
from jinja2 import Environment
from soprano_sdk.nodes.collect_input import (
    CollectInputStrategy,
    _extract_conversational_text,
    _build_workflow_context_summary,
)
from soprano_sdk.core.constants import WorkflowKeys


class TestExtractConversationalText:
    def test_json_message_returns_text(self):
        content = json.dumps({"text": "What is your order ID?", "options": [], "is_selectable": False})
        assert _extract_conversational_text(content) == "What is your order ID?"

    def test_plain_text_returns_none(self):
        assert _extract_conversational_text("ORDER_ID_CAPTURED: ORD-12345") is None

    def test_json_without_text_key_returns_none(self):
        content = json.dumps({"options": ["a", "b"]})
        assert _extract_conversational_text(content) is None

    def test_empty_string_returns_none(self):
        assert _extract_conversational_text("") is None

    def test_json_with_empty_text_returns_empty_string(self):
        content = json.dumps({"text": "", "options": []})
        assert _extract_conversational_text(content) == ""

    def test_json_strips_options_metadata(self):
        content = json.dumps({
            "text": "Pick one:",
            "options": ["A", "B", "C"],
            "is_selectable": True
        })
        assert _extract_conversational_text(content) == "Pick one:"


class TestBuildWorkflowContextSummary:
    def test_empty_execution_order_returns_empty(self):
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: [],
            WorkflowKeys.NODE_FIELD_MAP: {},
            WorkflowKeys.CONVERSATIONS: {},
        }
        assert _build_workflow_context_summary(state) == ""

    def test_missing_keys_returns_empty(self):
        assert _build_workflow_context_summary({}) == ""

    def test_single_node_with_conversation(self):
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {
                "order_id_conversation": [
                    {"role": "assistant", "content": json.dumps({"text": "What is your order ID?", "options": [], "is_selectable": False})},
                    {"role": "user", "content": "ORD-12345"},
                    {"role": "assistant", "content": "ORDER_ID_CAPTURED: ORD-12345"},
                ]
            },
            "order_id": "ORD-12345",
        }
        result = _build_workflow_context_summary(state)
        assert "<workflow_state>" in result
        assert "</workflow_state>" in result
        assert "Order Id: ORD-12345" in result
        assert "Agent: What is your order ID?" in result
        assert "User: ORD-12345" in result
        # Extraction pattern must NOT appear
        assert "ORDER_ID_CAPTURED" not in result

    def test_multi_field_node(self):
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_names"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_names": ["first_name", "last_name"]},
            WorkflowKeys.CONVERSATIONS: {
                "first_name_conversation": [
                    {"role": "assistant", "content": json.dumps({"text": "What is your full name?", "options": [], "is_selectable": False})},
                    {"role": "user", "content": "John Doe"},
                ]
            },
            "first_name": "John",
            "last_name": "Doe",
        }
        result = _build_workflow_context_summary(state)
        assert "First Name: John" in result
        assert "Last Name: Doe" in result
        assert "Agent: What is your full name?" in result
        assert "User: John Doe" in result

    def test_multiple_nodes_in_order(self):
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id", "collect_reason"],
            WorkflowKeys.NODE_FIELD_MAP: {
                "collect_order_id": "order_id",
                "collect_reason": "return_reason",
            },
            WorkflowKeys.CONVERSATIONS: {
                "order_id_conversation": [
                    {"role": "assistant", "content": json.dumps({"text": "What is your order ID?"})},
                    {"role": "user", "content": "ORD-123"},
                ],
                "return_reason_conversation": [
                    {"role": "assistant", "content": json.dumps({"text": "Why are you returning?"})},
                    {"role": "user", "content": "Defective"},
                ],
            },
            "order_id": "ORD-123",
            "return_reason": "Defective",
        }
        result = _build_workflow_context_summary(state)
        assert "Collect Order Id" in result
        assert "Collect Reason" in result
        # Execution order preserved
        assert result.index("Collect Order Id") < result.index("Collect Reason")

    def test_call_function_node_skipped(self):
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id", "check_eligibility"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {
                "order_id_conversation": [
                    {"role": "user", "content": "ORD-123"},
                ],
            },
            "order_id": "ORD-123",
        }
        result = _build_workflow_context_summary(state)
        assert "Check Eligibility" not in result
        assert "Collect Order Id" in result

    def test_node_with_no_conversation(self):
        """Pre-populated field still shows collected values."""
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {},
            "order_id": "ORD-123",
        }
        result = _build_workflow_context_summary(state)
        assert "Order Id: ORD-123" in result

    def test_node_with_none_value_excluded(self):
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {},
            "order_id": None,
        }
        result = _build_workflow_context_summary(state)
        assert "Order Id:" not in result

    def test_extraction_patterns_excluded(self):
        """Plain-text assistant messages (extraction patterns) must not appear."""
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {
                "order_id_conversation": [
                    {"role": "assistant", "content": json.dumps({"text": "Please provide your order ID."})},
                    {"role": "user", "content": "ORD-999"},
                    {"role": "assistant", "content": "ORDER_ID_CAPTURED: ORD-999"},
                    {"role": "assistant", "content": "INTENT_CHANGE: collect_reason"},
                ]
            },
            "order_id": "ORD-999",
        }
        result = _build_workflow_context_summary(state)
        assert "ORDER_ID_CAPTURED" not in result
        assert "INTENT_CHANGE" not in result
        assert "Agent: Please provide your order ID." in result
        assert "User: ORD-999" in result

    def test_node_with_only_extraction_pattern_no_conversation_section(self):
        """If only user messages and extraction patterns, conversation only shows user."""
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {
                "order_id_conversation": [
                    {"role": "user", "content": "ORD-123"},
                    {"role": "assistant", "content": "ORDER_ID_CAPTURED: ORD-123"},
                ]
            },
            "order_id": "ORD-123",
        }
        result = _build_workflow_context_summary(state)
        assert "User: ORD-123" in result
        assert "ORDER_ID_CAPTURED" not in result

    def test_collected_data_before_conversation_history(self):
        """COLLECTED DATA section should appear before CONVERSATION HISTORY."""
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {
                "order_id_conversation": [
                    {"role": "assistant", "content": json.dumps({"text": "What is your order ID?"})},
                    {"role": "user", "content": "ORD-123"},
                ]
            },
            "order_id": "ORD-123",
        }
        result = _build_workflow_context_summary(state)
        assert result.index("COLLECTED DATA:") < result.index("CONVERSATION HISTORY:")


class TestGetInstructionsWithWorkflowContext:
    def _create_strategy(self, **agent_overrides):
        agent_config = {"name": "test_agent", "instructions": "Collect the return reason."}
        agent_config.update(agent_overrides)
        step_config = {
            "id": "collect_reason",
            "field": "return_reason",
            "agent": agent_config,
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment(),
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.get_localization_instructions.return_value = None
        engine_context.workflow_description = "Test workflow"
        return CollectInputStrategy(step_config, engine_context)

    def test_context_appended_when_prior_nodes_exist(self):
        strategy = self._create_strategy()
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {
                "order_id_conversation": [
                    {"role": "user", "content": "ORD-123"},
                ]
            },
            "order_id": "ORD-123",
        }
        instructions = strategy._get_instructions(state, {})
        assert "<workflow_state>" in instructions
        assert "<auto_extraction_rule>" in instructions
        assert "Collect the return reason." in instructions

    def test_no_context_for_first_node(self):
        strategy = self._create_strategy()
        state = {}
        instructions = strategy._get_instructions(state, {})
        assert "<workflow_state>" not in instructions
        assert "<auto_extraction_rule>" not in instructions
        assert "Collect the return reason." in instructions

    def test_context_appears_before_intent_detection(self):
        strategy = self._create_strategy()
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {},
            "order_id": "ORD-123",
        }
        collector_nodes = {"collect_order_id": "Collect order ID"}
        instructions = strategy._get_instructions(state, collector_nodes)
        assert instructions.index("<workflow_state>") < instructions.index("<intent_detection>")

    def test_context_appears_before_out_of_scope(self):
        strategy = self._create_strategy(detect_out_of_scope=True)
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {},
            "order_id": "ORD-123",
        }
        instructions = strategy._get_instructions(state, {})
        assert instructions.index("<workflow_state>") < instructions.index("<out_of_scope_detection>")

    def test_auto_extraction_rule_contains_current_fields(self):
        strategy = self._create_strategy()
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: ["collect_order_id"],
            WorkflowKeys.NODE_FIELD_MAP: {"collect_order_id": "order_id"},
            WorkflowKeys.CONVERSATIONS: {},
            "order_id": "ORD-123",
        }
        instructions = strategy._get_instructions(state, {})
        assert "Return Reason" in instructions
        assert "You are currently collecting: Return Reason" in instructions
