"""
Helper functions for MFA workflow testing.
These simulate payment processing operations.
"""
import random
from typing import Dict, Any


def validate_customer_id(customer_id: str, **state) -> tuple[bool, str]:
    """
    Validate customer ID format.

    Valid format: CUST followed by 6 digits (e.g., CUST123456)
    """
    if not customer_id:
        return False, "Customer ID cannot be empty"

    if not customer_id.startswith("CUST"):
        return False, "Customer ID must start with 'CUST'"

    if len(customer_id) != 10:
        return False, "Customer ID must be 10 characters (CUST + 6 digits)"

    try:
        int(customer_id[4:])
    except ValueError:
        return False, "Last 6 characters must be digits"

    return True, None


def validate_payment_amount(payment_amount: int, **state) -> tuple[bool, str]:
    """
    Validate payment amount.

    Valid range: 100 to 50000
    """
    if not payment_amount:
        return False, "Payment amount cannot be empty"

    try:
        amount = int(payment_amount)
    except (ValueError, TypeError):
        return False, "Payment amount must be a number"

    if amount < 100:
        return False, "Payment amount must be at least ₹100"

    if amount > 50000:
        return False, "Payment amount cannot exceed ₹50,000"

    return True, None


def process_payment(state: Dict[str, Any]) -> bool:
    """
    Process the payment transaction.

    Simulates payment processing with random success/failure.
    In production, this would call actual payment gateway.
    """
    customer_id = state.get('customer_id')
    payment_amount = state.get('payment_amount')

    print("\n[Payment Processing]")
    print(f"Customer ID: {customer_id}")
    print(f"Amount: ₹{payment_amount}")
    print("Processing transaction...")

    # Simulate payment processing (90% success rate)
    success = random.random() > 0.1

    if success:
        print("✓ Payment successful!")
        return True
    else:
        print("✗ Payment failed - insufficient funds or network error")
        return False


def generate_payment_confirmation(state: Dict[str, Any]) -> str:
    """
    Generate payment confirmation message.
    """
    customer_id = state.get('customer_id')
    payment_amount = state.get('payment_amount')

    # Generate random transaction ID
    txn_id = f"TXN{random.randint(100000, 999999)}"

    return f"""
🎉 Payment Successful!

Transaction ID: {txn_id}
Customer ID: {customer_id}
Amount: ₹{payment_amount}

Thank you for your payment!
Your transaction has been processed successfully.
A confirmation has been sent to your registered email.
"""
