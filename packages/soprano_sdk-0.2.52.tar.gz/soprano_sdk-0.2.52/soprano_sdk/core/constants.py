from enum import Enum
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class WorkflowKeys:
    STEP_ID = '_step_id'
    STATUS = '_status'
    OUTCOME_ID = '_outcome_id'
    MESSAGES = '_messages'
    CONVERSATIONS = '_conversations'
    STATE_HISTORY = '_state_history'
    COLLECTOR_NODES = '_collector_nodes'
    ATTEMPT_COUNTS = '_attempt_counts'
    NODE_EXECUTION_ORDER = '_node_execution_order'
    NODE_FIELD_MAP = '_node_field_map'
    COMPUTED_FIELDS = '_computed_fields'
    VALIDATION_ERRORS = '_validation_errors'
    PARTIAL_DATA = '_partial_data'
    ERROR = 'error'
    TARGET_LANGUAGE = '_target_language'
    TARGET_SCRIPT = '_target_script'
    RUNTIME_CONSTRAINTS = '_runtime_constraints'
    ASYNC_PENDING = '_async_pending'
    PENDING_PROMPT = '_pending_prompt'
    USER_MESSAGE = '_user_message'


# Framework metadata fields that should be excluded from data field processing
COLLECT_INPUT_METADATA_FIELDS = frozenset([
    'bot_response',
    'options',
    'is_selectable',
    'intent_change',
    'out_of_scope'
])


class ActionType(Enum):
    COLLECT_INPUT_WITH_AGENT = 'collect_input_with_agent'
    CALL_FUNCTION = 'call_function'
    CALL_ASYNC_FUNCTION = 'call_async_function'
    FOLLOW_UP = 'follow_up'
    MFA = 'mfa'


class InterruptType:
    """Interrupt type markers for workflow pauses"""
    USER_INPUT = '__WORKFLOW_INTERRUPT__'
    ASYNC = '__ASYNC_INTERRUPT__'
    OUT_OF_SCOPE = '__OUT_OF_SCOPE_INTERRUPT__'


class OutcomePrefix:
    """Outcome type markers for workflow completion"""
    REDIRECT = '__REDIRECT__'


class DataType(Enum):
    TEXT = 'text'
    NUMBER = 'number'
    DOUBLE = 'double'
    BOOLEAN = 'boolean'
    LIST = 'list'
    DICT = 'dict'
    ANY = "any"


class OutcomeType(Enum):
    SUCCESS = 'success'
    FAILURE = 'failure'
    REDIRECT = 'redirect'


class StatusPattern:
    COLLECTING = '{step_id}_collecting'
    MAX_ATTEMPTS = '{step_id}_max_attempts'
    NEXT_STEP = '{step_id}_{next_step}'
    SUCCESS = '{step_id}_success'
    FAILED = '{step_id}_failed'
    INTENT_CHANGE = '{step_id}_{target_node}'


class TransitionPattern:
    CAPTURED = '{field}_CAPTURED:'
    FAILED = '{field}_FAILED:'
    INTENT_CHANGE = 'INTENT_CHANGE:'


class ResponseMarkers:
    OPTIONS_DATA = 'OPTIONS_DATA:'


DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_MODEL = 'gpt-4o-mini'
DEFAULT_TIMEOUT = 300

MAX_ATTEMPTS_MESSAGE = "I'm having trouble understanding your {field}. Please contact customer service for assistance."
WORKFLOW_COMPLETE_MESSAGE = "Workflow completed."

# Humanization defaults
DEFAULT_HUMANIZATION_ENABLED = False
DEFAULT_HUMANIZATION_SYSTEM_PROMPT = """You transform template-based messages into natural, conversational responses.

Rules:
1. Rewrite the reference message naturally while maintaining ALL factual information
2. Preserve URLs, links, phone numbers, and formatted data EXACTLY as provided
3. Use conversation history for context and tone matching. If the customer is frustrated or angry, be empathetic and apologetic. If the customer is casual, be friendly and relaxed. If there were previous errors or failed attempts, acknowledge them with extra reassurance. When no conversation history is provided, default to a warm, professional tone.
4. Be warm, professional, and helpful
5. Keep responses concise but complete

CRITICAL: Return ONLY the humanized message itself. Do NOT include:
- Preambles like "Here's..." or "Sure, here's..."
- Explanations of what you did
- Meta-commentary about the transformation
- Phrases like "more condensed version" or "rewritten message"
- Placeholders like "[insert X]", "[placeholder]", or "[your message here]"

Just provide the actual humanized message and nothing else. All content must be final, not placeholders."""

def build_option_guidelines() -> str:
    """Build option formatting guidelines for LLM structured output instructions."""
    return """
    OPTION POPULATION GUIDELINES:

    First, determine how many distinct questions that expect a user response are present in the message.
    Then apply the matching rule:

    1. SINGLE QUESTION present:
        - Always put ALL options in the options field, never in the message text.
        - Do NOT list, number, or repeat the options in the message text. The UI renders options separately as buttons/list items. Your message should only contain the question or prompt, not the choices.
        - Do NOT generate or invent options from your own knowledge. Only use options that are explicitly provided in your context or in the message.
        - If options are provided: preserve them exactly in your options field. Do NOT add, remove, or modify any provided options.
        Each option is a dict with two keys:
            - "text": the primary display text shown as the button label or list item heading
            - "subtext": optional secondary text shown below "text" (e.g., price, availability, description, URL). Use "" when there is no meaningful additional context to add.
        - Unique identifiers should be included in the 'text' field, not 'subtext', to ensure they are preserved in the UI. Additional details can go in 'subtext'.
        - Leave subtext as '' when the label is self-explanatory (e.g. yes/no).
        - For URLs or clickable items, use text as the label and subtext as the URL, then set is_selectable to false.
        - URLs in text or subtext fields MUST be preserved verbatim. Do NOT shorten, expand, rewrite, or replace any URL.
        - Set is_selectable to true if the user must select from the provided options, false otherwise.

    2. MULTIPLE QUESTIONS present:
        - options: []
        - is_selectable: false
        - Include all questions directly in the message text, preserving their original wording.
        - Do NOT extract, transform, or infer any options from the questions.
        - Do NOT treat questions as selectable options.
        - Do NOT restructure questions into selectable items.
"""


def build_humanization_options_guidance() -> str:
    """Build OPTIONS HANDLING guidance for the humanization LLM."""
    guidelines = build_option_guidelines()
    return f"""
OPTIONS HANDLING:

The UI renders options separately as buttons/list items.
CRITICAL: Do NOT generate or invent options from your own knowledge. Only use options that are present in the reference message.

{guidelines}
    Examples:
    Single question (options extracted, NOT listed in message text):
    - "Would you like to proceed?" → options: [{{"text": "Yes", "subtext": ""}}, {{"text": "No", "subtext": ""}}], is_selectable: true
    - "Contact us via our Help Center or Support portal" → options: [{{"text": "Help Center", "subtext": "https://example.com/help"}}, {{"text": "Support Portal", "subtext": "https://example.com/support"}}], is_selectable: false
    - "What is your name?" → options: [], is_selectable: false

    Multiple questions (no options, questions stay in message text):
    - "What is your order ID? And what is the reason for the return?" → options: [], is_selectable: false
"""


OPTION_SELECTION_GUIDELINES = build_option_guidelines()
HUMANIZATION_OPTIONS_GUIDANCE = build_humanization_options_guidance()


class HumanizationKeys:
    """Keys for humanization agent configuration"""
    ENABLED = 'enabled'
    MODEL = 'model'
    BASE_URL = 'base_url'
    INSTRUCTIONS = 'instructions'


# Localization defaults
DEFAULT_LOCALIZATION_INSTRUCTIONS = """LANGUAGE REQUIREMENT:
You MUST respond in {language} using {script} script.
- All your responses must be in {language}
- Use the {script} writing system
- Maintain the same meaning and tone as you would in English
- Do not mix languages unless quoting the user
"""


class LocalizationKeys:
    """Keys for localization configuration"""
    LANGUAGE = 'language'
    SCRIPT = 'script'
    INSTRUCTIONS = 'instructions'


class MFAConfig(BaseSettings):
    """
    Configuration for MFA REST API endpoints.

    Values can be provided during initialization or will be automatically
    loaded from environment variables with the same name (uppercase).

    Example:
        # Load from environment variables
        config = MFAConfig()

        # Or provide specific values
        config = MFAConfig(
            generate_token_base_url="https://api.example.com",
            generate_token_path="/v1/mfa/generate"
        )
    """
    generate_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the generate token endpoint"
    )
    generate_token_path: Optional[str] = Field(
        default=None,
        description="Path for the generate token endpoint"
    )
    validate_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the validate token endpoint"
    )
    validate_token_path: Optional[str] = Field(
        default=None,
        description="Path for the validate token endpoint"
    )
    authorize_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the authorize token endpoint"
    )
    authorize_token_path: Optional[str] = Field(
        default=None,
        description="Path for the authorize token endpoint"
    )
    resend_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the resend token endpoint"
    )
    resend_token_path: Optional[str] = Field(
        default=None,
        description="Path for the resend token endpoint"
    )
    api_timeout: int = Field(
        default=30,
        description="API request timeout in seconds"
    )
    initial_message: Optional[str] = Field(
        default=None,
        description="Initial message to display when MFA authentication is required"
    )
    mfa_validation_error_message: str = Field(
        default="Invalid OTP entered",
        description="Message to display when MFA validation fails"
    )
    max_attempts_message: str = Field(
        default="Maximum authentication attempts reached. Please try again later.",
        description="Message to display when max MFA attempts are reached"
    )

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra='ignore'
    )
