"""Basic unit tests for MoMaHub registry (no network required)."""

import pytest

from momahub import MoMaHub, NodeInfo, InferenceRequest, NodeStatus


@pytest.fixture
def hub() -> MoMaHub:
    return MoMaHub()


@pytest.fixture
def node() -> NodeInfo:
    return NodeInfo(
        node_id="test-gpu-0",
        url="http://localhost:11434",
        gpu_model="GTX 1080 Ti",
        vram_gb=11.0,
        models=["qwen2.5:7b", "mistral:7b"],
    )


def test_register_and_list(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    nodes = hub.list_nodes()
    assert len(nodes) == 1
    assert nodes[0].node_id == "test-gpu-0"


def test_deregister(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    removed = hub.deregister("test-gpu-0")
    assert removed is True
    assert hub.list_nodes() == []


def test_deregister_missing(hub: MoMaHub) -> None:
    assert hub.deregister("nonexistent") is False


def test_heartbeat(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    node.status = NodeStatus.OFFLINE
    hub._nodes["test-gpu-0"] = node
    ok = hub.heartbeat("test-gpu-0")
    assert ok is True
    assert hub.get_node("test-gpu-0").status == NodeStatus.ONLINE


def test_stats_empty(hub: MoMaHub) -> None:
    stats = hub.stats()
    assert stats.total_nodes == 0
    assert stats.online_nodes == 0


def test_stats_with_nodes(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    stats = hub.stats()
    assert stats.total_nodes == 1
    assert stats.online_nodes == 1
    assert set(stats.unique_models) == {"qwen2.5:7b", "mistral:7b"}


def test_filter_by_status(hub: MoMaHub, node: NodeInfo) -> None:
    hub.register(node)
    offline = NodeInfo(node_id="offline-gpu", url="http://localhost:11435",
                       status=NodeStatus.OFFLINE)
    hub.register(offline)
    assert len(hub.list_nodes(status=NodeStatus.ONLINE)) == 1
    assert len(hub.list_nodes(status=NodeStatus.OFFLINE)) == 1
