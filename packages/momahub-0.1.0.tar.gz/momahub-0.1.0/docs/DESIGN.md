# MoMa Hub — Design Document

## Vision

**MoMa = Mixture of Models on Ollama.**

The same way SETI@home donated idle CPU cycles to astronomy, Airbnb
unlocked spare bedrooms, and Uber turned idle cars into a fleet —
MoMa Hub turns idle consumer GPUs into a federated AI inference network.

A GTX 1080 Ti (11 GB VRAM, ~$150 used) can serve 7B-parameter models
at real-time speed. There are millions of such cards sitting idle in
gaming PCs worldwide. MoMa Hub organises them.

---

## Core Analogy

| Inspiration | Resource shared | Platform |
|-------------|----------------|---------|
| SETI@home   | CPU cycles       | Distributed science |
| Airbnb      | Spare bedrooms   | Short-term rental |
| Uber        | Idle cars + time | Ride-sharing |
| Docker Hub  | Container images | Runtime sharing |
| GitHub      | Source code      | Software sharing |
| **MoMa Hub** | **GPU inference** | **AI sharing** |

---

## Architecture (MVP v0.1)

```
Consumer GPU Node
┌─────────────────┐
│  Ollama serve   │  ← pulls + serves models locally
│  (GTX 1080 Ti)  │
└────────┬────────┘
         │  REST /api/generate
         ▼
┌─────────────────┐
│   MoMa Hub      │  ← registry + router (FastAPI)
│   Registry      │     • register / heartbeat / deregister
│   + Router      │     • round-robin routing (MVP)
└────────┬────────┘     • capability-aware routing (v0.2)
         │
         ▼
┌─────────────────┐
│   Client        │  momahub infer --model qwen2.5:7b --prompt "..."
│   (CLI / SDK)   │  OR: from momahub import MoMaHub
└─────────────────┘
```

### Two-tier contribution model (mirroring Docker Hub + GitHub)

| Tier | Contribution | Tool |
|------|-------------|------|
| **Runtime** | Run an Ollama node; register with hub | `momahub register` |
| **Software** | Publish SPL scripts; share prompt recipes | SPL Hub (v0.2) |

---

## Roadmap

### v0.1 — Local MVP (current)
- [x] `MoMaHub` class: register / route / heartbeat
- [x] FastAPI server (`momahub serve`)
- [x] CLI: `register`, `nodes`, `stats`, `infer`
- [x] Round-robin routing
- [x] `pip install momahub`

### v0.2 — Home cluster
- [ ] SQLite-persistent registry (survives server restart)
- [ ] Capability-aware routing (VRAM-based model selection)
- [ ] Heartbeat daemon (auto-deregister stale nodes)
- [ ] Load balancing (queue depth, latency history)
- [ ] `momahub node daemon` — background process with auto-heartbeat

### v0.3 — LAN federation
- [ ] mDNS/DNS-SD node discovery (zero-config LAN)
- [ ] SPL integration (`USING HUB momahub://...` in SPL scripts)
- [ ] Simple web dashboard

### v0.4 — Internet federation
- [ ] Auth + API keys
- [ ] Encrypted tunnels (Tailscale / WireGuard)
- [ ] Public MoMa Hub registry (hub.momahub.ai)
- [ ] Contribution score + leaderboard

---

## Hardware Reference

| GPU | VRAM | 7B model | 13B model | 70B model |
|-----|------|----------|-----------|-----------|
| GTX 1080 Ti | 11 GB | ✅ | ❌ | ❌ |
| RTX 3090    | 24 GB | ✅ | ✅ | ❌ |
| RTX 4090    | 24 GB | ✅ | ✅ | ❌ |
| A100 40 GB  | 40 GB | ✅ | ✅ | ~half |
| 2× A100 80 GB | 160 GB | ✅ | ✅ | ✅ |

Target MVP hardware: GTX 1080 Ti — widely available (~$150 used),
11 GB VRAM sufficient for all 7B models (qwen2.5:7b, mistral:7b,
llama3.1:8b, deepseek-r1:7b, etc.).

---

## Anti-Monopoly Rationale

Top-tier model providers (OpenAI, Anthropic, Google) charge $15–60 / 1M
output tokens. A 7B model on a home GTX 1080 Ti costs ~$0 marginal
(electricity only). MoMa Hub makes the economics of open-source local
inference accessible to anyone with a gaming GPU — lowering the barrier
to democratic AI participation and preventing AI capability monopoly.
