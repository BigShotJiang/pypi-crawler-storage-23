"""Example: 4-GPU local cluster on GTX 1080 Ti cards.

Assumes 4 Ollama instances running on ports 11434-11437.
Start them with:
    OLLAMA_HOST=0.0.0.0:11434 ollama serve &
    OLLAMA_HOST=0.0.0.0:11435 ollama serve &
    OLLAMA_HOST=0.0.0.0:11436 ollama serve &
    OLLAMA_HOST=0.0.0.0:11437 ollama serve &

Then pull a model on each:
    for port in 11434 11435 11436 11437; do
        OLLAMA_HOST=localhost:$port ollama pull qwen2.5:7b
    done
"""

import asyncio
import sys

sys.path.insert(0, "../../src")

from momahub import MoMaHub, NodeInfo, InferenceRequest


async def main() -> None:
    hub = MoMaHub()

    # Register 4 local GTX 1080 Ti nodes
    for i, port in enumerate([11434, 11435, 11436, 11437]):
        hub.register(NodeInfo(
            node_id=f"home-gpu-{i}",
            url=f"http://localhost:{port}",
            gpu_model="GTX 1080 Ti",
            vram_gb=11.0,
            models=["qwen2.5:7b"],
        ))

    print(f"Hub stats: {hub.stats()}")

    # Send 4 parallel requests — each goes to a different GPU
    prompts = [
        "Explain self-attention in one sentence.",
        "What is the key innovation of the Transformer?",
        "Why is positional encoding needed?",
        "What is multi-head attention?",
    ]

    requests = [InferenceRequest(model="qwen2.5:7b", prompt=p) for p in prompts]
    results = await asyncio.gather(*[hub.infer(r) for r in requests])

    for req, resp in zip(requests, results):
        print(f"\nQ: {req.prompt}")
        if resp.error:
            print(f"  ERROR: {resp.error}")
        else:
            print(f"  A [{resp.node_id}, {resp.latency_ms:.0f}ms]: {resp.content[:200]}")


if __name__ == "__main__":
    asyncio.run(main())
