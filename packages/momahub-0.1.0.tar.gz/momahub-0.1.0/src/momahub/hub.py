"""MoMa Hub — in-memory node registry + round-robin router (MVP)."""

from __future__ import annotations

import time
from datetime import datetime
from typing import Optional

import httpx

from .models import (
    HubStats,
    InferenceRequest,
    InferenceResponse,
    NodeInfo,
    NodeStatus,
)


class MoMaHub:
    """Central registry and router for Ollama inference nodes.

    MVP implementation: in-memory registry, round-robin routing.
    Future: persistent SQLite registry, capability-aware routing, SPL integration.
    """

    def __init__(self) -> None:
        self._nodes: dict[str, NodeInfo] = {}
        self._rr_index: int = 0             # round-robin cursor

    # ------------------------------------------------------------------
    # Registry operations
    # ------------------------------------------------------------------

    def register(self, node: NodeInfo) -> NodeInfo:
        """Register (or update) an inference node."""
        node.registered_at = node.registered_at or datetime.utcnow()
        node.last_seen = datetime.utcnow()
        self._nodes[node.node_id] = node
        return node

    def deregister(self, node_id: str) -> bool:
        if node_id in self._nodes:
            del self._nodes[node_id]
            return True
        return False

    def get_node(self, node_id: str) -> Optional[NodeInfo]:
        return self._nodes.get(node_id)

    def list_nodes(self, status: Optional[NodeStatus] = None) -> list[NodeInfo]:
        nodes = list(self._nodes.values())
        if status is not None:
            nodes = [n for n in nodes if n.status == status]
        return nodes

    def heartbeat(self, node_id: str) -> bool:
        """Update last_seen for a node; mark online if previously offline."""
        node = self._nodes.get(node_id)
        if node is None:
            return False
        node.last_seen = datetime.utcnow()
        node.status = NodeStatus.ONLINE
        return True

    # ------------------------------------------------------------------
    # Routing
    # ------------------------------------------------------------------

    def _pick_node(self, model: str) -> Optional[NodeInfo]:
        """Round-robin over online nodes that have the requested model."""
        candidates = [
            n for n in self._nodes.values()
            if n.status == NodeStatus.ONLINE and model in n.models
        ]
        if not candidates:
            # fall back: any online node (node will pull the model on demand)
            candidates = [n for n in self._nodes.values() if n.status == NodeStatus.ONLINE]
        if not candidates:
            return None
        node = candidates[self._rr_index % len(candidates)]
        self._rr_index += 1
        return node

    async def infer(self, request: InferenceRequest) -> InferenceResponse:
        """Route an inference request to the best available node."""
        node = self._pick_node(request.model)
        if node is None:
            return InferenceResponse(
                node_id="none",
                model=request.model,
                content="",
                error="No online nodes available for model: " + request.model,
            )

        node.status = NodeStatus.BUSY
        t0 = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                payload = {
                    "model": request.model,
                    "prompt": request.prompt,
                    "stream": False,
                    "options": {
                        "temperature": request.temperature,
                        "num_predict": request.max_tokens,
                    },
                }
                if request.system:
                    payload["system"] = request.system

                resp = await client.post(f"{node.url}/api/generate", json=payload)
                resp.raise_for_status()
                data = resp.json()

            latency_ms = (time.monotonic() - t0) * 1000
            return InferenceResponse(
                node_id=node.node_id,
                model=request.model,
                content=data.get("response", ""),
                input_tokens=data.get("prompt_eval_count", 0),
                output_tokens=data.get("eval_count", 0),
                latency_ms=latency_ms,
            )
        except Exception as exc:
            return InferenceResponse(
                node_id=node.node_id,
                model=request.model,
                content="",
                error=str(exc),
            )
        finally:
            node.status = NodeStatus.ONLINE
            node.last_seen = datetime.utcnow()

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> HubStats:
        nodes = list(self._nodes.values())
        all_models: list[str] = []
        for n in nodes:
            all_models.extend(n.models)
        return HubStats(
            total_nodes=len(nodes),
            online_nodes=sum(1 for n in nodes if n.status == NodeStatus.ONLINE),
            total_models=len(all_models),
            unique_models=sorted(set(all_models)),
        )


# Module-level singleton for simple single-process use
_default_hub: Optional[MoMaHub] = None


def get_hub() -> MoMaHub:
    global _default_hub
    if _default_hub is None:
        _default_hub = MoMaHub()
    return _default_hub
