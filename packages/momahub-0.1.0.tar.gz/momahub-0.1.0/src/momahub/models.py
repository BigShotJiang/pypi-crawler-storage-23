"""Pydantic models for MoMa Hub."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class NodeStatus(str, Enum):
    ONLINE = "online"
    BUSY = "busy"
    OFFLINE = "offline"


class NodeInfo(BaseModel):
    """A registered inference node (one Ollama instance on one GPU)."""

    node_id: str                            # e.g. "home-gpu-0"
    url: str                                # e.g. "http://192.168.1.10:11434"
    gpu_model: str = "unknown"              # e.g. "GTX 1080 Ti"
    vram_gb: float = 11.0                   # usable VRAM in GB
    models: list[str] = Field(default_factory=list)  # ollama model tags available
    status: NodeStatus = NodeStatus.ONLINE
    registered_at: datetime = Field(default_factory=datetime.utcnow)
    last_seen: datetime = Field(default_factory=datetime.utcnow)


class InferenceRequest(BaseModel):
    """A single inference request routed through MoMa Hub."""

    model: str                              # e.g. "qwen2.5:7b"
    prompt: str
    system: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 512
    stream: bool = False


class InferenceResponse(BaseModel):
    """Result from a node inference call."""

    node_id: str
    model: str
    content: str
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0.0
    error: Optional[str] = None


class HubStats(BaseModel):
    """Aggregate stats for the hub registry."""

    total_nodes: int
    online_nodes: int
    total_models: int
    unique_models: list[str] = Field(default_factory=list)
