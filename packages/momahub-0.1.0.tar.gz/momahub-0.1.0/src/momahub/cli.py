"""MoMa Hub CLI — momahub <command>."""

from __future__ import annotations

import asyncio
import json
import sys

import click
import httpx


HUB_URL_DEFAULT = "http://localhost:8765"


@click.group()
@click.option("--hub", default=HUB_URL_DEFAULT, envvar="MOMAHUB_URL", show_default=True,
              help="MoMa Hub server URL")
@click.pass_context
def main(ctx: click.Context, hub: str) -> None:
    """MoMa Hub — distributed AI inference on consumer GPUs."""
    ctx.ensure_object(dict)
    ctx.obj["hub"] = hub


# ------------------------------------------------------------------
# Server management
# ------------------------------------------------------------------

@main.command()
@click.option("--host", default="0.0.0.0", show_default=True)
@click.option("--port", default=8765, show_default=True)
def serve(host: str, port: int) -> None:
    """Start the MoMa Hub registry server."""
    try:
        import uvicorn
        from momahub.server import app
    except ImportError:
        click.echo("uvicorn / fastapi required: pip install momahub[server]", err=True)
        sys.exit(1)
    click.echo(f"Starting MoMa Hub on http://{host}:{port}")
    uvicorn.run(app, host=host, port=port)


# ------------------------------------------------------------------
# Node management
# ------------------------------------------------------------------

@main.command("register")
@click.option("--node-id", required=True, help="Unique node identifier, e.g. home-gpu-0")
@click.option("--url", required=True, help="Ollama base URL, e.g. http://localhost:11434")
@click.option("--gpu", default="unknown", help="GPU model name")
@click.option("--vram", default=11.0, type=float, help="Usable VRAM in GB")
@click.option("--models", multiple=True, help="Pre-pulled model tags (repeat for multiple)")
@click.pass_context
def register_node(ctx: click.Context, node_id: str, url: str, gpu: str,
                  vram: float, models: tuple) -> None:
    """Register an Ollama node with the hub."""
    hub = ctx.obj["hub"]
    payload = {
        "node_id": node_id,
        "url": url,
        "gpu_model": gpu,
        "vram_gb": vram,
        "models": list(models),
    }
    resp = httpx.post(f"{hub}/nodes/register", json=payload)
    resp.raise_for_status()
    click.echo(f"Registered: {json.dumps(resp.json(), indent=2)}")


@main.command("nodes")
@click.pass_context
def list_nodes(ctx: click.Context) -> None:
    """List all registered nodes."""
    hub = ctx.obj["hub"]
    resp = httpx.get(f"{hub}/nodes")
    resp.raise_for_status()
    nodes = resp.json()
    if not nodes:
        click.echo("No nodes registered.")
        return
    for n in nodes:
        click.echo(f"  [{n['status']}] {n['node_id']}  {n['url']}  "
                   f"gpu={n['gpu_model']}  vram={n['vram_gb']}GB  "
                   f"models={n['models']}")


@main.command("stats")
@click.pass_context
def hub_stats(ctx: click.Context) -> None:
    """Show hub statistics."""
    hub = ctx.obj["hub"]
    resp = httpx.get(f"{hub}/stats")
    resp.raise_for_status()
    click.echo(json.dumps(resp.json(), indent=2))


# ------------------------------------------------------------------
# Inference
# ------------------------------------------------------------------

@main.command("infer")
@click.option("--model", required=True, help="Ollama model tag, e.g. qwen2.5:7b")
@click.option("--prompt", required=True, help="Prompt text")
@click.option("--system", default=None, help="System prompt")
@click.pass_context
def infer(ctx: click.Context, model: str, prompt: str, system: str | None) -> None:
    """Send an inference request through the hub."""
    hub = ctx.obj["hub"]
    payload: dict = {"model": model, "prompt": prompt}
    if system:
        payload["system"] = system
    resp = httpx.post(f"{hub}/infer", json=payload, timeout=120.0)
    resp.raise_for_status()
    data = resp.json()
    click.echo(data["content"])
    click.echo(
        f"\n[node={data['node_id']}  latency={data['latency_ms']:.0f}ms  "
        f"tokens={data['input_tokens']}+{data['output_tokens']}]",
        err=True,
    )


if __name__ == "__main__":
    main()
