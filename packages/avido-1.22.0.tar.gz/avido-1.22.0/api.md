# ValidateWebhook

Types:

```python
from avido.types import ValidateWebhookValidateResponse
```

Methods:

- <code title="post /v0/validate-webhook">client.validate_webhook.<a href="./src/avido/resources/validate_webhook.py">validate</a>(\*\*<a href="src/avido/types/validate_webhook_validate_params.py">params</a>) -> <a href="./src/avido/types/validate_webhook_validate_response.py">ValidateWebhookValidateResponse</a></code>

# Applications

Types:

```python
from avido.types import ApplicationOutput, ApplicationResponse, ApplicationListAPIKeysResponse
```

Methods:

- <code title="post /v0/applications">client.applications.<a href="./src/avido/resources/applications/applications.py">create</a>(\*\*<a href="src/avido/types/application_create_params.py">params</a>) -> <a href="./src/avido/types/application_response.py">ApplicationResponse</a></code>
- <code title="get /v0/applications/{id}">client.applications.<a href="./src/avido/resources/applications/applications.py">retrieve</a>(id) -> <a href="./src/avido/types/application_response.py">ApplicationResponse</a></code>
- <code title="get /v0/applications">client.applications.<a href="./src/avido/resources/applications/applications.py">list</a>(\*\*<a href="src/avido/types/application_list_params.py">params</a>) -> <a href="./src/avido/types/application_output.py">SyncOffsetPagination[ApplicationOutput]</a></code>
- <code title="get /v0/applications/{id}/api-keys">client.applications.<a href="./src/avido/resources/applications/applications.py">list_api_keys</a>(id) -> <a href="./src/avido/types/application_list_api_keys_response.py">ApplicationListAPIKeysResponse</a></code>
- <code title="get /v0/applications/by-slug/{slug}">client.applications.<a href="./src/avido/resources/applications/applications.py">retrieve_by_slug</a>(slug) -> <a href="./src/avido/types/application_response.py">ApplicationResponse</a></code>

## Webhook

Types:

```python
from avido.types.applications import WebhookRetrieveResponse, WebhookCreateOrUpdateResponse
```

Methods:

- <code title="get /v0/applications/{id}/webhook">client.applications.webhook.<a href="./src/avido/resources/applications/webhook.py">retrieve</a>(id) -> <a href="./src/avido/types/applications/webhook_retrieve_response.py">WebhookRetrieveResponse</a></code>
- <code title="delete /v0/applications/{id}/webhook">client.applications.webhook.<a href="./src/avido/resources/applications/webhook.py">delete</a>(id) -> None</code>
- <code title="post /v0/applications/{id}/webhook">client.applications.webhook.<a href="./src/avido/resources/applications/webhook.py">create_or_update</a>(id, \*\*<a href="src/avido/types/applications/webhook_create_or_update_params.py">params</a>) -> <a href="./src/avido/types/applications/webhook_create_or_update_response.py">WebhookCreateOrUpdateResponse</a></code>

# Webhook

Types:

```python
from avido.types import WebhookTestResponse
```

Methods:

- <code title="post /v0/webhook/test">client.webhook.<a href="./src/avido/resources/webhook.py">test</a>() -> <a href="./src/avido/types/webhook_test_response.py">WebhookTestResponse</a></code>

# Traces

Types:

```python
from avido.types import TraceOutput, TraceResponse
```

Methods:

- <code title="get /v0/traces/{id}">client.traces.<a href="./src/avido/resources/traces.py">retrieve</a>(id) -> <a href="./src/avido/types/trace_response.py">TraceResponse</a></code>
- <code title="get /v0/traces">client.traces.<a href="./src/avido/resources/traces.py">list</a>(\*\*<a href="src/avido/types/trace_list_params.py">params</a>) -> <a href="./src/avido/types/trace_output.py">SyncOffsetPagination[TraceOutput]</a></code>
- <code title="get /v0/traces/by-test/{id}">client.traces.<a href="./src/avido/resources/traces.py">retrieve_by_test</a>(id) -> <a href="./src/avido/types/trace_response.py">TraceResponse</a></code>

# Ingest

Types:

```python
from avido.types import IngestResponse, Usage
```

Methods:

- <code title="post /v0/ingest">client.ingest.<a href="./src/avido/resources/ingest.py">create</a>(\*\*<a href="src/avido/types/ingest_create_params.py">params</a>) -> <a href="./src/avido/types/ingest_response.py">IngestResponse</a></code>

# Otel

Types:

```python
from avido.types import OtlpAttribute
```

Methods:

- <code title="post /v0/otel/traces">client.otel.<a href="./src/avido/resources/otel.py">ingest_traces</a>(\*\*<a href="src/avido/types/otel_ingest_traces_params.py">params</a>) -> <a href="./src/avido/types/ingest_response.py">IngestResponse</a></code>

# Tasks

Types:

```python
from avido.types import (
    CoreTag,
    Task,
    TaskListResponse,
    TaskGetCoverageResponse,
    TaskGetIDsResponse,
    TaskInstallTemplateResponse,
)
```

Methods:

- <code title="post /v0/tasks">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">create</a>(\*\*<a href="src/avido/types/task_create_params.py">params</a>) -> <a href="./src/avido/types/task.py">Task</a></code>
- <code title="get /v0/tasks/{id}">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">retrieve</a>(id) -> <a href="./src/avido/types/task.py">Task</a></code>
- <code title="put /v0/tasks/{id}">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">update</a>(id, \*\*<a href="src/avido/types/task_update_params.py">params</a>) -> <a href="./src/avido/types/task.py">Task</a></code>
- <code title="get /v0/tasks">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">list</a>(\*\*<a href="src/avido/types/task_list_params.py">params</a>) -> <a href="./src/avido/types/task_list_response.py">SyncOffsetPagination[TaskListResponse]</a></code>
- <code title="post /v0/tasks/delete">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">bulk_delete</a>(\*\*<a href="src/avido/types/task_bulk_delete_params.py">params</a>) -> None</code>
- <code title="get /v0/tasks/task-coverage">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">get_coverage</a>(\*\*<a href="src/avido/types/task_get_coverage_params.py">params</a>) -> <a href="./src/avido/types/task_get_coverage_response.py">TaskGetCoverageResponse</a></code>
- <code title="get /v0/tasks/ids">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">get_ids</a>(\*\*<a href="src/avido/types/task_get_ids_params.py">params</a>) -> <a href="./src/avido/types/task_get_ids_response.py">TaskGetIDsResponse</a></code>
- <code title="post /v0/tasks/template">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">install_template</a>(\*\*<a href="src/avido/types/task_install_template_params.py">params</a>) -> <a href="./src/avido/types/task_install_template_response.py">TaskInstallTemplateResponse</a></code>
- <code title="post /v0/tasks/trigger">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">trigger</a>(\*\*<a href="src/avido/types/task_trigger_params.py">params</a>) -> None</code>
- <code title="post /v0/tasks/upload-csv">client.tasks.<a href="./src/avido/resources/tasks/tasks.py">upload_csv</a>(\*\*<a href="src/avido/types/task_upload_csv_params.py">params</a>) -> None</code>

## Schedule

Types:

```python
from avido.types.tasks import ScheduleRetrieveResponse
```

Methods:

- <code title="get /v0/tasks/{id}/schedule">client.tasks.schedule.<a href="./src/avido/resources/tasks/schedule.py">retrieve</a>(id) -> <a href="./src/avido/types/tasks/schedule_retrieve_response.py">ScheduleRetrieveResponse</a></code>
- <code title="delete /v0/tasks/{id}/schedule">client.tasks.schedule.<a href="./src/avido/resources/tasks/schedule.py">delete</a>(id) -> None</code>
- <code title="post /v0/tasks/schedule">client.tasks.schedule.<a href="./src/avido/resources/tasks/schedule.py">create_or_update</a>(\*\*<a href="src/avido/types/tasks/schedule_create_or_update_params.py">params</a>) -> None</code>

## Tags

Methods:

- <code title="put /v0/tasks/{id}/tags">client.tasks.tags.<a href="./src/avido/resources/tasks/tags.py">update</a>(id, \*\*<a href="src/avido/types/tasks/tag_update_params.py">params</a>) -> <a href="./src/avido/types/documents/tags_response.py">TagsResponse</a></code>
- <code title="post /v0/tasks/tags">client.tasks.tags.<a href="./src/avido/resources/tasks/tags.py">add</a>(\*\*<a href="src/avido/types/tasks/tag_add_params.py">params</a>) -> None</code>
- <code title="get /v0/tasks/{id}/tags">client.tasks.tags.<a href="./src/avido/resources/tasks/tags.py">get</a>(id) -> <a href="./src/avido/types/documents/tags_response.py">TagsResponse</a></code>

# Definitions

Types:

```python
from avido.types import (
    EvalDefinition,
    EvalDefinitionOutput,
    EvalType,
    LinkEvalRequest,
    OutputMatchExtractConfig,
    OutputMatchExtractConfigOutput,
    OutputMatchListConfig,
    OutputMatchStringConfig,
)
```

Methods:

- <code title="post /v0/definitions">client.definitions.<a href="./src/avido/resources/definitions.py">create</a>(\*\*<a href="src/avido/types/definition_create_params.py">params</a>) -> <a href="./src/avido/types/eval_definition.py">EvalDefinition</a></code>
- <code title="put /v0/definitions/{id}">client.definitions.<a href="./src/avido/resources/definitions.py">update</a>(id, \*\*<a href="src/avido/types/definition_update_params.py">params</a>) -> <a href="./src/avido/types/eval_definition.py">EvalDefinition</a></code>
- <code title="get /v0/definitions">client.definitions.<a href="./src/avido/resources/definitions.py">list</a>(\*\*<a href="src/avido/types/definition_list_params.py">params</a>) -> <a href="./src/avido/types/eval_definition_output.py">SyncOffsetPagination[EvalDefinitionOutput]</a></code>
- <code title="delete /v0/definitions/{id}">client.definitions.<a href="./src/avido/resources/definitions.py">delete</a>(id) -> None</code>
- <code title="post /v0/definitions/link">client.definitions.<a href="./src/avido/resources/definitions.py">link</a>(\*\*<a href="src/avido/types/definition_link_params.py">params</a>) -> None</code>
- <code title="post /v0/definitions/unlink">client.definitions.<a href="./src/avido/resources/definitions.py">unlink</a>(\*\*<a href="src/avido/types/definition_unlink_params.py">params</a>) -> None</code>
- <code title="put /v0/definitions/{id}/tasks/{taskId}">client.definitions.<a href="./src/avido/resources/definitions.py">update_task_config</a>(task_id, \*, id, \*\*<a href="src/avido/types/definition_update_task_config_params.py">params</a>) -> None</code>

# Experiments

Types:

```python
from avido.types import Experiment, ExperimentOutput, ExperimentStatus
```

Methods:

- <code title="post /v0/experiments">client.experiments.<a href="./src/avido/resources/experiments/experiments.py">create</a>(\*\*<a href="src/avido/types/experiment_create_params.py">params</a>) -> <a href="./src/avido/types/experiment.py">Experiment</a></code>
- <code title="get /v0/experiments/{id}">client.experiments.<a href="./src/avido/resources/experiments/experiments.py">retrieve</a>(id) -> <a href="./src/avido/types/experiment.py">Experiment</a></code>
- <code title="put /v0/experiments/{id}">client.experiments.<a href="./src/avido/resources/experiments/experiments.py">update</a>(id, \*\*<a href="src/avido/types/experiment_update_params.py">params</a>) -> <a href="./src/avido/types/experiment.py">Experiment</a></code>
- <code title="get /v0/experiments">client.experiments.<a href="./src/avido/resources/experiments/experiments.py">list</a>(\*\*<a href="src/avido/types/experiment_list_params.py">params</a>) -> <a href="./src/avido/types/experiment_output.py">SyncOffsetPagination[ExperimentOutput]</a></code>

## Variants

Types:

```python
from avido.types.experiments import ExperimentVariant, ExperimentVariantOutput, RunResultOutput
```

Methods:

- <code title="post /v0/experiments/{id}/variants">client.experiments.variants.<a href="./src/avido/resources/experiments/variants.py">create</a>(id, \*\*<a href="src/avido/types/experiments/variant_create_params.py">params</a>) -> <a href="./src/avido/types/experiments/experiment_variant.py">ExperimentVariant</a></code>
- <code title="put /v0/experiments/{id}/variants/{variantId}">client.experiments.variants.<a href="./src/avido/resources/experiments/variants.py">update</a>(variant_id, \*, id, \*\*<a href="src/avido/types/experiments/variant_update_params.py">params</a>) -> <a href="./src/avido/types/experiments/experiment_variant.py">ExperimentVariant</a></code>
- <code title="get /v0/experiments/{id}/variants">client.experiments.variants.<a href="./src/avido/resources/experiments/variants.py">list</a>(id, \*\*<a href="src/avido/types/experiments/variant_list_params.py">params</a>) -> <a href="./src/avido/types/experiments/experiment_variant_output.py">SyncOffsetPagination[ExperimentVariantOutput]</a></code>
- <code title="post /v0/experiments/{id}/variants/{variantId}/trigger">client.experiments.variants.<a href="./src/avido/resources/experiments/variants.py">trigger</a>(variant_id, \*, id) -> None</code>

# InferenceSteps

Types:

```python
from avido.types import InferenceStepOutput, InferenceStepType, InferenceStepCreateResponse
```

Methods:

- <code title="post /v0/inference-steps">client.inference_steps.<a href="./src/avido/resources/inference_steps.py">create</a>(\*\*<a href="src/avido/types/inference_step_create_params.py">params</a>) -> <a href="./src/avido/types/inference_step_create_response.py">InferenceStepCreateResponse</a></code>
- <code title="get /v0/inference-steps">client.inference_steps.<a href="./src/avido/resources/inference_steps.py">list</a>(\*\*<a href="src/avido/types/inference_step_list_params.py">params</a>) -> <a href="./src/avido/types/inference_step_output.py">SyncOffsetPagination[InferenceStepOutput]</a></code>

# Tests

Types:

```python
from avido.types import (
    EvalOutput,
    RunType,
    TestResultOutput,
    TestRetrieveResponse,
    TestListResponse,
)
```

Methods:

- <code title="get /v0/tests/{id}">client.tests.<a href="./src/avido/resources/tests.py">retrieve</a>(id) -> <a href="./src/avido/types/test_retrieve_response.py">TestRetrieveResponse</a></code>
- <code title="get /v0/tests">client.tests.<a href="./src/avido/resources/tests.py">list</a>(\*\*<a href="src/avido/types/test_list_params.py">params</a>) -> <a href="./src/avido/types/test_list_response.py">SyncOffsetPagination[TestListResponse]</a></code>

# Topics

Types:

```python
from avido.types import TopicOutput, TopicResponse
```

Methods:

- <code title="post /v0/topics">client.topics.<a href="./src/avido/resources/topics.py">create</a>(\*\*<a href="src/avido/types/topic_create_params.py">params</a>) -> <a href="./src/avido/types/topic_response.py">TopicResponse</a></code>
- <code title="get /v0/topics/{id}">client.topics.<a href="./src/avido/resources/topics.py">retrieve</a>(id) -> <a href="./src/avido/types/topic_response.py">TopicResponse</a></code>
- <code title="get /v0/topics">client.topics.<a href="./src/avido/resources/topics.py">list</a>(\*\*<a href="src/avido/types/topic_list_params.py">params</a>) -> <a href="./src/avido/types/topic_output.py">SyncOffsetPagination[TopicOutput]</a></code>

# Annotations

Types:

```python
from avido.types import AnnotationOutput, AnnotationResponse
```

Methods:

- <code title="post /v0/annotations">client.annotations.<a href="./src/avido/resources/annotations.py">create</a>(\*\*<a href="src/avido/types/annotation_create_params.py">params</a>) -> <a href="./src/avido/types/annotation_response.py">AnnotationResponse</a></code>
- <code title="get /v0/annotations/{id}">client.annotations.<a href="./src/avido/resources/annotations.py">retrieve</a>(id) -> <a href="./src/avido/types/annotation_response.py">AnnotationResponse</a></code>
- <code title="put /v0/annotations/{id}">client.annotations.<a href="./src/avido/resources/annotations.py">update</a>(id, \*\*<a href="src/avido/types/annotation_update_params.py">params</a>) -> <a href="./src/avido/types/annotation_response.py">AnnotationResponse</a></code>
- <code title="get /v0/annotations">client.annotations.<a href="./src/avido/resources/annotations.py">list</a>(\*\*<a href="src/avido/types/annotation_list_params.py">params</a>) -> <a href="./src/avido/types/annotation_output.py">SyncOffsetPagination[AnnotationOutput]</a></code>
- <code title="delete /v0/annotations/{id}">client.annotations.<a href="./src/avido/resources/annotations.py">delete</a>(id) -> None</code>

# Issues

Types:

```python
from avido.types import (
    AssignedUserInfo,
    GroupedIssueOutput,
    IssueOutput,
    IssuePriority,
    IssueSource,
    IssueStatus,
    IssueType,
    IssueRetrieveResponse,
    IssueUpdateResponse,
    IssueBulkUpdateResponse,
    IssueListMinimalResponse,
)
```

Methods:

- <code title="post /v0/issues">client.issues.<a href="./src/avido/resources/issues/issues.py">create</a>(\*\*<a href="src/avido/types/issue_create_params.py">params</a>) -> None</code>
- <code title="get /v0/issues/{id}">client.issues.<a href="./src/avido/resources/issues/issues.py">retrieve</a>(id) -> <a href="./src/avido/types/issue_retrieve_response.py">IssueRetrieveResponse</a></code>
- <code title="put /v0/issues/{id}">client.issues.<a href="./src/avido/resources/issues/issues.py">update</a>(id, \*\*<a href="src/avido/types/issue_update_params.py">params</a>) -> <a href="./src/avido/types/issue_update_response.py">IssueUpdateResponse</a></code>
- <code title="get /v0/issues">client.issues.<a href="./src/avido/resources/issues/issues.py">list</a>(\*\*<a href="src/avido/types/issue_list_params.py">params</a>) -> <a href="./src/avido/types/grouped_issue_output.py">SyncOffsetPagination[GroupedIssueOutput]</a></code>
- <code title="delete /v0/issues/{id}">client.issues.<a href="./src/avido/resources/issues/issues.py">delete</a>(id) -> None</code>
- <code title="patch /v0/issues">client.issues.<a href="./src/avido/resources/issues/issues.py">bulk_update</a>(\*\*<a href="src/avido/types/issue_bulk_update_params.py">params</a>) -> <a href="./src/avido/types/issue_bulk_update_response.py">IssueBulkUpdateResponse</a></code>
- <code title="get /v0/issues/minimal">client.issues.<a href="./src/avido/resources/issues/issues.py">list_minimal</a>(\*\*<a href="src/avido/types/issue_list_minimal_params.py">params</a>) -> <a href="./src/avido/types/issue_list_minimal_response.py">SyncOffsetPagination[IssueListMinimalResponse]</a></code>

## SuggestedTask

Types:

```python
from avido.types.issues import (
    TaskOutput,
    TaskStatus,
    SuggestedTaskRetrieveResponse,
    SuggestedTaskUpdateAndActivateResponse,
)
```

Methods:

- <code title="get /v0/issues/{id}/suggested-task">client.issues.suggested_task.<a href="./src/avido/resources/issues/suggested_task.py">retrieve</a>(id) -> <a href="./src/avido/types/issues/suggested_task_retrieve_response.py">SuggestedTaskRetrieveResponse</a></code>
- <code title="put /v0/issues/{id}/suggested-task">client.issues.suggested_task.<a href="./src/avido/resources/issues/suggested_task.py">update_and_activate</a>(id, \*\*<a href="src/avido/types/issues/suggested_task_update_and_activate_params.py">params</a>) -> <a href="./src/avido/types/issues/suggested_task_update_and_activate_response.py">SuggestedTaskUpdateAndActivateResponse</a></code>

# Runs

Types:

```python
from avido.types import RunOutput, RunRetrieveResponse
```

Methods:

- <code title="get /v0/runs/{id}">client.runs.<a href="./src/avido/resources/runs.py">retrieve</a>(id) -> <a href="./src/avido/types/run_retrieve_response.py">RunRetrieveResponse</a></code>
- <code title="get /v0/runs">client.runs.<a href="./src/avido/resources/runs.py">list</a>(\*\*<a href="src/avido/types/run_list_params.py">params</a>) -> <a href="./src/avido/types/run_output.py">SyncOffsetPagination[RunOutput]</a></code>

# StyleGuides

Types:

```python
from avido.types import (
    StyleGuideOutput,
    StyleGuideResponse,
    StyleGuideSectionInput,
    StyleGuideSectionOutput,
)
```

Methods:

- <code title="post /v0/style-guides">client.style_guides.<a href="./src/avido/resources/style_guides.py">create</a>(\*\*<a href="src/avido/types/style_guide_create_params.py">params</a>) -> <a href="./src/avido/types/style_guide_response.py">StyleGuideResponse</a></code>
- <code title="get /v0/style-guides/{id}">client.style_guides.<a href="./src/avido/resources/style_guides.py">retrieve</a>(id) -> <a href="./src/avido/types/style_guide_response.py">StyleGuideResponse</a></code>
- <code title="put /v0/style-guides/{id}">client.style_guides.<a href="./src/avido/resources/style_guides.py">update</a>(id, \*\*<a href="src/avido/types/style_guide_update_params.py">params</a>) -> <a href="./src/avido/types/style_guide_response.py">StyleGuideResponse</a></code>
- <code title="get /v0/style-guides">client.style_guides.<a href="./src/avido/resources/style_guides.py">list</a>(\*\*<a href="src/avido/types/style_guide_list_params.py">params</a>) -> <a href="./src/avido/types/style_guide_output.py">SyncOffsetPagination[StyleGuideOutput]</a></code>

# Documents

Types:

```python
from avido.types import (
    DocumentOutput,
    DocumentResponse,
    DocumentListResponse,
    DocumentCountResponse,
    DocumentCountByAssigneeResponse,
    DocumentListChunkedResponse,
    DocumentListIDsResponse,
)
```

Methods:

- <code title="post /v0/documents">client.documents.<a href="./src/avido/resources/documents/documents.py">create</a>(\*\*<a href="src/avido/types/document_create_params.py">params</a>) -> <a href="./src/avido/types/document_response.py">DocumentResponse</a></code>
- <code title="get /v0/documents/{id}">client.documents.<a href="./src/avido/resources/documents/documents.py">retrieve</a>(id) -> <a href="./src/avido/types/document_response.py">DocumentResponse</a></code>
- <code title="get /v0/documents">client.documents.<a href="./src/avido/resources/documents/documents.py">list</a>(\*\*<a href="src/avido/types/document_list_params.py">params</a>) -> <a href="./src/avido/types/document_list_response.py">SyncOffsetPagination[DocumentListResponse]</a></code>
- <code title="delete /v0/documents/{id}">client.documents.<a href="./src/avido/resources/documents/documents.py">delete</a>(id) -> None</code>
- <code title="post /v0/documents/activate-latest">client.documents.<a href="./src/avido/resources/documents/documents.py">activate_latest</a>(\*\*<a href="src/avido/types/document_activate_latest_params.py">params</a>) -> None</code>
- <code title="put /v0/documents/{id}/assign">client.documents.<a href="./src/avido/resources/documents/documents.py">assign</a>(id, \*\*<a href="src/avido/types/document_assign_params.py">params</a>) -> <a href="./src/avido/types/document_response.py">DocumentResponse</a></code>
- <code title="get /v0/documents/count">client.documents.<a href="./src/avido/resources/documents/documents.py">count</a>() -> <a href="./src/avido/types/document_count_response.py">DocumentCountResponse</a></code>
- <code title="get /v0/documents/count-by-assignee">client.documents.<a href="./src/avido/resources/documents/documents.py">count_by_assignee</a>() -> <a href="./src/avido/types/document_count_by_assignee_response.py">DocumentCountByAssigneeResponse</a></code>
- <code title="post /v0/documents/delete">client.documents.<a href="./src/avido/resources/documents/documents.py">delete_multiple</a>(\*\*<a href="src/avido/types/document_delete_multiple_params.py">params</a>) -> None</code>
- <code title="get /v0/documents/chunked">client.documents.<a href="./src/avido/resources/documents/documents.py">list_chunked</a>(\*\*<a href="src/avido/types/document_list_chunked_params.py">params</a>) -> <a href="./src/avido/types/document_list_chunked_response.py">SyncOffsetPagination[DocumentListChunkedResponse]</a></code>
- <code title="get /v0/documents/ids">client.documents.<a href="./src/avido/resources/documents/documents.py">list_ids</a>(\*\*<a href="src/avido/types/document_list_ids_params.py">params</a>) -> <a href="./src/avido/types/document_list_ids_response.py">DocumentListIDsResponse</a></code>
- <code title="post /v0/documents/{id}/optimize">client.documents.<a href="./src/avido/resources/documents/documents.py">optimize_doc</a>(id) -> None</code>
- <code title="post /v0/documents/status">client.documents.<a href="./src/avido/resources/documents/documents.py">update_status</a>(\*\*<a href="src/avido/types/document_update_status_params.py">params</a>) -> None</code>
- <code title="post /v0/documents/upload-csv">client.documents.<a href="./src/avido/resources/documents/documents.py">upload_csv</a>(\*\*<a href="src/avido/types/document_upload_csv_params.py">params</a>) -> None</code>

## Export

Types:

```python
from avido.types.documents import ExportCsvResponse
```

Methods:

- <code title="post /v0/documents/export/csv">client.documents.export.<a href="./src/avido/resources/documents/export.py">csv</a>(\*\*<a href="src/avido/types/documents/export_csv_params.py">params</a>) -> str</code>

## Optimize

Methods:

- <code title="post /v0/documents/optimize">client.documents.optimize.<a href="./src/avido/resources/documents/optimize.py">bulk</a>(\*\*<a href="src/avido/types/documents/optimize_bulk_params.py">params</a>) -> None</code>

## Versions

Types:

```python
from avido.types.documents import (
    DocumentVersionOutput,
    DocumentVersionResponse,
    VersionListResponse,
    VersionActivateResponse,
)
```

Methods:

- <code title="post /v0/documents/{id}/versions">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">create</a>(id) -> <a href="./src/avido/types/documents/document_version_response.py">DocumentVersionResponse</a></code>
- <code title="get /v0/documents/{id}/versions/{versionNumber}">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">retrieve</a>(version_number, \*, id) -> <a href="./src/avido/types/documents/document_version_response.py">DocumentVersionResponse</a></code>
- <code title="put /v0/documents/{id}/versions/{versionNumber}">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">update</a>(version_number, \*, id, \*\*<a href="src/avido/types/documents/version_update_params.py">params</a>) -> <a href="./src/avido/types/documents/document_version_response.py">DocumentVersionResponse</a></code>
- <code title="get /v0/documents/{id}/versions">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">list</a>(id) -> <a href="./src/avido/types/documents/version_list_response.py">VersionListResponse</a></code>
- <code title="put /v0/documents/{id}/versions/{versionNumber}/activate">client.documents.versions.<a href="./src/avido/resources/documents/versions.py">activate</a>(version_number, \*, id) -> <a href="./src/avido/types/documents/version_activate_response.py">VersionActivateResponse</a></code>

## Tests

Types:

```python
from avido.types.documents import (
    DocumentTestOutput,
    DocumentTestStatus,
    DocumentTestType,
    TestTriggerResponse,
)
```

Methods:

- <code title="get /v0/documents/tests">client.documents.tests.<a href="./src/avido/resources/documents/tests.py">list</a>(\*\*<a href="src/avido/types/documents/test_list_params.py">params</a>) -> <a href="./src/avido/types/documents/document_test_output.py">SyncOffsetPagination[DocumentTestOutput]</a></code>
- <code title="post /v0/documents/tests/trigger">client.documents.tests.<a href="./src/avido/resources/documents/tests.py">trigger</a>(\*\*<a href="src/avido/types/documents/test_trigger_params.py">params</a>) -> <a href="./src/avido/types/documents/test_trigger_response.py">TestTriggerResponse</a></code>

## Tags

Types:

```python
from avido.types.documents import TagsResponse, UpdateTags
```

Methods:

- <code title="put /v0/documents/{id}/tags">client.documents.tags.<a href="./src/avido/resources/documents/tags.py">update</a>(id, \*\*<a href="src/avido/types/documents/tag_update_params.py">params</a>) -> <a href="./src/avido/types/documents/tags_response.py">TagsResponse</a></code>
- <code title="get /v0/documents/{id}/tags">client.documents.tags.<a href="./src/avido/resources/documents/tags.py">list</a>(id) -> <a href="./src/avido/types/documents/tags_response.py">TagsResponse</a></code>
- <code title="post /v0/documents/tags">client.documents.tags.<a href="./src/avido/resources/documents/tags.py">add_multiple</a>(\*\*<a href="src/avido/types/documents/tag_add_multiple_params.py">params</a>) -> None</code>

# Tags

Types:

```python
from avido.types import TagOutput, TagResponse
```

Methods:

- <code title="post /v0/tags">client.tags.<a href="./src/avido/resources/tags.py">create</a>(\*\*<a href="src/avido/types/tag_create_params.py">params</a>) -> <a href="./src/avido/types/tag_response.py">TagResponse</a></code>
- <code title="get /v0/tags/{id}">client.tags.<a href="./src/avido/resources/tags.py">retrieve</a>(id) -> <a href="./src/avido/types/tag_response.py">TagResponse</a></code>
- <code title="put /v0/tags/{id}">client.tags.<a href="./src/avido/resources/tags.py">update</a>(id, \*\*<a href="src/avido/types/tag_update_params.py">params</a>) -> <a href="./src/avido/types/tag_response.py">TagResponse</a></code>
- <code title="get /v0/tags">client.tags.<a href="./src/avido/resources/tags.py">list</a>(\*\*<a href="src/avido/types/tag_list_params.py">params</a>) -> <a href="./src/avido/types/tag_output.py">SyncOffsetPagination[TagOutput]</a></code>
- <code title="delete /v0/tags/{id}">client.tags.<a href="./src/avido/resources/tags.py">delete</a>(id) -> None</code>

# ScrapeJobs

Types:

```python
from avido.types import (
    ScrapeJobOutput,
    ScrapeJobStatus,
    ScrapeJobCreateResponse,
    ScrapeJobStartResponse,
)
```

Methods:

- <code title="post /v0/scrape-jobs">client.scrape_jobs.<a href="./src/avido/resources/scrape_jobs.py">create</a>(\*\*<a href="src/avido/types/scrape_job_create_params.py">params</a>) -> <a href="./src/avido/types/scrape_job_create_response.py">ScrapeJobCreateResponse</a></code>
- <code title="get /v0/scrape-jobs/{id}">client.scrape_jobs.<a href="./src/avido/resources/scrape_jobs.py">retrieve</a>(id) -> <a href="./src/avido/types/scrape_job_output.py">ScrapeJobOutput</a></code>
- <code title="put /v0/scrape-jobs/{id}">client.scrape_jobs.<a href="./src/avido/resources/scrape_jobs.py">update</a>(id, \*\*<a href="src/avido/types/scrape_job_update_params.py">params</a>) -> <a href="./src/avido/types/scrape_job_output.py">ScrapeJobOutput</a></code>
- <code title="get /v0/scrape-jobs">client.scrape_jobs.<a href="./src/avido/resources/scrape_jobs.py">list</a>(\*\*<a href="src/avido/types/scrape_job_list_params.py">params</a>) -> <a href="./src/avido/types/scrape_job_output.py">SyncOffsetPagination[ScrapeJobOutput]</a></code>
- <code title="post /v0/scrape-jobs/{id}/start">client.scrape_jobs.<a href="./src/avido/resources/scrape_jobs.py">start</a>(id) -> <a href="./src/avido/types/scrape_job_start_response.py">ScrapeJobStartResponse</a></code>

# Quickstarts

Types:

```python
from avido.types import (
    QuickstartOutput,
    QuickstartResponse,
    QuickstartApproveStyleGuideResponse,
    QuickstartConfirmStyleScoresResponse,
    QuickstartUpdateStyleGuideSectionResponse,
)
```

Methods:

- <code title="post /v0/quickstarts">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">create</a>(\*\*<a href="src/avido/types/quickstart_create_params.py">params</a>) -> <a href="./src/avido/types/quickstart_response.py">QuickstartResponse</a></code>
- <code title="get /v0/quickstarts/{id}">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">retrieve</a>(id) -> <a href="./src/avido/types/quickstart_response.py">QuickstartResponse</a></code>
- <code title="put /v0/quickstarts/{id}">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">update</a>(id, \*\*<a href="src/avido/types/quickstart_update_params.py">params</a>) -> <a href="./src/avido/types/quickstart_response.py">QuickstartResponse</a></code>
- <code title="get /v0/quickstarts">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">list</a>(\*\*<a href="src/avido/types/quickstart_list_params.py">params</a>) -> <a href="./src/avido/types/quickstart_output.py">SyncOffsetPagination[QuickstartOutput]</a></code>
- <code title="post /v0/quickstarts/approve-style-guide">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">approve_style_guide</a>(\*\*<a href="src/avido/types/quickstart_approve_style_guide_params.py">params</a>) -> <a href="./src/avido/types/quickstart_approve_style_guide_response.py">QuickstartApproveStyleGuideResponse</a></code>
- <code title="post /v0/quickstarts/confirm-style-scores">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">confirm_style_scores</a>(\*\*<a href="src/avido/types/quickstart_confirm_style_scores_params.py">params</a>) -> <a href="./src/avido/types/quickstart_confirm_style_scores_response.py">QuickstartConfirmStyleScoresResponse</a></code>
- <code title="post /v0/quickstarts/update-style-guide-section">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">update_style_guide_section</a>(\*\*<a href="src/avido/types/quickstart_update_style_guide_section_params.py">params</a>) -> <a href="./src/avido/types/quickstart_update_style_guide_section_response.py">QuickstartUpdateStyleGuideSectionResponse</a></code>
- <code title="post /v0/quickstarts/upload-csv">client.quickstarts.<a href="./src/avido/resources/quickstarts.py">upload_csv</a>(\*\*<a href="src/avido/types/quickstart_upload_csv_params.py">params</a>) -> None</code>

# Reporting

Types:

```python
from avido.types import (
    ChartType,
    DateFilterPresetValue,
    DateFilterUnit,
    Measurement,
    MeasurementType,
    ReportOutput,
    ReportResponse,
    ReportingColumnMetadataOutput,
    ReportingQuery,
    ReportingQueryDateTrunc,
    ReportingQueryFilter,
    ReportingQueryGroupBy,
    ReportingQueryResponse,
)
```

Methods:

- <code title="post /v0/reporting">client.reporting.<a href="./src/avido/resources/reporting/reporting.py">create</a>(\*\*<a href="src/avido/types/reporting_create_params.py">params</a>) -> <a href="./src/avido/types/report_response.py">ReportResponse</a></code>
- <code title="get /v0/reporting/{id}">client.reporting.<a href="./src/avido/resources/reporting/reporting.py">retrieve</a>(id) -> <a href="./src/avido/types/report_response.py">ReportResponse</a></code>
- <code title="put /v0/reporting/{id}">client.reporting.<a href="./src/avido/resources/reporting/reporting.py">update</a>(id, \*\*<a href="src/avido/types/reporting_update_params.py">params</a>) -> <a href="./src/avido/types/report_response.py">ReportResponse</a></code>
- <code title="get /v0/reporting">client.reporting.<a href="./src/avido/resources/reporting/reporting.py">list</a>(\*\*<a href="src/avido/types/reporting_list_params.py">params</a>) -> <a href="./src/avido/types/report_output.py">SyncOffsetPagination[ReportOutput]</a></code>
- <code title="delete /v0/reporting/{id}">client.reporting.<a href="./src/avido/resources/reporting/reporting.py">delete</a>(id) -> None</code>
- <code title="post /v0/reporting/query">client.reporting.<a href="./src/avido/resources/reporting/reporting.py">query</a>(\*\*<a href="src/avido/types/reporting_query_params.py">params</a>) -> <a href="./src/avido/types/reporting_query_response.py">ReportingQueryResponse</a></code>

## Datasources

Types:

```python
from avido.types.reporting import DatasourceListResponse
```

Methods:

- <code title="get /v0/reporting/datasources">client.reporting.datasources.<a href="./src/avido/resources/reporting/datasources/datasources.py">list</a>() -> <a href="./src/avido/types/reporting/datasource_list_response.py">DatasourceListResponse</a></code>

### Columns

Types:

```python
from avido.types.reporting.datasources import (
    ReportingColumnsIntentSchema,
    ReportingQueryDatasource,
    ColumnListResponse,
    ColumnContextAwareResponse,
    ColumnValuesResponse,
)
```

Methods:

- <code title="get /v0/reporting/datasources/{id}/columns">client.reporting.datasources.columns.<a href="./src/avido/resources/reporting/datasources/columns.py">list</a>(id) -> <a href="./src/avido/types/reporting/datasources/column_list_response.py">ColumnListResponse</a></code>
- <code title="post /v0/reporting/datasources/{id}/columns">client.reporting.datasources.columns.<a href="./src/avido/resources/reporting/datasources/columns.py">context_aware</a>(id, \*\*<a href="src/avido/types/reporting/datasources/column_context_aware_params.py">params</a>) -> <a href="./src/avido/types/reporting/datasources/column_context_aware_response.py">ColumnContextAwareResponse</a></code>
- <code title="get /v0/reporting/datasources/{id}/columns/{columnId}/values">client.reporting.datasources.columns.<a href="./src/avido/resources/reporting/datasources/columns.py">values</a>(column_id, \*, id) -> <a href="./src/avido/types/reporting/datasources/column_values_response.py">ColumnValuesResponse</a></code>
