# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from avido.types import IngestResponse
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestOtel:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_ingest_traces(self, client: Avido) -> None:
        otel = client.otel.ingest_traces()
        assert_matches_type(IngestResponse, otel, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_ingest_traces_with_all_params(self, client: Avido) -> None:
        otel = client.otel.ingest_traces(
            resource_spans=[
                {
                    "resource": {
                        "attributes": [
                            {
                                "key": "key",
                                "value": {
                                    "array_value": {
                                        "values": [
                                            {
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "string_value": "stringValue",
                                            }
                                        ]
                                    },
                                    "bool_value": True,
                                    "double_value": 0,
                                    "int_value": 0,
                                    "kvlist_value": {"values": []},
                                    "string_value": "stringValue",
                                },
                            }
                        ]
                    },
                    "scope_spans": [
                        {
                            "scope": {
                                "name": "name",
                                "version": "version",
                            },
                            "spans": [
                                {
                                    "end_time_unix_nano": "1737052800500000000",
                                    "name": "llm.generate",
                                    "span_id": "00f067aa0ba902b7",
                                    "start_time_unix_nano": "1737052800000000000",
                                    "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736",
                                    "attributes": [
                                        {
                                            "key": "openinference.span.kind",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "LLM",
                                            },
                                        },
                                        {
                                            "key": "llm.model_name",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "gpt-4o-2024-08-06",
                                            },
                                        },
                                        {
                                            "key": "input.value",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "Tell me a joke.",
                                            },
                                        },
                                        {
                                            "key": "output.value",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "Why did the chicken cross the road?",
                                            },
                                        },
                                        {
                                            "key": "llm.token_count.prompt",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 12,
                                                "kvlist_value": {"values": []},
                                                "string_value": "stringValue",
                                            },
                                        },
                                        {
                                            "key": "llm.token_count.completion",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 18,
                                                "kvlist_value": {"values": []},
                                                "string_value": "stringValue",
                                            },
                                        },
                                    ],
                                    "kind": 0,
                                    "parent_span_id": "ecc2efdd09bd231a",
                                    "status": {
                                        "code": -9007199254740991,
                                        "message": "message",
                                    },
                                }
                            ],
                        }
                    ],
                }
            ],
        )
        assert_matches_type(IngestResponse, otel, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_ingest_traces(self, client: Avido) -> None:
        response = client.otel.with_raw_response.ingest_traces()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        otel = response.parse()
        assert_matches_type(IngestResponse, otel, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_ingest_traces(self, client: Avido) -> None:
        with client.otel.with_streaming_response.ingest_traces() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            otel = response.parse()
            assert_matches_type(IngestResponse, otel, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncOtel:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_ingest_traces(self, async_client: AsyncAvido) -> None:
        otel = await async_client.otel.ingest_traces()
        assert_matches_type(IngestResponse, otel, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_ingest_traces_with_all_params(self, async_client: AsyncAvido) -> None:
        otel = await async_client.otel.ingest_traces(
            resource_spans=[
                {
                    "resource": {
                        "attributes": [
                            {
                                "key": "key",
                                "value": {
                                    "array_value": {
                                        "values": [
                                            {
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "string_value": "stringValue",
                                            }
                                        ]
                                    },
                                    "bool_value": True,
                                    "double_value": 0,
                                    "int_value": 0,
                                    "kvlist_value": {"values": []},
                                    "string_value": "stringValue",
                                },
                            }
                        ]
                    },
                    "scope_spans": [
                        {
                            "scope": {
                                "name": "name",
                                "version": "version",
                            },
                            "spans": [
                                {
                                    "end_time_unix_nano": "1737052800500000000",
                                    "name": "llm.generate",
                                    "span_id": "00f067aa0ba902b7",
                                    "start_time_unix_nano": "1737052800000000000",
                                    "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736",
                                    "attributes": [
                                        {
                                            "key": "openinference.span.kind",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "LLM",
                                            },
                                        },
                                        {
                                            "key": "llm.model_name",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "gpt-4o-2024-08-06",
                                            },
                                        },
                                        {
                                            "key": "input.value",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "Tell me a joke.",
                                            },
                                        },
                                        {
                                            "key": "output.value",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 0,
                                                "kvlist_value": {"values": []},
                                                "string_value": "Why did the chicken cross the road?",
                                            },
                                        },
                                        {
                                            "key": "llm.token_count.prompt",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 12,
                                                "kvlist_value": {"values": []},
                                                "string_value": "stringValue",
                                            },
                                        },
                                        {
                                            "key": "llm.token_count.completion",
                                            "value": {
                                                "array_value": {
                                                    "values": [
                                                        {
                                                            "bool_value": True,
                                                            "double_value": 0,
                                                            "int_value": 0,
                                                            "string_value": "stringValue",
                                                        }
                                                    ]
                                                },
                                                "bool_value": True,
                                                "double_value": 0,
                                                "int_value": 18,
                                                "kvlist_value": {"values": []},
                                                "string_value": "stringValue",
                                            },
                                        },
                                    ],
                                    "kind": 0,
                                    "parent_span_id": "ecc2efdd09bd231a",
                                    "status": {
                                        "code": -9007199254740991,
                                        "message": "message",
                                    },
                                }
                            ],
                        }
                    ],
                }
            ],
        )
        assert_matches_type(IngestResponse, otel, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_ingest_traces(self, async_client: AsyncAvido) -> None:
        response = await async_client.otel.with_raw_response.ingest_traces()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        otel = await response.parse()
        assert_matches_type(IngestResponse, otel, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_ingest_traces(self, async_client: AsyncAvido) -> None:
        async with async_client.otel.with_streaming_response.ingest_traces() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            otel = await response.parse()
            assert_matches_type(IngestResponse, otel, path=["response"])

        assert cast(Any, response.is_closed) is True
