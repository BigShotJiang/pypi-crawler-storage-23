# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestOptimize:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_bulk(self, client: Avido) -> None:
        optimize = client.documents.optimize.bulk(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )
        assert optimize is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_bulk(self, client: Avido) -> None:
        response = client.documents.optimize.with_raw_response.bulk(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        optimize = response.parse()
        assert optimize is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_bulk(self, client: Avido) -> None:
        with client.documents.optimize.with_streaming_response.bulk(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            optimize = response.parse()
            assert optimize is None

        assert cast(Any, response.is_closed) is True


class TestAsyncOptimize:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_bulk(self, async_client: AsyncAvido) -> None:
        optimize = await async_client.documents.optimize.bulk(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )
        assert optimize is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_bulk(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.optimize.with_raw_response.bulk(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        optimize = await response.parse()
        assert optimize is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_bulk(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.optimize.with_streaming_response.bulk(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            optimize = await response.parse()
            assert optimize is None

        assert cast(Any, response.is_closed) is True
