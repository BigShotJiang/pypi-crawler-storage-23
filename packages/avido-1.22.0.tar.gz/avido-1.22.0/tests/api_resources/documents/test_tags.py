# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from tests.utils import assert_matches_type
from avido.types.documents import TagsResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTags:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Avido) -> None:
        tag = client.documents.tags.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
        )
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Avido) -> None:
        response = client.documents.tags.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tag = response.parse()
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Avido) -> None:
        with client.documents.tags.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tag = response.parse()
            assert_matches_type(TagsResponse, tag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.documents.tags.with_raw_response.update(
                id="",
                tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        tag = client.documents.tags.list(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.documents.tags.with_raw_response.list(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tag = response.parse()
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.documents.tags.with_streaming_response.list(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tag = response.parse()
            assert_matches_type(TagsResponse, tag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.documents.tags.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_add_multiple(self, client: Avido) -> None:
        tag = client.documents.tags.add_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            tag_ids=["456e4567-e89b-12d3-a456-426614174000", "789e4567-e89b-12d3-a456-426614174000"],
        )
        assert tag is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_add_multiple(self, client: Avido) -> None:
        response = client.documents.tags.with_raw_response.add_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            tag_ids=["456e4567-e89b-12d3-a456-426614174000", "789e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tag = response.parse()
        assert tag is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_add_multiple(self, client: Avido) -> None:
        with client.documents.tags.with_streaming_response.add_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            tag_ids=["456e4567-e89b-12d3-a456-426614174000", "789e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tag = response.parse()
            assert tag is None

        assert cast(Any, response.is_closed) is True


class TestAsyncTags:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncAvido) -> None:
        tag = await async_client.documents.tags.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
        )
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.tags.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tag = await response.parse()
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.tags.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tag = await response.parse()
            assert_matches_type(TagsResponse, tag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.documents.tags.with_raw_response.update(
                id="",
                tag_ids=["123e4567-e89b-12d3-a456-426614174000", "456e4567-e89b-12d3-a456-426614174000"],
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        tag = await async_client.documents.tags.list(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.tags.with_raw_response.list(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tag = await response.parse()
        assert_matches_type(TagsResponse, tag, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.tags.with_streaming_response.list(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tag = await response.parse()
            assert_matches_type(TagsResponse, tag, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.documents.tags.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_add_multiple(self, async_client: AsyncAvido) -> None:
        tag = await async_client.documents.tags.add_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            tag_ids=["456e4567-e89b-12d3-a456-426614174000", "789e4567-e89b-12d3-a456-426614174000"],
        )
        assert tag is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_add_multiple(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.tags.with_raw_response.add_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            tag_ids=["456e4567-e89b-12d3-a456-426614174000", "789e4567-e89b-12d3-a456-426614174000"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        tag = await response.parse()
        assert tag is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_add_multiple(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.tags.with_streaming_response.add_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            tag_ids=["456e4567-e89b-12d3-a456-426614174000", "789e4567-e89b-12d3-a456-426614174000"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            tag = await response.parse()
            assert tag is None

        assert cast(Any, response.is_closed) is True
