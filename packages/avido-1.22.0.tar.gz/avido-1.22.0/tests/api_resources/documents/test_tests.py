# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from tests.utils import assert_matches_type
from avido._utils import parse_datetime
from avido.pagination import SyncOffsetPagination, AsyncOffsetPagination
from avido.types.documents import (
    DocumentTestOutput,
    TestTriggerResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTests:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        test = client.documents.tests.list()
        assert_matches_type(SyncOffsetPagination[DocumentTestOutput], test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Avido) -> None:
        test = client.documents.tests.list(
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            start=parse_datetime("2025-01-01T00:00:00Z"),
            status="COMPLETED",
            type="KNOWLEDGE_COVERAGE",
        )
        assert_matches_type(SyncOffsetPagination[DocumentTestOutput], test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.documents.tests.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        test = response.parse()
        assert_matches_type(SyncOffsetPagination[DocumentTestOutput], test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.documents.tests.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            test = response.parse()
            assert_matches_type(SyncOffsetPagination[DocumentTestOutput], test, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_trigger(self, client: Avido) -> None:
        test = client.documents.tests.trigger(
            type="KNOWLEDGE_COVERAGE",
        )
        assert_matches_type(TestTriggerResponse, test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_trigger(self, client: Avido) -> None:
        response = client.documents.tests.with_raw_response.trigger(
            type="KNOWLEDGE_COVERAGE",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        test = response.parse()
        assert_matches_type(TestTriggerResponse, test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_trigger(self, client: Avido) -> None:
        with client.documents.tests.with_streaming_response.trigger(
            type="KNOWLEDGE_COVERAGE",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            test = response.parse()
            assert_matches_type(TestTriggerResponse, test, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncTests:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        test = await async_client.documents.tests.list()
        assert_matches_type(AsyncOffsetPagination[DocumentTestOutput], test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncAvido) -> None:
        test = await async_client.documents.tests.list(
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            start=parse_datetime("2025-01-01T00:00:00Z"),
            status="COMPLETED",
            type="KNOWLEDGE_COVERAGE",
        )
        assert_matches_type(AsyncOffsetPagination[DocumentTestOutput], test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.tests.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        test = await response.parse()
        assert_matches_type(AsyncOffsetPagination[DocumentTestOutput], test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.tests.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            test = await response.parse()
            assert_matches_type(AsyncOffsetPagination[DocumentTestOutput], test, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_trigger(self, async_client: AsyncAvido) -> None:
        test = await async_client.documents.tests.trigger(
            type="KNOWLEDGE_COVERAGE",
        )
        assert_matches_type(TestTriggerResponse, test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_trigger(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.tests.with_raw_response.trigger(
            type="KNOWLEDGE_COVERAGE",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        test = await response.parse()
        assert_matches_type(TestTriggerResponse, test, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_trigger(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.tests.with_streaming_response.trigger(
            type="KNOWLEDGE_COVERAGE",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            test = await response.parse()
            assert_matches_type(TestTriggerResponse, test, path=["response"])

        assert cast(Any, response.is_closed) is True
