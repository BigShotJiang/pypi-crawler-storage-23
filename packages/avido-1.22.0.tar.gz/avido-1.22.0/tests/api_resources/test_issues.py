# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from avido.types import (
    GroupedIssueOutput,
    IssueUpdateResponse,
    IssueRetrieveResponse,
    IssueBulkUpdateResponse,
    IssueListMinimalResponse,
)
from tests.utils import assert_matches_type
from avido._utils import parse_datetime
from avido.pagination import SyncOffsetPagination, AsyncOffsetPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestIssues:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Avido) -> None:
        issue = client.issues.create(
            source="TEST",
            title="Response quality degradation",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Avido) -> None:
        issue = client.issues.create(
            source="TEST",
            title="Response quality degradation",
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            description="The chatbot is providing incomplete responses to user queries",
            eval_definition_id="789e4567-e89b-12d3-a456-426614174000",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            priority="HIGH",
            task_id="789e4567-e89b-12d3-a456-426614174000",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            topic_id="789e4567-e89b-12d3-a456-426614174000",
            trace_id="trace_abc123",
            type="BUG",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Avido) -> None:
        response = client.issues.with_raw_response.create(
            source="TEST",
            title="Response quality degradation",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Avido) -> None:
        with client.issues.with_streaming_response.create(
            source="TEST",
            title="Response quality degradation",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert issue is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Avido) -> None:
        issue = client.issues.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(IssueRetrieveResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Avido) -> None:
        response = client.issues.with_raw_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert_matches_type(IssueRetrieveResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Avido) -> None:
        with client.issues.with_streaming_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert_matches_type(IssueRetrieveResponse, issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.issues.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Avido) -> None:
        issue = client.issues.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(IssueUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Avido) -> None:
        issue = client.issues.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            assigned_to="user_345678",
            comment="Duplicate report",
            eval_definition_id="789e4567-e89b-12d3-a456-426614174000",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            priority="LOW",
            status="RESOLVED",
            summary="The chatbot is consistently providing incomplete responses",
            task_id="789e4567-e89b-12d3-a456-426614174000",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            title="Response quality degradation - Critical",
            topic_id="789e4567-e89b-12d3-a456-426614174000",
            trace_id="trace_xyz789",
            type="HUMAN_ANNOTATION",
        )
        assert_matches_type(IssueUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Avido) -> None:
        response = client.issues.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert_matches_type(IssueUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Avido) -> None:
        with client.issues.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert_matches_type(IssueUpdateResponse, issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.issues.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        issue = client.issues.list()
        assert_matches_type(SyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Avido) -> None:
        issue = client.issues.list(
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            assigned_to="user_789012",
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            priority="HIGH",
            skip=0,
            source="TEST",
            start=parse_datetime("2025-01-01T00:00:00Z"),
            status="OPEN",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            type="BUG",
        )
        assert_matches_type(SyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.issues.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert_matches_type(SyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.issues.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert_matches_type(SyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Avido) -> None:
        issue = client.issues.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Avido) -> None:
        response = client.issues.with_raw_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Avido) -> None:
        with client.issues.with_streaming_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert issue is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.issues.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_bulk_update(self, client: Avido) -> None:
        issue = client.issues.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )
        assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_bulk_update_with_all_params(self, client: Avido) -> None:
        issue = client.issues.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            assigned_to="user_789012",
            comment="Fixed in version 2.1.0",
            priority="HIGH",
            status="RESOLVED",
        )
        assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_bulk_update(self, client: Avido) -> None:
        response = client.issues.with_raw_response.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_bulk_update(self, client: Avido) -> None:
        with client.issues.with_streaming_response.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_minimal(self, client: Avido) -> None:
        issue = client.issues.list_minimal()
        assert_matches_type(SyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_minimal_with_all_params(self, client: Avido) -> None:
        issue = client.issues.list_minimal(
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            assigned_to="user_789012",
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            priority="HIGH",
            skip=0,
            source="TEST",
            start=parse_datetime("2025-01-01T00:00:00Z"),
            status="OPEN",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            type="BUG",
        )
        assert_matches_type(SyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_minimal(self, client: Avido) -> None:
        response = client.issues.with_raw_response.list_minimal()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = response.parse()
        assert_matches_type(SyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_minimal(self, client: Avido) -> None:
        with client.issues.with_streaming_response.list_minimal() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = response.parse()
            assert_matches_type(SyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncIssues:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.create(
            source="TEST",
            title="Response quality degradation",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.create(
            source="TEST",
            title="Response quality degradation",
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            description="The chatbot is providing incomplete responses to user queries",
            eval_definition_id="789e4567-e89b-12d3-a456-426614174000",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            priority="HIGH",
            task_id="789e4567-e89b-12d3-a456-426614174000",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            topic_id="789e4567-e89b-12d3-a456-426614174000",
            trace_id="trace_abc123",
            type="BUG",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.create(
            source="TEST",
            title="Response quality degradation",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.create(
            source="TEST",
            title="Response quality degradation",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert issue is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(IssueRetrieveResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert_matches_type(IssueRetrieveResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert_matches_type(IssueRetrieveResponse, issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.issues.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(IssueUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            assigned_to="user_345678",
            comment="Duplicate report",
            eval_definition_id="789e4567-e89b-12d3-a456-426614174000",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            priority="LOW",
            status="RESOLVED",
            summary="The chatbot is consistently providing incomplete responses",
            task_id="789e4567-e89b-12d3-a456-426614174000",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            title="Response quality degradation - Critical",
            topic_id="789e4567-e89b-12d3-a456-426614174000",
            trace_id="trace_xyz789",
            type="HUMAN_ANNOTATION",
        )
        assert_matches_type(IssueUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert_matches_type(IssueUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert_matches_type(IssueUpdateResponse, issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.issues.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.list()
        assert_matches_type(AsyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.list(
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            assigned_to="user_789012",
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            priority="HIGH",
            skip=0,
            source="TEST",
            start=parse_datetime("2025-01-01T00:00:00Z"),
            status="OPEN",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            type="BUG",
        )
        assert_matches_type(AsyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert_matches_type(AsyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert_matches_type(AsyncOffsetPagination[GroupedIssueOutput], issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert issue is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert issue is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.issues.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_bulk_update(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )
        assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_bulk_update_with_all_params(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            assigned_to="user_789012",
            comment="Fixed in version 2.1.0",
            priority="HIGH",
            status="RESOLVED",
        )
        assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_bulk_update(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_bulk_update(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.bulk_update(
            issue_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert_matches_type(IssueBulkUpdateResponse, issue, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_minimal(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.list_minimal()
        assert_matches_type(AsyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_minimal_with_all_params(self, async_client: AsyncAvido) -> None:
        issue = await async_client.issues.list_minimal(
            annotation_id="890e5678-e89b-12d3-a456-426614174000",
            assigned_to="user_789012",
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            priority="HIGH",
            skip=0,
            source="TEST",
            start=parse_datetime("2025-01-01T00:00:00Z"),
            status="OPEN",
            test_id="789e4567-e89b-12d3-a456-426614174000",
            type="BUG",
        )
        assert_matches_type(AsyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_minimal(self, async_client: AsyncAvido) -> None:
        response = await async_client.issues.with_raw_response.list_minimal()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        issue = await response.parse()
        assert_matches_type(AsyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_minimal(self, async_client: AsyncAvido) -> None:
        async with async_client.issues.with_streaming_response.list_minimal() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            issue = await response.parse()
            assert_matches_type(AsyncOffsetPagination[IssueListMinimalResponse], issue, path=["response"])

        assert cast(Any, response.is_closed) is True
