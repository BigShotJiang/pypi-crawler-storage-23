# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from avido.types import (
    DocumentResponse,
    DocumentListResponse,
    DocumentCountResponse,
    DocumentListIDsResponse,
    DocumentListChunkedResponse,
    DocumentCountByAssigneeResponse,
)
from tests.utils import assert_matches_type
from avido._utils import parse_datetime
from avido.pagination import SyncOffsetPagination, AsyncOffsetPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestDocuments:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Avido) -> None:
        document = client.documents.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Avido) -> None:
        document = client.documents.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
            assignee="user_123456789",
            language="english",
            metadata={"foo": "bar"},
            original_sentences=["This is the first sentence.", "This is the second sentence."],
            scrape_job_id="321e4567-e89b-12d3-a456-426614174000",
            status="DRAFT",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Avido) -> None:
        response = client.documents.with_raw_response.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Avido) -> None:
        with client.documents.with_streaming_response.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(DocumentResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Avido) -> None:
        document = client.documents.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Avido) -> None:
        response = client.documents.with_raw_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Avido) -> None:
        with client.documents.with_streaming_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(DocumentResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.documents.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        document = client.documents.list()
        assert_matches_type(SyncOffsetPagination[DocumentListResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Avido) -> None:
        document = client.documents.list(
            assignee="user_123456789",
            end_date=parse_datetime("2024-12-31T23:59:59.999Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            scrape_job_id=["182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e"],
            search="API documentation",
            skip=0,
            start_date=parse_datetime("2024-01-01T00:00:00.000Z"),
            status=["APPROVED"],
            tag_id=["string"],
        )
        assert_matches_type(SyncOffsetPagination[DocumentListResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.documents.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(SyncOffsetPagination[DocumentListResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.documents.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(SyncOffsetPagination[DocumentListResponse], document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Avido) -> None:
        document = client.documents.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Avido) -> None:
        response = client.documents.with_raw_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Avido) -> None:
        with client.documents.with_streaming_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.documents.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_activate_latest(self, client: Avido) -> None:
        document = client.documents.activate_latest(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_activate_latest(self, client: Avido) -> None:
        response = client.documents.with_raw_response.activate_latest(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_activate_latest(self, client: Avido) -> None:
        with client.documents.with_streaming_response.activate_latest(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_assign(self, client: Avido) -> None:
        document = client.documents.assign(
            id="123e4567-e89b-12d3-a456-426614174000",
            user_id="user_123456789",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_assign(self, client: Avido) -> None:
        response = client.documents.with_raw_response.assign(
            id="123e4567-e89b-12d3-a456-426614174000",
            user_id="user_123456789",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_assign(self, client: Avido) -> None:
        with client.documents.with_streaming_response.assign(
            id="123e4567-e89b-12d3-a456-426614174000",
            user_id="user_123456789",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(DocumentResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_assign(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.documents.with_raw_response.assign(
                id="",
                user_id="user_123456789",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_count(self, client: Avido) -> None:
        document = client.documents.count()
        assert_matches_type(DocumentCountResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_count(self, client: Avido) -> None:
        response = client.documents.with_raw_response.count()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(DocumentCountResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_count(self, client: Avido) -> None:
        with client.documents.with_streaming_response.count() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(DocumentCountResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_count_by_assignee(self, client: Avido) -> None:
        document = client.documents.count_by_assignee()
        assert_matches_type(DocumentCountByAssigneeResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_count_by_assignee(self, client: Avido) -> None:
        response = client.documents.with_raw_response.count_by_assignee()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(DocumentCountByAssigneeResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_count_by_assignee(self, client: Avido) -> None:
        with client.documents.with_streaming_response.count_by_assignee() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(DocumentCountByAssigneeResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete_multiple(self, client: Avido) -> None:
        document = client.documents.delete_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete_multiple(self, client: Avido) -> None:
        response = client.documents.with_raw_response.delete_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete_multiple(self, client: Avido) -> None:
        with client.documents.with_streaming_response.delete_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_chunked(self, client: Avido) -> None:
        document = client.documents.list_chunked()
        assert_matches_type(SyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_chunked_with_all_params(self, client: Avido) -> None:
        document = client.documents.list_chunked(
            document_id="123e4567-e89b-12d3-a456-426614174000",
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            status="APPROVED",
            version_id="321e4567-e89b-12d3-a456-426614174001",
        )
        assert_matches_type(SyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_chunked(self, client: Avido) -> None:
        response = client.documents.with_raw_response.list_chunked()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(SyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_chunked(self, client: Avido) -> None:
        with client.documents.with_streaming_response.list_chunked() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(SyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_ids(self, client: Avido) -> None:
        document = client.documents.list_ids()
        assert_matches_type(DocumentListIDsResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_ids_with_all_params(self, client: Avido) -> None:
        document = client.documents.list_ids(
            scrape_job_id=["182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e"],
            search="API documentation",
            status=["APPROVED"],
            tag_id=["string"],
        )
        assert_matches_type(DocumentListIDsResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_ids(self, client: Avido) -> None:
        response = client.documents.with_raw_response.list_ids()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(DocumentListIDsResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_ids(self, client: Avido) -> None:
        with client.documents.with_streaming_response.list_ids() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(DocumentListIDsResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_optimize_doc(self, client: Avido) -> None:
        document = client.documents.optimize_doc(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_optimize_doc(self, client: Avido) -> None:
        response = client.documents.with_raw_response.optimize_doc(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_optimize_doc(self, client: Avido) -> None:
        with client.documents.with_streaming_response.optimize_doc(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_optimize_doc(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.documents.with_raw_response.optimize_doc(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_status(self, client: Avido) -> None:
        document = client.documents.update_status(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            status="APPROVED",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update_status(self, client: Avido) -> None:
        response = client.documents.with_raw_response.update_status(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            status="APPROVED",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update_status(self, client: Avido) -> None:
        with client.documents.with_streaming_response.update_status(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            status="APPROVED",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_upload_csv(self, client: Avido) -> None:
        document = client.documents.upload_csv(
            file={},
            file_name="Knowledge Base Q1 2024",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_upload_csv(self, client: Avido) -> None:
        response = client.documents.with_raw_response.upload_csv(
            file={},
            file_name="Knowledge Base Q1 2024",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_upload_csv(self, client: Avido) -> None:
        with client.documents.with_streaming_response.upload_csv(
            file={},
            file_name="Knowledge Base Q1 2024",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True


class TestAsyncDocuments:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
            assignee="user_123456789",
            language="english",
            metadata={"foo": "bar"},
            original_sentences=["This is the first sentence.", "This is the second sentence."],
            scrape_job_id="321e4567-e89b-12d3-a456-426614174000",
            status="DRAFT",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.create(
            content="This document describes the API endpoints...",
            title="API Documentation",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(DocumentResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(DocumentResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.documents.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.list()
        assert_matches_type(AsyncOffsetPagination[DocumentListResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.list(
            assignee="user_123456789",
            end_date=parse_datetime("2024-12-31T23:59:59.999Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            scrape_job_id=["182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e"],
            search="API documentation",
            skip=0,
            start_date=parse_datetime("2024-01-01T00:00:00.000Z"),
            status=["APPROVED"],
            tag_id=["string"],
        )
        assert_matches_type(AsyncOffsetPagination[DocumentListResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(AsyncOffsetPagination[DocumentListResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(AsyncOffsetPagination[DocumentListResponse], document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.documents.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_activate_latest(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.activate_latest(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_activate_latest(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.activate_latest(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_activate_latest(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.activate_latest(
            document_ids=[
                "123e4567-e89b-12d3-a456-426614174000",
                "223e4567-e89b-12d3-a456-426614174001",
                "323e4567-e89b-12d3-a456-426614174002",
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_assign(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.assign(
            id="123e4567-e89b-12d3-a456-426614174000",
            user_id="user_123456789",
        )
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_assign(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.assign(
            id="123e4567-e89b-12d3-a456-426614174000",
            user_id="user_123456789",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(DocumentResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_assign(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.assign(
            id="123e4567-e89b-12d3-a456-426614174000",
            user_id="user_123456789",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(DocumentResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_assign(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.documents.with_raw_response.assign(
                id="",
                user_id="user_123456789",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_count(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.count()
        assert_matches_type(DocumentCountResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_count(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.count()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(DocumentCountResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_count(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.count() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(DocumentCountResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_count_by_assignee(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.count_by_assignee()
        assert_matches_type(DocumentCountByAssigneeResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_count_by_assignee(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.count_by_assignee()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(DocumentCountByAssigneeResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_count_by_assignee(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.count_by_assignee() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(DocumentCountByAssigneeResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete_multiple(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.delete_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete_multiple(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.delete_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete_multiple(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.delete_multiple(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_chunked(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.list_chunked()
        assert_matches_type(AsyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_chunked_with_all_params(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.list_chunked(
            document_id="123e4567-e89b-12d3-a456-426614174000",
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            status="APPROVED",
            version_id="321e4567-e89b-12d3-a456-426614174001",
        )
        assert_matches_type(AsyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_chunked(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.list_chunked()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(AsyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_chunked(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.list_chunked() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(AsyncOffsetPagination[DocumentListChunkedResponse], document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_ids(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.list_ids()
        assert_matches_type(DocumentListIDsResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_ids_with_all_params(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.list_ids(
            scrape_job_id=["182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e"],
            search="API documentation",
            status=["APPROVED"],
            tag_id=["string"],
        )
        assert_matches_type(DocumentListIDsResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_ids(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.list_ids()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(DocumentListIDsResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_ids(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.list_ids() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(DocumentListIDsResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_optimize_doc(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.optimize_doc(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_optimize_doc(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.optimize_doc(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_optimize_doc(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.optimize_doc(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_optimize_doc(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.documents.with_raw_response.optimize_doc(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_status(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.update_status(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            status="APPROVED",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update_status(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.update_status(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            status="APPROVED",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update_status(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.update_status(
            document_ids=["123e4567-e89b-12d3-a456-426614174000", "223e4567-e89b-12d3-a456-426614174001"],
            status="APPROVED",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_upload_csv(self, async_client: AsyncAvido) -> None:
        document = await async_client.documents.upload_csv(
            file={},
            file_name="Knowledge Base Q1 2024",
        )
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_upload_csv(self, async_client: AsyncAvido) -> None:
        response = await async_client.documents.with_raw_response.upload_csv(
            file={},
            file_name="Knowledge Base Q1 2024",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert document is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_upload_csv(self, async_client: AsyncAvido) -> None:
        async with async_client.documents.with_streaming_response.upload_csv(
            file={},
            file_name="Knowledge Base Q1 2024",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert document is None

        assert cast(Any, response.is_closed) is True
