# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from avido.types import (
    ReportOutput,
    ReportResponse,
    ReportingQueryResponse,
)
from tests.utils import assert_matches_type
from avido._utils import parse_datetime
from avido.pagination import SyncOffsetPagination, AsyncOffsetPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestReporting:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Avido) -> None:
        reporting = client.reporting.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Avido) -> None:
        reporting = client.reporting.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
            assignee="user_789012",
            query={
                "datasource": "task",
                "timezone": "America/New_York",
                "filters": [
                    {
                        "column": "type",
                        "operator": "eq",
                        "type": "string",
                        "value": ["STATIC"],
                    }
                ],
                "group_by": [
                    {
                        "column": "type",
                        "type": "string",
                    },
                    {
                        "column": "createdAt",
                        "date_trunc": "month",
                        "type": "date",
                    },
                ],
                "measurements": [
                    {
                        "type": "count",
                        "alias": "average_score",
                        "column": "score",
                    },
                    {
                        "type": "avg",
                        "alias": "average_score",
                        "column": "score",
                    },
                ],
                "order_by": [
                    {
                        "column": "createdAt",
                        "direction": "desc",
                    },
                    {
                        "column": "count",
                        "direction": "asc",
                    },
                ],
            },
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Avido) -> None:
        response = client.reporting.with_raw_response.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = response.parse()
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Avido) -> None:
        with client.reporting.with_streaming_response.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = response.parse()
            assert_matches_type(ReportResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Avido) -> None:
        reporting = client.reporting.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Avido) -> None:
        response = client.reporting.with_raw_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = response.parse()
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Avido) -> None:
        with client.reporting.with_streaming_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = response.parse()
            assert_matches_type(ReportResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.reporting.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Avido) -> None:
        reporting = client.reporting.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Avido) -> None:
        reporting = client.reporting.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            assignee="user_345678",
            description="Updated analysis including new metrics",
            query={
                "datasource": "task",
                "timezone": "America/New_York",
                "filters": [
                    {
                        "column": "type",
                        "operator": "eq",
                        "type": "string",
                        "value": ["STATIC"],
                    }
                ],
                "group_by": [
                    {
                        "column": "type",
                        "type": "string",
                    },
                    {
                        "column": "createdAt",
                        "date_trunc": "month",
                        "type": "date",
                    },
                ],
                "measurements": [
                    {
                        "type": "count",
                        "alias": "average_score",
                        "column": "score",
                    },
                    {
                        "type": "avg",
                        "alias": "average_score",
                        "column": "score",
                    },
                ],
                "order_by": [
                    {
                        "column": "createdAt",
                        "direction": "desc",
                    },
                    {
                        "column": "count",
                        "direction": "asc",
                    },
                ],
            },
            title="Q1 2025 Performance Report",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Avido) -> None:
        response = client.reporting.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = response.parse()
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Avido) -> None:
        with client.reporting.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = response.parse()
            assert_matches_type(ReportResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.reporting.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        reporting = client.reporting.list()
        assert_matches_type(SyncOffsetPagination[ReportOutput], reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Avido) -> None:
        reporting = client.reporting.list(
            assignee="user_789012",
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            start=parse_datetime("2025-01-01T00:00:00Z"),
        )
        assert_matches_type(SyncOffsetPagination[ReportOutput], reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.reporting.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = response.parse()
        assert_matches_type(SyncOffsetPagination[ReportOutput], reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.reporting.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = response.parse()
            assert_matches_type(SyncOffsetPagination[ReportOutput], reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Avido) -> None:
        reporting = client.reporting.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert reporting is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Avido) -> None:
        response = client.reporting.with_raw_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = response.parse()
        assert reporting is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Avido) -> None:
        with client.reporting.with_streaming_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = response.parse()
            assert reporting is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.reporting.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_query(self, client: Avido) -> None:
        reporting = client.reporting.query(
            datasource="task",
            timezone="America/New_York",
        )
        assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_query_with_all_params(self, client: Avido) -> None:
        reporting = client.reporting.query(
            datasource="task",
            timezone="America/New_York",
            filters=[
                {
                    "column": "type",
                    "operator": "eq",
                    "type": "string",
                    "value": ["STATIC"],
                }
            ],
            group_by=[
                {
                    "column": "type",
                    "type": "string",
                },
                {
                    "column": "createdAt",
                    "date_trunc": "month",
                    "type": "date",
                },
            ],
            limit=25,
            measurements=[
                {
                    "type": "count",
                    "alias": "average_score",
                    "column": "score",
                },
                {
                    "type": "avg",
                    "alias": "average_score",
                    "column": "score",
                },
            ],
            order_by=[
                {
                    "column": "createdAt",
                    "direction": "desc",
                },
                {
                    "column": "count",
                    "direction": "asc",
                },
            ],
            skip=0,
        )
        assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_query(self, client: Avido) -> None:
        response = client.reporting.with_raw_response.query(
            datasource="task",
            timezone="America/New_York",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = response.parse()
        assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_query(self, client: Avido) -> None:
        with client.reporting.with_streaming_response.query(
            datasource="task",
            timezone="America/New_York",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = response.parse()
            assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncReporting:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
            assignee="user_789012",
            query={
                "datasource": "task",
                "timezone": "America/New_York",
                "filters": [
                    {
                        "column": "type",
                        "operator": "eq",
                        "type": "string",
                        "value": ["STATIC"],
                    }
                ],
                "group_by": [
                    {
                        "column": "type",
                        "type": "string",
                    },
                    {
                        "column": "createdAt",
                        "date_trunc": "month",
                        "type": "date",
                    },
                ],
                "measurements": [
                    {
                        "type": "count",
                        "alias": "average_score",
                        "column": "score",
                    },
                    {
                        "type": "avg",
                        "alias": "average_score",
                        "column": "score",
                    },
                ],
                "order_by": [
                    {
                        "column": "createdAt",
                        "direction": "desc",
                    },
                    {
                        "column": "count",
                        "direction": "asc",
                    },
                ],
            },
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.with_raw_response.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = await response.parse()
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.with_streaming_response.create(
            description="Comprehensive analysis of AI model performance for December 2024",
            title="Monthly Performance Report",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = await response.parse()
            assert_matches_type(ReportResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.with_raw_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = await response.parse()
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.with_streaming_response.retrieve(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = await response.parse()
            assert_matches_type(ReportResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.reporting.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.update(
            id="123e4567-e89b-12d3-a456-426614174000",
            assignee="user_345678",
            description="Updated analysis including new metrics",
            query={
                "datasource": "task",
                "timezone": "America/New_York",
                "filters": [
                    {
                        "column": "type",
                        "operator": "eq",
                        "type": "string",
                        "value": ["STATIC"],
                    }
                ],
                "group_by": [
                    {
                        "column": "type",
                        "type": "string",
                    },
                    {
                        "column": "createdAt",
                        "date_trunc": "month",
                        "type": "date",
                    },
                ],
                "measurements": [
                    {
                        "type": "count",
                        "alias": "average_score",
                        "column": "score",
                    },
                    {
                        "type": "avg",
                        "alias": "average_score",
                        "column": "score",
                    },
                ],
                "order_by": [
                    {
                        "column": "createdAt",
                        "direction": "desc",
                    },
                    {
                        "column": "count",
                        "direction": "asc",
                    },
                ],
            },
            title="Q1 2025 Performance Report",
        )
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.with_raw_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = await response.parse()
        assert_matches_type(ReportResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.with_streaming_response.update(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = await response.parse()
            assert_matches_type(ReportResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.reporting.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.list()
        assert_matches_type(AsyncOffsetPagination[ReportOutput], reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.list(
            assignee="user_789012",
            end=parse_datetime("2025-01-31T23:59:59Z"),
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
            start=parse_datetime("2025-01-01T00:00:00Z"),
        )
        assert_matches_type(AsyncOffsetPagination[ReportOutput], reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = await response.parse()
        assert_matches_type(AsyncOffsetPagination[ReportOutput], reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = await response.parse()
            assert_matches_type(AsyncOffsetPagination[ReportOutput], reporting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )
        assert reporting is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.with_raw_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = await response.parse()
        assert reporting is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.with_streaming_response.delete(
            "123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = await response.parse()
            assert reporting is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.reporting.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_query(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.query(
            datasource="task",
            timezone="America/New_York",
        )
        assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_query_with_all_params(self, async_client: AsyncAvido) -> None:
        reporting = await async_client.reporting.query(
            datasource="task",
            timezone="America/New_York",
            filters=[
                {
                    "column": "type",
                    "operator": "eq",
                    "type": "string",
                    "value": ["STATIC"],
                }
            ],
            group_by=[
                {
                    "column": "type",
                    "type": "string",
                },
                {
                    "column": "createdAt",
                    "date_trunc": "month",
                    "type": "date",
                },
            ],
            limit=25,
            measurements=[
                {
                    "type": "count",
                    "alias": "average_score",
                    "column": "score",
                },
                {
                    "type": "avg",
                    "alias": "average_score",
                    "column": "score",
                },
            ],
            order_by=[
                {
                    "column": "createdAt",
                    "direction": "desc",
                },
                {
                    "column": "count",
                    "direction": "asc",
                },
            ],
            skip=0,
        )
        assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_query(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.with_raw_response.query(
            datasource="task",
            timezone="America/New_York",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        reporting = await response.parse()
        assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_query(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.with_streaming_response.query(
            datasource="task",
            timezone="America/New_York",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            reporting = await response.parse()
            assert_matches_type(ReportingQueryResponse, reporting, path=["response"])

        assert cast(Any, response.is_closed) is True
