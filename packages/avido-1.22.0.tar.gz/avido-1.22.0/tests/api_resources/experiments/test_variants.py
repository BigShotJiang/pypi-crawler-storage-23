# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from tests.utils import assert_matches_type
from avido.pagination import SyncOffsetPagination, AsyncOffsetPagination
from avido.types.experiments import (
    ExperimentVariant,
    ExperimentVariantOutput,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestVariants:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Avido) -> None:
        variant = client.experiments.variants.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Avido) -> None:
        variant = client.experiments.variants.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
            description="Adjust temperature and top_p",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            title="Variant A",
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Avido) -> None:
        response = client.experiments.variants.with_raw_response.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = response.parse()
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Avido) -> None:
        with client.experiments.variants.with_streaming_response.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = response.parse()
            assert_matches_type(ExperimentVariant, variant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_create(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.experiments.variants.with_raw_response.create(
                id="",
                config_patch={"llm": {"temperature": "bar"}},
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Avido) -> None:
        variant = client.experiments.variants.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Avido) -> None:
        variant = client.experiments.variants.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
            description="Tweaked temperature and top_p",
            status="REJECTED",
            title="Improved Variant",
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Avido) -> None:
        response = client.experiments.variants.with_raw_response.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = response.parse()
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Avido) -> None:
        with client.experiments.variants.with_streaming_response.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = response.parse()
            assert_matches_type(ExperimentVariant, variant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.experiments.variants.with_raw_response.update(
                variant_id="321e4567-e89b-12d3-a456-426614174000",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `variant_id` but received ''"):
            client.experiments.variants.with_raw_response.update(
                variant_id="",
                id="123e4567-e89b-12d3-a456-426614174000",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        variant = client.experiments.variants.list(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(SyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Avido) -> None:
        variant = client.experiments.variants.list(
            id="123e4567-e89b-12d3-a456-426614174000",
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
        )
        assert_matches_type(SyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.experiments.variants.with_raw_response.list(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = response.parse()
        assert_matches_type(SyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.experiments.variants.with_streaming_response.list(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = response.parse()
            assert_matches_type(SyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.experiments.variants.with_raw_response.list(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_trigger(self, client: Avido) -> None:
        variant = client.experiments.variants.trigger(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert variant is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_trigger(self, client: Avido) -> None:
        response = client.experiments.variants.with_raw_response.trigger(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = response.parse()
        assert variant is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_trigger(self, client: Avido) -> None:
        with client.experiments.variants.with_streaming_response.trigger(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = response.parse()
            assert variant is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_trigger(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.experiments.variants.with_raw_response.trigger(
                variant_id="321e4567-e89b-12d3-a456-426614174000",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `variant_id` but received ''"):
            client.experiments.variants.with_raw_response.trigger(
                variant_id="",
                id="123e4567-e89b-12d3-a456-426614174000",
            )


class TestAsyncVariants:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncAvido) -> None:
        variant = await async_client.experiments.variants.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncAvido) -> None:
        variant = await async_client.experiments.variants.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
            description="Adjust temperature and top_p",
            parent_id="123e4567-e89b-12d3-a456-426614174000",
            title="Variant A",
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncAvido) -> None:
        response = await async_client.experiments.variants.with_raw_response.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = await response.parse()
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncAvido) -> None:
        async with async_client.experiments.variants.with_streaming_response.create(
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = await response.parse()
            assert_matches_type(ExperimentVariant, variant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_create(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.experiments.variants.with_raw_response.create(
                id="",
                config_patch={"llm": {"temperature": "bar"}},
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncAvido) -> None:
        variant = await async_client.experiments.variants.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncAvido) -> None:
        variant = await async_client.experiments.variants.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
            config_patch={"llm": {"temperature": "bar"}},
            description="Tweaked temperature and top_p",
            status="REJECTED",
            title="Improved Variant",
        )
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncAvido) -> None:
        response = await async_client.experiments.variants.with_raw_response.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = await response.parse()
        assert_matches_type(ExperimentVariant, variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncAvido) -> None:
        async with async_client.experiments.variants.with_streaming_response.update(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = await response.parse()
            assert_matches_type(ExperimentVariant, variant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.experiments.variants.with_raw_response.update(
                variant_id="321e4567-e89b-12d3-a456-426614174000",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `variant_id` but received ''"):
            await async_client.experiments.variants.with_raw_response.update(
                variant_id="",
                id="123e4567-e89b-12d3-a456-426614174000",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        variant = await async_client.experiments.variants.list(
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert_matches_type(AsyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncAvido) -> None:
        variant = await async_client.experiments.variants.list(
            id="123e4567-e89b-12d3-a456-426614174000",
            limit=25,
            order_by="createdAt",
            order_dir="desc",
            skip=0,
        )
        assert_matches_type(AsyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.experiments.variants.with_raw_response.list(
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = await response.parse()
        assert_matches_type(AsyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.experiments.variants.with_streaming_response.list(
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = await response.parse()
            assert_matches_type(AsyncOffsetPagination[ExperimentVariantOutput], variant, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.experiments.variants.with_raw_response.list(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_trigger(self, async_client: AsyncAvido) -> None:
        variant = await async_client.experiments.variants.trigger(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )
        assert variant is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_trigger(self, async_client: AsyncAvido) -> None:
        response = await async_client.experiments.variants.with_raw_response.trigger(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        variant = await response.parse()
        assert variant is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_trigger(self, async_client: AsyncAvido) -> None:
        async with async_client.experiments.variants.with_streaming_response.trigger(
            variant_id="321e4567-e89b-12d3-a456-426614174000",
            id="123e4567-e89b-12d3-a456-426614174000",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            variant = await response.parse()
            assert variant is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_trigger(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.experiments.variants.with_raw_response.trigger(
                variant_id="321e4567-e89b-12d3-a456-426614174000",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `variant_id` but received ''"):
            await async_client.experiments.variants.with_raw_response.trigger(
                variant_id="",
                id="123e4567-e89b-12d3-a456-426614174000",
            )
