# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from avido import Avido, AsyncAvido
from tests.utils import assert_matches_type
from avido.types.reporting.datasources import (
    ColumnListResponse,
    ColumnValuesResponse,
    ColumnContextAwareResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestColumns:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Avido) -> None:
        column = client.reporting.datasources.columns.list(
            "task",
        )
        assert_matches_type(ColumnListResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Avido) -> None:
        response = client.reporting.datasources.columns.with_raw_response.list(
            "task",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column = response.parse()
        assert_matches_type(ColumnListResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Avido) -> None:
        with client.reporting.datasources.columns.with_streaming_response.list(
            "task",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column = response.parse()
            assert_matches_type(ColumnListResponse, column, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_context_aware(self, client: Avido) -> None:
        column = client.reporting.datasources.columns.context_aware(
            id="task",
            intent="filters",
        )
        assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_context_aware_with_all_params(self, client: Avido) -> None:
        column = client.reporting.datasources.columns.context_aware(
            id="task",
            intent="filters",
            filters=[
                {
                    "column": "type",
                    "operator": "eq",
                    "type": "string",
                    "value": ["STATIC", "NORMAL"],
                }
            ],
            group_by=[
                {
                    "column": "type",
                    "type": "string",
                }
            ],
            measurements=[
                {
                    "type": "avg",
                    "alias": "average_score",
                    "column": "score",
                }
            ],
        )
        assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_context_aware(self, client: Avido) -> None:
        response = client.reporting.datasources.columns.with_raw_response.context_aware(
            id="task",
            intent="filters",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column = response.parse()
        assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_context_aware(self, client: Avido) -> None:
        with client.reporting.datasources.columns.with_streaming_response.context_aware(
            id="task",
            intent="filters",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column = response.parse()
            assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_values(self, client: Avido) -> None:
        column = client.reporting.datasources.columns.values(
            column_id="status",
            id="task",
        )
        assert_matches_type(ColumnValuesResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_values(self, client: Avido) -> None:
        response = client.reporting.datasources.columns.with_raw_response.values(
            column_id="status",
            id="task",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column = response.parse()
        assert_matches_type(ColumnValuesResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_values(self, client: Avido) -> None:
        with client.reporting.datasources.columns.with_streaming_response.values(
            column_id="status",
            id="task",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column = response.parse()
            assert_matches_type(ColumnValuesResponse, column, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_values(self, client: Avido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `column_id` but received ''"):
            client.reporting.datasources.columns.with_raw_response.values(
                column_id="",
                id="task",
            )


class TestAsyncColumns:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncAvido) -> None:
        column = await async_client.reporting.datasources.columns.list(
            "task",
        )
        assert_matches_type(ColumnListResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.datasources.columns.with_raw_response.list(
            "task",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column = await response.parse()
        assert_matches_type(ColumnListResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.datasources.columns.with_streaming_response.list(
            "task",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column = await response.parse()
            assert_matches_type(ColumnListResponse, column, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_context_aware(self, async_client: AsyncAvido) -> None:
        column = await async_client.reporting.datasources.columns.context_aware(
            id="task",
            intent="filters",
        )
        assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_context_aware_with_all_params(self, async_client: AsyncAvido) -> None:
        column = await async_client.reporting.datasources.columns.context_aware(
            id="task",
            intent="filters",
            filters=[
                {
                    "column": "type",
                    "operator": "eq",
                    "type": "string",
                    "value": ["STATIC", "NORMAL"],
                }
            ],
            group_by=[
                {
                    "column": "type",
                    "type": "string",
                }
            ],
            measurements=[
                {
                    "type": "avg",
                    "alias": "average_score",
                    "column": "score",
                }
            ],
        )
        assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_context_aware(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.datasources.columns.with_raw_response.context_aware(
            id="task",
            intent="filters",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column = await response.parse()
        assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_context_aware(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.datasources.columns.with_streaming_response.context_aware(
            id="task",
            intent="filters",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column = await response.parse()
            assert_matches_type(ColumnContextAwareResponse, column, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_values(self, async_client: AsyncAvido) -> None:
        column = await async_client.reporting.datasources.columns.values(
            column_id="status",
            id="task",
        )
        assert_matches_type(ColumnValuesResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_values(self, async_client: AsyncAvido) -> None:
        response = await async_client.reporting.datasources.columns.with_raw_response.values(
            column_id="status",
            id="task",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column = await response.parse()
        assert_matches_type(ColumnValuesResponse, column, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_values(self, async_client: AsyncAvido) -> None:
        async with async_client.reporting.datasources.columns.with_streaming_response.values(
            column_id="status",
            id="task",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column = await response.parse()
            assert_matches_type(ColumnValuesResponse, column, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_values(self, async_client: AsyncAvido) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `column_id` but received ''"):
            await async_client.reporting.datasources.columns.with_raw_response.values(
                column_id="",
                id="task",
            )
