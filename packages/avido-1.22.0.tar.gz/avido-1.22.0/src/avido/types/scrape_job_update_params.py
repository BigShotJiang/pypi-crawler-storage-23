# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Required, TypedDict

from .scrape_job_status import ScrapeJobStatus

__all__ = ["ScrapeJobUpdateParams", "Page"]


class ScrapeJobUpdateParams(TypedDict, total=False):
    name: str
    """The new name/title of the scrape job"""

    pages: Optional[Iterable[Page]]
    """Array of page URLs to update"""

    status: ScrapeJobStatus
    """The status of the scrape job"""


class Page(TypedDict, total=False):
    url: Required[str]
    """The URL of the page"""

    category: str
    """The category of the page"""

    description: str
    """The description of the page"""

    title: str
    """The title of the page"""
