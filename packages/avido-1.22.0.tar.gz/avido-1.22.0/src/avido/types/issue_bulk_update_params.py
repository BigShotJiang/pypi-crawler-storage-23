# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .issue_status import IssueStatus
from .issue_priority import IssuePriority

__all__ = ["IssueBulkUpdateParams"]


class IssueBulkUpdateParams(TypedDict, total=False):
    issue_ids: Required[Annotated[SequenceNotStr[str], PropertyInfo(alias="issueIds")]]
    """Array of issue IDs to update. Maximum 100 issues per request."""

    assigned_to: Annotated[Optional[str], PropertyInfo(alias="assignedTo")]
    """User ID to assign all issues to, or null to unassign.

    User must be a valid organization member and not banned.
    """

    comment: str
    """Optional comment to add when updating issues.

    Typically used when resolving or dismissing issues to provide context.
    """

    priority: IssuePriority
    """Updated priority level to apply to all specified issues"""

    status: IssueStatus
    """Updated status to apply to all specified issues"""
