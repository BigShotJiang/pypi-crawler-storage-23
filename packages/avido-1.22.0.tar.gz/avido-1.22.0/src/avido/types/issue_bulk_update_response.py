# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .issue_output import IssueOutput

__all__ = ["IssueBulkUpdateResponse"]


class IssueBulkUpdateResponse(BaseModel):
    """Successful response containing updated issues with assigned user info"""

    data: List[IssueOutput]
