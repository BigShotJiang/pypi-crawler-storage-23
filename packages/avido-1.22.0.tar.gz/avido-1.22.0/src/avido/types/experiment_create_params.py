# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["ExperimentCreateParams"]


class ExperimentCreateParams(TypedDict, total=False):
    description: Required[str]
    """The experiment description"""

    title: Required[str]
    """The title of the experiment"""

    assignee: str
    """User ID of the person assigned to this experiment"""

    inference_step_ids: Annotated[SequenceNotStr[str], PropertyInfo(alias="inferenceStepIds")]
    """List of inference step ids used in the experiment"""

    task_ids: Annotated[SequenceNotStr[str], PropertyInfo(alias="taskIds")]
    """List of task ids used in the experiment"""
