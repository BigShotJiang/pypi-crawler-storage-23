# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = [
    "OtelIngestTracesParams",
    "ResourceSpan",
    "ResourceSpanResource",
    "ResourceSpanScopeSpan",
    "ResourceSpanScopeSpanScope",
    "ResourceSpanScopeSpanSpan",
    "ResourceSpanScopeSpanSpanStatus",
]


class OtelIngestTracesParams(TypedDict, total=False):
    resource_spans: Annotated[Iterable[ResourceSpan], PropertyInfo(alias="resourceSpans")]


class ResourceSpanResource(TypedDict, total=False):
    attributes: Iterable["OtlpAttributeParam"]


class ResourceSpanScopeSpanScope(TypedDict, total=False):
    name: str

    version: str


class ResourceSpanScopeSpanSpanStatus(TypedDict, total=False):
    code: int

    message: str


class ResourceSpanScopeSpanSpan(TypedDict, total=False):
    """
    OpenTelemetry Protocol span representing a unit of work with timing, attributes, and status. Trace IDs must be 32 hex characters, span IDs must be 16 hex characters.
    """

    end_time_unix_nano: Required[Annotated[Union[str, float], PropertyInfo(alias="endTimeUnixNano")]]

    name: Required[str]

    span_id: Required[Annotated[str, PropertyInfo(alias="spanId")]]

    start_time_unix_nano: Required[Annotated[Union[str, float], PropertyInfo(alias="startTimeUnixNano")]]

    trace_id: Required[Annotated[str, PropertyInfo(alias="traceId")]]

    attributes: Iterable["OtlpAttributeParam"]

    kind: int

    parent_span_id: Annotated[str, PropertyInfo(alias="parentSpanId")]

    status: ResourceSpanScopeSpanSpanStatus


class ResourceSpanScopeSpan(TypedDict, total=False):
    """
    OpenTelemetry Protocol scope span containing instrumentation scope metadata and associated spans.
    """

    scope: ResourceSpanScopeSpanScope

    spans: Iterable[ResourceSpanScopeSpanSpan]


class ResourceSpan(TypedDict, total=False):
    """
    OpenTelemetry Protocol resource span containing resource attributes and scope spans.
    """

    resource: ResourceSpanResource

    scope_spans: Annotated[Iterable[ResourceSpanScopeSpan], PropertyInfo(alias="scopeSpans")]


from .otlp_attribute_param import OtlpAttributeParam
