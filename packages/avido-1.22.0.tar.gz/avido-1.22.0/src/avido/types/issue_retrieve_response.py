# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .grouped_issue_output import GroupedIssueOutput

__all__ = ["IssueRetrieveResponse"]


class IssueRetrieveResponse(BaseModel):
    """Successful response containing the issue data with its duplicate/child issues"""

    data: GroupedIssueOutput
