# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["DocumentVersionOutput"]


class DocumentVersionOutput(BaseModel):
    """A specific version of a document with its content and metadata"""

    id: str
    """Unique identifier of the document version"""

    content: str
    """Content of the document version"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the document version was created"""

    document_id: str = FieldInfo(alias="documentId")
    """ID of the document this version belongs to"""

    language: str
    """Language of the document version"""

    metadata: Dict[str, object]
    """Optional metadata associated with the document version"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the document version was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this document version"""

    original_sentences: List[str] = FieldInfo(alias="originalSentences")
    """Array of original sentences from the source"""

    status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]
    """Status of the document.

    Valid options: DRAFT, REVIEW, APPROVED, ARCHIVED, ACTIVE.
    """

    title: str
    """Title of the document version"""

    version_number: int = FieldInfo(alias="versionNumber")
    """Version number of this document version"""
