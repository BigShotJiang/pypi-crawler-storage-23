# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from ..document_output import DocumentOutput
from .document_version_output import DocumentVersionOutput

__all__ = ["VersionActivateResponse"]


class VersionActivateResponse(BaseModel):
    """Response after activating a document version"""

    document: DocumentOutput

    new_active_version: DocumentVersionOutput = FieldInfo(alias="newActiveVersion")
    """A specific version of a document with its content and metadata"""
