# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from .document_test_type import DocumentTestType
from .document_test_status import DocumentTestStatus

__all__ = [
    "DocumentTestOutput",
    "Results",
    "ResultsDocumentKnowledgeCoverageTestResultsOutput",
    "ResultsDocumentKnowledgeCoverageTestResultsOutputResult",
    "ResultsDocumentKnowledgeCoverageTestResultsOutputResultTask",
    "ResultsDocumentMeceTestResultsOutput",
    "ResultsDocumentMeceTestResultsOutputResult",
    "ResultsDocumentMeceTestResultsOutputResultContradiction",
    "ResultsDocumentMeceTestResultsOutputResultDocument",
    "ResultsDocumentMeceTestResultsOutputResultOverlap",
    "ResultsDocsToTasksMappingResultsOutput",
    "ResultsDocsToTasksMappingResultsOutputOrphanedDocumentsList",
    "ResultsDocsToTasksMappingResultsOutputOrphanedTasksList",
    "ResultsDocsToTasksMappingResultsOutputResult",
    "ResultsDocsToTasksMappingResultsOutputResultDocument",
    "ResultsDocsToTasksMappingResultsOutputResultMappedTask",
]


class ResultsDocumentKnowledgeCoverageTestResultsOutputResultTask(BaseModel):
    """The task that was tested"""

    id: str
    """The ID of the task"""

    description: str
    """The description of the task"""

    title: str
    """The title of the task"""


class ResultsDocumentKnowledgeCoverageTestResultsOutputResult(BaseModel):
    coverage: float
    """The coverage of the task"""

    documents: List[str]
    """The titles of the documents that were retrieved"""

    reasoning: str
    """The reasoning for the coverage assessment"""

    task: ResultsDocumentKnowledgeCoverageTestResultsOutputResultTask
    """The task that was tested"""


class ResultsDocumentKnowledgeCoverageTestResultsOutput(BaseModel):
    results: List[ResultsDocumentKnowledgeCoverageTestResultsOutputResult]

    score: float
    """The score of the document test"""


class ResultsDocumentMeceTestResultsOutputResultContradiction(BaseModel):
    contradicting_document_id: str
    """The ID of the contradicting document"""

    contradicting_document_title: str
    """The title of the contradicting document"""

    passage_a: str
    """The passage content from the current document"""

    passage_b: str
    """The passage content from the contradicting location"""

    reason: str
    """Explanation of the contradiction"""


class ResultsDocumentMeceTestResultsOutputResultDocument(BaseModel):
    id: str
    """The ID of the document"""

    name: str
    """The name of the document"""


class ResultsDocumentMeceTestResultsOutputResultOverlap(BaseModel):
    id: str
    """The ID of the overlapping document"""

    overlap_score: float
    """The overlap score contribution for this document"""

    title: str
    """The title of the overlapping document"""


class ResultsDocumentMeceTestResultsOutputResult(BaseModel):
    contradiction_count: int
    """The total number of contradictions found"""

    contradictions: List[ResultsDocumentMeceTestResultsOutputResultContradiction]
    """Contradictions found (both inter-document and intra-document)"""

    document: ResultsDocumentMeceTestResultsOutputResultDocument

    overlap_score: float
    """The overlap score of the document"""

    overlaps: List[ResultsDocumentMeceTestResultsOutputResultOverlap]
    """Overlapping documents contributing to the overlap score"""


class ResultsDocumentMeceTestResultsOutput(BaseModel):
    mean_contradictions: float
    """The mean contradiction score of the documents"""

    mean_overlap: float
    """The mean overlap score of the documents"""

    results: List[ResultsDocumentMeceTestResultsOutputResult]


class ResultsDocsToTasksMappingResultsOutputOrphanedDocumentsList(BaseModel):
    id: str
    """The ID of the document"""

    name: str
    """The name of the document"""


class ResultsDocsToTasksMappingResultsOutputOrphanedTasksList(BaseModel):
    id: str
    """The ID of the task"""

    description: str
    """The description of the task"""

    title: str
    """The title of the task"""


class ResultsDocsToTasksMappingResultsOutputResultDocument(BaseModel):
    """The document that was mapped to tasks"""

    id: str
    """The ID of the document"""

    name: str
    """The name of the document"""


class ResultsDocsToTasksMappingResultsOutputResultMappedTask(BaseModel):
    id: str
    """The ID of the task"""

    description: str
    """The description of the task"""

    title: str
    """The title of the task"""


class ResultsDocsToTasksMappingResultsOutputResult(BaseModel):
    document: ResultsDocsToTasksMappingResultsOutputResultDocument
    """The document that was mapped to tasks"""

    mapped_tasks: Optional[List[ResultsDocsToTasksMappingResultsOutputResultMappedTask]] = None
    """The mapped tasks"""


class ResultsDocsToTasksMappingResultsOutput(BaseModel):
    orphaned_documents: int
    """The number of orphaned documents"""

    orphaned_documents_list: List[ResultsDocsToTasksMappingResultsOutputOrphanedDocumentsList]
    """The list of orphaned documents"""

    orphaned_tasks: int
    """The number of orphaned tasks"""

    orphaned_tasks_list: List[ResultsDocsToTasksMappingResultsOutputOrphanedTasksList]
    """The list of orphaned tasks"""

    results: List[ResultsDocsToTasksMappingResultsOutputResult]

    total_documents: int
    """The total number of documents"""

    total_tasks: int
    """The total number of tasks"""


Results: TypeAlias = Union[
    ResultsDocumentKnowledgeCoverageTestResultsOutput,
    ResultsDocumentMeceTestResultsOutput,
    ResultsDocsToTasksMappingResultsOutput,
]


class DocumentTestOutput(BaseModel):
    """
    A document test execution for evaluating knowledge base quality (MECE, Coverage, etc.)
    """

    id: str
    """Unique identifier of the document test"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the document test was created"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the document test was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this document test"""

    status: DocumentTestStatus
    """Status of the test execution"""

    type: DocumentTestType
    """Type of document test"""

    results: Optional[Results] = None
    """
    Test results, structure depends on test type (KNOWLEDGE_COVERAGE, MECE, or
    DOCS_TO_TASKS_MAPPING)
    """
