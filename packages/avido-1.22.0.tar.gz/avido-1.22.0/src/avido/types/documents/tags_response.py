# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..._models import BaseModel
from ..tag_output import TagOutput

__all__ = ["TagsResponse"]


class TagsResponse(BaseModel):
    """Successful response containing tags"""

    data: List[TagOutput]
