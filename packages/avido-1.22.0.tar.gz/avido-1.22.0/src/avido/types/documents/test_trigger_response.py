# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel
from .document_test_output import DocumentTestOutput

__all__ = ["TestTriggerResponse"]


class TestTriggerResponse(BaseModel):
    __test__ = False
    """Successful response containing document test data"""
    data: DocumentTestOutput
    """
    A document test execution for evaluating knowledge base quality (MECE, Coverage,
    etc.)
    """
