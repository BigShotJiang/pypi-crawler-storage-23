# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, Annotated, TypedDict

from ..._types import SequenceNotStr
from ..._utils import PropertyInfo

__all__ = ["VersionUpdateParams"]


class VersionUpdateParams(TypedDict, total=False):
    id: Required[str]
    """The unique identifier of the document"""

    content: str
    """Updated content for the version"""

    language: str
    """Language of the initial document version"""

    metadata: Dict[str, object]
    """Updated metadata for the version"""

    original_sentences: Annotated[SequenceNotStr[str], PropertyInfo(alias="originalSentences")]
    """Updated array of original sentences from the source"""

    status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]
    """Updated status for the version"""

    title: str
    """Updated title for the version"""
