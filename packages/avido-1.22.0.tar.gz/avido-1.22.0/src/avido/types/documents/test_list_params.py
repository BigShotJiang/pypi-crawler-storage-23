# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Literal, Annotated, TypedDict

from ..._utils import PropertyInfo
from .document_test_type import DocumentTestType
from .document_test_status import DocumentTestStatus

__all__ = ["TestListParams"]


class TestListParams(TypedDict, total=False):
    end: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """End date (ISO8601) for filtering document tests by creation date"""

    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Field to order by in the result set."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    start: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """Start date (ISO8601) for filtering document tests by creation date"""

    status: DocumentTestStatus
    """Filter by test status"""

    type: DocumentTestType
    """Filter by test type"""
