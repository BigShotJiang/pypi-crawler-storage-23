# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .document_test_type import DocumentTestType

__all__ = ["TestTriggerParams"]


class TestTriggerParams(TypedDict, total=False):
    type: Required[DocumentTestType]
    """Type of document test"""
