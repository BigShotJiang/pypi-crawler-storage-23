# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from ..scrape_job_output import ScrapeJobOutput
from .document_version_output import DocumentVersionOutput

__all__ = ["DocumentVersionResponse", "Document"]


class Document(BaseModel):
    """
    A Core Document represents a piece of content that can be organized hierarchically with parent-child relationships and supports versioning
    """

    id: str
    """Unique identifier of the document"""

    assignee: str
    """User ID of the person assigned to this document"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the document was created"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the document was last modified"""

    optimized: bool
    """Whether the document has been optimized"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this document"""

    scrape_job: Optional[ScrapeJobOutput] = FieldInfo(alias="scrapeJob", default=None)
    """Optional scrape job that generated this document"""

    scrape_job_id: Optional[str] = FieldInfo(alias="scrapeJobId", default=None)
    """Optional ID of the scrape job that generated this document"""


class DocumentVersionResponse(BaseModel):
    """Response containing a specific document version"""

    document: Document
    """
    A Core Document represents a piece of content that can be organized
    hierarchically with parent-child relationships and supports versioning
    """

    version: DocumentVersionOutput
    """A specific version of a document with its content and metadata"""
