# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["DocumentTestType"]

DocumentTestType: TypeAlias = Literal["KNOWLEDGE_COVERAGE", "MECE", "DOCS_TO_TASKS_MAPPING"]
