# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["QuickstartConfirmStyleScoresResponse", "Data"]


class Data(BaseModel):
    application_id: str = FieldInfo(alias="applicationId")
    """The application ID associated with the quickstart"""

    quickstart_id: str = FieldInfo(alias="quickstartId")
    """The confirmed quickstart ID"""


class QuickstartConfirmStyleScoresResponse(BaseModel):
    """
    Response schema for confirming style scores and triggering quickstart completion
    """

    data: Data
