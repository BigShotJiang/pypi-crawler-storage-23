# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["ReportingColumnMetadataOutput"]


class ReportingColumnMetadataOutput(BaseModel):
    """Metadata about a column in a datasource"""

    id: str
    """Column identifier"""

    name: str
    """Column name"""

    type: Literal["string", "number", "date", "boolean"]
    """Column data type"""
