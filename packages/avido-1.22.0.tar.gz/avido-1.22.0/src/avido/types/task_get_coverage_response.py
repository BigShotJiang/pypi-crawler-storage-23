# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["TaskGetCoverageResponse"]


class TaskGetCoverageResponse(BaseModel):
    """Response containing task coverage statistics"""

    task_count: int = FieldInfo(alias="taskCount")
    """The total number of active tasks"""

    task_coverage: float = FieldInfo(alias="taskCoverage")
    """
    The percentage of active tasks that have at least one test run in the given date
    range
    """

    task_with_test_count: int = FieldInfo(alias="taskWithTestCount")
    """
    The number of active tasks that have at least one test run in the given date
    range
    """
