# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo
from .issue_type import IssueType
from .issue_source import IssueSource
from .issue_status import IssueStatus
from .issue_priority import IssuePriority

__all__ = ["IssueListParams"]


class IssueListParams(TypedDict, total=False):
    annotation_id: Annotated[str, PropertyInfo(alias="annotationId")]
    """Filter by associated annotation ID"""

    assigned_to: Annotated[str, PropertyInfo(alias="assignedTo")]
    """Filter by assignee user ID"""

    end: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """End date (ISO8601) for filtering issues by creation date"""

    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Field to order by in the result set."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    priority: IssuePriority
    """Filter by issue priority"""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    source: IssueSource
    """Filter by issue source"""

    start: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """Start date (ISO8601) for filtering issues by creation date"""

    status: IssueStatus
    """Filter by issue status"""

    test_id: Annotated[str, PropertyInfo(alias="testId")]
    """Filter by associated test ID"""

    type: IssueType
    """Filter by issue type"""
