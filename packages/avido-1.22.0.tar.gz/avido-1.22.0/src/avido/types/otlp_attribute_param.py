# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["OtlpAttributeParam", "Value", "ValueArrayValue", "ValueArrayValueValue", "ValueKvlistValue"]


class ValueArrayValueValue(TypedDict, total=False):
    """
    OpenTelemetry Protocol attribute value that can be a string, integer, double, or boolean.
    """

    bool_value: Annotated[bool, PropertyInfo(alias="boolValue")]

    double_value: Annotated[float, PropertyInfo(alias="doubleValue")]

    int_value: Annotated[float, PropertyInfo(alias="intValue")]

    string_value: Annotated[str, PropertyInfo(alias="stringValue")]


class ValueArrayValue(TypedDict, total=False):
    values: Required[Iterable[ValueArrayValueValue]]


class ValueKvlistValue(TypedDict, total=False):
    values: Required[Iterable["OtlpAttributeParam"]]


class Value(TypedDict, total=False):
    array_value: Annotated[ValueArrayValue, PropertyInfo(alias="arrayValue")]

    bool_value: Annotated[bool, PropertyInfo(alias="boolValue")]

    double_value: Annotated[float, PropertyInfo(alias="doubleValue")]

    int_value: Annotated[float, PropertyInfo(alias="intValue")]

    kvlist_value: Annotated[ValueKvlistValue, PropertyInfo(alias="kvlistValue")]

    string_value: Annotated[str, PropertyInfo(alias="stringValue")]


class OtlpAttributeParam(TypedDict, total=False):
    """OpenTelemetry Protocol attribute with key-value structure.

    Values can be primitives, arrays, or nested key-value lists. Maximum nesting depth: 5 levels.
    """

    key: Required[str]

    value: Required[Value]
