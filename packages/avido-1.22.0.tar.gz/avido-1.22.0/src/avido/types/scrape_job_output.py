# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .scrape_job_status import ScrapeJobStatus

__all__ = ["ScrapeJobOutput", "Page"]


class Page(BaseModel):
    url: str
    """The URL of the page"""

    category: Optional[str] = None
    """The category of the page"""

    description: Optional[str] = None
    """The description of the page"""

    title: Optional[str] = None
    """The title of the page"""


class ScrapeJobOutput(BaseModel):
    """A scrape job for extracting content from a website"""

    id: str
    """The unique identifier of the scrape job"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the scrape job was created"""

    initiated_by: str = FieldInfo(alias="initiatedBy")
    """User ID who initiated the scrape job"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the scrape job was last modified"""

    name: str
    """The name/title of the scrape job"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns the scrape job"""

    status: ScrapeJobStatus
    """Current status of the scrape job"""

    url: str
    """The URL that was scraped"""

    pages: Optional[List[Page]] = None
    """The pages scraped from the URL"""
