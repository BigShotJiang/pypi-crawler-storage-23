# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["WebhookTestResponse"]


class WebhookTestResponse(BaseModel):
    """Response indicating whether the webhook test was successful"""

    success: bool
    """Whether the webhook test was successful"""

    error: Optional[str] = None
    """Error message if the webhook test failed"""

    status_code: Optional[int] = FieldInfo(alias="statusCode", default=None)
    """HTTP status code returned by the webhook endpoint"""
