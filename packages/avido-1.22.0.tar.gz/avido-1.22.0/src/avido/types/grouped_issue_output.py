# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .issue_type import IssueType
from .issue_output import IssueOutput
from .issue_source import IssueSource
from .issue_status import IssueStatus
from .issue_priority import IssuePriority
from .assigned_user_info import AssignedUserInfo

__all__ = ["GroupedIssueOutput"]


class GroupedIssueOutput(BaseModel):
    id: str
    """Unique identifier of the issue"""

    application_id: str = FieldInfo(alias="applicationId")
    """The application this issue belongs to"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the issue was created"""

    issues: List[IssueOutput]
    """list of sub issues"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the issue was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this issue"""

    priority: IssuePriority
    """Priority level of the issue"""

    source: IssueSource
    """Where the issue originated from"""

    status: IssueStatus
    """Current status of the issue"""

    title: str
    """Title of the issue"""

    type: IssueType
    """Type/category of the issue"""

    annotation_id: Optional[str] = FieldInfo(alias="annotationId", default=None)
    """Associated annotation ID if related to an annotation"""

    assigned_to: Optional[str] = FieldInfo(alias="assignedTo", default=None)
    """User ID of the person assigned to this issue"""

    assigned_user: Optional[AssignedUserInfo] = FieldInfo(alias="assignedUser", default=None)
    """Full information about the assigned user"""

    comment: Optional[str] = None
    """Optional comment explaining resolution or dismissal"""

    description: Optional[str] = None
    """Detailed description of the issue"""

    eval_definition_id: Optional[str] = FieldInfo(alias="evalDefinitionId", default=None)
    """Associated evaluation definition ID if issue came from an evaluation"""

    has_suggested_task: Optional[bool] = FieldInfo(alias="hasSuggestedTask", default=None)
    """Whether this issue has an associated suggested task in draft status.

    True if the issue has a taskId and the task's status is DRAFT and the issue type
    is SUGGESTED_TASK.
    """

    impact: Optional[str] = None
    """Detailed impact of the issue"""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent issue ID for sub-issues"""

    summary: Optional[str] = None
    """Detailed summary of the issue"""

    task_id: Optional[str] = FieldInfo(alias="taskId", default=None)
    """Associated task ID if issue came from a task"""

    test_id: Optional[str] = FieldInfo(alias="testId", default=None)
    """Associated test ID if issue came from a test"""

    topic_id: Optional[str] = FieldInfo(alias="topicId", default=None)
    """Associated topic ID if issue came from a topic"""

    trace_id: Optional[str] = FieldInfo(alias="traceId", default=None)
    """Associated trace ID for monitoring/debugging"""
