# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .run_type import RunType
from .experiments.run_result_output import RunResultOutput

__all__ = ["RunOutput"]


class RunOutput(BaseModel):
    """A Run represents a batch of tests triggered by a single task"""

    id: str
    """Unique identifier of the run"""

    application_id: str = FieldInfo(alias="applicationId")
    """The ID of the application this test belongs to"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the run was created"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the run was last modified"""

    type: RunType

    experiment_variant_id: Optional[str] = FieldInfo(alias="experimentVariantId", default=None)
    """Optional ID of the experiment variant this run belongs to"""

    result: Optional[RunResultOutput] = None
    """Aggregated run result with pass/fail statistics and average score"""
