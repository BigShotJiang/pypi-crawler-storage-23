# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .eval_output import EvalOutput
from .test_result_output import TestResultOutput

__all__ = ["TestRetrieveResponse", "Test"]


class Test(BaseModel):
    __test__ = False
    """A Test represents a single test applying all the linked evals on a Trace"""
    id: str
    """Unique identifier of the run"""

    application_id: str = FieldInfo(alias="applicationId")
    """The ID of the application this test belongs to"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the test was created"""

    evals: List[EvalOutput]
    """Array of evaluations in this run"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the test was last modified"""

    run_id: str = FieldInfo(alias="runId")
    """The unique identifier of the run"""

    status: Literal["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED"]
    """Status of the evaluation/test"""

    task_id: str = FieldInfo(alias="taskId")
    """The unique identifier of the task"""

    result: Optional[TestResultOutput] = None
    """Aggregated test result with pass/fail statistics"""


class TestRetrieveResponse(BaseModel):
    __test__ = False
    test: Test
    """A Test represents a single test applying all the linked evals on a Trace"""
