# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["StyleGuideSectionOutput"]


class StyleGuideSectionOutput(BaseModel):
    """A section for a style guide"""

    approved: bool
    """Whether or not the section has been approved"""

    content: str
    """The content of the section in markdown"""

    heading: str
    """The heading of the section"""
