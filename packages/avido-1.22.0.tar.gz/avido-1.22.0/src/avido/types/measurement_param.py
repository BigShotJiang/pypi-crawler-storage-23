# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .measurement_type import MeasurementType

__all__ = ["MeasurementParam"]


class MeasurementParam(TypedDict, total=False):
    """Measurement/aggregation specification for GROUP BY queries.

    Count measures all records, while avg/sum/min/max measure specific numeric/boolean columns.
    """

    type: Required[MeasurementType]
    """Type of measurement to perform"""

    alias: str
    """
    Optional alias for the measurement in results (defaults to type_column or
    'count')
    """

    column: str
    """Column to measure (required for avg/sum/min/max, not used for count)"""
