# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["WebhookRetrieveResponse", "Data"]


class Data(BaseModel):
    """Webhook configuration for an application"""

    id: str
    """The unique identifier for the webhook"""

    application_id: str = FieldInfo(alias="applicationId")
    """The ID of the application this webhook belongs to"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the webhook was created"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the webhook was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """The organization ID this webhook belongs to"""

    url: str
    """The URL where webhook events will be sent"""

    webhook_secret: str = FieldInfo(alias="webhookSecret")
    """The secret used to sign webhook payloads"""


class WebhookRetrieveResponse(BaseModel):
    """Response containing a webhook configuration or null"""

    data: Optional[Data] = None
    """Webhook configuration for an application"""
