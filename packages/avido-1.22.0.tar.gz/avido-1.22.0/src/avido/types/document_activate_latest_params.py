# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["DocumentActivateLatestParams"]


class DocumentActivateLatestParams(TypedDict, total=False):
    document_ids: Required[Annotated[SequenceNotStr[str], PropertyInfo(alias="documentIds")]]
    """Array of document IDs to activate their latest versions.

    Maximum 100 documents per request.
    """
