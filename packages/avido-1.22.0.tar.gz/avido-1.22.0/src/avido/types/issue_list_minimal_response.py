# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .issue_source import IssueSource
from .issue_status import IssueStatus
from .issue_priority import IssuePriority
from .assigned_user_info import AssignedUserInfo

__all__ = ["IssueListMinimalResponse"]


class IssueListMinimalResponse(BaseModel):
    """Lightweight issue representation with essential fields and assigned user info"""

    id: str
    """Unique identifier of the issue"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the issue was created"""

    priority: IssuePriority
    """Priority level of the issue"""

    source: IssueSource
    """Where the issue originated from"""

    status: IssueStatus
    """Current status of the issue"""

    title: str
    """Title of the issue"""

    assigned_to: Optional[str] = FieldInfo(alias="assignedTo", default=None)
    """User ID of the person assigned to this issue"""

    assigned_user: Optional[AssignedUserInfo] = FieldInfo(alias="assignedUser", default=None)
    """Full information about the assigned user"""
