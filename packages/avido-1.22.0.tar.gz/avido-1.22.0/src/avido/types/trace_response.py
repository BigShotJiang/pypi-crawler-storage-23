# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .trace_output import TraceOutput

__all__ = ["TraceResponse"]


class TraceResponse(BaseModel):
    """Successful response containing a single trace object"""

    data: TraceOutput
    """A trace grouping related steps (e.g. a user-agent interaction or conversation)."""
