# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["QuickstartUpdateStyleGuideSectionParams"]


class QuickstartUpdateStyleGuideSectionParams(TypedDict, total=False):
    approved: Required[bool]
    """Whether or not the section has been approved"""

    content: Required[str]
    """The content of the section in markdown"""

    heading: Required[str]
    """The heading of the section"""

    quickstart_id: Required[Annotated[str, PropertyInfo(alias="quickstartId")]]
    """The ID of the quickstart containing the style guide"""

    section_index: Required[Annotated[int, PropertyInfo(alias="sectionIndex")]]
    """The zero-based index of the section to update"""
