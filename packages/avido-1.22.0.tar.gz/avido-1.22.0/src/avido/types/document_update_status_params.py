# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["DocumentUpdateStatusParams"]


class DocumentUpdateStatusParams(TypedDict, total=False):
    document_ids: Required[Annotated[SequenceNotStr[str], PropertyInfo(alias="documentIds")]]
    """Array of document IDs to update status. Maximum 100 documents per request."""

    status: Required[Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]]
    """The new status to apply to all specified documents"""
