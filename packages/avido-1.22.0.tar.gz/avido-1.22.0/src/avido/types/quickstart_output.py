# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .style_guide_section_output import StyleGuideSectionOutput

__all__ = [
    "QuickstartOutput",
    "Conversations",
    "ConversationsMetadata",
    "ConversationsTopic",
    "ConversationsTopicMetadata",
    "ConversationsTopicTask",
    "ConversationsTopicTaskConversation",
    "StyleGuide",
]


class ConversationsMetadata(BaseModel):
    conversations: int
    """The number of conversations in the quickstart"""

    initial_baseline: float = FieldInfo(alias="initialBaseline")
    """The initial baseline score from 1-5"""

    tasks: int
    """The number of tasks in the quickstart"""

    topics: int
    """The number of topics in the quickstart"""


class ConversationsTopicMetadata(BaseModel):
    conversations: int
    """The number of conversations in the topic"""

    tasks: int
    """The number of tasks in the topic"""


class ConversationsTopicTaskConversation(BaseModel):
    id: str
    """A unique ID for the conversation"""

    analysis: str
    """
    A brief explanation for your rating, referring to specific aspects of the
    response and the query. Make sure that the explanation is formatted as markdown,
    and that it is easy to read and understand.
    """

    input: str
    """The user's question to the agent"""

    output: str
    """The agent's response to the user"""

    score: float
    """Naturalness score calculated as an average of the 5 metrics"""

    style_analysis: Optional[str] = FieldInfo(alias="styleAnalysis", default=None)
    """
    A brief explanation for your rating, referring to specific aspects of the
    response and the query. Make sure that the explanation is formatted as markdown,
    and that it is easy to read and understand.
    """

    style_score: Optional[float] = FieldInfo(alias="styleScore", default=None)
    """Style score"""


class ConversationsTopicTask(BaseModel):
    conversations: List[ConversationsTopicTaskConversation]
    """A list of the conversations for this task and topic combination"""

    description: str
    """
    The description of the task in the format 'The user wants to block their credit
    card' if the user wants to block their credit card
    """

    title: str
    """
    The title of the task describing what the user wants in the format 'Block Credit
    Card' if the user wants to block their credit card
    """


class ConversationsTopic(BaseModel):
    baseline: float
    """The baseline score from 1-5"""

    metadata: ConversationsTopicMetadata

    name: str
    """
    The topic of the evaluation case, indicating the general category for the user's
    request
    """

    tasks: List[ConversationsTopicTask]

    style_benchmark: Optional[float] = FieldInfo(alias="styleBenchmark", default=None)
    """The baseline score from 1-5"""


class Conversations(BaseModel):
    metadata: ConversationsMetadata

    topics: List[ConversationsTopic]
    """A list of the topics covered in the quickstart"""


class StyleGuide(BaseModel):
    name: str

    related_quickstart: str = FieldInfo(alias="relatedQuickstart")

    sections: List[StyleGuideSectionOutput]


class QuickstartOutput(BaseModel):
    """A quickstart is a set of conversations that can be used to test a style guide"""

    id: str
    """A unique ID for the quickstart"""

    conversations: Conversations

    created_at: datetime = FieldInfo(alias="createdAt")

    modified_at: datetime = FieldInfo(alias="modifiedAt")

    name: str
    """The name of the quickstart"""

    status: Literal[
        "PENDING",
        "IN_PROGRESS",
        "BASELINE_REVIEW",
        "AWAITING_STYLE_REVIEW",
        "REVIEWING_STYLE",
        "AWAITING_STYLE_CONFIRMATION",
        "AWAITING_VOTING",
        "COMPLETED",
        "FAILED",
    ]

    style_guide: Optional[StyleGuide] = FieldInfo(alias="styleGuide", default=None)
