# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DocumentCountResponse"]


class DocumentCountResponse(BaseModel):
    """Response containing total and active document counts"""

    active_version_count: int = FieldInfo(alias="activeVersionCount")
    """Number of documents that currently have an active version"""

    total_count: int = FieldInfo(alias="totalCount")
    """Total number of documents in the organization"""
