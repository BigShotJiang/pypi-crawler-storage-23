# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["CoreTag"]


class CoreTag(BaseModel):
    id: str
    """Unique identifier of the tag"""

    color: str
    """Hex color code for the tag"""

    name: str
    """Name of the tag"""
