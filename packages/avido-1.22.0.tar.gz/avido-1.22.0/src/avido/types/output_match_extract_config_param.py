# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Required, TypedDict

__all__ = ["OutputMatchExtractConfigParam"]


class OutputMatchExtractConfigParam(TypedDict, total=False):
    flags: Required[str]

    group: Required[Union[int, Iterable[int]]]

    pattern: Required[str]
