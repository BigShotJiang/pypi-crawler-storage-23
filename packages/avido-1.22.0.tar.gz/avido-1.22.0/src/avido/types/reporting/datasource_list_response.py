# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..._models import BaseModel
from .datasources.reporting_query_datasource import ReportingQueryDatasource

__all__ = ["DatasourceListResponse", "Data"]


class Data(BaseModel):
    """A reporting datasource with id and display name"""

    id: ReportingQueryDatasource
    """Datasource identifier"""

    name: str
    """Human-readable datasource name"""


class DatasourceListResponse(BaseModel):
    """Response containing list of available datasources"""

    data: List[Data]
    """List of available reporting datasources"""
