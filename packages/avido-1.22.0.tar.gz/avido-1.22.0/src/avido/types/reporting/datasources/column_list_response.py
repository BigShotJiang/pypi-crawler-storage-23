# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from ...._models import BaseModel
from .reporting_query_datasource import ReportingQueryDatasource
from ...reporting_column_metadata_output import ReportingColumnMetadataOutput

__all__ = ["ColumnListResponse", "Data"]


class Data(BaseModel):
    """Metadata about a reporting datasource"""

    columns: List[ReportingColumnMetadataOutput]
    """List of whitelisted columns for this datasource"""

    datasource: ReportingQueryDatasource
    """Datasource name"""

    is_org_level: bool = FieldInfo(alias="isOrgLevel")
    """Whether this datasource is scoped to organization (true) or application (false)"""


class ColumnListResponse(BaseModel):
    """Response containing datasource column metadata"""

    data: Data
    """Metadata about a reporting datasource"""
