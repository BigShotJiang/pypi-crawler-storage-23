# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Required, Annotated, TypedDict

from ...._utils import PropertyInfo
from ...measurement_param import MeasurementParam
from ...reporting_query_filter_param import ReportingQueryFilterParam
from .reporting_columns_intent_schema import ReportingColumnsIntentSchema
from ...reporting_query_group_by_param import ReportingQueryGroupByParam

__all__ = ["ColumnContextAwareParams"]


class ColumnContextAwareParams(TypedDict, total=False):
    intent: Required[ReportingColumnsIntentSchema]
    """Intent for which columns are needed"""

    filters: Iterable[ReportingQueryFilterParam]
    """Current filters applied (used for context when intent is orderBy)"""

    group_by: Annotated[Iterable[ReportingQueryGroupByParam], PropertyInfo(alias="groupBy")]
    """
    Current groupBy clauses (required when intent is orderBy to determine available
    sort columns)
    """

    measurements: Iterable[MeasurementParam]
    """
    Current measurements (required when intent is orderBy to include measurement
    aliases as sortable columns)
    """
