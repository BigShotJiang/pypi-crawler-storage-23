# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ...._models import BaseModel
from .reporting_query_datasource import ReportingQueryDatasource
from .reporting_columns_intent_schema import ReportingColumnsIntentSchema
from ...reporting_column_metadata_output import ReportingColumnMetadataOutput

__all__ = ["ColumnContextAwareResponse", "Data"]


class Data(BaseModel):
    columns: List[ReportingColumnMetadataOutput]
    """Available columns based on the intent and current query context"""

    datasource: ReportingQueryDatasource

    intent: ReportingColumnsIntentSchema
    """
    Intent for which columns are being requested: filters (all filterable columns),
    groupBy (groupable columns), measurements (columns available for aggregation),
    orderBy (columns that can be used for sorting based on current query context)
    """


class ColumnContextAwareResponse(BaseModel):
    """Response containing context-aware columns for the specified intent"""

    data: Data
