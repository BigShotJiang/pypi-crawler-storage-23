# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ...._models import BaseModel

__all__ = ["ColumnValuesResponse", "Data"]


class Data(BaseModel):
    """A distinct value from a datasource column with id and display name.

    Can be null for optional fields.
    """

    id: str
    """Value identifier"""

    name: str
    """Human-readable value name"""


class ColumnValuesResponse(BaseModel):
    """Response containing distinct column values"""

    data: List[Data]
    """List of distinct values for the column"""
