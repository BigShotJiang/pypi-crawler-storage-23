# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["DocumentListIDsResponse"]


class DocumentListIDsResponse(BaseModel):
    """Response containing all document IDs without pagination"""

    document_ids: List[str] = FieldInfo(alias="documentIds")
    """Array of all document IDs matching the filter criteria"""
