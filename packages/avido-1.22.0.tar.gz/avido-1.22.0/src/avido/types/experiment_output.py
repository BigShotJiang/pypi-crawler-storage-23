# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .experiment_status import ExperimentStatus

__all__ = ["ExperimentOutput"]


class ExperimentOutput(BaseModel):
    id: str
    """The unique identifier of the experiment"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the experiment was created"""

    description: str
    """The experiment description"""

    inference_step_ids: List[str] = FieldInfo(alias="inferenceStepIds")
    """List of inference step ids used in the experiment"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the experiment was last modified"""

    status: ExperimentStatus

    task_ids: List[str] = FieldInfo(alias="taskIds")
    """List of task ids used in the experiment"""

    title: str
    """The title of the experiment"""

    assignee: Optional[str] = None
    """User ID of the person assigned to this experiment"""
