# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["AssignedUserInfo"]


class AssignedUserInfo(BaseModel):
    """Information about the user assigned to an issue"""

    id: str
    """User ID"""

    email: str
    """User email"""

    name: str
    """User full name"""

    image: Optional[str] = None
    """User profile image URL"""
