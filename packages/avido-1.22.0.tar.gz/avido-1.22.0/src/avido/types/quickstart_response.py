# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .quickstart_output import QuickstartOutput

__all__ = ["QuickstartResponse"]


class QuickstartResponse(BaseModel):
    """Response schema for a single quickstart"""

    data: QuickstartOutput
    """A quickstart is a set of conversations that can be used to test a style guide"""
