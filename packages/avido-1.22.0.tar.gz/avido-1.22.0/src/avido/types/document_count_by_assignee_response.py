# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel

__all__ = ["DocumentCountByAssigneeResponse", "Data"]


class Data(BaseModel):
    """Document count grouped by assignee"""

    assignee: Optional[str] = None
    """Assignee user ID for the grouped documents"""

    count: int
    """Number of documents assigned to this assignee"""


class DocumentCountByAssigneeResponse(BaseModel):
    """Response containing document counts grouped by assignee"""

    data: List[Data]
