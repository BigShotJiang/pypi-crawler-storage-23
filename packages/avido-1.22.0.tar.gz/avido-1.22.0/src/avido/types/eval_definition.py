# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .eval_definition_output import EvalDefinitionOutput

__all__ = ["EvalDefinition"]


class EvalDefinition(BaseModel):
    """Response containing an eval definition"""

    data: EvalDefinitionOutput
