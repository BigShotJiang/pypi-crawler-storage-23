# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .inference_step_type import InferenceStepType

__all__ = ["InferenceStepOutput"]


class InferenceStepOutput(BaseModel):
    id: str
    """The unique identifier of the inference step"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the variant was created"""

    description: str
    """The inference step description"""

    external_id: str = FieldInfo(alias="externalId")
    """identifier used in the ai application"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the variant was last modified"""

    title: str
    """The title of the inference step"""

    type: InferenceStepType
    """The type of the inference step"""
