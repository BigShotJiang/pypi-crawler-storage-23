# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["TagOutput"]


class TagOutput(BaseModel):
    """A tag that can be applied to documents for organization"""

    id: str
    """Unique identifier of the tag"""

    color: str
    """Hex color code for the tag"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the tag was created"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the tag was last modified"""

    name: str
    """Name of the tag"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this tag"""

    description: Optional[str] = None
    """Optional description of the tag"""
