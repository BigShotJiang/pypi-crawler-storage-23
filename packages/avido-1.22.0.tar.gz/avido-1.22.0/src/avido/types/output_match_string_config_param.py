# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

from .output_match_extract_config_param import OutputMatchExtractConfigParam

__all__ = ["OutputMatchStringConfigParam"]


class OutputMatchStringConfigParam(TypedDict, total=False):
    type: Required[Literal["string"]]

    extract: OutputMatchExtractConfigParam
