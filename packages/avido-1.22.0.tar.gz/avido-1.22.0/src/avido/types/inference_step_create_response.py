# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .inference_step_output import InferenceStepOutput

__all__ = ["InferenceStepCreateResponse"]


class InferenceStepCreateResponse(BaseModel):
    """Response containing a single inference step"""

    data: InferenceStepOutput
