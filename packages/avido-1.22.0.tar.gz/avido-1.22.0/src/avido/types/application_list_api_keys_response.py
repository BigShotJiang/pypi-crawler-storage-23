# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ApplicationListAPIKeysResponse", "Data"]


class Data(BaseModel):
    """API key for application authentication"""

    id: str
    """Unique identifier of the API key"""

    application_id: str = FieldInfo(alias="applicationId")
    """ID of the application this API key belongs to"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the API key was created"""

    key_id: str = FieldInfo(alias="keyId")
    """The API key id value"""

    name: str
    """Name/description of the API key"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """When the API key was last updated"""


class ApplicationListAPIKeysResponse(BaseModel):
    """Response containing a list of API keys"""

    data: List[Data]
    """Array of API keys"""
