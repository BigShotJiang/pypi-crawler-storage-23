# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .report_output import ReportOutput

__all__ = ["ReportResponse"]


class ReportResponse(BaseModel):
    """Successful response containing the report data"""

    data: ReportOutput
    """A report for tracking and analyzing AI application performance"""
