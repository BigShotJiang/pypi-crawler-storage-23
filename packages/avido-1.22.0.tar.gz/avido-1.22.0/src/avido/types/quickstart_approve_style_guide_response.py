# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["QuickstartApproveStyleGuideResponse", "Data"]


class Data(BaseModel):
    application_id: str = FieldInfo(alias="applicationId")
    """The application ID associated with the quickstart"""

    quickstart_id: str = FieldInfo(alias="quickstartId")
    """The approved quickstart ID"""

    style_guide_id: str = FieldInfo(alias="styleGuideId")
    """The created style guide ID"""


class QuickstartApproveStyleGuideResponse(BaseModel):
    """
    Response schema for approving a quickstart style guide and creating a style guide record
    """

    data: Data
