# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .._utils import PropertyInfo
from .._models import BaseModel
from .date_filter_unit import DateFilterUnit
from .measurement_type import MeasurementType
from .date_filter_preset_value import DateFilterPresetValue
from .reporting_query_date_trunc import ReportingQueryDateTrunc
from .reporting.datasources.reporting_query_datasource import ReportingQueryDatasource

__all__ = [
    "ReportOutput",
    "Query",
    "QueryFilter",
    "QueryFilterReportingQueryStringFilterOutput",
    "QueryFilterReportingQueryNumberFilterOutput",
    "QueryFilterReportingQueryBooleanFilterOutput",
    "QueryFilterReportingQueryDateFilterOutput",
    "QueryFilterReportingQueryDateFilterOutputDateFilter",
    "QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterRangeOutput",
    "QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterPresetOutput",
    "QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterRelativeOutput",
    "QueryGroupBy",
    "QueryGroupByReportingQueryGroupByBase",
    "QueryGroupByReportingQueryGroupByDate",
    "QueryMeasurement",
    "QueryOrderBy",
]


class QueryFilterReportingQueryStringFilterOutput(BaseModel):
    """Filter for string columns using eq/neq operators"""

    column: str
    """Column name to filter on (must be a string column in the datasource)"""

    operator: Literal["eq", "neq"]
    """Filter operator for string values"""

    type: Literal["string"]
    """Filter type for string columns"""

    value: List[str]
    """Array of string values to filter by"""


class QueryFilterReportingQueryNumberFilterOutput(BaseModel):
    """Filter for numeric columns using eq/neq/lt/gt/lte/gte operators"""

    column: str
    """Column name to filter on (must be a numeric column in the datasource)"""

    operator: Literal["eq", "neq", "lt", "gt", "lte", "gte"]
    """Filter operator for numeric values"""

    type: Literal["number"]
    """Filter type for numeric columns"""

    value: List[float]
    """
    Array of numeric values to filter by (for comparison operators, only first value
    is used)
    """


class QueryFilterReportingQueryBooleanFilterOutput(BaseModel):
    """Filter for boolean columns using eq operator with single value"""

    column: str
    """Column name to filter on (must be a boolean column in the datasource)"""

    operator: Literal["eq"]
    """Filter operator for boolean values"""

    type: Literal["boolean"]
    """Filter type for boolean columns"""

    value: bool
    """Boolean value to filter by"""


class QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterRangeOutput(BaseModel):
    """Absolute date range with optional from/to boundaries.

    from is inclusive, to is exclusive.
    """

    type: Literal["range"]
    """Absolute date range with explicit boundaries"""

    from_: Optional[datetime] = FieldInfo(alias="from", default=None)
    """Inclusive start boundary (ISO8601). Omit for open-ended range."""

    to: Optional[datetime] = None
    """Exclusive end boundary (ISO8601). Omit for open-ended range."""


class QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterPresetOutput(BaseModel):
    """
    Preset date range that expands to concrete dates at query time (e.g., thisQuarter, last30Days)
    """

    preset: DateFilterPresetValue
    """Preset date range that expands to concrete dates at query time"""

    type: Literal["preset"]
    """Preset date range using common shortcuts"""


class QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterRelativeOutput(BaseModel):
    """
    Relative date range using bounded offsets from now (e.g., last 14 days, 2-6 weeks ago)
    """

    from_: int = FieldInfo(alias="from")
    """Starting offset (units ago from now). 0 = now. Must be < to. Defaults to 0."""

    to: int
    """Ending offset (units ago from now). Must be > from. Defaults to 1."""

    type: Literal["relative"]
    """Relative date range using offsets from now"""

    unit: DateFilterUnit
    """Time unit for relative date ranges (day, week, month, quarter, year)"""


QueryFilterReportingQueryDateFilterOutputDateFilter: TypeAlias = Annotated[
    Union[
        QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterRangeOutput,
        QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterPresetOutput,
        QueryFilterReportingQueryDateFilterOutputDateFilterDateFilterRelativeOutput,
    ],
    PropertyInfo(discriminator="type"),
]


class QueryFilterReportingQueryDateFilterOutput(BaseModel):
    """Filter for date columns using date filter (range/preset/relative)"""

    column: str
    """Column name to filter on (must be a date column in the datasource)"""

    date_filter: QueryFilterReportingQueryDateFilterOutputDateFilter = FieldInfo(alias="dateFilter")
    """Date filter supporting absolute ranges, presets, and relative windows"""

    type: Literal["date"]
    """Filter type for date columns"""


QueryFilter: TypeAlias = Annotated[
    Union[
        QueryFilterReportingQueryStringFilterOutput,
        QueryFilterReportingQueryNumberFilterOutput,
        QueryFilterReportingQueryBooleanFilterOutput,
        QueryFilterReportingQueryDateFilterOutput,
    ],
    PropertyInfo(discriminator="type"),
]


class QueryGroupByReportingQueryGroupByBase(BaseModel):
    """Group by specification for non-date columns"""

    column: str
    """Column name to group by (must be whitelisted for datasource)"""

    type: Literal["string", "number", "boolean"]
    """Column type for non-date columns"""


class QueryGroupByReportingQueryGroupByDate(BaseModel):
    """Group by specification for date columns with required truncation"""

    column: str
    """Date column name to group by (must be whitelisted for datasource)"""

    date_trunc: ReportingQueryDateTrunc = FieldInfo(alias="dateTrunc")
    """Required date truncation granularity for date columns"""

    type: Literal["date"]
    """Column type for date columns"""


QueryGroupBy: TypeAlias = Union[QueryGroupByReportingQueryGroupByBase, QueryGroupByReportingQueryGroupByDate]


class QueryMeasurement(BaseModel):
    """Measurement/aggregation specification for GROUP BY queries.

    Count measures all records, while avg/sum/min/max measure specific numeric/boolean columns.
    """

    type: MeasurementType
    """Type of measurement to perform"""

    alias: Optional[str] = None
    """
    Optional alias for the measurement in results (defaults to type_column or
    'count')
    """

    column: Optional[str] = None
    """Column to measure (required for avg/sum/min/max, not used for count)"""


class QueryOrderBy(BaseModel):
    """Order by specification for sorting results.

    Column must be in the SELECT clause (groupBy column or measurement).
    """

    column: str
    """Column name to order by (must be a groupBy column or measurement alias)"""

    direction: Literal["asc", "desc"]
    """Sort order direction (ascending or descending)."""


class Query(BaseModel):
    """
    Optional reporting query configuration defining datasource, filters, groupBy, measurements, and ordering
    """

    datasource: ReportingQueryDatasource
    """Datasource to query"""

    timezone: str
    """
    IANA timezone identifier for date filter resolution (e.g., 'America/New_York',
    'Europe/London', 'UTC')
    """

    filters: Optional[List[QueryFilter]] = None
    """Optional filters to apply to the query.

    Each filter must specify a type (string/number/boolean/date) that matches the
    column type.
    """

    group_by: Optional[List[QueryGroupBy]] = FieldInfo(alias="groupBy", default=None)
    """Optional group by clauses for aggregating results.

    For date columns, dateTrunc is required.
    """

    measurements: Optional[List[QueryMeasurement]] = None
    """Optional measurements/aggregations to compute when using groupBy.

    Defaults to count if not specified. Use avg/sum/min/max for numeric or boolean
    columns.
    """

    order_by: Optional[List[QueryOrderBy]] = FieldInfo(alias="orderBy", default=None)
    """Optional ordering specification.

    If not specified, defaults to ordering by all groupBy columns (with createdAt
    priority) then measurements. For non-groupBy queries, defaults to createdAt
    DESC, id DESC.
    """


class ReportOutput(BaseModel):
    """A report for tracking and analyzing AI application performance"""

    id: str
    """Unique identifier of the report"""

    application_id: str = FieldInfo(alias="applicationId")
    """The application this report belongs to"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the report was created"""

    description: str
    """Detailed description of the report"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the report was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this report"""

    title: str
    """Title of the report"""

    assignee: Optional[str] = None
    """User ID of the person assigned to this report"""

    query: Optional[Query] = None
    """
    Optional reporting query configuration defining datasource, filters, groupBy,
    measurements, and ordering
    """
