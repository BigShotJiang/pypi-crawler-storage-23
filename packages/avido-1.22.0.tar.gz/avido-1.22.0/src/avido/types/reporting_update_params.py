# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

from .reporting_query_param import ReportingQueryParam

__all__ = ["ReportingUpdateParams"]


class ReportingUpdateParams(TypedDict, total=False):
    assignee: Optional[str]
    """Updated assignee user ID (can be set to null to unassign)"""

    description: str
    """Updated description of the report"""

    query: Optional[ReportingQueryParam]
    """
    Reporting query definition with datasource, filters, groupBy, measurements, and
    ordering
    """

    title: str
    """Updated title of the report"""
