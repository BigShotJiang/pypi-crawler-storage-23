# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo
from .issue_type import IssueType
from .issue_status import IssueStatus
from .issue_priority import IssuePriority

__all__ = ["IssueUpdateParams"]


class IssueUpdateParams(TypedDict, total=False):
    annotation_id: Annotated[Optional[str], PropertyInfo(alias="annotationId")]
    """Update associated annotation ID"""

    assigned_to: Annotated[Optional[str], PropertyInfo(alias="assignedTo")]
    """Reassign the issue to a different user"""

    comment: Optional[str]
    """Reason for resolving or dismissing the issue"""

    eval_definition_id: Annotated[Optional[str], PropertyInfo(alias="evalDefinitionId")]
    """Update associated evaluation definition ID"""

    parent_id: Annotated[Optional[str], PropertyInfo(alias="parentId")]
    """Update parent issue ID for sub-issues"""

    priority: IssuePriority
    """Updated priority level"""

    status: IssueStatus
    """Updated status of the issue"""

    summary: Optional[str]
    """Updated summary of the issue"""

    task_id: Annotated[Optional[str], PropertyInfo(alias="taskId")]
    """Update associated task ID"""

    test_id: Annotated[Optional[str], PropertyInfo(alias="testId")]
    """Update associated test ID"""

    title: str
    """Updated title of the issue"""

    topic_id: Annotated[Optional[str], PropertyInfo(alias="topicId")]
    """Update associated topic ID"""

    trace_id: Annotated[Optional[str], PropertyInfo(alias="traceId")]
    """Update associated trace ID"""

    type: IssueType
    """Updated type/category"""
