# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["TaskGetIDsResponse"]


class TaskGetIDsResponse(BaseModel):
    """Response containing an array of task IDs"""

    task_ids: List[str] = FieldInfo(alias="taskIds")
    """Array of task IDs"""
