# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Required, TypedDict

from .style_guide_section_input_param import StyleGuideSectionInputParam

__all__ = ["StyleGuideUpdateParams"]


class StyleGuideUpdateParams(TypedDict, total=False):
    content: Required[Iterable[StyleGuideSectionInputParam]]
