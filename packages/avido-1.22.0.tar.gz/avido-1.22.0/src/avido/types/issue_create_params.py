# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .issue_type import IssueType
from .issue_source import IssueSource
from .issue_priority import IssuePriority

__all__ = ["IssueCreateParams"]


class IssueCreateParams(TypedDict, total=False):
    source: Required[IssueSource]
    """Where the issue originated from"""

    title: Required[str]
    """Title of the issue"""

    annotation_id: Annotated[str, PropertyInfo(alias="annotationId")]
    """Associated annotation ID if related to an annotation"""

    description: Optional[str]
    """Detailed description of the issue"""

    eval_definition_id: Annotated[str, PropertyInfo(alias="evalDefinitionId")]
    """Associated evaluation definition ID if issue came from an evaluation"""

    parent_id: Annotated[str, PropertyInfo(alias="parentId")]
    """Parent issue ID for creating sub-issues"""

    priority: IssuePriority
    """Priority level of the issue"""

    task_id: Annotated[str, PropertyInfo(alias="taskId")]
    """Associated task ID if issue came from a task"""

    test_id: Annotated[str, PropertyInfo(alias="testId")]
    """Associated test ID if issue came from a test"""

    topic_id: Annotated[str, PropertyInfo(alias="topicId")]
    """Associated topic ID if issue came from a topic"""

    trace_id: Annotated[str, PropertyInfo(alias="traceId")]
    """Associated trace ID for monitoring/debugging"""

    type: IssueType
    """Type/category of the issue"""
