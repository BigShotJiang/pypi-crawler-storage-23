# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .reporting_query_param import ReportingQueryParam

__all__ = ["ReportingCreateParams"]


class ReportingCreateParams(TypedDict, total=False):
    description: Required[str]
    """Detailed description of the report"""

    title: Required[str]
    """Title of the report"""

    assignee: str
    """User ID of the person assigned to this report"""

    query: ReportingQueryParam
    """
    Optional reporting query configuration defining datasource, filters, groupBy,
    measurements, and ordering
    """
