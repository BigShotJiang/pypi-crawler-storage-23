# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["TaskUpdateParams"]


class TaskUpdateParams(TypedDict, total=False):
    description: str
    """A short description of the task"""

    input_examples: Annotated[SequenceNotStr[str], PropertyInfo(alias="inputExamples")]
    """Example inputs for the task"""

    metadata: Optional[Dict[str, object]]
    """Replace the existing task metadata.

    Use null to clear all metadata for the task.
    """

    simulated_prompt_schema: Annotated[Optional[Dict[str, object]], PropertyInfo(alias="simulatedPromptSchema")]
    """
    JSON schema that defines the structure for user prompts that should be generated
    for tests
    """

    title: str
    """The title of the task"""

    topic_id: Annotated[Optional[str], PropertyInfo(alias="topicId")]
    """ID of the topic this task belongs to"""
