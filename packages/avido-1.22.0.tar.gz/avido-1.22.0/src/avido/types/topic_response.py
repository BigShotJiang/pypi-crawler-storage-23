# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .topic_output import TopicOutput

__all__ = ["TopicResponse"]


class TopicResponse(BaseModel):
    """Successful response containing the topic data"""

    data: TopicOutput
    """Details about a single Topic"""
