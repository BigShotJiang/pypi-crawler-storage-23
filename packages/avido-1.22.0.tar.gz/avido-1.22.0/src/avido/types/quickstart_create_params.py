# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = [
    "QuickstartCreateParams",
    "Conversations",
    "ConversationsMetadata",
    "ConversationsTopic",
    "ConversationsTopicMetadata",
    "ConversationsTopicTask",
    "ConversationsTopicTaskConversation",
]


class QuickstartCreateParams(TypedDict, total=False):
    conversations: Required[Conversations]

    initiated_by: Required[Annotated[str, PropertyInfo(alias="initiatedBy")]]
    """The user who created the quickstart"""

    name: Required[str]
    """The name of the quickstart"""

    status: Required[
        Literal[
            "PENDING",
            "IN_PROGRESS",
            "BASELINE_REVIEW",
            "AWAITING_STYLE_REVIEW",
            "REVIEWING_STYLE",
            "AWAITING_STYLE_CONFIRMATION",
            "AWAITING_VOTING",
            "COMPLETED",
            "FAILED",
        ]
    ]


class ConversationsMetadata(TypedDict, total=False):
    conversations: Required[int]
    """The number of conversations in the quickstart"""

    initial_baseline: Required[Annotated[float, PropertyInfo(alias="initialBaseline")]]
    """The initial baseline score from 1-5"""

    tasks: Required[int]
    """The number of tasks in the quickstart"""

    topics: Required[int]
    """The number of topics in the quickstart"""


class ConversationsTopicMetadata(TypedDict, total=False):
    conversations: Required[int]
    """The number of conversations in the topic"""

    tasks: Required[int]
    """The number of tasks in the topic"""


class ConversationsTopicTaskConversation(TypedDict, total=False):
    id: Required[str]
    """A unique ID for the conversation"""

    analysis: Required[str]
    """
    A brief explanation for your rating, referring to specific aspects of the
    response and the query. Make sure that the explanation is formatted as markdown,
    and that it is easy to read and understand.
    """

    input: Required[str]
    """The user's question to the agent"""

    output: Required[str]
    """The agent's response to the user"""

    score: Required[float]
    """Naturalness score calculated as an average of the 5 metrics"""

    style_analysis: Annotated[Optional[str], PropertyInfo(alias="styleAnalysis")]
    """
    A brief explanation for your rating, referring to specific aspects of the
    response and the query. Make sure that the explanation is formatted as markdown,
    and that it is easy to read and understand.
    """

    style_score: Annotated[Optional[float], PropertyInfo(alias="styleScore")]
    """Style score"""


class ConversationsTopicTask(TypedDict, total=False):
    conversations: Required[Iterable[ConversationsTopicTaskConversation]]
    """A list of the conversations for this task and topic combination"""

    description: Required[str]
    """
    The description of the task in the format 'The user wants to block their credit
    card' if the user wants to block their credit card
    """

    title: Required[str]
    """
    The title of the task describing what the user wants in the format 'Block Credit
    Card' if the user wants to block their credit card
    """


class ConversationsTopic(TypedDict, total=False):
    baseline: Required[float]
    """The baseline score from 1-5"""

    metadata: Required[ConversationsTopicMetadata]

    name: Required[str]
    """
    The topic of the evaluation case, indicating the general category for the user's
    request
    """

    tasks: Required[Iterable[ConversationsTopicTask]]

    style_benchmark: Annotated[Optional[float], PropertyInfo(alias="styleBenchmark")]
    """The baseline score from 1-5"""


class Conversations(TypedDict, total=False):
    metadata: ConversationsMetadata

    topics: Iterable[ConversationsTopic]
    """A list of the topics covered in the quickstart"""
