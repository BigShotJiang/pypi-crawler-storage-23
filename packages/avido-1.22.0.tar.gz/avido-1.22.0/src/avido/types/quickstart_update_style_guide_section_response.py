# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .quickstart_output import QuickstartOutput

__all__ = ["QuickstartUpdateStyleGuideSectionResponse"]


class QuickstartUpdateStyleGuideSectionResponse(BaseModel):
    """Response schema for updating a quickstart style guide section"""

    data: QuickstartOutput
    """A quickstart is a set of conversations that can be used to test a style guide"""
