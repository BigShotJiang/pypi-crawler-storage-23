# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .issue_output import IssueOutput

__all__ = ["IssueUpdateResponse"]


class IssueUpdateResponse(BaseModel):
    """Successful response containing the issue data"""

    data: IssueOutput
    """An issue tracking problems or improvements in the AI application"""
