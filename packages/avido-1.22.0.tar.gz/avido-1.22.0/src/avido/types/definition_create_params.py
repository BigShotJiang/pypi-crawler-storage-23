# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._utils import PropertyInfo
from .eval_type import EvalType
from .output_match_list_config_param import OutputMatchListConfigParam
from .output_match_string_config_param import OutputMatchStringConfigParam

__all__ = ["DefinitionCreateParams", "GlobalConfig", "GlobalConfigCriterion", "GlobalConfigGroundTruth"]


class DefinitionCreateParams(TypedDict, total=False):
    name: Required[str]

    type: Required[EvalType]

    global_config: Annotated[GlobalConfig, PropertyInfo(alias="globalConfig")]

    style_guide_id: Annotated[str, PropertyInfo(alias="styleGuideId")]


class GlobalConfigCriterion(TypedDict, total=False):
    criterion: Required[str]
    """The criterion describes what our evaluation LLM must look for in the response.

    Remember that the answer to the criterion must be as a pass/fail.
    """


class GlobalConfigGroundTruth(TypedDict, total=False):
    ground_truth: Required[Annotated[str, PropertyInfo(alias="groundTruth")]]
    """
    The ground truth is the most correct answer to the task that we measure the
    response against
    """


GlobalConfig: TypeAlias = Union[
    GlobalConfigCriterion, GlobalConfigGroundTruth, OutputMatchStringConfigParam, OutputMatchListConfigParam
]
