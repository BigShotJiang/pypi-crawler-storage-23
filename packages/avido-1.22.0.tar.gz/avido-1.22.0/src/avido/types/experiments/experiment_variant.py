# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel
from .experiment_variant_output import ExperimentVariantOutput

__all__ = ["ExperimentVariant"]


class ExperimentVariant(BaseModel):
    """Response containing a single experiment variant"""

    data: ExperimentVariantOutput
