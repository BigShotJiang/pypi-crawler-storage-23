# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["VariantCreateParams"]


class VariantCreateParams(TypedDict, total=False):
    config_patch: Required[Annotated[Dict[str, Dict[str, object]], PropertyInfo(alias="configPatch")]]
    """The config patch to apply to the system, entire config if baseline"""

    description: str
    """The variant description"""

    parent_id: Annotated[str, PropertyInfo(alias="parentId")]
    """Parent variant ID for inherited variants (non-baseline variants)"""

    title: str
    """The title of the variant"""
