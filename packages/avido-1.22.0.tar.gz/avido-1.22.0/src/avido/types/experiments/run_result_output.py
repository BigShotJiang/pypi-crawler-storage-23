# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from ..eval_type import EvalType

__all__ = ["RunResultOutput", "Eval"]


class Eval(BaseModel):
    id: str

    average_score: float = FieldInfo(alias="averageScore")

    failed: int

    name: str

    passed: int

    pass_rate: float = FieldInfo(alias="passRate")

    total: int

    type: EvalType


class RunResultOutput(BaseModel):
    average_score: float = FieldInfo(alias="averageScore")

    evals: List[Eval]

    failed: int

    passed: int

    pass_rate: float = FieldInfo(alias="passRate")

    total: int
