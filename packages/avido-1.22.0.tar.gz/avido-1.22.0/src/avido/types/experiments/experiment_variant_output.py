# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from .run_result_output import RunResultOutput

__all__ = ["ExperimentVariantOutput"]


class ExperimentVariantOutput(BaseModel):
    id: str
    """The unique identifier of the variant"""

    config: Dict[str, Dict[str, object]]
    """The config patch to apply to the system, entire config if baseline"""

    config_patch: Dict[str, Dict[str, object]] = FieldInfo(alias="configPatch")
    """The config patch to apply to the system, entire config if baseline"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the variant was created"""

    description: str
    """The experiment description"""

    experiment_id: str = FieldInfo(alias="experimentId")
    """The unique identifier of the experiment"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the variant was last modified"""

    status: Literal["DRAFT", "RUNNING", "COMPLETED", "FAILED", "REJECTED"]

    title: str
    """The title of the experiment"""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent variant ID for inherited variants (non-baseline variants)"""

    result: Optional[RunResultOutput] = None
