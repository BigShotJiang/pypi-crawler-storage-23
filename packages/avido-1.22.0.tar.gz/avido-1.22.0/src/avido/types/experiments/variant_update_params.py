# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["VariantUpdateParams"]


class VariantUpdateParams(TypedDict, total=False):
    id: Required[str]
    """The unique identifier of the experiment"""

    config_patch: Annotated[Dict[str, Dict[str, object]], PropertyInfo(alias="configPatch")]
    """The config patch to apply to the system, entire config if baseline"""

    description: str
    """Updated description of the variant"""

    status: Literal["REJECTED"]

    title: str
    """Updated title of the variant"""
