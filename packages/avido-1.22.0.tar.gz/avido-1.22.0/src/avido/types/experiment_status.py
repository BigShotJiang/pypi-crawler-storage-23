# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["ExperimentStatus"]

ExperimentStatus: TypeAlias = Literal[
    "DRAFT",
    "BASELINE_PENDING",
    "BASELINE_RUNNING",
    "BASELINE_COMPLETED",
    "BASELINE_FAILED",
    "VARIANT_RUNNING",
    "IDLE",
    "COMPLETED",
    "ARCHIVED",
]
