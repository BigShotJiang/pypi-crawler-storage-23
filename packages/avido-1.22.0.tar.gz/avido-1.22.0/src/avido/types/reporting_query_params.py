# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .measurement_param import MeasurementParam
from .reporting_query_filter_param import ReportingQueryFilterParam
from .reporting_query_group_by_param import ReportingQueryGroupByParam
from .reporting.datasources.reporting_query_datasource import ReportingQueryDatasource

__all__ = ["ReportingQueryParams", "OrderBy"]


class ReportingQueryParams(TypedDict, total=False):
    datasource: Required[ReportingQueryDatasource]
    """Datasource to query"""

    timezone: Required[str]
    """
    IANA timezone identifier for date filter resolution (e.g., 'America/New_York',
    'Europe/London', 'UTC')
    """

    filters: Iterable[ReportingQueryFilterParam]
    """Optional filters to apply to the query.

    Each filter must specify a type (string/number/boolean/date) that matches the
    column type.
    """

    group_by: Annotated[Iterable[ReportingQueryGroupByParam], PropertyInfo(alias="groupBy")]
    """Optional group by clauses for aggregating results.

    For date columns, dateTrunc is required.
    """

    limit: int
    """Number of items to include in the result set."""

    measurements: Iterable[MeasurementParam]
    """Optional measurements/aggregations to compute when using groupBy.

    Defaults to count if not specified. Use avg/sum/min/max for numeric or boolean
    columns.
    """

    order_by: Annotated[Iterable[OrderBy], PropertyInfo(alias="orderBy")]
    """Optional ordering specification.

    If not specified, defaults to ordering by all groupBy columns (with createdAt
    priority) then measurements. For non-groupBy queries, defaults to createdAt
    DESC, id DESC.
    """

    skip: int
    """Number of items to skip before starting to collect the result set."""


class OrderBy(TypedDict, total=False):
    """Order by specification for sorting results.

    Column must be in the SELECT clause (groupBy column or measurement).
    """

    column: Required[str]
    """Column name to order by (must be a groupBy column or measurement alias)"""

    direction: Required[Literal["asc", "desc"]]
    """Sort order direction (ascending or descending)."""
