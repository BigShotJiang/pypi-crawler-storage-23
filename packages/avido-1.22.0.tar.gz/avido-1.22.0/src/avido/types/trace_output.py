# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "TraceOutput",
    "Step",
    "StepLlmStartStepOutput",
    "StepLlmEndStepOutput",
    "StepLlmEndStepOutputUsage",
    "StepToolStepOutput",
    "StepRetrieverStepOutput",
    "StepLogStepOutput",
    "StepGroupStepOutput",
    "StepResponseStepOutput",
    "StepRequestStepOutput",
]


class StepLlmStartStepOutput(BaseModel):
    """Start of an LLM trace."""

    id: str
    """UUID for the step."""

    event: Literal["start"]

    input: str
    """JSON input for this LLM trace event (e.g., the prompt)."""

    api_model_id: str = FieldInfo(alias="modelId")
    """Model ID or name used for the LLM call."""

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["llm"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """


class StepLlmEndStepOutputUsage(BaseModel):
    """Number of input and output tokens used by the LLM."""

    completion_tokens: int = FieldInfo(alias="completionTokens")
    """Number of completion tokens used by the LLM."""

    prompt_tokens: int = FieldInfo(alias="promptTokens")
    """Number of prompt tokens used by the LLM."""


class StepLlmEndStepOutput(BaseModel):
    """End of an LLM trace."""

    id: str
    """UUID for the step."""

    event: Literal["end"]

    api_model_id: str = FieldInfo(alias="modelId")
    """Model ID or name used for the LLM call."""

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["llm"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    finish_reason: Optional[str] = FieldInfo(alias="finishReason", default=None)
    """
    The reason the LLM stopped generating, extracted from
    gen_ai.response.finish_reasons.
    """

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    output: Optional[str] = None
    """JSON describing the output.

    String inputs are parsed or wrapped in { message: val }.
    """

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """

    usage: Optional[StepLlmEndStepOutputUsage] = None
    """Number of input and output tokens used by the LLM."""


class StepToolStepOutput(BaseModel):
    """Track all tool calls using the Tool Step event"""

    id: str
    """UUID for the step."""

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["tool"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """

    tool_call_id: Optional[str] = FieldInfo(alias="toolCallId", default=None)
    """The tool call ID, extracted from gen_ai.tool.call.id."""

    tool_input: Optional[str] = FieldInfo(alias="toolInput", default=None)
    """JSON input for the tool call."""

    tool_output: Optional[str] = FieldInfo(alias="toolOutput", default=None)
    """JSON output from the tool call."""


class StepRetrieverStepOutput(BaseModel):
    """Track all retriever (RAG) calls using the Retriever Step event."""

    id: str
    """UUID for the step."""

    query: str
    """Query used for RAG."""

    result: str
    """Retrieved text"""

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["retriever"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """


class StepLogStepOutput(BaseModel):
    """Track all logs using the Log Step event."""

    id: str
    """UUID for the step."""

    content: str
    """The actual log message for this trace."""

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["log"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """


class StepGroupStepOutput(BaseModel):
    """
    Use this to group multiple steps together, for example a log, llm start, and llm end.
    """

    id: str
    """UUID for the step."""

    key: str
    """
    A unique identifier for the grouping, which must be appended to the
    corresponding steps
    """

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["group"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """


class StepResponseStepOutput(BaseModel):
    """Track AI responses to users using the Response Step event."""

    id: str
    """UUID for the step."""

    content: str
    """The response content from the AI to the user."""

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["response"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """


class StepRequestStepOutput(BaseModel):
    """Track user requests to the AI using the Request Step event."""

    id: str
    """UUID for the step."""

    content: str
    """The request content from the user to the AI."""

    status: Literal["success", "error", "timeout", "pending"]
    """Status of the step indicating success or failure. Defaults to 'success'."""

    timestamp: datetime
    """When the step was created"""

    trace_id: str = FieldInfo(alias="traceId")
    """UUID referencing the parent trace's ID."""

    type: Literal["request"]

    cost_amount: Optional[float] = FieldInfo(alias="costAmount", default=None)
    """Cost of the step in the configured currency (primarily for LLM steps)"""

    duration_ms: Optional[int] = FieldInfo(alias="durationMs", default=None)
    """Duration of the step in milliseconds"""

    end_time: Optional[datetime] = FieldInfo(alias="endTime", default=None)
    """When the step ended (for duration tracking)"""

    error: Optional[str] = None
    """Error message or stack trace if the step failed."""

    group: Optional[str] = None
    """Optionally, the key for a group step to group the step with."""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Extra metadata about this trace event.

    String values are parsed as JSON if possible, otherwise wrapped in { raw: val }.
    """

    name: Optional[str] = None
    """The name of the step."""

    params: Union[Dict[str, object], List[object], None] = None
    """Arbitrary params for the step."""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """Parent step ID for hierarchical span relationships.

    Links this step to its parent in the trace tree.
    """

    status_code: Optional[str] = FieldInfo(alias="statusCode", default=None)
    """
    Status code associated with the step (e.g., HTTP status code for API calls, OTEL
    status code for traced spans).
    """


Step: TypeAlias = Union[
    StepLlmStartStepOutput,
    StepLlmEndStepOutput,
    StepToolStepOutput,
    StepRetrieverStepOutput,
    StepLogStepOutput,
    StepGroupStepOutput,
    StepResponseStepOutput,
    StepRequestStepOutput,
]


class TraceOutput(BaseModel):
    """A trace grouping related steps (e.g. a user-agent interaction or conversation)."""

    id: str
    """Unique Trace ID (UUID)."""

    timestamp: datetime
    """When the trace was created"""

    metadata: Union[Dict[str, object], List[object], None] = None
    """Arbitrary metadata (e.g., userId, source).

    String inputs are parsed as JSON or wrapped in { raw: val }.
    """

    reference_id: Optional[str] = FieldInfo(alias="referenceId", default=None)
    """
    An optional reference ID to link the trace to an existing conversation or
    interaction in your own database.
    """

    steps: Optional[List[Step]] = None
    """The steps associated with the trace."""

    test_id: Optional[str] = FieldInfo(alias="testId", default=None)
    """The associated Test if this was triggered by an Avido eval"""
