# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["ExperimentUpdateParams"]


class ExperimentUpdateParams(TypedDict, total=False):
    assignee: Optional[str]
    """User ID of the person assigned to this experiment"""

    description: str
    """The experiment description"""

    inference_step_ids: Annotated[SequenceNotStr[str], PropertyInfo(alias="inferenceStepIds")]
    """List of inference step ids used in the experiment"""

    status: Literal["DRAFT", "COMPLETED", "ARCHIVED"]

    task_ids: Annotated[SequenceNotStr[str], PropertyInfo(alias="taskIds")]
    """List of task ids used in the experiment"""

    title: str
    """The title of the experiment"""
