# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["TaskGetCoverageParams"]


class TaskGetCoverageParams(TypedDict, total=False):
    created_at_gte: Required[Annotated[Union[str, datetime], PropertyInfo(alias="createdAtGte", format="iso8601")]]
    """Filter tasks with tests created on or after this date"""

    created_at_lte: Required[Annotated[Union[str, datetime], PropertyInfo(alias="createdAtLte", format="iso8601")]]
    """Filter tasks with tests created on or before this date"""
