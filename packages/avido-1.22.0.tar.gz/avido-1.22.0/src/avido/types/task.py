# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .issues.task_output import TaskOutput

__all__ = ["Task"]


class Task(BaseModel):
    """Successful response containing the task data"""

    task: TaskOutput
    """
    A task that represents a specific job-to-be-done by the LLM in the user
    application.
    """
