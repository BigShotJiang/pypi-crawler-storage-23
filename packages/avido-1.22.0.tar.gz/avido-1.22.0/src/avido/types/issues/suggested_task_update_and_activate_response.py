# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel
from .task_output import TaskOutput

__all__ = ["SuggestedTaskUpdateAndActivateResponse"]


class SuggestedTaskUpdateAndActivateResponse(BaseModel):
    """
    Successful response containing the suggested task (DRAFT) associated with the issue
    """

    task: TaskOutput
    """
    A task that represents a specific job-to-be-done by the LLM in the user
    application.
    """
