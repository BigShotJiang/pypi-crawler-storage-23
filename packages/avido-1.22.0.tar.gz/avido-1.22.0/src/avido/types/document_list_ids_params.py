# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["DocumentListIDsParams"]


class DocumentListIDsParams(TypedDict, total=False):
    scrape_job_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="scrapeJobId")]
    """Filter by scrape job ID. Supports multiple values."""

    search: str
    """Search in document version title and content"""

    status: List[Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]]
    """
    Filter by document version status (filters documents by their active version
    status). Supports multiple values.
    """

    tag_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="tagId")]
    """Filter documents by tag ID"""
