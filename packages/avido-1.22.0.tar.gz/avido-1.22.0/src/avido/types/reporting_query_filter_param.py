# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo
from .date_filter_unit import DateFilterUnit
from .date_filter_preset_value import DateFilterPresetValue

__all__ = [
    "ReportingQueryFilterParam",
    "ReportingQueryStringFilter",
    "ReportingQueryNumberFilter",
    "ReportingQueryBooleanFilter",
    "ReportingQueryDateFilter",
    "ReportingQueryDateFilterDateFilter",
    "ReportingQueryDateFilterDateFilterDateFilterRange",
    "ReportingQueryDateFilterDateFilterDateFilterPreset",
    "ReportingQueryDateFilterDateFilterDateFilterRelative",
]


class ReportingQueryStringFilter(TypedDict, total=False):
    """Filter for string columns using eq/neq operators"""

    column: Required[str]
    """Column name to filter on (must be a string column in the datasource)"""

    operator: Required[Literal["eq", "neq"]]
    """Filter operator for string values"""

    type: Required[Literal["string"]]
    """Filter type for string columns"""

    value: Required[SequenceNotStr[str]]
    """Array of string values to filter by"""


class ReportingQueryNumberFilter(TypedDict, total=False):
    """Filter for numeric columns using eq/neq/lt/gt/lte/gte operators"""

    column: Required[str]
    """Column name to filter on (must be a numeric column in the datasource)"""

    operator: Required[Literal["eq", "neq", "lt", "gt", "lte", "gte"]]
    """Filter operator for numeric values"""

    type: Required[Literal["number"]]
    """Filter type for numeric columns"""

    value: Required[Iterable[float]]
    """
    Array of numeric values to filter by (for comparison operators, only first value
    is used)
    """


class ReportingQueryBooleanFilter(TypedDict, total=False):
    """Filter for boolean columns using eq operator with single value"""

    column: Required[str]
    """Column name to filter on (must be a boolean column in the datasource)"""

    operator: Required[Literal["eq"]]
    """Filter operator for boolean values"""

    type: Required[Literal["boolean"]]
    """Filter type for boolean columns"""

    value: Required[bool]
    """Boolean value to filter by"""


_ReportingQueryDateFilterDateFilterDateFilterRangeReservedKeywords = TypedDict(
    "_ReportingQueryDateFilterDateFilterDateFilterRangeReservedKeywords",
    {
        "from": Union[str, datetime],
    },
    total=False,
)


class ReportingQueryDateFilterDateFilterDateFilterRange(
    _ReportingQueryDateFilterDateFilterDateFilterRangeReservedKeywords, total=False
):
    """Absolute date range with optional from/to boundaries.

    from is inclusive, to is exclusive.
    """

    type: Required[Literal["range"]]
    """Absolute date range with explicit boundaries"""

    to: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """Exclusive end boundary (ISO8601). Omit for open-ended range."""


class ReportingQueryDateFilterDateFilterDateFilterPreset(TypedDict, total=False):
    """
    Preset date range that expands to concrete dates at query time (e.g., thisQuarter, last30Days)
    """

    preset: Required[DateFilterPresetValue]
    """Preset date range that expands to concrete dates at query time"""

    type: Required[Literal["preset"]]
    """Preset date range using common shortcuts"""


_ReportingQueryDateFilterDateFilterDateFilterRelativeReservedKeywords = TypedDict(
    "_ReportingQueryDateFilterDateFilterDateFilterRelativeReservedKeywords",
    {
        "from": int,
    },
    total=False,
)


class ReportingQueryDateFilterDateFilterDateFilterRelative(
    _ReportingQueryDateFilterDateFilterDateFilterRelativeReservedKeywords, total=False
):
    """
    Relative date range using bounded offsets from now (e.g., last 14 days, 2-6 weeks ago)
    """

    to: Required[int]
    """Ending offset (units ago from now). Must be > from. Defaults to 1."""

    type: Required[Literal["relative"]]
    """Relative date range using offsets from now"""

    unit: Required[DateFilterUnit]
    """Time unit for relative date ranges (day, week, month, quarter, year)"""


ReportingQueryDateFilterDateFilter: TypeAlias = Union[
    ReportingQueryDateFilterDateFilterDateFilterRange,
    ReportingQueryDateFilterDateFilterDateFilterPreset,
    ReportingQueryDateFilterDateFilterDateFilterRelative,
]


class ReportingQueryDateFilter(TypedDict, total=False):
    """Filter for date columns using date filter (range/preset/relative)"""

    column: Required[str]
    """Column name to filter on (must be a date column in the datasource)"""

    date_filter: Required[Annotated[ReportingQueryDateFilterDateFilter, PropertyInfo(alias="dateFilter")]]
    """Date filter supporting absolute ranges, presets, and relative windows"""

    type: Required[Literal["date"]]
    """Filter type for date columns"""


ReportingQueryFilterParam: TypeAlias = Union[
    ReportingQueryStringFilter, ReportingQueryNumberFilter, ReportingQueryBooleanFilter, ReportingQueryDateFilter
]
