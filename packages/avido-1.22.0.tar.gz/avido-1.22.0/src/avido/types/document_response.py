# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .document_output import DocumentOutput

__all__ = ["DocumentResponse"]


class DocumentResponse(BaseModel):
    """Successful response containing the document data"""

    document: DocumentOutput
