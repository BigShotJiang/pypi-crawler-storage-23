# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .annotation_output import AnnotationOutput

__all__ = ["AnnotationResponse"]


class AnnotationResponse(BaseModel):
    """Successful response containing the annotation data"""

    data: AnnotationOutput
    """A single annotation indicating a change in the AI application configuration"""
