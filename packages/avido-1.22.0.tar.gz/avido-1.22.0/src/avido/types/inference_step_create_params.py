# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .inference_step_type import InferenceStepType

__all__ = ["InferenceStepCreateParams"]


class InferenceStepCreateParams(TypedDict, total=False):
    description: Required[str]
    """The inference step description"""

    external_id: Required[Annotated[str, PropertyInfo(alias="externalId")]]
    """identifier used in the ai application"""

    title: Required[str]
    """The title of the inference step"""

    type: Required[InferenceStepType]
    """The type of the inference step"""
