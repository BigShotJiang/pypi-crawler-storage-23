# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .eval_type import EvalType
from .application_output import ApplicationOutput
from .output_match_extract_config_output import OutputMatchExtractConfigOutput

__all__ = [
    "EvalDefinitionOutput",
    "GlobalConfig",
    "GlobalConfigCriterion",
    "GlobalConfigGroundTruth",
    "GlobalConfigOutputMatchStringConfigOutput",
    "GlobalConfigOutputMatchListConfigOutput",
]


class GlobalConfigCriterion(BaseModel):
    criterion: str
    """The criterion describes what our evaluation LLM must look for in the response.

    Remember that the answer to the criterion must be as a pass/fail.
    """


class GlobalConfigGroundTruth(BaseModel):
    ground_truth: str = FieldInfo(alias="groundTruth")
    """
    The ground truth is the most correct answer to the task that we measure the
    response against
    """


class GlobalConfigOutputMatchStringConfigOutput(BaseModel):
    type: Literal["string"]

    extract: Optional[OutputMatchExtractConfigOutput] = None


class GlobalConfigOutputMatchListConfigOutput(BaseModel):
    match_mode: Literal["exact_unordered", "contains"] = FieldInfo(alias="matchMode")

    type: Literal["list"]

    extract: Optional[OutputMatchExtractConfigOutput] = None

    pass_threshold: Optional[float] = FieldInfo(alias="passThreshold", default=None)

    score_metric: Optional[Literal["f1", "precision", "recall"]] = FieldInfo(alias="scoreMetric", default=None)


GlobalConfig: TypeAlias = Union[
    GlobalConfigCriterion,
    GlobalConfigGroundTruth,
    GlobalConfigOutputMatchStringConfigOutput,
    GlobalConfigOutputMatchListConfigOutput,
]


class EvalDefinitionOutput(BaseModel):
    id: str

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the eval definition was created"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the eval definition was last modified"""

    name: str

    type: EvalType

    application: Optional[ApplicationOutput] = None
    """Application configuration and metadata"""

    global_config: Optional[GlobalConfig] = FieldInfo(alias="globalConfig", default=None)

    style_guide_id: Optional[str] = FieldInfo(alias="styleGuideId", default=None)
