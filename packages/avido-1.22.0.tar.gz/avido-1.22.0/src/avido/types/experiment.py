# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .experiment_output import ExperimentOutput

__all__ = ["Experiment"]


class Experiment(BaseModel):
    """Response containing a single experiment"""

    data: ExperimentOutput
