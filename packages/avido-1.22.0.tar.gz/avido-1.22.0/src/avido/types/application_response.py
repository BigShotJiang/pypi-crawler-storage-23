# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .application_output import ApplicationOutput

__all__ = ["ApplicationResponse"]


class ApplicationResponse(BaseModel):
    """Successful response containing the application data"""

    data: ApplicationOutput
    """Application configuration and metadata"""
