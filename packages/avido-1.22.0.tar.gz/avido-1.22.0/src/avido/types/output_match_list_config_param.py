# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .output_match_extract_config_param import OutputMatchExtractConfigParam

__all__ = ["OutputMatchListConfigParam"]


class OutputMatchListConfigParam(TypedDict, total=False):
    match_mode: Required[Annotated[Literal["exact_unordered", "contains"], PropertyInfo(alias="matchMode")]]

    type: Required[Literal["list"]]

    extract: OutputMatchExtractConfigParam

    pass_threshold: Annotated[float, PropertyInfo(alias="passThreshold")]

    score_metric: Annotated[Literal["f1", "precision", "recall"], PropertyInfo(alias="scoreMetric")]
