# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._utils import PropertyInfo
from .reporting_query_date_trunc import ReportingQueryDateTrunc

__all__ = ["ReportingQueryGroupByParam", "ReportingQueryGroupByBase", "ReportingQueryGroupByDate"]


class ReportingQueryGroupByBase(TypedDict, total=False):
    """Group by specification for non-date columns"""

    column: Required[str]
    """Column name to group by (must be whitelisted for datasource)"""

    type: Required[Literal["string", "number", "boolean"]]
    """Column type for non-date columns"""


class ReportingQueryGroupByDate(TypedDict, total=False):
    """Group by specification for date columns with required truncation"""

    column: Required[str]
    """Date column name to group by (must be whitelisted for datasource)"""

    date_trunc: Required[Annotated[ReportingQueryDateTrunc, PropertyInfo(alias="dateTrunc")]]
    """Required date truncation granularity for date columns"""

    type: Required[Literal["date"]]
    """Column type for date columns"""


ReportingQueryGroupByParam: TypeAlias = Union[ReportingQueryGroupByBase, ReportingQueryGroupByDate]
