# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .tag_output import TagOutput

__all__ = ["TagResponse"]


class TagResponse(BaseModel):
    """Successful response containing the tag data"""

    data: TagOutput
    """A tag that can be applied to documents for organization"""
