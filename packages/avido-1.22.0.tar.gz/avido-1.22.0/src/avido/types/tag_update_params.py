# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["TagUpdateParams"]


class TagUpdateParams(TypedDict, total=False):
    color: str
    """Hex color code for the tag"""

    description: Optional[str]
    """Optional description of the tag"""

    name: str
    """Name of the tag"""
