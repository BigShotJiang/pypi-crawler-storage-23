# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["ScrapeJobCreateResponse"]


class ScrapeJobCreateResponse(BaseModel):
    """Response after starting a scrape job"""

    id: str
    """The unique identifier of the created scrape job"""
