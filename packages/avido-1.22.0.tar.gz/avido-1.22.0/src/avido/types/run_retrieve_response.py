# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .run_output import RunOutput

__all__ = ["RunRetrieveResponse"]


class RunRetrieveResponse(BaseModel):
    """Successful response containing the run data"""

    run: RunOutput
    """A Run represents a batch of tests triggered by a single task"""
