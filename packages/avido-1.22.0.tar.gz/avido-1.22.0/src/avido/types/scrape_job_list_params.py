# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["ScrapeJobListParams"]


class ScrapeJobListParams(TypedDict, total=False):
    limit: int
    """Number of items to include in the result set."""

    skip: int
    """Number of items to skip before starting to collect the result set."""
