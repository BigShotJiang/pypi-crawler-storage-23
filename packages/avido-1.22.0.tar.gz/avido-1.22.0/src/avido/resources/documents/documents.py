# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Union
from datetime import datetime
from typing_extensions import Literal

import httpx

from .tags import (
    TagsResource,
    AsyncTagsResource,
    TagsResourceWithRawResponse,
    AsyncTagsResourceWithRawResponse,
    TagsResourceWithStreamingResponse,
    AsyncTagsResourceWithStreamingResponse,
)
from .tests import (
    TestsResource,
    AsyncTestsResource,
    TestsResourceWithRawResponse,
    AsyncTestsResourceWithRawResponse,
    TestsResourceWithStreamingResponse,
    AsyncTestsResourceWithStreamingResponse,
)
from .export import (
    ExportResource,
    AsyncExportResource,
    ExportResourceWithRawResponse,
    AsyncExportResourceWithRawResponse,
    ExportResourceWithStreamingResponse,
    AsyncExportResourceWithStreamingResponse,
)
from ...types import (
    document_list_params,
    document_assign_params,
    document_create_params,
    document_list_ids_params,
    document_upload_csv_params,
    document_list_chunked_params,
    document_update_status_params,
    document_activate_latest_params,
    document_delete_multiple_params,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from .optimize import (
    OptimizeResource,
    AsyncOptimizeResource,
    OptimizeResourceWithRawResponse,
    AsyncOptimizeResourceWithRawResponse,
    OptimizeResourceWithStreamingResponse,
    AsyncOptimizeResourceWithStreamingResponse,
)
from .versions import (
    VersionsResource,
    AsyncVersionsResource,
    VersionsResourceWithRawResponse,
    AsyncVersionsResourceWithRawResponse,
    VersionsResourceWithStreamingResponse,
    AsyncVersionsResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPagination, AsyncOffsetPagination
from ..._base_client import AsyncPaginator, make_request_options
from ...types.document_response import DocumentResponse
from ...types.document_list_response import DocumentListResponse
from ...types.document_count_response import DocumentCountResponse
from ...types.document_list_ids_response import DocumentListIDsResponse
from ...types.document_list_chunked_response import DocumentListChunkedResponse
from ...types.document_count_by_assignee_response import DocumentCountByAssigneeResponse

__all__ = ["DocumentsResource", "AsyncDocumentsResource"]


class DocumentsResource(SyncAPIResource):
    @cached_property
    def export(self) -> ExportResource:
        return ExportResource(self._client)

    @cached_property
    def optimize(self) -> OptimizeResource:
        return OptimizeResource(self._client)

    @cached_property
    def versions(self) -> VersionsResource:
        return VersionsResource(self._client)

    @cached_property
    def tests(self) -> TestsResource:
        return TestsResource(self._client)

    @cached_property
    def tags(self) -> TagsResource:
        return TagsResource(self._client)

    @cached_property
    def with_raw_response(self) -> DocumentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return DocumentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DocumentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return DocumentsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        content: str,
        title: str,
        assignee: str | Omit = omit,
        language: str | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        original_sentences: SequenceNotStr[str] | Omit = omit,
        scrape_job_id: str | Omit = omit,
        status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentResponse:
        """
        Creates a new document with the provided information.

        Args:
          content: Content of the initial document version

          title: Title of the initial document version

          assignee: User ID of the person assigned to this document. Defaults to the authenticated
              user if not provided.

          language: Language of the initial document version

          metadata: Optional metadata for the initial document version

          original_sentences: Array of original sentences from the source

          scrape_job_id: Optional ID of the scrape job that generated this document

          status: Status of the initial document version

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/documents",
            body=maybe_transform(
                {
                    "content": content,
                    "title": title,
                    "assignee": assignee,
                    "language": language,
                    "metadata": metadata,
                    "original_sentences": original_sentences,
                    "scrape_job_id": scrape_job_id,
                    "status": status,
                },
                document_create_params.DocumentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentResponse:
        """
        Retrieves detailed information about a specific document, including its
        parent-child relationships and active version details.

        Args:
          id: The unique identifier of the document

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/documents/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentResponse,
        )

    def list(
        self,
        *,
        assignee: str | Omit = omit,
        end_date: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        scrape_job_id: SequenceNotStr[str] | Omit = omit,
        search: str | Omit = omit,
        skip: int | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        status: List[Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]] | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[DocumentListResponse]:
        """
        Retrieves a paginated list of documents with optional filtering by status,
        assignee, parent, and other criteria. Only returns documents with active
        approved versions unless otherwise specified.

        Args:
          assignee: Filter by assignee user ID

          end_date: Filter documents created before this date (inclusive).

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          scrape_job_id: Filter by scrape job ID. Supports multiple values.

          search: Search in document version title and content

          skip: Number of items to skip before starting to collect the result set.

          start_date: Filter documents created after this date (inclusive).

          status: Filter by document version status (filters documents by their active version
              status). Supports multiple values.

          tag_id: Filter documents by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/documents",
            page=SyncOffsetPagination[DocumentListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "assignee": assignee,
                        "end_date": end_date,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "scrape_job_id": scrape_job_id,
                        "search": search,
                        "skip": skip,
                        "start_date": start_date,
                        "status": status,
                        "tag_id": tag_id,
                    },
                    document_list_params.DocumentListParams,
                ),
            ),
            model=DocumentListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes a document and its related document versions by the given document ID

        Args:
          id: The unique identifier of the document

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/v0/documents/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def activate_latest(
        self,
        *,
        document_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Activates the latest version (highest version number) for multiple documents.
        Returns information about which documents were successfully activated and which
        failed.

        Args:
          document_ids: Array of document IDs to activate their latest versions. Maximum 100 documents
              per request.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/documents/activate-latest",
            body=maybe_transform(
                {"document_ids": document_ids}, document_activate_latest_params.DocumentActivateLatestParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def assign(
        self,
        id: str,
        *,
        user_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentResponse:
        """
        Assigns a specific document to a user by their user ID.

        Args:
          id: The unique identifier of the document

          user_id: The unique identifier of the user to assign the document to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/v0/documents/{id}/assign",
            body=maybe_transform({"user_id": user_id}, document_assign_params.DocumentAssignParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentResponse,
        )

    def count(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentCountResponse:
        """
        Returns total document count and count of documents that have an active version.
        """
        return self._get(
            "/v0/documents/count",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentCountResponse,
        )

    def count_by_assignee(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentCountByAssigneeResponse:
        """
        Retrieves document counts grouped by assignee for the authenticated
        organization.
        """
        return self._get(
            "/v0/documents/count-by-assignee",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentCountByAssigneeResponse,
        )

    def delete_multiple(
        self,
        *,
        document_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Deletes multiple documents by ID.

        This will also delete their versions.

        Args:
          document_ids: Array of document IDs to delete

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/documents/delete",
            body=maybe_transform(
                {"document_ids": document_ids}, document_delete_multiple_params.DocumentDeleteMultipleParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_chunked(
        self,
        *,
        document_id: str | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"] | Omit = omit,
        version_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[DocumentListChunkedResponse]:
        """
        Retrieves a paginated list of document chunks with optional filtering by
        document ID.

        Args:
          document_id: Filter by document ID

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          status: Filter by document version status

          version_id: Filter by specific document version ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/documents/chunked",
            page=SyncOffsetPagination[DocumentListChunkedResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "document_id": document_id,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "status": status,
                        "version_id": version_id,
                    },
                    document_list_chunked_params.DocumentListChunkedParams,
                ),
            ),
            model=DocumentListChunkedResponse,
        )

    def list_ids(
        self,
        *,
        scrape_job_id: SequenceNotStr[str] | Omit = omit,
        search: str | Omit = omit,
        status: List[Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]] | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentListIDsResponse:
        """Fetches all document IDs without pagination.

        Supports filtering by status and
        tags. Useful for bulk operations.

        Args:
          scrape_job_id: Filter by scrape job ID. Supports multiple values.

          search: Search in document version title and content

          status: Filter by document version status (filters documents by their active version
              status). Supports multiple values.

          tag_id: Filter documents by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v0/documents/ids",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "scrape_job_id": scrape_job_id,
                        "search": search,
                        "status": status,
                        "tag_id": tag_id,
                    },
                    document_list_ids_params.DocumentListIDsParams,
                ),
            ),
            cast_to=DocumentListIDsResponse,
        )

    def optimize_doc(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Triggers a background optimization job for the specified document.

        Returns 204
        No Content on success.

        Args:
          id: The unique identifier of the document

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            f"/v0/documents/{id}/optimize",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update_status(
        self,
        *,
        document_ids: SequenceNotStr[str],
        status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Updates the status of the active version for multiple documents.

        Args:
          document_ids: Array of document IDs to update status. Maximum 100 documents per request.

          status: The new status to apply to all specified documents

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/documents/status",
            body=maybe_transform(
                {
                    "document_ids": document_ids,
                    "status": status,
                },
                document_update_status_params.DocumentUpdateStatusParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def upload_csv(
        self,
        *,
        file: object,
        file_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Uploads a CSV file containing documents.

        The file will be validated and
        processed asynchronously. Documents are organization-scoped and do not require
        an application context.

        Args:
          file: CSV file containing documents

          file_name: Name for this import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers["Content-Type"] = "multipart/form-data"
        return self._post(
            "/v0/documents/upload-csv",
            body=maybe_transform(
                {
                    "file": file,
                    "file_name": file_name,
                },
                document_upload_csv_params.DocumentUploadCsvParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncDocumentsResource(AsyncAPIResource):
    @cached_property
    def export(self) -> AsyncExportResource:
        return AsyncExportResource(self._client)

    @cached_property
    def optimize(self) -> AsyncOptimizeResource:
        return AsyncOptimizeResource(self._client)

    @cached_property
    def versions(self) -> AsyncVersionsResource:
        return AsyncVersionsResource(self._client)

    @cached_property
    def tests(self) -> AsyncTestsResource:
        return AsyncTestsResource(self._client)

    @cached_property
    def tags(self) -> AsyncTagsResource:
        return AsyncTagsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncDocumentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncDocumentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDocumentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncDocumentsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        content: str,
        title: str,
        assignee: str | Omit = omit,
        language: str | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        original_sentences: SequenceNotStr[str] | Omit = omit,
        scrape_job_id: str | Omit = omit,
        status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentResponse:
        """
        Creates a new document with the provided information.

        Args:
          content: Content of the initial document version

          title: Title of the initial document version

          assignee: User ID of the person assigned to this document. Defaults to the authenticated
              user if not provided.

          language: Language of the initial document version

          metadata: Optional metadata for the initial document version

          original_sentences: Array of original sentences from the source

          scrape_job_id: Optional ID of the scrape job that generated this document

          status: Status of the initial document version

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/documents",
            body=await async_maybe_transform(
                {
                    "content": content,
                    "title": title,
                    "assignee": assignee,
                    "language": language,
                    "metadata": metadata,
                    "original_sentences": original_sentences,
                    "scrape_job_id": scrape_job_id,
                    "status": status,
                },
                document_create_params.DocumentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentResponse:
        """
        Retrieves detailed information about a specific document, including its
        parent-child relationships and active version details.

        Args:
          id: The unique identifier of the document

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/documents/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentResponse,
        )

    def list(
        self,
        *,
        assignee: str | Omit = omit,
        end_date: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        scrape_job_id: SequenceNotStr[str] | Omit = omit,
        search: str | Omit = omit,
        skip: int | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        status: List[Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]] | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[DocumentListResponse, AsyncOffsetPagination[DocumentListResponse]]:
        """
        Retrieves a paginated list of documents with optional filtering by status,
        assignee, parent, and other criteria. Only returns documents with active
        approved versions unless otherwise specified.

        Args:
          assignee: Filter by assignee user ID

          end_date: Filter documents created before this date (inclusive).

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          scrape_job_id: Filter by scrape job ID. Supports multiple values.

          search: Search in document version title and content

          skip: Number of items to skip before starting to collect the result set.

          start_date: Filter documents created after this date (inclusive).

          status: Filter by document version status (filters documents by their active version
              status). Supports multiple values.

          tag_id: Filter documents by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/documents",
            page=AsyncOffsetPagination[DocumentListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "assignee": assignee,
                        "end_date": end_date,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "scrape_job_id": scrape_job_id,
                        "search": search,
                        "skip": skip,
                        "start_date": start_date,
                        "status": status,
                        "tag_id": tag_id,
                    },
                    document_list_params.DocumentListParams,
                ),
            ),
            model=DocumentListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes a document and its related document versions by the given document ID

        Args:
          id: The unique identifier of the document

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/v0/documents/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def activate_latest(
        self,
        *,
        document_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Activates the latest version (highest version number) for multiple documents.
        Returns information about which documents were successfully activated and which
        failed.

        Args:
          document_ids: Array of document IDs to activate their latest versions. Maximum 100 documents
              per request.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/documents/activate-latest",
            body=await async_maybe_transform(
                {"document_ids": document_ids}, document_activate_latest_params.DocumentActivateLatestParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def assign(
        self,
        id: str,
        *,
        user_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentResponse:
        """
        Assigns a specific document to a user by their user ID.

        Args:
          id: The unique identifier of the document

          user_id: The unique identifier of the user to assign the document to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/v0/documents/{id}/assign",
            body=await async_maybe_transform({"user_id": user_id}, document_assign_params.DocumentAssignParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentResponse,
        )

    async def count(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentCountResponse:
        """
        Returns total document count and count of documents that have an active version.
        """
        return await self._get(
            "/v0/documents/count",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentCountResponse,
        )

    async def count_by_assignee(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentCountByAssigneeResponse:
        """
        Retrieves document counts grouped by assignee for the authenticated
        organization.
        """
        return await self._get(
            "/v0/documents/count-by-assignee",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DocumentCountByAssigneeResponse,
        )

    async def delete_multiple(
        self,
        *,
        document_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Deletes multiple documents by ID.

        This will also delete their versions.

        Args:
          document_ids: Array of document IDs to delete

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/documents/delete",
            body=await async_maybe_transform(
                {"document_ids": document_ids}, document_delete_multiple_params.DocumentDeleteMultipleParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_chunked(
        self,
        *,
        document_id: str | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"] | Omit = omit,
        version_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[DocumentListChunkedResponse, AsyncOffsetPagination[DocumentListChunkedResponse]]:
        """
        Retrieves a paginated list of document chunks with optional filtering by
        document ID.

        Args:
          document_id: Filter by document ID

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          status: Filter by document version status

          version_id: Filter by specific document version ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/documents/chunked",
            page=AsyncOffsetPagination[DocumentListChunkedResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "document_id": document_id,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "status": status,
                        "version_id": version_id,
                    },
                    document_list_chunked_params.DocumentListChunkedParams,
                ),
            ),
            model=DocumentListChunkedResponse,
        )

    async def list_ids(
        self,
        *,
        scrape_job_id: SequenceNotStr[str] | Omit = omit,
        search: str | Omit = omit,
        status: List[Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]] | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DocumentListIDsResponse:
        """Fetches all document IDs without pagination.

        Supports filtering by status and
        tags. Useful for bulk operations.

        Args:
          scrape_job_id: Filter by scrape job ID. Supports multiple values.

          search: Search in document version title and content

          status: Filter by document version status (filters documents by their active version
              status). Supports multiple values.

          tag_id: Filter documents by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v0/documents/ids",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "scrape_job_id": scrape_job_id,
                        "search": search,
                        "status": status,
                        "tag_id": tag_id,
                    },
                    document_list_ids_params.DocumentListIDsParams,
                ),
            ),
            cast_to=DocumentListIDsResponse,
        )

    async def optimize_doc(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Triggers a background optimization job for the specified document.

        Returns 204
        No Content on success.

        Args:
          id: The unique identifier of the document

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            f"/v0/documents/{id}/optimize",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update_status(
        self,
        *,
        document_ids: SequenceNotStr[str],
        status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Updates the status of the active version for multiple documents.

        Args:
          document_ids: Array of document IDs to update status. Maximum 100 documents per request.

          status: The new status to apply to all specified documents

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/documents/status",
            body=await async_maybe_transform(
                {
                    "document_ids": document_ids,
                    "status": status,
                },
                document_update_status_params.DocumentUpdateStatusParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def upload_csv(
        self,
        *,
        file: object,
        file_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Uploads a CSV file containing documents.

        The file will be validated and
        processed asynchronously. Documents are organization-scoped and do not require
        an application context.

        Args:
          file: CSV file containing documents

          file_name: Name for this import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers["Content-Type"] = "multipart/form-data"
        return await self._post(
            "/v0/documents/upload-csv",
            body=await async_maybe_transform(
                {
                    "file": file,
                    "file_name": file_name,
                },
                document_upload_csv_params.DocumentUploadCsvParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class DocumentsResourceWithRawResponse:
    def __init__(self, documents: DocumentsResource) -> None:
        self._documents = documents

        self.create = to_raw_response_wrapper(
            documents.create,
        )
        self.retrieve = to_raw_response_wrapper(
            documents.retrieve,
        )
        self.list = to_raw_response_wrapper(
            documents.list,
        )
        self.delete = to_raw_response_wrapper(
            documents.delete,
        )
        self.activate_latest = to_raw_response_wrapper(
            documents.activate_latest,
        )
        self.assign = to_raw_response_wrapper(
            documents.assign,
        )
        self.count = to_raw_response_wrapper(
            documents.count,
        )
        self.count_by_assignee = to_raw_response_wrapper(
            documents.count_by_assignee,
        )
        self.delete_multiple = to_raw_response_wrapper(
            documents.delete_multiple,
        )
        self.list_chunked = to_raw_response_wrapper(
            documents.list_chunked,
        )
        self.list_ids = to_raw_response_wrapper(
            documents.list_ids,
        )
        self.optimize_doc = to_raw_response_wrapper(
            documents.optimize_doc,
        )
        self.update_status = to_raw_response_wrapper(
            documents.update_status,
        )
        self.upload_csv = to_raw_response_wrapper(
            documents.upload_csv,
        )

    @cached_property
    def export(self) -> ExportResourceWithRawResponse:
        return ExportResourceWithRawResponse(self._documents.export)

    @cached_property
    def optimize(self) -> OptimizeResourceWithRawResponse:
        return OptimizeResourceWithRawResponse(self._documents.optimize)

    @cached_property
    def versions(self) -> VersionsResourceWithRawResponse:
        return VersionsResourceWithRawResponse(self._documents.versions)

    @cached_property
    def tests(self) -> TestsResourceWithRawResponse:
        return TestsResourceWithRawResponse(self._documents.tests)

    @cached_property
    def tags(self) -> TagsResourceWithRawResponse:
        return TagsResourceWithRawResponse(self._documents.tags)


class AsyncDocumentsResourceWithRawResponse:
    def __init__(self, documents: AsyncDocumentsResource) -> None:
        self._documents = documents

        self.create = async_to_raw_response_wrapper(
            documents.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            documents.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            documents.list,
        )
        self.delete = async_to_raw_response_wrapper(
            documents.delete,
        )
        self.activate_latest = async_to_raw_response_wrapper(
            documents.activate_latest,
        )
        self.assign = async_to_raw_response_wrapper(
            documents.assign,
        )
        self.count = async_to_raw_response_wrapper(
            documents.count,
        )
        self.count_by_assignee = async_to_raw_response_wrapper(
            documents.count_by_assignee,
        )
        self.delete_multiple = async_to_raw_response_wrapper(
            documents.delete_multiple,
        )
        self.list_chunked = async_to_raw_response_wrapper(
            documents.list_chunked,
        )
        self.list_ids = async_to_raw_response_wrapper(
            documents.list_ids,
        )
        self.optimize_doc = async_to_raw_response_wrapper(
            documents.optimize_doc,
        )
        self.update_status = async_to_raw_response_wrapper(
            documents.update_status,
        )
        self.upload_csv = async_to_raw_response_wrapper(
            documents.upload_csv,
        )

    @cached_property
    def export(self) -> AsyncExportResourceWithRawResponse:
        return AsyncExportResourceWithRawResponse(self._documents.export)

    @cached_property
    def optimize(self) -> AsyncOptimizeResourceWithRawResponse:
        return AsyncOptimizeResourceWithRawResponse(self._documents.optimize)

    @cached_property
    def versions(self) -> AsyncVersionsResourceWithRawResponse:
        return AsyncVersionsResourceWithRawResponse(self._documents.versions)

    @cached_property
    def tests(self) -> AsyncTestsResourceWithRawResponse:
        return AsyncTestsResourceWithRawResponse(self._documents.tests)

    @cached_property
    def tags(self) -> AsyncTagsResourceWithRawResponse:
        return AsyncTagsResourceWithRawResponse(self._documents.tags)


class DocumentsResourceWithStreamingResponse:
    def __init__(self, documents: DocumentsResource) -> None:
        self._documents = documents

        self.create = to_streamed_response_wrapper(
            documents.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            documents.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            documents.list,
        )
        self.delete = to_streamed_response_wrapper(
            documents.delete,
        )
        self.activate_latest = to_streamed_response_wrapper(
            documents.activate_latest,
        )
        self.assign = to_streamed_response_wrapper(
            documents.assign,
        )
        self.count = to_streamed_response_wrapper(
            documents.count,
        )
        self.count_by_assignee = to_streamed_response_wrapper(
            documents.count_by_assignee,
        )
        self.delete_multiple = to_streamed_response_wrapper(
            documents.delete_multiple,
        )
        self.list_chunked = to_streamed_response_wrapper(
            documents.list_chunked,
        )
        self.list_ids = to_streamed_response_wrapper(
            documents.list_ids,
        )
        self.optimize_doc = to_streamed_response_wrapper(
            documents.optimize_doc,
        )
        self.update_status = to_streamed_response_wrapper(
            documents.update_status,
        )
        self.upload_csv = to_streamed_response_wrapper(
            documents.upload_csv,
        )

    @cached_property
    def export(self) -> ExportResourceWithStreamingResponse:
        return ExportResourceWithStreamingResponse(self._documents.export)

    @cached_property
    def optimize(self) -> OptimizeResourceWithStreamingResponse:
        return OptimizeResourceWithStreamingResponse(self._documents.optimize)

    @cached_property
    def versions(self) -> VersionsResourceWithStreamingResponse:
        return VersionsResourceWithStreamingResponse(self._documents.versions)

    @cached_property
    def tests(self) -> TestsResourceWithStreamingResponse:
        return TestsResourceWithStreamingResponse(self._documents.tests)

    @cached_property
    def tags(self) -> TagsResourceWithStreamingResponse:
        return TagsResourceWithStreamingResponse(self._documents.tags)


class AsyncDocumentsResourceWithStreamingResponse:
    def __init__(self, documents: AsyncDocumentsResource) -> None:
        self._documents = documents

        self.create = async_to_streamed_response_wrapper(
            documents.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            documents.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            documents.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            documents.delete,
        )
        self.activate_latest = async_to_streamed_response_wrapper(
            documents.activate_latest,
        )
        self.assign = async_to_streamed_response_wrapper(
            documents.assign,
        )
        self.count = async_to_streamed_response_wrapper(
            documents.count,
        )
        self.count_by_assignee = async_to_streamed_response_wrapper(
            documents.count_by_assignee,
        )
        self.delete_multiple = async_to_streamed_response_wrapper(
            documents.delete_multiple,
        )
        self.list_chunked = async_to_streamed_response_wrapper(
            documents.list_chunked,
        )
        self.list_ids = async_to_streamed_response_wrapper(
            documents.list_ids,
        )
        self.optimize_doc = async_to_streamed_response_wrapper(
            documents.optimize_doc,
        )
        self.update_status = async_to_streamed_response_wrapper(
            documents.update_status,
        )
        self.upload_csv = async_to_streamed_response_wrapper(
            documents.upload_csv,
        )

    @cached_property
    def export(self) -> AsyncExportResourceWithStreamingResponse:
        return AsyncExportResourceWithStreamingResponse(self._documents.export)

    @cached_property
    def optimize(self) -> AsyncOptimizeResourceWithStreamingResponse:
        return AsyncOptimizeResourceWithStreamingResponse(self._documents.optimize)

    @cached_property
    def versions(self) -> AsyncVersionsResourceWithStreamingResponse:
        return AsyncVersionsResourceWithStreamingResponse(self._documents.versions)

    @cached_property
    def tests(self) -> AsyncTestsResourceWithStreamingResponse:
        return AsyncTestsResourceWithStreamingResponse(self._documents.tests)

    @cached_property
    def tags(self) -> AsyncTagsResourceWithStreamingResponse:
        return AsyncTagsResourceWithStreamingResponse(self._documents.tags)
