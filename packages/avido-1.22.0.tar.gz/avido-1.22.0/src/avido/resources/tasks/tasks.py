# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Union, Optional
from datetime import datetime
from typing_extensions import Literal

import httpx

from .tags import (
    TagsResource,
    AsyncTagsResource,
    TagsResourceWithRawResponse,
    AsyncTagsResourceWithRawResponse,
    TagsResourceWithStreamingResponse,
    AsyncTagsResourceWithStreamingResponse,
)
from ...types import (
    task_list_params,
    task_create_params,
    task_update_params,
    task_get_ids_params,
    task_trigger_params,
    task_upload_csv_params,
    task_bulk_delete_params,
    task_get_coverage_params,
    task_install_template_params,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from .schedule import (
    ScheduleResource,
    AsyncScheduleResource,
    ScheduleResourceWithRawResponse,
    AsyncScheduleResourceWithRawResponse,
    ScheduleResourceWithStreamingResponse,
    AsyncScheduleResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPagination, AsyncOffsetPagination
from ...types.task import Task
from ..._base_client import AsyncPaginator, make_request_options
from ...types.task_list_response import TaskListResponse
from ...types.task_get_ids_response import TaskGetIDsResponse
from ...types.task_get_coverage_response import TaskGetCoverageResponse
from ...types.task_install_template_response import TaskInstallTemplateResponse

__all__ = ["TasksResource", "AsyncTasksResource"]


class TasksResource(SyncAPIResource):
    @cached_property
    def schedule(self) -> ScheduleResource:
        return ScheduleResource(self._client)

    @cached_property
    def tags(self) -> TagsResource:
        return TagsResource(self._client)

    @cached_property
    def with_raw_response(self) -> TasksResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return TasksResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TasksResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return TasksResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        description: str,
        title: str,
        metadata: Dict[str, object] | Omit = omit,
        simulated_prompt_schema: Dict[str, object] | Omit = omit,
        topic_id: str | Omit = omit,
        type: Literal["STATIC", "NORMAL"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Task:
        """
        Creates a new task.

        Args:
          description: A short description of the task

          title: The title of the task

          metadata: Optional metadata to associate with the task when creating it (e.g., external
              identifiers).

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          topic_id: ID of the topic this task belongs to

          type: The type of task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/tasks",
            body=maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "metadata": metadata,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "topic_id": topic_id,
                    "type": type,
                },
                task_create_params.TaskCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Task,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Task:
        """
        Retrieves detailed information about a specific task.

        Args:
          id: The unique identifier of the task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/tasks/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Task,
        )

    def update(
        self,
        id: str,
        *,
        description: str | Omit = omit,
        input_examples: SequenceNotStr[str] | Omit = omit,
        metadata: Optional[Dict[str, object]] | Omit = omit,
        simulated_prompt_schema: Optional[Dict[str, object]] | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Task:
        """
        Updates an existing task with the provided information.

        Args:
          id: The unique identifier of the task

          description: A short description of the task

          input_examples: Example inputs for the task

          metadata: Replace the existing task metadata. Use null to clear all metadata for the task.

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          title: The title of the task

          topic_id: ID of the topic this task belongs to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/v0/tasks/{id}",
            body=maybe_transform(
                {
                    "description": description,
                    "input_examples": input_examples,
                    "metadata": metadata,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "title": title,
                    "topic_id": topic_id,
                },
                task_update_params.TaskUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Task,
        )

    def list(
        self,
        *,
        eval_definition_id: SequenceNotStr[str],
        status: List[Literal["success", "warning", "error", "no-tests"]],
        topic_id: SequenceNotStr[str],
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[TaskListResponse]:
        """
        Retrieves a paginated list of tasks with optional filtering.

        Args:
          eval_definition_id: Filter tasks by eval definition ID

          status: Filter tasks by status

          topic_id: Filter tasks by topic ID

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          tag_id: Filter tasks by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/tasks",
            page=SyncOffsetPagination[TaskListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "eval_definition_id": eval_definition_id,
                        "status": status,
                        "topic_id": topic_id,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "tag_id": tag_id,
                    },
                    task_list_params.TaskListParams,
                ),
            ),
            model=TaskListResponse,
        )

    def bulk_delete(
        self,
        *,
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes multiple tasks by their IDs.

        Args:
          task_ids: Array of task IDs to delete

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/tasks/delete",
            body=maybe_transform({"task_ids": task_ids}, task_bulk_delete_params.TaskBulkDeleteParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get_coverage(
        self,
        *,
        created_at_gte: Union[str, datetime],
        created_at_lte: Union[str, datetime],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskGetCoverageResponse:
        """
        Returns the percentage of active tasks that have at least one test run within
        the specified date range.

        Args:
          created_at_gte: Filter tasks with tests created on or after this date

          created_at_lte: Filter tasks with tests created on or before this date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v0/tasks/task-coverage",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "created_at_gte": created_at_gte,
                        "created_at_lte": created_at_lte,
                    },
                    task_get_coverage_params.TaskGetCoverageParams,
                ),
            ),
            cast_to=TaskGetCoverageResponse,
        )

    def get_ids(
        self,
        *,
        eval_definition_id: SequenceNotStr[str],
        status: List[Literal["success", "warning", "error", "no-tests"]],
        topic_id: SequenceNotStr[str],
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskGetIDsResponse:
        """
        Retrieves a list of task IDs with optional filtering.

        Args:
          eval_definition_id: Filter tasks by eval definition ID

          status: Filter tasks by status

          topic_id: Filter tasks by topic ID

          tag_id: Filter tasks by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v0/tasks/ids",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "eval_definition_id": eval_definition_id,
                        "status": status,
                        "topic_id": topic_id,
                        "tag_id": tag_id,
                    },
                    task_get_ids_params.TaskGetIDsParams,
                ),
            ),
            cast_to=TaskGetIDsResponse,
        )

    def install_template(
        self,
        *,
        title: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskInstallTemplateResponse:
        """
        Installs a predefined task template, creating tasks, topics, and eval
        definitions.

        Args:
          title: The title of the task template to install

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/tasks/template",
            body=maybe_transform({"title": title}, task_install_template_params.TaskInstallTemplateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskInstallTemplateResponse,
        )

    def trigger(
        self,
        *,
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Triggers the execution of a task.

        Args:
          task_ids: Array of task IDs to trigger

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/tasks/trigger",
            body=maybe_transform({"task_ids": task_ids}, task_trigger_params.TaskTriggerParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def upload_csv(
        self,
        *,
        file: object,
        file_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Uploads a CSV file containing tasks.

        The file will be validated and processed
        asynchronously.

        Args:
          file: CSV file containing tasks

          file_name: Name for this import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers["Content-Type"] = "multipart/form-data"
        return self._post(
            "/v0/tasks/upload-csv",
            body=maybe_transform(
                {
                    "file": file,
                    "file_name": file_name,
                },
                task_upload_csv_params.TaskUploadCsvParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncTasksResource(AsyncAPIResource):
    @cached_property
    def schedule(self) -> AsyncScheduleResource:
        return AsyncScheduleResource(self._client)

    @cached_property
    def tags(self) -> AsyncTagsResource:
        return AsyncTagsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncTasksResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncTasksResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTasksResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncTasksResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        description: str,
        title: str,
        metadata: Dict[str, object] | Omit = omit,
        simulated_prompt_schema: Dict[str, object] | Omit = omit,
        topic_id: str | Omit = omit,
        type: Literal["STATIC", "NORMAL"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Task:
        """
        Creates a new task.

        Args:
          description: A short description of the task

          title: The title of the task

          metadata: Optional metadata to associate with the task when creating it (e.g., external
              identifiers).

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          topic_id: ID of the topic this task belongs to

          type: The type of task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/tasks",
            body=await async_maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "metadata": metadata,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "topic_id": topic_id,
                    "type": type,
                },
                task_create_params.TaskCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Task,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Task:
        """
        Retrieves detailed information about a specific task.

        Args:
          id: The unique identifier of the task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/tasks/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Task,
        )

    async def update(
        self,
        id: str,
        *,
        description: str | Omit = omit,
        input_examples: SequenceNotStr[str] | Omit = omit,
        metadata: Optional[Dict[str, object]] | Omit = omit,
        simulated_prompt_schema: Optional[Dict[str, object]] | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Task:
        """
        Updates an existing task with the provided information.

        Args:
          id: The unique identifier of the task

          description: A short description of the task

          input_examples: Example inputs for the task

          metadata: Replace the existing task metadata. Use null to clear all metadata for the task.

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          title: The title of the task

          topic_id: ID of the topic this task belongs to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/v0/tasks/{id}",
            body=await async_maybe_transform(
                {
                    "description": description,
                    "input_examples": input_examples,
                    "metadata": metadata,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "title": title,
                    "topic_id": topic_id,
                },
                task_update_params.TaskUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Task,
        )

    def list(
        self,
        *,
        eval_definition_id: SequenceNotStr[str],
        status: List[Literal["success", "warning", "error", "no-tests"]],
        topic_id: SequenceNotStr[str],
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[TaskListResponse, AsyncOffsetPagination[TaskListResponse]]:
        """
        Retrieves a paginated list of tasks with optional filtering.

        Args:
          eval_definition_id: Filter tasks by eval definition ID

          status: Filter tasks by status

          topic_id: Filter tasks by topic ID

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          tag_id: Filter tasks by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/tasks",
            page=AsyncOffsetPagination[TaskListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "eval_definition_id": eval_definition_id,
                        "status": status,
                        "topic_id": topic_id,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "tag_id": tag_id,
                    },
                    task_list_params.TaskListParams,
                ),
            ),
            model=TaskListResponse,
        )

    async def bulk_delete(
        self,
        *,
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes multiple tasks by their IDs.

        Args:
          task_ids: Array of task IDs to delete

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/tasks/delete",
            body=await async_maybe_transform({"task_ids": task_ids}, task_bulk_delete_params.TaskBulkDeleteParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get_coverage(
        self,
        *,
        created_at_gte: Union[str, datetime],
        created_at_lte: Union[str, datetime],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskGetCoverageResponse:
        """
        Returns the percentage of active tasks that have at least one test run within
        the specified date range.

        Args:
          created_at_gte: Filter tasks with tests created on or after this date

          created_at_lte: Filter tasks with tests created on or before this date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v0/tasks/task-coverage",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "created_at_gte": created_at_gte,
                        "created_at_lte": created_at_lte,
                    },
                    task_get_coverage_params.TaskGetCoverageParams,
                ),
            ),
            cast_to=TaskGetCoverageResponse,
        )

    async def get_ids(
        self,
        *,
        eval_definition_id: SequenceNotStr[str],
        status: List[Literal["success", "warning", "error", "no-tests"]],
        topic_id: SequenceNotStr[str],
        tag_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskGetIDsResponse:
        """
        Retrieves a list of task IDs with optional filtering.

        Args:
          eval_definition_id: Filter tasks by eval definition ID

          status: Filter tasks by status

          topic_id: Filter tasks by topic ID

          tag_id: Filter tasks by tag ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v0/tasks/ids",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "eval_definition_id": eval_definition_id,
                        "status": status,
                        "topic_id": topic_id,
                        "tag_id": tag_id,
                    },
                    task_get_ids_params.TaskGetIDsParams,
                ),
            ),
            cast_to=TaskGetIDsResponse,
        )

    async def install_template(
        self,
        *,
        title: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskInstallTemplateResponse:
        """
        Installs a predefined task template, creating tasks, topics, and eval
        definitions.

        Args:
          title: The title of the task template to install

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/tasks/template",
            body=await async_maybe_transform({"title": title}, task_install_template_params.TaskInstallTemplateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskInstallTemplateResponse,
        )

    async def trigger(
        self,
        *,
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Triggers the execution of a task.

        Args:
          task_ids: Array of task IDs to trigger

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/tasks/trigger",
            body=await async_maybe_transform({"task_ids": task_ids}, task_trigger_params.TaskTriggerParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def upload_csv(
        self,
        *,
        file: object,
        file_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Uploads a CSV file containing tasks.

        The file will be validated and processed
        asynchronously.

        Args:
          file: CSV file containing tasks

          file_name: Name for this import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers["Content-Type"] = "multipart/form-data"
        return await self._post(
            "/v0/tasks/upload-csv",
            body=await async_maybe_transform(
                {
                    "file": file,
                    "file_name": file_name,
                },
                task_upload_csv_params.TaskUploadCsvParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class TasksResourceWithRawResponse:
    def __init__(self, tasks: TasksResource) -> None:
        self._tasks = tasks

        self.create = to_raw_response_wrapper(
            tasks.create,
        )
        self.retrieve = to_raw_response_wrapper(
            tasks.retrieve,
        )
        self.update = to_raw_response_wrapper(
            tasks.update,
        )
        self.list = to_raw_response_wrapper(
            tasks.list,
        )
        self.bulk_delete = to_raw_response_wrapper(
            tasks.bulk_delete,
        )
        self.get_coverage = to_raw_response_wrapper(
            tasks.get_coverage,
        )
        self.get_ids = to_raw_response_wrapper(
            tasks.get_ids,
        )
        self.install_template = to_raw_response_wrapper(
            tasks.install_template,
        )
        self.trigger = to_raw_response_wrapper(
            tasks.trigger,
        )
        self.upload_csv = to_raw_response_wrapper(
            tasks.upload_csv,
        )

    @cached_property
    def schedule(self) -> ScheduleResourceWithRawResponse:
        return ScheduleResourceWithRawResponse(self._tasks.schedule)

    @cached_property
    def tags(self) -> TagsResourceWithRawResponse:
        return TagsResourceWithRawResponse(self._tasks.tags)


class AsyncTasksResourceWithRawResponse:
    def __init__(self, tasks: AsyncTasksResource) -> None:
        self._tasks = tasks

        self.create = async_to_raw_response_wrapper(
            tasks.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            tasks.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            tasks.update,
        )
        self.list = async_to_raw_response_wrapper(
            tasks.list,
        )
        self.bulk_delete = async_to_raw_response_wrapper(
            tasks.bulk_delete,
        )
        self.get_coverage = async_to_raw_response_wrapper(
            tasks.get_coverage,
        )
        self.get_ids = async_to_raw_response_wrapper(
            tasks.get_ids,
        )
        self.install_template = async_to_raw_response_wrapper(
            tasks.install_template,
        )
        self.trigger = async_to_raw_response_wrapper(
            tasks.trigger,
        )
        self.upload_csv = async_to_raw_response_wrapper(
            tasks.upload_csv,
        )

    @cached_property
    def schedule(self) -> AsyncScheduleResourceWithRawResponse:
        return AsyncScheduleResourceWithRawResponse(self._tasks.schedule)

    @cached_property
    def tags(self) -> AsyncTagsResourceWithRawResponse:
        return AsyncTagsResourceWithRawResponse(self._tasks.tags)


class TasksResourceWithStreamingResponse:
    def __init__(self, tasks: TasksResource) -> None:
        self._tasks = tasks

        self.create = to_streamed_response_wrapper(
            tasks.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            tasks.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            tasks.update,
        )
        self.list = to_streamed_response_wrapper(
            tasks.list,
        )
        self.bulk_delete = to_streamed_response_wrapper(
            tasks.bulk_delete,
        )
        self.get_coverage = to_streamed_response_wrapper(
            tasks.get_coverage,
        )
        self.get_ids = to_streamed_response_wrapper(
            tasks.get_ids,
        )
        self.install_template = to_streamed_response_wrapper(
            tasks.install_template,
        )
        self.trigger = to_streamed_response_wrapper(
            tasks.trigger,
        )
        self.upload_csv = to_streamed_response_wrapper(
            tasks.upload_csv,
        )

    @cached_property
    def schedule(self) -> ScheduleResourceWithStreamingResponse:
        return ScheduleResourceWithStreamingResponse(self._tasks.schedule)

    @cached_property
    def tags(self) -> TagsResourceWithStreamingResponse:
        return TagsResourceWithStreamingResponse(self._tasks.tags)


class AsyncTasksResourceWithStreamingResponse:
    def __init__(self, tasks: AsyncTasksResource) -> None:
        self._tasks = tasks

        self.create = async_to_streamed_response_wrapper(
            tasks.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            tasks.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            tasks.update,
        )
        self.list = async_to_streamed_response_wrapper(
            tasks.list,
        )
        self.bulk_delete = async_to_streamed_response_wrapper(
            tasks.bulk_delete,
        )
        self.get_coverage = async_to_streamed_response_wrapper(
            tasks.get_coverage,
        )
        self.get_ids = async_to_streamed_response_wrapper(
            tasks.get_ids,
        )
        self.install_template = async_to_streamed_response_wrapper(
            tasks.install_template,
        )
        self.trigger = async_to_streamed_response_wrapper(
            tasks.trigger,
        )
        self.upload_csv = async_to_streamed_response_wrapper(
            tasks.upload_csv,
        )

    @cached_property
    def schedule(self) -> AsyncScheduleResourceWithStreamingResponse:
        return AsyncScheduleResourceWithStreamingResponse(self._tasks.schedule)

    @cached_property
    def tags(self) -> AsyncTagsResourceWithStreamingResponse:
        return AsyncTagsResourceWithStreamingResponse(self._tasks.tags)
