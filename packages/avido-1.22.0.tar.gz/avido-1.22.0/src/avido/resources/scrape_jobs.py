# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional

import httpx

from ..types import ScrapeJobStatus, scrape_job_list_params, scrape_job_create_params, scrape_job_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPagination, AsyncOffsetPagination
from .._base_client import AsyncPaginator, make_request_options
from ..types.scrape_job_output import ScrapeJobOutput
from ..types.scrape_job_status import ScrapeJobStatus
from ..types.scrape_job_start_response import ScrapeJobStartResponse
from ..types.scrape_job_create_response import ScrapeJobCreateResponse

__all__ = ["ScrapeJobsResource", "AsyncScrapeJobsResource"]


class ScrapeJobsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ScrapeJobsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return ScrapeJobsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ScrapeJobsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return ScrapeJobsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        url: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobCreateResponse:
        """
        Create a scrape job

        Args:
          url: The URL to scrape

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/scrape-jobs",
            body=maybe_transform({"url": url}, scrape_job_create_params.ScrapeJobCreateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobOutput:
        """
        Get a scrape job by ID

        Args:
          id: The unique identifier of the scrape job

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/scrape-jobs/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobOutput,
        )

    def update(
        self,
        id: str,
        *,
        name: str | Omit = omit,
        pages: Optional[Iterable[scrape_job_update_params.Page]] | Omit = omit,
        status: ScrapeJobStatus | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobOutput:
        """
        Update a scrape job

        Args:
          id: The unique identifier of the scrape job

          name: The new name/title of the scrape job

          pages: Array of page URLs to update

          status: The status of the scrape job

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/v0/scrape-jobs/{id}",
            body=maybe_transform(
                {
                    "name": name,
                    "pages": pages,
                    "status": status,
                },
                scrape_job_update_params.ScrapeJobUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobOutput,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[ScrapeJobOutput]:
        """
        List all scrape jobs

        Args:
          limit: Number of items to include in the result set.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/scrape-jobs",
            page=SyncOffsetPagination[ScrapeJobOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "skip": skip,
                    },
                    scrape_job_list_params.ScrapeJobListParams,
                ),
            ),
            model=ScrapeJobOutput,
        )

    def start(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobStartResponse:
        """
        Start scraping all pages of a scrape job

        Args:
          id: The unique identifier of the scrape job

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/v0/scrape-jobs/{id}/start",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobStartResponse,
        )


class AsyncScrapeJobsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncScrapeJobsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncScrapeJobsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncScrapeJobsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncScrapeJobsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        url: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobCreateResponse:
        """
        Create a scrape job

        Args:
          url: The URL to scrape

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/scrape-jobs",
            body=await async_maybe_transform({"url": url}, scrape_job_create_params.ScrapeJobCreateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobOutput:
        """
        Get a scrape job by ID

        Args:
          id: The unique identifier of the scrape job

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/scrape-jobs/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobOutput,
        )

    async def update(
        self,
        id: str,
        *,
        name: str | Omit = omit,
        pages: Optional[Iterable[scrape_job_update_params.Page]] | Omit = omit,
        status: ScrapeJobStatus | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobOutput:
        """
        Update a scrape job

        Args:
          id: The unique identifier of the scrape job

          name: The new name/title of the scrape job

          pages: Array of page URLs to update

          status: The status of the scrape job

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/v0/scrape-jobs/{id}",
            body=await async_maybe_transform(
                {
                    "name": name,
                    "pages": pages,
                    "status": status,
                },
                scrape_job_update_params.ScrapeJobUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobOutput,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ScrapeJobOutput, AsyncOffsetPagination[ScrapeJobOutput]]:
        """
        List all scrape jobs

        Args:
          limit: Number of items to include in the result set.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/scrape-jobs",
            page=AsyncOffsetPagination[ScrapeJobOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "skip": skip,
                    },
                    scrape_job_list_params.ScrapeJobListParams,
                ),
            ),
            model=ScrapeJobOutput,
        )

    async def start(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ScrapeJobStartResponse:
        """
        Start scraping all pages of a scrape job

        Args:
          id: The unique identifier of the scrape job

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/v0/scrape-jobs/{id}/start",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ScrapeJobStartResponse,
        )


class ScrapeJobsResourceWithRawResponse:
    def __init__(self, scrape_jobs: ScrapeJobsResource) -> None:
        self._scrape_jobs = scrape_jobs

        self.create = to_raw_response_wrapper(
            scrape_jobs.create,
        )
        self.retrieve = to_raw_response_wrapper(
            scrape_jobs.retrieve,
        )
        self.update = to_raw_response_wrapper(
            scrape_jobs.update,
        )
        self.list = to_raw_response_wrapper(
            scrape_jobs.list,
        )
        self.start = to_raw_response_wrapper(
            scrape_jobs.start,
        )


class AsyncScrapeJobsResourceWithRawResponse:
    def __init__(self, scrape_jobs: AsyncScrapeJobsResource) -> None:
        self._scrape_jobs = scrape_jobs

        self.create = async_to_raw_response_wrapper(
            scrape_jobs.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            scrape_jobs.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            scrape_jobs.update,
        )
        self.list = async_to_raw_response_wrapper(
            scrape_jobs.list,
        )
        self.start = async_to_raw_response_wrapper(
            scrape_jobs.start,
        )


class ScrapeJobsResourceWithStreamingResponse:
    def __init__(self, scrape_jobs: ScrapeJobsResource) -> None:
        self._scrape_jobs = scrape_jobs

        self.create = to_streamed_response_wrapper(
            scrape_jobs.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            scrape_jobs.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            scrape_jobs.update,
        )
        self.list = to_streamed_response_wrapper(
            scrape_jobs.list,
        )
        self.start = to_streamed_response_wrapper(
            scrape_jobs.start,
        )


class AsyncScrapeJobsResourceWithStreamingResponse:
    def __init__(self, scrape_jobs: AsyncScrapeJobsResource) -> None:
        self._scrape_jobs = scrape_jobs

        self.create = async_to_streamed_response_wrapper(
            scrape_jobs.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            scrape_jobs.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            scrape_jobs.update,
        )
        self.list = async_to_streamed_response_wrapper(
            scrape_jobs.list,
        )
        self.start = async_to_streamed_response_wrapper(
            scrape_jobs.start,
        )
