# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import InferenceStepType, inference_step_list_params, inference_step_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPagination, AsyncOffsetPagination
from .._base_client import AsyncPaginator, make_request_options
from ..types.inference_step_type import InferenceStepType
from ..types.inference_step_output import InferenceStepOutput
from ..types.inference_step_create_response import InferenceStepCreateResponse

__all__ = ["InferenceStepsResource", "AsyncInferenceStepsResource"]


class InferenceStepsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> InferenceStepsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return InferenceStepsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> InferenceStepsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return InferenceStepsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        description: str,
        external_id: str,
        title: str,
        type: InferenceStepType,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceStepCreateResponse:
        """
        Create an inference step

        Args:
          description: The inference step description

          external_id: identifier used in the ai application

          title: The title of the inference step

          type: The type of the inference step

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/inference-steps",
            body=maybe_transform(
                {
                    "description": description,
                    "external_id": external_id,
                    "title": title,
                    "type": type,
                },
                inference_step_create_params.InferenceStepCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InferenceStepCreateResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[InferenceStepOutput]:
        """
        List inference steps

        Args:
          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/inference-steps",
            page=SyncOffsetPagination[InferenceStepOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                    },
                    inference_step_list_params.InferenceStepListParams,
                ),
            ),
            model=InferenceStepOutput,
        )


class AsyncInferenceStepsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncInferenceStepsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncInferenceStepsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncInferenceStepsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncInferenceStepsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        description: str,
        external_id: str,
        title: str,
        type: InferenceStepType,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceStepCreateResponse:
        """
        Create an inference step

        Args:
          description: The inference step description

          external_id: identifier used in the ai application

          title: The title of the inference step

          type: The type of the inference step

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/inference-steps",
            body=await async_maybe_transform(
                {
                    "description": description,
                    "external_id": external_id,
                    "title": title,
                    "type": type,
                },
                inference_step_create_params.InferenceStepCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=InferenceStepCreateResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[InferenceStepOutput, AsyncOffsetPagination[InferenceStepOutput]]:
        """
        List inference steps

        Args:
          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/inference-steps",
            page=AsyncOffsetPagination[InferenceStepOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                    },
                    inference_step_list_params.InferenceStepListParams,
                ),
            ),
            model=InferenceStepOutput,
        )


class InferenceStepsResourceWithRawResponse:
    def __init__(self, inference_steps: InferenceStepsResource) -> None:
        self._inference_steps = inference_steps

        self.create = to_raw_response_wrapper(
            inference_steps.create,
        )
        self.list = to_raw_response_wrapper(
            inference_steps.list,
        )


class AsyncInferenceStepsResourceWithRawResponse:
    def __init__(self, inference_steps: AsyncInferenceStepsResource) -> None:
        self._inference_steps = inference_steps

        self.create = async_to_raw_response_wrapper(
            inference_steps.create,
        )
        self.list = async_to_raw_response_wrapper(
            inference_steps.list,
        )


class InferenceStepsResourceWithStreamingResponse:
    def __init__(self, inference_steps: InferenceStepsResource) -> None:
        self._inference_steps = inference_steps

        self.create = to_streamed_response_wrapper(
            inference_steps.create,
        )
        self.list = to_streamed_response_wrapper(
            inference_steps.list,
        )


class AsyncInferenceStepsResourceWithStreamingResponse:
    def __init__(self, inference_steps: AsyncInferenceStepsResource) -> None:
        self._inference_steps = inference_steps

        self.create = async_to_streamed_response_wrapper(
            inference_steps.create,
        )
        self.list = async_to_streamed_response_wrapper(
            inference_steps.list,
        )
