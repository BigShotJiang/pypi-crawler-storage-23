# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import datetime
from typing_extensions import Literal

import httpx

from ...types import (
    reporting_list_params,
    reporting_query_params,
    reporting_create_params,
    reporting_update_params,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPagination, AsyncOffsetPagination
from ..._base_client import AsyncPaginator, make_request_options
from ...types.report_output import ReportOutput
from ...types.report_response import ReportResponse
from .datasources.datasources import (
    DatasourcesResource,
    AsyncDatasourcesResource,
    DatasourcesResourceWithRawResponse,
    AsyncDatasourcesResourceWithRawResponse,
    DatasourcesResourceWithStreamingResponse,
    AsyncDatasourcesResourceWithStreamingResponse,
)
from ...types.measurement_param import MeasurementParam
from ...types.reporting.datasources import ReportingQueryDatasource
from ...types.reporting_query_param import ReportingQueryParam
from ...types.reporting_query_response import ReportingQueryResponse
from ...types.reporting_query_filter_param import ReportingQueryFilterParam
from ...types.reporting_query_group_by_param import ReportingQueryGroupByParam
from ...types.reporting.datasources.reporting_query_datasource import ReportingQueryDatasource

__all__ = ["ReportingResource", "AsyncReportingResource"]


class ReportingResource(SyncAPIResource):
    @cached_property
    def datasources(self) -> DatasourcesResource:
        return DatasourcesResource(self._client)

    @cached_property
    def with_raw_response(self) -> ReportingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return ReportingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ReportingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return ReportingResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        description: str,
        title: str,
        assignee: str | Omit = omit,
        query: ReportingQueryParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportResponse:
        """
        Creates a new report.

        Args:
          description: Detailed description of the report

          title: Title of the report

          assignee: User ID of the person assigned to this report

          query: Optional reporting query configuration defining datasource, filters, groupBy,
              measurements, and ordering

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/reporting",
            body=maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "assignee": assignee,
                    "query": query,
                },
                reporting_create_params.ReportingCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportResponse:
        """
        Retrieves a specific report by its ID.

        Args:
          id: The unique identifier of the report

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/reporting/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportResponse,
        )

    def update(
        self,
        id: str,
        *,
        assignee: Optional[str] | Omit = omit,
        description: str | Omit = omit,
        query: Optional[ReportingQueryParam] | Omit = omit,
        title: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportResponse:
        """Updates an existing report.

        Can be used to update title, description, or
        reassign/unassign the report.

        Args:
          id: The unique identifier of the report

          assignee: Updated assignee user ID (can be set to null to unassign)

          description: Updated description of the report

          query: Reporting query definition with datasource, filters, groupBy, measurements, and
              ordering

          title: Updated title of the report

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/v0/reporting/{id}",
            body=maybe_transform(
                {
                    "assignee": assignee,
                    "description": description,
                    "query": query,
                    "title": title,
                },
                reporting_update_params.ReportingUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportResponse,
        )

    def list(
        self,
        *,
        assignee: str | Omit = omit,
        end: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        start: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[ReportOutput]:
        """
        Retrieves a paginated list of reports with optional filtering by date range,
        assignee, and application.

        Args:
          assignee: Filter by assignee user ID

          end: End date (ISO8601) for filtering reports by creation date

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          start: Start date (ISO8601) for filtering reports by creation date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/reporting",
            page=SyncOffsetPagination[ReportOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "assignee": assignee,
                        "end": end,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "start": start,
                    },
                    reporting_list_params.ReportingListParams,
                ),
            ),
            model=ReportOutput,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes a specific report by its ID.

        Args:
          id: The unique identifier of the report

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/v0/reporting/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def query(
        self,
        *,
        datasource: ReportingQueryDatasource,
        timezone: str,
        filters: Iterable[ReportingQueryFilterParam] | Omit = omit,
        group_by: Iterable[ReportingQueryGroupByParam] | Omit = omit,
        limit: int | Omit = omit,
        measurements: Iterable[MeasurementParam] | Omit = omit,
        order_by: Iterable[reporting_query_params.OrderBy] | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportingQueryResponse:
        """
        Queries reporting data from specified datasources with optional filters and
        groupBy clauses. Supports aggregation and date truncation for time-based
        grouping.

        Args:
          datasource: Datasource to query

          timezone: IANA timezone identifier for date filter resolution (e.g., 'America/New_York',
              'Europe/London', 'UTC')

          filters: Optional filters to apply to the query. Each filter must specify a type
              (string/number/boolean/date) that matches the column type.

          group_by: Optional group by clauses for aggregating results. For date columns, dateTrunc
              is required.

          limit: Number of items to include in the result set.

          measurements: Optional measurements/aggregations to compute when using groupBy. Defaults to
              count if not specified. Use avg/sum/min/max for numeric or boolean columns.

          order_by: Optional ordering specification. If not specified, defaults to ordering by all
              groupBy columns (with createdAt priority) then measurements. For non-groupBy
              queries, defaults to createdAt DESC, id DESC.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/reporting/query",
            body=maybe_transform(
                {
                    "datasource": datasource,
                    "timezone": timezone,
                    "filters": filters,
                    "group_by": group_by,
                    "limit": limit,
                    "measurements": measurements,
                    "order_by": order_by,
                    "skip": skip,
                },
                reporting_query_params.ReportingQueryParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportingQueryResponse,
        )


class AsyncReportingResource(AsyncAPIResource):
    @cached_property
    def datasources(self) -> AsyncDatasourcesResource:
        return AsyncDatasourcesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncReportingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncReportingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncReportingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncReportingResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        description: str,
        title: str,
        assignee: str | Omit = omit,
        query: ReportingQueryParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportResponse:
        """
        Creates a new report.

        Args:
          description: Detailed description of the report

          title: Title of the report

          assignee: User ID of the person assigned to this report

          query: Optional reporting query configuration defining datasource, filters, groupBy,
              measurements, and ordering

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/reporting",
            body=await async_maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "assignee": assignee,
                    "query": query,
                },
                reporting_create_params.ReportingCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportResponse:
        """
        Retrieves a specific report by its ID.

        Args:
          id: The unique identifier of the report

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/reporting/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportResponse,
        )

    async def update(
        self,
        id: str,
        *,
        assignee: Optional[str] | Omit = omit,
        description: str | Omit = omit,
        query: Optional[ReportingQueryParam] | Omit = omit,
        title: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportResponse:
        """Updates an existing report.

        Can be used to update title, description, or
        reassign/unassign the report.

        Args:
          id: The unique identifier of the report

          assignee: Updated assignee user ID (can be set to null to unassign)

          description: Updated description of the report

          query: Reporting query definition with datasource, filters, groupBy, measurements, and
              ordering

          title: Updated title of the report

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/v0/reporting/{id}",
            body=await async_maybe_transform(
                {
                    "assignee": assignee,
                    "description": description,
                    "query": query,
                    "title": title,
                },
                reporting_update_params.ReportingUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportResponse,
        )

    def list(
        self,
        *,
        assignee: str | Omit = omit,
        end: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        start: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ReportOutput, AsyncOffsetPagination[ReportOutput]]:
        """
        Retrieves a paginated list of reports with optional filtering by date range,
        assignee, and application.

        Args:
          assignee: Filter by assignee user ID

          end: End date (ISO8601) for filtering reports by creation date

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          start: Start date (ISO8601) for filtering reports by creation date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/reporting",
            page=AsyncOffsetPagination[ReportOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "assignee": assignee,
                        "end": end,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "start": start,
                    },
                    reporting_list_params.ReportingListParams,
                ),
            ),
            model=ReportOutput,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes a specific report by its ID.

        Args:
          id: The unique identifier of the report

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/v0/reporting/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def query(
        self,
        *,
        datasource: ReportingQueryDatasource,
        timezone: str,
        filters: Iterable[ReportingQueryFilterParam] | Omit = omit,
        group_by: Iterable[ReportingQueryGroupByParam] | Omit = omit,
        limit: int | Omit = omit,
        measurements: Iterable[MeasurementParam] | Omit = omit,
        order_by: Iterable[reporting_query_params.OrderBy] | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ReportingQueryResponse:
        """
        Queries reporting data from specified datasources with optional filters and
        groupBy clauses. Supports aggregation and date truncation for time-based
        grouping.

        Args:
          datasource: Datasource to query

          timezone: IANA timezone identifier for date filter resolution (e.g., 'America/New_York',
              'Europe/London', 'UTC')

          filters: Optional filters to apply to the query. Each filter must specify a type
              (string/number/boolean/date) that matches the column type.

          group_by: Optional group by clauses for aggregating results. For date columns, dateTrunc
              is required.

          limit: Number of items to include in the result set.

          measurements: Optional measurements/aggregations to compute when using groupBy. Defaults to
              count if not specified. Use avg/sum/min/max for numeric or boolean columns.

          order_by: Optional ordering specification. If not specified, defaults to ordering by all
              groupBy columns (with createdAt priority) then measurements. For non-groupBy
              queries, defaults to createdAt DESC, id DESC.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/reporting/query",
            body=await async_maybe_transform(
                {
                    "datasource": datasource,
                    "timezone": timezone,
                    "filters": filters,
                    "group_by": group_by,
                    "limit": limit,
                    "measurements": measurements,
                    "order_by": order_by,
                    "skip": skip,
                },
                reporting_query_params.ReportingQueryParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ReportingQueryResponse,
        )


class ReportingResourceWithRawResponse:
    def __init__(self, reporting: ReportingResource) -> None:
        self._reporting = reporting

        self.create = to_raw_response_wrapper(
            reporting.create,
        )
        self.retrieve = to_raw_response_wrapper(
            reporting.retrieve,
        )
        self.update = to_raw_response_wrapper(
            reporting.update,
        )
        self.list = to_raw_response_wrapper(
            reporting.list,
        )
        self.delete = to_raw_response_wrapper(
            reporting.delete,
        )
        self.query = to_raw_response_wrapper(
            reporting.query,
        )

    @cached_property
    def datasources(self) -> DatasourcesResourceWithRawResponse:
        return DatasourcesResourceWithRawResponse(self._reporting.datasources)


class AsyncReportingResourceWithRawResponse:
    def __init__(self, reporting: AsyncReportingResource) -> None:
        self._reporting = reporting

        self.create = async_to_raw_response_wrapper(
            reporting.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            reporting.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            reporting.update,
        )
        self.list = async_to_raw_response_wrapper(
            reporting.list,
        )
        self.delete = async_to_raw_response_wrapper(
            reporting.delete,
        )
        self.query = async_to_raw_response_wrapper(
            reporting.query,
        )

    @cached_property
    def datasources(self) -> AsyncDatasourcesResourceWithRawResponse:
        return AsyncDatasourcesResourceWithRawResponse(self._reporting.datasources)


class ReportingResourceWithStreamingResponse:
    def __init__(self, reporting: ReportingResource) -> None:
        self._reporting = reporting

        self.create = to_streamed_response_wrapper(
            reporting.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            reporting.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            reporting.update,
        )
        self.list = to_streamed_response_wrapper(
            reporting.list,
        )
        self.delete = to_streamed_response_wrapper(
            reporting.delete,
        )
        self.query = to_streamed_response_wrapper(
            reporting.query,
        )

    @cached_property
    def datasources(self) -> DatasourcesResourceWithStreamingResponse:
        return DatasourcesResourceWithStreamingResponse(self._reporting.datasources)


class AsyncReportingResourceWithStreamingResponse:
    def __init__(self, reporting: AsyncReportingResource) -> None:
        self._reporting = reporting

        self.create = async_to_streamed_response_wrapper(
            reporting.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            reporting.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            reporting.update,
        )
        self.list = async_to_streamed_response_wrapper(
            reporting.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            reporting.delete,
        )
        self.query = async_to_streamed_response_wrapper(
            reporting.query,
        )

    @cached_property
    def datasources(self) -> AsyncDatasourcesResourceWithStreamingResponse:
        return AsyncDatasourcesResourceWithStreamingResponse(self._reporting.datasources)
