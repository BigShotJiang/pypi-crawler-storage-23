# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.measurement_param import MeasurementParam
from ....types.reporting.datasources import (
    ReportingQueryDatasource,
    ReportingColumnsIntentSchema,
    column_context_aware_params,
)
from ....types.reporting_query_filter_param import ReportingQueryFilterParam
from ....types.reporting_query_group_by_param import ReportingQueryGroupByParam
from ....types.reporting.datasources.column_list_response import ColumnListResponse
from ....types.reporting.datasources.column_values_response import ColumnValuesResponse
from ....types.reporting.datasources.reporting_query_datasource import ReportingQueryDatasource
from ....types.reporting.datasources.column_context_aware_response import ColumnContextAwareResponse
from ....types.reporting.datasources.reporting_columns_intent_schema import ReportingColumnsIntentSchema

__all__ = ["ColumnsResource", "AsyncColumnsResource"]


class ColumnsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ColumnsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return ColumnsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ColumnsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return ColumnsResourceWithStreamingResponse(self)

    def list(
        self,
        id: ReportingQueryDatasource,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ColumnListResponse:
        """
        Returns metadata about the whitelisted columns for a specific datasource that
        can be used for filtering in reporting queries.

        Args:
          id: Datasource name

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/reporting/datasources/{id}/columns",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ColumnListResponse,
        )

    def context_aware(
        self,
        id: ReportingQueryDatasource,
        *,
        intent: ReportingColumnsIntentSchema,
        filters: Iterable[ReportingQueryFilterParam] | Omit = omit,
        group_by: Iterable[ReportingQueryGroupByParam] | Omit = omit,
        measurements: Iterable[MeasurementParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ColumnContextAwareResponse:
        """
        Returns available columns for a datasource based on the intent and current query
        context. For filters/groupBy/measurements intents, returns all eligible columns.
        For orderBy intent, returns columns based on current groupBy and measurements
        context.

        Args:
          id: Datasource name

          intent: Intent for which columns are needed

          filters: Current filters applied (used for context when intent is orderBy)

          group_by: Current groupBy clauses (required when intent is orderBy to determine available
              sort columns)

          measurements: Current measurements (required when intent is orderBy to include measurement
              aliases as sortable columns)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/v0/reporting/datasources/{id}/columns",
            body=maybe_transform(
                {
                    "intent": intent,
                    "filters": filters,
                    "group_by": group_by,
                    "measurements": measurements,
                },
                column_context_aware_params.ColumnContextAwareParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ColumnContextAwareResponse,
        )

    def values(
        self,
        column_id: str,
        *,
        id: ReportingQueryDatasource,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ColumnValuesResponse:
        """Returns a list of distinct values from a specific column in a datasource.

        For
        relation columns (e.g., topicId), returns the related records with their IDs and
        display names.

        Args:
          id: Datasource identifier

          column_id: Column identifier

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not column_id:
            raise ValueError(f"Expected a non-empty value for `column_id` but received {column_id!r}")
        return self._get(
            f"/v0/reporting/datasources/{id}/columns/{column_id}/values",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ColumnValuesResponse,
        )


class AsyncColumnsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncColumnsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncColumnsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncColumnsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncColumnsResourceWithStreamingResponse(self)

    async def list(
        self,
        id: ReportingQueryDatasource,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ColumnListResponse:
        """
        Returns metadata about the whitelisted columns for a specific datasource that
        can be used for filtering in reporting queries.

        Args:
          id: Datasource name

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/reporting/datasources/{id}/columns",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ColumnListResponse,
        )

    async def context_aware(
        self,
        id: ReportingQueryDatasource,
        *,
        intent: ReportingColumnsIntentSchema,
        filters: Iterable[ReportingQueryFilterParam] | Omit = omit,
        group_by: Iterable[ReportingQueryGroupByParam] | Omit = omit,
        measurements: Iterable[MeasurementParam] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ColumnContextAwareResponse:
        """
        Returns available columns for a datasource based on the intent and current query
        context. For filters/groupBy/measurements intents, returns all eligible columns.
        For orderBy intent, returns columns based on current groupBy and measurements
        context.

        Args:
          id: Datasource name

          intent: Intent for which columns are needed

          filters: Current filters applied (used for context when intent is orderBy)

          group_by: Current groupBy clauses (required when intent is orderBy to determine available
              sort columns)

          measurements: Current measurements (required when intent is orderBy to include measurement
              aliases as sortable columns)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/v0/reporting/datasources/{id}/columns",
            body=await async_maybe_transform(
                {
                    "intent": intent,
                    "filters": filters,
                    "group_by": group_by,
                    "measurements": measurements,
                },
                column_context_aware_params.ColumnContextAwareParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ColumnContextAwareResponse,
        )

    async def values(
        self,
        column_id: str,
        *,
        id: ReportingQueryDatasource,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ColumnValuesResponse:
        """Returns a list of distinct values from a specific column in a datasource.

        For
        relation columns (e.g., topicId), returns the related records with their IDs and
        display names.

        Args:
          id: Datasource identifier

          column_id: Column identifier

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not column_id:
            raise ValueError(f"Expected a non-empty value for `column_id` but received {column_id!r}")
        return await self._get(
            f"/v0/reporting/datasources/{id}/columns/{column_id}/values",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ColumnValuesResponse,
        )


class ColumnsResourceWithRawResponse:
    def __init__(self, columns: ColumnsResource) -> None:
        self._columns = columns

        self.list = to_raw_response_wrapper(
            columns.list,
        )
        self.context_aware = to_raw_response_wrapper(
            columns.context_aware,
        )
        self.values = to_raw_response_wrapper(
            columns.values,
        )


class AsyncColumnsResourceWithRawResponse:
    def __init__(self, columns: AsyncColumnsResource) -> None:
        self._columns = columns

        self.list = async_to_raw_response_wrapper(
            columns.list,
        )
        self.context_aware = async_to_raw_response_wrapper(
            columns.context_aware,
        )
        self.values = async_to_raw_response_wrapper(
            columns.values,
        )


class ColumnsResourceWithStreamingResponse:
    def __init__(self, columns: ColumnsResource) -> None:
        self._columns = columns

        self.list = to_streamed_response_wrapper(
            columns.list,
        )
        self.context_aware = to_streamed_response_wrapper(
            columns.context_aware,
        )
        self.values = to_streamed_response_wrapper(
            columns.values,
        )


class AsyncColumnsResourceWithStreamingResponse:
    def __init__(self, columns: AsyncColumnsResource) -> None:
        self._columns = columns

        self.list = async_to_streamed_response_wrapper(
            columns.list,
        )
        self.context_aware = async_to_streamed_response_wrapper(
            columns.context_aware,
        )
        self.values = async_to_streamed_response_wrapper(
            columns.values,
        )
