# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    quickstart_list_params,
    quickstart_create_params,
    quickstart_update_params,
    quickstart_upload_csv_params,
    quickstart_approve_style_guide_params,
    quickstart_confirm_style_scores_params,
    quickstart_update_style_guide_section_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPagination, AsyncOffsetPagination
from .._base_client import AsyncPaginator, make_request_options
from ..types.quickstart_output import QuickstartOutput
from ..types.quickstart_response import QuickstartResponse
from ..types.quickstart_approve_style_guide_response import QuickstartApproveStyleGuideResponse
from ..types.quickstart_confirm_style_scores_response import QuickstartConfirmStyleScoresResponse
from ..types.quickstart_update_style_guide_section_response import QuickstartUpdateStyleGuideSectionResponse

__all__ = ["QuickstartsResource", "AsyncQuickstartsResource"]


class QuickstartsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> QuickstartsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return QuickstartsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> QuickstartsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return QuickstartsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        conversations: quickstart_create_params.Conversations,
        initiated_by: str,
        name: str,
        status: Literal[
            "PENDING",
            "IN_PROGRESS",
            "BASELINE_REVIEW",
            "AWAITING_STYLE_REVIEW",
            "REVIEWING_STYLE",
            "AWAITING_STYLE_CONFIRMATION",
            "AWAITING_VOTING",
            "COMPLETED",
            "FAILED",
        ],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartResponse:
        """
        Creates a new quickstart

        Args:
          initiated_by: The user who created the quickstart

          name: The name of the quickstart

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/quickstarts",
            body=maybe_transform(
                {
                    "conversations": conversations,
                    "initiated_by": initiated_by,
                    "name": name,
                    "status": status,
                },
                quickstart_create_params.QuickstartCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartResponse:
        """
        Retrieves a single quickstart by its unique identifier

        Args:
          id: The unique identifier of the quickstart

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/quickstarts/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartResponse,
        )

    def update(
        self,
        id: str,
        *,
        status: Literal[
            "PENDING",
            "IN_PROGRESS",
            "BASELINE_REVIEW",
            "AWAITING_STYLE_REVIEW",
            "REVIEWING_STYLE",
            "AWAITING_STYLE_CONFIRMATION",
            "AWAITING_VOTING",
            "COMPLETED",
            "FAILED",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartResponse:
        """
        Updates a quickstart by its unique identifier

        Args:
          id: The unique identifier of the quickstart

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/v0/quickstarts/{id}",
            body=maybe_transform({"status": status}, quickstart_update_params.QuickstartUpdateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        status: Literal[
            "PENDING",
            "IN_PROGRESS",
            "BASELINE_REVIEW",
            "AWAITING_STYLE_REVIEW",
            "REVIEWING_STYLE",
            "AWAITING_STYLE_CONFIRMATION",
            "AWAITING_VOTING",
            "COMPLETED",
            "FAILED",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[QuickstartOutput]:
        """
        Retrieves a paginated list of quickstarts with optional filtering

        Args:
          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          status: Filter by quickstart status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/quickstarts",
            page=SyncOffsetPagination[QuickstartOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "status": status,
                    },
                    quickstart_list_params.QuickstartListParams,
                ),
            ),
            model=QuickstartOutput,
        )

    def approve_style_guide(
        self,
        *,
        quickstart_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartApproveStyleGuideResponse:
        """
        Finalizes the quickstart style guide, creates a style guide record, and moves
        the quickstart to reviewing style status.

        Args:
          quickstart_id: The ID of the quickstart to approve

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/quickstarts/approve-style-guide",
            body=maybe_transform(
                {"quickstart_id": quickstart_id},
                quickstart_approve_style_guide_params.QuickstartApproveStyleGuideParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartApproveStyleGuideResponse,
        )

    def confirm_style_scores(
        self,
        *,
        quickstart_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartConfirmStyleScoresResponse:
        """
        Confirms the style scores for a quickstart and triggers the quickstart
        completion process.

        Args:
          quickstart_id: The ID of the quickstart to confirm style scores for

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/quickstarts/confirm-style-scores",
            body=maybe_transform(
                {"quickstart_id": quickstart_id},
                quickstart_confirm_style_scores_params.QuickstartConfirmStyleScoresParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartConfirmStyleScoresResponse,
        )

    def update_style_guide_section(
        self,
        *,
        approved: bool,
        content: str,
        heading: str,
        quickstart_id: str,
        section_index: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartUpdateStyleGuideSectionResponse:
        """
        Updates a single section of the style guide in a quickstart by index.

        Args:
          approved: Whether or not the section has been approved

          content: The content of the section in markdown

          heading: The heading of the section

          quickstart_id: The ID of the quickstart containing the style guide

          section_index: The zero-based index of the section to update

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/quickstarts/update-style-guide-section",
            body=maybe_transform(
                {
                    "approved": approved,
                    "content": content,
                    "heading": heading,
                    "quickstart_id": quickstart_id,
                    "section_index": section_index,
                },
                quickstart_update_style_guide_section_params.QuickstartUpdateStyleGuideSectionParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartUpdateStyleGuideSectionResponse,
        )

    def upload_csv(
        self,
        *,
        file: object,
        file_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Uploads a CSV file containing quickstart conversations for AI evaluation.

        The
        file will be validated and processed asynchronously. Requires an application
        context.

        Args:
          file: CSV file containing quickstart conversations

          file_name: Name for this import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers["Content-Type"] = "multipart/form-data"
        return self._post(
            "/v0/quickstarts/upload-csv",
            body=maybe_transform(
                {
                    "file": file,
                    "file_name": file_name,
                },
                quickstart_upload_csv_params.QuickstartUploadCsvParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncQuickstartsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncQuickstartsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncQuickstartsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncQuickstartsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncQuickstartsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        conversations: quickstart_create_params.Conversations,
        initiated_by: str,
        name: str,
        status: Literal[
            "PENDING",
            "IN_PROGRESS",
            "BASELINE_REVIEW",
            "AWAITING_STYLE_REVIEW",
            "REVIEWING_STYLE",
            "AWAITING_STYLE_CONFIRMATION",
            "AWAITING_VOTING",
            "COMPLETED",
            "FAILED",
        ],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartResponse:
        """
        Creates a new quickstart

        Args:
          initiated_by: The user who created the quickstart

          name: The name of the quickstart

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/quickstarts",
            body=await async_maybe_transform(
                {
                    "conversations": conversations,
                    "initiated_by": initiated_by,
                    "name": name,
                    "status": status,
                },
                quickstart_create_params.QuickstartCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartResponse:
        """
        Retrieves a single quickstart by its unique identifier

        Args:
          id: The unique identifier of the quickstart

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/quickstarts/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartResponse,
        )

    async def update(
        self,
        id: str,
        *,
        status: Literal[
            "PENDING",
            "IN_PROGRESS",
            "BASELINE_REVIEW",
            "AWAITING_STYLE_REVIEW",
            "REVIEWING_STYLE",
            "AWAITING_STYLE_CONFIRMATION",
            "AWAITING_VOTING",
            "COMPLETED",
            "FAILED",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartResponse:
        """
        Updates a quickstart by its unique identifier

        Args:
          id: The unique identifier of the quickstart

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/v0/quickstarts/{id}",
            body=await async_maybe_transform({"status": status}, quickstart_update_params.QuickstartUpdateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        status: Literal[
            "PENDING",
            "IN_PROGRESS",
            "BASELINE_REVIEW",
            "AWAITING_STYLE_REVIEW",
            "REVIEWING_STYLE",
            "AWAITING_STYLE_CONFIRMATION",
            "AWAITING_VOTING",
            "COMPLETED",
            "FAILED",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[QuickstartOutput, AsyncOffsetPagination[QuickstartOutput]]:
        """
        Retrieves a paginated list of quickstarts with optional filtering

        Args:
          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          status: Filter by quickstart status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/quickstarts",
            page=AsyncOffsetPagination[QuickstartOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                        "status": status,
                    },
                    quickstart_list_params.QuickstartListParams,
                ),
            ),
            model=QuickstartOutput,
        )

    async def approve_style_guide(
        self,
        *,
        quickstart_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartApproveStyleGuideResponse:
        """
        Finalizes the quickstart style guide, creates a style guide record, and moves
        the quickstart to reviewing style status.

        Args:
          quickstart_id: The ID of the quickstart to approve

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/quickstarts/approve-style-guide",
            body=await async_maybe_transform(
                {"quickstart_id": quickstart_id},
                quickstart_approve_style_guide_params.QuickstartApproveStyleGuideParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartApproveStyleGuideResponse,
        )

    async def confirm_style_scores(
        self,
        *,
        quickstart_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartConfirmStyleScoresResponse:
        """
        Confirms the style scores for a quickstart and triggers the quickstart
        completion process.

        Args:
          quickstart_id: The ID of the quickstart to confirm style scores for

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/quickstarts/confirm-style-scores",
            body=await async_maybe_transform(
                {"quickstart_id": quickstart_id},
                quickstart_confirm_style_scores_params.QuickstartConfirmStyleScoresParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartConfirmStyleScoresResponse,
        )

    async def update_style_guide_section(
        self,
        *,
        approved: bool,
        content: str,
        heading: str,
        quickstart_id: str,
        section_index: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuickstartUpdateStyleGuideSectionResponse:
        """
        Updates a single section of the style guide in a quickstart by index.

        Args:
          approved: Whether or not the section has been approved

          content: The content of the section in markdown

          heading: The heading of the section

          quickstart_id: The ID of the quickstart containing the style guide

          section_index: The zero-based index of the section to update

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/quickstarts/update-style-guide-section",
            body=await async_maybe_transform(
                {
                    "approved": approved,
                    "content": content,
                    "heading": heading,
                    "quickstart_id": quickstart_id,
                    "section_index": section_index,
                },
                quickstart_update_style_guide_section_params.QuickstartUpdateStyleGuideSectionParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuickstartUpdateStyleGuideSectionResponse,
        )

    async def upload_csv(
        self,
        *,
        file: object,
        file_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Uploads a CSV file containing quickstart conversations for AI evaluation.

        The
        file will be validated and processed asynchronously. Requires an application
        context.

        Args:
          file: CSV file containing quickstart conversations

          file_name: Name for this import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers["Content-Type"] = "multipart/form-data"
        return await self._post(
            "/v0/quickstarts/upload-csv",
            body=await async_maybe_transform(
                {
                    "file": file,
                    "file_name": file_name,
                },
                quickstart_upload_csv_params.QuickstartUploadCsvParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class QuickstartsResourceWithRawResponse:
    def __init__(self, quickstarts: QuickstartsResource) -> None:
        self._quickstarts = quickstarts

        self.create = to_raw_response_wrapper(
            quickstarts.create,
        )
        self.retrieve = to_raw_response_wrapper(
            quickstarts.retrieve,
        )
        self.update = to_raw_response_wrapper(
            quickstarts.update,
        )
        self.list = to_raw_response_wrapper(
            quickstarts.list,
        )
        self.approve_style_guide = to_raw_response_wrapper(
            quickstarts.approve_style_guide,
        )
        self.confirm_style_scores = to_raw_response_wrapper(
            quickstarts.confirm_style_scores,
        )
        self.update_style_guide_section = to_raw_response_wrapper(
            quickstarts.update_style_guide_section,
        )
        self.upload_csv = to_raw_response_wrapper(
            quickstarts.upload_csv,
        )


class AsyncQuickstartsResourceWithRawResponse:
    def __init__(self, quickstarts: AsyncQuickstartsResource) -> None:
        self._quickstarts = quickstarts

        self.create = async_to_raw_response_wrapper(
            quickstarts.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            quickstarts.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            quickstarts.update,
        )
        self.list = async_to_raw_response_wrapper(
            quickstarts.list,
        )
        self.approve_style_guide = async_to_raw_response_wrapper(
            quickstarts.approve_style_guide,
        )
        self.confirm_style_scores = async_to_raw_response_wrapper(
            quickstarts.confirm_style_scores,
        )
        self.update_style_guide_section = async_to_raw_response_wrapper(
            quickstarts.update_style_guide_section,
        )
        self.upload_csv = async_to_raw_response_wrapper(
            quickstarts.upload_csv,
        )


class QuickstartsResourceWithStreamingResponse:
    def __init__(self, quickstarts: QuickstartsResource) -> None:
        self._quickstarts = quickstarts

        self.create = to_streamed_response_wrapper(
            quickstarts.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            quickstarts.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            quickstarts.update,
        )
        self.list = to_streamed_response_wrapper(
            quickstarts.list,
        )
        self.approve_style_guide = to_streamed_response_wrapper(
            quickstarts.approve_style_guide,
        )
        self.confirm_style_scores = to_streamed_response_wrapper(
            quickstarts.confirm_style_scores,
        )
        self.update_style_guide_section = to_streamed_response_wrapper(
            quickstarts.update_style_guide_section,
        )
        self.upload_csv = to_streamed_response_wrapper(
            quickstarts.upload_csv,
        )


class AsyncQuickstartsResourceWithStreamingResponse:
    def __init__(self, quickstarts: AsyncQuickstartsResource) -> None:
        self._quickstarts = quickstarts

        self.create = async_to_streamed_response_wrapper(
            quickstarts.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            quickstarts.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            quickstarts.update,
        )
        self.list = async_to_streamed_response_wrapper(
            quickstarts.list,
        )
        self.approve_style_guide = async_to_streamed_response_wrapper(
            quickstarts.approve_style_guide,
        )
        self.confirm_style_scores = async_to_streamed_response_wrapper(
            quickstarts.confirm_style_scores,
        )
        self.update_style_guide_section = async_to_streamed_response_wrapper(
            quickstarts.update_style_guide_section,
        )
        self.upload_csv = async_to_streamed_response_wrapper(
            quickstarts.upload_csv,
        )
