# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.issues import suggested_task_update_and_activate_params
from ...types.issues.suggested_task_retrieve_response import SuggestedTaskRetrieveResponse
from ...types.issues.suggested_task_update_and_activate_response import SuggestedTaskUpdateAndActivateResponse

__all__ = ["SuggestedTaskResource", "AsyncSuggestedTaskResource"]


class SuggestedTaskResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SuggestedTaskResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return SuggestedTaskResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SuggestedTaskResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return SuggestedTaskResourceWithStreamingResponse(self)

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SuggestedTaskRetrieveResponse:
        """Retrieves the DRAFT task associated with an issue of type SUGGESTED_TASK.

        This
        endpoint only works for issues that have a taskId and are of type SUGGESTED_TASK
        with a task in DRAFT status.

        Args:
          id: The unique identifier of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/issues/{id}/suggested-task",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SuggestedTaskRetrieveResponse,
        )

    def update_and_activate(
        self,
        id: str,
        *,
        description: str | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SuggestedTaskUpdateAndActivateResponse:
        """
        Updates the DRAFT task associated with an issue and activates it (changes status
        from DRAFT to ACTIVE). This endpoint only works for issues of type
        SUGGESTED_TASK with a task in DRAFT status. After activation, the task becomes a
        regular active task.

        Args:
          id: The unique identifier of the issue

          description: Updated description for the suggested task

          title: Updated title for the suggested task

          topic_id: Updated topic ID for the suggested task. Use null to remove topic association.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/v0/issues/{id}/suggested-task",
            body=maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "topic_id": topic_id,
                },
                suggested_task_update_and_activate_params.SuggestedTaskUpdateAndActivateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SuggestedTaskUpdateAndActivateResponse,
        )


class AsyncSuggestedTaskResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSuggestedTaskResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncSuggestedTaskResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSuggestedTaskResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncSuggestedTaskResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SuggestedTaskRetrieveResponse:
        """Retrieves the DRAFT task associated with an issue of type SUGGESTED_TASK.

        This
        endpoint only works for issues that have a taskId and are of type SUGGESTED_TASK
        with a task in DRAFT status.

        Args:
          id: The unique identifier of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/issues/{id}/suggested-task",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SuggestedTaskRetrieveResponse,
        )

    async def update_and_activate(
        self,
        id: str,
        *,
        description: str | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SuggestedTaskUpdateAndActivateResponse:
        """
        Updates the DRAFT task associated with an issue and activates it (changes status
        from DRAFT to ACTIVE). This endpoint only works for issues of type
        SUGGESTED_TASK with a task in DRAFT status. After activation, the task becomes a
        regular active task.

        Args:
          id: The unique identifier of the issue

          description: Updated description for the suggested task

          title: Updated title for the suggested task

          topic_id: Updated topic ID for the suggested task. Use null to remove topic association.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/v0/issues/{id}/suggested-task",
            body=await async_maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "topic_id": topic_id,
                },
                suggested_task_update_and_activate_params.SuggestedTaskUpdateAndActivateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SuggestedTaskUpdateAndActivateResponse,
        )


class SuggestedTaskResourceWithRawResponse:
    def __init__(self, suggested_task: SuggestedTaskResource) -> None:
        self._suggested_task = suggested_task

        self.retrieve = to_raw_response_wrapper(
            suggested_task.retrieve,
        )
        self.update_and_activate = to_raw_response_wrapper(
            suggested_task.update_and_activate,
        )


class AsyncSuggestedTaskResourceWithRawResponse:
    def __init__(self, suggested_task: AsyncSuggestedTaskResource) -> None:
        self._suggested_task = suggested_task

        self.retrieve = async_to_raw_response_wrapper(
            suggested_task.retrieve,
        )
        self.update_and_activate = async_to_raw_response_wrapper(
            suggested_task.update_and_activate,
        )


class SuggestedTaskResourceWithStreamingResponse:
    def __init__(self, suggested_task: SuggestedTaskResource) -> None:
        self._suggested_task = suggested_task

        self.retrieve = to_streamed_response_wrapper(
            suggested_task.retrieve,
        )
        self.update_and_activate = to_streamed_response_wrapper(
            suggested_task.update_and_activate,
        )


class AsyncSuggestedTaskResourceWithStreamingResponse:
    def __init__(self, suggested_task: AsyncSuggestedTaskResource) -> None:
        self._suggested_task = suggested_task

        self.retrieve = async_to_streamed_response_wrapper(
            suggested_task.retrieve,
        )
        self.update_and_activate = async_to_streamed_response_wrapper(
            suggested_task.update_and_activate,
        )
