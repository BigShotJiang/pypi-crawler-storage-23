# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime
from typing_extensions import Literal

import httpx

from ...types import (
    IssueType,
    IssueSource,
    IssueStatus,
    IssuePriority,
    issue_list_params,
    issue_create_params,
    issue_update_params,
    issue_bulk_update_params,
    issue_list_minimal_params,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPagination, AsyncOffsetPagination
from ..._base_client import AsyncPaginator, make_request_options
from .suggested_task import (
    SuggestedTaskResource,
    AsyncSuggestedTaskResource,
    SuggestedTaskResourceWithRawResponse,
    AsyncSuggestedTaskResourceWithRawResponse,
    SuggestedTaskResourceWithStreamingResponse,
    AsyncSuggestedTaskResourceWithStreamingResponse,
)
from ...types.issue_type import IssueType
from ...types.issue_source import IssueSource
from ...types.issue_status import IssueStatus
from ...types.issue_priority import IssuePriority
from ...types.grouped_issue_output import GroupedIssueOutput
from ...types.issue_update_response import IssueUpdateResponse
from ...types.issue_retrieve_response import IssueRetrieveResponse
from ...types.issue_bulk_update_response import IssueBulkUpdateResponse
from ...types.issue_list_minimal_response import IssueListMinimalResponse

__all__ = ["IssuesResource", "AsyncIssuesResource"]


class IssuesResource(SyncAPIResource):
    @cached_property
    def suggested_task(self) -> SuggestedTaskResource:
        return SuggestedTaskResource(self._client)

    @cached_property
    def with_raw_response(self) -> IssuesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return IssuesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> IssuesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return IssuesResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        source: IssueSource,
        title: str,
        annotation_id: str | Omit = omit,
        description: Optional[str] | Omit = omit,
        eval_definition_id: str | Omit = omit,
        parent_id: str | Omit = omit,
        priority: IssuePriority | Omit = omit,
        task_id: str | Omit = omit,
        test_id: str | Omit = omit,
        topic_id: str | Omit = omit,
        trace_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Creates a new issue for tracking problems or improvements.

        Args:
          source: Where the issue originated from

          title: Title of the issue

          annotation_id: Associated annotation ID if related to an annotation

          description: Detailed description of the issue

          eval_definition_id: Associated evaluation definition ID if issue came from an evaluation

          parent_id: Parent issue ID for creating sub-issues

          priority: Priority level of the issue

          task_id: Associated task ID if issue came from a task

          test_id: Associated test ID if issue came from a test

          topic_id: Associated topic ID if issue came from a topic

          trace_id: Associated trace ID for monitoring/debugging

          type: Type/category of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/issues",
            body=maybe_transform(
                {
                    "source": source,
                    "title": title,
                    "annotation_id": annotation_id,
                    "description": description,
                    "eval_definition_id": eval_definition_id,
                    "parent_id": parent_id,
                    "priority": priority,
                    "task_id": task_id,
                    "test_id": test_id,
                    "topic_id": topic_id,
                    "trace_id": trace_id,
                    "type": type,
                },
                issue_create_params.IssueCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IssueRetrieveResponse:
        """
        Retrieves detailed information about a specific issue, including all
        duplicate/child issues in the issues array.

        Args:
          id: The unique identifier of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v0/issues/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IssueRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        annotation_id: Optional[str] | Omit = omit,
        assigned_to: Optional[str] | Omit = omit,
        comment: Optional[str] | Omit = omit,
        eval_definition_id: Optional[str] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        priority: IssuePriority | Omit = omit,
        status: IssueStatus | Omit = omit,
        summary: Optional[str] | Omit = omit,
        task_id: Optional[str] | Omit = omit,
        test_id: Optional[str] | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        trace_id: Optional[str] | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IssueUpdateResponse:
        """Updates an existing issue.

        Can be used to reassign, change status, update
        priority, or modify any other issue fields.

        Args:
          id: The unique identifier of the issue

          annotation_id: Update associated annotation ID

          assigned_to: Reassign the issue to a different user

          comment: Reason for resolving or dismissing the issue

          eval_definition_id: Update associated evaluation definition ID

          parent_id: Update parent issue ID for sub-issues

          priority: Updated priority level

          status: Updated status of the issue

          summary: Updated summary of the issue

          task_id: Update associated task ID

          test_id: Update associated test ID

          title: Updated title of the issue

          topic_id: Update associated topic ID

          trace_id: Update associated trace ID

          type: Updated type/category

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/v0/issues/{id}",
            body=maybe_transform(
                {
                    "annotation_id": annotation_id,
                    "assigned_to": assigned_to,
                    "comment": comment,
                    "eval_definition_id": eval_definition_id,
                    "parent_id": parent_id,
                    "priority": priority,
                    "status": status,
                    "summary": summary,
                    "task_id": task_id,
                    "test_id": test_id,
                    "title": title,
                    "topic_id": topic_id,
                    "trace_id": trace_id,
                    "type": type,
                },
                issue_update_params.IssueUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IssueUpdateResponse,
        )

    def list(
        self,
        *,
        annotation_id: str | Omit = omit,
        assigned_to: str | Omit = omit,
        end: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        priority: IssuePriority | Omit = omit,
        skip: int | Omit = omit,
        source: IssueSource | Omit = omit,
        start: Union[str, datetime] | Omit = omit,
        status: IssueStatus | Omit = omit,
        test_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[GroupedIssueOutput]:
        """
        Retrieves a paginated list of issues with optional filtering by date range,
        status, priority, assignee, and more.

        Args:
          annotation_id: Filter by associated annotation ID

          assigned_to: Filter by assignee user ID

          end: End date (ISO8601) for filtering issues by creation date

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          priority: Filter by issue priority

          skip: Number of items to skip before starting to collect the result set.

          source: Filter by issue source

          start: Start date (ISO8601) for filtering issues by creation date

          status: Filter by issue status

          test_id: Filter by associated test ID

          type: Filter by issue type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/issues",
            page=SyncOffsetPagination[GroupedIssueOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "annotation_id": annotation_id,
                        "assigned_to": assigned_to,
                        "end": end,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "priority": priority,
                        "skip": skip,
                        "source": source,
                        "start": start,
                        "status": status,
                        "test_id": test_id,
                        "type": type,
                    },
                    issue_list_params.IssueListParams,
                ),
            ),
            model=GroupedIssueOutput,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes an existing issue permanently.

        Args:
          id: The unique identifier of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/v0/issues/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def bulk_update(
        self,
        *,
        issue_ids: SequenceNotStr[str],
        assigned_to: Optional[str] | Omit = omit,
        comment: str | Omit = omit,
        priority: IssuePriority | Omit = omit,
        status: IssueStatus | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IssueBulkUpdateResponse:
        """Updates status, priority, or assignment for multiple issues.

        Returns updated
        issues with assigned user information. User must be a valid organization member
        and not banned when assigning.

        Args:
          issue_ids: Array of issue IDs to update. Maximum 100 issues per request.

          assigned_to: User ID to assign all issues to, or null to unassign. User must be a valid
              organization member and not banned.

          comment: Optional comment to add when updating issues. Typically used when resolving or
              dismissing issues to provide context.

          priority: Updated priority level to apply to all specified issues

          status: Updated status to apply to all specified issues

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            "/v0/issues",
            body=maybe_transform(
                {
                    "issue_ids": issue_ids,
                    "assigned_to": assigned_to,
                    "comment": comment,
                    "priority": priority,
                    "status": status,
                },
                issue_bulk_update_params.IssueBulkUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IssueBulkUpdateResponse,
        )

    def list_minimal(
        self,
        *,
        annotation_id: str | Omit = omit,
        assigned_to: str | Omit = omit,
        end: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: Literal["createdAt", "priority"] | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        priority: IssuePriority | Omit = omit,
        skip: int | Omit = omit,
        source: IssueSource | Omit = omit,
        start: Union[str, datetime] | Omit = omit,
        status: IssueStatus | Omit = omit,
        test_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[IssueListMinimalResponse]:
        """
        Retrieves a paginated list of issues with only essential fields (id, title,
        status, source, priority, createdAt, assignedTo). Optimized for list views and
        performance. Supports sorting by createdAt and priority.

        Args:
          annotation_id: Filter by associated annotation ID

          assigned_to: Filter by assignee user ID

          end: End date (ISO8601) for filtering issues by creation date

          limit: Number of items to include in the result set.

          order_by: Field to order by (restricted to createdAt and priority)

          order_dir: Order direction.

          priority: Filter by issue priority

          skip: Number of items to skip before starting to collect the result set.

          source: Filter by issue source

          start: Start date (ISO8601) for filtering issues by creation date

          status: Filter by issue status

          test_id: Filter by associated test ID

          type: Filter by issue type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/issues/minimal",
            page=SyncOffsetPagination[IssueListMinimalResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "annotation_id": annotation_id,
                        "assigned_to": assigned_to,
                        "end": end,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "priority": priority,
                        "skip": skip,
                        "source": source,
                        "start": start,
                        "status": status,
                        "test_id": test_id,
                        "type": type,
                    },
                    issue_list_minimal_params.IssueListMinimalParams,
                ),
            ),
            model=IssueListMinimalResponse,
        )


class AsyncIssuesResource(AsyncAPIResource):
    @cached_property
    def suggested_task(self) -> AsyncSuggestedTaskResource:
        return AsyncSuggestedTaskResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncIssuesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncIssuesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncIssuesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncIssuesResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        source: IssueSource,
        title: str,
        annotation_id: str | Omit = omit,
        description: Optional[str] | Omit = omit,
        eval_definition_id: str | Omit = omit,
        parent_id: str | Omit = omit,
        priority: IssuePriority | Omit = omit,
        task_id: str | Omit = omit,
        test_id: str | Omit = omit,
        topic_id: str | Omit = omit,
        trace_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Creates a new issue for tracking problems or improvements.

        Args:
          source: Where the issue originated from

          title: Title of the issue

          annotation_id: Associated annotation ID if related to an annotation

          description: Detailed description of the issue

          eval_definition_id: Associated evaluation definition ID if issue came from an evaluation

          parent_id: Parent issue ID for creating sub-issues

          priority: Priority level of the issue

          task_id: Associated task ID if issue came from a task

          test_id: Associated test ID if issue came from a test

          topic_id: Associated topic ID if issue came from a topic

          trace_id: Associated trace ID for monitoring/debugging

          type: Type/category of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/issues",
            body=await async_maybe_transform(
                {
                    "source": source,
                    "title": title,
                    "annotation_id": annotation_id,
                    "description": description,
                    "eval_definition_id": eval_definition_id,
                    "parent_id": parent_id,
                    "priority": priority,
                    "task_id": task_id,
                    "test_id": test_id,
                    "topic_id": topic_id,
                    "trace_id": trace_id,
                    "type": type,
                },
                issue_create_params.IssueCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IssueRetrieveResponse:
        """
        Retrieves detailed information about a specific issue, including all
        duplicate/child issues in the issues array.

        Args:
          id: The unique identifier of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v0/issues/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IssueRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        annotation_id: Optional[str] | Omit = omit,
        assigned_to: Optional[str] | Omit = omit,
        comment: Optional[str] | Omit = omit,
        eval_definition_id: Optional[str] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        priority: IssuePriority | Omit = omit,
        status: IssueStatus | Omit = omit,
        summary: Optional[str] | Omit = omit,
        task_id: Optional[str] | Omit = omit,
        test_id: Optional[str] | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        trace_id: Optional[str] | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IssueUpdateResponse:
        """Updates an existing issue.

        Can be used to reassign, change status, update
        priority, or modify any other issue fields.

        Args:
          id: The unique identifier of the issue

          annotation_id: Update associated annotation ID

          assigned_to: Reassign the issue to a different user

          comment: Reason for resolving or dismissing the issue

          eval_definition_id: Update associated evaluation definition ID

          parent_id: Update parent issue ID for sub-issues

          priority: Updated priority level

          status: Updated status of the issue

          summary: Updated summary of the issue

          task_id: Update associated task ID

          test_id: Update associated test ID

          title: Updated title of the issue

          topic_id: Update associated topic ID

          trace_id: Update associated trace ID

          type: Updated type/category

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/v0/issues/{id}",
            body=await async_maybe_transform(
                {
                    "annotation_id": annotation_id,
                    "assigned_to": assigned_to,
                    "comment": comment,
                    "eval_definition_id": eval_definition_id,
                    "parent_id": parent_id,
                    "priority": priority,
                    "status": status,
                    "summary": summary,
                    "task_id": task_id,
                    "test_id": test_id,
                    "title": title,
                    "topic_id": topic_id,
                    "trace_id": trace_id,
                    "type": type,
                },
                issue_update_params.IssueUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IssueUpdateResponse,
        )

    def list(
        self,
        *,
        annotation_id: str | Omit = omit,
        assigned_to: str | Omit = omit,
        end: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        priority: IssuePriority | Omit = omit,
        skip: int | Omit = omit,
        source: IssueSource | Omit = omit,
        start: Union[str, datetime] | Omit = omit,
        status: IssueStatus | Omit = omit,
        test_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[GroupedIssueOutput, AsyncOffsetPagination[GroupedIssueOutput]]:
        """
        Retrieves a paginated list of issues with optional filtering by date range,
        status, priority, assignee, and more.

        Args:
          annotation_id: Filter by associated annotation ID

          assigned_to: Filter by assignee user ID

          end: End date (ISO8601) for filtering issues by creation date

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          priority: Filter by issue priority

          skip: Number of items to skip before starting to collect the result set.

          source: Filter by issue source

          start: Start date (ISO8601) for filtering issues by creation date

          status: Filter by issue status

          test_id: Filter by associated test ID

          type: Filter by issue type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/issues",
            page=AsyncOffsetPagination[GroupedIssueOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "annotation_id": annotation_id,
                        "assigned_to": assigned_to,
                        "end": end,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "priority": priority,
                        "skip": skip,
                        "source": source,
                        "start": start,
                        "status": status,
                        "test_id": test_id,
                        "type": type,
                    },
                    issue_list_params.IssueListParams,
                ),
            ),
            model=GroupedIssueOutput,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Deletes an existing issue permanently.

        Args:
          id: The unique identifier of the issue

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/v0/issues/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def bulk_update(
        self,
        *,
        issue_ids: SequenceNotStr[str],
        assigned_to: Optional[str] | Omit = omit,
        comment: str | Omit = omit,
        priority: IssuePriority | Omit = omit,
        status: IssueStatus | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> IssueBulkUpdateResponse:
        """Updates status, priority, or assignment for multiple issues.

        Returns updated
        issues with assigned user information. User must be a valid organization member
        and not banned when assigning.

        Args:
          issue_ids: Array of issue IDs to update. Maximum 100 issues per request.

          assigned_to: User ID to assign all issues to, or null to unassign. User must be a valid
              organization member and not banned.

          comment: Optional comment to add when updating issues. Typically used when resolving or
              dismissing issues to provide context.

          priority: Updated priority level to apply to all specified issues

          status: Updated status to apply to all specified issues

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            "/v0/issues",
            body=await async_maybe_transform(
                {
                    "issue_ids": issue_ids,
                    "assigned_to": assigned_to,
                    "comment": comment,
                    "priority": priority,
                    "status": status,
                },
                issue_bulk_update_params.IssueBulkUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=IssueBulkUpdateResponse,
        )

    def list_minimal(
        self,
        *,
        annotation_id: str | Omit = omit,
        assigned_to: str | Omit = omit,
        end: Union[str, datetime] | Omit = omit,
        limit: int | Omit = omit,
        order_by: Literal["createdAt", "priority"] | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        priority: IssuePriority | Omit = omit,
        skip: int | Omit = omit,
        source: IssueSource | Omit = omit,
        start: Union[str, datetime] | Omit = omit,
        status: IssueStatus | Omit = omit,
        test_id: str | Omit = omit,
        type: IssueType | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[IssueListMinimalResponse, AsyncOffsetPagination[IssueListMinimalResponse]]:
        """
        Retrieves a paginated list of issues with only essential fields (id, title,
        status, source, priority, createdAt, assignedTo). Optimized for list views and
        performance. Supports sorting by createdAt and priority.

        Args:
          annotation_id: Filter by associated annotation ID

          assigned_to: Filter by assignee user ID

          end: End date (ISO8601) for filtering issues by creation date

          limit: Number of items to include in the result set.

          order_by: Field to order by (restricted to createdAt and priority)

          order_dir: Order direction.

          priority: Filter by issue priority

          skip: Number of items to skip before starting to collect the result set.

          source: Filter by issue source

          start: Start date (ISO8601) for filtering issues by creation date

          status: Filter by issue status

          test_id: Filter by associated test ID

          type: Filter by issue type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/issues/minimal",
            page=AsyncOffsetPagination[IssueListMinimalResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "annotation_id": annotation_id,
                        "assigned_to": assigned_to,
                        "end": end,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "priority": priority,
                        "skip": skip,
                        "source": source,
                        "start": start,
                        "status": status,
                        "test_id": test_id,
                        "type": type,
                    },
                    issue_list_minimal_params.IssueListMinimalParams,
                ),
            ),
            model=IssueListMinimalResponse,
        )


class IssuesResourceWithRawResponse:
    def __init__(self, issues: IssuesResource) -> None:
        self._issues = issues

        self.create = to_raw_response_wrapper(
            issues.create,
        )
        self.retrieve = to_raw_response_wrapper(
            issues.retrieve,
        )
        self.update = to_raw_response_wrapper(
            issues.update,
        )
        self.list = to_raw_response_wrapper(
            issues.list,
        )
        self.delete = to_raw_response_wrapper(
            issues.delete,
        )
        self.bulk_update = to_raw_response_wrapper(
            issues.bulk_update,
        )
        self.list_minimal = to_raw_response_wrapper(
            issues.list_minimal,
        )

    @cached_property
    def suggested_task(self) -> SuggestedTaskResourceWithRawResponse:
        return SuggestedTaskResourceWithRawResponse(self._issues.suggested_task)


class AsyncIssuesResourceWithRawResponse:
    def __init__(self, issues: AsyncIssuesResource) -> None:
        self._issues = issues

        self.create = async_to_raw_response_wrapper(
            issues.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            issues.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            issues.update,
        )
        self.list = async_to_raw_response_wrapper(
            issues.list,
        )
        self.delete = async_to_raw_response_wrapper(
            issues.delete,
        )
        self.bulk_update = async_to_raw_response_wrapper(
            issues.bulk_update,
        )
        self.list_minimal = async_to_raw_response_wrapper(
            issues.list_minimal,
        )

    @cached_property
    def suggested_task(self) -> AsyncSuggestedTaskResourceWithRawResponse:
        return AsyncSuggestedTaskResourceWithRawResponse(self._issues.suggested_task)


class IssuesResourceWithStreamingResponse:
    def __init__(self, issues: IssuesResource) -> None:
        self._issues = issues

        self.create = to_streamed_response_wrapper(
            issues.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            issues.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            issues.update,
        )
        self.list = to_streamed_response_wrapper(
            issues.list,
        )
        self.delete = to_streamed_response_wrapper(
            issues.delete,
        )
        self.bulk_update = to_streamed_response_wrapper(
            issues.bulk_update,
        )
        self.list_minimal = to_streamed_response_wrapper(
            issues.list_minimal,
        )

    @cached_property
    def suggested_task(self) -> SuggestedTaskResourceWithStreamingResponse:
        return SuggestedTaskResourceWithStreamingResponse(self._issues.suggested_task)


class AsyncIssuesResourceWithStreamingResponse:
    def __init__(self, issues: AsyncIssuesResource) -> None:
        self._issues = issues

        self.create = async_to_streamed_response_wrapper(
            issues.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            issues.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            issues.update,
        )
        self.list = async_to_streamed_response_wrapper(
            issues.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            issues.delete,
        )
        self.bulk_update = async_to_streamed_response_wrapper(
            issues.bulk_update,
        )
        self.list_minimal = async_to_streamed_response_wrapper(
            issues.list_minimal,
        )

    @cached_property
    def suggested_task(self) -> AsyncSuggestedTaskResourceWithStreamingResponse:
        return AsyncSuggestedTaskResourceWithStreamingResponse(self._issues.suggested_task)
