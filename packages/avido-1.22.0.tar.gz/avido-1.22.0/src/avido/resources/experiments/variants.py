# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPagination, AsyncOffsetPagination
from ..._base_client import AsyncPaginator, make_request_options
from ...types.experiments import variant_list_params, variant_create_params, variant_update_params
from ...types.experiments.experiment_variant import ExperimentVariant
from ...types.experiments.experiment_variant_output import ExperimentVariantOutput

__all__ = ["VariantsResource", "AsyncVariantsResource"]


class VariantsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> VariantsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return VariantsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> VariantsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return VariantsResourceWithStreamingResponse(self)

    def create(
        self,
        id: str,
        *,
        config_patch: Dict[str, Dict[str, object]],
        description: str | Omit = omit,
        parent_id: str | Omit = omit,
        title: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExperimentVariant:
        """
        Creates a new variant for the specified experiment.

        Args:
          id: The unique identifier of the experiment

          config_patch: The config patch to apply to the system, entire config if baseline

          description: The variant description

          parent_id: Parent variant ID for inherited variants (non-baseline variants)

          title: The title of the variant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/v0/experiments/{id}/variants",
            body=maybe_transform(
                {
                    "config_patch": config_patch,
                    "description": description,
                    "parent_id": parent_id,
                    "title": title,
                },
                variant_create_params.VariantCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExperimentVariant,
        )

    def update(
        self,
        variant_id: str,
        *,
        id: str,
        config_patch: Dict[str, Dict[str, object]] | Omit = omit,
        description: str | Omit = omit,
        status: Literal["REJECTED"] | Omit = omit,
        title: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExperimentVariant:
        """Updates a specific experiment variant.

        Only title, description, and configPatch
        can be updated.

        Args:
          id: The unique identifier of the experiment

          variant_id: The unique identifier of the variant

          config_patch: The config patch to apply to the system, entire config if baseline

          description: Updated description of the variant

          title: Updated title of the variant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not variant_id:
            raise ValueError(f"Expected a non-empty value for `variant_id` but received {variant_id!r}")
        return self._put(
            f"/v0/experiments/{id}/variants/{variant_id}",
            body=maybe_transform(
                {
                    "config_patch": config_patch,
                    "description": description,
                    "status": status,
                    "title": title,
                },
                variant_update_params.VariantUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExperimentVariant,
        )

    def list(
        self,
        id: str,
        *,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[ExperimentVariantOutput]:
        """
        Retrieves a paginated list of variants for the specified experiment.

        Args:
          id: The unique identifier of the experiment

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            f"/v0/experiments/{id}/variants",
            page=SyncOffsetPagination[ExperimentVariantOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                    },
                    variant_list_params.VariantListParams,
                ),
            ),
            model=ExperimentVariantOutput,
        )

    def trigger(
        self,
        variant_id: str,
        *,
        id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Triggers execution of all tasks associated with the experiment for the specified
        variant. Returns 204 No Content on success.

        Args:
          id: The unique identifier of the experiment

          variant_id: The unique identifier of the variant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not variant_id:
            raise ValueError(f"Expected a non-empty value for `variant_id` but received {variant_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            f"/v0/experiments/{id}/variants/{variant_id}/trigger",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncVariantsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncVariantsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncVariantsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncVariantsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncVariantsResourceWithStreamingResponse(self)

    async def create(
        self,
        id: str,
        *,
        config_patch: Dict[str, Dict[str, object]],
        description: str | Omit = omit,
        parent_id: str | Omit = omit,
        title: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExperimentVariant:
        """
        Creates a new variant for the specified experiment.

        Args:
          id: The unique identifier of the experiment

          config_patch: The config patch to apply to the system, entire config if baseline

          description: The variant description

          parent_id: Parent variant ID for inherited variants (non-baseline variants)

          title: The title of the variant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/v0/experiments/{id}/variants",
            body=await async_maybe_transform(
                {
                    "config_patch": config_patch,
                    "description": description,
                    "parent_id": parent_id,
                    "title": title,
                },
                variant_create_params.VariantCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExperimentVariant,
        )

    async def update(
        self,
        variant_id: str,
        *,
        id: str,
        config_patch: Dict[str, Dict[str, object]] | Omit = omit,
        description: str | Omit = omit,
        status: Literal["REJECTED"] | Omit = omit,
        title: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExperimentVariant:
        """Updates a specific experiment variant.

        Only title, description, and configPatch
        can be updated.

        Args:
          id: The unique identifier of the experiment

          variant_id: The unique identifier of the variant

          config_patch: The config patch to apply to the system, entire config if baseline

          description: Updated description of the variant

          title: Updated title of the variant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not variant_id:
            raise ValueError(f"Expected a non-empty value for `variant_id` but received {variant_id!r}")
        return await self._put(
            f"/v0/experiments/{id}/variants/{variant_id}",
            body=await async_maybe_transform(
                {
                    "config_patch": config_patch,
                    "description": description,
                    "status": status,
                    "title": title,
                },
                variant_update_params.VariantUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExperimentVariant,
        )

    def list(
        self,
        id: str,
        *,
        limit: int | Omit = omit,
        order_by: str | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        skip: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ExperimentVariantOutput, AsyncOffsetPagination[ExperimentVariantOutput]]:
        """
        Retrieves a paginated list of variants for the specified experiment.

        Args:
          id: The unique identifier of the experiment

          limit: Number of items to include in the result set.

          order_by: Field to order by in the result set.

          order_dir: Order direction.

          skip: Number of items to skip before starting to collect the result set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            f"/v0/experiments/{id}/variants",
            page=AsyncOffsetPagination[ExperimentVariantOutput],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "skip": skip,
                    },
                    variant_list_params.VariantListParams,
                ),
            ),
            model=ExperimentVariantOutput,
        )

    async def trigger(
        self,
        variant_id: str,
        *,
        id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Triggers execution of all tasks associated with the experiment for the specified
        variant. Returns 204 No Content on success.

        Args:
          id: The unique identifier of the experiment

          variant_id: The unique identifier of the variant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not variant_id:
            raise ValueError(f"Expected a non-empty value for `variant_id` but received {variant_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            f"/v0/experiments/{id}/variants/{variant_id}/trigger",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class VariantsResourceWithRawResponse:
    def __init__(self, variants: VariantsResource) -> None:
        self._variants = variants

        self.create = to_raw_response_wrapper(
            variants.create,
        )
        self.update = to_raw_response_wrapper(
            variants.update,
        )
        self.list = to_raw_response_wrapper(
            variants.list,
        )
        self.trigger = to_raw_response_wrapper(
            variants.trigger,
        )


class AsyncVariantsResourceWithRawResponse:
    def __init__(self, variants: AsyncVariantsResource) -> None:
        self._variants = variants

        self.create = async_to_raw_response_wrapper(
            variants.create,
        )
        self.update = async_to_raw_response_wrapper(
            variants.update,
        )
        self.list = async_to_raw_response_wrapper(
            variants.list,
        )
        self.trigger = async_to_raw_response_wrapper(
            variants.trigger,
        )


class VariantsResourceWithStreamingResponse:
    def __init__(self, variants: VariantsResource) -> None:
        self._variants = variants

        self.create = to_streamed_response_wrapper(
            variants.create,
        )
        self.update = to_streamed_response_wrapper(
            variants.update,
        )
        self.list = to_streamed_response_wrapper(
            variants.list,
        )
        self.trigger = to_streamed_response_wrapper(
            variants.trigger,
        )


class AsyncVariantsResourceWithStreamingResponse:
    def __init__(self, variants: AsyncVariantsResource) -> None:
        self._variants = variants

        self.create = async_to_streamed_response_wrapper(
            variants.create,
        )
        self.update = async_to_streamed_response_wrapper(
            variants.update,
        )
        self.list = async_to_streamed_response_wrapper(
            variants.list,
        )
        self.trigger = async_to_streamed_response_wrapper(
            variants.trigger,
        )
