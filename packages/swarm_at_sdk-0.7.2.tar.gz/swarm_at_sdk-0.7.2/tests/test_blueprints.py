"""Tests for Blueprint Store: transaction chain templates and settlement credits."""

from __future__ import annotations

import pytest

from swarm_at.blueprints import (
    Blueprint,
    BlueprintError,
    BlueprintStep,
    BlueprintStore,
    InsufficientCreditsError,
)


@pytest.fixture()
def store() -> BlueprintStore:
    return BlueprintStore()


def make_blueprint(
    blueprint_id: str = "bp-audit-1",
    name: str = "Public Domain Audit",
    tags: list[str] | None = None,
    steps: list[BlueprintStep] | None = None,
    credit_cost: float = 1.0,
) -> Blueprint:
    """Factory for test blueprints."""
    return Blueprint(
        blueprint_id=blueprint_id,
        name=name,
        tags=tags or ["audit", "compliance"],
        steps=steps or [
            BlueprintStep(step_id="s1", name="Extract"),
            BlueprintStep(step_id="s2", name="Verify", depends_on=["s1"]),
            BlueprintStep(step_id="s3", name="Settle", depends_on=["s2"]),
        ],
        credit_cost=credit_cost,
    )


class TestBlueprintRegistration:
    def test_register_blueprint(self, store: BlueprintStore) -> None:
        bp = make_blueprint()
        result = store.register_blueprint(bp)
        assert result.blueprint_id == "bp-audit-1"
        assert store.blueprint_count == 1

    def test_duplicate_raises(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint())
        with pytest.raises(BlueprintError, match="already registered"):
            store.register_blueprint(make_blueprint())

    def test_get_blueprint(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint())
        bp = store.get_blueprint("bp-audit-1")
        assert bp.name == "Public Domain Audit"

    def test_get_unknown_raises(self, store: BlueprintStore) -> None:
        with pytest.raises(BlueprintError, match="not found"):
            store.get_blueprint("nonexistent")

    def test_list_blueprints(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint(blueprint_id="bp-1", name="A"))
        store.register_blueprint(make_blueprint(blueprint_id="bp-2", name="B"))
        assert len(store.list_blueprints()) == 2

    def test_list_filtered_by_tag(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint(blueprint_id="bp-1", tags=["audit"]))
        store.register_blueprint(make_blueprint(blueprint_id="bp-2", tags=["soc2"]))
        results = store.list_blueprints(tag="soc2")
        assert len(results) == 1
        assert results[0].blueprint_id == "bp-2"

    def test_list_validated_only(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint(blueprint_id="bp-1"))
        store.register_blueprint(make_blueprint(blueprint_id="bp-2"))
        store.validate_blueprint("bp-1", validation_hash="abc123")
        results = store.list_blueprints(validated_only=True)
        assert len(results) == 1


class TestBlueprintValidation:
    def test_validate_sets_hash(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint())
        bp = store.validate_blueprint("bp-audit-1", validation_hash="deadbeef")
        assert bp.validated is True
        assert bp.validation_hash == "deadbeef"


class TestBlueprintForking:
    def test_fork_validated_blueprint(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint())
        store.validate_blueprint("bp-audit-1", validation_hash="ok")
        forked = store.fork_blueprint("bp-audit-1", account_id="builder-1")
        assert forked.blueprint_id == "bp-audit-1"
        assert store.fork_count("bp-audit-1") == 1

    def test_fork_unvalidated_raises(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint())
        with pytest.raises(BlueprintError, match="must be validated"):
            store.fork_blueprint("bp-audit-1", account_id="builder-1")

    def test_multiple_forks_tracked(self, store: BlueprintStore) -> None:
        store.register_blueprint(make_blueprint())
        store.validate_blueprint("bp-audit-1", validation_hash="ok")
        store.fork_blueprint("bp-audit-1", "builder-1")
        store.fork_blueprint("bp-audit-1", "builder-2")
        assert store.fork_count("bp-audit-1") == 2


class TestCreditAccounts:
    def test_create_account(self, store: BlueprintStore) -> None:
        acc = store.create_account("builder-1", initial_balance=100.0)
        assert acc.balance == 100.0

    def test_duplicate_account_raises(self, store: BlueprintStore) -> None:
        store.create_account("builder-1")
        with pytest.raises(BlueprintError, match="already exists"):
            store.create_account("builder-1")

    def test_charge_settlement_deducts_credits(self, store: BlueprintStore) -> None:
        store.create_account("builder-1", initial_balance=10.0)
        store.register_blueprint(make_blueprint(credit_cost=2.0))
        store.validate_blueprint("bp-audit-1", validation_hash="ok")
        acc = store.charge_settlement("builder-1", "bp-audit-1")
        assert acc.balance == pytest.approx(8.0)
        assert acc.total_spent == pytest.approx(2.0)

    def test_insufficient_credits_raises(self, store: BlueprintStore) -> None:
        store.create_account("builder-1", initial_balance=0.5)
        store.register_blueprint(make_blueprint(credit_cost=2.0))
        with pytest.raises(InsufficientCreditsError):
            store.charge_settlement("builder-1", "bp-audit-1")

    def test_earn_credits_increases_balance(self, store: BlueprintStore) -> None:
        store.create_account("builder-1", initial_balance=5.0)
        acc = store.earn_credits("builder-1", 3.0)
        assert acc.balance == pytest.approx(8.0)
        assert acc.total_earned == pytest.approx(3.0)


class TestBlueprintSteps:
    def test_steps_have_dependencies(self) -> None:
        bp = make_blueprint()
        assert bp.steps[1].depends_on == ["s1"]
        assert bp.steps[2].depends_on == ["s2"]

    def test_step_complexity_in_range(self) -> None:
        step = BlueprintStep(step_id="s1", name="Test", complexity=0.8)
        assert step.complexity == 0.8
