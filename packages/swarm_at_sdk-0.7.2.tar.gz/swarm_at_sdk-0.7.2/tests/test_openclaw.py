"""Tests for swarm_at.openclaw — discovery document generators."""

from __future__ import annotations

import pytest

from swarm_at.openclaw import (
    enrich_openapi,
    generate_agent_card,
    generate_ai_plugin,
    generate_api_sitemap,
    generate_discovery_index,
    generate_jsonld,
    generate_llms_txt,
    generate_mcp_json,
    generate_robots_txt,
    generate_security_txt,
)

API_URL = "https://api.swarm.at"
SITE_URL = "https://swarm.at"


# ---------------------------------------------------------------------------
# TestLlmsTxt
# ---------------------------------------------------------------------------


class TestLlmsTxt:
    """llms.txt v1.1.0 generation."""

    def test_contains_protocol_name(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        assert "# swarm.at" in txt

    def test_contains_required_sections(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        for section in ["## Endpoints", "## MCP Tools", "## Quick Start", "## Settlement Tiers", "## Trust Model"]:
            assert section in txt, f"Missing section: {section}"

    def test_endpoint_links(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        assert f"{API_URL}/v1/settle" in txt
        assert f"{API_URL}/v1/context" in txt
        assert f"{API_URL}/public/ledger" in txt
        assert f"{API_URL}/public/agents" in txt
        assert f"{API_URL}/public/blueprints" in txt

    def test_mcp_mention(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        assert "settle_action" in txt
        assert "check_settlement" in txt
        assert "ledger_status" in txt

    def test_trust_levels(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        for level in ["untrusted", "provisional", "trusted", "senior"]:
            assert level in txt


# ---------------------------------------------------------------------------
# TestAgentCard
# ---------------------------------------------------------------------------


class TestAgentCard:
    """A2A agent card generation."""

    def test_required_fields(self) -> None:
        card = generate_agent_card(API_URL)
        for field in ["name", "description", "url", "version", "skills"]:
            assert field in card, f"Missing A2A field: {field}"

    def test_skills_match_mcp_tools(self) -> None:
        card = generate_agent_card(API_URL)
        skill_ids = {s["id"] for s in card["skills"]}
        assert skill_ids == {
            "guard_action", "settle_action", "check_settlement",
            "ledger_status", "list_blueprints", "get_blueprint",
            "fork_blueprint", "verify_receipt", "check_trust",
            "get_credits", "topup_credits",
            "claim_authorship", "verify_authorship",
            "start_writing_session", "record_writing_event",
            "approve_writing", "get_provenance_report",
            "list_writing_sessions",
        }

    def test_auth_structure(self) -> None:
        card = generate_agent_card(API_URL)
        auth = card["authentication"]
        assert "bearer" in auth["schemes"]

    def test_service_url(self) -> None:
        card = generate_agent_card(API_URL)
        assert card["serviceUrl"] == API_URL

    def test_capabilities(self) -> None:
        card = generate_agent_card(API_URL)
        assert "capabilities" in card
        assert isinstance(card["capabilities"], dict)


# ---------------------------------------------------------------------------
# TestRobotsTxt
# ---------------------------------------------------------------------------


class TestRobotsTxt:
    """robots.txt generation."""

    def test_allows_crawlers(self) -> None:
        txt = generate_robots_txt(API_URL)
        assert "User-agent: *" in txt
        assert "Allow: /" in txt

    def test_references_sitemap(self) -> None:
        txt = generate_robots_txt(API_URL)
        assert f"Sitemap: {API_URL}/sitemap.xml" in txt

    def test_valid_format(self) -> None:
        txt = generate_robots_txt(API_URL)
        lines = [line.strip() for line in txt.strip().splitlines() if line.strip()]
        assert len(lines) >= 2
        assert lines[0].startswith("User-agent:")


# ---------------------------------------------------------------------------
# TestJsonLd
# ---------------------------------------------------------------------------


class TestJsonLd:
    """Schema.org JSON-LD generation."""

    def test_context(self) -> None:
        ld = generate_jsonld(API_URL, SITE_URL)
        assert ld["@context"] == "https://schema.org"

    def test_type_is_webapi(self) -> None:
        ld = generate_jsonld(API_URL, SITE_URL)
        assert ld["@type"] == "WebAPI"

    def test_correct_urls(self) -> None:
        ld = generate_jsonld(API_URL, SITE_URL)
        assert ld["url"] == API_URL
        assert SITE_URL in ld["documentation"]


# ---------------------------------------------------------------------------
# TestEnrichOpenApi
# ---------------------------------------------------------------------------


class TestEnrichOpenApi:
    """OpenAPI enrichment."""

    @pytest.fixture()
    def base_schema(self) -> dict:
        return {
            "openapi": "3.1.0",
            "info": {"title": "swarm.at", "version": "0.1.0"},
            "paths": {
                "/v1/settle": {
                    "post": {"summary": "Submit a proposal"}
                },
                "/health": {
                    "get": {"summary": "Health check"}
                },
            },
        }

    def test_servers_added(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        assert "servers" in enriched
        urls = [s["url"] for s in enriched["servers"]]
        assert API_URL in urls

    def test_tags_added(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        assert "tags" in enriched
        tag_names = {t["name"] for t in enriched["tags"]}
        assert "settlement" in tag_names
        assert "discovery" in tag_names

    def test_authorship_tag_present(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        tag_names = {t["name"] for t in enriched["tags"]}
        assert "authorship" in tag_names

    def test_examples_present(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        settle_post = enriched["paths"]["/v1/settle"]["post"]
        assert "x-example" in settle_post

    def test_existing_paths_preserved(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        assert "/health" in enriched["paths"]
        assert "/v1/settle" in enriched["paths"]


# ---------------------------------------------------------------------------
# TestPureFunctions
# ---------------------------------------------------------------------------


class TestPureFunctions:
    """Verify generators are deterministic and side-effect-free."""

    def test_llms_txt_deterministic(self) -> None:
        a = generate_llms_txt(API_URL, SITE_URL)
        b = generate_llms_txt(API_URL, SITE_URL)
        assert a == b

    def test_agent_card_deterministic(self) -> None:
        a = generate_agent_card(API_URL)
        b = generate_agent_card(API_URL)
        assert a == b

    def test_no_mutation_of_input(self) -> None:
        schema = {"openapi": "3.1.0", "info": {"title": "test"}, "paths": {}}
        original_keys = set(schema.keys())
        enrich_openapi(schema, api_url=API_URL)
        assert set(schema.keys()) == original_keys

    def test_security_txt_deterministic(self) -> None:
        a = generate_security_txt(SITE_URL)
        b = generate_security_txt(SITE_URL)
        assert a == b

    def test_ai_plugin_deterministic(self) -> None:
        a = generate_ai_plugin(API_URL)
        b = generate_ai_plugin(API_URL)
        assert a == b

    def test_mcp_json_deterministic(self) -> None:
        a = generate_mcp_json(API_URL)
        b = generate_mcp_json(API_URL)
        assert a == b


# ---------------------------------------------------------------------------
# TestSecurityTxt
# ---------------------------------------------------------------------------


class TestSecurityTxt:
    """security.txt generation per RFC 9116."""

    def test_contains_contact(self) -> None:
        txt = generate_security_txt(SITE_URL)
        assert "Contact:" in txt

    def test_contains_expires(self) -> None:
        txt = generate_security_txt(SITE_URL)
        assert "Expires:" in txt

    def test_contains_canonical_with_site_url(self) -> None:
        txt = generate_security_txt(SITE_URL)
        assert "Canonical:" in txt
        assert SITE_URL in txt

    def test_returns_string(self) -> None:
        txt = generate_security_txt(SITE_URL)
        assert isinstance(txt, str)


# ---------------------------------------------------------------------------
# TestAiPlugin
# ---------------------------------------------------------------------------


class TestAiPlugin:
    """OpenAI plugin manifest generation."""

    def test_schema_version(self) -> None:
        plugin = generate_ai_plugin(API_URL)
        assert plugin["schema_version"] == "v1"

    def test_name_fields(self) -> None:
        plugin = generate_ai_plugin(API_URL)
        assert "name_for_human" in plugin
        assert "name_for_model" in plugin

    def test_description_for_model(self) -> None:
        plugin = generate_ai_plugin(API_URL)
        assert "description_for_model" in plugin
        assert isinstance(plugin["description_for_model"], str)

    def test_auth_type(self) -> None:
        plugin = generate_ai_plugin(API_URL)
        assert plugin["auth"]["type"] == "service_http"

    def test_api_url_contains_api_url(self) -> None:
        plugin = generate_ai_plugin(API_URL)
        assert API_URL in plugin["api"]["url"]

    def test_returns_dict(self) -> None:
        plugin = generate_ai_plugin(API_URL)
        assert isinstance(plugin, dict)


# ---------------------------------------------------------------------------
# TestDiscoveryIndex
# ---------------------------------------------------------------------------


class TestDiscoveryIndex:
    """Discovery index generation."""

    def test_protocol_field(self) -> None:
        idx = generate_discovery_index(API_URL, SITE_URL)
        assert idx["protocol"] == "swarm.at"

    def test_version_field(self) -> None:
        idx = generate_discovery_index(API_URL, SITE_URL)
        assert "version" in idx

    def test_discovery_dict_has_expected_keys(self) -> None:
        idx = generate_discovery_index(API_URL, SITE_URL)
        discovery = idx["discovery"]
        for key in ["llms_txt", "agent_card", "openapi", "ai_plugin", "mcp_json"]:
            assert key in discovery, f"Missing discovery key: {key}"

    def test_public_endpoints_present(self) -> None:
        idx = generate_discovery_index(API_URL, SITE_URL)
        assert "public_endpoints" in idx
        assert isinstance(idx["public_endpoints"], dict)

    def test_discovery_urls_contain_api_url(self) -> None:
        idx = generate_discovery_index(API_URL, SITE_URL)
        for key, url in idx["discovery"].items():
            assert API_URL in url, f"discovery[{key!r}] does not contain api_url"

    def test_returns_dict(self) -> None:
        idx = generate_discovery_index(API_URL, SITE_URL)
        assert isinstance(idx, dict)


# ---------------------------------------------------------------------------
# TestApiSitemap
# ---------------------------------------------------------------------------


class TestApiSitemap:
    """API sitemap generation."""

    def test_contains_urlset(self) -> None:
        xml = generate_api_sitemap(API_URL)
        assert "<urlset" in xml

    def test_contains_url_loc_entries(self) -> None:
        xml = generate_api_sitemap(API_URL)
        assert "<url><loc>" in xml

    def test_contains_api_url(self) -> None:
        xml = generate_api_sitemap(API_URL)
        assert f"{API_URL}/llms.txt" in xml

    def test_returns_string(self) -> None:
        xml = generate_api_sitemap(API_URL)
        assert isinstance(xml, str)


# ---------------------------------------------------------------------------
# TestMcpJson
# ---------------------------------------------------------------------------


class TestMcpJson:
    """MCP server discovery document generation."""

    def test_name_field(self) -> None:
        doc = generate_mcp_json(API_URL)
        assert "name" in doc

    def test_version_field(self) -> None:
        doc = generate_mcp_json(API_URL)
        assert "version" in doc

    def test_tool_count_is_18(self) -> None:
        doc = generate_mcp_json(API_URL)
        assert doc["tool_count"] == 18

    def test_install_field(self) -> None:
        doc = generate_mcp_json(API_URL)
        assert "install" in doc
        assert isinstance(doc["install"], str)

    def test_registry_field(self) -> None:
        doc = generate_mcp_json(API_URL)
        assert "registry" in doc

    def test_openapi_contains_api_url(self) -> None:
        doc = generate_mcp_json(API_URL)
        assert API_URL in doc["openapi"]

    def test_returns_dict(self) -> None:
        doc = generate_mcp_json(API_URL)
        assert isinstance(doc, dict)
