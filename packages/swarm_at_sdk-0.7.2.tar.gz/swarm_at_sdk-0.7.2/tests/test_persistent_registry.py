"""Tests for PersistentAgentRegistry — append-only JSONL event log."""

from __future__ import annotations

from pathlib import Path

import pytest

from swarm_at.agents import (
    AgentError,
    AgentRole,
    PersistentAgentRegistry,
    TrustLevel,
)


@pytest.fixture()
def registry_path(tmp_path: Path) -> Path:
    return tmp_path / "registry.jsonl"


@pytest.fixture()
def registry(registry_path: Path) -> PersistentAgentRegistry:
    return PersistentAgentRegistry(path=registry_path)


class TestPersistence:
    """Events written to disk and replayed on restart."""

    def test_register_persists(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("agent-1", role=AgentRole.WORKER, capabilities=["python"])
        # Rebuild from disk
        restored = PersistentAgentRegistry(path=registry_path)
        agent = restored.get("agent-1")
        assert agent.role == AgentRole.WORKER
        assert agent.capabilities == ["python"]

    def test_settlement_persists(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(5):
            registry.record_settlement("agent-1", success=True, complexity=0.8)
        restored = PersistentAgentRegistry(path=registry_path)
        agent = restored.get("agent-1")
        assert agent.settlements_completed == 5
        assert agent.reputation_score > 0

    def test_divergence_persists(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(5):
            registry.record_settlement("agent-1", success=True)
        registry.record_divergence("agent-1", penalty=0.05, critical=False)
        restored = PersistentAgentRegistry(path=registry_path)
        agent = restored.get("agent-1")
        assert agent.divergence_penalty == pytest.approx(0.05)

    def test_critical_divergence_persists(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(5):
            registry.record_settlement("agent-1", success=True)
        registry.record_divergence("agent-1", penalty=0.5, critical=True)
        restored = PersistentAgentRegistry(path=registry_path)
        agent = restored.get("agent-1")
        assert agent.under_review is True
        assert agent.trust_level == TrustLevel.UNTRUSTED

    def test_reinstate_persists(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(5):
            registry.record_settlement("agent-1", success=True)
        registry.record_divergence("agent-1", critical=True)
        registry.reinstate("agent-1")
        restored = PersistentAgentRegistry(path=registry_path)
        agent = restored.get("agent-1")
        assert agent.under_review is False
        assert agent.divergence_penalty == 0.0

    def test_revoke_persists(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("agent-1")
        registry.revoke("agent-1")
        restored = PersistentAgentRegistry(path=registry_path)
        with pytest.raises(AgentError):
            restored.get("agent-1")
        assert restored.count == 0

    def test_trust_promotion_survives_restart(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(25):
            registry.record_settlement("agent-1", success=True, complexity=0.7)
        assert registry.get("agent-1").trust_level == TrustLevel.TRUSTED
        restored = PersistentAgentRegistry(path=registry_path)
        assert restored.get("agent-1").trust_level == TrustLevel.TRUSTED


class TestReplayEdgeCases:
    """Handles corrupt lines, empty files, missing files."""

    def test_empty_file(self, registry_path: Path) -> None:
        registry_path.write_text("")
        reg = PersistentAgentRegistry(path=registry_path)
        assert reg.count == 0

    def test_missing_file(self, registry_path: Path) -> None:
        reg = PersistentAgentRegistry(path=registry_path)
        assert reg.count == 0

    def test_corrupt_line_skipped(self, registry_path: Path) -> None:
        registry_path.write_text(
            '{"event":"register","agent_id":"good","role":"worker","capabilities":[]}\n'
            "NOT VALID JSON\n"
            '{"event":"register","agent_id":"also-good","role":"worker","capabilities":[]}\n'
        )
        reg = PersistentAgentRegistry(path=registry_path)
        assert reg.count == 2

    def test_unknown_event_skipped(self, registry_path: Path) -> None:
        registry_path.write_text(
            '{"event":"register","agent_id":"agent-1","role":"worker","capabilities":[]}\n'
            '{"event":"time_travel","agent_id":"agent-1"}\n'
        )
        reg = PersistentAgentRegistry(path=registry_path)
        assert reg.count == 1


class TestFileGrowth:
    """Event log grows append-only, never rewrites."""

    def test_append_only(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        registry.register("a1")
        size_after_register = registry_path.stat().st_size
        registry.record_settlement("a1", success=True)
        size_after_settlement = registry_path.stat().st_size
        assert size_after_settlement > size_after_register

    def test_multiple_agents(self, registry_path: Path, registry: PersistentAgentRegistry) -> None:
        for i in range(10):
            registry.register(f"agent-{i}")
        restored = PersistentAgentRegistry(path=registry_path)
        assert restored.count == 10
        lines = registry_path.read_text().strip().splitlines()
        assert len(lines) == 10


class TestSeedOnFirstBoot:
    """Canonical agents seeded when registry is empty."""

    def test_seed_via_state_module(self, tmp_path: Path) -> None:
        """PersistentAgentRegistry + seed_registry works end-to-end."""
        from swarm_at.seed import CANONICAL_AGENTS, seed_registry

        reg = PersistentAgentRegistry(path=tmp_path / "registry.jsonl")
        seed_registry(reg)
        assert reg.count == len(CANONICAL_AGENTS)
        # Verify persistence
        restored = PersistentAgentRegistry(path=tmp_path / "registry.jsonl")
        assert restored.count == len(CANONICAL_AGENTS)
        agent = restored.get("orchestrator-prime")
        assert agent.trust_level == TrustLevel.SENIOR
        assert agent.settlements_completed == 150
