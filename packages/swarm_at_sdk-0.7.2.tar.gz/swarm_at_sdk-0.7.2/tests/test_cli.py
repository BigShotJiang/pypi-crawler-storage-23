"""Tests for the swarm CLI.

Uses Click's CliRunner for isolated, in-process invocation.
All tests run in local mode with tmp_path ledgers.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from swarm_at.cli import (
    CliContext,
    _load_config,
    _save_config,
    main,
)
from swarm_at.settler import GENESIS_HASH


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

runner = CliRunner()


def invoke(*args: str, env: dict[str, str] | None = None) -> Any:
    """Run the CLI, allow SystemExit (Click converts to exit_code)."""
    return runner.invoke(main, list(args), env=env)


def invoke_local(*args: str, ledger_path: str = "", env: dict[str, str] | None = None) -> Any:
    """Run CLI in explicit local mode with a ledger path."""
    base = ["--local"]
    if ledger_path:
        base += ["--ledger-path", ledger_path]
    return invoke(*base, *args, env=env)


def settle_one(ledger_path: str, action: str = "test-action") -> str:
    """Settle one entry and return the hash."""
    result = invoke_local("settle", action, "--agent", "test-agent",
                          ledger_path=ledger_path)
    assert result.exit_code == 0, result.output
    for line in result.output.splitlines():
        if line.startswith("hash:"):
            return line.split(": ", 1)[1].strip()
    raise AssertionError(f"No hash in output: {result.output}")


# ---------------------------------------------------------------------------
# --help
# ---------------------------------------------------------------------------


class TestHelp:
    def test_main_help(self) -> None:
        result = invoke("--help")
        assert result.exit_code == 0
        assert "swarm" in result.output.lower()

    def test_settle_help(self) -> None:
        result = invoke("settle", "--help")
        assert result.exit_code == 0
        assert "--agent" in result.output

    def test_status_help(self) -> None:
        result = invoke("status", "--help")
        assert result.exit_code == 0

    def test_ledger_help(self) -> None:
        result = invoke("ledger", "--help")
        assert result.exit_code == 0
        assert "list" in result.output
        assert "verify" in result.output

    def test_agents_help(self) -> None:
        result = invoke("agents", "--help")
        assert result.exit_code == 0

    def test_blueprints_help(self) -> None:
        result = invoke("blueprints", "--help")
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


class TestStatus:
    def test_status_empty_ledger(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("status", ledger_path=lp)
        assert result.exit_code == 0
        assert "local" in result.output
        assert GENESIS_HASH in result.output
        assert "entry_count: 0" in result.output

    def test_status_with_entries(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        settle_one(lp)
        result = invoke_local("status", ledger_path=lp)
        assert result.exit_code == 0
        assert "entry_count: 1" in result.output
        assert "chain_intact: True" in result.output

    def test_status_json(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke("--local", "--ledger-path", lp, "--json", "status")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["mode"] == "local"
        assert data["entry_count"] == 0


# ---------------------------------------------------------------------------
# settle
# ---------------------------------------------------------------------------


class TestSettle:
    def test_settle_local(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("settle", "research", "--agent", "bot-1",
                              ledger_path=lp)
        assert result.exit_code == 0
        assert "SETTLED" in result.output

    def test_settle_with_data(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("settle", "analyze", "--data", '{"key": "val"}',
                              ledger_path=lp)
        assert result.exit_code == 0
        assert "SETTLED" in result.output

    def test_settle_bad_json(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("settle", "action", "--data", "not-json",
                              ledger_path=lp)
        assert result.exit_code == 1
        assert "Invalid JSON" in result.output

    def test_settle_sandbox_tier(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("settle", "sandbox-test", "--tier", "sandbox",
                              ledger_path=lp)
        assert result.exit_code == 0
        assert "SETTLED" in result.output

    def test_settle_json_output(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke("--local", "--ledger-path", lp, "--json",
                        "settle", "test")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "SETTLED"
        assert len(data["hash"]) == 64

    def test_settle_custom_confidence(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("settle", "high-conf", "--confidence", "0.99",
                              ledger_path=lp)
        assert result.exit_code == 0
        assert "SETTLED" in result.output


# ---------------------------------------------------------------------------
# ledger list / verify
# ---------------------------------------------------------------------------


class TestLedger:
    def test_list_empty(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("ledger", "list", ledger_path=lp)
        assert result.exit_code == 0
        assert "0 of 0" in result.output

    def test_list_with_entries(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        settle_one(lp, "action-1")
        settle_one(lp, "action-2")
        result = invoke_local("ledger", "list", ledger_path=lp)
        assert result.exit_code == 0
        assert "2 of 2" in result.output

    def test_list_with_limit(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        for i in range(5):
            settle_one(lp, f"action-{i}")
        result = invoke_local("ledger", "list", "--limit", "2", ledger_path=lp)
        assert result.exit_code == 0
        assert "2 of 5" in result.output

    def test_list_with_offset(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        for i in range(5):
            settle_one(lp, f"action-{i}")
        result = invoke_local("ledger", "list", "--offset", "3", ledger_path=lp)
        assert result.exit_code == 0
        assert "2 of 5" in result.output

    def test_list_json(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        settle_one(lp)
        result = invoke("--local", "--ledger-path", lp, "--json",
                        "ledger", "list")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 1
        assert "current_hash" in data[0]

    def test_list_filter_task_id(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        settle_one(lp, "target-action")
        settle_one(lp, "other-action")
        # task_id is auto-generated UUID, so filtering by "nonexistent" returns 0
        result = invoke_local("ledger", "list", "--task-id", "nonexistent",
                              ledger_path=lp)
        assert result.exit_code == 0
        assert "0 of 0" in result.output

    def test_verify_found(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        h = settle_one(lp)
        result = invoke_local("ledger", "verify", h, ledger_path=lp)
        assert result.exit_code == 0
        assert "found: True" in result.output

    def test_verify_not_found(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("ledger", "verify", "a" * 64, ledger_path=lp)
        assert result.exit_code == 0
        assert "found: False" in result.output


# ---------------------------------------------------------------------------
# agents (local — server-only guard)
# ---------------------------------------------------------------------------


class TestAgents:
    def test_agents_list_local(self) -> None:
        """Local agents list returns empty (fresh registry)."""
        result = invoke_local("agents", "list")
        assert result.exit_code == 0

    def test_agents_register_local(self, tmp_path: Path) -> None:
        """Local register uses PersistentAgentRegistry."""
        r = CliRunner()
        with r.isolated_filesystem(temp_dir=tmp_path):
            result = r.invoke(main, ["--local", "agents", "register", "test-bot"])
            assert result.exit_code == 0, result.output
            assert "test-bot" in result.output

    def test_agents_info_local_not_found(self) -> None:
        """Local info for missing agent errors."""
        result = invoke_local("agents", "info", "ghost-agent")
        assert result.exit_code == 1
        assert "not found" in result.output


# ---------------------------------------------------------------------------
# blueprints (local — server-only guard)
# ---------------------------------------------------------------------------


class TestBlueprints:
    def test_blueprints_list_local(self) -> None:
        result = invoke_local("blueprints", "list")
        assert result.exit_code == 0
        assert "audit-chain" in result.output

    def test_blueprints_list_tag_filter(self) -> None:
        result = invoke_local("blueprints", "list", "--tag", "audit")
        assert result.exit_code == 0
        assert "audit-chain" in result.output

    def test_blueprints_info_local(self) -> None:
        result = invoke_local("blueprints", "info", "audit-chain")
        assert result.exit_code == 0
        assert "Audit Chain" in result.output

    def test_blueprints_info_not_found(self) -> None:
        result = invoke_local("blueprints", "info", "nonexistent-bp")
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_blueprints_info_json(self) -> None:
        result = invoke("--local", "--json", "blueprints", "info", "audit-chain")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "audit-chain"
        assert "steps" in data


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


class TestInit:
    def test_init_creates_files(self, tmp_path: Path) -> None:
        target = str(tmp_path / "project")
        result = invoke("init", target)
        assert result.exit_code == 0
        assert (Path(target) / ".env.example").exists()
        assert (Path(target) / "AGENTS.md").exists()
        assert (Path(target) / "settle_example.py").exists()

    def test_init_skips_existing(self, tmp_path: Path) -> None:
        target = str(tmp_path / "project")
        invoke("init", target)
        result = invoke("init", target)
        assert result.exit_code == 0
        assert "skip" in result.output

    def test_init_default_directory(self, tmp_path: Path) -> None:
        r = CliRunner()
        with r.isolated_filesystem(temp_dir=tmp_path):
            result = r.invoke(main, ["init"])
            assert result.exit_code == 0
            assert Path(".env.example").exists()


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------


class TestLogin:
    def test_login_saves_config(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        result = runner.invoke(
            main,
            ["login", "--api-url", "https://test.swarm.at", "--api-key", "sk-test"],
        )
        assert result.exit_code == 0
        assert config_file.exists()
        content = config_file.read_text()
        assert "https://test.swarm.at" in content
        assert "sk-test" in content
        assert config_file.stat().st_mode & 0o777 == 0o600


# ---------------------------------------------------------------------------
# whoami (remote only)
# ---------------------------------------------------------------------------


class TestWhoami:
    def test_whoami_requires_remote(self) -> None:
        result = invoke_local("whoami", "some-agent")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()


# ---------------------------------------------------------------------------
# serve / mcp (just test they exist and parse args)
# ---------------------------------------------------------------------------


class TestServeAndMcp:
    def test_serve_help(self) -> None:
        result = invoke("serve", "--help")
        assert result.exit_code == 0
        assert "--port" in result.output
        assert "--host" in result.output

    def test_mcp_help(self) -> None:
        result = invoke("mcp", "--help")
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------


class TestConfig:
    def test_load_empty_config(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", tmp_path / "nope.toml")
        assert _load_config() == {}

    def test_roundtrip_config(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        _save_config({"api_url": "https://api.swarm.at", "api_key": "sk-abc"})
        loaded = _load_config()
        assert loaded["api_url"] == "https://api.swarm.at"
        assert loaded["api_key"] == "sk-abc"


# ---------------------------------------------------------------------------
# CliContext
# ---------------------------------------------------------------------------


class TestCliContext:
    def test_default_local(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SWARM_API_URL", raising=False)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", Path("/nonexistent/config.toml"))
        ctx = CliContext()
        assert ctx.mode == "local"

    def test_api_url_forces_remote(self) -> None:
        ctx = CliContext(api_url="https://api.swarm.at")
        assert ctx.mode == "remote"

    def test_force_local_overrides_api_url(self) -> None:
        ctx = CliContext(api_url="https://api.swarm.at", force_local=True)
        assert ctx.mode == "local"

    def test_env_var_forces_remote(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_API_URL", "https://env.swarm.at")
        ctx = CliContext()
        assert ctx.mode == "remote"
        assert ctx.api_url == "https://env.swarm.at"

    def test_config_file_forces_remote(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("SWARM_API_URL", raising=False)
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)
        _save_config({"api_url": "https://cfg.swarm.at", "api_key": "sk-cfg"})

        ctx = CliContext()
        assert ctx.mode == "remote"
        assert ctx.api_url == "https://cfg.swarm.at"
        assert ctx.api_key == "sk-cfg"


# ---------------------------------------------------------------------------
# JSON output mode
# ---------------------------------------------------------------------------


class TestJsonOutput:
    def test_status_json(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke("--local", "--ledger-path", lp, "--json", "status")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, dict)
        assert "latest_hash" in data

    def test_ledger_list_json(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        settle_one(lp)
        result = invoke("--local", "--ledger-path", lp, "--json", "ledger", "list")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)

    def test_settle_json(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke("--local", "--ledger-path", lp, "--json", "settle", "test")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "SETTLED"


# ---------------------------------------------------------------------------
# Remote mode (mocked SwarmClient)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# blueprints publish / fork
# ---------------------------------------------------------------------------


class TestBlueprintsFork:
    def test_fork_local(self) -> None:
        """Fork a seeded blueprint locally."""
        result = invoke_local("blueprints", "fork", "audit-chain")
        assert result.exit_code == 0
        assert "molecule_id" in result.output

    def test_fork_local_not_found(self) -> None:
        result = invoke_local("blueprints", "fork", "nonexistent")
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_fork_json(self) -> None:
        result = invoke("--local", "--json", "blueprints", "fork", "audit-chain")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "molecule_id" in data
        assert data["bead_count"] > 0

    def test_fork_with_agent(self) -> None:
        result = invoke_local("blueprints", "fork", "audit-chain", "--agent", "bot-1")
        assert result.exit_code == 0
        assert "molecule_id" in result.output


class TestBlueprintsPublish:
    def test_publish_requires_remote(self) -> None:
        result = invoke_local("blueprints", "publish", "--name", "test", "--agent", "bot")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_publish_help(self) -> None:
        result = invoke("blueprints", "publish", "--help")
        assert result.exit_code == 0
        assert "--name" in result.output
        assert "--agent" in result.output

    def test_publish_bad_steps_json(self) -> None:
        result = invoke(
            "--api-url", "http://mock:8000",
            "blueprints", "publish",
            "--name", "test", "--agent", "bot", "--steps", "not-json",
        )
        assert result.exit_code == 1
        assert "Invalid JSON" in result.output


# ---------------------------------------------------------------------------
# agents verify-trust / trust-summary
# ---------------------------------------------------------------------------


class TestAgentsVerifyTrust:
    def test_verify_trust_not_found(self) -> None:
        result = invoke_local("agents", "verify-trust", "ghost-agent")
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_verify_trust_invalid_level(self) -> None:
        result = invoke_local("agents", "verify-trust", "any-agent", "--min-trust", "bogus")
        assert result.exit_code == 1
        assert "Invalid trust level" in result.output

    def test_verify_trust_registered_agent(self) -> None:
        """Verify trust for a known agent via mocked registry."""
        from swarm_at.agents import AgentIdentity, AgentRole, TrustLevel

        agent = AgentIdentity(agent_id="trust-bot", role=AgentRole.WORKER,
                              trust_level=TrustLevel.UNTRUSTED)
        with patch("swarm_at.agents.AgentRegistry.get", return_value=agent):
            result = invoke_local("agents", "verify-trust", "trust-bot",
                                  "--min-trust", "untrusted")
            assert result.exit_code == 0
            assert "meets_requirement: True" in result.output

    def test_verify_trust_help(self) -> None:
        result = invoke("agents", "verify-trust", "--help")
        assert result.exit_code == 0
        assert "--min-trust" in result.output


class TestAgentsTrustSummary:
    def test_trust_summary_local(self) -> None:
        result = invoke_local("agents", "trust-summary")
        assert result.exit_code == 0
        assert "total_agents" in result.output

    def test_trust_summary_json(self) -> None:
        result = invoke("--local", "--json", "agents", "trust-summary")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "total_agents" in data
        assert "by_trust_level" in data


# ---------------------------------------------------------------------------
# webhooks (remote only)
# ---------------------------------------------------------------------------


class TestWebhooks:
    def test_webhooks_help(self) -> None:
        result = invoke("webhooks", "--help")
        assert result.exit_code == 0
        assert "register" in result.output
        assert "unregister" in result.output

    def test_webhooks_register_requires_remote(self) -> None:
        result = invoke_local("webhooks", "register", "settlement.created", "https://example.com/hook")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_webhooks_list_requires_remote(self) -> None:
        result = invoke_local("webhooks", "list")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_webhooks_unregister_requires_remote(self) -> None:
        result = invoke_local("webhooks", "unregister", "settlement.created", "https://example.com/hook")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_webhooks_register_remote(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"event": "settlement.created", "url": "https://ex.com", "status": "registered"}
        mock_resp.raise_for_status = MagicMock()

        with patch("swarm_at.sdk.client.httpx.Client") as mock_http_cls:
            mock_http = MagicMock()
            mock_http.post.return_value = mock_resp
            mock_http_cls.return_value = mock_http

            result = invoke(
                "--api-url", "http://mock:8000",
                "webhooks", "register", "settlement.created", "https://ex.com",
            )
            assert result.exit_code == 0
            assert "registered" in result.output

    def test_webhooks_list_remote(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"webhooks": [], "total": 0}
        mock_resp.raise_for_status = MagicMock()

        with patch("swarm_at.sdk.client.httpx.Client") as mock_http_cls:
            mock_http = MagicMock()
            mock_http.get.return_value = mock_resp
            mock_http_cls.return_value = mock_http

            result = invoke("--api-url", "http://mock:8000", "webhooks", "list")
            assert result.exit_code == 0
            assert "total" in result.output


# ---------------------------------------------------------------------------
# credits group (remote only)
# ---------------------------------------------------------------------------


class TestCredits:
    def test_credits_help(self) -> None:
        result = invoke("credits", "--help")
        assert result.exit_code == 0
        assert "balance" in result.output
        assert "topup" in result.output

    def test_credits_balance_requires_remote(self) -> None:
        result = invoke_local("credits", "balance", "bot-1")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_credits_topup_requires_remote(self) -> None:
        result = invoke_local("credits", "topup", "bot-1", "50")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_credits_balance_remote(self) -> None:
        with patch("swarm_at.sdk.client.SwarmClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.get_credits.return_value = {
                "agent_id": "bot-1", "balance": 100.0,
            }
            mock_cls.return_value = mock_client

            result = invoke("--api-url", "http://mock:8000",
                            "credits", "balance", "bot-1")
            assert result.exit_code == 0
            assert "100" in result.output

    def test_credits_topup_remote(self) -> None:
        with patch("swarm_at.sdk.client.SwarmClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.topup_credits.return_value = {
                "agent_id": "bot-1", "balance": 150.0, "added": 50.0,
            }
            mock_cls.return_value = mock_client

            result = invoke("--api-url", "http://mock:8000",
                            "credits", "topup", "bot-1", "50")
            assert result.exit_code == 0
            assert "150" in result.output

    def test_credits_balance_json(self) -> None:
        with patch("swarm_at.sdk.client.SwarmClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.get_credits.return_value = {
                "agent_id": "bot-1", "balance": 100.0,
            }
            mock_cls.return_value = mock_client

            result = invoke("--api-url", "http://mock:8000", "--json",
                            "credits", "balance", "bot-1")
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["balance"] == 100.0


# ---------------------------------------------------------------------------
# auth token (remote only)
# ---------------------------------------------------------------------------


class TestAuthToken:
    def test_auth_token_requires_remote(self) -> None:
        result = invoke_local("auth", "token", "my-agent")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_auth_token_help(self) -> None:
        result = invoke("auth", "token", "--help")
        assert result.exit_code == 0
        assert "--role" in result.output

    def test_auth_token_remote(self) -> None:
        with patch("swarm_at.sdk.client.SwarmClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.create_token.return_value = {
                "token": "eyJhbGciOiJIUzI1NiJ9.test",
                "agent_id": "bot-1",
                "role": "worker",
            }
            mock_cls.return_value = mock_client

            result = invoke("--api-url", "http://mock:8000", "auth", "token", "bot-1")
            assert result.exit_code == 0
            assert "token" in result.output


# ---------------------------------------------------------------------------
# workflow execute (remote only)
# ---------------------------------------------------------------------------


class TestWorkflowExecute:
    def test_workflow_execute_requires_remote(self) -> None:
        result = invoke_local("workflow", "execute", "mol-1", "--step", "s1", "--agent", "bot")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_workflow_execute_help(self) -> None:
        result = invoke("workflow", "execute", "--help")
        assert result.exit_code == 0
        assert "--step" in result.output
        assert "--agent" in result.output

    def test_workflow_execute_bad_json(self) -> None:
        result = invoke(
            "--api-url", "http://mock:8000",
            "workflow", "execute", "mol-1",
            "--step", "s1", "--agent", "bot", "--data", "not-json",
        )
        assert result.exit_code == 1
        assert "Invalid JSON" in result.output

    def test_workflow_execute_remote(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "molecule_id": "mol-1", "step_id": "s1", "status": "SETTLED", "hash": "a" * 64,
        }
        mock_resp.raise_for_status = MagicMock()

        with patch("swarm_at.sdk.client.httpx.Client") as mock_http_cls:
            mock_http = MagicMock()
            mock_http.post.return_value = mock_resp
            mock_http_cls.return_value = mock_http

            result = invoke(
                "--api-url", "http://mock:8000",
                "workflow", "execute", "mol-1",
                "--step", "s1", "--agent", "bot",
            )
            assert result.exit_code == 0
            assert "SETTLED" in result.output


# ---------------------------------------------------------------------------
# authorship group
# ---------------------------------------------------------------------------


class TestAuthorship:
    def test_authorship_help(self) -> None:
        result = invoke("authorship", "--help")
        assert result.exit_code == 0
        assert "claim" in result.output
        assert "verify" in result.output
        assert "list" in result.output
        assert "sessions" in result.output
        assert "report" in result.output

    def test_authorship_claim_local(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("authorship", "claim", "hello world",
                              "--agent", "bot-1", ledger_path=lp)
        assert result.exit_code == 0, result.output
        assert "SETTLED" in result.output

    def test_authorship_claim_local_json(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke("--local", "--json", "--ledger-path", lp,
                        "authorship", "claim", "hello world", "--agent", "bot-1")
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["status"] == "SETTLED"
        assert len(data["content_hash"]) == 64
        assert data["agent_id"] == "bot-1"

    def test_authorship_verify_local(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        # Claim first
        claim = invoke("--local", "--json", "--ledger-path", lp,
                       "authorship", "claim", "some content", "--agent", "bot-1")
        assert claim.exit_code == 0, claim.output
        c_hash = json.loads(claim.output)["content_hash"]
        # Verify
        result = invoke_local("authorship", "verify", c_hash, ledger_path=lp)
        assert result.exit_code == 0, result.output
        assert "True" in result.output or "true" in result.output

    def test_authorship_verify_not_found(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke_local("authorship", "verify", "0" * 64, ledger_path=lp)
        assert result.exit_code == 0
        assert "False" in result.output or "false" in result.output

    def test_authorship_list_local(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        # Claim first
        invoke_local("authorship", "claim", "content-a", "--agent", "bot-1", ledger_path=lp)
        # List
        result = invoke("--local", "--json", "--ledger-path", lp,
                        "authorship", "list", "bot-1")
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["agent_id"] == "bot-1"
        assert data["total"] == 1
        assert len(data["claims"]) == 1

    def test_authorship_list_empty(self, tmp_path: Path) -> None:
        lp = str(tmp_path / "ledger.jsonl")
        result = invoke("--local", "--json", "--ledger-path", lp,
                        "authorship", "list", "nobody")
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["total"] == 0
        assert data["claims"] == []

    def test_authorship_sessions_requires_remote(self) -> None:
        result = invoke_local("authorship", "sessions")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_authorship_report_requires_remote(self) -> None:
        result = invoke_local("authorship", "report", "sess-1")
        assert result.exit_code == 1
        assert "remote" in result.output.lower()

    def test_authorship_claim_remote(self) -> None:
        with patch("swarm_at.sdk.client.SwarmClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.claim_authorship.return_value = {
                "status": "SETTLED",
                "hash": "a" * 64,
                "content_hash": "b" * 64,
                "agent_id": "bot-1",
            }
            mock_cls.return_value = mock_client

            result = invoke("--api-url", "http://mock:8000",
                            "authorship", "claim", "hello", "--agent", "bot-1")
            assert result.exit_code == 0
            assert "SETTLED" in result.output

    def test_authorship_verify_remote(self) -> None:
        with patch("swarm_at.sdk.client.SwarmClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.verify_authorship.return_value = {
                "verified": True,
                "agent_id": "bot-1",
                "content_hash": "b" * 64,
            }
            mock_cls.return_value = mock_client

            result = invoke("--api-url", "http://mock:8000",
                            "authorship", "verify", "b" * 64, "--agent", "bot-1")
            assert result.exit_code == 0
            assert "True" in result.output or "true" in result.output


# ---------------------------------------------------------------------------
# config group
# ---------------------------------------------------------------------------


class TestConfigCommand:
    def test_config_path(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        config_file = tmp_path / ".swarm" / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)
        result = invoke("config", "path")
        assert result.exit_code == 0
        assert str(config_file) in result.output

    def test_config_get_no_file(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """get with no config file produces empty output."""
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", tmp_path / "nope.toml")
        result = invoke("config", "get")
        assert result.exit_code == 0
        assert result.output.strip() == ""

    def test_config_set_creates_file(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        result = invoke("config", "set", "api_url", "https://api.swarm.at")
        assert result.exit_code == 0
        assert config_file.exists()
        assert config_file.stat().st_mode & 0o777 == 0o600

    def test_config_set_then_get_roundtrip(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        set_result = invoke("config", "set", "api_key", "sk-test123")
        assert set_result.exit_code == 0

        get_result = invoke("config", "get")
        assert get_result.exit_code == 0
        assert "sk-test123" in get_result.output

    def test_config_get_single_key(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        invoke("config", "set", "api_url", "https://api.swarm.at")
        invoke("config", "set", "api_key", "sk-secret")

        result = invoke("config", "get", "api_url")
        assert result.exit_code == 0
        assert result.output.strip() == "https://api.swarm.at"

    def test_config_get_nonexistent_key_errors(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        invoke("config", "set", "api_url", "https://api.swarm.at")

        result = invoke("config", "get", "nonexistent_key")
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_config_set_overwrites_existing_key(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        invoke("config", "set", "api_url", "https://old.swarm.at")
        invoke("config", "set", "api_url", "https://new.swarm.at")

        result = invoke("config", "get", "api_url")
        assert result.exit_code == 0
        assert result.output.strip() == "https://new.swarm.at"

    def test_config_set_preserves_other_keys(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        config_dir = tmp_path / ".swarm"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr("swarm_at.cli.CONFIG_DIR", config_dir)
        monkeypatch.setattr("swarm_at.cli.CONFIG_FILE", config_file)

        invoke("config", "set", "api_url", "https://api.swarm.at")
        invoke("config", "set", "api_key", "sk-abc")

        result = invoke("config", "get")
        assert result.exit_code == 0
        assert "api_url" in result.output
        assert "api_key" in result.output

    def test_config_help(self) -> None:
        result = invoke("config", "--help")
        assert result.exit_code == 0
        assert "get" in result.output
        assert "set" in result.output
        assert "path" in result.output


# ---------------------------------------------------------------------------
# Remote mode (mocked SwarmClient)
# ---------------------------------------------------------------------------


class TestRemoteMode:
    def test_settle_remote(self) -> None:
        """settle in remote mode calls SettlementContext with api_url."""
        mock_result = MagicMock()
        mock_result.status.value = "SETTLED"
        mock_result.hash = "a" * 64
        mock_result.reason = None

        with patch("swarm_at.settle.SettlementContext") as mock_sc_cls:
            mock_sc = MagicMock()
            mock_sc.settle.return_value = mock_result
            mock_sc_cls.return_value = mock_sc

            result = invoke("--api-url", "http://mock:8000",
                            "settle", "test-action")
            assert result.exit_code == 0
            assert "SETTLED" in result.output
            mock_sc_cls.assert_called_once()
            call_kwargs = mock_sc_cls.call_args
            assert call_kwargs.kwargs.get("api_url") == "http://mock:8000"

    def test_status_remote(self) -> None:
        with patch("swarm_at.sdk.client.SwarmClient") as mock_cls:
            mock_client = MagicMock()
            mock_client.verify_ledger.return_value = {"chain_intact": True, "entry_count": 42}
            mock_client.latest_hash.return_value = "b" * 64
            mock_cls.return_value = mock_client

            result = invoke("--api-url", "http://mock:8000", "status")
            assert result.exit_code == 0
            assert "remote" in result.output
