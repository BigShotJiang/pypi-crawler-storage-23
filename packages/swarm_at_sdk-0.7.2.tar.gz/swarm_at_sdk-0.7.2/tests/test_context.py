"""Tests for the Context Injector (swarm_at/context.py).

get_context_slice() prunes shared state to a task-specific subset via keyword
filtering plus an always_include pinned set.
"""

from __future__ import annotations

from typing import Any

import pytest

from swarm_at.context import get_context_slice


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_state(**kwargs: Any) -> dict[str, Any]:
    """Convenience factory for readable inline state dicts."""
    return dict(kwargs)


# ---------------------------------------------------------------------------
# Default always_include behaviour (core_logic)
# ---------------------------------------------------------------------------


class TestDefaultAlwaysInclude:
    def test_core_logic_present_always_returned(self) -> None:
        state = {"core_logic": "rules", "irrelevant": "noise"}
        result = get_context_slice(state, query_keywords=[])
        assert result == {"core_logic": "rules"}

    def test_core_logic_absent_returns_empty(self) -> None:
        state = {"topic_a": "data", "topic_b": "data"}
        result = get_context_slice(state, query_keywords=[])
        assert result == {}

    def test_core_logic_missing_with_matching_keyword(self) -> None:
        state = {"topic_a": "data", "other": "noise"}
        result = get_context_slice(state, query_keywords=["topic_a"])
        assert result == {"topic_a": "data"}

    def test_core_logic_plus_keyword_match(self) -> None:
        state = {"core_logic": "rules", "topic_a": "data_a", "topic_b": "data_b"}
        result = get_context_slice(state, query_keywords=["topic_a"])
        assert result == {"core_logic": "rules", "topic_a": "data_a"}

    def test_core_logic_not_duplicated_when_in_keywords(self) -> None:
        state = {"core_logic": "rules", "other": "noise"}
        result = get_context_slice(state, query_keywords=["core_logic"])
        # core_logic appears once — dict keys are unique
        assert result == {"core_logic": "rules"}
        assert len(result) == 1


# ---------------------------------------------------------------------------
# Custom always_include
# ---------------------------------------------------------------------------


class TestCustomAlwaysInclude:
    def test_custom_key_always_returned(self) -> None:
        state = {"config": "settings", "data": "values", "noise": "drop"}
        result = get_context_slice(state, query_keywords=[], always_include=["config"])
        assert result == {"config": "settings"}

    def test_custom_key_plus_keyword(self) -> None:
        state = {"config": "settings", "data": "values", "noise": "drop"}
        result = get_context_slice(state, query_keywords=["data"], always_include=["config"])
        assert result == {"config": "settings", "data": "values"}

    def test_multiple_always_include_keys(self) -> None:
        state = {"a": 1, "b": 2, "c": 3, "d": 4}
        result = get_context_slice(state, query_keywords=[], always_include=["a", "b"])
        assert result == {"a": 1, "b": 2}

    def test_always_include_missing_key_skipped(self) -> None:
        """Keys listed in always_include that aren't in state are silently omitted."""
        state = {"real_key": "value"}
        result = get_context_slice(state, query_keywords=[], always_include=["missing_key"])
        assert result == {}

    def test_empty_always_include_list_falls_back_to_default(self) -> None:
        """Passing [] as always_include is falsy, so it falls back to ["core_logic"].

        The implementation uses `always_include or ["core_logic"]`, meaning an empty
        list is treated as "not provided" and the default wins.
        """
        state = {"core_logic": "rules", "topic": "data"}
        result = get_context_slice(state, query_keywords=["topic"], always_include=[])
        # [] is falsy → fallback to ["core_logic"], so both keys appear
        assert result == {"core_logic": "rules", "topic": "data"}

    def test_always_include_none_uses_default(self) -> None:
        state = {"core_logic": "rules", "topic": "data"}
        result = get_context_slice(state, query_keywords=[], always_include=None)
        assert result == {"core_logic": "rules"}


# ---------------------------------------------------------------------------
# Keyword filtering
# ---------------------------------------------------------------------------


class TestKeywordFiltering:
    def test_single_keyword_match(self) -> None:
        state = {"auth": "token", "billing": "info", "noise": "drop"}
        result = get_context_slice(state, query_keywords=["auth"])
        assert "auth" in result
        assert "billing" not in result

    def test_multiple_keyword_matches(self) -> None:
        state = {"auth": "token", "billing": "info", "noise": "drop"}
        result = get_context_slice(state, query_keywords=["auth", "billing"])
        assert result == {"auth": "token", "billing": "info"}

    def test_keyword_not_in_state_ignored(self) -> None:
        state = {"a": 1, "b": 2}
        result = get_context_slice(state, query_keywords=["z"], always_include=[])
        assert result == {}

    def test_duplicate_keywords_produce_single_entry(self) -> None:
        state = {"topic": "data", "noise": "drop"}
        result = get_context_slice(state, query_keywords=["topic", "topic"], always_include=[])
        assert result == {"topic": "data"}

    def test_empty_keywords_list_with_none_always_include(self) -> None:
        """No keywords and always_include=None → only core_logic (if present)."""
        state = {"topic_a": "data", "core_logic": "rules"}
        result = get_context_slice(state, query_keywords=[], always_include=None)
        assert result == {"core_logic": "rules"}

    def test_empty_keywords_list_with_empty_always_include_falls_back(self) -> None:
        """always_include=[] is falsy → falls back to ["core_logic"] default."""
        state = {"topic_a": "data", "core_logic": "rules"}
        result = get_context_slice(state, query_keywords=[], always_include=[])
        assert result == {"core_logic": "rules"}

    @pytest.mark.parametrize(
        "keywords, expected_keys",
        [
            # core_logic is always included by default when always_include is not overridden
            (["agent_state"], {"agent_state", "core_logic"}),
            (["task_queue", "agent_state"], {"task_queue", "agent_state", "core_logic"}),
            (["nonexistent"], {"core_logic"}),
            ([], {"core_logic"}),
        ],
        ids=["one-match", "two-matches", "no-match", "no-keywords"],
    )
    def test_keyword_selection_matrix(
        self, keywords: list[str], expected_keys: set[str]
    ) -> None:
        state = make_state(
            agent_state="active",
            task_queue="pending",
            core_logic="rules",
            irrelevant="noise",
        )
        # No always_include override → core_logic is always pinned
        result = get_context_slice(state, query_keywords=keywords)
        assert set(result.keys()) == expected_keys

    @pytest.mark.parametrize(
        "keywords, expected_keys",
        [
            (["agent_state"], {"agent_state"}),
            (["task_queue", "agent_state"], {"task_queue", "agent_state"}),
            (["nonexistent"], set()),
            ([], set()),
        ],
        ids=["one-match-no-core", "two-matches-no-core", "no-match-no-core", "no-keywords-no-core"],
    )
    def test_keyword_selection_matrix_custom_always_include(
        self, keywords: list[str], expected_keys: set[str]
    ) -> None:
        """With a custom non-empty always_include that excludes core_logic."""
        state = make_state(
            agent_state="active",
            task_queue="pending",
            irrelevant="noise",
            # deliberately no core_logic key in state
        )
        result = get_context_slice(state, query_keywords=keywords, always_include=["pinned_key"])
        # pinned_key is not in state so it's omitted; only keywords that match appear
        assert set(result.keys()) == expected_keys


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_state_returns_empty(self) -> None:
        assert get_context_slice({}, query_keywords=["anything"]) == {}

    def test_empty_state_with_always_include_returns_empty(self) -> None:
        assert get_context_slice({}, query_keywords=[], always_include=["core_logic"]) == {}

    def test_returns_dict_not_view(self) -> None:
        state = {"core_logic": "rules"}
        result = get_context_slice(state, query_keywords=[])
        assert isinstance(result, dict)

    def test_mutation_of_result_does_not_affect_state(self) -> None:
        state = {"core_logic": "original"}
        result = get_context_slice(state, query_keywords=[])
        result["core_logic"] = "mutated"
        # Original state is unaffected (values are not deep-copied, but key reassignment is safe)
        assert state["core_logic"] == "original"

    def test_values_preserved_exact_types(self) -> None:
        state = {
            "core_logic": {"nested": "dict"},
            "count": 42,
            "flag": True,
            "items": [1, 2, 3],
        }
        result = get_context_slice(
            state, query_keywords=["count", "flag", "items"], always_include=["core_logic"]
        )
        assert result["core_logic"] == {"nested": "dict"}
        assert result["count"] == 42
        assert result["flag"] is True
        assert result["items"] == [1, 2, 3]

    def test_none_value_in_state_included(self) -> None:
        state = {"core_logic": None, "other": "data"}
        result = get_context_slice(state, query_keywords=[])
        assert "core_logic" in result
        assert result["core_logic"] is None

    def test_large_state_only_returns_matches(self) -> None:
        state = {f"key_{i}": f"val_{i}" for i in range(100)}
        state["core_logic"] = "pinned"
        state["target"] = "found"
        result = get_context_slice(state, query_keywords=["target"])
        assert len(result) == 2
        assert "core_logic" in result
        assert "target" in result

    @pytest.mark.parametrize(
        "state, keywords, always_include, expected",
        [
            (
                {"core_logic": "rules", "topic_a": "data_a", "topic_b": "data_b", "irrel": "x"},
                ["topic_a"],
                None,
                {"core_logic": "rules", "topic_a": "data_a"},
            ),
            (
                {"core_logic": "important", "other": "stuff"},
                [],
                None,
                {"core_logic": "important"},
            ),
            (
                {"core_logic": "rules", "config": "settings", "data": "values"},
                ["data"],
                ["config"],
                {"config": "settings", "data": "values"},
            ),
            ({}, ["anything"], None, {}),
            ({"a": 1, "b": 2}, ["x", "y"], None, {}),
            ({"a": 1, "b": 2}, ["a", "b"], [], {"a": 1, "b": 2}),
        ],
        ids=[
            "filter-by-keyword",
            "core-logic-always",
            "custom-always-include",
            "empty-state",
            "no-matches",
            "all-keywords-match-no-default",
        ],
    )
    def test_parametrized_slice(
        self,
        state: dict[str, Any],
        keywords: list[str],
        always_include: list[str] | None,
        expected: dict[str, Any],
    ) -> None:
        kwargs: dict[str, Any] = {}
        if always_include is not None:
            kwargs["always_include"] = always_include
        assert get_context_slice(state, keywords, **kwargs) == expected


# ---------------------------------------------------------------------------
# Return value independence
# ---------------------------------------------------------------------------


class TestReturnValueIndependence:
    def test_two_calls_with_same_state_produce_equal_results(self) -> None:
        state = {"core_logic": "rules", "topic": "data"}
        r1 = get_context_slice(state, query_keywords=["topic"])
        r2 = get_context_slice(state, query_keywords=["topic"])
        assert r1 == r2

    def test_different_keywords_produce_different_slices(self) -> None:
        # Use a custom always_include that points to a non-existent key so only
        # the keyword match appears (avoids core_logic being pinned by default).
        state = {"a": 1, "b": 2}
        r_a = get_context_slice(state, query_keywords=["a"], always_include=["pinned"])
        r_b = get_context_slice(state, query_keywords=["b"], always_include=["pinned"])
        assert r_a == {"a": 1}
        assert r_b == {"b": 2}

    def test_different_keywords_include_core_logic_by_default(self) -> None:
        state = {"core_logic": "rules", "a": 1, "b": 2}
        r_a = get_context_slice(state, query_keywords=["a"])
        r_b = get_context_slice(state, query_keywords=["b"])
        # core_logic is pinned in both slices
        assert r_a == {"core_logic": "rules", "a": 1}
        assert r_b == {"core_logic": "rules", "b": 2}
