"""Tests for blueprint execution via workflow engine."""

from __future__ import annotations

import pytest

from swarm_at.blueprints import Blueprint, BlueprintStep
from swarm_at.workflow import (
    BeadStatus,
    WorkflowError,
    execute_blueprint_step,
    fork_blueprint,
)


@pytest.fixture()
def test_blueprint() -> Blueprint:
    """Simple 2-step blueprint for testing."""
    return Blueprint(
        blueprint_id="test-bp",
        name="Test Blueprint",
        description="For testing",
        tags=["test"],
        steps=[
            BlueprintStep(
                step_id="step-1",
                name="First",
                description="Do first",
                depends_on=[],
                agent_role="worker",
                complexity=0.3,
            ),
            BlueprintStep(
                step_id="step-2",
                name="Second",
                description="Do second",
                depends_on=["step-1"],
                agent_role="worker",
                complexity=0.5,
            ),
        ],
        credit_cost=10,
    )


@pytest.fixture()
def complex_blueprint() -> Blueprint:
    """Multi-step blueprint with parallel dependencies."""
    return Blueprint(
        blueprint_id="complex-bp",
        name="Complex Blueprint",
        description="Multi-step workflow",
        tags=["test", "complex"],
        steps=[
            BlueprintStep(
                step_id="init",
                name="Initialize",
                description="Setup",
                depends_on=[],
                agent_role="worker",
                complexity=0.2,
            ),
            BlueprintStep(
                step_id="task-a",
                name="Task A",
                description="Parallel task A",
                depends_on=["init"],
                agent_role="worker",
                complexity=0.5,
            ),
            BlueprintStep(
                step_id="task-b",
                name="Task B",
                description="Parallel task B",
                depends_on=["init"],
                agent_role="worker",
                complexity=0.5,
            ),
            BlueprintStep(
                step_id="finalize",
                name="Finalize",
                description="Combine results",
                depends_on=["task-a", "task-b"],
                agent_role="specialist",
                complexity=0.7,
            ),
        ],
        credit_cost=20,
    )


class TestForkBlueprint:
    """Tests for fork_blueprint function."""

    def test_fork_creates_correct_number_of_beads(self, test_blueprint):
        """Fork creates a molecule with correct number of beads."""
        molecule = fork_blueprint(test_blueprint)

        assert len(molecule.beads) == 2
        assert molecule.name == "Test Blueprint"

    def test_fork_preserves_step_dependencies(self, test_blueprint):
        """Fork preserves step dependencies from blueprint."""
        molecule = fork_blueprint(test_blueprint)

        step1 = next(b for b in molecule.beads if b.bead_id == "step-1")
        step2 = next(b for b in molecule.beads if b.bead_id == "step-2")

        assert step1.depends_on == []
        assert step2.depends_on == ["step-1"]

    def test_fork_sets_metadata_with_source_blueprint(self, test_blueprint):
        """Fork sets metadata with source blueprint id."""
        molecule = fork_blueprint(test_blueprint)

        assert "source_blueprint" in molecule.metadata
        assert molecule.metadata["source_blueprint"] == "test-bp"

    def test_fork_uses_agent_id_in_metadata(self, test_blueprint):
        """Fork uses agent_id in metadata."""
        molecule = fork_blueprint(test_blueprint, agent_id="agent-123")

        assert molecule.metadata["agent_id"] == "agent-123"
        assert all(b.agent_id == "agent-123" for b in molecule.beads)

    def test_fork_uses_default_agent_id(self, test_blueprint):
        """Fork uses default 'anonymous' agent_id when not specified."""
        molecule = fork_blueprint(test_blueprint)

        assert molecule.metadata["agent_id"] == "anonymous"
        assert all(b.agent_id == "anonymous" for b in molecule.beads)

    def test_each_bead_maps_to_blueprint_step(self, test_blueprint):
        """Each bead maps correctly to a blueprint step."""
        molecule = fork_blueprint(test_blueprint)

        for step in test_blueprint.steps:
            bead = next(b for b in molecule.beads if b.bead_id == step.step_id)
            assert bead.name == step.name
            assert bead.depends_on == step.depends_on

    def test_molecule_id_includes_blueprint_id(self, test_blueprint):
        """Molecule ID includes the blueprint ID."""
        molecule = fork_blueprint(test_blueprint)

        assert molecule.molecule_id.startswith("bp-test-bp-")

    def test_fork_complex_blueprint_preserves_parallel_deps(self, complex_blueprint):
        """Fork preserves parallel dependencies in complex workflows."""
        molecule = fork_blueprint(complex_blueprint)

        assert len(molecule.beads) == 4

        init = next(b for b in molecule.beads if b.bead_id == "init")
        task_a = next(b for b in molecule.beads if b.bead_id == "task-a")
        task_b = next(b for b in molecule.beads if b.bead_id == "task-b")
        finalize = next(b for b in molecule.beads if b.bead_id == "finalize")

        assert init.depends_on == []
        assert task_a.depends_on == ["init"]
        assert task_b.depends_on == ["init"]
        assert set(finalize.depends_on) == {"task-a", "task-b"}


class TestExecuteBlueprintStep:
    """Tests for execute_blueprint_step function."""

    def test_executing_step_returns_hash(self, workflow_engine, test_blueprint):
        """Executing a step returns a settlement hash."""
        molecule = fork_blueprint(test_blueprint, agent_id="test-agent")
        workflow_engine.register_molecule(molecule)

        hash_result = execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "step-1",
            data={"result": "step 1 complete"},
        )

        assert isinstance(hash_result, str)
        assert len(hash_result) == 64

    def test_steps_execute_in_dependency_order(self, workflow_engine, test_blueprint):
        """Steps execute in dependency order."""
        molecule = fork_blueprint(test_blueprint, agent_id="test-agent")
        workflow_engine.register_molecule(molecule)

        # Execute step-1
        hash1 = execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "step-1",
            data={"result": "step 1 done"},
        )

        # Now step-2 can execute
        hash2 = execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "step-2",
            data={"result": "step 2 done"},
        )

        assert hash1 != hash2
        assert len(hash1) == 64
        assert len(hash2) == 64

        # Verify beads are settled
        mol = workflow_engine.get_molecule(molecule.molecule_id)
        assert mol is not None
        step1 = mol.get_bead("step-1")
        step2 = mol.get_bead("step-2")
        assert step1 is not None
        assert step2 is not None
        assert step1.status == BeadStatus.SETTLED
        assert step2.status == BeadStatus.SETTLED

    def test_executing_step_with_unmet_deps_raises(
        self, workflow_engine, test_blueprint
    ):
        """Executing a step with unmet dependencies raises WorkflowError."""
        molecule = fork_blueprint(test_blueprint, agent_id="test-agent")
        workflow_engine.register_molecule(molecule)

        # Try to execute step-2 before step-1
        with pytest.raises(WorkflowError, match="unmet dependencies"):
            execute_blueprint_step(
                workflow_engine,
                molecule.molecule_id,
                "step-2",
                data={"result": "should fail"},
            )

    def test_full_blueprint_walkthrough(self, workflow_engine, test_blueprint):
        """Full blueprint walkthrough: fork and execute all steps in order."""
        # Fork the blueprint
        molecule = fork_blueprint(test_blueprint, agent_id="test-agent")
        workflow_engine.register_molecule(molecule)

        # Execute all steps
        hashes = []
        hashes.append(
            execute_blueprint_step(
                workflow_engine,
                molecule.molecule_id,
                "step-1",
                data={"result": "step 1 complete"},
                confidence=0.98,
            )
        )
        hashes.append(
            execute_blueprint_step(
                workflow_engine,
                molecule.molecule_id,
                "step-2",
                data={"result": "step 2 complete"},
                confidence=0.97,
            )
        )

        # Verify all hashes are unique
        assert len(hashes) == 2
        assert len(set(hashes)) == 2

        # Verify molecule is complete
        mol = workflow_engine.get_molecule(molecule.molecule_id)
        assert mol is not None
        assert mol.is_complete
        assert mol.progress == 1.0

    def test_execute_complex_blueprint_with_parallel_steps(
        self, workflow_engine, complex_blueprint
    ):
        """Execute complex blueprint with parallel dependencies."""
        molecule = fork_blueprint(complex_blueprint, agent_id="test-agent")
        workflow_engine.register_molecule(molecule)

        # Execute init
        execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "init",
            data={"initialized": True},
        )

        # Execute parallel tasks (order doesn't matter)
        execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "task-a",
            data={"task_a_result": "done"},
        )
        execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "task-b",
            data={"task_b_result": "done"},
        )

        # Execute finalize
        execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "finalize",
            data={"combined": "all done"},
        )

        # Verify completion
        mol = workflow_engine.get_molecule(molecule.molecule_id)
        assert mol is not None
        assert mol.is_complete
        assert mol.progress == 1.0

    def test_execute_step_with_custom_confidence(
        self, workflow_engine, test_blueprint
    ):
        """Execute step with custom confidence score."""
        molecule = fork_blueprint(test_blueprint, agent_id="test-agent")
        workflow_engine.register_molecule(molecule)

        hash_result = execute_blueprint_step(
            workflow_engine,
            molecule.molecule_id,
            "step-1",
            data={"result": "with confidence"},
            confidence=0.85,
        )

        assert len(hash_result) == 64

    def test_execute_nonexistent_molecule_raises(self, workflow_engine, test_blueprint):
        """Executing step on nonexistent molecule raises WorkflowError."""
        with pytest.raises(WorkflowError, match="not found"):
            execute_blueprint_step(
                workflow_engine,
                "nonexistent-molecule",
                "step-1",
                data={"result": "should fail"},
            )

    def test_execute_nonexistent_step_raises(self, workflow_engine, test_blueprint):
        """Executing nonexistent step raises WorkflowError."""
        molecule = fork_blueprint(test_blueprint, agent_id="test-agent")
        workflow_engine.register_molecule(molecule)

        with pytest.raises(WorkflowError, match="not found"):
            execute_blueprint_step(
                workflow_engine,
                molecule.molecule_id,
                "nonexistent-step",
                data={"result": "should fail"},
            )
