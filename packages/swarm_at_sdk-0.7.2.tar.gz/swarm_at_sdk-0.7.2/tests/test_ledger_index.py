"""Tests for Ledger in-memory cache, indexes, and lookup methods.

Covers:
- find_by_task_id / find_by_agent_id lookups
- latest_hash and entry_count properties
- Cache stays consistent across append_entry calls
- read_all returns from cache on second call (no extra file I/O)
"""

from __future__ import annotations

from pathlib import Path

from swarm_at.models import LedgerEntry
from swarm_at.settler import GENESIS_HASH, Ledger, generate_hash


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_entry(
    task_id: str,
    parent_hash: str = GENESIS_HASH,
    agent_id: str = "",
) -> LedgerEntry:
    """Build a minimal LedgerEntry with a valid hash chain link."""
    payload: dict[str, object] = {"result": "ok"}
    if agent_id:
        payload["agent_id"] = agent_id
    draft = LedgerEntry(
        timestamp=1_700_000_000.0,
        task_id=task_id,
        parent_hash=parent_hash,
        payload=payload,
        current_hash="",
    )
    entry_dict = draft.model_dump()
    entry_dict["current_hash"] = ""
    entry_dict["current_hash"] = generate_hash(entry_dict)
    return LedgerEntry(**entry_dict)


# ---------------------------------------------------------------------------
# find_by_task_id
# ---------------------------------------------------------------------------


class TestFindByTaskId:
    def test_find_by_task_id(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        entry = _make_entry("task-abc")
        ledger.append_entry(entry)

        result = ledger.find_by_task_id("task-abc")
        assert result is not None
        assert result.task_id == "task-abc"

    def test_find_by_task_id_not_found(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        assert ledger.find_by_task_id("nonexistent") is None

    def test_find_by_task_id_returns_latest_write(self, tmp_path: Path) -> None:
        """When two entries share a task_id, the index keeps the last one."""
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e1 = _make_entry("dup-task")
        ledger.append_entry(e1)
        e2 = _make_entry("dup-task", parent_hash=e1.current_hash)
        ledger.append_entry(e2)

        result = ledger.find_by_task_id("dup-task")
        assert result is not None
        assert result.current_hash == e2.current_hash


# ---------------------------------------------------------------------------
# find_by_agent_id
# ---------------------------------------------------------------------------


class TestFindByAgentId:
    def test_find_by_agent_id(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e1 = _make_entry("t1", agent_id="agent-alpha")
        ledger.append_entry(e1)
        e2 = _make_entry("t2", parent_hash=e1.current_hash, agent_id="agent-alpha")
        ledger.append_entry(e2)
        e3 = _make_entry("t3", parent_hash=e2.current_hash, agent_id="agent-beta")
        ledger.append_entry(e3)

        results = ledger.find_by_agent_id("agent-alpha")
        assert len(results) == 2
        task_ids = {r.task_id for r in results}
        assert task_ids == {"t1", "t2"}

    def test_find_by_agent_id_not_found(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        assert ledger.find_by_agent_id("ghost-agent") == []

    def test_find_by_agent_id_returns_copy(self, tmp_path: Path) -> None:
        """Mutating the returned list must not corrupt the internal index."""
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e = _make_entry("t1", agent_id="ag-1")
        ledger.append_entry(e)

        result = ledger.find_by_agent_id("ag-1")
        result.clear()

        assert len(ledger.find_by_agent_id("ag-1")) == 1

    def test_no_agent_id_in_payload_not_indexed(self, tmp_path: Path) -> None:
        """Entries without agent_id in payload must not appear in agent index."""
        ledger = Ledger(path=tmp_path / "l.jsonl")
        entry = _make_entry("t-no-agent")  # agent_id=""
        ledger.append_entry(entry)

        assert ledger.find_by_agent_id("") == []


# ---------------------------------------------------------------------------
# latest_hash property
# ---------------------------------------------------------------------------


class TestLatestHash:
    def test_latest_hash_empty_ledger(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        assert ledger.latest_hash == GENESIS_HASH

    def test_latest_hash_matches_last_entry(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e1 = _make_entry("t1")
        ledger.append_entry(e1)
        e2 = _make_entry("t2", parent_hash=e1.current_hash)
        ledger.append_entry(e2)

        assert ledger.latest_hash == e2.current_hash

    def test_latest_hash_matches_get_latest_hash(self, tmp_path: Path) -> None:
        """latest_hash property and get_latest_hash() must agree."""
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e = _make_entry("t1")
        ledger.append_entry(e)

        assert ledger.latest_hash == ledger.get_latest_hash()


# ---------------------------------------------------------------------------
# entry_count property
# ---------------------------------------------------------------------------


class TestEntryCount:
    def test_entry_count_empty(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        assert ledger.entry_count == 0

    def test_entry_count_matches_read_all(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        prev_hash = GENESIS_HASH
        for i in range(5):
            e = _make_entry(f"t{i}", parent_hash=prev_hash)
            ledger.append_entry(e)
            prev_hash = e.current_hash

        assert ledger.entry_count == len(ledger.read_all())
        assert ledger.entry_count == 5


# ---------------------------------------------------------------------------
# Cache consistency on append
# ---------------------------------------------------------------------------


class TestCacheInvalidationOnAppend:
    def test_append_updates_cache(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        # Warm the cache
        _ = ledger.read_all()

        e = _make_entry("new-task")
        ledger.append_entry(e)

        # Cache must reflect the new entry without re-reading from disk
        assert ledger.entry_count == 1
        assert ledger.find_by_task_id("new-task") is not None

    def test_sequential_appends_all_cached(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        prev_hash = GENESIS_HASH
        hashes: list[str] = []
        for i in range(10):
            e = _make_entry(f"task-{i}", parent_hash=prev_hash, agent_id="agent-x")
            ledger.append_entry(e)
            prev_hash = e.current_hash
            hashes.append(e.current_hash)

        assert ledger.entry_count == 10
        assert ledger.latest_hash == hashes[-1]
        assert len(ledger.find_by_agent_id("agent-x")) == 10

    def test_append_updates_task_index(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        assert ledger.find_by_task_id("alpha") is None

        e = _make_entry("alpha")
        ledger.append_entry(e)
        assert ledger.find_by_task_id("alpha") is not None

    def test_append_updates_agent_index(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        assert ledger.find_by_agent_id("ag-z") == []

        e = _make_entry("t1", agent_id="ag-z")
        ledger.append_entry(e)
        assert len(ledger.find_by_agent_id("ag-z")) == 1


# ---------------------------------------------------------------------------
# read_all caching
# ---------------------------------------------------------------------------


class TestReadAllCached:
    def test_second_call_returns_same_data(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e = _make_entry("t1")
        ledger.append_entry(e)

        first = ledger.read_all()
        second = ledger.read_all()
        assert first == second

    def test_read_all_does_not_re_read_file_after_cache_warm(self, tmp_path: Path) -> None:
        """After the cache is warm, read_all must not trigger another _load_cache call."""
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e = _make_entry("t1")
        ledger.append_entry(e)

        # Warm the cache (append_entry already does this, but be explicit)
        ledger.read_all()
        load_count_after_warm = ledger._load_count

        # Additional read_all calls must not increment _load_count
        ledger.read_all()
        ledger.read_all()
        assert ledger._load_count == load_count_after_warm

    def test_read_all_returns_copy(self, tmp_path: Path) -> None:
        """Mutating the list from read_all must not corrupt the internal cache."""
        ledger = Ledger(path=tmp_path / "l.jsonl")
        e = _make_entry("t1")
        ledger.append_entry(e)

        result = ledger.read_all()
        result.clear()

        assert len(ledger.read_all()) == 1

    def test_cold_ledger_loads_from_disk(self, tmp_path: Path) -> None:
        """A freshly constructed Ledger pointing at an existing file loads correctly."""
        # Write two entries via a first Ledger instance
        path = tmp_path / "shared.jsonl"
        ledger_a = Ledger(path=path)
        e1 = _make_entry("disk-t1")
        ledger_a.append_entry(e1)
        e2 = _make_entry("disk-t2", parent_hash=e1.current_hash)
        ledger_a.append_entry(e2)

        # A new instance starts cold — must read from disk
        ledger_b = Ledger(path=path)
        assert ledger_b.entry_count == 2
        assert ledger_b.find_by_task_id("disk-t1") is not None
        assert ledger_b.find_by_task_id("disk-t2") is not None
        assert ledger_b.latest_hash == e2.current_hash
