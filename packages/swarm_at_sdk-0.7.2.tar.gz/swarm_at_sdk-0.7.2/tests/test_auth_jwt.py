"""Tests for JWT authentication."""

from __future__ import annotations

import time
from typing import Any

import pytest
from fastapi import FastAPI, Depends
from fastapi.testclient import TestClient

from swarm_at.auth import AuthError, JWTAuth, create_fastapi_dependency


class TestJWTAuth:
    def test_create_token_returns_string(self) -> None:
        auth = JWTAuth()
        token = auth.create_token("agent-123")
        assert isinstance(token, str)
        assert len(token) > 0

    def test_verify_token_roundtrips(self) -> None:
        auth = JWTAuth()
        token = auth.create_token("agent-123", role="coordinator")
        payload = auth.verify_token(token)
        assert payload["sub"] == "agent-123"
        assert payload["role"] == "coordinator"
        assert "iat" in payload
        assert "exp" in payload

    def test_verify_token_rejects_expired(self) -> None:
        auth = JWTAuth(expiry_seconds=0)
        token = auth.create_token("agent-123")
        time.sleep(0.1)  # Ensure expiration
        with pytest.raises(AuthError, match="expired"):
            auth.verify_token(token)

    def test_verify_token_rejects_invalid(self) -> None:
        auth = JWTAuth()
        with pytest.raises(AuthError, match="Invalid token"):
            auth.verify_token("not-a-valid-jwt")

    def test_verify_token_rejects_wrong_secret(self) -> None:
        auth1 = JWTAuth(secret="secret-one-padded-to-32-bytes!!")
        auth2 = JWTAuth(secret="secret-two-padded-to-32-bytes!!")
        token = auth1.create_token("agent-123")
        with pytest.raises(AuthError, match="Invalid token"):
            auth2.verify_token(token)

    def test_get_agent_id_extracts_correctly(self) -> None:
        auth = JWTAuth()
        token = auth.create_token("agent-456")
        agent_id = auth.get_agent_id(token)
        assert agent_id == "agent-456"

    def test_get_agent_id_raises_on_invalid_token(self) -> None:
        auth = JWTAuth()
        with pytest.raises(AuthError):
            auth.get_agent_id("bad-token")


class TestFastAPIDependency:
    def test_accepts_valid_jwt(self) -> None:
        auth = JWTAuth()
        token = auth.create_token("agent-789", role="coordinator")

        app = FastAPI()
        verify = create_fastapi_dependency(auth)

        @app.get("/protected")
        def protected(user: dict[str, Any] = Depends(verify)) -> dict[str, Any]:
            return user

        client = TestClient(app)
        resp = client.get("/protected", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "agent-789"
        assert data["role"] == "coordinator"

    def test_accepts_valid_api_key(self) -> None:
        auth = JWTAuth()
        api_keys = {"test-key-123"}

        app = FastAPI()
        verify = create_fastapi_dependency(auth, api_keys=api_keys)

        @app.get("/protected")
        def protected(user: dict[str, Any] = Depends(verify)) -> dict[str, Any]:
            return user

        client = TestClient(app)
        resp = client.get("/protected", headers={"Authorization": "Bearer test-key-123"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "api-key-user"
        assert data["role"] == "worker"

    def test_rejects_invalid_token(self) -> None:
        auth = JWTAuth()

        app = FastAPI()
        verify = create_fastapi_dependency(auth)

        @app.get("/protected")
        def protected(user: dict[str, Any] = Depends(verify)) -> dict[str, Any]:
            return user

        client = TestClient(app)
        resp = client.get("/protected", headers={"Authorization": "Bearer bad-token"})
        assert resp.status_code == 401

    def test_rejects_missing_header(self) -> None:
        auth = JWTAuth()

        app = FastAPI()
        verify = create_fastapi_dependency(auth)

        @app.get("/protected")
        def protected(user: dict[str, Any] = Depends(verify)) -> dict[str, Any]:
            return user

        client = TestClient(app)
        resp = client.get("/protected")
        assert resp.status_code in (401, 403)  # HTTPBearer behavior varies by version

    def test_jwt_takes_precedence_over_api_key(self) -> None:
        """If a valid JWT is provided, it should be used even if api_keys are configured."""
        auth = JWTAuth()
        token = auth.create_token("agent-jwt")
        api_keys = {"test-key-123"}

        app = FastAPI()
        verify = create_fastapi_dependency(auth, api_keys=api_keys)

        @app.get("/protected")
        def protected(user: dict[str, Any] = Depends(verify)) -> dict[str, Any]:
            return user

        client = TestClient(app)
        resp = client.get("/protected", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "agent-jwt"

    def test_falls_back_to_api_key_on_jwt_failure(self) -> None:
        """If JWT verification fails, should fall back to API key check."""
        auth = JWTAuth()
        api_keys = {"fallback-key"}

        app = FastAPI()
        verify = create_fastapi_dependency(auth, api_keys=api_keys)

        @app.get("/protected")
        def protected(user: dict[str, Any] = Depends(verify)) -> dict[str, Any]:
            return user

        client = TestClient(app)
        resp = client.get("/protected", headers={"Authorization": "Bearer fallback-key"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "api-key-user"
