"""Tests for Phase 3 API endpoints: credits, blueprint fork, JWT auth, ledger mode."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.api.main import app
from swarm_at.auth import JWTAuth


@pytest.fixture()
def api_client() -> TestClient:
    return TestClient(app)


@pytest.fixture()
def authed_client() -> TestClient:
    api_state.api_keys = {"sk-test-key"}
    client = TestClient(app)
    client.headers["Authorization"] = "Bearer sk-test-key"
    return client


# ---------------------------------------------------------------------------
# Credit endpoints
# ---------------------------------------------------------------------------


class TestGetCredits:
    def test_returns_balance_for_registered_agent(self, authed_client: TestClient) -> None:
        api_state.credit_ledger.register("agent-a", initial_balance=50.0)
        r = authed_client.get("/v1/credits/agent-a")
        assert r.status_code == 200
        assert r.json()["balance"] == 50.0

    def test_404_for_unknown_agent(self, authed_client: TestClient) -> None:
        r = authed_client.get("/v1/credits/nonexistent")
        assert r.status_code == 404

    def test_requires_auth(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        r = api_client.get("/v1/credits/agent-a")
        assert r.status_code == 401


class TestTopupCredits:
    def test_adds_credits(self, authed_client: TestClient) -> None:
        api_state.credit_ledger.register("agent-a", initial_balance=10.0)
        r = authed_client.post("/v1/credits/agent-a/topup", json={"amount": 25.0})
        assert r.status_code == 200
        assert r.json()["balance"] == 35.0

    def test_rejects_negative_amount(self, authed_client: TestClient) -> None:
        r = authed_client.post("/v1/credits/agent-a/topup", json={"amount": -5.0})
        assert r.status_code == 400

    def test_rejects_zero_amount(self, authed_client: TestClient) -> None:
        r = authed_client.post("/v1/credits/agent-a/topup", json={"amount": 0})
        assert r.status_code == 400

    def test_rejects_amount_over_cap(self, authed_client: TestClient) -> None:
        api_state.credit_ledger.register("agent-a", initial_balance=10.0)
        r = authed_client.post("/v1/credits/agent-a/topup", json={"amount": 1001.0})
        assert r.status_code == 400
        assert "maximum" in r.json()["detail"].lower()

    def test_allows_amount_at_cap(self, authed_client: TestClient) -> None:
        api_state.credit_ledger.register("agent-a", initial_balance=10.0)
        r = authed_client.post("/v1/credits/agent-a/topup", json={"amount": 1000.0})
        assert r.status_code == 200
        assert r.json()["balance"] == 1010.0


# ---------------------------------------------------------------------------
# Blueprint fork
# ---------------------------------------------------------------------------


class TestForkBlueprint:
    def _seed(self) -> None:
        from swarm_at.seed_blueprints import seed_blueprints
        seed_blueprints(api_state.blueprint_store)

    def test_forks_seeded_blueprint(self, authed_client: TestClient) -> None:
        self._seed()
        api_state.credit_ledger.register("test-agent", initial_balance=500.0)
        r = authed_client.post("/v1/blueprints/audit-chain/fork?agent_id=test-agent")
        assert r.status_code == 200
        body = r.json()
        assert "molecule_id" in body
        assert body["bead_count"] > 0
        assert body["metadata"]["source_blueprint"] == "audit-chain"

    def test_fork_debits_credits(self, authed_client: TestClient) -> None:
        self._seed()
        api_state.credit_ledger.register("agent-b", initial_balance=500.0)
        bp = api_state.blueprint_store.get_blueprint("audit-chain")
        before = api_state.credit_ledger.balance("agent-b")
        authed_client.post("/v1/blueprints/audit-chain/fork?agent_id=agent-b")
        after = api_state.credit_ledger.balance("agent-b")
        assert after == before - bp.credit_cost

    def test_fork_rejects_insufficient_credits(self, authed_client: TestClient) -> None:
        self._seed()
        api_state.credit_ledger.register("broke-agent", initial_balance=0.01)
        r = authed_client.post("/v1/blueprints/audit-chain/fork?agent_id=broke-agent")
        assert r.status_code == 402

    def test_404_for_unknown_blueprint(self, authed_client: TestClient) -> None:
        r = authed_client.post("/v1/blueprints/nonexistent/fork?agent_id=test-agent")
        assert r.status_code == 404

    def test_requires_auth(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        r = api_client.post("/v1/blueprints/audit-chain/fork?agent_id=test-agent")
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# JWT token endpoint
# ---------------------------------------------------------------------------


class TestAuthToken:
    def test_returns_token_when_jwt_configured(self, authed_client: TestClient) -> None:
        api_state.jwt_auth = JWTAuth(secret="test-secret-123-padded-to-32-b!")
        r = authed_client.post("/v1/auth/token", json={"agent_id": "agent-x", "role": "worker"})
        assert r.status_code == 200
        body = r.json()
        assert "token" in body
        assert body["agent_id"] == "agent-x"
        assert body["role"] == "worker"
        # Verify the token is valid
        claims = api_state.jwt_auth.verify_token(body["token"])
        assert claims["sub"] == "agent-x"

    def test_501_when_jwt_not_configured(self, api_client: TestClient) -> None:
        # Dev mode (no api_keys, no jwt_auth) — auth passes, but endpoint returns 501
        r = api_client.post("/v1/auth/token", json={"agent_id": "agent-x"})
        assert r.status_code == 501

    def test_requires_auth(self, api_client: TestClient) -> None:
        """Unauthenticated callers cannot mint tokens."""
        api_state.jwt_auth = JWTAuth(secret="test-secret-123-padded-to-32-b!")
        r = api_client.post("/v1/auth/token", json={"agent_id": "agent-x"})
        assert r.status_code == 401

    def test_jwt_token_works_as_bearer(self, authed_client: TestClient) -> None:
        """A JWT token issued by /v1/auth/token authenticates protected endpoints."""
        api_state.jwt_auth = JWTAuth(secret="test-secret-456-padded-to-32-b!")
        # Issue token (authed via API key)
        r = authed_client.post("/v1/auth/token", json={"agent_id": "agent-y"})
        token = r.json()["token"]
        # Use it on a protected endpoint — should pass verify_api_key via JWT path
        r2 = authed_client.get(
            "/v1/ledger/latest",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r2.status_code == 200
        assert "latest_hash" in r2.json()

    def test_jwt_only_mode_rejects_bad_token(self, api_client: TestClient) -> None:
        """When only JWT is configured (no API keys), invalid tokens are rejected."""
        api_state.jwt_auth = JWTAuth(secret="test-secret-789-padded-to-32-b!")
        r = api_client.get(
            "/v1/ledger/latest",
            headers={"Authorization": "Bearer not-a-valid-jwt"},
        )
        assert r.status_code == 403


# ---------------------------------------------------------------------------
# Ledger mode
# ---------------------------------------------------------------------------


class TestLedgerMode:
    def test_returns_file_mode_by_default(self, api_client: TestClient) -> None:
        r = api_client.get("/v1/ledger/mode")
        assert r.status_code == 200
        body = r.json()
        assert body["mode"] == "file"
        assert "latest_hash" in body
        assert "entry_count" in body
        assert body["chain_intact"] is True

    def test_entry_count_increases_after_settle(self, authed_client: TestClient) -> None:
        # Check initial
        r1 = authed_client.get("/v1/ledger/mode")
        initial_count = r1.json()["entry_count"]
        # Settle something
        from tests.conftest import make_settle_request

        req = make_settle_request()
        authed_client.post("/v1/settle", json=req)
        # Check again
        r2 = authed_client.get("/v1/ledger/mode")
        assert r2.json()["entry_count"] == initial_count + 1
