"""Tests for observability middleware and /metrics endpoint.

Covers:
- Correlation ID generation and pass-through
- Structured log output (JSON format gated on env var)
- /metrics Prometheus format
- Metric counter increments after requests
"""

from __future__ import annotations

import json
import logging
import os
from io import StringIO
from typing import Any
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from swarm_at.api.main import app
from swarm_at.api.middleware import _Metrics, metrics


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def client() -> TestClient:
    """TestClient that does not raise on 4xx/5xx."""
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture(autouse=True)
def _reset_metrics() -> Any:
    """Reset global metrics counters before each test to avoid leakage."""
    metrics.total_requests = 0
    metrics.total_settlements = 0
    metrics.error_count_by_status.clear()
    metrics._duration_buckets = {b: 0 for b in _Metrics.DURATION_BUCKETS}
    metrics._duration_inf = 0
    metrics._duration_sum = 0.0
    metrics._duration_count = 0
    yield


# ---------------------------------------------------------------------------
# Correlation ID tests
# ---------------------------------------------------------------------------


def test_correlation_id_generated_when_absent(client: TestClient) -> None:
    """A UUID correlation ID is created and returned when none is provided."""
    response = client.get("/public/ledger/latest")
    assert response.status_code == 200
    correlation_id = response.headers.get("X-Request-ID")
    assert correlation_id is not None
    assert len(correlation_id) == 36  # UUID4 canonical form
    # Confirm it looks like a UUID (has four hyphens)
    assert correlation_id.count("-") == 4


def test_correlation_id_passed_through_when_provided(client: TestClient) -> None:
    """When the client sends X-Request-ID, it echoes back unchanged."""
    custom_id = "my-custom-trace-abc123"
    response = client.get(
        "/public/ledger/latest",
        headers={"X-Request-ID": custom_id},
    )
    assert response.status_code == 200
    assert response.headers.get("X-Request-ID") == custom_id


def test_different_requests_get_different_correlation_ids(client: TestClient) -> None:
    """Each request without a client-supplied ID gets a unique correlation ID."""
    r1 = client.get("/public/ledger/latest")
    r2 = client.get("/public/ledger/latest")
    id1 = r1.headers.get("X-Request-ID")
    id2 = r2.headers.get("X-Request-ID")
    assert id1 is not None
    assert id2 is not None
    assert id1 != id2


def test_correlation_id_present_on_error_responses(client: TestClient) -> None:
    """Correlation ID header appears even on 404 responses."""
    response = client.get("/nonexistent-path")
    assert response.status_code == 404
    assert response.headers.get("X-Request-ID") is not None


# ---------------------------------------------------------------------------
# /metrics endpoint format tests
# ---------------------------------------------------------------------------


def test_metrics_endpoint_returns_200(client: TestClient) -> None:
    response = client.get("/metrics")
    assert response.status_code == 200


def test_metrics_content_type(client: TestClient) -> None:
    response = client.get("/metrics")
    assert "text/plain" in response.headers["content-type"]


def test_metrics_contains_required_metric_names(client: TestClient) -> None:
    """All four metric families must be present in the output."""
    response = client.get("/metrics")
    body = response.text
    assert "swarm_total_requests_total" in body
    assert "swarm_total_settlements_total" in body
    assert "swarm_errors_total" in body
    assert "swarm_request_duration_seconds" in body


def test_metrics_has_type_and_help_lines(client: TestClient) -> None:
    """Each metric must have # HELP and # TYPE metadata lines."""
    response = client.get("/metrics")
    body = response.text
    assert "# HELP swarm_total_requests" in body
    assert "# TYPE swarm_total_requests counter" in body
    assert "# HELP swarm_total_settlements" in body
    assert "# TYPE swarm_total_settlements counter" in body
    assert "# HELP swarm_errors_total" in body
    assert "# TYPE swarm_errors_total counter" in body
    assert "# HELP swarm_request_duration_seconds" in body
    assert "# TYPE swarm_request_duration_seconds histogram" in body


def test_metrics_histogram_has_buckets_and_inf(client: TestClient) -> None:
    """Duration histogram must include labelled buckets and +Inf."""
    response = client.get("/metrics")
    body = response.text
    # Spot-check a few bucket labels
    assert 'le="0.005"' in body
    assert 'le="0.1"' in body
    assert 'le="1.0"' in body
    assert 'le="+Inf"' in body
    # Summary lines
    assert "swarm_request_duration_seconds_sum" in body
    assert "swarm_request_duration_seconds_count" in body


# ---------------------------------------------------------------------------
# Metric counter increment tests
# ---------------------------------------------------------------------------


def test_total_requests_increments(client: TestClient) -> None:
    assert metrics.total_requests == 0
    client.get("/public/ledger/latest")
    assert metrics.total_requests == 1
    client.get("/public/ledger/latest")
    assert metrics.total_requests == 2


def test_error_count_increments_on_4xx(client: TestClient) -> None:
    assert not metrics.error_count_by_status
    client.get("/nonexistent-path")
    assert metrics.error_count_by_status.get(404, 0) == 1


def test_metrics_endpoint_does_not_count_itself(client: TestClient) -> None:
    """Scraping /metrics should not increment the request counter."""
    client.get("/metrics")
    assert metrics.total_requests == 0


def test_duration_histogram_populated_after_request(client: TestClient) -> None:
    assert metrics._duration_count == 0
    client.get("/public/ledger/latest")
    assert metrics._duration_count == 1
    assert metrics._duration_sum > 0.0
    assert metrics._duration_inf == 1


def test_error_count_appears_in_metrics_output(client: TestClient) -> None:
    """After a 404, the metrics output shows the labelled error counter."""
    client.get("/does-not-exist")
    response = client.get("/metrics")
    body = response.text
    assert 'swarm_errors_total{status="404"}' in body


# ---------------------------------------------------------------------------
# Request logging tests
# ---------------------------------------------------------------------------


def test_request_logging_human_format_no_crash(client: TestClient) -> None:
    """Default (non-JSON) logging emits something without crashing."""
    log_stream = StringIO()
    handler = logging.StreamHandler(log_stream)
    logger = logging.getLogger("swarm_at.api.requests")
    # Temporarily add a capture handler
    logger.addHandler(handler)
    try:
        client.get("/public/ledger/latest")
        output = log_stream.getvalue()
        # Should log the path at minimum
        assert "/public/ledger/latest" in output
    finally:
        logger.removeHandler(handler)


def test_request_logging_json_format(client: TestClient) -> None:
    """When SWARM_LOG_FORMAT=json, each log line is valid JSON with required fields."""
    log_stream = StringIO()

    with patch.dict(os.environ, {"SWARM_LOG_FORMAT": "json"}):
        # Re-create a JSON formatter on the logger for this test
        from swarm_at.api.middleware import _JsonFormatter

        handler = logging.StreamHandler(log_stream)
        handler.setFormatter(_JsonFormatter())
        logger = logging.getLogger("swarm_at.api.requests")
        logger.addHandler(handler)
        try:
            # Trigger a request; the existing middleware uses the module-level
            # _request_logger which already has its formatter set at import time,
            # so we capture what our new handler emits via the logger propagation.
            client.get(
                "/public/ledger/latest",
                headers={"X-Request-ID": "json-test-id"},
            )
            output = log_stream.getvalue().strip()
        finally:
            logger.removeHandler(handler)

    # There should be at least one line; take the last one emitted by our handler
    lines = [line for line in output.splitlines() if line.strip()]
    assert lines, "Expected at least one JSON log line"
    record = json.loads(lines[-1])
    # Standard fields always present
    assert "timestamp" in record
    assert "level" in record
    assert "message" in record


def test_log_record_contains_request_fields(client: TestClient) -> None:
    """Log records emitted by the middleware include method, path, status, duration_ms."""
    captured: list[logging.LogRecord] = []

    class _Capture(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            captured.append(record)

    handler = _Capture()
    logger = logging.getLogger("swarm_at.api.requests")
    logger.addHandler(handler)
    try:
        client.get("/public/ledger/latest")
    finally:
        logger.removeHandler(handler)

    assert captured, "Expected at least one log record"
    record = captured[-1]
    assert getattr(record, "method", None) == "GET"
    assert getattr(record, "path", None) == "/public/ledger/latest"
    assert getattr(record, "status", None) == 200
    duration = getattr(record, "duration_ms", None)
    assert duration is not None
    assert duration >= 0


# ---------------------------------------------------------------------------
# _Metrics unit tests
# ---------------------------------------------------------------------------


def test_metrics_prometheus_text_is_valid_format() -> None:
    """Validate the raw text output of _Metrics.prometheus_text()."""
    m = _Metrics()
    m.record_request(status_code=200, duration_seconds=0.042, path="/v1/settle")
    m.record_request(status_code=500, duration_seconds=0.1, path="/v1/settle")
    m.record_settlement()

    text = m.prometheus_text()
    lines = text.strip().splitlines()

    # Every non-comment, non-empty line must be either HELP/TYPE or a sample
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#"):
            assert stripped.startswith("# HELP") or stripped.startswith("# TYPE")
        else:
            # Sample lines: metric_name [labels] value
            parts = stripped.split()
            assert len(parts) >= 2, f"Bad sample line: {stripped!r}"
            # Value must be parseable as float
            float(parts[-1])


def test_metrics_counters_accumulate_correctly() -> None:
    m = _Metrics()
    m.record_request(200, 0.01, "/a")
    m.record_request(200, 0.02, "/b")
    m.record_request(404, 0.03, "/c")
    m.record_request(500, 0.04, "/d")

    assert m.total_requests == 4
    assert m.error_count_by_status[404] == 1
    assert m.error_count_by_status[500] == 1
    assert m._duration_count == 4
    assert abs(m._duration_sum - 0.10) < 1e-9


def test_metrics_histogram_bucket_counts() -> None:
    """Buckets accumulate correctly: a 0.03s request falls in all buckets >= 0.05."""
    m = _Metrics()
    m.record_request(200, 0.03, "/x")

    # 0.005 and 0.01 and 0.025 are < 0.03, so they should NOT be incremented
    assert m._duration_buckets[0.005] == 0
    assert m._duration_buckets[0.01] == 0
    assert m._duration_buckets[0.025] == 0
    # 0.05 >= 0.03, so it and all larger buckets should be incremented
    assert m._duration_buckets[0.05] == 1
    assert m._duration_buckets[0.1] == 1
    assert m._duration_buckets[1.0] == 1
    assert m._duration_inf == 1
