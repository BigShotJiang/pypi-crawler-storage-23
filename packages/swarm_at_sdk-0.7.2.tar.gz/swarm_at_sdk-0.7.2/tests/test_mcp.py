"""Tests for the MCP Settlement Server."""

from __future__ import annotations

import pytest

from swarm_at.mcp.server import SettlementMCPServer


class TestSettleAction:
    @pytest.mark.parametrize(
        "action, confidence, expect_proceed",
        [
            ("ls -la /tmp", 0.95, True),
            ("echo hello", 0.95, True),
            ("rm -rf /", 0.95, False),
            ("rm -rf ~", 0.95, False),
            ("echo hello", 0.5, False),
        ],
        ids=["safe", "safe-echo", "blocked-rm-root", "blocked-rm-home", "low-confidence"],
    )
    def test_settle_action_outcomes(
        self, mcp_server: SettlementMCPServer, action: str, confidence: float, expect_proceed: bool
    ) -> None:
        result = mcp_server.settle_action(action, confidence=confidence)
        assert result["proceed"] is expect_proceed

    def test_chained_settlements(self, mcp_server: SettlementMCPServer) -> None:
        r1 = mcp_server.settle_action("step 1", confidence=0.95)
        assert r1["proceed"] is True
        r2 = mcp_server.settle_action("step 2", confidence=0.95)
        assert r2["proceed"] is True
        assert mcp_server.ledger.verify_chain() is True


class TestCheckSettlement:
    def test_not_found(self, mcp_server: SettlementMCPServer) -> None:
        assert mcp_server.check_settlement(task_id="nonexistent")["found"] is False

    def test_found_by_hash(self, mcp_server: SettlementMCPServer) -> None:
        token = mcp_server.settle_action("test action", confidence=0.95)["settlement_token"]
        result = mcp_server.check_settlement(hash=token)
        assert result["found"] is True
        assert result["hash"] == token


class TestMCPToolGuarding:
    """Tests for agent-based tool permission enforcement in MCP server."""

    def test_no_registry_allows_all(self, mcp_server: SettlementMCPServer) -> None:
        """Without a registry, no permission enforcement."""
        result = mcp_server.settle_action("safe action", confidence=0.95, agent_id="any-agent")
        assert result["proceed"] is True

    def test_untrusted_agent_blocked_from_settle(self, tmp_path) -> None:
        """UNTRUSTED agent cannot use settle_action."""
        from swarm_at.agents import AgentRegistry
        from swarm_at.settler import Ledger

        registry = AgentRegistry()
        registry.register("new-agent")
        ledger = Ledger(path=tmp_path / "guarded.jsonl")
        server = SettlementMCPServer(ledger=ledger, agent_registry=registry)
        result = server.settle_action("action", confidence=0.95, agent_id="new-agent")
        assert result["proceed"] is False
        assert "lacks permission" in result["reason"]

    def test_provisional_agent_can_settle(self, tmp_path) -> None:
        """PROVISIONAL agent can use settle_action."""
        from swarm_at.agents import AgentRegistry
        from swarm_at.settler import Ledger

        registry = AgentRegistry()
        registry.register("trusted-agent")
        for _ in range(8):
            registry.record_settlement("trusted-agent", success=True)
        ledger = Ledger(path=tmp_path / "guarded.jsonl")
        server = SettlementMCPServer(ledger=ledger, agent_registry=registry)
        result = server.settle_action("safe action", confidence=0.95, agent_id="trusted-agent")
        assert result["proceed"] is True


class TestVerifyReceipt:
    """Tests for the verify_receipt MCP tool."""

    def test_finds_settled_entry(self, mcp_server: SettlementMCPServer) -> None:
        token = mcp_server.settle_action("test action", confidence=0.95)["settlement_token"]
        result = mcp_server.verify_receipt(token)
        assert result["found"] is True
        assert result["hash"] == token
        assert "task_id" in result
        assert "timestamp" in result

    def test_not_found_for_unknown_hash(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.verify_receipt("0" * 64)
        assert result["found"] is False
        assert "reason" in result


class TestCheckTrust:
    """Tests for the check_trust MCP tool."""

    def test_meets_requirement(self, tmp_path) -> None:
        from swarm_at.agents import AgentRegistry
        from swarm_at.settler import Ledger

        registry = AgentRegistry()
        registry.register("test-agent")
        # Build up to PROVISIONAL
        for _ in range(8):
            registry.record_settlement("test-agent", success=True)
        ledger = Ledger(path=tmp_path / "trust.jsonl")
        server = SettlementMCPServer(ledger=ledger, agent_registry=registry)
        result = server.check_trust("test-agent", min_trust="provisional")
        assert result["meets_requirement"] is True

    def test_does_not_meet_requirement(self, tmp_path) -> None:
        from swarm_at.agents import AgentRegistry
        from swarm_at.settler import Ledger

        registry = AgentRegistry()
        registry.register("new-agent")
        ledger = Ledger(path=tmp_path / "trust.jsonl")
        server = SettlementMCPServer(ledger=ledger, agent_registry=registry)
        result = server.check_trust("new-agent", min_trust="trusted")
        assert result["meets_requirement"] is False

    def test_missing_registry(self, mcp_server: SettlementMCPServer) -> None:
        # Default mcp_server fixture has no agent_registry
        result = mcp_server.check_trust("any-agent")
        assert "error" in result

    def test_unknown_agent(self, tmp_path) -> None:
        from swarm_at.agents import AgentRegistry
        from swarm_at.settler import Ledger

        registry = AgentRegistry()
        ledger = Ledger(path=tmp_path / "trust.jsonl")
        server = SettlementMCPServer(ledger=ledger, agent_registry=registry)
        result = server.check_trust("nonexistent")
        assert "error" in result


class TestStartWritingSession:
    def test_creates_session(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.start_writing_session("jane", "claude")
        assert "session_id" in result
        assert result["writer"] == "jane"
        assert result["tool"] == "claude"

    def test_session_stored(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.start_writing_session("jane", "claude")
        assert result["session_id"] in mcp_server._writing_sessions


class TestRecordWritingEvent:
    def _start(self, server: SettlementMCPServer) -> str:
        return server.start_writing_session("jane", "claude")["session_id"]

    def test_direction(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="direction",
            action="premise", chose="noir detective", phase="concept",
        )
        assert result["status"] == "SETTLED"
        assert len(result["hash"]) == 64

    def test_prompt(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="prompt", text="Write the opening scene",
        )
        assert result["status"] == "SETTLED"

    def test_generation(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="generation",
            output_hash="a" * 64, model="claude-sonnet-4-5",
        )
        assert result["status"] == "SETTLED"

    def test_revision(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="revision",
            description="Rewrote opening", kept_ratio=0.35,
        )
        assert result["status"] == "SETTLED"

    def test_rejection(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="rejection",
            output_hash="b" * 64, reason="Too generic",
        )
        assert result["status"] == "SETTLED"

    def test_invalid_event_type(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="invalid",
        )
        assert "error" in result

    def test_unknown_session(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.record_writing_event(
            session_id="nonexistent", event_type="direction",
            action="test", chose="test",
        )
        assert "error" in result

    def test_phase_parameter(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="direction",
            action="theme", chose="redemption", phase="concept",
        )
        assert result["status"] == "SETTLED"

    def test_invalid_phase(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.record_writing_event(
            session_id=sid, event_type="direction",
            action="test", chose="test", phase="invalid",
        )
        assert "error" in result


class TestApproveWriting:
    def _start(self, server: SettlementMCPServer) -> str:
        return server.start_writing_session("jane", "claude")["session_id"]

    def test_approve(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.approve_writing(sid, content_hash="c" * 64)
        assert result["status"] == "SETTLED"

    def test_approve_with_version(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.approve_writing(sid, content_hash="c" * 64, version="v1")
        assert result["status"] == "SETTLED"

    def test_unknown_session(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.approve_writing("nonexistent", content_hash="c" * 64)
        assert "error" in result


class TestGetProvenanceReport:
    def _start(self, server: SettlementMCPServer) -> str:
        return server.start_writing_session("jane", "claude")["session_id"]

    def test_empty_session_report(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        result = mcp_server.get_provenance_report(sid)
        assert result["session_id"] == sid
        assert result["writer"] == "jane"
        assert "work_agency" in result

    def test_report_after_events(self, mcp_server: SettlementMCPServer) -> None:
        sid = self._start(mcp_server)
        mcp_server.record_writing_event(
            session_id=sid, event_type="direction",
            action="premise", chose="noir", phase="concept",
        )
        mcp_server.record_writing_event(
            session_id=sid, event_type="generation",
            output_hash="a" * 64, phase="scene",
        )
        report = mcp_server.get_provenance_report(sid)
        assert report["total_events"] == 2
        assert report["work_agency"] > 0

    def test_unknown_session(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.get_provenance_report("nonexistent")
        assert "error" in result
