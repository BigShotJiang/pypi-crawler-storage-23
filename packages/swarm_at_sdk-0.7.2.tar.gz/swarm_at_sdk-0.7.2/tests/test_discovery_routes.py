"""Tests for discovery routes: llms.txt, robots.txt, agent-card, openapi."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.api.main import app


@pytest.fixture()
def api_client() -> TestClient:
    return TestClient(app)


# ---------------------------------------------------------------------------
# TestLlmsTxtRoute
# ---------------------------------------------------------------------------


class TestLlmsTxtRoute:
    """GET /llms.txt"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/llms.txt")
        assert resp.status_code == 200

    def test_content_type_is_text(self, api_client: TestClient) -> None:
        resp = api_client.get("/llms.txt")
        assert "text/plain" in resp.headers["content-type"]

    def test_contains_protocol_name(self, api_client: TestClient) -> None:
        resp = api_client.get("/llms.txt")
        assert "swarm.at" in resp.text

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/llms.txt")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestRobotsTxtRoute
# ---------------------------------------------------------------------------


class TestRobotsTxtRoute:
    """GET /robots.txt"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/robots.txt")
        assert resp.status_code == 200

    def test_contains_user_agent(self, api_client: TestClient) -> None:
        resp = api_client.get("/robots.txt")
        assert "User-agent" in resp.text

    def test_references_llms_txt(self, api_client: TestClient) -> None:
        resp = api_client.get("/robots.txt")
        assert "llms.txt" in resp.text


# ---------------------------------------------------------------------------
# TestAgentCardRoute
# ---------------------------------------------------------------------------


class TestAgentCardRoute:
    """GET /.well-known/agent-card.json"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        assert resp.status_code == 200

    def test_valid_json(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        data = resp.json()
        assert isinstance(data, dict)

    def test_a2a_fields(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        data = resp.json()
        for field in ["name", "description", "skills", "authentication", "serviceUrl"]:
            assert field in data, f"Missing A2A field: {field}"

    def test_well_known_path(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestWellKnownOpenApi
# ---------------------------------------------------------------------------


class TestWellKnownOpenApi:
    """GET /.well-known/openapi.json"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/openapi.json")
        assert resp.status_code == 200

    def test_has_paths(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/openapi.json").json()
        assert "paths" in data
        assert len(data["paths"]) > 0

    def test_has_servers(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/openapi.json").json()
        assert "servers" in data

    def test_enriched_tags(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/openapi.json").json()
        assert "tags" in data
        tag_names = {t["name"] for t in data["tags"]}
        assert "settlement" in tag_names
        assert "discovery" in tag_names


# ---------------------------------------------------------------------------
# TestSecurityTxtRoute
# ---------------------------------------------------------------------------


class TestSecurityTxtRoute:
    """GET /.well-known/security.txt"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/security.txt")
        assert resp.status_code == 200

    def test_content_type_is_text(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/security.txt")
        assert "text/plain" in resp.headers["content-type"]

    def test_contains_required_fields(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/security.txt")
        assert "Contact:" in resp.text
        assert "Expires:" in resp.text
        assert "Canonical:" in resp.text

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/.well-known/security.txt")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestAiPluginRoute
# ---------------------------------------------------------------------------


class TestAiPluginRoute:
    """GET /.well-known/ai-plugin.json"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/ai-plugin.json")
        assert resp.status_code == 200

    def test_content_type_is_json(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/ai-plugin.json")
        assert "application/json" in resp.headers["content-type"]

    def test_has_required_keys(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/ai-plugin.json").json()
        for key in ["schema_version", "name_for_human", "name_for_model", "description_for_model", "auth", "api"]:
            assert key in data, f"Missing key: {key}"

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/.well-known/ai-plugin.json")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestDiscoveryIndexRoute
# ---------------------------------------------------------------------------


class TestDiscoveryIndexRoute:
    """GET /discovery"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/discovery")
        assert resp.status_code == 200

    def test_content_type_is_json(self, api_client: TestClient) -> None:
        resp = api_client.get("/discovery")
        assert "application/json" in resp.headers["content-type"]

    def test_has_required_keys(self, api_client: TestClient) -> None:
        data = api_client.get("/discovery").json()
        for key in ["protocol", "version", "discovery", "public_endpoints"]:
            assert key in data, f"Missing key: {key}"

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/discovery")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestSitemapRoute
# ---------------------------------------------------------------------------


class TestSitemapRoute:
    """GET /sitemap.xml"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/sitemap.xml")
        assert resp.status_code == 200

    def test_content_type_is_text(self, api_client: TestClient) -> None:
        resp = api_client.get("/sitemap.xml")
        assert "text/plain" in resp.headers["content-type"]

    def test_contains_urlset(self, api_client: TestClient) -> None:
        resp = api_client.get("/sitemap.xml")
        assert "<urlset" in resp.text
        assert "<url><loc>" in resp.text

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/sitemap.xml")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestMcpJsonRoute
# ---------------------------------------------------------------------------


class TestMcpJsonRoute:
    """GET /.well-known/mcp.json"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/mcp.json")
        assert resp.status_code == 200

    def test_content_type_is_json(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/mcp.json")
        assert "application/json" in resp.headers["content-type"]

    def test_has_required_keys(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/mcp.json").json()
        for key in ["name", "version", "tool_count", "install", "registry"]:
            assert key in data, f"Missing key: {key}"

    def test_tool_count_is_18(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/mcp.json").json()
        assert data["tool_count"] == 18

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/.well-known/mcp.json")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestPublicJsonLdRoute
# ---------------------------------------------------------------------------


class TestPublicJsonLdRoute:
    """GET /public/jsonld"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/jsonld")
        assert resp.status_code == 200

    def test_content_type_is_json(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/jsonld")
        assert "application/json" in resp.headers["content-type"]

    def test_has_required_keys(self, api_client: TestClient) -> None:
        data = api_client.get("/public/jsonld").json()
        for key in ["@context", "@type", "url", "documentation"]:
            assert key in data, f"Missing key: {key}"

    def test_context_is_schema_org(self, api_client: TestClient) -> None:
        data = api_client.get("/public/jsonld").json()
        assert data["@context"] == "https://schema.org"

    def test_type_is_webapi(self, api_client: TestClient) -> None:
        data = api_client.get("/public/jsonld").json()
        assert data["@type"] == "WebAPI"

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/public/jsonld")
        assert resp.status_code == 200
