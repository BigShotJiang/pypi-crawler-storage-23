"""Tests for SDK authorship session lifecycle methods.

Covers: start_session, record_event, approve_writing, delete_session.
"""

from __future__ import annotations

import hashlib

import pytest

import swarm_at.api.state as api_state
from swarm_at.sdk.client import SwarmClient


def _fingerprint(content: str) -> str:
    return hashlib.sha256(content.encode()).hexdigest()


@pytest.fixture()
def sdk_client() -> SwarmClient:
    """SDK client backed by authed TestClient transport."""
    from fastapi.testclient import TestClient
    from swarm_at.api.main import app

    api_state.api_keys = {"sk-test-key"}
    test_client = TestClient(app)
    test_client.headers["Authorization"] = "Bearer sk-test-key"
    sdk = SwarmClient.__new__(SwarmClient)
    sdk.api_url = "http://testserver"
    sdk._http = test_client
    return sdk


# ---------------------------------------------------------------------------
# TestStartSession
# ---------------------------------------------------------------------------


class TestStartSession:
    def test_start_session(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.start_session(writer="alice", tool="claude")
        assert "session_id" in result
        assert result["writer"] == "alice"
        assert result["tool"] == "claude"

    def test_start_session_default_tool(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.start_session(writer="bob")
        assert result["tool"] == "unknown"
        assert result["writer"] == "bob"

    def test_start_session_requires_auth(self) -> None:
        from fastapi.testclient import TestClient
        from swarm_at.api.main import app
        from swarm_at.sdk.errors import AuthError

        # Enable auth by setting a key, then use a client that sends no token.
        api_state.api_keys = {"sk-real-key"}
        test_client = TestClient(app, raise_server_exceptions=False)
        sdk = SwarmClient.__new__(SwarmClient)
        sdk.api_url = "http://testserver"
        sdk._http = test_client  # no Authorization header
        with pytest.raises(AuthError) as exc_info:
            sdk.start_session(writer="unauthed")
        assert exc_info.value.status_code in {401, 403}


# ---------------------------------------------------------------------------
# TestRecordEvent
# ---------------------------------------------------------------------------


class TestRecordEvent:
    def test_record_event(self, sdk_client: SwarmClient) -> None:
        session = sdk_client.start_session(writer="alice", tool="claude")
        sid = session["session_id"]

        result = sdk_client.record_event(
            session_id=sid,
            event_type="prompt",
            phase="concept",
            text="Write a short story about a robot",
        )
        assert "status" in result
        assert "hash" in result
        assert len(result["hash"]) == 64

    def test_record_multiple_events(self, sdk_client: SwarmClient) -> None:
        session = sdk_client.start_session(writer="multi", tool="gpt-4")
        sid = session["session_id"]

        r1 = sdk_client.record_event(
            session_id=sid,
            event_type="direction",
            phase="concept",
            action="set_theme",
            chose="sci-fi",
        )
        r2 = sdk_client.record_event(
            session_id=sid,
            event_type="prompt",
            phase="structure",
            text="Outline three acts",
        )
        r3 = sdk_client.record_event(
            session_id=sid,
            event_type="generation",
            phase="scene",
            output_hash="a" * 64,
            model="gpt-4",
        )
        for r in (r1, r2, r3):
            assert r["status"] == "SETTLED"
            assert len(r["hash"]) == 64

    def test_record_unknown_session(self, sdk_client: SwarmClient) -> None:
        from swarm_at.sdk.errors import NotFoundError

        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.record_event(
                session_id="no-such-session",
                event_type="prompt",
                phase="revision",
                text="hi",
            )
        assert exc_info.value.status_code == 404

    def test_record_invalid_event_type(self, sdk_client: SwarmClient) -> None:
        from swarm_at.sdk.errors import SwarmError

        session = sdk_client.start_session(writer="err-writer", tool="test")
        sid = session["session_id"]
        with pytest.raises(SwarmError) as exc_info:
            sdk_client.record_event(
                session_id=sid,
                event_type="not_a_real_event",
                phase="revision",
            )
        assert exc_info.value.status_code == 400

    def test_record_invalid_phase(self, sdk_client: SwarmClient) -> None:
        from swarm_at.sdk.errors import SwarmError

        session = sdk_client.start_session(writer="phase-err", tool="test")
        sid = session["session_id"]
        with pytest.raises(SwarmError) as exc_info:
            sdk_client.record_event(
                session_id=sid,
                event_type="prompt",
                phase="not_a_phase",
                text="hi",
            )
        assert exc_info.value.status_code == 400


# ---------------------------------------------------------------------------
# TestApproveWriting
# ---------------------------------------------------------------------------


class TestApproveWriting:
    def test_approve_writing(self, sdk_client: SwarmClient) -> None:
        session = sdk_client.start_session(writer="approver", tool="test")
        sid = session["session_id"]
        sdk_client.record_event(
            session_id=sid,
            event_type="prompt",
            phase="concept",
            text="Write something",
        )

        content_hash = _fingerprint("final content")
        result = sdk_client.approve_writing(session_id=sid, content_hash=content_hash)
        assert result["status"] == "SETTLED"
        assert len(result["hash"]) == 64

    def test_approve_empty_session(self, sdk_client: SwarmClient) -> None:
        """Approving a session with no events should still succeed."""
        session = sdk_client.start_session(writer="empty-approver", tool="test")
        sid = session["session_id"]
        content_hash = _fingerprint("bare content")
        result = sdk_client.approve_writing(session_id=sid, content_hash=content_hash)
        assert result["status"] == "SETTLED"

    def test_approve_with_version(self, sdk_client: SwarmClient) -> None:
        session = sdk_client.start_session(writer="versioned", tool="test")
        sid = session["session_id"]
        content_hash = _fingerprint("versioned content")
        result = sdk_client.approve_writing(
            session_id=sid, content_hash=content_hash, version="v1.0"
        )
        assert result["status"] == "SETTLED"

    def test_approve_unknown_session(self, sdk_client: SwarmClient) -> None:
        from swarm_at.sdk.errors import NotFoundError

        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.approve_writing(
                session_id="ghost-session", content_hash=_fingerprint("x")
            )
        assert exc_info.value.status_code == 404


# ---------------------------------------------------------------------------
# TestDeleteSession
# ---------------------------------------------------------------------------


class TestDeleteSession:
    def test_delete_session(self, sdk_client: SwarmClient) -> None:
        session = sdk_client.start_session(writer="to-delete", tool="test")
        sid = session["session_id"]

        result = sdk_client.delete_session(sid)
        assert result["session_id"] == sid
        assert result["status"] == "deleted"

    def test_delete_session_removes_it(self, sdk_client: SwarmClient) -> None:
        """Session is gone from list after deletion."""
        from swarm_at.sdk.errors import NotFoundError

        session = sdk_client.start_session(writer="gone", tool="test")
        sid = session["session_id"]
        sdk_client.delete_session(sid)

        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.get_authorship_report(sid)
        assert exc_info.value.status_code == 404

    def test_delete_unknown_session(self, sdk_client: SwarmClient) -> None:
        from swarm_at.sdk.errors import NotFoundError

        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.delete_session("phantom")
        assert exc_info.value.status_code == 404


# ---------------------------------------------------------------------------
# TestFullLifecycle
# ---------------------------------------------------------------------------


class TestFullLifecycle:
    def test_full_lifecycle(self, sdk_client: SwarmClient) -> None:
        """start → record events → approve → get report."""
        session = sdk_client.start_session(writer="novelist", tool="claude")
        sid = session["session_id"]

        sdk_client.record_event(
            session_id=sid,
            event_type="direction",
            phase="concept",
            action="choose_genre",
            chose="thriller",
        )
        sdk_client.record_event(
            session_id=sid,
            event_type="prompt",
            phase="structure",
            text="Build a three-act structure",
        )
        sdk_client.record_event(
            session_id=sid,
            event_type="generation",
            phase="dialogue",
            output_hash="b" * 64,
            model="claude-sonnet-4-6",
        )
        sdk_client.record_event(
            session_id=sid,
            event_type="revision",
            phase="revision",
            description="Tightened pacing",
            kept_ratio=0.85,
        )

        content_hash = _fingerprint("final thriller manuscript")
        sdk_client.approve_writing(session_id=sid, content_hash=content_hash)

        report = sdk_client.get_authorship_report(sid)
        assert isinstance(report, dict)
        assert "work_agency" in report
        assert isinstance(report["work_agency"], float)

    def test_get_report_after_approve(self, sdk_client: SwarmClient) -> None:
        """Report is accessible after approve and contains provenance data."""
        session = sdk_client.start_session(writer="reporter", tool="test")
        sid = session["session_id"]

        sdk_client.record_event(
            session_id=sid,
            event_type="prompt",
            phase="concept",
            text="Start something",
        )
        content_hash = _fingerprint("report test content")
        sdk_client.approve_writing(session_id=sid, content_hash=content_hash)

        report = sdk_client.get_authorship_report(sid)
        assert "work_agency" in report
        assert "chain_verified" in report
        assert report["chain_verified"] is True

    def test_list_sessions_after_start(self, sdk_client: SwarmClient) -> None:
        sdk_client.start_session(writer="listed-writer", tool="test")
        sessions = sdk_client.list_authorship_sessions(writer="listed-writer")
        assert sessions["total"] >= 1
        writers = [s["writer"] for s in sessions["sessions"]]
        assert "listed-writer" in writers
