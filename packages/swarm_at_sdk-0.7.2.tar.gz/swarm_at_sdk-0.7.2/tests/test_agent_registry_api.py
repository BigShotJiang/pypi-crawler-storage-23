"""Tests for agent registry API endpoints (public + auth-required)."""

from __future__ import annotations

import time

from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.agents import AgentRole


def _register_with_settlements(
    agent_id: str,
    *,
    role: AgentRole = AgentRole.WORKER,
    successes: int = 0,
    failures: int = 0,
    complexity: float = 0.5,
) -> None:
    """Register an agent and record settlements."""
    api_state.agent_registry.register(agent_id, role=role)
    for _ in range(successes):
        api_state.agent_registry.record_settlement(agent_id, success=True, complexity=complexity)
    for _ in range(failures):
        api_state.agent_registry.record_settlement(agent_id, success=False, complexity=complexity)


class TestPublicAgents:
    """GET /public/agents — agent leaderboard."""

    def test_empty_registry(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents")
        assert resp.status_code == 200
        data = resp.json()
        assert data["agents"] == []
        assert data["total"] == 0

    def test_returns_registered_agents(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("agent-1", role=AgentRole.WORKER)
        resp = api_client.get("/public/agents")
        data = resp.json()
        assert data["total"] == 1
        assert data["agents"][0]["agent_id"] == "agent-1"

    def test_filter_by_trust_level(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("untrusted-1")
        api_state.agent_registry.register("trusted-1")
        for _ in range(23):
            api_state.agent_registry.record_settlement("trusted-1", success=True)
        resp = api_client.get("/public/agents", params={"min_trust": "trusted"})
        data = resp.json()
        assert data["total"] == 1
        assert data["agents"][0]["agent_id"] == "trusted-1"

    def test_invalid_trust_level_returns_400(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents", params={"min_trust": "invalid"})
        assert resp.status_code == 400

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-secret"}
        resp = api_client.get("/public/agents")
        assert resp.status_code == 200

    def test_agent_fields_present(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("agent-1")
        for _ in range(5):
            api_state.agent_registry.record_settlement("agent-1", success=True)
        resp = api_client.get("/public/agents")
        agent = resp.json()["agents"][0]
        assert "reputation_score" in agent
        assert "success_rate" in agent
        assert "trust_level" in agent
        assert "last_active" in agent


class TestLeaderboardSorting:
    """GET /public/agents — sort parameter."""

    def test_default_sort_is_reputation_desc(self, api_client: TestClient) -> None:
        _register_with_settlements("low-rep", successes=5, failures=5, complexity=0.2)
        _register_with_settlements("high-rep", successes=10, complexity=0.9)
        resp = api_client.get("/public/agents")
        agents = resp.json()["agents"]
        assert agents[0]["agent_id"] == "high-rep"
        assert agents[0]["reputation_score"] >= agents[1]["reputation_score"]

    def test_sort_by_volume(self, api_client: TestClient) -> None:
        _register_with_settlements("few", successes=3)
        _register_with_settlements("many", successes=25)
        resp = api_client.get("/public/agents", params={"sort": "volume"})
        agents = resp.json()["agents"]
        assert agents[0]["agent_id"] == "many"
        assert agents[0]["settlements_completed"] >= agents[1]["settlements_completed"]

    def test_sort_by_success_rate(self, api_client: TestClient) -> None:
        _register_with_settlements("messy", successes=7, failures=3)
        _register_with_settlements("clean", successes=5)
        resp = api_client.get("/public/agents", params={"sort": "success_rate"})
        agents = resp.json()["agents"]
        assert agents[0]["agent_id"] == "clean"
        assert agents[0]["success_rate"] >= agents[1]["success_rate"]

    def test_sort_by_active(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("old")
        api_state.agent_registry.get("old").last_active = time.time() - 3600
        api_state.agent_registry.register("recent")
        api_state.agent_registry.get("recent").last_active = time.time()
        resp = api_client.get("/public/agents", params={"sort": "active"})
        agents = resp.json()["agents"]
        assert agents[0]["agent_id"] == "recent"

    def test_sort_by_seniority(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("veteran")
        api_state.agent_registry.get("veteran").registered_at = 1000.0
        api_state.agent_registry.register("rookie")
        api_state.agent_registry.get("rookie").registered_at = 9000.0
        resp = api_client.get("/public/agents", params={"sort": "seniority"})
        agents = resp.json()["agents"]
        # desc = highest registered_at first (most recent registration)
        assert agents[0]["agent_id"] == "rookie"

    def test_sort_asc(self, api_client: TestClient) -> None:
        _register_with_settlements("low", successes=2)
        _register_with_settlements("high", successes=20)
        resp = api_client.get("/public/agents", params={"sort": "volume", "order": "asc"})
        agents = resp.json()["agents"]
        assert agents[0]["agent_id"] == "low"

    def test_invalid_sort_returns_400(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents", params={"sort": "bogus"})
        assert resp.status_code == 400
        assert "Invalid sort" in resp.json()["detail"]

    def test_invalid_order_returns_400(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents", params={"order": "sideways"})
        assert resp.status_code == 400


class TestLeaderboardRoleFilter:
    """GET /public/agents — role filter."""

    def test_filter_by_role(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("w-1", role=AgentRole.WORKER)
        api_state.agent_registry.register("o-1", role=AgentRole.ORCHESTRATOR)
        api_state.agent_registry.register("w-2", role=AgentRole.WORKER)
        resp = api_client.get("/public/agents", params={"role": "worker"})
        data = resp.json()
        assert data["total"] == 2
        ids = {a["agent_id"] for a in data["agents"]}
        assert ids == {"w-1", "w-2"}

    def test_invalid_role_returns_400(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents", params={"role": "wizard"})
        assert resp.status_code == 400

    def test_role_and_trust_combined(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("w-untrusted", role=AgentRole.WORKER)
        _register_with_settlements("w-trusted", role=AgentRole.WORKER, successes=23)
        _register_with_settlements("v-trusted", role=AgentRole.VALIDATOR, successes=23)
        resp = api_client.get("/public/agents", params={"role": "worker", "min_trust": "trusted"})
        data = resp.json()
        assert data["total"] == 1
        assert data["agents"][0]["agent_id"] == "w-trusted"


class TestLeaderboardPagination:
    """GET /public/agents — pagination."""

    def test_default_pagination(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("agent-1")
        resp = api_client.get("/public/agents")
        data = resp.json()
        assert data["page"] == 1
        assert data["page_size"] == 50
        assert data["has_more"] is False

    def test_page_size(self, api_client: TestClient) -> None:
        for i in range(5):
            api_state.agent_registry.register(f"agent-{i}")
        resp = api_client.get("/public/agents", params={"page_size": 2})
        data = resp.json()
        assert len(data["agents"]) == 2
        assert data["total"] == 5
        assert data["has_more"] is True

    def test_page_2(self, api_client: TestClient) -> None:
        for i in range(5):
            _register_with_settlements(f"agent-{i}", successes=i + 1)
        resp = api_client.get(
            "/public/agents",
            params={"page": 2, "page_size": 2, "sort": "volume"},
        )
        data = resp.json()
        assert len(data["agents"]) == 2
        assert data["page"] == 2
        assert data["has_more"] is True

    def test_last_page(self, api_client: TestClient) -> None:
        for i in range(5):
            api_state.agent_registry.register(f"agent-{i}")
        resp = api_client.get("/public/agents", params={"page": 3, "page_size": 2})
        data = resp.json()
        assert len(data["agents"]) == 1
        assert data["has_more"] is False

    def test_past_last_page_returns_empty(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("agent-1")
        resp = api_client.get("/public/agents", params={"page": 99})
        data = resp.json()
        assert data["agents"] == []
        assert data["total"] == 1
        assert data["has_more"] is False

    def test_page_size_validation(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents", params={"page_size": 0})
        assert resp.status_code == 422
        resp = api_client.get("/public/agents", params={"page_size": 201})
        assert resp.status_code == 422

    def test_no_duplicate_across_pages(self, api_client: TestClient) -> None:
        """Every agent appears exactly once across all pages."""
        for i in range(7):
            _register_with_settlements(f"agent-{i}", successes=i + 1)
        all_ids: list[str] = []
        for pg in range(1, 5):
            resp = api_client.get(
                "/public/agents",
                params={"page": pg, "page_size": 3, "sort": "volume"},
            )
            data = resp.json()
            all_ids.extend(a["agent_id"] for a in data["agents"])
        assert len(all_ids) == 7
        assert len(set(all_ids)) == 7


class TestRegisterAgent:
    """POST /v1/agents/register — agent self-registration."""

    def test_register_new_agent(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.post(
            "/v1/agents/register",
            json={"agent_id": "my-agent", "role": "worker", "capabilities": ["python"]},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "my-agent"
        assert data["role"] == "worker"
        assert data["trust_level"] == "untrusted"
        assert data["capabilities"] == ["python"]
        assert "registered_at" in data

    def test_register_defaults(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.post(
            "/v1/agents/register",
            json={"agent_id": "minimal-agent"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["role"] == "worker"
        assert data["capabilities"] == []

    def test_register_all_roles(self, authed_api_client: TestClient) -> None:
        for role in ["worker", "orchestrator", "validator", "auditor", "specialist"]:
            resp = authed_api_client.post(
                "/v1/agents/register",
                json={"agent_id": f"agent-{role}", "role": role},
            )
            assert resp.status_code == 200
            assert resp.json()["role"] == role

    def test_duplicate_returns_409(self, authed_api_client: TestClient) -> None:
        authed_api_client.post(
            "/v1/agents/register", json={"agent_id": "dup-agent"},
        )
        resp = authed_api_client.post(
            "/v1/agents/register", json={"agent_id": "dup-agent"},
        )
        assert resp.status_code == 409

    def test_invalid_role_returns_400(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.post(
            "/v1/agents/register",
            json={"agent_id": "bad-role", "role": "wizard"},
        )
        assert resp.status_code == 400

    def test_requires_auth(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-secret"}
        resp = api_client.post(
            "/v1/agents/register", json={"agent_id": "no-auth"},
        )
        assert resp.status_code == 401

    def test_registered_agent_shows_on_leaderboard(self, authed_api_client: TestClient) -> None:
        authed_api_client.post(
            "/v1/agents/register",
            json={"agent_id": "leaderboard-agent", "role": "validator"},
        )
        resp = authed_api_client.get("/public/agents")
        ids = [a["agent_id"] for a in resp.json()["agents"]]
        assert "leaderboard-agent" in ids


class TestGetAgent:
    """GET /v1/agents/{agent_id} — authenticated agent detail."""

    def test_get_agent(self, authed_api_client: TestClient) -> None:
        api_state.agent_registry.register("agent-1", capabilities=["search"])
        resp = authed_api_client.get("/v1/agents/agent-1")
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "agent-1"
        assert data["capabilities"] == ["search"]
        assert "divergence_penalty" in data
        assert "under_review" in data
        assert "last_active" in data

    def test_404_for_unknown(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.get("/v1/agents/ghost")
        assert resp.status_code == 404

    def test_requires_auth(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-secret"}
        api_state.agent_registry.register("agent-1")
        resp = api_client.get("/v1/agents/agent-1")
        assert resp.status_code == 401


class TestPublicAgentDetail:
    """GET /public/agents/{agent_id}"""

    def test_returns_agent_profile(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("agent-1", capabilities=["python"])
        resp = api_client.get("/public/agents/agent-1")
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "agent-1"
        assert data["capabilities"] == ["python"]

    def test_404_for_unknown_agent(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents/nonexistent")
        assert resp.status_code == 404

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-secret"}
        api_state.agent_registry.register("agent-1")
        resp = api_client.get("/public/agents/agent-1")
        assert resp.status_code == 200

    def test_shows_reputation_data(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("agent-1")
        for _ in range(23):
            api_state.agent_registry.record_settlement("agent-1", success=True)
        resp = api_client.get("/public/agents/agent-1")
        data = resp.json()
        assert data["trust_level"] == "trusted"
        assert data["reputation_score"] > 0
        assert data["settlements_completed"] == 23
