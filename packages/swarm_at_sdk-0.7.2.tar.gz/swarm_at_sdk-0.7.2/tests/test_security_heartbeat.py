"""Tests for Security Heartbeat: verification gate for local agent state."""

from __future__ import annotations

from pathlib import Path

import pytest

from swarm_at.agents import AgentRegistry, AgentRole, TrustLevel
from swarm_at.engine import SwarmAtEngine
from swarm_at.security_heartbeat import StateSnapshot, VerificationGate
from swarm_at.settler import Ledger


@pytest.fixture()
def security_env(tmp_path: Path):
    """Isolated security heartbeat environment."""
    ledger = Ledger(path=tmp_path / "security_ledger.jsonl")
    engine = SwarmAtEngine(ledger=ledger)
    registry = AgentRegistry()

    # Create monitored files
    memory = tmp_path / "memory.md"
    heartbeat = tmp_path / "HEARTBEAT.md"
    memory.write_text("# Agent Memory\nStatus: active\n")
    heartbeat.write_text("# Heartbeat\nLast: 2024-01-01\n")

    registry.register("agent-oclaw", role=AgentRole.WORKER)
    # Promote to PROVISIONAL (8 settlements with Bayesian trust)
    for _ in range(8):
        registry.record_settlement("agent-oclaw", success=True)

    gate = VerificationGate(
        engine=engine,
        registry=registry,
        monitored_files=[memory, heartbeat],
    )

    return {
        "gate": gate,
        "engine": engine,
        "registry": registry,
        "memory": memory,
        "heartbeat": heartbeat,
        "agent_id": "agent-oclaw",
    }


class TestStateSnapshot:
    def test_from_paths_reads_files(self, tmp_path: Path) -> None:
        f = tmp_path / "test.md"
        f.write_text("hello")
        snap = StateSnapshot.from_paths([f], agent_id="test")
        assert snap.files["test.md"] == "hello"
        assert len(snap.file_hashes["test.md"]) == 64

    def test_missing_file_gives_empty_content(self, tmp_path: Path) -> None:
        snap = StateSnapshot.from_paths([tmp_path / "missing.md"], agent_id="test")
        assert snap.files["missing.md"] == ""

    def test_combined_hash_is_deterministic(self, tmp_path: Path) -> None:
        f = tmp_path / "a.md"
        f.write_text("content")
        s1 = StateSnapshot.from_paths([f], agent_id="test")
        s2 = StateSnapshot.from_paths([f], agent_id="test")
        assert s1.combined_hash == s2.combined_hash

    def test_combined_hash_changes_on_content_change(self, tmp_path: Path) -> None:
        f = tmp_path / "a.md"
        f.write_text("version1")
        s1 = StateSnapshot.from_paths([f], agent_id="test")
        f.write_text("version2")
        s2 = StateSnapshot.from_paths([f], agent_id="test")
        assert s1.combined_hash != s2.combined_hash


class TestVerificationGate:
    def test_first_wake_passes_and_settles(self, security_env: dict) -> None:
        result = security_env["gate"].stake_on_wake(security_env["agent_id"])
        assert result.passed is True
        assert result.settlement_hash is not None
        assert len(result.settlement_hash) == 64

    def test_second_wake_same_state_passes(self, security_env: dict) -> None:
        gate = security_env["gate"]
        agent_id = security_env["agent_id"]
        gate.stake_on_wake(agent_id)
        result = gate.stake_on_wake(agent_id)
        assert result.passed is True

    def test_state_deviation_fails_verification(self, security_env: dict) -> None:
        gate = security_env["gate"]
        agent_id = security_env["agent_id"]
        # First wake — settles state
        gate.stake_on_wake(agent_id)
        # Modify monitored file
        security_env["memory"].write_text("# MODIFIED by rogue process")
        # Second wake — detects deviation
        result = gate.stake_on_wake(agent_id)
        assert result.passed is False
        assert "deviates" in result.reason

    def test_deviation_records_divergence_penalty(self, security_env: dict) -> None:
        gate = security_env["gate"]
        agent_id = security_env["agent_id"]
        gate.stake_on_wake(agent_id)
        security_env["heartbeat"].write_text("TAMPERED")
        gate.stake_on_wake(agent_id)
        agent = security_env["registry"].get(agent_id)
        assert agent.divergence_penalty > 0

    def test_freeze_agent_triggers_critical_review(self, security_env: dict) -> None:
        gate = security_env["gate"]
        agent_id = security_env["agent_id"]
        gate.freeze_agent(agent_id, "unauthorized system command")
        agent = security_env["registry"].get(agent_id)
        assert agent.under_review is True
        assert agent.trust_level == TrustLevel.UNTRUSTED
        assert agent_id in security_env["registry"].review_queue


class TestContinuousVerification:
    def test_no_change_passes(self, security_env: dict) -> None:
        gate = security_env["gate"]
        agent_id = security_env["agent_id"]
        gate.stake_on_wake(agent_id)
        result = gate.verify_continuous(agent_id)
        assert result.passed is True

    def test_file_change_fails_continuous_check(self, security_env: dict) -> None:
        gate = security_env["gate"]
        agent_id = security_env["agent_id"]
        gate.stake_on_wake(agent_id)
        security_env["memory"].write_text("CHANGED")
        result = gate.verify_continuous(agent_id)
        assert result.passed is False
        assert "changed since" in result.reason
