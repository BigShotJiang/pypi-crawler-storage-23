"""Tests for the public dashboard aggregate endpoint."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.seed_blueprints import seed_blueprints


@pytest.fixture()
def seeded_store() -> None:
    """Seed the API state blueprint store with canonical blueprints."""
    seed_blueprints(api_state.blueprint_store)


class TestDashboardEndpoint:
    """GET /public/dashboard aggregate stats."""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/dashboard")
        assert resp.status_code == 200

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/public/dashboard")
        assert resp.status_code == 200

    def test_contains_all_sections(self, api_client: TestClient) -> None:
        data = api_client.get("/public/dashboard").json()
        assert "ledger" in data
        assert "agents" in data
        assert "blueprints" in data
        assert "publisher_leaderboard" in data
        assert "recent_activity" in data

    def test_ledger_section_shape(self, api_client: TestClient) -> None:
        data = api_client.get("/public/dashboard").json()
        ledger = data["ledger"]
        assert "entry_count" in ledger
        assert "intact" in ledger
        assert "latest_hash" in ledger

    def test_agents_section_shape(self, api_client: TestClient) -> None:
        data = api_client.get("/public/dashboard").json()
        agents = data["agents"]
        assert "total" in agents
        assert "by_trust_level" in agents

    def test_blueprints_has_top_forked(self, api_client: TestClient, seeded_store: None) -> None:
        data = api_client.get("/public/dashboard").json()
        assert "top_forked" in data["blueprints"]
        assert isinstance(data["blueprints"]["top_forked"], list)

    def test_top_forked_limited_to_5(self, api_client: TestClient, seeded_store: None) -> None:
        data = api_client.get("/public/dashboard").json()
        assert len(data["blueprints"]["top_forked"]) <= 5

    def test_leaderboard_limited_to_10(self, api_client: TestClient) -> None:
        data = api_client.get("/public/dashboard").json()
        assert len(data["publisher_leaderboard"]) <= 10

    def test_leaderboard_excludes_swarm_at(self, api_client: TestClient, seeded_store: None) -> None:
        data = api_client.get("/public/dashboard").json()
        for entry in data["publisher_leaderboard"]:
            assert entry["agent_id"] != "swarm.at"

    def test_leaderboard_includes_community_authors(self, api_client: TestClient, seeded_store: None) -> None:
        """Community-authored blueprints appear on leaderboard (with 0 earnings initially)."""
        data = api_client.get("/public/dashboard").json()
        authors = [e["agent_id"] for e in data["publisher_leaderboard"]]
        # At least one community author should be present
        assert len(authors) > 0
        assert all(a != "swarm.at" for a in authors)

    def test_recent_activity_shape(self, api_client: TestClient) -> None:
        data = api_client.get("/public/dashboard").json()
        activity = data["recent_activity"]
        assert "settlements_24h" in activity
        assert "latest_types" in activity
        assert isinstance(activity["latest_types"], list)
