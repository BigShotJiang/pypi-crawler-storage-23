"""Live API test suite against https://api.swarm.at.

Run with: pytest tests/test_live_api.py -v --tb=short
Requires network access. Skipped if API unreachable.
"""

from __future__ import annotations

import os

import httpx
import pytest

BASE = os.environ.get("SWARM_LIVE_API", "https://api.swarm.at")
API_KEY = os.environ.get("SWARM_API_KEY", "")

_client = httpx.Client(base_url=BASE, timeout=15)


def _api_reachable() -> bool:
    try:
        r = _client.get("/health", timeout=5)
        return r.status_code == 200
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _api_reachable(), reason="Live API unreachable")


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class TestHealth:
    def test_health_returns_ok(self):
        r = _client.get("/health")
        assert r.status_code == 200
        assert r.json() == {"status": "ok"}

    def test_health_is_fast(self):
        r = _client.get("/health")
        assert r.elapsed.total_seconds() < 2.0


# ---------------------------------------------------------------------------
# Public Ledger
# ---------------------------------------------------------------------------


class TestPublicLedger:
    def test_ledger_returns_paginated(self):
        r = _client.get("/public/ledger")
        assert r.status_code == 200
        data = r.json()
        assert "entries" in data
        assert "total" in data
        assert "offset" in data
        assert "limit" in data
        assert isinstance(data["entries"], list)

    def test_ledger_pagination_params(self):
        r = _client.get("/public/ledger", params={"offset": 0, "limit": 2})
        assert r.status_code == 200
        data = r.json()
        assert len(data["entries"]) <= 2

    def test_ledger_latest(self):
        r = _client.get("/public/ledger/latest")
        assert r.status_code == 200
        data = r.json()
        assert "latest_hash" in data
        assert isinstance(data["latest_hash"], str)

    def test_ledger_verify(self):
        r = _client.get("/public/ledger/verify")
        assert r.status_code == 200
        data = r.json()
        assert "intact" in data
        assert "entry_count" in data
        assert isinstance(data["intact"], bool)

    def test_ledger_entry_not_found(self):
        r = _client.get("/public/ledger/entry/nonexistent-task-12345")
        assert r.status_code == 404

    def test_ledger_invalid_offset(self):
        r = _client.get("/public/ledger", params={"offset": -1})
        assert r.status_code == 422

    def test_ledger_invalid_limit(self):
        r = _client.get("/public/ledger", params={"limit": 0})
        assert r.status_code == 422

    def test_ledger_limit_capped(self):
        r = _client.get("/public/ledger", params={"limit": 501})
        assert r.status_code == 422


# ---------------------------------------------------------------------------
# Public Agents
# ---------------------------------------------------------------------------


class TestPublicAgents:
    def test_agents_returns_list(self):
        r = _client.get("/public/agents")
        assert r.status_code == 200
        data = r.json()
        assert "agents" in data
        assert "total" in data
        assert "page" in data
        assert "page_size" in data
        assert "has_more" in data
        assert isinstance(data["agents"], list)

    def test_agents_have_expected_fields(self):
        r = _client.get("/public/agents")
        data = r.json()
        if data["agents"]:
            agent = data["agents"][0]
            for field in ("agent_id", "role", "trust_level", "settlements_completed",
                          "success_rate", "reputation_score", "last_active"):
                assert field in agent, f"Missing field: {field}"

    def test_seeded_agents_present(self):
        r = _client.get("/public/agents")
        data = r.json()
        ids = {a["agent_id"] for a in data["agents"]}
        assert "orchestrator-prime" in ids
        assert "validator-alpha" in ids

    def test_filter_by_role(self):
        r = _client.get("/public/agents", params={"role": "orchestrator"})
        assert r.status_code == 200
        data = r.json()
        for agent in data["agents"]:
            assert agent["role"] == "orchestrator"

    def test_filter_invalid_role(self):
        r = _client.get("/public/agents", params={"role": "nonexistent"})
        assert r.status_code == 400

    def test_sort_by_volume(self):
        r = _client.get("/public/agents", params={"sort": "volume", "order": "desc"})
        assert r.status_code == 200
        data = r.json()
        volumes = [a["settlements_completed"] for a in data["agents"]]
        assert volumes == sorted(volumes, reverse=True)

    def test_sort_by_reputation_asc(self):
        r = _client.get("/public/agents", params={"sort": "reputation", "order": "asc"})
        assert r.status_code == 200
        data = r.json()
        reps = [a["reputation_score"] for a in data["agents"]]
        assert reps == sorted(reps)

    def test_invalid_sort_key(self):
        r = _client.get("/public/agents", params={"sort": "bogus"})
        assert r.status_code == 400

    def test_invalid_order(self):
        r = _client.get("/public/agents", params={"order": "sideways"})
        assert r.status_code == 400

    def test_invalid_trust_level(self):
        r = _client.get("/public/agents", params={"min_trust": "mega"})
        assert r.status_code == 400

    def test_pagination(self):
        r = _client.get("/public/agents", params={"page": 1, "page_size": 2})
        assert r.status_code == 200
        data = r.json()
        assert len(data["agents"]) <= 2
        assert data["page"] == 1
        assert data["page_size"] == 2

    def test_page_size_too_large(self):
        r = _client.get("/public/agents", params={"page_size": 201})
        assert r.status_code == 422


class TestPublicAgentDetail:
    def test_known_agent(self):
        r = _client.get("/public/agents/orchestrator-prime")
        assert r.status_code == 200
        data = r.json()
        assert data["agent_id"] == "orchestrator-prime"
        assert data["role"] == "orchestrator"
        assert "trust_level" in data
        assert "capabilities" in data
        assert "registered_at" in data

    def test_unknown_agent(self):
        r = _client.get("/public/agents/does-not-exist-99")
        assert r.status_code == 404

    def test_detail_has_no_sensitive_fields(self):
        """Public detail should not leak internal-only fields."""
        r = _client.get("/public/agents/orchestrator-prime")
        data = r.json()
        # divergence_penalty is auth-only
        assert "divergence_penalty" not in data


# ---------------------------------------------------------------------------
# Public Schema
# ---------------------------------------------------------------------------


class TestPublicSchema:
    def test_schema_structure(self):
        r = _client.get("/public/schema")
        assert r.status_code == 200
        data = r.json()
        assert data["protocol"] == "swarm.at"
        assert "version" in data
        assert "schemas" in data
        assert "guarantees" in data
        assert "tiers" in data

    def test_schema_has_required_schemas(self):
        r = _client.get("/public/schema")
        data = r.json()
        for name in ("Proposal", "SettlementResult", "SettleRequest"):
            assert name in data["schemas"], f"Missing schema: {name}"

    def test_schema_guarantees(self):
        r = _client.get("/public/schema")
        data = r.json()
        expected = {"determinism", "idempotency", "chain_integrity", "trust_scoring"}
        assert expected <= set(data["guarantees"])

    def test_schema_tiers(self):
        r = _client.get("/public/schema")
        data = r.json()
        for tier_name, policy in data["tiers"].items():
            assert "enforce_chain" in policy
            assert "write_ledger" in policy


# ---------------------------------------------------------------------------
# Discovery routes
# ---------------------------------------------------------------------------


class TestDiscoveryRoutes:
    """Verify OpenClaw discovery endpoints are live and public."""

    def test_llms_txt_returns_200(self):
        r = _client.get("/llms.txt")
        assert r.status_code == 200

    def test_llms_txt_is_plain_text(self):
        r = _client.get("/llms.txt")
        assert "text/plain" in r.headers.get("content-type", "")

    def test_llms_txt_contains_protocol_name(self):
        r = _client.get("/llms.txt")
        assert "# swarm.at" in r.text

    def test_robots_txt_returns_200(self):
        r = _client.get("/robots.txt")
        assert r.status_code == 200

    def test_robots_txt_references_llms(self):
        r = _client.get("/robots.txt")
        assert "llms.txt" in r.text

    def test_agent_card_returns_valid_json(self):
        r = _client.get("/.well-known/agent-card.json")
        assert r.status_code == 200
        data = r.json()
        for field in ("name", "skills", "serviceUrl"):
            assert field in data, f"Missing A2A field: {field}"

    def test_well_known_openapi_has_paths(self):
        r = _client.get("/.well-known/openapi.json")
        assert r.status_code == 200
        data = r.json()
        assert "paths" in data
        assert len(data["paths"]) > 0

    def test_discovery_routes_no_auth(self):
        """All discovery routes should be public even when auth is configured."""
        for path in ("/llms.txt", "/robots.txt", "/.well-known/agent-card.json",
                     "/.well-known/openapi.json"):
            r = _client.get(path)
            assert r.status_code == 200, f"{path} returned {r.status_code}"


# ---------------------------------------------------------------------------
# Public Blueprints
# ---------------------------------------------------------------------------


class TestPublicBlueprints:
    def test_blueprints_returns_list(self):
        r = _client.get("/public/blueprints")
        assert r.status_code == 200
        data = r.json()
        assert "blueprints" in data
        assert "total" in data
        assert "page" in data

    def test_seeded_blueprints_present(self):
        r = _client.get("/public/blueprints")
        data = r.json()
        assert data["total"] >= 3
        ids = {bp["blueprint_id"] for bp in data["blueprints"]}
        assert "audit-chain" in ids

    def test_blueprint_has_expected_fields(self):
        r = _client.get("/public/blueprints")
        data = r.json()
        if data["blueprints"]:
            bp = data["blueprints"][0]
            for field in ("blueprint_id", "name", "tags", "step_count"):
                assert field in bp, f"Missing field: {field}"

    def test_filter_by_tag(self):
        r = _client.get("/public/blueprints", params={"tag": "audit"})
        assert r.status_code == 200
        data = r.json()
        assert data["total"] >= 1
        for bp in data["blueprints"]:
            assert "audit" in bp["tags"]

    def test_blueprint_detail(self):
        r = _client.get("/public/blueprints/audit-chain")
        assert r.status_code == 200
        data = r.json()
        assert "steps" in data
        assert len(data["steps"]) > 0
        assert "step_id" in data["steps"][0]

    def test_blueprint_not_found(self):
        r = _client.get("/public/blueprints/nonexistent-blueprint-xyz")
        assert r.status_code == 404


# ---------------------------------------------------------------------------
# Auth enforcement — unauthenticated requests should be rejected
# ---------------------------------------------------------------------------


class TestAuthEnforcement:
    """Verify that /v1/* endpoints reject requests without valid auth."""

    def test_settle_requires_auth(self):
        r = _client.post("/v1/settle", json={"primary": {}, "shadow": None})
        assert r.status_code == 401

    def test_context_requires_auth(self):
        r = _client.get("/v1/context", params={"keywords": "test"})
        assert r.status_code == 401

    def test_status_requires_auth(self):
        r = _client.get("/v1/status/some-task")
        assert r.status_code == 401

    def test_ledger_latest_requires_auth(self):
        r = _client.get("/v1/ledger/latest")
        assert r.status_code == 401

    def test_ledger_verify_requires_auth(self):
        r = _client.get("/v1/ledger/verify")
        assert r.status_code == 401

    def test_register_agent_requires_auth(self):
        r = _client.post("/v1/agents/register", json={"agent_id": "test", "role": "worker"})
        assert r.status_code == 401

    def test_get_agent_requires_auth(self):
        r = _client.get("/v1/agents/orchestrator-prime")
        assert r.status_code == 401

    def test_whoami_requires_auth(self):
        r = _client.get("/v1/whoami", params={"agent_id": "orchestrator-prime"})
        assert r.status_code == 401

    def test_invalid_token_rejected(self):
        r = _client.get(
            "/v1/ledger/latest",
            headers={"Authorization": "Bearer totally-fake-token"},
        )
        assert r.status_code == 403

    def test_malformed_auth_header(self):
        r = _client.get(
            "/v1/ledger/latest",
            headers={"Authorization": "Basic dXNlcjpwYXNz"},
        )
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# Authenticated endpoints (only if SWARM_API_KEY is set)
# ---------------------------------------------------------------------------


_has_key = pytest.mark.skipif(not API_KEY, reason="SWARM_API_KEY not set")


def _authed(**kwargs) -> dict:
    return {"Authorization": f"Bearer {API_KEY}", **kwargs}


@_has_key
class TestAuthenticatedEndpoints:
    def test_ledger_latest(self):
        r = _client.get("/v1/ledger/latest", headers=_authed())
        assert r.status_code == 200
        assert "latest_hash" in r.json()

    def test_ledger_verify(self):
        r = _client.get("/v1/ledger/verify", headers=_authed())
        assert r.status_code == 200
        data = r.json()
        assert data["intact"] is True

    def test_get_agent(self):
        r = _client.get("/v1/agents/orchestrator-prime", headers=_authed())
        assert r.status_code == 200
        data = r.json()
        assert data["agent_id"] == "orchestrator-prime"
        # Auth endpoint includes divergence_penalty
        assert "divergence_penalty" in data

    def test_context(self):
        r = _client.get("/v1/context", params={"keywords": "test"}, headers=_authed())
        assert r.status_code == 200

    def test_status_not_found(self):
        r = _client.get("/v1/status/nonexistent-task", headers=_authed())
        assert r.status_code == 404


# ---------------------------------------------------------------------------
# Whoami (authenticated)
# ---------------------------------------------------------------------------


@_has_key
class TestWhoamiLive:
    def test_whoami_known_agent(self):
        r = _client.get("/v1/whoami", params={"agent_id": "orchestrator-prime"},
                        headers=_authed())
        assert r.status_code == 200
        data = r.json()
        assert data["agent_id"] == "orchestrator-prime"
        assert "trust_level" in data
        assert "allowed_tools" in data
        assert "next_promotion" in data

    def test_whoami_unknown_agent(self):
        r = _client.get("/v1/whoami", params={"agent_id": "nonexistent-agent-xyz"},
                        headers=_authed())
        assert r.status_code == 404

    def test_whoami_requires_auth(self):
        r = _client.get("/v1/whoami", params={"agent_id": "orchestrator-prime"})
        assert r.status_code == 401

    def test_whoami_missing_param(self):
        r = _client.get("/v1/whoami", headers=_authed())
        assert r.status_code == 422


# ---------------------------------------------------------------------------
# Security probes against live API
# ---------------------------------------------------------------------------


class TestLiveSecurityProbes:
    """Verify OWASP hardening works on the live deployment."""

    @pytest.mark.parametrize(
        "agent_id",
        [
            "'; DROP TABLE agents; --",
            "<script>alert(1)</script>",
            "../../../etc/passwd",
            "a" * 200,
        ],
        ids=["sql-injection", "xss", "path-traversal", "overflow"],
    )
    def test_malicious_agent_id_in_lookup(self, agent_id: str):
        """Malicious agent IDs should get 404, not 500."""
        r = _client.get(f"/public/agents/{agent_id}")
        assert r.status_code in (404, 422), f"Unexpected {r.status_code} for {agent_id!r}"

    def test_null_byte_rejected_by_transport(self):
        """Null bytes in URLs are blocked at the HTTP client level."""
        with pytest.raises(httpx.InvalidURL):
            _client.get("/public/agents/agent\x00injected")

    def test_oversized_settle_body(self):
        """Huge payload should be rejected, not crash the server."""
        huge = {"primary": {"x": "a" * 2_000_000}}
        r = _client.post("/v1/settle", json=huge)
        # Should get auth error (401) before payload processing, or 422 for validation
        assert r.status_code in (401, 413, 422)

    def test_deeply_nested_json(self):
        """Deep nesting should not cause stack overflow."""
        nested: dict = {"a": "leaf"}
        for _ in range(100):
            nested = {"nested": nested}
        r = _client.post("/v1/settle", json={"primary": nested})
        assert r.status_code in (401, 422)

    def test_public_endpoints_no_server_errors(self):
        """All public endpoints should return clean responses, never 500."""
        endpoints = [
            "/health",
            "/public/ledger",
            "/public/ledger/latest",
            "/public/ledger/verify",
            "/public/agents",
            "/public/schema",
            "/public/blueprints",
            "/llms.txt",
            "/robots.txt",
            "/.well-known/agent-card.json",
            "/.well-known/openapi.json",
        ]
        for ep in endpoints:
            r = _client.get(ep)
            assert r.status_code < 500, f"{ep} returned {r.status_code}"

    def test_cors_headers_present(self):
        """CORS should be configured for allowed origins."""
        r = _client.get(
            "/health",
            headers={"Origin": "https://swarm.at"},
        )
        assert r.status_code == 200
        # CORS middleware should echo the allowed origin
        assert "access-control-allow-origin" in r.headers

    def test_cors_rejects_unknown_origin(self):
        """Unknown origins should not get CORS headers."""
        r = _client.get(
            "/health",
            headers={"Origin": "https://evil.example.com"},
        )
        # Either no CORS header or not matching the evil origin
        acao = r.headers.get("access-control-allow-origin", "")
        assert "evil.example.com" not in acao


# ---------------------------------------------------------------------------
# Credits (authenticated)
# ---------------------------------------------------------------------------


@_has_key
class TestCreditsLive:
    def test_topup_returns_balance(self):
        r = _client.post(
            "/v1/credits/live-test-agent/topup",
            json={"amount": 1.0},
            headers=_authed(),
        )
        assert r.status_code == 200
        data = r.json()
        assert "balance" in data

    def test_get_credits_returns_balance(self):
        # Top up first to ensure agent exists
        _client.post(
            "/v1/credits/live-test-agent/topup",
            json={"amount": 1.0},
            headers=_authed(),
        )
        r = _client.get("/v1/credits/live-test-agent", headers=_authed())
        assert r.status_code == 200
        data = r.json()
        assert "balance" in data

    def test_credits_requires_auth(self):
        r = _client.get("/v1/credits/test")
        assert r.status_code == 401

    def test_credits_unknown_agent(self):
        r = _client.get("/v1/credits/definitely-not-real-agent", headers=_authed())
        assert r.status_code == 404


# ---------------------------------------------------------------------------
# Fork Blueprint (authenticated)
# ---------------------------------------------------------------------------


@_has_key
class TestForkBlueprintLive:
    def test_fork_returns_molecule(self):
        r = _client.post(
            "/v1/blueprints/audit-chain/fork",
            params={"agent_id": "live-test-agent"},
            headers=_authed(),
        )
        assert r.status_code == 200
        data = r.json()
        assert "molecule_id" in data
        assert "bead_count" in data

    def test_fork_unknown_blueprint(self):
        r = _client.post(
            "/v1/blueprints/nonexistent/fork",
            params={"agent_id": "test"},
            headers=_authed(),
        )
        assert r.status_code == 404

    def test_fork_requires_auth(self):
        r = _client.post(
            "/v1/blueprints/audit-chain/fork",
            params={"agent_id": "test"},
        )
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# Ledger Mode (public)
# ---------------------------------------------------------------------------


class TestLedgerModeLive:
    def test_ledger_mode_returns_status(self):
        r = _client.get("/v1/ledger/mode")
        assert r.status_code == 200
        data = r.json()
        assert "mode" in data

    def test_ledger_mode_has_chain_intact(self):
        r = _client.get("/v1/ledger/mode")
        data = r.json()
        assert "chain_intact" in data
        assert isinstance(data["chain_intact"], bool)


# ---------------------------------------------------------------------------
# Auth Token (public)
# ---------------------------------------------------------------------------


class TestAuthTokenLive:
    def test_token_requires_auth_or_jwt_config(self):
        """Unauthenticated callers cannot mint tokens (or JWT not configured)."""
        r = _client.post(
            "/v1/auth/token",
            json={"agent_id": "test", "role": "worker"},
        )
        # 401/403: auth enforced, request rejected
        # 501: JWT not configured (auth passed in dev mode, endpoint unavailable)
        assert r.status_code in (401, 403, 501)
