"""Tests for SDK Phase 4 methods: guard_action, authorship, webhooks, workflows, sessions."""

from __future__ import annotations

import pytest

import swarm_at.api.state as api_state
from swarm_at.sdk.client import GuardError, SwarmClient
from swarm_at.sdk.errors import SwarmError
from swarm_at.seed_blueprints import seed_blueprints


@pytest.fixture()
def sdk_client() -> SwarmClient:
    """SDK client backed by authed TestClient transport."""
    from fastapi.testclient import TestClient
    from swarm_at.api.main import app

    api_state.api_keys = {"sk-test-key"}
    test_client = TestClient(app)
    test_client.headers["Authorization"] = "Bearer sk-test-key"
    sdk = SwarmClient.__new__(SwarmClient)
    sdk.api_url = "http://testserver"
    sdk._http = test_client
    return sdk


# ---------------------------------------------------------------------------
# TestGuardAction
# ---------------------------------------------------------------------------


class TestGuardAction:
    def test_guard_action_succeeds(self, sdk_client: SwarmClient) -> None:
        sdk_client.register_agent("guard-agent")
        result = sdk_client.guard_action(
            agent_id="guard-agent",
            action="deploy",
            data={"env": "staging"},
            confidence=0.95,
        )
        assert result["status"] == "SETTLED"
        assert result["action"] == "deploy"
        assert result["agent_id"] == "guard-agent"
        assert result["hash"] is not None
        assert len(result["hash"]) == 64

    def test_guard_action_raises_on_rejection(self, sdk_client: SwarmClient) -> None:
        # Patch latest_hash to return a stale hash that breaks chain integrity
        sdk_client.register_agent("guard-reject-agent")
        original_latest_hash = sdk_client.latest_hash

        def bad_hash() -> str:
            return "0" * 64  # genesis hash is always stale after first settlement

        # Settle once to advance the chain, then use genesis hash (now stale)
        sdk_client.guard_action(agent_id="guard-reject-agent", action="first-action")

        # Monkeypatch latest_hash to return the genesis hash (now invalid parent)
        sdk_client.latest_hash = bad_hash  # type: ignore[method-assign]
        with pytest.raises(GuardError):
            sdk_client.guard_action(agent_id="guard-reject-agent", action="stale-action")

        sdk_client.latest_hash = original_latest_hash  # type: ignore[method-assign]


# ---------------------------------------------------------------------------
# TestClaimAuthorship
# ---------------------------------------------------------------------------


class TestClaimAuthorship:
    def test_claim_authorship_succeeds(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.claim_authorship(
            agent_id="author-agent",
            content="The quick brown fox",
            content_type="text",
            label="test-content",
        )
        assert result["status"] == "SETTLED"
        assert result["agent_id"] == "author-agent"
        assert result["content_hash"] is not None
        assert len(result["content_hash"]) == 64
        assert result["hash"] is not None
        assert len(result["hash"]) == 64

    def test_claim_authorship_raises_on_rejection(self, sdk_client: SwarmClient) -> None:
        # Settle once to advance the chain past genesis
        sdk_client.claim_authorship(agent_id="author-agent-2", content="first claim")

        # Monkeypatch latest_hash to return the genesis hash (stale parent)
        sdk_client.latest_hash = lambda: "0" * 64  # type: ignore[method-assign]
        with pytest.raises(GuardError):
            sdk_client.claim_authorship(agent_id="author-agent-2", content="rejected claim")


# ---------------------------------------------------------------------------
# TestVerifyAuthorship
# ---------------------------------------------------------------------------


class TestVerifyAuthorship:
    def test_verify_after_claim(self, sdk_client: SwarmClient) -> None:
        content = "Uniquely identifiable content for verify test"
        claimed = sdk_client.claim_authorship(
            agent_id="verify-agent",
            content=content,
            content_type="text",
        )
        content_hash = claimed["content_hash"]

        result = sdk_client.verify_authorship(content_hash=content_hash, agent_id="verify-agent")
        assert result["verified"] is True
        assert result["content_hash"] == content_hash

    def test_verify_unknown_hash(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.verify_authorship(content_hash="b" * 64)
        assert result["verified"] is False


# ---------------------------------------------------------------------------
# TestListAuthored
# ---------------------------------------------------------------------------


class TestListAuthored:
    def test_list_after_claim(self, sdk_client: SwarmClient) -> None:
        content = "Content for list-authored test"
        claimed = sdk_client.claim_authorship(
            agent_id="list-agent",
            content=content,
            content_type="text",
            label="authored-item",
        )
        content_hash = claimed["content_hash"]

        result = sdk_client.list_authored("list-agent")
        assert result["agent_id"] == "list-agent"
        assert result["total"] >= 1
        hashes = [c["content_hash"] for c in result["claims"]]
        assert content_hash in hashes

    def test_list_empty(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.list_authored("agent-with-no-claims")
        assert result["agent_id"] == "agent-with-no-claims"
        assert result["total"] == 0
        assert result["claims"] == []


# ---------------------------------------------------------------------------
# TestPublishBlueprint
# ---------------------------------------------------------------------------


class TestPublishBlueprint:
    def test_publish_returns_blueprint_info(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.publish_blueprint(
            name="My Test Blueprint",
            description="A blueprint for testing",
            tags=["test"],
            steps=[
                {"step_id": "step-1", "name": "Step One", "description": "First step"},
                {"step_id": "step-2", "name": "Step Two", "description": "Second step"},
            ],
            credit_cost=2.0,
            agent_id="publisher-agent",
        )
        assert "blueprint_id" in result
        assert result["name"] == "My Test Blueprint"
        assert result["step_count"] == 2
        assert result["validated"] is False
        assert result["author"] == "publisher-agent"

    def test_publish_auto_claims_authorship(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.publish_blueprint(
            name="Authorship Blueprint",
            description="Should auto-claim authorship",
            agent_id="author-publisher",
        )
        assert result["authorship_hash"] != ""
        assert len(result["authorship_hash"]) == 64


# ---------------------------------------------------------------------------
# TestWebhooks
# ---------------------------------------------------------------------------


class TestWebhooks:
    def test_register_and_list(self, sdk_client: SwarmClient) -> None:
        reg = sdk_client.register_webhook(
            event="settlement.created",
            url="https://example.com/webhook",
        )
        assert reg["event"] == "settlement.created"
        assert reg["status"] == "registered"

        # list_webhooks returns {"webhooks": {event: [url, ...]}, "total": N}
        listed = sdk_client.list_webhooks(event="settlement.created")
        event_urls: list[str] = listed["webhooks"].get("settlement.created", [])
        assert "https://example.com/webhook" in event_urls

    def test_unregister(self, sdk_client: SwarmClient) -> None:
        sdk_client.register_webhook(
            event="settlement.rejected",
            url="https://example.com/to-remove",
        )
        sdk_client.unregister_webhook(
            event="settlement.rejected",
            url="https://example.com/to-remove",
        )
        listed = sdk_client.list_webhooks(event="settlement.rejected")
        event_urls: list[str] = listed["webhooks"].get("settlement.rejected", [])
        assert "https://example.com/to-remove" not in event_urls

    def test_register_invalid_event(self, sdk_client: SwarmClient) -> None:
        with pytest.raises(SwarmError) as exc_info:
            sdk_client.register_webhook(
                event="not.a.real.event",
                url="https://example.com/invalid",
            )
        assert exc_info.value.status_code == 400


# ---------------------------------------------------------------------------
# TestExecuteStep
# ---------------------------------------------------------------------------


class TestExecuteStep:
    @pytest.fixture()
    def seeded_store(self):
        seed_blueprints(api_state.blueprint_store)

    def test_execute_step_in_forked_workflow(
        self, sdk_client: SwarmClient, seeded_store,
    ) -> None:
        # audit-chain costs 3.0 credits — give agent enough balance
        api_state.credit_ledger.register("workflow-agent", initial_balance=10.0)

        fork = sdk_client.fork_blueprint("audit-chain", agent_id="workflow-agent")
        molecule_id = fork["molecule_id"]
        assert fork["bead_count"] == 3

        # First step in audit-chain is "collect"
        result = sdk_client.execute_step(
            molecule_id=molecule_id,
            step_id="collect",
            agent_id="workflow-agent",
            data={"evidence": "gathered"},
            confidence=0.95,
        )
        assert result["molecule_id"] == molecule_id
        assert result["step_id"] == "collect"
        assert result["status"] == "SETTLED"
        assert result["hash"] is not None
        assert len(result["hash"]) == 64


# ---------------------------------------------------------------------------
# TestAuthorshipSessions
# ---------------------------------------------------------------------------


class TestAuthorshipSessions:
    def test_list_sessions_empty(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.list_authorship_sessions()
        assert result["total"] == 0
        assert result["sessions"] == []

    def test_get_report(self, sdk_client: SwarmClient) -> None:
        # Create a session directly via the API (SDK has no create_session method)
        resp = sdk_client._http.post(
            "/v1/authorship/sessions",
            json={"writer": "test-writer", "tool": "test-tool"},
        )
        assert resp.status_code == 200
        session_id = resp.json()["session_id"]

        # Record a generation event so the session has some data
        sdk_client._http.post(
            f"/v1/authorship/sessions/{session_id}/events",
            json={
                "event_type": "generation",
                "output_hash": "c" * 64,
                "model": "gpt-4",
                "phase": "scene",
            },
        )

        report = sdk_client.get_authorship_report(session_id)
        assert isinstance(report, dict)
        assert "work_agency" in report

    def test_get_report_text(self, sdk_client: SwarmClient) -> None:
        resp = sdk_client._http.post(
            "/v1/authorship/sessions",
            json={"writer": "text-writer", "tool": "text-tool"},
        )
        assert resp.status_code == 200
        session_id = resp.json()["session_id"]

        report_text = sdk_client.get_authorship_report(session_id, text=True)
        assert isinstance(report_text, str)
        assert len(report_text) > 0

    def test_list_sessions_after_create(self, sdk_client: SwarmClient) -> None:
        sdk_client._http.post(
            "/v1/authorship/sessions",
            json={"writer": "listed-writer", "tool": "some-tool"},
        )
        result = sdk_client.list_authorship_sessions(writer="listed-writer")
        assert result["total"] == 1
        assert result["sessions"][0]["writer"] == "listed-writer"
