#!/usr/bin/env python3
"""Fetch Polymarket data via Gamma API and build the dashboard HTML.

Replaces the POLYMARKET_DATA blob in docs/polymarket.html with fresh data
from gamma-api.polymarket.com.  No external dependencies beyond stdlib.
"""

import json
import re
import sys
import urllib.request
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path

DOCS_DIR = Path(__file__).resolve().parent.parent / "docs"
TEMPLATE = DOCS_DIR / "polymarket.html"
GAMMA_BASE = "https://gamma-api.polymarket.com"
TOP_N = 15

# ── Category keyword patterns ──────────────────────────────────────────────────
# Matched against " {question.lower()} " so word-boundary keywords work.

CATEGORIES: dict[str, list[str]] = {
    "politics": [
        "president", "election", "nomination", "congress", "senate",
        "governor", "vote", "democrat", "republican",
        "parliament", "prime minister", "political",
    ],
    "crypto": [
        "bitcoin", "btc", " eth ", "ethereum", "crypto", "token",
        "defi", "solana", "nft", "blockchain", "binance", "coinbase",
        "stablecoin",
    ],
    "ai_tech": [
        " ai ", "gpt", "openai", "anthropic", "deepmind",
        "artificial intelligence", "machine learning", " llm",
        "semiconductor", "chip", "nvidia", "robot", " agi",
        "chatbot",
    ],
    "sports": [
        "nba", "nfl", "premier league", "fifa", "world cup",
        "ufc", "super bowl", "champions league", "la liga",
        "bundesliga", "ligue 1", "serie a", "mlb", "nhl",
        "win the 202", " finals",
    ],
    "science": [
        "climate", "fda", "nasa", "vaccine", "asteroid",
        "hurricane", "earthquake", "pandemic", "virus", "disease",
        "temperature", "moon ", "mars ", "spacex",
    ],
    "economics": [
        "fed ", "federal reserve", "rate cut", "rate hike",
        "gdp", "inflation", "recession", "tariff",
        "unemployment", "stock market", "s&p", "interest rate",
        "treasury", "debt ceiling",
    ],
}


# ── Helpers ─────────────────────────────────────────────────────────────────────


def gamma_fetch(endpoint: str, params: dict[str, str]) -> list[dict]:
    """GET a JSON array from the Gamma API."""
    qs = urllib.parse.urlencode(params)
    url = f"{GAMMA_BASE}/{endpoint}?{qs}"
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (compatible; swarm-at-dashboard/1.0)",
    })
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read())
            return data if isinstance(data, list) else []
    except Exception as e:
        print(f"  x {endpoint} failed: {e}", file=sys.stderr)
        return []


def extract(m: dict) -> dict:
    """Normalize a Gamma market object into our dashboard schema."""
    prices = m.get("outcomePrices", "[]")
    if isinstance(prices, str):
        try:
            prices = json.loads(prices)
        except (json.JSONDecodeError, TypeError):
            prices = []
    yes_price = float(prices[0]) if prices else 0.0

    # Event slug is the correct URL slug for polymarket.com/event/<slug>
    events = m.get("events") or []
    event_slug = events[0].get("slug", "") if events else ""

    return {
        "question": m.get("question") or m.get("title") or "",
        "slug": event_slug or m.get("slug") or "",
        "volume": float(m.get("volumeNum") or m.get("volume") or 0),
        "volume_24h": float(m.get("volume24hr") or 0),
        "yes_price": round(yes_price, 4),
        "end_date": m.get("endDate") or "",
        "liquidity": float(m.get("liquidityNum") or m.get("liquidity") or 0),
        "competitive": float(m.get("competitive") or 0),
        "price_change_1d": round(float(m.get("oneDayPriceChange") or 0), 4),
    }


def categorize(question: str) -> str:
    """Return category key for a question, or empty string."""
    q = f" {question.lower()} "
    for cat, keywords in CATEGORIES.items():
        if any(kw in q for kw in keywords):
            return cat
    return ""


def dedup(markets: list[dict]) -> list[dict]:
    """Remove duplicate markets by slug, preserving order."""
    seen: set[str] = set()
    out: list[dict] = []
    for m in markets:
        key = m["slug"] or m["question"]
        if key not in seen:
            seen.add(key)
            out.append(m)
    return out


# ── Build ───────────────────────────────────────────────────────────────────────


def build() -> None:
    print("Polymarket dashboard build", file=sys.stderr)
    print("=" * 40, file=sys.stderr)

    fetches: list[tuple[str, dict[str, str]]] = [
        ("trending",    {"order": "volume24hr",   "ascending": "false"}),
        ("volume",      {"order": "volume",       "ascending": "false"}),
        ("competitive", {"order": "competitive",  "ascending": "false"}),
        ("ending_soon", {"order": "endDate",      "ascending": "true"}),
        ("liquidity",   {"order": "liquidity",    "ascending": "false"}),
    ]

    rankings: dict[str, list[dict]] = {}
    pool: dict[str, dict] = {}

    for name, extra in fetches:
        params = {"limit": "100", "active": "true", "closed": "false", **extra}
        print(f"  {name}...", file=sys.stderr, end=" ")
        raw = gamma_fetch("markets", params)
        extracted = dedup([extract(m) for m in raw])

        # For ending_soon, drop markets with no end date
        if name == "ending_soon":
            extracted = [m for m in extracted if m["end_date"]]

        rankings[name] = extracted[:TOP_N]
        print(f"{len(raw)} fetched, {len(rankings[name])} kept", file=sys.stderr)

        for m in extracted:
            pool.setdefault(m["slug"] or m["question"], m)

    if not any(rankings.values()):
        print("No data fetched -- keeping existing HTML", file=sys.stderr)
        sys.exit(1)

    # Build category buckets from the full pool
    categories: dict[str, list[dict]] = {cat: [] for cat in CATEGORIES}
    for m in pool.values():
        cat = categorize(m["question"])
        if cat:
            categories[cat].append(m)

    for cat in categories:
        categories[cat] = sorted(
            categories[cat], key=lambda x: x["volume_24h"], reverse=True
        )[:TOP_N]

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "rankings": rankings,
        "categories": categories,
    }

    # Summary
    print(f"\nPool: {len(pool)} unique markets", file=sys.stderr)
    for cat, items in categories.items():
        print(f"  {cat}: {len(items)}", file=sys.stderr)

    # Inject into HTML template
    html = TEMPLATE.read_text()
    blob = json.dumps(payload, separators=(",", ":"))
    html = re.sub(
        r"^const POLYMARKET_DATA = .+;$",
        lambda _: f"const POLYMARKET_DATA = {blob};",
        html,
        count=1,
        flags=re.MULTILINE,
    )
    TEMPLATE.write_text(html)
    print(f"\n-> {TEMPLATE} ({len(blob):,} bytes payload)", file=sys.stderr)


if __name__ == "__main__":
    build()
