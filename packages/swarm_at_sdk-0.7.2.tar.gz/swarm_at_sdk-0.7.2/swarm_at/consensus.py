"""Collective Consensus ("Molt" logic): multi-agent staking, verification, and finality."""

from __future__ import annotations

import time
from enum import Enum

from pydantic import BaseModel, Field

from swarm_at.agents import AgentRegistry
from swarm_at.engine import SwarmAtEngine, calculate_divergence
from swarm_at.models import Proposal, SettlementStatus


class StakeStatus(str, Enum):
    STAKED = "STAKED"
    VERIFIED = "VERIFIED"
    CONTESTED = "CONTESTED"
    FINALIZED = "FINALIZED"
    REJECTED = "REJECTED"


class Stake(BaseModel):
    agent_id: str
    proposal: Proposal
    timestamp: float = Field(default_factory=time.time)
    status: StakeStatus = StakeStatus.STAKED


class Verification(BaseModel):
    agent_id: str
    agrees: bool
    proposal: Proposal | None = None
    reason: str = ""
    timestamp: float = Field(default_factory=time.time)


class ConsensusRound(BaseModel):
    task_id: str
    stake: Stake | None = None
    verifications: list[Verification] = Field(default_factory=list)
    required_verifications: int = 1
    max_divergence: float = 0.15
    status: StakeStatus = StakeStatus.STAKED
    settled_hash: str | None = None


class ConsensusEngine:
    """Manages multi-agent consensus rounds for collaborative tasks.

    Flow:
    1. First agent stakes a solution
    2. Other agents verify or contest it
    3. Finality reached when consensus threshold is met
    """

    def __init__(
        self,
        engine: SwarmAtEngine | None = None,
        required_verifications: int = 1,
        max_divergence: float = 0.15,
        max_active_rounds: int = 1000,
        registry: AgentRegistry | None = None,
    ):
        self.engine = engine or SwarmAtEngine()
        self.required_verifications = required_verifications
        self.max_divergence = max_divergence
        self.max_active_rounds = max_active_rounds
        self.registry = registry
        self._rounds: dict[str, ConsensusRound] = {}

    def stake(self, task_id: str, agent_id: str, proposal: Proposal) -> ConsensusRound:
        """First agent stakes a solution on the ledger."""
        if self.registry is not None:
            agent = self.registry.get(agent_id)
            if not agent.can_stake():
                raise ConsensusError(f"Agent {agent_id} lacks permission to stake (trust: {agent.trust_level.value}).")
        active_count = len(self.active_rounds())
        if active_count >= self.max_active_rounds:
            raise ConsensusError(
                f"Too many active rounds ({active_count}). Limit: {self.max_active_rounds}"
            )
        if task_id in self._rounds:
            existing = self._rounds[task_id]
            if existing.status == StakeStatus.FINALIZED:
                raise ConsensusError(f"Task {task_id} already finalized.")
            # Allow re-staking if previous was contested/rejected
            if existing.status not in (StakeStatus.CONTESTED, StakeStatus.REJECTED):
                staker = existing.stake.agent_id if existing.stake else "unknown"
                raise ConsensusError(f"Task {task_id} already has an active stake from {staker}.")

        round_ = ConsensusRound(
            task_id=task_id,
            stake=Stake(agent_id=agent_id, proposal=proposal),
            required_verifications=self.required_verifications,
            max_divergence=self.max_divergence,
        )
        self._rounds[task_id] = round_
        return round_

    def verify(
        self,
        task_id: str,
        agent_id: str,
        agrees: bool,
        counter_proposal: Proposal | None = None,
        reason: str = "",
    ) -> ConsensusRound:
        """Another agent verifies or contests the staked solution."""
        if self.registry is not None:
            agent = self.registry.get(agent_id)
            if not agent.can_verify():
                raise ConsensusError(f"Agent {agent_id} lacks permission to verify (trust: {agent.trust_level.value}).")
        if task_id not in self._rounds:
            raise ConsensusError(f"No active stake for task {task_id}.")

        round_ = self._rounds[task_id]
        if round_.status == StakeStatus.FINALIZED:
            raise ConsensusError(f"Task {task_id} already finalized.")
        if round_.stake is None:
            raise ConsensusError(f"No stake to verify for task {task_id}.")
        if agent_id == round_.stake.agent_id:
            raise ConsensusError("Staker cannot verify their own stake.")

        # Check for duplicate verification from same agent
        for v in round_.verifications:
            if v.agent_id == agent_id:
                raise ConsensusError(f"Agent {agent_id} already verified task {task_id}.")

        # If contesting with a counter-proposal, check divergence
        if not agrees and counter_proposal is not None:
            divergence = calculate_divergence(round_.stake.proposal, counter_proposal)
            reason = reason or f"Divergence: {divergence:.2f}"

        verification = Verification(
            agent_id=agent_id,
            agrees=agrees,
            proposal=counter_proposal,
            reason=reason,
        )
        round_.verifications.append(verification)

        # Evaluate consensus
        round_ = self._evaluate(round_)
        self._rounds[task_id] = round_
        return round_

    def _evaluate(self, round_: ConsensusRound) -> ConsensusRound:
        """Evaluate whether consensus has been reached."""
        agrees = [v for v in round_.verifications if v.agrees]
        contests = [v for v in round_.verifications if not v.agrees]

        # Enough agreements? -> finalize
        if len(agrees) >= round_.required_verifications and round_.stake is not None:
            result = self.engine.verify_and_settle(round_.stake.proposal)
            if result.status == SettlementStatus.SETTLED:
                round_.status = StakeStatus.FINALIZED
                round_.settled_hash = result.hash
            else:
                round_.status = StakeStatus.REJECTED
            return round_

        # More contests than possible remaining agreements? -> reject
        if len(contests) > 0 and len(round_.verifications) >= round_.required_verifications:
            round_.status = StakeStatus.CONTESTED
            return round_

        # Still waiting for more verifications
        return round_

    def get_round(self, task_id: str) -> ConsensusRound | None:
        return self._rounds.get(task_id)

    def active_rounds(self) -> list[ConsensusRound]:
        return [r for r in self._rounds.values() if r.status not in (StakeStatus.FINALIZED, StakeStatus.REJECTED)]


class ConsensusError(Exception):
    pass
