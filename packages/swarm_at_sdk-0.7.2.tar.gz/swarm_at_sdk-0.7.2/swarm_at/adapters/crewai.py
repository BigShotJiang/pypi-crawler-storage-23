"""CrewAI adapter: settle task completions."""

from __future__ import annotations

from typing import Any

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmTaskCallback:
    """Task callback for CrewAI's ``Crew(task_callback=...)``.

    Usage::

        callback = SwarmTaskCallback()
        crew = Crew(agents=[...], tasks=[...], task_callback=callback.on_task_complete)

    Maps: CrewAI Task -> Bead, TaskOutput -> Payload.
    """

    def __init__(
        self,
        context: SettlementContext | None = None,
        confidence: float = 0.95,
        tier: SettlementTier | None = None,
    ) -> None:
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def on_task_complete(self, task_output: Any) -> None:
        """Called by CrewAI when a task completes."""
        # Extract what we can via getattr — no hard dependency on CrewAI types
        description = getattr(task_output, "description", "")
        raw_output = getattr(task_output, "raw", "")
        agent_name = getattr(task_output, "agent", "crewai-agent")
        if hasattr(agent_name, "role"):
            agent_name = agent_name.role

        self.context.settle(
            agent=str(agent_name),
            task=f"crewai:{description[:80]}",
            data={"description": str(description), "output": str(raw_output)},
            confidence=self.confidence,
        )
