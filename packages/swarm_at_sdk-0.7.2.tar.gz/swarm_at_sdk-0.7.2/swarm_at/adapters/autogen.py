"""AutoGen adapter: observe agent replies and settle them."""

from __future__ import annotations

from typing import Any

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmReplyCallback:
    """Pure observer callback compatible with AutoGen's ``agent.register_reply()``.

    Usage::

        callback = SwarmReplyCallback()
        agent.register_reply([autogen.Agent], callback.on_reply)

    Returns ``(False, None)`` so AutoGen continues normal processing.
    Maps: agent message -> Bead, agent name -> agent_id.
    """

    def __init__(
        self,
        context: SettlementContext | None = None,
        confidence: float = 0.95,
        tier: SettlementTier | None = None,
    ) -> None:
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def on_reply(
        self,
        recipient: Any,
        messages: Any,
        sender: Any,
        config: Any = None,
    ) -> tuple[bool, None]:
        """Called by AutoGen on each reply. Settles, then returns (False, None)."""
        agent_name = getattr(sender, "name", "autogen-agent")
        last_msg = ""
        if isinstance(messages, list) and messages:
            last = messages[-1]
            if isinstance(last, dict):
                last_msg = str(last.get("content", ""))
            else:
                last_msg = str(last)

        recipient_name = str(getattr(recipient, "name", "unknown"))

        self.context.settle(
            agent=str(agent_name),
            task=f"autogen:{agent_name}:reply",
            data={"message": last_msg, "recipient": recipient_name},
            confidence=self.confidence,
        )
        return (False, None)
