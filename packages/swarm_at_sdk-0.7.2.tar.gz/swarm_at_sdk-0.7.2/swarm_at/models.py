"""Data models for the swarm.at settlement protocol."""

from __future__ import annotations

import json
import string
import uuid
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

MAX_PAYLOAD_BYTES = 1_048_576  # 1 MB
MAX_NESTING_DEPTH = 32


def _check_nesting_depth(obj: Any, current: int = 0) -> int:
    """Return the maximum nesting depth of a JSON-serializable object."""
    if current > MAX_NESTING_DEPTH:
        return current
    if isinstance(obj, dict):
        if not obj:
            return current
        return max(_check_nesting_depth(v, current + 1) for v in obj.values())
    if isinstance(obj, list):
        if not obj:
            return current
        return max(_check_nesting_depth(v, current + 1) for v in obj)
    return current


_HEX_CHARS = set(string.hexdigits)


class AgentMetadata(BaseModel):
    model: str
    version: str = "1.0"


class Header(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    parent_hash: str = Field(..., min_length=64, max_length=64)
    agent_metadata: AgentMetadata = AgentMetadata(model="unknown")

    @field_validator("parent_hash")
    @classmethod
    def parent_hash_must_be_hex(cls, v: str) -> str:
        if not all(c in _HEX_CHARS for c in v):
            raise ValueError("parent_hash must contain only hexadecimal characters")
        return v


class Payload(BaseModel):
    data_update: dict[str, Any] = Field(default_factory=dict)
    confidence_score: float = Field(..., ge=0.0, le=1.0)

    @model_validator(mode="after")
    def check_payload_limits(self) -> "Payload":
        raw = json.dumps(self.data_update, default=str)
        if len(raw) > MAX_PAYLOAD_BYTES:
            raise ValueError(
                f"Payload data_update exceeds {MAX_PAYLOAD_BYTES} bytes ({len(raw)})"
            )
        depth = _check_nesting_depth(self.data_update)
        if depth > MAX_NESTING_DEPTH:
            raise ValueError(
                f"Payload nesting depth {depth} exceeds limit of {MAX_NESTING_DEPTH}"
            )
        return self


class Proposal(BaseModel):
    header: Header
    payload: Payload
    proof: str | None = None


class SettlementStatus(str, Enum):
    SETTLED = "SETTLED"
    REJECTED = "REJECTED"
    ESCROWED = "ESCROWED"


class SettlementResult(BaseModel):
    status: SettlementStatus
    hash: str | None = None
    reason: str | None = None


class LedgerEntry(BaseModel):
    timestamp: float
    task_id: str
    parent_hash: str
    payload: dict[str, Any]
    current_hash: str


class InstitutionalRules(BaseModel):
    min_confidence: float = 0.85
    max_drift_allowed: float = 0.15


class SettlementReceipt(BaseModel):
    """Rich settlement receipt for third-party verification."""

    status: SettlementStatus
    hash: str | None = None
    reason: str | None = None
    task_id: str
    agent_id: str = ""
    timestamp: float = 0.0
    parent_hash: str = ""
    trust_level: str = ""
    credit_cost: float = 0.0


class AuthorshipClaim(BaseModel):
    """Structured authorship claim payload."""

    type: str = "authorship-claim"
    agent_id: str
    content_hash: str = Field(..., min_length=64, max_length=64)
    content_type: str = ""
    label: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("content_hash")
    @classmethod
    def content_hash_must_be_hex(cls, v: str) -> str:
        if not all(c in _HEX_CHARS for c in v):
            raise ValueError("content_hash must contain only hexadecimal characters")
        return v


class AuthorshipReceipt(SettlementReceipt):
    """Receipt for authorship claims. Adds content_hash."""

    content_hash: str = ""
    content_type: str = ""


class SettleRequest(BaseModel):
    primary: Proposal
    shadow: Proposal | None = None


class BatchSettleRequest(BaseModel):
    proposals: list[SettleRequest] = Field(..., max_length=100)


class BatchSettleResponse(BaseModel):
    results: list[SettlementResult]
    settled: int
    rejected: int
