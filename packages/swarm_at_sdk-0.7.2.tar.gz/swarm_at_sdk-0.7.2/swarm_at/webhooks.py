"""Webhook registry for settlement event notifications."""

from __future__ import annotations

import logging

_logger = logging.getLogger("swarm_at.webhooks")


class WebhookRegistry:
    """In-memory webhook subscription store."""

    def __init__(self) -> None:
        self._hooks: dict[str, list[str]] = {}  # event -> [url, ...]

    def register(self, event: str, url: str) -> None:
        """Subscribe a URL to an event type."""
        if event not in self._hooks:
            self._hooks[event] = []
        if url not in self._hooks[event]:
            self._hooks[event].append(url)

    def unregister(self, event: str, url: str) -> bool:
        """Remove a webhook. Returns True if found."""
        if event in self._hooks and url in self._hooks[event]:
            self._hooks[event].remove(url)
            return True
        return False

    def list_hooks(self, event: str | None = None) -> dict[str, list[str]]:
        """List registered webhooks, optionally filtered by event."""
        if event:
            return {event: self._hooks.get(event, [])}
        return dict(self._hooks)

    def get_urls(self, event: str) -> list[str]:
        """Get all URLs for a specific event."""
        return list(self._hooks.get(event, []))

    def clear(self) -> None:
        """Remove all registrations."""
        self._hooks.clear()

    @property
    def count(self) -> int:
        """Total number of registered webhooks across all events."""
        return sum(len(urls) for urls in self._hooks.values())
