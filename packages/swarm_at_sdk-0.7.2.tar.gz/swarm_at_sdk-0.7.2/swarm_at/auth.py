"""JWT authentication for swarm.at agents."""

from __future__ import annotations

import time
from typing import Any, Callable

import jwt
from fastapi import HTTPException, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer


class AuthError(Exception):
    """Custom exception for authentication failures."""


class JWTAuth:
    """JWT authentication handler for swarm.at agents."""

    def __init__(
        self,
        secret: str = "swarm-at-dev-secret-not-for-prod!",
        algorithm: str = "HS256",
        expiry_seconds: int = 3600,
    ) -> None:
        self.secret = secret
        self.algorithm = algorithm
        self.expiry_seconds = expiry_seconds

    def create_token(self, agent_id: str, role: str = "worker") -> str:
        """Create a signed JWT token with agent claims."""
        now = int(time.time())
        claims = {
            "sub": agent_id,
            "role": role,
            "iat": now,
            "exp": now + self.expiry_seconds,
        }
        return jwt.encode(claims, self.secret, algorithm=self.algorithm)

    def verify_token(self, token: str) -> dict[str, Any]:
        """Verify and decode a JWT token. Raises AuthError on failure."""
        try:
            payload = jwt.decode(
                token,
                self.secret,
                algorithms=[self.algorithm],
            )
            if not isinstance(payload, dict):
                raise AuthError("Invalid token payload")
            return dict(payload)
        except jwt.ExpiredSignatureError as e:
            raise AuthError("Token has expired") from e
        except jwt.InvalidTokenError as e:
            raise AuthError("Invalid token") from e

    def get_agent_id(self, token: str) -> str:
        """Extract agent_id from token. Raises AuthError on failure."""
        payload = self.verify_token(token)
        agent_id = payload.get("sub")
        if not agent_id or not isinstance(agent_id, str):
            raise AuthError("Token missing agent_id (sub claim)")
        return str(agent_id)


def create_fastapi_dependency(
    auth: JWTAuth, api_keys: set[str] | None = None
) -> Callable[[HTTPAuthorizationCredentials], dict[str, Any]]:
    """Factory that returns a FastAPI dependency for JWT/API key auth."""
    security = HTTPBearer()

    def verify_auth(
        credentials: HTTPAuthorizationCredentials = Security(security),
    ) -> dict[str, Any]:
        token = credentials.credentials

        # Try JWT first
        try:
            payload = auth.verify_token(token)
            return {
                "agent_id": payload["sub"],
                "role": payload.get("role", "worker"),
            }
        except AuthError:
            pass

        # Fall back to API key check
        if api_keys and token in api_keys:
            return {"agent_id": "api-key-user", "role": "worker"}

        # Both failed
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    return verify_auth
