"""Authorship provenance: settlement-backed audit trails for human-AI creative work.

Implements the Human-AI Agency Spectrum framework (Ghuneim, 2026) as a
verifiable evidence layer on top of swarm.at's hash-chained ledger.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import logging
import time
import uuid
from enum import Enum, IntEnum
from typing import Any

from pydantic import BaseModel, Field

from swarm_at.models import SettlementResult
from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


# ---------------------------------------------------------------------------
# Agency Spectrum data model
# ---------------------------------------------------------------------------


class AgencyLayer(IntEnum):
    """Six layers of human-AI agency from the Agency Spectrum framework."""

    L0_ORACLE = 0
    L1_EXECUTOR = 1
    L2_COLLABORATOR = 2
    L3_SUPERVISOR = 3
    L4_DIRECTOR = 4
    L5_PURE_TOOL = 5


class CreativePhase(str, Enum):
    """Creative contribution types with associated weights."""

    CONCEPT = "concept"
    STRUCTURE = "structure"
    CHARACTER = "character"
    SCENE = "scene"
    DIALOGUE = "dialogue"
    REVISION = "revision"


PHASE_WEIGHTS: dict[CreativePhase, float] = {
    CreativePhase.CONCEPT: 0.25,
    CreativePhase.STRUCTURE: 0.20,
    CreativePhase.CHARACTER: 0.15,
    CreativePhase.SCENE: 0.15,
    CreativePhase.DIALOGUE: 0.15,
    CreativePhase.REVISION: 0.10,
}


# ---------------------------------------------------------------------------
# Internal event model
# ---------------------------------------------------------------------------


class AuthorshipEvent(BaseModel):
    """Single event in a writing session's provenance chain."""

    event_type: str
    actor: str
    actor_role: str  # "writer" or "tool"
    phase: CreativePhase
    agency: AgencyLayer
    timestamp: float = Field(default_factory=time.time)
    settlement_hash: str
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Compliance and behavioral models
# ---------------------------------------------------------------------------

ANCHORING_THRESHOLD = 0.80
SATISFICING_THRESHOLD = 3


class ComplianceAssessment(BaseModel):
    """Maps work agency score to regulatory frameworks."""

    copyright: str
    wga: str
    sag_aftra: str
    eu_ai_act: str
    safe_harbor: bool
    market_tier: str

    @classmethod
    def from_score(cls, score: float) -> ComplianceAssessment:
        if score >= 0.90:
            return cls(
                copyright="Clean — Full human authorship claim",
                wga="Full credit — Literary material",
                sag_aftra="Compliant with consent",
                eu_ai_act="Assistive function — Marking exempt",
                safe_harbor=True,
                market_tier="Premium",
            )
        if score >= 0.70:
            return cls(
                copyright="Diluted — Defensible with documentation",
                wga="Conditional — L3 requires process evidence",
                sag_aftra="Enhanced consent required",
                eu_ai_act="Assistive function — Marking exempt",
                safe_harbor=False,
                market_tier="Standard",
            )
        if score >= 0.40:
            return cls(
                copyright="Shared — Thin copyright at best",
                wga="Not literary material (studio use)",
                sag_aftra="Prohibited for performance",
                eu_ai_act="Marking required",
                safe_harbor=False,
                market_tier="Budget",
            )
        return cls(
            copyright="Absent — No human authorship claim",
            wga="Not literary material",
            sag_aftra="Prohibited",
            eu_ai_act="Marking required",
            safe_harbor=False,
            market_tier="Locked out of professional tiers",
        )


class BehavioralFlags(BaseModel):
    """Behavioral constraint warnings detected from session data."""

    anchoring_risk: bool = False
    satisficing_risk: bool = False
    missing_foundation: bool = False
    high_acceptance: float = 0.0


# ---------------------------------------------------------------------------
# Report models
# ---------------------------------------------------------------------------


class ProvenanceEvent(BaseModel):
    """Single event in the provenance report."""

    event_type: str
    actor: str
    actor_role: str
    phase: str
    agency_layer: int
    timestamp: float
    settlement_hash: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProvenanceReport(BaseModel):
    """Verifiable authorship provenance report."""

    session_id: str
    writer: str
    tool: str
    started_at: float
    completed_at: float | None

    work_agency: float
    work_agency_pct: str
    phase_scores: dict[str, float]

    compliance: ComplianceAssessment
    safe_harbor: bool
    behavioral_flags: BehavioralFlags

    total_events: int
    human_events: int
    ai_events: int
    events: list[ProvenanceEvent]

    first_hash: str
    last_hash: str
    chain_verified: bool
    ledger_path: str

    def to_text(self) -> str:
        """Human-readable provenance report."""
        from swarm_at import __version__

        lines: list[str] = []
        lines.append("AUTHORSHIP PROVENANCE REPORT")
        lines.append("=" * 60)
        lines.append(
            f"Session: {self.session_id} | Writer: {self.writer} | Tool: {self.tool}"
        )

        start = datetime.datetime.fromtimestamp(
            self.started_at, tz=datetime.timezone.utc
        ).strftime("%Y-%m-%d %H:%M")
        end = (
            datetime.datetime.fromtimestamp(
                self.completed_at, tz=datetime.timezone.utc
            ).strftime("%Y-%m-%d %H:%M")
            if self.completed_at
            else "in progress"
        )
        lines.append(f"Period: {start} -> {end}")
        lines.append("")

        lines.append(f"WORK AGENCY: {self.work_agency_pct}")
        lines.append("=" * 60)
        lines.append("")

        lines.append("Phase Breakdown:")
        for phase_name, score in self.phase_scores.items():
            bar_len = int(score * 20)
            bar = "#" * bar_len
            lines.append(f"  {phase_name:<16} {bar:<20} {score:.0%}")
        lines.append("")

        harbor = "ABOVE THRESHOLD" if self.safe_harbor else "BELOW THRESHOLD"
        lines.append(f"SAFE HARBOR: {harbor} ({self.work_agency_pct})")
        lines.append("")

        lines.append("COMPLIANCE ASSESSMENT:")
        lines.append(f"  Copyright (USCO):  {self.compliance.copyright}")
        lines.append(f"  WGA:               {self.compliance.wga}")
        lines.append(f"  SAG-AFTRA:         {self.compliance.sag_aftra}")
        lines.append(f"  EU AI Act:         {self.compliance.eu_ai_act}")
        lines.append(f"  Market Tier:       {self.compliance.market_tier}")
        lines.append("")

        flags = self.behavioral_flags
        if flags.anchoring_risk or flags.satisficing_risk or flags.missing_foundation:
            lines.append("BEHAVIORAL FLAGS:")
            if flags.anchoring_risk:
                lines.append("  ! Anchoring risk: high average kept_ratio")
            if flags.satisficing_risk:
                lines.append(
                    "  ! Satisficing risk: consecutive AI outputs without human review"
                )
            if flags.missing_foundation:
                lines.append(
                    "  ! Missing foundation: AI generation before human creative direction"
                )
            lines.append("")

        lines.append(
            f"EVENT TIMELINE ({self.total_events} events: "
            f"{self.human_events} human, {self.ai_events} AI):"
        )
        for ev in self.events:
            ts = datetime.datetime.fromtimestamp(
                ev.timestamp, tz=datetime.timezone.utc
            ).strftime("%H:%M:%S")
            role = "HUMAN" if ev.actor_role == "writer" else "AI"
            lines.append(
                f"  {ts}  L{ev.agency_layer}  [{role}]  {ev.event_type}  {ev.phase}"
            )
        lines.append("")

        verified = "VERIFIED" if self.chain_verified else "FAILED"
        lines.append(
            f"CHAIN INTEGRITY: {verified} ({self.total_events}/{self.total_events} hashes valid)"
        )
        lines.append(f"Ledger: {self.ledger_path}")
        if self.first_hash:
            lines.append(
                f"First hash: {self.first_hash[:12]}...  Last hash: {self.last_hash[:12]}..."
            )
        lines.append("")
        lines.append("This report is informational, not legal advice.")
        lines.append(f"Generated by swarm.at v{__version__}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# WritingSession — the main API
# ---------------------------------------------------------------------------


class WritingSession:
    """Settlement-backed audit trail for human-AI creative work."""

    def __init__(
        self,
        writer: str,
        tool: str,
        phase_weights: dict[CreativePhase, float] | None = None,
        tier: SettlementTier | None = None,
        ledger_path: str = "ledger.jsonl",
        expires_at: float | None = None,
    ) -> None:
        self.writer = writer
        self.tool = tool
        self.session_id = uuid.uuid4().hex[:8]
        self.phase_weights = phase_weights or dict(PHASE_WEIGHTS)
        self.events: list[AuthorshipEvent] = []
        self._ctx = SettlementContext(tier=tier, ledger_path=ledger_path)
        self._started_at = time.time()
        self.expires_at = expires_at

    @property
    def is_expired(self) -> bool:
        """Check if the session has exceeded its TTL."""
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at

    # -- serialization -----------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize session to a JSON-safe dict. SettlementContext is excluded."""
        return {
            "session_id": self.session_id,
            "writer": self.writer,
            "tool": self.tool,
            "started_at": self._started_at,
            "phase_weights": {p.value: w for p, w in self.phase_weights.items()},
            "events": [ev.model_dump() for ev in self.events],
            "expires_at": self.expires_at,
        }

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        ledger_path: str = "ledger.jsonl",
        tier: SettlementTier | None = None,
    ) -> WritingSession:
        """Reconstruct a session from a serialized dict."""
        session = cls.__new__(cls)
        session.session_id = data["session_id"]
        session.writer = data["writer"]
        session.tool = data["tool"]
        session._started_at = data["started_at"]
        session.phase_weights = (
            {CreativePhase(k): v for k, v in data["phase_weights"].items()}
            if data.get("phase_weights")
            else dict(PHASE_WEIGHTS)
        )
        session.events = [
            AuthorshipEvent.model_validate(ev) for ev in data.get("events", [])
        ]
        session._ctx = SettlementContext(tier=tier, ledger_path=ledger_path)
        session.expires_at = data.get("expires_at")
        return session

    # -- internal helpers --------------------------------------------------

    def _settle_event(
        self,
        event_type: str,
        actor: str,
        actor_role: str,
        phase: CreativePhase,
        agency: AgencyLayer,
        metadata: dict[str, Any],
    ) -> SettlementResult:
        """Settle an event to the ledger and record it."""
        data = {
            "event_type": event_type,
            "actor": actor,
            "actor_role": actor_role,
            "phase": phase.value,
            "agency_layer": agency.value,
            "session_id": self.session_id,
            **metadata,
        }
        result = self._ctx.settle(agent=actor, task=event_type, data=data)

        if result.hash:
            event = AuthorshipEvent(
                event_type=event_type,
                actor=actor,
                actor_role=actor_role,
                phase=phase,
                agency=agency,
                settlement_hash=result.hash,
                metadata=metadata,
            )
            self.events.append(event)

        return result

    # -- public methods ----------------------------------------------------

    def direct(
        self,
        action: str,
        chose: str,
        rejected: list[str] | None = None,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L4_DIRECTOR,
    ) -> SettlementResult:
        """Record a human creative decision."""
        meta: dict[str, Any] = {"action": action, "chose": chose}
        if rejected:
            meta["rejected"] = rejected
        return self._settle_event(
            "creative-direction", self.writer, "writer", phase, agency, meta
        )

    def prompt(
        self,
        text: str,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L3_SUPERVISOR,
    ) -> SettlementResult:
        """Record a prompt given to the AI tool. Text is hashed, not stored."""
        prompt_hash = hashlib.sha256(text.encode()).hexdigest()
        meta: dict[str, Any] = {"prompt_hash": prompt_hash}
        return self._settle_event(
            "prompt", self.writer, "writer", phase, agency, meta
        )

    def generate(
        self,
        output_hash: str,
        model: str = "",
        params: dict[str, Any] | None = None,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L1_EXECUTOR,
    ) -> SettlementResult:
        """Record AI-generated output. Caller provides the hash."""
        meta: dict[str, Any] = {"output_hash": output_hash}
        if model:
            meta["model"] = model
        if params:
            meta["params"] = params
        return self._settle_event(
            "ai-generation", self.tool, "tool", phase, agency, meta
        )

    def revise(
        self,
        description: str,
        kept_ratio: float,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L3_SUPERVISOR,
    ) -> SettlementResult:
        """Record human edits to AI output."""
        if not 0.0 <= kept_ratio <= 1.0:
            raise ValueError(f"kept_ratio must be 0.0-1.0, got {kept_ratio}")
        meta: dict[str, Any] = {
            "description": description,
            "kept_ratio": kept_ratio,
        }
        return self._settle_event(
            "editorial-revision", self.writer, "writer", phase, agency, meta
        )

    def reject(
        self,
        output_hash: str,
        reason: str,
        phase: CreativePhase = CreativePhase.SCENE,
    ) -> SettlementResult:
        """Record rejection of AI output. Agency is always L4."""
        meta: dict[str, Any] = {"output_hash": output_hash, "reason": reason}
        return self._settle_event(
            "rejection", self.writer, "writer", phase, AgencyLayer.L4_DIRECTOR, meta
        )

    def approve(
        self,
        content_hash: str,
        version: str = "",
    ) -> SettlementResult:
        """Record final approval. Session-level, no phase."""
        meta: dict[str, Any] = {"content_hash": content_hash}
        if version:
            meta["version"] = version
        return self._settle_event(
            "approval",
            self.writer,
            "writer",
            CreativePhase.REVISION,
            AgencyLayer.L4_DIRECTOR,
            meta,
        )

    # -- computed properties -----------------------------------------------

    @property
    def work_agency(self) -> float:
        """Weighted agency score across creative phases.

        Formula from Agency Spectrum:
            Work Agency = sum(weight * phase_agency) / sum(weights_used)
        Phases without events are excluded from the denominator.
        """
        if not self.events:
            return 0.0

        phase_scores: dict[CreativePhase, list[float]] = {}
        for ev in self.events:
            phase_scores.setdefault(ev.phase, []).append(ev.agency.value / 5.0)

        numerator = 0.0
        denominator = 0.0
        for phase, scores in phase_scores.items():
            weight = self.phase_weights.get(phase, 0.0)
            if weight > 0:
                phase_avg = sum(scores) / len(scores)
                numerator += weight * phase_avg
                denominator += weight

        if denominator == 0:
            return 0.0
        return numerator / denominator

    @property
    def behavioral_flags(self) -> BehavioralFlags:
        """Detect behavioral constraint risks from session data."""
        # Anchoring: high average kept_ratio across revisions
        revisions = [e for e in self.events if e.event_type == "editorial-revision"]
        avg_kept = 0.0
        if revisions:
            ratios = [e.metadata.get("kept_ratio", 0.0) for e in revisions]
            avg_kept = sum(ratios) / len(ratios)
        anchoring = len(revisions) > 0 and avg_kept > ANCHORING_THRESHOLD

        # Satisficing: N+ consecutive ai-generation without human creative event
        human_types = {"creative-direction", "editorial-revision", "rejection"}
        max_consecutive_gen = 0
        current_streak = 0
        for ev in self.events:
            if ev.event_type == "ai-generation":
                current_streak += 1
                max_consecutive_gen = max(max_consecutive_gen, current_streak)
            elif ev.event_type in human_types:
                current_streak = 0
        satisficing = max_consecutive_gen >= SATISFICING_THRESHOLD

        # Missing foundation: first AI generation before any L4+ human event
        has_foundation = False
        missing = False
        for ev in self.events:
            if ev.actor_role == "writer" and ev.agency >= AgencyLayer.L4_DIRECTOR:
                has_foundation = True
            if ev.event_type == "ai-generation" and not has_foundation:
                missing = True
                break

        # High acceptance ratio
        gen_count = sum(1 for e in self.events if e.event_type == "ai-generation")
        reject_count = sum(1 for e in self.events if e.event_type == "rejection")
        high_accept = 0.0
        if gen_count > 0:
            high_accept = (gen_count - reject_count) / gen_count

        return BehavioralFlags(
            anchoring_risk=anchoring,
            satisficing_risk=satisficing,
            missing_foundation=missing,
            high_acceptance=high_accept,
        )

    def report(self) -> ProvenanceReport:
        """Generate a verifiable provenance report for this session."""
        wa = self.work_agency
        flags = self.behavioral_flags
        compliance = ComplianceAssessment.from_score(wa)

        # Phase scores
        phase_scores: dict[str, float] = {}
        phase_events: dict[CreativePhase, list[float]] = {}
        for ev in self.events:
            phase_events.setdefault(ev.phase, []).append(ev.agency.value / 5.0)
        for phase, scores in phase_events.items():
            phase_scores[phase.value] = sum(scores) / len(scores)

        # Event conversion
        prov_events = [
            ProvenanceEvent(
                event_type=ev.event_type,
                actor=ev.actor,
                actor_role=ev.actor_role,
                phase=ev.phase.value,
                agency_layer=ev.agency.value,
                timestamp=ev.timestamp,
                settlement_hash=ev.settlement_hash,
                metadata=ev.metadata,
            )
            for ev in self.events
        ]

        human = sum(1 for e in self.events if e.actor_role == "writer")
        ai = sum(1 for e in self.events if e.actor_role == "tool")

        first_hash = self.events[0].settlement_hash if self.events else ""
        last_hash = self.events[-1].settlement_hash if self.events else ""

        # Chain verification
        chain_ok = True
        if self.events and self._ctx._engine:
            chain_ok = self._ctx._engine.ledger.verify_chain()

        ledger_path = ""
        if self._ctx._engine:
            ledger_path = str(self._ctx._engine.ledger.path)

        return ProvenanceReport(
            session_id=self.session_id,
            writer=self.writer,
            tool=self.tool,
            started_at=self._started_at,
            completed_at=time.time(),
            work_agency=wa,
            work_agency_pct=f"{wa:.1%}",
            phase_scores=phase_scores,
            compliance=compliance,
            safe_harbor=compliance.safe_harbor,
            behavioral_flags=flags,
            total_events=len(self.events),
            human_events=human,
            ai_events=ai,
            events=prov_events,
            first_hash=first_hash,
            last_hash=last_hash,
            chain_verified=chain_ok,
            ledger_path=ledger_path,
        )


# ---------------------------------------------------------------------------
# Session stores
# ---------------------------------------------------------------------------

_store_logger = logging.getLogger("swarm_at.authorship.store")


class WritingSessionStore:
    """In-memory store for writing sessions."""

    def __init__(self) -> None:
        self._sessions: dict[str, WritingSession] = {}

    def create(self, session: WritingSession) -> None:
        self._sessions[session.session_id] = session

    def get(self, session_id: str) -> WritingSession | None:
        return self._sessions.get(session_id)

    def update(self, session: WritingSession) -> None:
        self._sessions[session.session_id] = session

    def delete(self, session_id: str) -> bool:
        """Remove a session. Returns True if it existed."""
        return self._sessions.pop(session_id, None) is not None

    def cleanup_expired(self) -> int:
        """Remove expired sessions. Returns count removed."""
        expired = [sid for sid, s in self._sessions.items() if s.is_expired]
        for sid in expired:
            del self._sessions[sid]
        return len(expired)

    def list_sessions(self, writer: str | None = None) -> list[WritingSession]:
        sessions = list(self._sessions.values())
        if writer is not None:
            sessions = [s for s in sessions if s.writer == writer]
        return sessions

    def __contains__(self, session_id: str) -> bool:
        return session_id in self._sessions

    def __len__(self) -> int:
        return len(self._sessions)


class PersistentWritingSessionStore(WritingSessionStore):
    """WritingSessionStore backed by a JSONL file."""

    def __init__(
        self,
        path: str,
        ledger_path: str = "ledger.jsonl",
        tier: SettlementTier | None = None,
    ) -> None:
        super().__init__()
        self._path = path
        self._ledger_path = ledger_path
        self._tier = tier
        self._replay()

    def _replay(self) -> None:
        """Rebuild sessions from JSONL on disk."""
        try:
            with open(self._path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                        if record.get("event") == "delete":
                            sid = record["session"]["session_id"]
                            self._sessions.pop(sid, None)
                            continue
                        session_data = record["session"]
                        session = WritingSession.from_dict(
                            session_data,
                            ledger_path=self._ledger_path,
                            tier=self._tier,
                        )
                        self._sessions[session.session_id] = session
                    except Exception:
                        _store_logger.warning("Skipping corrupt line in %s", self._path)
        except FileNotFoundError:
            pass

    def _append(self, event: str, session: WritingSession) -> None:
        with open(self._path, "a") as f:
            record = {"event": event, "session": session.to_dict()}
            f.write(json.dumps(record) + "\n")

    def create(self, session: WritingSession) -> None:
        super().create(session)
        self._append("create", session)

    def delete(self, session_id: str) -> bool:
        session = self._sessions.get(session_id)
        if session is None:
            return False
        del self._sessions[session_id]
        with open(self._path, "a") as f:
            record = {"event": "delete", "session": session.to_dict()}
            f.write(json.dumps(record) + "\n")
        return True

    def update(self, session: WritingSession) -> None:
        super().update(session)
        self._append("update", session)
