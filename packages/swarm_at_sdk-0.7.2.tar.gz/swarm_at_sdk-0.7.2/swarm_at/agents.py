"""Agent Identity & Roles: persistent identity, role-based trust, lifecycle management."""

from __future__ import annotations

import json
import logging
import math
import re
import time
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator

# Agent ID validation: alphanumeric start/end, dots/hyphens/underscores allowed, 2-64 chars
AGENT_ID_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,62}[a-zA-Z0-9]$")
RESERVED_AGENT_IDS = frozenset({"system", "admin", "swarm", "root", "operator", "ledger"})
DEFAULT_MAX_AGENTS = 10_000


# ---------------------------------------------------------------------------
# Bayesian trust math (stdlib only, via math.lgamma)
# ---------------------------------------------------------------------------

def _log_beta(a: float, b: float) -> float:
    """Log of the Beta function: ln(B(a,b)) = lgamma(a) + lgamma(b) - lgamma(a+b)."""
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def _regularized_beta_inc(x: float, a: float, b: float, max_iter: int = 200, tol: float = 1e-12) -> float:
    """Regularized incomplete beta function I_x(a,b) via Lentz continued fraction."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    # Use the symmetry relation for better convergence
    if x > (a + 1.0) / (a + b + 2.0):
        return 1.0 - _regularized_beta_inc(1.0 - x, b, a, max_iter, tol)

    ln_prefix = a * math.log(x) + b * math.log(1.0 - x) - _log_beta(a, b) - math.log(a)

    # Lentz's algorithm for the continued fraction
    f = 1.0
    c = 1.0
    d = 1.0 - (a + b) * x / (a + 1.0)
    if abs(d) < 1e-30:
        d = 1e-30
    d = 1.0 / d
    f = d

    for m in range(1, max_iter + 1):
        # Even step
        numerator = m * (b - m) * x / ((a + 2 * m - 1) * (a + 2 * m))
        d = 1.0 + numerator * d
        if abs(d) < 1e-30:
            d = 1e-30
        d = 1.0 / d
        c = 1.0 + numerator / c
        if abs(c) < 1e-30:
            c = 1e-30
        f *= d * c

        # Odd step
        numerator = -(a + m) * (a + b + m) * x / ((a + 2 * m) * (a + 2 * m + 1))
        d = 1.0 + numerator * d
        if abs(d) < 1e-30:
            d = 1e-30
        d = 1.0 / d
        c = 1.0 + numerator / c
        if abs(c) < 1e-30:
            c = 1e-30
        delta = d * c
        f *= delta

        if abs(delta - 1.0) < tol:
            break

    return math.exp(ln_prefix) * f


def _beta_quantile(p: float, a: float, b: float, max_iter: int = 50, tol: float = 1e-8) -> float:
    """Inverse CDF of Beta(a,b) via Newton's method."""
    if p <= 0.0:
        return 0.0
    if p >= 1.0:
        return 1.0

    # Initial guess using approximation
    x = a / (a + b)
    x = max(0.001, min(0.999, x))

    for _ in range(max_iter):
        cdf = _regularized_beta_inc(x, a, b)
        # PDF of Beta distribution
        ln_pdf = (a - 1.0) * math.log(max(x, 1e-30)) + (b - 1.0) * math.log(max(1.0 - x, 1e-30)) - _log_beta(a, b)
        pdf = math.exp(ln_pdf)
        if pdf < 1e-30:
            break
        x_new = x - (cdf - p) / pdf
        x_new = max(1e-10, min(1.0 - 1e-10, x_new))
        if abs(x_new - x) < tol:
            x = x_new
            break
        x = x_new

    return x


# ---------------------------------------------------------------------------
# Bayesian trust constants
# ---------------------------------------------------------------------------

BAYESIAN_PRIOR_ALPHA = 1.0   # skeptical prior (1 phantom success)
BAYESIAN_PRIOR_BETA = 2.0    # 2 phantom failures
CREDIBLE_INTERVAL = 0.05     # 5th percentile

# Circuit breaker constants
DEMOTION_ROLLING_WINDOW = 10
DEMOTION_ROLLING_THRESHOLD = 0.80
COOLDOWN_BASE_SECONDS = 3600.0  # 1h base cooldown
COOLDOWN_MAX_SECONDS = 86400.0  # 24h cap


class SettlementRecord(BaseModel):
    """Individual settlement outcome with complexity weight."""
    success: bool
    complexity: float = Field(default=0.5, ge=0.1, le=1.0)
    timestamp: float = Field(default_factory=time.time)


class AgentRole(str, Enum):
    """Role types inspired by Gas Town archetypes."""

    ORCHESTRATOR = "orchestrator"  # coordinates workflows (Gas Town: Mayor)
    WORKER = "worker"  # executes tasks (Gas Town: Crew)
    VALIDATOR = "validator"  # verifies settlements (Gas Town: Witness)
    AUDITOR = "auditor"  # shadow audits (Gas Town: Deacon)
    SPECIALIST = "specialist"  # domain expert (Gas Town: Refinery)


class TrustLevel(str, Enum):
    """Trust earned through settlement history."""

    UNTRUSTED = "untrusted"  # new agent, cannot stake
    PROVISIONAL = "provisional"  # can execute, cannot stake alone
    TRUSTED = "trusted"  # full participation
    SENIOR = "senior"  # can orchestrate, reduced verification requirements


# Bayesian trust thresholds: min_volume = evidence required, min_lower_bound = 5th percentile
BAYESIAN_THRESHOLDS: dict[TrustLevel, dict[str, float]] = {
    TrustLevel.PROVISIONAL: {"min_volume": 5, "min_lower_bound": 0.60},
    TrustLevel.TRUSTED: {"min_volume": 20, "min_lower_bound": 0.82},
    TrustLevel.SENIOR: {"min_volume": 100, "min_lower_bound": 0.92},
}


# Role-based default tool access
ROLE_DEFAULT_TOOLS: dict[AgentRole, set[str]] = {
    AgentRole.ORCHESTRATOR: {"settle_action", "check_settlement", "ledger_status"},
    AgentRole.WORKER: {"settle_action", "check_settlement"},
    AgentRole.VALIDATOR: {"check_settlement", "ledger_status"},
    AgentRole.AUDITOR: {"check_settlement", "ledger_status"},
    AgentRole.SPECIALIST: {"settle_action", "check_settlement"},
}

# Minimum trust level required to use each tool
TOOL_TRUST_GATES: dict[str, TrustLevel] = {
    "settle_action": TrustLevel.PROVISIONAL,
    "check_settlement": TrustLevel.UNTRUSTED,
    "ledger_status": TrustLevel.UNTRUSTED,
}


class AgentIdentity(BaseModel):
    """Persistent agent identity with role and trust tracking."""

    agent_id: str
    role: AgentRole = AgentRole.WORKER

    @field_validator("agent_id")
    @classmethod
    def validate_agent_id(cls, v: str) -> str:
        if not AGENT_ID_PATTERN.match(v):
            raise ValueError(
                f"Invalid agent_id '{v}': must be 2-64 chars, alphanumeric start/end, "
                "only [a-zA-Z0-9._-] allowed"
            )
        if v.lower() in RESERVED_AGENT_IDS:
            raise ValueError(f"agent_id '{v}' is reserved")
        return v

    trust_level: TrustLevel = TrustLevel.UNTRUSTED
    capabilities: list[str] = Field(default_factory=list)
    registered_at: float = Field(default_factory=time.time)
    settlements_completed: int = 0
    settlements_failed: int = 0
    last_active: float = Field(default_factory=time.time)
    metadata: dict[str, Any] = Field(default_factory=dict)
    settlement_history: list[SettlementRecord] = Field(default_factory=list)
    divergence_penalty: float = 0.0
    under_review: bool = False

    # Enhanced circuit breaker fields
    last_demotion_at: float | None = None
    demotion_count: int = 0
    cooldown_until: float | None = None

    # MCP tool permission fields
    allowed_tools: list[str] | None = None  # None = use role defaults
    denied_tools: list[str] = Field(default_factory=list)

    @property
    def success_rate(self) -> float:
        total = self.settlements_completed + self.settlements_failed
        if total == 0:
            return 0.0
        return self.settlements_completed / total

    @property
    def reputation_score(self) -> float:
        """Complexity-weighted success rate minus divergence penalty.

        R = sum(S_i * C_i) / sum(C_i) - delta(D)
        """
        if not self.settlement_history:
            return 0.0
        weighted_success = sum(
            r.complexity for r in self.settlement_history if r.success
        )
        total_complexity = sum(r.complexity for r in self.settlement_history)
        if total_complexity == 0:
            return 0.0
        return (weighted_success / total_complexity) - self.divergence_penalty

    @property
    def rolling_success_rate(self) -> float:
        """Success rate over last DEMOTION_ROLLING_WINDOW settlements."""
        recent = self.settlement_history[-DEMOTION_ROLLING_WINDOW:]
        if not recent:
            return 1.0  # No history = no demotion
        return sum(1 for r in recent if r.success) / len(recent)

    @property
    def bayesian_lower_bound(self) -> float:
        """5th percentile of Beta(prior + successes, prior + failures).

        With skeptical prior (alpha=1, beta=2), new agents start pessimistic.
        5/5 gives ~0.55, not enough for PROVISIONAL. 10/10 gives ~0.69.
        100/100 gives ~0.94, enough for SENIOR.
        """
        total = self.settlements_completed + self.settlements_failed
        if total == 0:
            return 0.0
        alpha = BAYESIAN_PRIOR_ALPHA + self.settlements_completed
        beta = BAYESIAN_PRIOR_BETA + self.settlements_failed
        return _beta_quantile(CREDIBLE_INTERVAL, alpha, beta)

    @property
    def is_active(self) -> bool:
        """Agent considered active if seen in last 24 hours."""
        return (time.time() - self.last_active) < 86400

    @property
    def is_in_cooldown(self) -> bool:
        """True if agent is in demotion cooldown (cannot be re-promoted)."""
        if self.cooldown_until is None:
            return False
        return time.time() < self.cooldown_until

    def can_stake(self) -> bool:
        """PROVISIONAL or higher can stake solutions."""
        return self.trust_level in (
            TrustLevel.PROVISIONAL, TrustLevel.TRUSTED, TrustLevel.SENIOR,
        )

    def can_verify(self) -> bool:
        """PROVISIONAL or higher can verify."""
        return self.trust_level != TrustLevel.UNTRUSTED

    def can_merge(self) -> bool:
        """TRUSTED or higher can merge to shared process chains."""
        return self.trust_level in (TrustLevel.TRUSTED, TrustLevel.SENIOR)

    def can_orchestrate(self) -> bool:
        """Only SENIOR orchestrators can orchestrate workflows."""
        return self.trust_level == TrustLevel.SENIOR and self.role == AgentRole.ORCHESTRATOR

    def can_use_tool(self, tool_name: str) -> bool:
        """Check if agent can use a specific MCP tool.

        Checks denied_tools, then allowed_tools (or role defaults), then trust gate.
        """
        if tool_name in self.denied_tools:
            return False
        allowed = self.allowed_tools if self.allowed_tools is not None else ROLE_DEFAULT_TOOLS.get(self.role, set())
        if tool_name not in allowed:
            return False
        required_trust = TOOL_TRUST_GATES.get(tool_name, TrustLevel.UNTRUSTED)
        trust_order = list(TrustLevel)
        return trust_order.index(self.trust_level) >= trust_order.index(required_trust)


class AgentRegistry:
    """Manages agent lifecycle — registration, trust promotion, lookup."""

    def __init__(self, max_agents: int = DEFAULT_MAX_AGENTS) -> None:
        self._agents: dict[str, AgentIdentity] = {}
        self._review_queue: list[str] = []
        self.max_agents = max_agents

    def register(
        self,
        agent_id: str,
        role: AgentRole = AgentRole.WORKER,
        capabilities: list[str] | None = None,
    ) -> AgentIdentity:
        """Register a new agent. Raises if already registered or capacity reached."""
        if agent_id in self._agents:
            raise AgentError(f"Agent {agent_id} already registered.")
        if len(self._agents) >= self.max_agents:
            raise AgentError(
                f"Registry full: {self.max_agents} agents registered."
            )
        identity = AgentIdentity(
            agent_id=agent_id,
            role=role,
            capabilities=capabilities or [],
        )
        self._agents[agent_id] = identity
        return identity

    def get(self, agent_id: str) -> AgentIdentity:
        """Look up an agent by ID. Raises if not found."""
        if agent_id not in self._agents:
            raise AgentError(f"Agent {agent_id} not found.")
        return self._agents[agent_id]

    def record_settlement(
        self, agent_id: str, success: bool, complexity: float = 0.5,
    ) -> AgentIdentity:
        """Record a settlement outcome and auto-promote/demote trust."""
        agent = self.get(agent_id)
        agent.last_active = time.time()
        record = SettlementRecord(success=success, complexity=complexity)
        agent.settlement_history.append(record)
        if success:
            agent.settlements_completed += 1
        else:
            agent.settlements_failed += 1
        agent.trust_level = self._calculate_trust(agent)
        return agent

    def _apply_demotion(self, agent: AgentIdentity, target: TrustLevel) -> TrustLevel:
        """Record demotion metadata: timestamp, count, exponential cooldown."""
        agent.last_demotion_at = time.time()
        agent.demotion_count += 1
        cooldown = min(
            COOLDOWN_BASE_SECONDS * (2 ** (agent.demotion_count - 1)),
            COOLDOWN_MAX_SECONDS,
        )
        agent.cooldown_until = time.time() + cooldown

        # Double-fault escalation: already PROVISIONAL + still failing -> UNTRUSTED + review
        if agent.trust_level == TrustLevel.PROVISIONAL and target == TrustLevel.PROVISIONAL:
            agent.under_review = True
            if agent.agent_id not in self._review_queue:
                self._review_queue.append(agent.agent_id)
            return TrustLevel.UNTRUSTED

        return target

    def _calculate_trust(self, agent: AgentIdentity) -> TrustLevel:
        """Determine trust level using Bayesian credible intervals with circuit breaker.

        Uses Beta(prior + successes, prior + failures) 5th percentile as the
        effective trust score. Divergence penalties compound with demotion count.
        """
        if agent.under_review:
            return TrustLevel.UNTRUSTED

        # Cooldown freezes trust level (blocks both promotion and further demotion)
        if agent.is_in_cooldown:
            return agent.trust_level

        total = agent.settlements_completed + agent.settlements_failed

        # Circuit breaker: rolling window demotion
        if total >= DEMOTION_ROLLING_WINDOW:
            if agent.rolling_success_rate < DEMOTION_ROLLING_THRESHOLD:
                # Don't "promote" via demotion if already below target
                if agent.trust_level == TrustLevel.UNTRUSTED:
                    return TrustLevel.UNTRUSTED
                return self._apply_demotion(agent, TrustLevel.PROVISIONAL)

        # Compute effective Bayesian bound with divergence penalty
        div_penalty = agent.divergence_penalty * (1.0 + 0.5 * agent.demotion_count)
        effective_bound = agent.bayesian_lower_bound - div_penalty

        # Promotion checks (highest first)
        thresholds = BAYESIAN_THRESHOLDS
        if (
            total >= thresholds[TrustLevel.SENIOR]["min_volume"]
            and effective_bound >= thresholds[TrustLevel.SENIOR]["min_lower_bound"]
        ):
            return TrustLevel.SENIOR

        if (
            total >= thresholds[TrustLevel.TRUSTED]["min_volume"]
            and effective_bound >= thresholds[TrustLevel.TRUSTED]["min_lower_bound"]
        ):
            return TrustLevel.TRUSTED

        if (
            total >= thresholds[TrustLevel.PROVISIONAL]["min_volume"]
            and effective_bound >= thresholds[TrustLevel.PROVISIONAL]["min_lower_bound"]
        ):
            return TrustLevel.PROVISIONAL

        return TrustLevel.UNTRUSTED

    def find_by_role(self, role: AgentRole) -> list[AgentIdentity]:
        """Find all agents with a given role."""
        return [a for a in self._agents.values() if a.role == role]

    def find_by_trust(self, min_trust: TrustLevel) -> list[AgentIdentity]:
        """Find agents at or above a trust level."""
        levels = list(TrustLevel)
        min_idx = levels.index(min_trust)
        return [a for a in self._agents.values() if levels.index(a.trust_level) >= min_idx]

    def active_agents(self) -> list[AgentIdentity]:
        """Return all currently active agents."""
        return [a for a in self._agents.values() if a.is_active]

    def revoke(self, agent_id: str) -> None:
        """Remove an agent from the registry."""
        if agent_id not in self._agents:
            raise AgentError(f"Agent {agent_id} not found.")
        del self._agents[agent_id]

    def record_divergence(
        self, agent_id: str, penalty: float = 0.1, critical: bool = False,
    ) -> AgentIdentity:
        """Record a divergence event. Critical divergence revokes identity."""
        agent = self.get(agent_id)
        agent.divergence_penalty += penalty
        if critical:
            agent.under_review = True
            if agent_id not in self._review_queue:
                self._review_queue.append(agent_id)
            agent.trust_level = TrustLevel.UNTRUSTED
        else:
            agent.trust_level = self._calculate_trust(agent)
        return agent

    @property
    def review_queue(self) -> list[str]:
        """Agent IDs under review for critical divergence."""
        return list(self._review_queue)

    def reinstate(self, agent_id: str) -> AgentIdentity:
        """Reinstate an agent from review, resetting to UNTRUSTED."""
        agent = self.get(agent_id)
        if not agent.under_review:
            raise AgentError(f"Agent {agent_id} is not under review.")
        agent.under_review = False
        agent.divergence_penalty = 0.0
        if agent_id in self._review_queue:
            self._review_queue.remove(agent_id)
        agent.trust_level = self._calculate_trust(agent)
        return agent

    @property
    def count(self) -> int:
        return len(self._agents)


class PersistentAgentRegistry(AgentRegistry):
    """AgentRegistry backed by an append-only JSONL event log.

    Every mutation (register, settlement, divergence, reinstate, revoke)
    appends an event to registry.jsonl. On init, replays the log to
    rebuild in-memory state. The settlement ledger stays untouched.
    """

    def __init__(self, path: str | Path = "registry.jsonl", max_agents: int = DEFAULT_MAX_AGENTS) -> None:
        super().__init__(max_agents=max_agents)
        self.path = Path(path)
        self._logger = logging.getLogger("swarm_at.agents.persistent")
        self._replay()

    def _append_event(self, event: dict[str, Any]) -> None:
        """Append a single event to the log file."""
        with open(self.path, "a") as f:
            f.write(json.dumps(event, default=str) + "\n")

    def _replay(self) -> None:
        """Rebuild in-memory state from the event log."""
        if not self.path.exists():
            return
        count = 0
        for line in self.path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
                self._apply_event(event)
                count += 1
            except (json.JSONDecodeError, KeyError, AgentError) as exc:
                self._logger.warning("Skipping bad event: %s (%s)", line[:100], exc)
        self._logger.info("Replayed %d events from %s", count, self.path)

    def _apply_event(self, event: dict[str, Any]) -> None:
        """Apply a single event to the in-memory registry (no disk write)."""
        kind = event["event"]
        if kind == "register":
            super().register(
                agent_id=event["agent_id"],
                role=AgentRole(event.get("role", "worker")),
                capabilities=event.get("capabilities", []),
            )
        elif kind == "settlement":
            super().record_settlement(
                agent_id=event["agent_id"],
                success=event["success"],
                complexity=event.get("complexity", 0.5),
            )
        elif kind == "divergence":
            super().record_divergence(
                agent_id=event["agent_id"],
                penalty=event.get("penalty", 0.1),
                critical=event.get("critical", False),
            )
        elif kind == "reinstate":
            super().reinstate(event["agent_id"])
        elif kind == "revoke":
            super().revoke(event["agent_id"])
        else:
            self._logger.warning("Unknown event type: %s", kind)

    def register(
        self,
        agent_id: str,
        role: AgentRole = AgentRole.WORKER,
        capabilities: list[str] | None = None,
    ) -> AgentIdentity:
        result = super().register(agent_id, role=role, capabilities=capabilities)
        self._append_event({
            "event": "register",
            "agent_id": agent_id,
            "role": role.value,
            "capabilities": capabilities or [],
            "timestamp": time.time(),
        })
        return result

    def record_settlement(
        self, agent_id: str, success: bool, complexity: float = 0.5,
    ) -> AgentIdentity:
        result = super().record_settlement(agent_id, success=success, complexity=complexity)
        self._append_event({
            "event": "settlement",
            "agent_id": agent_id,
            "success": success,
            "complexity": complexity,
            "timestamp": time.time(),
        })
        return result

    def record_divergence(
        self, agent_id: str, penalty: float = 0.1, critical: bool = False,
    ) -> AgentIdentity:
        result = super().record_divergence(agent_id, penalty=penalty, critical=critical)
        self._append_event({
            "event": "divergence",
            "agent_id": agent_id,
            "penalty": penalty,
            "critical": critical,
            "timestamp": time.time(),
        })
        return result

    def reinstate(self, agent_id: str) -> AgentIdentity:
        result = super().reinstate(agent_id)
        self._append_event({
            "event": "reinstate",
            "agent_id": agent_id,
            "timestamp": time.time(),
        })
        return result

    def revoke(self, agent_id: str) -> None:
        super().revoke(agent_id)
        self._append_event({
            "event": "revoke",
            "agent_id": agent_id,
            "timestamp": time.time(),
        })


class AgentError(Exception):
    pass
