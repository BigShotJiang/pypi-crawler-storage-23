"""Context Injector: prunes Shared State into task-specific slices."""

from __future__ import annotations

from typing import Any


def get_context_slice(
    state: dict[str, Any],
    query_keywords: list[str],
    always_include: list[str] | None = None,
) -> dict[str, Any]:
    """Extract relevant institutional memory for a stateless agent.

    Filters the full shared state down to entries matching the query keywords,
    plus any keys in `always_include` (defaults to ["core_logic"]).
    """
    include_keys = set(always_include or ["core_logic"])
    include_keys.update(query_keywords)
    return {k: v for k, v in state.items() if k in include_keys}
