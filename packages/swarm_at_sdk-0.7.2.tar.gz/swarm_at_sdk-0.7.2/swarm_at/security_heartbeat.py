"""Security Heartbeat: verification gate for local agent state."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path

from swarm_at.agents import AgentRegistry
from swarm_at.engine import SwarmAtEngine
from swarm_at.models import AgentMetadata, Header, Payload, Proposal

logger = logging.getLogger("swarm_at.security_heartbeat")


class StateSnapshot:
    """Snapshot of local agent state files for verification."""

    def __init__(self, files: dict[str, str], agent_id: str) -> None:
        self.files = files  # filename -> content
        self.agent_id = agent_id
        self.file_hashes = {
            name: hashlib.sha256(content.encode()).hexdigest()
            for name, content in files.items()
        }

    @classmethod
    def from_paths(cls, paths: list[Path], agent_id: str) -> "StateSnapshot":
        """Read files from disk into a snapshot."""
        files: dict[str, str] = {}
        for p in paths:
            if p.exists():
                files[p.name] = p.read_text()
            else:
                files[p.name] = ""
        return cls(files=files, agent_id=agent_id)

    @property
    def combined_hash(self) -> str:
        """Single hash representing all monitored files."""
        raw = json.dumps(self.file_hashes, sort_keys=True).encode()
        return hashlib.sha256(raw).hexdigest()


class VerificationGate:
    """Verification gate: agents must stake() their state to the ledger on wake.

    If local state deviates from the ledger's source of truth,
    triggers AUDITOR role to freeze the process.
    """

    def __init__(
        self,
        engine: SwarmAtEngine,
        registry: AgentRegistry,
        monitored_files: list[Path] | None = None,
    ) -> None:
        self.engine = engine
        self.registry = registry
        self.monitored_files = monitored_files or []
        self._last_verified_hash: str = ""

    def stake_on_wake(self, agent_id: str) -> VerificationResult:
        """Agent stakes its current state to the ledger on wake-up.

        Returns VerificationResult with pass/fail and details.
        """
        agent = self.registry.get(agent_id)

        # Build snapshot of monitored files
        snapshot = StateSnapshot.from_paths(self.monitored_files, agent_id)

        # Verify against ledger: check if last entry for this agent matches
        ledger_state = self._get_last_agent_state(agent_id)

        if ledger_state and ledger_state != snapshot.combined_hash:
            # State deviation detected — trigger audit
            logger.warning(
                "State deviation for %s: local=%s ledger=%s",
                agent_id, snapshot.combined_hash[:16], ledger_state[:16],
            )
            self.registry.record_divergence(agent_id, penalty=0.05, critical=False)
            return VerificationResult(
                passed=False,
                agent_id=agent_id,
                reason="Local state deviates from ledger source of truth",
                local_hash=snapshot.combined_hash,
                ledger_hash=ledger_state,
            )

        # State matches or first wake — settle the snapshot
        parent_hash = self.engine.ledger.get_latest_hash()
        proposal = Proposal(
            header=Header(
                task_id=f"heartbeat-{agent_id}",
                parent_hash=parent_hash,
                agent_metadata=AgentMetadata(model=agent_id, version="security-heartbeat"),
            ),
            payload=Payload(
                data_update={
                    "type": "security_heartbeat",
                    "agent_id": agent_id,
                    "state_hash": snapshot.combined_hash,
                    "file_hashes": snapshot.file_hashes,
                    "trust_level": agent.trust_level.value,
                },
                confidence_score=1.0,
            ),
        )

        result = self.engine.verify_and_settle(proposal)
        self._last_verified_hash = snapshot.combined_hash

        return VerificationResult(
            passed=result.status.value == "SETTLED",
            agent_id=agent_id,
            reason=result.reason or "",
            local_hash=snapshot.combined_hash,
            ledger_hash=parent_hash,
            settlement_hash=result.hash,
        )

    def freeze_agent(self, agent_id: str, reason: str) -> None:
        """Freeze an agent by recording critical divergence."""
        logger.warning("Freezing agent %s: %s", agent_id, reason)
        self.registry.record_divergence(agent_id, penalty=0.5, critical=True)

    def verify_continuous(self, agent_id: str) -> VerificationResult:
        """Continuous verification check (called periodically, not just on wake)."""
        snapshot = StateSnapshot.from_paths(self.monitored_files, agent_id)

        if self._last_verified_hash and snapshot.combined_hash != self._last_verified_hash:
            # State changed since last verification
            self.registry.record_divergence(agent_id, penalty=0.05, critical=False)
            return VerificationResult(
                passed=False,
                agent_id=agent_id,
                reason="State changed since last verification",
                local_hash=snapshot.combined_hash,
                ledger_hash=self._last_verified_hash,
            )

        return VerificationResult(
            passed=True,
            agent_id=agent_id,
            local_hash=snapshot.combined_hash,
            ledger_hash=self._last_verified_hash or "",
        )

    def _get_last_agent_state(self, agent_id: str) -> str:
        """Find the most recent state_hash for this agent in the ledger."""
        entries = self.engine.ledger.read_all()
        for entry in reversed(entries):
            payload = entry.payload
            if (
                payload.get("type") == "security_heartbeat"
                and payload.get("agent_id") == agent_id
            ):
                return str(payload.get("state_hash", ""))
        return ""


class VerificationResult:
    """Result of a verification gate check."""

    def __init__(
        self,
        passed: bool,
        agent_id: str,
        reason: str = "",
        local_hash: str = "",
        ledger_hash: str = "",
        settlement_hash: str | None = None,
    ) -> None:
        self.passed = passed
        self.agent_id = agent_id
        self.reason = reason
        self.local_hash = local_hash
        self.ledger_hash = ledger_hash
        self.settlement_hash = settlement_hash
