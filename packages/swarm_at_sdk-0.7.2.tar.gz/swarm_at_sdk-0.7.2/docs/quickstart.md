# Quickstart

Get from zero to a verified settlement in 5 minutes.

**What you'll build:** A local hash-chained ledger that records agent actions, then verify the chain is intact.

**Prerequisites:** Python 3.10+

## 1. Install

```bash
pip install swarm-at-sdk[cli]
```

This gives you the `swarm` CLI and the Python SDK.

## 2. Initialize a project

```bash
swarm init my-project
cd my-project
```

This creates three starter files: `.env.example`, `AGENTS.md`, and `settle_example.py`.

## 3. Settle your first action

```bash
swarm settle "reviewed PR #42" --agent my-agent
```

Output:

```
status: SETTLED
hash: a1b2c3d4e5f6...  (64-char SHA-256)
```

The CLI created a `ledger.jsonl` file in your working directory. That file is your hash-chained settlement ledger. Every entry links to the previous one via `parent_hash`, forming a tamper-evident chain.

## 4. Check ledger status

```bash
swarm status
```

Output:

```
mode: local
ledger_path: ledger.jsonl
latest_hash: a1b2c3d4e5f6...
chain_intact: True
entry_count: 1
```

`chain_intact: True` means every entry's hash links correctly to its parent. If anyone tampers with the file, verification fails.

## 5. List ledger entries

```bash
swarm ledger list
```

Output:

```
Showing 1 of 1 entries (offset=0)
  a1b2c3d4e5f6...  <task-id>                 1709123456.789
```

Add `--json` for machine-readable output:

```bash
swarm ledger list --json
```

## 6. Verify a specific hash

Copy the hash from step 3 and verify it exists in the ledger:

```bash
swarm ledger verify a1b2c3d4e5f6...
```

Output:

```
found: True
hash: a1b2c3d4e5f6...
task_id: <uuid>
timestamp: 1709123456.789
parent_hash: 0000000000000000000000000000000000000000000000000000000000000000
```

The `parent_hash` of all zeros is the genesis hash -- the root of the chain.

## 7. Register an agent

```bash
swarm agents register my-agent --role worker
```

This creates a persistent agent identity with a trust level that grows as the agent completes more settlements.

## 8. Use the Python SDK

The same operations work from Python code. Create a file called `settle_demo.py`:

```python
from swarm_at import SettlementContext

ctx = SettlementContext()
result = ctx.settle(agent="my-agent", task="analyzed data", confidence=0.95)

print(f"Status: {result.status.value}")  # SETTLED
print(f"Hash:   {result.hash}")          # 64-char SHA-256
```

Run it:

```bash
python settle_demo.py
```

The SDK writes to the same `ledger.jsonl` file. You can verify the new entry with `swarm status` and see `entry_count` has increased.

For a one-liner without managing context:

```python
from swarm_at import settle

result = settle(agent="my-agent", task="processed invoice")
print(result.hash)
```

## 9. Connect to a remote API

Local mode is the default. To settle against the hosted API at `api.swarm.at`:

```bash
swarm login
```

This prompts for the API URL and key, then saves credentials to `~/.swarm/config.toml`.

After login, all commands automatically use the remote API:

```bash
swarm settle "reviewed PR #42" --agent my-agent
swarm status
swarm ledger list
```

You can also set the mode per-command:

```bash
# Force remote
swarm --api-url https://api.swarm.at --api-key sk-... settle "reviewed PR #42" --agent my-agent

# Force local (even if config exists)
swarm --local settle "reviewed PR #42" --agent my-agent
```

The Python SDK works the same way:

```python
from swarm_at import SettlementContext

ctx = SettlementContext(api_url="https://api.swarm.at", api_key="sk-...")
result = ctx.settle(agent="my-agent", task="analyzed data", confidence=0.95)
```

Or set `SWARM_API_URL` and `SWARM_API_KEY` environment variables and both the CLI and SDK pick them up automatically.

## What you just learned

- **Settlements** are immutable, hash-chained records of agent actions
- **Local mode** writes directly to a JSONL file -- no server needed
- **Remote mode** connects to the hosted API for multi-agent collaboration
- The **CLI** and **Python SDK** share the same underlying engine

## Next steps

- [Framework Adapters](adapters.md) -- plug settlement into LangGraph, CrewAI, AutoGen, OpenAI Agents, and more
- [Settlement Types](settlement-types.md) -- 75 canonical types for classifying agent actions
- [Technical Specification](SPEC.md) -- the full protocol design
