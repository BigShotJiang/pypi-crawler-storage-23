# swarm.at Technical Specification

**Version:** 1.0.0
**Domain:** swarm.at
**Subtitle:** Swarm-as-a-Service (SaaS) Information Settlement Protocol

---

## 1. Overview

swarm.at is a stateless Swarm-as-a-Service platform that acts as the deterministic clearing house for collaborative AI agents. It decouples **Representation** (the logic an agent performs) from **Collaboration** (the settlement on a shared task).

Agents produce probabilistic output. swarm.at turns that output into a deterministic, auditable record. The platform provides the institutional integrity layer that makes autonomous agents production-ready for enterprise use.

**Core metaphor:** Intelligence is ephemeral. Settlement is permanent.

---

## 2. System Primitives

**Statelessness:** No agent maintains a session. Each interaction is a pure function: `(Context + Task) = Proposal`. Every call must include a `Context_Slice` and a `Parent_Hash`.

**Determinism:** Any operation that updates Shared State must be verified against the Institutional Logic schema.

**Immutability:** Once a task is settled, its record cannot be altered. `Current_Hash` must always link to `Parent_Hash`.

**Institutional DNA:** Rules (brand voice, budget limits, factual cutoffs) are stored in a schema external to the agents. Agents receive read-only slices.

**Thrift:** Minimize dependencies. Use Python 3.10+ standard libraries unless an external library reduces complexity by >50%.

---

## 3. Architecture

The system follows a **Triage-Execute-Settle** pattern across five layers.

### 3.1 Layer Overview

| Layer | Component | Responsibility | Implementation |
|-------|-----------|---------------|----------------|
| Ingress | Context Injector | Prunes Shared State into a task-specific slice | Semantic search or keyword filtering |
| Execution | Dispatcher | Routes tasks by complexity to cheapest capable model | Python/FastAPI + Model Arbitrage |
| Execution | Executor | Stateless agent performing the work | Disposable API calls (Anthropic/OpenAI) |
| Verification | Shadow Auditor | Cross-model divergence checks to detect hallucinations | Secondary model comparison |
| Settlement | Settler | Commits verified work to the Ledger | Hash-chaining + flat-file append |
| Public | Verification Portal | UI for auditing transaction hashes | GitHub Pages |

### 3.2 Data Flow

```
User defines goal
  -> Dispatcher evaluates complexity (0.0-1.0), selects model tier
    -> Context Injector prunes Shared State into task-specific slice
      -> Executor (stateless agent) receives slice + task, produces Proposal
        -> Shadow Auditor runs secondary check (optional, for high-risk/random)
          -> Settler verifies hash-chain + confidence + divergence
            -> SETTLED (ledger append) | REJECTED (re-base) | ESCROWED (high divergence)
```

---

## 4. Data Model

### 4.1 Proposal Schema

The unit of work submitted by an agent for settlement.

```json
{
  "header": {
    "task_id": "UUID",
    "parent_hash": "SHA-256 (64 hex chars)",
    "agent_metadata": {
      "model": "string",
      "version": "string"
    }
  },
  "payload": {
    "data_update": {},
    "confidence_score": 0.0
  },
  "proof": "Optional trace of reasoning"
}
```

### 4.2 Ledger Entry Schema

Each settled transaction appended to the JSONL ledger.

```json
{
  "timestamp": 1234567890.123,
  "task_id": "UUID",
  "parent_hash": "SHA-256",
  "payload": {},
  "current_hash": "SHA-256"
}
```

### 4.3 Institutional Rules Schema

Configurable rules governing settlement behavior.

```json
{
  "min_confidence": 0.85,
  "max_drift_allowed": 0.15
}
```

### 4.4 Ledger Format

- **Format:** Append-only `.jsonl` (one JSON object per line)
- **Integrity:** SHA-256 hash-chaining of all state transitions
- **Security:** Write-access restricted to the Settlement Engine; agents receive read-only slices
- **Genesis:** Empty ledger starts with parent hash `"0" * 64`

---

## 5. Settlement Engine

The core logic governing the transition from execution to finality.

### 5.1 Settlement Statuses

| Status | Meaning |
|--------|---------|
| `SETTLED` | Proposal verified and committed to ledger |
| `REJECTED` | Failed verification (state drift, low confidence) |
| `ESCROWED` | High model divergence; held for manual review |

### 5.2 Verification Steps

The `verify_and_settle()` method executes these checks in order:

1. **Integrity Check:** `proposal.parent_hash == ledger.latest_hash`. Reject on mismatch ("State drift detected. Re-base required.").
2. **Logic Check:** `proposal.confidence_score >= institutional_rules.min_confidence`. Reject if below threshold.
3. **Shadow Audit (optional):** If a shadow proposal exists, calculate divergence. Escrow if `divergence > max_drift_allowed`.
4. **Finality:** Construct ledger entry, compute `current_hash = SHA-256(entry)`, append to ledger.

### 5.3 Hash Generation

```python
SHA-256(json.dumps(content, sort_keys=True).encode())
```

Deterministic: sorted keys ensure consistent hashing regardless of insertion order.

---

## 6. Components

### 6.1 Dispatcher (Model Arbitrage)

Evaluates task complexity on a 0.0-1.0 scale and selects the lowest-cost API tier capable of the task.

| Tier | Complexity Range | Use Case |
|------|-----------------|----------|
| Thrifty | 0.0 - 0.3 | Simple lookups, formatting |
| Standard | 0.3 - 0.7 | Research, analysis |
| Premium | 0.7 - 1.0 | Complex reasoning, multi-step |

**Goal:** Drop agent OpEx by 40-60% through intelligent routing.

### 6.2 Context Injector (Semantic Pruning)

Extracts relevant institutional memory for a stateless agent. Takes the full Shared State and a set of query keywords, returns only the matching subset plus `core_logic`.

```python
def get_context_slice(state, query_keywords):
    return {k: v for k, v in state.items()
            if k in query_keywords or k == "core_logic"}
```

**Problem solved:** Passing a 100k-token "brain" to every agent call is expensive. The Context Injector ensures agents run leaner, faster, and cheaper.

### 6.3 Shadow Auditor (Divergence Engine)

Runs a secondary, low-cost model check and compares outputs against the primary agent's proposal.

- **Basic divergence:** Binary (payloads match or don't)
- **Extended divergence:** Structural diff, optional NLP similarity scoring
- **Threshold:** Configurable via `max_drift_allowed` (default 0.15)
- **Outcome:** If models disagree beyond threshold, status is `ESCROWED` (flagged before hitting ledger)

**SDK interface:** Provided as a decorator (`@shadow_audit`) that wraps agent functions.

### 6.4 Settler (Ledger Operations)

Manages the append-only JSONL ledger.

- `get_latest_hash()` — Read last entry's `current_hash`
- `append_entry(entry)` — Write new entry to ledger
- `verify_chain()` — Walk the full ledger and verify every hash link

---

## 7. API Specification

**Framework:** FastAPI
**Base URL:** `https://api.swarm.at`
**Auth:** Bearer token (`Authorization: Bearer $SWARM_AT_KEY`)

### 7.1 Endpoints

#### `POST /v1/settle`

Submit a proposal for settlement.

**Request body:** Proposal schema (section 4.1)

**Response:**
```json
{"status": "SETTLED", "hash": "abc123..."}
// or
{"status": "REJECTED", "reason": "State drift detected. Re-base required."}
// or
{"status": "ESCROWED", "reason": "High model divergence."}
```

#### `GET /v1/context?keywords=key1,key2`

Get a context slice for a task.

**Response:** Pruned subset of Shared State.

#### `GET /v1/status/{task_id}`

Check settlement status of a specific task.

#### `GET /v1/ledger/latest`

Get the latest settled hash.

#### `GET /v1/ledger/verify`

Verify full ledger integrity (hash-chain unbroken).

#### `GET /v1/whoami?agent_id=...`

Agent self-check: returns trust level, allowed tools, promotion path. Requires auth.

#### `POST /v1/agents/register`

Register a new agent identity. Body: `{"agent_id": "...", "role": "worker", "capabilities": []}`. Requires auth.

#### `GET /public/blueprints?tag=...&page=1&page_size=50`

List available workflow blueprints. Public, no auth required. Supports tag filtering and pagination.

#### `GET /public/blueprints/{blueprint_id}`

Full blueprint detail including steps, credit cost, and fork count. Public, no auth required.

#### `GET /llms.txt`

LLM-readable protocol summary (text/plain). Follows the llms.txt v1.1.0 convention.

#### `GET /robots.txt`

Crawler guidance referencing `/llms.txt`.

#### `GET /.well-known/agent-card.json`

A2A agent-to-agent discovery card (JSON). Contains name, description, skills, and serviceUrl.

#### `GET /.well-known/openapi.json`

Enriched OpenAPI 3.1 spec with servers, tags, and examples.

#### `GET /v1/credits/{agent_id}`

Check agent credit balance. Requires auth.

**Response:**
```json
{"agent_id": "...", "balance": 42.5}
```

#### `POST /v1/credits/{agent_id}/topup`

Add credits to agent account. Requires auth.

**Request body:**
```json
{"amount": 10.0}
```

**Response:**
```json
{"agent_id": "...", "balance": 52.5}
```

#### `POST /v1/blueprints/{blueprint_id}/fork`

Fork blueprint into executable molecule. Requires auth.

**Query params:**
- `agent_id` (string): Agent fork owner (default: "anonymous")

**Response:**
```json
{
  "molecule_id": "...",
  "name": "...",
  "bead_count": 3,
  "metadata": {...}
}
```

#### `POST /v1/auth/token`

Issue JWT token for agent. Public endpoint.

**Request body:**
```json
{"agent_id": "...", "role": "worker"}
```

**Response:**
```json
{"token": "eyJhb...", "agent_id": "...", "role": "worker"}
```

#### `GET /v1/ledger/mode`

Report ledger backend status. Public endpoint.

**Response:**
```json
{"mode": "file", "backend": "JSONL", "path": "/tmp/ledger.jsonl"}
```

---

## 8. MCP Settlement Server

An MCP (Model Context Protocol) server that acts as a gatekeeper for high-risk agent actions.

**Server name:** `swarm-at-mcp`
**Installation:** `mcp add swarm-at --protocol-key [YOUR_KEY]`

### 8.1 Tools Exposed

#### `settle_action`

Validates a proposed action against Institutional DNA before allowing execution. Used for high-risk operations (terminal commands, file writes, payments, deletions).

**Input:** Action description, context, parent_hash
**Output:** `{"proceed": true/false, "reason": "...", "settlement_token": "..."}`

#### `check_settlement`

Query ledger status for a given task or hash.

#### `list_blueprints`

List available workflow blueprints with optional tag filter.

**Input:** `tag` (optional string)
**Output:** JSON array of blueprints with `blueprint_id`, `name`, `tags`, `step_count`, `credit_cost`

#### `get_blueprint`

Get full blueprint details including steps, credit cost, and fork count.

**Input:** `blueprint_id` (string)
**Output:** Full blueprint JSON with steps array

#### `get_credits`

Fetch agent credit balance.

**Input:** `agent_id` (string)
**Output:** `{"agent_id": "...", "balance": 42.5}`

#### `topup_credits`

Add credits to agent account.

**Input:** `agent_id` (string), `amount` (float)
**Output:** `{"agent_id": "...", "balance": 52.5}`

#### `fork_blueprint`

Fork blueprint into executable molecule.

**Input:** `blueprint_id` (string), `agent_id` (string, optional)
**Output:** `{"molecule_id": "...", "name": "...", "bead_count": 3, "metadata": {...}}`

### 8.2 Safety Model

Before an agent runs a destructive command (e.g., `rm -rf`), it requests a Settlement Token from the MCP server. If the command violates Institutional DNA, the token is denied.

---

## 9. Python SDK

Drop-in library for agent builders.

### 9.1 Client API

```python
from swarm_at import SwarmClient

client = SwarmClient(api_url="https://api.swarm.at", api_key="sk-...")

# Submit and settle a proposal
result = client.settle(proposal)

# Get pruned context for a task
context = client.context_slice(state, keywords=["topic_a", "topic_b"])

# Decorator for cross-model verification
@client.shadow_audit(shadow_model="haiku")
def research_task(context):
    return agent.run(context)
```

### 9.2 Methods

| Method | Description |
|--------|-------------|
| `settle(proposal)` | Submit proposal, return settlement result |
| `context_slice(state, keywords)` | Get pruned context slice |
| `shadow_audit(shadow_model)` | Decorator triggering cross-model verification |
| `list_blueprints(tag, page, page_size)` | List blueprints with optional filtering |
| `get_blueprint(blueprint_id)` | Get full blueprint detail with steps |
| `whoami(agent_id)` | Agent self-check: trust level, permissions, promotion path |
| `register_agent(agent_id, role, capabilities)` | Register a new agent identity |
| `get_credits(agent_id)` | Fetch agent credit balance |
| `topup_credits(agent_id, amount)` | Add credits to agent account |
| `fork_blueprint(blueprint_id, agent_id)` | Fork blueprint into executable molecule |
| `create_token(agent_id, role)` | Exchange credentials for JWT token |

### 9.3 One-Liner Public API

For the simplest integration, use the module-level `settle()` function:

```python
from swarm_at import settle

result = settle(agent="my-agent", task="research", data={"findings": "..."})
```

Or use `SettlementContext` for stateful chaining:

```python
from swarm_at import SettlementContext

ctx = SettlementContext()
r1 = ctx.settle(agent="agent-a", task="step-1")
r2 = ctx.settle(agent="agent-a", task="step-2")  # auto-chains parent hash
```

Remote mode activates automatically when `SWARM_API_URL` is set.

---

## 9A. Settlement Tiers

Graduated adoption tiers allow agents to start safely and grow into full settlement.

| Tier | `SWARM_TIER` | Behavior |
|------|-------------|----------|
| **SANDBOX** | `sandbox` | Log-only. No ledger writes. Returns deterministic synthetic hashes. |
| **STAGING** | `staging` | Writes to ledger. Skips hash-chain enforcement. Enforces confidence. |
| **PRODUCTION** | `production` | Full verification: chain integrity + confidence + shadow audit. Default. |

```bash
export SWARM_TIER=sandbox
```

Each tier is governed by a `TierPolicy` with four flags: `enforce_chain`, `enforce_confidence`, `write_ledger`, `log_only`.

---

## 9B. Framework Adapters

First-class adapters for the major agent frameworks. No framework imports required by the adapters -- they use `getattr` on duck-typed objects.

### LangGraph

```python
from swarm_at.adapters.langgraph import SwarmNodeWrapper

wrapper = SwarmNodeWrapper(agent="research-agent")

@wrapper.wrap
def research_node(state):
    return {"findings": "..."}
```

### AutoGen

```python
from swarm_at.adapters.autogen import SwarmReplyCallback

callback = SwarmReplyCallback()
agent.register_reply([autogen.Agent], callback.on_reply)
```

Returns `(False, None)` -- pure observer, does not interfere with AutoGen's reply chain.

### CrewAI

```python
from swarm_at.adapters.crewai import SwarmTaskCallback

callback = SwarmTaskCallback()
crew = Crew(agents=[...], tasks=[...], task_callback=callback.on_task_complete)
```

### OpenAI Assistants

```python
from swarm_at.adapters.openai_assistants import SwarmRunHandler

handler = SwarmRunHandler(assistant_id="asst_abc123")
handler.settle_run(run, messages)    # Run -> Molecule
handler.settle_step("tool_calls", step_data)  # RunStep -> Bead
```

### Install

```bash
pip install swarm-at[langgraph]   # LangGraph adapter
pip install swarm-at[autogen]     # AutoGen adapter
pip install swarm-at[crewai]      # CrewAI adapter
pip install swarm-at[openai]      # OpenAI Assistants adapter
pip install swarm-at[all]         # All adapters + MCP
```

---

## 9C. Protocol Schema Endpoint

Machine-readable endpoint for agent discovery:

```
GET /public/schema
```

Returns:
- `protocol`: "swarm.at"
- `version`: "0.1.0"
- `schemas`: JSON schemas for `Proposal`, `SettlementResult`, `SettleRequest`
- `guarantees`: determinism, idempotency, chain_integrity, trust_scoring
- `tiers`: policy details for sandbox/staging/production

No authentication required.

---

## 9E. Credit System

Per-agent metering layer for resource allocation and cost control.

### Concept

Each agent maintains a credit balance (default 100.0 credits). Blueprints carry a `credit_cost` field. When an agent forks a blueprint or settles a proposal, the cost is deducted from their balance. Credits can be topped up via API.

### Credit Ledger

- **Storage:** In-memory or persistent per-agent record
- **Operations:** `balance(agent_id)`, `topup(agent_id, amount)`, `debit(agent_id, amount)`
- **Default balance:** 100.0 credits per new agent
- **Topup:** No limit, allowed only via API with auth

### Blueprint Cost Enforcement

When forking a blueprint, cost is validated:
1. Agent balance checked against blueprint `credit_cost`
2. If insufficient, returns 402 (Payment Required)
3. If sufficient, debit is applied immediately
4. Cost is recorded in ledger for audit

### Endpoints

**GET /v1/credits/{agent_id}** (auth required)

Check balance. Returns `{"agent_id": "...", "balance": 42.5}`.

**POST /v1/credits/{agent_id}/topup** (auth required)

Add credits. Body: `{"amount": 10.0}`. Returns `{"agent_id": "...", "balance": 52.5}`.

Error on negative/zero amount (400).

### Environment

| Variable | Default | Purpose |
|----------|---------|---------|
| `SWARM_DEFAULT_CREDITS` | `100.0` | Initial balance for new agents |
| `SWARM_CREDIT_LEDGER` | `in-memory` | Storage backend (file, redis, dynamodb) |

---

## 9F. JWT Authentication

Token-based auth for stateless agent identification and role enforcement.

### Concept

Complements API key auth. Agents exchange credentials for a signed JWT token via `/v1/auth/token`. Token contains agent identity, role, issued time, and expiration. Enables per-agent role-based access control (RBAC) without maintaining session state.

### Token Format

**Algorithm:** HS256 (HMAC-SHA256)

**Payload:**
- `sub` (string): agent_id
- `role` (string): agent role (worker, orchestrator, etc.)
- `iat` (int): issued at (Unix timestamp)
- `exp` (int): expiration (Unix timestamp, default 1 hour)

**Example decoded:**
```json
{
  "sub": "my-agent",
  "role": "worker",
  "iat": 1234567890,
  "exp": 1234571490
}
```

### Dual Auth

The API supports both mechanisms:
1. **Bearer API key:** Traditional static token (SWARM_API_KEYS env var)
2. **JWT:** Dynamic token issued per request (SWARM_JWT_SECRET env var)

Request uses `Authorization: Bearer <token>`. Server validates first as API key, falls back to JWT decode.

### Endpoints

**POST /v1/auth/token** (public)

Issue token. Body: `{"agent_id": "my-agent", "role": "worker"}`. Returns `{"token": "eyJhb...", "agent_id": "my-agent", "role": "worker"}`.

Returns 501 if `SWARM_JWT_SECRET` not configured.

### Environment

| Variable | Default | Purpose |
|----------|---------|---------|
| `SWARM_JWT_SECRET` | (unset) | HS256 signing key; if unset, JWT auth disabled |
| `SWARM_JWT_EXPIRY` | `3600` | Token lifetime (seconds) |

### Error Cases

- 501: JWT auth not configured (SWARM_JWT_SECRET missing)
- 401: Malformed/missing authorization header
- 403: Invalid API key or JWT signature

---

## 9G. OpenClaw Discovery Protocol

Makes swarm.at discoverable by LLMs, web crawlers, and agent-to-agent frameworks. All discovery endpoints are public (no auth required).

### Discovery Endpoints

| Path | Content-Type | Purpose |
|------|-------------|---------|
| `/llms.txt` | `text/plain` | LLM-readable protocol summary (llms.txt v1.1.0) |
| `/robots.txt` | `text/plain` | Crawler guidance, references `/llms.txt` |
| `/.well-known/agent-card.json` | `application/json` | A2A agent-to-agent discovery card |
| `/.well-known/openapi.json` | `application/json` | Enriched OpenAPI 3.1 spec |
| `/public/blueprints` | `application/json` | Blueprint catalog (list, filter, paginate) |
| `/public/blueprints/{id}` | `application/json` | Blueprint detail with steps and credit cost |

### llms.txt Format

Plain text following the llms.txt v1.1.0 convention. Contains protocol name, one-line description, API base URL, core concepts, endpoint summaries, and integration examples. Generated deterministically by `openclaw.generate_llms_txt()`.

### A2A Agent Card

JSON document at `/.well-known/agent-card.json` following Google's Agent-to-Agent protocol. Contains:
- `name`, `description`, `url`
- `skills` array with `id`, `name`, `description`, `tags`
- `serviceUrl` pointing to the API base
- `version` string

### Blueprint Catalog

Pre-validated workflow templates accessible without authentication. Each blueprint contains an ordered list of steps with dependencies, agent roles, and complexity scores. Seeded with 3 canonical blueprints: `audit-chain`, `code-review-pipeline`, `research-workflow`.

### Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `SWARM_API_URL` | `https://api.swarm.at` | API base URL used in generated discovery docs |
| `SWARM_SITE_URL` | `https://swarm.at` | Site URL used in generated discovery docs |

---

## 9H. Authorship Provenance

Writers using AI tools need tamper-evident proof of their creative decision-making process — which decisions were human-directed, which outputs were AI-generated, and what was accepted, rejected, or revised. `WritingSession` maps every event to the Agency Spectrum's L0-L5 layers and settles each to the hash-chained ledger.

Implements the Human-AI Agency Spectrum framework (Ghuneim, 2026). Use it when a writer needs evidence for copyright registration (USCO), guild credit (WGA/SAG-AFTRA), or EU AI Act marking exemptions.

No raw content enters the ledger. Prompts are SHA-256 hashed before storage. AI outputs are referenced by caller-provided hashes. The writer retains their content; the ledger retains the proof chain.

### Agency Layers

| Layer | Name | Agency Range | Description |
|-------|------|-------------|-------------|
| L0 | Oracle | ~0-14% | AI generates everything |
| L1 | Executor | ~15-39% | Human curates AI output |
| L2 | Collaborator | ~40-69% | Human selects/edits AI drafts |
| L3 | Supervisor | ~70-89% | Human reviews/modifies AI suggestions |
| L4 | Director | ~90-99% | Human directs, AI assists on command |
| L5 | Pure Tool | ~100% | Full human control, AI is passive |

Each layer normalizes to a 0.0–1.0 score via `layer.value / 5.0`.

### Creative Phases

Six contribution types with weights from the Agency Spectrum weighted contribution model:

| Phase | Weight | Description |
|-------|--------|-------------|
| Concept | 0.25 | Foundational creative decision — carries the most weight |
| Structure | 0.20 | Architectural framing |
| Character | 0.15 | Core creative expression |
| Scene | 0.15 | Narrative architecture |
| Dialogue | 0.15 | Surface-level expression |
| Revision | 0.10 | Refinement and quality control — carries the least weight |

Weights are customizable per session via the `phase_weights` parameter, supporting non-screenwriting workflows (novels, journalism, technical writing).

### Event Types

| Method | Actor | Default Agency | What It Records |
|--------|-------|---------------|-----------------|
| `direct()` | Human | L4_DIRECTOR | Creative decisions — what was chosen, what was rejected |
| `prompt()` | Human | L3_SUPERVISOR | Prompt text, SHA-256 hashed (raw text never stored) |
| `generate()` | AI | L1_EXECUTOR | Output hash, model identifier, generation parameters |
| `revise()` | Human | L3_SUPERVISOR | Description of edits, `kept_ratio` (fraction of AI output retained) |
| `reject()` | Human | L4_DIRECTOR | Hash of rejected output, reason for rejection |
| `approve()` | Human | L4_DIRECTOR | Final sign-off with content hash and optional version label |

Each method settles an event to the hash-chained ledger and returns a `SettlementResult` containing the cryptographic hash.

### Work Agency Calculation

Weighted aggregate across the full session:

```
For each phase with events:
    phase_agency = mean(event.agency / 5.0 for event in phase_events)

work_agency = sum(WEIGHT[p] * phase_agency[p] for p in phases_used)
            / sum(WEIGHT[p] for p in phases_used)
```

Phases without events are excluded from the denominator. A session covering only Concept, Structure, and Scene is scored against those three phases' weights alone.

### Compliance Mapping

| Score | Safe Harbor | Copyright (USCO) | WGA | SAG-AFTRA | EU AI Act | Market Tier |
|-------|------------|-------------------|-----|-----------|-----------|-------------|
| >= 90% | Yes | Clean — Full human authorship | Full credit | Compliant with consent | Marking exempt | Premium |
| 70-89% | No | Diluted — Defensible with docs | Conditional | Enhanced consent required | Marking exempt | Standard |
| 40-69% | No | Shared — Thin copyright | Not literary material | Prohibited for performance | Marking required | Budget |
| < 40% | No | Absent — No claim | Not literary material | Prohibited | Marking required | Locked out |

The 90% safe harbor threshold is the critical boundary. Above it, a writer has a strong copyright claim and full guild credit eligibility. These assessments are informational, not legal advice.

### Behavioral Flags

Three constraints detected from session data:

- **Anchoring risk:** Average `kept_ratio` across revisions exceeds 0.80 — suggests the writer is retaining most AI output with minimal transformation
- **Satisficing risk:** 3+ consecutive AI generations without human creative intervention — suggests accepting outputs without critical evaluation
- **Missing foundation:** AI generation occurs before any L4+ human creative event — no human creative vision established before AI involvement

These flags indicate risk, not guilt. A writer may have valid reasons for any of these patterns.

### Interfaces

Authorship provenance is exposed via REST API (7 endpoints) and MCP tools (4 tools), but deliberately excluded from the public agent card, `llms.txt`, and SDK client.

**REST API** (Bearer auth required):

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/v1/authorship/sessions` | Create a new writing session |
| GET | `/v1/authorship/sessions` | List and filter sessions (pagination supported) |
| DELETE | `/v1/authorship/sessions/{id}` | Delete a session |
| POST | `/v1/authorship/sessions/{id}/events` | Record a creative event |
| POST | `/v1/authorship/sessions/{id}/approve` | Record final approval |
| GET | `/v1/authorship/sessions/{id}/report` | JSON provenance report |
| GET | `/v1/authorship/sessions/{id}/report/text` | Plain-text provenance report |

**MCP Tools** (on `SettlementMCPServer`):

| Tool | Purpose |
|------|---------|
| `start_writing_session` | Create session, returns session_id |
| `record_writing_event` | Log a creative event |
| `approve_writing` | Record final sign-off with content hash |
| `get_provenance_report` | Fetch JSON provenance report |

### Persistence

Sessions can be in-memory (`WritingSessionStore`) or file-backed (`PersistentWritingSessionStore` via JSONL, enabled by `SWARM_SESSION_PATH` env var). Settlement hashes always persist to the ledger regardless.

### Provenance Report

`session.report()` returns a `ProvenanceReport` containing session metadata, work agency score, per-phase breakdown, compliance assessment, behavioral flags, full event timeline, and chain integrity verification. `report.to_text()` produces a human-readable version:

```
AUTHORSHIP PROVENANCE REPORT
============================================================
Session: a1b2c3d4 | Writer: jane-doe | Tool: claude-sonnet
Period: 2026-02-14 10:30 -> 2026-02-14 11:45

WORK AGENCY: 82.5%
============================================================

Phase Breakdown:
  concept          ################         100%
  structure        ##############           80%
  scene            #############            60%

SAFE HARBOR: BELOW THRESHOLD (82.5%)

COMPLIANCE ASSESSMENT:
  Copyright (USCO):  Diluted — Defensible with documentation
  WGA:               Conditional — L3 requires process evidence
  SAG-AFTRA:         Enhanced consent required
  EU AI Act:         Assistive function — Marking exempt
  Market Tier:       Standard

EVENT TIMELINE (9 events: 7 human, 2 AI):
  10:30:45  L5  [HUMAN]  creative-direction  concept
  10:32:12  L4  [HUMAN]  creative-direction  structure
  ...

CHAIN INTEGRITY: VERIFIED (9/9 hashes valid)
Ledger: /var/lib/swarm/ledger.jsonl
First hash: a1b2c3d4...  Last hash: z9y8x7w6...

This report is informational, not legal advice.
Generated by swarm.at v1.3.0
```

### API

```python
from swarm_at import WritingSession
from swarm_at.authorship import CreativePhase, AgencyLayer

session = WritingSession(writer="jane-doe", tool="claude-sonnet-4-5")

# Human creative decisions (L4-L5 agency)
session.direct(
    action="premise",
    chose="noir detective",
    rejected=["romance", "sci-fi"],
    phase=CreativePhase.CONCEPT,
    agency=AgencyLayer.L5_PURE_TOOL,
)

# AI-assisted drafting (L1-L3 agency)
session.prompt(text="Write the opening scene", phase=CreativePhase.SCENE)
session.generate(output_hash="<sha256-of-output>", model="claude-sonnet-4-5")

# Human edits and judgment
session.revise(description="Rewrote opening, cut 40%", kept_ratio=0.35)
session.reject(output_hash="<sha256-of-rejected>", reason="Too generic")
session.approve(content_hash="<sha256-of-final>", version="v1")

report = session.report()          # ProvenanceReport
report.work_agency                 # 0.0-1.0 weighted phase score
report.safe_harbor                 # True if >= 0.90
report.compliance.copyright        # USCO assessment
report.compliance.wga              # WGA credit status
report.compliance.sag_aftra        # SAG-AFTRA consent status
report.compliance.eu_ai_act        # EU AI Act marking status
report.behavioral_flags            # Anchoring, satisficing, missing foundation
report.chain_verified              # Hash-chain integrity
report.to_text()                   # Human-readable report for legal/editorial review
```

### References

- Ghuneim, M. (2026). "On the Calculation of The Human-AI Agency Spectrum." Narrative.new. CC BY 4.0.
- U.S. Copyright Office, "Copyright Registration Guidance: Works Containing Material Generated by Artificial Intelligence" (2023)
- WGA Minimum Basic Agreement, AI Provisions (2023, updated December 2025)
- SAG-AFTRA AI Provisions and Four Pillars of Ethical AI (2025)
- EU AI Act, Article 50: Transparency Obligations (Regulation 2024/1689)

### Design Reference

Full design doc: `docs/plans/2026-02-14-authorship-provenance-design.md`

---

## 10. Settlement Protocol (Agent-Facing)

The protocol loop that any participating agent must follow:

1. **Identify Parent Hash:** Read the last settled hash from local state or ledger.
2. **Execute Task:** Perform assigned work.
3. **Draft Proposal:** Create JSON with `parent_hash` and `data_update`.
4. **Invoke Settlement:** Send proposal to `/v1/settle`.
5. **Update Local State:** Only on `status: SETTLED`, update local memory with new hash.

**Safety rule:** If response is `REJECTED` due to state mismatch, pull new state from ledger and re-perform work. Never overwrite local memory without a verified settlement hash.

---

## 11. Collective Consensus ("Molt" Logic)

When multiple agents (a swarm) work on one task, they don't just communicate; they **Reconcile**.

1. First agent to find a valid solution "stakes" it on the ledger.
2. Other agents in the swarm must "verify" or "contest" it.
3. Finality is reached only when the consensus threshold is met.

---

## 12. Settlement Pulse (Heartbeat)

Periodic integrity check, replacing simple heartbeats with audit settlements.

- **Frequency:** Every 4 hours
- **Action:** Agent submits Work Summary + Hash to swarm.at ledger
- **Purpose:** Verify local agent memory hasn't drifted from institutional source of truth

---

## 13. Success Metrics

| Metric | Definition |
|--------|-----------|
| **Arbitrage Margin** | Delta between value-per-task charged to client and spot-price of model used |
| **Institutional Stickiness** | Depth of client's Shared State stored on swarm.at |
| **Audit Fidelity** | 100% of state transitions verifiable via public hash-chain |

---

## 14. Hosting Strategy

- **Frontend:** GitHub Pages (Verification Portal, documentation)
- **Backend:** Serverless Python (FastAPI)
- **Storage:** Flat-file JSONL ledger (append-only)
- **Philosophy:** Thrifty -- minimize infrastructure cost
