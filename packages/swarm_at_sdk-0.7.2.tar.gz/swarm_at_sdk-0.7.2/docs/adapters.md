# Framework Adapters

swarm.at ships 8 adapters that plug settlement into popular agent frameworks. Each adapter wraps framework-specific lifecycle events (node completions, task callbacks, reply hooks) and records them to the swarm.at hash-chained ledger. No adapter requires the target framework at import time -- they duck-type all external objects via `getattr`.

All adapters share two primitives:

- **`SettlementContext`** -- stateful wrapper that tracks `parent_hash` between settlements. Operates in local mode (in-process ledger) or remote mode (HTTP via `SwarmClient`).
- **`SettlementTier`** -- graduated adoption: `SANDBOX` (log-only), `STAGING` (writes ledger, no chain enforcement), `PRODUCTION` (full verification).

## Quick Start

Install the SDK with the adapter extra you need:

```bash
pip install swarm-at-sdk[langgraph]
pip install swarm-at-sdk[crewai]
pip install swarm-at-sdk[autogen]
pip install swarm-at-sdk[openai]          # Assistants API
pip install swarm-at-sdk[openai-agents]   # Agents SDK
pip install swarm-at-sdk[strands]
pip install swarm-at-sdk[haystack]
pip install swarm-at-sdk                  # Polymarket (no extra needed)
```

Or install everything:

```bash
pip install swarm-at-sdk[all]
```

Every adapter can be instantiated with an optional `SettlementContext` (to share ledger state across adapters) and an optional `SettlementTier` (defaults to `SANDBOX` via `SWARM_TIER` env var).

```python
from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier

# Shared context -- all adapters write to the same ledger chain
ctx = SettlementContext(tier=SettlementTier.PRODUCTION, ledger_path="ledger.jsonl")
```

## Adapter Registry

The `swarm_at.adapters` module provides a dynamic registry for loading adapters by name. This is useful for configuration-driven pipelines where the adapter choice comes from config files or environment variables.

```python
from swarm_at.adapters import get_adapter, list_adapters, check_adapter

# List all registered adapter names
list_adapters()
# ['autogen', 'crewai', 'haystack', 'langgraph',
#  'openai_agents', 'openai_assistants', 'polymarket', 'strands']

# Check if an adapter's dependencies are installed
check_adapter("langgraph")  # True if langgraph is importable

# Load an adapter class by name
AdapterClass = get_adapter("langgraph")
adapter = AdapterClass(agent="my-agent")
```

`get_adapter()` returns the class, not an instance. It finds the first class in the adapter module whose name starts with `Swarm`. Raises `KeyError` for unknown names and `ImportError` if the framework dependency is missing.

### Adapter Protocol

All adapters structurally conform to the `SwarmAdapter` protocol defined in `swarm_at/adapters/protocol.py`:

```python
from swarm_at.adapters.protocol import SwarmAdapter

class SwarmAdapter(Protocol):
    def settle(self, action: str, agent_id: str, **kwargs: Any) -> Any: ...
```

This is a structural protocol (`@runtime_checkable`). Adapters don't inherit from it -- they satisfy it by shape. Each adapter exposes specialized methods (e.g., `settle_run`, `on_task_complete`) tailored to its framework's lifecycle, and most also work as generic `settle()` callables.

---

## LangGraph

Decorator that settles LangGraph node function outputs to the ledger.

**Class:** `SwarmNodeWrapper`
**Maps:** node function to settlement entry, graph state dict to payload, function name to agent ID.
**Action type:** `langgraph:<node_name>`

```bash
pip install swarm-at-sdk[langgraph]
```

### Setup

```python
from swarm_at.adapters.langgraph import SwarmNodeWrapper

wrapper = SwarmNodeWrapper(agent="research-agent", confidence=0.95)
```

### Usage

```python
@wrapper.wrap
def research_node(state: dict) -> dict:
    # Your LangGraph node logic
    return {"findings": "The data shows...", "sources": ["arxiv:2401.1234"]}

# When research_node runs, swarm.at automatically settles the output.
# The function's return value passes through unchanged.
result = research_node({"query": "quantum computing trends"})
# result == {"findings": "The data shows...", "sources": ["arxiv:2401.1234"]}
```

**What gets settled:** The node's return value. If it returns a dict, that dict becomes the settlement payload. If it returns anything else, the payload is `{"output": str(result)}`. The settlement action is `langgraph:<function_name>`.

### Shared context

```python
from swarm_at.settle import SettlementContext

ctx = SettlementContext(ledger_path="pipeline.jsonl")

wrapper = SwarmNodeWrapper(agent="research-agent", context=ctx)
# All wrapped nodes share the same ledger chain
```

---

## CrewAI

Task completion callback that settles each CrewAI task output.

**Class:** `SwarmTaskCallback`
**Maps:** CrewAI `TaskOutput` to settlement entry, task description to payload, agent role to agent ID.
**Action type:** `crewai:<task_description>` (truncated to 80 chars)

```bash
pip install swarm-at-sdk[crewai]
```

### Setup

```python
from swarm_at.adapters.crewai import SwarmTaskCallback

callback = SwarmTaskCallback(confidence=0.95)
```

### Usage

```python
from crewai import Agent, Task, Crew

researcher = Agent(role="researcher", goal="Find facts", backstory="...")
task = Task(description="Research quantum computing", agent=researcher)

crew = Crew(
    agents=[researcher],
    tasks=[task],
    task_callback=callback.on_task_complete,  # Settles each task completion
)

crew.kickoff()
```

**What gets settled:** On each task completion, the callback extracts `task_output.description`, `task_output.raw`, and `task_output.agent.role`. The payload is `{"description": ..., "output": ...}`. The agent ID comes from the CrewAI agent's `role` attribute.

---

## AutoGen

Reply observer that settles agent messages without interrupting AutoGen's conversation flow.

**Class:** `SwarmReplyCallback`
**Maps:** agent reply to settlement entry, message content to payload, `sender.name` to agent ID.
**Action type:** `autogen:<agent_name>:reply`

```bash
pip install swarm-at-sdk[autogen]
```

### Setup

```python
from swarm_at.adapters.autogen import SwarmReplyCallback

callback = SwarmReplyCallback(confidence=0.95)
```

### Usage

```python
import autogen

assistant = autogen.AssistantAgent("assistant", llm_config={...})
user_proxy = autogen.UserProxyAgent("user_proxy")

# Register the settlement observer on the assistant
assistant.register_reply([autogen.Agent], callback.on_reply)

user_proxy.initiate_chat(assistant, message="Analyze this dataset")
```

**What gets settled:** Each reply triggers a settlement. The payload contains `{"message": <last_message_content>, "recipient": <recipient_name>}`. The callback returns `(False, None)` so AutoGen continues normal processing -- it's a pure observer, not an interceptor.

---

## OpenAI Assistants

Settles Assistant API runs and individual run steps.

**Class:** `SwarmRunHandler`
**Maps:** Run to settlement entry (molecule-level), RunStep to settlement entry (bead-level), `assistant_id` to agent ID.
**Action types:** `openai:run:<run_id>`, `openai:step:<step_type>`

```bash
pip install swarm-at-sdk[openai]
```

### Setup

```python
from swarm_at.adapters.openai_assistants import SwarmRunHandler

handler = SwarmRunHandler(assistant_id="asst_abc123")
```

### Usage

```python
from openai import OpenAI

client = OpenAI()

# Create and poll a run
run = client.beta.threads.runs.create_and_poll(
    thread_id="thread_xyz",
    assistant_id="asst_abc123",
)

# Settle the completed run
messages = client.beta.threads.messages.list(thread_id="thread_xyz")
handler.settle_run(run, messages.data)

# Or settle individual steps
steps = client.beta.threads.runs.steps.list(
    thread_id="thread_xyz", run_id=run.id
)
for step in steps.data:
    handler.settle_step(step.type, step)
```

**What gets settled:** `settle_run` records the full run with `run_id`, `status`, and extracted message text. `settle_step` records individual steps (tool calls, message creation) with step type and details. The `task_id` parameter on `settle_run` is set to the run ID for traceability.

---

## OpenAI Agents SDK

Settles agent runs and tool calls from the OpenAI Agents SDK (`openai-agents`).

**Class:** `SwarmAgentHook`
**Maps:** `RunResult` to settlement entry, `last_agent.name` to agent ID, tool call IDs extracted from `new_items`.
**Action types:** `openai-agents:run:<agent_name>`, `openai-agents:tool:<tool_name>`

```bash
pip install swarm-at-sdk[openai-agents]
```

### Setup

```python
from swarm_at.adapters.openai_agents import SwarmAgentHook

hook = SwarmAgentHook(agent="triage-agent")
```

### Usage

```python
from agents import Agent, Runner

agent = Agent(name="triage-agent", instructions="Triage support tickets")

result = Runner.run_sync(agent, "Customer can't log in")

# Settle the full run
hook.settle_run(result)

# Or settle individual tool calls
hook.settle_tool_call(
    "search_kb",
    {"query": "login issues"},
    {"results": ["Reset password", "Clear cache"]},
)
```

**What gets settled:** `settle_run` extracts `final_output`, `last_agent.name`, and tool call IDs from `new_items`. `settle_tool_call` records individual tool invocations with their input and output. All object access uses `getattr` -- no hard dependency on the `agents` package types.

---

## Strands

Callback for AWS Strands Agents tool and agent lifecycle events.

**Class:** `SwarmStrandsCallback`
**Maps:** tool completion to settlement entry, agent completion to settlement entry.
**Action types:** `strands:tool:<tool_name>`, `strands:agent:<agent_name>`

```bash
pip install swarm-at-sdk[strands]
```

### Setup

```python
from swarm_at.adapters.strands import SwarmStrandsCallback

callback = SwarmStrandsCallback(confidence=0.95)
```

### Usage

```python
# After a tool executes
callback.on_tool_complete(
    "web_search",
    {"query": "latest AI regulations"},
    {"results": ["EU AI Act update", "US executive order"]},
)

# After an agent run completes
callback.on_agent_complete("research-agent", result)
```

**What gets settled:** `on_tool_complete` records the tool name, input, and output as strings. The agent ID for tool settlements is `strands:<tool_name>`. `on_agent_complete` records the agent name and its output (extracted via `getattr(result, "output", str(result))`).

---

## Haystack

Pipeline component that slots into a Haystack pipeline and settles data flowing through it.

**Class:** `SwarmSettlementComponent`
**Maps:** pipeline data to settlement entry, component name to agent ID.
**Action type:** `haystack:<agent_name>`

```bash
pip install swarm-at-sdk[haystack]
```

### Setup

```python
from swarm_at.adapters.haystack import SwarmSettlementComponent

settlement = SwarmSettlementComponent(agent="rag-pipeline")
```

### Usage

```python
from haystack import Pipeline
from haystack.components.generators import OpenAIGenerator

pipeline = Pipeline()
pipeline.add_component("generator", OpenAIGenerator(model="gpt-4"))
pipeline.add_component("settlement", settlement)
pipeline.connect("generator.replies", "settlement.data")

result = pipeline.run({"generator": {"prompt": "Summarize this document"}})
# result["settlement"]["receipt"] == {"status": "settled", "hash": "a1b2c3..."}
```

**What gets settled:** The `run()` method accepts `data` (any type), an optional `agent` override, and an optional `task` override. If `data` is a dict, it becomes the payload directly. Otherwise, the payload is `{"output": str(data)}`. Returns `{"receipt": {"status": ..., "hash": ...}}` so downstream components can reference the settlement hash.

---

## Polymarket

Domain-specific adapter for prediction market operations. Unlike the framework adapters above, this one doesn't wrap a third-party library's lifecycle -- it provides explicit methods for market reads, trades, price checks, and portfolio snapshots.

**Class:** `SwarmPolymarketAdapter`
**Maps:** market operations to settlement entries.
**Action types:** `polymarket:market-read`, `polymarket:trade`, `polymarket:price-check`, `polymarket:portfolio`

```bash
pip install swarm-at-sdk  # No extra dependency needed
```

### Setup

```python
from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

adapter = SwarmPolymarketAdapter(agent="market-bot")
```

### Usage

```python
# Settle a market data read
adapter.settle_market_read([
    {"id": "0xabc", "question": "Will BTC hit 100k?", "outcome_prices": [0.72, 0.28]},
])

# Settle a trade execution
adapter.settle_trade(
    side="buy",
    token="0xdef",
    price=0.65,
    size=100,
    result={"filled": True, "avg_price": 0.6502},
)

# Settle a price check
adapter.settle_price_check("0xdef", {"bid": 0.64, "ask": 0.66})

# Settle a portfolio snapshot
adapter.settle_portfolio("0xaddr", [
    {"token": "0xdef", "size": 50, "avg_entry": 0.60},
])
```

**What gets settled:** Each method settles a different market operation type. Trade settlements enforce a minimum confidence of 0.99 (`max(self.confidence, 0.99)`) because financial execution demands high certainty. All other operations use the configured confidence (default 0.95). Market objects are stringified -- no dependency on `py-clob-client`.
