# Settlement Types

75 settlement types across 11 categories. Every settlement carries a `type` field inside `payload.data_update` that classifies what the agent did. The type string is freeform but should match one of these canonical values for consistent querying and analytics.

Types use lowercase kebab-case. Polymarket types are namespaced with a `polymarket:` prefix.

## Knowledge Verification

Settlements that verify, validate, or extract structured information from data. These are the foundation of the ledger's seed data, originally populated from public domain sources.

| Type | Description | When to use |
|------|-------------|-------------|
| `text-fingerprint` | Hashes and records a text document for tamper-evident reference. | Ingesting a document into the ledger for the first time. |
| `qa-verification` | Settles a factual question-answer pair verified by multi-agent consensus. | An agent answers a factual question and wants the answer on record. |
| `fact-extraction` | Records structured entities (names, dates, quantities) extracted from unstructured text. | Pulling structured data out of a document or web page. |
| `classification` | Settles a genre, topic, or tone classification applied to content. | Tagging content with labels (e.g., sentiment: positive, genre: sci-fi). |
| `summarization` | Records a text condensation verified against the source. | Producing a summary and proving it was cross-checked. |
| `translation-audit` | Verifies a translation between languages matches the source meaning. | Auditing machine or human translations for accuracy. |
| `data-validation` | Confirms correctness of structured data like math constants or periodic table values. | Checking that reference data (physical constants, conversion factors) is accurate. |
| `code-review` | Records a code review finding with verdict (pass/fail) and scope. | Completing a code review and committing the findings to the ledger. |
| `sentiment-analysis` | Settles dimensional sentiment scores for a piece of text. | Running sentiment analysis and recording the result immutably. |
| `logical-reasoning` | Verifies formal logic, syllogisms, or deductive reasoning steps. | Validating a logical argument or proof. |
| `unit-conversion` | Confirms metric, imperial, or scientific unit conversions are correct. | Verifying unit math before using a converted value downstream. |
| `geo-validation` | Verifies geographic facts (coordinates, borders, distances, capitals). | Checking geographic claims against authoritative data. |
| `timeline-ordering` | Confirms correct chronological ordering of historical events. | Verifying that a sequence of events is in the right order. |
| `regex-verification` | Validates that a regular expression matches the intended patterns. | Testing regex correctness before deploying it in production. |
| `schema-validation` | Checks data against a schema (JSON Schema, Protobuf, Avro, etc.). | Validating that a payload conforms to its declared schema. |

## Agent Behaviors

Settlements that record what an agent did during a task. These types track the full range of agent actions -- from writing code to browsing the web to delegating work.

| Type | Description | When to use |
|------|-------------|-------------|
| `code-generation` | Records new code creation with language, framework, and line count metadata. | An agent writes new code from scratch. |
| `code-edit` | Records modifications to existing code with diff tracking. | An agent edits existing files (not a full rewrite). |
| `code-refactor` | Records structural code improvements that preserve external behavior. | Renaming, extracting functions, reorganizing modules without changing functionality. |
| `bug-fix` | Records a defect resolution with root cause analysis. | An agent identifies and fixes a bug. |
| `test-authoring` | Records test creation with coverage and assertion metadata. | An agent writes new tests. |
| `codebase-search` | Records a code search operation with match scoring. | An agent searches a codebase for patterns, definitions, or usages. |
| `web-research` | Records web research with source verification. | An agent browses the web and wants to record what it found and verified. |
| `planning` | Records task decomposition and execution planning. | An agent breaks a goal into subtasks before starting work. |
| `debugging` | Records a diagnostic investigation with hypothesis and resolution. | An agent investigates a bug or failure, tracking symptoms through resolution. |
| `shell-execution` | Records a shell command execution with safety classification and exit code. | An agent runs a shell command. Always include `safety` (safe-read, safe-write, destructive). |
| `file-operation` | Records file system operations (create, move, delete, chmod) with change tracking. | An agent creates, moves, or deletes files. |
| `git-operation` | Records git operations (commit, push, merge, rebase) with ref metadata. | An agent performs git operations. |
| `dependency-management` | Records package install, update, or removal operations. | An agent manages project dependencies (pip install, npm update, etc.). |
| `agent-handoff` | Records task delegation from one agent to another. | A primary agent hands off a subtask to a specialized agent. |
| `consensus-vote` | Records an agent's vote in a multi-agent consensus round. | An agent participates in a vote or multi-agent decision. |
| `task-delegation` | Records work distribution to sub-agents with assignment details. | An orchestrator distributes tasks to worker agents. |
| `documentation` | Records documentation creation or updates. | An agent writes or updates docs, READMEs, or inline comments. |
| `api-integration` | Records an external API call with endpoint, method, status, and latency. | An agent calls a third-party API and wants the interaction on record. |
| `deployment` | Records build, deploy, or release operations. | An agent deploys code, publishes a package, or runs a release pipeline. |
| `conversation-turn` | Records a single conversational exchange between agents or agent and user. | Settling an individual turn in a multi-turn conversation. |

## Prediction Markets

Settlements specific to prediction market integrations. The `polymarket:` namespace separates market operations from general protocol activity. Trade settlements enforce a minimum confidence of 0.99 because financial execution demands near-certainty.

| Type | Description | When to use |
|------|-------------|-------------|
| `polymarket:market-read` | Records a prediction market data read with price, volume, and liquidity. | An agent reads current market state (prices, volume, open interest). |
| `polymarket:price-check` | Records a bid/ask spread and liquidity snapshot. | An agent checks pricing and spread before deciding to trade. |
| `polymarket:trade` | Records a trade execution. Requires confidence >= 0.99. | An agent executes a trade. The high confidence floor prevents accidental financial settlement. |
| `polymarket:portfolio` | Records a portfolio position snapshot. | An agent takes a snapshot of current holdings for audit or reporting. |

## Protocol Operations

Internal protocol actions that maintain the swarm.at system itself. These are generated by the protocol during normal operations like forking blueprints, verifying trust, or running guard checks.

| Type | Description | When to use |
|------|-------------|-------------|
| `blueprint-fork` | Records a blueprint forked into an executable workflow. | An agent forks a blueprint to start executing it. Credits are debited. |
| `guard-action` | Records a pre-action settlement check (settle before you act). | Before any destructive or irreversible operation. The agent proposes the action, gets approval, then acts. |
| `trust-check` | Records an agent trust level verification against a threshold. | Before delegating sensitive work to another agent. Verifies the agent meets a minimum trust level. |
| `credit-topup` | Records credits added to an agent's balance. | When topping up an agent's credit balance. |
| `receipt-verify` | Records a settlement receipt lookup by hash. | When a third party looks up a past settlement to verify it happened. |
| `badge-request` | Records a trust badge SVG generation request. | When an agent or site requests an embeddable trust badge. |
| `adapter-settlement` | Records a framework adapter settling agent output. | When a framework adapter (LangGraph, CrewAI, etc.) settles an agent's output. |
| `blueprint-execution` | Records a full blueprint run with step completion tracking. | When a blueprint finishes all its steps. Includes the step list and outputs. |

## Compliance

Settlements that verify regulatory compliance or assess operational risk. Use these to create an audit trail for governance reviews.

| Type | Description | When to use |
|------|-------------|-------------|
| `compliance-check` | Verifies adherence to a specific regulation or control (GDPR, SOC 2, HIPAA). | Running a compliance check against a regulation. Include the regulation name, article/control, and evidence. |
| `risk-assessment` | Evaluates the risk of a proposed action with mitigations. | Before a high-risk action (deploy, migration, key rotation). Record the risk level and mitigation plan. |
| `sla-verification` | Checks SLA adherence for uptime, latency, or data integrity targets. | End of a reporting period, or after an incident. Compares actual metrics against SLA targets. |
| `cost-optimization` | Analyzes infrastructure and resource costs with recommendations. | Reviewing cloud spend, package bandwidth, or compute costs. Record current costs and recommendations. |

## Security

Settlements that track security operations. These create an immutable record of vulnerability scans, access changes, and certificate management.

| Type | Description | When to use |
|------|-------------|-------------|
| `security-scan` | Records a vulnerability or secret scan with tool, target, and findings. | After running pip-audit, npm audit, trufflehog, or similar security scanners. |
| `access-control` | Records permission grants, promotions, or revocations for agents. | When an agent's access is granted, elevated, or revoked. Include the action (grant/promote/revoke), principal, and resource. |
| `certificate-renewal` | Records TLS certificate lifecycle events (renewal, expiry, auto-renew status). | When a certificate is renewed or approaching expiry. |

## Infrastructure

Settlements that track the health and operations of infrastructure. Build dashboards from these to monitor service health, performance, and incident response.

| Type | Description | When to use |
|------|-------------|-------------|
| `health-check` | Records service health and availability with latency and uptime metrics. | Periodic health probes or after deploying a service. |
| `performance-benchmark` | Records endpoint latency (p50/p95/p99) and throughput benchmarks. | After running load tests or benchmarks. Include the method and tool used. |
| `backup-verification` | Verifies backup integrity and synchronization status. | After a backup run or periodic backup audit. Confirm chain integrity and entry counts. |
| `config-change` | Tracks a configuration modification with old value, new value, and reason. | Changing a production config value. Always record old and new values for rollback reference. |
| `incident-response` | Records production incident detection, root cause, and resolution. | During or after a production incident. Include severity (P1-P4), root cause, resolution, and data loss status. |
| `log-analysis` | Records log pattern analysis, error rates, and traffic breakdowns. | After analyzing logs for a time period. Include error rates, top errors, and traffic patterns. |

## Data Processing

Settlements that record data transformation, enrichment, and analysis operations. These track how raw data becomes structured knowledge.

| Type | Description | When to use |
|------|-------------|-------------|
| `anomaly-detection` | Records outlier detection in metrics or agent behavior. | When a metric deviates from expected values. Record expected vs. observed, and whether it's a true anomaly. |
| `data-enrichment` | Records metadata addition to existing records. | When enriching existing data with new fields (e.g., adding tags, classifications, or computed attributes). |
| `knowledge-extraction` | Records structured knowledge extracted from data sources. | When querying data to produce structured insights (top agents, frequency analysis, trend reports). |
| `content-moderation` | Records content safety and policy compliance checks. | When reviewing content (blueprints, agent names, descriptions) for profanity, PII, or policy violations. |

## Notifications

Settlements that track event delivery, workflow execution, caching, and rate limiting. These record the operational plumbing that keeps the system running.

| Type | Description | When to use |
|------|-------------|-------------|
| `notification-dispatch` | Records a webhook or alert delivery with channel, event, and delivery status. | When a webhook fires or an alert is sent. Record whether delivery succeeded. |
| `workflow-orchestration` | Records multi-step workflow execution with step tracking and duration. | When an orchestrated workflow (onboarding, release pipeline, publish flow) completes all steps. |
| `cache-invalidation` | Records cache clearing with reason and TTL. | When invalidating a cache (blueprint store, trust scores) due to data changes. |
| `rate-limit-enforcement` | Records rate limit monitoring and enforcement actions. | When a rate limit is checked or enforced. Record whether the limit was breached and what action was taken. |

## Experiments

Settlements that track ML model evaluations, A/B test results, and feature flag changes. These create an audit trail for experimentation and gradual rollouts.

| Type | Description | When to use |
|------|-------------|-------------|
| `model-evaluation` | Records ML model accuracy, calibration, or error rate evaluations. | After evaluating a model against a test set. Include the metric, test set size, and results. |
| `ab-test-result` | Records A/B experiment results with variant comparison and winner selection. | When an A/B test reaches statistical significance. Record both variants, the winner, and the decision. |
| `feature-flag-toggle` | Records a feature flag state change with rationale. | When toggling a feature flag on or off. Always record old state, new state, and why. |

## Discovery

Settlements that track DNS, SEO, API discovery, and price monitoring. These verify that the protocol's public surface area is healthy and reachable.

| Type | Description | When to use |
|------|-------------|-------------|
| `dns-resolution` | Verifies DNS records resolve to expected targets. | Periodic DNS health checks or after DNS changes. |
| `seo-audit` | Audits SEO tags, structured data, sitemaps, and robots.txt. | After deploying site changes. Check OG tags, JSON-LD, canonical URLs. |
| `discovery-check` | Verifies A2A agent cards, llms.txt, and OpenAPI endpoints are live and valid. | After deploying API changes that affect discovery endpoints. |
| `price-alert` | Records price threshold monitoring for prediction markets. | When monitoring a market price against a threshold. Record whether the alert triggered. |

## Authorship (Proprietary)

One additional type exists outside the 75 canonical types. It is used internally by the authorship provenance system and is not included in the public catalog.

| Type | Description | When to use |
|------|-------------|-------------|
| `authorship-claim` | Binds an agent to a content hash in the ledger. First claim wins. | When an agent produces content and wants a tamper-evident authorship record. Used by `engine.claim_authorship()`. |

## Payload Conventions

Every settlement payload is a flat or shallow dict stored in `payload.data_update`. The `type` field is the only required key. Everything else is type-specific, but some conventions apply across types:

| Field | Convention |
|-------|-----------|
| `type` | Required. One of the canonical type strings above. |
| `agent` / `agent_id` | The agent performing the action. |
| `timestamp` | ISO 8601 string for when the action occurred (server assigns the settlement timestamp separately). |
| `verdict` | For review/check types: `"pass"` or `"fail"`. |
| `source` | Where the data came from (API name, database, file path). |

### Confidence Score Guidelines

The confidence score (`payload.confidence_score`) is separate from the type but the two work together. Some guidelines:

| Scenario | Typical range |
|----------|---------------|
| Deterministic checks (hash verification, schema validation) | 0.97 -- 0.99 |
| Human-reviewed decisions (code review, compliance) | 0.95 -- 0.98 |
| Automated analysis (anomaly detection, sentiment) | 0.90 -- 0.95 |
| Financial execution (`polymarket:trade`) | >= 0.99 (enforced) |
| Low-confidence or speculative | 0.85 -- 0.90 (minimum threshold is 0.85) |

## Adding New Types

New types don't require code changes. The `type` field accepts any string. To add a new type:

1. Pick a lowercase kebab-case name. Use a namespace prefix for domain-specific types (e.g., `polymarket:trade`).
2. Use it in `payload.data_update.type` when settling.
3. Add it to this catalog with a description and usage guidance.
4. Update the category map in `scripts/settle_batch.py` so the public ledger sync counts it correctly.
5. If the type is a new category, update the public ledger README.
