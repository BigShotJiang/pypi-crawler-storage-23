# Authorship Provenance

Settlement-backed audit trails for human-AI creative work. Implements the Human-AI Agency Spectrum framework (Ghuneim, 2026) as a verifiable evidence layer on swarm.at's hash-chained ledger. WritingSession records every human decision and AI action, settles each to the ledger, and produces provenance reports with compliance assessments.

## Quick Start

### Python SDK

```python
from swarm_at.authorship import WritingSession, CreativePhase

session = WritingSession(writer="jane", tool="claude-4")
session.direct(action="outline", chose="three-act structure", phase=CreativePhase.STRUCTURE)
session.prompt(text="Write the opening scene", phase=CreativePhase.SCENE)
session.generate(output_hash="abc123...", model="claude-4", phase=CreativePhase.SCENE)
session.revise(description="Cut two paragraphs", kept_ratio=0.3, phase=CreativePhase.SCENE)
session.approve(content_hash="def456...")

report = session.report()
print(report.work_agency_pct)   # "85.0%"
print(report.to_text())         # full provenance report
```

### REST API

```bash
# Create session
curl -X POST http://localhost:8000/v1/authorship/sessions \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"writer": "jane", "tool": "claude-4"}'

# Record event
curl -X POST http://localhost:8000/v1/authorship/sessions/{id}/events \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"event_type": "direction", "action": "outline", "chose": "three-act", "phase": "structure"}'

# List sessions
curl http://localhost:8000/v1/authorship/sessions?writer=jane \
  -H "Authorization: Bearer $TOKEN"

# Get report
curl http://localhost:8000/v1/authorship/sessions/{id}/report \
  -H "Authorization: Bearer $TOKEN"
```

### MCP Tools

Five tools available on SettlementMCPServer:

- `start_writing_session(writer, tool)` — Create a new session
- `record_writing_event(session_id, event_type, ...)` — Log a creative event
- `approve_writing(session_id, content_hash, version?)` — Record final approval
- `get_provenance_report(session_id)` — Fetch JSON report
- `list_writing_sessions(writer?)` — List active sessions with work agency scores

## WritingSession Methods

| Method | Actor | Default Phase | Default Agency | Returns |
|--------|-------|---------------|----------------|---------|
| `direct(action, chose, rejected?, phase?, agency?)` | writer | SCENE | L4_DIRECTOR | SettlementResult |
| `prompt(text, phase?, agency?)` | writer | SCENE | L3_SUPERVISOR | SettlementResult |
| `generate(output_hash, model?, params?, phase?, agency?)` | tool | SCENE | L1_EXECUTOR | SettlementResult |
| `revise(description, kept_ratio, phase?, agency?)` | writer | SCENE | L3_SUPERVISOR | SettlementResult |
| `reject(output_hash, reason, phase?)` | writer | SCENE | L4_DIRECTOR | SettlementResult |
| `approve(content_hash, version?)` | writer | REVISION | L4_DIRECTOR | SettlementResult |

**Method Details**

### `direct(action, chose, rejected=None, phase=CreativePhase.SCENE, agency=AgencyLayer.L4_DIRECTOR)`

Records a human creative decision. Settles to ledger with actor=writer.

- `action` (str): Decision category (e.g., "outline", "theme", "blocking")
- `chose` (str): The selection made
- `rejected` (list[str], optional): Options not selected
- `phase` (CreativePhase): Creative layer (default SCENE)
- `agency` (AgencyLayer): Human agency level (default L4_DIRECTOR)

### `prompt(text, phase=CreativePhase.SCENE, agency=AgencyLayer.L3_SUPERVISOR)`

Records a prompt to the AI tool. Prompt text is hashed (SHA-256), not stored.

- `text` (str): Prompt content
- `phase` (CreativePhase): Creative layer (default SCENE)
- `agency` (AgencyLayer): Human agency level (default L3_SUPERVISOR)

### `generate(output_hash, model="", params=None, phase=CreativePhase.SCENE, agency=AgencyLayer.L1_EXECUTOR)`

Records AI-generated output. Caller provides the content hash.

- `output_hash` (str): SHA-256 hash of generated content
- `model` (str, optional): Model identifier (e.g., "claude-sonnet")
- `params` (dict, optional): Generation parameters (temperature, etc.)
- `phase` (CreativePhase): Creative layer (default SCENE)
- `agency` (AgencyLayer): AI agency level (default L1_EXECUTOR)

### `revise(description, kept_ratio, phase=CreativePhase.SCENE, agency=AgencyLayer.L3_SUPERVISOR)`

Records human edits to AI output. Validates `kept_ratio` in 0.0–1.0 range.

- `description` (str): What was changed
- `kept_ratio` (float): Fraction of output retained (0.0–1.0)
- `phase` (CreativePhase): Creative layer (default SCENE)
- `agency` (AgencyLayer): Human agency level (default L3_SUPERVISOR)

### `reject(output_hash, reason, phase=CreativePhase.SCENE)`

Records rejection of AI output. Agency is always L4_DIRECTOR.

- `output_hash` (str): Hash of rejected output
- `reason` (str): Why it was rejected
- `phase` (CreativePhase): Creative layer (default SCENE)

### `approve(content_hash, version="")`

Records final approval and sign-off. Phase is always REVISION, agency is L4_DIRECTOR.

- `content_hash` (str): SHA-256 hash of final content
- `version` (str, optional): Version identifier (e.g., "v1.0", "final-draft")

## Creative Phases and Weights

| Phase | Weight | Description |
|-------|--------|-------------|
| CONCEPT | 0.25 | Foundational creative decision |
| STRUCTURE | 0.20 | Architectural framing |
| CHARACTER | 0.15 | Core creative expression |
| SCENE | 0.15 | Narrative architecture |
| DIALOGUE | 0.15 | Surface-level expression |
| REVISION | 0.10 | Refinement and quality control |

Custom weights can be set via `phase_weights` dict at session construction:

```python
session = WritingSession(
    writer="jane",
    tool="claude",
    phase_weights={
        CreativePhase.CONCEPT: 0.50,
        CreativePhase.STRUCTURE: 0.50,
    }
)
```

## Agency Layers

| Layer | Value | Agency Range | Description |
|-------|-------|-------------|-------------|
| L0_ORACLE | 0 | ~0–14% | AI generates everything |
| L1_EXECUTOR | 1 | ~15–39% | Human curates AI output |
| L2_COLLABORATOR | 2 | ~40–69% | Human selects/edits AI drafts |
| L3_SUPERVISOR | 3 | ~70–89% | Human reviews/modifies AI suggestions |
| L4_DIRECTOR | 4 | ~90–99% | Human directs, AI assists on command |
| L5_PURE_TOOL | 5 | ~100% | Full human control, AI is passive |

Normalized to 0.0–1.0: `layer.value / 5.0`

## Work Agency Formula

Work agency is a weighted average of human agency across creative phases with events.

```
For each phase with events:
    phase_agency = mean(event.agency / 5.0 for event in phase_events)

work_agency = sum(weight[p] * phase_agency[p]) / sum(weight[p])
              (only over phases with events)
```

Range: 0.0 (pure AI) to 1.0 (pure human). Phases without events don't affect the score.

## Compliance Thresholds

| Score | Copyright | WGA | SAG-AFTRA | EU AI Act | Safe Harbor | Market Tier |
|-------|-----------|-----|-----------|-----------|-------------|-------------|
| >= 90% | Clean — Full human authorship claim | Full credit — Literary material | Compliant with consent | Assistive function — Marking exempt | Yes | Premium |
| 70–89% | Diluted — Defensible with documentation | Conditional — L3 requires process evidence | Enhanced consent required | Assistive function — Marking exempt | No | Standard |
| 40–69% | Shared — Thin copyright at best | Not literary material (studio use) | Prohibited for performance | Marking required | No | Budget |
| < 40% | Absent — No human authorship claim | Not literary material | Prohibited | Marking required | No | Locked out of professional tiers |

These thresholds are computed by `ComplianceAssessment.from_score(work_agency)`.

## Behavioral Flags

Three constraint warnings detected from session data:

- **anchoring_risk**: True if average `kept_ratio` across all revisions exceeds 0.80 (heavy reliance on AI drafts with minimal edits)
- **satisficing_risk**: True if 3 or more consecutive `ai-generation` events occur without an intervening human creative event (evidence of lazy acceptance)
- **missing_foundation**: True if any `ai-generation` occurs before the first L4+ human creative direction (no human vision established)

Accessed via `session.behavioral_flags` property.

## REST API Endpoints

| Method | Path | Purpose | Auth |
|--------|------|---------|------|
| GET | `/v1/authorship/sessions` | List/filter/paginate sessions | Bearer |
| DELETE | `/v1/authorship/sessions/{id}` | Delete session | Bearer |
| POST | `/v1/authorship/sessions` | Create session | Bearer |
| POST | `/v1/authorship/sessions/{id}/events` | Record event | Bearer |
| POST | `/v1/authorship/sessions/{id}/approve` | Approve content | Bearer |
| GET | `/v1/authorship/sessions/{id}/report` | JSON report | Bearer |
| GET | `/v1/authorship/sessions/{id}/report/text` | Plain text report | Bearer |

All endpoints require Bearer token authentication and are tagged "authorship" in OpenAPI schema.

### Query Parameters (List Sessions)

- `writer` (str, optional): Filter by writer name
- `page` (int, default 1): Page number (1-indexed)
- `page_size` (int, default 50, max 200): Items per page

Response includes pagination metadata: `total`, `has_more`, `sessions`.

## Session Persistence

**In-Memory (Default)**

Sessions live in memory via `WritingSession`. Settlement hashes are written to the ledger.

```python
session = WritingSession(writer="jane", tool="claude")
# Sessions are not persisted unless explicitly serialized
```

**Persistent Store (via JSONL)**

Set `SWARM_SESSION_PATH` environment variable to enable file-backed persistence:

```bash
export SWARM_SESSION_PATH=/var/lib/swarm/sessions.jsonl
python app.py
```

The `PersistentWritingSessionStore` replays JSONL on startup and appends create/update events. Auto-enabled when `SWARM_LEDGER_PATH` is set (sessions.jsonl co-located with ledger).

## Serialization

- `session.to_dict()` — JSON-safe dict (excludes SettlementContext)
- `WritingSession.from_dict(data, ledger_path?, tier?)` — Reconstruct session

Used internally by `PersistentWritingSessionStore` for JSONL serialization.

```python
# Export
data = session.to_dict()
with open("session.json", "w") as f:
    json.dump(data, f)

# Import
with open("session.json") as f:
    data = json.load(f)
restored = WritingSession.from_dict(data, ledger_path="/path/to/ledger.jsonl")
```

## Provenance Report

### `ProvenanceReport` Model

Returned by `session.report()`. Contains:

- `session_id`, `writer`, `tool` — Session metadata
- `started_at`, `completed_at` — Timestamps
- `work_agency`, `work_agency_pct` — Overall human agency score and formatted percentage
- `phase_scores` — Per-phase agency breakdown (dict[str, float])
- `compliance` — `ComplianceAssessment` object (copyright, WGA, SAG-AFTRA, EU AI Act, market tier)
- `safe_harbor` — Boolean, true if work_agency >= 0.90
- `behavioral_flags` — `BehavioralFlags` object
- `total_events`, `human_events`, `ai_events` — Event counts
- `events` — List of `ProvenanceEvent` objects (full timeline)
- `first_hash`, `last_hash` — Settlement chain endpoints
- `chain_verified` — Boolean, true if ledger verification passed
- `ledger_path` — Path to the settlement ledger

### `report.to_text()`

Generates a human-readable provenance report for sharing or compliance audits:

```
AUTHORSHIP PROVENANCE REPORT
============================================================
Session: a1b2c3d4 | Writer: jane-doe | Tool: claude-sonnet
Period: 2025-02-14 10:30 -> 2025-02-14 11:45

WORK AGENCY: 82.5%
============================================================

Phase Breakdown:
  concept          ################         100%
  structure        ##############           80%
  scene            #############            60%
  ...

SAFE HARBOR: ABOVE THRESHOLD (82.5%)

COMPLIANCE ASSESSMENT:
  Copyright (USCO):  Diluted — Defensible with documentation
  WGA:               Conditional — L3 requires process evidence
  SAG-AFTRA:         Enhanced consent required
  EU AI Act:         Assistive function — Marking exempt
  Market Tier:       Standard

EVENT TIMELINE (9 events: 7 human, 2 AI):
  10:30:45  L5  [HUMAN]  creative-direction  concept
  10:32:12  L4  [HUMAN]  creative-direction  structure
  ...

CHAIN INTEGRITY: VERIFIED (9/9 hashes valid)
Ledger: /var/lib/swarm/ledger.jsonl
First hash: a1b2c3d4...  Last hash: z9y8x7w6...

This report is informational, not legal advice.
Generated by swarm.at v0.6.2
```

## Event Types

Internal events settled to the ledger:

- `creative-direction` — Human choice (direct)
- `prompt` — Prompt to AI (prompt)
- `ai-generation` — AI output (generate)
- `editorial-revision` — Human edits (revise)
- `rejection` — AI output rejected (reject)
- `approval` — Content approved (approve)

## Settlement Integration

Every event settles to swarm.at's hash-chained ledger via `SettlementContext`. The ledger:

- Verifies chain integrity (all hashes form a valid chain)
- Timestamps each event
- Stores metadata (action, chose, output_hash, etc.)
- Never stores raw content (only hashes)

Access the settlement hash via `result.hash` from any method return value:

```python
result = session.direct(action="outline", chose="3-act")
print(result.hash)  # 64-char SHA-256 hash
```

## Example: Full Screenplay Session

```python
from swarm_at.authorship import WritingSession, CreativePhase, AgencyLayer

session = WritingSession(writer="mark", tool="claude-sonnet-4.5")

# Concept (pure human)
session.direct(
    action="premise",
    chose="AI agency framework explainer",
    rejected=["listicle", "academic paper"],
    phase=CreativePhase.CONCEPT,
    agency=AgencyLayer.L5_PURE_TOOL,
)

# Structure (director-level guidance)
session.direct(
    action="outline",
    chose="six-layer progressive disclosure",
    phase=CreativePhase.STRUCTURE,
    agency=AgencyLayer.L5_PURE_TOOL,
)

# Drafting with AI assistance
session.prompt(
    text="Draft the section on the 90% threshold",
    phase=CreativePhase.SCENE,
)
session.generate(
    output_hash="a" * 64,
    model="claude-sonnet-4.5",
    params={"temperature": 0.7},
    phase=CreativePhase.SCENE,
    agency=AgencyLayer.L2_COLLABORATOR,
)

# Human edits
session.revise(
    description="Rewrote framing, kept legal citations, cut 40%",
    kept_ratio=0.35,
    phase=CreativePhase.SCENE,
    agency=AgencyLayer.L4_DIRECTOR,
)

# Dialogue polish with rejection
session.prompt(
    text="Suggest stakeholder positioning language",
    phase=CreativePhase.DIALOGUE,
)
session.generate(
    output_hash="b" * 64,
    phase=CreativePhase.DIALOGUE,
    agency=AgencyLayer.L2_COLLABORATOR,
)
session.reject(
    output_hash="b" * 64,
    reason="Too corporate, doesn't match voice",
)

# Final approval
session.approve(content_hash="f" * 64, version="v1.0")

# Report
report = session.report()
print(f"Work Agency: {report.work_agency_pct}")
print(f"Safe Harbor: {report.safe_harbor}")
print(f"Market Tier: {report.compliance.market_tier}")
print(report.to_text())
```

## Environment Variables

- `SWARM_SESSION_PATH` — Path to sessions.jsonl for persistent store
- `SWARM_LEDGER_PATH` — Path to settlement ledger (auto-enables persistence)
- `SWARM_API_URL` — Base URL for API (used in MCP tools)

## Related Files

- `swarm_at/authorship.py` — Main implementation
- `tests/test_authorship.py` — Unit tests
- `tests/test_authorship_api.py` — API tests
- `swarm_at/api/main.py` — REST endpoints
- `swarm_at/mcp/server.py` — MCP tools
