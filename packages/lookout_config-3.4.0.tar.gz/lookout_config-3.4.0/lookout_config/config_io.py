from __future__ import annotations

from pathlib import Path

from fluxconf import ConfigIO as BaseConfigIO

from lookout_config.types import LookoutConfig

BASE_CONFIG_DIR = Path("~/.config/greenroom")


class ConfigIO(BaseConfigIO[LookoutConfig]):
    """Configuration I/O handler for Lookout configuration files."""

    file_name = "lookout.yml"
    config_type = LookoutConfig
    schema_url = "https://greenroom-robotics.github.io/lookout/schemas/lookout.schema.json"
    migrations_dir = Path(__file__).parent / "migrations"
    always_include_fields = ["version"]

    def __init__(self, config_directory: str | Path = "") -> None:
        """Initialize ConfigIO with a configurable config directory.

        Args:
            config_directory: Base configuration directory path. Defaults to ~/.config/greenroom
        """
        if not str(config_directory).startswith(("~", "/")):
            config_directory = BASE_CONFIG_DIR / config_directory
        super().__init__(config_directory)
