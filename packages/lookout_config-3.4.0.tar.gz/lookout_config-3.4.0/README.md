# Lookout Config

Lookout Config is used to load config stored inside the `~/.config/greenroom` folder.

## Install

* `pip install -e ./packages/lookout_config`
* or...
* `pip install lookout_config` (Public on [PyPi](https://pypi.org/project/lookout-config/))

## Usage

### Reading config

```python
from lookout_config import get_config_io

config_io = get_config_io()
config = config_io.read()
```

## Configuration I/O

The `ConfigIO` class is built on [fluxconf](https://github.com/Greenroom-Robotics/fluxconf)'s `ConfigIO`, which handles YAML serialization, schema validation, and file management.

`LookoutConfig` inherits from `VersionedBaseModel` — the config carries a `version` field that enables automatic [migrations](https://github.com/Greenroom-Robotics/fluxconf?tab=readme-ov-file#migrations) when the schema evolves.

## Development

**Regenerate JSON schemas after modifying configuration classes:**
```bash
python3 -m lookout_config.generate_schemas
```

**Run tests:**
```bash
pytest ./packages/lookout_config
```
