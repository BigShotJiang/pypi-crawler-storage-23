from typing import MutableMapping, Any

JSON = MutableMapping[str, Any]
