# INSTALLATION INSTRUCTIONS

**note: currently only tested on windows 11 and ubuntu 24.04**

## Requirements
Python 3.10 + (3.12 recommended)
Vulkan Supported GPU (Nvidia, Intel, AMD)

## Minimum Requirements
8-10GB VRAM GPU (AMD rx 5000+)
32GB DDR4 RAM (faster is better)
Intel i5 9th generation or i3 12th gen (i3 below 12th gen could work but slow)

## SUPPORTED AND TESTED DEVICES
This list will continue to evolve as we test it on more devices. If you wish to offer your help
to run our tests on specific GPUs, open an Issue and tell us about it. 

READ: [SUPPORTED_DEVICES.md](./SUPPORTED_DEVICES.md)

