grilly.datasets package
=======================

Submodules
----------

grilly.datasets.clean\_conversations module
-------------------------------------------

.. automodule:: grilly.datasets.clean_conversations
   :members:
   :undoc-members:
   :show-inheritance:

grilly.datasets.loader module
-----------------------------

.. automodule:: grilly.datasets.loader
   :members:
   :undoc-members:
   :show-inheritance:

grilly.datasets.merge\_svc module
---------------------------------

.. automodule:: grilly.datasets.merge_svc
   :members:
   :undoc-members:
   :show-inheritance:

grilly.datasets.validate\_svc module
------------------------------------

.. automodule:: grilly.datasets.validate_svc
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: grilly.datasets
   :show-inheritance:
   :noindex:
