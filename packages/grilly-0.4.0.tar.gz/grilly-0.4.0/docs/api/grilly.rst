grilly package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   grilly.backend
   grilly.datasets
   grilly.experimental
   grilly.functional
   grilly.nn
   grilly.optim
   grilly.scripts
   grilly.utils

Submodules
----------

grilly.main module
------------------

.. automodule:: grilly.main
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: grilly
   :show-inheritance:
   :noindex:
