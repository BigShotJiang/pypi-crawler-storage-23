"""Unit tests for hash computation and glob expansion utilities."""

from __future__ import annotations

from pathlib import Path

from cascache_lib.cache.utils import compute_cache_key, expand_globs


def test_expand_globs_single_file(temp_dir: Path, sample_file: Path):
    """Test expanding a single file path."""
    patterns = [str(sample_file.relative_to(temp_dir))]
    result = expand_globs(patterns, temp_dir)
    assert len(result) == 1
    assert result[0] == sample_file


def test_expand_globs_multiple_files(temp_dir: Path, sample_files: list[Path]):
    """Test expanding glob pattern to multiple files."""
    patterns = ["*.txt"]
    result = expand_globs(patterns, temp_dir)
    assert len(result) == len(sample_files)
    assert set(result) == set(sample_files)


def test_expand_globs_recursive(temp_dir: Path):
    """Test recursive glob expansion."""
    # Create nested structure
    nested = temp_dir / "foo" / "bar"
    nested.mkdir(parents=True)
    (nested / "test.txt").write_text("test")

    patterns = ["**/test.txt"]
    result = expand_globs(patterns, temp_dir)
    assert len(result) == 1
    assert result[0].name == "test.txt"


def test_expand_globs_deduplicate(temp_dir: Path, sample_file: Path):
    """Test that duplicate paths are deduplicated."""
    patterns = [
        str(sample_file.relative_to(temp_dir)),
        str(sample_file.relative_to(temp_dir)),
    ]
    result = expand_globs(patterns, temp_dir)
    assert len(result) == 1


def test_compute_cache_key_deterministic(temp_dir: Path, sample_file: Path):
    """Test that cache key is deterministic."""
    key1 = compute_cache_key("echo test", [sample_file])
    key2 = compute_cache_key("echo test", [sample_file])
    assert key1 == key2
    assert len(key1) == 64  # SHA256 hex digest


def test_compute_cache_key_different_command(temp_dir: Path, sample_file: Path):
    """Test that different commands produce different keys."""
    key1 = compute_cache_key("echo test", [sample_file])
    key2 = compute_cache_key("echo other", [sample_file])
    assert key1 != key2


def test_compute_cache_key_different_inputs(temp_dir: Path):
    """Test that different inputs produce different keys."""
    file1 = temp_dir / "file1.txt"
    file1.write_text("content1")
    file2 = temp_dir / "file2.txt"
    file2.write_text("content2")

    key1 = compute_cache_key("echo test", [file1])
    key2 = compute_cache_key("echo test", [file2])
    assert key1 != key2


def test_compute_cache_key_with_env(temp_dir: Path, sample_file: Path):
    """Test that environment variables affect cache key."""
    key1 = compute_cache_key("echo test", [sample_file], env={"VAR": "value1"})
    key2 = compute_cache_key("echo test", [sample_file], env={"VAR": "value2"})
    assert key1 != key2


def test_compute_cache_key_empty_inputs():
    """Test cache key computation with no inputs."""
    key = compute_cache_key("echo test", [])
    assert len(key) == 64
    assert isinstance(key, str)


def test_compute_cache_key_nonexistent_file(temp_dir: Path):
    """Test that nonexistent files are handled gracefully."""
    nonexistent = temp_dir / "nonexistent.txt"
    key = compute_cache_key("echo test", [nonexistent])
    assert len(key) == 64  # Should still compute a key
