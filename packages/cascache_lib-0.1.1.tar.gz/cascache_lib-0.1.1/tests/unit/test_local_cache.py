"""Unit tests for LocalCache implementation."""

from __future__ import annotations

from pathlib import Path

import pytest

from cascache_lib.cache.local import LocalCache


@pytest.mark.asyncio
async def test_local_cache_put_get(cache_dir: Path, temp_dir: Path):
    """Test basic put and get operations."""
    cache = LocalCache(cache_dir)

    # Create output file
    output_file = temp_dir / "output.txt"
    output_file.write_text("test output")

    # Store in cache
    cache_key = "test_key_123"
    assert await cache.put(cache_key, [output_file])

    # Remove output file
    output_file.unlink()
    assert not output_file.exists()

    # Restore from cache
    assert await cache.get(cache_key, [output_file])
    assert output_file.exists()
    assert output_file.read_text() == "test output"


@pytest.mark.asyncio
async def test_local_cache_exists(cache_dir: Path, temp_dir: Path):
    """Test cache existence check."""
    cache = LocalCache(cache_dir)
    cache_key = "test_exists"

    # Initially doesn't exist
    assert not await cache.exists(cache_key)

    # Store something
    output_file = temp_dir / "output.txt"
    output_file.write_text("content")
    await cache.put(cache_key, [output_file])

    # Now exists
    assert await cache.exists(cache_key)


@pytest.mark.asyncio
async def test_local_cache_clear(cache_dir: Path, temp_dir: Path):
    """Test clearing the cache."""
    cache = LocalCache(cache_dir)

    # Add some cached items
    for i in range(3):
        output_file = temp_dir / f"output{i}.txt"
        output_file.write_text(f"content {i}")
        await cache.put(f"key{i}", [output_file])

    # Verify they exist
    assert await cache.exists("key0")
    assert await cache.exists("key1")

    # Clear cache
    await cache.clear()

    # Verify they're gone
    assert not await cache.exists("key0")
    assert not await cache.exists("key1")


@pytest.mark.asyncio
async def test_local_cache_multiple_outputs(cache_dir: Path, temp_dir: Path):
    """Test caching multiple output files."""
    cache = LocalCache(cache_dir)
    cache_key = "multi_output"

    # Create multiple outputs
    output_files = []
    for i in range(3):
        output_file = temp_dir / f"out{i}.txt"
        output_file.write_text(f"output {i}")
        output_files.append(output_file)

    # Cache all outputs
    assert await cache.put(cache_key, output_files)

    # Remove outputs
    for f in output_files:
        f.unlink()

    # Restore all outputs
    assert await cache.get(cache_key, output_files)
    for i, f in enumerate(output_files):
        assert f.exists()
        assert f.read_text() == f"output {i}"


@pytest.mark.asyncio
async def test_local_cache_directory_output(cache_dir: Path, temp_dir: Path):
    """Test caching a directory."""
    cache = LocalCache(cache_dir)
    cache_key = "dir_output"

    # Create directory with files
    output_dir = temp_dir / "dist"
    output_dir.mkdir()
    (output_dir / "file1.txt").write_text("content1")
    (output_dir / "file2.txt").write_text("content2")

    # Cache directory
    assert await cache.put(cache_key, [output_dir])

    # Remove directory
    import shutil

    shutil.rmtree(output_dir)
    assert not output_dir.exists()

    # Restore directory
    assert await cache.get(cache_key, [output_dir])
    assert output_dir.exists()
    assert (output_dir / "file1.txt").read_text() == "content1"
    assert (output_dir / "file2.txt").read_text() == "content2"


@pytest.mark.asyncio
async def test_local_cache_get_nonexistent(cache_dir: Path, temp_dir: Path):
    """Test getting a nonexistent cache key."""
    cache = LocalCache(cache_dir)
    output_file = temp_dir / "output.txt"

    # Try to get nonexistent key
    assert not await cache.get("nonexistent_key", [output_file])
    assert not output_file.exists()
