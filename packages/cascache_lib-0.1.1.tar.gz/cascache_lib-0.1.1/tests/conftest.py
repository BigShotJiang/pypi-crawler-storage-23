"""Test fixtures and configuration for cascache_lib tests."""

from __future__ import annotations

import asyncio
import tempfile
from collections.abc import Generator
from pathlib import Path

import pytest


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Create a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def cache_dir(temp_dir: Path) -> Path:
    """Create a cache directory for tests."""
    cache = temp_dir / ".cache"
    cache.mkdir(parents=True, exist_ok=True)
    return cache


@pytest.fixture
def sample_file(temp_dir: Path) -> Path:
    """Create a sample file for testing."""
    file_path = temp_dir / "sample.txt"
    file_path.write_text("Hello, World!")
    return file_path


@pytest.fixture
def sample_files(temp_dir: Path) -> list[Path]:
    """Create multiple sample files for testing."""
    files = []
    for i in range(3):
        file_path = temp_dir / f"file{i}.txt"
        file_path.write_text(f"Content {i}")
        files.append(file_path)
    return files


@pytest.fixture
def output_dir(temp_dir: Path) -> Path:
    """Create an output directory for tests."""
    output = temp_dir / "output"
    output.mkdir(parents=True, exist_ok=True)
    return output


@pytest.fixture
def event_loop():
    """Create an event loop for async tests."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()
