"""cascache_lib - Content-addressable storage (CAS) caching library for Python.

This library provides content-addressed caching with both local filesystem and
remote CAS backend support. It's designed to be generic and reusable across
different tools and workflows.

Key Features:
- Abstract CacheBackend interface for flexibility
- LocalCache: Fast filesystem-based caching with tar.gz compression
- RemoteCache: Remote caching using cascache server (gRPC)
- HybridCache: Combines local and remote for optimal performance
- Content hashing utilities for cache key computation
- Async/await support for non-blocking I/O
- Automatic retry with exponential backoff
- Graceful degradation (fallback to local when remote unavailable)

Basic Usage:
    from cascache_lib import LocalCache, compute_cache_key
    from pathlib import Path

    # Create cache instance
    cache = LocalCache(Path(".cache"))

    # Compute cache key from inputs
    cache_key = compute_cache_key(
        command="python build.py",
        inputs=[Path("src/main.py")],
        env={"PYTHON_VERSION": "3.13"},
    )

    # Check cache
    if await cache.exists(cache_key):
        await cache.get(cache_key, [Path("dist/")])
    else:
        # Run build...
        await cache.put(cache_key, [Path("dist/")])

Remote CAS Usage:
    from cascache_lib import RemoteCache, HybridCache

    # Create remote cache
    remote = RemoteCache(
        cas_url="grpc://cache.example.com:50051",
        token="your-token-here",
    )

    # Or use hybrid cache (local + remote)
    cache = HybridCache(
        local_cache=LocalCache(Path(".cache")),
        remote_cache=remote,
        auto_upload=True,
    )
"""

from __future__ import annotations

__version__ = "0.1.0"

from cascache_lib.cache.base import CacheBackend
from cascache_lib.cache.factory import create_cache
from cascache_lib.cache.hybrid import HybridCache
from cascache_lib.cache.local import LocalCache
from cascache_lib.cache.remote import RemoteCache
from cascache_lib.cache.utils import compute_cache_key, expand_globs

__all__ = [
    "__version__",
    # Core interfaces
    "CacheBackend",
    # Implementations
    "LocalCache",
    "RemoteCache",
    "HybridCache",
    # Factory
    "create_cache",
    # Utilities
    "compute_cache_key",
    "expand_globs",
]
