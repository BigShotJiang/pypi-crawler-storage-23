"""Configuration models for cascache_lib.

These Pydantic models define the configuration schema for cache backends.
They can be used directly or integrated into larger configuration systems.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class LocalCacheConfig(BaseModel):
    """Local filesystem cache configuration.

    Attributes:
        enabled: Whether local cache is enabled
        path: Directory path for cache storage
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True
    path: str = ".cache"


class RemoteCacheConfig(BaseModel):
    """Remote CAS cache configuration.

    Attributes:
        enabled: Whether remote cache is enabled
        type: Cache backend type (currently only "cas" supported)
        url: CAS server URL (e.g., "grpc://localhost:50051")
        token_file: Optional path to authentication token file
        upload: Whether to upload to remote cache on put()
        download: Whether to download from remote cache on get()
        timeout: Request timeout in seconds
        max_retries: Maximum number of retry attempts for transient errors
        initial_backoff: Initial backoff delay in seconds for retry logic
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    type: Literal["cas"] = "cas"
    url: str = "grpc://localhost:50051"
    token_file: str | None = None
    upload: bool = True
    download: bool = True
    timeout: float = 30.0
    max_retries: int = 3
    initial_backoff: float = 0.1


class CacheConfig(BaseModel):
    """Combined cache configuration with local and optional remote backend.

    Attributes:
        local: Local filesystem cache settings
        remote: Remote CAS cache settings
    """

    model_config = ConfigDict(extra="forbid")

    local: LocalCacheConfig = Field(default_factory=LocalCacheConfig)
    remote: RemoteCacheConfig = Field(default_factory=RemoteCacheConfig)
