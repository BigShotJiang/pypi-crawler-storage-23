"""API module - gRPC protobuf definitions and generated code."""

from __future__ import annotations

__all__: list[str] = []
