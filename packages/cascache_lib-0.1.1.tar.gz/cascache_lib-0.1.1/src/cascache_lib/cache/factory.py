"""Factory functions for creating cache instances from configuration."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from cascache_lib.cache.base import CacheBackend
from cascache_lib.cache.hybrid import HybridCache
from cascache_lib.cache.local import LocalCache
from cascache_lib.cache.remote import RemoteCache

if TYPE_CHECKING:
    from cascache_lib.config import CacheConfig

logger = logging.getLogger(__name__)


def create_cache(config: CacheConfig, cache_dir: Path | None = None) -> CacheBackend:
    """Create cache instance based on configuration.

    This factory function creates the appropriate cache backend(s) based on the
    provided configuration. It handles:
    - Local-only caching (when remote is disabled)
    - Remote-only caching (when local is disabled)
    - Hierarchical caching (CacheManager with both local and remote)
    - Token loading from file
    - Graceful fallback to local on remote configuration errors

    Args:
        config: Cache configuration model
        cache_dir: Override default cache directory path

    Returns:
        CacheBackend instance (LocalCache, RemoteCache, or HybridCache)

    Example:
        from cascache_lib import create_cache
        from cascache_lib.config import CacheConfig

        # Local-only cache
        config = CacheConfig(
            local={"enabled": True, "path": ".cache"},
            remote={"enabled": False},
        )
        cache = create_cache(config)

        # Hybrid cache (local + remote)
        config = CacheConfig(
            local={"enabled": True, "path": ".cache"},
            remote={
                "enabled": True,
                "url": "grpc://localhost:50051",
                "token_file": "~/.cache/cascache/token",
            },
        )
        cache = create_cache(config)
    """
    # Create local cache (always required)
    local_path = cache_dir or Path(config.local.path)
    local_cache = LocalCache(local_path) if config.local.enabled else None

    # If only local cache, return it directly
    if not config.remote.enabled:
        if local_cache:
            logger.info(f"Using local cache: {local_path}")
            return local_cache
        else:
            # No cache enabled at all - create disabled cache
            logger.warning("No cache enabled")
            return LocalCache(Path(".cache"))  # Will exist but won't be used

    # Remote cache is enabled - create RemoteCache
    try:
        # Read token from file if specified
        token = None
        if config.remote.token_file:
            token_path = Path(config.remote.token_file).expanduser()
            if token_path.exists():
                token = token_path.read_text().strip()
                logger.debug(f"Loaded CAS token from {token_path}")
            else:
                logger.warning(f"Token file not found: {token_path}")

        remote_cache = RemoteCache(
            cas_url=config.remote.url,
            token=token,
            timeout=config.remote.timeout,
            max_retries=config.remote.max_retries,
            initial_backoff=config.remote.initial_backoff,
        )
        logger.info(f"Configured remote cache: {config.remote.url}")

        # Return HybridCache if we have both local and remote
        if local_cache:
            return HybridCache(
                local_cache=local_cache,
                remote_cache=remote_cache,
                auto_upload=config.remote.upload,
            )
        else:
            # Only remote cache
            return remote_cache

    except Exception as e:
        logger.error(f"Failed to create remote cache: {e}")
        if local_cache:
            logger.info("Falling back to local cache only")
            return local_cache
        raise
