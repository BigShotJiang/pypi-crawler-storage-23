"""Cache module - Content-addressable caching backends.

This module provides a flexible caching system with multiple backend options:
- LocalCache: Fast filesystem-based caching
- RemoteCache: Shared cache via cascache server (gRPC)
- HybridCache: Combines local and remote for optimal performance

The module also includes utilities for content hashing and a factory
function to create cache instances from configuration.
"""

from __future__ import annotations

from cascache_lib.cache.base import CacheBackend
from cascache_lib.cache.factory import create_cache
from cascache_lib.cache.hybrid import HybridCache
from cascache_lib.cache.local import LocalCache
from cascache_lib.cache.remote import RemoteCache
from cascache_lib.cache.utils import compute_cache_key, expand_globs

__all__ = [
    # Core interface
    "CacheBackend",
    # Implementations
    "LocalCache",
    "RemoteCache",
    "HybridCache",
    # Utilities
    "compute_cache_key",
    "expand_globs",
    # Factory
    "create_cache",
]
