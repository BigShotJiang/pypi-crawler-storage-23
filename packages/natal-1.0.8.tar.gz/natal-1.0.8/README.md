# Natal

> create Natal Chart with ease

<img src="https://raw.githubusercontent.com/hoishing/natal/refs/heads/main/birth_chart_example.jpg" width=600/>

## Features

- SVG natal chart generation in pure python
- supported chart types:
  - birth chart
  - transit chart
  - synastry chart
  - solar return chart
- highly configurable
  - all planets, asteroids, vertices can be enabled / disabled
  - orbs for each aspect
  - light, dark, or mono theme
  - light / dark theme color definitions
  - chart stroke, opacity, font, spacing between planets ...etc
- high precision astrological data with [Swiss Ephemeris]
- chart data statistics
  - element, modality, and polarity counts
  - planets in each houses
  - quadrant and hemisphere distribution
  - aspect pair counts
  - composite chart aspects
  - aspects cross reference table
- thoroughly tested with `pytest`

## Tech Stack

- [tagit]: SVG / HTML generation and manipulation
- [pyswisseph]: astrological data - Swiss Ephemeris
- [pydantic]: data validation

[pydantic]: https://github.com/pydantic/pydantic
[pyswisseph]: https://github.com/astrorigin/pyswisseph
[Swiss Ephemeris]: https://www.astro.com/swisseph/swephinfo_e.htm
[tagit]: https://github.com/hoishing/tagit
