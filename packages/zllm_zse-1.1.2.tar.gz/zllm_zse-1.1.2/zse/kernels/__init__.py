"""
ZSE Custom Kernels

High-performance kernels for INT4 inference.
Uses Triton for JIT compilation (no Python.h needed).
"""

# Only import Triton kernels - raw CUDA disabled to avoid Python.h issues
_TRITON_INT4_AVAILABLE = False
int4_matmul_triton = None
TritonInt4Linear = None

try:
    from .triton_int4 import (
        int4_matmul_triton,
        TritonInt4Linear,
        is_triton_available,
    )
    _TRITON_INT4_AVAILABLE = is_triton_available()
except ImportError:
    pass

def is_triton_available():
    return _TRITON_INT4_AVAILABLE

# Disable raw CUDA to avoid Python.h compilation errors
int4_matmul = None
Int4Linear = None
int4_matmul_pytorch = None

def is_kernel_available():
    return False

__all__ = [
    "int4_matmul_triton",
    "TritonInt4Linear",
    "is_triton_available",
]
