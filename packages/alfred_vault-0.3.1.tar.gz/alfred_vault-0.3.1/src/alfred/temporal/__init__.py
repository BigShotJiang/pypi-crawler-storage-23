"""Temporal workflow execution engine for Alfred.

Optional dependency — install with: pip install alfred-vault[temporal]
"""
