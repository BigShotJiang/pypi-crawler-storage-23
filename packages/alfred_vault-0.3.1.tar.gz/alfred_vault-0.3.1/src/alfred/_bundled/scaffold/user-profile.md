# User Profile

This file helps Alfred understand who you are so it can make better decisions about what's relevant to your vault. Fill in the sections below with as much or as little detail as you like.

Alfred uses this profile to:
- Filter entity extraction (only create records for things relevant to you)
- Calibrate the distiller (focus on learnings that matter to your work)
- Prioritize the janitor (fix issues in records you care about first)

---

## About Me

<!-- Your name, role, and what you do -->

## My Work

<!-- What projects are you working on? What's your profession? Who do you work with? -->

## My Interests

<!-- What topics, domains, or areas are you actively engaged in? -->

## What's NOT Relevant

<!-- Anything you want Alfred to explicitly ignore or skip? -->
