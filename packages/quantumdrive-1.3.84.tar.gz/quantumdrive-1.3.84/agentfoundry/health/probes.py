"""Health probes for AgentFoundry components.

Each probe wraps an existing component and implements :class:`HealthCheckable`.
Probes are standalone -- they do not require modifying the wrapped component.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, List, Optional
from urllib.parse import urlparse

from agentfoundry.health.models import ComponentHealth, ComponentStatus
from agentfoundry.health.protocol import HealthCheckable

logger = logging.getLogger(__name__)


class VectorStoreHealthProbe(HealthCheckable):
    """Health probe for VectorStore providers (Milvus, Chroma, FAISS).

    Checks:
    - Can reach the provider and call ``get_store()`` without error
    - Reports cached collection count and store type
    - Marks degraded if latency approaches timeout
    """

    def __init__(self, provider: Any, provider_name: str = "vectorstore"):
        self._provider = provider
        self._provider_name = provider_name

    @property
    def health_component_name(self) -> str:
        return f"vectorstore.{self._provider_name}"

    def check_health(self, *, timeout: float = 5.0) -> ComponentHealth:
        t0 = time.perf_counter()
        meta: dict[str, Any] = {"provider_class": type(self._provider).__name__}
        try:
            store = self._provider.get_store(org_id="global")
            latency = (time.perf_counter() - t0) * 1000
            meta["store_type"] = type(store).__name__

            if hasattr(self._provider, "_milvus_stores"):
                meta["cached_collections"] = len(self._provider._milvus_stores)

            status = ComponentStatus.HEALTHY
            if latency > (timeout * 1000 * 0.8):
                status = ComponentStatus.DEGRADED
                meta["warning"] = "High latency approaching timeout"

            return ComponentHealth(
                name=self.health_component_name,
                status=status,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                metadata=meta,
            )
        except Exception as exc:
            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.UNHEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                error=str(exc),
                metadata=meta,
            )


class LLMHealthProbe(HealthCheckable):
    """Health probe for LLM providers.

    Checks:
    - LLM object is not None and appears valid
    - Optionally performs a lightweight API ping (disabled by default
      to avoid cost; enable via ``ping=True``)
    """

    def __init__(
        self,
        llm: Any,
        provider_name: str = "llm",
        *,
        ping: bool = False,
    ):
        self._llm = llm
        self._provider_name = provider_name
        self._ping = ping

    @property
    def health_component_name(self) -> str:
        return f"llm.{self._provider_name}"

    def check_health(self, *, timeout: float = 5.0) -> ComponentHealth:
        t0 = time.perf_counter()
        meta: dict[str, Any] = {}
        try:
            if self._llm is None:
                raise RuntimeError("LLM instance is None")

            meta["llm_class"] = type(self._llm).__name__
            model_name = getattr(
                self._llm,
                "model_name",
                getattr(self._llm, "model", "unknown"),
            )
            meta["model"] = str(model_name)

            if self._ping:
                from langchain_core.messages import HumanMessage

                resp = self._llm.invoke([HumanMessage(content="ping")])
                meta["ping_response_chars"] = len(str(getattr(resp, "content", "")))

            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.HEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                metadata=meta,
            )
        except Exception as exc:
            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.UNHEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                error=str(exc),
                metadata=meta,
            )


class KGraphHealthProbe(HealthCheckable):
    """Health probe for Knowledge Graph backends.

    Supports:
    - DuckSqliteGraph: persistent ``conn`` attribute, ``facts`` table
    - AuroraGraphStore: connectionless (opens per-query via ``_dsn``),
      ``kg_triples`` table
    """

    def __init__(self, kgraph: Any, backend_name: str = "duckdb_sqlite"):
        self._kgraph = kgraph
        self._backend_name = backend_name

    @property
    def health_component_name(self) -> str:
        return f"kgraph.{self._backend_name}"

    def _check_aurora(self, meta: dict[str, Any]) -> int:
        """Ping Aurora/Postgres via a fresh connection and return row count."""
        import psycopg

        dsn = getattr(self._kgraph, "_dsn", None)
        if not dsn:
            raise RuntimeError("AuroraGraphStore has no DSN configured")
        table = getattr(self._kgraph, "_table", "kg_triples")
        with psycopg.connect(dsn, connect_timeout=5) as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                row = cur.fetchone()
        meta["table"] = table
        return row[0] if row else 0

    def _check_duckdb(self, meta: dict[str, Any]) -> int:
        """Ping DuckDB via the persistent connection and return row count."""
        conn = getattr(self._kgraph, "conn", None)
        if conn is None:
            raise RuntimeError("KGraph has no database connection")
        result = conn.execute("SELECT COUNT(*) FROM facts").fetchone()
        db_path = getattr(self._kgraph, "db_path", None)
        if db_path:
            meta["db_path"] = str(db_path)
        return result[0] if result else 0

    def check_health(self, *, timeout: float = 5.0) -> ComponentHealth:
        t0 = time.perf_counter()
        meta: dict[str, Any] = {"backend": self._backend_name}
        try:
            if self._kgraph is None:
                raise RuntimeError("KGraph instance is None")

            meta["kgraph_class"] = type(self._kgraph).__name__

            # Route to the right check based on backend type
            if hasattr(self._kgraph, "_dsn"):
                fact_count = self._check_aurora(meta)
            else:
                fact_count = self._check_duckdb(meta)

            meta["fact_count"] = fact_count

            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.HEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                metadata=meta,
            )
        except Exception as exc:
            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.UNHEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                error=str(exc),
                metadata=meta,
            )


class ToolRegistryHealthProbe(HealthCheckable):
    """Health probe for the ToolRegistry.

    Checks:
    - Registry is instantiated
    - Reports tool count and tool names
    - Marks degraded if no tools are loaded
    """

    def __init__(self, registry: Any):
        self._registry = registry

    @property
    def health_component_name(self) -> str:
        return "tool_registry"

    def check_health(self, *, timeout: float = 5.0) -> ComponentHealth:
        t0 = time.perf_counter()
        meta: dict[str, Any] = {}
        try:
            if self._registry is None:
                raise RuntimeError("ToolRegistry is None")

            tools = self._registry.list_tools()
            meta["tool_count"] = len(tools)
            meta["tool_names"] = tools[:20]
            if len(tools) > 20:
                meta["truncated"] = True

            status = ComponentStatus.HEALTHY if tools else ComponentStatus.DEGRADED
            if not tools:
                meta["warning"] = "No tools loaded"

            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=status,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                metadata=meta,
            )
        except Exception as exc:
            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.UNHEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                error=str(exc),
                metadata=meta,
            )


class OrchestratorHealthProbe(HealthCheckable):
    """Health probe for the Orchestrator.

    Checks:
    - Orchestrator singleton is initialized
    - Supervisor agent was compiled successfully
    - LLM is set
    - Optionally aggregates sub-component health from child probes
    """

    def __init__(
        self,
        orchestrator: Any,
        child_probes: Optional[List[HealthCheckable]] = None,
    ):
        self._orchestrator = orchestrator
        self._child_probes = child_probes or []

    @property
    def health_component_name(self) -> str:
        return "orchestrator"

    def check_health(self, *, timeout: float = 5.0) -> ComponentHealth:
        t0 = time.perf_counter()
        meta: dict[str, Any] = {}
        try:
            if self._orchestrator is None:
                raise RuntimeError("Orchestrator is None")

            meta["initialized"] = getattr(self._orchestrator.__class__, "_initialized", False)
            meta["has_supervisor"] = self._orchestrator.supervisor is not None
            meta["has_llm"] = self._orchestrator.base_llm is not None
            meta["tool_count"] = len(getattr(self._orchestrator, "master_tools", []))

            model_name = getattr(
                self._orchestrator.base_llm,
                "model_name",
                getattr(self._orchestrator.base_llm, "model", "unknown"),
            )
            meta["model"] = str(model_name)

            if not meta["has_supervisor"]:
                status = ComponentStatus.DEGRADED
                meta["warning"] = "Supervisor agent not compiled"
            elif not meta["has_llm"]:
                status = ComponentStatus.UNHEALTHY
            else:
                status = ComponentStatus.HEALTHY

            child_results = []
            for probe in self._child_probes:
                child_health = probe.check_health(timeout=timeout)
                child_results.append(child_health.model_dump())
                if child_health.status == ComponentStatus.UNHEALTHY:
                    status = ComponentStatus.DEGRADED

            if child_results:
                meta["sub_components"] = child_results

            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=status,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                metadata=meta,
            )
        except Exception as exc:
            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.UNHEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                error=str(exc),
                metadata=meta,
            )


class CeleryHealthProbe(HealthCheckable):
    """Health probe for Celery workers and broker.

    Checks:
    - Workers respond to ``ping`` (ensures broker reachability and workers alive)
    - Aggregates active/reserved/scheduled task counts
    - Lists active queues and worker hostnames
    - Returns sanitized broker/result backend URLs for visibility
    """

    def __init__(self, app: Any, name: str = "celery"):
        self._app = app
        self._name = name

    @property
    def health_component_name(self) -> str:
        return self._name

    @staticmethod
    def _sanitize_url(url: str | None) -> str:
        if not url:
            return ""
        try:
            parsed = urlparse(url)
            host = parsed.hostname or ""
            port = f":{parsed.port}" if parsed.port else ""
            path = parsed.path or ""
            return f"{parsed.scheme}://{host}{port}{path}"
        except Exception:
            return "redacted"

    def _count_tasks(self, mapping: dict[str, list] | None) -> int:
        if not mapping:
            return 0
        total = 0
        for tasks in mapping.values():
            try:
                total += len(tasks or [])
            except Exception:
                continue
        return total

    def check_health(self, *, timeout: float = 5.0) -> ComponentHealth:
        t0 = time.perf_counter()
        meta: dict[str, Any] = {}
        try:
            if self._app is None:
                raise RuntimeError("Celery app is None")

            inspector = self._app.control.inspect(timeout=timeout)
            if inspector is None:
                raise RuntimeError("Failed to create Celery inspector")

            # Ping workers (broadcast). Returns dict hostname -> reply.
            ping = inspector.ping() or {}
            workers_online = sorted(ping.keys())
            meta["workers_online"] = workers_online
            meta["worker_count"] = len(workers_online)

            active = inspector.active() or {}
            reserved = inspector.reserved() or {}
            scheduled = inspector.scheduled() or {}
            meta["active_tasks_total"] = self._count_tasks(active)
            meta["reserved_tasks_total"] = self._count_tasks(reserved)
            meta["scheduled_tasks_total"] = self._count_tasks(scheduled)

            active_queues = inspector.active_queues() or {}
            queues: set[str] = set()
            for qlist in active_queues.values():
                for q in qlist or []:
                    name = q.get("name") if isinstance(q, dict) else None
                    if name:
                        queues.add(name)
            meta["queues"] = sorted(queues)

            # Broker/result backend (sanitized)
            meta["broker"] = self._sanitize_url(getattr(self._app.conf, "broker_url", ""))
            backend_url = getattr(self._app.conf, "result_backend", "")
            if backend_url:
                meta["result_backend"] = self._sanitize_url(str(backend_url))

            status = ComponentStatus.HEALTHY
            error = None
            if meta["worker_count"] == 0:
                status = ComponentStatus.UNHEALTHY
                error = "No Celery workers responded to ping"

            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=status,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                error=error,
                metadata=meta,
            )
        except Exception as exc:
            latency = (time.perf_counter() - t0) * 1000
            return ComponentHealth(
                name=self.health_component_name,
                status=ComponentStatus.UNHEALTHY,
                latency_ms=round(latency, 2),
                last_checked=datetime.now(timezone.utc),
                error=str(exc),
                metadata=meta,
            )
