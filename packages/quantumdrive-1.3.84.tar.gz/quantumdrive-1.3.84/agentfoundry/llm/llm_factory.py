__author__ = "Chris Steel"
__copyright__ = "Copyright 2023, Syntheticore Corporation"
__credits__ = ["Chris Steel"]
__date__ = "2/9/2025"
__license__ = "Syntheticore Confidential"
__version__ = "1.0"
__email__ = "csteel@syntheticore.com"
__status__ = "Production"

import logging
import os
import threading
import warnings

from langchain_openai import ChatOpenAI

from agentfoundry.llm.ollama_llm import OllamaLLM
from agentfoundry.utils.agent_config import AgentConfig

logger = logging.getLogger(__name__)


class LLMFactory:
    """Factory for creating LLM clients, with caching per (provider, model, api_key)."""

    _CACHE: dict[tuple[str, str, str], object] = {}
    _LOCK = threading.Lock()

    @staticmethod
    def get_llm_model(
        config: AgentConfig = None,
        provider: str | None = None,
        llm_model: str | None = None,
        api_base: str | None = None,
    ):
        """
        Returns an instance of an LLM based on configuration.

        Args:
            config: AgentConfig object containing credentials and settings.
                    Required for new code. If None, falls back to legacy config with deprecation warning.
            provider: Explicit provider override (e.g. 'openai').
            llm_model: Explicit model override (e.g. 'gpt-4').
            api_base: Explicit API base URL override (e.g. Ollama host).

        Returns:
            LLM instance (ChatOpenAI, OllamaLLM, etc.)
        """
        # Handle backward compatibility
        if config is None:
            warnings.warn(
                "LLMFactory.get_llm_model() without config is deprecated. "
                "Pass AgentConfig explicitly or use AgentConfig.from_legacy_config().",
                DeprecationWarning,
                stacklevel=2
            )
            config = AgentConfig.from_legacy_config()
        
        # Extract configuration
        provider = provider or config.llm.provider
        llm_model = llm_model or config.llm.model_name
        api_key_val = config.get_api_key(provider) or ""
        api_base = api_base or config.llm.api_base

        # Create a cache key that includes the API key (hashed or raw) to prevent tenant leakage
        cache_key = (str(provider), str(llm_model), str(api_key_val))

        if cache_key in LLMFactory._CACHE:
            logger.debug("LLMFactory cache hit: provider=%s model=%s", provider, llm_model)
            return LLMFactory._CACHE[cache_key]

        with LLMFactory._LOCK:
            # Double-checked locking
            if cache_key in LLMFactory._CACHE:
                logger.debug("LLMFactory cache hit (lock): provider=%s model=%s", provider, llm_model)
                return LLMFactory._CACHE[cache_key]

            logger.info("Creating LLM: provider=%s model=%s", provider, llm_model)

            if provider == "ollama":
                model_name = llm_model or "gemma3:27b"
                host = api_base or "http://127.0.0.1:11434"
                try:
                    llm = OllamaLLM(model=model_name, base_url=host)
                except Exception as e:
                    logger.error(f"Failed to create ChatOllama LLM: {e}")
                    raise

            elif provider == "openai":
                if not api_key_val:
                    raise ValueError("OPENAI_API_KEY must be provided for OpenAI LLM.")

                # Temperature handling
                restricted_prefixes = ("o1", "o2", "o3", "o4", "gpt-4o")
                temp_cfg = os.getenv("TEMPERATURE", "")
                pass_temperature = True
                if isinstance(llm_model, str) and llm_model.lower().startswith(restricted_prefixes):
                    pass_temperature = False
                if temp_cfg in (None, ""):
                    pass_temperature = False

                try:
                    temperature = float(temp_cfg) if pass_temperature else None
                    if temperature is None:
                        llm = ChatOpenAI(model=llm_model, api_key=api_key_val)
                    else:
                        llm = ChatOpenAI(model=llm_model, api_key=api_key_val, temperature=temperature)
                except Exception as e:
                    logger.error(f"Failed to create OpenAI LLM: {e}")
                    raise

            elif provider == "grok":
                if not api_key_val:
                    raise ValueError("XAI_API_KEY must be provided for Grok LLM.")
                from agentfoundry.llm.grok_chatxai_logging import LoggingChatXAI
                llm = LoggingChatXAI(model=llm_model, api_key=api_key_val)

            elif provider == "gemini":
                from agentfoundry.llm.gemini_llm import GeminiLLM
                if not api_key_val:
                    raise ValueError("GEMINI_API_KEY must be provided for Gemini LLM.")
                llm = GeminiLLM(model=llm_model, api_key=api_key_val)

            else:
                raise ValueError(f"Unknown LLM provider: {provider}")

            LLMFactory._verify_llm(llm, str(provider), str(llm_model))
            LLMFactory._CACHE[cache_key] = llm
            return llm

    @staticmethod
    def _verify_llm(llm, provider: str, model: str) -> None:
        import time as _time
        from agentfoundry.utils.exceptions import InitializationError
        from langchain_core.messages import HumanMessage

        if llm is None:
            raise InitializationError("LLMFactory", f"LLM creation returned None for {provider}/{model}")
        if not callable(getattr(llm, 'invoke', None)):
            raise InitializationError("LLMFactory", f"LLM {type(llm).__name__} missing invoke()")
        logger.info("LLM ping: verifying %s/%s ...", provider, model)
        t0 = _time.perf_counter()
        try:
            llm.invoke([HumanMessage(content="ping")])
        except Exception as exc:
            dt = int((_time.perf_counter() - t0) * 1000)
            logger.error("LLM ping failed for %s/%s after %dms: %s", provider, model, dt, exc)
            raise InitializationError(
                "LLMFactory",
                f"LLM ping failed for {provider}/{model}: {exc}",
                cause=exc,
            ) from exc
        dt = int((_time.perf_counter() - t0) * 1000)
        logger.info("LLM ping ok: %s/%s responded in %dms", provider, model, dt)

    @staticmethod
    def get_llm_by_role(config: AgentConfig = None, role: str = "reasoning"):
        """Return an LLM instance for the given role.

        Roles:
            "reasoning" (default) -> config.llm  (primary model)
            "formatting"          -> config.llm_formatter (structured-output model)

        If no formatter config is present, falls back to the primary model.
        """
        if config is None:
            from agentfoundry.utils.agent_config import AgentConfig as _AC
            config = _AC.from_legacy_config()

        if role == "formatting" and config.llm_formatter is not None:
            fmt = config.llm_formatter
            logger.info("get_llm_by_role: role=%s provider=%s model=%s", role, fmt.provider, fmt.model_name)
            return LLMFactory.get_llm_model(
                config=config,
                provider=fmt.provider,
                llm_model=fmt.model_name,
                api_base=fmt.api_base,
            )
        logger.debug("get_llm_by_role: role=%s using primary LLM", role)
        return LLMFactory.get_llm_model(config=config)

    @classmethod
    def reset(cls) -> None:
        """Clear all cached LLM instances, allowing reconfiguration."""
        with cls._LOCK:
            cls._CACHE.clear()
        logger.info("LLMFactory: all cached LLM instances cleared")

    @classmethod
    def reset_provider(cls, provider: str) -> None:
        """Remove cached LLM instances for a specific provider."""
        lower = provider.lower()
        with cls._LOCK:
            keys = [k for k in cls._CACHE if k[0].lower() == lower]
            for k in keys:
                del cls._CACHE[k]
        if keys:
            logger.info("LLMFactory: cleared %d cached instance(s) for provider '%s'", len(keys), lower)


if __name__ == "__main__":
    # Quick test
    logging.basicConfig(level=logging.INFO)
    try:
        openai_llm = LLMFactory.get_llm_model(provider="openai")
        print("OpenAI LLM:", openai_llm)
    except Exception as e:
        print(f"Skipping OpenAI test: {e}")