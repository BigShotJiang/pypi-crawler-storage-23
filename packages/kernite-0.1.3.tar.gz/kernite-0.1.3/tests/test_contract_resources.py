from __future__ import annotations

import json
from pathlib import Path

from kernite.contracts import (
    load_execute_request_template,
    load_execute_vectors_v1,
    load_policy_version_template,
    load_reason_codes_v1,
)


ROOT = Path(__file__).resolve().parents[1]


def _read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_packaged_execute_vectors_match_repository_docs() -> None:
    packaged = load_execute_vectors_v1()
    docs = _read_json(ROOT / "docs" / "conformance" / "v1" / "execute_vectors.json")

    assert packaged
    assert packaged == docs


def test_packaged_reason_codes_match_repository_docs() -> None:
    packaged = load_reason_codes_v1()
    docs = _read_json(ROOT / "docs" / "conformance" / "v1" / "reason_codes_v1.json")

    assert packaged
    assert packaged == docs


def test_packaged_templates_match_repository_templates() -> None:
    packaged_execute_request = load_execute_request_template()
    packaged_policy_version = load_policy_version_template()

    execute_request = _read_json(ROOT / "templates" / "execute-request.template.json")
    policy_version = _read_json(ROOT / "templates" / "policy-version.template.json")

    assert packaged_execute_request == execute_request
    assert packaged_policy_version == policy_version
