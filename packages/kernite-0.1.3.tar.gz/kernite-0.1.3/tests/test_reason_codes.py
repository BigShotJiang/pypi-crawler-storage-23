from kernite.contracts import load_execute_vectors_v1, load_reason_codes_v1
from kernite.reason_codes import REASON_CODE_DICTIONARY_V1, reason_code_meaning


def test_reason_code_dictionary_v1_has_no_empty_definitions():
    assert REASON_CODE_DICTIONARY_V1
    for code, meaning in REASON_CODE_DICTIONARY_V1.items():
        assert code
        assert meaning


def test_reason_code_lookup_returns_none_for_unknown():
    assert reason_code_meaning("unknown_code") is None


def test_all_conformance_vector_reason_codes_are_declared():
    vectors = load_execute_vectors_v1()

    used_codes = {
        code
        for vector in vectors
        for code in vector.get("expect", {}).get("reason_codes", [])
    }
    assert used_codes <= set(REASON_CODE_DICTIONARY_V1)


def test_reason_code_dictionary_matches_packaged_contract_json():
    assert REASON_CODE_DICTIONARY_V1 == load_reason_codes_v1()
