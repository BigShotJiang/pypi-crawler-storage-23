# SBOM Policy

## Goal

Generate and publish Software Bill of Materials (SBOM) for each release in CycloneDX format.

## Requirements

- SBOM must be generated in CI.
- Format: CycloneDX JSON.
- SBOM artifact must be attached to CI run and release records.
- Security scans must run on pull requests and protected branches.

## Coverage

- Python dependencies
- Node dependencies
- Transitive dependencies where available via lockfiles

## Operational Rules

- SBOM generation failure blocks release workflows.
- Security findings from dependency scans must be triaged before release.
- SBOM artifacts should be retained for audit and incident response.

