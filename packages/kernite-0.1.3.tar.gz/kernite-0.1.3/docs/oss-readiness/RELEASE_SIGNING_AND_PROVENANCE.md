# Release Signing and Provenance

## Goal

Make releases verifiable and tamper-evident.

## Policy

- Release tags must be signed by maintainers.
- Release artifacts must have provenance attestation.
- Provenance must be generated in CI with OIDC-backed identity.

## Minimum Requirements

1. Signed tags
- maintainers sign release tags before pushing
- unsigned release tags are invalid for public release

2. Build provenance
- CI generates build provenance attestation for release artifacts
- attestation references commit SHA and tag

3. Verification
- maintainers verify signature and attestation before announcing release

## Suggested Verification Checklist

- tag signature valid and trusted
- artifact checksum matches published checksum
- attestation subject matches artifact and release commit
- advisory links (if security release) are present

