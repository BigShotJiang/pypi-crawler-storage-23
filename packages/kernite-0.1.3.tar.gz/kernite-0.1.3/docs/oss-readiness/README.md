# OSS Readiness

This directory contains baseline operational artifacts for open source trust:

- vulnerability handling and disclosure workflow
- release signing/provenance policy
- SBOM policy and CI expectations

Files:
- `docs/oss-readiness/VULNERABILITY_DISCLOSURE.md`
- `docs/oss-readiness/RELEASE_SIGNING_AND_PROVENANCE.md`
- `docs/oss-readiness/SBOM_POLICY.md`
