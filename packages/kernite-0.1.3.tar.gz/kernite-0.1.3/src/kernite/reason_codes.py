from __future__ import annotations

from typing import Final

from kernite.contracts import load_reason_codes_v1

# v1 reason-code semantics that are treated as stable compatibility surface.
REASON_CODE_DICTIONARY_V1: Final[dict[str, str]] = load_reason_codes_v1()


def reason_code_meaning(code: str) -> str | None:
    return REASON_CODE_DICTIONARY_V1.get(str(code))
