# Skst Safe Build
[![PyPI version](https://badge.fury.io/py/skst_safe_build.svg)](https://badge.fury.io/py/skst_safe_build)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

# skst_safe_build
A Python package for safely building and packaging CPP based Python projects. It provides tools and utilities to ensure that your build process works even if a C compiler is not available.