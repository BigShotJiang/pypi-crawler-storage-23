import shutil
import subprocess


def has_compiler(name: str) -> bool:
    if shutil.which(name) is None:
        return False
    try:
        subprocess.run(
            [name, "--version"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True,
        )
        return True
    except Exception:
        return False


has_cpp_compiler = any(
    has_compiler(c) for c in ["g++", "clang++", "cl"]
)

if has_cpp_compiler:
    from scikit_build_core.build import *
else:
    from setuptools.build_meta import *


