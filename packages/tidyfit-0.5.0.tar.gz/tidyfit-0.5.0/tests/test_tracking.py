from tidyfit.tracking import log_experiment


def test_log_experiment(tmp_path):
    p = tmp_path / "exp.jsonl"
    log_experiment(p, {"metric": 0.9})
    txt = p.read_text().strip()
    assert "metric" in txt
