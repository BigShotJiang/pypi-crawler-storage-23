from tidyfit.model_io import save_model, load_model


def test_model_io(tmp_path):
    obj = {"a": 1}
    p = save_model(obj, tmp_path / "m.pkl", metadata={"v": "1"})
    out = load_model(p)
    assert out == obj
    assert (tmp_path / "m.pkl.meta.json").exists()
