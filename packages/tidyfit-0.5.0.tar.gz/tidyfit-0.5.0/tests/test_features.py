import pandas as pd
from tidyfit.features import interaction_terms, polynomial_features, drop_low_variance


def test_feature_builders():
    df = pd.DataFrame({"a": [1, 2, 3], "b": [2, 3, 4], "c": [1, 1, 1]})
    out = interaction_terms(df, ["a", "b"])
    assert "a__x__b" in out.columns
    out2 = polynomial_features(df, ["a"], degree=3)
    assert "a__pow3" in out2.columns
    out3 = drop_low_variance(df)
    assert "c" not in out3.columns
