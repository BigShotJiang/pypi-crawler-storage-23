from tidyfit.metrics import (
    classification_report_per_class,
    threshold_sweep,
    metric_confidence_interval,
    calibration_table,
)


def test_metrics_suite():
    y = [0, 1, 1, 0, 1]
    yp = [0, 1, 0, 0, 1]
    rep = classification_report_per_class(y, yp)
    assert set(rep.columns) >= {"class", "precision", "recall", "f1"}
    sweep = threshold_sweep(y, [0.1, 0.9, 0.4, 0.2, 0.8], [0.5])
    assert len(sweep) == 1
    m, lo, hi = metric_confidence_interval([0.8, 0.9, 1.0])
    assert lo <= m <= hi
    cal = calibration_table(y, [0.1, 0.9, 0.4, 0.2, 0.8], bins=5)
    assert cal["count"].sum() == 5
