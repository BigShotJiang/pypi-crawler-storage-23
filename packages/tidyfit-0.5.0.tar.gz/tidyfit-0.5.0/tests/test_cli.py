import pandas as pd
from tidyfit.cli import main
import sys


def test_cli_data_summary(tmp_path, capsys):
    p = tmp_path / "d.csv"
    pd.DataFrame({"a": [1, 2], "y": [0, 1], "y_score": [0.2, 0.8]}).to_csv(
        p, index=False
    )

    sys.argv = ["tidyfit", "data-summary", str(p)]
    main()
    assert "a" in capsys.readouterr().out

    sys.argv = ["tidyfit", "stratified-split", str(p), "--target", "y"]
    main()
    assert "train=" in capsys.readouterr().out

    sys.argv = [
        "tidyfit",
        "curve-data",
        str(p),
        "--label-col",
        "y",
        "--score-col",
        "y_score",
    ]
    main()
    assert "roc_points=" in capsys.readouterr().out

    out_dir = tmp_path / "curves"
    sys.argv = [
        "tidyfit",
        "curve-data",
        str(p),
        "--label-col",
        "y",
        "--score-col",
        "y_score",
        "--out-dir",
        str(out_dir),
    ]
    main()
    txt = capsys.readouterr().out
    assert "saved=" in txt
    assert (out_dir / "roc_points.csv").exists()
    assert (out_dir / "pr_points.csv").exists()
