from tidyfit.reproducibility import set_global_seed, snapshot_environment


def test_repro_tools(tmp_path):
    set_global_seed(123)
    p = snapshot_environment(tmp_path / "env.json")
    assert p.exists()
