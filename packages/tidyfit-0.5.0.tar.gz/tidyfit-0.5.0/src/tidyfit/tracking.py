from __future__ import annotations

from pathlib import Path
import json
from datetime import datetime, UTC


def log_experiment(path: str | Path, payload: dict) -> None:
    """Append experiment row to JSONL."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    row = {"ts": datetime.now(UTC).isoformat(), **payload}
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row) + "\n")
