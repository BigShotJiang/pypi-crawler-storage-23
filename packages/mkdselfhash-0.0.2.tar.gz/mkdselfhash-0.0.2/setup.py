import setuptools

setuptools.setup(
            name='python-markdown-selfhash',
            install_requires=['markdown>=3'],
            tests_require=['mkdocs'],
            py_modules=['mkdselfhash'],
            version="0.0.2",
            )
