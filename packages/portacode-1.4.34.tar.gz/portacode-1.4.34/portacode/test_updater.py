from unittest import TestCase
from unittest.mock import patch

from portacode.updater import build_pip_install_command


class UpdaterCommandTests(TestCase):
    @patch("portacode.updater._running_in_virtualenv", return_value=True)
    def test_venv_omits_user_flag_for_non_root(self, _mock_venv):
        with patch("portacode.updater.sys.executable", "/opt/portacode-venv/bin/python"):
            with patch("portacode.updater.os.geteuid", return_value=1000):
                cmd = build_pip_install_command(version="1.4.34.dev7")

        self.assertEqual(
            cmd,
            [
                "/opt/portacode-venv/bin/python",
                "-m",
                "pip",
                "install",
                "--upgrade",
                "portacode==1.4.34.dev7",
            ],
        )

    @patch("portacode.updater._running_in_virtualenv", return_value=False)
    def test_non_root_outside_venv_uses_user_flag(self, _mock_venv):
        with patch("portacode.updater.sys.executable", "/usr/bin/python3"):
            with patch("portacode.updater.os.geteuid", return_value=1000):
                cmd = build_pip_install_command(version="1.4.34.dev7")

        self.assertEqual(cmd[-1], "--user")
        self.assertEqual(cmd[:6], ["/usr/bin/python3", "-m", "pip", "install", "--upgrade", "portacode==1.4.34.dev7"])

    @patch("portacode.updater._running_in_virtualenv", return_value=False)
    @patch("portacode.updater.shutil.which", return_value="/usr/bin/sudo")
    def test_root_with_sudo_user_outside_venv_switches_to_invoking_user(self, _mock_which, _mock_venv):
        with patch("portacode.updater.sys.executable", "/usr/bin/python3"):
            with patch("portacode.updater.os.geteuid", return_value=0):
                with patch.dict("portacode.updater.os.environ", {"SUDO_USER": "ubuntu"}, clear=False):
                    cmd = build_pip_install_command(version="1.4.34.dev7")

        self.assertEqual(cmd[:4], ["sudo", "-u", "ubuntu", "-H"])
        self.assertEqual(cmd[-1], "--user")
