"""Galactic Bakeshop Django project."""
