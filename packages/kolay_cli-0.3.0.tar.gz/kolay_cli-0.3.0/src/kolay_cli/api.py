import requests
from typing import Dict, Any, Optional

from . import config

class APIError(Exception):
    pass

class KolayClient:
    def __init__(self, token: Optional[str] = None, base_url: Optional[str] = None):
        self.token = token or config.get_api_token()
        self.base_url = (base_url or config.get_base_url()).rstrip("/")
        
        if not self.token:
            raise APIError("API token is required. Please set it using 'kolay auth login' or the KOLAY_API_TOKEN environment variable.")
        
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Accept-Language": "en"
        })

    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("GET", endpoint, params=params)

    def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("POST", endpoint, json=data)

    def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("PUT", endpoint, json=data)

    def delete(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("DELETE", endpoint, params=params)

    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            # Most Kolay API responses return a json payload
            if response.content:
                return response.json()
            return {}
        except requests.exceptions.HTTPError as e:
            msg = f"API Error: {e.response.status_code}"
            try:
                error_data = e.response.json()
                if "message" in error_data:
                    msg += f" - {error_data['message']}"
            except Exception:
                msg += f" - {e.response.text}"
            raise APIError(msg)
        except Exception as e:
            raise APIError(f"Request failed: {str(e)}")
