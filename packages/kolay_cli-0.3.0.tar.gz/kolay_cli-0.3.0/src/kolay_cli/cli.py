import typer

from . import __version__
from .commands import auth, person, leave, transaction
from rich.console import Console

LOGO = """\b
[bold cyan]                        +************                                                               [/bold cyan]
[bold cyan]                       +*+        **+                                                               [/bold cyan]
[bold cyan]                      +*+       +*+      %%               #%%                                       [/bold cyan]
[bold cyan]                     +*+       +*+       %%   *#*  #%%#   #%%   #%%#*#*+**    **+                   [/bold cyan]
[bold cyan]                   +**+       +*+        %% #%%* %%%##%%% #%% %%%#*%%%% %%#  #%%                    [/bold cyan]
[bold cyan]                    **+      +**+        %%%%#  %%#    %%##%%#%%    %%%  %%##%%#                    [/bold cyan]
[bold cyan]                     +*+    +*++*+       %%#%%# %%%    %%##%%*%%    #%%   %%%%#                     [/bold cyan]
[bold cyan]                      +*+  **   +*+      %%  #%% *%%%%%%# #%% #%%%%%%%%   *%%%                      [/bold cyan]
[bold cyan]                       +*+**      **+                                     #%%                       [/bold cyan]
[bold cyan]                        +************                                   #%%%                    [/bold cyan]

Kolay CLI - A command-line interface for the Kolay IK API.
"""

app = typer.Typer(
    no_args_is_help=True,
    rich_markup_mode="rich"
)
console = Console()

app.add_typer(auth.app, name="auth")
app.add_typer(person.app, name="person")
app.add_typer(leave.app, name="leave")
app.add_typer(transaction.app, name="transaction")

@app.callback(invoke_without_command=True, help=LOGO)
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Print the CLI version.",
        is_eager=True,
    )
):
    if version:
        console.print(f"Kolay CLI version: [bold cyan]{__version__}[/bold cyan]")
        raise typer.Exit()

if __name__ == "__main__":
    app()
