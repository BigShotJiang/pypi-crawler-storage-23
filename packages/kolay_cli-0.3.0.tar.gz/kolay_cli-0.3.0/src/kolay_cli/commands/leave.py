import typer
from typing import Optional
from rich.console import Console
from rich.table import Table
import json

from ..api import KolayClient, APIError

app = typer.Typer(help="Manage leave records in Kolay.")
console = Console()


@app.command(name="list")
def list_leaves(
    status: str = typer.Option("approved", help="Filter by status: approved, waiting, rejected, cancelled"),
    start_date: Optional[str] = typer.Option(None, help="Start date filter (YYYY-MM-DD HH:MM:SS). Defaults to Jan 1 of current year."),
    end_date: Optional[str] = typer.Option(None, help="End date filter (YYYY-MM-DD HH:MM:SS). Defaults to Dec 31 of current year."),
    person_id: Optional[str] = typer.Option(None, help="Filter by person ID"),
    limit: int = typer.Option(100, help="Max number of records to return"),
    include_inactive: bool = typer.Option(False, help="Include inactive employees"),
):
    """
    List leave records. Filter by status, date range, or person.
    """
    from datetime import datetime

    try:
        client = KolayClient()

        # API requires startDate and endDate — default to current year
        now = datetime.now()
        if not start_date:
            start_date = f"{now.year}-01-01 00:00:00"
        if not end_date:
            end_date = f"{now.year}-12-31 23:59:59"

        params: dict = {
            "status": status,
            "startDate": start_date,
            "endDate": end_date,
            "limit": limit,
        }
        if include_inactive:
            params["include_inactive_employees"] = "true"
        if person_id:
            params["personId"] = person_id

        console.print(f"Fetching leave records ({status}, {start_date[:10]} → {end_date[:10]})...")
        response = client.get("v2/leave/list", params=params)

        data = response.get("data", [])
        if not data:
            console.print("[yellow]No leave records found.[/yellow]")
            return

        table = Table(title="Leave Records")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Person", style="magenta")
        table.add_column("Type", style="yellow")
        table.add_column("Start", style="green")
        table.add_column("End", style="green")
        table.add_column("Status", style="bold")

        for leave in data:
            lid = str(leave.get("id", "N/A"))

            person = leave.get("person", {})
            if isinstance(person, dict):
                person_name = person.get("name", "N/A")
            else:
                person_name = str(leave.get("personId", "N/A"))

            leave_type = leave.get("type", leave.get("leaveType", {}))
            type_name = leave_type.get("name", "N/A") if isinstance(leave_type, dict) else str(leave_type)

            start = leave.get("startDate", "N/A")
            end = leave.get("endDate", "N/A")
            lstatus = leave.get("status", "N/A")

            status_color = {
                "approved": "[green]approved[/green]",
                "waiting": "[yellow]waiting[/yellow]",
                "rejected": "[red]rejected[/red]",
                "cancelled": "[dim]cancelled[/dim]",
            }.get(str(lstatus).lower(), lstatus)

            table.add_row(lid, person_name, type_name, start, end, status_color)

        console.print(table)
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)


@app.command(name="view")
def view_leave(
    leave_id: str = typer.Argument(..., help="ID of the leave record to view"),
):
    """
    View the details of a specific leave record.
    """
    try:
        client = KolayClient()
        response = client.get(f"v2/leave/view/{leave_id}")

        data = response.get("data", {})
        if not data:
            console.print(f"[yellow]Leave record '{leave_id}' not found or permission denied.[/yellow]")
            return

        console.print(f"\n[bold cyan]Leave Record ({leave_id})[/bold cyan]")
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)


@app.command(name="create")
def create_leave(
    person_id: Optional[str] = typer.Option(None, help="Person ID to create leave for"),
    leave_type_id: Optional[str] = typer.Option(None, help="Leave type ID (auto-listed if omitted)"),
    start_date: Optional[str] = typer.Option(None, help="Start datetime (YYYY-MM-DD HH:MM:SS)"),
    end_date: Optional[str] = typer.Option(None, help="End datetime (YYYY-MM-DD HH:MM:SS)"),
    comment: Optional[str] = typer.Option(None, help="Optional comment"),
    replacement_person_id: Optional[str] = typer.Option(None, help="Optional replacement person ID"),
):
    """
    Create a new leave record. Shows available leave types for the person.
    """

    try:
        client = KolayClient()

        # 1. Get person ID
        if not person_id:
            person_id = typer.prompt("Person ID")

        # 2. Fetch available leave types for this person
        if not leave_type_id:
            console.print(f"\nFetching available leave types for person {person_id}...")
            try:
                status_resp = client.get(f"v2/person/leave-status/{person_id}")
                leave_types = status_resp.get("data", [])
            except APIError:
                leave_types = []

            if leave_types:
                table = Table(title="Available Leave Types", header_style="bold cyan")
                table.add_column("#", style="bold white", width=3)
                table.add_column("Name")
                table.add_column("Remaining", justify="right", style="green")
                table.add_column("ID", style="dim")

                for i, lt in enumerate(leave_types, 1):
                    name = lt.get("name", "N/A")
                    if lt.get("primary"):
                        name = f"⭐ {name}"
                    unused = lt.get("unused")
                    remaining = str(unused) if unused is not None else "∞"
                    table.add_row(str(i), name, remaining, lt.get("id", "N/A"))

                console.print(table)

                choice = typer.prompt("Pick a leave type (enter # or ID)")
                # If user entered a number, map it
                try:
                    idx = int(choice) - 1
                    if 0 <= idx < len(leave_types):
                        leave_type_id = leave_types[idx].get("id")
                    else:
                        leave_type_id = choice
                except ValueError:
                    leave_type_id = choice
            else:
                leave_type_id = typer.prompt("Leave type ID")

        # 3. Get dates
        if not start_date:
            start_date = typer.prompt("Start datetime (YYYY-MM-DD HH:MM:SS)")
        if not end_date:
            end_date = typer.prompt("End datetime (YYYY-MM-DD HH:MM:SS)")

        # 4. Build payload and create
        params: dict = {
            "personId": person_id,
            "leaveTypeId": leave_type_id,
            "startDate": start_date,
            "endDate": end_date,
        }
        if comment:
            params["comment"] = comment
        if replacement_person_id:
            params["replacementPersonId"] = replacement_person_id

        console.print("Creating leave record...")
        response = client.post("v2/leave/create", data=params)

        data = response.get("data", {})
        leave_id = data.get("id", "N/A") if isinstance(data, dict) else "N/A"
        console.print(f"[bold green]Leave record created![/bold green] ID: [cyan]{leave_id}[/cyan]")
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)

