import typer
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from ..api import KolayClient, APIError
from datetime import datetime

app = typer.Typer(help="Manage transactions (advances, bonuses, overtime, etc.) in Kolay.")
console = Console()

@app.command(name="list")
def list_transactions(
    page: int = typer.Option(1, help="Page number"),
    person_id: Optional[str] = typer.Option(None, help="Filter by person ID"),
    type: Optional[str] = typer.Option(None, help="Filter by type (e.g. advancePayment, overtime, bonus)"),
    status: Optional[str] = typer.Option(None, help="Filter by status (waiting, approved, rejected)")
):
    """
    List transactions from the Kolay API.
    """
    try:
        client = KolayClient()
        console.print(f"Fetching transactions (page {page})...")
        
        payload = {
            "page": page,
            "limit": 20,
            "startDate": "2000-01-01",
            "endDate": "2100-12-31"
        }
        if person_id:
            payload["personId"] = person_id
        if type:
            payload["type"] = type
        if status:
            payload["status"] = status
            
        response = client.post("v2/transaction/list", data=payload)
        data_block = response.get("data", {})
        data = data_block.get("items", []) if isinstance(data_block, dict) else (data_block if isinstance(data_block, list) else [])
        
        if not data:
            console.print("[yellow]No transactions found.[/yellow]")
            return

        table = Table(title="Transactions")
        table.add_column("ID", style="dim")
        table.add_column("Person")
        table.add_column("Type")
        table.add_column("Amount", justify="right")
        table.add_column("Date")
        table.add_column("Status")

        for trx in data:
            trx_id = str(trx.get("id", "N/A"))
            
            person = trx.get("person", {})
            if isinstance(person, dict):
                person_name = f"{person.get('firstName', '')} {person.get('lastName', '')}".strip() or str(person.get("id", "N/A"))
            else:
                person_name = str(trx.get("personId", "N/A"))

            trx_type = trx.get("type", "N/A")
            amount = f"{trx.get('amount', 0)} {trx.get('currency', 'TL')}"
            date = trx.get("date", "N/A")
            
            status_val = trx.get("status", "N/A")
            status_color = "yellow" if status_val == "waiting" else "green" if status_val == "approved" else "red"
            status_str = f"[{status_color}]{status_val}[/{status_color}]"
            
            table.add_row(trx_id, person_name, trx_type, amount, date, status_str)

        console.print(table)

    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)

@app.command(name="view")
def view_transaction(transaction_id: str = typer.Argument(..., help="ID of the transaction to view")):
    """
    View details of a specific transaction.
    """
    try:
        client = KolayClient()
        console.print(f"Fetching transaction {transaction_id}...")
        response = client.get(f"v2/transaction/view/{transaction_id}")
        
        trx = response.get("data", {})
        if not trx:
            console.print(f"[yellow]Transaction {transaction_id} not found.[/yellow]")
            return
            
        table = Table(show_header=False, box=None)
        
        for key, value in trx.items():
            if not isinstance(value, (dict, list)):
                table.add_row(f"[bold]{key}:[/bold]", str(value))
        
        console.print(Panel(table, title=f"Transaction: {trx.get('type', 'N/A')}", border_style="cyan", expand=False))
        
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)

@app.command(name="delete")
def delete_transaction(transaction_id: str = typer.Argument(..., help="ID of the transaction to delete")):
    """
    Delete a specific transaction.
    """
    try:
        client = KolayClient()
        console.print(f"Deleting transaction {transaction_id}...")
        client.delete(f"v2/transaction/delete/{transaction_id}")
        console.print("[bold green]Success![/bold green] Transaction deleted.")
        
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)

@app.command(name="create")
def create_transaction(
    person_id: str = typer.Option(..., "--person-id", "-p", help="ID of the person"),
    type: str = typer.Option(..., "--type", "-t", help="Type: advancePayment, overtime, bonus, premium, otherCut, militaryBenefit, nationalHolidayBenefit, fuelAllowanceBenefit"),
    amount: str = typer.Option(..., "--amount", "-a", help="Amount"),
    currency: str = typer.Option("TL", "--currency", "-c", help="Currency (e.g. TL, USD)"),
    date: str = typer.Option(None, "--date", "-d", help="Date in YYYY-MM-DD format (defaults to today)"),
    description: Optional[str] = typer.Option(None, "--desc", help="Description"),
    installment_plan: Optional[str] = typer.Option(None, "--installments", help="Installment plan (required for advancePayment)"),
    status: str = typer.Option("waiting", "--status", help="Status: waiting, approved, rejected")
):
    """
    Create a new transaction.
    """
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")
        
    payload = {
        "personId": person_id,
        "type": type,
        "amount": amount,
        "currency": currency,
        "date": date,
        "status": status,
        "isGross": False,
        "paid": False,
        "affectPayroll": False
    }
    
    if description:
        payload["description"] = description
        
    if type == "advancePayment":
        if not installment_plan:
            installment_plan = typer.prompt("Installment plan (e.g. 1, 3, 6)", default="1")
        payload["installmentPlan"] = installment_plan

    try:
        client = KolayClient()
        console.print(f"Creating {type} transaction for person {person_id}...")
        client.post("v2/transaction/create", data=payload)
        console.print("[bold green]Success![/bold green] Transaction created.")
        
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)
