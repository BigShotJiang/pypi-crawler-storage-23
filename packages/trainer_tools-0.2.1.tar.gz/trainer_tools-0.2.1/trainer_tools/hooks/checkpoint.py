import logging
from .ema import EMAHook
from ..imports import *
from .base import BaseHook
from ..trainer import Trainer
import os
from omegaconf import OmegaConf
from ..checkpoint import save_pretrained
from .metrics import MetricsHook

log = logging.getLogger(__name__)


class CheckpointHook(BaseHook):
    """
    Saves model, optimizer, scheduler, scaler, and RNG states.
    Can resume training from a checkpoint.

    Works transparently in both single-device and distributed (Accelerate)
    setups.
    """

    ord = -3

    def __init__(
        self,
        save_dir: str,
        save_every_steps: int = 1000,
        keep_last: int = 3,
        resume_path: Optional[str] = None,
        save_strategy: Literal["best", "latest"] = "best",
        metric_name: str = "valid_loss",
    ):
        self.save_dir, self.every, self.keep_last = Path(save_dir), save_every_steps, keep_last
        self.resume_path, self.save_strategy, self.metric = resume_path, save_strategy, metric_name
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.saved_checkpoints: list[Path] = []
        self.config_saved = False
        self._best_metric = float("inf")
        self._best_ckpt_path: Optional[Path] = None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _unwrap_model(trainer: Trainer, model: nn.Module | None = None):
        """Return the raw model, stripping any DDP/FSDP wrapper."""
        model = model or trainer.model
        if trainer.is_distributed:
            return trainer.accelerator.unwrap_model(model)
        return model

    @staticmethod
    def _get_scaler(trainer: Trainer):
        """Return the GradScaler from AMPHook or Accelerate, or None."""
        if hasattr(trainer, "scaler"):
            return trainer.scaler
        accel = getattr(trainer, "accelerator", None)
        if accel is not None:
            scaler = getattr(accel, "scaler", None)
            if scaler is not None and scaler.is_enabled():
                return scaler
        return None

    def _save_config(self, trainer: Trainer):
        if self.config_saved or not trainer.is_main:
            return
        if not (config := getattr(trainer, "config", None)):
            return
        config_path = self.save_dir / "config.yaml"
        OmegaConf.save(config, config_path, resolve=True)
        log.info(f"Saved config: {config_path}")
        self.config_saved = True

    # ------------------------------------------------------------------
    # Save / load
    # ------------------------------------------------------------------

    def _save(self, trainer: Trainer, filename: str, *, is_best: bool = False, sync: bool = True):
        # Synchronise all processes so every rank has finished the step.
        # Skipped for interrupt saves where a barrier could deadlock.
        if trainer.is_distributed and sync:
            trainer.accelerator.wait_for_everyone()
        if not trainer.is_main:
            return

        path = self.save_dir / filename
        state = {
            "model": self._unwrap_model(trainer).state_dict(),
            "opt": trainer.opt.state_dict(),
            "epoch": trainer.epoch,
            "step": trainer.step,
            "rng_torch": torch.get_rng_state(),
            "rng_numpy": np.random.get_state(),
        }
        if torch.cuda.is_available():
            state["rng_cuda"] = torch.cuda.get_rng_state()
        if (scaler := self._get_scaler(trainer)) is not None:
            state["scaler"] = scaler.state_dict()

        from .optimization import LRSchedulerHook

        if sched_hook := trainer.get_hook(LRSchedulerHook, None):
            state["scheduler"] = sched_hook.sched.state_dict()
        if (ema_hook := trainer.get_hook(EMAHook, None)) and ema_hook.ema_model is not None:
            state["ema"] = ema_hook.ema_model.state_dict()

        torch.save(state, path)
        log.info(f"Saved checkpoint: {path}")

        if "interrupted" in filename or "final" in filename:
            return

        if is_best:
            if self._best_ckpt_path and self._best_ckpt_path.exists() and self._best_ckpt_path != path:
                self._best_ckpt_path.unlink()
            self._best_ckpt_path = path
            return

        self.saved_checkpoints.append(path)
        if len(self.saved_checkpoints) <= self.keep_last:
            return
        oldest = self.saved_checkpoints.pop(0)
        if oldest.exists():
            oldest.unlink()

    def before_fit(self, trainer: Trainer):
        self._save_config(trainer)

        if not self.resume_path:
            return
        if Path(self.resume_path).exists():
            self.load_checkpoint(trainer, self.resume_path)
            log.info(f"Resumed training from checkpoint: {self.resume_path}, step {trainer.step}/{trainer.n_steps}")
        else:
            log.info(f"Resume path {self.resume_path} does not exist. Starting fresh training.")

    def after_step(self, trainer: Trainer):
        if not (trainer.training and trainer.step > 0 and trainer.step % self.every == 0):
            return

        self._save(trainer, f"checkpoint_step_{trainer.step}.pt", is_best=False)

        if self.save_strategy == "best":
            metrics_hook = trainer.get_hook(MetricsHook, None)
            if metrics_hook is None:
                log.warning("No MetricsHook found, switching save_strategy to 'latest'.")
                self.save_strategy = "latest"
                return

            stats = metrics_hook.step_data if self.metric in metrics_hook.step_data else metrics_hook.epoch_data
            current_metric = stats[self.metric]
            if current_metric < self._best_metric:
                self._best_metric = current_metric
                self._save(trainer, f"checkpoint_best_step_{trainer.step}.pt", is_best=True)

    def after_cancel(self, trainer: Trainer):
        self._save(trainer, "checkpoint_interrupted.pt", sync=False)

    def after_fit(self, trainer: Trainer):
        self._save(trainer, "model_final.pt")
        if not trainer.is_main:
            return

        model_to_save = self._unwrap_model(trainer)
        if (ema_hook := trainer.get_hook(EMAHook, None)) and ema_hook.ema_model is not None:
            model_to_save = ema_hook.ema_model
            log.info("Using EMA model for pretrained export")

        save_pretrained(model_to_save, self.save_dir, config=getattr(trainer, "config", None))

    def load_checkpoint(self, trainer: Trainer, path: str):
        """Restore training state.  Runs on **all** processes in distributed mode."""
        if not os.path.exists(path):
            raise FileNotFoundError(f"{path} not found")
        log.info(f"Loading checkpoint from {path}...")
        checkpoint = torch.load(path, map_location=trainer.device, weights_only=False)

        self._unwrap_model(trainer).load_state_dict(checkpoint["model"])
        trainer.opt.load_state_dict(checkpoint["opt"])
        trainer.epoch = checkpoint["epoch"]
        trainer.step = checkpoint["step"]

        torch.set_rng_state(checkpoint["rng_torch"].cpu())
        if torch.cuda.is_available() and "rng_cuda" in checkpoint:
            torch.cuda.set_rng_state(checkpoint["rng_cuda"].cpu())
        np.random.set_state(checkpoint["rng_numpy"])

        if "scaler" in checkpoint and (scaler := self._get_scaler(trainer)) is not None:
            scaler.load_state_dict(checkpoint["scaler"])

        if "scheduler" in checkpoint:
            from .optimization import LRSchedulerHook

            try:
                trainer.get_hook(LRSchedulerHook).sched.load_state_dict(checkpoint["scheduler"])
            except KeyError:
                log.warning("Checkpoint has scheduler state but no LRSchedulerHook found.")
        if "ema" in checkpoint:
            trainer._ema_state_buffer = checkpoint["ema"]
        log.info(f"Resumed at Epoch {trainer.epoch}, Step {trainer.step}")
