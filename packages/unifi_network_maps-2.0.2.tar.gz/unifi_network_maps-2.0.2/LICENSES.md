# Third-Party Licenses

This document lists the licenses for third-party assets used in the network map output.

Icons, fonts, and theme assets are bundled by the
[unifi-topology](https://github.com/merlijntishauser/unifi-topology) library.
See the [unifi-topology LICENSES.md](https://github.com/merlijntishauser/unifi-topology/blob/main/LICENSES.md)
for full details on vendored assets.

## Summary

### Icon Sets

| Set | Source | License |
|-----|--------|---------|
| Isometric | [markmanx/isopacks](https://github.com/markmanx/isopacks) | MIT |
| Modern | Custom isometric bases + [Heroicons](https://heroicons.com/) | MIT |

### Fonts

| Font | Source | License |
|------|--------|---------|
| Inter | [rsms/inter](https://github.com/rsms/inter) | SIL Open Font License 1.1 |
| Space Grotesk | [floriankarsten/space-grotesk](https://github.com/floriankarsten/space-grotesk) | SIL Open Font License 1.1 |

## License Compatibility

When sourcing icons for this project, use license-compatible sources:

**Compatible licenses:**
- Public Domain / CC0
- MIT License
- Apache 2.0
- CC-BY (with attribution)
- BSD

**Not compatible:**
- CC-NC (Non-Commercial)
- GPL/LGPL (copyleft)
