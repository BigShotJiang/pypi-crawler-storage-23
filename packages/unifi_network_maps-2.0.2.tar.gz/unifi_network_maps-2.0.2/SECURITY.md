# Security Policy

## Reporting a Vulnerability

Please report security issues by opening a private advisory or emailing the maintainer.
If you are unsure, open a GitHub issue and note that you can provide details privately.

We aim to respond within 7 days.
