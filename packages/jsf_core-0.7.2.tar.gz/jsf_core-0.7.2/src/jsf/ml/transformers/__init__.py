"""Transformer-based Models for Natural Language Processing in Trading.

This subpackage provides NLP capabilities for trading strategies, including:
- Sentiment analysis from financial news and social media
- Document embeddings for fundamental analysis
- Named entity recognition for company/sector extraction
- Text classification for event detection

⚠️ EDUCATIONAL PURPOSE ONLY ⚠️
These models are for LEARNING about NLP in finance, not for real trading.

Planned Features (Phase 20+):
- FinBERT: Pre-trained BERT for financial sentiment
- DistilBERT: Lightweight sentiment classification
- GPT-2: Text generation for report analysis
- Custom embeddings for trading signals

Example:
    >>> from jsf.ml.transformers import FinBERTSentiment
    >>> 
    >>> # Analyze news sentiment
    >>> model = FinBERTSentiment()
    >>> sentiment = model.predict([
    ...     "Company XYZ beats earnings expectations",
    ...     "Market crash fears grow amid uncertainty"
    ... ])
    >>> print(sentiment)  # [0.85, -0.72]

Requirements:
    pip install transformers torch
    # OR
    pip install transformers tensorflow

Note:
    This module requires additional dependencies not installed by default.
    Install with: pip install jsf-core[nlp]
"""

from typing import List, Dict, Any, Optional

# Version tracking for transformers subpackage
__version__ = "0.1.0-dev"
__status__ = "planned"


def _check_transformers():
    """Check if HuggingFace Transformers is available."""
    try:
        import transformers
        return transformers
    except ImportError:
        raise ImportError(
            "HuggingFace Transformers is not installed.\n"
            "Install with: pip install transformers torch\n"
            "Or: pip install transformers tensorflow"
        )


def _check_torch():
    """Check if PyTorch is available."""
    try:
        import torch
        return torch
    except ImportError:
        return None


def get_backend() -> str:
    """Get the available deep learning backend.
    
    Returns:
        'torch' if PyTorch is available, 'tensorflow' otherwise
    """
    if _check_torch() is not None:
        return 'torch'
    
    try:
        import tensorflow
        return 'tensorflow'
    except ImportError:
        raise ImportError(
            "Neither PyTorch nor TensorFlow is installed.\n"
            "Install one of: pip install torch OR pip install tensorflow"
        )


class SentimentAnalyzer:
    """Base class for sentiment analysis models.
    
    This is a placeholder for future FinBERT integration.
    Currently returns mock sentiment for educational purposes.
    """
    
    def __init__(self, model_name: str = "mock"):
        """Initialize sentiment analyzer.
        
        Args:
            model_name: Name of the model to use
        """
        self.model_name = model_name
        self._is_loaded = False
    
    def load(self):
        """Load the model (placeholder)."""
        self._is_loaded = True
    
    def predict(self, texts: List[str]) -> List[float]:
        """Predict sentiment scores.
        
        Args:
            texts: List of text strings to analyze
            
        Returns:
            List of sentiment scores in range [-1, 1]
            -1 = very negative, 0 = neutral, 1 = very positive
            
        Note:
            This is a MOCK implementation for educational purposes.
            Real implementation will use FinBERT or similar.
        """
        import numpy as np
        
        # Mock sentiment based on simple keyword matching
        # Replace with actual model in production
        scores = []
        positive_words = {'beat', 'gain', 'profit', 'growth', 'rise', 'surge', 'rally'}
        negative_words = {'loss', 'crash', 'fall', 'decline', 'fear', 'risk', 'drop'}
        
        for text in texts:
            text_lower = text.lower()
            pos_count = sum(1 for w in positive_words if w in text_lower)
            neg_count = sum(1 for w in negative_words if w in text_lower)
            
            if pos_count + neg_count == 0:
                score = 0.0
            else:
                score = (pos_count - neg_count) / (pos_count + neg_count)
            
            # Add small noise for realism
            score += np.random.uniform(-0.1, 0.1)
            score = np.clip(score, -1, 1)
            scores.append(float(score))
        
        return scores
    
    def predict_proba(self, texts: List[str]) -> List[Dict[str, float]]:
        """Predict sentiment probabilities.
        
        Args:
            texts: List of text strings
            
        Returns:
            List of dicts with 'positive', 'neutral', 'negative' probabilities
        """
        scores = self.predict(texts)
        
        probas = []
        for score in scores:
            if score > 0.3:
                proba = {'positive': 0.7, 'neutral': 0.2, 'negative': 0.1}
            elif score < -0.3:
                proba = {'positive': 0.1, 'neutral': 0.2, 'negative': 0.7}
            else:
                proba = {'positive': 0.3, 'neutral': 0.4, 'negative': 0.3}
            probas.append(proba)
        
        return probas


class TextEmbedder:
    """Base class for text embedding models.
    
    Converts text to dense vector representations for ML models.
    This is a placeholder for future BERT embedding integration.
    """
    
    def __init__(self, model_name: str = "mock", embedding_dim: int = 768):
        """Initialize text embedder.
        
        Args:
            model_name: Name of the model to use
            embedding_dim: Dimension of output embeddings
        """
        self.model_name = model_name
        self.embedding_dim = embedding_dim
    
    def embed(self, texts: List[str]) -> "np.ndarray":
        """Generate embeddings for texts.
        
        Args:
            texts: List of text strings
            
        Returns:
            Array of shape (n_texts, embedding_dim)
            
        Note:
            This is a MOCK implementation using random embeddings.
            Real implementation will use sentence-transformers or BERT.
        """
        import numpy as np
        
        # Mock: Generate deterministic pseudo-random embeddings
        # based on text hash for reproducibility
        embeddings = []
        for text in texts:
            # Use hash as seed for reproducibility
            seed = hash(text) % (2**32)
            np.random.seed(seed)
            embedding = np.random.randn(self.embedding_dim)
            # Normalize to unit length
            embedding = embedding / np.linalg.norm(embedding)
            embeddings.append(embedding)
        
        return np.array(embeddings)


# Import attention visualization utilities
from .attention import (
    AttentionHead,
    AttentionPattern,
    AttentionAnalyzer,
    FinancialAttentionInterpreter,
    analyze_attention,
)

# Import sentiment analysis
from .sentiment import (
    SimpleSentiment,
    FinBERTSentiment,
    SentimentResult,
    SentimentLabel,
)

# Import BERT models
from .bert import (
    FinBERT,
    CustomBERT,
    BERTFeatureExtractor,
    BERTConfig,
    BERTSentimentResult,
    create_finbert,
)


# Export placeholder classes
__all__ = [
    # Base classes
    "SentimentAnalyzer",
    "TextEmbedder",
    "get_backend",
    # Attention visualization
    "AttentionHead",
    "AttentionPattern",
    "AttentionAnalyzer",
    "FinancialAttentionInterpreter",
    "analyze_attention",
    # Sentiment analysis
    "SimpleSentiment",
    "FinBERTSentiment",
    "SentimentResult",
    "SentimentLabel",
    # BERT models
    "FinBERT",
    "CustomBERT",
    "BERTFeatureExtractor",
    "BERTConfig",
    "BERTSentimentResult",
    "create_finbert",
]
