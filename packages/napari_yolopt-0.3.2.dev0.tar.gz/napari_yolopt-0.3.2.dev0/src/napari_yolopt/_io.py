from __future__ import annotations

import csv
import json
import os
from pathlib import Path
from typing import Iterable, List, Optional, Tuple
import hyperspy.api as hs

import numpy as np
import tifffile

from napari_yolopt._schema import (
    BOXES_SUFFIX,
    DETECTIONS_POLYGONS_SUFFIX,
    POLYGONS_SUFFIX,
    PARAMS_SUFFIX,
    MASTER_CSV,
    SHAPES_HEADER,
    ANALYSIS_FOLDER_NAME,
)

IMAGE_EXTENSIONS = {".tif", ".tiff", ".emd"}


def list_image_files(folder: str) -> List[str]:
    paths = []
    for entry in sorted(os.listdir(folder)):
        path = os.path.join(folder, entry)
        if not os.path.isfile(path):
            continue
        if Path(path).suffix.lower() in IMAGE_EXTENSIONS:
            paths.append(path)
    return paths


def image_stem(image_path: str) -> str:
    return Path(image_path).stem


def analysis_folder_path(folder: str) -> str:
    return os.path.join(folder, ANALYSIS_FOLDER_NAME)


def ensure_analysis_folder(folder: str) -> str:
    path = analysis_folder_path(folder)
    os.makedirs(path, exist_ok=True)
    return path


def boxes_csv_path(folder: str, image_path: str) -> str:
    return os.path.join(
        analysis_folder_path(folder), f"{image_stem(image_path)}{BOXES_SUFFIX}"
    )


def polygons_csv_path(folder: str, image_path: str) -> str:
    return os.path.join(
        analysis_folder_path(folder),
        f"{image_stem(image_path)}{POLYGONS_SUFFIX}",
    )


def detections_polygons_csv_path(folder: str, image_path: str) -> str:
    return os.path.join(
        analysis_folder_path(folder),
        f"{image_stem(image_path)}{DETECTIONS_POLYGONS_SUFFIX}",
    )


def params_json_path(folder: str, image_path: str) -> str:
    return os.path.join(
        analysis_folder_path(folder),
        f"{image_stem(image_path)}{PARAMS_SUFFIX}",
    )


def master_csv_path(folder: str) -> str:
    return os.path.join(analysis_folder_path(folder), MASTER_CSV)


def load_image(image_path: str) -> np.ndarray:
    ext = Path(image_path).suffix.lower()
    if ext in {".tif", ".tiff"}:
        img = tifffile.imread(image_path)
    elif ext == ".emd":
        try:
            import importlib

            hs = importlib.import_module("hyperspy.api")
        except Exception as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "hyperspy is required to load .emd files"
            ) from exc
        signal = hs.load(image_path)
        if isinstance(signal, list):
            signal = signal[0]
        img = signal.data
    else:
        raise ValueError(f"Unsupported image type: {ext}")

    if img.ndim > 2:
        img = img[..., 0]
    return np.asarray(img)


def infer_pixel_size_m(image_path: str) -> Optional[float]:
    ext = Path(image_path).suffix.lower()
    if ext not in {".tif", ".tiff", ".emd"}:
        return None

    try:
        signal = hs.load(image_path)
        if isinstance(signal, list):
            signal = signal[0]
        metadata = signal.original_metadata
    except Exception:
        return None

    try:
        if ext == ".emd":
            return float(metadata["BinaryResult"]["PixelSize"]["height"])
        if ext in {".tif", ".tiff"}:
            return float(metadata["fei_metadata"]["Scan"]["PixelHeight"])
    except Exception:
        return None

    return None


def read_shapes_csv(path: str) -> Tuple[List[np.ndarray], List[str]]:
    if not os.path.exists(path):
        return [], []

    shapes = {}
    shape_types = {}
    with open(path, "r", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            idx = int(row["index"])
            shape_type = row["shape-type"]
            axis_0 = float(row["axis-0"])
            axis_1 = float(row["axis-1"])
            shapes.setdefault(idx, []).append([axis_0, axis_1])
            shape_types[idx] = shape_type

    sorted_indices = sorted(shapes.keys())
    data = [np.asarray(shapes[i], dtype=np.float32) for i in sorted_indices]
    types = [shape_types[i] for i in sorted_indices]
    return data, types


def write_shapes_csv(
    path: str, shapes: Iterable[np.ndarray], shape_types: Iterable[str]
) -> None:
    with open(path, "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(SHAPES_HEADER)
        for idx, (shape, shape_type) in enumerate(zip(shapes, shape_types)):
            shape = np.asarray(shape)
            for vertex_idx, (axis_0, axis_1) in enumerate(shape):
                writer.writerow(
                    [idx, shape_type, vertex_idx, float(axis_0), float(axis_1)]
                )


def read_boxes_csv(path: str) -> np.ndarray:
    shapes, _types = read_shapes_csv(path)
    if not shapes:
        return np.zeros((0, 4), dtype=np.float32)
    boxes = []
    for shape in shapes:
        y_min = float(np.min(shape[:, 0]))
        y_max = float(np.max(shape[:, 0]))
        x_min = float(np.min(shape[:, 1]))
        x_max = float(np.max(shape[:, 1]))
        boxes.append([x_min, y_min, x_max, y_max])
    return np.asarray(boxes, dtype=np.float32)


def write_boxes_csv(path: str, boxes: np.ndarray) -> None:
    shapes = []
    shape_types = []
    for box in boxes:
        x_min, y_min, x_max, y_max = box
        shapes.append(
            np.asarray(
                [
                    [y_min, x_min],
                    [y_min, x_max],
                    [y_max, x_max],
                    [y_max, x_min],
                ],
                dtype=np.float32,
            )
        )
        shape_types.append("rectangle")
    write_shapes_csv(path, shapes, shape_types)


def read_params_json(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    with open(path, "r") as handle:
        return json.load(handle)


def write_params_json(path: str, params: dict) -> None:
    with open(path, "w") as handle:
        json.dump(params, handle, indent=2)
