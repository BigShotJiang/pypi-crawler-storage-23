from __future__ import annotations

import csv
import os
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import List, Optional, TYPE_CHECKING

import numpy as np
from qtpy.QtCore import Qt
from qtpy.QtWidgets import (
    QCheckBox,
    QDoubleSpinBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
    QSizePolicy,
    QSlider,
)
from napari.qt.threading import thread_worker
from superqt import QRangeSlider

from napari_yolopt._export import (
    save_boxes_csv,
    save_polygons_csv,
    update_master_csv,
)
from napari_yolopt._geometry import (
    boxes_to_rectangles,
    compute_inclusion,
    compute_inclusion_from_points,
    polygons_centroids,
    polygons_to_boxes,
)
from napari_yolopt._io import (
    boxes_csv_path,
    detections_polygons_csv_path,
    ensure_analysis_folder,
    infer_pixel_size_m,
    list_image_files,
    load_image,
    master_csv_path,
    params_json_path,
    polygons_csv_path,
    read_boxes_csv,
    read_params_json,
    read_shapes_csv,
    write_params_json,
)
from napari_yolopt._predict import _to_uint8, load_model
from napari_yolopt._rotated_predict import _predict_for_angle_serial
from napari_yolopt._rotated_fusion import fuse_rotated_polygons
from napari_yolopt._schema import PARAMS_VERSION
from ._tooltips import TOOLTIP_TEXT  # type: ignore

IMAGE_LAYER_NAME = "image"
DETECTIONS_LAYER_NAME = "detections"
FILTERS_LAYER_NAME = "filters"

if TYPE_CHECKING:
    import napari


class YoloOptWidget(QWidget):
    def __init__(self, viewer: "napari.viewer.Viewer" = None):
        super().__init__()
        if viewer is None:
            try:
                import napari

                viewer = napari.current_viewer()
            except Exception as exc:
                raise RuntimeError("Napari viewer is required") from exc
        self.viewer = viewer

        self._folder_path: Optional[str] = None
        self._image_paths: List[str] = []
        self._current_index: Optional[int] = None
        self._model_path: Optional[str] = None
        self._model = None
        self._boxes: np.ndarray = np.zeros((0, 4), dtype=np.float32)
        self._scores: np.ndarray = np.zeros((0,), dtype=np.float32)
        self._detections_polygons: List[np.ndarray] = []
        self._detections_areas_px: np.ndarray = np.zeros(
            (0,), dtype=np.float32
        )
        self._included_mask: np.ndarray = np.zeros((0,), dtype=bool)
        self._shapes_connected = False
        self._pixel_size_m: Optional[float] = None
        self._prediction_worker = None
        self._prediction_job_id = 0
        self._prediction_cancel = threading.Event()

        self._build_ui()

    def _build_ui(self) -> None:
        main_layout = QVBoxLayout()
        tooltip_text = TOOLTIP_TEXT

        folder_group = QGroupBox("Folder")
        folder_layout = QHBoxLayout()
        self.folder_line = QLineEdit()
        self.folder_line.setPlaceholderText("Select folder...")
        self.folder_button = QPushButton("Browse")
        self.folder_button.clicked.connect(self._select_folder)
        folder_layout.addWidget(self.folder_line)
        folder_layout.addWidget(self.folder_button)
        folder_group.setLayout(folder_layout)
        main_layout.addWidget(folder_group)

        model_group = QGroupBox("Model")
        model_layout = QHBoxLayout()
        self.model_line = QLineEdit()
        self.model_line.setPlaceholderText("Select model .pt...")
        self.model_line.editingFinished.connect(self._on_model_path_edited)
        self.model_button = QPushButton("Browse")
        self.model_button.clicked.connect(self._select_model_path)
        model_layout.addWidget(self.model_line)
        model_layout.addWidget(self.model_button)
        model_group.setLayout(model_layout)
        main_layout.addWidget(model_group)

        images_group = QGroupBox("Images")
        images_layout = QVBoxLayout()
        self.image_list = QListWidget()
        self.image_list.setSizePolicy(
            QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
        )
        self.image_list.setMaximumHeight(200)
        self.image_list.itemClicked.connect(self._on_image_selected)
        images_layout.addWidget(self.image_list)
        images_group.setLayout(images_layout)
        main_layout.addWidget(images_group)

        params_group = QGroupBox("Parameters")
        params_layout = QVBoxLayout()

        pred_group = QGroupBox("Multiscale prediction")
        pred_layout = QVBoxLayout()

        scale_layout = QHBoxLayout()
        scale_layout.addWidget(QLabel("Scale range"))
        self.scale_min_label = QLabel("1.0")
        self.scale_max_label = QLabel("50.0")
        self.scales_range = QRangeSlider(Qt.Horizontal)
        self.scales_range.setRange(1, 50)
        self.scales_range.setValue((3, 30))
        self.scales_range.setToolTip(tooltip_text.get("scale_range", ""))
        scale_layout.addWidget(self.scale_min_label)
        scale_layout.addWidget(self.scales_range)
        scale_layout.addWidget(self.scale_max_label)
        pred_layout.addLayout(scale_layout)

        num_scales_layout = QHBoxLayout()
        self.num_scales_spin = QSpinBox()
        self.num_scales_spin.setRange(1, 10)
        self.num_scales_spin.setSingleStep(2)
        self.num_scales_spin.setValue(3)
        self.num_scales_spin.setReadOnly(False)
        self.num_scales_spin.setToolTip(tooltip_text.get("num_scales", ""))
        num_scales_layout.addWidget(QLabel("Num scales"))
        num_scales_layout.addWidget(self.num_scales_spin)
        pred_layout.addLayout(num_scales_layout)

        iou_layout = QHBoxLayout()
        self.iou_spin = QDoubleSpinBox()
        self.iou_spin.setRange(0.0, 1.0)
        self.iou_spin.setSingleStep(0.05)
        self.iou_spin.setValue(0.5)
        self.iou_spin.setToolTip(tooltip_text.get("overlap_threshold", ""))
        iou_layout.addWidget(QLabel("Overlap threshold"))
        iou_layout.addWidget(self.iou_spin)
        pred_layout.addLayout(iou_layout)

        pred_group.setLayout(pred_layout)
        params_layout.addWidget(pred_group)

        fusion_group = QGroupBox("Multiangle fusion")
        fusion_layout = QVBoxLayout()

        num_angles_layout = QHBoxLayout()
        self.num_angles_spin = QSpinBox()
        self.num_angles_spin.setRange(1, 36)
        self.num_angles_spin.setValue(10)
        self.num_angles_spin.setToolTip(tooltip_text.get("num_angles", ""))
        num_angles_layout.addWidget(QLabel("Num angles"))
        num_angles_layout.addWidget(self.num_angles_spin)
        fusion_layout.addLayout(num_angles_layout)

        dist_layout = QHBoxLayout()
        self.fuse_max_dist_spin = QDoubleSpinBox()
        self.fuse_max_dist_spin.setRange(0.0, 100.0)
        self.fuse_max_dist_spin.setValue(9.0)
        self.fuse_max_dist_spin.setToolTip(tooltip_text.get("distance", ""))
        dist_layout.addWidget(QLabel("Distance"))
        dist_layout.addWidget(self.fuse_max_dist_spin)
        fusion_layout.addLayout(dist_layout)

        hyp_layout = QHBoxLayout()
        self.fuse_hyp_tau_spin = QDoubleSpinBox()
        self.fuse_hyp_tau_spin.setRange(1.0, 2.0)
        self.fuse_hyp_tau_spin.setSingleStep(0.01)
        self.fuse_hyp_tau_spin.setValue(1.3)
        self.fuse_hyp_tau_spin.setToolTip(
            tooltip_text.get("hypotenuse_threshold", "")
        )
        hyp_layout.addWidget(QLabel("Hypotenuse threshold"))
        hyp_layout.addWidget(self.fuse_hyp_tau_spin)
        fusion_layout.addLayout(hyp_layout)

        support_layout = QHBoxLayout()
        self.fuse_min_support_spin = QSpinBox()
        self.fuse_min_support_spin.setRange(1, 36)
        self.fuse_min_support_spin.setValue(4)
        self.fuse_min_support_spin.setToolTip(
            tooltip_text.get("min_support", "")
        )
        support_layout.addWidget(QLabel("Min support"))
        support_layout.addWidget(self.fuse_min_support_spin)
        fusion_layout.addLayout(support_layout)

        n_jobs_layout = QHBoxLayout()
        n_jobs_layout.addWidget(QLabel("n_jobs"))
        self.n_jobs_slider = QSlider(Qt.Horizontal)
        max_jobs = max(1, (os.cpu_count() or 1) - 1)
        default_jobs = max(1, (os.cpu_count() or 1) - 2)
        self.n_jobs_slider.setRange(1, max_jobs)
        self.n_jobs_slider.setValue(default_jobs)
        self.n_jobs_slider.setToolTip(tooltip_text.get("n_jobs", ""))
        self.n_jobs_label = QLabel(str(default_jobs))
        n_jobs_layout.addWidget(self.n_jobs_slider)
        n_jobs_layout.addWidget(self.n_jobs_label)
        fusion_layout.addLayout(n_jobs_layout)

        fusion_group.setLayout(fusion_layout)
        params_layout.addWidget(fusion_group)

        params_group.setLayout(params_layout)
        main_layout.addWidget(params_group)

        filters_group = QGroupBox("Behavior of polygons in 'filters' layer")
        filters_layout = QHBoxLayout()
        self.exclude_checkbox = QCheckBox("Exclude polygons")
        filters_layout.addWidget(self.exclude_checkbox)
        filters_group.setLayout(filters_layout)

        main_layout.addWidget(filters_group)

        action_layout = QHBoxLayout()
        self.validate_button = QPushButton("Validate/move to next \u27a4")
        self.validate_button.clicked.connect(self._validate_and_next)
        action_layout.addWidget(self.validate_button)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        action_layout.addWidget(self.progress_bar)
        self.status_label = QLabel("Ready")
        self.status_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        action_layout.addWidget(self.status_label)
        main_layout.addLayout(action_layout)

        self.setLayout(main_layout)

        self._on_scales_range_changed(self.scales_range.value())

        self.scales_range.valueChanged.connect(self._on_scales_range_changed)
        self.scales_range.sliderReleased.connect(
            self._on_scales_range_released
        )
        self.num_angles_spin.valueChanged.connect(
            self._on_prediction_params_changed
        )
        self.num_scales_spin.valueChanged.connect(self._on_num_scales_changed)
        self.iou_spin.valueChanged.connect(self._on_prediction_params_changed)
        self.fuse_max_dist_spin.valueChanged.connect(
            self._on_prediction_params_changed
        )
        self.fuse_hyp_tau_spin.valueChanged.connect(
            self._on_prediction_params_changed
        )
        self.fuse_min_support_spin.valueChanged.connect(
            self._on_prediction_params_changed
        )
        self.n_jobs_slider.valueChanged.connect(self._on_n_jobs_changed)
        self.n_jobs_slider.sliderReleased.connect(
            self._on_prediction_params_changed
        )
        self.exclude_checkbox.stateChanged.connect(
            lambda _state: self._update_inclusion_colors()
        )

    def _select_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, "Select Analysis Folder"
        )
        if not folder:
            return
        self.folder_line.setText(folder)
        self._load_folder(folder)

    def _select_model_path(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select Model", "", "*.pt")
        if not path:
            return
        self.model_line.setText(path)
        if self._model_path != path:
            self._model_path = path
            self._model = None
            self._rerun_prediction_for_current_image()

    def _on_model_path_edited(self) -> None:
        path = self.model_line.text().strip()
        if not path:
            self._model_path = None
            self._model = None
            return
        if self._model_path != path:
            self._model_path = path
            self._model = None
            self._rerun_prediction_for_current_image()

    def _load_folder(self, folder: str) -> None:
        self._folder_path = folder
        self._image_paths = list_image_files(folder)
        if not self._model_path:
            self._infer_model_path_from_params()
        if self._pixel_size_m is None:
            self._infer_pixel_size_from_metadata()
        self._populate_image_list()
        first_unprocessed = self._find_first_unprocessed()
        if first_unprocessed is None and self._image_paths:
            first_unprocessed = 0
        if first_unprocessed is not None:
            self._select_image_index(first_unprocessed)
        else:
            self.status_label.setText("No images found")

    def _infer_model_path_from_params(self) -> None:
        if not self._folder_path:
            return
        for image_path in self._image_paths:
            params_path = params_json_path(self._folder_path, image_path)
            params = read_params_json(params_path)
            model_path = params.get("model_path")
            if model_path:
                self._model_path = model_path
                self.model_line.setText(model_path)
                self._model = None
                break

    def _infer_pixel_size_from_metadata(self) -> None:
        if not self._folder_path:
            return
        for image_path in self._image_paths:
            pixel_size_m = infer_pixel_size_m(image_path)
            if pixel_size_m is not None:
                self._pixel_size_m = pixel_size_m
                break

    def _populate_image_list(self) -> None:
        self.image_list.blockSignals(True)
        self.image_list.clear()
        if not self._image_paths:
            self.image_list.blockSignals(False)
            return
        for path in self._image_paths:
            item = QListWidgetItem(os.path.basename(path))
            if self._folder_path and self._is_image_validated(path):
                item.setForeground(Qt.darkGreen)
            self.image_list.addItem(item)
        self.image_list.blockSignals(False)

    def _is_image_validated(self, image_path: str) -> bool:
        if not self._folder_path:
            return False
        master_path = master_csv_path(self._folder_path)
        if not os.path.exists(master_path):
            return False
        image_name = os.path.basename(image_path)
        try:
            with open(master_path, "r", newline="") as handle:
                reader = csv.DictReader(handle)
                for row in reader:
                    if row.get("image_name") == image_name:
                        return True
        except Exception:
            return False
        return False

    def _find_first_unprocessed(self) -> Optional[int]:
        if not self._folder_path:
            return None
        for idx, path in enumerate(self._image_paths):
            if not os.path.exists(boxes_csv_path(self._folder_path, path)):
                return idx
        return None

    def _select_image_index(self, index: int) -> None:
        if index < 0 or index >= len(self._image_paths):
            return
        self.image_list.blockSignals(True)
        self.image_list.setCurrentRow(index)
        self.image_list.blockSignals(False)
        self._load_image_by_index(index)

    def _on_image_selected(self, item: QListWidgetItem) -> None:
        index = self.image_list.row(item)
        self._load_image_by_index(index)

    def _formatted_image_name(self, image_path: str) -> str:
        return (
            image_path
            if len(image_path) <= 20
            else f"{image_path[:10]}...{image_path[-10:]}"
        )

    def _load_image_by_index(self, index: int) -> None:
        if not self._folder_path:
            return
        self._current_index = index
        image_path = self._image_paths[index]
        image = load_image(image_path)

        self._cancel_prediction()
        self._clear_prediction_and_filters_layers()

        self._ensure_image_layer(image)
        self._ensure_filters_layer()
        self.status_label.setText(
            f"Loaded {self._formatted_image_name(os.path.basename(image_path))}"
        )
        self.viewer.reset_view()
        if not self._model_path:
            return
        self._load_polygons(image_path)
        self._update_inclusion_colors()
        self._start_prediction_for_image(image, image_path)

    def _clear_prediction_and_filters_layers(self) -> None:
        self._boxes = np.zeros((0, 4), dtype=np.float32)
        self._scores = np.zeros((0,), dtype=np.float32)
        self._detections_polygons = []
        self._detections_areas_px = np.zeros((0,), dtype=np.float32)
        self._included_mask = np.zeros((0,), dtype=bool)

        if DETECTIONS_LAYER_NAME in self.viewer.layers:
            layer = self.viewer.layers[DETECTIONS_LAYER_NAME]
            layer.data = []
        if FILTERS_LAYER_NAME in self.viewer.layers:
            layer = self.viewer.layers[FILTERS_LAYER_NAME]
            layer.data = []

    def _ensure_image_layer(self, image: np.ndarray) -> None:
        if IMAGE_LAYER_NAME in self.viewer.layers:
            self.viewer.layers[IMAGE_LAYER_NAME].data = image
        else:
            self.viewer.add_image(image, name=IMAGE_LAYER_NAME)

    def _ensure_filters_layer(self) -> None:
        if FILTERS_LAYER_NAME in self.viewer.layers:
            return
        layer = self.viewer.add_shapes(
            [],
            name=FILTERS_LAYER_NAME,
            shape_type="polygon",
            edge_color="yellow",
            face_color="transparent",
            edge_width=3,
        )
        if not self._shapes_connected:
            self._connect_shape_events()

    def _load_params_for_image(self, image_path: str) -> None:
        if not self._folder_path:
            return
        params_path = params_json_path(self._folder_path, image_path)
        params = read_params_json(params_path)
        exclude_mode = params.get("exclude_mode")
        if exclude_mode is not None:
            self.exclude_checkbox.setChecked(bool(exclude_mode))
        scale_min = params.get("scale_min")
        scale_max = params.get("scale_max")
        if scale_min is not None and scale_max is not None:
            self.scales_range.setValue(
                (int(float(scale_min) * 10), int(float(scale_max) * 10))
            )
        num_scales = params.get("num_scales")
        if num_scales is not None:
            self.num_scales_spin.setValue(int(num_scales))
        iou_thresh = params.get("iou_thresh")
        if iou_thresh is not None:
            self.iou_spin.setValue(float(iou_thresh))
        num_angles = params.get("num_angles")
        if num_angles is not None:
            self.num_angles_spin.setValue(int(num_angles))
        max_dist = params.get("fuse_max_dist")
        if max_dist is not None:
            self.fuse_max_dist_spin.setValue(float(max_dist))
        hyp_tau = params.get("fuse_hyp_tau")
        if hyp_tau is not None:
            self.fuse_hyp_tau_spin.setValue(float(hyp_tau))
        min_support = params.get("fuse_min_support")
        if min_support is not None:
            self.fuse_min_support_spin.setValue(int(min_support))
        n_jobs = params.get("n_jobs")
        if n_jobs is not None:
            self.n_jobs_slider.setValue(int(n_jobs))
        if self.num_angles_spin.value() == 1:
            if self.n_jobs_slider.value() != 1:
                self.n_jobs_slider.setValue(1)
        pixel_size_m = params.get("pixel_size_m")
        if pixel_size_m is not None:
            self._pixel_size_m = float(pixel_size_m)

    def _prediction_params(self) -> dict:
        return {
            "model_path": self._model_path,
            "scale_min": self.scales_range.value()[0] / 10.0,
            "scale_max": self.scales_range.value()[1] / 10.0,
            "num_angles": self.num_angles_spin.value(),
            "num_scales": self.num_scales_spin.value(),
            "iou_thresh": self.iou_spin.value(),
            "fuse_max_dist": self.fuse_max_dist_spin.value(),
            "fuse_hyp_tau": self.fuse_hyp_tau_spin.value(),
            "fuse_min_support": self.fuse_min_support_spin.value(),
        }

    def _prediction_params_match(self, image_path: str) -> bool:
        if not self._folder_path:
            return False
        params_path = params_json_path(self._folder_path, image_path)
        params = read_params_json(params_path)
        current = self._prediction_params()
        for key, value in current.items():
            if key not in params:
                return False
            existing = params.get(key)
            if isinstance(value, float):
                if not np.isclose(float(existing), float(value)):
                    return False
            else:
                if existing != value:
                    return False
        return True

    def _load_cached_predictions(self, image_path: str) -> bool:
        if not self._folder_path:
            return False
        if not self._prediction_params_match(image_path):
            return False
        detections_path = detections_polygons_csv_path(
            self._folder_path, image_path
        )
        boxes_path = boxes_csv_path(self._folder_path, image_path)
        if os.path.exists(detections_path):
            shapes, _shape_types = read_shapes_csv(detections_path)
            self._detections_polygons = shapes
            self._boxes = polygons_to_boxes(shapes)
            self._scores = np.zeros((len(self._boxes),), dtype=np.float32)
            if len(self._boxes) > 0:
                x_min = self._boxes[:, 0]
                y_min = self._boxes[:, 1]
                x_max = self._boxes[:, 2]
                y_max = self._boxes[:, 3]
                self._detections_areas_px = (x_max - x_min) * (y_max - y_min)
            else:
                self._detections_areas_px = np.zeros((0,), dtype=np.float32)
            self._update_detections_layer(self._detections_polygons)
            return True
        if os.path.exists(boxes_path):
            self._boxes = read_boxes_csv(boxes_path)
            self._scores = np.zeros((len(self._boxes),), dtype=np.float32)
            self._detections_polygons = boxes_to_rectangles(self._boxes)
            if len(self._boxes) > 0:
                x_min = self._boxes[:, 0]
                y_min = self._boxes[:, 1]
                x_max = self._boxes[:, 2]
                y_max = self._boxes[:, 3]
                self._detections_areas_px = (x_max - x_min) * (y_max - y_min)
            else:
                self._detections_areas_px = np.zeros((0,), dtype=np.float32)
            self._update_detections_layer(self._detections_polygons)
            return True
        return False

    def _save_prediction_results(self, image_path: str) -> None:
        if not self._folder_path:
            return
        ensure_analysis_folder(self._folder_path)
        detections_path = detections_polygons_csv_path(
            self._folder_path, image_path
        )
        save_polygons_csv(
            detections_path,
            self._detections_polygons,
            ["polygon"] * len(self._detections_polygons),
        )
        save_boxes_csv(
            boxes_csv_path(self._folder_path, image_path), self._boxes
        )
        params = {
            "version": PARAMS_VERSION,
            "image_name": os.path.basename(image_path),
            **self._prediction_params(),
            "n_jobs": self.n_jobs_slider.value(),
            "exclude_mode": self.exclude_checkbox.isChecked(),
            "pixel_size_m": self._pixel_size_m,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        }
        write_params_json(
            params_json_path(self._folder_path, image_path), params
        )

    def _start_prediction_for_image(
        self, image: np.ndarray, image_path: str, force_predict: bool = False
    ) -> None:
        if not self._folder_path or not self._model_path:
            return
        if not force_predict and self._load_cached_predictions(image_path):
            self._update_inclusion_colors()
            self.status_label.setText(
                f"Loaded predictions for {self._formatted_image_name(os.path.basename(image_path))}"
            )
            return

        if self._model is None:
            self._model = load_model(self._model_path)

        num_angles = self.num_angles_spin.value()
        if num_angles == 1:
            angles = [0.0]
            if self.n_jobs_slider.value() != 1:
                self.n_jobs_slider.setValue(1)
        elif num_angles == 2:
            angles = [0.0, 45.0]
        else:
            angles = np.linspace(0.0, 90.0, num_angles).tolist()

        job_id = self._prediction_job_id + 1
        self._prediction_job_id = job_id
        self._prediction_cancel.clear()
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, len(angles))
        self.progress_bar.setValue(0)
        self.status_label.setText("Predicting...")

        @thread_worker
        def _worker():
            img_uint8 = _to_uint8(image)
            polygons_by_angle = {}
            completed = 0

            if self.n_jobs_slider.value() > 1:
                with ThreadPoolExecutor(
                    max_workers=self.n_jobs_slider.value()
                ) as executor:
                    futures = {
                        executor.submit(
                            _predict_for_angle_serial,
                            angle,
                            img_uint8,
                            self._model,
                            self.scales_range.value()[0] / 10.0,
                            self.scales_range.value()[1] / 10.0,
                            self.num_scales_spin.value(),
                            self.iou_spin.value(),
                        ): angle
                        for angle in angles
                    }
                    for future in as_completed(futures):
                        if self._prediction_cancel.is_set():
                            for pending in futures:
                                pending.cancel()
                            return {"cancelled": True}
                        angle = futures[future]
                        polygons, _scores = future.result()
                        polygons_by_angle[angle] = polygons
                        completed += 1
                        yield completed
            else:
                for angle in angles:
                    if self._prediction_cancel.is_set():
                        return {"cancelled": True}
                    polygons, _scores = _predict_for_angle_serial(
                        angle,
                        img_uint8,
                        self._model,
                        self.scales_range.value()[0] / 10.0,
                        self.scales_range.value()[1] / 10.0,
                        self.num_scales_spin.value(),
                        self.iou_spin.value(),
                    )
                    polygons_by_angle[angle] = polygons
                    completed += 1
                    yield completed

            ordered_polys = [polygons_by_angle[a] for a in angles]
            fused_polys, fused_areas = fuse_rotated_polygons(
                ordered_polys,
                max_dist=self.fuse_max_dist_spin.value(),
                hyp_tau=self.fuse_hyp_tau_spin.value(),
                min_support=self.fuse_min_support_spin.value(),
                nms_iou=self.iou_spin.value(),
            )
            return {
                "polygons": fused_polys,
                "areas": fused_areas,
            }

        worker = _worker()
        self._prediction_worker = worker

        def _on_yielded(progress):
            if job_id != self._prediction_job_id:
                return
            if isinstance(progress, int):
                self.progress_bar.setValue(progress)

        def _on_returned(result):
            if job_id != self._prediction_job_id:
                return
            self.progress_bar.setVisible(False)
            if result.get("cancelled"):
                return
            self._detections_polygons = result["polygons"]
            self._detections_areas_px = result["areas"]
            self._boxes = polygons_to_boxes(self._detections_polygons)
            self._scores = np.zeros((len(self._boxes),), dtype=np.float32)
            self._update_detections_layer(self._detections_polygons)
            self._update_inclusion_colors()
            self._save_prediction_results(image_path)
            self.status_label.setText(
                f"Loaded {self._formatted_image_name(os.path.basename(image_path))}"
            )

        def _on_finished():
            if job_id != self._prediction_job_id:
                return
            self.progress_bar.setVisible(False)

        worker.yielded.connect(_on_yielded)
        worker.returned.connect(_on_returned)
        worker.finished.connect(_on_finished)
        worker.start()

    def _rerun_prediction_for_current_image(self) -> None:
        if self._folder_path is None or self._current_index is None:
            return
        if not self._model_path:
            return
        image_path = self._image_paths[self._current_index]
        image = load_image(image_path)
        self.status_label.setText("Updating predictions")
        self._ensure_filters_layer()
        self._start_prediction_for_image(image, image_path, force_predict=True)

    def _cancel_prediction(self) -> None:
        self._prediction_cancel.set()
        if self._prediction_worker is not None:
            try:
                self._prediction_worker.quit()
            except Exception:
                pass

    def _on_prediction_params_changed(self, _value=None) -> None:
        if self.num_angles_spin.value() == 1:
            if self.n_jobs_slider.value() != 1:
                self.n_jobs_slider.setValue(1)
        self._model = None
        self._cancel_prediction()
        self._rerun_prediction_for_current_image()

    def _on_num_scales_changed(self, value: int) -> None:
        if value % 2 == 0:
            adjusted = value - 1 if value > 1 else value + 1
            if adjusted != value:
                self.num_scales_spin.setValue(adjusted)
                return
        self._on_prediction_params_changed(value)

    def _on_n_jobs_changed(self, value: int) -> None:
        self.n_jobs_label.setText(str(value))

    def _on_scales_range_changed(self, values) -> None:
        min_val, max_val = values
        self.scale_min_label.setText(f"{min_val / 10.0:.1f}")
        self.scale_max_label.setText(f"{max_val / 10.0:.1f}")

    def _on_scales_range_released(self) -> None:
        self._on_prediction_params_changed(None)

    def _update_detections_layer(self, polygons: List[np.ndarray]) -> None:
        if DETECTIONS_LAYER_NAME in self.viewer.layers:
            layer = self.viewer.layers[DETECTIONS_LAYER_NAME]
            layer.data = polygons
            layer.shape_type = ["polygon"] * len(polygons)
            layer.edge_width = 3
        else:
            layer = self.viewer.add_shapes(
                polygons,
                name=DETECTIONS_LAYER_NAME,
                shape_type="polygon",
                edge_color="green",
                face_color="transparent",
                edge_width=3,
            )

    def _load_polygons(self, image_path: str) -> None:
        if not self._folder_path:
            return
        polygons_path = polygons_csv_path(self._folder_path, image_path)
        shapes, shape_types = read_shapes_csv(polygons_path)

        if FILTERS_LAYER_NAME in self.viewer.layers:
            layer = self.viewer.layers[FILTERS_LAYER_NAME]
            layer.data = shapes
            if shape_types:
                layer.shape_type = shape_types
        else:
            layer = self.viewer.add_shapes(
                shapes,
                name=FILTERS_LAYER_NAME,
                shape_type=shape_types or "polygon",
                edge_color="yellow",
                face_color="transparent",
                edge_width=3,
            )
        if not self._shapes_connected:
            self._connect_shape_events()

    def _connect_shape_events(self) -> None:
        if FILTERS_LAYER_NAME not in self.viewer.layers:
            return
        self.viewer.layers[FILTERS_LAYER_NAME].events.data.connect(
            self._on_shapes_changed
        )
        self._shapes_connected = True

    def _on_shapes_changed(self, _event=None) -> None:
        self._update_inclusion_colors()

    def _update_inclusion_colors(self) -> None:
        if DETECTIONS_LAYER_NAME not in self.viewer.layers:
            return
        if self._boxes.size == 0 and not self._detections_polygons:
            return
        shapes = []
        shape_types = []
        if FILTERS_LAYER_NAME in self.viewer.layers:
            filter_layer = self.viewer.layers[FILTERS_LAYER_NAME]
            shapes = list(filter_layer.data)
            if isinstance(filter_layer.shape_type, str):
                shape_types = [filter_layer.shape_type] * len(shapes)
            else:
                shape_types = list(filter_layer.shape_type)
        if self._detections_polygons:
            points = polygons_centroids(self._detections_polygons)
            self._included_mask = compute_inclusion_from_points(
                points,
                shapes,
                shape_types,
                self.exclude_checkbox.isChecked(),
            )
        else:
            self._included_mask = compute_inclusion(
                self._boxes,
                shapes,
                shape_types,
                self.exclude_checkbox.isChecked(),
            )
        colors = [
            "#00ff00" if inc else "#ff0000" for inc in self._included_mask
        ]
        self.viewer.layers[DETECTIONS_LAYER_NAME].edge_color = colors

    def _validate_and_next(self) -> None:
        if self._folder_path is None or self._current_index is None:
            return
        ensure_analysis_folder(self._folder_path)
        image_path = self._image_paths[self._current_index]
        image_name = os.path.basename(image_path)

        shapes = []
        shape_types = []
        if FILTERS_LAYER_NAME in self.viewer.layers:
            filter_layer = self.viewer.layers[FILTERS_LAYER_NAME]
            shapes = list(filter_layer.data)
            if isinstance(filter_layer.shape_type, str):
                shape_types = [filter_layer.shape_type] * len(shapes)
            else:
                shape_types = list(filter_layer.shape_type)

        self._included_mask = compute_inclusion(
            self._boxes, shapes, shape_types, self.exclude_checkbox.isChecked()
        )

        save_boxes_csv(
            boxes_csv_path(self._folder_path, image_path), self._boxes
        )
        save_polygons_csv(
            polygons_csv_path(self._folder_path, image_path),
            shapes,
            shape_types,
        )
        update_master_csv(
            master_csv_path(self._folder_path),
            image_name,
            self._boxes,
            self._included_mask,
            self._pixel_size_m,
            self._detections_areas_px,
        )

        params = {
            "version": PARAMS_VERSION,
            "image_name": image_name,
            "model_path": self._model_path,
            "scale_min": self.scales_range.value()[0] / 10.0,
            "scale_max": self.scales_range.value()[1] / 10.0,
            "num_angles": self.num_angles_spin.value(),
            "num_scales": self.num_scales_spin.value(),
            "iou_thresh": self.iou_spin.value(),
            "fuse_max_dist": self.fuse_max_dist_spin.value(),
            "fuse_hyp_tau": self.fuse_hyp_tau_spin.value(),
            "fuse_min_support": self.fuse_min_support_spin.value(),
            "n_jobs": self.n_jobs_slider.value(),
            "exclude_mode": self.exclude_checkbox.isChecked(),
            "pixel_size_m": self._pixel_size_m,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        }
        write_params_json(
            params_json_path(self._folder_path, image_path), params
        )

        self._populate_image_list()

        next_index = self._find_first_unprocessed()
        if next_index is None:
            if self._current_index + 1 < len(self._image_paths):
                next_index = self._current_index + 1

        if next_index is None:
            self.status_label.setText("Folder completed")
            return

        self._select_image_index(next_index)
