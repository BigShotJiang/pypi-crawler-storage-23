from __future__ import annotations

TOOLTIP_TEXT = {
    "scale_range": (
        "Sets the min/max scale factors used for multiscale inference.\n"
        "Lower values emphasize smaller features; higher values emphasize larger ones.\n"
        "The model is run at multiple scales between these limits."
    ),
    "num_scales": (
        "Number of scales evaluated between min and max.\n"
        "Uses odd values to keep a central scale of 1.0 when the range spans it.\n"
        "Higher values increase coverage and runtime."
    ),
    "overlap_threshold": (
        "Overlap threshold used to merge overlapping detections across scales.\n"
        "Lower values keep more boxes; higher values suppress near-duplicates."
    ),
    "num_angles": (
        "Number of rotation angles used for multi-angle prediction.\n"
        "If 1: only 0°. If 2: 0° and 45°. If >2: evenly spaced from 0° to 90°.\n"
        "More angles increase robustness and runtime."
    ),
    "distance": (
        "Max centroid distance (pixels) for grouping polygons across angles.\n"
        "Smaller values are stricter; larger values fuse more shapes."
    ),
    "hypotenuse_threshold": (
        "Gating factor for polygon size consistency when fusing angles.\n"
        "Values closer to 1 are stricter; larger values allow more variation."
    ),
    "min_support": (
        "Minimum number of angles that must agree on a shape to keep it.\n"
        "Higher values reduce false positives but may drop faint features."
    ),
    "n_jobs": (
        "Number of threads used to process angles concurrently.\n"
        "Higher values speed up inference but increase CPU usage."
    ),
}
