from __future__ import annotations

import csv
import os
from typing import Iterable

import numpy as np

from napari_yolopt._io import write_boxes_csv, write_shapes_csv


def save_boxes_csv(path: str, boxes: np.ndarray) -> None:
    write_boxes_csv(path, boxes)


def save_polygons_csv(
    path: str, shapes: Iterable[np.ndarray], shape_types: Iterable[str]
) -> None:
    write_shapes_csv(path, shapes, shape_types)


def update_master_csv(
    master_path: str,
    image_name: str,
    boxes: np.ndarray,
    included: np.ndarray,
    pixel_size_m: float | None = None,
    areas_px: np.ndarray | None = None,
) -> None:
    rows = []
    if os.path.exists(master_path):
        with open(master_path, "r", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                if row.get("image_name") != image_name:
                    area_px = row.get("area_px")
                    area_m2 = row.get("area_m2")
                    if area_px is None and area_m2 is None:
                        legacy_area = row.get("area")
                        area_px = legacy_area
                        area_m2 = None
                    rows.append(
                        {
                            "image_name": row.get("image_name"),
                            "box_id": row.get("box_id"),
                            "area_px": area_px,
                            "area_m2": area_m2,
                        }
                    )

    for idx, box in enumerate(boxes):
        if not included[idx]:
            continue
        if areas_px is not None and idx < len(areas_px):
            area_px = float(areas_px[idx])
        else:
            x_min, y_min, x_max, y_max = box
            area_px = max(0.0, (x_max - x_min) * (y_max - y_min))
        area_m2 = (
            area_px * (pixel_size_m**2) if pixel_size_m is not None else None
        )
        rows.append(
            {
                "image_name": image_name,
                "box_id": str(idx),
                "area_px": f"{area_px}",
                "area_m2": f"{area_m2}" if area_m2 is not None else "",
            }
        )

    with open(master_path, "w", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["image_name", "box_id", "area_px", "area_m2"]
        )
        writer.writeheader()
        writer.writerows(rows)
