from __future__ import annotations

from typing import Iterable, List, Tuple

import numpy as np


def boxes_to_rectangles(boxes: np.ndarray) -> List[np.ndarray]:
    rectangles = []
    for box in boxes:
        x_min, y_min, x_max, y_max = box
        rectangles.append(
            np.asarray(
                [
                    [y_min, x_min],
                    [y_min, x_max],
                    [y_max, x_max],
                    [y_max, x_min],
                ],
                dtype=np.float32,
            )
        )
    return rectangles


def polygons_to_boxes(polygons: Iterable[np.ndarray]) -> np.ndarray:
    boxes = []
    for poly in polygons:
        poly = np.asarray(poly)
        if poly.size == 0:
            continue
        y_min = float(np.min(poly[:, 0]))
        y_max = float(np.max(poly[:, 0]))
        x_min = float(np.min(poly[:, 1]))
        x_max = float(np.max(poly[:, 1]))
        boxes.append([x_min, y_min, x_max, y_max])
    if not boxes:
        return np.zeros((0, 4), dtype=np.float32)
    return np.asarray(boxes, dtype=np.float32)


def polygons_centroids(polygons: Iterable[np.ndarray]) -> np.ndarray:
    points = []
    for poly in polygons:
        poly = np.asarray(poly)
        if poly.size == 0:
            continue
        points.append(np.mean(poly, axis=0))
    if not points:
        return np.zeros((0, 2), dtype=np.float32)
    return np.asarray(points, dtype=np.float32)


def _point_in_polygon(point: Tuple[float, float], polygon: np.ndarray) -> bool:
    y, x = point
    inside = False
    n = len(polygon)
    if n < 3:
        return False
    for i in range(n):
        y0, x0 = polygon[i]
        y1, x1 = polygon[(i + 1) % n]
        intersects = ((y0 > y) != (y1 > y)) and (
            x < (x1 - x0) * (y - y0) / (y1 - y0 + 1e-12) + x0
        )
        if intersects:
            inside = not inside
    return inside


def _point_in_rectangle(point: Tuple[float, float], rect: np.ndarray) -> bool:
    y = point[0]
    x = point[1]
    y_min = float(np.min(rect[:, 0]))
    y_max = float(np.max(rect[:, 0]))
    x_min = float(np.min(rect[:, 1]))
    x_max = float(np.max(rect[:, 1]))
    return (y_min <= y <= y_max) and (x_min <= x <= x_max)


def _point_in_ellipse(point: Tuple[float, float], ellipse: np.ndarray) -> bool:
    y = point[0]
    x = point[1]
    y_min = float(np.min(ellipse[:, 0]))
    y_max = float(np.max(ellipse[:, 0]))
    x_min = float(np.min(ellipse[:, 1]))
    x_max = float(np.max(ellipse[:, 1]))
    cy = (y_min + y_max) / 2.0
    cx = (x_min + x_max) / 2.0
    ry = max((y_max - y_min) / 2.0, 1e-6)
    rx = max((x_max - x_min) / 2.0, 1e-6)
    return ((y - cy) ** 2) / (ry**2) + ((x - cx) ** 2) / (rx**2) <= 1.0


def _point_in_shape(
    point: Tuple[float, float], shape: np.ndarray, shape_type: str
) -> bool:
    if shape_type == "rectangle":
        return _point_in_rectangle(point, shape)
    if shape_type == "ellipse":
        return _point_in_ellipse(point, shape)
    return _point_in_polygon(point, shape)


def compute_inclusion(
    boxes: np.ndarray,
    shapes: Iterable[np.ndarray],
    shape_types: Iterable[str],
    exclude_mode: bool,
) -> np.ndarray:
    shapes_list = list(shapes)
    types_list = list(shape_types)
    if boxes.size == 0:
        return np.zeros((0,), dtype=bool)

    if not shapes_list:
        return np.ones((len(boxes),), dtype=bool)

    centroids = np.column_stack(
        (
            (boxes[:, 1] + boxes[:, 3]) / 2.0,
            (boxes[:, 0] + boxes[:, 2]) / 2.0,
        )
    )

    inside = np.zeros((len(boxes),), dtype=bool)
    for idx, point in enumerate(centroids):
        for shape, shape_type in zip(shapes_list, types_list):
            if _point_in_shape(
                (float(point[0]), float(point[1])), shape, shape_type
            ):
                inside[idx] = True
                break

    if exclude_mode:
        return ~inside
    return inside


def compute_inclusion_from_points(
    points: np.ndarray,
    shapes: Iterable[np.ndarray],
    shape_types: Iterable[str],
    exclude_mode: bool,
) -> np.ndarray:
    shapes_list = list(shapes)
    types_list = list(shape_types)
    if points.size == 0:
        return np.zeros((0,), dtype=bool)
    if not shapes_list:
        return np.ones((len(points),), dtype=bool)

    inside = np.zeros((len(points),), dtype=bool)
    for idx, point in enumerate(points):
        for shape, shape_type in zip(shapes_list, types_list):
            if _point_in_shape(
                (float(point[0]), float(point[1])), shape, shape_type
            ):
                inside[idx] = True
                break

    if exclude_mode:
        return ~inside
    return inside
