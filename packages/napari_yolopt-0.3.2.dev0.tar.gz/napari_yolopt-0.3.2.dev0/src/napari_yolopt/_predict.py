from __future__ import annotations

from typing import Tuple

import numpy as np
from scipy.ndimage import zoom
from tqdm import tqdm


def _to_uint8(img: np.ndarray) -> np.ndarray:
    if img.dtype == np.uint8:
        return img
    img = img.astype(np.float32)
    denom = img.max() - img.min()
    if denom < 1e-8:
        return np.zeros_like(img, dtype=np.uint8)
    return (255 * (img - img.min()) / denom).astype(np.uint8)


def _compute_iou(box: np.ndarray, boxes: np.ndarray) -> np.ndarray:
    x1 = np.maximum(box[0], boxes[:, 0])
    y1 = np.maximum(box[1], boxes[:, 1])
    x2 = np.minimum(box[2], boxes[:, 2])
    y2 = np.minimum(box[3], boxes[:, 3])

    inter_w = np.maximum(0.0, x2 - x1)
    inter_h = np.maximum(0.0, y2 - y1)
    inter = inter_w * inter_h

    area_box = (box[2] - box[0]) * (box[3] - box[1])
    area_boxes = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])

    union = area_box + area_boxes - inter
    return np.where(union > 0, inter / union, 0.0)


def nms_iou(
    boxes: np.ndarray, scores: np.ndarray, iou_thresh: float
) -> np.ndarray:
    if boxes.size == 0:
        return np.array([], dtype=np.int64)
    order = scores.argsort()[::-1]
    keep = []

    while order.size > 0:
        i = order[0]
        keep.append(i)
        if order.size == 1:
            break
        rest = order[1:]
        iou = _compute_iou(boxes[i], boxes[rest])
        order = rest[iou <= iou_thresh]

    return np.array(keep, dtype=np.int64)


def load_model(model_path: str):
    from ultralytics import YOLO

    return YOLO(model_path)


def _build_scales(
    scale_min: float, scale_max: float, num_scales: int
) -> np.ndarray:
    if num_scales <= 1:
        return np.array([np.sqrt(scale_min * scale_max)], dtype=float)

    if num_scales % 2 == 0:
        num_scales += 1

    if scale_min < 1.0 < scale_max:
        k = (num_scales - 1) // 2
        left = np.logspace(np.log10(scale_min), 0.0, k, endpoint=False)
        right = np.logspace(0.0, np.log10(scale_max), k + 1, endpoint=True)[1:]
        return np.concatenate([left, np.array([1.0]), right])

    return np.logspace(np.log10(scale_min), np.log10(scale_max), num_scales)


def run_multiscale_prediction_uint8(
    img_uint8: np.ndarray,
    model,
    scale_min: float,
    scale_max: float,
    num_scales: int,
    iou_thresh: float,
) -> Tuple[np.ndarray, np.ndarray]:
    scales = _build_scales(scale_min, scale_max, num_scales)

    all_boxes = []
    all_scores = []

    for scale in scales:
        img_scaled = zoom(img_uint8, scale, order=1)

        rgb = np.repeat(img_scaled[:, :, None], 3, axis=2)

        # predict
        results = model(
            rgb,
            verbose=False,
            device="cpu",
        )

        for result in results:
            if result.boxes is None:
                continue
            boxes = result.boxes.xyxy.cpu().numpy()
            scores = result.boxes.conf.cpu().numpy()
            if boxes.size == 0:
                continue
            boxes_scaled = boxes / scale
            all_boxes.append(boxes_scaled)
            all_scores.append(scores)

    if not all_boxes:
        return np.zeros((0, 4), dtype=np.float32), np.zeros(
            (0,), dtype=np.float32
        )

    all_boxes = np.concatenate(all_boxes, axis=0)
    all_scores = np.concatenate(all_scores, axis=0)

    keep_idx = nms_iou(all_boxes, all_scores, iou_thresh)
    return all_boxes[keep_idx], all_scores[keep_idx]


def run_multiscale_prediction(
    image: np.ndarray,
    model,
    scale_min: float = 0.5,
    scale_max: float = 5,
    num_scales: int = 20,
    iou_thresh: float = 0.5,
) -> Tuple[np.ndarray, np.ndarray]:
    img_uint8 = _to_uint8(image)
    return run_multiscale_prediction_uint8(
        img_uint8,
        model,
        scale_min=scale_min,
        scale_max=scale_max,
        num_scales=num_scales,
        iou_thresh=iou_thresh,
    )


if __name__ == "__main__":
    print(_build_scales(0.5, 5, 5))
