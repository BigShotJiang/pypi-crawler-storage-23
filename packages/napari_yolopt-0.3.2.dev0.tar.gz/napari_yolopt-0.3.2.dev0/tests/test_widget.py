from napari_yolopt._widget import YoloOptWidget


def test_yolo_widget_instantiation(make_napari_viewer):
    viewer = make_napari_viewer()
    widget = YoloOptWidget(viewer)
    assert widget.viewer is viewer
