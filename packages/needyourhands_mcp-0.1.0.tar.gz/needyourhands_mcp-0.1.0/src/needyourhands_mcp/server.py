"""
NeedYourHands MCP Server.

Exposes eight tools over the Model Context Protocol so that AI agents can
search for, book and manage human workers on the NeedYourHands marketplace.

The server communicates with the FastAPI backend via httpx.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .tools import (
    BookHumanInput,
    BookHumanOutput,
    GetAvailabilityInput,
    GetAvailabilityOutput,
    GetTaskStatusInput,
    GetTaskStatusOutput,
    RateHumanInput,
    RateHumanOutput,
    SearchHumansInput,
    SearchHumansOutput,
    SubmitTaskInput,
    SubmitTaskOutput,
    CancelMissionInput,
    CancelMissionOutput,
    VerifyProofInput,
    VerifyProofOutput,
)

logger = logging.getLogger(__name__)

API_BASE_URL = os.getenv("NEEDYOURHANDS_API_URL", "http://localhost:8000")
API_KEY = os.getenv("NEEDYOURHANDS_API_KEY", "")

server = Server("needyourhands-mcp")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _headers() -> dict[str, str]:
    """Return common HTTP headers including the API key."""
    headers: dict[str, str] = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if API_KEY:
        headers["X-API-Key"] = API_KEY
    return headers


async def _api_call(
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Make an HTTP request to the backend API and return the JSON body."""
    url = f"{API_BASE_URL}{path}"
    async with httpx.AsyncClient(timeout=30.0) as client:
        if method == "GET":
            resp = await client.get(url, headers=_headers(), params=payload)
        else:
            resp = await client.post(url, headers=_headers(), json=payload)

        if resp.status_code >= 400:
            error_detail = resp.text
            try:
                error_detail = resp.json().get("detail", resp.text)
            except Exception:
                pass
            return {"error": True, "status_code": resp.status_code, "detail": error_detail}

        return resp.json()


def _format_response(data: dict[str, Any]) -> str:
    """Format a response dict as a human-readable JSON string."""
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

TOOL_DEFINITIONS: list[Tool] = [
    Tool(
        name="search_humans",
        description=(
            "Search for available human workers on NeedYourHands.com. "
            "Filter by skills, location, budget and urgency. "
            "Returns a ranked list of matching workers with ratings and availability."
        ),
        inputSchema=SearchHumansInput.model_json_schema(),
    ),
    Tool(
        name="book_human",
        description=(
            "Book a specific human worker for a task. "
            "Creates a mission with the worker, sets up escrow payment. "
            "The worker will be notified and can accept or decline."
        ),
        inputSchema=BookHumanInput.model_json_schema(),
    ),
    Tool(
        name="get_availability",
        description=(
            "Check the availability of a specific worker for a given date. "
            "Returns available time slots and the next available date if not available."
        ),
        inputSchema=GetAvailabilityInput.model_json_schema(),
    ),
    Tool(
        name="submit_task",
        description=(
            "Submit a new task to the marketplace without pre-selecting a worker. "
            "The platform will match the task with the best available workers. "
            "Returns the task ID and number of matching candidates."
        ),
        inputSchema=SubmitTaskInput.model_json_schema(),
    ),
    Tool(
        name="get_task_status",
        description=(
            "Get the current status of a mission including proofs, worker info, "
            "ETA and full timeline of events."
        ),
        inputSchema=GetTaskStatusInput.model_json_schema(),
    ),
    Tool(
        name="rate_human",
        description=(
            "Rate a human worker after a mission is completed. "
            "Provide a 1-5 star rating and optional comment. "
            "This helps improve future recommendations."
        ),
        inputSchema=RateHumanInput.model_json_schema(),
    ),
    Tool(
        name="cancel_mission",
        description=(
            "Cancel a mission with a reason. Payment is automatically refunded "
            "(if captured) or the authorization is released (if escrowed). "
            "Completed and already-cancelled missions cannot be cancelled."
        ),
        inputSchema=CancelMissionInput.model_json_schema(),
    ),
    Tool(
        name="verify_proof",
        description=(
            "Verify (approve or reject) a proof submitted by a worker. "
            "When all proofs are approved, the mission is automatically completed. "
            "If rejected, the worker can resubmit new proofs."
        ),
        inputSchema=VerifyProofInput.model_json_schema(),
    ),
]


# ---------------------------------------------------------------------------
# MCP handlers
# ---------------------------------------------------------------------------


@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """Return the list of tools offered by this MCP server."""
    return TOOL_DEFINITIONS


@server.call_tool()
async def handle_call_tool(name: str, arguments: dict[str, Any] | None) -> list[TextContent]:
    """Dispatch a tool call to the appropriate handler."""
    arguments = arguments or {}

    try:
        if name == "search_humans":
            result = await _handle_search_humans(arguments)
        elif name == "book_human":
            result = await _handle_book_human(arguments)
        elif name == "get_availability":
            result = await _handle_get_availability(arguments)
        elif name == "submit_task":
            result = await _handle_submit_task(arguments)
        elif name == "get_task_status":
            result = await _handle_get_task_status(arguments)
        elif name == "rate_human":
            result = await _handle_rate_human(arguments)
        elif name == "cancel_mission":
            result = await _handle_cancel_mission(arguments)
        elif name == "verify_proof":
            result = await _handle_verify_proof(arguments)
        else:
            result = {"error": True, "detail": f"Unknown tool: {name}"}
    except Exception as exc:
        logger.exception("Error calling tool %s", name)
        result = {"error": True, "detail": str(exc)}

    return [TextContent(type="text", text=_format_response(result))]


# ---------------------------------------------------------------------------
# Individual tool handlers
# ---------------------------------------------------------------------------


async def _handle_search_humans(args: dict[str, Any]) -> dict[str, Any]:
    """Search for workers matching the given criteria."""
    inp = SearchHumansInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "search_humans",
            "params": {
                "skills": inp.skills,
                "location": inp.location,
                "radius_km": inp.radius_km,
                "budget_max_eur": inp.budget_max_eur,
                "urgency": inp.urgency,
            },
        },
    )
    if data.get("error"):
        return data
    output = SearchHumansOutput(**data)
    return output.model_dump()


async def _handle_book_human(args: dict[str, Any]) -> dict[str, Any]:
    """Book a specific worker for a task."""
    inp = BookHumanInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "book_human",
            "params": {
                "human_id": inp.human_id,
                "task_title": inp.task_title,
                "task_description": inp.task_description,
                "location": inp.location,
                "deadline": inp.deadline,
                "budget_eur": inp.budget_eur,
            },
        },
    )
    if data.get("error"):
        return data
    output = BookHumanOutput(**data)
    return output.model_dump()


async def _handle_get_availability(args: dict[str, Any]) -> dict[str, Any]:
    """Check worker availability for a given date."""
    inp = GetAvailabilityInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "get_availability",
            "params": {
                "human_id": inp.human_id,
                "date": inp.date,
                "time_range": inp.time_range,
            },
        },
    )
    if data.get("error"):
        return data
    output = GetAvailabilityOutput(**data)
    return output.model_dump()


async def _handle_submit_task(args: dict[str, Any]) -> dict[str, Any]:
    """Submit a task to the marketplace."""
    inp = SubmitTaskInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "submit_task",
            "params": {
                "title": inp.title,
                "description": inp.description,
                "required_skills": inp.required_skills,
                "location": inp.location,
                "budget_eur": inp.budget_eur,
                "deadline": inp.deadline,
            },
        },
    )
    if data.get("error"):
        return data
    output = SubmitTaskOutput(**data)
    return output.model_dump()


async def _handle_get_task_status(args: dict[str, Any]) -> dict[str, Any]:
    """Retrieve the current status of a mission."""
    inp = GetTaskStatusInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "get_task_status",
            "params": {
                "mission_id": inp.mission_id,
            },
        },
    )
    if data.get("error"):
        return data
    output = GetTaskStatusOutput(**data)
    return output.model_dump()


async def _handle_rate_human(args: dict[str, Any]) -> dict[str, Any]:
    """Rate a worker after a mission."""
    inp = RateHumanInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "rate_human",
            "params": {
                "mission_id": inp.mission_id,
                "rating": inp.rating,
                "comment": inp.comment,
            },
        },
    )
    if data.get("error"):
        return data
    output = RateHumanOutput(**data)
    return output.model_dump()


async def _handle_cancel_mission(args: dict[str, Any]) -> dict[str, Any]:
    """Cancel a mission with a reason."""
    inp = CancelMissionInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "cancel_mission",
            "params": {
                "mission_id": inp.mission_id,
                "reason": inp.reason,
            },
        },
    )
    if data.get("error"):
        return data
    output = CancelMissionOutput(**data)
    return output.model_dump()


async def _handle_verify_proof(args: dict[str, Any]) -> dict[str, Any]:
    """Verify (approve or reject) a worker's proof."""
    inp = VerifyProofInput(**args)
    data = await _api_call(
        "POST",
        "/api/v1/mcp/tools/call",
        {
            "tool": "verify_proof",
            "params": {
                "mission_id": inp.mission_id,
                "proof_index": inp.proof_index,
                "approved": inp.approved,
                "rejection_reason": inp.rejection_reason,
            },
        },
    )
    if data.get("error"):
        return data
    output = VerifyProofOutput(**data)
    return output.model_dump()


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


async def _run_stdio() -> None:
    """Run the MCP server over stdin/stdout (local mode)."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def _create_sse_app():
    """Create a Starlette ASGI app with SSE transport (Cloud Run mode)."""
    from mcp.server.sse import SseServerTransport
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse
    from starlette.routing import Mount, Route

    sse = SseServerTransport("/messages/")

    async def handle_sse(request):
        async with sse.connect_sse(request.scope, request.receive, request._send) as streams:
            await server.run(streams[0], streams[1], server.create_initialization_options())

    async def health(request):
        return JSONResponse({"status": "ok", "server": "needyourhands-mcp", "version": "0.1.0"})

    return Starlette(
        routes=[
            Route("/health", health),
            Route("/sse", handle_sse),
            Mount("/messages/", app=sse.handle_post_message),
        ],
    )


def main() -> None:
    """CLI entrypoint. Uses SSE/HTTP when PORT env var is set (Cloud Run), stdio otherwise."""
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    logger.info("Starting NeedYourHands MCP Server v0.1.0")
    logger.info("Backend API URL: %s", API_BASE_URL)

    port = os.getenv("PORT")
    if port:
        import uvicorn

        logger.info("Running in HTTP/SSE mode on port %s", port)
        app = _create_sse_app()
        uvicorn.run(app, host="0.0.0.0", port=int(port))
    else:
        logger.info("Running in stdio mode")
        asyncio.run(_run_stdio())


if __name__ == "__main__":
    main()
