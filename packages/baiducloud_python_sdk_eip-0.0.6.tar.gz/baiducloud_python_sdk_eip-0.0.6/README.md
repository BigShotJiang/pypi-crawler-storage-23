English | [简体中文](README-CN.md)

## Baidu Cloud eipApi SDK for Python

## Requirements

- Python >=2.7, !=3.0.*, !=3.1.*, !=3.2.*, <4

## Installation

- **Install with pip**

Python SDK uses a common package management tool named `pip`. If pip is not installed, see the [pip user guide](https://pip.pypa.io/en/stable/installing/ "pip User Guide") to install pip.

```bash
# Install the baiducloud_python_sdk_eip
pip install baiducloud_python_sdk_eip
```

## Issues

[Opening an Issue](https://github.com/baidubce/baiducloud-python-sdk/issues/new), Issues not conforming to the guidelines may be closed immediately.

## Usage

[Quick Examples](https://github.com/baidubce/baiducloud-python-sdk/blob/master/docs/Usage-EN.md)

## Changelog

Detailed changes for each release are documented in the [release notes](./ChangeLog.md).

## References

- [Latest Release](https://github.com/baidubce/baiducloud-python-sdk)

## License

[Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0)