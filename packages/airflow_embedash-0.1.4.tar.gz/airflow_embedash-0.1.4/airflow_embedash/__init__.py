"""Airflow Embedded Dashboards package."""
 
from __future__ import annotations
 
__version__ = "0.1.4" 

 