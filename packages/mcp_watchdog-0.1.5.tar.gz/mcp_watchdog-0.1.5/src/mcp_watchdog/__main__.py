"""Allow running as `python -m mcp_watchdog`."""
from mcp_watchdog.cli import main

main()
