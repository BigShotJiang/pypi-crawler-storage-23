"""mcp-watchdog: MCP security proxy - SMAC-L3 for AI coding assistants."""

__version__ = "0.1.5"
