
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""The Python Fintech package"""

__version__ = '7.9.1'

__all__ = ['register', 'LicenseManager', 'FintechLicenseError']

def register(name=None, keycode=None, users=None):
    """
    Registers the Fintech package.

    It is required to call this function once before any submodule
    can be imported. Without a valid license the functionality is
    restricted.

    When calling this function without arguments, the license
    information will be read from the environment variables
    FINTECH_LICENSE_NAME, FINTECH_LICENSE_KEYCODE and
    FINTECH_LICENSE_USERS or alternatively from a license file
    referenced by FINTECH_LICENSE_PATH or a file available
    at one of the following locations (*new since v7.9*):

    Unix:

    - $XDG_CONFIG_HOME/pyfintech/license.txt
    - ~/.config/pyfintech/license.txt
    - $XDG_CONFIG_DIRS/pyfintech/license.txt
    - /etc/xdg/pyfintech/license.txt

    MacOS:

    - ~/Library/Application Support/pyfintech/license.txt
    - /Library/Application Support/pyfintech/license.txt

    Windows:

    - %LOCALAPPDATA%/pyfintech/license.txt
    - %ALLUSERSPROFILE%/pyfintech/license.txt

    :param name: The name of the licensee.
    :param keycode: The keycode of the licensed version.
    :param users: The licensed EBICS user ids (Teilnehmer-IDs).
        It must be a string or a list of user ids. Not applicable
        if a license is based on subscription.
    """
    ...


class LicenseManager:
    """
    The LicenseManager class

    The LicenseManager is used to dynamically add or remove EBICS users
    to or from the list of licensed users. Please note that the usage
    is not enabled by default. It is activated upon request only.
    Users that are licensed this way are verified remotely on each
    restricted EBICS request. The transfered data is limited to the
    information which is required to uniquely identify the user.
    """

    def __init__(self, password):
        """
        Initializes a LicenseManager instance.

        :param password: The assigned API password.
        """
        ...

    @property
    def licensee(self):
        """The name of the licensee."""
        ...

    @property
    def keycode(self):
        """The license keycode."""
        ...

    @property
    def userids(self):
        """The registered EBICS user ids (client-side)."""
        ...

    @property
    def expiration(self):
        """The expiration date of the license."""
        ...

    def change_password(self, password):
        """
        Changes the password of the LicenseManager API.

        :param password: The new password.
        """
        ...

    def add_ebics_user(self, hostid, partnerid, userid):
        """
        Adds a new EBICS user to the license.

        :param hostid: The HostID of the bank.
        :param partnerid: The PartnerID (Kunden-ID).
        :param userid: The UserID (Teilnehmer-ID).

        :returns: `True` if created, `False` if already existent.
        """
        ...

    def remove_ebics_user(self, hostid, partnerid, userid):
        """
        Removes an existing EBICS user from the license.

        :param hostid: The HostID of the bank.
        :param partnerid: The PartnerID (Kunden-ID).
        :param userid: The UserID (Teilnehmer-ID).

        :returns: The ISO formatted date of final deletion.
        """
        ...

    def count_ebics_users(self):
        """Returns the number of EBICS users that are currently registered."""
        ...

    def list_ebics_users(self):
        """Returns a list of EBICS users that are currently registered (*new in v6.4*)."""
        ...


class FintechLicenseError(Exception):
    """Exception concerning the license"""
    ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzcfXdcW0e66GkqiGqMaW64IxAC94ZbbGw6jsENFxBIgGwQoAIGCxuMsSjGuPcC7ti44N7tzKSX3exuNutos9kku+nJluTem6x3N37fzJFEdeJk331/PPjp6OicKd/M'
        b'fH2+mfkT0+1PAZ+Z8DGZ4aJl0hktm85quWZOx+sEHVvNtbDpklwmXarltcJGRiPTSrRS+JaXy80ys7yaqWZZZjGjlaUyAqNzK5vEMukKlin30sp0igx3rRyuHvTek169'
        b'dIoNrFaWrlimKGVLGbdcpdujAYq0PF3I/DJzXqEhZK7eYNZl54UUabJXa3J1CiX/mQxA+8yNXFi42Fl1NtupBTx8ZI5v0zi42JgcVgtt2CivYGuZaqaCK3ezstUApZWr'
        b'ZlhmHbuOS+10D1DkKfnk7M7dIoXPZPj0JYUKtGtSGWVIsp35hrxOy5fDNbpIwsD3krjYzPz9Qz2ZT8S8f5vRyvQKIS1sEoGQszE2Pod3Qcn+PCidhXeFUki2RMJ9n3Ho'
        b'aCrahy9H4N14axquVS3Ctbgh8tnYtNgw3Ig3K3Ed3swzcxZK8YXZofo+XxxjTOGQ8fO9oV+8UZr5eWZ+zpeZoTrVhxGaWM2Xma9n+WXn5eRzlzYETRrLVOXJEtFtJWce'
        b'DDlGZru7x7hDoeGkyCRLRBiuj+SYweiygC/Mm2geCGnQuf7LUANqwk0JkAQ1oibZpHzGy5cfNAsdNJLRVfJ2LlRpJBgpXsjDRz7ROcbCcp0hJEdEjOl2L43JpDOaM7Is'
        b'+nyz3sCRxpPx8gjyYgXW6OHM2srbhRyLIdsuy8gwWgwZGXb3jIzsfJ3GYCnKyFDynWoil1bW6EXu3cmFFBJMCvaDi8+nUo5jpSy5Cqz0e3K1DCdtqlylTlCpkyPCUF1K'
        b'pz5FVb6MaqwEty7BJ/MJKMeLX2ZflzCTQuJeZP8ZiFgtQxHos+kWzixnlkzKrso6nH/L6kCg92fQt68HrWLf4pg1/63O7L+pdKaYxTqaB0Jj8rI9M1W/Xfis+DBtvZQB'
        b'iEO3hWTmn85cxliiCHDH0W102x2dVgFMtbgpNWqBOP6h6ohQXBsZFpfEogP4BrN8mTwRbRuhZC1DIRu+hg/3dYcmJaBzeHuEIhTXowvotMAEo7sC2o8vPmshw5kux7vJ'
        b'cEZOwTeh5eRWxrincJAFNVoGQYpkdAi3dhtxKd5Ohzx+jpK39INEi4NQQ4IXPhOhjE+SMNJUzh/fVFhIz0ehdnMClFyEqvHmuLgIjnFHezl8Oj+Vlr4mAbVH9sMNKbg+'
        b'PkmN6xLRWYHxRdU8rlTgi1A6AXI2AHAiIU4VF0HxUoKO4EOMF67nk9HOQRYytPh07mKSQLIkhREEFhJszbEQlEYnS1JWoysiQifF4UZlHJSPd/DoFqrF7dBZQZAqZ3zA'
        b'crw/YcxYSJCAt6TESRjvIfzUkOnwvj8pfmPMevUa8j4uSXzthc/zo5ENXYAUQ0g9N/GFme6xMEZFuAFvToCG4gvoJuOHD/L4JLo6DZpCalpoKsMNqmTOG2+JU6ml0BmX'
        b'OXwZ1ZRbBhDUH4fOlaNj4XhLIvS2ShkRL2H6DuLxjvHoIK1mNtqPmhNSIuLCAUvr4lTxkerYJCnaFMSoGAne5z+LFlOGLqHLBIxwbzd4r2YZd3yUw9fxBXzTooQEC3wt'
        b'CeQ92j4+nLRofmgC0PoWvBnQa36ElJktSHElagMMGAapx8fgq5C6LiXx2dDYRLwF7UabkxNTFpKUqimSGHSosAs74zoz3eOUk9tY4JW8TbBJbFKbzCa3udkUNnebh83T'
        b'5mXztvnY+th8bX1tfrZ+Nn9bgC3QFmQLtvW3DbANtA2yDbaF2IbYhtqG2YbbRthG2kbZQm1KW5gt3KayRdjUtkhblG20bYxtrG2cbbxtgm2ibVLOZAdPZmoF4Mks8GSG'
        b'8mSW8mHgxKmd7nvjyd7wGdCDJ29Kpj2SoZjdG78AZoGbQoFf4F0D6EDErV9OiWs6upAcoYxAtYS6fDN5dD51niWAoM1WyH3JHbCnAVCPZ7j17Ey0o8wSSJDuBj7gEY5a'
        b'VbESRkAbl6KLLK7GV4fTjHinz6hwfFtQRuBaQEcpOsOFo20ZNOMQT3SajJcKBl6Im4HvsOguvoUOU0pF+w1FCUBn5J1btoxFJ1BrlFhf0wy8HRhLLAFEiJ2Dr7Do8jx8'
        b'nBJYMLqyaimuD1crOYZD19j0AnSKAjISCGlPArJp0RmgTykjzedC09F5iuzoZDxuTsD1GHgHVDcM1U1n0Tk9vkbf4sP4PjqO76EzFFVZKHcLm1iBr4pvt+LDIQno9myK'
        b'eSqWkU7gAvBtfI+2gse3YsPRxaHxQGop0PyZnJdihti+5jwzbgjsAyWGRkCuNdzooRnim8awojX4EtB3KLTBwE7HO/AWcRTOLpmE23ENND6egLGXnYuuoR2U9NH+KSMp'
        b'rSjjItBOfIFj5Og+h2yj0VXaMQI6ZuqHmnFDkgow38rOGIXaxBHagU/ge0w6OovrySt0mU1DR2T0XWFfVJmAryxRJROiExhpMKdAJ/xogege3pRWXIwbYtE5yFbBznVb'
        b'ayFYmDQN3UmZAaxSTWCsZ+d5hlr8Ke+b5oP3oW3hatwoofUsWo+OUuaLbk3FR4CbECGBrgeyjNt4Dm1HNei6yBxtK/ElYEcEiHB1HPRlMrr4jIQJyBPGWPEmisKBkHpj'
        b'QjiRHvEgH24v4Rk3KYd2gTDZ9mTtaIJI9VwO9xN1o4296UZCDzrkk/Xs6i2CiUi6/SWffpG5/MGbz2194eFzW1+8snVbn5e9ct5P5Jn3Fs2cKDw6JwP1hiD4soXoWIIq'
        b'FPAb30HnElgYybNcWfpyqvtEoFZ0ShRzK3CVS9JRMYcOPCtqNlw3rYYqGXbBYtbnu9QXZr0PSCBjX6ZDfeELs1YZCUMx+nQrBZSVfs5yaJaNpBgyqkyV1797UVdIO6So'
        b'CZ0Np7IQqMrohatZdB/tX9NlOFjHJ9UJlxVugc2xySLk/q42dDTEy1CYUZiVYzFla8z6QkMtPPuGtEvgLGEE0U4BFuwDWqC9lBIfHpGcTJQSkBo8E44um/AGCd6P61DD'
        b'U0Cy8QchcXOCodtMnpFWU2xcjzePAwqIx2fH09qB9fniah7dlaMN2VynSjmmk0o9nVTKroKKM8g3C98sfHPwDRS7iodv+KwSmiXwS2gBS6iWSAeSTkqBzQVglTK7IiOj'
        b'oFBrydeBDirPyDBoCsidR0ZGsUWT7/gFSqq2MFtMoNVnm+FOainSQkvsnhkZJn2uQWO2GCGlkrPzWpPZzpuM2YAG3XGqQGNavZUAT5RZOSdnyb8XqyBIQFjIOD10NTAd'
        b'vEXKCCq0pQw4K640PZkkowlJsqLJYhNyJC7C5H4eYbJMb0aLNNkSCvfRaDM+iBpSqJqC6iKV8YnJUfhsUjyoD6D1TESbpKiGQ1u7lCg4wCXkaJrCUA7CA8hCjuAAlqPA'
        b'8gAsR4HlKYDcOj610z0Am9MbsIoewAIXyY7Jk5jmwIO1t9mzH36a+WXmy9pPM9PRw5cCf+Hz+gM0/99z0XzlCy/Pf+3By/NfePu55fjN15e8Nh+/+fxezu9sdmiuKpdw'
        b'Gs0Wj7EFWMmaQwid3OyPtpvQudhkUNDrjPiuSCF98FYeXcQb3JTiaCuFbpZLdxyQZGRr8kXGQvgGs54b7AMoIAcUkFdy35cHm/L0OeYMndFYaFRH5xdCatN0Nc0ksivB'
        b'LmiMuSa7dHUp+e7EgnoYTZxxJLkf5azcOAIuRxgXM/L9sBdmNJE09lAkPgQiBtcmhoM25JNOjUa8HRTQOhDcySA40TW8AzXIFkxmUP0MN3wdtJO9+uJDN3gqJo7eO/hF'
        b'5pIHW9GNd89sba+9W63c23Ko/VDroRGNk2uUNTdrju1uqb65qaW6NSgUv8MxH5sUix/HQVcTxomvSqJAHQaBWIIPocPsLHwYbXX2r6TX/u3Wye6dOpF2tYJ2taK/wPpw'
        b'CqlR6Uru+eQx6+PqNpJ8f0e3+X3SS7cRRR6fC13e0Wukz/AJHdja/dEtAZ0Oxkd/RLayNqaTbH06En5Kv4Mk2ULQAN+aMrYbBScB+tq6kPD0GWl6n1WvSEzEU3HlvTLH'
        b'SG697klGcvTeITUt1aMPj65xix1T9c7rmdslw1+CIfzrKUXYc0OVEjPVd5oTVa4hTGRnoSp8k0rkqeiwaJumJKsikkVp3AddMS/m0Ra0zWRWk8xH8B7QRIiODdZwaHyE'
        b'Gm1JgW5tCo9D50JHoEpUR7ItyZDnoPokM9Hd1bgpk5ZKkqH9mTSlmCwY7xLQhpE5ZjpClxeAqkRKpk0nzYZ6IdU46fBhkoHLB/6QSuBpMWTnafQGnTZDtya7EwkrQgWC'
        b'DvQftIQwZzYlaAmQsnctARA63IVhJMupDgzzsveCYYR4cRu+ZZqC2sKpSRsLPGhzQhLgGvAlKTOiXJICgnxDF3RwYhkRL07+S602F//92R4ugelNi5Mn55Mm3R0jl2vT'
        b'tynYma+uO2B6Z/nK3Ane/5ohGt5n0P2J4RFxoExXJ6KrDBi5R1l0FRTxS9QhM9X0tfdObzbUR/od+31govEr0ZGSmwEKwPzfuzNFmsFr08aJD5cu78sM134HtWcOQMVq'
        b'Rv/KyEiJqRDe5AyuS9BoNad1p3VfZhZpaq+26T7PPKP5PNOQE+Z7RpMOKH1la5+wF+V+v2nTcGc+PKs7r2nT+Ms+537tMTRzSs07bGzAEF28/6XfRvV7h39h34IlAwIv'
        b'trKvXrSPfYt7Q/W29EyOR877+SzjETXwjYGfAe8iCo3/enw1weVvkI/GtWgrVzh/QO885kelhZCnMeVRTBtJMU0+Rg7aAvkXdQcFy/1bkHg4fgn/4ioFiVHVgX+iAOjA'
        b'v96hYMVkFBNJ5vYOTPR9sxdMJK8EOToE5gyoKnDfDx0dAEZnlvuPuFbZbq7Vn6mlkA5x64F4HskWwrJDfPvjHVB1JNjaSyPRrWSKJ/E+QuJxDvpgZqZKvTJARB7vDF4r'
        b'4chdpio8cTljJIpsbxc7m6FfETyNMxHtuXaeLuL10QputE/NB9+OzNO9kjOsZNGytf4pF2uWvOMxNHzJpxtC33l15EuxhlUbXvPLGN30+E87hicHXny/9p9vZ32sCij7'
        b'a23JqNC5d3xG76vZ9k7YwvrTQVuLxjZV/PN3G147lG6JOfOHMxlfHajLXVz6uP5387+LfmvVkdnaIaMLhw7te3/T1YlDl68f7Tb0NX600p2yPrQB7+or2ji4MUWJG+NE'
        b'ruoP7K9thMDjM5mU9aHGmZ4mlVKJ6xPDIuKcbuAwtGf4Mgm6H4sPmYnrDhj1HnwTX05G58yOJJ64ks9BZ8cFoF2UhU/AVzy6uQ6JQYXapg3CV1GNmRr6d9BufBiM11pc'
        b'J40mhj7awkXoUZuZSCG0BR/3pFxYlYT3hAEXq+soajDaJuBt+CjabybWrhafmBUeTxwi6FR4YrKEcUftHD6E962lnmvcAtzkHNi5qjAlCAGwXMC6DUG2EGFlZAZtUZoS'
        b'3RJFA1STuEYUCgq8lUPX0I0FFFq9zs1hQh5GB5wmJL6MDlIIQKTsQNfDkyPiVFDvLaWSYzzkvHwlru7CzrtrX52oWFpkycrXixIjlNIxF+PF+gBZcY+lnB+QlOCgYELD'
        b'UomC9YB/kCRqVzl+vVbh7yJbkvL5DrL1udsL2ZLGLJqODoWHJoFmUpeIajyljBxf5FDlcnye1pMt7URmvvCRO8nMlyc2npUNYiqktTKrtJap5ipkVplpZLnMyjczVmkL'
        b'WyFfzBjcBMbMlvVnGfK/lDG4l4Iab5WTfFYpKSGa0bIkp7HSKikK1zMVEqukmWth5jArkpZzFW4VClK+1a2aM1bQmgS4S7NKm/kWWkazQNN6VLjX8pDO3crl8HrGqjjO'
        b'bgEjr3iuYSjN5QHwedS6WaXVLECsqJWTu2qW5pTTnPJuObOtHsaSWg8xhxNWljKX4ihypeW6AzTba9lapoQxbgdoJFquhXW0y5mGNUtzOEh3otadpjtRy5FSu6WSQopr'
        b'tRKaAr67ptDyzTKtoJVsBLN1DlPNQu96aqXNMqtns1wr08pbOPLE6mn8pdbN6unPVHjaZDZ3UCB5rQJyya08yVXhBe32qma18tWc8SOrl9YdxsHL4ON6Khi/0XqQuqxe'
        b'Law/ecdpPSu8rNxW1hgIULIESriXab2skD4AOHMOB+m8DUOtrJVbzcO7vlpvcu947q/1sYp3fTrlH6HtI+anbwRIQ2rztnprfSeSb09IE231oldvbV+rl9WTlEfeGWRW'
        b'b/KmaJbVk/w2i2NK2uADbfBbLUAuo9WHtE3br4SBX+niL8iTC3dy5/NCrfiLPIdW9tH6w29GG1DDBTHWPhR+H6g9sNaT1LBKYfVxwmAl7dxoZq3e1ewG1uwufrvlKoOS'
        b'0x7J8jVmvSFi9CNOFdJFADr9FdRJQig4F0hohaSC+CmYbVwxR7wQoqRmjUQzUnJ2Th1lZ83dXSeK6Hy9yZxdWFA0nYcaTBwlz/IB2Xm67NVgBnZYih0JH/EhhcZHrMpI'
        b'JOQjRWFOiLmsSBcywtQDRomTyEOcMLqT2VkrEdCciatlid/EAe/GDtCA/Y2mwrHkB5ifcSzRApwwD2I+I5U+8taElGjyLboQgCp0hElJpeyjQJOu2KIzZOtC9GZdQcgI'
        b'PXk9aoRp1KM+9AG5dT0S6LVvp5TO3I/cQgosJnNIli7kkbdOb87TGaHV0Blw/UxUwx+xox6xQx+5jTAtU6vVK+A5mVR81EcVkltodvbTFPgoPewSvUGrW2NXLCIAxxCT'
        b'Eh5BrSa7kF1YVGYXVuvKwByHmgu1OrtbVplZpzEaNfBiVaHeYJcaTUX5erNdMOqKjHSU7W5pUAEtSelrd8suNJiJVWG081CSXSA+J7uUdo/JLiGwmOxykyVLvJPQF+SB'
        b'3qzJytfZWb2dh1d2qUlMwK62y/WmDLOlCF4KZpPZaBdKyJUvMOVCdgKGXVJsKTTrlJ5PNqaf8gKIu9CFpXInOj4kyLSFiA+O+LY41ovKM+6xXJA7pJ2PQ4v1YP3huYIn'
        b'T/wdchDk4jfCY18fX3jiw/rCx0/qS9/5Q3oiHX1YgZPCty/88mIVnAdxoXBy+sSLIz61QBbk6mMOyvbj/KFEKJejjtaMdXnEdEoKnY63JKviQXfJ4Cejm3wXTyMRe1In'
        b'VXxIVARQVK1MM0NFTy6IKb5CsPImz2KpGZRX8tGDWDvIE2Fm5ax8NFCPMRQEHwvMPdQKQiKIaeaATfJBDPVF8lYBWL9AxIRpjFXIZaE8AcoOBWHFExECwiEJaJAIBYmW'
        b'lCfRClAGT37BNwhBUk7xOFG0GFO1QlGalohkiVVG65I63kvE2mk5XDRDfwuO30I0Uyy1ctSJLEkGMk4jg0lHdBG5pLnuyDOlxBhLxpk36cx2XqPVGok+aIwnr+R2GcG/'
        b'Ak2RXa7V5Wgs+WZAW/KIOEyNqc7S7HLdmiJdtlmnNS4mzxaQzNIfwbRO3mwSWKDNcJarZB2mkcD5UETzYR1IQIecoEog6wPvCBo5bOhpqMY9gU7wxaG6SDIVlyROnYWj'
        b'63hjmgTvRvvH9rA3SO2EeGltPWY+GTL3mePuNGysbKrDbOluD7n0KS1caskws3Ug4VcxRXJAMchoDAa08IQnLJGe1aw7aANUPgFCgNRja/lad3JfR3y+AgBCqlcAOB45'
        b'cpdD1c3KEQRK7cVpSrCa9Cn1x35KgBCsRFFgyhdCxTy5p0pSGOA7B5UBaNXsagbAgjsrAFLBG9wpeFLA7GHkDp5wLGPoY+Xps/G1RI0BGiDKVa2UYLxDwQLAoeTBFbyV'
        b'lgtpY2qlgKk8qDKCQUru4Tn9ZRWMi4ncAQqi5VgFRxmTQMX0BRVTMEtyuLLVLKiPLFMuQGdJiEjWwu91EhK9BHQBNGllST7HJAngGRk9u6xEY6Q+VD4XEBk4qnF1qXEe'
        b'wbH5IjZ2uE2XkgtFXj3FfJ3RqJQ/NYfswFuPDMobi6DiAlMiwVoSBiInGMt5UaYGjBEYVyDLVRKmCQYAJwALA4P+ka9MTnzDj7248ihNdrauyGzqkPdaXXahUWPu6izu'
        b'qApkdC4BgrQIyJsG0dAHxEWidP+5XJ+3y0gHAiGLRea5GurmAmg265zo4IkQGARtDOYUQeXBT26DU63IIcUVk3vFzxJJOS5wZI7KZrIOV0EILwwT56Ir0d5odKJPQmJy'
        b'ckSoUsq4qzl8XIv29fCmKhzfpnS46Jh0QLJ0jjIAmdOXkc7vdBO9G0CN7jkSGpAnr2bTBddzkVkQWvXIcaOBeuS9xMYITLqUIqjM3scRYDdXn69LLNRodcYuUsk5l0IZ'
        b'CPXlcVAscKNOcyn8U82lPH202hiGWsCH8SYTOhcam6SOS3p2lS+x61MS4yIW4NqU1FDCQ2ngCNqAT7stzcAX9a/cTJHQKbryV+59kfll5ueZeTlhHytpsNrLYrBa1peZ'
        b'v8hKf/DucztfuLJ12zb29OGPN00+PKJmyN6qsQOZ0dh92Y09Sgm18pV9I/FlvDmCREYVU7dE+HqOCbYIaJMQQ1Osyx3r8kmg86M7zfMOQ61mMsuoWjZfdAPUJeLGwWrR'
        b'D+DF80PQhiVm4h01jBkbHhEbp7Lg3cR1h69waGMKvmCeyxB/Nq4sRA2lNKiBBNfQgKA4fFXsBlRPqo7E9Ym4CW8mINThJmDdDCS4g+/ifZ64hUOnHBM4P8Iq5BkZeoPe'
        b'nJFB/QVEL2XWM+sVJi/QbBRseXAPHFE7M7gmiEy6/By7NJ++/YEJIqC0EnJvcdZtJIGmRkIqRFNiqpgq3y09HQk/BMKT8XW6iK88kAGRn9IcqQtnhZ+Hs71PVsqSaQwa'
        b'bkFVYxLQJXTCNWZ4K894oTO8j2+MiNb78VW0g0x907hLV7r5uDYNXXU6066ChrI8VIZ3jsHHLRGQbRW66i9mCg0FTIyNwPWoNS00Pgk3qdAGvTouIj4JxKG32zR8Z56F'
        b'MF4gnIWpEYt84mPxZmV8UiIkdxAQJByHdkuHA7T39b/ZVc+biKz5atixLzJfyTqtO61Z8mAvurG1fe+Fjcqa1k2zDrbsa69rr25dIrycK21fHThlyWuB9X+utO4Olo6+'
        b'aHUzyWbLTGPcx/6G2+21u2bzcx4HP2M+uel7PhpUNzPxDC3KysUNgwqJt03CCINYdBTbULuZKDbrUZs8XB23BO3o4koTVhaMoX5GQOWdyzpRIapEB0QHIaVDfBhV0dm7'
        b'wcugG/H9teqI2AiOkaLjXNSyaDqFmj0ZHUhQT2Djk1RxqNHlrpQwI+ZJ0v3wUecU39Nrg57ZRp3GrHNM4FN68XPQi9RKhKhA59iJvVA+uCfSdsntJE5CDEBBRLR1UM6T'
        b'Zx2Bhij5rHHRUClcyjrTkL+tFxr6MXB6EJK7E9NjnYTUWf1kuyigP5ukSEUuu8dFUl7JNGJzMTqOGhM6kxM+HChS1Ly1NKx5RKGlV3LqREt4O74n0tNiLc1TgG+jzU+g'
        b'J3wPb1B1IqgVqPWHo1AIuKDzOqJQlKydzenuSpFH52sKsrSa6VudTgmBsRATZxm6jA+bnsDh8fYEdC42CW1xoS3e5ZwNXyml8+H8GF8T2rHAF59jUBve1AdV4jbcQCeG'
        b'MyLRAYeLHpqqorIHnUK3GK8F/Gh8DG3v0irijiF2AlXRn2HolB3R9CUw6nS8XZo+T8W9AOPM03EW6Njy64TUTve9jTPHdDJFOk3dWcg0DT61BFUmkClGtRgIlBobTuL9'
        b'FgLhRwyNVuItiXELXYMqAeGoU+B769bROZUhaTIS7uzTPKXQ45XILKAP+tg/XM4AJUXN5PUq/cB54vzLF96DmGjCZBattR41rGYsxIs9Ge1mu1QuBkaDokFjk+bmqQjX'
        b'LFjvFohu4yMW4oEKHoT3J6DduCGBTIiCghKK6xaLHPZZF5xgwC7H7TJ8IRtv1I9+/zPBtB6yvnFgyrTNoxVopt+c3O//MjJ0ScJffCLfH6+688D/Ee8/JCT+14EbW6Nr'
        b'ZJbr21pzBn1zWLZvtl7+p5Ksj18NeKF98fwvdm/7qmCgMfCisSrYe9C0Nz59/w309b+v73vhVwHz2raMNdyuba0YULf/0qgT08JulwqzRy5v+e4j26h89Yx/NA0MlNco'
        b'5ZQzxqL2QMCPQ7N6zuKMEPiEInHuuhkdRjVRgHVdVSEHAx6dZybWbRYw4vZwV+QvahA1kgYZMwQ1oZZUiS8+FUrLk8CYnkxQd3DjEcpO/Bg3PkunTyrw3iWoIQVdoZPr'
        b'KQ6wPPElPjAT7RDnjE5MRVeW4TMJeItjBj5cDfq07zoeb/ZbRedQPDQxzrdkXtR9IoduoRbcGFhG2z8ct+KT+K7UFV/TJbimblyXiZafY355kfiZjCJjoZm6HqikCHFI'
        b'CmY9N5CaX6y/3If1BYkhVJL5F2pwje/JpnVrdNkOJt1hwnQtX+Q+EtE26jAmO+TJj4g458StlysrlSxr4bKfcC3SpUSyMFXBH/Uy0bOcYMtdvHP4j3KzQdpe+JkjuodH'
        b'2yfjdkkMvjkTXR2BWpXMULzLbxU+PDufwDhqSqDwX77MzL/1Naq+5q6NHjEyh6XT94pn97EXZe97es/MHPPumM1cMEMffz2YzOov9eLmv89+v0QTfIjRl45IEUwn4V2N'
        b'fN2IxASvDVF+1t9wBa3FMWjWncrSvzE31jz38oLa8FvtwysM0fzwQW/5Lv5mcDt/Ny5Pko3XHPQLb9k9dKXP2AlLvzhkeu6jZ7KmTuvHFT977sRDz5ffW9jQ/8zBfTO8'
        b'vrt4zXQn+9/P/+l5c8vx1H1n5rxy4taFhxdX5L/82nOyP989op/bNDVuyPQPG7w37PfKGvpw/POWhFmfbPEdu/p/cj9fmNb873f+sO7rjyN2N/5d6Smie32osdv8J96z'
        b'iNoaBnyaJsGnhqPdjklJtGtpJ2UKaHcrRfk1+DI6iS9r+d5oGZ2INpPgENTEKUSjxTmOqBYGDMYQRMg21EpIcYJWugJdFtW7YrL8IRw0rwn4oFP5MgwT1be7qHFtAroI'
        b'PKSrHJMw/ccLqGESOmUmsgYdyO6HGpaV/BxTh5g5/ABa3exgfN0h8aiei67RnDKmH67i8RV8Ae+kdtskXBkrRvoQoEhX7sUbGK+FfCi6VUwjKiS4AZ0TVyqQhSZydIJb'
        b'GrMmuojOReMbC9EOp1kn2nSJ6LBo1h3G180klHgdrhFngLtI33OoVZS+5/B2qreiW8F63JDIMuwkBtXMpl296QkBEz/bb8KKMQVikFonRkIZUpiLIUkVTuVVQf2axCOk'
        b'4IBBcdIAgfXjfDh/tnzgD7KmLuqs1PGsgwG5/TS4OWMF08VQtMJlU1dWFPKPXtTcHwZSKaMTIkZSiJEY6aIBWuqsgUTXZudrTKZsHbBXh33r8Z/MV7SydjdHmVAebYoJ'
        b'LkWsw9QGLYXjZP4s5zGStRASxNt98GUnH0XXM7rTA8dMQXelaF9fdKyHQ8U5mU5H1uk40vFawRmymyNoOS2/0Y04iqgjSEL9xhKXI2i+xgxdZ4BuS84WupXssqxnwsVh'
        b'DDg80zkyh4Io1MpAQZSAgihQBVFClUJhHdTTcf+k2FrXtGDnKEIadFEZCBJE7JPinM6WdTrapeTE5Xd78W60qbO1QBQAIG5cJzDBc4RYvImlhnq6YW3nVOFhKnQwVsoE'
        b'm4SFSnRDPypMJZjiIN0ng+xfZC6lgYjtJX1jr21sr26vvrlPz6bKEmSrZb9/5uP0TcGbhn7mtdvv5Ji5IZ5/1o2eOPbtqOfH/i5KGHucGZ3rzkRs9Qk5m6QUKOcx4GPj'
        b'nSx6E97amUe3TKQcQb0W3Qx3mbG4ajIXZVxKfUn8YHSaAp2A6gjnsqAm0Hd0PGqbp6fGNL6Pd0JrCNfCjfiyi3OtsUqdVq7sp2kwbjmABhnELO1i5jLrFTP8PIBD8MRf'
        b'LHxV3r8H5qhdOUX6kdr57HyTXZ5jyafx7XahCNLapWaNMVdn/tFgMcFYTe7JmgZjDblscjGFDXC505UpBOJemMIPwajkkomfvitbsLtTii3QmfMKtbQa4zpn9/Sce17v'
        b'AqgKLrdYh20oZzhuECsuethbmOWi6cvoAN4i77LKj5kaIgX77CCupXbKX1bzjDDuKBBcZuJXw41MD1OqKyl2mR5ykSJDwyx/fNFaj2g3AnvPaLegZGr6sBn4gAmUiivu'
        b'xRZ8DUTWddxuLsFX3UtQozdI+zNFHridYabhkxJ8EVVhm4UsGZCju+gO5KpLTMaN4ckLqbEeB191KRHOhcggdGtVatS+YKqUunavoFsKfL+i5EdXT/M0COWnxZbm9uaP'
        b'7pX/EKm/GDcVhaPTiQTqaWgH5RyQNI2HB4fxPXGp7K0p0BdAgAzeILYS7wpHraEsE4y2CUZ0MFn/quc9iSkR0n54ZlC/+nbPyigP4Y+DQ/dyo1MXFVXlbV2g3ZTrvjb1'
        b'w78kl354u6Hq+XnFyy+9lPWs/esPR96afHlhwMnG1NpzXtUPP/h0ZM2kvwx+6ZDvgvp6pYRqLbgKFPDzYAfRdWIB+LYUtXFjE8fReLN1+BreCLbZrvBYynSEiSw6j26j'
        b'u1SnQfdRizddkLMdHwVFK0JM5I2q+FXodH9qT6Fdifg+OjkTkpGFeJsBPyezqD0M3acVoDMlAxJUa6G5sWBIOwPabqKGJ1BMp8h5TVGRDkiRsATKaPxdjMZDK1BPmpyu'
        b'VxH+WR4G7CIjX5+tM5h0GTnGwoKMHH1nm6hTUc56KcP4AYc0K6agxEtiLT/syk18DvVi7TwLb3XoDJuQEkF0URLYdhtX0SFHjSnUcwHfotDubuOIYX+Ei4udrEWHfQrQ'
        b'abxPXGl3Or04nHTv2AkcI0Hb8C18mEVX1qEWimJAXmfxHiCj9tISfKXYQ15U7FEs4OvLGf+pfC7ahw9T549Xho9pcDTovO1uniWeCi85vlRKKLZYwgz3FSrKU2hdpkIw'
        b'xkEa0dFcbIYhu8iBIXAQt1vITI8wIxkq2wEoXZcYFq9CZ/DOUlUo8XH0j0x0LthKlTtWj7Nkgfll99noAtpAF3Rkosuzu+ceH0Tz95p7d74C1/ASuq54cYoGtOfLuLWo'
        b'GDWVAupeB4ZjBnX6Or6Ir1ugFakCqkL7Vop+93MWPwrpngTiCQApmSgzzWC88TZ+wTq1yH1voErA94ZIdKJbkaW43UMhZYbHCageV6FbVFumUb3RUNsRdHnWcEDKqczU'
        b'/Ol05ZgWXx4LVW0oTYmIA3XjQmycjPGYxuHD6OI06uJHR/BBrXsE8YUkLBZbKzI8tB/ZKEqgqwsIe1uBq2ToDjo02kKiHjUg7g+nuqOjUP9wZvhq1EzlwL8WuVEnFmNa'
        b'5fHSmHTRibXSX3R4RRlLEh+VBjsdXm8MpnsBMA8G5aveVq8U076XR/cC8GGmlHtERMxjLCQ4yg8dLCYunfAEGqH6bGcwO4HoiyqZQlQpr8A3dfqXPnhLMM0A4hjGViTN'
        b'n5rMj/az/nLlX0fNmF4VmzauiAkLDh5qYHyPNq8dGhobfm7YrOyJqgWJL/S5eHs5E3/+Aftpn5feL9vRNvS1L/YdKhvW5L73QfgNs2KQG58e1dy01z3Sc8577w//8J2W'
        b'hDtDNZnPe7SkeVlXBUcHmPaeKt0+fETkzZg9SWMXeD/T5Hn+17+pHD912eGIsjL7GtP/rBy//2+T+62OtAT/snjqb/8QW/eL97ZfeGu654a/SQokdyp/v/P3zVWnF4/I'
        b'LZg3jg0fcLH83jtJ64uve33VdnuyflW/T94rXxT82W023+gpuF1I/7ri6757785ojzzf/72Rf7/rk2pbFPTRP6OfO/V9ZnTzil88bvOf+7fVrXtXRkziw7843mf8r7fe'
        b'Xt9/1lrZ+w1Mn0N//9Z30aPvh316/233RxNH/urrw1/98Z2UsVXj6geusr744feDDaGW6Kv3ld6iGXkuD7UkkC0yGvA2vENFeAbPuONLPIfv4T1mghNF6CJdlYRv+TFc'
        b'CTvLewU1uUfhw5NFNj4HVYmcHN/rKzLpK/iMe0JimBrZFonsxT2fw8dRbSx9PSBSRnYNoEMswZV+jBw3cBVoM75CVUghHlWHpwAoU6kc25wgA4Ducfi6e7rDLt46xcG+'
        b'2ATU6ODxDalizPK2mILwucCvauNUcSDOcb2E8Y7mc3xyqf6KqoFq6hPIhC4UrEwvjUgGpScgUZjptojmn4qOMGL0No3dbsd3Sfw2PoI3i+ptix4U+QbRsQhKRxsjRJCl'
        b'ihfwbtop6IpeGR6flMjiO3gnIwxh0aFUIHDCH0oz0QZHyYQTB62CQoD+AtA1ITY/TJRe+6Jxs1N0StfgZiI60W50j+rtC8HYcurtG9DJTno7Ohv2o461p9G6u1jp/XoV'
        b'clQ0Ejcbx4rCUVhKAtw8qIAEm51TKHw4X7Da4Y7z4X3YQM4Z4eFBF3wq2AGPPWigGieGxn3r4e7DCTKPRzTA7bEg8fjeWOeUza1cJ6H50wwHWsjDbkr5qV7EKIlH8cjN'
        b'w3vQvg5J2qsUlTArzXK0C98fpuRpSB26lIHPUO87nVWcOI7MK9aiC1QgILhBe8DAuoYbktG5RIcHGF3l8ImRCro6PtKADoSPHg9IGCYFbGvmxqYkZ/PdNMEApzaYCZce'
        b'204wro0n2G5bT3A2/5wA13yJ5KnmS0Ad/eAMVKoI6fS3QJerN5l1RlOIOU/XfSsktaJL2jhziN4UYtQVW/RGnTbEXBhCHMSQEZ6SbW/ISuyQQhLpmqXLKTTqQjSGshCT'
        b'JUt0i3QpKltjIJGs+oKiQqNZp1WHLNaDFWQxh9AQWr02xIGcFCpn2fDCXAYgdCnJqDOZjXrin+4G7eI8nYECqDfkdoOx1FmZMddSoDOYTSpaj6POLqXoDdCSAo0jG7QW'
        b'oDbqNNoQQjU0l85QojcWGkg5ALtRT+JXu4I4Ny45LWZ2bEZi3OyY5NSYjORZSTGqHk8TYpbOTpkTA52m/cHcC1NjFqSSuF9NPoybAUAr0eWXifBoXP1G6LlbP+XojCSQ'
        b'WBuSVdaj0Pmz0mJpmTRjiKZEo88nDelShMYMo0ujm+moFObnF5aSziWqMekgU0homEFXGmLSExwomaieHKac0nVQFhr0a7o9iggZvmTOvIzZKclz4+ZlxKYkxUQWlTm2'
        b'Xop0NEdtXmPulmldpDq70JCjz32q1J2rmBO3IPWpMkXqzNmRa7RPqqFL6iRNdkpqj5ati0zUZxk1xrLIWUVFkFfEo1RLEUH7p4PhpxfQlQr0Bm1hqakHZCMSU2bPSpw1'
        b'f/6cWWmzRjwVKCNmJSZS5Ju/IGVuXGLMk3J1yTaFRuyFEJfMlBCy6Rq5c6KQIxfwmV6yrNaVkdhzMZfjR7eM2pAS4FzQI70WYDHBSzG7K33MM3GzU+mbEL0W8DVNp883'
        b'6PIKdMaIuDkmZddyyB/wPGfYvSaEcBrAd0onZEUCAcdZljokuRA4ijhK3SmH/OlzOpEncKMsDQEIRhM4pCnbqC8y92hID+elF9NLFMMkarXNx9dTI2m4jjouYsHiWDAG'
        b'U2PjJQsmT0atSgW+ie+gY2WT0a6ZQyf3I1vWnPYIQvUrewgkH2cNC7oKJMYhkliXSOJs3jk+P3HKvodHlkj04B6NikiGdFTa94w17hl65XASu0KvfvYGLqSqnkt/JY7N'
        b'P4j2pLdlvSOYSAznXyad+iIzIidO45HzaeZnmQU5XzKXZmmnzB6bHZwaNHtbnmxY7J0d45tuVo8fGFsaZYmqnLM/aEVg1gurn3u0KnB40IPyffuDEoIazEFBD0ZueCEg'
        b'SiVczleuCFR8NGVJQJRam6n9NFO6z+f1B/tYZqN0YGVMuJKjSuhCvGVyeERoLDocSj24+7mIvugEDfXD19BmVEf30GEZwcImLsN16LrbTw9AkmSUGjVFVBskuo6oC4I2'
        b'OF9gA0GPk3I+rB8oWr50WUO50uhQITrF6jrZQccTUqLTX0JD5J9+2pgVM1C9j+yxkgSQmQa49D6myr+9F82PoEcBasbHw51E0XmnB3RuvmOzhw6NMMZXGRkPyvlcdNpb'
        b'Pwrv/5EoVZ66RH/6jh89vIISpjevoCzZQmI0A8GIrhwbNW7MhNHjx+Ldnug6umg2G0uKLSbqqriCL4EO2o6v4svecg+Fl5unO2oC7XQzx4C5f90Nn4Mmt4i7+01JYHYy'
        b'jDyznzl++DPrReO9YGossxWs/wfa8lULxoY50Pz5TWs4agmcMxf0e6nFszLKR/Lm4wu5U9gQ+WsXWf/lfWPnN/817c0bSS/lTTxxes+eTyd9oGqJ1ezu99KdhgYbt2P4'
        b'0lsflFae1Suu30tY/OLjtqi9yXnDD++98uuHN4asHHy2zW/osCbAaBqyfGp2ltPkY/AevI/afLHoGrXZ4hdhskNY/VoazeF0CeJ96PoPha/9eDSqsdCckUU8YM6QNieS'
        b'rxQAsf0oapPVPOWqp0JvR3HO+UnXIpAfjlOlKTqQuxEuy7ojt++xXpA7hqGbrh3BF3vF7t5QG9dHorqUMRN4Bu8cWIIafNS4Cm2hODBoCM8clxFIMz1WhKQy1FuE2wqj'
        b'8Q7AS/UsXMOoZegMTXt6qIyx5gGAIZmqtgkaEYk2DZYwLxcFkHXo+bVCkohE9M3jRXJmecVIKDnTw8tzgPhQSIlnboSrWcYnU3G733Lx4aTZPkx0ymyGKcrMPzjTwIib'
        b'KlwejM6l4ka8c+H4+VlRuF5gpAtY1BaL79NMH2UFM9ExBSC2MqP/HG4QSzoSdZGtBFHxN/fqVYGBUcvFPc7aFiSlIlIQ2XrM5M9nstPRIW9xY5hLMRLiVHf6p1LxIXQu'
        b'FNeq4sm8AXEo0IAr3BROjHJgsQolJL9HA0DaZFKy+V7m3gTG450lf9Z+zuSTGdfmgFHycRP8x7CZiQnG7IiJRfN/MWFBziieWoYKdAPvw5dB3CSh3dPhch83Ucgnq6Yy'
        b'WuVXpDm+TW46sTkB8hlkr63Qmfpic2D+6vX04cWk6Yw25B9AuJm+s0KXiCknh6vYTI7xeaCPXvcw1XMwfbhjyu/YKzwT+2BxQeYSby8lfRjlNo/dyTEzH0hOlgQWjJpI'
        b'H74Q3Y+NAvR7MH1xWaCcX0gfhqy0MH+D75mrtasD1xln04dBq9PYTwsXSxgfjfvFiLVi7TEV29hQHjgJP9T6UD1TDJyLUC9lbkB7ZlZ8Xf5Qs0FHH74ZMZRN5JhJD9a1'
        b'WB5O2DtQRIqiQcwc0kzDudyH059Npw8HLk9km0mLLB+tCYyxO1Jm+LMvD10iAApO0yaWirWX5r7JCnHzZEymJsXKO7YuNRU/z0ya6ssDXsbZk1Xiw4lhVuaG7zcsMz/T'
        b'/75/kPjwn+V/YL6LLObh4WR54XgHns6CoTSOY+Ch6vbkgeLDCk0xUwlDVzT6X4a0ZL5A3zoBM6YD8CT64T8Xzk8wvDXT59znR776xxrf6YOirRzL/dlDNZm9PFP1cNq+'
        b'mhPbAocNmb/2o8qp/Xdayoc9VC2Ze5P/5H2P/EnMb+c+80zE785+++jmrTPPvH38uVf3TFSuSZj23+dTHpXd/3TPruoN0xN+f3r/uoX6wCUf/Osz26mtFuvhGo/zx79J'
        b'XKOODriyYcLD094btQcfPoidZ1j4+txVV5uD6175JuPU8/n1+rjVn6elHembUz3plOLFy02fD/ivpbs+fHA0dUHk5x8+9/WMFWsbzbNH+x/feH1k7YUJSaMM51s/4/Bv'
        b'w7K+kZz/7e3UP3+YUSCXffHdJ2dCtKvPpA35d/nl+4pVUcM8/W1j6v7b/vv0r+7bzEU3Jlx6PetUgPpUf3vGC2c0/pvNo6Z9MMVgvmWZ9aeRirZi9xETbjROvdGwdhKq'
        b'iH4wetCrw5vuoOx3vqwz//35/tEVyzb9q//94xfeGvneuBlDBt49+oeWlm9feSkj8e+xf9C9VDD0u8Q3754cuL456iX9S5GfNq7+TXOF78C/rlv7yY70jKKxB8Y82rPP'
        b'/b3Imcv27/Vd9PLbushd7y146/Ln3rF/rP/1rxOVclHUnPfCd1weQFSDr9MdHGYxVH9C1/oFhOPaSAadQBcYDrWw81ElOkL9khM8CsPjIxIi4tGtsGQJ4yHl8F2QszvE'
        b'abGaebhanLQa7euSUZYQWmrpwKHANlLiUJvA4H2cNJ8biqrwNupx9JWjK+FqZXx41khxu1jGG1fyhWgzPk49mrh5Cd5M3aW4wTe5k7cUNcyn8VZDQV7u6BlfiG+k8+gi'
        b'umf5qRExPv9JFMqPylyH2KQyN6+TzPVIJEFAPl6cwrlfhJdjLxiyvCoQ/n3ZASACB3AC3VRMQVbKsr68P8hpBct9z3Hy7wVeoBGOxBXJfe/BKyCvQF2SwuPy4CfLcNET'
        b'KaGr4ewyh5lpl1DbsZPw/s/XFLfyRrJJnrjsbptL5pP1xLHdZX7YtV5kPlE65+AduLVD5F8b+YNSX8IgGxgAYPnt8RYnjq70R81kYv302l7n1smM1RWLhJkGMhIfR1vx'
        b'Nct4kq12LG570nw83J/sA99mfK20WMI8u0qKyRzUURpn1BcdzHniRL5niacQoZAyc4qlCyX5dE2JsXguDWBwTRo5fKvTZsVJmEh0RYLbYtBuOl2OD+ETuKVjup8uaUEH'
        b'LT64hh80UUV5tZtBnK6KWvRwQklugUM9MNM91EOipJL4L7MV4sNpfRzzXXO3McZhkxj9pzO3C6bn4I1laP34LZO90EyPmK8Sd7+yUeNdu337dvciNj79+LhhW08fFaY0'
        b'Z2798qbkXb/L/TK+/mf5tddPxjW9/+afPMtm9lHWK09sNoadnj3t89/UvjjunaUBky2/GxT54Nph07eVTS+/kOKx23L3u+KhbTfb9sxIrkm49lX91eM7hw+6FvaweXbZ'
        b'7gTVtcXPLa9Kup1T9M4nO34xe/Ibsyeoj1S9pIzu84Ih/e03Pvv9mEXtX2bvetmzbYH6+MTCZQVXQnfc/G6S/Tnp9698G5nDTat99LnSTdxR555xnHsYbiVrgHrbNF2C'
        b'79CZiIn4PNnxtRHtGB5ONlztmDRCm33oNmi4LdwjIQVfHE53QmNnQYkNVFcXwBJpdU6gMOi+SZw/OYbOm0nwFD6LzuJdDgQdk+XwwuOmRBK9cFgoRNuRuF3PanxL0xmP'
        b'gS/im+iUbxiPTodFiHu7X11gWphKEnV4373QeX4Ovo+3U2Cy8Y4SvHkgaoiMSI7A9YlKKeM9gM9ALUMpMGg3PiEjIeCg6LWjJqLsuTYI7Y+2CeiYp85pOQf8X+eKP41x'
        b'OrkXZZxjOjFOYZ6c5biRrM9cshbcg6MB3uKWAhyJriRbt3kRlvlP4w5XmU2kSX7/T9qw3cXmSPXB3dncpD/3wuaInJ6lQ7col1uJdxFGxzHeE/icBHSl12ga8mfyYDuC'
        b'EbVsOq/l0gUtny7RCulS+MjgI89l0t3gW7GT3yloJY0s3TSORDMJWqlWRleuuus8tHKt20ZGq9C6N3LpnvDbg/72pL+94LcX/e1Nf3vDbx/6uw/97QMl0tkbKNNX23ej'
        b'PL2PqzbWVZufth+tzRfeycm/1r+RbB9KNiEO0AbSd317eRekDabv/By/+2sHQA39HL8GagfBL3+tQNfdDrZ7JYoiLklj0OTqjB/IuG5zP8Qz2jVNCI1I65Lox3LoTcQF'
        b'SmeDtGUGTYGeTLmUhWi0WuInNeoKCkt0ndyuXQuHTJDINZXi9Km63LU0hzpkfr5OY9KFGArNZEJIY6aJLSZyWEcXD6uJJAnRGYj/lU5zOPZsUDumrjTZZn2JxkwKLio0'
        b'0JksHanRkF/W1fG60CTOiGnIHFEn9zGdRirVlNGnJTqjPkcPT0kjzWQOBsrUabLznjA/5egFR61q2plmo8ZgIhMz2hCtxqwhQObrC/RmsUOhmU+ejMrTZ+d1n4+zGPRQ'
        b'OECi1+oMZn1OmaOnQPPpUtCjgXlmc5FpSmSkpkivXlVYaNCb1FpdpMOd/2ik83UODGaWJnt1zzTq7Fx9spK1y4sAY0oLjdonu8vofr4c9dOSZd2Sn76s+1FNT8e8QW/W'
        b'a/L15ToY1x5IaTCZNYbs7hOY5M8xOeCEWpwfgB/6XAP04az5ca5XPScDnmK7b2kynXPG9/AFkCp0AeASfKHnmtpO6//A/N9H9zFFrSZqR7j0n9BYFdgjajVuIru9T0B7'
        b'pGvxiUFKloYJCehqNNkePyVCjesWpePGFJbxRQd5XCXM1PMZ7womsu/DX799kay6Dc0iV9XHn2fGavLpKnW1f6gmXsNdDgqI+uZXpVGR2uUPLm1t2XGzWtlwtfpm9eiG'
        b'iJqbe1qrRxye5li7vnZ/n3X8Z2BJkQVZg8F4Ot5ZRncS5Pgyai/Ep/BlKqkLccssSNiK9vSQ1TPTqbgfi2x+7tDieXi30qWU9EM2QY4u4maqcqxg/cLxlthxAsPjY1p8'
        b'mzUMK6IW1AoS/eXoBXYwPsXI0VYOVaFqsNvoaR/90CncMBfVJUTI6K79CXj7emqXrUK30FZa6Jjx/PAVjKycxfvdCqndNQK3wQDsEGgDa5MSpQwoniy+CeN3zLkK6imC'
        b'FEjYf7dwQ2ruzKb7IoNc9mfLA7pibtdV763iSgfjXob50f0uWzkxWddl7zc5pxO/yvnv93wvwctPAuPJC1Pp0TDMKtee42QJgnM+r5UVwei6SNVYDpeXOcdO7VKmR6XO'
        b'NayPgp44UQjV8NrC7KcCK0cES57hsOqMh54A02sAj/Ew3Dzy6zRZ6JxzVD9VZRudlRFmq9eanljZL1yVqUhlTt2ul7nJ7Hw9MPEIE/By5dMB4Wixe4ZuTZHeSOXEE+H4'
        b'lQuOYQSOjhxEEHXv+K7VO5k73X2XMnfH7uc2SSfm/nSzIb0u4u05GwJslTilC7KGpeJGgej/zNAJqClWRx2qcfgQqkVnAUbUju9XMBV4Xx/KI1EbPjcKN8RR1X6sANyh'
        b'gZuH9sXji/iM3vuVR6xpGaT6+9dvD2x4pU9llAc/YtSAG4/0lS/mDeETV8WutC7f9AflyMivvswb3zruzp3Jb2rSJv1jR9qqa3+edLI166bMM3Ttv7JPRFybIp1a0JB1'
        b'4ZXJq9P3Tf90e9+P/sH4BAQJ6L5SIa5TO1ps6cwtAd5rnU2fyfiQGOG20zeW+JvjxABnfJvD+0yoDh+RiY6mIxHDXFMlZJoEHwgqi0RNYoDZNmjt7nCHI0lAhxYns+gi'
        b'Oimjb9fi3es7xVXjqpl0HqV+BmWjA9Dm6RS+rYrO/A7dxKfEiq/yJBJqSyQ5lkkYhWonsOjOJHyCFt0PbcdNdJMRxw4jzxahjeg02iXGC1bj7TmdNg8G/hw3rRCfxAfF'
        b'IMVjYGoexg2x0/AGdC7WwclBkJ3l8SbVzC5rZJ9ql3R5hs6QbSwrMlPOS82NDs67REE3VxNdSHT2sgfjc+TuvNLs6fYbduxL38F/ydbXb/XCf1ufhv86wPhfU6o29qpU'
        b'zc7TGHJ1YiyYUw1ysoJuKhZoSk+rXZGYoKdUqnpfwi8AV6NOnxUz0D2XzuPQeHYnUaUH8KxZ/9UWP96UDwlPbvm23+tDfFGUX8yvvv16xrh+K+bseZAetvfMfvnIo9Iq'
        b'/cI3ZjPLYkvsUbnn72ZVtX1d8PUzS9367ZoqlF2rvq/55MUv+98L+Uvs3z6OymqcGP1SQN39mye2Rn5VdO7dBB/Tnu/cvh4xMvHTwaO+q/WfeWKW0k1carmtUONUUgaM'
        b'IjoK2h0trq09Gw3I3YAPzUohOwCgM6pQlvHCjbwOn0WHqcYxWJhIj9HpIIA+iZQEdHg3JbIivJ8cUxEJOiQLxH0cV0Wy6DI+L6pjpaCZVIt7pyekoMbIWJWoNOI7fVkm'
        b'CjdLJ6ehSzR+gMdbJgMpR+Cr+J5DI0Jn51AiVyhTnJoUkGnjYKpJ4bZnHZwJteKDTn2JkY1AjURhQgcEykCi8I7l6CQ63F1jGoOu/XQS9s6maJjhxJledCiF3ovGpQ54'
        b'HMyVD+pGPN2yiyXvfyLlGg+4SLYVLn/shWQP90KyP1KrkrdL8wpNZr3W7gZEYTYQtcAuFdWDJy97pGQtuJY8SlxLHiVPteQRxOkHz7Dd7HzyN0urJXYSIcVOeoZoY7qk'
        b'/BPpWWyISM2xcB83x8kVsjSG1T1p2sUGHO0Wc84Xf0Lm0ASLASzUiLg5vYRcdQrfcuYk9jjJ1iVcS9kbvEad2WI0mKaEZKYZLbpMEnUl7kCjVYVkztXkm8RnmnwSxFkG'
        b'ag/Rvgzmn8WW+GR93YA/cqZkePDtwOIvMlc+ePO5h8+99dylrTd3t1S3VE9uaN/XfuT67vZNoxtaN7U0DTlYVTekpkoiP7AvKGhDkEdQve7VoKCgmVG+tamVWQf1jPb9'
        b'xDc8F577SslTrjAJRPAl1NCZa1jGEb4xAh2j1DypRO7gCdG4iREIS0CX8qnKET4JtSUkxqG6FCEqCdcnqtGWSBoQr0SbJegcuorbfjplemm02gxdlj7bRPVcSpi+XQjT'
        b'q5zMwQx/XD6wG3l0zSmaN1JRWp4hl7Pk0tZV0HY+fkrolMziSkup9jxcvuyFarf1tnT7B8H6X6NLEns9rze6XEAdZECaBhEXSXxhJwLt5Br7/49ESba41JQQ0allFn1g'
        b'1PTI0Rs0+SFaXb6uZ1Dk0xPntGG/FChx/k3xGSXO0u/+E/IMYhJ/6bn475uBOOl68avoCll9CNQ5EJ3rItan5YkBeU3o7pgOmX3Mj9Cn9wwz2S0/F99NDI/HjbgxMgE1'
        b'pnSh0BloC1EMZL747NqfTqN9RJ9rdzLtWFvtIFSFg1C7KXbqHtnFsi90I0jjRRf9XYLLP3uhvw290N+P1va/cJoQ0XWzeqE8ioaURAyWgiygNsC8Tp7qDv9vtsVoBCGR'
        b'X9bJXP+5SKm3LpbQ3c4+qi8nhwFe3NpCkXF0T2SMSuyGjiNe6yItHn7k3qb+3CEr0IX5uJ1i4zSvLsioA/uQLl86UuiFGvL6ONCR4GIy3mwmRktkhicx7sAyBXHRgYqo'
        b'Du0ii1dmoJuykMSSLqjY+2FCfbILLQZzp9E09Yp7ct8n4F6P7I5zCUWO36tgEB0cFA+vwEXBOzdBqur49/r6KTCxR93/O+daPTI8ERM7gsqfGgsdKy70hpCSCepxYb2w'
        b'6qfDyt+/dZOnWJny3L9+BCt/CCfbhwUxDz9xP9/c34GV4bNwtUOBmY+2dMLKQfioI2h5qbeLRUayGfgcujwSt1K0XI0vRounw6K6GHVnHglIOQnZpGAA7Z74FGjpQ/r1'
        b'x7Ey2IGVg7thRvfcYslXn4yI1+Hi2ysift7bpok/Up0yoPt+MkT82IUMizHf7kmuGc5pGru7a1WfXms8SNK2kMsxcjnBOJzCdnmRsbBIZzSX2eVOzyoNTrHLHN5Lu6KT'
        b'B5H4MahlRBUtyu0pqdFmin6Sn7GhcSd35E64HOccm0DKGYET3AW241/O+bGcp5TlSIfxvX/7CnJ3P9bDw4f18PJhvbx85XRGJRdtQ9c7YkTw1SQwkMHC5ZhQVIXqcaVk'
        b'PdqGz/SY1yGUP5NxKLddp5XF7cftfR1L5RxjR889eBQSs4bsy0ycqNlkHZzRIK49c6lvyWCB9jKWnfyzHb1yHy7BvGubD+gV1kLOsZqEr+MbHXug4YuO1unxjmTn7Em8'
        b'QkaiwNMt5LzIgFX4jDOCvEv4ONqV9VQR5Oiergcv7G3jTqbrmdkdO8f/3LPYSEU9fcEeyUqeBu1M91cwRJfyKTmwbgmzL4UG5CYCb3i3dAYZP493AmtHvsvkJ8HjY4Oi'
        b'JZ8F3sx9HNNfeXP1/Iwzg0+vvrVkQ+j+5BcnjVvaqDqUcm7qiSkrBv4m7GjWv1WPktZ7ftzfs+LOwouhG2ePj/8kuWzWB4OkwYoB7y55Jv1P02+PPLhgRlrdwJ1hdwYv'
        b'eyYybsGa33m3F341zs5vC1tQNGbAifEfz/kf7eGFm9zHqW5yM/uYhk6V3B/0hamkKDTgnZgz7kGet9Y/BgujeVmCRNyU4ZQKhqJhprWLqzo+F+8UY5bWcGIgk3RPcXn2'
        b'BDFmqWVdX4aEskQNUqWu9bOKD1cs82dUJJBJvbf41eixDA3gwjY9uoAbkiLU5DB05z6SuClBhreh1jJcF4PPoBNol2QEgzaOdMMt+CSy0eL2SQUxWGoRCtKuXSHW8dpY'
        b'ccF/1AQL97vRMnE/9G8q757+fTalHfbDan3c7uUCPVis/9S/jGhs98IhHnN+uXfjfIv36YTHrfffb1lw/fQwla74Mff9uLlLreWlbx+aX6N+tXz1X26El9b2/6/c/5ag'
        b'oA8H56XFLf5obo027rvv/vSPEUv7//v1m9sFN7fftoaf/9Vvjy6buP/75oGvTm3b8/F1fdq1mq2a0tcm/jkvf+XepbnL6nBQ9tfuf6/gdm8cmSf8SSlQJ9cCXOudEJnf'
        b'xR9diLb4003V8Bm8zeoe5gyQQreZrjFSFQtEf94edAYfQNuiwyPIqd6kJyWMO77F4evxuJ266xSongnH9WHEl4aOoS1k/e9kXI1P9FwG8HO3Xeu8v4nRpOni9iZo0Vm0'
        b'CSoFdXkTp7cPF0JZKrk3PucsqJW3CyQCoZOS9XMBa2WN2MXFSAUjehOFIb/rJfiHDsIBdBLdCA9LRpudjg98VAF6Q390SEBn56A7PZiRayOhOb0yoxy3/5QR9T4ppXAy'
        b'ogGp7oQRBc5wC8nfu+CrsZQR7SygKwNCmLkeOb9bYi37WmREQ2ZP+3/IiEYk56x+3e2ruGnhngF5S4ySyqEfzylRfN6DERVJ58hoU24NpJxm/jivTI9vRiaIBD97NuU0'
        b'a+65Zy6fUaFjjEQTpm9W6WgwZV5tfGZ+nVopPnx2IOUPeVMiM1VLFdniUg4jOguE4pqKw/VDRBaH9/rqD6z3YE0FkKh6JxPxWrsnjvIQHpxaeenDCYfeX3ipZnHIu8dN'
        b'BYufqfyl/99PtjATh3/3rXnqkNo/3EsL+mflKeknGyZ+e+qTfvHXZzz/5q99TKs+3Zx/61z9oP+p+6PhVMxvBvxJ8drRtlP/HvH9+6PG/Hdwxfm912eEHRsYp09TstQu'
        b'Ui/FlQlEkgI7CJvEyFdwuny8qYtW+dOiqLsTplb3A4Q5XU6O9KEESUjTQwxZZo0vuApCPwOC5130R8qZ2Bv9DXihF/qjoZWX8I01IvnFJRHqU/OE+DIF1OI5rMfiTfKh'
        b'WzrHAlHWSsRTV6xsM0NIroWr4Og9rxXgnjez5P0cZsWG5VyFUEFOZpHUMmaOHis3vlxmlTTzWkkLWyFZzBhWk/NQysaJR+7RN+QwPslSxrCyFMjVuJ3mJjkXWnnjM5BC'
        b'0iIeuyel5xl5Qh3SClkta5WRc1u0skZIb5VGk8P0ptG8EshrgryZ5PQggFsC8EkofCSvvEdeOeTVGgbTvFJ6YN7T56uslYpp4TdjJScU+Yln1NBD7FqsjNYtCHiK4wx3'
        b'RTJwY52uaK6RbBKY9khiMedETDKSncUBMV8kA0te0EPQjGT9r1JmJNNedjedwVKgA8VdZyR7gNml5BQSrc7usdCgJzdUTxXzxop41bGRb0ex9HwYui6NrAE0kjVSdnbV'
        b'T93cz4McGmYaIy6ajuMdG8nJeXE/ES/HAVrw/VigB2qRBXd+5NgsrvO9eCeeekTiZix0Pr0ZbQIpvBldSQAEjYuYEEY2VqELJEIGCbh9NmruETDhOlSBqAFWYONaNpUh'
        b'Rx7SUeDowUJkbSbtT+NMZ1vIduumJ52dTFuYYS7MyC805K5yKutkLYKXeCxTZr9cfJOsISNQgu2K68TdY4nuxYxENZIydHtsj6PrXGFl4yioWnY1a5QS00PLW8lZg6xW'
        b'aGbIUXYAuMSfaWGtbABDpBt5Qg0UqaMZhFE/4kasoSvyPuPE9kjKc/T5+UrOzhrsbN6T2kaaRJpG21hM2qagwyeeWCZnxZC1erwTHUKtg4idDo1CTbSJKbS9UmbkIEkZ'
        b'Powae7TQ5UrR0haSI8gq6OFGlIwGkjOjapkS1tgP3sG9lgX2wRTLgZlwLYxphPi0VgBSJH3ABZKzJGkKeEaZjJb3h2szYTwsHVhJstgHBJk/05BmvsnQc0UkliKwhe0y'
        b'o64oX5Ots8v0Jq0+V282/kqktsUU+7Of0vlaUKidPFE8qyiDFlNOes7Hgfhyun6FHIfkLxpzs9ah89B1jSmofRxgRltkCjnFjZzfTY90aVKxzCR0SroO7LH9T8ZoUryI'
        b'x4TvtogowCXbJRpTtl4P+tgrjFMoDOsKryxPtyZfn1NWwzvCsrx4ur+NFiyEBHyIzknTrbvQWQFU3BoO31qGjjwZEpKXDADlywoysASeCgd0dCC4ZOO7DNUSE5xQ/dDe'
        b'fW4WgwPGegIjPemLJyEcdBs6TTneQc59b1iGd3UGlWybeAgfQvU/qdPynMAZ//CkDnPLmjBOPBRxG5Rk/CM8owYcPr4enU8YMzaiX5zLtvAewk8NSP4POmujC573n6qr'
        b'ADaR3+8msJET/qjqtSRmEkCGmtRxDjWH8cLn+dG4De/vEdflOtmTsA8tC6yGyHDG2M9MGBFfzYGEYyp48cw/KxdATxA0Sa1cUTCQqRAkxsJJku3Do0aPGTtu/ISJkybP'
        b'emb2nJi582Lj4hMSk5JT5j+7IDVt4aLFS5amiyRJlCJRirEgsPQlQENAl1LRKW+XZOdpjCa7lOyXMXaCKJvcujd87ARxUA7xjuO56How8YTG7z142g1D0bHhCWMmpOLr'
        b'HeFI3gH8lFh0/Mlj5OHAEi3rEBAwIh87a1eyxk97xZGxE8RxOMU7TuNQ8BRLVuPaAQBC8byEjpE4zkehSl+67mEtOpvkExWenEQ3GSSndyEwKi8+k9vrAawUvmAKH+Wf'
        b'5ABWlkDaCIMWwKSKdgwJSjTrC3RkG1o7mw5cX2oxZxsKS+1uelOhOPUGXO4rAjinNXdviyckyqD5zZqCojbeYf/IeR8p3RF5jNoLbyDHEanISQiR1G6OUMfhzREMM9Io'
        b'WY9O4zNzu0QxEaT1doHPOmQxOT4Y9CFyALPRq4MUrKwxAJrEaDlyXGAFY5AS1u/QJ8lRgzJyup/zfTNHtEd6pCAn6qJaDrSrcbXkNL++taCBWrlm3pVLqpU5csnFXORs'
        b'yXKJFVJtAfMwlaEa6P9p70vAoyqvhu82ayaTlSwQICyBTDY2AdkEFdAkJMgiyqJDkjuBJJOZcGcSIExcCDAzrIpUZVHZVJAixQUXQNp7W61+ba1+XcetrW0trbX182vV'
        b'tJX/nPPeO5mQxKXf939////5GXLX977rec97znnPsk2nQAUoxYbpV4hIu3aYYepKsk22d4oRK5mL8Dlco6nDIjtC8Ccn63/xq3pHhzVkDZlkew4HbbFhOOgmSdkaskHe'
        b'zukcK9fMLYWSN3LkLSWFTf+L2Gdd1vFXTB07Fv7D1YSpE6fA/y6+9CIO00XszC5+6kWEC6IKYdiBn18fuIjE+UXENGy9M7O1AGOZxkwshqvZsy7o8ckUKzAmwkcuO1v0'
        b'7AAddR43bsrGTLhRHFA+xOfSek8NzMtmvy+4WsHpEhPrPbUxJ5bnhrXUTW9iVm9NIOjG/P5p/ikZSkVZdsB/5aSx454R9QiDOLkZnwQTXMyDSW7mJWE4UJR2ipOZw+cR'
        b'tUjGoLzwCaMZ79WOq3vWZhRfX1JE6uoIsc+MnTBW4kbykvo19RsLWnFNUKNy0yKC02HcsHLtsTrDxgj/9dAJWE34G+delI9gbEqgWbKQBZGUrJAJ/iTAHKYcLhNSZUMa'
        b'AD6elPX0baOIKIvGd50ii4cNqURlXEQ6iAGKxUMC5MyWTam6FxKIxzTC4aUIx3ZGBCLxlE0BNvuNb0x4tG/Sj4Ibv2VgrjyuPb/W6wdyhuGKvoIyM+QtKj/Fr6sIRIjC'
        b'NMekIAAXIETMINDQ7onZAh7UHQhivOG1DTI60SUAkj294y1D9ZJ4vOa7WYqEmvxY1DdxGGWFNsFDeOmSJKLrQUJON2sX1INpN1RiYPj5jKhCr5FVQFUN1R6UtKfU01m9'
        b'VsB4r+Lw4gpISzTiJQfxshiiHIYbCVDCPCL2M3G60LMwxAKSnBgNFEO7Y0TbDhGHknIohacUWh3fQ2oRSHoTDa+5uqtw+oqZ65q9ZcUzaS0DpmnG8uGjbylcfisci114'
        b'XVY0c8XMqxhOwMoyBvAlNrGRnIqZAzA361bHTKsUf2sLTHHgvuDk9a/1KDT1YWUVoZSYpQVVLhQfzOOaIHxgNQr9PAojFf1GwtduI/G7os5QSSJOyEyyuTaEGPgjKlfd'
        b'qt5XQP4X1VPoSUNFB/KwAperG+fjigG80JUuMzB0j2qbe6wVPTYADtN4AJUhZHJIdzAySZmByu9KOh4P8sAcZAM2heUvxLlRLV5QhuKR3gwHnpxzwx+wGLYOIr0gNzEb'
        b'Robn1oyk1JPiqaex1BS2HjlzXplHKa6Lp6jumUJmS65UHePtXUJ+PsPDIgPfTIRyKVjT4HWJMcnj9TTDoHjaPN7PmYgxR4viCaIZF/b5R6Kuz+wQmWuaVIoGnErX0qVM'
        b'JIovEdhrJ6u0sLZrVnFhRamLCGLglKnjeW6YethU2KA93r8l5Sdc4pYX4ClumeiRKPYnh7E994iN5kbLMis8w3if+MzisTTaZItxFzaFLYDj0I7SuswuD8ewEHCfJDs2'
        b'2ZYlxe+TZSfcO/SwEVLYWm+SU+RU+Ca5x7M0OR2eOeNPJDlDzoQnKT1SDZCz4Fkq2U9yy9LkEWGxnicLSduydHkk3Q2Rh8JdhlwA35ihBvnyMLjPpCAVA4hwHRVLmgNj'
        b'4/EFrwFyswcsGoz5IgPjdku5KHY1J0vGtUED8x0EAxcvwT/lU44IRtRHOq6H17spPtwJU8xNU9aN5i+BFmBIrZKBiYX2vITKlV2esE8ilmqLBDHSVAC5BnfIVwPMFRDq'
        b'Ddas6stKJGYDfrjB54bXDqMKDqF9QGIV4il6lS0YZadzzDzFbzFmqF7+cSFmcuPyQHOjTzsVnDkZks6ZportqYll46e9BiherIMGCJGAbJjnAMeJkbWVkXzfJeUYJdmF'
        b'Xmr3cYmMNz7wtAzwTApDUouRKOxkwaRDIhGeA2VklITpGCQa5k8bFxgjA3mJZ1gIeBRowhML+yqLM9LKPAZVP8Q4QGt1Fz8mxhd1CWVjYMjIhy/OVYKnGL+hy7ShqKMg'
        b'AHjmM3xgBzodCDX0cEorsWHCQB7ol9InLf1JfNyAbmBx9pBz+zxJHzzDVMIuDORTBeEOO9+e2wMME7/q6eFWTOy5IQYQUs8FmeBNoPDxMG0MEypRuYIn0rQVhTISRtAw'
        b'1H82U/vi4N6PUE6ZBN8X4lBKVPl0vifYYI7/hUqu6q6kMhFrasEMa7xeZTLfL0E1FV6V4HI9BS7aMy6vDnzdJ6ahGmH0QBRzRSSkQCIE1I3I5AlUP96oH/IuIUNocJyP'
        b'mXyB5poWqOr0eFXNLHaBHtwzZvGwenw5Y8YZkMNYSbc3swPhjfRWe3piW1j2/XfuWNYUId4UId4UIbEp2NXIcBkSkGk8raMJDWlAzy1Blw4Y6CdPuYr/smaZ6GF+UmJL'
        b'0nu1hOXfa1DiXDdqA0egphERWjLAwAdKKhInLLI9cOMko8RZHBR0MBJDBvoVYVbPYgSCpIzHhiFiYa1LcruBzGoIeprdbmOlWMh9sVc75Wp0QiXpglq7Toil8u3ZPaZr'
        b'd+b9j9TKRKDL+bz2sbEi9t0Y2ZH6yMJSSCMr6iMrJaYmjkbBAOaMhp3Gho+6AmXCCaMN/REwqmwMedxz3pcbcozafq2kr4SsZ9CjObPA7dk78aK+ICarIS9czIrpawG1'
        b'ut21fr/X7a7CuY9Ucntmz8LYayLgF/cYDYMRQbkVEX0RmCkhrp5k4UjgHoA15ii/04CmudAxuXycZFwPSLnBF4ylIK0ue+q8NUyXi4RBfrYjY6wM+JkyFw+0C3SZ/Mes'
        b'eDCU0QIDrMjByCWBN1/qOWNYsrl9NoJAKj/eCJnARhZ2SMQl6dIcXUgfk+rGXeFD4xkWFylm86yr87YGGto8sWRc1dzAcZLP7o+wkvnQQF9gxvDhtNMBmA2V7Em6YTSv'
        b'Eh/Mw0MW36t5Sjk8u7EbF2C7gMbpsWBgfXoJsOJMyQ/g0EBCUJQDABUwhjWKFhDci5Bwx6ITRi2XWyGg2ChkCgltHPD4OEtMuRhBSQi42PUqHs/T9TeAL8yI1teYQ2b2'
        b'HK64Rgk3OqGkFMjP0mGFks0hC5RmCVmxW0OWbA5SToOUlg5byKYsD/GBxcCcLiVBkzid8wkhG9IqgZqQEKiRqfaN8G0DgybJ2AKDvukyjUA6y2WLOWBWAGPZ4JVhqGOW'
        b'oN8tN9QFaReR1gZYXYIAV7UxGybEKRQg+pKxP6N50hKkdcde5/cFmNlNjJdRvouZxjCjUZiRUCczL1lEHtv7X1ZvgFfLcPBQCUwibJdJWyxOmt3pNMPNeqRBjFKAzGnP'
        b'5VdvxnEih2kauoS5c138XFfW5Yp61JiznN4YZVi8bS6e8d3ITjPCAEkQWvSpZ2jBIeRMeEiZjQfcLifoo1YkBP768oFguyOCYV1MRkdYOasoSMAMSgI2G66cYqojVcqU'
        b'Ms3p5kyL1e6UnFKOifZ5Bg+8IYBhUndUaTuK11SUaM9ru6pNXO4saa7WWbLYxZNbrgrtfHqCsYJGcTbxC5eZG6/dVyibF6v3LofE2GVqWN2rHV7ZWhnPl+eSbhO0E42r'
        b'e+nUIIYg7YH0OHZoACpGR2yrdXP25pomj06rKIV94CiLPqLrDTYlVWDW3y8s0/aP1x4IJNTErj4oaNs65vTifw3EFVjMJfC/qRTKEBU/gdsFvlICzpVn3oKWmZg1UL2o'
        b'c7pmFAJDGhL+wtkqO+WUTehziM2rtJhjdmtz83q9tn2TyrTAoH45Y15g6eUTeEy+m8dkkgc4iiSFkHTpg6laGR5fVEfwOp8AqyROLWI+GfjaiXZ1I+HuixNSNP3M7Nnl'
        b'HBIqDt9pYEozPwQmFkymAYkt+mpeI9joKiv6Yf5iNqBTWFXCxria+fasHgXGk/RPqukbOESC6EyGEX2E2ryoD4BiFBjiM7d7a5wr5NtzLmttPFH/xV9FQynzwA2aUbmD'
        b'qEbA+Ep6hDoCWXKsGO5so2BQySVaqrvCq7tVEhgZTANJvUbE0jX8524KEt7ZYZA+DAU6STrXd3u+Eu3D6tUv/WNxu70en9t9r9GFQGZnXlYkJehfeoCNCXKrjO1QwgcS'
        b'LjD9EVz4zu3ea0CMtQ8QpRRfooXIe8ztt3WExg8gYYdZ9SpFp+xuYuteX/Fgb8XRWxlfGmrx4ImvD7qr9H6HdTkkuk0yVAs4u2g1O8RU0Wqzig6RVE8GavuXqs+pOwIu'
        b'RNzqyWACFhyiPidp96n3TekfDaLzIAMN7hEbxUZpmcnDXOyjkE/ySI0WoNz0uzBfzxOKtC6zMrEcoEWGJm0kXrMTyFhj6fNrGz11QXKcpffWV5QdId5QCj9PZPQIjkoR'
        b'jkp279K+mtwIBVVK8edJjU5gYSVw8aVR0GoDBSnuPihShIhTmGcNNmBIHw34PLwTN+5R4NBuC3I670X0qL6lKawfyLY0CQOJIdqk6BTYxiO8N62frG958gfNxPeNhTSW'
        b'bt7vEM/SGm1id7pr+26eDkiZiQZ4x+zlwB+sY+pnhMEQ/GPOq4lmbA3qimndnPCXQWtPGCIqAVh4B9B+SAFmoUbZP/rvOJ2PTLp8Ttb3oOcYoXdzzyn6paKzYj4Huydm'
        b'NxXmEHNEFinwhZnaPu3J+drWiqoy1PLZNq9qTXxyLoXeuUZ91DJCO+Tqf3YOTJidRJLQhiKQKSJjrWODjPYbOOla9Ow3z+9vam3psaNp0iEnIz7h9NUq0r2lAZj+qjhS'
        b'MjEqXgqub/EoB/HSFpfJ9bmamr1U6jclw5YFN4YutQ//nBqWsU/6MJfxxqfhZfOmAV6clwz1BC5VJIe52mb1Ce1gQmerJxAPLl2mU7zazvKSMu0M6q5pu8pKMQbpGru2'
        b'T73b3GsfKi4cwXxRVY2EHU6mbsYYwJCg6yxkRZAF5CJm5GsjHF2bDjHbIb7rH9eSRwI0+KtrDQT9zQ3tHjnfC6xsPu13K/mFnqDi8aBvRH83GLv698tIyaei9TZ5dUCL'
        b'wYZVPr8CZXTLSzGyFIW+QmPzGlluYDG18ot0JqjQVZTPmO6eVoQJVehZRA0GgAqQEwmlBiPxoItGX6nhUyFfp9kDPbMDRot2KsWbq+bBRMoiEU9CGSSQ+Krx4HzwzcuS'
        b'jmvtVhbNFRVNWSi3o+q+yqvUC+o27Rva04DatNOc9kQxe8mrjxaq29Rd7JXoG27lF2i7tfv7D3y+MmHyyd17VZZ6E+2S2ZaJZIFghidsj8wKCyQ66rHComiRrcg7oOII'
        b'8AbmhL0x6zILLZVWAhNnzKHPiypgf5Tqub18E8QB8iiHBgkNAGgyf0DskOKSu3RgEPgGVOLiVvG0O4EshaDMjsvqhoYE/Q1Qn7kcsBUSSghCYmAyXtG9lAu5o0wC2sJk'
        b'f0JImI3KBib4zmSkIfnEFEOO2yjIZmDlJGTl4hI/C4rOm3AGk3RvKR6IhOx+JnXj2JjdTTJsN0rXaSVBusmlO42g1FcS8LQonvqGdW5UECN15pjgC3x5D32/kHS9fEEQ'
        b'UAD0D7vJSp5zkUQ2k5g7lbRJ0vmBfHz7iwalm+FJRBYWLkFH5BEOVTNk/jD2soAyIh7uUYEOevBaJiFC1YBALkmNJJL3OAC9kNyIuE9OlnZgfxcb8iOmJK9MpS8Avtio'
        b'wJiaO2G0KYcR8NwCWHwupmFv9OeEmFARvlNgT9Y4UA2BdppQG3YR7h/FxDk+OSZVYyB105Iab2vvzcU4xcQ2F1G+JQttbK9N51hwowFHaW187eD7Ut8jd3S8ydhi5NpL'
        b'e/Zxnd8HyCVIOCqQqH7CvAVCpiQN7pYlV/Ok5mBRPISUmBCGBFXjGWqhBUwMeNbETH5F9igo5Qy0eoPEWjR3C5++MI6Ms2fl/mKAkpVnLh7tvB2BSiBHzJ/ZxTxUZxfS'
        b'7cIHUkb7oM9pZq8NyLgcdS4BFE5ZAIlBHSIQYaRERDYUWQhiJJgXD7EBl0KizLfxONEPCviUnhmqjMjhwJS8xBHzVO9FlRAf9ZchPl2PfbcBD6EvoMhug/eZJp3wYf4t'
        b'06kLhDukXvNGL6rPRZagCk0HE8xI4BjCZjhCFFn+INKi4iFURoV3bLehDWcEXolwNTIIOCkkoA74Rp4UNgB3HeKJ3oW5AjNjPMo9fVbjCabB3VfZxK7gCXRpFqN/zNVs'
        b't1UAjg5r2JV1o6/J51/r615d84cXBIZ3mTcUBHAz1kwiaLYja2ZYTFmDnYg6dkTgGiIXgrVAb94iluz2oZYTOriFDAabdBdYzAgilWebGFmIoIR0vn1gz+5N/LQXbooL'
        b'3eq5xM1OAhskYJCUEdhVA9chMUUm3bgF8Q9+QUY6IXNIIqw/ICixHa5GWBFQhn2YX8gZ2N9QNzArnbwOJkpHfEbSDg/w7eg1GshyS4IgympIm5UFeGtj8mVoUcIE7Vsw'
        b'vAnSFxugiD1lFyWB9dmQ3ihcL1qshrlg65NV74hXnJqw6b8usW2BLN406BUrlyWlD0gdarVlOUmrvWpo6aLqbqmldrpK246OYYZkS+pZ9aQW7tMRMf6jsH1x2iSF2HKD'
        b'JmFewg16BN9cTosgI6FTIqSdgzJMJglJjVnn+eua5jZ4PdUKcgk9qJEeGhIVHBPlMp4zYA8KMk+zkHHVAr2jndAsFF8CfMHRREJMMwk0LWjl4rbG1am6Migmqez36P69'
        b'kb7sshQEylAZEMeMNAPMDQFMx9RYLTW1AdRHiFlJYVBuUGIW1GL2twZjJnczxfigmMcxixtTAHWdoCgRkzCFsqMP9hzhYYYBWjgZMQ6emX52vj3N6KS+RaGI4exGP6Fz'
        b'fKY9ijJAtN+xce3WCM49wEmIqG/ifONIBRm4zw6B59oLQjDDZKFJVIZsxK/MSuFNwHsjJruN1ND0/PgmSRkfhH7EfodnVlli+RlpfXZ2Xsuvxe046vlF3BorbcEtvphG'
        b'OK7O3+qVqcdr6sjFOAZ6bXpv3178d3ymywY8IHQpdVPM1NwEnaxsJ7Hy/EXEzsdMHkUBVHQXPnQsbPVhcv1NwOvxtOhIMGbx+GTKytfvnI5JWPh12PNoJIzWYwJZkdGm'
        b'HSn6k1nSHcKnZpvECx+1J8fHAr/sX8Of2Vg1csoA6gmEXd4YAyUbxkMyxqOHot8qWjtN1DgGNCY0HNK7wKQ04zVJqC5nh1t9WKGbTfrsZ0EagMz8hyS0p8QrzVJ9EdnF'
        b'CEo5QZ7+UH/ydIvbLXsA0d0ap7T49tQEeKWX/XdTUUJ5CLC6AFtgAmzah4Builsw8si7H8C67DQ6SNkVr9rlBhNuN+BjFMvWmAw7MyK9zaSZkVBJPVkvVWj8wwWBqC8a'
        b'zSRDZIjdw5RBkaLmu/XBAPp20VjVef1AJWLHGaoxktuzrq4P6TKgHpjTq03xbRDkEBw95z1LgzITxJP9rCjUMzRUB/FwCA9Hv4zcNwyJppgMcT7nlJx2RxrKfh0WFph8'
        b'zyjtCHo8ma/tHORv00ObJzeKdvUZ9UivdcOin4kWiAuUUEtdAl41LlRC3c9lkpwaZjEzROBtrfVmEvDaYP1II+7WQlEvcO/LBmsJprRDHrgHlsjZbnKlx6S5N8ye2wsz'
        b'xukSJAyCnE5RwLoBlITA+EhjDOEMtYsIjRJaP9I94MWgmd3pq4jBi3Ql3bAeCxyf31YQ6EqGGz3KOdwaMkrmFgedAbbUrPLEHAFP0N2i+OXWOuAOHPi1e8mchYvK51fH'
        b'kvAd+ZQEPJbkdushiN1uptvuxiAN8Q01PIz+giHFsgMG3GeRSi+itfZkLLZvFrM/kbW+bdGVtghqkt9c4yOHeujXAVHDyW4IZx4aLic5sWXxNrRDlUiw3Z5OFenxsrpH'
        b'dUxcguT5wYTRw/mHLolDAhORNQrKmIh0EFEFKcEDnyselFDG3MlU5um6QwRqX8zmUDWbngJ1cNDM1ESIPuWVeRGgNGVTp7DLCRSqdNASEtgKJwMYSVynyPTHxnGB69by'
        b'TJq9lNN1ysg6FlXoPyKlj4KCRXNuuDr/I+wCpj25TvHU24nQjwlra3UQiZmBdmhpDVIvxkxya3NLgFkwopol7azGTGtR8UGXkDKcR/1Mnwj1q798DF4Fo0PeZtI1Ep1E'
        b'ZzgILBykroaiLfslIGo/g0UjicaHVS9mu97jbfMEG+pqFPSGwSzscIDqDPkV/kMDrLjXDJRwh3jDhozGDKl80v6G8RD1+Ub9T9fAWQHlL+KbCB80AYtpyuRQCxZN39n9'
        b'IHZvlc0dNtnSYYeRNsN9EsBCEmnLBjscwD84crmO5JBNqTXShZJhpK2w8s6TbR3JvhS6t8P9cjmpwx4v24plr7myZ11CjhBQrzlcE6f4MG/Zkc3lci1+yMkZcip75eSQ'
        b'E3jDvSGnXsa2kEO5E/c2dJwioSFWyIJ5yWKHzeeklFj6XnyL2umsJHyLOjOyJWQKJYfsQDPYGvGY1OiQ03aYITe78nVMBXU0E8ylV19EW5WL2POLlY/g+F446+c/+HjR'
        b'X2bOJWlJlzhjxgwarpjoBmzCL2a8Jp8f46+JWa71tyoNgIz4cpcQM/k8a93r2Gm9K5lZF9jJnMvb4PMEGJJqrlFWNfgCsQy8qWkN+gm5uWsBdzXFrPiw3u8Deljxt/pk'
        b'tvdyDDOS6jxeb0y6+QZ/ICbNmzN3cUxaStfVc25e7Eph0E0KBBJlIJFljykQXA/0dBJWwL3a07BqNWTNamPHBG4vVMejXwNHDEWYFA/UImauZVIYm6+12U1fME1lCa/h'
        b'qWddkB5/oTgmiWmgklb5dpw8OCtZPEEH0VipzKGY7kpA0kV8zJAM3RHkkQMOJrww0045m2rmS+h+iwQZqTTZEgrqU1RD69g6rue8or00J+30I2dUIAtRDk21IiJxXrjK'
        b'WlGs06nb9eeimQsvm0N8FtO3FGULYrmgpMtYe3Lboi5rZausrWvgNTUKGqHmT/DXT2GCf7JLD7Q2K2Uwel3FX8ZEt7Qsf+SY4oJeFFdcAw5l6GR8ZungI7o0QTc7qzek'
        b'fii0MgzPSNHrMq4KLc6eN+jSLK59KHUyVn7ClL4Mzi5icMEuqaggUERzB6ULZHw2ngQHMDSkAR9zEpA3AH9f5/f6FR2Rs3wNho/2/PpfqKH2F+P1/BWkfSpOfQmZZHWI'
        b'Mq7hvI6FWd5s319SnqH9fAMNK8/y/RKEp3gd6Stv8HpBCSKGf8a/Xrew4WHIzG+KCxtSJaslR8p05hRS8Iwl/msCSS1rRE7Q9lWoh/hhWlhGHcA4cVBNtHJ1dbUeeEh9'
        b'WDvgqFU397JTVveUoeacSKE6VkxWtyB5MlXdMYwbph1V92EG5B+oziNy0or3oEYrSy4ud3ENjaVPCYEjQAP+4rPSqsWfrs3wZD7w8tGX5T+88KfNCyfdWXbRvPnMyCuC'
        b'nY+UFszZNeQvU/c8m79wwJrDtcoPNnx66NK1n84//9Ffpv3+5Ze//72Oj0++87fdyi9+fzJ/y/3VaTNKU99tn+d9zT7u0JzahR/Ndk+Oukoz/n1q1fd+11y75KbolFtG'
        b'nvl92emqoalvtG752aHl366+Jb/tovn0cnfqhv/MqD31eOrf/nPcaffHUfH56/J+1Pqru8osp++79vvj9u4e90JK3dFf/vTAD79V+OLA6rdOPhca8tKm9Ts3Pz49ecUK'
        b'9Tdb3Gv3i4dG3POfeXfdnb+zfMW49/9s+rfVi55tvD9t8CONy37y8Ly3Jq6Y7E1pvem7Q81DfL+o//aPz/1wzo5X2i7uOVfySlGHfeGeW1yVc3Z25vl+2TZizp+qiy7d'
        b'NemxnxxzVRRc/wvnIztOlgZvbtgfXfPTT1LGqpFz1tfv/5Z3T/Sx948vat2/d/cI28vf2HmuZH+oY3yJRfnuenlcOKRdd+uE1lN7x1Y89MD6+18SPjWdn/32Tzsb339T'
        b'O9w1tO7xEeUvFn13xM/3NE+x7r5ZVTR/27ca/rr5wfqnvVcNuG3bstsGvHvggwfXf3LPba72t+9aenH3kCULVxbMefHn9w5eMjM0jv/rD3dsuDna9etzvzp009bxtz6y'
        b'6t7A2dEfeyKvjGhrH5py87ud7dvPPzJ88JLTP2n5RtvAUxt+vftm/38c/f7Pn6oIf+9nDR/v3/6b/M5w4c+WJi+9ZeeUqV9vrGzbmLl1XfDQ8afvP37dqvueeXRJzceD'
        b'Cn+e88cX3y5+rWzmi494pjmW37XgieU/O+O9UDN4yWL5QeWHGwe/H5tuqzv7gxmhjY8ueafp2f312vT3D3k/XaC5j7QNtdzbNNGW9OaNJ2Z8e8K/vTd8yHXrhvxx6kcj'
        b'd/i+9sKAvDfefOG1vxcE5JnfWfXXzIVb/vHNt1d5Pnjngbfueu/Aq+99oj72+ty/TG4++x/b91749k0/2X36nuX3jf71BbN3zlsvHqnedXX1e4Ok7K7frvzdf/yo7lcv'
        b'//32j0f8+cP00dM/zHjg1Jn7M/76yZ5vFi9+9c3fPrvzodGffnAi7H/1zV2PD/pN3qqh7/xyQ2Bo3ajHBv341aLbvtn0YnvzmZeevvepPas/TfOvXn/k4caK8+0H/vrU'
        b'6Udz/zD63MN/LP3o6BF7488v3Tj2UMZ7L49dvnbeB9ui36+cPK1wTd1Lno1vKFsf+uM8paZ69If/tnXBPt+79ae2PpH9ltT2t+K3x/102vlF35/93M3Xvdl4ZP/ab1fc'
        b'rm0oevu6GWNrTzx9puWNRz3Rjqt+/f6kKWc73r73nbSFg36/cGLTkQ8vLX3pk2nm975Z/sDfRe9xdXH1Plcyc5UXqVVP0rbpLuA155WXqlvVXeqzNgs3QLtT1J4qSAqi'
        b'JFM9VqKdwmTz1TvUu2i3Xd2p7rJwaeo5Ub2nwE6utBfePge9E6oH1c3l6vYx15dgnPV0dYuoPtVcwrwbb1TPDCGfl9WlRQsw1I9Ve1pQ79XOq8coErJ2Vj07CCMhF6hf'
        b'6xkMWVS/YVWfoGAzamfV6h7qrupxdb+u7iprd5NzP22r9gA63cft4KTlNjQWx/iT6gXR7VL3BFE1E2OHqsehJmTHqueG13rzNqqPMB8/TKUgNNUuqWelIAqa1L3aCe2x'
        b'hDqUV1WWaDtcCYoIJ5cZH95eaee06LogLnb5ZeqRfnVG1D3qKV1rpEXdF6SYvce0Z7SzgTIKlLKrtbtAKijgS9R5WKvts6lnirRHKZaIekg7rz2o3ZfVrwD6gLafPKfd'
        b'Pky9L750aLu1Y/ww9e42IBC/+mLV38E15b8xs//3Dq7hjLD4v+JgCNG8/hrZ7SZ3eLjPI/DmOnRDZ+a/2k/6tXMo6rkLIv4B/W7L5AVHKjunp/NCRiEv3DCQF7IEIM/M'
        b'JUVCToUzN8ckzRKEHP5KnrtdsI3ihVZgp6249T+SF1IFPp+OebwwFJXKBBMdLQL6bLKhwFkQBXRMZup57eAFq/EknVIO54U8gc+CGlEaJx1TR/EOv0Tm2lRjCXIdNgRS'
        b'5vAOi4O+HsJbnXiGui8XeKj9FQJfwjuqlXfje4Rb//+8+MJDN2uB/YZiT/IUEXqoD6eHuL6YVg7tXszUKKxQ1XWcM1ccrB0INOz/yW/5QDEA7KgVd5fufrl60NWpW86u'
        b'+nDdS3/zOSbVf2g2a7MmuV69q3JP3Y8Ez/TAmuurJ4VzLv7p+d+kvT+5qsqyY/E7j/7+8X37Xg9lV5j/ftepjoJndpftzZrw6lN7cx/R3h9/S/3X9q58u+FSeOW9T13K'
        b'fHLoTy1rPM6U737r9qe+9ujuU+UVJzLXxxZdfPUazysbz584f/JN6x9Pfuf1zz798Q3nXqvpavrg2NkL8oFFP/9knufpZ4JL3lm881z2IaVi06Tv/2V6y+LHXYtvazi5'
        b'cdVNg72/GdpQnTHo+L835f55/+++d/PuP96x9/C4l65ovbL+mDqucnReIOj/4Def3vpKztoj954W3nB9XLrpO8dmL7TfUxo4s+rrapvv669MGr+kbtqkJavOjv/Jyv25'
        b'Tf9hLrnxRx/dUjllQ+5Ttyc9durkyfzK5Y/9KFPe/6ff/XBzzX1Z31PW5fzlWN7gBZOmPnJo++QFtr8teGjra3fYX7MJD731yqU3cl/f8UvXjx2v/u67fz4wakv2j67I'
        b'W7B/afJLr21asWh53UO7P/rJqjOn19867dlfv5zx4uM/2x1akvLeaxNtgVNpb89Omrrd1zDwrQWdH09IDv14Rez23zQekqqqTv1tx5NtbSkbHq954d//euvrs1La/nTj'
        b'Hz7V3v7VY9/64Ehj4Kq/rv9z9PFh+TXf+u3tr9y5TZo+8u5rBubKd7/E2wsPbxpfdOzwlqkDVx/ePGnq736VOiPvlzkdjpaNw6rXbAmsWLlp3Kj7a7dUrqjZ2fTmyjuX'
        b'v/mtl/7xbufvj33QpLz7+Ful87t+VfThnKMPfsbfPO2Nna9d6ZrJ4pSHs8brgLVd21ZCkFU3i3MuFMd5G4hwKVAf1+5Wny8lIqkXgbTuVnInrO26ujwevU99YC4nYfS+'
        b'OvU5ijw2QN2bV6w+XlK1zgwr8Z38Su2CtouotHrtQkZxZekE9UIRsGpAEVF8LhaffdgiU/qYJhae8AH17gr0e6ye1vb0FRx+QQu1ZqZ2r7kSkmnbXZio2FyhPcSlTBab'
        b'1D3aNgrUarcVadvGXK/tEGcs5aTrefXJ5Gupjm3qKe3BSm1n4ehcgRN8/FXabvUb9Gb0oqxibdsS9KQ838SZZwlObZ+FYgOUque009q22eoTUFZhKc+Z1wnjWgMUcKxA'
        b'O6QdrkSKUNumPuTCGOFW9YKghtOagiiWSBo6HEjKEvWusbDChPiZinqE/D+rz0JFzqsntK0lggpUpqA+yS+eqj3Puvm5xWq4UntOe6CkGvtL4swDBbsHuhnblnPbMvKH'
        b'p25W98OHHfzcTDvRQfnq0Q5t2/wy9blWHjLcyl+n3aOd0Ikp9by2HYqLAJFXdL12b6V6ioOsgYJDPfyCK0yzW3OIUnZojw1OAuK2EgrYV2ov1LaqpzDa4kD1vKTu074+'
        b'g+hgbUvLJPK1BT2CXrYqq01SDZe9WhrfZKJKDlQ3t8AIVDSPw6rcz89VABSwm0u1k2qkWIuMKdaOY+C3Y/xN7gBVXzuubsrVtgGt560HUu52fhYAZJRGQN0yZUBxGQz4'
        b'Tu2oifpqiXaf9gJ11jVVucUYNOSCdmdReRXP2SYK6m51r7qfxqdCe6CyEtFpFT8fhpZkBHcK2sMj4D02ZK56wqI9XK1umz+/tLy4gmJWpk8T1RPqvuEEayb1ntGVLGbm'
        b'/GrMoEHdwzlvE2erz2r7qEV2YDl2QFvN6sb1HL+I045sUI+yFh1IulYPhFlex0kYB3Otepbi2M1Qoy6AmOPkDUV9TNvJSbW8+sLVaicLkhL111UCOX1nqasCamReJGSp'
        b'T0ynFjWoz2ci8E/UjmnbyxHgktT7Be2YrB6miXyltg/4hs4qgIRuZWMJ2JhOUbtDey6fMtkwS3uhsrykvJTVTjszg3NqW8XqyepxFkTwhbVl+N60aA4nSbz6EADbw8SX'
        b'5Heo4SKtkzWrCgbLVQ6Za/eI6vPDtTOUufq8+uzo4nL1ZKFrTEUJpx7luBTtiKje0TxXj/33tPp8ZfH15eJNbk4ayAOl/6x2J02LKeruJdo2RBK7RO0clL2AV88O1CKs'
        b'Upvq1RPFFSbtYW0zx1dy2v3apnHME/ojalR7AWZFiXruFvgY3S9Cv4QE7YBL3czG4tgcDFaAMQHNKZyUyqv7lgEE0Vzs1MJtlRUl05KqJ07gOYu2WzADH/cY48N2qGfU'
        b'CwBtd1eOn9DTp+JomJDU3oh6d9ntbnzfw7GhVz3BsjimHs6vJL+w+nz2w3g71YPiteO0nYwjPKZt3cC8XG7SHrnM02VmNg1sLc8BYDM3k718TKqPVQUp4PdJ9SzMesBH'
        b'pTDHimCUYIrvTqoAJDSPOmZ7Zan6mMRVIdzfuaZM50enz0tCbrcFP6wEmNKensVlagdEqMvOuQwnHQqNI8aXTym7vqqMh7odFrRnJrhoGiUBr3YQEEL1CG0zLR44z54U'
        b'tCe1YxODurDu2FXq7nEwVedpuypLXKUVJi5jiAiAY6XWmeepT1fiHITmRctLKsZAKWZt8yyuhDNpe1vbCDn5tSOZ+jK2Y74L+EJ1B6xRY9TjXFaBJKpbJAYNR9WNV6Ij'
        b'2PmKen4+LTQWqM4TMElytLsoyUrt9FoYcajMqIFtJD0ETtbC5WpPSksnNtLE36A9P1Q9cwXUCZB/dP58jNaRpsFieEg7MIPgZuqKK6i/YBWTtSc4qZQHnPmAdoHWMvX+'
        b'kPoNrOuYytIZK+PLHi6pg0ZKamcTMMgUeOYUgO6FSu3oNeVVRVUWziwJ1qXawywo7Xng0g+SX9Z87Ry2txT6VXsYYEI9rG35om08F2/wrv/nma5/4UPPGOmoxC4kWQUr'
        b'3/Nn51MFyeQgt7l5QK4LvFVw6m/sfDfjaNdVIu2Cne/+pQpmzFFAL+uZPfJ10CYQfSOg5ZBEqexsu0cIiYle2o2febWZZ+J6XUPdRv4iWlvc7u64Ccaex6/5xDbiBbEg'
        b'jo97syCUooduRjL8oecX1IsIfBuOtZzMN8IvuiSyBPXpoqPhLMBZgLMI5yw4S3C+MbKkgYOzPbIEzSajQzF9I6bkw3x4iaEB2MGh9p9XbJaiKc2mDr7Z3CE0Wzpwb9Mi'
        b'27zWZluHRNd2r705qcNE10leR3Nyh5muHV5nc0qHBfdNg6mQ+wA4p8E5A87pcB4C5ww4w3vc+Y0OC3GRFDinhMhjUjQphDEX+GgqpMuEczqcB8DZCecsOBegljqcLSEp'
        b'Oly2RLNlMZojJ0dzZWd0kJwSzZNTo4PltA6rnN5hkzOiA0OizEVyURM+OkLOjLrkAdEyOSs6X86OVsk50Rvk3Oh18sBouTwoWiTnRUvkwdFieUi0UB4anSvnR8fLw6JT'
        b'5eHRq+QR0ZnyyOiVckH0CnlUdKI8OjpDLozOkl3RSXJRdLpcHJ0sl0SnyaXRKXJZdII8JjpOHhutlMdFx8jjoxXyhOgi+Yro9fLE6Bx5UvRqeXK0VL4yukCeEl0oT41W'
        b'R+ydXHSkPC16TTAbrtLk6dF58ozotfJV0cXyzOhYmY/ODlngTX5ECFlDtnrspcywM5wdHhquqpfkWfLVMH72kD3qIG2c7pA7znBKODOcBSlzwrnhgeFB4SHwzbDw6HBZ'
        b'eEx4bPjq8Jzw3PD14YpwZXhReHH4RoCHYfI18fysEWfEGnF1ClFbmAWXZvk6KOfUcFo4PTxAz30w5D08XBAeFXaFi8Il4fHhCeErwhPDk8KTw1eGp4SnhqeFp4dnhK8K'
        b'zwzPCl8Tng0ll4fnhedDmWXytfEyTVCmico0Q3msJMx/VLgYvrguXF6fJM+Op04OixTXIxnSpYcz9Nrkh0dCTUZDTa6FEqrDN9RnyHOMbzqSIs5QEpUwir5NglKSqT9z'
        b'oIfy4OsR9H0hfF8cLg2Pg/rOpXwWhBfW58pz46WLUFeRcpJus+M4djgiBRFHpCjiCDki5Z0C6p3QkxJ6UsKe3OYIJdGe7HXMBzn5Kum2dOlf5w7XZ2ZfFuFaeSU5SMqa'
        b'jbyh1q77+e4aUBAodOU3MPXYmvza1gZvsMHnEpS9iINouxGXxn79frnrfSSVQ9W6H5l0Mz0H7X4rvzWMdFwSoLtVnmC9glYhVs+6OtIEIjt93NP318cchi4U6UDx6MOl'
        b'GfAjXNnRH3Jzi+IJBOBO9PpXoSE3as2RW1qlCw4XqW+w8Rdx5/wihi+7yBn64X7ZA1iWTDnIea3Y4m+J2SF32VNfg7Yb1no32yhmBqTd/jbimDlmrqd8Ykl1fneNsooi'
        b'/mHMQnfTWr/Puz7+yA6PfCyzmAOuA8Ea3X2pFe7qvTWrAjELXFFmNrrwBYIBeksWAVRCW43SfYO6xnhH39GFk54qAdLY8PkpHy8MYE0t+0DxeNrQ8TXeoEIG3ZjqvOh7'
        b'1+ytgQEeFxNrG1aRHj269WGe+mN2jBnLrpl+0sv6IAeVmjoPRolzuyF5rZsNpAWuUMMiJrkVT33M6ZYbAjW1Xo+7rqZuNVOPBsCQmc+5Ug7DCRT2NEw1dPeQqmI+vgQW'
        b'BgR1wNBDFnq4Rf2F2agjIJDVsNAJ/POa5JBh1t+33uMXerxC4ASSV1cZJbrAYQBtjzqSoq1Rx6fgbcQCmM4BEysXaxLiAQcJ9WhDkkLOPjmyLBEj+aS5JoWkiL0VYCri'
        b'6DCFhEhSE3q5cnSYfZl0xyljIo4krsMU4ZimW8QeSYc3Tmi7Ixv7whyxwP3gTiFkjgyAEgXfDSFBKYdnQyJZ9egPqBJ106CcDCjnJkqdA1/nYW6+qfB8aCSN0gUiaYB3'
        b'LGSB5+iwQkpLJBNSSrBWiOjEmufW1IYkWEF4ys8M+d0dMcM3Nsp1EKTBkXBCC+3wvf5dyAZXdrzCYCUh2yKOtT3Cw/fn4LuUSHKSYf0nRlLpXXIO+jtOQtfYoSR8FxIA'
        b'0yZnc8wijZy02piT+LgOIOvJ70H/2yMDoVwB+yNkyiSrwngP/JTqmm30gK63Z8CJ47+0ZzLsX0A+/ZVE2AjNV5p1nwxOg1YVmImZGa7NZJ2YjupN5BvWQZ5hs4jONQPd'
        b'm4VqTKJTSBXyiMq1ipm8JFn/AQhe6DFN0vSVh6bJ64I+TZww1C59mmQmThP0o47DF5FgdcrpMXFw+IrhG4muEORNISkQpHDZ5gj+smDYRVQZDFmUq0MWMi6yhqA0Bjww'
        b'UQZO53yNkUGREZFRAP659SZ0ZwWgW9hhj6DinR1yTQrZI4NgOjYB4KUkoV91B6oYRpx4HXLQhIN8QklAHKboAExKiOxdyA7gXuGbHBkZSY4MkvnICPgbBX9DI4X1fCQN'
        b'y4kMxWmVCcQlPB8Y4SOpkVQkyhosNK1NCMYwkdJCVmhNMgA8nEMwNSLOHK7DGUkHUgCfOLM5mDbJRCIkwVdAHChn6Xu4klHJ2YwKXB0mXxs8NUeKINeUUEokh9IAMoD6'
        b'pkTy6S5fvxtJdyP1uwK6K9DvhtDdEP1uoFFTuhtEd4P0uxF0N0K/G0V3o/S7PLrL0++G091w/W4w3Q3W74bR3TD9bmi85/Aul+5y8a4+BRaGUiTtQ9xORJmICKCtkdGR'
        b'ZGhxaij1LnRXJtHRgkeClmyEFsgDer8eHabrrcnm0O4RejQDoQxyFcmthYR9j4ibnheHJFIIlgyHkt3O0NP+t8xdV9m/AP74n8dRaxBHbY/jKKfueQ0VKs28kwIHpfOC'
        b'JPDsJ/3NarWTY9lMUs4UPpWSmVJmpoBql9IndgdFf5Ls5izBDvgLfnx/P+nPjvRUMR1wG267Sp85TA5yBN8DvxmGaoTfmBNPwGDANkesOn4zR7gE/CZGTLScA8ESsUUw'
        b'0oOFKar3WI76pFL+G+I6Uqe+Y9YV93TELwKSl3o1ymo06hw2SoJpgrSHAGjZxhrSSTqoSgbqzUdS0WupHnKDUkITkyNmXKGhK1IAUSUj2sY71MCP2Hfl8JhrUiQdpyF2'
        b'FiEx0QRINmKbDCTg9B669z7rOC4wJ1HzHpAgoFNA+KJ+nQq5kP44hpKh/LhE3zj9dGrG/yxEf2COa+ADDAt4tFvyeDMMQjqfRzBmvxzG7InD0Y6kJpCFkRQkg+PDIenD'
        b'kUnDMQDIMzGQRW/wPgvvKZ7AcIA7B5oz0zv7rnTqPDT2t+SQaQTe9dH103p0PRB8EUsumvJKypmQGKg2SHAey5OAoMTV2aS0Yjw7xLSwrplgBYLB7rC0m1AYQcaINokL'
        b'cuubjZx9/FqOvshh3wduJObcGU4FxjwznF1v0cNuWhNKsSLmV+6JJOMT42u2JgKlYasXmiTlWajL8/GcbSgEgW9OwjfwBJ7b4t8klr4/0TwvbvzTp5VR3BtxPAwccirQ'
        b'aOh2CqCBvjFgTgjoqdOfhbSr7tnA8AjmEmNCsFb5GPlLlF9+1dh4zoaA219b716roCa5MtWi8zASL+leewn+XDyx8P+M/q8r919paXBadNtkNpFQD98hOGhhwObmfWaX'
        b'JPKShMH/0F6bhXKRMASgXfpTTqbdYhXSeYcF3+IyAse/S69LpRLvymEyijuwLAo+IgbWB5T38Nnv8HARD79nmt/otCig/IFsF9q9DbXK+3TZXBNcrfyRrMzhwlODoS2U'
        b'D8hqp0FWSihT4N9jYk0tcP6rawJoix6z6H64YpaAcbHK66+t8QZcyf89Hei66V9ATv//D//MxgbC5HdQlob2DoJglXpuajiFHJODZ7/emx7sJ/Xxc/T59J//mfW/7nuH'
        b'OV2ULPNEaaKdrxelRjufL0qOsaKUZ+eni9K1dvRnYkV2E0g4gdpZjVZBuHcXS+22h0QZoNutz8jmmhaYlkFF+TrPTJHJ5wLbS/ktzbs56+o8LeiRSkF1V9xZqatpDXjc'
        b'7lim2x1obSHZIQra0OYGnia5u28Uh8AlWjMm2OxOb/bLrV4Pui9jFB+sk1IqegPuc4eHu906h52F4WiGaewuSWhZ3vW/AH+VUD4='
    ))))
