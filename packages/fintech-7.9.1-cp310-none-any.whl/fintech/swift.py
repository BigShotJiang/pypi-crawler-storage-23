
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
SWIFT module of the Python Fintech package.

This module defines functions to parse SWIFT messages.
"""

__all__ = ['parse_mt940', 'SWIFTParserError']

def parse_mt940(data):
    """
    Parses a SWIFT message of type MT940 or MT942.

    It returns a list of bank account statements which are represented
    as usual dictionaries. Also all SEPA fields are extracted. All
    values are converted to unicode strings.

    A dictionary has the following structure:

    - order_reference: string (Auftragssreferenz)
    - reference: string or ``None`` (Bezugsreferenz)
    - bankcode: string (Bankleitzahl)
    - account: string (Kontonummer)
    - number: string (Auszugsnummer)
    - balance_open: dict (Anfangssaldo)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - balance_close: dict (Endsaldo)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - balance_booked: dict or ``None`` (Valutensaldo gebucht)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - balance_noted: dict or ``None`` (Valutensaldo vorgemerkt)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - sum_credits: dict or ``None`` (Summe Gutschriften / MT942 only)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - count: int (Anzahl Buchungen)
    - sum_debits: dict or ``None`` (Summe Belastungen / MT942 only)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - count: int (Anzahl Buchungen)
    - transactions: list of dictionaries (Auszugsposten)
        - description: string or ``None`` (Beschreibung)
        - valuta: date (Wertstellungsdatum)
        - date: date or ``None`` (Buchungsdatum)
        - amount: Decimal (Betrag)
        - reversal: bool (Rückbuchung)
        - booking_key: string (Buchungsschlüssel)
        - booking_text: string or ``None`` (Buchungstext)
        - reference: string (Kundenreferenz)
        - bank_reference: string or ``None`` (Bankreferenz)
        - gvcode: string (Geschäftsvorfallcode)
        - primanota: string or ``None`` (Primanoten-Nr.)
        - bankcode: string or ``None`` (Bankleitzahl)
        - account: string or ``None`` (Kontonummer)
        - iban: string or ``None`` (IBAN)
        - amount_original: dict or ``None`` (Originalbetrag in Fremdwährung)
            - amount: Decimal (Betrag)
            - currency: string (Währung)
        - charges: dict or ``None`` (Gebühren)
            - amount: Decimal (Betrag)
            - currency: string (Währung)
        - textkey: int or ``None`` (Textschlüssel)
        - name: list of strings (Name)
        - purpose: list of strings (Verwendungszweck)
        - sepa: dictionary of SEPA fields
        - [nn]: Unknown structured fields are added with their numeric ids.

    :param data: The SWIFT message.
    :returns: A list of dictionaries.
    """
    ...


class SWIFTParserError(Exception):
    """SWIFT parser returned an error."""
    ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzVfAlYVEe28L23F6CbTVRE3NoFpdmlERH3DdlBAcUVGmigpenGe7txXwHZBNxQFhXcFRUREHFDrUpMMpN9JolDJsskmcxkNXtiEvU/VbdR3Oaf97//ve89/frSXVWn'
        b'6uznVNXp/ph57J8EXtPgJUyCRwaziMliFrEZbAZXyCzidJJGaYbkIMu7ZEh1sgImnxEGLOZ08gxZAbuF1dnouAKWZTLkCYxdttrmV50iYUFEWKIq15RhMehUpkyVOVun'
        b'il9tzjYZVWF6o1mXnq3K06bnaLN0fgpFYrZe6BmbocvUG3WCKtNiTDfrTUZBZTbBUF7Qqaxz6gQBwAQ/RfqwXuiPgJcKXkpCAg+PYqaYLeaKJcXSYlmxvNim2LbYrlhR'
        b'rCy2L3Yodix2KnYu7lPsUty3uF9x/2LX4gHFbsUDi92LBxUPLh5SPLR4WKaKEm+7XlXCFDDrh6+xW6cqYBYw64YXMCyzQbVheEKv9ysZu0y1JDa9N0dZePWBV1+CkpRy'
        b'NYFR28YabOH9y2MkGS9x5F1qdFKcL2MZBW/RJSECl+PSuGj1irm4BFfEqXFFRFK8r5wZM1uKr+ESVKJmLYPJ0NPoRIIQEYN2omO4Em+LwdtYRhHBoZaxc9LZx+Tq0oPF'
        b'fMIYFljzf2FMpouVeLZEAsRzQDxLiecowewGLqHXeyC+8N8jfq5IvO84udtdzg0klmqfmDuUoY3RnCTkKEs5YsjxnCM2Tl9vN/oiB4JNTTUsS1CIjb8sls3Xss6gr6n2'
        b'zyXYMicZgwKauYFu7n+x/acHw/xtzHdcx9j+Q6oZgx10GMfWsi02jCpgQuOIvwaumPKl2Lwq9zun3U6s5zd5n0jvJbcPvsZ0MxZ/6MBH8Hl8FF9GLSCMcv+5np64zD/c'
        b'F5ehk4mekTG4yscvwjcyhmWMTnaTl3k+wW6bHrpDCLsJq5lMyQOGsv8WQ7OextAHEz9gqFJk6FFvJ4ZZMoFhAlLtj2skIhm+G1AbELDNOwpvw6XRc8MjfCKSmMAotANv'
        b'S+iPdieiclTNZMlscAO6iAosRFwBc/to0AWYPmgqOsmsWKWz9IPWRFSE92pQO7SvUaP9TI4U7aId+NqUfppAoo6H0BW0h0lfg8roPDlz8SW8S8YwfrgtgvFbLFA0qxOV'
        b'jHOgJ8M4p/oM1yeI0vy0rwvzi30EkfukryLzGH3S745SQUsE9NyqL1L/mbo8M1r7cqbfR2ptuPbzVJf07ExD2pffl6VGal/NVLtEatXOsdozuhNsU9+sf2ZEahczO9PD'
        b'tSbdTmnZ0ZbjATMWblMPVs0P/X7GzdhjjmHbL96w3/cZE/bn/i0oT82ZhxIqmofNVQKT1DGhqNzi6wXS5pj+qFhqiw7gA2Z3Ql/ZPFwHzCzDVXibhA9npBNYdA6V4qNq'
        b'tpvzVKslPJFJrwcHj19dJ2XypjU6oypTdHp+wkp9pnlKt4J6tJQMrVlHxgn28LAfYc86s7asJ7x4ec8Uakm3LF9rsOi6bVJSeIsxJaVbmZKSbtBpjZa8lJQn1lWzPNES'
        b'XkYeZJaRZH4iK+cP5BzHylnylLLye+RpGULYjjcN8w738YpFFXGgIjLGFW9GV9KlA1E7vhyWzvVSQulTtBscygPt5qi7kIB2c1S7JVSjuQ2ShF7vn+YreyZ/VLvlsRZX'
        b'0R6vgo/bxeICfA30mvHFlei0pT90OeBduBrvkqAtuJxh/Bl/tAdXU9WcjU+h3aCCdngfaCHo4VFcpF/0kUYm+EFv57Qfv0hddH07qkHt20/uOllwrmRM0cWCiH3si5lE'
        b'4+wzP3x5TTbD7GmydRs4V81SJcCNzlO8I31xSUR07AJcLWOU6ByH9y/CnVZRPU0HqCS6laLAMw0mrZlKnGi+vZcUZA3SVjyQtpRKr1uWoUvTm3kyiCeuSs31kjDHkyDX'
        b'S8wE3PuBmN95hphHuqEWEPPgcVTQNMz4sMygXCna0U/0IuOW9WVXTcyVMvHXc5MHxXpQDqM9w/EJwRwcYDdNynBpDD7GoyY6vCO9P7tuVb6UCbie6+bcssQygPDoQChq'
        b'JsMT8SGW4XQMPokPojPi/CGu7O+pa6VM3vXcW7P/pqbCBW90PpMAoGZUIGG4LAaf0i2l43MtA9mg/AIg+vp6N4dAPR2fhvcuF8zjAwLxGcDHyOAmdAodpONf8B3EJo+r'
        b'lDLTrq+/NevOOqoH9ujaYDI+biDHcCaY3AHto6Pl8UPYW/N2SBnV9fU1Nu+tF9HfG4d2Cbh9XIBiGqCPChjchq7MpgAtPkPZIPMBKZMK6Ix+abrFjQCUoO1+FCAbnZAB'
        b'RCGD2/GpoRQiMknFliw5JGWcAcK82p0ytN9wVCjw4wIclCxF6DSuRbUiQ8NGsNLppwj/19/KbHOiGIUvBOVvs4wNiHABesFh4zZcgy5TgI3DPNjtE1uIBNYnJ/hOoBih'
        b'HWiviUKgbeBdOHDLuB0VTaIQ38waze7jLxERrHdLKnKhGOGL+ALuEARNgNN4WGMjOERTIB2+lPdkX+ReIBIQ3FQKZ7pAPNo9ns4PCck+kBiqY3AnuuBEIfwkXuyL/V4C'
        b'iBvCLUEdbBlIFgDrXEVBpuMDNgBRT9a8hrZRkMNpPmz4yjeI2IQaTUMGBUF7If+pxm2CvQL+lAAd+Dwb5IXbKEjsAD/2h/5/BZAbQs2cxmQL9dH1EHMqlXxwAJh+I2HW'
        b'MQYIK0JVFGZD1Fg2fMVHRN6A2Y9TRfGdxlWoXonPjQOgJICBNEqCts6lEO+OCmRf9/8KIIAWD5UoD3wOYt02pSIQBH4eJIj3sHbJ+JTI+mN4P9qpxB1jA2zQVjJbEcvO'
        b'x40UEB1AXckCblvpiJpQJSHoIOvttUSUwOH1toKdA24R3MmU19jg9aiQ9qxaLChXWHBHGjoIGQ4+x3rg2iDas3gkyEzJm3GVhcDUsEPlaIuIRi1qQVWCGV9QphAlwxWs'
        b'NyQvmy3Eu/owNoKjgwJtjuQYiYydnI/OUrtaCFlAE/Q4opMKlpHYsdNQF26gK3mCSm2FrhWD+xCaOlk/tGMBpckRYuBxpUMe2obqUJuUkYxkp81Gh0RGFQq4jCg6uoL3'
        b'gGXkMfgMakumiy2NdAaTD4JwWiRnuExwEqgSbaNgKvDg54gu9lXKRANsBV/VQiWM9/CoTMDncJsTqsNHCA+b2SB8Hu2ls0rwvhEC7oBevHUo6WxiNWOS1KJivqwYx4aM'
        b'/JZYr3ArLj6VNqaagtnOzN+hEfRoPpbSxpnxIezrYRIZWK3gtvGY6Bvf6DOR7dwAKDmDLswdNIo2jvabxJpt+8jAYIVboRGZtPGGZQq7ZPAQaLwhuKW0OtDGqxOnsa+P'
        b'HS0DSxXccn7xpI1DFs1gv9ngBY2w+vLL4kj5tNnsieHBMrBQoWb4tmjaKFsdxtpqQqHxhpA87iMX2tg+IoKd5DcHQsD1nBr/11fRxhLvaHaadq4MjCknOc2Po43S2Dh2'
        b'SexSaLyRc8tGtpA2zpg4l/2hb7oM7CHn1pysWbSxa+U81n5jLjTeyHFz8tGKLroAHUP7BKXCEZ9FJ0A57Nlp8VLqXceg07heyTs6oKYQ0Kc+7ORMnWi/Z9Amd3BVF1YK'
        b'4J93SKhWe0ejOtHsDqJCI9gCOE4bMCDo3M2O4NF+tSiBct+bbHj6FBsgd6WbcsMC2tiof4n90mYWhL3rppqVWEkbZyv/wMbL4qDxhil5tiWGNt5VvsIeWZxkAzwwJWcq'
        b'Jj+RoNv1ZBqzGKZnm/hwL8Rk2j1I1qX/VrKe/Xg642x9PZrOTI61kC1rlF5A5XGQ0FTh0ogYSJDxCVwKGadrqnQM2uIhEjuag3xoWpgctofLQ5zFTPn9JXYw64kQshna'
        b'NiSIofYyZoZPlH8UrpyMD8ZB7maLC7nVA9FBMXYsCIUtwD5UhdpJ8s4uJNvGS560bzreG+/tCcluiX+sjLHPkqThXU4jF1MfsXAA2kLMGdX2Y0KZUHQQ7eAJ3ygWroFS'
        b'xpa5PtNhWqrPG7Ozxca/L5Ez9kxnvh3s6JQzNzLi7qAcH+ZBZao1AUQjdjLazA10nxsD2VMUzaWryN41ClX5R6DiQeiMJ8uozDJHcAHFdAbYgRWiTtwVrQkin3YzaaNM'
        b'FpKyh9tP8YZdGWxsIDOEvS9s0yKkTF+1BN7umEdhV6OjPlLULG5PYGuCTqDLlLrUtDi0b5AGtYJgUANjsMclFCBYOxrCwSaNhjprJgtfQB0WsnVegE70R9eCNBrIp8EN'
        b'L8+dIyK3P3aNGyrVBJP3NUwGboaklO7NO/vjfVGRBKtYXEmkosdVjnmSkDWoXYRswttQI3BEE0xwqGV0A1IoZEp/VBgVDUD+uMKbZZSLOHwaleNmfAUXqTmKfRhuyR2D'
        b'ijTBkC9C5M1EZ1PFPO3ocNSMa/EuTTBBs57JQmdHi+lz9aQxuBz2NzF9bGSMdCiLDuEmGzoZahqwTIc6NcFgIWgfk43ODLMMopPh7R7eESAQXBqLINGynyxB1c5O6HCq'
        b'6NuPw96xHFLqExrUQcY3MgbcMoQul4rLhuLyaCA/bpIEfHIXi+o3TLbEELBj6CyuFKIjImLI8UbPznTGwrmefmqvGD+1L6dAR3UQRo+hI56e6KSrtxqS+CPe/dBu1/74'
        b'yAB0nIOtWD9n1GjYYPjl/v37z/UjyvjNcJtpqdEvui4TTQLv9Mbl3rG+4Wg/OiFlpNNY1JSHz6j7ibF2i2y64MBbJqBDxCsdYEfiS1raw6ELsPFvc+QttrNJVwerdpgn'
        b'xu7DsYG4DYBAcmWkq4v17oMOUHoX4YqFAsCga/iw6MmGoUoXMRDvRnvQJWGFRQE5w2aST15mVbhgNe30GIAOQ7RaCclZHSqW0dRjuBQfpQvOwGfGQKqA2x1wdSxLA3+g'
        b'EhfQBTNYdF7pqASrvoabwOkuYhfj7cvFBQshWdohmBUroY/kx+gqOxhXT6bk5abg/aQL16nIaptZVRqqFd3xpbiNuM3M4/Y4TJiCuthBeBOuFDuPoJ24WEDFRtxqljMs'
        b'mAaumoTO0zm15GRAaeugyB0DrnU8Gw60nKEU5IN+7IWcb4U92owbCAl17Jj4QAqVgIsilY72dqh6I0BNZCNAyNbAADaDD0IE5x3RdlQN1Dmy41HtWpG6MkhJ6kl4b3VA'
        b'W2ZA5wh2OqrJpjaVgDYvF1assB81ifC5gx06GBan6n8CH1wkKEBADdOJ6HayKtSaR2HScdVKJe3BJ0BVXdiAlEW0YzDeCsq9S04M4SSkTD6JqFkMa8dC0RFU7qRYkc8y'
        b'Usg+cF1fVIH2TxdVqw43LiCEhc220nUSifL0RvuVVLPQfkerasGi5yhUINrjSvAbZ+pBbysSU0Z3yMnOU73DZ6OsajcEF1KyxuFzMqJ2XpDdiVqHu/AetVREs55Bu0SJ'
        b'4hOGBxJFuyio2hQuzMXHeokTFHUbBdQlDgC5XYC4bAFXgS6xqBhyyc1BTqJj24/P4l2ofCXusEelYFm4hI3HXajWHdyTJDZWtJVmfBx3UQUNwrWifq6FDI1a5nlwkpeo'
        b'fh4yWpUQ162ifYtBZUtp12501qq6aeia2lFkbTtuQV1KhR1uTUsFWYWyc4aNEZ1pIdqZQzgxZYmEpuPD562mHYvUDLHzReOsZo5K8VUxBZbgzUpbYOoed5hJwfqFO4ma'
        b'0rHGB7fZQ0ebs4TmlmPMuFTsKgvC20Gh7Pl56CTpO8qO8ZhMlzHJ/AVH3GGOiyNyaGBHLcdHKEGhqC4bDFxpl4V3kNy9lQ3GR7DIZ1SQjy8reeDHeQ98SEpF6weh8iAl'
        b'NgRU6jSxKn/QPmpWuGKFmIrtGYmOKfF5uxW4EXXIGckYdkLoAArkhXfgItql84IczZMNXQceitpNJ1hwk4Aq8nDHNDVDKVNPQ2KIjZwwEZDMc3JZB5k4LmVH44P+Fm8K'
        b'BTu0KtCGXagqH+8GlMrQmWB0csVs8DF78S68ZwHLjFwm7S/nKVfxIRVsCHfZQFQazQQwAbh+rCWWzHM6ZymM3ov3opLe88Asu6F1O8zfCn93g55dgLbtMK7YDjdB0wl0'
        b'Kns5OPxzs9BF1GiHarW4lpI6Dh9eTjmLtwdZOesxlPJ8UaaPyFXYH3T1sHW/LcROqn6XwT2ViuzrXCtyLxH2PzR+XsINybQreIDIvnR00RJP1EUjUeKKKAiG4TF+NHJ5'
        b'44qYSN95uCQuwdMvJhKiHa6IUM8PhyxkHm7B7cICRuhPjlfP9Os5ZnVG1S5x+Jh9BKqmMpEmL7Da51l0vMdAK8AL0vBbNnXWo2aIS/EetFmDj1MtMEvWU5ktQ609QjuK'
        b'aoBIuklqchsY5efrFUlwbpaC5Qxxmi8x4CobmjmheuDBbhJ4K/xRGThHkmjY4hoOVeMKN8omD70MEspwn8g4XzmjjOLwlTx8YGqIaAinUBHaScwNb9Vb7c3Xkea1uJOk'
        b'Y96RMVHu6KAvWR4SSxd0QAJZXClq1r9Y/xdOuAxpy/45E5YmTo7rP73fVU3bb++/+3PpoeuHGks8y0Z4lgy75eYedBO5Xhq07OXRNT8H3Hr5uecGfHzz86TRo/tdHjU/'
        b'uONmZOjGzfunbt7yhzc1bZLpZbV/mfCPA5d/zhl/5nR8SvPUsUdKZ0eH3fq+j/5G4Og9p9//WOrqc3nysW18d91Hr6e/3dUeXT91snfnvvKvZ55dEB1b9e7Yd88ueemI'
        b'68Xr70q9r/S/EK2vVVYqinTzs+/umus+pfPzFua1pNe8h+T57njP4cyH57ui9/9jmvu0ZROOfLZjvkv+Bx8ODn/u7cX7jufd3/S9eUTeiKHP2V+76Fx0VzXph/3Fmvfx'
        b'QlXDkMBPdvwt9/MNN9Z/Uhi89e8X+vX52XDs8Pu/Dn79duzGrmkG2eW1rm9snv1mgHJ1tM3MjMn6kwXaN5ff+vSfH31xTx071MnufGLUkRdXh/a5G/XuQeUfnxsQ82JG'
        b'pKzK69WaVr8sjwMvPl8XuHnHNz6/HZrYWP2uZIgxYcWFoWkD9jpGnxQao66/MGkRf9v/t5+H3RqcHln0p1ePHuq8rN88LmXG8XTTyP2vLL+RoTvw8uwUw5lj3xVmuryR'
        b'sHjwmT8mJyQvaGnumF2/as07X7+Tr7wXmv+Sxjj1z3+9pR+xcaLW7/6SjOp90R6+WX0++HP1kp90Pw987XOF15K/LR7NJby1QxedtGDu2ckLPHTLQ1/+wz9VV7acOr65'
        b'+efCe5z+n/I5EZvW/XTjFY+OnVPb/9BvXXBn6IyLPyRM/Doz5dsQvvlbnzkX25e+t2+T8f3PNgz57NCMCxNsv+449bYp7/z9zpaWmysPO5fvbw1Lm9jZ4PLBZqPrhHTX'
        b'4E+cf3xu4oor9We/CM7/JPja6Jg/tZuVSTVTPjlXVzz5dd8fup5Xlp7504nbf9ySPvba+jfuKPPfOLfstfKxXhnXbF6zWffOt1U7Lt8vOOIx6bdr0+O+ebPyq1cnZ93v'
        b'89PP++8mDPi2gPuq8bC/5/L7kqbKYa+8eEDtYCaBMDsaN+Jyn1hIXnGVDyTq6BQXCGGvOQAfpAPwhewR3n4RPl5qP1y1Ic8HlzKMm0q6DBfiQjM5jUWt4HAKe24UwOfB'
        b'FpneKUCqv81MndUxSYq3H6TJpbCAHFVyykBfG4jZ9KirCmJKlI9nOHiPI2BoYMGAweqFqIyCRqFGfDwqIsYrxoaRSznYbZfa4k4fetkxJiOSHPavgY17KaAFa1dJmL4T'
        b'JZBYHcPHzXTfVmLAx6LQ3rA4Xwhp+ex0vNvZTLOzqjm40NtPjct8GEDpNJccpsEXUYmIbxOqhfSgPMYnAldCdxBnkTnGKcQbllIZvhpFLqOiIkjKDxzL4NCpaFi0FInk'
        b'2o0e4+0F5K6CdJFQbDeRQw32yZRZA/CFEVHgqHAFhI2GGN9IckvhgjsluDgiR+38+LH7f/ahtvuPwTw85ncRj/nNvNYoaMX7a3ra/yE8FDNsWTnbj7VnbTkF68j2g6dC'
        b'Ysu6sLbQBq2sgr6c6f+eT7b0vSNn/czJbThWft8ePruyzpwtJ2WlcnJv5AozyOn83CZH1pVzhLZ+rFQK/Q/+k/6eJ/z9zsXZEeaUAqQj60hXg9W5ofB04egLZiG9ZD1n'
        b'Ts66QU8/0stKN8FY6HW8p5ACVZuYzdJfefseXqgl3fa9WdDrHuM/xlk1yzv08JZOP5Ox3nIMvvaUWw5fmqhByn7cep3lr4ZdqHdstB9kFi2irnvLmTnotA1sOMrxATVL'
        b'UyANOoYuR0X4RMwRIKeFlLg+efATZ0YEEXqcE83QMyNyf848eYOe6fDg7Ij7d8+OfsyFyRWqXv/iiRoJKu2jNQ+0kGJ1nk4VkzghKEBl4umbQL9HQB/5EGFW8TqzhTeS'
        b'uQx6wUymSNMac1Ta9HSTxWhWCWatWZerM5oF1cpsfXq2SsvrACaP1wnQqMt4ZDqtoLIIFq1BlaGnktXyep3gp5puEEwqrcGgSpgdP12VqdcZMgQ6j24VqEE6zELGGB6Z'
        b'it5piqPSTcZ8HQ+jSKmHxahPN2XoAC9eb8wS/gVt0x9isVqVDaiRGpNMk8FgWgmQZAJLOpCuC332FL7Awwwdn8LrMnW8zpiuC7Wuq/KcbskE3LMEwdq3Rv0Y5JMwII/U'
        b'1FiTUZeaqvKcoVtjyXomMBEBIfPhejOgxaDTm9dosw2Pj7bK6uHgKJPRbDJacnN1/ONjoTVNx/emQyCIPH1wmtagBQpSTHk6YyhlJwAYM7XAeEFryDA9Ot6KTK6Iyyxd'
        b'uj4XVAEoJYx62tB0C084tPohNgvwkWzeYnzqaHIZHkqfMKclPRuGCfDJkvssrNMNJkHXg/ZsY8b/ApTTTKYcXYYV50f0ZT7Yg1lnpDSosnRpMJv5fzYtRpP53yAl38Rn'
        b'gX/hc/6HUiNYclPSeV2G3iw8jZYEYjeqORazkJ7N6zOBLJW/6HVVJqNh9X8rTVYnoDdSKyWOQmUlTWd8Glm0huBfUDVDZ9AKZgr+v4Oo3jlF6INw1jsWPfB3eSbB/PgE'
        b'Vs3QCem8Po+APMtzE1nr9GnPwJhELrO2R7kWQOSCpQyGZ2iYddGH6vjoWs9Wzf8w33kdRFEwulAVeBkYOQ9fSc9JExd42njii4D4lBxdL1H1IAQsMOArgqAz/CtQMwT4'
        b'ZzDROg8Z8XRkn4i4URZjhs749IhpXRZi5FNi9aMLw5h/NUdW/qNxdw6RNj6SaRbAU2VCEkO6nwaYx4MAwOdpn75uvLVbZ/SN5f2ehf0jaz+B99Pjv1URHssBHgF+Zj4g'
        b'wuph6acDRsyYHvtstUsx8fosvZGo1JM+JM7al0YVEgxYFcbrcjNWPtPWe8/8byi0OPw/6EyytRBtnury5ujS8BUw66f4hP8GxIgZUDsjfu4RvBKh518bm1Gbq3vo7ax5'
        b'scozFpqfqqcWPo/mRU9AzNfxK3XGDGKWa1bq0nOeBi3o8rShvRNrmKBXVv8UiMVG49JQVZIxx2haaXyYdWf03gdoMzKgYaXenE2SdD1PslQdr09X6TP+VYYfCrtpbS5x'
        b'm4BTYvZjFeCPAoZa9zmhsC94WmR4dPQjl/Xk9NeJefyyPlGs+3g+VUILExl+o6ErWiXedj/vI2NsSb35mjSDx8yJjIXcb89ywVtQOWpDZcF4OzqPtpFT7iZUMQadp8fe'
        b'3Fh8Bp1hJuHTMtTohjrp1jNwIymKQVdwJ2ycJzITcTXaS5foSy/UGecW/QaffP0yRrwEqff01wQyuANtFu+08RZcaFFBT4BmlXfPZvfBRnf4MBnqwEfdfXGX2sEynJCJ'
        b'L8Na5eEx0RG+iJw8wdAoXzkzLFnqFIGPLFtCr+eXAf4Hcbl/JBnkH4n2o80xUT0HumNxhdzbrj89p3YbiM6T897eh719ElELujhJPMfuGsVGzcFVva/CyT042pRP+/GJ'
        b'keMeXnfjY7iDXnk34xYnepTthmvJGZl43M4xtvgi54quoDKbxZTo5FzUQK7ZI4AI2O3jKv9wXCFhhrlIY+W4RuJh8SA4bEVNSnFUMal8jqLVj5W4lJQ9jPKWTcLtqNoy'
        b'BkYG4Vbc2mu+OLFCITaGZdToimydI7nbRO2WkfSywwefpGNRx7Ce5UkRAgwelSqbhtuSKMPdUMM6bz9cAbP5RcbgUjdc56OWM4NwvRQdxltxhUU8DLRPtY6KiMFlMMIO'
        b'72EG9JcGhOBz4nqXcJPl6RK+hovc0TlUZ/Eh45ol6LhAS5jneYZHpPh40QKLBeQYEf4mxeMKKbPA1wZV+zqLKrUbn0KXNIFStG8EqbpjMqbgS1Q4DrjY5XHhpqIu1JKv'
        b'EO97CtKWaAJl80jhLapnstHF6WJNwSF0vg/eJcXnbBhyD4QKNOLlYfVqfD5qlucTytCBTtA7MaNq1UNlGITbRV0w4X1qjl49uKICdEqDWvPkDBvNoJ1DUPNSXC9e7DRn'
        b'4QroYtBZVEirN3LQMXyV0jEMH8IFjyoRKNV5VBabpZZTHqSiMyM0mjwJw0YxWlQJQj6DD9Ml45egJo0Gt8gYdh6Dt+MS1I4qxXoLG3wI7ddoeICKY3CNLzqLy0dSm7bL'
        b'tQOYVoCZz/BoD5hg1zJaR7KGy9FoWNy1iDCJyVmJr9CZ+qN9uEajkeGq0aTSgDGgnaiROoGBIQMYkKrzN/7GdQtMAxk6C9qWqBLw5QyWYWYzs/FBtJuOjVrtTL4AE9IS'
        b'sjbaZbwto5bQ6x5cuQJvEm97Ht70NOEiVI0u4ypR+4pAEVuiUDk+3uvaiNwZqfAOKtJJS4QoWhkulbJmO9SgQq3WGzXQvvN4Zw/zAPFa4N1psUjEC+3Fxx9wbxi+Csw7'
        b'hg9QFzMR1PLw020XHUPtuMYDNVnFTr7fwvYwGrUHgIjL0DXKuUUb5j3gNLC5Al4NCgv9KtAUJE6PLqPSpxi922DKy3WrVCARVAR6T0USpqA+Ixkdcn62I0C1GlQ3W0s5'
        b'k4XqcSXIDngiym7uULo+bsxCO+gUU/CFp/iH1DF0fTVuwKUajdRrJi1Fys4YRr2GDB+fGBXhG+sHvsATl+b4i6f0g1CxFB3FXWiHWFXbiI6sIyU0at8IKWNnwzlC+Kk0'
        b'4uNUH1oXOzFgdm7Xl2YYJoRvECuy0NWN6MoDUa6Qo4aZCdTTLkSHaIlQbzVRjULV6lTxBvn8Chvv9SMifaN8vWLJN42csiS6aHTQMprgcdUU/2g1F65CxaicFg4NipaC'
        b'VmzHDdSNsatQzROFX9aqrzR80hFX2lL2oXNyV7GAClX69/JBXukyE2juKf888RI1BNXT4reeyjfcMGM1Ou9GryNRixKXikVivQvEhuA9eNtyVEtZOApdBLWnxUpiqZIH'
        b'bkL1qCWIBoQ+Ib4PWAJaVOWIzvvjsmhyYRNFmBCI9sojwhZSZV+SbvPgznQyPkCvTQ/MXS4Kao97n17FVL5JpJzKCZdowEYJGXNR4xSxQEssz2rER9Ch9biddo4GP1P6'
        b'oFAPbRpFavWc8tbSCIiP4Dq7R4oJS/25CQvFUsKtEBOoQ960apwSgl8ZpBgJTAI+gclVMSlPXGVeJKTik6InGY0uUx1JzkeXlbwcXQBB4JOQZsSjbeLV71l0ABfhXfgc'
        b'3sKKX8M4icvEbCWBVCaCt3fJiz5lWieWYYEf3Y5Ok6t/Gy0qIpdWTApuThSDx0WP1agtQIKPwEh0gjGpAkRjr/Cbinc5OYJXqbZhHI2gpYkRGyxzCchRvM33kYt44CdY'
        b'Ja5IwCUR0O6PS+PJlXy4eB8/Nx61qnIDEuaF+8x9JPyh0w7OcUusUQ634FNuUbhG95jrw13plLIrGiUDXLH9ZvEqg9t4byYRZEYQXTMGNUb11Ol5oN3yFM5rQbiY9ZwX'
        b'BkWh0jmPz7gFF1B/a4Pr0PnHXfIFSBWrE3AZVV03SArbH00I0OkRNCHAF9EWitjOZHsG9MNzu5L3Walaw1jzu+b+vdMNXIuOPcw30MFZlgWE5sMD5wkPmQQsAv6Q77n5'
        b'+XqClnlF4M2oTqzQSyA8LvGZH040jOrw3CfYeW1tH1SB6vxpQZ5fjJSmxq9nrTL81mc6Q+mxz1jxuJLiw7iKqikuSgdtJN48Cl9JR21BJLzPZZYtBfUBRespNywF/kAf'
        b'S0LJeki0m9HpeRZSqTlOsMG7ECjADjDs3agkfwT9a60yaZah1rR55jR0fhwLLJcvRDvxPrHe46zE58GM+aCpzWvwHtpjmgsm14MHeKAidGaKn1qsd55piyo0wSsgFkUy'
        b'IMZLqDl/Fu2wTMNlmiC5DaqjWZQOVaFd1lqVWlysCcqHdaZBcxs6mYB3i1TVTZ4K6+AWhsavU7BnaPVA26yXUmh32mzoHQudYYz9VDC9mmzLDBI6J00HK8DlwM5yf1yV'
        b'gFsc0LmgsfEP1H6e7/x54TG2j4kJCGlQkAI1VGotzhVgi3IK9OmUHAIhsy4Pgj3R7FwzaM2pYHSOYzhXxoi7cJMPeHpitd7ZqwDNRrRfxjAbmA14L74IsiOBLB6djce7'
        b'FKhQRr9shbZYv06zH+2eDOI5I0Pt4DJwLZDpijoBiBZBHV+bEDVu6mN2shQdEvPFK77uj1kJroLEFdVYk76BuHw5qZHscCCFVxdYkGFb0FqxTgpXolZ0hhbJiBUySvno'
        b'DD0tYrZMgIcWtE8ZG4MrfOdbdT8CX8WlC8Ijk8ITRY6ik+BNYnz9YqPjZIAqblGgIvkk/cT1d1jhLZjo28W165OiTINnOzd/feDbV7/8Y87t0FdnMO+u3mnjb2OvHV4Y'
        b'Mjx16ObGvBVGj+j2N21fGzEy/sJ2N9uPhseE+CrGtM/QhO/4pc++kDx5rOe+7b9ILuZ9+kXd+YhZ0w6fab537NjnX3x+dq2QEB8x/mXXCWm84vDN7OSLqvFfBAW/E9sZ'
        b'4JRbcyr6uA2fi6MnvKxMcrm56ccRF69vPXz43f1X5mYHB/v8mHx8ccnYwQGZ9Tdf6awrN1RkbQ19r93r6u4X5q84E1c7L+Ok7Wmvq8dzn/vhdlZ5SF2714b0/bPmV4SM'
        b'qcxtcRo4ZcGLS+Z8+txHDuPlQfNfSrled92Y98ewibszg7mG+SeDx6V1S7bsr35x6ien/nB/SIrFeX1Cy4QbG9hgpy/zh25euvcz5XtjVjXF/XXQ5y8Lyz5snvO9+7pX'
        b'lO+/1u92vdvCH0d03Zse+PXebR9IvpD8FtFiI/3N9VbBh7+1pcI791szr2/o+6X2Rpf0pxfjq5J+/djykcex+rK9R5s/qm7y216wZZjL2uQv+5yb83zwc0P7/nbi1sdp'
        b'76ZlPX/Aee28L9XnqlZfnn3vby+M+XQPP7ap+YeTtlEBUa9FLyz8073TiZMXSkcO+v4Gu+Kdt86tHOv/8fqi052hb8+fM6bBbXlq8Tl/y9Sf1t/0Hlz5VvHtspvuU14N'
        b'Xhe2gS9e0vf7m8av3rC8e6t8eeLET64/r72dm+P/edvym3ER97tafe98ujHt99MBCbNmvtR9fql0SHuu5vt1Tg6z7K545VTeKXl5gbf8efuGre/b52W/+UrapNGXCr4+'
        b'+Mst7yl3HH+788PrDTUeOS1t8mVOSTm/R5/88MJKyxehd7Z9NS1JWTL3s4bX73c33/v+en7ID2tv/yhtfm1GeZ+Wf3zY8FLQ1KljV2ncts9qfn/Md7K5hv4/f7Rp56kX'
        b'N+bfXmeXtcHumoAmu3z9xYf3vnPc/Hfdvrslr0neMTqO+7TM7e68Ex9dbUk88berb73Z8JZl4/J1vhOGDMj4cdChFSkX/Yd2jp585arnnbOjc385W3KtdtaH+S+9bfim'
        b'6/3J9181rPT5ddwf8m7/+Zekz/YXpPzjnStTWz8yJYakjZvf59ek6053LC/9/spd09HLprCU5+eoPj6z1th41fFviW4TDo6e7LekZeU3P2PTqoYfA2perd+wrP2XoLDJ'
        b'7/39zpVXFRMnV71nq/nrjXfeXvrzn/bsv7DU0/7tnI64RZcPlL9/+Ejf1+d8de7eJ5Uj7n/yysbk1cuGfXA07uK1Y92zfho/2v3u7W/r0VsNx2viPqp8491r3Pqo12XT'
        b'45I83x76vcvbxrA/rvvLb5Kzd446rzN0hm2Vd9WH/WB4c9yVU38O/Or7q3dnPHdz4+/KXxS3Vb/mlh7x7rfxm/EdC0+94BWsdjKTgGWzER+31t6ACxUPSVBhX2YA6pCG'
        b'uy8xE+8lgHNr9vayVsPYLeRwzTh0dAEupqUy03So+UEtDNobIA+C9LwQVYulMi3xzIPSnv54C6nu8Y1QUkA7tHUGrezpqepBnZNW4/J0sazoHC5Q9yo8isMltPYIN8e7'
        b'm0lCiI464AJS/fBYcc8eSNzqcavOTBKUdSze+6A4iZQmoaqhtDrJw42igE74LPCOjfGJJLjboovcOlS/El1OsuKOT+dDrlXm7wsbw1T5Ss4PkuhztCxpEDoeFuUUCKj3'
        b'zMw4BUiygnAj5RiLz7o8yJnQXnSUJE3kNw3oxHNQ+fqe2qJMdImUF2mADIoxroF8obDnu7eyxFTrV29noz1UXrjIgKpxGykvQmfyxG9wr8NFTP9JUkk6KlX3//9dIvTs'
        b'khWH//w8T3xtONc8ISiAFhLVkbKUjcxGW5eHZT0KWhpkS0t5ONaRFBRxpGxHwXIcxz79v/x7WycpLTqyp5DuLCkpIu/daHGS/K6trKdXHEFKfkiVDXffmePuSSXcXamU'
        b'+10q436T2nB3pLbcL1I77mepgvtJquR+lNpzP0gduO+ljtx3UifuW6kz9420D3db6sJ9zfUlGNh+4ThAxcphXSnrzLqxzhJHwNseVhgMqw2+34+WMDlzivty+EtotGfF'
        b'giRSAKWQ0M93FXLac1cqJ61upJUjlLgABQoZKVIiXCAvKSeHEXJOzo0iLRJOnNFaGKXg7OmnwYBJP+h3Zx3FUqn73H2FFPhxTyG1p3yWbuK+UziTFUiplj3MR9rlsKaU'
        b'4516xKeWdEvJuXWv0qf/vGKoWd65RzXoUn8kKkHSHWbzqI6nFERR0+gYjOrBI6xGtV70FMKXZIsM454nwRcXZz/xLXyiYNPIvCSt05HfgGEWcRnsIkkGl0B/lqLbmR7D'
        b'0xIlfjbPm/hfh4kH81RZeWvFkS5DpTWqdKTfL1Yt7bZNSSE3GSkp3YqUFPHHXuC9fUrKCovWYO2xSUnJMKWnpIgW8PBBCSY/K/EJaz2it2VsObrj6R+EOpWO+IJZaUdq'
        b'vqIDfXnrDzj44wa5LGSpmg3T+0VkSoTZAFt2N3Py6y/F4oB+sviJse92JoQecdAdeIHTHTi4Tec1yPX360nSpue41hlpM0f8ZXra8x2L7+3aO2J41JwNce+UfxH3xZmD'
        b'ufsVIavmXHn744nb3A8v/OHTzz+w17z/mZfLdP9/tN1f8qY2/KL9fM37c5tHLnOfUmz/i83G1Nd2tv2S/c747Y6rrtxdO+jo7sQOrzXcwIyZ3i6dCREekyWrbx3c9vKY'
        b'rVzZB4M9dkfY9G9V7D2t/HJmxZcvMBNKhvNuIz/xvPniiujtu2pGHB8789W0yn0vcAtfGHGxUNe6uT/fPyf5BXnwuaLcL1MHrL31Auu4onB05eWfnKpCYvPKNPs+PpQT'
        b'tjWtzLvA/ZMTM6fX/uHbUYs6jwy1W/qmfukbA5fzPz6vVieF6dS1x083GmZUVx9e4l+c89fC+b97347eu8j+QnaxfW6KdMSHfSSXs777dsDltwzN72K11Ex0Y2BkEuw4'
        b'YFsTkpRH8u2CeDEC7cdbN4i/ptHrpzTQaVwptcUXwNeT8x2JdJ3SC1ejTlLUCWHqwdBhqE2Kz4bgk7RsVItrUwV0JjzW17MnmPXB2yX4tBq1hE8Cc6BW4fJf6M3ldMvw'
        b'7Af10qDaBpM2IyWFuugt8OBcOS6IVRF3cZ84CFvOmXO25eTEfT7xIu708Rdxr4+/iLuFl1yqoG7L9g54OtGZ/zbYltnI2dmzniwJDtxAV5Yf0MsVcWBSDx1Rn/8aVrG8'
        b'2wNbJYsTv0RrNf2+fMYvUqBqu2RUTo4LyU8eLUmETX6VDeM4UDJEg47qEzNrWCEThrXZDRpyc6zjlmnOW9/YmLnSwZx2dPSoVaPPBpxbNDHqs/ApP7nmJTicXaM92LQw'
        b'Jfenb9+rO9t19Jv77/VzPfnpSn2o9+/Na5bbaTMUQyZnyf1CFhj/GrEtetKymZ94Rr1jOH/817/b3Ixw+0tDsdrGWmpcNIv+NsZ6dDaOnvTZQK7RyuETS/FumovkbkSn'
        b'o+J8IRUrjYuL8+07nwOlvCJBB7MkZvELFu54p0gWOdIzD0IVlCwXyVBvfMlMzgQyUDu+GhURE4iuWUu0bYemimXhB/xoDz6GTz/4WSelmsPbB6LNNMeaMzJbgP7TqOXR'
        b'n30aNNVMv9vkbvaOhP3qoT5sFKRNaBM62mMnqv+2JOj/VYWk/9LG9Ea92WpjRK1sHRTWumkfCdF6ZqM0iR/4QOtHdEsMOmO3lBTMdsvMljyDrltKboYhMOvT4UmKHrsl'
        b'gpnvlqWtNuuEbimpm+mW6I3mbhn9oZZuGa81ZgG03phnMXdL0rP5bomJz+iWZ+oNZh18yNXmdUvW6PO6ZVohXa/vlmTrVsEQmF4iWHK75YKJ1LV2K/SC3iiYSdlctzzP'
        b'kmbQp3fbaNPTdXlmoduerh4oXtN3O4gZn14whQQHjO1WCtn6THMKDaPdDhZjerZWD6E1RbcqvdsuJUWAUJsHgVNuMVoEXcZDIxd5oOLJb/Tw5JiMJ7eDPPG9PAmbPPk+'
        b'NU8OuXmis7yaPMjFDE+KqHlyrM+TA3t+LHkQveOJevJe5EF+QIcnuQXvSR7jyIN8y5ondyc8+To0Ty7EeRV5kF+i4snehSfGw48nD3ICw3s/8BZEaHY9Yo2886S3oCN+'
        b'te35EaVu55QU63ur4/3VPfPRX5VTGU1mFenTZcSqbXnii0h2oTUYwBVSJSHG0q0AofBmgVQmdMsNpnStAeQxz2I063N1NLXhJ/Yw87F0pNt2kpjETGF7MJcyUrktJ6pi'
        b'Px1HM+f/A7vJpjI='
    ))))
