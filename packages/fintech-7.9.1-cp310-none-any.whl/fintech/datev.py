
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
DATEV module of the Python Fintech package.

This module defines functions and classes
to create DATEV data exchange files.
"""

__all__ = ['DatevCSV', 'DatevKNE']

class DatevCSV:
    """DatevCSV format class"""

    def __init__(self, adviser_id, client_id, account_length=4, currency='EUR', initials=None, version=510, first_month=1):
        """
        Initializes the DatevCSV instance.

        :param adviser_id: DATEV number of the accountant
            (Beraternummer). A numeric value up to 7 digits.
        :param client_id: DATEV number of the client
            (Mandantennummer). A numeric value up to 5 digits.
        :param account_length: Length of G/L account numbers
            (Sachkonten). Therefore subledger account numbers
            (Personenkonten) are one digit longer. It must be
            a value between 4 (default) and 8.
        :param currency: Currency code (Währungskennzeichen)
        :param initials: Initials of the creator (Namenskürzel)
        :param version: Version of DATEV format (eg. 510, 710)
        :param first_month: First month of financial year (*new in v6.4.1*).
        """
        ...

    @property
    def adviser_id(self):
        """DATEV adviser number (read-only)"""
        ...

    @property
    def client_id(self):
        """DATEV client number (read-only)"""
        ...

    @property
    def account_length(self):
        """Length of G/L account numbers (read-only)"""
        ...

    @property
    def currency(self):
        """Base currency (read-only)"""
        ...

    @property
    def initials(self):
        """Initials of the creator (read-only)"""
        ...

    @property
    def version(self):
        """Version of DATEV format (read-only)"""
        ...

    @property
    def first_month(self):
        """First month of financial year (read-only)"""
        ...

    def add_entity(self, account, name, street=None, postcode=None, city=None, country=None, vat_id=None, customer_id=None, tag=None, other=None):
        """
        Adds a new debtor or creditor entity.

        There are a huge number of possible fields to set. Only
        the most important fields can be set directly by the
        available parameters. Additional fields must be set
        by using the parameter *other*.

        Fields that can be set directly
        (targeted DATEV field names in square brackets):

        :param account: Account number [Konto]
        :param name: Name [Name (Adressatentyp keine Angabe)]
        :param street: Street [Straße]
        :param postcode: Postal code [Postleitzahl]
        :param city: City [Ort]
        :param country: Country code, ISO-3166 [Land]
        :param vat_id: VAT-ID [EU-Land]+[EU-USt-IdNr.]
        :param customer_id: Customer ID [Kundennummer]
        :param tag: Short description of the dataset. Also used
            in the final file name. Defaults to "Stammdaten".
        :param other: An optional dictionary with extra fields.
            Note that the method arguments take precedence over
            the field values in this dictionary. For possible
            field names and type declarations see
            `DATEV documentation <https://www.datev.de/dnlexom/client/app/index.html#/document/1003221/D18014404834105739>`_.
        """
        ...

    def add_accounting(self, debitaccount, creditaccount, amount, date, reference=None, postingtext=None, vat_id=None, tag=None, other=None):
        """
        Adds a new accounting record.

        Each record is added to a DATEV data file, grouped by a
        combination of *tag* name and the corresponding financial
        year.

        There are a huge number of possible fields to set. Only
        the most important fields can be set directly by the
        available parameters. Additional fields must be set
        by using the parameter *other*.

        Fields that can be set directly
        (targeted DATEV field names in square brackets):

        :param debitaccount: The debit account [Konto]
        :param creditaccount: The credit account
            [Gegenkonto (ohne BU-Schlüssel)]
        :param amount: The posting amount with not more than
            two decimals.
            [Umsatz (ohne Soll/Haben-Kz)]+[Soll/Haben-Kennzeichen]
        :param date: The booking date. Must be a date object or
            an ISO8601 formatted string [Belegdatum]
        :param reference: Usually the invoice number [Belegfeld 1]
        :param postingtext: The posting text [Buchungstext]
        :param vat_id: The VAT-ID [EU-Land u. USt-IdNr.]
        :param tag: Short description of the dataset. Also used
            in the final file name. Defaults to "Bewegungsdaten".
        :param other: An optional dictionary with extra fields.
            Note that the method arguments take precedence over
            the field values in this dictionary. For possible
            field names and type declarations see
            `DATEV documentation <https://www.datev.de/dnlexom/client/app/index.html#/document/1003221/D36028803343536651>`_.
    
        """
        ...

    def as_dict(self):
        """
        Generates the DATEV files and returns them as a dictionary.

        The keys represent the file names and the values the
        corresponding file data as bytes.
        """
        ...

    def save(self, path):
        """
        Generates and saves all DATEV files.

        :param path: If *path* ends with the extension *.zip*, all files are
            stored in this archive. Otherwise the files are saved in a folder.
        """
        ...


class DatevKNE:
    """
    The DatevKNE class (Postversanddateien)

    *This format is obsolete and not longer accepted by DATEV*.
    """

    def __init__(self, adviserid, advisername, clientid, dfv='', kne=4, mediumid=1, password=''):
        """
        Initializes the DatevKNE instance.

        :param adviserid: DATEV number of the accountant (Beraternummer).
            A numeric value up to 7 digits.
        :param advisername: DATEV name of the accountant (Beratername).
            An alpha-numeric value up to 9 characters.
        :param clientid: DATEV number of the client (Mandantennummer).
            A numeric value up to 5 digits.
        :param dfv: The DFV label (DFV-Kennzeichen). Usually the initials
            of the client name (2 characters).
        :param kne: Length of G/L account numbers (Sachkonten). Therefore
            subledger account numbers (Personenkonten) are one digit longer.
            It must be a value between 4 (default) and 8.
        :param mediumid: The medium id up to 3 digits.
        :param password: The password registered at DATEV, usually unused.
        """
        ...

    @property
    def adviserid(self):
        """Datev adviser number (read-only)"""
        ...

    @property
    def advisername(self):
        """Datev adviser name (read-only)"""
        ...

    @property
    def clientid(self):
        """Datev client number (read-only)"""
        ...

    @property
    def dfv(self):
        """Datev DFV label (read-only)"""
        ...

    @property
    def kne(self):
        """Length of accounting numbers (read-only)"""
        ...

    @property
    def mediumid(self):
        """Data medium id (read-only)"""
        ...

    @property
    def password(self):
        """Datev password (read-only)"""
        ...

    def add(self, inputinfo='', accountingno=None, **data):
        """
        Adds a new accounting entry.

        Each entry is added to a DATEV data file, grouped by a combination
        of *inputinfo*, *accountingno*, year of booking date and entry type.

        :param inputinfo: Some information string about the passed entry.
            For each different value of *inputinfo* a new file is generated.
            It can be an alpha-numeric value up to 16 characters (optional).
        :param accountingno: The accounting number (Abrechnungsnummer) this
            entry is assigned to. For accounting records it can be an integer
            between 1 and 69 (default is 1), for debtor and creditor core
            data it is set to 189.

        Fields for accounting entries:

        :param debitaccount: The debit account (Sollkonto) **mandatory**
        :param creditaccount: The credit account (Gegen-/Habenkonto) **mandatory**
        :param amount: The posting amount **mandatory**
        :param date: The booking date. Must be a date object or an
            ISO8601 formatted string. **mandatory**
        :param voucherfield1: Usually the invoice number (Belegfeld1) [12]
        :param voucherfield2: The due date in form of DDMMYY or the
            payment term id, mostly unused (Belegfeld2) [12]
        :param postingtext: The posting text. Usually the debtor/creditor
            name (Buchungstext) [30]
        :param accountingkey: DATEV accounting key consisting of
            adjustment key and tax key.
    
            Adjustment keys (Berichtigungsschlüssel):
    
            - 1: Steuerschlüssel bei Buchungen mit EU-Tatbestand
            - 2: Generalumkehr
            - 3: Generalumkehr bei aufzuteilender Vorsteuer
            - 4: Aufhebung der Automatik
            - 5: Individueller Umsatzsteuerschlüssel
            - 6: Generalumkehr bei Buchungen mit EU-Tatbestand
            - 7: Generalumkehr bei individuellem Umsatzsteuerschlüssel
            - 8: Generalumkehr bei Aufhebung der Automatik
            - 9: Aufzuteilende Vorsteuer
    
            Tax keys (Steuerschlüssel):
    
            - 1: Umsatzsteuerfrei (mit Vorsteuerabzug)
            - 2: Umsatzsteuer 7%
            - 3: Umsatzsteuer 19%
            - 4: n/a
            - 5: Umsatzsteuer 16%
            - 6: n/a
            - 7: Vorsteuer 16%
            - 8: Vorsteuer 7%
            - 9: Vorsteuer 19%

        :param discount: Discount for early payment (Skonto)
        :param costcenter1: Cost center 1 (Kostenstelle 1) [8]
        :param costcenter2: Cost center 2 (Kostenstelle 2) [8]
        :param vatid: The VAT-ID (USt-ID) [15]
        :param eutaxrate: The EU tax rate (EU-Steuersatz)
        :param currency: Currency, default is EUR (Währung) [4]
        :param exchangerate: Currency exchange rate (Währungskurs)

        Fields for debtor and creditor core data:

        :param account: Account number **mandatory**
        :param name1: Name1 [20] **mandatory**
        :param name2: Name2 [20]
        :param customerid: The customer id [15]
        :param title: Title [1]

            - 1: Herrn/Frau/Frl./Firma
            - 2: Herrn
            - 3: Frau
            - 4: Frl.
            - 5: Firma
            - 6: Eheleute
            - 7: Herrn und Frau

        :param street: Street [36]
        :param postbox: Post office box [10]
        :param postcode: Postal code [10]
        :param city: City [30]
        :param country: Country code, ISO-3166 [2]
        :param phone: Phone [20]
        :param fax: Fax [20]
        :param email: Email [60]
        :param vatid: VAT-ID [15]
        :param bankname: Bank name [27]
        :param bankaccount: Bank account number [10]
        :param bankcode: Bank code [8]
        :param iban: IBAN [34]
        :param bic: BIC [11]
        """
        ...

    def as_dict(self):
        """
        Generates the DATEV files and returns them as a dictionary.

        The keys represent the file names and the values the
        corresponding file data as bytes.
        """
        ...

    def save(self, path):
        """
        Generates and saves all DATEV files.

        :param path: If *path* ends with the extension *.zip*, all files are
            stored in this archive. Otherwise the files are saved in a folder.
        """
        ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzsvQdYW0fWMHzvVUEgUY1t3OWOAIne7djgBohmgxu2AwJJIFtIWAUb4l4CNmDcC7bj3nvv9mYmu5tskk3ddzck2U1PHGc3yaZuNht/Z+ZKQjKS4+R93//5/uf5jLnc'
        b'6e3MaXPO3PeZB/4J4Hcs/FpHwUPLlDHVTBmrZbXcKqaM0wn2CrWCfawlTCvUiVYy9Yy19yxOJ9aKVrIrWJ2fjlvJsoxWXML4r1L4/bA4YHxW6YRp8lqz1m7Uyc16ua1G'
        b'Jy9usNWYTfKJBpNNV1Ujr9NUzdNU61QBAaU1Bqszr1anN5h0VrnebqqyGcwmq1xj0sqrjBqrVWcNsJnlVRadxqaT8w1oNTaNXLewqkZjqtbJ9QajzqoKqBroNqzB8DsI'
        b'fqVkaHXwaGKa2CauSdAkbBI1iZv8miRN/k0BTdImWVNgU1BTcFNIU2hTWFOPpvCmnk29mno3RTT1aerb1K+pf9OApoH6QXRKJIsHNTMrmcXyRv9Fg1Yy05lF8pUMyywZ'
        b'tERe4va+gEyHoLDKfZ45+O0Lvz1Ih4R0rksYhbTQKIH3pQoBQ+LiUvoWv6YZzthHQIBFh9Bm3ILXFOVPxs24rUjRF13CbblTi5ViZuQEIb6DV+FVCtbeHzJX4uX4ujW3'
        b'AK/DrQW4lZ1VyQTkcugsuoCPKDh7T1LfHLxanRuTK2KEQhbtikV7IvE6O+nT3FHDSYISr8Gto9GaAhEThNcKCtGloVCUzCI6E4Buoha8NqYOOtSaK8LrLEwAusChi1Cm'
        b'2T6c5LmFruPDkOm8DDUvmG/HF+bjlXi5bL6dZXrjdgFqLUIboLdDIS++GYavohbUHqtWRpEuW9Fq3E4i/Jh+w4RoZWLfKvYBIO3nnLwaspr8WjK/bDX1/RyryDYDMC/m'
        b'YBVZuoocXTl2CVfi9g6rWPPgKpKO9Oq2ioP4VWwJ9WNkDBMSN82W8ryRY2hkrM6xtPW5C39YmsFHinpLmBCIi6tvGGCo0PORedkiBv7K4/R9exoKZcwxxhgA0aHaPsKv'
        b'wyLGSJh3R/6Tuxw/OaeOMfpDwuLE7eyuYk0wM7Yi4a2EdfWFfHTkqK+CZZWqQVzxO+xPMw5OvMR0MvYYSBCiDSmwei2xkyMj8drYHCVei45JJpZG5hXg9hhVrjKvgGVM'
        b'wf6j0eER3WZf6hx0Dj/7nvuIIXOvl7pml/t1s0v2iLjb7MoKLaQH9nACOEfxmuiSKcppHMMJOBuDd0um22EmmUl44+ISjpFGMEOZoeiInuZG+4dkl0xBu/FtqLmGmYBv'
        b'oLV2UjnaU4+24k0CBp+dzMQysWJ0zh4K8RGwi9rxJpZJKWKUjLKfwB5Bq0Fn8fmSgsm4TcRwT+Dj+DLbPxlfsUeSpUQ30HmyKaLVuBWvyZ8ciY7F5NA9ii6idSp8TIRW'
        b'jMbraf3jewehC2IG77Iwo5hRUtRsmDL2Jca6HZK2Rq6c82J8EIqTrda8mdu5avdflwnOXnhaFBItEUvPTdminPPsP69OsJaErV//hw/efeJOa6/Hvnw+uPTzdYUfH2hN'
        b'smgP+X2j1n2f0+/6E0kbQjd+Hb3l2R4nJu88dGDHjffmrXrW8NeZL09dW3tn2twjBVvfeLLl89B3Pn3vTO/tRUsVeya8+eNrE2c+ffT3+3sNGL7k/JPPoerHiq/eYtfP'
        b'SFnRUqYQ2QaQiV+mj1TjtmjcVqDMizFlAxaBLSzATegWPmYjszQRb2Oj85S4OTfXkl8oYqToHId3FwtsBC3jjhB0LlqlyIsmOAYQDN6DtwTjZQIzvo420Szo+FJ0Wkom'
        b'zw44YS1qAhjlmFB8XYBOqebbCJ5aAHN9AOZ6LSxSK2yrdHwZd7Do3NTHFVwnF6mwEJhRSOmfX/Eg4PdDr1F6i7lRZwKqQumVCmiNrv6xzkCLzqTVWcotuiqzRUuyWuXw'
        b'kDwWwkrYAPjpBb9B8EP+hsHfEDaEC2AtYmfNCkGnmC/c6VdebrGbyss7peXlVUadxmSvKy//1f1WsBY/8i4iD9LcGNI5Av9yLOY4VsySp5AV/0SedkIZ8WFDfnSeCR/E'
        b'bepcJVobCyhgXWweywxH50Tl89Btj21J/gkdfyn21REWAdgDLVsmgF+hgSkTwV+xlivz0wY1MXpWK9SKVvmXSei7WOu3SlLmT98lWn94D+CpsV6gDdBKISyFMGAUCMu0'
        b'gRCWaVlgKaoVwZ3iKXTKCukU3v0J0FKVwK1bZMx+ToyRxjjJPFTEoyJBswBQkRBQkYCiIiFFP4IlwhK3d0BFem+oSNANFQl5RJ9dJgRM3RwnHFthfLwxnTGclweJrMWQ'
        b'MvuNJfcqXqj8pGKjtlnzaUVr9UndJxAu+81sfHZ9/OrJu/ZtDX2mSHNUYxQdZ4/PXlLxB+GGmAGyCVEDWqUzMpd9GtFnSsSKp7cnCpjzotBe305ViOnui7OgddEOUonb'
        b'owGDrEQHg9FhQSO+MMRGKCNqw0djnVkGo5NAcBlZjMAP7y209SHpZ2ZVqnFLPvAPCjEjQWvRLgO3EDeF0NSwMehJgsPUuegU5F2tFqdxfdBBvIzu7FG4DYh7SxGwCEJm'
        b'xFAR3sXCrm2KpIm4WYI3RCtzKGMhwRfR1koOrUoFzsENQgXethoF2E5JebnBZLCVl9MtFQSPkDLYOgC1QthEwvuNwTwEqJz5+M0k6hRadUZ9p5Cwgp1+9TqLFbhGC1kd'
        b'C6GCx1hny6RKSyB5BLt2CVBpZpZzl4Qc6b5LurVaxT2wGVxQl+KAOj3ngDmOkj8BwBxHYU5A4YxbIihxe/cGc4wPmKPUG1+eh/ZKcRss0zqg4bi9JIdfzsnFU4At3EZI'
        b'4hi8TxyK11cZzg6ysNY4UsOW1nsVBAIjq2LeU2k2JuVrPqsIqarRGyuFa+OVFf+omPFsxAu/2cEye5Ik9nadQkgXVYivDuWhhat3wAu3EDVX2AjyCErA+/EFwOPtuF2l'
        b'rCPIGhB13yVCNV4NbNxyi6036e8tFQUa4QAKNjzQTA2yETKIt0wfop5dX6RkGa6ezVrgx68p5xVAAEdW62wGm67WASMExQVUylgZ2xjmWiVXFr4qIV3xTqFJU6vrAgpL'
        b'CN9MmAskKDSQLlU5oSFojxdo8NLO/woaqn5kkFCQadyJn5L5AIkFeS6AmNrXsPd4pciaAEX6FvXKanCHiC54+KyCW5tgj/tL3ME4YWLdYQFz8hXJzD7PKwQUIvzzYnmA'
        b'6IXaXRCB1wXZ5AQfDgSeyA0iIma7YAIAYscTFCBKwvtSHIIuoVYXQAQ7aaNvBAHrb+2+/tUywA5u62L1XH8Rv7xkoTtF9RqjvRsUCNygINwFCmSea1yIoeOhoOBq0jdu'
        b'yOBBgTDLrF7438UPrKN6T2AQFdrJTs9B69FlIsWhJrSiFDcrlarJOXlTcXNRCc+R5gBzqmIZG77lL8ZrS+3RUGjwdLSlC4DQ8dkeMOSCILQe7zT88feLhdZCKPR91Kp7'
        b'FZ8CDBn1UR/FaHI0Rgo9dZrmD0/pjmo+qfhjZUxVzMZITZ7muCakinmul0UwYUfvs7a4GK1Wm6OR6N95gWHi46Wrg1fGpgN/Sbm/C/Xu3F9sLt7rZP7C0Q3K/VnQiXwn'
        b'CUMb0A4nWjpts1GZch/ahra7gWHu40p3MDyDVlFIjkfngLtsibQUuSEmtG4WTURXl2TyxKwH3kXpGRCzbHRE4SAnQp+MIw+sYnsd4RddtCzAKKHsoYzl7odwjYEO4OFz'
        b'uaMqnky5YLTbhgCs1UXIKKgSkb7WCaphW7yAqmdr3UQ6T4RFxWkXwmKb2UcS4brBqNArjAoKDX/58iBnzYOIIfuXqjU51Z8BAP2hskYfrjkqOhfRO06pJQDUojmuO6nj'
        b'nlNWnNbMfnbG87NxKS7GRlz87JtPzxC8HvrCb97gGGH/NxOCLb8bCMSKMC+wmiuGdfE2YnSYwkXGWIp2Ghf15lmXPhNci30UHadpITMwiG4xubhNmeIHJR/nhuJVqIOm'
        b'KdHuwU6WKBhtBcEUWKK+Bd4h4GH4C5h9q83iwF1EoA+xhQE8BABcNAZ1IROShZY6JuAX2TcsAG/TBQZEG2F3Yaw2L2DwQCMKrtBCpHlFIOG9CIEEQSSgvJxXxMG7rLx8'
        b'vl1j5FN4FCqpAgCqNlsaOiUOTstKualOsd6gM2qtlKGidJRiUAqbtGdObPxQmYsfCJmaEjIQUk7CCDkhy/8EcTKJTBQiCpfYycKgdejMEikRWMrxDSKzSGRcRYPRt8Si'
        b'Yh6QWLgyoVZAJJRdXJloM6MV7wUJZR+7kgXpRULlDv9O8QQTYPeGH8LH6yoNNjMIf7Fqi07Lv97l+Yi7pIkfwqbpLI32amudxm6tqtEYdfJESCJD+kGWr7M12nTyiRaD'
        b'1XaMo9N+93cw5G92wLSqzSabObMQplkemaW16KxWmGSTraFOPhUkT4tJV1OrMyky3QLWal01PG0ak9ZrOZPGhm9ajCp5MSySGcpOM1tMj5LPW2XzdAaTTp5lqtZU6hSZ'
        b'HmmZarulsVLXqDNU1ZjspurMCVOV+aRT8HdqiU2ZC/KaKjPLBBOmyywFImmMzZqn0arkkywaLVSlM1oJ6TTSdk3WerMFam50tmGxZZbYLBq8R5dZbLba9JqqGvpi1Bls'
        b'jZoaY2YR5KDNwcxb4W+j3a24M1C5gPSOyOxyR0cgSiUvs1uhYaNb5+XxPlMSMtU6k6lRJVebLVB3nRlqMzVqaDs6R3s6+SR802gzVMvrzaZucZUGa2apzqjTQ1q2DnjR'
        b'eaTeSEeUwpkmn6QD2MEH9TYrGSWZ0u655ZPyFZkTlAUag9E9lY9RZObycGJzT3PGKTInaha6J0BQkVkC2xg6qXNPcMYpMrM1pnnOKYc5IkHPWSMx8wgMKwvttVABROXj'
        b'g0RJMo/MGj/9EJmbnVVI0nQ6ix6QBbyWTM+dWKocZ4a1cUw+3QsGUw3AGqnHMe05GnudTUnaAaxTqXK06Xj3mHdv8WTuPQaR0G0QCd0HkeBtEAn8IBK6BpHgPogEL4NI'
        b'8DWIBLfOJvgYRILvQSR2G0Ri90EkehtEIj+IxK5BJLoPItHLIBJ9DSLRrbOJPgaR6HsQSd0GkdR9EEneBpHEDyKpaxBJ7oNI8jKIJF+DSHLrbJKPQST5HkRyt0Ekdx9E'
        b'srdBJPODSO4aRLL7IJK9DCLZ1yCS3Tqb7GMQyR6D6NqIsJ8sBp1ew+PHSRY73qM3W2oBMavtBNWZ6BgAG+tAfnIG6iyAkAH7max1Fl1VTR3gaxPEAy62WXQ2kgPSK3Ua'
        b'SyVMFATHGwjLoFPy5C7LbiUEpRHYhszp+GCNBebNaqUNEKzH01ijodZgk0c6SK8iswymm+SrhERTNck3ER80Gg3VQKNscoNJXqoBuuhWoISuAUkppspc98q6yLiyDHoB'
        b'CCOSFPdIcJSHpOHdCyT4LpDgtUCiPNtit0Fy93I0Pcl3hUleK0z2XSCZFijQ8HSZzjnwJcCf0DibbqHN9QKYyPWa6J7V6srGL0S2DshxtVvE8MwygwlWg6w/bYckNUIU'
        b'Ib2ApT2CCZ5BQD8aqw2oncWgtxGo0WtqoP+QyaTVQGdMlQC2rhW3WfDBagCiXJPWUK+ST+Tph3sowSOU6BFK8ggle4RSPEKpHqE0j1C6Z+txnkHP3sR7difesz/xnh2K'
        b'T/bCpsgjpzhm1epgNBRdjJG3RAev5C3JyT75SnOhMi/pRd5bI3yXt3gPVsz3GB6S7os7+yWZE3y37MGnPUo2QJXesnmQgJRuJCClOwlI8UYCUngSkNKFjVPcSUCKFxKQ'
        b'4osEpLih+hQfJCDFNx1L7TaI1O6DSPU2iFR+EKldg0h1H0Sql0Gk+hpEqltnU30MItX3INK6DSKt+yDSvA0ijR9EWtcg0twHkeZlEGm+BpHm1tk0H4NI8z2I9G6DSO8+'
        b'iHRvg0jnB5HeNYh090GkexlEuq9BpLt1Nt3HINJ9DwIQZDdZIc6LsBDnVVqIc4gLcW5sSpyHwBDnTWKI8ykyxLnLBnG+hIY4j/E4ujjRoqvVWhsAy9QC3raajfXASWSW'
        b'TCjOUlJqZbNadHoggiZC87xGJ3iPTvQeneQ9Otl7dIr36FTv0Wneo9N9DCeOIPR5JnyzTm/TWeVFxUUlDgaOEHNrnQ7kYZ6Z7CLmbrFO8u0WNUlXiW8SSv8A21DNxzu4'
        b'BmcowSOUmFnsUK64Fe6mdonvHpXQPQrEHCMRijU2wpfKS+xQnaZWB2RUY7NbCVvLj0ZeqzHZgbzIq3U8mAI59KYGULgVMRDibtDSYj+b2Uv9XoiS97q7Z6Qqpq7ZkQPz'
        b'LXewvHQq9STdMcn8e4LbO5EJuzRVP7CZhcckFqJbtVDFOzlg5o9LiKmZhZxId4qsdUaDzTLQpcQL8VTnEbOxxU69JK/O4wQcK/4PJ+I4cbzkRTs9tj5FTh+sxLBkDbo8'
        b'OgYdEzKSFG5JHNr6P6jQ0yv8OwOyqqrMdpMNBIjOoGxYdV7w0NTpjHd78uo8ohD/oe94gINaYC6IylTOiz4AxQbAPZCF6GM7hYQJshATvW9uQsTUWp6nMdeYdPISs9EY'
        b'mwNIyaRUNxIVS1ewC81lTleXyfliRJVGEKjVYLXzESTNPcxvu0lE88ez+HxD2VOVJVU1RnwTlt8IbIl7MDNbZ9RVa8lA+FeH3qXrPcEhImU6Z4Ky/IQn1Dl2t1Nuk/N8'
        b'kUP669JTOeQ+yq0TiQ8yw/6yUcnAUQNtzmiADPTNYNKb5Up5lsXm7IojJtdESj4QSbIleMuW0C1bordsid2yJXnLltQtW7K3bMndsqV4y5bSLVuqt2yp3bKlecsGbEZR'
        b'SWk8RKj5hSHsro5GJnSLhIC8QAco06mMldtV8i5lLETysOzUjqrkhGV3Ct681rVrGeX50fmZE+2medQWV2epBhzVSPAKic+eKk9K5ymt3pmFaIW9xTvghk/yUmFmGZUI'
        b'yMAttRqS6AIRbykuUPFVLOFhxbwn8iD0kGLeE3mQekgx74k8iD2kmPdEHuQeUsx7Ig+CDynmPZEHyYcU855IiqU/rJj3RLrccQ9db++ptODDAcU3pMQ/FFR8pNKCDwUW'
        b'H6m04EPBxUcqLfhQgPGRSgs+FGR8pNKCDwUaH6m04EPBxkcqLfhQwPGRSnf8QyEHUkts+GbVPCBdC4D42ihvukBnsOoyJwKJ78J+gA41JqOGqBetczU1Fqi1Wgc5TDrC'
        b'F3XpGx2UkyC8LLueaMZcSM5JSyGJYN4ugiyPzDI18jwxOdIDZFxgsAFp1GmBA9HYHkh+AA93L9yFyR9MsxjxZauDTfBIyaEHPHobcCUuyYpSEiXld7yKAY6ROqg5kH6g'
        b'NISL1lP+uZYQeJvOANNic6mKc4HZtRn0hnkad+xfRiVBlwrZnc3g5Ue3o0R3NmmijhcudIZKkpQPq0bOxqw8Z+ObUXNXD0O/oWWN0V47T1fj1GVTIki5OGJHVWiJ8sXF'
        b'Esu7mz652D6SD+3UurkNnRluzS/E62IpJ4vXBuFWtR/Ts1IoSwnsxsjKnIysjfVkZDeLN0s3S7Xc5h6be/AMbZufv9g/QBvTJGoKbOqhF2ilWtkqf2BshTqRNlAbtIrR'
        b'BmtD2rgyMYRDaTiMhv0g3IOGw2lYAuGeNNyLhv0h3JuGI2g4AMJ9aLgvDUsh3I+G+9OwjPRAz2kHaAeukpQF0p72eODHXzuoLcBf4i/RKps4R4+FWrl2MO1xED+6zQGb'
        b'WT0ZoR99OksOafOHcipqNyeiXhwhUNpPO1Q7jJYO1sZCmqhJQn08wmjacO2IVf5lIRAbCj0bqY2EnoVCKz20ijanh0JQU7BepI3SRq+SQC1hVByoUcR1SsYTs+5xJdN+'
        b'iA2Qu/1zRst5XMJ7IHnkOCayDCGgMYwc5lPr7ljyRs01iEygkN0lljZ3qcEysbPpym5JdWa3EJsbSzzJQuwe7lLLAAIXCr/OAI22HtCTpdyg7fSvAiRhspHXIA0vwJQb'
        b'gcuz1XRKquywf0xVDZ0SYqJq0BgdNhlSvQEYu/Ja2Ls1tO1OwYSpU3ijD0s6PKokbsAY4PilBjsTmQccpfybxE0BTX76AIddkKRZspJZ7N/ov0hC7YL8qS2QZIl/ids7'
        b'79rxzSYYvMfMkX+5fFcNjTordQ5zzbeB2jVU6VTdinSLyADZQ1Mr75qmDIdbGOAXog1y+J055ktjsnWrgfyLzAa0YHMiJYVKnkXKAwKpklODQbm9Tg5oNFWuNVQbbNbu'
        b'/XJ0w7VC3nvBJ3vvgevM42f6kPxzffAEjQx5Pv1LujApNt+Z6uiY1XtfCNEh6B6IhUpeWgMEAHaATm61Vxp12moYzyPVwhuU8JIq1CTXQBUQ5vsvN5qBGFlU8lybvNYO'
        b'8kqlzmstGsfgK3W2BTpy5iuP1Or0GrvRpqBegWm+18KxJTLk4xxv8iqiNIx0HTW6KRsVvmpxbqcMJ7RaXYtJnBDNFnkkb7gyD9+0NIL07asih61UBhW1CFsC1fAw4sAu'
        b'kbpqlTw5Pi5Gnhof57Mat/2cIZ9IAnIaINXpDSbYNdBHeYNOAx2LMukWkHPP+hRVkio+StF9qh7BvljGuzm83BDKvNU3i2HqKmKujZzF2EcTWncb35bjlgJ0shg35+K2'
        b'HHRUHYvXFBND05x8BW6JKVSitbg9f3IOOpVTWFCQW8AyeAPaKzPPy6LVftkQyLyQDKiwuCJ/lbSesRN/FXw9Gy1zq7arTrwOr8kHsorWeFSKL46Gelc1yBh0Al2hFfsB'
        b'hc6pGswwFRWyZyYOZuwjScVX8eYyd/+sHJUyKg8aQKeFDL6xMGW22IrXNFAXM1rLP/v7MXX9+jKMvCL/mVnpjJ04xlqlM711Dh+eiZuh2pYY0sdWxTS3MaNrFik6PwVf'
        b'MAx5oYOzLoFaJvQ4NeCF5/2XxYVMeCV/yaZP/hgUk3VWoD7LpLKTU4dM27tTMS7zm3ThQMHHYc+hTaFo4/jc7NTH9704qFLyoqHl1t0h54qPzJ064OLqxqnfff/nvZLI'
        b'hYFfnL12YOWkb85+t3rP0cB5uCbsp4iXtbVL1O+da/jX53lXVPqkhp+YKk3kX19/VSGjniLZ4agNtcS6vEkETPBwvHOIQK+caSPUAm3A+0NRS1E+XuW+nCzTF68UNqJD'
        b'eKONaAHH982UqtEK1ArDLrA7LG17oiahpG82NQrHl9Ax+IWKJnosIcv0GiyUMnXUynIkXr8kWhmZo+SYibhZjDo4JdqLb/EVNOPtg6C8Solv9XUtWRg6LcAtaD9+ilYw'
        b'ZlBwtEqB1wKjhi9kiNFJLhGdQutpBRXoVh/UQnzFYP3b0DHHIomZsHoBupWrsRFyjQ6mRZFOOpg30kXHCjNMHF6NzyWKVSMHUccHtLY2G7KSOekRpSI5cRtujyY55VZR'
        b'4FDGRpSeU6EQcXwgnODVMLyGtKqENtE2AV4tXGAjjAA+PRwvJ62i9qIurpGwjH3RVSFqQXfwQd50MuBX+rF1+blQu1PSKLNUvEjMEnc1/knc1STUZQ1iODHEBrCNoU6C'
        b'/IC/TQBvckq2qmUseWSRRzZ5jGOcvjXjmYfbMEv4Ul2VZLtK0Uq8eOncZRwWoczygdu9GLd276+HnTPr+KWGpaRni5i5DNUIs4UKtlNa3sVEWCJcc+fmnTTKqKmt1Goe'
        b'C4VavuL9U93adKb+4EDrjtqcLEAkkAut0mwyNiiOsZ0CrbnqkTpXzXcuoNzFWnjrm4V44oZDeUsuvPwwiO8BX8RLBx6p5Rq+5eByT4bCZ/O9Xc0rHspy/OKOrOI74l/u'
        b'pOg+u9DX1YU+2RqrzsUC/Nqx+5e7uGlfTQ5wNTnUJ4Pw68YrKXc6svlqW97Vtk+m4tcNXFbuLjf4an9o14r/DCfioxcengfUd45rYly+c7/a78BZdTe/g2pJA0s9dbPO'
        b'/8Q7PtXoP2NeaX2x9T3Z07JdSuaxO9obwu9u3VVw1BHFT4oPObA3Rd1o/wQX9u5XznuanEZn0FY3osHj7nzGgb3x2okPc2jzKyfbys2ZiVnKLA0f2RjihspoBr5M7wdr'
        b'inAtyEx4jIDJtZIoZjmzPKjTC4rsVq8ioNPPsUF5836x1WbR6Wydkjqz1UYY5k5hlcHW0OnH52noFNdrqAwqrQK23VzLy6YCm6a6U2QGsLdUSd2WgWDxIOdSEIehJqlL'
        b'pgx0XRsQxF/ZoA9yrLy0WQYrL4OVl9KVl9HVli6Rlbi98yv/zdsiL5JlllZrBdGB8L9aXSXZhPC/ymEgJ9dRc/5HEC6p6EPlFo28xl6tcxPnYHasBhCH5LzTA5HMrDqb'
        b'Sl4EQN6tHoINasmhjKG2zmwhUqizWJXGBKINKQpikUVXZTM2yCsbSIFulWjqNQajhjRJJQFiXmlVkZEaiHoNtpqjSoc0RersVgdUbbcaTNW0R65q5FF04aIeYUYmOkZb'
        b'Q9Qh3fveLX+kTWOphja0TrREysuJwtBKJBPrfDuZ3UqLpmqezmZVZDy6wM/DbIY8y4O6yGfRI9I5voqRljPk1MVh1s86Ovishd8iGfIS+lc+y2F25zO/cytlyIm6E5aK'
        b'CqKz3M3ufJYlmw9EWHjKZxVZbL7z8dsTsvIvtI0YeW5JkTIxPiVFPouoOH2W5vc0CKdZpcrc8fJZjnPDOdGz3N04fDfehQqIuM0H5KQid+Nhn8UBecBk1sDWgO1qrbIY'
        b'6mwOYkbglHh1072VZbSaAX51Wq+aAgAnkpuQHiO9Bogutko+nlcX0C06pMSmqa0lHnCmIT4VB3QzAGBBB+ocW0troBcRaWBaFxiAxOkWwoo7Nlz3esi/QrNNx28Tuvl1'
        b'thqzFjBJtb0WAA36opkHGxA2jQ5mp0onNwOt91oPPySyaagexMoP02B165JKPhGQmhMhea3FfdsRrQmAOrlmqcoIA+ZvWLLqvJescFyyZK6iPedPVEbV2Gx11ozY2AUL'
        b'FvB3Yqi0ulityahbaK6N5dnOWE1dXawBFn+hqsZWaxwa66wiNj4uLjEhIT52fHxaXHxSUlxSWmJSfFxyamL6YxXlP6OjIFSwu0thWCG9yQJdwE/iZVaQVC/iPXlKVSHx'
        b'5osGWY9hhpWIaoaq7ITCTeuJNqJzZYnwGs/E46N4AxX1541w3LiTgit3jM9g7EQ7GoVO46fU+dH4sIO6T8bN5NqTPOUU4hI7JZI4mE4H4RT+gMAGFZ/xx1sScQc1aMH7'
        b'UXsFvgASbztqDQTOwI8R4R2cbDSkk1uS8LaBqBlfUKHleB+5fIOYv0Dt5FoVjhmEDgnx9TS7fSzpM2oF4fqCGjWhHbi1YCpeX5evcB9hMW4uhJKt6ql18CjKz8NbhNQZ'
        b'UooPogOD6LVQjXgXui5V4Y3ohCIP3UR7Ahj/PA7vwTvwNXr1E9qKl0/FVwLxhVyohGUEaBuLlkGpZjtVBhysyZDiZrQWH4tV4TXQcgw6lgcCdTPLyCeJhAsX06ulCtHy'
        b'kfhCLD6AN0WxDJfDpqALQ+kUH48W83cipQwdVt03mKEX6vjjY7XWQKUSb8GX+GYls7lJ8zX8DG3By/FhayDaAsPfEhiowhvwpXx8LhpvFDC9GwToJHpyIr2VSgGLv1Wq'
        b'ghpg+nLJtAiYnvgaWikXBkehG4aBeQmsdQcBmF2Byj8WBKC4ENE7qYZX7x+PPqT+/N0BwltobFbqlE9Vb89YlT6xecATJeVj9V9+iapGiKNPNlbMTxxS2hj514jgT6dc'
        b'/82KP42QNilf+WzVkUEvbSoxW54ZMihek3j2rqHQWvbyk1uTDvRUGgpe++jJ+vf/lLH6cvmfj7w5p/G1aV++lPnRt/bX/rPLVH2iPaHCOq/5L+O/fynz+Lt+wXui1n43'
        b'3nG9RyHqGIoOpTyolRHo8QW0jbKck3GbTe2ho+AinFqK6EQRbl86m2pleggLpOoHNDLoIj4ulOQUU+0OzO4Gi5O/RZfRXg/1BLnaiPaoD1qFz0cXKnNzC9QxuE3BMr3w'
        b'Tdhp64QJgybz9ztsm7ZUHVOUFZkD/YAFRCe4hjn4uMe1H0G/9iYen860ARqttpzn5Sj7PMLBPstyZKyE7cWSp/uPkFzDA38j2MYeLja4qw6eTQ/kFQ9ljNPKjVwNYplN'
        b'HnPI43HyKCePCvLQkEcl46Hq8O4VLOXr7KqkwtVEpauJQFeLGlc7lLvXkircufsRf/bC3XsblsK/U6Ylxn8OjqkzkOeDnUGxppb+JZen6Dr9Hee9VbpOKeFagFck1mB8'
        b'T1yDrQpwQ8lEMxPiRMlTCIsf4MHkBwGbH+xg9EMIo68PcbD5AZTNlwKbH0DZfCll7QOWSEvc3h1sfrvfw9l8jcuiT85frPQIzOwE4g7B55YDRYU5Az4VuASN+82ChJOI'
        b'kVdbzPY6SAUGWtOdQplrKw0mjZNniQJ2JooSW57WElWAy/6TdNAlHXeriUjL/08u+f+zXOK+1TLIQvExLiXYz8gnHnuTL89HOSvwyqTN+hmLUJ/N8Xufb8ex3R1xPJ9r'
        b'MhOljoVysibv/OkCM2EkDbUaow9OeNZDbGJBvvBuFeuzxwRL8f2tNJvnkf6SGJW8wAFdGhqWmyvnwsKD1O/9UNFE5KK0lLh4h56MAAIIdaS6WV32sj474UKSGfKpVrvG'
        b'aKQ7AwCn3myocu3GWW7mtg8VDR1I1nMZqCveLHeT3J8V3kjxBwQ4D8PP/wvkr2zdAl21w2zn/8lg/xfIYIkpcQlpaXGJiUmJyYkpKcnxXmUw8u/hgpnIq2Am5w+PA0LI'
        b'HXnF02VjK2QKezljJ8LX8BKBOrcAr43JRTfQfic/O9mbXLUU3fJPSserqRiDD+L1w0GqOjedCFZdUhXaDXJKMmSY1DtVrcorwGticr3VakbHugS2Ftzij46MQh1UzELH'
        b'A/FFa5H5sYIix0VIpP7peD0UaMfNIFwFgBQCdUL4WslstAt1oAP+DDoBokdhFDrLi1mTkq15uC0XtTxRUKQmtyfFCZmIbAFuzYi1y8kA1i1ptEbhbehgAV4XSTh3VS46'
        b'Fckyg6pFInRmEM00vB4dleIraN0UCW5Dp9ERZSFIWxwTlihA+9DhJP6a3TN5UTATXcfZIPhIjejSFHLjaDxqES3k8Ao74eGHs0W0UzCwK7g1N0ZBri8NxwcE+IbBStdo'
        b'yEAOFvCT7CCmwjir0MzYydkb2pIaLhUzU8YzpUzpLKGd6OjRAbQf3ZSSyYFZ3ICv5IC02YauF+JN+BIRQlvQCYjIx+tyiBA2u49kkhld469aPTkYJv8COUy9xOQyudX4'
        b'FhXJk9AuvAxgAp1bTGTyAnSSz34Vr+lPbmZF7UpyMytaZTF+f//+/SftRFSX5wSPrYi5OFPHH9W39iXCZUSEWF5hnD4xgbGT48XJsyPJ1LQ5RPecmGnkIDkAIvKmAjTk'
        b'4NaSSAXARI7rsmQFukxnT2wKnDMS3+DvfN2HLuMzJXhLQWBinoBh8UkGn0TnJfZMSNShg7VS3EaXZ0oXpEgemB//YjI96DTeKGRQ01T/mQ2o1a4kld/GJ3CzBV+xBjpF'
        b'4MmReEuJxFPYHdNTHFRtpnK4Oq6HNQ9tRueURQWxBHwKHfKuAm8XoYtGkOZJr2Wj0Uq1Opq/zVMhZqToDocv9GbpxcDh5YXcM2Jm4dkGrezNGYpZ4bxBB7qITkLHLzh0'
        b'HLzNBYAWXhNbVDCZXA68Lnsy1OZu24B3oyMyvH5qKr2RR4vOpUeHoQuq3BiQ/sWonYsFCN1Ol7mxAq+DDVE7HGREzsKmRXMKgZ1eSLkCbUcbowvwdrdi6Aju4C/5OeeP'
        b'mqEcuoo6HCUhezMtmRxhRTtjHxxkKN5heLJPociaBiLTf/0zes760YWCLNnqv/cxp+wsyPleff7Ht5YNPXh44v7DF5o350iUoX/Kx0mH3+EkBz/o9fXrdSP+qr+yf8d3'
        b'nzX8MKpq6L036yY8N+H8WxO3Di9sDYp+qUb5jfH912emHHom1jhT/k1Lyt37w8+sD/9qzqtDdwyemf3Ey2xSU9D0FwsGna6uPPDBp/Oi88PurH3utcAI0V+OZq6Tjx7b'
        b'abh2+IfCpqOTpI0ho2sGvKr6cprt5vvPZvj/mG+/OOqLlNeeW/fNWS63/Qsk+WH+J8/ufOrcU9vnHX+mYveK5NN/M8rGrN42deCAP+rHiPR3/I6MGvl10MAx9v96y2/B'
        b'5weCB65hD1+78lNK30UTJseV227vmX3qwg/zSj6d+d2gV75a+5t/m0b/lPD2jZbjb7xXdO8V5blBMzc+vuT75seff7z4+bcrgzP1U64fqvyXX1iRKffAHUUg1SKUzMGb'
        b'PZURE/F+oo9YjLfZCBIayeAWdT7eGujNaoLqI6rwSlpV9bRih0IiG61xtxJB58fQDHgXPo13qd2McpLRyeBpAqMIXeAvGL2C9puio0rREYedh/9MDh2authGrAJmsuh2'
        b'9ONGFcHuMQSI1nHKof1sBJOo8Ob+6nz01OgoMcPNYVMbcDt/xdsZ3D4LncjHW9DqghhAgGoWnTfgm9Q4Bp/EqwD0W3qGukw7xIu4kXgbvkqtRfAuFfSnpQidgj3cEuPF'
        b'CgQ28AqqaTHB21F6SIi2TfFi46HIouYiuCV6uBWqO41X5hQqCbmiEx6K1wvQ2bIEqmuJxFdD1DGFeI+7siWz50Pu1VKE/A+pXrwpYYKIpqFL+KaKmGmEIVhKVTEcr4bp'
        b'UsYE0MvOhFQRQ0ISLogdCKnhEEdMT0i+EJqL5JBxAbQkt4y8hbGNvT00HF3t8sobGa9A0ZGHnjyqyYPc4WgxkMdcl1LFm97G71HuVw7g69S7Kta5aprraifQ1USXBscI'
        b'jzJ3DU7UYS8aHF/jqxK58VrkyNzzDnZRk18TQw9R2aYAqneRNgldd7CLmsUrmcXiRv9FIqpnEVPdimiJuMTt3dt3CkhD3e9gD+KZuk2jCMNQNyGQqZBhw1imlMb+LoHQ'
        b'5ppM/7EV+TFZJv6m9lB0c7YVtUn81fMFjCAI8PfWwVRjPyxLUoLaSnHb1ILJ+FIxvjQ1MCUujmESFg7oLUDLo3VUjx6Ibo8twW2laEVachxemwT8lGQ+i/c+hm5TAqGy'
        b'BDtrYRlRFOs3FPiyE7MpzUFPTkoi16zHo2vkmnW0tjd/d/yRfrC9D+BDADcjmISpESloJ60L71fhA2pVXFJCMseIl7ApqAU9ZdZR/Xg/vD2Xv9U8v1BkHOG41RxtQpcM'
        b'RU+8LbJ+BnkkX8TUtmflCeNDJpzYWJhxd/KkrPHB7xSMWn56zsy0l4euFahWNTX/4Xf1k9+8nWVhPq8ZPrq1WfXPex9//GWuvz5y/diM+aumy+N2vH1tVWiP4x3aZ4f9'
        b'u3/E3P1lPXK2tn194G30j44Nnw0f9hZw0HPLLtnb/vHOj09/82nMuKAPAgrThj79+YHAc3eLc/85+9bipN7Fhm9O9Hnj9qjmLXuV/3l1/3ObRnw0csO+Vyb9/e9txp2f'
        b'XzxrGDNmc9pP/266/0flQZPguXPPj3zv2s6z8uxbk5+995/6I4cOvWd657ERf/vLs0s05XciP0q+99d/tYrLelr9vvyq36epFQe2H1aEUYyUig/hI/RjAn4Mh/az+OzA'
        b'qY1oD00D1r5tCiDYgml4hRO/xqFWeofncEQQbIsbcp2BbgJ+XV1P1dxoP1lyamLXHbXOiQzER3rwt9GvnorXEwqFDz+oMX+KJ2GJ6MpwNfBnN2KBzWuPRceFTBC6LShH'
        b'63ELpRxL4tEGIGK4tQ4fKRAxwoEs2l8ex9d+EHjTU133bQvGoBv8Zdo78FqaYwa6rIlWKdAWdNx1oz1/m/0GfJCakSSMNqg9zSd7oVNCtA2t7ofPzeTtGzea0Qm1u20k'
        b'lN4EOcPmCtBJfRCltHhNmlGdXxiBz/uitOh8f9on2F+EchFjx9g8l6lj8EDB41q8nF6UORDtxU8CpU0WuWgtIbTj/OjSQPMX8SZ1jBuNGY6vNaDdFZRsmiXoGn/1/tA6'
        b'/vJ9Fp3D7YG05nE2IOHut4tz+ErBwqXoNJ3qgHTy6QAYaRG5Ihyt5zImmM2qR8O9/63L/J32NvzV/ZROHXTRKUlsEMHEFBuTy8YJjeLIz30hx/0kEXD/kQi5HyUi7t8y'
        b'MfcD58f9i5Nw33P+3HdcAPetUMp9I5RxX4cEcl8Jg7h/hgRzX4aEcF9wodznwjDuH+Ie3N/F4dxn4p7cPUkv7lOuN3eXi+A+4fpwH3N9uY+4ftyHXH/uA24A9z43kHuP'
        b'GyR+Vzg4iOsFjYQQqudmtcN3nyd3fl2EptOP12NbO0VWm8Zi6xRAvl9K20QW8nEci8lFwswuOkZJGLlh9hQhYX0dJIxZLn/14UZGfHf/F4y+ahSCHz7sppLg/btsTn8S'
        b'h2rX6NC4WHQ2u8VE02rlGnJy4KbAeSStu3yersEK9dRZdFZiWslrhhyqLqtL3e9QE3nTlj94EmDk9WukO5UNNp0XTZYHRRa7T56bjT69wbk3XlWBWvBWfBbfQO1oDezJ'
        b'jej8dHQenUMnJqNmEROBlgmeQCvRKkob++B2I94ES6ti8KlhqvH4OiXK/WLRU9YwdBQI9nzUMl2Jt6pVKgETjtYI0DHUjDZRQj+pr2DYepa8VeSXywYz/HltOz4YbOUL'
        b'zlBPV4qH4C2V6BY+iPcnMFHJojTUjm9S6XQJEYajQdwD1nuPS+S7M4RKdbhZifa6kfQJ6GIUizrSS+kBM24OxMvRVZua4iYiDgZDzynxvlKBNpTQQrPxcSBGbWz/dHTQ'
        b'kNxyUWBdSaiz4W7BC4OD0NiQ1e9+p69X3GIODsQD1r/FSE1TXs34sfXMe7Ib/n66cdPeWfLVUinXb3r4tNlfpv11eMT5fc2vPDMz+fXXv1n2ctuE3aqp/U/3vvlk/eEl'
        b'T725Y8gT5z88lDS45l9/+8J4w3/4m8VvNN6/d87yj390vrVDOmrp9/o/F63r97uPe6s+Gb6ux0iFmLL6IMIG4lNR7taFXSevO0bzxHPTiAn8lcRDcauSv5MY7ZvEp21B'
        b'x8jq4iPRqgIOhnqUVffAlyj2LgPCcB21jE+MzaPf9OAYqY7De3sDCqaLtD4O7QM42Y9PP2C16LRZvIa28WTkdH/c4f6lFkLXYOHOmPHJuQrxz6ATHxaPGms52XYUAw9x'
        b'YWChMUxAjM/D2DABwb0y+iP+T4RIyLkhFEfhn7WGtMDjA09UFbTzoajKUfMxtlNYp7HV+L7H/THGcUM2OdIk33oQu+5yFz7SXe7VCsG7AtbLcWYX9iKIxKqpJ29Gozse'
        b'e3SPODKIDHmuXh5F3qLkgIitvOKcYCjdQuJ1S/TIUapGQ11UDG3IgSot3tXQVnK5oNal/NZYqmoM9TqVvIjo6hcYrDoXOqR10AHQ7Bq53mwEMvAzuI0snH833CbhcRs6'
        b'i7ejS9E5sFGKc4CbySvIR8dKAyJz0CncHKMCTiMHP+lXh1bgDfR7CPXz1GrYVnkFKrwGOL5S3Ays0NDek4GhUUaSm2XU+LIf2rp0EUU4c3ToKt6ETpBPDZXHAI0ysmgF'
        b'bLEW+qUmfz3aEg3rb8CXFjIL0X4NL0I8CfvkYnQRx7CWJ6YwuGMCumPYHTREYL0CqcdmWEcXxAdwWbL88080Lmj89r++XRF79tz5s+dCsm78Nnt8WtHZN2rfGrG7/Nmf'
        b'Xv8sIEG4cccLsp3RkvMF39fs+SDuvX7p1sN11pTKpTuPl76ed1zI/uUPkctbd0+2v9jxbsy4JHZ0zu4Kwcffjl++4svItpHmsMFfq291CiVB3xZ3jEhf+pe5ryWZJUvv'
        b'v/dxddTSAbOK1szuefc10b1TLySV3A/u0PV8Rf5Wg/leT9mVbef7TNq9ZNvOjud7vyhKC39dpgjmsctldBpdgNmOwOcIcylMZdHp/ME8R3wE7wQE04Iu4Y6YQv4TcIwE'
        b't3CL0fF0ym8Pwxvi8QV8cYFDx+OPjuCNMRw6UIyuUSYwKByfIezwcC0sEYhZhVx/tCaK/zjUMbxVQj50F6PKpYlSoGZXUQeHbw5Feyl6ixAY1TFoXRH/DQPpWHzWjwPg'
        b'WIdu077PRB2kV2ti8Tm0rUhJpDguyhhOi8oNgwnVUKhwewwZVzBuMcUJqvHOBl69dBWfz6EYd4MO4MSBcZdZ+XG3T8A7omPJgYVSpeCYYHQJLcN7BGh1ArpBWxbilegG'
        b'ZeJD0PHYQhEjHsX1rpnLX0x/MLdSDTTUCa3+4Rwg4WvoMp2QpDhEzhvaCqeM42ckm4uY1otnxfegrTAplNuudH7rCtjt4D60JH5qVDnpFGp7jHx0R4yOcjHJWQ/TBv0M'
        b'2nZD1UKygymejnHhaWapzJ/ocyTUXUjGhtAn0c6EUC1P//vcMuH9xkAXXiV18HfZOz5uYGM8tC6+e3qM4/N23W9fD4/7BKv3d2F1Znmv+94+d+DRvsLhpj2BIQ7+Lt9n'
        b'wC2OfwoR/4eD3x4PXHZFbPS15qrycuqD1Cmps5jrdBZbw6P4PxGjfGq7Q9U/lIGmpImOhGfiw//HlXMPXVRLEjzeZxwf7yK3GAQIQeK5z8Hshd/nhouB9sIcCn7Z3yCh'
        b'TBDgqKXXfVlsCHkX9L/fd3JQqqRfX5Y3h7ys8QfmYaOVfF7SGhQkYAIHcHgfehLf5s03dwPSuCxFR20EqUjJkUwxOYrpn5DRVzgUdUT+L3x3qdtnB51VexIhv0JemXQO'
        b'H19chc4Sr5nBzOAR6AjlZWfjLXibWoXOxiVD4RKQ8S+z88egQ3TUWnTB8Sk8dAUd6/oY3mR8mpKeOHwqDLcAH7xmWBFuTRSCUNzC5QXg84ZnevxbYCUgu+UPM+5VzP7N'
        b'2fX7NsWvns9W+b3PHV4tk/bJzIr5KPxw+EerN4zKr0hRB0hnbN6Xc3pl/Op9K/dtyd3IDutBv+ZU4xf6WOkrChHFFxPwSrPTSVJciNcTJ8nUfIppwkFMuO38ot58vNyB'
        b'aNDleRSDidF6vDbapV0fATz4Ok6J1g+mqXq8OYsX7GfiQ07Z3jwYWE6CGcvQ3v7ksHfdQrSLJs7hdOipKQ/zjJGBjAWcjK6cmD5QJNTLDQlJhgVx5LsZQkA5QqC/ru0k'
        b'7BSSAp1ih7dat+89kXvoLItc24GUHMw9gFKC3vbyrTw5AYCVmcCEROYpc2LyUFssf2wrx1uj8Q5ROL4xqhsohTj+WjM4t+s9RpGLLQBWOa1glX+ZQCekn8hjyMfx2rgy'
        b'EYQlNOxPw2IIB9CwlIb9ICyj4UAalkA4iIaDadgfwiE0HErDAdCaH7QWpu1BPq+nHQ37hNX21PaCtmWOtN7aCHKVh/YxmtZX2w/SgkgIeFzimSPU9tcOgLhg7RiIE0KJ'
        b'QVo5uXBjc8BmbrNAL9gs3CwiP9o+eg7iyF+B6y8fyz+FfA63p/DBd+3gXcEGRjtks2gTqx26OQCew5x1wftwPi+8jXC9jXS9RWoV8IxyhaNdbzGuN6XrTeV6i3W9xbne'
        b'4l1vCa63ROeb+xi0Sbu4Q6w2eRdXFqoL04VqU/owe3vsY1ayNJTqDNEc4dQ0kvd9ksDc+mnTtOkw+z2p0aQfnW+RNkObCXG9tH2oR+DYTv9yIGmaicBdU/f0bgcCnvIJ'
        b'b34pph9SFLuOAUSPdAzwiB8eC+CPAcZR2w4m8g/qipgPEsfxh/FHh7QyESwTGTq9QrW6YQAf+bdpi9jvOSbOMkoza0BRNmMnl5/U44Oow8MlP78QbdW4SaWAjVr8mJJq'
        b'SQi6U0kr+lfDUAbI64zBgRXZV6bMZz52dvIr8jA83fqS0EpOZD4sXjKg9enAZXEywe6kQ2fZnLfXst+P/+KTM3Fszyl/6dj80m7lzJSENyqGP/905b01o/a9Il055en0'
        b'G9dyXvxHcfaLvU8kXX/unXsVJ1/+/otXd9ZU/5j+yTv5Het+yoialv9vv03KPpLg9xT+/DHizll4DcjN56zk40JKASMp5Wz4lpbn0LbhazNQCzqTT04YxSO5xJzQuFLK'
        b'KI9B62ZIccuiB620hZI5Ohu5sABdRO14l5t3YQle6TYpw/uIavBZdJL3SL+CDxRAO4dnEPwdHankM0K23v2Fo2YDj0ow2Hy8Ae2iH0FiM3KB6SRa9VZyxLhTgPbhg3GU'
        b'CU/CK/1ongQDzVOATjKQZYsAHQhATzm6vox8pBlvHBsLrHYubmVBBljLoVW98AEbuUJJhU+FopYFMB+UnNegPVAVai8C8rKmCK9TiZl0tRhtRdsdiPuR2dIuR/aBbgRB'
        b'nBDASkQR1KHdqcslHwV07ZoHfNh53WmniFpOdQqJ4W2nrOu8zWTu9DeY6uw2epFYF7fqbtEushCVkmU5eaxinIzqCo9+xj5IWnq95O07ct17+Us810XlpPs+3XSzIEjd'
        b'dN3bcXmr9++6C7Wbs67Koiao5hd0JbDcfQ59dmm8s0s/DHRrvrujuuqX+ch3rZivhie5Gh6Q68zstPz8xe3qnV7iBIjKaw2+PbXzXM32IoKJXG8x1/7y9mo829Ms9Nle'
        b'gau9cNoesQv+lbMqLreZbRqjz6aKXU31KSUZnfbDPtv7n9H/dzurJv84pvsHEflrZpTkrJqRzBJWyAYxcp4e/X0UdUeKzBxWETNfUsQYNkXs56xEefT6xy+RL/fmaDZr'
        b'I/VFGpn+k4pPmH/u7FOy/Zk+K/qkzXr5AlMxVsyMLlOwNiIaow0zCVLlkd2tCVQn4g3Z4e3o/EN4Xiouuj4X6MRsAdPIx28bQ91xxKO7hJd0421PeLs5o1vld+/Dv/+v'
        b'PnTbXeByrNvXYULKQr9Tst44o3iYmE6M3/Onqpj6lwjUsgfuGTo6hwms5Ovrn9qCYNVWrK/8pGK9dsZvtqPt6OL6Y4IXrmic35mce1u8cmCJgrNRjeKaofi2G4XyXDF8'
        b'+3EnheoQUyI/L4TqaNZEoQOLlSpyYrGCS0Rryh8mxASXU3NoQ6OuvNJorprn+u6fc3H7z27s4zb3nrk9Pl8rona83eWZTYyHimQjPGZ0W3Nvpia+2/XYrs5lJ3Dm/Jyt'
        b'ABZe8AsXvtuGZRnvR1l04Z8Y8B37WTQnZIorxuwar2V4e9C9qAMdRCcgswxtb2QaFzbQeHwNbZ+ATnDkQqroJ5gnNKjJTgy0QtEZtNmDt8yNQeu1uaWRhUqWSUJrxEH4'
        b'RiQ1Kd3dG4TS/iEsM7Yi/6/yHgw1kszr6TCSzG1b+l8RaaZFjJ1MwEK8ocx5AZSHoSQBnaFoO0CPx91P+/COANyxpNqyDApTnYA/CNHLcQvayRG5v0vqb0TbDDOvf8tZ'
        b'n4RMY9KODX/xViiKCxdU3H2j8Fmu7rlepeHFSPi67QyauiTvtWHhA/Ffw3farm+6XfLMgDO/92OtmXna30w8dOWreHnWcOtAznTp9YWJgdI/mWb36fOh8tMfzr/9W/8/'
        b'5f+5M/xvC3f8seWVb+9s1SY2z9342riPnvpT+tcfpiZ36h6vqMORa0de/zzY/s7g/ft+VPAGAWhVQKqn5rQ4KE5QPQ6fprrRdHQGd7g5G04sdpn27Q+xEZQ6KErvc6+h'
        b'ZrNzr+0ZSO3lxkeiVdKpeEOUQwhwMceD0AUhPoMvD6GVJmeg69RCBLc2oIt0kdFJEMydNYuZOHRc3N+WR1UUEaPwHjXaE+du1dCAV+BrNDUrCp9T4zNDPYwTzKgpVeH6'
        b'erhPRam4fIHF4PjSq9xtd0vKhSzHDgSmtK/DAE4Gb8JvG0Pc9h4t6vmlao2l2uqD6eQsWzw3/GZ4zH5ww4fs93bW9WCjhVVCt/3ocbTs+Fgx9eFzfaxYSA+4RLDVhXSr'
        b'i+j2Fi4Rlbi9+1KqibptdXEhPV1JWIyPok0CpiqGGQTruyyKyrdUsVYDO/5qNF67cLJympKYqPiFcgPRZo3hP7M/EFrJjZkj8GWiGluP/vL0W0+fXX9t07WV17ZnrlZs'
        b'H7z62spjK9PbcrWTWwdvX54YyJxQS4qH5wLFpr7Mu/DhOaiFanAQgAo1V2GZfjVCAIgNqFlpcq7Iw1Xk4nLq1kFXPsRt5YOMQqqb8ph0mpXXhYvdbATpF6epWsoTuR8T'
        b'8rEP5KSrvhUehgdX3euHf7t1wPeij2WoKSHTJKZ6CLL0fr9w6R/xLh5RIb/I9KxpP15ZXkIWeCs7soER4BtsQSVaZmjKfoazEqX60g9336tQayJ1kZVqnheruFdh0Ed9'
        b'9HnF3Yp5+s+09yq4tXEpifbzd68firOfrT97KH5NPPluOcvMvyj74HeBXXzrIxnCeHxwnGgT3RY53H17W3hLIWKj2tjTbZ67yvBVbfMNSttdS0qc080PLmlEu5cl9d7U'
        b'XXLO4HtxR/E7WuTY06L/iYXtvqedC0t2b8U0vBnWFW9JzBGU41ZG5MeiFfX4kGHP3TdYK3EB6qnsvFeR61zZqgJ9jubTCpXmk4rPYH0/qwjR1Ojzq8KqgHnLFzBHNvh9'
        b'ff1V2L9kCfxycJMarV+U7zDoxhfQlUf/vnBnULnjalW3lXXnuSWNQuImHuE20R4FnCoLz63ZKdZrqmxmiw/ULbTs8rWdd8JjwYNrH97kZe19dkkRzNsjd5knE8vkzsAu'
        b'eXyerqEzsN5sr6rRWWiReM9gQqe0ilxUoyMfio13DyR0SrQGK3/DDLFy7hTVa2zkRmKd3QZSKLk5l2zUTpluYVWNhtzrSqLKaE5iGRXfGeC8IcagdXOmn0Vz2Aw2o04h'
        b'oUdyFkJ4LMSvxttNyYWdEvKNEVJlp5S8OZ3YaTS9rIq2l2A5QGr2I76UleaF1N++U1RXYzbpOgV6zcJOka6WfCeX6xQaoGSnoNJQBQG/rHHjiqYWlnYKxxVNmWC5QJq9'
        b'yDygACFLSdaX8HEUPTluRxZTE2y2SaKX/HdFIoGjes+tVcVzxnsfX8x+P/F7honT9NstXsjY6ae10Sm834ovBwM4FYo5fJiNCsbr+a/q3BqGN1lt9ZCIL0lZBp+b74c7'
        b'uKBAvMJOJhttw+vqookJ6KnIHGCn1heocgsm4+ZCdCoGt8fmTc6JyYsFLhc4MadvFN40SzYuaiLlvVPJ1SV40+ReZI4amQK8MZoelWUXDExMSpweJ2TYkQzahDcPpNH4'
        b'TklGIgA6OiFKZBJRC2qm/Ucb0Sp8KDEJn6+K4xg2kkGbw4GJJ3yZX+UU12UX0Ptr+Ky0jMOnU4bS+vwf00Opg2VxYoZVMGhLSgq11FbgM0DhW9TDiHazIJl87P0cizeh'
        b'PQI6h1vF0Uzp2FcYJqSCe3Y6sPXErEw6E9+Auq7ivXEgWEYxwI3e1lCPvnGF/mqVUkV8BguUeG2+GR9lmd7ooHDsmAxaX9JMOTM2p1HE1FUserfMxksr/eaizYlJEdFx'
        b'AoaNYdB2OzrD+y+eRQcio3FzrGpcbS7PagajNkEltNdMa4sL7cXEhMwll86O2hwdy9emwUfCEpNypXF+DKtk0I4l6Diducel4cCv0m8lodsjhTEsul6MNtJ66seMYRaF'
        b'vydg4ios9f3KGTphKebSxKQFFnQWBDAVgzrG5VMinPAYiE4qtKZUkVcAspF/PAfSc7uS1rMuKI/ZnF8uhtmKUqjTeKq9FB3NTkxCm9BJdBbWOJZBO/ENfID2CW8aNQrY'
        b'9pBikBSoTcKT3FAugdb1fTAw1uEwUyBnrUxdwI/Nhq5nwszD4jF0qrYM0/OnbUeA/zukzqN3th7Bh4j3GLFCC0KrBI/hQ0W0xraqNKaubj/LVFRYfjOhlN8P6IhSCr27'
        b'ivelcHSc2/AJfJyeMscNxwf5KgvzC9H1eidk9UWbhWgt3mbhbQyXx+Pr0KdjASliOrrtFnTFAVrna/jy46sL+eULqhOkzcVnaHdq03sww/prYNdW9H9puI6fdEXChMSE'
        b'1CcIkMLwtlbgU7zb26lwtBWgdKSeACkHQHqexZvxzmnUvkg/Fi1LTJajM3EwKwnkcp79LB2cGK8QRqtn4o3EaJBlxAauD3DN/MyfgvW4k5iKLheTUmnQ78H4SdrvGWgf'
        b'2kLBLhevRWdI5g2yUYIQGz9gtHE62p2YGoTXkg2YAZCBLk2gBWErtZaq+WlSENv5Uf1kIYKeaLWGDvjucH8AjBc4mH/j23nD+L0EYveeGYmpMIIkhta2oz/ezvtSrpku'
        b'h14MxsQJt10N0FHF9UP7AnmTqna8KiIxdfbAJACpTOgDfmoxTUCrYPjr1eqKx8hJBGdmx07pzS/0enRtNoz3WHUSdHsUQCHag6/SlvBJETERHYb3F8BqtcJE9eD8cdNE'
        b'2usXQxqZr3PsBKbrv8sp5d1UBvYegC7E4U0FSSKGzWbQnnx0my7UUnQrFESEPHJSgrfCE99m0c56fJDWFVQ9kWlN+y0L+3Xuj9oMHgKX4GWATC/EoZsjkgABjCPKizuD'
        b'+FF2zIpTg4R6Gx/LB+7lcTZW249WlDq1DxNXfEgAU7no6hNSfqMBQBwcrM4lxj1m3CEUsjDAFegohauaDLySGvAWlakYFTDS7XZy9IJ2oxuTiNNFzJQckIOVxOn12FDc'
        b'EgtovSAGcA7DTArz66fFlyhCisfHURMRnndJeE9ZcpSznUNbqvDhrquw5UMEjHD8TTGx950b5sBxI1E7Xoc3QSS63jOGiUE3yuyEZKPj6M5EF9pOcR7kAU0RMsPRcZEd'
        b'XQjk1+/KZHwRt0yOmUY8e4SMMIydM1FABz4MrQCJvBS3BeE2AAe8AzCnFB2jm1iDTxOLC+rkXW3O7aIPw4tEBnwFb+I38YqpMM07pQzTJwTdJp62h9Ea6kI7f74tGuaj'
        b'gPooox3KPF4AjBcyI0pFCYChV9Ixd87rxyRFQrdCKhYxwSU8lKSjA+gg3gmM9eP4KrrDoDtiP4quZkbMd1aKLohcdXLMiKmixAR8lN+h16HwFvVkdJjY+1JX4ltjZ9Kk'
        b'VLwfnysB2tsmgu24lHuC7Y92pfOwfAFfQ5fVU9H6ZH4yDjH4ogZvpoPJQJenq3MD8UnqTN81F4NQixBfxi1oH52N+ejkVLwTuM9YvBHdZNBNtBv2JD05bEMr0SmyxVW5'
        b'xIH7Nr4VnatMEDL9UIfQOAxfoWstaMBNeCfAgx3tQbeAr5Co6c1bAI83JroKj0a0LAdldwprUYee379rJRjoMQVntM3AGNDKgTwxPIe3EefeNTGFNVOdHQ/uIZiLNkVR'
        b'EM9AeyqJdoBZiA8T9cD6ubTLSnxMSpEZhSx0frHDFqM/uiTEawXoMo+GzuHzSrxTREwSb6IbDLqBb8t4leENdESBW4ATqUuax8xDzXgDRXZjFknVSmUuOhmZR3YcLPDt'
        b'HmMFeHPsPLpEHD6Dn8I7ZdRtew+6yKCLNrSR8lnK3CriuApYdqW7Qw0CBoSCcyA+nWYNBEK0LBAwFexBfAqm5DaFs//MkjLhkZGEH8kfT2zpiV6kGC1X4RYYeTjeZWbM'
        b'w4T8Wl3DWwTAq6H983MI9Laqi5S0q/J+Qnx2NLpCNZevDRjGvgxF5X4x9W+nfSgwOKrEdzKo+hRvYBuZxsgwQ2PpNKH1O+Ddfv+HbXNenWl+bWyI3xdvXHp/WO2mq/tW'
        b'Xe+/763v/pS9fOvW7Fn/uPDW9IXfq7ds3Bb5hwNfZa+6WHR00NP/PvV930XMsN+9f0r3Zcjwr776bOH5xBGfhJUWBf/h5f8E3AwN3KIY3vnqjB177/02/JWYttKT4r/v'
        b'Cx506GB49ImyH39sWuvf8dJPKVlhXxxpZXQnPpz+25qS7OT3Ro3s0b9o4irFvdzZ739XWnwlIHDkvmeT1K8999iGPlv/U1g2xG+Gfvf4IdYYv939w9JfsDyTO+uDmn3/'
        b'vPls/Nb3Cwubd2nfuPfF5mfvZjdVj/9jr0939Uh/yfL0cxM2qFdnbJtwOvyD488mbxWNbBny55mmtJlh156zPN9YPzG0Zmfr768szBxSMvDe04PG/W7bE3p2379KJm0u'
        b'PWf804z7+1+fHvlE5+53DIXf3nz6b++GT3v1jfmz35y68viJ309uTzv9+W939521W6d66eh3i9a92TDx7S9Ov1OY8f7kjPeZE7lr7vQ797uO0lm/+efpT2PfM51skL56'
        b'/4Kp579H/CP3b/fuvtGr+tsrZ9f+u7Lfjvm7Q3Za9C2fv7P8rbzmpiHtCU+/f3Kbtm/Rq7uXBjxTcuyLk8XvXvvgzrMf93/v0LMnZvddqDxfe6Eg8MuJ713513+tXvjd'
        b'30YkffH4B+OWfHTgmT1fvDF30fz08t/e/vJY0Hc/LB75gfHQ1dg911+cEbvhcGHi7rn2jwd99sIPQ/xqFT1skVQIQKfRDaedATqELnhaXxBDA3QO7eRvezuPOqZFAy7H'
        b'K4FV5FAHW4AvonPU2GFwAj4MnBXIDsT164pwPItu1RVTHXFj4xTUElwns0DmNkFdcH2gv5gJB5bcPA2tozYFgUDBjgOKj8lxqnttMaH4ugCdWtJAtdCz5zc67dOAEK/H'
        b'G3kDtbN4Le+wvVYOw2iJxVul1EyXmCUf4FBLP/QUPcGZLE4h7tpXFzrVfZICTos2xtt68oh5De5QFyWgq2RU9WwWviPjLXCPASPSDtzxrXp31/IadJ0OWYDWTafElmMm'
        b'z6MOjrgV7eftQnYPQVeJ6Qe+aHJaf4ROw7upJYYFEva5X9CHDuEtDq05voM7qFHHYkBZO6kphpuxxnB0xmGv0TKN2mugDfjkwK5c1FzD0MgbbPSQUVU5asF30GryBQRy'
        b'ZKHEHTkgyBAjasdURKeLyA2AaC/9JgG6grYVu6lHTwGt6FKRArbcg67SKU+YjFYRBxG0N9LD9xGd0vHnBqslWVDPeHTJ00pEI/X2RYBfbM3aKdBoee3NQoZxaW+YpWGq'
        b'XqyQDaOe5sRvnHjRuX64MLbbD8RJPg0CrMlfEBhAf4nKvi8nZ4NoOrF0JnlDSHkuhA2Hd46VfBbWqzGwSykD/XHX5VuI/u2X+uFxfKkuHf8leBznnBYvy50/fV/zZvns'
        b'0RffJ+9UH8h/GYtpErn0gSxVWvyKS9dJQ3LmQaXFSF5p8ZcwjkmKJnbRFbL8YUMYXklI6Pu8UqDMhIUdWINWMwN7oOU8w7AT6OwJRA43+6BNOqYPPjyUZ5434tX4ZCI0'
        b'kAAC8womoZeDC18xzp8pnjKCfPAl5nH/RoYe61me8GeaF/JfgWmRzuA52SLFYnZh3+9ERIMymRnsOFvcFipJTCKkccsstIWpwpt4BUM42liZmAQMbtkitI3RoS2RtI53'
        b's8XM98mDiIwu+9EayFf8+eMhjDxtHPlGTr5l6Ry+CyfiQpg0oiiCyKWDU/mcNf6BzLKYOPLZG+Pvo1L5nJdmBzL9FyfTb+HsDYngc04IkDKlUVGENYgJlU3lcyqTpEyz'
        b'IIZEyr7oFctH/mmuH3PQHEG6FPN0XT/+pBHdnIv3laBb+BLhK6cS/ltUz4JkciabDk8pCk4c3iuOqGmGES3MiTjaalrDUEZmWUPWa0jigLH8UuEnpYD6CfvQmAjcA2qL'
        b'pzM3swDfxDsDiNMI3m6C56JyulIDdID3dhLR4MpAvJyYp22IpAmPoeWAhzYBwChRkx5Yub3oFi9KpomY8T0AGY+tiEmVC/gRVKHrLN6Et+AtQJRa8BYQzfCTDOCTq735'
        b'hetAh8WI1DYA+NoVzAAVX250NAacxeJjnkeswIBt5hnxi6QbJcrR9GCJBY4oTI420YGO06DlxN9nITplBr5zL1pNo0fgO3Z0Al4a8MGJTMMivIxGT5ktoGfPTwA7dx6e'
        b'TUZ60EvX5GCKiPk/zV0JWFPH2j45CSGQAGFxQ9CIiIRVAVFRURBRDJvigisEEiAatiyKS6so4oIKKmhFRG3RiiIi7ivtTL3dvLdX29vW2MW216pdrLW2eltb/5k5JyGB'
        b'BLG9//P/5GFyzsk5s51Zvm/me7/33yHuuESJL09IYRaZG65m4J7DuRpLcY5cVX2vu8XRYt+e8R6P8rckJcMh4jVjFl3zS1pxLTLB4dbpW72LNtRTDxsmN46b4pv+ekDs'
        b'Ow6ZC/s7zBjj7P5qg2tW9nu/fbdzyS/TpjVuHTdqVklV3ymNiXkfVs2Ofb303Tjl5kVXw8ui3zif+O2cMSWjpjfdvL1QFKAq/Nm1euoygWjW99oPq47H529/h3/lb1f8'
        b'7L/+4OTkLM+w3YvyMqUfge9SPlq2uXxp2dl9Tzhfbmi9Vem1yeVJI9zjeiu0qe8O97IPBz3K9hHP6TFnf+v9g1tO9IhueWtsMd2r8ecDrdKnta+pvv92Rfmgf1Spd5Q/'
        b'FN0u3+j7Ymn9atGwLa665e/XJ5QJ52fnOKTEeWScudJWPH3hQPfityqKPj2ysqb5hZ/u7trd707z9Y/algU8pIcv8msquHz4Y8GK37iPHrx471aNtDdjwNGG2tRJZlfZ'
        b'x8fKvjK7qZwHtjHeZV6CmxbCCm+kFWwMTA4OwHPRSRqNIpXgNJmu+ztGMuLFvLntqPYyUMrM5ZXwEJIEKmRwi5mRZw8dmcuXg/XgOJ5ck7BGil04Y+h+DKzoxwXNcL2c'
        b'zJVgWx9wBrWmFuwfC2Pz13MwNskHVi4guEwZrEIqGywdaonKNDP1bIBlJC9Z8FIBnu6R4r4/kEtxYTMH7M2G58lGNiiFO2ETPCQhxiomS5WQLAZftQauc8CCHuOPAAkB'
        b'HKqnPahP5/WFG4cTaKpaPR9vqrO+CMgak9sgNCCXYXfLDekMQOwoOAhPjppubtfqOnMRqYzEEHCgo8iC5BWwTYhElnBYQQSDFOcYAiztD1dZ+EzYEU7yAKq58zsINFic'
        b'mYkEGnAS7CECZVAJwH4fJgWFhOCFapRL2MgBh7lotDjvRGLx16ObKzqZw0pne/FGw712JCNCpCCfIjdtBi3jZHYUj+aAetAILpGfncAusF3mh/q2hV1AX3BKh713IUGo'
        b'CpSzNgg2DBDQBFfN9wJNchLhvMm9UKW9Ao6EWsiosMmLOBWaDC4mtUtp7SIa3Cc3Smnz4HrmRe+zXwwqvJw7GODO15I3lFIMVwX6DQ0wd5QE69OM1gzd2ibjYRs+Il7l'
        b'WIhXIg2PI6KJgwQkBmHhygN9eqJPb/TB584opMk/TcQkN8adAvrwbvG9eP929BbQjhxH2oMjeOrIxXYRAhrDypAA49wuwODkzazcushzu9HbKRTc6ywreVjbSO2QFKob'
        b'LJegry3kKxkd1eKjXh0gYcS0V7MUB8Tcl9gBYxNgg8BoCmo8wptNjAElwYJh8yxiskF28MmeL9n8M4gyUmOmxiRlTJuVOiHNwNUqdQYedjZgELI/pE2YlkYEQVJCRsb8'
        b'6w4xNJiKLghX1xkK72uJubTr80K/nO3Qv5MHXywQ2DPvmE9sXfgdPrwfaVce61LD0cylhoBP/8qzp/8jENCPBQ70I4Ej/YtASP8sENEPBU70TwJn+oHAhf5RIKbvC1zp'
        b'H/huKLbv+fecA5xR+r3teseRCT/DT2iyMNKARgJLFU/jzgZVSzptXBsparTjOrLu8qpdCButi/FbQZuOuJvsHXgKXyQzY5CGSw5PYa8QmBh4HRSOBKIjYhl4nci5MznH'
        b'DLwu5FxMzgWEodeRMPSKWAZed3LuQc4dCUOvI2HoFbEMvL3IeW9yLqrmKQbhfCn61NHVfAzCWeCk8OxD7XXGMBP2vK/xvBf6b+Bs5ij8WOC6PfEVJVzrslac40B4fAmv'
        b'LvrNgbDk8gi8RzBbjOtDMWATZy2jK4jWOiFNwUcxkDDouiq8iBX0YJZBV5Y84dftFhjvaUZWV/QTQ58r8cesJ5jZSl6gwF1E1ZF80+IkYBqGmrNkVuioMEtbqMYk3Bgh'
        b'j70TMzSi2DuyskjHOOgmcPkOTqM12GBVam9wYFnZMH8Re0h2kwWMw1TMZKTIWWTgLixA1/KVCpU+H10TFKGcLy7UKDTtHL5WyXMtvXIZfaA7IB3Lkd0iFpq8cnWXPhe7'
        b'C/ix2/S5uKL/NH3us9lzOzHlWvUU8CfZc81eiCkf2It6F7lAP9vKQ4FEri7Kkwdby8pISXYeSjKb+Crvmsy3ay5fK7y9z1Ejz+TyRW2RcescFz9DopZnYfZ4dGjuKVsa'
        b'0sEHNUNCZzUXllkndesfZlYVVjLPZgT1h2cwCdtiDbbuSsIWk3A3WYOtRtrOJPwXWIONfZ6pduZMolKwLyz8WS/MOFCwvrzZM4lGmavSohpGAxQax0hzCpLo2demL8A+'
        b'tf8UOa8Ls7yyarGYisgiawzqDT2R4owNaIaC3UqrJLrtoj9m0IU7wCsmV65rxonE4aCOREqN9aB03qlYdx090y2EpeZthjtgLYp2RUoXEeNt+unmLmL3FImQ8nJmMIn4'
        b'5Gwnqvciss4RdGvWfEqPEYtw08wFKNpicMk26y8x4TYzrD4D1gnBPlgFj5B4r0/lU6n9+pA1mYAF3hRxBp2xGG+BWamFhMA0UCc2j24lrHQANSgDTPlvL3Ggbk4ZjNeO'
        b'1GPsA5nyK0AdPI/jqxjWmQB4Xbv21yGfp4TYazK8wFAppwgpiUMwWdJpHurIvC1XzHhMMtqjU8T+RhXHItZz4LAQroNlvqqth8U87UYUictU7+Ar553oGNGEKcv+mL/u'
        b'4EpP/9KegshP3nBrE2VNn8LZdkZ0p3r4h2Ufnn3vVHrYN59cVwwM9HOZ+857D6MuzBp/2+VGy83yOQO/E8gKsvt/Hb3U/aoiYnDE5V2Pk8auyn0kOno//MLZ3PQfU/Qv'
        b'Hpr/5dSYsy/PvaD+KU375uzF9wOXj30SnVgd4nt67I7vIp+euCJ1ZJamm+OSkXqUDo5ZaJxY3WyDq8ktSbAUbBTKfAs7oSDBGvASWQb3G7fUXGeVwZVI/cRKY3/4Eg8e'
        b'Xd6LKJ65oBx7AjSprlpYz2qvSHP1hpvIcn1h2nwT/h00ZYGDdLgenNEx2/wHsUaZAraGJpjUarAPrCG/iuEmpAtiRbEmHW42KoojQTVJOx1pjDvNVgBAfSa7CMAFzRpw'
        b'lqwApM9YblJYh0SwKivSV/lwP9EmwdkIXAAsxAZjXwhu8IiWrGigC4lkfSOYTyWBMnuwe2Txf00FMOEpsWuIdiWPWuEc68ziKY3UwI4sQbD5mYkoGIke1omCX8PB6zgA'
        b'OIA4eAMHl3HwN4p6NnuOoDuROFkUSco1WuOXtn8k1pbMO2f/eeB4jhkm6ckmSG46ygsDwWxPy4wvGF/qgi/4uVGYogwzUcpmptKNmfq1X4ccEMHgOZljTWBIo9hkM905'
        b'pnT7M+n+NZ5iFqfIy0DCks0055vS7MukaSZQ/TmKXF4Gkolspic3peffLjXJO0Jdn58L2QQBNcopNnOgMOXAEy9ymIkyfzpNkxZkK81cizRRLZsEILM0pTSDliaLJiYb'
        b'2+RsrllWsOU67sPEyHYyCsguFXZGQbO6qyPxcSzKEZns2O26ZcdeJuX+bOfWbS4pJabS7C6VFLn5eZikzJmjOkWJmaRMgOaAIEmAObIanROwNrrJnAeHCLdMNjC9SPcV'
        b'QFNCUZK0wnysRjA6N/YQx8Kj5VmFeh1L0KRFAqutusF/mAxFiatEocohVDk6ViC3LBRb38QLJqq2XNb/nRVZGP8lmKid5F3pdkMjzTQaib+RP8a2bmNer4zc3qmjSvxj'
        b'sjTK7LwCTF3DKnrEC57VjLa3A61WlVtAmgJDENOJpUwrUZmXSoV0nlwbLDRGXWYoecmRI00qDU5pqDQIr5IY2Y7xHSa642xbWhhplSryPCbLwnU3YmT3ybZyLAuES61S'
        b'av97VFn+mBqKkFpJJQEB+VjPRsVZEhDwp8mzJP6EKCuY4Zt6nqi7IMrq1vPPS1slsUG3ZYu2KqR72bBAf3RJXuVvIq8aKpXMGRpmm3zKHEHCvka9kimOqoBklLDSxyUl'
        b'zZqFS2bNKy7+K5IvySc+dZUaPE0FEWY6k3pslqGwrjPUJaOW5WIJ01tCjT3FarYYYcichwslHz7ENqWaOd7GuHRk1k3QVdQjC7QqJlOFOdYZyhQLUMsg9YEfII6F5SX4'
        b'uJvkTPgvxiISLVk1U2Xn6VSEgUvbzg/Xuc/ajDNYMhTzXiv1aHA1RYBasErCVhEaofJRj5swPXiaXJelxCuR1vnCgiWouTAuT9X6/IXKPOv1HywJ73AbSU2uz1mq1ynR'
        b'zIEdTEtmFGq0JFM24oiIksToc/KUWXrc9dADMXpdIZ7fFtp4YFiUJKFAoVqkQo1ZrUYPMCx22g4lt/F0pLUsP38FDbcWjcosW/nPl60R1uJ7vnoZSSqyveqfUfNWL05j'
        b'WjJeMuyQ7+duiebFz9Gg0vjjujXlSZ61VJ8rtd38zB+XDB9kuwFa3Dh0pK07UTMrCO1MEMr8OKxjNJG2oonsKhrUKEzl6yKOEea32SzaSIvIrJTL5oTG4gHRCMceEXkA'
        b'yaRobDUO5f5pzBxrc8Juhxti3no0FTJnSMbxl6FTZQH6R81cguegEbZJM9uBipbRhHWIJqzLaAim0YJF0Z9QJ8bh+WaYzcdMGEjm0QnTyUiNL0j8USdnmzh67barQa/B'
        b'bJJothjPHgVJzGS7CdOnSvxnwoY8DeqkKC8RtrNiBr9sj8x0mc2UMSrtQr1G2zlTXYl7tsRLIkp2X/IziWgxFqv/3ZNhCKA0SpKMvyRzwobM6/5jYcxjYeQx22/DiFRl'
        b'RUj2HKvOXbUDAmNFj+AvdGPn+2yPYpOUGk1BaLxGrkeBOiQ0XoWkO9ujFrnd9liF47E9PuEEbA9QXaWMRqUJeUgIQ2O/7aGJ5A3JbArr2bBVeUiKVSp1WLLA30jAiuxS'
        b'vssqLImS4I1kJD/lYKkVXUB1bvul4ocwPph5Sq6W4JMun8hW6XCHRGGX4h4DisZ3Mgck4iAspweHD42MRC3Ndp4wHhllCH912SJz5Ki08WhQ6eomgmhGbwh/SeZE2r6R'
        b'HeaMRLFdtGgj1jpKEouOGEl4TtjwLu83dW3yiOXuXpf1bURws08y78f2YI1x20hEi41JRq/H9oiYpcpGESaMR0lb6ZGdUNd4D9/qDtvlYVwqKAMvSWUGrRo+jDWubYYH'
        b'Zpv4JTlgcyELnKMYP5U9Y3nUB5M8iPXn1RnODDAwB9TDzQyeD4P5VoNTYI+AgVJ68XpR31Fz8QbW3JRsD4oFscF18BhD0wFWy6gQuA2UEqwS2AcOebZjowf5UwQZXQQZ'
        b'go5RJcs5Q/o+IGbOA2ei2IinspVu3oHo7smDYGMS3JyCjQtB0+QkQh06jYLHQMVUqiTCIRc0LydIoq9cU7APpLy7Grn7jd7lOQ4UQY1zikKtuUDCkUxiNirMXCANhqUU'
        b'htmJpKA2hywZqtoiAK01oKMS2Tr95teTQaa4LPeXpzemjsu+8CNVN3pp2BfS+zeF6ojYVQ2R4toPV/9LcfZhn9ce7y24e/3GvX8MP579Cf/WlgC/UR6L//aosXxg8LCr'
        b'I1ZvmiP9uqda8XbRlLwHweF1e+/uPKK784NQ9M0Gp8jTtfOu9Rv9/fyJ9T2TNf1OpPP/PufF1vKr+ne/1Oalv/9g+ifHPp79YUqw/sL2rFl+UXff/uadzP9UaMfOBU9H'
        b'pmlLB6sLfN55eD8+InbaVb+TD51//n38L5+8cq5fXuH2uw//NeeP1oGfHi554/Knv//wj7Y/qOM1sb/HbJEKyLZRAqwEewNDJsC95uARsFNKrPRGgwsZLHgEQ0ca4CrQ'
        b'CpvEjH3fMX9YGwixZenJlATQxKP4atoHnnVkuDnODwIvCTt5DgVHxgi8XIl9rH3ecrO9pE4bSeD8cHYvKZsl3GqVTRR29LgEVnmxTpfANtjG+M5phQfBWi1+vWJwrCNN'
        b'ITwANuiwXXSqG1wnS0xAhQqm6KmcAN+BnSEfov+SU3NsF0e2sOJxT15h/hGkYBAIdqHnSwAdjF8eYn1Itq9ojif5Fqykn9K0l+l4qci0U2PCdLAOP9qXr7E5t9nelcNz'
        b'5V/KM4uExGmJ+FhgbQPLZ6uVDSyLrNqGfBCnTtggiVrLMzl1eg7CJU0xisBizMTF6N9pzBzEjJmNK7Bn4NeUfDT8PQrSUwy1zyYebNDqpwwDr8qGYCwralmcF0CZjIGE'
        b'YL9HwWPAaSGX8i9A2ZnpA04zuPFXwGlQ4xGbNmwIg4A9T8ETCaCMpHRT+ALnMe3vIxgiH/UkxoeBK+h08ChGbngXUhi54QU3EfSBB9wvwkAP1NdaKIz00IAWEsm7/e0p'
        b'ESVRu0gy1b0WFzLwixFRYkpCvUXbF2Wq1f7BjFX/DBG+OGKcc1Fm0KxgFtJRPlBE9aZSPYWpmUGfKcYwd9Z64os3RVRqpuiP4HDmzjmujpQHtdKLJ84M6pHnw9x5z1mI'
        b'Lt50QBdFoRG+zMVlfjhLJVp7lKWnRSJmQnAeRLBcq9JSU1PRQBxHgdKoNDK1+IvBerhbGz4EUyhyYAMFS0HFYPKQ71BwKi2VwnC9AxJYhn6BlXOYSew8qIM1BHYMNvVv'
        b'R4jA3VnkyXxwkhPOAETgbniUAlsHw6MMFGdDPjyZhn16wPXUAGoA3ApfJpAMV9i8MJxHoZHgNBVGhcFLYC8D6lmnROlu46A4FlDBVDAaGWsYFwOn+8LqHqCSwXm0Yzxi'
        b'Yhg/CbXgBDivBZfSUiWolYDjPfhgHzwJdxMIMbgE9hQyHvRBZVw70gM2gI0MEgNXetoUASWm/EfwMzODPvaQMvWbGOCALq5cKMrMFEUvcWHw3eAgqOuXhuuWwuj60ZRc'
        b'kM5M55E9KH9qXChnXOZonXcR2563YzjjELg/LRXslVJU1AtCuA/VxDEC+s0DZ+DZPH+tUziqQBocpuBF9Nt+VV1gHaUdhDrqxLrM/C0yjPkoz61rSPo1cXbttQcB333B'
        b'CzrLWbhoLG9D1bWWWM3HcZNGlgcXRziDEVLXine2Dns6eNkfSy6kJvSpmXs4uM8p3USXz/cfSji84fOv5vm6ThfNn3pXpazu4bT/YnVBwvEfb/bpH01PPGHg37l46EvP'
        b'35/w5d+3/iKe/s5D11mvxrrLM/uM/+eO2VuqSqu2VP1YXxIiuxw7OPbVp3da9m21L5aNapvo+x/3nN0vwtGhcZuu9J64fdQfA56kfdBwKz2iR/JQVYDuxZgbSyanSy5P'
        b'/Ufx92/vSs8Zl3l76brMNbxv1fnXfUccU+9U9frig8ezv9w6rMfYgqkPCv3G1K1/f8kNbohz4uXpw9480Lhg4Oj82+fbQo/ff2/iwK3vzlf0n9kqPPfqnf/0Kh1fzBVu'
        b'k3qQ+SzRY6nlfAZ3TrRqG6GyIygJP7ARtGLXj1KnwUnoRwE8T4MtE7OJA6mAIUKwZ1Dg5KREDsUbwAG7YZMbg1g8lpBDiA9rwEozN4EXwRECIskDa2ETvISNioxAVAYn'
        b'UgdXktkRls32l1kBcEgmgDZwzM5h1DIGTtIapQT74VkMcjDZmsTBtWTmV6WDl4zoDVAF9zAIjmzQRrIAmkbN74DgKErDFjXe4AQxM5kBzoC97SAT0FbM4EyawS4Ci1ga'
        b'hfqTJcJDBl9izGQCwRYG4HEGlPYBjXCLmXTSGrGUiB5af3hCZgHvgBXLnMFqbqwXaCGV6AVrwsx5wyZGEHTHUlhDSjARnIKNMnNwB9gA25xf4MbRbgzXziW5whzaAfcP'
        b'Z01l4LkBxIynl8w9aDQD2zBhNqpUDM5mHWgdyXBRIEFlpQmzMR9ljqFeO8TpiNUBLzOWOs7gGGNwBNYusbQ4Yq2NcoZjUejiTBt2Ks/wF0jIX4igsqiToMIr4rECiYgj'
        b'pgVklhezyFUMrRATcAVN2JFp06cdZkHAFV/z+/JvOXohIYdmYBdiYo6PTfV5jwUOgkc8R5bzjEgLndjUrOe/A68a18jcVmr+cdthk1/NPC0tliFs+hX+y+RqZUhM0XcU'
        b'U6wzi9knE28ps5F8fSxwkj3cYskt1oFZLBquJkM6B5xdzFCFYZ4wcC4JU4XlxzFYxP3gwAyMHASXYE0JVTIcHmb8ULSBHXA7oQrLhpWYK4wHalTBbo9oLbZ9SFxVOybp'
        b'oiMYJ0rWNJ76l6NzdOmuXccPjzgTtW7vjQFfSj5wDFlccVrxU497n30wV/jA9fHW5WOz7omnjJAP33FF+tPt2MQI7rJjl1f2r/bp6TBa8OaUVSNONXy+6eBHnqWZo6PW'
        b'KVcFz/0mfMmDv8mbvEZuE+ybd3fG4HEtRSsvqa6dvndCVdsHfN7m9ST2YrProuq3NHsLv7peXKc68E1l7eUNmeJ+tPCW57kbc472Gbx70Z5dh751cT4V6Un9XerCMGZt'
        b'9eEQUjb0HtE0fQjzhCFBrY3piKunwLO4A5lIwhrgEUwUNo5iHAmcAJXKGDSc4luMRGB0MAPWq6YXwoq+7hZEYDS8gIb+dYxhYWNGIjwOyoAl0RiNBMVmuJekHww2gAsy'
        b'pOAeMKcLo+FLvRyYoX4HEpB2y0EToQszUoWBXWiYJINQPQeNUhZOb/PByiHcXHCIZSKD53ORMnQAHGVYGlnCMJTgS6QM/cB2oTlhGDyMhitMGAZPJZHaC1fMRKmdIpRh'
        b'Rr4wWA8Z5BlcgzS2bbJ2xrAoIeYMQ+Iyy1W2yD18FCENM1GGgXI0S5Fn94IKcNFsioJVQjxL8fozmuUJ2OrSF5QHshA0whoG68DR/wpvGCG3IoPckE6DHLXCJ7hb1GF4'
        b'yDBRh2kWU13Dv0os0u6Prml9Ow1QVGnPGzapwozpoRHQEuPBnLI+vvFxstStIxxsCUWZY8Jeo55pqniOIi69dcp8LQPq6sAK5vqXFONuvKNLKBiAB/J0iqEBE/NFhLSr'
        b'51Na+udIwEQ8PN3wnvKeSrhuiwWjPDl6gjitgXtgxXRwRmsS3ewoJ08aDaKXYIOUk6wq+b2eo+2FpOH11OoJm0cVrB6HpOFeLa9/3HuIS/Z3N7kN912v3aKkmtKMiO1T'
        b'fadN+USxha/55kpWdd6u3YV/vPmkKTp0/HsTonnxMfN2V078bW3zpJzc2l2/iT5q3Vea6zdv4opzE+LTt/Oevh12dd7uR7JXJTs//6bmM3rCL063k7OV1fsX/9D7/qrx'
        b'm0veHfrqha82CqOL3y8XHLv3+9VlftcHA+0vs136xl2sfOtO37e/3jf9Y5+ebiu2FMcPO85rbNFlRXwQm7DUI/T6jhN//2D7lRdG/nD2S27/61+l7ZKvTbyw82r8px4P'
        b'5PP+ebD436kaYfULQ85tfXXQ7adf18kWXfbOqpz8Sc3VV8J/NsTn3kvMyR+w4IbUOfq0g/PBy2kpmzwfxsb8JqRnKtw/uyXlEpHV3Qt10X06WIHkFc4ICm4GdZlknHEe'
        b'Cw6YVoKUSJ0zGVCnxZGVHSdXNBJZ86U9DLRgcaYF1HVem+n7v9MEnztAAw/X1A+tBQSqKsjIUBfKFRkZZOAJwSOQJ01HcCR4yecpn8ZLPhJPTw+PAI+x9OAoDlkaGu3M'
        b'9RNSK+hFIziaj019j2ugMzLMVnU8/x/UAUdz3dR1cU7x2EN8EY+7Y4WqjMxeq0ID0SRQiSaA9SmJYD14ORlU2lPOfbje+c6qYP5srrYS3ab8p5f3+lHOYIjYbvHviwVx'
        b'k554xJSudC+2C6z5dIqf97XsQteCyUXDwmvfWB+WFHHtSujPt9ZPrNdPrQg88LAtfvn+mpbU3JkXUl/wW+t2ebuk+dTfk2atDzhSlL/jI+XAcgdeeVDrqviymNU9ezp7'
        b'n/pYXsndPGLf2jf79OLNLYbelftSotcsFv9+NWUDdBHc8P/8TBoSKyQ48w1wgw+elVPwCvVGmT2sgscpIWil4UGkXteT+XmAO7wgSwnGDKUpKSnBgaCUplzhBS7Ytwgc'
        b'ZGSE7eCClKkELMCj+fSghlSCG7dfPE30CFALq8SyhKSAJHuKnyHg0QKkSKxliJtawMFoWBHKRzLfJXA6jYKvTIVnSVcEawvjAyfbURwJ3C7DjgXKWNWrN2yaQYjuUHJw'
        b'IycGXqKEUhrlfvUy0lUngzKdtv13sB0eoxwTaNDiDdeQQs1Beud5GRkpUV8FTbHY3yXcwE0GF8Eq4qhoLqxLb98/OBcN9oBGO6a458Kxgw40pzNr8HawzocSudNIzjoP'
        b'q4nukwNr4Rmk/GwIKmJuQSVbSTmC4zQ4oQb1jAZ7FJSCbeimVhFYt7hYD48XLwgUFes5VC9YyQUb+eNJakPBRoilK7gxEBeICoL70RuqpeHLKOfNJKY+cLMaV3+oDA05'
        b'qMgunpgzCr+Bvr48sBo2+lk4SO7/f9/RbPdAh2eMQlYGpXZkBUb2C5wcTSQAWK8TcaK5HYUjni8jRpBxaICBq1YWGHjYktdgp9MXqZUGnlql1Rl4WJMy8AqL0M9crU5j'
        b'sCPc8QZeVmGh2sBVFegMdjloOERfGrzxj8lDivQ6Azc7T2PgFmoUBn6OSq1TopN8eZGBu1RVZLCTa7NVKgM3T1mCbkHRc7X6fANfW6jRKRUGR5XWiCo18Iv0WWpVtsGe'
        b'Ad1qDUJtnipHl6HUaAo1BqciuUarzFBpC7GhosFJX5CdJ1cVKBUZypJsg0NGhlaJipKRYeAzhn1mTu9pphE8wseYyk3zHQ6+xMEXOMA8b5rPcHAXB//Gwfc4+BoHmNRU'
        b'8yMO8L6S5lMcfIODezj4HAd3cPAzDh7g4BYOHuLgPg5u4uAHHHyCgxs4+AUHj3HwrcVbdTSOv5Medx5/yR2/CnKwNW92XohBnJHBHrNz1K+e7LmkSJ69UJ6rZKHMcoVS'
        b'kSwVEHkS087K1WqWdpZInAZH9AY0Oi1m8Tbw1YXZcrXWIJqKDQvzlRNw7Wt+NdZjB/N8g2B0fqFCr1ZG490B4huBR/HsBXTHFugxnCYt9H8ASKznxw=='
    ))))
