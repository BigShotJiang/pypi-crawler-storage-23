
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
SEPA module of the Python Fintech package.

This module defines functions and classes to work with SEPA.
"""

__all__ = ['Account', 'Amount', 'SEPATransaction', 'SEPACreditTransfer', 'SEPADirectDebit', 'CAMTDocument', 'Mandate', 'MandateManager']

class Account:
    """Account class"""

    def __init__(self, iban, name, country=None, city=None, postcode=None, street=None):
        """
        Initializes the account instance.

        :param iban: Either the IBAN or a 2-tuple in the form of
            either (IBAN, BIC) or (ACCOUNT_NUMBER, BANK_CODE).
            The latter will be converted to the corresponding
            IBAN automatically (deprecated). An IBAN is checked for
            validity.
        :param name: The name of the account holder.
        :param country: The country (ISO-3166 ALPHA 2) of the account
            holder (optional).
        :param city: The city of the account holder (optional).
        :param postcode: The postcode of the account holder (optional).
        :param street: The street of the account holder (optional).
        """
        ...

    @property
    def iban(self):
        """The IBAN of this account (read-only)."""
        ...

    @property
    def bic(self):
        """The BIC of this account (read-only)."""
        ...

    @property
    def name(self):
        """The name of the account holder (read-only)."""
        ...

    @property
    def country(self):
        """The country of the account holder (read-only)."""
        ...

    @property
    def city(self):
        """The city of the account holder (read-only)."""
        ...

    @property
    def postcode(self):
        """The postcode of the account holder (read-only)."""
        ...

    @property
    def street(self):
        """The street of the account holder (read-only)."""
        ...

    @property
    def address(self):
        """Tuple of unstructured address lines (read-only)."""
        ...

    def is_sepa(self):
        """
        Checks if this account seems to be valid
        within the Single Euro Payments Area.
        (added in v6.2.0)
        """
        ...

    def set_ultimate_name(self, name):
        """
        Sets the ultimate name used for SEPA transactions and by
        the :class:`MandateManager`.
        """
        ...

    @property
    def ultimate_name(self):
        """The ultimate name used for SEPA transactions."""
        ...

    def set_originator_id(self, cid=None, cuc=None):
        """
        Sets the originator id of the account holder (new in v6.1.1).

        :param cid: The SEPA creditor id. Required for direct debits
            and in some countries also for credit transfers.
        :param cuc: The CBI unique code (only required in Italy).
        """
        ...

    @property
    def cid(self):
        """The creditor id of the account holder (readonly)."""
        ...

    @property
    def cuc(self):
        """The CBI unique code (CUC) of the account holder (readonly)."""
        ...

    def set_mandate(self, mref, signed, recurrent=False):
        """
        Sets the SEPA mandate for this account.

        :param mref: The mandate reference.
        :param signed: The date of signature. Can be a date object
            or an ISO8601 formatted string.
        :param recurrent: Flag whether this is a recurrent mandate
            or not.
        :returns: A :class:`Mandate` object.
        """
        ...

    @property
    def mandate(self):
        """The assigned mandate (read-only)."""
        ...


class Amount:
    """
    The Amount class with an integrated currency converter.

    Arithmetic operations can be performed directly on this object.
    """

    default_currency = 'EUR'

    exchange_rates = {}

    implicit_conversion = False

    def __init__(self, value, currency=None):
        """
        Initializes the Amount instance.

        :param value: The amount value.
        :param currency: An ISO-4217 currency code. If not specified,
            it is set to the value of the class attribute
            :attr:`default_currency` which is initially set to EUR.
        """
        ...

    @property
    def value(self):
        """The amount value of type ``decimal.Decimal``."""
        ...

    @property
    def currency(self):
        """The ISO-4217 currency code."""
        ...

    @property
    def decimals(self):
        """The number of decimal places (at least 2). Use the built-in ``round`` to adjust the decimal places."""
        ...

    @classmethod
    def update_exchange_rates(cls):
        """
        Updates the exchange rates based on the data provided by the
        European Central Bank and stores it in the class attribute
        :attr:`exchange_rates`. Usually it is not required to call
        this method directly, since it is called automatically by the
        method :func:`convert`.

        :returns: A boolean flag whether updated exchange rates
            were available or not.
        """
        ...

    def convert(self, currency):
        """
        Converts the amount to another currency on the bases of the
        current exchange rates provided by the European Central Bank.
        The exchange rates are automatically updated once a day and
        cached in memory for further usage.

        :param currency: The ISO-4217 code of the target currency.
        :returns: An :class:`Amount` object in the requested currency.
        """
        ...


class SEPATransaction:
    """
    The SEPATransaction class

    This class cannot be instantiated directly. An instance is returned
    by the method :func:`add_transaction` of a SEPA document instance
    or by the iterator of a :class:`CAMTDocument` instance.

    If it is a batch of other transactions, the instance can be treated
    as an iterable over all underlying transactions.
    """

    @property
    def bank_reference(self):
        """The bank reference, used to uniquely identify a transaction."""
        ...

    @property
    def iban(self):
        """The IBAN of the remote account (IBAN). May contain domestic account numbers for transactions from/to outside SEPA."""
        ...

    @property
    def bic(self):
        """The BIC of the remote account (BIC)."""
        ...

    @property
    def name(self):
        """The name of the remote account holder."""
        ...

    @property
    def country(self):
        """The country of the remote account holder."""
        ...

    @property
    def address(self):
        """A tuple subclass which holds the address of the remote account holder. The tuple values represent the unstructured address. Structured fields can be accessed by the attributes *country*, *city*, *postcode* and *street*."""
        ...

    @property
    def ultimate_name(self):
        """The ultimate name of the remote account (ABWA/ABWE)."""
        ...

    @property
    def originator_id(self):
        """The creditor or debtor id of the remote account (CRED/DEBT)."""
        ...

    @property
    def amount(self):
        """The transaction amount of type :class:`Amount`. Debits are always signed negative."""
        ...

    @property
    def purpose(self):
        """A tuple of the transaction purpose (SVWZ)."""
        ...

    @property
    def date(self):
        """The booking date or appointed due date."""
        ...

    @property
    def valuta(self):
        """The value date."""
        ...

    @property
    def msgid(self):
        """The message id of the physical PAIN file."""
        ...

    @property
    def kref(self):
        """The id of the logical PAIN file (KREF)."""
        ...

    @property
    def eref(self):
        """The end-to-end reference (EREF)."""
        ...

    @property
    def mref(self):
        """The mandate reference (MREF)."""
        ...

    @property
    def purpose_code(self):
        """The external purpose code (PURP)."""
        ...

    @property
    def cheque(self):
        """The cheque number."""
        ...

    @property
    def info(self):
        """The transaction information (BOOKINGTEXT)."""
        ...

    @property
    def classification(self):
        """The transaction classification. For German banks it is a tuple in the form of (SWIFTCODE, GVC, PRIMANOTA, TEXTKEY), for French banks a tuple in the form of (DOMAINCODE, FAMILYCODE, SUBFAMILYCODE, TRANSACTIONCODE), otherwise a plain string."""
        ...

    @property
    def return_info(self):
        """A tuple of return code and reason."""
        ...

    @property
    def status(self):
        """The transaction status. A value of INFO, PDNG or BOOK."""
        ...

    @property
    def reversal(self):
        """The reversal indicator."""
        ...

    @property
    def batch(self):
        """Flag which indicates a batch transaction."""
        ...

    @property
    def camt_reference(self):
        """The reference to a CAMT file."""
        ...

    def get_account(self):
        """Returns an :class:`Account` instance of the remote account."""
        ...


class SEPACreditTransfer:
    """SEPACreditTransfer class"""

    def __init__(self, account, type='NORM', cutoff=14, batch=True, cat_purpose=None, scheme=None, currency=None):
        """
        Initializes the SEPA credit transfer instance.

        Supported pain schemes:

        - pain.001.003.03 (DE)
        - pain.001.001.03
        - pain.001.001.09 (*since v7.6*)
        - pain.001.001.03.ch.02 (CH)
        - pain.001.001.09.ch.03 (CH, *since v7.6*)
        - CBIPaymentRequest.00.04.00 (IT)
        - CBIPaymentRequest.00.04.01 (IT)
        - CBICrossBorderPaymentRequestLogMsg.00.01.01 (IT, *since v7.6*)

        :param account: The local debtor account.
        :param type: The credit transfer priority type (*NORM*, *HIGH*,
            *URGP*, *INST* or *SDVA*). (new in v6.2.0: *INST*,
            new in v7.0.0: *URGP*, new in v7.6.0: *SDVA*)
        :param cutoff: The cut-off time of the debtor's bank.
        :param batch: Flag whether SEPA batch mode is enabled or not.
        :param cat_purpose: The SEPA category purpose code. This code
            is used for special treatments by the local bank and is
            not forwarded to the remote bank. See module attribute
            CATEGORY_PURPOSE_CODES for possible values.
        :param scheme: The PAIN scheme of the document. If not
            specified, the scheme is set to *pain.001.001.03* for
            SEPA payments and *pain.001.001.09* for payments in
            currencies other than EUR.
            In Switzerland it is set to *pain.001.001.03.ch.02*,
            in Italy to *CBIPaymentRequest.00.04.00*.
        :param currency: The ISO-4217 code of the currency to use.
            It must match with the currency of the local account.
            If not specified, it defaults to the currency of the
            country the local IBAN belongs to.
        """
        ...

    @property
    def type(self):
        """The credit transfer priority type (read-only)."""
        ...

    def add_transaction(self, account, amount, purpose, eref=None, ext_purpose=None, due_date=None, charges='SHAR'):
        """
        Adds a transaction to the SEPACreditTransfer document.
        If :attr:`scl_check` is set to ``True``, it is verified that
        the transaction can be routed to the target bank.

        :param account: The remote creditor account.
        :param amount: The transaction amount as floating point number
            or an instance of :class:`Amount`.
        :param purpose: The transaction purpose text. If the value matches
            a valid ISO creditor reference number (starting with "RF..."),
            it is added as a structured reference. For other structured
            references a tuple can be passed in the form of
            (REFERENCE_NUMBER, PURPOSE_TEXT).
        :param eref: The end-to-end reference (optional).
        :param ext_purpose: The SEPA external purpose code (optional).
            This code is forwarded to the remote bank and the account
            holder. See module attribute EXTERNAL_PURPOSE_CODES for
            possible values.
        :param due_date: The due date. If it is an integer or ``None``,
            the next possible date is calculated starting from today
            plus the given number of days (considering holidays and
            the given cut-off time). If it is a date object or an
            ISO8601 formatted string, this date is used without
            further validation.
        :param charges: Specifies which party will bear the charges
            associated with the processing of an international
            transaction. Not applicable for SEPA transactions.
            Can be a value of SHAR (SHA), DEBT (OUR) or CRED (BEN).
            *(new in v7.6)*

        :returns: A :class:`SEPATransaction` instance.
        """
        ...

    def render(self):
        """Renders the SEPACreditTransfer document and returns it as XML."""
        ...

    @property
    def scheme(self):
        """The document scheme version (read-only)."""
        ...

    @property
    def message_id(self):
        """The message id of this document (read-only)."""
        ...

    @property
    def account(self):
        """The local account (read-only)."""
        ...

    @property
    def cutoff(self):
        """The cut-off time of the local bank (read-only)."""
        ...

    @property
    def batch(self):
        """Flag if batch mode is enabled (read-only)."""
        ...

    @property
    def cat_purpose(self):
        """The category purpose (read-only)."""
        ...

    @property
    def currency(self):
        """The ISO-4217 currency code (read-only)."""
        ...

    @property
    def scl_check(self):
        """
        Flag whether remote accounts should be verified against
        the SEPA Clearing Directory or not. The initial value is
        set to ``True`` if the local account is originated in
        Germany, otherwise it is set to ``False`` due to reasons
        of backward compatibility. Up to v7.8.x the *kontocheck*
        package was required to be installed.
        """
        ...

    def new_batch(self, kref=None):
        """
        After calling this method additional transactions are added to a new
        batch (``PmtInf`` block). This could be useful if you want to divide
        transactions into different batches with unique KREF ids.

        :param kref: It is possible to set a custom KREF (``PmtInfId``) for
            the new batch (new in v7.2). Be aware that KREF ids should be
            unique over time and that all transactions must be grouped by
            particular SEPA specifications (date, sequence type, etc.) into
            separate batches. This is done automatically if you do not pass
            a custom KREF.
        """
        ...

    def send(self, ebics_client, use_ful=None):
        """
        Sends the SEPA document using the passed EBICS instance.

        :param ebics_client: The :class:`fintech.ebics.EbicsClient` instance.
        :param use_ful: Flag, whether to use the order type
            :func:`fintech.ebics.EbicsClient.FUL` for uploading the document
            or otherwise one of the suitable order types
            :func:`fintech.ebics.EbicsClient.CCT`,
            :func:`fintech.ebics.EbicsClient.CCU`,
            :func:`fintech.ebics.EbicsClient.CIP`,
            :func:`fintech.ebics.EbicsClient.AXZ`,
            :func:`fintech.ebics.EbicsClient.CDD`,
            :func:`fintech.ebics.EbicsClient.CDB`,
            :func:`fintech.ebics.EbicsClient.XE2`,
            :func:`fintech.ebics.EbicsClient.XE3` or
            :func:`fintech.ebics.EbicsClient.XE4`.
            If not specified, *use_ful* is set to ``True`` if the local
            account is originated in France, otherwise it is set to ``False``.
            With EBICS v3.0 the document is always uploaded via
            :func:`fintech.ebics.EbicsClient.BTU`.
        :returns: The EBICS order id.
        """
        ...


class SEPADirectDebit:
    """SEPADirectDebit class"""

    def __init__(self, account, type='CORE', cutoff=36, batch=True, cat_purpose=None, scheme=None, currency=None):
        """
        Initializes the SEPA direct debit instance.

        Supported pain schemes:

        - pain.008.003.02 (DE)
        - pain.008.001.02
        - pain.008.001.08 (*since v7.6*)
        - pain.008.001.02.ch.01 (CH)
        - CBISDDReqLogMsg.00.01.00 (IT)
        - CBISDDReqLogMsg.00.01.01 (IT)

        :param account: The local creditor account with an appointed
            creditor id.
        :param type: The direct debit type (*CORE* or *B2B*).
        :param cutoff: The cut-off time of the creditor's bank.
        :param batch: Flag if SEPA batch mode is enabled or not.
        :param cat_purpose: The SEPA category purpose code. This code
            is used for special treatments by the local bank and is
            not forwarded to the remote bank. See module attribute
            CATEGORY_PURPOSE_CODES for possible values.
        :param scheme: The PAIN scheme of the document. If not
            specified, the scheme is set to *pain.008.001.02*.
            In Switzerland it is set to *pain.008.001.02.ch.01*,
            in Italy to *CBISDDReqLogMsg.00.01.00*.
        :param currency: The ISO-4217 code of the currency to use.
            It must match with the currency of the local account.
            If not specified, it defaults to the currency of the
            country the local IBAN belongs to.
        """
        ...

    @property
    def type(self):
        """The direct debit type (read-only)."""
        ...

    def add_transaction(self, account, amount, purpose, eref=None, ext_purpose=None, due_date=None):
        """
        Adds a transaction to the SEPADirectDebit document.
        If :attr:`scl_check` is set to ``True``, it is verified that
        the transaction can be routed to the target bank.

        :param account: The remote debtor account with a valid mandate.
        :param amount: The transaction amount as floating point number
            or an instance of :class:`Amount`.
        :param purpose: The transaction purpose text. If the value matches
            a valid ISO creditor reference number (starting with "RF..."),
            it is added as a structured reference. For other structured
            references a tuple can be passed in the form of
            (REFERENCE_NUMBER, PURPOSE_TEXT).
        :param eref: The end-to-end reference (optional).
        :param ext_purpose: The SEPA external purpose code (optional).
            This code is forwarded to the remote bank and the account
            holder. See module attribute EXTERNAL_PURPOSE_CODES for
            possible values.
        :param due_date: The due date. If it is an integer or ``None``,
            the next possible date is calculated starting from today
            plus the given number of days (considering holidays, the
            lead time and the given cut-off time). If it is a date object
            or an ISO8601 formatted string, this date is used without
            further validation.

        :returns: A :class:`SEPATransaction` instance.
        """
        ...

    def render(self):
        """Renders the SEPADirectDebit document and returns it as XML."""
        ...

    @property
    def scheme(self):
        """The document scheme version (read-only)."""
        ...

    @property
    def message_id(self):
        """The message id of this document (read-only)."""
        ...

    @property
    def account(self):
        """The local account (read-only)."""
        ...

    @property
    def cutoff(self):
        """The cut-off time of the local bank (read-only)."""
        ...

    @property
    def batch(self):
        """Flag if batch mode is enabled (read-only)."""
        ...

    @property
    def cat_purpose(self):
        """The category purpose (read-only)."""
        ...

    @property
    def currency(self):
        """The ISO-4217 currency code (read-only)."""
        ...

    @property
    def scl_check(self):
        """
        Flag whether remote accounts should be verified against
        the SEPA Clearing Directory or not. The initial value is
        set to ``True`` if the local account is originated in
        Germany, otherwise it is set to ``False`` due to reasons
        of backward compatibility. Up to v7.8.x the *kontocheck*
        package was required to be installed.
        """
        ...

    def new_batch(self, kref=None):
        """
        After calling this method additional transactions are added to a new
        batch (``PmtInf`` block). This could be useful if you want to divide
        transactions into different batches with unique KREF ids.

        :param kref: It is possible to set a custom KREF (``PmtInfId``) for
            the new batch (new in v7.2). Be aware that KREF ids should be
            unique over time and that all transactions must be grouped by
            particular SEPA specifications (date, sequence type, etc.) into
            separate batches. This is done automatically if you do not pass
            a custom KREF.
        """
        ...

    def send(self, ebics_client, use_ful=None):
        """
        Sends the SEPA document using the passed EBICS instance.

        :param ebics_client: The :class:`fintech.ebics.EbicsClient` instance.
        :param use_ful: Flag, whether to use the order type
            :func:`fintech.ebics.EbicsClient.FUL` for uploading the document
            or otherwise one of the suitable order types
            :func:`fintech.ebics.EbicsClient.CCT`,
            :func:`fintech.ebics.EbicsClient.CCU`,
            :func:`fintech.ebics.EbicsClient.CIP`,
            :func:`fintech.ebics.EbicsClient.AXZ`,
            :func:`fintech.ebics.EbicsClient.CDD`,
            :func:`fintech.ebics.EbicsClient.CDB`,
            :func:`fintech.ebics.EbicsClient.XE2`,
            :func:`fintech.ebics.EbicsClient.XE3` or
            :func:`fintech.ebics.EbicsClient.XE4`.
            If not specified, *use_ful* is set to ``True`` if the local
            account is originated in France, otherwise it is set to ``False``.
            With EBICS v3.0 the document is always uploaded via
            :func:`fintech.ebics.EbicsClient.BTU`.
        :returns: The EBICS order id.
        """
        ...


class CAMTDocument:
    """
    The CAMTDocument class is used to parse CAMT52, CAMT53 or CAMT54
    documents. An instance can be treated as an iterable over its
    transactions, each represented as an instance of type
    :class:`SEPATransaction`.

    Note: If orders were submitted in batch mode, there are three
    methods to resolve the underlying transactions. Either (A) directly
    within the CAMT52/CAMT53 document, (B) within a separate CAMT54
    document or (C) by a reference to the originally transfered PAIN
    message. The applied method depends on the bank (method B is most
    commonly used).
    """

    def __init__(self, xml, camt54=None, force_batch=False):
        """
        Initializes the CAMTDocument instance.

        :param xml: The XML string of a CAMT document to be parsed
            (either CAMT52, CAMT53 or CAMT54).
        :param camt54: In case `xml` is a CAMT52 or CAMT53 document, an
            additional CAMT54 document or a sequence of such documents
            can be passed which are automatically merged with the
            corresponding batch transactions.
        :param force_batch: Forces each transaction into a batch
            transaction with subtransactions for each TxDtls node.
            Must be used for documents with resolved batch transactions
            if the bank creates batches also for single executed
            transactions. (*new since v7.9.0*)
        """
        ...

    @property
    def type(self):
        """The CAMT type, eg. *camt.053.001.02* (read-only)."""
        ...

    @property
    def message_id(self):
        """The message id (read-only)."""
        ...

    @property
    def created(self):
        """The date of creation (read-only)."""
        ...

    @property
    def reference_id(self):
        """A unique reference number (read-only)."""
        ...

    @property
    def sequence_id(self):
        """The statement sequence number (read-only)."""
        ...

    @property
    def info(self):
        """Some info text about the document (read-only)."""
        ...

    @property
    def iban(self):
        """The local IBAN (read-only)."""
        ...

    @property
    def bic(self):
        """The local BIC (read-only)."""
        ...

    @property
    def name(self):
        """The name of the account holder (read-only)."""
        ...

    @property
    def currency(self):
        """The currency of the account (read-only)."""
        ...

    @property
    def date_from(self):
        """The start date (read-only)."""
        ...

    @property
    def date_to(self):
        """The end date (read-only)."""
        ...

    @property
    def balance_open(self):
        """The opening balance of type :class:`Amount` (read-only)."""
        ...

    @property
    def balance_close(self):
        """The closing balance of type :class:`Amount` (read-only)."""
        ...

    def iter_resolved(self):
        """
        Iterates over all transactions while resolving batches.
        Raises a RuntimeError when batches cannot be resolved
        or on other inconsistencies (number of transactions,
        amount mismatch).
        """
        ...


class Mandate:
    """SEPA mandate class."""

    def __init__(self, path):
        """
        Initializes the SEPA mandate instance.

        :param path: The path to a SEPA PDF file.
        """
        ...

    @property
    def mref(self):
        """The mandate reference (read-only)."""
        ...

    @property
    def signed(self):
        """The date of signature (read-only)."""
        ...

    @property
    def b2b(self):
        """Flag if it is a B2B mandate (read-only)."""
        ...

    @property
    def cid(self):
        """The creditor id (read-only)."""
        ...

    @property
    def created(self):
        """The creation date (read-only)."""
        ...

    @property
    def modified(self):
        """The last modification date (read-only)."""
        ...

    @property
    def executed(self):
        """The last execution date (read-only)."""
        ...

    @property
    def closed(self):
        """Flag if the mandate is closed (read-only)."""
        ...

    @property
    def debtor(self):
        """The debtor account (read-only)."""
        ...

    @property
    def creditor(self):
        """The creditor account (read-only)."""
        ...

    @property
    def pdf_path(self):
        """The path to the PDF file (read-only)."""
        ...

    @property
    def recurrent(self):
        """Flag whether this mandate is recurrent or not."""
        ...

    def is_valid(self):
        """Checks if this SEPA mandate is still valid."""
        ...


class MandateManager:
    """
    A MandateManager manages all SEPA mandates that are required
    for SEPA direct debit transactions.

    It stores all mandates as PDF files in a given directory.

    .. warning::

        The MandateManager is still BETA. Don't use for production!
    """

    def __init__(self, path, account):
        """
        Initializes the mandate manager instance.

        :param path: The path to a directory where all mandates
            are stored. If it does not exist it will be created.
        :param account: The creditor account with the full address
            and an appointed creditor id.
        """
        ...

    @property
    def path(self):
        """The path where all mandates are stored (read-only)."""
        ...

    @property
    def account(self):
        """The creditor account (read-only)."""
        ...

    @property
    def scl_check(self):
        """
        Flag whether remote accounts should be verified against
        the SEPA Clearing Directory or not. The initial value is
        set to ``True`` if the local account is originated in
        Germany, otherwise it is set to ``False`` due to reasons
        of backward compatibility. Up to v7.8.x the *kontocheck*
        package was required to be installed.
        """
        ...

    def get_mandate(self, mref):
        """
        Get a stored SEPA mandate.

        :param mref: The mandate reference.
        :returns: A :class:`Mandate` object.
        """
        ...

    def get_account(self, mref):
        """
        Get the debtor account of a SEPA mandate.

        :param mref: The mandate reference.
        :returns: A :class:`Account` object.
        """
        ...

    def get_pdf(self, mref, save_as=None):
        """
        Get the PDF document of a SEPA mandate.

        All SEPA meta data is removed from the PDF.

        :param mref: The mandate reference.
        :param save_as: If given, it must be the destination path
            where the PDF file is saved.
        :returns: The raw PDF data.
        """
        ...

    def add_mandate(self, account, mref=None, signature=None, recurrent=True, b2b=False, lang=None):
        """
        Adds a new SEPA mandate and creates the corresponding PDF file.
        If :attr:`scl_check` is set to ``True``, it is verified that
        a direct debit transaction can be routed to the target bank.

        :param account: The debtor account with the full address.
        :param mref: The mandate reference. If not specified, a new
            reference number will be created.
        :param signature: The signature which must be the full name
            of the account holder. If given, the mandate is marked
            as signed. Otherwise the method :func:`sign_mandate`
            must be called before the mandate can be used for a
            direct debit.
        :param recurrent: Flag if it is a recurrent mandate or not.
        :param b2b: Flag if it is a B2B mandate or not.
        :param lang: ISO 639-1 language code of the mandate to create.
            Defaults to the language of the account holder's country.
        :returns: The created or passed mandate reference.
        """
        ...

    def sign_mandate(self, document, mref=None, signed=None):
        """
        Updates a SEPA mandate with a signed document.

        :param document: The path to the signed document, which can
            be an image or PDF file.
        :param mref: The mandate reference. If not specified and
            *document* points to an image, the image is scanned for
            a Code39 barcode which represents the mandate reference.
        :param signed: The date of signature. If not specified, the
            current date is used.
        :returns: The mandate reference.
        """
        ...

    def update_mandate(self, mref, executed=None, closed=None):
        """
        Updates the SEPA meta data of a mandate.

        :param mref: The mandate reference.
        :param executed: The last execution date. Can be a date
            object or an ISO8601 formatted string.
        :param closed: Flag if this mandate is closed.
        """
        ...

    def archive_mandates(self, zipfile):
        """
        Archives all closed SEPA mandates.

        Currently not implemented!

        :param zipfile: The path to a zip file.
        """
        ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJy0fQd8FMfV+OzuNZ1OJyEJIfrRdSon0TtGVHUJFYoMnE7ak3RwKlwBBALTTyAEGEQxYDoYmV4N2AZnxjXFiUsS+774S1zi2HEc24mTODix/29m904n6SRD8v2l3+3u'
        b'7M7Om/LmtXnz9kPU7k+A31T4OSfBQUTFqAIVcyIn8ptQMW8VjilE4TjniBQVVuVGtBw5ezzKW1WiciO3gbOqrfxGjkOiqgCFVBjV95doC2bmpRqqakS33WqoKTe4Kq2G'
        b'vDpXZU21YZat2mUtqzTUWsqWWiqsJq22sNLm9OUVreW2aqvTUO6uLnPZaqqdBku1aCizW5xOuOuqMayocSw1rLC5Kg0UhElbZgxoQyL84uEXStuxBQ4e5OE8vEfwKDxK'
        b'j8qj9mg8IR6tJ9Sj84R59J5wT4SnmyfSE+WJ9nT3xHh6eGI9PT29PL09fTx9Pf08/T0GzwDPQM8gz2DPEM9QzzBPnMdYHs96RbMmvkGxEa1JWBVSH78RzUP1CRsRh9bG'
        b'r00oCLhegUIqjUJOWWBXc/AbCb8oWk0F6+4CZAzPsWvg+lCxEJHC06uSxL4xw5F7CFzi/eR8OGkkW3Oz5pAG0pRrJE3pRXlJKjRsJj4TpyD38LODjYK7N+2EyAGZ6Ynp'
        b'SWQruYuPk+3ZSqQn24Qcskfv7g7PLbok+lyJFApyCV/i8NEV+LS7H63GMLw9AV7b3hc3Z2enkyZjugJFkj0CvkOuLjDy7l6QacaIsswRI7Od8DiT7MiFcsIHCBPJMXKW'
        b'Pc4idwbAc7xhYnp6tvRcTy4Kw8ePl99PC8c7nPQR1Cy3hmznkDadx5fJnTj3QHg8iBztHUquhpMbTryVPFNLri/DjeFhCPUZ5BYUanz7USPnjqG4ujCLNGZlkO0CEsjd'
        b'+eQehw8tzYWHw+Bh34V9MvGFOOiEbZlkO96aS2uCm5Jzkoz4UqkKzZ6prscnciB3D9q765dMJ9fyyDWoUlauEinrOXJqdgE87QlPoSZkV0JGUmJ2Et49zMQhXXdBi+/i'
        b'y/C8D4VFPPhYQlpiPNmaNRofoS0KJbt4chFeLOPazbBRvmE/SLGzLW6i/wvs9MR7EjyJniSPyZPsSfEM94zwjCwfJWMs1xACGMsDxnIMY3mGpdxaviDgOhjG0qr36YCx'
        b'iyWM/ciuQg2F/REylNivhZsQu3kwVkCn3OEUje2pY+dLNyOmaJBYDAhdUpL15pyF0s2YMiUatzgCRrTE/nHUPNSC7Fq4/disWMXXkWjqL0LfH/YX/ubwP8w6jOwh8KBu'
        b'2AHu8rzPdZB/xG8ci3Oqpdvdcv8a3jxI0YvP+x333fyioQOQF7mT4IF7Eb4FU6cxeU5cHNmWnAY4gVsK4zKyyc5EU3pSRjaH8Jml1eEhk0PJOvcsOuIXyDpy2elyLF/m'
        b'dpJnyGVynVwlN8kVcoNcC9fotPqQsFC8Ezfg7SNSRo0YM3x0FX5uJH4GX1YgfPfREHIBnyGH3Bm0qAaAdiAz0pSVkZOenUl2wo3tZBtg/1bSBHWKS4w3GZMS8CV8Fp/P'
        b'hyKukv3kcbKX7CL7yB7SPA+hHilhkeTijA6oRIeBYq8zhY4HdwzVc8e5NTy74o9xx9Fx7hh/HIa7AR0T6uHecX6Jgt4BIl1u5HMctBCj0qtYUmOr9iqdtXaby6t019Za'
        b'HXBy28TRXqHSutIoeEOqLVVWJxBsq1dhcVQ4vQp6o4Xz8nFGBw+l3O8+qdxRs8pabSiXqLvJaa21TPEKUMpMWkUVHLR8JBfJMRI0fDm5kECasjjE4zP4KXyAm74qd1YZ'
        b'H9BCJX3Dh3FH4FAPiFcPdaeoLAqiQlSKKlEtasQQUXs4ZA1fj44haC30gsNIr8VQ6A0k6uqBWbE7nKiDe7zvnrM/9BL0xgy0SLuQXyOsUdA89UK9guZZltTAHRPEsHrE'
        b'3tAfU3hQOSeGixGbNPXwzkba10iCCf25ydgtx8unWr28BX658KuBXxH83PBzOu/ziYb7XIIx5G+0jWSTdDolnfZJp5vS6bB0ek46HfVy2vvc0Ptc8n0+OdmryJmVOYMN'
        b'XBt04GV0YJ1FiWwFVG0RzPd6roE2n6/nHueX8bSibLzYoYX38qYUL1fm0PluOfRw8Gon2W1OV1lNVe2UR2mB9EksWtXfWl1WI1rNdGhNk+w1ZRa7c4qpNS+gkhLmjK3W'
        b'q3ZYa+0UW5Q2l7XKCfhT46iy2G2rrA6FhHOc06utrjE7ga9XWp1edZWlttZWXeFVlFVaHF7B6S418o4wWqOwtnULDahEJq0c5RkKXsFp4J/nVN9pBAWnhWsdp/k+QtDD'
        b'ORZS7gGQbRI+SjZkSmyLbCB3JYaQpkC9yG7Fion4WhsEpDVV+/p0ApJlCaDW5QqZmvINQDPXCEBNeUZNBUZB+bVCQcD1CjrZgvB//3D5qWmIRE23hUehwWkfwBiXTHql'
        b'coREI6evSkO7dF4eCKd2UNQMNIvd7WHqhgyDP+JRbUnilO56KauxXyiKXjhBQBElWa8uHYbYhCPH8TMZg/HdkSkADu9BpeQ58pxt6uV3OOcCeBzPX/ms5I8lleVZlp+W'
        b'x3386brLT1xdsO2b/AMbe06IjUlJFD8RPylJ3K262nNibI8RMZnTxfz5+bHFTwxOTdwSPTci8/Dxfcc33laJfFbZo2MKUoSKXihycPcU83tG3hUN5SfgDfXzLAlJcWlJ'
        b'PFLhg3zSYz1cfeHBwLm4aSi+lGBKT4w3moAgk62AawbFYnKCeIwcG32jIgATguFEt7JKa9lSc5nDKtpcNQ6zTaTPnPRZ7CKKGXpOAVig4xwjfS8aFV6hzCZ61WU17mqX'
        b'o86rNpsd7mqz2RtqNpfZrZZqd63ZbBTaAQWkpAzcMdoHm5W4mEKjzYw8peIBBzl6VAAu0qM7Dh4Mm0tOAdalgdSDd+SagPVshZYmT9XhbWQnUMHJ+JCKnHm0Vwca70fA'
        b'cYiJC8gjlAt+Zs4/EDPvgH6UtGo6oN8MCf2+yYxEg9ELI0MB/RbVDpMxbRqKQAYU8ahQW6I7kWJChe5ucHcQvh0GHUBO4ttoOBq+cgXLq05VQPHrpmmnliROiqpAbmDt'
        b'aDTZVD0SuOPzbjQCjajiWc5fcDzMg1iVApVkWZLzERMXYmZNHsmjsAiQkEcq8H6WccuUMKBAn/QMyStJPGhbixh0sqE8aqQK4V39QaoaZSC3GaAYx7iRwNA3JaLRaPRQ'
        b'cpO9f8YdjeLQ1Gio0sLdcSJyR8LNqWPGjFQiQLR7aAwag2+QUyzv5NV90Th0Ky8sr2TSjbICqfqDx9aNFNAichiNRWPJ7uks5+G1A0BjyosMqS2Z5DbNlErFG2Pw0ZFq'
        b'OBdBMePwxVxpAk8bjNLQl+XqqSUDq/v1lvL2BB7fjK8BMY9D49F4skHJ8qaHxqE8VBvNl5RMm7RkFXJT3MIX8La5+Bp04cloNAFNwKfwJZa7ekwimo+OlUF9p321PE0q'
        b'uQ4/Tu7B2JJdfWHspuHT5av01UljgJT3rUXT0XQxS6rsTeVC4M1LyGlgaTPwbfw4u11Fnic7ndCLJ+rRTDSTHEuUOvzAxFgn9Ni+TDQLzcJN09ndmdwyp4CUZA+ajWbj'
        b'feQyu4uvhkx2qtFYvAOanTaXXJXgHV0NhAcaHJuO4D+BNEhtO4evgwYAjVsJg5GBMkB2Z/lrhqeQazxKIEdQJsoESeySO0rqi13h5JoKkcfxZZSFsrotZV1Rv1aFdOgX'
        b'8zlDSda/MiZJXTEe76kn1zjgr5NRNspW4eMs77/maFE0umXQRJToRg2rQ6xgsnUByGbXlAgfr0I5KGch3sYyz6sbCmC+HCAYSgY+V75WKvgRcmoVuSYg8iS+iXJR7sAF'
        b'LO//mOJRIdIoFBEl05rWxEt5yY0RNeSaGpHrqTC0eVl4I8v7x/ieKAU1JIaUlNTrEldJeD14KDkZSns7Hc1Bc8iGKpa1eHEIzMFvBnAlJYnCY4XSXHE9Mj9UgcS1KB/l'
        b'a8kRCR8K9SCqp8zTpZRkGfr2keCXkWfdoTxagVtgqheQZ/FddluRSg6EwhTaRtZDnQtDyDlWxK8n9YIplbIQ+qbPxIVD5L65Q04PCYV+PECuoCJU1BvvYZlfdPRHk9CX'
        b'/UJSShZ2m9pXasNy/CQ+Hgr9uH4YmovmRqewrHP4QYBnaKAGAWLbHfKEacSnRoYK0OWzgYrNw0fKWF57VA9Q52tnQJdPyjVopDrgs2vIlVCYXNeB4sxH89XkGMvcMCUZ'
        b'LUS1jtCUEv67YrNc4Zsj9LgRUSTZhBagBeRSN5Z5XPfRqBKN4wTQH/6iLZa45lNDRwAZjFXrUEnkhqGR0s2/aoejEhQ7OLS2hB/ZQwvkX6pFAz6ZiRthKh4gG1ExKq5f'
        b'JA3yjqn4Hm7kUZQRPYoezYVB/ub777//fJIS6GFlLcDTHZ3XTypaXD4G2dHUSeGGkvz3qvsgW+a3f+OdA4D+/3pc3ORfvJYhpEZvfn/1ueLPx/UefebJ0a9fm9V0rVu9'
        b'0GPgJ3+2v7h3uCHjb/Haz3Ne/dXMgR/1rUf9f/rWjV1bwu9sO7phz4EZS7VrLu+N+DgjcvMLdw+l9Xqz+anEDV+fP579z1+sTu3t/WybftOojTleZeazb0xf/cbsb4dP'
        b'vRZ7anrsmfHbf/FczaDf7ri//KfPfHj3yS8/F71/edJozv121cu/vhb3i/E/fUuZ+OaQxLe6n39z9Pm3wuxvJsW997I+qXT/ny1H99VODV82Y+ey/F/v+yC6Ytz3I5Ka'
        b'lJbzl156+qvQ5reUS1YZV/zz0ahD70yY1HPjtJz43+ZE2eZXHNrWeLh58K9eyX0q53DTd9+/eWhc2ovKOXcqxkde/NaZ9Ond5kZVftjitUVvfvHy0UcyP/48/FBc6cF3'
        b'so1KJjpk4P0m0piYEwaIuTULRAdQu/E5ULvxXXLZRS0EUVOHyCIHWZfKpA7Q4naxl1fjvcUgCSbk4HOkKTspg5pDIsktgXjIepuLalXkMD40ANTG7Znp+AJwhZ6qcXzP'
        b'gSrXAMZ5yJl5TnwhrSfek5MURy0mZKeAupFdApCxc+RxozKoyMJEiPYyRYAgo5cFGXeZmQq5TIq5DgddhYKLYDIulSj47x/ox/PfBf8p2qYF/t8P9FPw/2r9KeCn+ZdC'
        b'xTPpOprXCxouAiQfgKvQfUfPjnF+WUsAWctd5hhDb4wN1gUg6I33S1T0vQqfRBVxKIhERQ1ioZHqVoEKX8b7TNlwIdmbjGSdEu+ZhDf8gDhFbS8oQJziHkicqngwaV4t'
        b'iVPjF1PJBcWVpJbYnxw8WBanfjuYMh+kmVrqtquX95VkdLwJ3ySncslOv5COj0yxfRMXwjunw+O3tqs/Kyl+4fKu43taNh7f2PLE8M3DDx1vGLbZGPtqpiXHUmndrbgS'
        b'm38gNXHZluIt+qxpL/dSHZuwz36s1+su9LMvw/Z8ccLIuRigs8ZknyxONmbQiRE2wydsd4GevST0BB3PXeZyg7RtdljLrQ7QyCRUpWokekyj1PnE7QkBKKBwQuaucWCi'
        b'Hwfoi5tpkXQao/UR/wqCBSMYiS8g1yke4CdSGSokm4zx2SZjUkY23pqckZ2ZlAHqXg7wocfxNi1ZX7LgB1GirYT9H6KEr/C2KKHKYdIO2Qzyy9OhVIt/ZCI5j/ATozWS'
        b'5NAbGNPgn/Foakl+44ocNMv2+akkzkm76+Dgxs9KFrLBv7JxGVem/XDaywO/05/Rv1z+cvQZ+76BP4r+uGSLXhXxyIH1IKiG9rpxPzTkORHUL0bLzoFcdlga8tAoSQGr'
        b'xcdd1KK3Nja8nfYFJGwnaGDxuEUeu84xIrad5tUWH7QSPuhiOEq6HJMCsaHsB7Fhsh8b6IvbA7Dhb0GwYTg8MefagyhZeFsgItSBrPksbgkhDeHkwg/q+wKoXA+v728K'
        b'RiE6ooM6p5AN+/wcPZpvgOamlNjvgyTKbpZrFeiAGEONolktQzXSzSvlAtoUQhc3ShLf0k5EtvPVRoUzC9LvzYv/EFT0P5W8WlpZft76SclZS1xZ4u4/l8x/4dauAZuN'
        b'h7hXyzMs+y5Glnwi8m8mGqYMyytKiViR8lTK2JHbRrpGRI9wnBHQpJ+EH3D1BqRhZu/Hgfs14HNZ5DY+lp0Imlomh6/is+EuulTQM84IzJfsSM7NJk056fg8SENP4As9'
        b'8hVj0vGeB9Xcw6qtK11m0W01ixaXhDTRDGn4SC0XLdt0FLzue/6+Y4offRReBc3uDQE9XYQ365xdYRLveIReT/WjEy1odys6RX4RBJ0M8EQ7PIs00lUEvDXXmI2bctmi'
        b'yRByFW9dqCwOWVgmBAyxMhB7pkjYo2D2faVHVa6SMUhoADxZowAMEhgGKRjWCGsVBQHXwTCIFq/qgEFKicd8Nm8k0ox/naJF/pt9+kq48pveSpQ1XkKgiVkLkW3Mgn4K'
        b'pwWeGBb+qu/2K2HrUnSK3y7PTzn9z1Tvn2ZkPsGn9jh9/dyo8sbLxphffvq3p5zFKy15idrdJ3/9ox2z9oSPGbNsjmnljGVbf/zk6qK//GZlfshjg3OvWB1f1qz8+/eH'
        b'5lw+ZXtl+drEvbHv/e0gCGiUzQwan8/M7ma8SY14fIIrqsBbXbQFUaRxUmb6uFJpEYrDR4c6GS0KI2fxtUw6bRtJU66a7OGQhmzngTFef0TCyaczHmNYeQ/KBfalyOZA'
        b'4t5NbjF5jzThm5NIYzY+z7sQQNzEzcbNk7qSxVSdPmqPqboKaztE7SVRtz4aQFA9IKoWOB7Pa/hIHoQjlSPVj65Kiq6AoxQDvaoyt6umPJD0BZ0jgMaU5zumtUVdWujh'
        b'VtSN+X0Q1O0PT/CRR/pl5ia1Qdz+puH4hIIcIntcnTNBSmr9a1KoXPnfMkLalu4d8La/hLfKIT9GzTDElwv/NuKv0TKN+8tyalRB41L05lX6lWXSzeN1VPlFKSlj7KOU'
        b'j8o20b+lSkJUSvk2oTRvonQzNiIKDYZzytrPCoaUyK/vt1OTDopLWfu76jdHZkk3qzJGgRqIDCk2R99L1mnSza9z1QjEmIiU8m4x3JBa6eaFFUZQ2gH6sjnpf69eLd38'
        b'ovYRVA/wUnr2qq2L6SndDBs1Ga2kgMbfjJ84uUC6+eqjE5CL1tPYjZsxRJRuqkJiQfOHMteWWSpWJ0g3E/slgVYLr3ODBn80T+YE49Op6Q06ZPkzkf+YWC7dJIpUtI7e'
        b'rIuqPWe0SjeHrKKKJrRItTJsbTeXXKZCEkBT5m5e0jh7unSzpro3XYnUpOifGzxzgE66+dXMsaCSQtttTcZfR0dLN++mzkHHKKAi48j3xBDpZukiK3qVAhr0aULvkTOl'
        b'm7dGlqOf0tfL+lTZtd2lm1aOavFws9/KURcHyqRphSacLibGpoyZPevPRaOlm0Pdq9HXtEoTQ+f1NhrlgXNSrRy6acGCgZUmGVCPucyKgFI4Vd3vw1Yh24YlJxRMdf40'
        b'yVv0eHY+SdFt/v07/1z2we4zmwaP7rP50a+1vea7tsycQDIWW8uq3+izXagNFT8s//HL3x05Mvheev3Hvxx4t3ne4npsf+7LP2qGfandrFQfOD74E+73mrOJXz4xe1HK'
        b'3pihtfy57ycv/PDCWXVt5OjX+qVdLrg299TlKy88tbUi6k76B6//5V8a0yvq/EF5ry8s+UnL27891/zVluWaZzPtLcccdz7dVvTSvw+O+vPPl9z9Ztdi5egfDVz07zkv'
        b'bhvct/Aj/bMz8z8fMrfxdwr3R9XvH37jEcUjbw7a1/tvto9L7xm/ntlrTK9n3g2xHvzkywND//TxxweGrMBrTrz33tKf977y7dra7D+ufP9PW37afe53r1eM/37X7SF3'
        b'L5nvttzWjjgX8ULzhYg/fznP/M8p69d+q6zZueRvz48zCkz7dTvIUeDe+ODqNgycMu8585jEWIQPjMtMjEsDoWnYNJiioFjXJeNGVyzFvcOkGd9NIDu0uDk5nkMKNwca'
        b'8C3BGPYD1PSHD13Q6kB7P6XFpZbqpebKGruN0lZGkOdLBHmSBnRRjTCYyQ8RnIGtAEUwWSKS0/FahRZkCq3vX2h3ZleKP+j66OA93fdaIOga0LwdM/zkHITXOqvFEUDB'
        b'u2AwnGOmn3jTIq60Eu/oXwQh3nS9OiaDXJGIdwbZThrxDrZovJNszcL75sJAJarQZHJFRW6R/eTZDmqHQj47l9DpR114UDEfwoVwYihbP+BBu+FFYVNIsWBV0FXUTWgj'
        b'V6yEa5V8rYJrtXythmuNfK2xKihrKOfpiusmDdwJ8QC4Yi1z+tF51ami6LA6nTllqoD6aFDAYgNlZ7Krg9/1oVwjMxlVgwaYjBqYjIoxGTVjLKq16oKA62BMxrcY3l44'
        b'ckuyhsddAOcBCOT+TQPwFvIsWz+1Jf7yIud0wtXYSTf6bhuuxykRii9+daVvj1Fpb7vqG9S/mL9pxIjmP2wrP2r5vjn0Z+eXjzrksix5Sfwmp8hSf7Rh+YUJzcsemRfx'
        b'7ekPtrYs2vm6q+TH937Wt/Tzj4em9P/iWl7s3djHfySe2Nj4/uOainLXxazXS29l1v0bPTmh342X0oxaJs4U43Uj8TqyR55p8jwjT9lcVLjAt0aMB2FnG9mOn4Ph3y4g'
        b'xXgOX8GHZ7NpCM05VJ1gMpJtQGBVIPM48NWRZHumi/oAmePxYXzByHxgpJLJszyGWYqbmWy2nDw9IcGUJC3HneKX4SdS4gtdVHQgT5B9ZD9uxDdW4J1kZ2YS3ol3qlFo'
        b'DE88eGdvVrNHkg24MRdoB2lKiCJPGvHTChQeIriSdYx4hKaAnkCfJ+IWBVJp+NgVPc34EiM9vfDmGtyYTBqSTemStSbSYCKnBbK+FF9lnSIuTQTot/FF0OUzspOoM00j'
        b'T56ZvayjaK95YOLSSjzUZnO1dYXZzEiGgZEM9JiCkxaNY9hSoRYIhUr+V3CrwmW8NslvSmRA4xXK7E62EgjarM1V59XU1tCVcNHqVTldDqvV5dW5q1uNJV3pKCpHOr1O'
        b'Q761Reo64qDr244sP/2YDYfvW+lHrw0d6UeHuraR9Dj5R6eDk62XoCXUeaHSyOW0cF6NWV4MhWuF02ovb3UVkLpOM8luqSoVLVMioJS/0vsqtCrCB9H38IFBGjmv0kx7'
        b'zpHrh+MH5pgDh27wqiMftXN26KzMcqnMELNvHDotN/Khyq2QylWbpVHttNSooKW2Ea8pClAbE9DQhxOsO6zh0j8etad5Qo6t6sQ53knnUeXkpz8r+eSDb0t+WlpZriv/'
        b'HchmUX/hX3w70chJutTRIeROm2kKbP14z4jBEn4Hd78IszkD7H9sDjFiD3NI23NVdx8utMklOZsIjjxaSuskCASQ6+/IuXDoDv3njGVIjtbrPwuC5sEBAcmnf8ZQQGUz'
        b'9VAym71as1nyLIVrndm8zG2xS0/YdII566iptToAB9m0Y7Owde7NZU2mDgEWp7PMarf7Jn/7CdxC0U7KBllYQ6gf2X0kGzQ0iFfyXOT3um5MrAA9MZZzM1nqabI90pmV'
        b'bsxIMqmQdgmfUUc8ZNekDmMdKp+du7hWti5yxUKz0BzeHAG/sOZwG1/Ow5X8L/JNqhAhRBATKdsP8CyMAJZLGX8IsHCFlblRbULUkaqJB+avFLUsHcrSakjrWDqMpTWQ'
        b'1rN0OEuHQDqCpbuxtBbSkSwdxdKhkI5m6e4srYN0DEv3YOkwqJkWpkOs2HOTplhPWyNSEaNXE8fqrANxpbfYh4kb4fBuX/quNVzsB28LxRGs9eFi/yZeTJJtLYJoEAew'
        b'tnWD/AMZrEEMViSkB7P0EJaOkt5uVjdryoVmhTi0SRBNTDCR/IRpb+k94eUhYpxoZCVGQwnxrIQEVkJ3UWDOX8kg/JQx6nl/mNYQ8CfflRyY2zwxqrwKGwixDjqywbAv'
        b'p0wdMP7Uw1Hvm+85lIxIQlQI7T95XH2epPpyvUxe1Eyk0gB5UTPyomEkRb1WUxBwLfl7vt8LKFWbGtK/9Gqby8Y8t5zMh9sit8cGjM1SXUa9t9u/MqHW4rBUGWjbJhhm'
        b'2uAtB3s1fVpqjqHGYbAYRiS53LV2KxTCHpTXOKoMNeUdCqJ/Vun9OPpyomFa+nQjLSIudfr03KKcQnNOUfa0mfnwIDUn0zw9d8ZMoyloMYUAxm5xuaCoFTa73VBqNZTV'
        b'VC+HiW8VqVM5rUZZjQNISm1NtWirrghaCmuBxe2qqbK4bGUWu73OECdaax3WMguUYzQZUqulPDangRnGoXBoXNCylkOnisD7OtZX7j9KpSawitMrnw+9r/9B8QH+1unL'
        b'MiOX3pcT0IkFuUkjh48ZY0jNyktLNYwwtis1aEUlSIa4mlrqjm+xB+lhH1BojgwRroLX+EHK8bFvqSxf6j8vT2LbUmnS9X9QVgd7fkdrbFgOcz3HB/BdcoRaMBNN1Mk9'
        b'cx5pyGRe+P3xCUUVOYCfw5vwBmbKqBuyA/Xhjs0NSSnRz9DlIzfljLiJ7F9IzZhPC/h8HmmgAnwy2QpXuQVSUUVp+EJaTnZ2OnVd3kZOhJCbo3qwAmepqAdMbGqIoURn'
        b'fCwOuU1wcyJZT+7SpewEeBnUyDlpkuhO5XaymxxYbaRuIalqEPs3yo4ppRxoGyguXI1KEvcs6iUZXo5GU8eub5bzU0vsc/WPIDfbbjEN354GbCygeNJA3fKhrsn5aWRb'
        b'lgrNJqdV5Io4jJVywk19Xm6NCCsp6TMkdIW89nmWPIevU2+NEWQDddYAPe2YreeLf0TOe/C4YefJITsnUhVtxq8/+9kr66dO32P6w7HfKVxphWmjYqZtm/F+3hbV2EOP'
        b'Dh5rtR+s+OfnK6/PPWc6+G5L70Nj66J+9uvKvYf/kIq518tfOe6pWNnT/sn7jR9NXpOW2b3qxtraj2rzv7LOblyQzhv73Jgf+4+nT95bVLdv/9nf1H7wZOLy0wt2bTiU'
        b'0vfnn1wo+GLG+xPmHEzevOLugvG/dzuTh/FXBsxP2Pj6sLfE6hHPPHEh8uO5Xw27/NpvZkUV/MQ07O9HTB8deeT57NTbywcaI5hqtRqfJs+GQicZs91J8WQbvpmXzKPu'
        b'2KPQUCs2M4H3GYCPU68G2aXBSq7KXg35+AjzPcC3KvCpTFNGdmI6IMpOaQMEacE3e+HriupcvFVa8XsSH8F3EpLIoTWtPpeFC1yD4Nlk0jDev07GSrhGztJSupNNArlF'
        b'NoCqxjZYcJPojhMFbolPMnFQxAZ+JG9i6iU+StaLuBG00lvkjlQFJTnIkTszRKabqkeRi1S0hMEnVxVIIIc4ANUgvUxO4UOF9OVhbHMGTAwlucNzgImXWDfhyyuxJJji'
        b'3fiMD1GZggkS6lEXdai04H3kKtUjm4xka+gUKEXqDqm8BHxNSTbjJ8hupq6SxzPJTVZgFkee7A3VOcrhXTBxtjNBGJ8iV/ANeG7KVunwbnh8k8OHIvF69nJ3chafoLXN'
        b'tpZTZxBqStdXCBMW6tjjWfg6KztrOt4sS3H66cIssiuPLZNBQ64NpW8nktP4JN4h+Rvr8Vlhxkx8zLdMpv+vDWft5XQQgG3AumU1d4YsomtGKyTPaJ7awxSg7Or4GEix'
        b'e5CO4FQqFRf4z3O87/pfWhUoexLFNPmKl8ThEEm2p4tLnYozAZL/A6vtRrVUyOi2pbMy8/wFM3Gb0ueBgXrD0P8Nojd0qP8DK4AtVFll8lpn6p/Zp/61QvGpxPeHFPoF'
        b'IMp5QD7wsZ44h9UiJtVU2+uMJoAhiDVlD6OzK8yltrJOq1Tqq9L9wbQCID51Cf+BtWzWGVQs6RSy1Q85oWsR5uErQFvuyEY+rTEI8Eo/cFOg/PPfwNfK8JdwPkMDD3PM'
        b'ImmhEpJ2VpulPmOJRu6MrqSj/7Qyjlr/xOisHtW0V5bRXkl+ELnqv6tJZlc1WeavSdIPy2QPix6bGH5KteisAi4/gqQUMk0EYAea6gzywBrsbC9qp3X4v7HtbDIK9090'
        b'EDinUwXCabC1m69Oq7WK7YMFFYbpEB1epHtjZc2qADQZaN1Mt6PGkGepq7JWu5yGVGhNR/k2DpoMDYcXl48xjTClGLuWgOmfEnU0uRcaOcmj+8gUciEhJ340ZXeKqRx+'
        b'unSOrbh0OeekblsDh175rOSnpWmWOGtc5Cclr5Yq3X+CNF/6cfTL0WcWf6x/eaXKsHPAgfXXlIj0D5lu/bFRwazH+oEgOlNuGsBJyQ28T5gxF0vCw6SaaW1lm+315JRP'
        b'tLH3YNJJaDY5Rxqz8MZFvt2jwO/xusfYVpW+6YWZVG5ZjK8jfjGXDACe6soipqYmKGutJcDjCT2mXRMDrGdVuI8RyHmk1+a1L6zV+rUSDivaWL+2BjXyti0WxAjKF3/A'
        b'm4laB5CHe2hvpgpAT08HbCiwuiSLgNvusoE+LNN4t1PSednmbIPLYal2WgL2cZfWdSiIljGBmUcmlGRDHigKTpYKq6PkB7Qw+tfRBCr7xMxx7kQrUyfyKKWk+rW6NOSm'
        b'fUAaV4JQSB1E2qhV+DDe1IVqhW8Sjw198SPJRXDDx9bPSjIAcxMj/1jySckX25eU/0n8Y4niDeP2dxNnThuiM05dHpV3auP4I8M3AwaPDENDvwx1Z68x8ky+J/vNS8ju'
        b'iAAtwKcCDNW7qPoIsujNWT7JtlWunV4cINmSc9NlT6gfWil1Wl1m3wgxjs3QNEJGU5AINZLsp+VW9fRhVYd3fLCYyMUksC7drViOPD9Or6KYzPkcZtbT/8jvgmB15/Af'
        b'RiDSt6t6Zyygyc8CGA96UCw2+XaAUX/lzh3AmBsNc6Gh5kS/G82Dun9Rc1wWF8Qc5591NQ5bha3a4oI62sTOWGe1dYVM0IebhgexaXRuyBElawlrvs+5EwCZDPnWZW6b'
        b'Q+4dEa7KXAbRWmpzOYMaj+ichxo4a6p8YpgN+KnF7qxhBUhFSx1cbnU4OzctucukGk2flg6c2rbMTcsD4SWOcmWDw1crgJXuslA+/cOko6NDpibHTV0F8SbyBL6cmUMX'
        b'39mu8ZykOWm4Ya3fozSfNGTNSRPyjbgl3bC41OFYa1scgqZVhFeBXnzdTfGDnFtELrUxubS+jfBVsrcIN4LmeJLs5ZaRG5p5eDM+LG3UfDYOHl/T4cfp4hc5C5x05FRW'
        b'Le2aPk59vME9N42umxaRhsS5zC2gEbcUpiVSMNvTs8g2DqjWKeNKvG8wOVPII7IXP6PLm42fcdM4GXNTtVKlZpOnpHrV6n0F5s1LmqtGeY+p8ClLvO1E3ycVTipE3Stv'
        b'Tvrps9RbcOacx3Du16OyXlDoMBoVs9OuHLJemfbXd/gxL2lH7fv9yaUNb/zo0Z2X3/zVn+2HvxFfTQpfxG+4Vbn7nS9+pHhzzvKf/fKTub85/SlZVht+9Pdz33/0g3H3'
        b'n1/33ZOPHUo4+3Nv5YnyOm7w4f4/6hFrDJEsDM/jY1mkEfTxbJ/WHVrNk0P48EhmBglf5AyNJ00Ji6sZlfRR0v74mgI6vplcZ2YQ3EKuLgjYdtotMolsAbWfUeIL+BrZ'
        b'lzmdPNdqDUO6CKF7L7xOslOcnZURmjlyQAdKbV8orc/fxesSQI4gl8mJQEHiVgYr3zmK3EowReEtHba27hvPyh+EH6cL7blQ263UNCHbJchFso6t0S+sJnfh8aA5pmyV'
        b'bJRwxskuhQ/kJkMJaSuh8G2LHdhK/HupmFuMjrEAHbumZ1UHdtCmFF8VGIn3E8OueIIQkK2VMTwGh11tGUN0EF/cLmryMNq7wgxkrVN2cNbPDoYzFa2V5nWllzyEWiIv'
        b'Iivo5p5Oa3HOX4uJQYnd9KLp7W32QepDPZSqHNZyr8ppq6i2it4QINNuhwOk/1llioC6UhO2zkcFMySW1RojB3lCZScdXblOZmCKBiUwMCUwMAVjYErGtBRrlQUB15JK'
        b'8/4TXTIwKT6QJO8xXhCo5XS+qkTbJXEC37v+LQed2/9ZL0hvsVegB+k9C9X1TIbplmqqTFnkZ6VLgKcFZWZ07Qr4S0HuuDEpw9mqFV1REqn+CnpWp+D9nT/BMMtuqTCs'
        b'qLTKa2LQYNrm1hy+RnUGvrrGFQSMwwoNqXZOMKS2F6RL5OY8ADfsqMxpc9zUBRkfJKdmtmWGpEGmyUVpcCtfZm3ciEi8B+8hG0eRa5nkWgYaQk7pycECctFNxSET3tI/'
        b'05QUnwGkloYwegY/6S/FX3paRlFcRhLI5lk5IH+T03115CzZuIRJ9G8PS0e78kqVqKQk3rlyAGJ8duxsvBUE+t7qICslSRnZBYHSfGNBCLlnI8+w6mjIbXKDNLI8BDTF'
        b'hHTKQBMoS2U8ewSQYWmlJC0xI8uUnhSvAvXBqFuWiPe66aZ/fJncNbXh8LQpFHIcEHOQ2BONSRlKtGo6Pk+eCsFN+KxgFJhuPKtoLgMsIMUUTomfw+dcj7HISPhMLGlO'
        b'kN4egO9lU6+tJ/jVM6EHKb/IHdgjISNb7kIORQ0TVpD15BBZh+/Yvnr278jZAJnmXxjZ9/WESJKiU+S99tv51h+9dPr4S89PC48o3bXswNBhZ7eu8vDfntmbHfPcE+8t'
        b'SFeOW3zgygfqId3JZ6+W1hWNLnh+07Z3j+z4Yv9PqosjJn59/V95vzzw17cO7/rN0+9nn8h7KTl7eHzu8Y8nnt1VEtrX9dnp51NWH1v6dql6geNf7z79yN+tz62cPuG7'
        b'yd/Fp/zaCmyc8rA+OZWgjuOTuJHGeinlhuMt5KSLOmg/Ru7gdYyFtzJwfIfs9DNxUL8k8/xVUx8YYr8U4E5gcsDtcexpAj4/MTM9O55sVeML8K4GN/J4PT6lYeb3cfhx'
        b'fCB0Ft1U0J6Jk+a1kjfr2TRywxcPi4POPIaP4lNkFys9kiO7af024Qu5zEVWZecHkqN4p+Qqd9zsZptgcgF3ybbsRBiUZAGGk+wFpfIAY/I6fDadrR741w6mP1IhTCCX'
        b'sBSJxaj7P7L4h1LuKNMPxudNfj6vmkhDYGj8XF4r/3Rsew3PzPzaf6uUq6ICOa1cllRLlcS36Z48B42r5vC0ZfkhD+fmq5BK8vgFgi1+PghCErrYVioY+EYQqSBYXR/Y'
        b'QGik3m6+BnbGjX/u58YDKOsAwsoYiZ/zBJoFjQrqedTC50DRs4wxDuqL7KCRVRzFSHI6FGvKzGa2TOGgQXXYcoZXoNb7zlZMvGqffZmahZge7Q1rq91SESpAttrK3moz'
        b'cN3+j5aWOsM7h5nOcjpeaylVRQo+WqHiFN/zMFb9vucnqFhQHl74z856hU4byfFaKbSPVhHN8TFtc0QqDBzfn2Hwdyxa20SgiOedWTmSUM8h7Sp+xgiyI3pQB5anlc/O'
        b'79q5VIl8sUIUipU2VKwSFcVq+GlEZXGIqCrWiuri0GZls6Y5opkrF5ojRE0TL+aCoBTqiSgXmGc0dRTSWcPEUFHH3Kb0TXyxHtLhLB3B0uGQ7sbSkSwd0ay3dpPCC4EA'
        b'Rp15wj3dyjVilBhNXZ+gxMhmPcCNELs3MS9ulq9bOXWm6iHniIIyqRsV9dWOhjzUraqX2HuTprg71I0T+4h94TpG7Cf234SKezA3KVQcKw4UB8G5p/zGYHEI5OolDhWH'
        b'wd3ezPUJFfcR48UEOPf1qKCkRDEJ8vRjEbFMYjJc9xdTxOHw3MDujRBHwr0B4ihxNNwbKJc8RhwLdweJ48TxcHewfHeCOBHuDpFTk8TJkBoqp6aIj0BqmJyaKqZCKo5B'
        b'mCZOh2sju54hzoTreHY9S5wN1wmeELhOE9PhOtGjgesMMROuk8Q82SIjiNlizqaQYpOoYML5HK8qtYr5bz3dRlaiE196ILlwSZEnQQykYc4qHNTvxyAJb2V1fpeidn45'
        b'bR3CHFBAldVlKzNQx0OLZBstk2RQuEHFSihTMq3Y6ww11ZKgGEyQM/JelXm5xe62ekPMvlp4hZlF+Tn3J1W6XLUTkpNXrFhhspaVmqxuR02tBU7JTpfF5Uym6fKVIDy3'
        b'XiWJFpu9zrSyym5UeYXpWXleIa1olldIn5HvFTLyFniFzPx5XqFo9vxZLbxXKQHW+OC2MYa1WRipp7SXdyop/V3DN3D1/EZO5JYKznApTJ2zu4sX+Xo+BtFYog18PSDz'
        b'Gk4U6rnlyJFUz1FfRXiLhmMTjnOiqifki0XRaCxaw1Ur4LmaXjUg+l49MiugVOVxoPZmlahhy1Ih75uD6SLtfdvkcW51bWv/QmcSPusJSb+wSGWwO11Ys6Qum8Acxgpy'
        b'k0aNGD42EI1EUEvSy6m4b3DWWsts5TarmBhUKbC5qAoBLNDnxcYg+3RECWVBS3HYSt2dqBUT6OMJJaK13AK8xY9GJaCn2Moqaek2qZ8AGWU4gGAd2/YpHfP73W3VbFWq'
        b'tTXDhjiHeTmTl0v5lDKNT7+Hv/uCKSUlx6j2RrQHS5dTLPbaSotXO5e2ZKbDUeNwUOXE0UwPVGV17EXMpsAEh6P0cAx1uU2dcd3fc7IvrkKr4qJla4eB0/BakI1WhUuD'
        b'//B+AUZOqlhnQsS//F4BPhB+p4Ck9gjDhq2u1moogeEoAzZvN82QziUlJgeNifEwK6B7u6rW937ZpjdzTQiOhB3A8T5wETI4On+X8KH+3hDYgHg1FqeZ+Xh6NdaVtTXV'
        b'oNt2WhWel0MM6tH9MuYs4K4qBf0YOkPuBQMLJug0xFlcBrvV4nQZRhhNhiKnlSF5qdtmdyXZqqHXHNCXYkkJxVGLuMQNGWmGtqV0XMFtuzuJYzEg/OGC/buTOGa7f6At'
        b'sO//ORi5KaqlUplEaqwryyot1RVWg4PdKrXQBYcaadEWclkMtY6a5Ta6IFtaR292KIwu6dZagWtMp10LjZtmqV7KzO1OVw3IjIwwVD8QEZAJgK9KZlalEtq/bjbpJRJD'
        b'aZHfzA79S91fg6zl0UDOVldlTSsHSzQ4bUBN5WLoa3R9vY0TbSdtlAuaQENBTyiRmWuQRcEuLSKlNTU0mp+hPND04mZDIbYbhqDkcYXVAZN0OXBGSyl1FOjECNNGuKQI'
        b'1XE/mj6H7e7rv7Z3QlJaeiLVejPnUfsE2ZEGl7lFcRmJ6Ukq7MH7UVWkhtzj8WbmUFoyNQw0yMvkxhxye3FcRpKJmv0TcvANciI/iZzh0ajZyopSIzMhFJCT+ILTlETO'
        b'ZWeQvStUkSgc7xdMM8lTzFmT3CnrQRqnk42tZou4nKT4zKR8X7mZShBRNfjZUJHZHMiJcLK1kJxzsiBH1FUP7+SgLjtwC4t9vKxkUQHZX4+bSHMRaSJ7i6jRIpcj1x3k'
        b'8iy2oLEsdoXTlE2eKc1QIgEf4PA6cqyWRZvGm4cgZ5pkz8iEEs7jiwrUDaqLz5eRWyzGM96q0eOtZLczjkVoUq7hyIXq4YW2BRbCO1+CDJM3Te7eNDl/mkU3c88X+18p'
        b'+FP+lTVNmz9bt6N75ee/EN/mev3ijaG2U6+N2P3kwUvP7ln9561zhWmzFVVbDu547Y2rG9fNTWiOnTTToxsbXXI54905u7767J/Pzrn9fv8lN19Pc3NLjti7f3bqvaHq'
        b'bI97XMVrb5+uX1c469mTez/s979Htmw+ozxlnFGc/OHsP9j/8Zs+t4/+5W+by419xlY/+rsl4SdTb/1p3OYVUS9+m+b52e+uv/j3N0jk3xf0GnvxkZX/7vtZX90Hjo//'
        b'on3rD4/c+/vkFQcmGrtJSx578U3oWhpyai5ZTxrVSJHE4Qv4ObyeWSqs+HE+ISmkgmwjW5PTSJOAdLMEVclKaTfP9lJ8GTcmA0LYyTYOKZI5fA2fwycld9C9I/GNhIxs'
        b'vB6fzoKHAzj8JF4/U1ojOYb34ItzyDpqRslWI5WC15ATWcwF1Jq5OpNWCDePz4TXenD4hEjWuegSArmeOrGd+UY23eDtZD+5NM4tNer4rJ4JmXiDyRjvQ6FwclWoc+PL'
        b'zEC0iOzrkQmz4Txu8AWDGFIgGWZatMtZ4fh5fAheU+Rw+LIG75CgXyXryFFqWElPNOGtyXRGwfsGg4K0zCU35+OrzMg0Fd9LymydYrgpGfCIJ5eTVCiePKckG8jZbMlP'
        b'cws5WQpNVeP11FBDpwaHQkUelMk7ZL+LhrQTyAEaU4FD/HJu9PzUeqtUy+dsWN6/ObfSv4Pz8SUuGqSK3MMn9ZnZmZnZJrI1MZNFYiCn8S2oaTzeocSXoHnn2CCMHI9h'
        b'5HPwBYE0J6qQYgaHnyeH0h7CVfI/2QvZXSKE5ra0n1mPplJC9pj0r+0eIduNqPtoNJzpvkiFbFPSc5JTqXSXOpbSM79Owa3qI4s8QcH4dlKxTY//iXMoJ73KBIlrcFBR'
        b'QYISJclqhNb3+iaI3ajLOkGZx1BXnjQssguLGwYCAhcQ2YVn3wJ4oNhA7/8qmHgwXeJv8jYbSSqkcgywG8qy/IKZLCVQkcEpy/kduZG8nNBOzGgnVAQXIjrytsKOAouF'
        b'MsU2PNzHUmsor6drKXVUGulYM0tZpbROX2WtqnHUsaWfcrdDYstO9j2IH+bv7dWotiJsgFOjy+KoAJ3Fl7PLxZNq/+qJhCG+xROfHEWlH6szUOH/ATEg+LZ0jeSfdNCu'
        b'W36IRgDJK7FPnVAvbbC417/v2v1CLb25sMyeK908Nvmm/h3hS0DJqcvmc2fK2BrC1JRZzrAwHnhCM0d20LXsLcluaj7EBx/VZ7YRKvAT+HzrUo3MbS8W0uX+ecDx6apL'
        b'q/cAUKZV/SIm4IuzbLl3fsI7z0KRXw+dm90k7Y//x+v6CL7vtBmTNgzceexkeubmhe+/Pq0wZ3rcjg9Hmb9Zu62q1513f3l+7rjUryyWKyv+0mfClUEj/qoY/lrc0G2a'
        b'p37zTlrLnJWbBrw17f1PXvnH6bIaYsgutr17Uz2uoPehX2njF439pbri+ZD907rlav/wysujh3w+/K3Gga98kL9z0NWf//JuyLx/FC/6buTtV0yrH3/r5iSN8Q/dSxe/'
        b'PunEmse45WjMtqf2GfWMlCbjG4sDlvzJddyYhO842JL9VNWUTH8XKFD4XMGGt9rxVbxFotdN5JqrA79IUpGWiTK/wFvSpVBDzaPxXrZmpUYJ+HkW3Sh7NttegXcD897U'
        b'juqnK/HFBTLRtxRJRezF68vYmgDe7pI4H7nel7k5kmfwbbIloTUyRyi+Wr+GJ+fwRXKasR0XbiimgZCSk/i+5JAUB4kcI1tYD1Thy26JLStje0l8E7jJfsY4I0BAbPTx'
        b'zdsD2rLOm/gEfsJFpVR8nhwh55igmg4NgC6pJadae4UnV/E2zpyswafI06NYc5Ln5SWwVRYlUi3hk3BLP+iGnRJzvYh3Luno8UbOkMuaibNYlmR8pH9CYjahnx/B50FU'
        b'DMd7BKjNTQcMzrVgG+YflMepZcWBcbURAVxNM5nyM5W8ESKGi2Sci4YA0TPOJvlF6KkvhF7mGXJRbfzhjrVlX13EAuGlvK0OEDdow9szrZifB2Fa7SrQQS+npIbp5fTj'
        b'N1Qvhx+1noWJnIuHa2EjF0M/ncAHpthXPu7zQ2z3FUNMI8qhQbR+Xp25usYs68xOr2ApdUpGliD6uzfC7F8GlwyRc3h5R7iOh17kV/Xw2VXa5etgLfSvP9N4Bw3suwUb'
        b'ecegeo61BS0VHAbaJkf3eu4YbQM6zq3hqkNdgsjVszTNWS5INkS4VtBvHzCrBJ9zf5ife1bZnFCNskrGd4YA2afmKaY30wsYPdYFUbaqWrutzOYySx3utNVUs9HyhhTW'
        b'1cpGKdopshXKq2RM2quRTLo1jk58hfXmWgd1A7aaWf75tLNo4GAtc7rR00h3nOp7Fc92uMsd1+aNoAPPuo1OQZEaQaErqBl0CVfOx/i+9HE/UiotjjYyUWqq44h/UNt9'
        b'/kFjNgNMh9lc5rPMRAcayORnnaJgJKuJDwnlWlTSWqgpmkGvB4Buh09qM93ObzaX8/KeiYhW3JcftZHN6LXCBziW4T79DIrIHefXsE6o55ZKJjEAz01q4R0vINloCNds'
        b'Jt4NUg2V2Wx3mc02WgtaPBVuV4X560GfPXQ1ON9Y8JMmO16hoF7tBLLVbK6CO44fw41AqNYgUP3jbwqcNt18E2IpXxMhwV/CLaWWKnafXjFznTQQtB6dICxUx7rMbF7G'
        b'y77tWibn899r+YCK0RwdKua3FOpYd1CgOp9xUgLQSfOroZkrfMPfpturg3XAD3W7wod83JQue70CxnRVkF6v+E/GWukjPPyUrsca9A7z2mBQrUFmmN/XnXapb6b7HdwC'
        b'iHTH+UytYGbzBgrp5yjAFu170qaFbeTWwUFb2IN9VYgRXn4jL08wB+2NFqF1ijFi6gv8cdd/t131YM5bRNFs3kwHnbEOFkoxYN6zx0FRPwDDpM8ftXbHO511OyVvrMRt'
        b'QbrD0RHWA3RHbLDuuM8lOX5Fof46eKOd7lKzuYnW4V1ahwAyRx903lw9q0Joa4PZlPJ21VxW4m4fNde1oeYdoQkogK4MRQF0Re1CjIZAOrp9k9nuL8Grz6lxpQP3tNLN'
        b'RlaxFQ9YN3S2hwYonhvQcC8vr2RoWRSmNkjAMjwwEkjxhRy/66pXWImHgiFBR1htkGBcYJ9EdESH3v5e6t2+lygpclA5vBU1OvvQkdnscritom252XyETo1W+qsFMWFV'
        b'pL+6/mz/eY17+Wvcq+O4Qo0HPUiNdcC37TU1DlaXM7RfP6T9GuWvaOvT/7ymMf6axgSr6X1uyA/WU81CApnNF/1VDMCymvbTXxFYuzbCabfA2rlo/ejSNdSk9Xohv4Zf'
        b'I8i1FDbS+grSVTkv8wivCnoEwIL4/QKt4h9QIPX0aRmUenqVKypr7FbqzltlsVWL1s7ETK3ZLJVpNt/kZYqhZdpMBE/1G8X3q7r5W+zL2bloSQU6id2Esq6XEdknPgRj'
        b'OSzIWoXZfI928Uttu5g9eBBo2lZo5T8ErbbGaTbjINDYg86hRTNoLgkS50cleS3zdpux6Aw2aEhm80s+kSWyDecqDQa9K0bueLsLSLZqkEZe9VOsVjjswQPDKe8STgib'
        b'qBYo8Cd+SBGBc5g+cpxBQcyk/nlCPWzpzFiKHBoXqJ3MsYOjX+2jnKMHVIN+r28JVeX4Bv64NEfkmcGQS5nzKS30/kC2pGurrjDU1qyQFoWHp0iOEe7a2hoav+c+n2Ly'
        b'csNhppzzDZdXs8xtqXbR780FTCKvGkqqsLlAqbWurPXpb50aDqAfGHCz+XWf+KthEUXpN+UCekTO1MIYDu0WY3I79z9Hk1ye017jogHCWmha39b0DOnycmuZy7ZcijEN'
        b'5NRucbrMkmHVqzC7HXbHLVrac/TQ6kjox0+vxq+1hzJLprSAymzjTHt13KGHF+gB08OL9PAaPfyUHn5GDzSKuOMNeniLHn5JD0yU+h96eI8e/pcefkcP79PDB/TwET18'
        b'TA9/pIfP6OFP9PA5PXxBD1/Swze+PjZG/v9xTGzn+UHjvL9FPT9ciHknCgol/Vhg638EH83x3TvxQlTyXD+OH6bhYjneoOX0Kl2oRoB/hV6hUdGzTqETNEr60wsalV7Q'
        b'a+i/LkQnSP8xAvNJXIV3lDnJdtJEdudJXomaWN5tIOc7j976TjufRF+81HIFi96qYYHbWPRWGr5NDtzGIrWKISytZoHclCyQm1oO3KZj6TCWDmGB3JQskJtaDtwWwdLd'
        b'WDqUBXJTskBuajlwWzRLd2fpMBbITckCuamZh6NSjGXpnixNg7X1YuneLB0B6T4s3ZelaXC2fizdn6VpcDYDSw9g6SgWvE3JgrfRdDQL3qZkwdtoujukh7L0MJaOgXQc'
        b'SxtZugcL1aZkodpoOhbSiSydxNI9IW1i6WSW7gXpFJYeztK9IT2CpUeydB9Ij2Lp0SzdF9JjWHosS0vekNS3kXpDUq9GVGxg/oyoeADzZETFA8WpjMynesPp/pfC1o2l'
        b'719uvybk238ZkEmOItcuG/WqYC4eZZZqShhLrbILm8vGVmR8jhgsPJnPuY36YkhLH9a2izTy0lBb3wuqFAXsgi2hZNgibeERa8rcVNT3l9ymtBqHr0CbS7KMSa/6Vlqm'
        b'p2YXzpBLKOnE865NIr1cdiSxGEqZHQ+KkxbIAnfpJkogfW2VvStdDivtkDblWZzMmZNWjrl3LIeSLHa7wU3FK3sdZTxttv+2ebkNw6WaKzVi0o0BzmKO8j+HhvLAnqiB'
        b'd3MOnY8PupgB8zi3RhCB55mlo4IdleyoYkc1O2rYMYQdtSB10nMoS+nYMYwd9aIAx3B2HcGO3dgxkh2j2DGaHbuzYww79mDHWHbsyY692LE3O/Zhx77s2I8d+wP3FswG'
        b'kYPjAHZnYD1/bBD7gm4CSLqKNcp6xTGYo8c55yYRrnugNYpqHbunOs45dolq4PBD6hXUJrhG4RpKv7W7kXcecg0TNfUKyXTriqN365UbBQ4tW94A7VqibwAh0Pl0BtoA'
        b'kJl0EJLj+IpKB6MlxO8wTbqeCIw9zPJyZi9vNt9Xmoc4hzjvD2lfSKWFOj21+k1JVlOjV5cPbN9WJRmBvSppjVAKJiqYbaJXaXZbXQ4aHEban+ANl0KV+/epOayUMdHo'
        b'3I4qeqDBHKVwJfVMLGi7xRHEPmkxGEqsdTtAnLUCCCYSqJkp3WXxqsxVzgoGeind9qc0W6UT2wQY5nuNfVIMXiqrpAuZLJytxeV2glzisFIbt8VOIxxVl9dAjVm/2spt'
        b'Zcw/GUQRiVb4H1uqXK0N8kab2ceA2+68p+GEK+nyqxPqx+YqFMPOUphhbx9zuy4HMRbmoZTHkUD7QgtVdLic1OeaiVReNYwKHRGvPtU3LtI4qJ1WF31gVElOAVRa86qW'
        b'rqBfqw6IW3AU/XDQBDaWH1ORj8puEczvQdXuX9PhTqf/PD1GyMHl9cyqoYe0glvVo137HypmsxTs2BHGoc6dPHuCmiP5nsa2B+V3Qp1UyJwJqpe2bqRMlOIfuGrkzafU'
        b'B1AEAm0rrwOyG0AOH8Inlak29EsOnVa2j6+y9x1tg2XRlfeqGlfrjlcWDNRoMmRbmMu9C3RhYENVVid1qvdlkpxIndLW0sAwJOWOmqpkaFuN2+WEZjHi8eBbeB22rtow'
        b'wN+GtvG2OjaBRjJ9CKj2rqAO9kMd2j7WVjuwctTQB0awrsNsDfPDNQYJs/XfgnZ3BTreD/p/Ug1SMFmnu1TeocH81ik82ZdGjuXUZb2YuCUVxNYnqXRUC69RyYZFuQkS'
        b'HcpkKGi9V26zUoCyqAGlQ4ZWTxs/F3Ea4uV+ik+ES5uLnX2xuOLZSmS8FBAr/iHwY3VXnTXc31mjOoY66QQ/U6fNS02Gw8yHiLoF5EjfFTka5a/HpDZ77GkkEWtp2932'
        b'7eszPX/mjOQZM6cVPkSQOKhPeFf1GeuvTz4b/QDmL/tf+fzx2zkGmQwzWMgTyQ3KvsJS55Q3mRuqrRUWqsI/VC0juqrlRH8t432o7nNuCqiwzOMNcQVz5xU/RCQ/gN6t'
        b'K+hT/NCHMUZRU7OUysTSVnkQlWtra+hOKBCu3NLm+odqeGRXoFP9oMML/RtbHhyEvDkjqisQM9pSMGAh1AMtAA1rK+uc1MHNkJeangNz3P4Q7WvhHNFdAZ/dtmtbgdpr'
        b'KtrCNMRl5s+c9XAzsXtXoDP8oCXnvmoxyVWTBKdWIcAQN/PBYUoxIR0xXcHM9sPsGzR8gyEu+8EByoPboyuAeX6AAyQPRhAuq+k2EHmqSCE18ory8x5uvsR2BbTADzSS'
        b'0Tgma8vCyEPFL+zdFZS5rTShPeWiEjr1tKHXcdNyczPTc2YXzpz/oHRTxp4+XUFf4If+RXvobfUGk2EW0IjZVqhPNZMxnX7lPVgAeCBe89JnFdIw7omG2XOnJxry8tOz'
        b'U3NyC1MTDbQNmTMXGBOZRDeLokylXGZnpc3IzYYZJBU3KzU7PWuBdF1QNC0wWZifmlOQOr0wPZflBQjMoLDC5qSOrLV2Kl7KIT4epgv7dtWFZn8XDgwg6pKSJSGmhU1G'
        b'ixN68WEoas+uoJb6oY5pP3CSLmgypLbuREvPmZULQzAjZzal9BSVHmpu9uqqJlZ/TXoUMm4vKaAwhCLFnZoHnCvyUv+ArkBVttJ4OfwK29YoAbK2GpIC9ZqHIQf9ugK+'
        b'tC3RayV21LPbQK1fQZiKz8OEraTMlQE6hzH3Nx1bWWR+VbV6ei1tfKUrJ/BTbISjmeZXMnc5tuXWzI7HVHBUH+e4AIS5PzFf8n6mNjC/jCOJXK3WuOAimcmoceho03fQ'
        b'tlrooTWOAbNm0HgFjl2ILcO2hodut9gUSj/lJhdZLchrlSo+ln2BierLKm5V7/bKa8A7nY8UtceJPqerQglksGGiKxwrBXnxDrTyDqqy30cm2PJagBfQEuRQ0xXh44iu'
        b'AFdIS22VUkzcQRz9ShQ1bwR1e9PIpg/zakGuuRSYK1hlpIydtzs6oDJSYF6R8zkefCWNBquNUtJDOvHCs1urzeZ1gbUJbrBg+XKMg4KteDFDCluj8urbmcAYKuxoizQ7'
        b'ffjiDWtrAVPJBjC1zLnZ93y9Ktn4pZRsXwpm+lJQyxeLLeLVtTF7qWSrl4JZsPTt7FuhgeYtlWwX07SaxSTzlb6t2csxm5PRx5FBr2jAxgePzuaAmYjeoVYm6q5AV6Yi'
        b'Q/kR7deffiBKhrqT+4r/LupGp2fVg+XTKTRajaBTuqnbyNDk7NDlYbU6YwbZnpCTZTKQC9Q1newUUHylEl8mzw4NGpqR/rHQAa2rYCK/CbGvFgqiwv/VQqV8rWJfMJSu'
        b'1aJa1EBejYcv56SvFRaHSPE4irUsCC5P43LA3VCWI1yMgGudR4DrbmIkXIeJUYyVR3uj2iF9lg109cAoaopAUkB92Sk5NjOXDzNHF7XNfAWNRiCIfulAwTQDb4j/g8Jw'
        b'WVUjWuz0M3ID29tFKURz4PqL0+cVUsCxVV9fIRpfGe1pHO3grYLMviS7pJZb1ScInIfbAM88z8Z0xQB3+k2QQaE91DfjZMHK3BW8XT54D1NiSVclPt5pif5BpzzN50Li'
        b'E4B4Rzot1dJZ0ZRk7KFF/7zTzumU1nfm1yHLgK0w2zJbRqH2+WG2Z6syTEbR/2/Y6hMUVhrXeftkxtp+L4DfO4cujfjcrZwhLgAse/czZ7ClgrMXXDPXKnZNrxRLBUc/'
        b'l1JaaoO06piaugRybPMV+4ze/aRAwbeKRgkobQ29MKxdTYe1zS7WWKW98NIuAhYNxrfbjnEJEIueR/LUlD48zz7CQDtU8k+howMsrbYW1G3f9oHQABAsayeOXYJFFA/7'
        b'pCStvENFy5xSOjBn1sWQv3Ps0crY0+oT1Dqa7TAnE148Lcj+oyCX9AwGLLhA1s7VSqLi9WgG2sjJgIWcDuKv362Tbmug1HORiu7noPLM4/wy5qElsVrekUt79qh0TZ1V'
        b'vZyrPS7SD8a0+GofjVYlBau9q8ZlsQNBoitZzilwQel8TVXtlE57xatk75ylWP5nOqOC9grLk2PUt5eQWh14GKq0YkmrMMFkC/YxC9r/jiV+AeOHVrAWQ84tgtx9GgS8'
        b'WMVivPI6QSPoBV1IhOCmO4U0c8ltmTkXkOMSf5aYM7lGtiaaODSDXFBnkeuWDiw6Rj47t3NtWDQML/sXDiuLBeqgQt1T6LcFRS1lwHAFjJcy3MNhxfRzwkpgxRLLVbI9'
        b'td08kZ6e5Uop8BUwdbXYXYyRPz+sFnvQaxrkijmwqMVeLN2bpbWQ7sPSfVk6FNL9WLo/S+sgbWDpASwdBumBLD2IpfWQHszSQ1g6HGqjgdrRQFia4gh4Os6GrBEb0Slu'
        b'B1ccAU8j4SkNj6Up7gbt4FiILE1xJLuWQmRFhZjE8XJYLxpQpPUbjHpPuCeCtTbKE+3p7onx9PDElncXk8WUTSHF0c3q5hhxeBMnTqBwoEcEcaQ4ioUW606/VyiOlp4B'
        b'JBpWi96PEUcwljbRq6N46HOr8HJ5Xi7XqPTys6d5+fSZXn5mAZwLvfz0NK8wIzPTK8yelucV0gvgKi0fDtPTZnmFnFy4ysvK8Qr5uXAomEkfFGc6nmB0aHZ6njHMy8/I'
        b'dNCvikBxUGRavpfPSvfyOblePi/Ly+fDuWCmw8EyTC+GDEVQh/Q2c90XNJ05TchfKZACdCn8IdMVDxoyveMHUjuG+FbkuKlWYo4nNyniu8jWXBNpyqYxSdM4sz8OKYsC'
        b'akpn2xGzEtOz56TBdMig+znpp1KnkA3h+Poostu2b/ZvBCcNrF2x1PJZyfLDfyyJs8Z9EGdJs9jL7aWJloUvvP2j67uGH1g/si+qeFr1yZxVRoHtdyQNC6NCcUtimrQh'
        b'kmyZw6Nu5I6AL+B9ZIMUOeHpleQQoR/RooB3LKexBQ7xK8kWvEHaVXkJ7xiDGwM/0oz3Psa+07yK3HswQjFbpreMOPs2RsrbI1PZVwGiA3Gp7ReQla1L7Y44SpuCftsV'
        b'eBzLkebP5of8rOALR70+8D/yhSA7IIPWo0wTMNgUSttoxpqAz4zTeSeF9GmNZqxpCAHcCgHc0jDcCmH4pFkbUhBwHQy3KDp1/P5fnxz2+b7BeDd+nBx8LNMXgxCwKSnJ'
        b'RGPbsuiwdNSL8lbgTWkYWAfZURtKduEbQ90TKVUl+0lD64uAdbmLSEvSXHmfdgZpAvK8M3NeHNk6TwP4q0D4Nr4UGpaPj7G94u+56Of/UERKzPtj9pWGIDcL/rGD3CK7'
        b'2XZxulccb+tPLswm+9gLLw/XoAiEUlKGvjdKWdcPMbZQQA7Naxu7vs2ucTVaUKCO71WHD0Ux70ZyXJmUmZ6dmbicnCBNRg6F5vDkDNk9mkV5mbqGHExIo/vLR60le0am'
        b'pOBNJZloIL4h4LtLqtj3CfEeN7mSkEO3FzdlF7VuTE+ZNyfOlBRHGpLjaQDfGqOGXEtewqLKdAsfnkka8RZzelayCql68Pq15DhDSymS7gm8HT+fgFt6kGuJaUmQA9/h'
        b'x8C9De5UeKzHu/CWBGkgWrfB15G9reDmxLGI7XlxUrXw5jQB9cObw/Az5AI+IPXrFrPNuZx+347DTyCyATeTnRX4OfdUeJZlTQ78AmQtZCuMg9E7im+SxsTE7CIp5r60'
        b'Kb81WCU5JejITidpYa3oEebOlJ5Mf8xItmVBO6JmC+TJebluGu6THOLIrdZuGzAhqfWDAAENoTB4vI1H+Aa+Fzq6ilyTvtDTuACfJ3tAxVGuRKtQNnkOn3dTOhwZTY4C'
        b'+7+yYjm5jrcBfm1dQa4CXoX15vETE9e46SwnT6Xjy2kWJzyYSz9EEJeRlAitzZCg5cf5KwVVxnvILS0iJ8lpN91+Tc7UkhMJ0BWN0DWNyWRnQVwc0MCG5JzVy4oCv0SA'
        b'1+GWEDQANzMzQjfArY2h5Ca57iTPLMNNKxZZHLpl5Cb00kgBbyJboM/YxwOP4qsq0kg/5ZIUTa6boHOVKBLvFfBFsh+fY0i/wEi/Y4kMKarnF8cbFiMp1NBGsqfIuUyJ'
        b'8JP4NiI76ddfdlbamltOKpk737dfvV80Z2L1tOERX3tV/xq/sl/Ed0f3P/bjwk/3hJ7a2byvvHv0rryvt8ftsm0YmKQ+9sz4qaZdP7H++5u0UWWXJo+cuLjgiXUvFntF'
        b'U8SvvgxT9Ntw+cLtGQve9v7vnBFzFkdlZcTl/fvVrGN6x8mWaavC5h+M/zbNu3/BP168M+LTu3HXX767e9bkvf8cubrw8u6tl3qMSuh2zjl72Dtv9Hk9e133cZe/+NO+'
        b'Xe8+O/7LXgXnVbd3N6+KenHo6be5X424sq7+5d9MOC1O+ejKs7lfDpx696MpLYv+subDj976SP/jlvrV+1Kv/HxfXdKId/5e9BTf573LH3407aOJH//6TzvGv1dmyv9n'
        b'ckvdkzfu1f/vIHfe16Ev9S/698yIPbOysl47O75g/nl97KOHH9v10p2fvbtnjmel6mT1jz7p/s5vP6sb+7tPdTlTpm+7vz1j+/7BPS/Vvroye9tXW74v+/mz/96+cuyO'
        b'lf3NPyl4bdrbU46tjHrtm/5Dnt/813frjQMlltgk4qckntg7Vg4TILPEPWQdC98wY2lvmD3020+Z+C79/FMovsST0/hEDPviQsyiPizKAN6Z1jbWM368TPqy5DPkCD6I'
        b'G1fow7QOcsNJbk7D511hKhS9TChQFrLvP5E9+DBu8gX6cS5NJZeKpAhLTz6Kj80ip0ljVuDXHjaXSNz6En5+BPtw53Zj1RrSwCp3kScny8Olr02cJ5t64DuDcWP4cnKz'
        b'ltz4f+y9B1yT1/4H/ORJCIGwREQU1LgJIwwVERcOZAdlugUEFEXAhIC4ERQQ2S4UcaLgABQFJ+j5dQ97u61tb+28HXba2mqH7xlJWMHa3nv/7/t5P7dWDHme55zznPmb'
        b'368GVyvtzy+PgiaKn4DaUAmcc3ZNHtxB2OlvReEg0CVXqMDiiEvQ5G5MEuVwmGFJFKIGYTDhieCzBagdXZ0EJaiMsVTUaqDABM7g9YYnNGm4aIIAnV2CCij+EjqTFEv5'
        b'rgjZ1RiocIN2aKUQEMbQPB2ODFRnmq3WQKsl3gp2WErMTaHJMhMvP2jJWo3fIFQkRpdScVWkFUOgHNU6uw6fD8UhHgJOPE8Ap9VRrJpjliZQFIDOYHljgwDyJs1Kh/MU'
        b'LgMa4SQ0ERqMInQ6IBTh802BdjgQePSB6IIoawZqpB2Ijq8hjJ9hBKw9WGaNR8GYk/rysBt2JzF5aDs6HEOQLfAU6AdHQl3Z2rcNEZlHofMUNWM23oUuEG6lIhMyz4w4'
        b'cSw/DBr7seer4RDe7Yrc6OZ1bR3ev4w4aRgPu/DWvoPhg1SjPBMt/1gYOYlDUYWnK5YKcfcNgVoR3jabJtLpEI8qoH5tYneuMuHMWS60P+wkfXFNI+xdcVfhngrk+6OG'
        b'+AwZPa25eRQw3FWhDAlDxeiCEZTiewZCtWi1Eh2jxUfPhgMT4BrhHdWfHRYRwlALtJXOmFDYjAgBq8IVz4y2JWHBQjwbt/NwAp2EI3Q2ewegQnxDkEsgrhAPAjog8ebj'
        b'Id+IvehhtNVu0QrdDaggjNUSiGemk6MR5OBlcIXW5GUdh+9SuqBCN0dXbiLdyI1wZ7QaGRl70H7N9LCmLXGCrYN1wCvWeLri8T4K2zLIcYLKZuPpX2S5cl1XmRw3sdRN'
        b'ZzhmiqkzPlCKh5uig0Oi6Sw1wsNzniyqng+ieijwnxYiF3MhnDE6Z4SqaAejRmgUs2FegCdeYRijixNjlVYI7cnmhoXm/xROO9X7qcid3kPkNp0loWSsIt6OIpSKeFuB'
        b'ncCMFwm02rvASmCFr5vi70l+rOQR1uXxdXLNWijmxXxHpCrznXX8Rn5aC9b26yZGd2JxrTfVZknpApdFxCCmIhwQqoVEiZMujcvQxyCL1UuXJ65KfHL4k3qJartAW5SK'
        b'GA3Yo7R4SsZFLdpFgs79dN2wgjDsigEFwfCb/RVKU+Ml2nfqzRQsEOmM2V0r+0tWbBqvV/o4i7NQV81DR0pZosuwYK2TafFIusDPP3kgrvZdpUu0wU5LHkOKI9Y3xMVQ'
        b'eFSyuqNtf5em0+xxHWGir39wJI2LIlFRf5u4llnHSQC8JiMtKanXWs30tVKeVHy3K75dRmL+OyK0SEto1PTf4s9VzXjca1vqG+BEIxaSk7QhCqtIYAju9cRUkqyS8Pfq'
        b'xl1gtqTTSu61Gdb6ZtD4KRItsYwgtulDDf/Wm5/hHvPm/fRVju4dlbhrxZ3qpdtqVzpW5upj2j5H0mc2CLC2z1FtX0A1fG6jIKLTZwbgq+xRrCGyuN6pYMfSupMEf5EI'
        b'ltD+vSQwgA1I/uvCHdQ1FkMtUy9P06QkUE7YRBWFC5fFLYsjERwGy9ITMM1ISYwjkU2ymTQ3hgyvFuGWBgZqkb+1MUHJhhFytaDgsbGRKk1ibCxjrO2+WgmCvdapT+H/'
        b'DJbEIsWyOwdgdcE3j42dFZeiJnWQaFP8BQuQMtysNLJqlpIMkAQZsePHZSTHJxPnqEIWlU4ezhyv8FasoW11WpmWmpG2lDDuOhksLB2XRLa+rDh1FxRkXYoRATXuiQZI'
        b'/uthkxT0mElCZfIvJ/NEaiIXTt/w4Vexz8VLkry/u/MSx0m2C1pT4+UCRjdTGYH1DSq4MKklQt4ht/hpHSKC7j4jUdKyRAp+do9k1ncVOLhNYse1I7qcZeqlKUtoR3S4'
        b'QkgBrEDCXMucIB2UtTX4hQaItNAoXc9pLsfsw54ntYaw0dvb+Ovtr+joVCa1Qbmz/t3wm8Fu1IyFvsIwolOhFqgMploZNEGruTuqjOkdpZOASDBLcpLwL7Ld5hmyI+td'
        b'Zp3HbJ/rDpGaiMBPZwV/Fft57Iqku7E7lgXESZLupAi458KGvSGEb6fhsaPKbeG0kZ2HDr9e5Crt0AVqAeUek4suSlI/ZhAtnJ9gENXaQawXdQLON2ix1SFjHdSP8SE8'
        b'xiN6G2Ort3oZY+XUVP0Yz0Bbn3CMnZVkjM/am0/C2laJnKfmPnRAhmrZ8Isss+GsAJ3QiKkZa/BiOMqeEY0ZNJ5gHudPST5k9JOQYv3t49s/Tli+LGBpSFxI3IoP64zO'
        b'vTvg9b3heyPmbp70zMBtA5+xGX3jrQkhN8yqB3DnjCV3bDN0bsXOsH0G0QH0fUyFeaJd8oLuA2M22EJqyq+1NTw4bDh4w4PQ6WQ8hnvfrrfet/jIgCzcS4X/He7yJ1wu'
        b'HnPeEKmJ5lnz4kyyXF6KX/6ZIMks6U6IkOv7HY8yTfFSIe3wmpNkWJ8zpAguDsOqINqCanuMW7e4BzpKhhaPqXsP3wINgejY8Xrh6ialynsdFkOUVQbr+W9IET2HpOep'
        b'I1JGJg9a+S6nJl9vmz02OPuDODO6dYn8BLPO3+yQz3qcKdQx3etuJBrTQxdjcR69nyGkPJdez5CbT6DtGQjR/E/0pcHp3VMWxNM7hmsQ0tOg7elPneMIp/3CiqXXz5cd'
        b'rmLev+EPhD88fE0upNYf//GjoMiFGFNEvgLUCjvRhU1TmSWkGB3iepv+S9IMWkK81NTQB4f69iMeG3QC9shDXcWcBK7wqNwP7ellFIMetywsvHpq1DQaqfdRJOW59TqK'
        b'Lz6Jzs5qIB3cw7XnoOt1kjmtpSg1ow4+nTOdz+9DXX1dXOr5RvkDqNtvYL59vkOSg971J30i119S9wlA+lBPGKKfAJOU1CMkRefhYjAUEacU7LGlfilrOM38UsSOYY/q'
        b'R0tVcAEuWBIfBvWrWKEzcBEd4+EyPgqvUTcgnJiFDhPnyjo4Ex2AT8YwdPrxThbYtkaKLsD2OXIx82acXE9KaCGdB/VQxqEdElTKLjXAIU9o1og5btBoOMihcjgO7fTS'
        b'INjnKoUWI9yCWk+4wKHDcBS20HM2BbWo1BkC4qzLhgIObUuDSg3phAzYEyYlPaH2J5yNe6FpCD2yly5DV9UEyBFtRvuhgkPblegCdb/IY4mT8voaThYbIlqXytwv81BZ'
        b'JPE64YIsURUc5dBuODOX9ipqWw8V7F2gHm2nLwMtSdQR5QStItJR1vLu3QNNGSo4HxHgTMzezBFVhvaabIAcdJEWq3CYMAbKxsTAUXcRJ8AdAZtx4W0aDzLCUIqOdnGB'
        b'EvQW6pOdHQO7UPG6MUERxlwU7BXDBXQOdmgIIc5AdNV3DKEEcOQ8OI+JGzVkYaEzg2KgUsiFQBvnxrmFoUMpvzx69Kgi0QjPo19MLXxjU3IknhzjWj3ojaqC1xNnqbY2'
        b'KAigNN/FbkFRjlCImxHhKIfSmIBAIjztCKVSUzh5O3Gq+SJ0cBH1byZjSeo0iWTofB+ZSOtRO5G23MK0ndTZs0tm0Sl0xQzOxc/XxJLObotbYo5vLzdHm90lRrA5CmrE'
        b'WG41n2U9UDIpHF1B16AGGv2WrTFJ6r/aFK6KsyRou0mYGWqCXDjmjg4Oh2vr5EOgYKIC9onRnhly1DxlLFTZob2oCpVoIskr18SMJ/bkHHPOQyJETVHo3HzYJUaFkI92'
        b'OaE8uIaHoiTSPnkjqoPN9ujaimH2UDcctaIdaCtqSVoHeUIPR9yO4iFwdmbfUHQKTtENhE61JQvsBWP5W0s4q9hF45au4zQkxmQO3lmhKLQTY2wJ7ivGGqvzRUZ1Jo5t'
        b'gFbpUnQENtMy+dBAroxrChPFxq6QWas4DbFcoFpXOEzeo8qEk5nhD9GLV6KdoagCnYbLcFjggbZA7cQxuJ7KWLxOT8O+qNFwdD5u9+Z+kWhLIipYBofgovFydNUqG8vK'
        b'OTSUYADu4YNQhCoSQnvw2wa4BhlZ9yMBKahejv8n/spTJtAKFeaRcgF1vZuh5iQyC/DhASWBLni7wGPcPwhKJCL3RQOoD1kWAaeCDZDgSuZ1nvudOXC3y82SjdBW6su1'
        b'C0LFzkpUZsiba8CXOwAu45aR3SRwRJQxVBBNQMDxqEQwA5r8NSRCZENfuOIcgDttRyib/m5Bga7hLGaCeOmNx7vN6ebbDk8nXujZ4a7RPD45B1hCbRTapyEBIFDgLJBm'
        b'Qgt9A7wOoh2JVywBSlwcA0LR2XBSYAx9mpSD+1aAKvxMUY0SlWw0RSdhK+cNbeZQNNuWDnzjCnxec//w4LnYkJ1uZvhEpRQ4eKPAO2gwcbUQP4sETq2AJh4VoAaUoyGn'
        b'ow3ag/IjwuShDAk+KsZAPAiHCtNHwkm0GQ9oBexYKEOnED4UAoai9oChY1CjiDCe5FijKrul9CCBNriIv2mGZksTvL8XSeCcJTRnrNYIOBu1MMwHbaF7nCoSbY4g5C8t'
        b'cDRIiHe50xycthHRKA+HqVAYLHfFnVAYosTNctTJ14uDdAH6i2QStGU5T5mABuFTqzUCFUdCMSH5MYJTAicB2gd1UMaOlaNoN9rspZZmWghwRbvxZgJXXOlRAHlwhRDb'
        b'YIlZYLLWmwSkbPOjEQ7WcG5acIjSGE7qvFjS+Tw0RKNTNLLEFp1HBdTfej6+w+XKwV46iSyVHlCepXdeuuFZ00ybIs6cQCMAUKWC8MYMFqAjQVBKK3SKQXtJTEUYHMPV'
        b'ydFJEWdmJeyHz0gNkVpQS/+FzlAsp+D5BPmeehNxIaNjRqHNRkn4ixo66PjE3gEFwbp9WsBJBuFjfC+Pdm0KpD0fHIe2OTu6uim1HjGzZUJLKFpA27fADpUFB7qgPHRc'
        b'x3mThSroYxHL06DIVUk8fnA5kxMv4vvhneO8NkJBjuWLIkUQ5IsJebSXANWrLDSMS8AaT0HXoEwoIVfwGx9Fh4PZ6ZkXlEXopoPgAmOcxjvkfnRZIyO1qcY4a5crnptw'
        b'ZQlZskbcUFRpZIKXSpPGjZRdvG4O2R+Jio4K8dviCV/Ws4eUKMcYysIyaaVirJQ1Eo+1HO84JsPjJvCoFm1J1RA1eekEGzxvz6vxGVECzcYcD2cEruhqTHJo8nWR+nks'
        b'Mbww7Ce/iBdTX/e1OTBgavzEzNvHQ6t/nPbBp787lfJ8/USv07E5ZZev2nz4kW/AnE8j/Q55SF2O7fc7FbRIYL/go4m3+HVTDg35x7iVN73rZx9bN2nZzck/3zxgkmU9'
        b'J6DiWNAuk5a+426NCi4Slrfcdz13qfLWqvIXwyqqQ+I/HaEwUU091fCczY+PYnZH3/5y3hde7/qdsfnieMv5vFdaoiO/qv+xvOW5r24MaWtrmdVwt+mQbM/k8inCJcuW'
        b'vZT1TuDVhbZTtta+lLL9vHljyLt+vnPk9TnbLcZfqAxWrcu8PeN+Xssri/p6j4zb9aFN+fcBYxxHvXxz7pinPV754ceGF6IeFu93iFFGrxW9H1lbkBX5mcXShuTxe3Ib'
        b'7+zf9u3b74z78seJz1YFvw4XG5f7qC8smFnrOLD2uaa0tvIF44PuPLdJfOCPzWGnfkgbuGRF7q9GioaL7pO3ejnc23Q9a9ak6ulfvnb38PTSE3f+5TQl6BXv2we9y74Y'
        b'cDG75JkTX42ofNbz2qTLRa/GHDm3r2HQi9M+zn2279M7L01+qeV++I/CBXfHl376a4DpvXUjH/5wwP12RtXoiuRFuR+YuTo4Jbgdvmm0yP7NL9ZNiji//NU1F/zktXe4'
        b'efv3pl6vnPDjF31T7VLTinbfee34pzPGmT2cVvt59PYT7yVdzfmw4J7zNxOM/XaY1DhPBovM+xPPhx9Is1i8KGLXjDXtx6Pmj0nLX/rSGy9P+jpu0/3r1b9xvzeULvPM'
        b'/8k/t+qDtB2TLxfcu/SJrZPiH7Pk6on3Tt1bfLdK2Vb2HJ9Z5zF8m/KDWS9Lnx9m9/xbDeudP6+4rxwR11YQE+J//VTS7esrr4+8o7nj+Z043WhN5aCnFtze+iis+O1z'
        b'RUHr2nOsf1tlYTX+VXD6ruR+n29VBWvC9h/41WFoatSjWR/f3zy45rnhVW/eON0v/NeLb85eqshtP32+9IsLqhfdn77coD4VGf75P5ZfeDR374R+9rfHZJ34yi3v0WdD'
        b'wqsdnD7Ik4+mPvJAyJ9HIxfG4PMcL5eO0IWTqIQFf+Tg/b4ANaEzusCTaVCwktFzHdsIJ+AwtHRsdHjLPst4QnJ8YHs3Yo1sXEq+SJKUwMJSduMDpUkXJIZFzhDYji7w'
        b'mfOgnimNRajYCO/ALkldNmCoNaaPw1m88q+SHRhtXdSxA0MbOsyun1pnRiNyYMdkFuTAInIWQA7jHTsBuTO1tCDjUSthBhkMO1bSYIyx0DLO2Ukhh+0uHGfSf9Q8vEfA'
        b'QXSJRa3UD+ScCSFdoYsAXUNNeEcp4V3RBdTKgkEuYnFsJz5z0XHbzmwuKVPhTAbJAoBt09BpEkZBpJ8wJgRjxfgEEYTF3JBgEZa8ri6i7ZiPaylwZu2AE3Jc02l+TBCq'
        b'oJo61C8LZ2QyaXCABeV4BGS4kyuH8YF4Ro2KJavN4ZwazqPCjvCYWDd9gAxcEKM2dHIxMwM3Qb6EjEY21ynwwDpQiA5lQhttTtIMMZ4DiyCP3EBGXDqHhxJ/3wzK35c7'
        b'vA/ePLGwchZ24KM7UArtzEQQGLpaOwOC0Slj1BQroxWuX8nh4y5gmSeuiMSskAL7QL4QS89XYCtzKxRDOT66CYP9ApTv5kqJCY05yzDhclSHjrOJ1m4Kh53DXPA5fhrr'
        b'U0X0Dim08dBqnk3jSTw3eHUSgbZisZ3IQF7oGu3G+YvRfnzimUKj7sCbgAea1G6Pe/8cifrCvbktQNMl7gvqQ+gscvFBlZTarjhEkA6XaLhMKmyj8R9wfgHsJAaTxU6G'
        b'I0D08R9wUJgxlDyxLyxZG24khSZtxJE+3GgytNIIGH+0Cy/IHvEvc331ETB74QhbA6VjhGT6XEoMctYz3G0WpkFeFL1uBTsmYXUDiwptkEP5fjhpKo/P4D1zaN+kOIwl'
        b'53MUvkd7Ps+Dy/S9Y8zw2U8FmRZjnSDDw2kWT4blIthPRBlU591ZlBmBh5VIiKjR0sqgKDOXp6JMrD2dIIPweZ6Hq9ZGG9FQI9vs1bBNZN0flWUQLWQJVpw3a21S6Mqm'
        b'JwvPUU+lLzcPr4sj6LRrcEgg3tbCBU5oF5a3ycst9t3EaPMoad4WLB+c4rNHzpKb/9vwr3KH/yK07L8R+nPbshuOJjO+EZtld+Obj5iXUD4YK0pFJBbwj0iSFwv2IZB0'
        b'FjQkyJZQFeFvePxH9EgiJDnj+E4hoTUiXDKMxIj9Zb+TZ0kZ1hSWjqdoxiL8jJi3xnfxj6yE1kJb7TOm9F9rngCGm/EsNMmC/Sak4Uc8T0x6j0Q8/4dIyP8uFvG/iY34'
        b'X8Vi/qHYmH8glvC/iEz4n21M+c38fZGU/0lsxv8oMufviSz4H0SW/PciK/47SR/+W5G16BszW7E2nc2M0vR1MQ126zhm0GTxSiyqiGaBzSY/ImmoUuKajgCHjtSqDk9L'
        b'v/+z8ZdLOrUwXtdCVZ2+UbP1wU/UinoC/+rZmxV1+nOGGA0f11VyAc0vU/buLKVpN8RdKqDown/ZXfrhO7yBkIVpSRmEtTAuJYViqHYiBsYNTCYti0vpCsxHwbQSEphj'
        b'PU6WmpjVo1AWBuMYGzt7VUZgalJsrCw+JW3pSrlCC4OrC4LQqBOTNCkkEiE7TSPLimNUignJhP2wJ2lx50Ykp9Ibk2iOvzalM1HN8jwZGqKMYDHJkhPUT05USKAJfGSB'
        b'NJQBz0h1MoGaxfWQsIY42VKNOiNtFStW/2qBCbGxcgJl02v8Bu4fXX+Qj8mpJKCB8GJPx92YRTozY3lchr61HSEiBkvUvhvFv6WRTgR/hhZA0HC7dJEuY3aZKk2TTiHu'
        b'egmZUGUkL9WkxKlYqImWyJ4hLqhljiRj3QV3Aa6WAqJkp+NfEzOWKuR0EHoJNSEdmpGoGxftuNNAtNTujJTa0U9Io/m66QQ52VCZXQbgTxgdBZwhRkdTJdPBN0O1l9b4'
        b'Tyz/6KqjxUwnZvungc7VqApt75zCoNqwqFMKA7oaryF4i1BlDuVak6hMIiRm18tw2WG1O+wcODig78jVG6AxHG1FZ2agnQumB2Zgff4wapJMVroMgmoslVbPRFeGrEUn'
        b'rdyj0TFquPpiXCBXNuKQMRcbu8JmyGSOskpjWfoE4ZzFok8EakSbCTtvKcmEIQlGxtywFSI4BbkraAH+a0ScZPZyjvONDbk1O41LnmazQqTOxFe+e3P6Gz4jX5hoketu'
        b'5ffq+KX3vg58ni+ra7ay9b1n+snY8mn104UvJ/S/r8ydmaXJCBVWzK6bl/WPDd9Puxua+0yq+seYB8bKCU813f8svLzPC5GJv8UW5C7aaFq0pxSim6++8nPA3pvF9f7L'
        b'500+vHdB/PTm3wTztwx8bZqnXEplF09UgV9dGxJOtCqo7scUK6wDHc8g1veNo2HHjBV6pWo8bKduNocwLH89xsm80aaHQDNTKy7LsF7RukChJvZhV0edpawPlAlRkxj2'
        b'sVSBPZvQxU5K19yVROfyQ/lUwrfF+kCOs6s+SH4IFlNPe6MWFsm/FyqtNsDFjmD5WRycpLKUKdTHdSK2jF3hGoiaWYJAcxJclcqgrQfHomTwehplPxnlomtdguyh1L9D'
        b'6kWHcMvJgQMHsTqwn8m9/iGGIr+XOWk9iX+WXHjbhOTo0ZVKBR1ic+wu6GBRZxblC+ZFVJCwENL4ZhKp3DWGQV+ULq9Rj3/R6VDvwRLJszs6DteT+FfiYqK0Rt0PVy7H'
        b'2tDx2ktDSCgpPmeW4IOmC4CBLqW1IxCJJbQK9QmtwidNaP3wF5GBkzUiMVWLbNoVgF2jZidtIt3r8MbsNz1wRkQnUPXejqfE+OSl6iVLU5JxKYxLV4cFlUSwHZcuV9A7'
        b'FH7k5wx6W29Y7Z1K1faNDw1cdNFHLhJUYXUibWaaKoF8gTd+gxuzFnu+1zYoZkWFxFI0OE16Slpcgu7tdR1iOCpQ1Sm4kJwZ2ohetSY5gyHA6xtl+Lj401bNmBEZ6/J3'
        b'H436248Gzv67j06bO/9v1zpz5t9/dPrffXSun+fff3RMrKwXoeoJHh4bazjIMzCJUdIwEScxwUXmpJ3+Tl3CVw1EyBqWSXqJmpXNUsVRgO4/C5A13MwYIsWyXSFzjMK9'
        b'y2qhsIwMypYtJ1xhZnLc3+up6ZFRBprQwbVN9hjWDrbckg0Ez/ZIuNYzxOoFr76MSvtLX2POjDvkbiKLTXk7Xc5R5xA0pq93ghq1lCeRMRyqgorR1P0AdRZwHMqdoNnd'
        b'3d2I4wM5qEGb4RBzsbSjynhnpYJ4JXcTT0ldMKqfR/34kwJcnJVBPL6wRTDSyzsLNdF6Vg8Mc1YS2wYqEKxHlydBIzoiF1G31wo7M7fB1EUH54w44UDBZFfYTf1aqNEV'
        b'qpzREZIvlgGt+JiHXYKhKSiX1rRhY6LaE59zgjRuxSbUii5NpMW5WvVFJahYDS2WKtxuOC5wCluv6YOvhIZAOwkxGJ5IIgwkUMXSk/fBgbmoaaM2coJGTZTDcTnPkrYL'
        b'56HdKB+1d2kgOjaSXo1GByFXiUq7NrA/5NEuRLWeqA5ypZ2bAq1QQjskEl0boWv+JGhArZPQebmQdX3jeHTWGzeic5UWkM/6pBwOxA2FvK5VomMbaKnLUOEo3xBppgke'
        b'faGJwA0a4DC9kI1q3VHVOKm5ypLjhC6CqQloPxvKY7Bv0JKRxNUktRBwQjPBVNQQoCGIK5BLpOtgIulGUKwH4rrGoi8HR1DFeixa7wAsjaNitBftRNWR+IudcBWOQQWW'
        b'r3eiq9ZGsCveyBz/CEVbYcckWV8sIlpbojpUtSo5tnKQUH0HV3LO5vCiV4JXIl8r4++q3vml4JW62d8VRZZt5Bvv37Z94ZDVyDvh1y5eisz7+vnmO3H3Qn/NHlj6vVWC'
        b'W3N7tkdNRNC8wAcuES88X/RaTcpHAYnDN3309M1JtUeSlt4NGX51m9cFTdGW76tnGf3r7q22FRPHfpfms9gkZFJ+9LRL39vcVlbLEwLfyRr3ZlvikIL4mUs+Nfva4TnF'
        b'7AHrFGsCs74a9qvFV2+cNv41T+P84mdZXx9dl1+3rPW5n4b8ZCO+cFPgU9oU9/K2pjEu2bfX5hTXtCyO+/iFjaP27dyze4K/873po//4dM3vlj6e0Vvfb5TbUDvk+iS4'
        b'EownfW1HIiLzIBTCXirQJkLTkGWSrkmzU5RUELZ0QfXO7ibBWF4tYWK0mYvQeGMIyxjdIRTq5HYsnp6ehif/flqihxtewIXOziyFU4TyBJA7SEJLXIiuroT93t1yXWca'
        b'Mam8FZrNOqTyRVMkRCpHR2YxT0hVOrrkTHwJRNSF3Q64zTzKWQMttGSsLpVCu1oKF4h3u4h4bHKhTmBL2xog51FR+jiCr5DPofr5UDYDypn3Zh8c60uuifG1As4PnYVy'
        b'Z2in1xbEwAFyiRRYyOFlcRTPsCtOzMFRNGNZl+RRdMCN5o/COQ192B1OwmY19bWj41wM7r79eM1eY21tQdsGqNEOVEBahBd+GVTCedEa+uAyqMMKaKaFEX7wBIdKURvJ'
        b'ah3OvB3F/QbjRW2GNV3UwIVHwAElVLP3aOs7UJ25mtS2l4OjaA/sQA1Yx6IbTTNcRvn4Kq4N7eb6oAbYPhTOsERUK1TPVCVhdDdlqb9RL5mWj4uDV2Phl2oTCQa1CatU'
        b'YvK0YAxfj4gxlJhQiTGT/10i4imXR8cfwmNMGd95U0HXPyKshfDELPpobZ+usdS4fh36Cc2WNOssPatOdVFIaIAkfp0GvRJySp/eeAZ/eqV3TcTqpAFNpLemCGjAk+oB'
        b'+dy/G87UbdGSsEDlbemSGVHh4X7KGYF+EQyXU48/dVuaHpecqst9JKmYt007JQdS46U+CbRT5uaxrjhVFLaKGC+pkkXfj7Vu4P+XbPCqlbhdp4XaCSThrIwlQgKgJv7d'
        b'QmxjxPtiVfQRz/89eEwLkZWlBU9o33iR1yPJJhuBZJANi8SSwRl1N7whAda8q+f6i5JtFveIMDbT/qv2FHRlgSPAWgxUq1qkhdVinwm4lgn+Qz6baSG22Pcdn60I0FZC'
        b'X/rZJqGf/rNtQn/82Y5+HpAwMME+waFaSvjl8sVJgoRBCYPzJARfc6fxTkGCdKfZTslOa/InYUixsckwk+EJHvkEukuMNdwRCSMpFJUx5WYbnccReCzCPUee3SndySfx'
        b'+Mm++K/VTutk9ps1LtF6p8lO0yQRAdDCZQ43cUnwJNBgpNR8k3zzfOt8myRJgmuCgpZuQqN8xTTqt0+SmEJmSQiup4ibL6WppWNuW5OlMoMyTFBAtqRE1UPPLjJmzxu0'
        b'9Gqdb3qowAKrT7I6zUedkUD/9XR39/T0IXKvzxp1gg9ZOgp3dw/8F0vUY+TC2yJlWHjobVFAoH/AbVFUuP/sesFtfqYf/mlCqlwSpgyZVy9SmXAUQI7ombdNGBRvMv5o'
        b'lIS1ZfVfqdaDVCtStZD11kp+XCQrWBSojGDojH+xrAl4Y+talgrRAiNmRk97OH15Rka6j5tbVlaWQp28xpVoACqSB+u6VJtJqFiatsotIdGtWwsVWE9w91Tg+uR8R/n1'
        b'PIUHU+WQVArcQSFhM6aFLMGKwcNRpNEzpgfSFuJ/Z8dlk00vnJiL1Rm4UIX7WPwTb32ksHqBajVDTbxK2moWEaj0D/FbMn1a5IyAJyzKA+/TLV1e+eH4bg/OUKWp1dOp'
        b'xtK1jJC0ZaHqZbQkD1IS31ESbuALpCzLbv3xcGDvL/Wwn8HOk0u7lEKmm+plA2VPUL1Cvu1WyARayBjVTXKt98o9Hjr/hTe9bZyQmBSnScmg3U/H8v+9dBYm9Vd6okbp'
        b'plEdQYgoD2qSX/FYxtNEl7U+04PjaNLRpgZONFrgaLrrMYkutyWE3TUDT2sqc9galDm4TaIoBqbadTtR6J7tPWPiLfwewVivVTsaFAK4HLMzBsSAx9VVb8wO7CIDp3ax'
        b'/ugm0/ML0oJIZY88C1Nd187itHkWHSBqFEAtyVSfQ2H6pDkUH24xNmDJDGTpxclrEzvZMxktEHM5kU35MfbLCB0FsCydkjRQCUbt0/NGV1m3hSNznOknf/xtZOH96R0T'
        b'ZI5O6mTiv8ocr/ByeoIi2VqWOc4I+PObtWuW3Owi+7N6et9PZI6BkX/pCY/HPPGkWwMponujezMVa81dzC7E8sa1hFA6soHeniTnJ3us+7RJVyWnqZIzshmqr6MTOZUJ'
        b'1RY5l50MWw+dyGlN7iFnpxMxFTuRQ89JruhwsXopPBXuPtpbDBfT4Y11p7dqS+342ot+zYru7cUYRoX21QwgULD+Ga2mIBS9dg91VPh0hQ6gi8wwnoQ29b/XNnWARvjo'
        b'6Wl74kIQjAa9Q96Av538h69RjkFivadWUxoMkBiXQSaUWsea1glmg7ije8EfIJZXXA5J9GexA53IKmjvyCISE8m7alI6EbEZLGrGtEg//7DweUsIK1BYhN8SQggTQVup'
        b'99szerheO4ltQqx/KIGTFrVFN2467U1rMzbs5u6wI1PfBCuhw8zr1G1Pceo1UICOUDpbp2pGLtdti3Fib6e7pRdkBi0AB5ZQdWy7y+NSZX5R4b3Yw1NlEVnJGWsTVSl0'
        b'4DIe03i2IfaylvCCCcyIS8mmD/a+wzn1Pme1yCFsQDoARcjM1w6JHlyEuaZ6eaMMFvfQCfa7y7NpBkAvntRXgLtHK0apddO3W7mGx0TLt9hRL+XMjE9MSUtdRkr6E5s6'
        b'kUpMeshRlkpmHr6GdsBFqAyGEihfCmVCjoejAsdMa5rz5x2yShfoED2fJDk6G7M4B2KRnQFnlhKw0dH2FG4UzlijAzTbwB4uWRMlGJfcSmxxqFDEmUMeHJ3KE6zMiRQ4'
        b'00s+LLhzUlo0FAR6EXTOXqE5Q42CeG4cyrWAvKlQJ+epqXk5XIEaavuFArRZa/8dinJYPkrlSqiRmqvQHlOt0RhKVBoCV4PKKF5nBwBrR1P0STvp5ubhBH/V0VUZ5egI'
        b'22GHG2x3IZibDFDUlZj6NsNO2NNX4IBOzmJZGHtkayhWaH8oY3ChpVABR6j/IlxC8iHTHYxksSGNvtM5mgI6HCrHUwTRTVCmBRENUASFQiF+c7dwKAiZEyAMR4Ukmw8u'
        b'odrskRxqF0lhLzonS7b8pZVXH8aFfDbn25HFZy22+Jpte3dwetb1lI+CvSeeG7Bs/NKPXnO/I95mYlv4/LcLru+//frh0LbGrz8YnWNlO2/AlgLeYsCkH15ufqCcsnjA'
        b'xmMTyheM6afpH7v/pZSdK++nbzj64KnhP+UvO+x37rszd5d/2H/4yUX3/feLnmrfv3z52GHv/d5o/HHf3wZeeO/iVOdFktd2Bc2/lnhwY/Tu9HExluNfrI+YdTuo37tu'
        b'5z9RHCw5KjdnFsQr8QHOClcS2RBGMgWP8e6oCi5TS2j2lPUM5Nh0LEFndiFRGsacRbjQY6aJFnnRDY7ozboLIZejdl0oRjUZWkTQItxFJEwkAuV2ib/HldRkkAltAXXo'
        b'HLE2o83jaKAIn6aN7U3GPa9w9YHTXcLMLaCIBV40JKL90h5RF37eElQwg5XQjopGUkvusMldgAAHCWmguhM6Dqe7QAoyPEFrKNZBCtZBAwMoPAjb7ElSTRcQyAzUuhiv'
        b'1lpq4s5GbegQsbWvJTHaOnP7XGhk3ZwD2wbiuvDqWzIUzuPLoYJZQ0eyuJOTmbAdr/YQASqBfRwfL/CA3JldgDBM/y3Dmx73bmYvWhS3yVpKzG9iIQlvNSU4eMQw90jC'
        b'iwQszJSErFrwIn4gCWx9ZFgP6oxopyoUGDInl3TBmFvwOP1r8IEn1b/+Ct4coy27bbSEAuz1Boa1HzeMoc0ZqlBP4Kx4Aum3O1IcMVNFBEwLvy0ilKq3RYRdVW5sKJKW'
        b'xamSsNXbxlo6b9X7AgPp+Za6k2Q2p0/PZ4qjmVZ1NKdp+Bb5lkmWfzEJfxlWIOsMKZDTEhLUXSmpdQeoAeueXvTqqYcmyXyIYOgTq4dKiTXgt3fRCjJ6iC0SH9kznLQ7'
        b'JSJjBCb6eYd4mkF6MkMrvD+RWqQVaPWkuX+mGTHOLPasAWbbOLUsKSUtjpgMZJTCVctR2VvQTFxqFz647oS4vbWii7pgiK82I3ENk4Uz9BSvq1hsZy/Bmvie5AQiyHV0'
        b'RQerHnsHmSOljSevRgW1YeGzFArFMHkvIiYLfaCBx3FkNnUietaXzJgsmejbcd1gefpnOogptVNAG5bVlabSYBmO4X6z/Ii3xm+JMip0ul+4i0ynkTAuz15DuWikce+c'
        b'rmnpLPL6MSWsMaTk9UKe+pjiyH96HZD08ONUNG20sR7QzmBpOqZuQ9qcDPeKX7hyWkhPzc1wcPITanM6ai3WFXqOYzJhtfOGrAusACdSGuvYWGVaKtkpHhO1vSajo3bK'
        b'gEv6KC6FREqTDUI/dQlPPe6qhLhewqtTNMxotiw5MzFVN/Px0kwgITyOS9NSCbs9xfbDHZdMv8W93GvDWDGdTQ3yzq+pZXyOX5G4NIPtB4aVm4gwby93DxnjoGXvQ9rg'
        b'ooUL1b4v1f3J2sSbosFykjQqutboamdcsr1qeOxU8pFFaDUqHQM8CUDPxrWkpODFF6diehW72fDeolanLU2mg6DX79JVaYTInfQi7lrtYOOFwKa94c7sxI8oU2JNLy49'
        b'PSV5KQ0uJKo2XU+dA+oNr50ZWiL5Dj5WcmDLHPFPuYuMHNsyx7CocDkZDHJ8yxyn+yl7WYdOnTIEvOQ9EQ4fE6k1Tb/Vd+M2elwEaBc1U2JQzRyiZJFEbZ5wFLXC3k5x'
        b'8xZwfBUVhahy5J1MlCNZtFAW6/KT2WiOKXC1qNED65iWWbxWx0TN/rNY3Fd7IOTKlJ2CnubZsqpOYm3pMGzG2ieDmaEYM2OFkRqSFIiF3nbXnsrppdWQh5XTOahGE8xU'
        b'jWVQpKVYIPwbkVrQhGBXp+gAl6AorZIag/YZ0FMZCE2jXx9UtDSIvkdKf3+io8Z56SKUoBxVaoinAEvxezc8SVWd6ukgrZnjyCA07LxIZqCY83G3gSZUjtoZ88PpTVAh'
        b'NXdeoQuZQk2JGsLWugRaoDaYYgu5BoUR/ZeVY4RV1a2mIwegetMOjdMXaxPVRIe1RlvRsUh0KGEOKpy+Ee1DW9Ap/Oco/nfbyjWoDB2fHr8YbZ+uSp4zZ8ViVX8oGLkQ'
        b'Va1cbsVByWQHVI32wnaqI2fDSThN8iP2G6eb8RwPVwVu0DSOwsSsG4t29toyKByASJt2+6LyeLS1S7O2whHYST6TwK5YS8iX4fef08cO9jvQIViGrqKd0szhUKoPLauJ'
        b'1MTjKw5wPF1vCZBHa4GE0jWayCHQAGXp5pZQEant+k52AmIeIOOjpWwhECoUcAfloDoJjV+zgAJbPGNPz6JYPavno0NqhkFiGOeJPBTpqMdEkYvRbkJQcQHlm/ujA1Cp'
        b'8SNjenwD5AR35i8qRqdn03mDyw2eQ9NFS6HSSB2Etlvj6b0dKjNQWzhWrbcLoH21ub81VNH0Ez9ondCjoIB56HyHchrdpUi0VYp22oyE4/3QCVRr20/IoarQPqgWauCK'
        b'hjDgAcG3ukrfUf9qdmgXIybBS3Inruz8JDxEWyAP9zGNsUMV8Rzkh5uF9/fTEBbAcNg8sZNZJiRQHuSq6EQ9MgyOdyA/aRtm3nXViDk4oLHGq+CQu4bEyKA8dM5CB2wx'
        b'J+AxhetL9kB1vRYeHmRDmg3XqB9SuAxdIvaeVei0lh6mVAKVNE6H4rcMxZteK6PFYaQ41T6deHHw8jlC6BWTn5utMVLvwfqW7M5noXOuKe2nWf3z/SvXLmzIavGInR4w'
        b'oDbsoPGh0k/emj5QcG7k8K8HjK9aGe83YOBO/4tfOf4muiroZ5Ro2pq9Y/0VB+uXv1k/dczEMc5C532BfqtCdxVNj3Sx+mDrgvHbxla99Yap47xjxxwfJCqjznw62XP2'
        b'qqVzWy8rRyxyDJpwaaz91+0VZ15/s2BcYvDH7WeH9k/9Mid0XvO8fT67jj0/X6P+Y5/JM+EH35z1YMC7K1oyx/r+/s/IVT+FFdeFTVixcMaVzdEz34qKqRiXG/3+pTf3'
        b'fC7/MG6N05ptry5NPh/ym+Wd1ddPBf446HrWK289Ek8tbEsoj/nZN//9dWmvOz6SRJZdfnPjs15P1bV+lbSOU/wuPPGmxSX/RanT7ttmO7TMQ79LvvZe/nmK5bdTvpF9'
        b'/+svX/Z9I/lt+MfUjx2i3O4oL6/I+d3+2zkXjB8d/njdy3uVC75+VHimedfhUk3LFCvHBa+HiKYOu/TjMbeS5rfeVLpceRC3J+utL6feDrv10UsfePW3kyfecrhwy+e9'
        b'Zw9venh+zuybaOw9T+XPL6y3eHdv/7ttp/74dNPudcdGHRsot6VGnjDUsr7DainiYC9qJ2aiIJTDLDctUmKFCoMDcF6frMRMUF4ol9KO2A6B9uAwV3QebdPiP+wPY0gI'
        b'bXBqcHDIoj5d4yslkE8tPutHwz5cGhTFdoqvxIuymeX2l6Kdqs58JxnmC+Eg4zuBPVNpCQMS4BQUuXjM15mnGISDy0j6aqap7nr7VjI605FYxNkz+9bOhbAbGld0ynai'
        b'1rcDsI3alVSWM51RvTXa3RGriQ4IaJgiFEbA9iVQ6YyXYCBZJ+IUfpgQVdDnLOD0CoJ4AWdRnRb1Ih+10940wl1yuktwpC0qpzY1vNtfYWlMJyxNexrVUGmMjqdjJByl'
        b'1sWBcA3VBUMJujDArXMWPZxE2lSuetw758gdV1GTC2F/E7kI0OWlVvTtZ8O5ML1FTjxfT8yCCpJYJGapgw86hmq1xk1q2YRiyKWNHIcKI4NDAs3EqLBbFr2Qc0cXxW6o'
        b'eAVtw0LvEdR8iY+VMCxCxEO+xUzhZHTBn3VjDd51LsWjik4pZXBakEAjOueiU+MzvFCRW6irHNc/mZehumi55ImTly3/O1F4J3TQkzuJiGjQGGgaYiaw4K14C4EZ/ivm'
        b'rfBfidBaYGZFgjvFj0yFIprVLhHwm0158pnkp/Pa72n+PG8jtMb/2uC/VrxYmwdPEszMjEjKGcmBJ+ZGC2Lce2RGcup5koNOrq0dZsDm9hez0DtsZ6o7XRPVnrz/OyeP'
        b'3zGQQW4gebzGSJdsZ8CgyeU4vmPApPkEb9t7YM8UYvEjlj4WIMIlifUhPsInRVl9GNtDiwhPTMUKrPrPzHnUdqDVV4i2GqeWzQ0N+ROlhGRNDO6hlLgoqbziF49qgvGe'
        b'NHqKnhqyKzgeFMU49oC9gGp0xryfWEuiljg12jkA1WN5QX/Cdxzv0giKRYYl0wYoJFICnIBGnZgAWMSgKsn8meiMOtMGV3AuQ4H3XUUm/hFEgtNHLDYanwxFLOu4FB1R'
        b'kwqgOAkXMZhDZeZQT+Xp2ZTItTJ41TzcfJ0Hz3wJVatqNTxNquEsV7nIho3SEgUemZM4BsrgROwYdw4rVjUcapfDJZqUMrgPVOI/OxPw0LtxbuhgEHvkDLRFSk1Ua6Ge'
        b'wMvVE1XsEOxm6R77oAJtwXsqlsGdCH5JtgByUC5PH7SGbZuCycGiRC3QZMSJbXkzO1RIZfLsbO8ILHY24mOGBN7jXTQUjrK8lH5QEAG7IA+1jdHj2cF+LRTpRktUKzXn'
        b'vHV6DRSNpw1JHWZLskoGQkFHYgkert20ssGLx5J8FLR3oj4lJd2Kde0+vPm3SjPVUEuYFnF1TmhLJFNAy4zsieY2EQp0qpvdasY/V0+w7iJQMeyMwjv9rqhQOJwh4CRh'
        b'AjiPqtxp5ysHl3AOAs7uumyNRcwoKVN0j3DDOOIaiXWNHeYQtE6r/ZoQrEnO/TvnDNMfBo7nehAl6xehjNMSJUvxsuMOcesFCVyCYCs/gDuso0xejkXKL0hUF+G6mZag'
        b'CklOTazXkiaLUvAv3VmfiVdkpZjj7vF0uTBFowCq7WkoM/NGmuhE4P5YF6mg+ROCcK8JcAkKUeEE2JrpOytpdaBqYyrKGcSt97RCZ6GJ9cIPC804PDqO3NwUMxujWPbC'
        b'X47pz7lwnNX1lCSHF8PHcNRxnASVvtA8gdASWpp0QzpEB9AxLQTecNSKtUe/aXrl0Q2vETJaQ1FJHL6CcqeuNsciko1gIuT40urcQ40pX+bmtatDHopsODlPJxIczwqW'
        b'mssW6CaSKZxg0YW7wmCfNHMkVOqVxTKoYwuB4CKVQbMUtowzVxlzwlGCyStRg1zA8OsbVNCiVqIG/BIijpcKZFCf8G8NZh4eTNXHZPf/hPz4TMD1IO0mw3cFD5/qc3yR'
        b'NmMRqkCXpZm+6CK0WPLkBbwXqDRMTtiB8qUqdJS4BfHLYB1uVYhuFR/COnmzGbSssDLGS64SXw7WpqpJoRbVSFE1ie2cw80xwl+TftqYZSV1dHKGsyFxCXjuB/Hz0R64'
        b'SIsbjNo9odktCFpDFKhBgIW5XAHeL1ySw6+9KFRPwAv+g+ntiVGBKQ5RVr8/+vnu6zVVTxV+vTq3ptr7xdiJcaEOo0Uo9bqLRU7eyKHi6du5QR/W/DhzwqEP+j9TJhYM'
        b'zBO995rriFTZ2QCJ9yfi6R9d3zrRceGd7Xne6XeiNOPPVc4IbV/buPH3M1+GRRYEbXj/VHXEsV8fjhu0a9Ige89Ci6htg+5Uu3H2p34v+cWiX9/YlQv7+UTGf3PVtPxV'
        b'51/Wpdz4wDwyL/qYau72sVEPfVz8xS6frY+YN8hl1hcuiSdH7Xth1daC7Wfy3vx07bGPTE/vq5vpHQ0rIvfFCJszJpx+Z/7C4Mi5rSMXfNCIXrvkYzf+Q7MG1wX9F74T'
        b'/fHQT5Zf39fy2QVr8/MlK35YVFqVnzvlzSvOn4y6vSLmwbdbPvCd0TLliOdnM9zt6+MWxW2/VhR96WRWedZnjyxWzTzStmVq0MtjLMq2P/vUygMeN/q/8eXGwK8SPsma'
        b't+P7TTND7L1qxtz4+Y27f/h+1ffA8g+39flJOsxrtY35GLd7C7f55Czpl3bzmbCm3TZ3Vp09+fMJzZb2zaPPvnvme6/b11f8fPDNwW983TTI7t3vG8of+PzzDd9f868r'
        b'FxiNVby3Q9bv25DJ4ee/17z+WcSdvV/lvT8y4Om3jw+OnxX9tMPmimcWWSaOjbr+ftnN5+connVdPPvEuOI562qHvVB87+LTx/baPfVP0bvm7w5/IWWjtZ3G9O7iJvUd'
        b'b9WQlPY3hYOummaMuevrs+2Z5AifLP7Cr+VNrbJvJi9O/M52WFrohFeNv7P87A/VgH+uuioOCtv3LzeLDLfPqn5LO/xezQfDVBtuDlh3cN6N8wPeafvw8zsrbw+7+Nn7'
        b'OWaayB/Lzhyu+CnczuvIllVrsu6PCw0qOfjOxDiUdGu+otJ0/93gn1rvlr1xb1HTlbiffav29L3W//MpL31n3Bh+848095/v9f+SX/rSV74ef0wpqvkk7faBLbOfzTaC'
        b'IQsWgbDvjtkrYy8fXfjsSqesr7J3WBy3m3Hw+Kp5vytlz74XNe7LO0/taC/7Qur5r10e1Y9yArIt45+2zLZ88VuHVZuefa5+/zcel9Z9fPATdf5lSduHg/h7pnv9Lza8'
        b's2fBijX5q198ZpP93aPh9nbvNNtONIv+5ebrkvcufaEyd3jp95RBpYnvWKj3PJdl+s7GFy8/9ctB0/FQcGXET29lFH7vZnKlqE9W4JdnvrD++NFTi4a90G9Rxc0qTeH3'
        b'm3Yp3rmBf/9SMaEiq9Cxed4Bzynbyx9Nz/7t0fsOL58fLS55xe1u5Xrh3WW/bnzBy1jZ1P9zu7ved5NvmWQX+ni2FG7iq02eybqueDXyrZxXbo0a/u4WdCr7rZZbQ7wX'
        b'ffPMv5563eSf84tNJ6/74u7qq6+MLpx4N/uWPFLwvOniguqNa8W/2e6ZFf5SY/oEONG49kbS6szK9ZnfLZ65yOeP0S13Xhg/2f6zt2e19As92nbgjvm+GwPd/nHz6ttz'
        b'6pXftc1sF30qnOZ278Xc9UP+Ncnq239+OPm++aMfVi3v18/1jy/On9t1K/iNPlGLHlh++tXEsSnR8pUM360hZp7UiVCNEOQzFpaxYRrPDUHNImhE50KY3loRDFt0SusE'
        b'dEWrt2LVcgdVDB3gXLazoi+60i3cYjHaYU718kGq4cH4sNNeGwK5WJZyFy4ToTNUSQ2AOkJpqFdSUfsibeAHbIEcisnRf6ZJTx0VdsIRnZIaHECLSpolpUiGZ9BJSmvb'
        b'wWsJx9ARGtmxYjrs0sIlOvoLGFiiCbpK33RYlp+6I+0IdjsKOHNoF/oq4DiNQJkLpyarFbhuV5VSTo7zZhpnA4UWWFjlxsIpcQRuFVM1t6A9KE/LSewMZbimJbzTAEca'
        b'Q4NylkJOcIiTUwTW1xcJxqNdXgwZEIty1Xgw3LD8vByVk9aV8iMnogu05ZZwGJ3SAsFNtidQcKf47KgRtLqwwHFSKHAlWIfBaF+ykDOG83xYqpqBvwSK9RehOWQd2onf'
        b'CxXggx/LXo3UhrDaHrZBkSItO0gHl4uqUQltlMwdDrPHXQPNiMlFYsrHoP0on3FwnsMSc47aKRBK0mkmaanSmLOKSkZNwgy4hnbT1k1H1dAQTPEBg9F2wkR5jReiOk86'
        b'fdZiOakWjyCc6w9tYVJU7yjmTKCVR7WZNnRUVto6qBVyVIP7ersJHhsjzhRKeChahlp0+H47lpMWmsihibz/8RAhfr+rwr7j41lGZgVqX+WMX6l9bIdpZUEwC0vahtqs'
        b'yDg6K+Smjk7EamEtQHvthLDZ3pGN5Na5C6WKYGiRQxHkwxbcARb8gtHZLPX2KF4GVWrl7IECJgvUDcCrgnbMxekB0IzfmHQ7xcw04vqgKii1FaIqvLqo0Uk6FeqDkyFf'
        b'SwqqBUC2R1tE6LgS2OsRay/arFYEokYzfEsIHOE4C7FwKl4zB+grjIN9qFwKp2OCXENWozMBeH6q5QJuQKTIv5+SJau2QluMWi5FbaSVbRy6BIejWeFXbNGFYB3e9mp0'
        b'1AivvJ3CSVh/qWI3VNqPxa3X4jWirUIdZGMxKqKdG4sqhOpAtGutkxyLSXhq4TlVDRV0ntsMSSUQnM4rjTiBlENXk9BluiG42Y0PDlGifd2wrGHPMDoZY1Allg+Lgm3j'
        b'KQojBXO0jGQRbFtQ8wgK5XguvbMRygRVsdTkVlSKSqSOCi9LKFwdgptkCvt4dCXEmI1lu/Ng8jahrqux1MuZePBoL+xH15j96siqNKlC7kSQXH1RJd7mkvlkLKqfpTWv'
        b'QvW4EwrcFIEE+Rmdmoo7AhUL4+HqDNoP/qOgHte7Whm2johqJwRYBm+FC2yGbsFLIU8qB4ISULQCzhrhJbBXABfQnpH0Yachafil1tLgSK3ZDA7h6U3F5YuBM9WKlOH0'
        b'XYVQSACr9+Etgb7PKVSZGBwS6LqK2OHFnDSIxwpywyJmDj2LNsNxdaCTXBWiVECJE171bkIJD2wjxFL+fjiM9wNUhkjSC1zEsveaFXTCLNkQihWH6ahERYRcHs8b+3gL'
        b'VugeaNgIRSGork9naudauEhtsyPxixYT6d13NBPesczLBu4oKvfoMPzCbmhh8YGz5tE3WY/yoBy3NWYtbq2bgDP15fGCvbKMAnQOQpVYwYci1GgKO9hixdOxOQTrNVAo'
        b'hD2Tl9Pb4AhcQtVqhxFQIjdFDS5YFscb+Tl82wArkRMiM5ZU5bxpHi6DXkGtHniwogV456pJoChYbmjLRmJMdVnLTKnhAbRDFOi4P3HLZEKzUSYeoT6CxfPmsR2g3diK'
        b'XHHLFHMCVEPMEjtn0/nkCG2QiwX40agOCh3x4oAafANctGGzbet8gm5W4hiU5YTOYT3MGFXyE+xQPd2ypX1QOYlpDSOWlEI8K/BYVeEO44UJyXCavkYwOj/L2dEV15fX'
        b'CTg9aTndEzb6yNWLzekhhXdUui0KOTt0SuSxAbWxU/1IjD3b1kPgAuSRObsfz1l0FQrZwj8jN6Fdjfaa4N2L9KIpXMBTYSXaxTaVM9AsJqdtiC86K+D4aIGrixMVK9Au'
        b'KziphmJNZLAJFGbhAceVCLi+UClEB/Gfo3SVj+NNgl1RA6oI0uGwQwViHN2+sHcGM8RilWoPM8ba+7NaL/PolFQDeQPMTXCXDhVMW4AaGRv5/iQoVsMOV+lk3BobwXAo'
        b'dKBv4pWJ1x+dNIGr8eWxw8ipXi8ciS7irmB+A8vFenx6N1SMd3iKTz+lTwZRDPGGVreaAoK5wfZQF3lgKN6sqaEflaMqI857khgdsUXNrFt34TVZ32GDnhYl5qgJOj8m'
        b'g9ClhECLPxVROkDiO3Bn8TJq12HPRkGDxA1KZjHbu+UEKb3RdXUg2Wf7hMElvDLR0QR0iI3WhbXWnSiucRsOMppr1OZCV/vaSV5qpRyOzNcuLz8enZynDXaVQIufWgkX'
        b'ZsrpFr5bgErQEbSP9c0BPPPa8aN0E3Eneqj5OKEJ7O9PBTNUuUHaAZ07ybkTeC6FzrWGzbR9xiEEz4+9gZJU02cCYaYRomOZbsz9Uj7JtTPAPt5jR/po8fUD8TZKpsWM'
        b'wSKpYyZqdXXi8GJqFeB1dVHbTBU0o0YpbNcKOVew9MhJOH7O8CA6a7LhykapQmwpDxLgJ8/jZYj2b6ALxXJ4Ct6uLkrkctOgUDJL8DqxQXlCKBiFtmYQ42eW6Uq8c+ca'
        b'c5xgIF61/RczuaFl6AjcZ2fdsNBAd2YrIeSvEKLtqAmdpOszAQrxam92mdxHoSCLvwqfYqgRS0TkZBw50FqK62uDGry9ygWDh0IDo3i/CgfgonoD5IUE4s4y0b0RXrxQ'
        b'JvIBHZDE3A34tHHFJxk+Y65hOXEwj+VvVMO22ktQb08ZeZQELsSVTGe8cHdvhEN055kPW6FJ7eYETQFyaBeTnecqH8DjdU+a7QoFidDsqoTWkBXpeFfYIIBd6BCcYoTg'
        b'tfGJBKD5HCrogoJMMJDxAqpjc3E/3rsuqhVB6DS6qMG7SCGW2Hge7UTFiQza+1wQytHKzoGWjni5lAtpCIlwAirpT99vtCXUk/DrVYPxC2rDr9fg3YGanAq90IlgRWiU'
        b'E96iswWToCaYbQBH8euQuOzxZAOIF3igajMmOE9Ra9FK1s3nOQZWMgbtlvf576DYiv/kuhaDgmbNilXUdE8dPPMNwBvr/ki8JRTylwAZE8w/EcX+E+FtjrhgxBTSmMSB'
        b'M8cNuSbBd5E/NvgeKwH/iIAV84/sJA4C/p6ZpRVF9OD/EImIM2eEYAQ/ED+Jrz3E35mLKMCxtZD/TSQW4atiftQjfrOFgP+df2QlGUzK+0P8oulEK54wrxN4YwJybCWw'
        b'w3c4iK0ENgRNROhA6hPyD6xNrOjv5Fs7czsKo+yIP+PvjHqvnX/kYGQnIOVShBIK12yDWyQR8w8sTMT3JVL+R9On+V9MI0wpEDKBQjYTyPDPUQJSN27LH6S9/O/iXyU2'
        b'EsHaAQYcN6z3O/EX/snYdUpI/gKPFp6AnJqAzRv2H3E5ti8Z8CD13hBcPU2HvyUg+cZKpVyEf9Ag8nqzbmAlqmKOJl1HzAjwC/WLoPAkNEmaoZUU6SFGSDtVCzmtuVNu'
        b'838CIrJI303NuHoL4mbbRg4aTsTzYp6BcP/GG//nPolf4sdbCCSWEgpKwgtsHvGTGdSInciC3PcHL+QFgx9xmwabUvqauUYZ0kxzdMm/h3We5ybNF8P2cCjvkUtvqv2X'
        b'IpE/BmxEmCDRfjbp9NkUf5YmmNHP5vizhfZ7y06ftcAj1SZ6UBGbhH6dQEWEnUBFbIuNTQaYDEwYpQcVsU9w0IOKEDASLmFIguwvgIoMLRabDMQljtZDipgnGSUMSxhu'
        b'EEyEQJh0BhNJkjvetqS4O5Qhe2ZifHLGQ7ceSCKdrv4bMCLeLD3dU87fFs0IC/e7LZzuOV11iUz2K+THNcGT43l4s/xKz78EAqJ9yPuvA33oqqPpnB4E6EP1DMu+IZAc'
        b'qmcprFC4X2hYpB8F+BjRDVwjYubM8MTVXZPI3VXPkxd+kls99CgYuoY8tOutVD00Rtc2y026lEHGQfVzZ3wNXeeoHpA3+oVc6q0OD9Wb5J7/Y1SMnry7Rkrqz/JfaEew'
        b'+syG69D6vHkWCVpuN0lKUL0gV0bgyaDaWpTc/OrbRmqi8Zj7LCRc5AFxLyU5xYfFmSZ9zv2wZcALv3q/zk2wEp3a/bZcwFLHtg2PIGBs4yd3hPg0D+yFdPQtXeQH0W17'
        b'Ewxo/IeCsBisteu2up4QVUOGO1jt/phDjKJrvGHgIOu9wrfJaH5LoDPIXvt/Bp0xVPyk0BkJtNUEG4BE7f8ncTN0C+JPcDN0C+pP7/B+YtyMrmu0N9yM3pb6Y4AsDC5b'
        b'w/f/BdyK7vlZLJUgLpVkAZA0q16ShvSPGUJC7YF10WWctfgW5LhgmBX4yHDqPb/nz4AldC35K9ASyUn/Q5X4/w+qhG7FGQBVIP89CbZD10X7hNgOBhfw/5Ad/gayA/mv'
        b'Z8qNkTJSM5kc13vHof0UWiCe64EsABVQHKLlBu5AdEXtkC+FWjlsTj7vcINXE2Apl8JGwnP++Z3lSfOv37rxxo13brx1470br934543LZQfK7+cP3Xo2d3hNfa686NLc'
        b'I3kjt9ZXnS302Dp0b84YIbc5wnwQnyA3YvJDHeyF/I4QWauRvPuoscyA1o4OJbP0f33yvxXayfL/A+JZcHUesZp18rS2onatq3U0OkSNKNmeaD/Nbef4eLRvg8ADXUyl'
        b'Bi9fTkmjm9G1gV1pE6BIR5v+H8p6N8x+0Cn3PZIFo5IwVdEjA1LIX05sH/UkItDgm08kAv2V7PblcoFSdVugE8kMZLbPxi1jme09atKntQ/r5aDrkcoufnzo7VLjbotC'
        b'qlsYhG4437ibmCYlglqSVCumGVMxTYLFNGMqpkmoaGa8URLR6bOWq2GDITHt8QnqnZXG/19kp3dF7dLKPtqU7VX4tCC5s/9LWP9fwrrsfwnr/0tY//OEdZdeJaQUfAp0'
        b'5in7S/nrj9ky/i/z1/+rWddCgyKgtZIRp/MDg6HIdJg+4xrV2zH8LsJX1HeDB0PrjwiAwjBXmu/gBsdQ3ZyAICim9GAxBP+KJJeKSBhSkQm67IPaaah25KpV3bOoZ6IG'
        b'c5pFjc6jZhpsvBZ2DVabowuoxlyXvz18msYTX0mxRzlYHgsay9zWveFv8RyqhIMmcDU7U+OKHzMfgeU7fQInFAS4sCwNKAiNR8ewhEtZV5eMlkxDF8fTJ1Alqs0I1om9'
        b'MX21gi9Jd3WBklAS1MVx4VJjKE6DszRPF46js3CMErmS4qJmx7hGx6A6dJnk7QaFhqD6yAB0JiBU4RoYistx49E5qScqCo/gBqNqi5SEhbTr+3Heak+0D/YwggzUugnO'
        b'a8aRBm1H26C9S/GwH/ZEx5A01HRPFclqpcngIi4WFRmjXagB1WqI8x2q0DV0OoI0h9yrzTuOZM+E6l5+DexZkGSMagdBHW3I+OhYKWqCoyoL3JvCPoLJaGsQQ36rQRdh'
        b'Fx66tunQmqUmaSPtAucoaKYB87s2GXESznekhW9sSKsikcMqtguvfpqIUo9GRJVOtt7ia7a1ctFu1cwlW28i6a21/NqVKy/b3AzKuRJgVDz2e9v0iObh5qE/VHx77aW8'
        b'iBK7pE+l4jmX+v1uPqi/X8CKqL5Ni380/eM9/2PLfpP5DTe7o3CYJ7v3xjfDRljkXRjXt+TzxnOBKGmm/RWfyEtVt+a+pzkY/nBZ8KisNM9lHz0X1jTSdMv4y16Obwd8'
        b'43vpk4Hf91t3MG38yYXOPzYd9f/5yNJ/1VXb7E899OXKhxXl9+a59lv5wOvjvX29js6vnJhQOsS8j9+gjz+Rs7Q+dNEIXSTs0gedu8B+wRFfpnKUbED7OhHPwW6o1eZz'
        b'DoJqFkFTggrjgsPSoV1LPYeOozotppgSKilpNtFWUqx0CZfDde7oc+gYuoqn3q6ebG5wEpVSdzdqteg0WzYO0HIKO06ilVsuQntJymIp1IRovcY5c+hzPOyK6UhqRye0'
        b'QWqCmSx0ttx4XLfQWQ87N13o7HytK36ujYo2fwA6QyJGoBDXYQFXhCEjh7EYrOMoPxkrmNXmrkE6SuMlqIG6uUdAkyDY039JEFn4jRy0hs9kgUNbBqFmZ7iGFbxOrB6W'
        b'2jA1OAxF5s5BoWw3wAppFsrtO1oI+/vPpxpkgBva4qxAdeEdWZbooieNbjW3R6XBIYEGUizRycE0y5IgBfakjpP+B5McQ/5E9zPdSFIdCX0vSVcUi4lf2IZ6vC2oB9qC'
        b'/sV3aFMW1w7prjYZzEw0eZLMxI6kRKPenfvGvVPYGkhAjHgSxVN22IDi+Wfv9V/OQVz0pzmIhjS2v5WASDqrZwLicCXFwJw7DR0N7gjZfpL0Q8hHRdoUxBGBlG4UHZsG'
        b'lzsQBlATN9cofsZkoZQbBqeFkAdblmvJnOAg7KTYlKgOTmuzEKMTaFbTSrQbbSWPi1xgF8suhFp0iB4FuYtZCqF79LNOblYhHMsWKkf7Vo6BsjHuCyBHl0OI8j0oTxUq'
        b'SVu5bjJhqiIphHBoGsuN2hlmhI4r1MRZhk9dVAhb0BZaez9ULXOWO4WiS1CtSx/cCm30/BoFjeEsf5DmDm6MMAuOocWNQIf9soMioFiXO0jy0lhFZxNjImDXmKCEJF3q'
        b'oGI1K8wWcojY4g4VLM8PDltrSNSPMswoCdo7Z/PpUvmODmbUqhtKaSqfe5YgzDrSmSWx7RjKUvnc56TGrJkZzL58TR5AU/nco+YMC/SY9e+l8i17suyv54ihhWZ/EWMH'
        b'ynOSaUlIXPBeujowFLa7QLlz0AYsTZFAIqhAzQSthATxyVGL0BPLL8GoAprVUtxbM6DAMhKdgoP0dXa7sew99ySfBcf7DWfv2JxiS7P33BUP1D8GbeBoRiTsGY/nbHOn'
        b'3L1pwbrsPdiRzCbhkQw4J4WW1ea4DZUsRw9PzMO0VI2JmCbpuc9SzDyR7c/JBSzjrmguyiNRuSLIRedYXO4+OP9v9WvSk/VrH4muX8npk4kuwGVpJrRYroUCllUH51Po'
        b'lJOiHG+4tk6q0iXV4aYyDjWBr5Lm1BlDJSrRZtWhk3CKLpSxXqgIlTgRU9Ucbg7UMkxe3PdnUBlJrPPHkhsJPqWZdXmz2NXTmYSvjWbWsbS6wCTYPQ72Jc/9fKBQvRm3'
        b'YPKbQZrIZ1Ntpll9/U1V6D9XX7/T1HJjlF2lxwR/+0r1M3tv2dnlPntasPrzD69vsbMIeNHy0IARygCHX6QbucK+oxsc+gTIvj+51naAVf6+hp9PrvB546uS9xwXlFc+'
        b'uDL9xe3rRxw97ba0NmrYjPKHFuuTE/7x/K1XFU2vVf2j8NisVZ/PMu3TOuygyfAXVw5fsOfVSzO/DAmUDV/qGZd51a7QW/riyGFxJUfivF6w2H5y4CX7z0IUN0cPe8n+'
        b'2U/eLvyHQMH137HS9HrD889o6k48WjPqX2+Ptl6ce/PerYJ5+19oU4Ts+OKy6KufZqZb/jZ20dgH0eWeljfGrnzFpiBn6iAv4VtHvh+fNN/kwyWr5KnPhtSef9jvF4v1'
        b'fu9VJWlmR3/Ea4amJU0KHn9M837T4ISX7v9rRMWzl25kpd/bIfnnmG+edvzowVtvTx8/Zc7I+SckUzzfzp/zlPR06ZrXv/1l2XfSqiWijfs+veHacm+2RfSvX9fb7bo8'
        b'L2xT9bKNz8vWlidYb32ptimx6VOHL06Me93ilOdy7gp/Nyh95yXTltvPnXT5GS0QLli58kez9+OXKa0O2MVmDvrBy/63EyFVX7k++33odfsVayYZny9/69CCB6Kvq1a9'
        b'tmpSqjKmtXb305oFE1rMW97PdJ6TfMZ48ptVDhkj/C3yn35unN8mf78v73ts3TVJlrF46+K5U2teH/ajpPn+l6GDnFeMTuG8Cp5T1CRK/pl6+qFRY9irf+S+/Uba4DOp'
        b'f7zBnfxtct3tr779+NugRWuV/2odksllWt0d+sjpt6ZNeY82jfV79rjjZ95feN1YNeOu6LMH3Dcj6gvcswpWpKPKgxdjnA69m7H918pZL0z94u7odrvbP8d8ubk43Xjj'
        b'bOMVv0wd5H3gZlZB5IsfL3xpTIpG2lh6afEPAVdsQ99UDMssmfJDQDv+6DZsxrHYkt9qYyeeiHL/4ebZbRMDwKHq5Idjxpmrj33wTc7vzXVXS5+79MGVCfuf2dYnW3R/'
        b'0k//D2/fARfVsf1/793Cwi69iA1pIksVsVHsosBSVMCOdBClCAsIWOgiVQRRqVaULgiCImIyk95MLyam9/qSPBNT/U+5uyxq8pK83//pB9i7995p58zMOXPO95zqXSPf'
        b'GH4QFvaT86i0r6JP0ff0r3My0ntKj/VJP2kvPBZ54dOGz367vMN7ve8i69T8S1bJnZ2N2VoZz25sMzOWv9Dg9do3sndNp74y+ZFemLJ0yYIc0f4PQ7+c/HzFR2e/Mb4W'
        b'lvL5od++P/3vD768+dmX+Sm3JoXN+vRiwvI7Nyprnx/YNTX0p9KvH7u5//PWzXdPJZ/f+u6Xb4YlgK5b894vWldVuvpq1vZU00d364fXWAOvbQ+/HWBnEfxI2lrz30TW'
        b'1h8ta/pNnkrifqDJWwe7iJwdAM5ooNRUgja8JqNuyn1R4DzBqIGjO8djq6CPVCpuWzQefGSPjhqhBns44rI6GZaAc8x6DZQahaiB8/AYsX7Mh1eQvF1BfZudXXy3w2YV'
        b'sixmP2mBhSds4nFlFFUGBkCFMzwHm0gLNgSAZg9OqZnUikDLYKt+hpzBin4HHOOxZXJ/tONgGAoFlwksYAPjBYrFaMvp8aZ6QyHo2alQ2ZzEERy4luNgspzoBwFJ8CiP'
        b'IaMAMqz+zgSFi2kmPXAaSflO9r5r9DH+nILIUveQLliBAniWYgKcthGnY4IimwxpMBkJvO61D1ZoQslUODJYakjxKN2bUT9wonQk/YyokGRXPGiElwpQ607f9oHnnP0o'
        b'kmytLxngaaDdiqDIksBBDSAZhpHlyXmgUeMUiiGjALJ9MF9gzUMQY2BjPIGQUfyYLrjGQ8jcYCfp2hyDNUqMwSL4sX2gg4eQZcMx6s3dBc7YL4F1GigyHkIGSh2onlsP'
        b'RqMIDAwJSZVyWEFhYEg47CB6ZAYY8gONDsogFQ4MjoAWoqSKJ+E4egQIBs7PHMeCYRwYOAbr6dj0wEOgi+RpBOU7VUqd1JrcnAvPrZcGOcvkOKDPGRb2IsGvdz08S5q+'
        b'CZwOcIP5E8AiFCgCO31oVO8yeMleMQ4xi94zDjLzghcI06x0dYyCRWqQGY8wq4YNFMvWmwWvSf2dA1bbpmEBG5bJKcbMQigE/VMYCr3qgIN2IXvVYDIVkqwkmA5gIzgB'
        b'OuIDxsFkPJIsKYeOQB0ohs0YaACvGqhgCLBCQO2ew7tg3Q6SZLWCx5KBSmNKutbZsEKtp7PwIsynijo4AC4Txkl0D0JPoApXgioeTYZk7y7qit4Ae+AJhUrJ7xSCk/AI'
        b'QZSB8+AK1bdRScFSexeKJ9uk4BFlu2Lp6UIPKAe9uFOg0irQWYUp604kY5KN9IxOjCnzQYPWj9tOMGUHQQVh2zXwIKgFlfvGcWU8qCwQXCdcZecCiwmojELK3ObBE5kr'
        b'SMn+qFlqRBkPJ6taBC/pe5A+i+F5U9QrxAu7YJ8KUXaFguBCwKg1BlR27gZDakQZ4ii6UjbC0/C8ggZ2E8eB6zymrBbk0/s94BgoygK1KkgIxYMg0becQlu7F2R7RpCl'
        b'gSLKjMPpylDskofk2XQ4CK8G85AyeAqcIq1dsnsTPUd1h2MqSFkKpNGtQDk8sJnKrsWgnciuYtBNWeqaAnS5GWiGEyNHT9fgKK2zDV6eQtvpyiomUdBLPKqTbC3HQAs4'
        b'o8Q4CRWiDAys0ACVwdKFZPoYbNVSagLKktECoMKUCQDdX8zggI8KU0YAZeAcaIbliIfOEas6OOLij1FlYhNbgioDZ8EgaWIAPCjjcWUEVYbKPrINFs6jnFcPj4MhfFsM'
        b'xmbx6DLU6svk7kzExPlIioVl9qAU9qrwZS4CctcYtaCLwMsiQOVuBx5eBjpyyISOXw4O4YHRQdMGn3wWmsBLqOHmiFcc0QrXSUbeCDYuwiK01+xxCfribsKX5hGhNAB+'
        b'OVKBSQD8Y2hY8XRcBCsipHyplxBnbgXNjA6o5UB3EDxPj/uO5cJKKY+aQfpo3ELrmXmEDZSh4KoKAyQCR20IoG1rDMH2rQV9aCjQzggrJ6PNUVsNapvuJQSHkaZ9lMoB'
        b'18GonIe1UUibHdrUToCqfZR7B+fB6zzaF5MqWMSD2lKjMqh+cmgqgbShbQsWEkwb6LMhbBAHajOViMt4RNuMZZqYtnZtQmZXWLJY4ewfCEuW8JA208VkokeBk5bgsoUG'
        b'Co3HoE0BPbRhXWBwHsWgGYMTZFenGDQbLmMm1s7ygicg0GaCqyoQGg9AA8emEsKvEsbiYZKBejpMiIFhoSAj0I0MIziyCkfjQWKONiyX+6EtqWY6GcbJoEC4Gs2JejKM'
        b'+lswa+HHBGjRxR3Vgs3cMng9ibb2sKHhJDTU44AzCjZbBS9TvGs3PAx71Weuoh2gix66gnYRoXT2OngVVuCRagZX+HNPG0BPMOcrVirlsD8YSTsjiJMOOco5xiBHsBfW'
        b'u9NZXwnzEx0R96G5UD1fgY8ZYAO3B23hBXSzykeT6JwShwAtCzLBJ7RYWGEZQ1PBPngS7bf4vI2NABcnwvBOb9ZE4k1A4YFhBenWLmcki5KnHGCrCsdGQGwWc0m3ds+A'
        b'Jyje1hWtt9EUxKqvTdjeNBM24Xvg4HwVTjrVk24hhUj6RMNhroLqUpzupFk0Pl//IsZRs2necGwCxG4SPElRl01Ipz9F2wdGYacKKkhwgoic+RQjWwVPwW4yy7pjNMB2'
        b'PNQOHMmg+CvYirYX/NSxSSqwXRxaiDABVoNScJLH2jWAC4R9MNYOVmlR4bRuHrguxdi0JtCswtt5SCjYXxseJwsPBtu56GvA7RZNo6vDKLiwZgESQ+U83g5Wo80S82Ra'
        b'djYB3O3dpobcYbzdXkR2AvKvgYNGcMDJxQWcj1fh7aZFUvGhFZ5cLvUPFMB2JEpjvB1aTdrJtJ7vDAaUGlg7P3YcbbcRHKNb0BAogZcI3I5A7VynGU+FNLJBRIyYIu0c'
        b'WGcHFdAOXuZtI4P2oJsA7fBO5yvnkXbwLNo1SNSxyWi3pVA7ArSzzEErfs1yajcZFSGZsCKQh9lNQbNBjbTTN6Fr3Vl4Plrp4k8hdnFojhGUHWz1JCvxjERQDE5t0cTZ'
        b'8SA7eHQr3V/K4SBoo1lO0L7cH09xdjOjCe5xp4OVwiVQ7AjrCcpuvxs/zKtsCJhOazmOr0bBdCb2cr3/PXiOQJuI1WD9nyDnePzcLIqfM2CFgj9CzknuQc4JiTVBB+PS'
        b'fjUQC8n7lqwlZ47+TvkLSDmJlpDHrsl4/Br3O8a1cXfFr+vMvxc7x/1uJDQgGDchqRlbNXAp5hIzfOrPOdFyUQlC8X+JmnuZu6OzUhM1Z/7HqDmze+0M/yVk7ii2eGD7'
        b'9Z9ZPJgCs1sPsHn8QVtQCzDUIP03FWpOgFFzn7P8WaTc+H+HdvsSVfoNBgWmMP9XaDfx65yjHisRaSDbZo0j2+h35nctlhGfgpTteyccW4NeQ3xyzTL24LooedvM+3xf'
        b'9fi/ypp7EG1HtI5oHzGO5/DvI3r8Z1P+rw79myiIFxyRxHJVglhntUUJZ7ORleqW6pUalBqVmsbLMLKN4MeEcSKciLuYidWO1aniNovRtZRcy8g1Rq3pkms9ci1B1/rk'
        b'2oBca6NrQ3JtRK510LUxuTYh11J0bUquzci1DF1PItfm5FoXXU8m11PItR66nkqup5FrfYKaw9cW5NoAXc8g15bk2hBdW5Fra3JthK5tyLUtuTYmmXtM4gWxM2PtiiWb'
        b'TUpF8WzsrFh79NmUfJbHOqDPZsSJUkCsb5JSKXpHH42VIRkrx1gn9MSkWAHxDnW5KVuxLDBUlcf+vSHuHsdJ7Lmk+QQF1Kn9bjJScWoHJX1m3hwn+tedJELAn+ZOKExl'
        b'pVO6WC7TcAnkPdwIOoD3o0N3M+LSSZ6G1CyceDZjokufZs4GJ8u4qJjtlulxu9LjlHEpGkVo+Bxih9UJJfyRU89EW+GEi6BU7MvlF29JMq4qLXfHpcdZKjOjkxOJd1Ji'
        b'igbogrhLodtR6Cdje3rcxMqT4zK2p8YSP3TU5tSkrDhi1czEi01SDna7mpCUwtInkXgw2S+T8264SRP9urD7E+8ZSAnhytNBNeJOlvbL5arHoiyVcdhDLSPuz4iEaWi/'
        b'Qo6RGlEaXoC8/11qemJCYkpUEoYM8BBjNAQYDnFPR5XKqAQCFomjyTfQU7T3lrFxu9DqqrRMpQ0nrnz2/L3lmMOSU5UTPbpiUpOTsbsx4b173AblgpuC7OSkm+KYqOSM'
        b'eXNvSuNT02PiIghFglbFCDWWJDFzb4osIT9VGLS4sGh5kfILDIcmjkCdIkt4UKuI2SfK1d4rJOZrETFZC/eLQjQ+8ymytgn+AlBswsT6Y2eyP/IvRN2lroUbAwN43ziS'
        b'GYWUO05HRDHiP4qm6YOdTu3jKHv90Rz+EwATGWtPjEOJiUKrQCRqUiT18aOFqQvRZMU/yFcTFRubSD1C+XonsCJm2rTMOH46KzPRPFMvJw8Gbkzwm6VpaPBsjMrMSE2O'
        b'ykiMIcybHJeeoJFk5g8gIOlolu5KTYnFI0zn+J8njeGHR4MFPbEPMHbrJWuVpjNzYgoiUBQt9j8lsaHtREuOZvUEvESKDc1emZGktEzB8KwHFhWIwTVoUNTILPUQ0pL5'
        b'xSj2AZ18sPtz/PjUjSHLt5K+iv2Xk5SpFP2FRg2t43HZcTGZf4S5m7jc2TvgHDlqTKKHy+wHoBInSBpYShIx97pwTA9SYj3FQTF/4IUfHeWdGfIn5UMV8ldvT7pYoGQS'
        b'90napr78PX49E4dYAGP7w5ASdBgO43PaDKSwyZFeViGHR5GyiJR5+gpog1fgENERQknY1XnKXNClDbpR9fuZ/aAddBBDued+6pFhkL1D9vrcYJqOFbQ6wFIwAA7BLrTR'
        b'ejFe0eBa0p27d+/OXiPEyXksDbJ2OU3zX4Nj387Cz7fAk6BNCcv1YNluarpB2rt2EjzqYM8yc+ARsSPo4p0wEpSgQIq/5paB3kB2AWrxMCqGqOSXbZ01C9HBv1jG2lME'
        b'z8Aia3g6mNjOtzuHSOkdARwB7ZPwEdXBLFSGA1EXF+NoUrQQm3DSFj+HtCA57Hf0U6BLAbMeHpdM259N42mfxzlWwCUhHFDdlszjUmCdXC6gDzRbSnBqE2d42H32PNAD'
        b'rnGMbB+3M0WbOHuAalAL2scfgGMKMSPbzyU5g4OZNNcBqKJZVvgHRqawjCyPSw5wJUNnPF2HZk3xDfXFD631hWU72HHb2Ep9rUmgaCmJ7p0OjoASqqOvdYZD8CqoJjq6'
        b'MajGZ2+t3pmr0VOB1qgRGp5AqnQzsCxAoXDm0haBlmnwGig3hRfhRYUJKFdIdeBFUOG/LoSJi4cdoNxgAayMJNwRPJ3SOzI818nP34zJxNE1QDvSlg88oArsCevqH2YP'
        b'y3xhZQh2PlWEwT41lxI3pGA/kdFMHVgC2kQieMVnJuiQMw6w02e3CWxx3YoGncRoCsOWIv1d6YhL4GVdeJq1gydhE6F+EBiDtVJJehYiPz7wLGAdQP5MmjC3KBmehgOy'
        b'NPJe9yRYwtrC5gjy2h5QYanchU/PGYEMPdXNRu7kIzTbg5Z1yjR4UYbfyl8Dr7G2PqAW8RMJs3XNDI4o4RApE4zuW8KamSmpa1B9Vsh4ZYt3srar4SChuQnoSRmneAI8'
        b'RSkOK8E14i0NRkLc8X1Q4qjKmBPo7B8c5qt+hx9RfPbIwBNJUsSi5xBPsmSagHpYNQknNvLHZ1bUEAhPg3JmCqwVpoEeOJLpih7LgofAVXVWHnB1nqqaNc7rafEMrGVi'
        b'4WUJA0fgxcSFuj8IlClovve/+1xynVeq8TKDx3f/+MPexe+0fJ/1fvFqSSSwWchWltXV2L1jKVrOtW2aGe286dsVoVdNpj26UfKk0fTln/a+62i5Obf4jvCIpYPnjvjX'
        b'SssKwJ7v79545rlvsm68u8yw+XimtcTIuj1yTUDL/v6PNn0lWfxyTdG/8rn4kqnugSbLnjU5HAR8XNqAo3Hld+Y/xdUprY6k1CqSnXSsDU4d3ObV6NCYLX/DRn+Dxexn'
        b'B89M25v+1Q/fldtX22oNvbTBqe3WvkcD7n7TbDd/jtDDf3PKnvMbDB49vrjN12h7cM6cI4ZZJmHPGTyp3WXnPm/mmQ9mbfJOdndf81DrpsmPmrwy7bGZ3Tke3YbGTzkb'
        b'ds+r/37TO9zXmx5rHJ717+j5CYkfttSe/2hyd+6Sj5svhT1t803z1v7nfjqsfPjzCgAvnU7P9p/qeeG7+PIf6lNn5T2cMH+ty7yW5157e6Zb4g1L1w39Ni+KnugqHJ0W'
        b'4vbKhy0njp+Y/9MPuyUeh01ne/U+Nhhk7tE+uMRRObzhX7YHTDZ8NG9yw5ZVu58dGcu8cOitHeuvVL80xXNNwVs1Cz4MfOaGt53g5hV94bUtc+Z0HXc2fjNsRebUnR83'
        b'ynb+4KQIvNN04PSBby7OP3lrz0LXmsyc1asEuaOpH/w8Y4ryE8HNbWYfd3Xenv/wjU9fjZnyUt52/6N2P7kGxlR+fKUtMXau7tkO62eb3Bo35L0Q6t5oo3gpO/ZV53cv'
        b'v6n/5TtBe91OrAv9Jtcr+uHmJdkPsXte+IXxvtJUuzhV9OptK89Yu5d+k/x68AePXd/rv2C1xlRnw5GI2dM7ja9mXX+vtyK+Ok1/U9nrrpYrE6Qtt5L3fv/DrG/eX/ZD'
        b'2U8/3djP2tkKLq+Mky+lR4vX4LEwR5dAjuGy4DnQzipgN6ilR/WDyfH0zN8/aC4cUPM8M2O1ENaA87CQOiIXwFZ0WQEu4HXIBuajBQqWc4wUjKL5CYZziWVCN3KWo1+A'
        b'FprLw47gILsIDsKDpAGRTth6CQ8uD1Y7LjhHadHzxaPw3F6A5lAHqAT52NVYHMlZoxlJA4WB8nmwGSeFcgVnYW8w9ibezzlws+gZcGd6GD51BN1o2axyFjPibZyNoZha'
        b'D86DMlCvCHb2s5nnhM/QpWAQ+xBUgw5q0W3D7pgqb41k93FvjVFQT+0LpUH66lQ7y/eOO32ngBOkV4YWLrZOfIgz/tTVFbTTXp32gn341BUtLuWqk1dYrw+6aGA1c1jm'
        b'6Ad60E4tTMDWVRYHxrWkFLkACmAhNhsEakQ/25+AVqBmYRps5QO/waNovAanwVoNKyg+AqbH+a0LAKKWq3+gwhkfowbxIdRsYb1oKmzyQgPWROlaLgClSljlh90FQHOw'
        b'Qi/IGQ4qOMZilRC02cNKOlZHlA7YueCQNrm7AZznGF0fDglB+NgcH3Drmuai6oKcnQIXgG6NCi3dhLBt4STS4m2wNhwfJM+ERzXCtW2LIafE/tGIuSqCXfwDnfwCYbUu'
        b'y+htFyyEbbMIMU21YBndm4mZZdt2AbYHa6FVvoq87c7tI3aWSkTgE2j11mLE2pzMCpwnbGm1VkdJDB6CneAUqGb3bocnaJjHgbmW1FxMbMXL3Nip3hLqZnAIscEgtXsS'
        b'mycanQMsaI2wJe1Zy+Keox6CY4tIgFIRbGSRvHQVtQdzhg4SHnqlLgoSkq/TC796Yi8lL+LlIW6CQdhUX8MeDMYWUWNCMWpADbHKMuzMhcQoqzSgB+qXwakIfCcRDqks'
        b'utuQgDpGRtkXzZNLeEaXB4hR5U1RttjD4cRi3j0CXobtuFuHHHHTBmAj7GHRLL/uQ4PbXZu7Y4u+hv/DPMRQZDxKYUU49Uw67kisQiI4wrGRoIe8lwkuzyHWczSM1Qtx'
        b'NoV8B2pgaMEmM0TXmXHj5nMj0CvAUY7FhLnQQHSDxlBi6FOZ+SSgkUPT93w6Df/Yh0bjpBoHsUHrHvesTDhKxswGXNBGoiYfwvaSnxkLeucJ+bzwaL4M0ZtEXoI9sFvM'
        b'6MUKfFxyMlwYnNPiNGgCFbuz4KBuGqydPi6BYYy7K6z2DXSWi5kQH4meGSyma9Np0CKD5yyVjjpIIJazjNY+bi48nE2pNIBW3W5jcFXpmE7ZXSuOm2MDr5L5kmyAhNsK'
        b'7MCCVlzHGeAidkYSMaawU2gImuW0hItm02E/qJXiwmkJoJNbFDqHOn1MnqkqADHpnCAtRi9IsBSNYi21oBwHheCM0h+7Z7HggBQOswYg34qMky5i5jpQD7rGzV+9oJxG'
        b'VRzZA7uwAczG03WCAUwO+ihfXgSjNlPB8XEXJHAJXKYr0jCaXdeUxOzMgUZw1IS1QaRrICvSHpiP7lYEowb5oRlM1gdXX1glYGzgOdFCowVpsJuyQwk4a42DiJ7M5N3T'
        b'FCxjMF2wFpyAXdT+jdSdar292DOIDzN9OSmDOscXgTolHSoBKIF9q1ks7JLGeSwFFY7+zgpnh6BADtSyjH6CIAo2uRBMCrwCTu7WaBw8joOWYzRRGXZikm8TgSaZH/Gg'
        b'2w8vmMz2VfPJBCYJnj+PZbxArzjIFLbzdixhsKMaQOMBD7KwCNbPpxbkAlAOGqXoLhrDbl8VSxvCEQHShGrmkGaHJpnsAH2OZBdC+5sEXuXAYdC5gRDLJSNj3HYnMxg3'
        b'3YEhgVz3v7eS/X/KNaYOwfAQ+vXnBjUmT2e3AavHiVkdVsxOw8YnjpgrfjMQSYhpCd/BZijuF4kW/qzHTkE/01hb1o414rOMSVhzYnLTI4YqM/SdGfqvxxnh3+RbC2zG'
        b'+lksMXvAd2JUhx4JeYkNaDRrGTacGbDC20KtXFPNA7yJUSHkYgrEEaKLdBH+JeYmIHxk/xV5hBpljtejHuIwCR/N7M9tYEyBfcsDrGAP7tZfijdR/B/jTYxhd30Sb2Ji'
        b'NepgE24qkwM5s3eyjEtwsXTAB40us+e5q8Lh3B974q83r/bPmvewqnk/T8Xt4M+vLRNjJ9T4l2NvdLA3JRH0ZCz2D+t8RF2nFQGKE3R0PD1Qw4d+f7tm3E05e1M3Qn1s'
        b'H5H4x9U/rq7ebpllZkpiWmbcA6Ii/MM2yCJUx7Z/1oSn1E1wwCOgzEBDQA5+1We+/7QZCZjii/6M4s+q63YJScVBmFLiU0lkCcuo6NTMjAkxnf5+/fG4/ljmT+p/fiLH'
        b'acQY+kdjnp74Z5W9pK5synhly/1W/MO6kv6srldVdaVjW/VfL7Tnzwp9Q90B+9AHRIZSRTv5R3yC2FWHBGyIwOET/rAJb00kGIm5QCftP50kElprRuof1vmOus7JfHyO'
        b'/65G3YjoqCRsbYpI3RWX8ofVvq+udiGuFj9LTSBJmnbVewO6/ONW6albFZOUqoz7w2Z9NLFZ+OH/qlkT0Kv4ILGUK2VKBfGCvxkIFEeIFLMPMvxhYzY2jhBjdlRS0gSD'
        b'BzZOJcXxxhe1ielBgUXWRSUqSWiYdahDiclxPunpqeno9bgUtdklJioFBz6LjlMbc+4rBQejSeHj0SSmkGAfygw0ixLR6/bjsUAm2NjvK4QPBZScqCQhdx5gI5xgoMEE'
        b'xHZXd0bTQKMTdB9CUKBiD2LTwAhB0T52L7uDUaECCS90sAQALeczJnIZ2ffyCYYGfiPh8yUaMZmYb6bmwFLlPcI7PIxPkZzTkJ7j6u+MsQdyRSA8/GfgS3AYjhqugLWw'
        b'kESLmG2gpc7tMCFoxRp4MNg9hETuUJsdQJ2HTh4o06f5G9tCYLMj+l5d8VpfcgS35h5McQisgQcx5mVg3RpneFTIzEY63qlkPa8lsDETI9qRej6aqwA99r6BLn6Ba9fA'
        b'qlB7l0Ckwx0JmwhOhkfX+iLtiwVlO2MngTZwbpMctJvt5BhQuVcf1oFDYOgfkiR9BjdOEBG2UT6QJnfw3LVC32XOJ+22Cv2jwcNdhpdBuUa3QUmkthk7LdH4IwOBshK9'
        b'f3z3Lz5V/XpgtsGKr+zk0avf078jWb/RULBuOGVt6ZxLs88Jiq1OVNX5z77l9cve/VbKlSnciu8NTxzeefH4ZVeHb+LfXtQUafSOU1DeZgO3xitPN5YdKtrq+Gjuy02d'
        b'O3b7W3x0BSx5RS/+mvHwjiRFzCM32x/xKXv27pa03OHZFwVu4bNmrH1S662+6WOPfyp/3SxerkV0O/tN3or7Nd0ZoD3ZSAiPh00hZ2/Bm3ZpPKTWNsFRf1tHkTcoiSFF'
        b'BcKz+vdmT+OYGXuiydEHjw+B50EhLFLhluClOJr7qk9Ijrl0MucTtJSAEc40wFgpeAyp+wSeUAALIU6ETt4EB9UHMDNsV5gLYSfoBlfowdEpTxtCI3Da1lXDcdwajiJy'
        b'j+sk94XAUxP+pi725olQLUhEAcRhebn8/6QCMnkW+7ESJybxF3Bcf6SG3TXn9Ihqx92VCIT/zp0yQZGYUJWGF+F9zRt3G7RBT32KVSbMkv9JZWIKDMoeoDT9SSP+zwNO'
        b'xz8o4DTL3Gv+FgQlrpJ6CpUk7WrsMzh+tCT+3SSWqfOUnGNf6uuQs/TgZwDU6CBGUJjfcwZXCKv/IHJ0gMoxFs/2/0xEJk9skGtyj1qZFJeiCqH4oMjRuIq7En5D/s9E'
        b'YQpk3z6ALA+s9H8TAfx+ggiDQhPjG8I4Jf46xy9NESWLf/cZ2zcYRihnHZ64O75e3j/ir/CLcfo59j7dOSIiOjU16c8Gk7yt/XcG8+u/cDBAa50wmrivuEa8cCiDGCJK'
        b'qUJuqyI8Uv8qtlQ3Xo8fZ+6gCI2zAI0zR8ZZQMaW2y8I0fj8oHHGDhi4qxPFCqsgYn/eIspRpsFutHTxJmjWNgDWE3+Lx1Kx/T3STmdpZJKVnSlNuQ2ur4aDSj1wDJxP'
        b'18YvnGZdcsAYMdjbcDjW0nGJLnrB3NiBIYGrjJcQEEulI428g/evSqMYBfoYhOO3rluzznk9x2xbqgVO7XHKxCgbWAtaVqOVvycbm49B9biVRsQ4xIhAF+gENCbUOtAY'
        b'o9w1LZ63rLOR9qCeOk4M+Bqh+paH001TtRrDKhHphNtkiAPKVq5eSGwhQmcW9MALBiT0vCksmuIoZ4TqBOB5LsSuvh1tChf4E1J8aGwOW/UTBHGwC/SGkkKzNzg4KtbC'
        b'y0gacvYTMtpaHKieAipIoWi8Zir8uD0YjykUsuCE7T7yzlx9UOfoAg/s8XOSO4sZbQ8OiRun9Gh+6PN7gtG2BIZAqTodpMiPxGKQwDZs9HMOwkeaHrCZEYdzprrwJMmp'
        b'AUu1HHEspbZYPycXDNCpICNNYwg5LhLBKuvZ97GjVMWOvuPsOJEZWXWQ0b/KiMX3MiLulfZ9jOgSRLjN2xoxz8YxjkHMo2uzl6GxvcawT4UyiKbEOgnrCR41AgzT2C09'
        b'u0GPkuBrBIitzhI4jzc4Rl8tAmema9BLH143RfRi1xDOgedgWwZv9AIHVu1k94YmE0pZpsImZQA4A4ZdEXdL2OkOsZQadcE4rVE57F8TQHPSIT4sJjUZw+OgjyInBdgt'
        b'5AJBTsKDYvLibnCBocBXRPrAVIx7NUEvYi7NE4ECu6UasFcCeUXyxhhxnco0wPOtwmkZlivDM60YK3jMUi4i3OiFhNBSeDr83pcT4CUan6TKmeQ9pZkMHfwI8rQHjpF6'
        b'18aDqglgV3goEONdRcbEt2S7ZBHJzogmjwpJq2NKfIAmAxz3GNXnIncIdJE7+4NheCyQZaxBicgDidcHaJyTZlAXEZ6iQq9S6OoiU3qvEfSuB+Vb+SxkLCOWcJP2+ZF5'
        b'D66Bk6ANFw+P348BIyirZF3ihIJ6Hw0rXG0mw/IAbNVU4JUElJMDfrsNop12niQ4H2hEDDOGjeOwBDQ/INObquwgUKAFa2JADen/LJFA5awzCXSjVQW0giEy6nPN4QGV'
        b'JA7KTdTrymy0HhHb5Vn7jVhkvW/VAvlZeOHaYEFXp6MkFV4FRu/j5Qden4NXoC2wiI7RWdSn8woaiwzpWH0YwrjZgd7rAoUeBLOH7sF+0I8xe36zyD2pg0UsKFItC2RN'
        b'AL2gk/TJHjasUMm4ym1Exm3xIAy/zQ2tEDNC0QvsQgbJ2NcRB5EZ0rJZ7BjojOaWUA9URqGFcFUYaT169WQuYi1fZydwxInEeDjK7YVXYR8BP8Ar4OiyiTnkUAdVyDZ3'
        b'V1pGPjwBj8Mj4LoaaUpgpuJF1KUvH9QIUBUPWsDAKOjGixi4NE/OkRkWgi5qEPddtPDOEjIsbEdL5/ZlZEj8EekqlbFIGe0XYyQvxqcdgFeJT6INKukirEPfS9Y7MU6z'
        b'4TGyiZWt12FMsoUcYxAp25C4lcYJOp+GhsH3UyQCRQbcXmBBv7TVQ32X1WuhFSvA2lmXflkWpMuYxyL5cU2kTBy2n345tlDCGGwPFDKRkU7e3Lb7QykRMRH/TCGSB9Ie'
        b'tbD2uEsrllmPFtQ0LlYdqJpIPrwGyWbdoz3e1PZOiEuJy96VvrhKm19kuXwzJhMnqwK1WaDtftWeRitH6j0oRx+OTVDqYZ0ADoA6I6TXuxtEz4cdoCMHdJiKlsEjPlkM'
        b'OL7WFA4sAbWZy3HxB9EC3YH9vRD71jm7+BHYqf/aNc7rfTVJmQ1O8NQEA5wOixgNdsoi0QZ8ksyh6fCwG1q25c6wnLoskDkyLUwIe9Ca1z0TFicua+8SKJ9CnT70iEdc'
        b'yJWUN5ca3AovN5J/vjjppR/3fTzYcsZANunrdSK2cO6qcqfYbJH5xWKhZPYWYdbDdgdGBm1r7AJrrCMMLWfULPFtcX3iS6dnn0iz+vbagtTqlplL+tqzH1n1fnb7piMV'
        b'm8DcQ95P7ol+/shy6WfbP3Eqvcs1CALSWgQuSqupLlbGRYInCmq+tpU2pIcGXfnt2lR/i7zerIerdDqfd9+vVfzQU6HPrkhobR5ziP76+7uDS6+83vN81PBIRuruZecT'
        b'WtrrQyeHp4asP9d+wsfRUz8nbOal16NmBUyqea369bSwPe9GfVwvez8XiE+cNFhQWbvruefOHGyorDl1teyNnFfW9To9mrzS+PhtH/FBO8N99cs22H62562XP807JtO5'
        b'+OsLGV3HJ8eaCgNTzv/qdu51v51vnK1ufCpoQ7Cypf+td2LKn00+WdHRd1fr7vlXKnUu6f9+UP+7dx1f87ZJMbhzcfJFqWGOs/KcWdyzn1ubvNL87e0v2odWGO8MSWp9'
        b'edOHxmeDTm4Olb6srP2X9XtyoPjw7RUWtV62mQ0vCz586WxQ3cjyHPfiDdo3jLbZeK++9dor4o8sjN8++4S3z1DGrugdzpbSl4durt39ryrHZdo3fn77Uys41amhafZu'
        b'39ar2S/FhT93+vKVL+4cPLHz32/ZrJ6pDE1Z2Gv9ziqX7JsNHb/sCNlwqvG5n3Rv+3h+EF26yduoKME8Lz/1mRe9nvY9NOOpj4q/2Pzh8q8Kn663yDL/tXDzWzUFny3o'
        b'1c9bHtgb/VxKtEP2E6/WfFXl/oUB8PY60JPZu7P7x+Lbj/5yp+21l7aYrtD//IdVA9se2739eMftYL+rb+4vTfzxVmVycYD4MY+3hr/0NPspPSQl/P25qzdWDR3Y4yE9'
        b'vfdX35Q3e15PttVb8KbJCKt7+/iQ/OcLkg96vrA7PetO0jLjq6MFZuuXlNgNjnDf7/6X0Dp95FeT3b83RKTdEou/ei341G+17/34he8PhT8dy2Nv97u9d3O33IOCkGv9'
        b'wShJrNyOtm14VYRW6lE0UTqJU8RmUA+OSNG8GIiS+2nbIxEayYyG4LwANKO1jOYJR/Lj2CqpgxxehJXxKzEmeCq3HhTAYhIXYu/8jXBg9tZxh6jiLOoA1wyb5WpPH6Uv'
        b'jguh7c4nmNWCxSpfrPBdCSw8MJcltvfFSA5vU7sAgRMZJPLB5o18AsujoWqZCIwmEpnIns8VDi5hjzspxr6nBbjKxYwuPL0TPWkHKyYTj5a58AwsVoahbVLDD0jDCygB'
        b'0sAN4HIYvKSEF5FoX5uhyvwbBpuIc4GT80JQlKcZ12EbOACPUoBz39JQqT3aLQ9jAYkLZReDI/tokcN7YB2qsgmcVnv5wIPgID3maY0OXQFb1XFI+CgkSBg/R+8fRSNy'
        b'iYT1wC42JWjjIXE9BmEN6bgNzpd+YYsyANMHrYEKEaMj49C6eRFcJ23Whn0bZsAzJDqNE8OIQTfnHgpaSMv2uMHjNPG8Z4wqZhBsAaeoc0nR1BTB0ntCkVzawBGmMECy'
        b'aiPIF2sEMUFSZjESgQk1KmCjCxpoHO6nEoscBWDQgwX9aGNoI9zBpsyiGbnT/VXBU2BRLh2t4/CivRKW+/nBYZjvouAYrTTOIWEn5aoqz9U4dAXsT/bnQ1fMAl10/Ou8'
        b'Qb0S0bYEljjTRMGebnwAG1Asg1dDsJ9MGvZEEjM6GzgwsieDdEVvJh63FCkOqYIdaUSgkYUXtqNiSY1FgbBJ6h/oKGYEXmj4R1hwWN+fxt8pRy/2YZFf20XhooMlIXNw'
        b'SagPBhaAMjBAnvHfjTMm12tRJLo6uIUJEo5h3cYUct4YBrpMlQ4u4zEoNCJQIG6qpU46A4gPCmnsBtgfD/pUsRvAKXCY0qtuFzwrwd6J48hzWL9GQL3CDrGw5J4IT/Dw'
        b'PBLkyX4jDZlTCDphk8tCjTAafBANUIqWApKhtVRvuzSTJGiG1atwjmZXOkgtibFhrjgqCfFkFPmwsEqHpqhfBvr2SUnkIcHUMJrbt3A2H04AVIJhpTO8Ou7YdJT3bluW'
        b'uWynu0YsEWtYZ0Vp2YekLVWQgkpQN4WPUYD4g4TVBuVTpATOLwAdMhKgIFGbjJ+n13IlHAaXgu5PCDx7LencVtgZIfW3gWcDaereGERCLD7oo7XwmPJBaXvhUTDmCZu9'
        b'KP+dhoPb9y8YjyZgDK9akzZPBtdhNcZwIA7TgqWot1oKzgqplyVkHKymIekdxzfAo1qxieYTLvSma28jzE/XMZoQf8wZtoNRyhOX4CDMN0yFFU5BaOlGIhfLSNEchr0m'
        b'8DSl6fFNSJE8ikYNP1Iphwd9cazlXg6thmNS6jCFyBuAdDdf2OSKRDtwil0DegDNFb4RjVjxQivHYCc0lbFyocVI4RgHhzNBPaFTCMiPlzoYgSuwGg1aIDs3F/TRipvQ'
        b'/4saDqQCRtcUXMEepGcB7+DcAU7kpmMPQOriPNG/+SQckJv9/wZ43+Pe898HPL6pQ46giVWQSODvM3/tvJ3J0/HGZ+tCEr0A/9bj7IijlRPrwFoQxyshcaiSsVw+OSLE'
        b'T1JXrN+FAu43TsCJdb630zdj7VgDTo81Z8UcdrqiuYXN+CzDU4h7lgz9NiLxAXQ4c9aAlaAnzVk9iR6SnvXuTuOmCPT4iAmW6BvhXfwzjcMlykiGHjOWj7rAiTnU5sO5'
        b'8nt9l/AoRLh4E08H5WKX8VGh2obwpnZGdmxcRlRikvKmVkRGdnSUMk7DTesfZBxCGow99saapXbJskOfHP/O6avlo/efvmb64znStMnrH6s5W2GROzMfNug7RYNSory9'
        b'54VBatvjdJhIJ9fpHhh2hmfi5Kh1vD1pEbxAQuEJ0DQtpTrw5fXBCg2TkWIxOYScAs4I0WbbuZZHGoFD7g58GbobaRHgKighRy1b5LBdswgRKNEoA/R60ZjJNfDaGo2e'
        b'qcAJ8KjrDC8hPOIOGwhsL9IQnHTE3sW88RMULV+7Cw8RyZyFoxmxTKSpxBbWghECLdNJB9XjKCKkpPXCOgwjAhfB0Uyse5qBs/sUSPEeAI3O9qAjlJTmNo+3zaIV3FbM'
        b'+CVlOuJpZWtPsnfxubvQk2ckuGp7jROSraBRop+zimiAcfB46oP6dA6eI53Ki8vEwYNAr+4qZRaoQgvmhMLC+IQCuGM4tmJ8ngScXgCbCS8n3jzwqUBZhT4mvLwxHOmO'
        b'xmtN9qV+/EbrozvNZtWVOH9ZPDfDPsPQdLq9kdHhplmrR32fe0RPkRbBFs1dUeT0uclQ/tEl+a0HCgvL50xPvJPv27w72eB03769z137xGJGVcTB0/GPHDV/quXE+prZ'
        b'td/21/vkfFhVctt3yjv2zj+O/l77w7aKbTufuhP56iBnPO1oRiIY8rGL8H/34trPnL9bZRpuofguIyfE5DnH2U9d+8Lfes4FAyW3uU/+UMnrlx+fapVa/MyqIq3NXy7J'
        b'kCw4s0jfX3bBPCCp893Ohg92eIcrA0ZutKccue32ydWyf19p8nvrkmfw/ADjusk2otfnDD2c9PQzG32eemb5nqc3NTa3aYc1eCw82v7yjLXaPc9+8GPeuw2vbvS0UPZ0'
        b'KN50Wpg32/2ZweQ33lspGwu5cujYpthb++zunpy5arRpP7Q48/XLs45dOfbLlacUOcdX5zhPyrk29bNNi3506DMdu5pUZL30RdMv7zos15nT4DfV+qsduZtDfePmLGpb'
        b'07Uozqb8QPq7X+RUeJz8Cbj6h/sZ/vsHQ899ru/4VrTKv27+LDn4rb7PdOPyoEd0wgf/cgqzv5MnXfDB29M/eeedzB7b7HMvvmlyXNkLE4O31/909Zkbcw61Vjh45R56'
        b'dO6yzPSGzpbv64pH/K3CboPDdxfEPDTZtBX6/Pir1a2SFxqDHjOaHPz8Mz5v5ax66tX2j40sX9Pe+v5zMxc+2vJ05IV3F+8M13/mFe0DNy6dB4Fec98zivoidMFrtxuW'
        b'aA8/8tzRZMs4G+WPi60fNbornfKxeCzvwLpPPn7rVvCaYy03K1p633v8Rq3+V0+vsRg983r3oZTqb0+8tSn7wzfOJa9VVMzydbtzakP7kznV/VeDPr0RaLwZfrxBfrkg'
        b'bGx6qlSud1rQ9ug+w69/F2eeFB9R+MpdiI89OIAE2Af7Tqsd7M23YBd7eBJcogJ4r00GHHCcYaDy6mdBLzjPB6dDTx32QOokPlGkKiXWJyOQqETk/qLMWGUQhlHIJ3qS'
        b'w6YUKvN1oOld7+jntphH4iDdTwdcJRpaABI/S++3uy+CdRRzsAeeoGI3EvHBBbXYbQjzVZL3AjgED2bgk7hZwfCUIhgJ8+tBGc48Yb2FiCtr0apxlrrLS3ZgDQEcsiJW'
        b'+Z1aHipZBZ98I7EKSyxopSyZDuuFSNnqhn1EHVsHihdLkf5RvR0c4/snNeZgkZKP95kDOsAQhjClyVl4GQ4wot0sbLbfTkREoRC2KOWgIkrlRo+oc5ZCp/J9dyhpdFQk'
        b'bXYHYWiDzm4OdMUkUAxAJRI+lXIf0KBytWdzQ01IOKfImDgk8YoZl9XcBtYLduuRqnbmgRJlEBI8+9RxS2vMqdDYCYd8NGAZYiYPjmJUBpImqcboBoYFSgcG+0mgRZIE'
        b'7CwEJ7dRdXNL2kQtInAmjRQLymfyAXsxmIVXQZxANdVCEM2aaWaPqs3wyrgLPTwUAI/AA7wTPSwP51VAk1w0GmiNxSIzLy/7wwN8yNB5prxmAE/AS0Q7cM+hzNkRI1bC'
        b'MnBiMhrIKnxK0MGCQ4gPSbckTLgSVpiCMrTHIA1dAJB20OC3nYy/GHT5S11MsgLT8b4COjJQpYYmgh2wMpWUnAFGtyAFEfTC1l100CS6XKw9GCNvZ4RuokFqd2LIeoe9'
        b'mA9Sux/0Ekl3HhKiVYi/cbgf6DAniD8PUEfjvB0FNWim8dLwiqkT5GGc4YaOzTEvUAorFP6oNWQKBbMwPxYcoNOrGc3LMqk/6HIgCivRVqWrqZw/sG6bKrKwtg+OLeyA'
        b'1EseNHHG0soRKafXV48nHgE1aUSSjwUt8KgatYfDFoMCHrZXCfppisqOpE0aoj4SfC4HkalhHie0zk2jtDkNhv3xIAxu4fsvWchF70NsgfuuDPV+gEuMNyyegX1iZiNN'
        b'iUCK6kAVNv1i5pL6I0rh2JY6ARyoCYPHyTyeBkbtUUFYzABlmvYSNKNPzd4sNgZDsRkYVz/NU4JWRVgDe/4UVWICeyjbjiRgLI2GvKfFgKuwV2+zAMfoLaKuPf2J4Ioi'
        b'SACG76veAR4UgcHpsJWWdgmehqS4YKS2ueAqtZglsEJPILBCbJ9PJ1I/PIm1LjQmVc7iNNhDoJawCDbLjf4/6kD/V/HeNOO5+avcVv66NiQzkxEdQ0x+DDgzbhrSYaaw'
        b'Jug/1mawxkJzw+CMMVgvkXBYFzJiJb9aaEnS8VNiEl9NgoX5u0isvytBeosQg1nukjhcv3Oczu9igTnSa4zQmyQ6110hf0f8u0Qo4fTEMoEO0bSMOAMCQcH1ScQU1mKE'
        b'9DQjjsBS8oWsRCDhmAKuTXj3fiQH0YZ4zYcCR+z/L2EpvOazZsKAi/6O5mP3xV8BpJBuyLmgVXLz9I24nk34FzYEpVfhX9g0n45DKqRXYNf/i+jXTS0ehnFTpomKuCnV'
        b'xCdswE9H4feq8S/sOZB+ksG2J7Vb+E0t3lf7pkzThfqm7kTXZexSRlyYiOsNGQc67P/jowQNDyIOffTBDlXFDA0dZ6+HGdKO4+JpuDdO8L/5ayCUTZIJ7AREn/QEQxn3'
        b'arQsMxm27YTtwjjnrff5amG9lbhVYcMcCXOmit+kVSqJl6g9t7h/5kqHt1EZc6/n1o6gTMzUsAT2Kd1nz50z322eOxgGfRkZ6VlpmUo4DPvQwn4RiX39SHoZ0JfAPlAq'
        b'09HT1pWCQ+AgkjpqYX3IGngYHlsvwhrnFal0E6wjOqHACMlE2LRY4YixuTiznABjLYuMYYsAjuDoLDhaVeK2GOxc4sZE6LkJkaaKB08GWsBp8gb6JQCF6YwxHEGr/gUc'
        b'wOUYHCEJTNxgV6o76skcJOpFzQEnTUgmmC17YI+qTvomaIR1pEYkGReQKpdHx7hz2KeF83YHV5yp70l/iieqDL/GLhawjMlM3MZiUEXqEoNiWOEuZpi5TF76XFCpS+oC'
        b'tUicGBnvo8CIMV6NUe/41YM0H1EkGFrjjmg9Dx8mls7bMCeTbLQ17om0f/g1jjGBHbDMGLexGRwgpm5EktML3EUMM59Zzs6HjeA8jR9Tr+NOq+NfnAKrWfzeCXCKhuIZ'
        b'CwOn3BFDLcDg1c4FSLg4TxwhjEEf7OLbqjUjHJzCQ3MFvZoURBMnHfM2cNdimIVIVGxdOAmOkWGJR8QfdkTScSdprZYNY4Krs19PHBHgOVCiBwbQJw80gHYe2fAw6V4q'
        b'KLNXDQoaDWvGeBbqPaZeAmilb/aCa2j4BhD9PBmfXDRb5pJWgmpHeJUnOizSs+QYyi3g8FTaypMS0Iz5dzkzDV5bPiuHjIoNogisQPJdIeUYG/QWJgKSI5rIaytj45SI'
        b'4iuwftS0AjYakMrSbECXI2FNQTLqyilvxoTQoBcOUxpcQnRsVSKyr0QCatPKReGUeCe3z6YDiXuoFY3GsQWNNR7LyZNIdfuQMJavRFT3YZYt9oHn00grfeHReYTo5DUj'
        b'xsQD1OLBhFUwnwyKPmyH/UpE81U4XPnBVXvgIeqjkj8PiSUVpG90SPFUEi02JkOKhNlC0tygtaBWiSi/moFnYPfqvagXWPRbDyqQOolfQcNzEYOdEeXDwGlwHr98AXQS'
        b'p6U0UAJ7lYj+vsxahe+qaNLTGZPBECUGfdEbdbXcjdS6xpKy2+BGpG5gDvDDis91JEtNI3MjHS0GPXybMeNEY5KAJkrM65R9kPbUBRqwoY/xR7cv+ysSyLvBEfPGx5ey'
        b'EAO65lKaigxJZ0EbKEdVDCCqKpj1yxXrWOKlsgWcBCcdDXfiRhfBi+k8I8BmZ/pWxxQnOIAIGsDo5AYAROpMLIKbJ+vyTSVdRW+J4BlCUNiEliTiW3N5GVJbBxBNAxlQ'
        b'vDcQqVZFlBsOOcMynovwy4iJzEE3pqsjnwYT9gTAa3AA0TUI8d+kIJAPSkm1sDQvVt1RLXAat7bVnNKlaTsNGjSEqFcIBxBZgxlfcC0YtCOCkZWgFhaCVhU/sXu1rBjK'
        b'DxGgnTAhPB/uCQcQRdcw/mFrYLMOmdCbQLUHrW/51ij19AqCfWRlNAX9JjQj1Lr9a9NWk1bqWKRR7ilATNCPll88PqAe03EMXqOzssfOXIqouA5plsvWLUDsjEdmMeh2'
        b'IKNSgHkHXMZjQ6szAKOkullsvJTDIAww5BYSGEfYVQIGwQE14/ArJOMTQgkZD0bImwG50VJExlAGlsWGGueQN62z4TH1cNKZImBk6+gqh7Yq6iSFBvA0LJEiQoYxcIQN'
        b'gwVolhHz3tgOHUdwKZdsHEXpdKEDnTMI42xG82VIiki4ngGnU9Z7gW6ygjjC/kV8E+FJW1CQztMAFpmT17xEsEuKaLeBQbN0ZANoYIn7kyE4izabwxxZxAWMyQL0yrZY'
        b'uubUwBNiKaLaRtTShRt90WZKzIvXQJ+EHxMBaguew5O209k0OJfMpknrcWR2TGJsrM/fBJqWUD7oNMsAFYg6mxlYGLl5mi9lrB7E/bWgAg3/FgatLke22MJS0oKVk5Sw'
        b'DvXUhcFWcBdDfgKAC+6I3jSvHprJ111hbSR5fikYm4zdHa2YzfC8FegEFXSqVYKGfbAOmwgYm2RHUDudfD1XDIZC0ODPZMDZ7TNR64/Sbo+Foi2wDvV7NrMaXpvtn02+'
        b'3ghOIskDO3w5MUnbnQz5rd/G0CwEtdCOQYvWObsFsFKuk0ltuPAEOMPvOniU0GScHYh38m1wlE65HnAYHleLJHgHBd2eeNWH59BGSZTtQdm68bWAjDQcxRZ69JA/PEXM'
        b'AJbGsItu3TvcLFm6bchBPSXVGSQ2nFJtfui1aMYkLIQs9COgg7TT1xEWqldGWIimRcAeyjetiBnJPjgGx9AqTpoBC3RY0hVcxrZkWslF0GFB2Zx0Nho7bV8jZYSCFlIJ'
        b'muZoeNTTSGs5Y7zRn3CMAF6nS0gzOAEvwAqHSfSJFaptswAMy1najiF4wVlBEhj7giZQgCOXgwscKNik/QmRK2vSl8p1iNHFRcAtPkfE2EinyrSl1I1u2WLZlDREU+xb'
        b'5x8+k0nCkITJrGTaSQ4JepGRSaszyXM5/kbpFzjsyRzpPeS7kr5czAhNWgVod1oaGXDWWId+eXuZ3qoYAdK7Zkc6/W7tSr+sCNWSnWPNceQ5J9115nw2xBkGSX3cUobZ'
        b'FSm77hVNvzTRl/prC+wZ7Cv4iGg5/fK3OBPb57g1uCLvdF03+uVPziK7Pr72fSmp9MufwwUWrRzppMzXYQVD/KCdQifpJQs24tq9H+JMkb4Yuorc8JOK0n9gSRFOLe4h'
        b'9OndceJd2wWkrbJTm7WYTxob8L8nl5AKzuSKddbQniTtWWzPfOJO/n2/hMwHLdgUindDJhWvCN2pexfQjbQ+R+GIRjabQStgQzZaQY/zkRwJQw/DMr+J7BYLOii/FYPz'
        b'pNoV0yYZnGRJF6bNCp9GO3t4iUlWIEOGZatV7pb7fSDVoSnx+pnA+0DStIfqdIfFPPDjpigxJTYuOx27DT8o3+FCHVQO/sqMyfRGf2L3wlHHIOwATFwK58K2wIBgWP+n'
        b'AMYLsFG6zI9PI/3Mlo2xpkwki7gsd2eQC6JKUFDiFa14TtmORcGMj6tqnwwyWWty4Juez/sbz536zPCRyYafaKc9xD5imDDF59TMp1xX+h7UVdwIn/dYdJRtVJdfpmzL'
        b'8NevfyceK3Cc8VDPXWfJSMbad6792Hy3Uv5p3O1VDxdc7TRcdqTSKsiuxnbR2Sfszj4ZH/uE2WDtpsHDHh8+yZXHasddnD79Q72MWq/+ireqFn247cstr3QPzAjfO33p'
        b'ghyDRR9aTbM79K59juzxJ40X+rWCxO9kuU8OfGpz4z3vHHbSk/u3Wrt+oJNjKvjQsvfwistjna/NTXnXLuW9+V9Hmu9O0//xW0Z/yZ6dN+2XfH51rDUsMyHtydcKfrh1'
        b'YFvWvt2vLjuSNenQYs/3vOa8Z5487R3d07pxW5dY61nsbh+Zb1gp6zANn+62dknQzraztg6Hmx3kle+XXXvl1hq3yGj3px7peDFz0dnOxLqabAPjDdGnlf5GPmHrdXvC'
        b'vvJqPWB4y+5Jif5TZ3+9PKMuO/zNX6MyDiXWXp5bX++nSH/v/LUz0e7HP85Z/eK5TS/WNion7Vd8/+pnIrfQpP25IZdmvB/l5L/IYR/7zFNhvzkM2rf/qKeMtTV+ZGr5'
        b'TVnyjfnJ+4sXxb4Ov29uGfWZ82JhWtbbtTerN79QEX5Jd0lU5pbPy/ReORWwc2HBhnear9Xf2jO0J7Hlg7NSQXvvp8NF2VE9vw2+nOs22faRndvr4j7xe/PpoTbdGLtZ'
        b'mxKbso7vrC9vbrn14ewd3/l9HrDsYkHpsdrUhXauOZUHwsw+fifqdZOf9vtklp2vekpxeCxT3n89Kbz0qcx41zfClUte8Uh46ZC88+nThUdu+7/xXKXfent/Q3jq8y/2'
        b'njc56xte8POzDncP7/vWeFbrd8YzXh4U/ytXbiX6et8z683XZSUcd7F/yaXk5JMbXky5a/zxT7c3fORV2/VF4uPvtf7+26ovXR5OHR1a+8v6XwobDOubfxIkr5Bu/NFc'
        b'rksOkOc5Y+lTIIWVaBaIGNFeFrt5bKV+ST0Y0QYr/MIpJlPoy4KBeNhIb3ZudFeQ3L4KnGdDGhQKmwSc/jKarARJ4K1wYFoE2t6GkeIh0GHdwIAVH8QOXIGFjnAQSXzV'
        b'oNtfxAhj0TZkDI5Sx5kxtDe24lh0fk5+QkYKT6zK4mDT5rn0bjkYsKOOb7AhXuX55g3a6RH7KBI4+hxBswmsdkWNEmaySPuFtdQBqV4CsU590lHt3UY82xqDyG0/UAfP'
        b'8BgRESNDUmWHmEPidf5eWvFpJMwoQDXeO8kJuXAS9vYZkBMPJDko36sIBvlJfL50BhTQt/Lned+bwlDXOcErXT71f3ys9YdHkJJ/cjB8U0cZE5USkZgclRBHzoeX/sd8'
        b'H6r/wix8REnOa+kPx/2u/hFwv6l/hNyv6h8R94v6R8z9LBQLfyZ/tbif1D8S7o76R5v7Uf2jw/2g/pFyt9U/MuG/hTLqiyP5VmaoQzKLYA8bHdZaQHNw0JwdOO+HkNND'
        b'PwYktJIRR0+4DVgjFh/QmQgMWEvyLn5eRnyBOPJJh/zF3kF2JCs6viZXPwsl1uh9W1b4FerfT9x7qI+e6XM51aGn4KYgMTlB45j571BpntqPBhf4IT5N9sQb6184TWYK'
        b'plQ8wJOGCIbHQbsH2jctdFQ7J1kwzLYJJaagJEagsYPj3VtHtYNj3LIGopHlYWRcvA5/8ig4KCxi9glztTFgbAODY8WzzH7BfmGIxucHnTzivV59uKk+ebQI+mO0Kh5P'
        b'1AYunvubeNX74Gv4H3df3aIgIiDMN+SYyPV4BCKd7kzTYTKxGIJTJ2IrdsUGex79aO/rF+KLVxM/EWiazSzYI7a3g3WJHhWPCZXYV8ag59YXkb5Rz/S3x9u//1nk1of6'
        b'agoOnyp2K+lo6C/rL7I6XuAuYFIeFj8fHi3nyBpmgkrrUajA8WJvbN29Mgm0wwLiD5mIlJ4rvJ3eQnRf5tbdsEyFKHmQg5w0ZntczM4IImyROY8db/7anGfyJGupj1zu'
        b'jAicSyECBw0adzLTKFnF/2yiBvdzE/h7gZq/56NPi7F45/2X+Zsp0Ot7AIcT0ErlVNhHInP6IqWeok3ucw6Dw8sx3ikQVovRXtQGzq7HOrS5FLaAmqRM6ncMi+coJuk6'
        b'4Zx7lUJGPIXTsZERVXchuLzaEdYaBgVxDGfIMvAIpH5lbALajZhVSB2NTHrCKBxnCSc+Cdi/XxEQFIShc2GwTBLMKSFSnMg76TN1GJNdl7WQwhHwZcYMRokVWLOxJ0J0'
        b'd6UJmOpPuPUss0NCNIPKaSJGkpEnwBrH6n3pTBJGXr7hIcRJ0BlG/LjuGxtfMNvEKLEmEG1rF3InLSzz9m4BIxCxMwfqSG2TWSEjWRmLi0hKkKPaCAGudXyASPCtUMpI'
        b'124nz+3Q0mJk9ptFWM2wCYqjzxWYZH+AFoW3dukxegYlSnzOss+n9IOPOGbLZaRsm+vHkFAZFtK7IWGOTbpZurtCUbOc2SOfhijxkL79cS6xY3fYY4cRy0+N+wUf2qWS'
        b'7YhAwz+afO0l/SednvQTMS//qMVyc87PIfUG73r5JfTnVIicke/fHUq+C1CMvYQmbPi/HRiH17zIV7s3zsBmLyYsnAmfdpk0b/2roxUvMMyzdcz7TMkhS/KdfmdxxQtC'
        b'Jm0Z8wFzwPEsOfUKyzRE8hHBMLkjAookoILzh2fhhUTvR9NYZRcq9sV5Rj7rnk15ealsKOH9WLurt46ecJAv+pdsWs3C0NGVjmFvBc7cmChiH3lU6f/CcxYG+4o/XHT5'
        b'O9tRboHL63X1z/saf9F048QSr7evLnrLY1XWj1bsChAgi9h1+ZlnhQ3x3mvOab9xrP2puTcnKZ9+5dP9vwa6PP5j0FsfJkS++C/dy+//fHXJ0vXOKWNXpO/23YaObLXN'
        b'6feNn6359ZNGP+/hRZUuYdHZ0LEjfkH0adny0a9vzy8JVTw7a8uCUec755aMmd0OgT9177LIrJkSUvvYkXU1Dw2WWLn+/FT2Ww/3HxhrO574umtOg+fC51NsrLQSV4W2'
        b'rblY+LKR/4H+vM6iJ9rSdyj7En2PPL9CP7HtS/tt66c/86rcr2vkpMWRvLjNX8nalS94LjigmNuSOA+WRnxj8uxtgV7CryvvPvz+D5+9P/Rvw+H6a402ixesHnWxuFSx'
        b'cW/6rLVX+hcOvmGa+XXmz3lZsce/++Dxd+46zjJpfnXvw580Dj9y47LXY7P2esSkXXR7bfjzqy+65xaH72X173z204avXnxual/KK7ee/vLQL8sarycFuLe4bLHdvqet'
        b'+zXPyaPK1xqVut/+PqMlr9lgb5jcgIiRIjAAOhTgAiiXwypnezEjTuAcYFsuWWNnwlrYjGU6ipcFh0GDBNRwqbZaROJLySISYlWgEzkRHBS6saAb9MJjxAlnAcz3U5Al'
        b'H8mvFVoMKARHJOAUtx9cjaUuUo0RhsoMs7lZWbp6oFpfH16UpYmw4UQAWoxgEanCCgfbdeRlZ9BjQcRnOATGqJfNCDgnghWB65aAbuwVXsyuBtVJpF/aJkjz3QC7/HkR'
        b'VryOM4EFsIKUGg6GMaiZ3kGr3wgVcPujSa89YBNLou7QSq/CRm0pB+qyQAUVvFtA20KFAJbACrkzdhERR3I2sMCL+rZc9IMFjsnzNXEsvqCf1BoP+hwd/cFgrDM86Ifz'
        b'd0tBPwdbzH3om1VwDFxT4CDHeKznxEvCubip+6lbyjk4Cg8qJoE+jf1uEix34N3V4OHVsAKnAiwLDpAjEnpxJsqg/9Jc/0+cmydIzeObH9lBW//GDqq3RkjCeFIZ1Qz7'
        b'fhM/CgMWS59CIpFiGZNmt+PyZUhaFRIpVY88K2ZNcG49IuUaEAlVhp7G8ij3q0wkI9KqDmvxstiZ1qJD9uv0hWqZVHRTuCsqY/tNYWxURtRN7YS4jIiMxIwkTedvrb8y'
        b'IIJ0T1ymF/7lod7KcT2L/u5WbtH/gK2cTKN8G3gUb+Vbtmls5lqMWaDQhIOVMZyGGIelt4nBzLCFnFUHM+OIZfwfhDhQFX5vTBO0uZMz5TIvbaTmYhg6PgVF/G0EhgWw'
        b'0BkWWmcnLovS55QEZ74l+IvITyM/jwyI+nJ0V5xO/LsBWszUw4KQQA+N8Cd/FksIU2oi3zn9Db5j8mRG6d5qLhBSmnlN9ILRFNC4e0mLX96PSbv4b5CWKTD45gHExe6m'
        b'8DIYXU5HLmgCdWeugMemi0JhL/P/hcAPDFojuI/AgqDEWsf9LMmkY9k4mxIv+5uk+OhY3ygaT2jGj4L4by3/IvmU/yX59EzTF91LPs8/I5/nRPLhlwv+Afm+fAD5SGiH'
        b'ZqRAdjsGPYB+8ERWrigS7ZdH/5iAWJXFwQaRJimMF/5NEt6nQ2Ly3Z8HSYfGw2FjcxROQaAwZlyQhyN7iZgbIprBHV92R8Lsei9voZZ/HvlSMVVA2lqrGxnw2yx7etY9'
        b'xYDBmJFdT+yLyns1I51GznGCI7AyBPQwJHh9KWhiQOsSWENeuDJNC6u2G/fJI52qV65iSFNcZsCmEOc9EfCoo6+fgBFv4lhQa5i43ySEVe5G97d9+tj0Si89zk22MqH5'
        b't4PS7sHV73o+v25z+eDMpMQNiQFwxZ3JRkH+yxfkBqcud5jytpGsI3S+mWeQW7vJC4Pw8HtzvS/keZrmHISPbqx7zm7q52cVX8yMyk5uuaG7T//6qh/hSs+jMbqxU66P'
        b'vue+OOfxmXcZ3cctVuxtkUuIz3I6aEl1dLb3ABd8cdIJ0Mg5e4aTfXivlEWyUpoJLy0RSWkqOKByCr0CRhRIdj4OjjphoSkYB9GoRDJLFI+/PWoKLymcpizH531qmGvZ'
        b'DOK7uwUJaFUACzNgyBpr1CxOd2GNfZjp2dsgHJ09fqCXAsrxed4O/pgRHkaixTF4GBxy9CUnc8IFLOi1AZU0nUW5J6wCndjaNvGw8Awovm+yokn1p45kN2V4Bd4VGx+B'
        b'908yg5f/rRksMddj9TiShJZDG/xvEqEe2ejTF2vM6xJck/AeNNZ9TeXSl+B3SlRtI0UU//3ZbfTZA2Y3iTiUDy4F08XZ1w/twHRwZ4CDsAUWC5HQVgEL71tEtfm/yin3'
        b'5jwVHJEd0YrnYrkqlhweceNRiOIlsYJYYbGEz2OKc5oyOJspn8dUm1zrkGstktdUTPKaSvg8prrkWo9ca5O8pmKS11TC5zE1JNdG5FpK8pqKSV5TCZ/H1JRcm5FrXZLX'
        b'VEzymkr4PKaTyfUUcq1P8pqKSV5TfG2AM7OiXk2PtSiWkCym1olMnGERc5atZjcborv4sEwbLW8zYi3RE0axViToq81NrcCoFOxP+bPzhPChOCmnZTK9RTOO3pPskSUL'
        b'+n2rqrZq6VvJ8KGeeL9ANMR4i9RWr6/CvyoD/Vz0H9M4TmjteBrHP8oKiGcNzduIP1mS7H+kiDUrV1nGJyY9IHffBA7D6/uDzgkzcY6CIFAZSFYAnJcs2Hk9DxgDPfCg'
        b'kwvLrGaVCVoLYBGsysSgHKT/XAH50l1pIei26tlQyVInfGQBDwaSMCdonYuxlMjWGdIoPe2gwVkVpWexD7jGgq7NqDhikjgHymCTIw6GckgRyDKL1kpgA7cHHHOkNvIa'
        b'cEbq6B/oQtKBRALs6Gk8SwCbEtyJq8VOcBgtj3N89/hzDAsvYL+8Qn3qU3E6zx4tuTqgMIBluGjWDRzxIidKsWgNK4/YqKC5Y1hGmsrBBngynB7x9s0Hx8k6jDHJFQHo'
        b'PqyZqwdPCJY7wWqaRe4w7IGNCtDji1qFCwCXQIG+jWBjFkfKXzRrCn/+iO7thIUSMIz607CJ3AwEZSuQMueAbnMMuL4ZH5aAgr0G5KZR/E7YAA5MjBSVC7ppjKAhMISd'
        b'DPkYEmjpHs1jQVMSGKYBuc7Bi7E4INcoHOYjcq2AlTT41eXlsFcdc8tCBxzEWm2tGzm9mRfjuROU3Bd0q2ENOTVTLsEx79a46i+NdMqw1WeIh4gFPOIXgpO4NDJWSBMv'
        b'DSN7tjgGP5rtIl0aKfPzkTC8iL9SBkYcYVXuBnWQLHWArONy8uIpLywy9DmJmUinYLMtdLMPW7ZBHa7LyQUMsGBkGiiiLHEBXrPVjNe1MUcfh+sChbEURnrVB+1oOGKX'
        b'M2KnSBKwCw7pEMHLBfRtQa2RgwLtB0fUArW8hwdomAE7MY8QzQQRC57bqAdPCsLBdXA+8Y54JavE0YRtLry5r3bROrhUVtJ2qTawufjXWW/PXvFo2EJWy/fMKd9l78Wu'
        b'65ka0C8//p4k69nEy4ab435qYF984psnXxz7zVvPJGn2Jfn3kY6RC994PNCr49MvTz4cucV70yt2n//2cY3bq3eKraRDj+l4f5mq/4jdD967Prb891DL86aBejtMZo30'
        b'v5V45uuOrzu/7hrq/H5X6+eX2r2KPvzlSf26G3UzOqZ++rXp48/0Zx1wXv9p/95PDj9ucySV9f6uviLzy3cffkJ5OsVh+OkM/ZwP8xP0GrVv5LzQ+JQw4NZH0vVv5NxM'
        b'eLNjQVrQywEv+7/iHdh6CzzdcPXbLHnEv5ZffPnSq8u76q5mfBD+fspA7XP/j7fvgKvqPhu+gw2yZSgqbpAl4ARBcAAyVVBEUPYUGRdQZChDNiJ7yx6yZIMgSPM8bdp0'
        b'JU3aJE3TNKO7afs2TZMm6dd8z/+cC4JiYmzfN/yiV+45//ns+aJjiVFA2lvnFZW3z+kc+ejj4t/c2f2qxrFfuuhE63Sbvmr6eYfpsS+Pnzhs9Ict2/9fh6nmbxZeOv3G'
        b'eeWh1urjb691/bzn7d+ktfzrxkfvWL599MvPxEW1tUluGsbreMfqMDQELAklMtDOsviGoYCTp7borom/5Oa+y5z/XjlWhF1hUMPZaGx3mXHFAjiPggDboVUBS0SZWO4l'
        b'LSSRidlLPbpC4eGjJl3YeJRvhTUNs9eVd8VA1RM1dDkPAcxCBy+YjYiOMCeQGdyFBUbZmGx8GnnhCbKtsfcqLhD3X6JsykkibLSCSi6Zzx1HodTN60q81FsKOZjFL7Fw'
        b'+3GuExejeLTrUi62XQdbZGz24T2+BE0zdmyFEi8ronniWLNM4Vlo450fO6CP1s/6Irmzhpyt2Ik5Qig/AG3c14aYAzVLXbNYbl0765oFhUb81DOJ5zm31hLx86WHNPeL'
        b'oR0mJNy+nKGQtX+T0j7ownz2RLoYptfyD8ADHMXb27mMsUUaqHyKNo49vDwb4iW/NZB1IpLSQOXtImzDdmVeXp3z4gpAFmYmLasYMQwlnLAsCopc6vnEUSrMhUI1RXEy'
        b'axkldY2vh17uGejBGY56yCmI9BN9ucyl9TDO2nBZLJIO6MdGZnLAbjFm+8I4d0ZaUGUK89hGz0lJiDJBEE77aHAznGIljWmGRRJ96qjqUbGTPNZw3X6ENG0jr9ZxdfWg'
        b'QfsxIuOQIq+RDIPcVGdgwYHr27bIMmU3q0aKbbSgmU9MqyDwG+OviyNCEYfpvDQPiGGOSOB9Ph9y7EIMkzB5MdPPiCGEpqqYltGJWcayT7dAKT5vRshSN577TK54Zvld'
        b'yZqVhVDh3MYKnKmOKwch5goxcD8qJEgrcd+IRKp8iYj/py2vKjXEsb+Xfs//fK6uoMC9I7f8u699h32Tpi6VIR9rwCPNbzq40jTw7I5nEf/qyRWn1fDNVQuDn66S0fTE'
        b'mp+9mcnBr2pm8gmtj++uszTDUmOdLVxDG6mY+qjBy/N10ongOzbIByZFR8Z9RW+bzxYXxE+/2NuGvRWcnCJ5jg4W0pllAkOsQp467b+WpjVyig2OZI2qo5P5xuRHrI4s'
        b'ncJz9fSRZAm+4ga+XJrZgOtNIQkPi06OlzxXByHuvlng91NnEykvzrZROhvfMug/ag6iGHg5Piw6IvorrlV2ad6dXB+Z4KRkQ/6l0P9kAVGLC1hsFv7UBSgsLWDb0gL4'
        b'l55/9iWY5lL4nj638tLcuxaBK3kZahGU8QM89wXIB4aFhxDQPHUFqksr2MRhFff08ze/Wbr3RWh96sQaSxNvXgHd/2nfHcUle9JTp9Zemnr7ct2Znfyi4rxy+mWzc1zu'
        b'8bAZ4VLYjKBQkCvIFKYpZgg4c4CQMwEIrgu9l32+yhb7mLmVDfukxVzhK0J2nr/i/+fnnjALsP84CLwaFc51c0mOIuBbBoeScL5BUjLr+RIXn/ykZeEJ68LiZT3hBPhH'
        b'wW/FXCuB04k2S60Edr0mYK0EbHcbC/lqWxM4l8SLvFCtzOn5jyTe3qeUtm9ZzMpmJolnF0MEN+R2p21aZHNLW30UhhMRGZ789JL4bFY9ZRbrx2Z9ZnYuyFZZhaGn2NEY'
        b'ytgUjONSCRBrliwdJlw7mQdGKwJv3LiqIDAvp0wSajXm/d+5eJ6M86Lb/UTpt7yL57t1v2QunpiID4NawkojORfPD0lRuy/urR+Q3rIhlqhK9RpDrFx+yTiMuV/nApK0'
        b'Pe99q+756vtOWrzvDuFjYV+dwuWTb3qea1f/0SrXzrw3WLw17KnXnpSw8tZJoWC3vksZi4zijEWc3QsbbUJ5cNhnLKMmJK3nFjbysVdlOtDPv4P5hjLWQoKj4dTo2AkV'
        b'YRKrAp6xM+qDsKiEvZEuoe7B7sEx792VHfuF/mv1p+u9z2UdenFd/roXtV8/6P6CSvMfBGNyCr96IfiJiLjVo+MkBVJA4QiWSPhNbknFRFVeSZSm8cRN8cN3P343KyfV'
        b'fZ67Uf3ZKjL2kwt4OlnmvHB8awDBkhfuWYkzsYXPPZ6grEdZEGASLxwQKV5pJE4yTEqOjo01vBIcGx32NfZeoWA1JiPn6ePEmdwi/dIECttL6QnDK2+6/PZ89PEtlbJJ'
        b'gewASwL+FPTjEKMIj2CViN/TJ9P35Srdj88ZuwfZJ40alYcZa+Z95KfU5dAfo29TH6Nno9fUUOwTo6czYh4mKN5tGuT/vZNo+EL54OHvtEDzj053qb0qtqqz3iAY/btu'
        b'6Y9/YazAVwxq0rMz4ZRWGIFp3o6jClNiZ29XTjOOvA5LJmG478FcYswmPIe8jg5dsZAttbFCIQyyB5iR9VQ6Z4MwgX6ofoRSnMEYaiKx6RLU8+/nWRPmcUYMrDjC2XCZ'
        b'/RbvipL5NhrtAbxCLiMjXAdF0OrlysUVHYiyNWGFbVp8TsCgjEAuVrQFR/kaO1AHeZDjRr83lRPIGAhxeiOMwSx2SlnX1zrIFKKTArmb5TDo2DflaodkuBqL3P8irq6I'
        b'UGaF0rg4/LLuRqsv6RG3O0ePbnse1NL83lepr4srkdZu1/qaahycny6fHZGYaW+MtkiMRezEFjWOtxQWRf+35Hgp+i05Xrx9S2FR2nxLYUlYLFjcGz//f974eBk1cqCP'
        b'1UzfjxDw9TJUxAZCkf//Tk0MVRl1ZR0RZxN3hVzoWWIosqyhvMgXW+FB5PYneLmm9O+k/Mc9jXLV+tWCMNEt5nvTKtAm0eGZvYv0BvNRKoep3FTgfIvbogXhClJvngIb'
        b'OWzNLSEXAq9MI8uEqYapcSMrLn0nSxKuepgG91slbi36YZq3RGHbuXe0uLe0w9beVKTvlel7AXuiWp5+9MN0bskpailqhe3ginvISnu0rClQLVAv0CjQLNAu0I9YE6Yf'
        b'to57W4UfnX4UqhVpl+tvicN2cp5VWc7tx1oNqRaosTkL1hboFOgW6NH76mEGYRu499dI3+ferpYP28i9Lyt9U417S5feUOR8l+wNVW6Xm9kuaR+isC1hW7l9qoVpcbqU'
        b'0VuqUvSgv4IjwyXv7Xm8J6Sj4conGGOgv5O41pDLOQVzMAYnGwZLmMUmMSVa8lg7xwiS67nnw+ir0GSmCUYnr+jc+Jgf8kQycZ54iXSqpVmCk5aUKGJZcYbBhpHRV8Lj'
        b'pMPGS649Noy5ueHVYAlrBmpj86Sjk+lnj21wieMdOe7jaG54LD5uZ7JhSlI4t4MESXxYCrfczSvdvFIbXDGd3xMZGUu8m0XYSWvA0LVHyC7lYYifKQ/jprH4vfOrNu18'
        b'zM27yLwvL27puTy9SyfKlDa61uXXsKp2xu6eu7Iwc8MTnBkrLJ5WxJp8hqdGJyWz31xlJxsitf+EryJQSBckVdP5NT2hvF+NZoukbyJSaLjgsDACk6esKS6M/jcMTkiI'
        b'j46jCZebub5GmllRwmdJmlnjmWLLvgziysQs1VN1WfLZYSXecucKn552cfdM3LpYmQ0WsEAZuwOup1gwWWThusbq79NbUit/BuZfwQLFzFN4m3MxGmPlZawiGdtFRiC7'
        b'k5SxESHWn9rCFfsIYz4iljAcLZMqSFUz4oMx26EAc7zNmJcWc0m877YSiM0FaodE20gCKuB8k/H4UPyoM9hOfZYdw5zyfEew/cayULF7G+eAlcEqnDIRsVL1SUmCJGc7'
        b'TqjzOSsWyGR8IGYpNz07dwo4b735Xqx85MU8jYXuix0zcQpGPPhidqfi5TELSnGCUy02m0CLLgwmJRLG4G2WbtgCo9Gpc34ySS/R13HTn4WX2anCbpW81qrafwu6k+9+'
        b'27K8vuGAQFMcEvJSVvFPs8NfJQnQPFlRy9clrrhKUdFv6l8f9r489fu2cVvjdX84rnPnlbUmGjW/73Ib/Pjj2lGvIZ9XS4SnPMDpr4MJfr9XqFXxsSr2sivfXDdQfS1K'
        b'44qz0TaDzm0ff7Yu7Yt3owu1IheKvg0jvn/9zH7c/9ubRNahEVoN3QVNkh8f8nkIhv++/0uL/W/vf39XvFeETsXOy5KW9QlDsXeVP/lpXJ+r1+C6PHHxD3QfdNpvki01'
        b'1uLLB05jcYAb5zEjEW6YixQYwCxOTj1utnXJW+ikvcxZeNuF88TtWH/ezf2Ej+Uyd71PNDfq9li6SF6wxRq4y0VWwfwJTlbclYbTbu67rLFzuQsTpRmnChf2Poq4isM+'
        b'LujqGC5wr6Zima0bH5hhLCcwwjpFbRG0J2Ihp2MfgRqswRKSAjzxLnSxS98lR4L1hPiUw2IJ1FzoxjITCyxmYoIc3IWZ8yLT49DPx3zdgcLryxyol3CC95/m4gS34QuQ'
        b'A1MkWtNh7Y+R2SyEOwb4kPvmMtZcWtamQdlHZK3qztt3ijYfldaAZ3otljpL3MzkBLowJeNiL8+97JHJ3HbSQCk5rbU3RGtkUnknWJs7lrCiiG6s3iC/KqdYDagTw+0A'
        b'aOZWLU/3Vct8cp6BhIpSJFf1FnskYT3vqu3CwguLkROeMCTmum/YJ/DLG8xkDSakJSJtoIpbBFci8gF2cEljOElKwC0WS41lQPJ/mcsxPZb9JNARiHEBmjDnySizp/ve'
        b'VnOmMcH3G8n7IXx/UxWupjqrr64pNPiSRbyrcJHxBl8qiRSkTi9NYZruSs76mNdLdpnXi7HNrwqeE/NPrOLmOvY8moL23VU0haet9psY5GW/2jAcvmgYfmKyJdeX9RIP'
        b'fpLpLmOw/4EvTFLzVW65qMUlSrxZ2NpyfvjfsUw/EQj8f2aZjiIwuiN8bFOLp/WEmfHj2e+IOCOyOLpeakR2FwsUCn++QzjZVmEs5Hz7h/CmsxRBH8Awj6SPUNTU/mvM'
        b'yJJW1iF1x2OwkBQaG8jlZX4T+3Cs8mJw6zfAA0G2ypermApZ4rCxGk48MhVOsg/uXmZYaeJ5AnsX6RFtlUjg+CrWYr2NqnbGMP9/l+6xqqnY4N/fkeVMxVYfNS6ainlD'
        b'ce7rLBtgy0/FWBYivUsY2GO0nNhy97gHe7ir3ASdz2wslrQ/660+qxX46vNdrvrHq1yuMzssbGAdila7XQNs/srb5Sy8ekdUT+CQjbGIK1UTB9WO3K0TAeGMwjbbOYlO'
        b'EfKwjHtBN1nAWYSVsSL6Z40OMpxF+C+Hf/mnX30QFvWsFmHFXz2rRbhL+PwW4RuqykqiNL2nXd7XGobZ3JeeyzCcvQpPeuo6iKYwC9XT8YtTNUXMSMyUzSVVU8Spms8W'
        b'TtzzhHrkHE4K/iIHWq78P12xvCwJj+CVuCfiOVbR/SThySmSuCQbQ0dDGy6Y2iZIegJBhvEhMaSOfo3OtjozkfVMYaAgxDrW1UcK9mdO+pqd9XXBojORT0YfQ9YexRhs'
        b'g7oUVvk64YIeaTMxtis0PKlCI1VmTivL4y3ZzdF/OzotTGKkeeIHP/hT0IdBfwx6KSSq/vcR/eHMrH3uW+dwpHz03N2bxrJGW1985YdvfvvNF06Kuy7pX9Ibr8+O8Rur'
        b'H28o0XY7513vMLa3lGBfX3DrhxpOyXbGcpwgbQIL0LUYokibqeUk/GlSHJjEed09ZJkYrYA1e5gY7SFtvZULd7FZ2QUnFnWLR5pFCA5wNujL0BYCk1DAKyZMKVnjxovo'
        b'o55X3Nw94T7mLIq6yudFeA/qoJDrRID9UAE5y1sRKGSuCGCsSFiBuc8iqL6lzNI3pHAjWoTqb4LOhND6Klx6pipfBGHdYwi1bAJu3j5pLBZn/n0kkK5qs+4T8Y89Ekgj'
        b'RCzv5rlotfYqOXdftdqnY/4Tktmz8lXmHJpcFeeTn4zciI9YzAX43ycBjvycz0gCVndCkTRwpmarOIlhwrdCNf8UFPCtV6a2vEDIWNuev7nEsj7beoPAAmTSD3/XWMQn'
        b'SY3GH7OO5hJqlgVLrsM7MmmqNhy6rYHRdD6qHodlLVgZPRZVL6e36HxZnUM4L3Inq28MzErGcqsDhfRW+FkiRYsiYpRo+aSlzweZqr96RsiULsKYR4u35JOCr4QHBid5'
        b'Pt0eysITpSxKjrOIyn1DiyiB7Hshq1lEF6GWmYrDpOXYnwlmHZfM2uHJwSw6K5iPTrkcf4V4Hiurvjjufwvg+Xekh2XDDKecQduUWUsvpyQlM2spj4BJydFxfMwaUxBX'
        b'NXfySuOKSCNmz6bBVzO1LuEaW6sk+Cp/XLTnr0ExhlVPWkaVPFNY2e9Ie7sneawXdOxbnclCMQxy5sV9OKNk4ipy3iwQugiwJuAoV2BEGeK9z7C6JDJ66QKZBmFyxwhn'
        b'dkzcx/I+BCd9XIJMz/s4CHwkCgTsfCHqTqhOMvES4ex1gfA0i1lIjs59pVsmqZ2+DPoBnvmRpZLIUUX2ldaw18+oKyt/R/nN9FqzY684nb4c/J7SvoYXT7n8bm1E3B8H'
        b'az46USzz76QD117bmnjT7bZ7/hH86EVXT5NtaeXjjgf/lr7xJSM3x1/babfvUHzP6pfBb75TtPu36bInv3tAfu2avNsGB4tPxE0Yax/feS3kH52pf5P74Dtvhl1Ybxfw'
        b'8sXpqTPnM7pfv//T1wN/cP/ozzy/PF/w87+LG1SMX/v+t6WJnR6Q7cD4fEvaUoqkjw5HdSyNTz9i8lfpFDhT2R1ljk/vxUJXZjs0CX6Mw7viIDeuDbTEm7h6aOkRf+cs'
        b'aTCLfEEIv52JJrukTROxC9sEirYiaMUxU0478tiP95g5bZ3qkkFtyZyGTTDKLc3T8TBvRNyA9x5lbhYf4c1hjTh6ljcBBmIrZwUUmUL96dWZq7Hcs3o/35KXJnlyRPXk'
        b'N5cQDvBt/pSEBl+qi7l2GEIZ/jdfyojU/y0jStNZhdrRhCvsWJwoECP6erGBVMhHzz6SHWLpn3XPR6F1Vovbfsqa6Vw5UxpHohWXgpt597Qfc3DLxAbHRfo4hcovQ/jF'
        b'bEUO4ZnjnMtUZGmhSpzzkbk8RQVqnNtTXKAprTmmFaElpefyhYpEzxWInstz9FyBo+Hy1xW8l33mjUPvXZdZhZ47hoWxiOi48Ksrw1OYe4d3JfGer9B4iSQ8KSE+Liw6'
        b'LvIr0hSJytoEJydLbIKWVKogjlIyvhFvGBTkI0kJDwoylcZiXwmXcD5/zsf5xGDBT/VpGoYGxzH6LYlncQKLQaDJwRK6DcOQ4LhLT2ciKxxgjwlfq7q/nspavoodsYNg'
        b'/rmkhPBQboem/CmvylweReLHpVwOCZc8szNvCcz4ZTwKqb8aFR0atYLLcTuKC74cvuoK4vn45cVziIqPDSPQXsYzH4tuvhwsufSYH3rp0pIM+YQAc0MvFpF6NTqJXwEx'
        b'/qj4MEObiJS4UAIPemZR5g5adaDF1YcGx8bSHYeER8RLWfBSWjAPBCks0Jo5kYNXHWc5DD31JJcCxGwMH88WeBRBuzjv0yJppWOFWIU8OcrynIOveZ/RCZJXvL0M91kf'
        b'NLPk/p1CtIaQMCx88aoWxyLQ56Fk9cDeY+ERwSmxyUmLKLI01qo3vjPJkJd3r32dUCOFTLaVBNIl6NMziGQrZB315aRvSdYx9uREDR3Mh5wkNT8rYgXCeAFMh+tzntrj'
        b'2OajjCNQfSVRKBBioQCbSVOeMxbyqaI5JAFNmxBDHPHEMtKzoUx41MUzZS99Z5JgoXwl8RQvKRmZC6+aGWGhxa4THrxHOQHHks/yrllohXuK0EWc9laKh4CrHz6WrnwF'
        b'p+hJznh31gjLsMzUyMUDRk+zAX25txdbckLlcSVo8YSy6x7QrQT9mCc4gA9Z040h6EkxY4JUFT7AuRVeaj5/jrmofeN592PoRQVod4M2Tiorilwj0Mt4m9UGj/3hPltp'
        b'/cUBBWRtY6QuZvdTtC53RRW87WZqbOYqK7AzkcNGnHLjjIYbseqkCVbKCYQaUH5WAC10ipXc2BtpMpWED0QCwyD31y+Y8jU+DrJM4aBvsXrWKgnp+/hfejuS6KEXJc9q'
        b'+un6xQv4cvSNmKODnSKWF35WWaB8ZS9XHop74e5ORYF6wt9ZXWmVYR0DQQpTTLAMbnlw6ePeLly13RO0+lITJsQu7YSdtKmru/kJs11yLIezGUuMVRJxCotSmAAAM0LW'
        b'v36FMMwarLhgqbGrhzv0+bgseVUhG2cUoZO2O+hkrMA3sKmB4ZCzcsuSr4XQBCNYzYu5FSfS3OQTsViadw0VgXzedb4R3EyHvkep17SITdDEf1m/K3F51rVaKsu79o/h'
        b'E+aL9Q9DjuKjDGghCYfdMlyoV/RF1ru20MIcFw5JE6D59OfGTB6mq+xPLWY/K1pG6rDs52G8z/fHXZBsMeEyEx9LS4Se81z6s8DRWJlf3gxM4m2oVV9K2xfCgD7Oc6no'
        b'yXQLBY9S9hWwAboSRekwacKVvrfEmzixLP4SpvbyOfvYncQdWIC6jNsFrLZaytlXOM2n7N90MXZLiFgyeUE7DPDtIwYycGwpYf8ktnE5+/uO87EV/aHMmMhlrUKOqjRr'
        b'n0vZJ8Tu5i7wnCVdAgv4VIZG86WAT3O8x317Y7Pfo4x9BZiGCSii7YwY85nghY5wn4uhmCDQlWaDc6ngwdIE+7QQi6WcfgUoiVYSQTbMYIO09YWugrcZ9MBD7DlNgro4'
        b'XGhLRKie+9JXLtSbtLHyMyfpG+zF+3JmQmi5rswl3+fYEErtSRGykpW6azME3BsZ2wioS4jadWGVl4xApCLABezBKmMlrk8H3nFxSFKVpEANtOOoCo6qQTFOJwsFWjHi'
        b'E9gG1VyoCWu9EMkee/RIEk6kEBzMxq3DHjHewSllrpZJJLZ7J6m6Oz169GpyoqJkjaqcwEgsgzm0qyL+FibXQj6Op+BEkmNCokoi3FKTpIgFWgbi/TCGeZz1VtFBMSkx'
        b'RYkbRg0nFXGUJmWPLk4fG3j4opws9NpynapkoUOFPQ+5ULRilVrhYkdfnOQ2HIK9cHdpVFrchcv88jbCPZkdBjjMl3WYOKXLHjLHlsUjkeAELe+42CZgA7eBNVDkKR0H'
        b'Z/bRUESi5QTqciKi690EKAz3NnipKuNUMq1DRXGNRHYbzArWXBfBeACW8KUJRvRhhi705EnuPkfwriwS5amAMQWu2RDtYxbnvT2wwhtuYhbewhpvuEW3DI1CutY+mJc2'
        b'QcL+Q8snwhwRPxHMuHPE2SMOpnFENwmn1CSyAhH2CHdFbOdM62lQhQVYQiTSzcLD3esMY1F4M+C0VOM3ZfSy9IQ7FrPCjTlnFJPCoY/vpLOgqe/GSpwLba4HsLKsedDN'
        b'd++u9sGHOO5CdMPNjGitpwz2HRJoQLMYagmQajnC7aCzTrBHQIRbPSgjO07aJCJI20Tgo2fNfnnkJ6rBAr6rheCfh6UfjByMZTiCYACTUAsDjLRA1TXBtWNEaLg1FWEr'
        b'3IYB4vZnsDWNNpcl5hugdGB1Iguygnt6qYJUyHPlCUgRDLLyHezVm77RgmhbvM/3uf7tT67JJrXQx/6ylMvebvGvOai3XLAd3fDdH3dePr0/cyF16lt53l8op/365P3b'
        b'u95zPRUu33/2T25mXYqnN+vGHXwzx2Qh+7BgQTHiDdX3swb1X/5w/7jt+N/NUkJdLlaWHpdTenXSv675yFh8zZxENfTl/KJMLcVXfrVer+RSmVvZS0Xrlb7n+snJgD93'
        b'HvvTxR7nqh1vKcmVl9haXum7cODNV9LXtGmL3pS85l0WHdOcpvDXYxInsz/+RnTHzeXHeklrdHbLveSr+dNbdh9LPvtsj5ar9pCmUmv3hSM7+rq3TW2xNxu/6/UXOHrj'
        b'e7MK2p+2veGZZX009k/r3vxj0MnkGtPjf/7U9S+l0PHyJ6ejd9nJyzQtvK25+0qgw+e/OW8a5yDIt9mU+WFGucZ3vcRKdx0dzc2Hfm376St77fZcm1xv8TurcePSupK1'
        b'4XVbPnsh9XbOH8u+Zy73tuLvTlt81rfuO+Xp/mbv/VFXlPK99/9ldPGDlIsDe0Sf/CgmT7HT2Wl4/Xzwxz0/8XeK/+DVt3/m/Yp3hP7o4HjsSOxY7Gi9XkDLF37jb1km'
        b'9b/d4PJ6QvdYTdJm+W8Vxme0+Pz2/TYb/5nf/fNAqcMHb9kIyyp2wAcK9l7XbiS+/O6ZyLKGPP+Pvp2y1jox5azvAatC3+Ljvymdf/GMimXjtNVvVXx1Oh82bTBI9Hn5'
        b'w19CyjvrJd/LGDuw5fid/S/cGvTY+MWml0yuuNWn/drjEx/bnE9Ld3q3vLTj2t74Lz4/9vB3tS1/udHxu/t7hzI/2vI90doozz/emLtdED9THP9+VdCvLFR9sn5xPzc4'
        b'OrL9ow+ORnxi/uWmd/+inqD26d/effiC6cclBcX66/Q/Gf20MOettIAfdX7Scrfn2olGL6+9rWNlo7d9erWtG77vX9CQMWj3o/cTWwP/Ot4w1/fzL7wGXW78yuyd8cBD'
        b'b6RbbpwT/fV9te+eUrA7bmpsyRmPPLDjrMkK/7fvBYHmCTG0Ke3i3ENbtWDeDQaUlmQOEZTw9ReqiUf1cbZyL+5LO5hl9RfKoMGdbwHQgeVXoDfjMVlmFOuSmaSp4ebG'
        b'2vFYsF64rB4p31zxhEcib8Kyx04BzSsPI9AJI1z3203QC73SetBQxk1KotScQAMLxFCKw0q8Db8zHEalsXRwZ99yg1jEVe6Jray3sYmXKWsbS8RLnrYSqIwPRThtCU2c'
        b'Xew6lGHzUnEcGMZ+LuLufBjfgZjZu5pXhoodgk4BHyvmgw+4FI5kHCDeOWXDx7BxdjdssOWLjgwqQ46J+RGSHB8VaYWaG9zqDm+wXYphc76wwuiWxkf1YYvVGRhwjSDK'
        b'WfKoFFsgDPM2t0rM18RCVvSPDlROILNHCH0CGOeCBVW915tYwCxJXItReSJTUgD4XJV2zIY7aZcfq8LmDp3cuOsTccYNS+whd1nR2TrkJ82ALB83E5wwhnu0XjmB3DXR'
        b'NpyHXt6RWANd65YX4iXtYSMUiK7bQBtfRbdD29TLdXlpOHq3lAei4igseBSHqKhNU2aJoP3Gbr7ybOUN6KaRC2QIkuRJq+oQnrGiVxnnOolVUJKK95YSbKA1TIULxIu+'
        b'QqsxJYmWgV+xB8m8nfBAoGUhxhrsv8HNq6NPkpi756LjUwGrOd8nTqbx81ZgM7a5QY3eIxEyD2a43ex2gHvQEL1CFt+xls9GKroGA8tlcbqsdiaNS25wNxtFGJGvCvdW'
        b'iuNNMMGt6YjRWU4cV4fS5eJ4Ggxwd7CNJI6uR/J4QhCTxzvhPl9sZgF7vVYVyPVwiBPI/RT5y+qFQaxiw5zw5N26NA1mieOh6jwPfXdw0oZV+iXtZdDCi5UgvC7adYbk'
        b'HE7ea4dyMS+cCa144SwRJ9fgiNAKcoSm2CGrqG3C32yn6mW3xQugA250vSQicakdcnnXdbMICljvkY0C0lyhyOIE18d7vZMM3IGBq9yON4TBba7W4V7CDoE8trtbihSO'
        b'QBFHuKAXJ0m3YBw90IAx9FnI58zahDILodLSKXwtWNpmuUBrq5jISj708ZFBPTilzT0kgDkLcw8sJi2Dpsd6GWiGGjXurCIIhrhnvEyPEVIU0eWIBLp7ZQ7HYjnnIV+7'
        b'Z89qpTdTsWc7tsoG0RnO8mdRm+HAtecq5u9E84oy3BJh+wbe/A8N52jwElO4t92TnqIT9xQZYPZuHqZ63GCcD8UNTVgeiKsRxl/oQ6+DOK52RUoI4T7UKGKfiFCqki/t'
        b'CKNb6dxLLMyMjRjgRJKgPSMiSXoWx4zV//OUpccs4Vr/7RG/IpQgOCxsRSiB6jP3TVmKfr3IqjiLuKIxfP8UHVbv+Ut1sRxX/3mxKrSKcCNX6VmB/jf4TFNBRaQg5F0M'
        b'rMiMJtc1m4+R5T6J5JaXihHK/FNGmeXQLfv5p9yHCpuUuJFZZxQdztCvwNWRluGcFay7idwnciqsf7c6F6Gryq1MU6wq5PuisFI367jSNKpc3K4qvaHK/XCdvr9UEq/i'
        b'1F12ZLyrQ5H3Vyw5ECSXmQ9jyXUgiVvp/vjPc9yM5fnJHo3OTcvNeHJpAZz/hK1w7Pn8J7tnnsHDvewwjMVvKSw6lR8lCobKCB79Jyd43GHCXCK800RR6jQRcm4T5jQR'
        b'cdli4mUOE5lCuVxBpmyaInN3+woyZDknicx1We9ln6UpQSxQ9wkb5pkEacjwSn8J5zkIllq+lzzjT/dCLD6xMjcoWWrEXzaEqdSWHxoct6qBN4T5agy5tkXMGPt0z8zz'
        b'OC2YG2jVWXctLm+XIZf/w9mXF9fBewv4JTHXDy09jrfQr+4wMDwaHxZufdAwJFjCWbj5DUvCEyThSeHc2N/M488doNS/83ixodUcMzT86kUxpGb/RacH8zN8nV38m1rB'
        b'V+/4s8kz5SAnJuA01Lo96op+asntv9LnDzVwk/n9y4wVcRi7bVJYCIwB1u1cbh12YaZSLPTyNsIyVeCsfbydOA17FeGWEs5yyvsGLLcwYaY8F9Y3sRJrrLbx2r+qskBb'
        b'cGC3inqQ+6/8YvjmLFGxJd4aWVx7FtacxeEnKSzV+YjNZhO4y7zZhXjbm9l1Pdw5vuzLRG7sFrjvcjWFfp/VjBjiM2uwB8vkubUIsS2SNRKGcRgWeAg8dkATn/HeHv+5'
        b'wajIUEawOyj8TfUfp/IWiDcbHHy4r2U3+R/SEtwXCoKyYlK3S5L5r506HLhvf651SfhTUZa7rGGQrZnPXt6MLfTEKmsZduT9AiuBlS90cluBTiw1X26px0IzVw+sYhZq'
        b'C5gwxVsnpD4Fru+R2ykXV1NXXm7Eaby9xhXbkzn/A0xgz+lV4jfMoAI6Vw3gOAr9xnyjKhw4CzdXFtaH9jC+tr6rN2dHNNuJoytMuKIDeC9dx4QzIvliU8gTU5cau7Ja'
        b'0Zy13GjpTciGh4qZ57GMO6kP17Banr/3UBAEqXx6fo/U4uMQw5/jO9vOOm0UR9G1Z6Wd2xxxSrKbMQ1m/DeW5c70sC0OMDMQSe2VgmuCawHnuF9vgzLeCgQTVwUkNOpq'
        b'c5l2/grQaSIviD4hSBWkrocG7llXvJXBDEAyWC+IFkSfw1rOxLvhLLZiCczIMeEZS0gB2yeEYZhy58+rDceAVftkNn2PFTZenORdRUZBzJCP3fLL9AecuRQ9fbxcNolF'
        b'jQ/9/cd2p2zjfuGgfufnF66f7bKvDrMt/mWP6tu9P5YNkBEGqGo6iALKRW//cF9w8anN2+QTRgclxc0v1P2Po5Wb9YtZ3/pwbjr+V4dcJwsK35f78I+dm/9s3v7dTUYe'
        b'0xpafxb0/vYFN+Nbg+mvveNi5nG7N6L53J2M8h2z33717987fP+Tzl0Np8J3lFX/45J+1uaILtH6v568slu4IMh+7Y9mcPSa8i9/53zM5R9nDr8Yp/7hX8oO/qZT9cUt'
        b'11TyPUz7Uv/8yb/fkVlvULM51O1ioL3rC2URscPBA+lGv83tdk10nnz/8NrpPZH736uN+c22Q5de7h/a//NM6xOBGZ9uS3rd7i8/eqmg+e+fnNBfa/ZOhunOdzb98ure'
        b'zz8efd10Luz98NGCd24eefGmn93VGzVvFLZq/nimrfj1yE7/6heSTjRtmHj5+z9/mNh4YJPh5tY9VZ8cP5u42XNSJcd05t0xrzsL4uyNIqsXt1/oWrfHd1bFumX0F0e+'
        b'v9Un4Cc/e+H/vfj6qw+SQwYKd7Sbvj38Zlf694ejnP/68rXPlUeDD7/75tBvbkyfOvyGbVvTBvcqszrvqxWfZKT8euFLsdF4TYrlLmMdXktsU7EywaFLyxXbHFzgpe4h'
        b'nMeJ5ZqtCB5AFrQf3ceXyOy21FrMCCQa2rXMjJGB9/h8wjmchTJWJ4IVidBN5MpEuGZyPRKTr/m6qcY/0nwDSBdnWpGlJT402ZX8yCZxFVt4BfEW3jwhjeUlffOJaqSk'
        b'TDfwynqvlymWpGcs61Jpi628SagRqgm4pX0qsUfEWlWyRpUww3eq3GiMCybQCwXLe1GejeB0IG8sxtlHXW9Yx5vZKKjChw68DlRPKmuHCa2I25TiBpFwA5T7S1vXzEG2'
        b'wMTMyMVMRNpZPl8U39eSUyQNLzH1aLm2L4AiLV7Z74BiXkdqw1xPTi8vMYS77tJgarV94gB7B14dnD0WyWlyeNuDiCgxDCvsNpETrIcm0kdNPLhVxOtgBXuVtepzJ6Ig'
        b'ZyCS8YRWPvevGbpgfoXWKVh7jNc5W5T5G69JuMQ/wKubm20fKZz3vflHKvdBr1TjNIP7vstUThiK4e9x0kfNxAvvrt7xgXTOu3ThnBGqzPLYMq1PJLSAMeiE/P+wa8//'
        b'oX6nsjxQg1Pw7jEe8I0UPMENlUAVTp3iW0ryjX1YpVADUvb46qFKYiWhjEiBa+QjI1z8W0bImlRK3xXxjSd5lU9d+olvSimjJvd31cXP9KcON5cm9yfpHOsfT/dYtide'
        b'A5Pj1Z6kJVWIaR7LVK7/vo4us2yyk0szcioXa0Zoq7JYN+YbqVykdA2vonR91QEsxs35s+UEiFZRuJiQygmorgIuBJ5VWeBr6os4pUvM1K4IlSUVS+aZVCwWY+y4Wozx'
        b'oor1qLD+UsgwF2n8Xw6M599ZrDnDv7dKMUlzw6N8uBG3lKeEUXFx9EwPo0dPeHsd2Lfbkuk9l4OTWbBMUrIkOi7yqUvgi908Ch16vJQf//1zJeoo8CHEyCom3+JEwUyt'
        b'x+TQVWVQm+NOfJH8LKiDO3yNpStQ+qjG0h0dTh67ksLlthCprPJbdLuL0k9jE+9MLsN7eP9RGX7j5T79uozoT98ulU3KogdvZWSaFW/WhN3ax67eePWIY/a33j/lIjP9'
        b'rpKGu+yWk3WNL5pOu8S51ve9lfn3lua0NVvHfvRKxLHgI7/54p+jDv/YGWZe7XU58vs5HoW/y/r2u39J3RD2t37Pd1N7MqdSf3K29rO9fokpl29mFf2t5/AXL5o+DPnH'
        b'hQ8uxFis9//0W//zL6HVn7au+eMbxrIc97UnkXjRUC6PbVwqUKc/X6E5OxoKWZgwqw+1lA9UIsqEMZzj2JyRAGeXZIqeiGUihdEGjlcq4AJUP8Ystdx2cbyyE/p5Hg4t'
        b'3qyzKmdun6PT7xCeUYOFFZk+/xELWUbhVVM4fFtB4z2fg8YTlXfjjXF82+BFOq/ANWxL2/AYCVo56woqvJIcLaPC36zMNZFY7n3/lXSWI7FpzHesIm3m+01JrCB7y8Iq'
        b'RPard8iKuqZFJzDjzP9K9i6rD9r3ZHyvJDQq+oq01o+0Ju2K6kKrUNGjvN0j9hpnKIm+nBAbzkw94WGbn0pxpRt7vNIN/fpZ2pkIVqVZMp4prB9vEs7iXd6xtUx1fTzI'
        b'axAHQ3QVorHYMHpHcLAM11DMMmkjSzA/9603X5goHy3svWks+z3N0KiI2BDT4LiIqJBf//DNswJB3s/l71XIGMtw7qydMKm/WOcj5zynTOyy4D0yk/Zwmwhgyq5lukQ7'
        b'NtjzMmOHA2ZJsf4yNC73h+JQSjJbzTmcvI7jAduf7o2VumKx7sLXtlBTD+bvdRG4kkSL0PMcWBujQpC8VFZzyS772AwrSqqnr8TLlanDj57gUC2TPn3/+VFNvXUVVHum'
        b'xUo+Y+uR9fT0cfKUlAo4Ke6ri9M9qpnRxf5gmQ9chheXRMBZwjnZjKMe3L74Q1n3vy2OfxN6Lgmij/sXDfasaJ2SsqZQtOmJYnNqCiJtoYKaqlBJSUeosE6O+SvojI2+'
        b'FNzQVDAXasYZChU2aQu5oCF4YHpmKa99s+9SZrtIYLRT9oqPYcrfWPmiRkVDuAOVdvHYtFsd8nEaH6zdvw+yQnFYzgYLoQIqFUi7u4M5m9ZAOeZBGwxC1bFj0KEMlVAs'
        b'XI8PYRofroEGG5yAMhgLhkns81nD8mFzcdjuEDyEERd46ExP3cbiazANfTBongGd7nDvUAbp+r3yOAL99DO7F7qhE3siE622Y4MlZmF7HLTgTezDMWzKsIMS6CEdfFTX'
        b'OfGQlw6UbMWso5kx1qSgz8N09CHMv+S8blPwOicbN1k/q3RzL+j0MzAjRXnyEMxgL4xDeRz0YwUNM+UCUwcv78LbVoFYugZ7wnBEiyShNqjEDvp5gLVBR7HxpHUM3ArF'
        b'ITlogSnMj4dRUmOJxw/ByNXL2AUPM+FBJG2gzgcq9LHjkj/WQtf+tXjPBR7shlLafgWUaRyDYW/I3elGa5jCxgMwnIkDp6BBiD3QiDlYTUpsI96OgrvYCB1XN4qVoRom'
        b'sNXKFDtxKuqA0iGchIJQA8hyvgw3w2jYOg+YMw51it/khGXR+BCbXLHGTw+GUh3xPkk0d3DETg7qTxmfoa2XQA3kKe3wwXE9bCetvgamPaAAms/RedRAnSlOH7DfbrdN'
        b'WwvHztIvmtN3+ptgA/ara2EBlsOkTxL9tkJVaQtzk9PhjcIwLWdEgHXW4bbYEABNVjCnia2qIR5QFplsj1mnsW4jlATuYxLTfQMtuB8LC+shP5K5z1lR3XpLA+wI23L2'
        b'vJ0FVhEo3IeepGCCulps9FHRD0iLs03HCYMLG6DREzr0/XGYzqcO7yrQZiYIpBqRqHapAhQcx9nddJO1MHCQdjlI65uG3HN0A7fNDhNEFKfCmO56LKbzeYBtqtfFOIdF'
        b'ztsc9VJus6jnOZKqJ+DOaUcSc5t2q7CypmszHOiCe49D1kZoxnozlT3IjFKj0CI+Dj2hwVuNoTxKBkoMb1hA94GUtCg1kv2KoAPv0smWJgT5wvzac9DoAI0wCl2QG4zN'
        b'u7DOZAcJ0bMwLYYRRaxej1PBsgl4BybO+F2FmzB3GJsyvWNhAJvoMOaNWBNBbMShODdbGqbFAJow++Q5Gr/yHNTth3ooCCH8yxYd9MBKGDGjZ8bwLvRn+mdqqZ+7EbLH'
        b'ORKbNa7t0cAhLlS9jUBwHnL2Em4VOW9y33ZtB4HbbWjAQUuC9AECz/tYGIyVsTBH+zqOD6BIHrvtsTIdWlPcHKNxaCcWGJGOsZCx3/wG5F9U9Ib7ehtZhTTs1TggE48L'
        b'QTgmwvJUneDjeBPGlaD0ugvUY7aBM5T5QRbmhalBK9z18j5jFaq5Qx/7HJ2VtDXNd8uutz5DeHTHHQu96YrrsV+PVZGFrGDs2Ud3+YAE9TwxVnpCBY4aYrMnFp/DfhiX'
        b'0SDwK9aFDtoGo015gVbsdEm8H4SJq6n6cGsjzTdEUHU3lQCiIE1DgRBinEUEzWRYaUMVneFNup8Rol2TCpGqrtiqD/ew7fxZHCC8y8PpTRdg3sONdZhS3AaVSUQVeiD/'
        b'YDiOX8aiczBvvo5ZrwO8YHo9Ad0A3joNlW6uGgFXcZLm62FGJH/IJhRaoG1lW+GA1k7vbWu9IJsOfNIPu2Pp6O56wZgx3peF+pBt0O6FD1NeI5jcibnWBJF2cJtBJK16'
        b'xgQmUg5ic4AMjdqGN+OCoS1RmfCybu9JU+hRD3KzJc2wzx5KcYqOaw7r1hMgPYRi2tsYDJ+AfH+WyLAF513s7e2w3hU6w9SVMI+AtptAahpuboVGwysExXUie5i7Jthn'
        b'fgKrLiWb0L2NQw/JacUwS9hTSWjXFOJ/IY7oR4cpNsXQeT8QECQVE6j2QyfUYnXAcSKNCya6vskXLkKbBy2yC8txwojQo+LwFqtULNVWhJnlAEsoUntSn9YxeRVzzRRv'
        b'wEQcRzKrVa9BA9HKHkf3fWmbQ2HEMz1DR3zRGUp0ITuCNrZAA/QQbcrdZ0/gWy9/GW5BbyBUraE77jNcA1UHsMEF2pLpkWxkO2nFFuJLvZClJsJcO6Ii3WvlYfoAzurt'
        b'IGgYg1krfKh9FTvj1l6TiYolva2GUDYfq9XooLpoez04B+Mn6To7NLDYb0MUAVsujjpAFx35XMBO4k73/FINCHjbL9theRDxsDpj6LtK+FBqTlfR4WhFZK6IwJJ4Z8Ce'
        b'S3uxwigG72YeUU2jBeZCFoFyB4xbGhqFBcM4UZxpFW2sIgE6VwULnaDFyodAAtqv0QKK8LYRTLKQfLidhh3y67fRIT/ALic/C3iIzUpOu2jD+UQj24hxNx2DcefI03SR'
        b'45CT5EfX2UAssRUepGHJFai/IB+OtXYRzuYcU7/tlkzsJj+FSEI5PVN7yFn3HNZB0yUoFl3Rg2YCbzpBAm9oOR9Dq1zAVvH2eFcnLIpbgxXhvvIbLuLQOqhjkGVB6Nzh'
        b'pAEzGhxc47wnTUCkNo6TMOZw2ASnhMc3BkGbPDacVhLyCTllhDP1UJ4MYwIit9vWYpYlnW+9QTrek4dZ6Ap3NoLGozCgRdygUZ8l86his/xlgxiCmUY1wsV6K2N8eMbc'
        b'BZpOpWO1AZS6btxPjGBaiY7mIZbIn4S+IIYqwcKEACYL3YnDYXxwwZeoBSO+g0QGSASJ3wdNWg4mpzVx2A8qgo5BznGYVcc25xv+dC5t+9O1oNTb3Q/6tuPEjQ1Hg4hs'
        b'9NN1DFymQxmAJv9rQqx1soYZn93pqkcxG5qg3j6U+HIO3XGHngYddj52iWFBAyvP6KqvI8ZXrA3lF9yDfQhv561P2cQSBledgypzyHXXttDGu7Ew6ECYVxgD1Tsw56gQ'
        b's2RPwmzYEahxioZxe094AIXrLh05ePT49XXYQMBPZLGbZiwQXCYG0IGjctBGWFCkQ9gyRod1G5utYB5K9QlJm7fDg0ycSrQnoK0nVleGtYcSscORCEpW2KlUyHeOJwRo'
        b'y4TazLUEVpNh17AvUg/riQa2E5UotsVbvhr7kOC9HLucSTYiiO423E9ruEOfOh32pzqrE1s8tg7GvQkMp2Hi2h5C+XnsP4qldHB5xPBa929kMpkESiMMdzJQxArtwxwp'
        b'6KBlZkFLNNSGaKRd8cBmmmWC0KoOKqNpNX0kEuSKoCyFjr5UP52218TaMxLTTDoH7SzNoEvPa4038YneGB1sD8eaE3TDPfggAO4E0RLv2cM9VpbwINxEhuXzWHuGhii4'
        b'GHWFcSDMvqyP4wlEXcYwb5vTeSUcWW/pdGoDlG5MKWdw3UO7JbimLSzJECZ4X3gZy0iGsDtgAtO7YeSK8s6D8hKSYeudzmLlEdoKtDnSFc/TzOMSOqQpRoHObYF8a8y1'
        b'DIY7NHUxjCSk26lsdIN5HA7BVnrmHhGPuhubIMvkLN33fZkDRAZrYWbXvsM4cIFEtBqcCSfxsoy5mYg9TyIRtdwbZlitSVBbeOQCtLli7WkH4qvl4Q7QcGYXCRxd8MCG'
        b'ZisjcaQN5tQIt+9Auzr2uUCZZSpWqnpsirxMlC5bnvCjJV0pEEa22xxz17Nbs86BQGwQalTNNsjQqd1R0jyIE5t2KIidMGczHWTWdgL8bo31xODLaNShAMy9ANWOQJTJ'
        b'ntggEScSEHA2EJuxxTaRCFYN9BIr6WL5bXRPwpNmZ6Fkexyx6SYY9MLc89gRYAPF7qYedHC5UHQ0Zr2X8ykmwhRfuA49IcaYEwpZWumGWEfMqsIfpyQEO7WncCAIC812'
        b'Q52IAK3VHQscCbwWiKoPRV4graScKHeRvh4d8kQQVtliAbTGH6DDv2sF+fYENV1YYemnHbHvoFcIdAXh/fgAIstttmpK2633a+tbGxNNn1DBIq1jnjuJFS5sh+YzNGrl'
        b'GgKth5eh+PRZwpHZAGjbAT3aYTgaRxM20TbvXCRM6PYPX0vkpxKGzGFYmQ6zGOsioWgTjF1IuKh7GPpj6aEhaIggAtEgjqFVZXkTwE9Yw207mN9JzHYGb97QxoeCWNa5'
        b'tdYFs1PeIqDUJQZQwoAyO46DyXmCyVQcCMe71xRI6MnVSqcDzN6xgSTcCYPdmlilTmKk7+k0Fyi/sWl7egrkB+udDFQ5Tey7k/1A7l5keSEdxKiy7ZjQlKG+BgZT6WJn'
        b'sfXsYWVilVOwoBaE3dgQQ6y2VxazUrDGJxzm0+Poq6aQCyTK3ONEByDR4QHMRxPwj4foYZ5kE3YbEVR0EOoM+MRhRYYhEYdmJupG0QIKL9pc1lOmNyqIcNTSaZR4+JGY'
        b'15/pnekblbpFxRNJWu3E7i1EuXsD7FNV6XBLgGFuOdyPS7DXhCm1ZMKSbAmJE+XnPK0Vt+FIiCfmQK03PTIFN+Wxf004Fp4yYc7dHChIgEY10lNuQksqjgUSoI5YqJiw'
        b'iIuGaHWnmGv2pDl1bCAUHSZaU7LeSIbOsmY3yZrlutpQHWe46Tjh6uAGnHEmsnWLlJMJuo3ZOJZDgJWJ27FnK2m3/XgzExqNzIj63ZenyXKxx9o53Dp1c0AEYXk24UJu'
        b'CqFBoxJUWmLZJWtsct9OmDCupZEUwtr0YP957L/Aks82EwA27yd5ZdoaCvB+Qhx0JpNSU0iqsu5ubZZke5hI/LjtVlp2eRRzEsvL4t0zxCoLCU6r7C/h5Bl9zJOBahwO'
        b'p3nvEKw1CrZetUs4n6Rzku53dMsuQpY7UBGWDM32qVC8FYtkA7AkBhoO0bNjMEHyZh0WnSUeUUJSSbO2uyq0uu644UXwOYj30vxiSUqs87Y/vp8pZgMHodtRsisApgmk'
        b'bnvAaHq0dgQRoAY1Au8JM+w8leGMVU67CCIm6Pju6W7BbAv3mDNEoUqwwliOiy25KgPDbidkL50RCC0EWCzBaS7r6IAP1rLMKfWNAqENk0276AtmmvTdJnAzEcGd/QKh'
        b'g4BEjDqo5dOaunEqws1MjkT4KoHwMH1lcZ5L6zpM1IpZ8YUW2CYQugoIZ4cOcF1dbB3pc4mpkGTtKq4sCzEYnExxFrNgnaFzdFBVeIsQo9FBhc59+LrSJn9FqLU9rRas'
        b'RXypwpzAoYNOqoZJ6zvw5gknD8iPsdcxJlIzjd36acSc2qHlhLqjP9HvcmgOwdskrxAGY+s+ZnMh1bsi1TzlKPSzTOvGTOgOD8YCZZq1BdolwYQ6VbBgD1m+p7DGk+6T'
        b'niGEzDvOgiSgl4V9F5zRJCmuyYKu7Y7V+W0EfdkbSB8Y3eVHY98WeNG8eeFEVoeJCVfRfZOSE50B+ebEYCt8oHwHqQpjBBXnSYap2EFkbggqD5KmlJcc6AEP3ejOuohV'
        b'lBBwjRmQ1pRLmlnhQeMMKLAmAW6WKMUIcYQ2GNlM8vBdaDgQfuCKGG/Lh6thvcsl6NuH9yUmm3DmIg6cP7EW+uQzUsI9JIFERSugi/UKrod6A33MpsMdIIKUTRSyJ+A8'
        b'jVVKZ1rrpx1DiDtDSyjfS1vtsVun5KuCLaFBnOrVKMZcK9JjsuhUhpBo6YIVlIpxxG+XlxXmnSPC1m6LIzsIeXqtTbg0lj4otyWJ6DbtJ0uimyJDzKk8ifbQBfPH/Emg'
        b'rILiXdAij4PRWO4CNYex7QypVKWku8zLr8WSoM2hxkfX46AC1ARBjYSQZd5YNQX7QiUS7KGfysw1tNyifWfPEQQOETmusMaxo84ZGhFhMGm0BqZUsdWFkCtnPw5ZnCD8'
        b'7oN8ZMadIjXS3ycgex00BxItgNrDLuc9/SW+53VJJCokXj6jewCrJRbWRCzGroiJRnTDoJkOLKRE4cB+0gbKd2lhoy4j5cTxCnbfIEyd3EvyYhEzRxl7RhBHhWkLaEom'
        b'gCqAaX8oiGOVrKH/GOHwkNsNGAokja+FrnTI1YazwMyJic+0+keSNtUNt/frrr9uQpLnhCdTJLAiAh5gx276YwHnDXWgNjzJNFmPRK4Be7x/cQ1mr8E5IbRcvOG/7VhK'
        b'D7EwGShWftwyQ3T0nr2hg9oVHNSRW3cV28MIN7JDiDKPnvTHYldtHUfSWxagTkInma+sLXs+0P00UYFy63UENbUwrI89lnpumw/BeDqpAwXn9LzMQh3liandP3WWM9GM'
        b'eW2iSRqhah+dx5wSrX8sjshSB/GU+SicSoEpYxiGkkMmhBU92BxH/7h9ZQ80ElMj+l7OoLQTRnfBvd3xJOu3qOM9GxwL86djzvc4q8ukTSRa3e0rJJFvjtA624CwZ9SZ'
        b'KEiLjAH2mhD1HcdOrbNwdwuR1jJocpC4k5zdEknSZ64Do7CjkJ0ZSwL+egcSFjr11Zhtyx170zSPKkH/5QtEM0t5K0BSKMF/+aXtrCg2AU77daIDMwZMViUlF3o9Lgpi'
        b'sOBILBGd5otHIok5jGNzOK2wMpk4cS69QVI53gkNg+HYk/txQlcdHm49T6BQr43djubsUHZhn244zkQT1DA5v590hzkJzl+UPaSODestsdIrgYhaqRZ2aJIGVpVO1DgL'
        b'FhJJ3Jk4DH0aXkaHrbcR/23DGj8FbHeOp3NvMtqZstE4Wueks6YGtmndSLFZA/lHRJ4E8f0EfkXQc53IQHvKWRco8SeSl2MC97XDCSnnCCumMn0vE7uMgzIxjtK/B0nO'
        b'mwm+QuS22S7jHHb7mRFNasQBY3hw5CIMbdp+gkhCFbtjuoSHRNUaiDQMadA25nHh+kl3GrRrL1ReXuvsRXPPrqfzeHAU7jsSDS4IlN1yONneOOV1ZjwnzXUB7nhjyZJu'
        b'60uT34K6PZuYeut3WlkIk5pY6AnDcmYw5C+nA31I9G9iLwHB8MGzOA/F5tEHCUIrOINJ/xYzImHMQtegYQp5RNEIRPNhhHQDfHjVy8yYbmsA5+wdoc8AGtQM1tHZl8JE'
        b'GKFq5+FDAujTJ6LSvx0aDmLWZiJ0YzB4DlvPQJOV30ZNojoFJ6A5zI8YwvBZJqN0YLufZKesOOoQ1lpgdyoWmcPYVh/MjdsNXTFHiCl00ZZ7SXBtdiJ6AzPuWGzqR2yj'
        b'aRdh802zzb5R2L1/7XkJPvQkaKslxpG3R1sBWmPimEuMiEQHjnjKExIsJHiR3l5BAFMKXWm0bWJV67DHAmpSiJnUecYQOJHmUme6Jg7ylAxtcOhgNNa76lyGOehLwaaD'
        b'MOsoIebdR+rryNmNsOAjOIA31yjggphWme+xFmZkmWmk8yD0ROq4QO3x9esOktZVTFvCIVsi4nMEE8OEBNMECPOJpH0OatGxN4SEMsSJiDIimnpLFOAYmagCk/7YE+Pl'
        b'GR1xkSTVMVVaQiMx3AElHHODklCoO2uiC6Ri5OCtGJVgHPSB21oOQRfSscXVY4MlVuzG0Q1RAVhmLWKSK1GhPNKiW3HOPTWDdl8Sok6Mqx0fbpTZDrVapzE/9JzzxSMe'
        b'ToTgpXZYk3QgDGe2EEW6R5daQqqhXCDRhkFlPwOOxDCiXU0HWR+6B0ZxcosxIW49dl4jfCuDESPSf0o05Ik39iecW0uTloTh/MlEuptbSKJBuSJMadqaE01ruaZ1Q20n'
        b'IVcDUZuHplgYCC37LxNOTmNpylGSaHShQ34FZJNuOyUW6eJdrHBQk0CXtlzMTqK5d2gzo0QRay2Frj4nmPYUivdDcXwN4dUk7b3d1FYVyw3Ob5AhEG8k1l1KIvxgGp12'
        b'zR4fxTNwbx82niPobiTCPavMFHIYMDhDx01aNZTpYJ63E5N8tGiwocBN0G2FQ8d3IYkyrqysWskWaDXfROhZcwia1tLRNCURy+kNh9FzBgTljaLTe9ZDp/5ByAqBIguS'
        b'fu2IGG46Y7yeyERlFOYqwmi45AZxrVyY8NtHPGU8nBHxEvnkk9bQp7Kfjvg2NugF0iHNaGJH5Fq8p2CU5ngoUZckShh2z2AZ+sT2urBBH6eSXbFPk4Sc28RBH0QRL0hT'
        b'OiqhO2yhQSq3HEiGLlsZSxw6vA3u2ithczIOqkdc0IMeDfVEqFqLpW6RNFA2VJvKW3nQfZKMQcdyX8bQI8Fh/+kYvLeFKEMfoVBz0BZccCLSVQd3TjjaCQgvigkpSQAn'
        b'wlUJU8oRWLCXWDNBaMlRGFmnKGQldgIDiOh105Xcp1HzNNb6Ege/BZ0KcDMK8g9inxlR/8LrV6DyQAAyE3mHAMYv2q4ngjIL+dE7Cc169aCdtYJvIIwYIZW6OUhRf6+f'
        b'Kj7QhTqfA24JzsRB78JdHJKhl3Jg3FD7IGkdndDjCP2yBoRLzbCwfa0+ybK3dmF5Bpazwym6CmPihB229NuKQ9Cx0xdniE9irca2Q9uw5QDUh58jyCnEWgnxpflUfxze'
        b'c+gM5MYmE2WsNhfsg57gVO2QEDr32Ch8ALdCYCSRpOcKkt1u0XmN2hBhzdt2kLTCGSyQ2LhF2BEZKMTidDM63jEVIcFevwqTiukqG8KSUjPhvhf9sxMa3UlBb4XhBBe8'
        b'58txxQl8cMjfHuqMiGOS9utshxOuJLsNK4dZkhBX70e4sSAfQpJa1hYC9J4UIeFRZjothvAom8CZIdI8PjAhQlxP0Dl1ECf0SMw9h1VK0UdhYBs2HbWACjFxt7Y17Ak7'
        b'9WhSGOfSI11cSBTIdT1z0BDz0+JJtJ7HXke6/zFoVcS5ffKxxHQGhNjujbPbMyGLVL+aHU5qyt5YG8Z51oaYjf9GOlTDLLNndcLMaZYxHs76lTFdDLuhx0UHG66d3nne'
        b'gjZXg/2HMPsGKV6TBsQZCwOg9QzJWpNmclHxVnow4qJEeD9ID96yonPNjyUcmFfDtguQR9LACDGWMkssXy9Pe+xWNMN7GVEk/eWHpMJNO2LJZdAmxjE9RWw6q+ekR+Ay'
        b'aCSrvgHvHz4D5aoOCkQzZyHLALOcSZoZYERtL94TEP+uwdu7VcNPQp6/m9GB5BglnFf3TdtJFJ5kcvvLJ+F2AlZZeZNazaTQ8YNRGQQgRTthRMPGjdC4XRdmlWDq3LXY'
        b'XXh3OxGuaWyCvIs4m6qE+ce9CTXySCe5S2SngvSVzXTedRvxjoqSOEIXS87HRF8ItMZGN1XhcR16bwgq5KBSQ5dQrgqmY1ROmFjg1EZm+yTOnQVz62Caue56DTaQzlca'
        b'ctiOZPeWPaweDNzbYBYHFe5bCS3KSO1JSoGGPXQN+Sdw8pAySe8PSDBoPp6mix0q12VpB5VO0KilmEE4V0n/qoAFk7iga9CymTTKXM0DXjCpB83q++1UrmKOK+YZBMpj'
        b'rw9URkELDBAclZ32Y/ZS7E1h9i66+gdEfUeISeRilzkWXg/cTFyaRKCz9OwdT9pMji9OpZmTXAbdhC9VxKgLlf1CUs4TRrYCYyYkjnbto70tZEL1RqwMJ6F7MpEAZuiq'
        b'HsHVQCYW3GAVVpRJ9Mg5B3XOJ1N+JWIVYoj5L6GBA7NL3fYlHkwkLOaw4Wm1bVhOKOC7LZ2+btaPDFXUwy79A9vochfwXiQMyrsE0RxTJCF1i/bh1HpYwN79Mcq0oTxs'
        b'Swbm/80+fwgqZaBWj2j53FVscIMOMevIB7PhxGzuXifSeJuwqZquokJpI3a6EikdoJMvxcoMEuIeHNLGon3wwAw7tuGsjgeWxDI31wlmqwo7SceTt4MQuUhFBvvD1xHs'
        b'T1wzJESfsfSKJ4jr0rKi5VXu1sHarZuMsWnHcZIYCD+OEjjMa0fhpAo22m7G7jWkNeYFQO5RnHGAAcVUljxA4k8NkedOAWnIs3Jwx8AF6pRJQejerQbtjpbQYE3CQp6e'
        b'z1q8u3WPnBwWnjqKRcqYc/QkacQPzEnCKjiIo2oJOGmh4mYFHdZY5WjjQOcyDo0yhPldRO/z04IM1Vly1wwRgxnINiRgHxKSXHbjiiXBW9VpyFPmwGImkAj4wqUdRBKa'
        b'sSCeDq6HkYLJ3SR7VEVEQecBAmhmgq/CYl0c30daTUUkFMpBR5Qh3JWBYXsbnGK6OWadIgo24X6VOPpDazmSqzuh1AhzTelghnWgIxPqNAguC7cwT7Jshty+SB8aufqQ'
        b'KtaS8CB3lYlAuVp740jfI3k+h6hEBfRoYcMx3VQWVuFNJ9cIsxevbId+M5hzgk5jWWjYTOJV0znou0QKzxB0mgWSAESMe59N/B6Ydd2ZiB3bod4Vekx2H8dxWeIpdSc2'
        b'k057B8csieb0MRxp8NY8Zk0i9oA5LpzZRsSt7nSQamCmzzo/gp1CzNrrTnPUb7Xb5JApIPGy8BIBwWywtCGw+OyFxWpATiQz9wh34c2DfKvgXBg/n8QVxpN3YKXxiKre'
        b'N+br6OyGWQ03U+E+yBUIDwiwNn0r94qOFdS4YZkAFpQFwt0sN38Oc/juwg/FB1mZAVZI/q5AeJTegeH9fOGxSoLGGrcTssTh2ngLGTNLLTYsvoNVm9y8RETybwqEVvSl'
        b'IRby3zDvWx2WuMuqpwiEBwUksMwr8pP17Ic8Zlkj0aSft61h51rpgCQ+EWktMZbF4VMCoZeAqHvfWr7AXP3Vk1jiIefgzRnXKmKNuF/rQFGym4koNZO3xqlghbGQGwmm'
        b'wzXcXGWJybYIhCYCOupWeMhXQcvDWQPOIEdf9kgtclXQaix04toMcVltjUEiwTkvVpg1KDYvPF5gLOZ+vUVNJPj9QS4R0rQ95CpfEWnYTCR4V06Je/aLQFuBp7HIk4bi'
        b'cuCij36UL5P0gCjWH3b+LbPKOf4XDup5dV1K4f7mY7F+EgtJXXpd+l8939/m6agqt7E+xNBBs1X0haaSnlXvvwRfvnnonsJ3Ptqsfizxtz/a/0XE1X+kv/u76ul3//FA'
        b'rnT9n76b+j+q1gN6/jb2Zt8tlDn4V+1Tvm/8st/1gumQ+stGbzY5lqXsf/3TPn+x4hv/DA/oG1Y8Krvprx++fuzWJZmfW/3p087XfVuOXHD6bPKdX+v+yQYiP7Z5MfJf'
        b'b31SLHlPz6XjYdjbBg/yf/WXtX87H/Obty1/Utij+cUXxgEnLuqEfWe0/EiS8XtvlChZlb4WZfzz66HH44/nJ2p9sGNoevMP7gvj66NrQyMkUZEF++bCewwv//D4K9me'
        b'v321taY1+EqAlRVmaF/4/Y5fZrR9O+z6zWS1NLd9afNab3zkEe9vciom12rLP151mTI0bqj1+9yves3Bcq1exczf7/zZXxubX/yfqfktB91sunw/PzJl6B0w7m72Uv+H'
        b'FYckp/UcWsLsDV86v6kmUPcjOd+pLs+IPySpHx1cpzSged7r93EFzXF6W32cP/7j3sYP1ZvS1rxx77WB/QnT3//xax//++WCTyz+fKjdwMnyRfPQe3/4RVrcUa9XjEcT'
        b'cv72fZWkxnde/TCv6sUDStuUW/58Pll9oOODLzvvRLgH/f/mrjwoiiuN9zUHN0GICnigeAwDeKBA0CgGUGEc8DZaiZ1hGGDWYWbsmUFFiLdyKyZ4IESNEBU8EEUhMTG+'
        b't4lHJcZUtrLY2dWY2sQ1laQqh6uyq+77XoOa459sbZUpan70dL9+/fr1637f1/P9ft/Wb3LOv48HnIp87kFJyIN9Y2d9WTSn8MKgthT9G6M/9P+kqLvUrbnR79PvnMts'
        b'H7y0La/+vQk398ZH4rFZBVfKzP4/ng5Jv3rudOSKQX1bz3eMr9zWOiN20+3KczkNy8yqtK9jrhd/te/C8MZa/RHNv29GHisfn7Tok+rXTZ6+Dbfm2mffjV40/dlJVeP/'
        b'HqF/5kre7vBPj52dFDZl98oNRpspbELXewP/NSg78d2Iamdln/qv73xz9nTm57YFJV2dCc5L1/7x9opdHXF3zpw53/zDZw2dzfd3XPvT94cyVt1PdZyriLr3Q9mkjdvn'
        b'dbeMKKq5lviXpozibp+N+jn962/pvBUSXD1EIpB7mkXlevpoqSbPnb003j3WQuZ1A67sx/1CGRvtjKJkKQcxvrY/nsCih/FGvJsmJYVFbRLNy+ZNnIwmH8nPy4/M+BUB'
        b'kseXTNOneCa8KC9B0BIXtonGz49MXvyw0DJ8ctlSPzXTb5BvMk/mhwa0mx4zAyxPV6HvUg8+FYDKUWWA1s8btwYUqvKNjM5fwIdyh7shXWQYeRLs+a2CqIrUPRNvp9Ub'
        b'BTXqJLNEjcKS25W1wKe3PkaL93NPR48itjmtULUCt7pQlXYpaZ+LTHplP6swaqRSH25XE5/sDNpF9VyGzIPgEpBzeSTmgqqNj+u5uOf9OnnbuD9A2OkTB104fdr+UUBJ'
        b'/i2KNocpRxRpVHYXAU7PcePYwSAq8kDN+bJaTuC1rFpQc2qO4/1ZThXEBgUFegUODNQEqYO9hT7BXL90bsg4llnFJXBsIk22JPAQoDsQ1sWEsqnDYB2XM7EnERNnTqJL'
        b'3IJJPWtCI0IXBk7x54N4LjAa9ho6tbesnovidOSj53TMGqGFrlNz0XQN+SPrmiD4Wn23N0pcG6hl+7GPf4QHwl3p5YdB0Lyk+nmywbgnPzie7MhklR6hQdnQT3oYDfCD'
        b'ofTX38gfRkXPNkeTZ1AFMZk347KsGXgPgt9SNmsY//48cWvRSeuQrNm8qy+pNuPExfFVFzL4KcFp4q2JAelJNyND04QRcyOjEks2+Cy9tsM4b75f9uUG54/3h9w/WNv2'
        b'ZcylkvplLaEfb2kc1d1YlX940Nnvk652VTUdH3bgyqJNc1K2G1I2r6w7+VPtR+94d82JuP3h4aFDQ463BBW+ab9YY3q/zHSp1nSWNy7Y1nyusfs/t7eP0DR/cdt5OUe8'
        b'EaFZO/9W1OWVg6c150b8c8O2gynf3jFH5E/46tmCxVbd1VPx8Se/jb4XVtL3YlmdZEqq+dust+o99/rfGOw7Zm2yn4+5a8dL3prY3C48aeKdxOTVKesT0ZjMwOvBeaU1'
        b'n4f37fhzyOwPaq6HJnSkVXPDvnNuHti9/N2hr41OvhXv+GL4Xf+uxZ99FBz7MvvTyhfWfXxCN4jyMRYtKAazNisLeLl4K3rVoGF8UBuHDxB7r5POW9M1uMWQFVM0Fx+D'
        b'ghDL/hQ+zcOrr+epAp2aRrXSiwEiAcSq3QuvgcjFCOIHEmdmHWWMxKFyXG1ALRHpxiijhlELnDYzlbLAw+IhJmlUEOpUM+wcBu/DRxZQEnZk4DI9rh4JWlaVaD0qZRmv'
        b'WA7VjSUNo0yTZuIUtffKggmZeBNqZFFroTfdeYLeB2Lwyc7JeAct4Y/L+czJuN2t2NioJrFXjC1oFkvclgO4URH7OroQn6DVhqMWozEdV+nSBSYIv8LD728l9Njk7HeH'
        b'GDKiM8fHoTfzWEaDt3JqMiTr6LGHowOhhrFxIqoiOxt61NEi+Am2ZMq2nwVvL8n2Jfjt9HSjstkfH+HH6CYqAlxH8R7S5ooo4K7zjDALl4Wz6C20Zgrtr75L84AiaIxm'
        b'GGHMiHgWHXohi1ofQUXZ+hhcBWT6AnjzxsJdgZsVyvfOokV6ELybAcczkhNPQVsEJqxEQGsnT6XnFJCM9hugPaS3UoNxJcv46Di8ZfKLtNFjBhS7ejaSnqqEzd7pHGpF'
        b'rSXu4QzVLD2d6IPbAnC7ixz1lBOfWEqME3KDhw8lA2uboCG7HVWY+e3FDCUq6dONaQkg3+eD6jjiyOwgphIYDtG4NvExoUYyokpZtGtxHzc8GdBBtBqvNaDDI8nFBYky'
        b'qhaZlY6qRmXG6MbhfWpmWpqmmIyOOnqlnYnTQ8f4ECPqBCih1zD4DQjYUgyUY+OIB3w8e75Ck2dUxSxunI87ley3TcQLboe46xgQQFe4R6htKMeEegS0Ee9TZN8WDtCS'
        b'Ti+HjCQz+uNyjvEazqGK0d60S1OJ43xInxETbYxB1fidWJbxDeG98f4XlYHWiTq0BrgqHWirIZZUQW4hnZrpE8fj156bqYgBHJiGGvTTo6NI9Wj1eHpV8BYQ/2srpNoK'
        b'AaRzd+kzRiepGNZAfEBUqupN/xT15J/t//e54uknYKc8yldcSEDr791D1wTNtcCeJS1VR/Olimo9Sw+E1aC8xj2A7MRa1sn/fspZ759gUshX1ICIlnmbxS5VkMlNVrk9'
        b'TptFFmxWl1sWcqxmgg6nxS7zLrckq7JXuC0uWch2OGwyb7W7ZVUuMbjIP8lkz7PIKqvd6XHLvDlfknmHlCOrc602t4V8KTA5Zb7I6pRVJpfZapXAiSdFSPW8y1Mgq10O'
        b'yW3Jkb2tLqvd5TbZzRZZ7fRk26xm2TdNoUEaTUtITb5OyeJ2W3NXiMsLbLJ2hsO8ZKqVtNgrOy7eYgcZK9nP6nKIbmuBhVRU4JSFqTNTp8p+TpPksohkE3DD5acKHDnP'
        b'JCh5UsQca57VLWtMZrPF6XbJfvQsRbeDGJP2PJl/3jhD9nHlW3PdokWSHJLs57Gb801WuyVHtCw3y16i6LKQfhNF2d/uEB3ZuR6Xmaa1kr16v5DT8dhBx+qRnaZ0fpS0'
        b'DSy5XQA7APYAgKq/BDLLEkSpSjsBNlI2LcBugAqAtQBVAKUA0KtSOZWwA3gVoA5gFcAagGqABoBGgCaAGoB1AJUA9QDbAWoBygD2ArwCsB5gK8Bq2gywtF6HJYj7kDY/'
        b'ZB/C+PLqNbwW3/214UVLdGtzyTCymPNj5UBR7FnuMeK7Q3u+D3aazEtA1AxosbDNkpOp01IOoawRRZPNJorKeKYsw0gYyGolJ62khfYd6DWWf5EgWtZOJOPAY7NMAu1E'
        b'qrIgMIJay/3vdxazKljDUQL2fwEEIyrk'
    ))))
