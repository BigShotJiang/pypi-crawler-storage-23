
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
IBAN module of the Python Fintech package.

This module defines functions to check IBANs and BICs and querying bank data
from the SCL directory, published by the German Central Bank.
"""

__all__ = ['check_iban', 'create_iban', 'check_bic', 'get_bic', 'parse_iban', 'get_bankname', 'get_routing', 'load_bankcodes', 'load_scl_data']

def check_iban(iban, bic=None, country=None, sepa=False):
    """
    Checks an IBAN for validity.

    :param iban: The IBAN to be checked.
    :param bic: If given, IBAN and BIC are checked in the
        context of each other.
    :param country: If given, the IBAN is checked in the
        context of this country. Must be an ISO-3166 ALPHA 2
        code.
    :param sepa: If *sepa* evaluates to ``True``, the IBAN is
        checked to be valid in the Single Euro Payments Area.
    :returns: ``True`` on validity, ``False`` otherwise.
    """
    ...


def create_iban(bankcode, account, bic=False):
    """
    Creates an IBAN from a German bank code and account number.

    The *kontocheck* package is required to perform this function.
    Otherwise a *RuntimeError* is raised.

    Deprecated, use function create_iban() of the kontocheck library.
    Will be removed in version 8.

    :param bankcode: The German bank code.
    :param account: The account number.
    :param bic: Flag if the corresponding BIC should be returned as well.
    :returns: Either the IBAN or a 2-tuple in the form of (IBAN, BIC).
    """
    ...


def check_bic(bic, country=None, scl=False):
    """
    Checks a BIC for validity.

    :param bic: The BIC to be checked.
    :param country: If given, the BIC is checked in the
        context of this country. Must be an ISO-3166 ALPHA 2
        code.
    :param scl: If set to ``True``, the BIC is checked for occurrence
        in the SEPA Clearing Directory, published by the German Central
        Bank. If set to a value of *SCT*, *SDD*, *COR1*, *B2B*, or *SCC*,
        the BIC is also checked to be valid for this payment order type.
        Up to v7.8.x the *kontocheck* package was required to use this
        option.
    :returns: ``True`` on validity, ``False`` otherwise.
    """
    ...


def get_bic(iban):
    """
    Returns the corresponding BIC for the given IBAN. The following
    countries are supported: DE, AT, CH.

    Up to v7.8.x the *kontocheck* package was required to use this
    function.
    """
    ...


def parse_iban(iban):
    """
    Splits a given IBAN into its fragments.

    Returns a 4-tuple in the form of
    (COUNTRY, CHECKSUM, BANK_CODE, ACCOUNT_NUMBER)
    """
    ...


def get_bankname(iban_or_bic):
    """
    Returns the bank name of a given European BIC or IBAN. In case of
    an IBAN the following countries are supported: DE, AT, CH.

    Up to v7.8.x the *kontocheck* package was required to use this
    function.
    """
    ...


def get_routing(iban_or_bic):
    """
    Returns a dictionary with the SEPA routing information for the given
    European BIC or IBAN from the SCL Directory. In case of an IBAN the
    following countries are supported: DE, AT, CH. *New since v7.9.0*

    Available keys:

    - SCT: SEPA Credit Transfer
    - SDD: SEPA Direct Debit (COR)
    - COR1: SEPA Direct Debit (COR1, *deprecated*)
    - B2B: SEPA Direct Debit (B2B)
    - SCC: SEPA Card Clearing
    - NAME: Bank name
    """
    ...


def load_bankcodes(data_file, clear=False):
    """
    Loads mappings from domestic bankcodes to BICs from the file specified
    by *data_file* which can be either the path or a textual file-like object.
    If *clear* evaluates to ``True``, the initial loaded mapping table will
    be purged. *New since v7.9.0*
    """
    ...


def load_scl_data(data_file, clear=False):
    """
    Loads the SCL Directory from the file specified by *data_file* which can
    be either the path or a textual file-like object. If *clear* evaluates
    to ``True``, the initial loaded SCL Directory will be purged.
    *New since v7.9.0*
    """
    ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzNfQlcFFfWb3V1dbM0m4goitruNpsKLogbigs7KuKu0EADjdBAL+CuiMoOKiqyCbgCbiwCKqDJPdmXbzKZySRhkklM3mSyz0xmJpNkJpN37q0G2Zzlve/7vWd+FE1X'
        b'1V3P+f//59xblY+5If+k+OOPP4aleIjntnOJ3HZJvCSeP85t5zXSOiFeWi/RO8YLGlkOl8kZxu7gNfJ4WY7kmERjoeFzJBIuXh7JWSWoLH64Zx20amW4MjUt3pSiUaYl'
        b'KI1JGuX6fcakNJ1yrVZn1MQlKdPVcXvUiRova+tNSVpD37XxmgStTmNQJph0cUZtms6gNKYp45I0cXuUtEiDUq2LV64KChA/ZJg0+n1aXaIyVq3bo4xXG9XWCfq0VFZd'
        b'ZECoMl6r18QZ0/T7PJTpptgUrSFJE6+M3cfOr9PoU9U6ZYBGZ9SrU5SrsAQv67hJA0ZkCv5Mxh8FHZV0PORyuZJcPleaK+TKcuW5FrmWuVa51rmKXJtc21y7XPtch9xR'
        b'uY65o3OdcsfkOueOzR2X65I7PndCrmvuxNxJCZPZaFoempzH5XCHlPutDk7O4bZwB5U5nIQ7PPmwMnLA5yzOKkklDY8bOEU8/jjiz2jaIIFNUySnsgxPscTPDlul4csk'
        b'9FNMaNLM2ZxpOn6Ek9bboBDyI0I3QB4UR6igOChqvaecm7VGcIcH8GgGuaKSmGivp5MH+xRB5NZsaIG7WcEe4TLOiRyTWpB6ct91dZxkiKmM7mvHVjowEhyafzkwCaPN'
        b'AyDJk+IA8DgAEjYAPOu05DAfOeBzFjWlIQNgbf4ZPADd4gBYT7LgbLjZKYIyxuatWB3HvtzsIeUETrlTwFHpzhwnfrnsoCXnwD0zUxYTY5PvFSx++e42gbPkLoRZ+MeE'
        b'vuOq5xq5FFqV8x4X4c+OnP8fpsG0b/iOedz+x5IUKzxh4V6xYSYXY8/5x3i/p48Jnsmxr5/b9Y36xcmzJ/PrP5T8Y+urk7RcL2fyolPRTcqScC4Kl0LtnA2zZ0PBnEBP'
        b'KCCNm2YHh0Gph1eQZ3CYhNPZWy1LhmYT7aIMig+GBHkECdgFiWIjqXLew6bKPd1kgI4svTHDZCCFJI/koV3sNMFRqc9uOK6SmcbT+u7O1NOr4PQCeqGe56zII37aIShh'
        b'p/VwFBro+Sw4Ss9nSDgrOMHPMhwwTaR3d5ByHbu9GGroeWjh8IJ83n0iuWFypVfc3go32BXVpJJe4SNgDR28M5zTmCbgBd4RpIeeV3rgWWiHZlrAaX4O1I1WzTFRO06w'
        b'X26wQcMK3QYXOHIeLq40OdGSr0OZ3KCXcdxqByjkSJ4NKRJPnPLPMOgt8EPrXijmSAG5mmQay1rrfxCrop+KoBtOcaQIrkK2yRm/CYRjpNRAStBcyGl0gnqO1HioWXnk'
        b'qh8OYAm6FTT5wCWOXDwy0TSGnuhYusCQgQ2AGjgGpVhTJDxiU6LeO8UALXKOC5gF5zhyajU8EO+4T/IPG0x4i9s6OM2RQryzg90xZ+JOgy3eAF3eUMuRCmiNYG0m1VAQ'
        b'Z4A22q5c0gblWJo1KTC50HOF5CYUGEgRG2e4CdUcqYTLUCrWdQp6SKNBge3eD6egDgu1XMXqgoKQfYYsdE+raDjPkRLoGG0aRREs+JDBHn9bjqdXX5gzh7VgHt58Htps'
        b'sQWjsQG3OFJLLkM+G7VJ0JKsoFOAk3EDbuBNcJRcYaMWarOdFOK0SaBzmyVHbuM9x1jtnksDDNCK86kMhjMcKd1OjrMbdFhPF7SZsF3W4+gwn/UZzyohp8kDXwU0YzUJ'
        b'5CHcwQmAu5bi1FT6koeGLIp47rSwgnnkjmgDdYvsDdCJbd4Ax6ECy/BPYoXBVXKB5Bns8RYDyaPVVELxXNawxDk4zpZ44oAPXOFI1QZyXay/ayu5h2doN+9vgetYvxec'
        b'ZWPsDFVjoM3ITCCDVlMKVzaZxtF6WiCfVEGbDc6pDr/Gu2pIN+lht3mQ+0Y8hWMA2QivDVjixEixQ63O4dAGLdhw3zlwGc39gA+ba6jD8sqhzQpvItdxbm9zpB4ewg02'
        b'RwlYVTaepA0pxe9xjC7FomUzC2qEo3vxHI7rITSOZg5nohxuiufOwrHDOObYSHtylRreabgAOawpvqQKT7fZYoVr99DbLtm6sq4dJJ2W2MY22pJmKIUmHCsoImfYSdI0'
        b'DiroWfS/HVBJzeUigsN9VmRUzDKcR7zPyYG2vwaN5RQbELgbDdcUlnRAKhLRQ8lVcj1StOIrYU4KaMXSfLdDOzYCskkdmy5SlGanyMQeR6toLRVwbYzYgiukfIcCOnAI'
        b'oRP9u4VWdByqxA5fgzKSi2exxxMmQBsaM16ULTaiOYCU4CksMnIPraseTioYAoVO0BmM2LgtUsjjyEk9+h+zpTOTdyoowUABNNIxv4BAnc96OpF0jVZYU39u84T7tNra'
        b'GDaPo+HKaFK4EE6RdsdAUiTjpHBJErEfClnbjdC4mhRmwllSfMCFFMg4IUlCsoMjTVRgKDcihtOT4QpS7E1LoPdbkWJ+LDlBalRSVvMUUjUDCqWIh5DPpXFp5BwpZp2A'
        b'W4ZpIQLnRWq5WC6WPCSnmdNbWUNTiJzzCESWjIfT5pmaegRusy7DGTjBOh2qN83CE7E4YAi8kEduLCSNMnUYKXZAG7iSHEAubw/j5htkWGFdlDhDTfO2GKhzHNRjW0gu'
        b'HFtpms1wU4uWZS7jNpyDs+zjfHIDzgmcKxTb7RasJpGLIjDCRWcD3MWmLFBTyC7Zsdukwu/HI/ecEQshHaSBlhJIbvcXQnosSY8g3UuaWX+coRV6GIusncVYxAadmxaz'
        b'HvIRg81tuTWgLTfFtpwhd20F+XhSxRpjIOVeiLeIEYt2w0UE5wVHxB4hK6GHlgWSmzgq/aV403ZhKZ4O5LoU7rnsZG0xJpMWgx7NJkYDuRw5jkZz1uSGJ1YgKXX2jwsb'
        b'W9KdrFBCIWlAZzy/eTQXrLRQkIe8iEtXSb0dI0C4Bs2MAjdAo2muqCIKxw0fYXIHiumvJgSAfNoyT70sA+6QNlYe0gpSMSVOcpzkiMzZbDR54qms1Cl9nTtCsqFYGiu2'
        b'DaGkEueeFOLUB8I9ObSTslDRCy/AXXIPgZ7xbjqUULbCgTbNoF8Uk5OygaNFZ07YyKFDIozlSqHZFnqY0WZOR3y3xvFe6Eyn7dyesSY/5nnkgpH1rzLaPP/FQyewIYwW'
        b'fzNMHhvGZZA7luQ+cuR5hgJxB8h5AymgnNqJnltLWfYyucYEmGED6aFNu90/kVK0MxwtcjIBPa6SWwgN86BWhrR5GgUHw6hqmdGsK6o2i7LiQRizru2QM2aQcYkm2iSa'
        b'aJkeLkpxzttIISsnDXIhx2DH0wnAryvRrCZnsHLgFsLe8ZFcplE001zoXC1YTPVkVjppDJwRpUzSGiZk3E2sa3OggX9SRvGQRjG/mX9AthVNrYKUjmI2MSoE3YZpH1I6'
        b'mWkfko/cT21sBrk2vx8InpjYDVbwfNHyvaFURk6RHlI32dhHvyehXBRNbRZMM2WijKXWj3Z1mVwf7NF9Uyl28pY8S7DMhGIRyc8g+90RVRa5foDJrA3o7fPouaNwwWlY'
        b'27DQm2Kvb6LwKmL2jxhr8IbLYomXotAxoYUqxwpkSqTzs+4IzEw6NkIruc6UG0qZHqbdYqCBOceajdDRV1kTrQxZdB+1F3JSiXx1lJSj44ZBj4U3ObqGTbSOdKCqpnLP'
        b'AZvK5F79BJM7bUPVBP1gdEUvg5ztsxeKg2AgtZakzBOKLPaJeqEic62oDncuYNqQdPiKcUTPfve+gm4MA4CbUDlf7P95mQHOiHMdbUeVOiXuaJSzNWh9pBWqWTXYDx1T'
        b'kqmTmZAkXVDH2iuD+xgh9Fk4azDlggAl0mwDdjsCLlrshUavBGhh/jzpcCiTa0IIk2tYGxvCVGFqPxwUD2oytQRvFFPnKHN1yZKhfazIZo3jogxZOB38Ijr1xXOTTDPp'
        b'1zUb0BfEopqGMcus6eul0JXIsT6t8w8RFeJSayYQoRzdmZbhP3b1UGyaTx1FQHzqIN2QL4WWw3OZWfCHSBMWQnnyDo5JNRVUjajoafmzSGME05m6haLMvAj1zHHIMVIo'
        b'GeKHjUP9MEOGPt9ELugQsqhP74a8NIM9rejCAqpOq10iROY5C10HB+IV/dTHO1JSeUSKLctD3UmbZB/nICrcWVDPJC7pXs9YfbcPiu+yPhMZ5niXR20TLNToJtRMAhCk'
        b'j4tyeDfiIpXDpFUwLaBk6ovDM7hjqCEHoINAWm3CVq4mt2ZiZHnOEk4dQLHJ/Osh3I8SlTTq0E5RShcrRSl9C4qnYaVUA8AVdM06yrcVUtZycg5jxvZhpBmglHHzSV0y'
        b'XJCRWl+4Ijr4SQxdUMnb4KRPxXm6iiMwBu6JkHEzHJX4IBscCLMMsX2gSoaMdxmhJzuYlZhii61lGp/k4wwzkV8L7aY5tNkNJHf/ExASiVe5q79QKY6FbfICyQaZha89'
        b'xocMHm9CfqAYGUxBaqKBgQO5yopD8ix2D2GUhthSg7UN8TmmvzaSYospqNmaRIVwn3RPwpGj8jnGjfa3kjSvEhnlODx0edJfRuisFErlpHmZD2mnFFdhLRZUttQP2uwo'
        b'Mj7EKASl7mVyP5l5C9J6c/JQf/EWB2wCtCSGoQGaY699pA0DlzZGJ6kYSraiLnZdyjJQJN+AmDOQ38ySwBW9pWMyem30FjbiSM9HoS2DElItejp6XClaWDmzhSjnrEGg'
        b'P9AVMHjuxKY8iIRc5grxARgTZeDExY2lUHcKRWC+iCCNU7HkIf3hqTbpRIS4hb6PQvYqM8zNcG2eOVhDem5l4RqqwEcM4x0gB79i8do+8oiFa4d2sDOHUSXdFYO1NR4s'
        b'VNtOctmZJftxclmk5p7EAjV6o9iq64cH60sRK26Lo9wc646jfGSWGMY0RuHYspguGKeBxnTGnaIjXYaTa/AM9aNLSLfoR2dw1stYDXK4FW3Gkaa+CsjdPiBJxim4O87c'
        b'TPKAXOGxHOxA/BQqMMqgxJdB2wQDaRlJpdzu051Y2DyolO2C8xgWnhZ1LByLhh4cx3YaLp2VUC+qOOTEeGHVwoGA0t/thoHFbZFB82pyKmuR2LbTPAJxmy0aSOZUOup1'
        b'ljiEzOKL9mYNZiqKE/1MtT7Ugtwct5jc1LJy5i6PF2NfKkhZ9Dse7rI+bkW4OT4YKW4NHTAf8ki2lnSibT6ayYqbNQklR5sthbfiRBqSXt4HJ8xaZVfAoNLQErv4OHPz'
        b'HLB19xaOInkLJKTK3zp8mTldRc7uxO6bg/CjLiwGT1zAvMAGjk8fFon0QbnKHyql0OmFY0K9KYJUJpiDdUS/ahat+5EORu3QNibjqfqO3PQ/yASESZZ+QJzGECTHhxje'
        b'UzA85U6Lqt4OXSJGNGy2G268N0TjvR8lSKF1Nkb1bP5uzPAScwTjEappkiCFlDJ9iI7X5jWiPDSHjY+gBPIEO2m8WFC5HRxXWMqp+92m0fwVUq0UDaEH8qnQHApZN8X2'
        b'3F5DHkjh9ha4JmaSHsLFAJaaGI2akaYm0oJNHgwTER+vDxNrAyzKw4K0LFqEOH5GnLNsDEAuKYwIF5Pw81XqNxcmmk/FLBezHFCDWETzHOSuOyP+8XDNnmUS3JaLiYSL'
        b'wWIS7xQ5Pl2RiYW5jYNG5EHTHNY7LLQYbXagHh3kyiR3SYgUHu3LFEepxpWcVmRi8attaP6uHOn/POObZdyBwWbZtLffKknbdqzkeDJc3s7p92BktcZXLO0WSv1TLCkD'
        b'FaEsKzNrLxusFYipN0YM+WWOLKqKInnz4KaM1I3yYcO+d+pucw7n/jKWwtFABRO2+0m127B4/UkE2ETak0VlWyYzqsVmSciJHWLKJ5XmpihzXEoSG1y8mBwXUz5rXVnK'
        b'xx/hmwnrmxj2KewoAOTFQzeasN7C5M0MlNQmjxyJDcS4ehkqggtYU7WCDacthqz9BNdEatKHa4zbsowFkvWWFgvh7HY2lYmkNHZY9EhuymJx/JGk243eY2WkiNxWML/f'
        b'Q+64DlL85mkXExmkNclJECbjINJrIZsndSN14pboSgW6cYLlgZXs2i2k5cAIeCI63RJydpQUejzIBQZm8CB293DMGALYUCY7gpK0mrRDjcpSpIAHUD9WYSelXn8DHnJ4'
        b'ZT7Gcs4sc4OOq4AWCV0XeEgdsF6BQRnLieZjeNWG56RMf12He5Qy75hTwCR/NbmosEIiCDXRCbzuCq3ipNfBnSiFCW1rHEdttBxrP8t8KnKCtZjPO61k6Txr9Cr6/cKs'
        b'vQoDOucSpIJ2qneLD4mCshCKPfFAMW8MaYYeRBlo2s+0cPp20oWnykgeS+eRAnLL7I4kj6X/BNK2iRRG4fiWL90lh1q8pl4lsI7tIeWjoTA0GIqknBQeSkj1YVKFt4rr'
        b'PUboCQuBglA5x++WQPnSOVMc2XoPDnwJKQmBkjmoFFWkSUAqqCAdDtIx0A2NTAGsINdIrnu4Z6DACf4S0oyD1YTBZ9faOLpM1vcPe8PRRSqW8VrNsRVNWa4kV57Ls0U7'
        b'aa5VgpV5kU7IE3K4Q7L9VgcFtkgnYwtzwmFZ5IDPWZzVcZX0sR/OhbVywL8AumJL12jZqq0yIU2vzFSnaOO1xn1e1oOu9EtX69WpSm2sWuen3JSkEW8wpiljNeK6rybe'
        b'a6QbYrVxfsqgBGWiNlOj8xDvMq8NK9X6/nuVWh1d7R1UAv0Xl6YzavYa6dq0Rh2XpEzDi/QjVhSXZtIZ9fsGVmbsa6bW8B/UY6TL3ObSvJRhJoOR9pEOUWSEp8+8hQuV'
        b'K0PXB65Ueo9QSLxmxLYZNOlq1jA3+slNqcFBNqmNGrZqHhOzSW/SxMQMau/wss3tF0ecTZK5L8pIrS4xRaNcY9KnKder96VqdEaDcqVeox7SFr3GaNLrDH79NSrTdP3T'
        b'7YHfrlWnGNjXdJCztIYhnRm0xIuAzVlyQ5d4HcLXskXaWO9xHEq1uXPDz+z63i1MjPdj6BJfF6knhfjHNm4bNJJL7OoER2sOL7Cc6xwztsPaW1zn9Q2241wRIeZu3s8H'
        b'LtvHMeSwiyCXWBoE6sjxJJq2eQQPVPbMK6NcQ82n0LmRYyoyzIK00ZoUsdU21LwPSS5HStwy2B16cnI2W2/D0nISEG5sE1lDXciJ9eJ6G9zab4tsFUHEFb19K6BbXG27'
        b'gUEoQtoFRFlzSIHwp0inlTTs2EhpPId0i83yWqLIoN83e5BsFImRGLuw7ERakLg8Zzme1NOcVi0GUfSEG2kledBmoGK83k+JIcK43WJGtxNjzgJx6Q4jzHqCAqZ0ITkm'
        b'9rKIlK0TF+/gUpYv6tMJUCAGHa3p0COu3gFqC8LyBW0grvlNgCtbFGxsOozkPJ5xg4siIVxGfsiFNtbbKlIdiZpy0WQR15uSHQ1ZVCqVQ4UG2zAVakRFVOo/mSWX4MyU'
        b'aI4UTCKtKik7s34pdJrPBE2maafqLWIt5S5IQn2VFBGUUac8D7BlkTirZeZKgmkdjnrWzbWkfJmYboNyOSml+bYrahUvjs9tcoYl0NhZOErjmFPkuiAGZU1Q7GBeqa2G'
        b'1p0YiXu6ixsyguScDf6au/BZZ/VoS040DSiQ+syl+ekyDyjnYiF7lnbhzm+lhk/w5PmVDQv+q0XHz7ORf7ii5HHJniUmf4/fSrb+zabIwybqavBXp75yCPhauBr8nL/7'
        b'azve69F+tSnq/Hdttz4gLc7Ok+Ze+kuLla7wztprZOxfX3B5V/PKP2R/O/nzrl+U5fRseee9UVbLJjpsyd8fvPXDDz96xe/YvVGzHB6s/+vfZ+XYO/09sPOnW+17Q0a9'
        b'uqvc5fOFx55RfxOgeC/wH6/PvnjiS+8f//SM2u/Bd1Oc3F7f11n8Y+veWw8jaxs7n59cuOjz2s+zPn/xo3P33/j0gSHo5kcLViZ/FR3yeqVdSMSFHabJ7zQt9n51+mft'
        b'j+uveiZ88GhLa5h8r1IlM1KK9bIn9e6eswM9eW4c3JGTSt4T2kieUUlH/CIaepciBIpUYSZyz+jpBgVzeGTiXMESBXarkWYWnEmVNynMwr9QrneabCyhGe4imTsuHUta'
        b'pejCtVBgpMYw1kpL98C4eXpJMNbYKSfHeB9frZFtc7g9foe7V5CHm4oyvheUekA+YoNS2O1JLqpkvfxsFbUhbshBZTXSt08/0GXsH8YsTdCn7dfolAniDigvynnLe60Z'
        b'AkfTP+hlhlCKgkcc5ggSXuIksZHIJfxPTrwgESTW+GOD3+FnqQ0eLfEbS4nA8/+wluJvvM6a7/tNrxQkrnikyz5iC1TyXoFW0ytF8uy1MFNRr0C5o9ciOlpv0kVH9yqi'
        b'o+NSNGqdKT06WiX/5x1TCXoqJ/R0o4ye2rye7pXSU5nBqq2jHaJTwGW7PpbzPHaGHgWJ/B/0aKI7rPbCyZ0obQLDqMaBUlEbjUFEr4TjUrin24uuTreToKKpg8oQPO3h'
        b'B4XhUBIRJOPs0qW+4yaJmjEH7qhDQsNFlSThFCttt/NwO2i2iC0N5GHAE211UZiz0ipOOoR3LPp4x4/r3+wlJAhmQSRlu5YEFERSJogEJoKkh4XIAZ/NgmjDMEGEtEl5'
        b'uV8R0W1q6r5NaGz7GmV5JmHUcWxqlDpTaiwVJYMKohLJbQ+qijRmN259++ioFtFrMkxavUjm6Ro9qq5UUXX07aYbzLsRfXSMDXHbiDVqUzVr9Po0vRsrTI1n4ofUvlqT'
        b'rtfEYU/iPZQmvLGvYGUc6x+z4tmqvh1/T5qpTNHG6tWoewaVtkWbkkJVh16TmpYpaqhMjd5Ay/MdWSbSgaLjJErFoaM3okYyj6Z4x9ChHakKKizXpqgTlVqxF3Fper3G'
        b'kJ6mi6c7Dam+NCSlmVLixZZT6YNNVxuUWZqUlKcpozVaOtZPhBjqYbXS29NoSkeBZZZbbLpw5GbTKzxoRap/opOkZpsdrJOswk2p1BeuRJGLtpC30pocnWsjwFEM/m9u'
        b'gOwVQaRKpyUN0x0xfMkhj6B8cThcnkjOkjMpFnA+AO5qkOqa5BiPHUj2JB1wC5pJiSscN4aQ8pWkgtwjd9eSfOiU8uThholjIWcaVDGy+3EvzwmbVqLnx9gIO6Zwpqn4'
        b'ZQBidRkCa6nKE28qpdsQMZSpDgqTcBNWCIegfamo6s66IFMGegqcMiblp5g93CatXcvPeMM2PFVa/7rtyy22R5UOsjeO/HT0Odv3nslOCkvx2rQ5eN+mhUWSquDvv3lg'
        b'd2FThdM420UTmvxCPQ+6nf3h65JRHuHbqly37Azf9cObvywLG7+kFp7fduHxmZZzk5f8cvTOHYdVFkYxLy9Ay6xU9wgPJGZOiJKQ+yRniZGt2N3D6CrfEOQ5OzgsHHkB'
        b'iqBUQa9DMikKseACoBI1RoXFmtU7jRTIyENPvKUQEMTcsasipMm5sauhNVZwg27BSGFqPzkFDSERnkEeKhWp9uE5BbnLQ7fEYKSb6sj13XOgkA7XjmnigEk4+w3SKOiA'
        b'e6ySbQiDxwYPKbkPd/uGNC3cSDeUBGBofS7EKzjMI4gUI6ZCdxKD1fHkrqBLUqukw3H8abTFwLxXMcC/GUuNYywl1yCM/2TJ2yATySWOjJMEid6+n3FkvZZ9LttrYXY+'
        b'kTJs6MGWXsMPaIdUTyWa3oEerPqphJb31hMqcbw5ApVQNt+8MHJAp/t6PCVC0K3HMNmfY0s310nNsOi9Ec6R4yiPi0idhxRN/uyukPmkJIPcwqi6xxpV2hlbqIEW8wLA'
        b'jk0kT5FpR3fAobI9QRrgRoaKnUlaQHoUmRn0TB4HBeugmpzeIyYUquBBogE67L0Fjoczkp2k1ZlcdxATkWfJSVJi8MYhk6RxE6JIp902pmL9yRlPRWamHIs7wWnRHSvJ'
        b'VdJt3g5EqqFlTT+j+R2ZA11rRKK8R2omDkoWzN5KUwWXSJ6ojQtDSZk78qSE40mJJDMjAMOCkmFk2B+EraJkKGV0KG7u5XMtEyz7SVH4t0gxEUnx06dlCRio/uscAUNm'
        b'iuL08n+dIXhK4E5v/n8et8elsGYZNMbhkfqQBtJxSYuLMyEJ6eKGN7QvVl+zfqUyAHWbnpLU6n973/uw8tg++AFtU9NJMbFN/G6RAZvcPPDX6tX0V0DExnn09yrvVfgL'
        b'W4nnA9w8hpU4oE/qFEPaiBkH2kk2zulingGLi6d8uS99yADSf1Hp9N7MRV6+XntZ6SPqoSz1YEFE5QqtYlhxaenDpdF/b05Dwo2U07Az5zSqE1zEnMbhn6Y6LV4oZil+'
        b'tXE0R4OcueFvLj62ZgnHtkZYQQ90Lp3Yl+eYTu6IgfgNF2jv2wfOj5ZAI2RbkZshrKDTU+3FdId83I72qS4ItywKDkiDq+FbfPDTPG4eMkoFq4CUTyfH4MRMH2ykN+dN'
        b'utexMr6Z4MApOc53bsIyuW/EXFoGQ6AihM1ztnDeXAzcg2xxe2Cdah+yUj1bflrPrSdH17ByHliY8zFrf514yFOHPJ/0rKPM0I6nlhUHeIYvtiP+Nq75Zw8smmA5cdf4'
        b'1fmffie191+vfOD09dQNKZeUDpuOxh8+/Xen352qur+04+S9w4IpOG3/46I9n2z4+OH0Pxuy37Ba1PB23WdVH39uZbu4KerOqx8JV+9t2JjcGPDZRx1vj/F0N236Sn7+'
        b'z++TGS/2nLnn+tG69/yCPNonb5z+K3dtzucxexP2/kY5yaI0Tr195uNX77d8tnneV2E/lJ7bk7akfcEs8tGSj5PDc/749ve/s98dscj/RZNKztg2NpKcNMeqGKh2oyh4'
        b'EqzegmojZYbomaTKHVo9xYCXRbuJ1iwOXkHOj4JCUjgWeQtKOE4+n7cLg2IjTfyS5hDUY7WkJgSKQ1R94an9XGki6YKjrPJ0UmV8EgVDi40G7tlZyTkH6JG67lCyKsjx'
        b'/XYoTO7vMAfBLAJedkAlEUnX8j+KY0VBYCVGrQjJTA54MznAHRFkvMRGEINWRxq0Ojh8g4ErfpqKJD3O/GODMoGGsfrRT4TCk0CyV4rwOEAf/KsYVDogBnXq1wy06D89'
        b'0QzjS0bQDHT84PY6cqE//oxgfDqK7lRsRftOkqok4sMUN0i7dmDiHi8+R6pIS/qwB2P6g0hfyps88qY0Qdr/4Ivk33rwBUPIH74chCcbRTx6SkAiwqdGpDkWYXgxokxI'
        b'S0lJy8KrBmMT4zItjUb1GqXBlJ6epseIzk+5eo2HcuUmD2VA4BAC/m9E3JFD0WEpYGEYXFqEm6bh50So9KAC3D1k4XJU5PmhG6DZqIe7Um4iaRCmojpvMq1hogqqEujj'
        b'NlsCcdLMCQNPUk9Obg70QGeFoqBQKAiKCoTCORsD+9XSJvpwlAXpsiXox1PZ0tdKnOlyVlI6etlmeoPzevRHCTmzxppcDCclh61JEyq0aHLUQh1BShnWLV3kiAD+xiEF'
        b'F7PzR99QTvubzSkyQyaemRGas+DVFlvAwOyZIwUn2vw5jfRtl2enXQlrtEohY971taqb92XYtBnpa/7+Qdulb57XzD2buWjzZ983ZscETs/N+K3tbw76qD66dymtqKRo'
        b'2X1XG9OuF76tcfvp8+QHsQ93lBV9bX/P2enHwBd+dk2XaNB5/X6OffLkqqV+KhlDlJQx/Xm1J0k10g0XEavu7THSNf1J5PQqM6KcJTcG59bEzBqpQ/Chuzjk0HwQ2nBA'
        b'UBsXeZLSSZAXBMWIXu5BYRnm8kPIDQvSnEAajNQ57ci1UIx+JKQHijk+U7KSnNaylN/qPf3JPHu9rT202mTYLoIKOec6XeDh0hREiH+CAE/FKYtEjbEfpZRmlLJ0s5Q4'
        b'IAbZSOzMaIRhi9ThHw4Uk5z7CmiUiimtJ0g0tJ5GiXgFAxx6n1LSFxplc9kOH44AORRM/KKNOAQkXwQbhQ7yN/AYNdaTtqeDyUIzmCTw/yGUoPD+oWmQr0Wmp2iNVHU/'
        b'QQtUkeiv9NsEvTqRLfQMQYA+/FEr54+YtRh08eyAiKjwTRu3USRZExASGRXmocRaQqIDIhjEBLDz0eFRYavWbFQ9HQh47smzhk+AQC4+7pfsRx/3S7K0V8bYvG0Vx5ko'
        b'3o7GIO64CA8iODzxbAHOqEjjzFHWpGKf2W1pVHbSGg0/WHxY8pLN+P57T8Gl4eByM1n7iw+uSwxBePVH+b/+IiZUHahO0ZyJb9A0qD+NmR3n8ZG7OrA5UZ2ckBL7JVcQ'
        b'6O0R82XMzpe2vroVtnrYnlXLX/7lXK+Y7S85vPZMhR33vwrtp7WeVkkZkcMNqF9IXZNcGjPIO9Ezr0I2UxHjNupRKpxMHCAVMhcYqcGZSOeMkDl4i+dsOWc1Dj1mDKk3'
        b'Qs2g6Jof0UWsMSYxDAjtHc1eYrOS+oUdC+otJfrx/XeNHVrWuH4noBf5DnQCu5eewruKmSTXPdDDLfxJrO5MbuwmXQLN/V5ViVetiD4isi5NecwhBaLLjD+yfZGQRJpM'
        b'/zP+8liQDAlUB7Ivyzbq1KksJOpzIrpGmq7BsIqyMZKxSMFBOmWc2qAZ6h59OWDjQIb+/56V+xxysDMK4Sy9McoXTiMRFI82wF2TjOPhogS9Zap2neob3kCTEjUfT/gi'
        b'5tOYlIRQ9dl4y4DQhA9Dpdy40/yver8XjYp/uoHaMAzHYaejzkxU3meikXrXJ3Ddq6A2HJ2mp4A/coIJEXtSv7HSW4MGGWvnCMZKH2txhxw4KmI2ExNQgn4aJuMmkzMC'
        b'4vZDqJkHp55ujH6iMdIcypPlhP/EIKcNzZw8geN4LZs4tX6fMktrTHqSDNCnmYzUrrQ6CtFqlqUfpBMHFTiSASsHPUvfn1MYaNcDbXmwQf1Hdq10C9dkKQ1aXZyG2vNi'
        b'r7lug0ob9MfKTLU2RR2LFLRHs8/gN9gnPLGtm/zM6RC0eBQXm/RqnSFBox963erV5uvEnilXa2LxauSuIZTkqaSZjqddO89D6RbfvyriNvTWVd6rRrwTvx96aWRAQF/D'
        b'1fr4/mTOkKvCV4at8WNZGgZC/5w8hy8QmF8WkOfEcg7pB+Jjlo49ksWxzZyOySgEB3Ank7vr4ydv9NzMc3PCkUDhAXnEEgX7Sac1KeTI7bHijoscb1Zsmw/LWsz2sYk5'
        b'GDjFkmP76jaQ6olMPtNH3pfKPGkmPWQLldF9IpruZj4RTHdTI9XNhSLtF/OvSAwpeG9KW90XMV/HJCeEPndD/VqC6qOvY4SWPS7f7PW7kOziNy55XKVL4fMh4zZeSB73'
        b'3NEvZ74w/qTMv131miL7mxmhigt7xjl7Oyet3KqyUXncCj3jf3r7C+NfiI2rW/4ru5kNy1+QeShcjrn4/oJziZngLutChcyWhPPg+tRBEnlbiEjDo6CGca0BrgXSBWUo'
        b'VTwJp4OgR7w9NxxqSKF9/P5M6CD5WRk2GQJn58GTrvWkmS05LMHvj1ENTPUvXIGClaSE1DB+J9ccJDRzi2KDE1ZsXygh3aOnD6Lwf5mop1hpdv0BiXqEygSMwnmqeW0k'
        b'rmbVq5/Sf/PEpxc+uR8w6eVRAwHT8cYIgElXfuAeNO1ngMk0CZtyC24CnFgG2QJpICWrzG+d2DSFZNNXHJCiCGp6QTIMvlulOoy3K6F7AZPtff+EgZBKX1LCUtLsnRMJ'
        b'MjOo8nkInYekCKo8A1UpA1L+sDRywGfxzRKPFwxl+dA0dbxBmapOT8fBM4joF5+WqjEYtXH9K49saxV7AUk/OiZoEYsM6Zo4bYJWEz+oyNh9iA5qozqaXuOmzErSxiUh'
        b'dupo5lPzZE0wXY3IzdYEadLZpE5hZXqmaPcgyMYmI24MJma644su0uv/6ZYvrU5r1GJZKdgv5H5zx5RGhp1Z2pTByV9sUbpJn6iJ/5doPAhmLLmR92uJqx6X4eIK9+Cw'
        b'UAknhJEbUySkhtRALcOK9n08nVKHq9KYlJRdck7cZtoRSOoH2gPG5/kRnpvRKQvnbAgktyDPAz0uY4U1OWU1jRQHi3uUrmFFxe720OIm4STbObhuR5rZWgiUQR1yd2EQ'
        b'W7/zETjLjMOkkA+2gGtmA4RH0OVO02tQEiGaKTxKwDC1RxpI6mawXCl0Q3lkpHw3HOcQ3aaP38raP3EaDfC5mM+FmJ3le1aIadt2e7Y/LbBeF+O6Qblb3J8Gt0iuFUXL'
        b'2hARLdtJtrhZty1q6iDA9YQTNALu2EizEG4YlGO/6yaxknt3stypMs41xmOxZr9Y3WxLtpfNoWdpTMoUG1tOm1+5Q2b4M56xqljgGd4TLKy0Cf8kLfH33+5MPX6I29Oy'
        b'5RTsfvYjh7veJ/Y36w3ShRUvrKlYe/BExaIFhessrb4//M2alwJ9L95ufCPRI7Bp6itXG6ytXmhL+Y1xnov717lJQRHf5W8rJKdm/PXyka7jB2PSjj4TGDZe/eexzSt+'
        b'crhzf9IVl4Ib68erm2we+/3w5q++v6378DM37a98lv8s3f1vxyoLHus6zx/a9njDjLKUzSmzpj+KelyR+lnD1TVRL5e8L9F2+nW/OMbz3Yuk+pyn6e4PG6XTZ00ufafn'
        b'2OzxHe813z/+vt+3Py2+VO5a01xyOXGR/+LGjxwOZJIfZt7L/fa39hszAtdnBaocjSxXV+O2GQoDPcI9VKpR5D5dYb3IIyDdW8Iwlu4/nuYeHgbFck5YlTlfQhqXzBbP'
        b'lG0hdWZr9Sfd1FqlLgzxPWZBKwYrNPkqQAu5s0hCbpMWUmKkNhYVRXKh0CPcjF+W5BT9mz8EV+OM9PEGXbS3gZ2DdjTiDJH35kNDX4LEj7TJyT2oJj1isvYqqSQ33b20'
        b'3ioo8MAgj9zkfRy8WIzoPQluu3uhUeRTe6bW6gQX0FTGkg4hUNjDtkVFT1szaFcU6UgdlLyBOtLOeGgDKYB2NPtlUBYU5sFzcgveMjaUkdhKqDCJ26Jozpkcg3N926JI'
        b'h61RfEMJnJO4e4WTZtYaSoIlvCd0yNl4QfV+W8aQleonDEnyg8SkdmNU3AB+JQ9D+uJcuEDusGXwTankrnu4Z1BQWIgHDtYYlYRzhm7BG87CMTYQSnJjzqCst90e976k'
        b'twEa2XROhSa6Qm/CguhKZ6UkbD95yGYMG30TLrqzNuDoWcIJchu6eHJ6tOLfT4b/k4TUAD62o+Ab3U8efF84QCnZ+qC1xJoRsQNvLXH9yYYRtBh084yo7diR/mfNvneW'
        b'CD/pp/XV0Cj0WvWTS6+MEcKAsGdENm/k9VTq6Wf0kzotzjCQ1J2KRyB1+kQq1MLpPeLbpPoDoVrSKmZWEa8Wy1DHnSIFw1h7pKXk/jdF9S8l/7vcTQOiSSNz97BY5Wkk'
        b'/VRiHkqJ/xlJj0jMg4r8VyQ9uPVZ5g1SZmIeVNJ/QtJ0A0X/vv9+knYK73u25+FBM+xNkbikIEO37UqhSuvdVUjRSd4y+koxiDLRZT5SR26QS/8GQyM/L4CKaS4gvgeG'
        b'HI+HAneRnhF3cuD6Dihl2VBSvSd6IEEjPe+AO8G74ZY5B7SPHCXdgxga6fk4nGUU3e6u4k00HScjF2cYGHlCB01CkHa7TFtraEOAILWZUZaZdiSbtGHfekgOOQUV5GQ6'
        b'nilDnydn5In0aeOjjuT+QnhoWktN/TQUwKURy8uMMkEeFreSNO/aCXUpifBIGeALudi0PKsgkuPDkbNHHBFi2mwYR9+a48x57P2FnFPGHNwRmiwSd1Mq9nSpr4zzj7FJ'
        b'tl4uBkpQFw1nFFDM9hAhS5RGWmIMsSGwb5gLScsElNNhiLZxhyx3kuwscdH2EUENgyTCcVtXLeWW6ueoeFbJqEhUKOM8pTh9B78amyXW7GKBCkX52IKLiXENiPcRIz81'
        b'eWQ7NPJzXTVYh3RFquRsuXkPMugVaHuS6SF55OpU9QGm+IJJPtxTZNKnZs0bZOAGDx3sXDp+m63IxFmo6NsiUw05K5h94Mg1D9geE+LlDKcniZu/H5KGNIO3k4+4PYZ0'
        b'hrmZt9+jqSgyRyWZ98dA5WxSL0ahSRjcKudJsYs7fVy0Yr9tojA0nT6JPi/t6u+RhfAtPp6egxHYGUXmASjrby88nCvu+0aAI8ewM7VQ/6TBJSvEXTR31VsGNDiCZDsH'
        b'khpxS3gtHHc3eG+362sxaSdN5rchwXXySJGZkNXfaD5B+1PKQ4lhFSLaxLq4ZaXLwp+b63Ai8cvnvv9AVrBmMScbc+n66p1H+ey6CXctr7w1c4/n6/emrNJLPuKdXh7j'
        b'K1tU986rc+2mtnqsePT9J+/GPetOwtsNd/ZPX7D1prLgFzckrjdLDn7T8LeXCrsaU0MfwNg/r/WbWvBy9xelb075ePIhmXD6Zvi0m29GvlO9NGTz1rdbXfb7+NdaNs7O'
        b'qDxbuHXU+h+akn1zu04ULr70pcNzpesWTjz6F+feCZs3Zj+zeMa7GQadzysvPoo5kPanh+OIInij13TNl3a/S3jf47ebN877MPWjopCdn3uXd5FzKWtf+S4vLHeTruVQ'
        b'25ioFGeHM4utTPa7Db3q3MuvzDwX0XRhk4vT68uLX3+3emXbn1vGhB82Le3xObLxq5Li13rGftJy/7VORfdrm3/+sNlC98KYnyVv/Un4qfbmlL31U1/+4PWxz86It3+U'
        b'Q1Kfb52tsmMEP3cejjSVgDo4hSqwXwLeJvlMY8VCw4w+CThfAsUo2RqdyXWjeadWC6nvx0NShPBTs2mnGJ+3Rkzt04GLJNA8ndye4MkUE7lOTsLRgTIQJSApg7xDkYgZ'
        b'9EFJaIVH8uFCkKlAchVq+pUgOZMoNqRh4lR3LyYCSTfcFoXgtsVsGyA82jt1sBA0q0D6uq5AUjjPKL4Wb9YScYs9Vi1uOkDV+oitt+2WkeMKN4ya6N2iEksdj22YTNoE'
        b'uGOrE6VaPTmPkYv94FTGBHKFdHmRa6yOvdDDVCSVkGmkjKnIWVDEZGD8Zg9zIyVw1lGUiKQY7rMRC/KGR8NWIgVff0tyjtSq7P+zDfb/XKn9n2xwsGXCzRCXEk1lAtNt'
        b'2826DZXb1GHKTSIIdEnRge275/9hKfRpObqPf5xETLzIeXqf+J/NDzZWruyKqRL+qPB3vaq/AVTGqyz+nfbO6pdx9O4LVMaNN8s4Lnv870YQcrTsUetRvpt13ByUb6jm'
        b'2Fsmp2O4XBsjW4LnWsU0Tge5PjtkwPo5nHcnjbMl3PQVKnJOtjh2O3sVpBMadCXdUQinQ7y8pJw1eTgaynnSk4phtjQ8fK1KslbFh6/V2soypIYO7OO4o/tSf5EbOXql'
        b'k/wP7/96k9JhjKqgoKc+Nq3hnQPPezV8mujUPHrCb7ZZ7h87f+EvW+pmun37mx9//3edoeznLom/O2xI++DADu/y/+ruSJ71+fHRjq1r2jff//3cV2RxVz9uTbGpXfK7'
        b's8/WvmHKOH1D4aQQQmSr2r92/WL7L//4+T3h7ZTyHc89bnb6Ov2Vj+XfOL5Z8/q3MyE8oy34b3f/sVc5zedNRz/rSv57F3AMuzTvuVmvzbKX3R/12beLPvn92NkH3cpW'
        b'Ok0p2P3p+7c83p3+hsXzuxwPbVgVsmHtqz8v/XadbOLRbKOD22cxNvUB84rsXrT0c7z8aVJRfdyGNS+ql9YcTfYbVfZpfOhn+r9WNL1ddfIzozzhzW0Xwva8t/STGK+a'
        b'3O1+kxWfrvK4VGjq/Fum1fk3NVvDt8TM2HXiLWPx7ehCk3HZQuPLk7Ku+6XEd1tVfeaccvXXzTVf+y9LfSb8gaJLe3n595MOfdDjp/jy8rxDlT/6+le9Eboj/dQkot4v'
        b'rOupKXns+/Hm5z6zqr5yPb3y4soJyxRl233X/eyLvyr8Dmy4806J8NUzM/a7LDSdulLzQ2fXpYgjb3311ekGf+u30ycuSh/d+caJX79fP6liU0nw2Pjnpv58/ba0rSev'
        b'hn72/PdFh85/sOmzvM98fvy79y9t9920ywqNmurx27NXFGHnTpd4F49/9rXg63ciPzz7+ahn3z9rv+Krgzt6l3d1TmzOaeG+fnx43Ts/ji9be3vhMQvVieibX471+YPD'
        b'++9au394u3SdS4XTkbeWvzD6yulnI29/W3ToUeqz4Y92xa/7auN/LVtX2pnzWubjNcGtpFk670T53rdGvbntgxXbnq+J/ri4XLH3fqff7xK/nvibRMPmP9RWH+hMei3X'
        b'/rtP//JDT9vJd/6imvGXnkuZk7suRNX+8fmuHZ+uiBrVdepcjzHVIfqPr9+wrap/79GfDrwQGKh6LV33ybpM+aXw43FHuIWfRzr5/FZlz1jAHzoXQiHSg4Q0wFlfDh2o'
        b'ZomY/K09MGcIpo0hTTS0jYYrDLj3h0HVENg1g27CQbhjhCoRuC+gjr4ygGlyPMltp1ViHc17MkMo7heIa1CKaaSaFPNQD6WQy2LzaB/yICTUzUu8XQEP01J4uEKurmGh'
        b'MzlJGkeRQlIaEY6UROmIFJNS1NRy6UTSsZvxJ33+mpzBkwVYaJGUExZLJtHdTqOgTlyrrpTOGkYLcJGcJ11wBlvBXg1xAZmheaQHtFge4tgsUgH5UYyLTKTywOBonsby'
        b'pJmn4fxoUiturz8/d/GwHSJ0e8gu0iTwu6BWzDycpI+cF3oEIamfcUVSlO/mp2EjxW5dgZNR7sGekBcUGo4jRy6QDtLCQ81iiUjil/TkTgjdwI+XMBbHwc0nd3homuGs'
        b'sv4/YJ7R/4009hRqoyuN/86BsZpldDTjtWhGaNXIF/xYnp8vUVKi+knOI6XxTlI7iSAVeIHn5bxE/E/+naUNb80+/chb0EfM6GNngpT/EXnu74KM/5sg538QLPjvBUv+'
        b'O8GK/6tgzX8rKPi/CDb8nwVb/k+CHf+NYM//UXDg/yCMEn4vOPJfC6P5rwQn/kthDP+F4Mx/LozlPxPG8Z8KLvzvhPH8J8IE/reCK/+/hIn8x8Ik/iNhMv9YUPIfClP4'
        b'D4Sp8t8I0/j3hen8e8IM/tfCTL5XmMW/K8zm3xFU/NuCG/8rwZ1/S/Dgfyl48r8QvPg3hTn8z4W5/BvCPP5ngjf/X4KP/HVhPv+asIB/VVjIvyIs4l8WfPmXhMX8i4If'
        b'/4KwhH9eWMo/JyzjQVjOE2EF/6zgzz8jrOQfCav4h0IA3yOsFrr5NX3jJP5nedch3IHtMHKU8DiarhLehz64Zz2e58fRv9zp/kfemZ23Z0drmtzhXW1QKvDTbCSTJI6L'
        b'nCV6tz5JoJL28tHRA5I7jv+DNiXRu/fLCtoC9nYmmsie+8UIgoLqxLVBJJdCivmBlHyGJy7SmdAxcR9p1P5s9i8k7AXqUzNf8nx5njXxd/D/ecW779/LHH86ZsqnFd2k'
        b'LuxLj7Lw7yp2PFc1Puetv/1h1679LppT26K//fkGi5qyX7957aNHVbA55Mrzv1z0s7CXflJHvPWSZXB9fWtcxKvZ0ya+kP9chWLLNz1/+fK3uwJm9bz87R9lx55zfT7k'
        b'pMpKVMvF5DocZ4onApt4FiMBmkVQkFYeGkgNVDMUGo2RX2dIhCd9wW9ERIQnuUMaeW4UdEupDIYTTBFD49YDYk8p+pqR01EK90jepL0TWV4VSeG+RUhQmFuYBScXyAlb'
        b'3nI/HBdP5dF3B6Lwx+gvkgvFKy9vRbhke6a75yx3D5ZxkhBuJgalF8ijAEY2ArlBblCYtuAkARy/nr7A0IY1ZfoG9Qjva0+AVvo+TI4BWiJch0b3/meWsFr7JCkUaJLh'
        b'JLk5aF1x8v8wUP1fGaTsX6MaTaOZUY3SgKWttXlfHz168aJsF/z1Hv0eNaVXmqLR9Qr0GYNeGdvT1iukaA3GXoHuqegV0tLxtNRg1PfKYvcZNYZeITYtLaVXqtUZe2UJ'
        b'CKP4S6/WJeLdWl26ydgrjUvS90rT9PG98gRtilGDf6Sq03ul+7XpvTK1IU6r7ZUmafbiJVi81GBK7ZUb2F6IXmutQaszGNW6OE2vnD2xEccel9KkGw29o1LT4hcvihY3'
        b'XMdrE7XGXoUhSZtgjNbQhzV7bU26uCS1VqeJj9bsjeu1io42aIz06d1euUlnMmjin8CG2PPJ+mD6mea59Cvogb7VRD+fHmhqWk8X4vR0gVW/iB786WExPdBNVXr62hA9'
        b'3fypp+/M0i+jh3X0sJIeaB5Lv4Qe1tAD3ZOnD6SHAHqgGUQ9TQLr6Ztz9PStP3qavNOH0MPyftShs2TdhzqB3w1HHXbFD5Z9T1L3OkRHmz+b+e2H8QmD/z8TSl2a0Zxk'
        b'DVdZ0sed49PicIzwgzolBbHVw2xJdFcFfm+N06E3Guieml55SlqcOsXQazPwIVl9WN+ADjiI5rhU/J9ZLJf0dUHgBAtLsxE6reeZWf5vTzDs7g=='
    ))))
