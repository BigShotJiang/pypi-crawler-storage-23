"""Provider-level variant selection tests (Issue #32)."""

from __future__ import annotations

import torch

from sagellm_backend.attention.base import AttentionMetadata
from sagellm_backend.providers.cpu import CPUBackendProvider


def test_cpu_provider_activation_variant_selection() -> None:
    provider = CPUBackendProvider()

    kernel = provider.get_activation_kernel(moe_masked=True)
    assert kernel is not None


def test_cpu_provider_gemm_variant_fallback_to_linear() -> None:
    provider = CPUBackendProvider()

    kernel = provider.get_gemm_kernel(quantization_mode="block_wise")
    assert kernel is provider.get_kernel("linear")


def test_cpu_provider_attention_variant_returns_cpu_backend() -> None:
    provider = CPUBackendProvider()
    metadata = AttentionMetadata.for_decode(
        context_lens=[16],
        block_tables=torch.zeros((1, 1), dtype=torch.int32),
        device="cpu",
    )

    backend = provider.get_attention_backend_for_metadata(metadata)
    assert backend.name == "cpu"
