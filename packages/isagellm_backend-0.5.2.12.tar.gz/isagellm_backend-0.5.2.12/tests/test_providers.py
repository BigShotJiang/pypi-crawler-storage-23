"""Tests for PyTorch Backend Providers.

Tests CUDABackendProvider and Ascend backend interface.
Integration tests are marked with @pytest.mark.gpu and skipped by default.
"""

from __future__ import annotations

import pytest

# ============================================================================
# Interface Tests (Always Run)
# ============================================================================


class TestCUDABackendInterface:
    """Test CUDA backend interface (no GPU required)."""

    def test_import(self):
        """Test that CUDABackendProvider can be imported."""
        try:
            from sagellm_backend.providers.cuda import CUDABackendProvider

            assert CUDABackendProvider is not None
        except ImportError:
            pytest.skip("torch not installed")

    def test_is_available(self):
        """Test is_available() class method."""
        try:
            from sagellm_backend.providers.cuda import CUDABackendProvider

            # Just check it returns a bool, don't check the value
            result = CUDABackendProvider.is_available()
            assert isinstance(result, bool)
        except ImportError:
            pytest.skip("torch not installed")


class TestAscendBackendInterface:
    """Test Ascend backend interface (no NPU required)."""

    def test_import(self):
        """Test that AscendBackendProvider can be imported."""
        try:
            from sagellm_backend.providers.ascend import (
                AscendBackendProvider,
            )

            assert AscendBackendProvider is not None
        except ImportError:
            pytest.skip("torch_npu not installed")

    def test_is_available(self):
        """Test is_available() class method."""
        try:
            from sagellm_backend.providers.ascend import (
                AscendBackendProvider,
            )

            # Just check it returns a bool
            result = AscendBackendProvider.is_available()
            assert isinstance(result, bool)
        except ImportError:
            pytest.skip("torch_npu not installed")


# ============================================================================
# Integration Tests (Require Hardware - Skipped by Default)
# ============================================================================


@pytest.mark.gpu
@pytest.mark.skipif(True, reason="Requires CUDA GPU - run with --run-gpu flag")
class TestCUDABackendIntegration:
    """Integration tests for CUDABackendProvider (requires GPU)."""

    def test_create_backend(self):
        """Test creating backend provider."""
        from sagellm_backend.providers.cuda import CUDABackendProvider

        backend = CUDABackendProvider(device_id=0)
        assert backend is not None

    def test_get_capability(self):
        """Test get_capability()."""
        from sagellm_backend.providers.cuda import CUDABackendProvider

        backend = CUDABackendProvider(device_id=0)
        cap = backend.get_capability()

        assert cap.device_type == "cuda"
        assert cap.total_memory_gb > 0

    def test_create_stream(self):
        """Test create_stream()."""
        from sagellm_backend.providers.cuda import CUDABackendProvider

        backend = CUDABackendProvider(device_id=0)
        stream = backend.create_stream()

        assert stream is not None
        stream.synchronize()

    def test_kv_block_alloc(self):
        """Test KV block allocation."""
        from sagellm_backend.providers.cuda import CUDABackendProvider

        backend = CUDABackendProvider(device_id=0)
        block = backend.kv_block_alloc(1024 * 1024)  # 1 MB

        assert block is not None
        assert block.size_bytes == 1024 * 1024

        backend.kv_block_free(block)


@pytest.mark.npu
@pytest.mark.skipif(True, reason="Requires Ascend NPU - run with --run-npu flag")
class TestAscendBackendIntegration:
    """Integration tests for AscendBackendProvider (requires NPU)."""

    def test_create_backend(self):
        """Test creating backend provider."""
        from sagellm_backend.providers.ascend import (
            AscendBackendProvider,
        )

        backend = AscendBackendProvider(device_id=0)
        assert backend is not None

    def test_get_capability(self):
        """Test get_capability()."""
        from sagellm_backend.providers.ascend import (
            AscendBackendProvider,
        )

        backend = AscendBackendProvider(device_id=0)
        cap = backend.get_capability()

        assert cap.device_type == "npu"
        assert cap.total_memory_gb > 0
