"""ROCm/HIP Kernels for Hygon DCU and Muxi GPUs.

This package contains ROCm/HIP implementations of key LLM kernels:
- Attention kernels (flash attention, paged attention)
- GEMM kernels (hipBLAS/rocBLAS)
- Normalization kernels (LayerNorm, RMSNorm)
- Activation kernels (GELU, SiLU, etc.)

Architecture optimizations:
- Wavefront size 64 (AMD/DCU architecture)
- ROCm memory hierarchy (LDS, L2 cache)
- hipBLAS/rocBLAS for optimized matrix operations
"""

from __future__ import annotations

__all__ = [
    "rocm_attention",
    "rocm_gemm",
    "rocm_layernorm",
    "rocm_rmsnorm",
]
