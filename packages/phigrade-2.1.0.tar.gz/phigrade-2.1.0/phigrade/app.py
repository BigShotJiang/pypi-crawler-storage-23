"""
FastAPI app for phigrade local server
"""
import logging
import uuid
import os
import shutil
import tempfile
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple
from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel
from tinydb import TinyDB, Query
from phigrade.compare import calculate_score

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class SubmissionCreate(BaseModel):
    """Request model for creating submissions"""
    code_files: Dict[str, str]
    is_reference: bool


class SubmissionRead(BaseModel):
    """Response model for submissions"""
    id: str
    course_id: str
    assignment_id: str
    code_files: Dict[str, str]
    is_reference: bool
    is_active: bool


class UtestCreate(BaseModel):
    """Request model for creating utests"""
    module_name: str
    utest_name: str
    max_points: float = 1.0
    aggregation: str = "fail_fast"
    num_comparisons: int = 0


class UtestRead(BaseModel):
    """Response model for utests"""
    id: str
    assignment_id: str
    module_name: str
    utest_name: str
    max_points: float
    aggregation: str
    num_comparisons: int


class UtestAttemptCreate(BaseModel):
    """Request model for utest attempts"""
    module_name: str
    utest_name: str


class UtestAttemptRead(BaseModel):
    """Response model for utest attempts"""
    id: str
    submission_id: str
    utest_id: str
    aggregate_score: float
    is_correct: Optional[bool]


class UtestRefComparisonCreate(BaseModel):
    """Request model for reference comparisons"""
    module_name: str
    utest_name: str
    comparison_name: str
    reference_output: Any
    comparison_info: Dict[str, Any]
    points: float = 1.0
    weight: float = 1.0


class UtestStudentComparisonCreate(BaseModel):
    """Request model for student attempt comparisons"""
    module_name: str
    utest_name: str
    comparison_name: str
    student_output: Any


class UtestRefComparisonRead(BaseModel):
    """Response model for reference comparisons"""
    id: str
    course_id: str
    assignment_id: str
    module_name: str
    utest_name: str
    comparison_name: str
    reference_output: Any
    comparison_info: Dict[str, Any]
    points: float
    weight: float


class UtestStudentComparisonRead(BaseModel):
    """Response model for attempt comparison results"""
    id: str
    course_id: str
    assignment_id: str
    module_name: str
    utest_name: str
    comparison_name: str
    student_output: Any
    is_correct: bool
    score: float
    num_comparisons: int


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _setup_db(local_db_file: str, teacher_mode: bool) -> Tuple[TinyDB, str]:
    if not local_db_file:
        raise ValueError("local_db_file cannot be None or empty")

    db_dir = os.path.dirname(os.path.abspath(local_db_file))
    if not os.path.exists(db_dir):
        os.makedirs(db_dir, exist_ok=True)

    if teacher_mode:
        db = TinyDB(local_db_file, sort_keys=True, indent=4, separators=(',', ': '))
        db.drop_tables()
        return db, local_db_file

    # local_db_file file must be present with references in student mode
    if not os.path.exists(local_db_file):
        raise FileNotFoundError(f"local_db_file does not exist: {local_db_file}")

    tmp_file = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".json",
        prefix="phigrade_student_",
        delete=False,
    )
    tmp_path = tmp_file.name
    tmp_file.close()
    shutil.copy2(local_db_file, tmp_path)
    db = TinyDB(tmp_path, sort_keys=True, indent=4, separators=(',', ': '))
    return db, tmp_path


def create_app(local_db_file: str, teacher_mode: bool = True) -> FastAPI:
    """Create and configure the FastAPI app."""
    app = FastAPI(
        title="PhiGrade Local Server",
        description="Local development server for phigrade testing",
        version="1.0.0"
    )

    # Initialize database
    db, db_path = _setup_db(local_db_file, teacher_mode)
    references = db.table("references")
    submissions = db.table("submissions")
    utests = db.table("utests")
    utest_attempts = db.table("utest_attempts")
    student_comparisons = db.table("student_comparisons")
    app.state.db_path = db_path

    @app.get("/ping", response_model=dict)
    def ping() -> dict:
        """Health check endpoint"""
        return {"status": "success"}

    @app.post("/api/v1/courses/{course_id}/assignments/{assignment_id}/submissions", response_model=SubmissionRead)
    def create_submission(course_id: str, assignment_id: str, submission: SubmissionCreate) -> SubmissionRead:
        """Create a regular submission (non-reference)."""
        if submission.is_reference:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Reference submissions must use the reference submission endpoint"
            )

        submission_id = str(uuid.uuid4())

        submission_data = {
            "id": submission_id,
            "course_id": str(course_id),
            "assignment_id": str(assignment_id),
            "code_files": submission.code_files,
            "is_reference": submission.is_reference,
            "is_active": True,
            "created_at": _now_iso(),
            "updated_at": None,
        }

        submissions.insert(submission_data)
        return SubmissionRead(**submission_data)

    @app.post("/api/v1/courses/{course_id}/assignments/{assignment_id}/reference-submissions", response_model=SubmissionRead)
    def create_reference_submission(course_id: str, assignment_id: str, submission: SubmissionCreate) -> SubmissionRead:
        """Create a reference submission and deactivate all existing reference submissions for the assignment"""
        if not submission.is_reference:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This endpoint is only for reference submissions"
            )

        existing_refs = submissions.search(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().is_reference == True) &
            (Query().is_active == True)
        )
        for existing in existing_refs:
            submissions.update(
                {"is_active": False, "updated_at": _now_iso()},
                Query().id == existing["id"]
            )

        submission_id = str(uuid.uuid4())

        submission_data = {
            "id": submission_id,
            "course_id": str(course_id),
            "assignment_id": str(assignment_id),
            "code_files": submission.code_files,
            "is_reference": submission.is_reference,
            "is_active": True,
            "created_at": _now_iso(),
            "updated_at": None,
        }

        submissions.insert(submission_data)
        return SubmissionRead(**submission_data)

    @app.post("/api/v1/courses/{course_id}/assignments/{assignment_id}/utests", response_model=UtestRead)
    def create_utest(course_id: str, assignment_id: str, utest: UtestCreate) -> UtestRead:
        """Create a utest definition"""
        existing = utests.get(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().module_name == utest.module_name) &
            (Query().utest_name == utest.utest_name)
        )
        if existing:
            raise HTTPException(status_code=400, detail="Utest already exists")

        utest_id = str(uuid.uuid4())
        utest_data = {
            "id": utest_id,
            "course_id": str(course_id),
            "assignment_id": str(assignment_id),
            "module_name": utest.module_name,
            "utest_name": utest.utest_name,
            "max_points": utest.max_points,
            "aggregation": utest.aggregation,
            "num_comparisons": utest.num_comparisons,
            "created_at": _now_iso(),
            "updated_at": None,
        }
        utests.insert(utest_data)
        return UtestRead(**utest_data)

    @app.get("/api/v1/courses/{course_id}/assignments/{assignment_id}/utests", response_model=list[UtestRead])
    def get_assignment_utests(course_id: str, assignment_id: str) -> list[UtestRead]:
        """Get all utests for an assignment"""
        utest_records = utests.search(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id))
        )
        return [UtestRead(**record) for record in utest_records]

    @app.post("/api/v1/courses/{course_id}/assignments/{assignment_id}/submissions/{submission_id}/utest-attempts", response_model=UtestAttemptRead)
    def create_utest_attempt(
        course_id: str,
        assignment_id: str,
        submission_id: str,
        attempt: UtestAttemptCreate,
    ) -> UtestAttemptRead:
        """Create a utest attempt for a submission."""
        utest = utests.get(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().module_name == attempt.module_name) &
            (Query().utest_name == attempt.utest_name)
        )
        if not utest:
            raise HTTPException(status_code=404, detail=f"Utest not found: course_id={course_id}, assignment={assignment_id}, module={attempt.module_name}, utest={attempt.utest_name}")

        submission = submissions.get(Query().id == str(submission_id))
        if not submission:
            raise HTTPException(status_code=404, detail="Submission not found")

        existing = utest_attempts.get(
            (Query().submission_id == str(submission_id)) &
            (Query().utest_id == utest["id"])
        )
        if existing:
            return UtestAttemptRead(**existing)

        attempt_id = str(uuid.uuid4())
        attempt_data = {
            "id": attempt_id,
            "submission_id": str(submission_id),
            "utest_id": utest["id"],
            "aggregate_score": 0.0,
            "is_correct": None,
            "submitted_at": _now_iso(),
        }
        utest_attempts.insert(attempt_data)
        return UtestAttemptRead(**attempt_data)

    def phigrade_compare(reference_data: dict, student_output: Any) -> float:
        """Compare student result against reference and calculate score"""
        return calculate_score(
            reference_output=reference_data["reference_output"],
            student_output=student_output,
            comparison_info=reference_data["comparison_info"],
            max_points=reference_data["points"]
        )

    @app.post("/api/v1/courses/{course_id}/assignments/{assignment_id}/submissions/{submission_id}/utest-attempts/{attempt_id}/ref-comparisons",
        response_model=UtestRefComparisonRead,
    )
    def submit_ref_comparison(
        course_id: str,
        assignment_id: str,
        submission_id: str,
        attempt_id: str,
        comparison: UtestRefComparisonCreate,
    ) -> UtestRefComparisonRead:
        """Submit a reference comparison."""
        submission = submissions.get(Query().id == str(submission_id))
        if not submission:
            raise HTTPException(status_code=404, detail="Submission not found")

        attempt = utest_attempts.get(
            (Query().id == str(attempt_id)) &
            (Query().submission_id == str(submission_id))
        )
        if not attempt:
            raise HTTPException(status_code=404, detail="Utest attempt not found")

        utest = utests.get(Query().id == attempt["utest_id"])
        if not utest:
            raise HTTPException(status_code=404, detail="Utest not found")
        if utest["module_name"] != comparison.module_name or utest["utest_name"] != comparison.utest_name:
            raise HTTPException(status_code=400, detail="Utest metadata does not match attempt")

        existing_reference = references.get(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().module_name == comparison.module_name) &
            (Query().utest_name == comparison.utest_name) &
            (Query().comparison_name == comparison.comparison_name)
        )
        if existing_reference:
            references.update(
                {
                    "reference_output": comparison.reference_output,
                    "comparison_info": comparison.comparison_info,
                    "points": comparison.points,
                    "weight": comparison.weight,
                    "submission_id": str(submission_id),
                    "updated_at": _now_iso(),
                },
                Query().id == existing_reference["id"],
            )
            reference_data = references.get(Query().id == existing_reference["id"])
        else:
            reference_data = {
                "id": str(uuid.uuid4()),
                "course_id": str(course_id),
                "assignment_id": str(assignment_id),
                "module_name": comparison.module_name,
                "utest_name": comparison.utest_name,
                "comparison_name": comparison.comparison_name,
                "reference_output": comparison.reference_output,
                "comparison_info": comparison.comparison_info,
                "points": comparison.points,
                "weight": comparison.weight,
                "submission_id": str(submission_id),
                "created_at": _now_iso(),
                "updated_at": None,
            }
            references.insert(reference_data)

        # Update num_comparisons on the utest to reflect the current count
        comparison_count = len(references.search(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().module_name == comparison.module_name) &
            (Query().utest_name == comparison.utest_name)
        ))
        utests.update(
            {"num_comparisons": comparison_count, "updated_at": _now_iso()},
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().module_name == comparison.module_name) &
            (Query().utest_name == comparison.utest_name)
        )

        return UtestRefComparisonRead(**reference_data)

    @app.post("/api/v1/courses/{course_id}/assignments/{assignment_id}/submissions/{submission_id}/utest-attempts/{attempt_id}/student-comparisons",
        response_model=UtestStudentComparisonRead,
    )
    def submit_student_comparison(
        course_id: str,
        assignment_id: str,
        submission_id: str,
        attempt_id: str,
        comparison: UtestStudentComparisonCreate,
    ) -> UtestStudentComparisonRead:
        """Submit a student comparison."""
        # For student comparisons, we don't require stored submissions/attempts
        # Just validate that the utest exists
        utest = utests.get(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().module_name == comparison.module_name) &
            (Query().utest_name == comparison.utest_name)
        )
        if not utest:
            raise HTTPException(status_code=404, detail="Utest not found")

        stored_reference = references.get(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().module_name == comparison.module_name) &
            (Query().utest_name == comparison.utest_name) &
            (Query().comparison_name == comparison.comparison_name)
        )

        if not stored_reference:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    "Reference comparison not found: "
                    f"assignment={assignment_id}, module={comparison.module_name}, "
                    f"utest={comparison.utest_name}, comparison={comparison.comparison_name}"
                )
            )

        score = phigrade_compare(stored_reference, comparison.student_output)
        is_correct = (score == stored_reference["points"])

        attempt = utest_attempts.get(Query().id == str(attempt_id))
        if not attempt:
            raise HTTPException(status_code=404, detail="Utest attempt not found")
        if attempt["submission_id"] != str(submission_id):
            raise HTTPException(status_code=404, detail="Utest attempt not found")

        existing_student = student_comparisons.get(
            (Query().utest_attempt_id == str(attempt_id)) &
            (Query().utest_ref_comparison_id == stored_reference["id"])
        )
        if existing_student:
            student_comparisons.update(
                {
                    "student_output": comparison.student_output,
                    "is_correct": is_correct,
                    "score": score,
                    "updated_at": _now_iso(),
                },
                Query().id == existing_student["id"],
            )
            student_record = student_comparisons.get(Query().id == existing_student["id"])
        else:
            student_record = {
                "id": str(uuid.uuid4()),
                "course_id": str(course_id),
                "assignment_id": str(assignment_id),
                "module_name": comparison.module_name,
                "utest_name": comparison.utest_name,
                "comparison_name": comparison.comparison_name,
                "utest_attempt_id": str(attempt_id),
                "utest_ref_comparison_id": stored_reference["id"],
                "student_output": comparison.student_output,
                "is_correct": is_correct,
                "score": score,
                "created_at": _now_iso(),
                "updated_at": None,
            }
            student_comparisons.insert(student_record)

        all_comparisons = student_comparisons.search(
            Query().utest_attempt_id == str(attempt_id)
        )
        if utest["aggregation"] == "fail_fast":
            attempt_score = min(comp["score"] for comp in all_comparisons)
            attempt_correct = all(comp.get("is_correct") for comp in all_comparisons)
        elif utest["aggregation"] == "even_weight":
            attempt_score = sum(comp["score"] for comp in all_comparisons) / len(all_comparisons)
            attempt_correct = (attempt_score == utest["max_points"])
        elif utest["aggregation"] == "weighted":
            total_weighted_score = 0.0
            total_weight = 0.0
            for comp in all_comparisons:
                ref_comp = references.get(Query().id == comp["utest_ref_comparison_id"])
                if not ref_comp:
                    continue
                total_weighted_score += comp["score"] * ref_comp["weight"]
                total_weight += ref_comp["weight"]
            attempt_score = total_weighted_score / total_weight if total_weight > 0 else 0.0
            attempt_correct = (attempt_score == utest["max_points"])
        else:
            attempt_score = sum(comp["score"] for comp in all_comparisons)
            attempt_correct = None

        utest_attempts.update(
            {
                "aggregate_score": attempt_score,
                "is_correct": attempt_correct,
            },
            Query().id == str(attempt_id),
        )

        response_data = {
            "id": student_record["id"],
            "course_id": str(course_id),
            "assignment_id": str(assignment_id),
            "module_name": comparison.module_name,
            "utest_name": comparison.utest_name,
            "comparison_name": comparison.comparison_name,
            "student_output": student_record["student_output"],
            "is_correct": student_record["is_correct"],
            "score": student_record["score"],
            "num_comparisons": utest["num_comparisons"],
            "utest_attempt_id": student_record["utest_attempt_id"],
            "utest_ref_comparison_id": student_record["utest_ref_comparison_id"],
        }

        return UtestStudentComparisonRead(**response_data)

    @app.get("/api/v1/courses/{course_id}/assignments/{assignment_id}/utest-attempts/my", response_model=list[dict])
    def get_my_assignment_attempts(course_id: str, assignment_id: str) -> list[dict]:
        """Get the current user's utest attempts for a specific assignment with comparisons"""
        active_submissions = submissions.search(
            (Query().course_id == str(course_id)) &
            (Query().assignment_id == str(assignment_id)) &
            (Query().is_reference == False) &
            (Query().is_active == True)
        )
        if not active_submissions:
            return []

        active_submission = sorted(
            active_submissions,
            key=lambda record: record.get("created_at", ""),
            reverse=True,
        )[0]

        attempts = utest_attempts.search(
            Query().submission_id == active_submission["id"]
        )

        attempts_with_comparisons = []
        for attempt in attempts:
            utest = utests.get(Query().id == attempt["utest_id"])
            if not utest:
                continue

            comparisons = student_comparisons.search(
                Query().utest_attempt_id == attempt["id"]
            )

            attempt_with_comparisons = {
                "id": str(attempt["id"]),
                "utest_id": str(attempt["utest_id"]),
                "submission_id": attempt["submission_id"],
                "aggregate_score": attempt["aggregate_score"],
                "is_correct": attempt["is_correct"],
                "submitted_at": attempt.get("submitted_at"),
                "comparisons": [
                    {
                        "id": str(comp["id"]),
                        "utest_attempt_id": str(comp["utest_attempt_id"]),
                        "utest_ref_comparison_id": str(comp["utest_ref_comparison_id"]),
                        "student_output": comp["student_output"],
                        "score": comp["score"],
                        "is_correct": comp["is_correct"],
                        "created_at": comp.get("created_at"),
                        "updated_at": comp.get("updated_at"),
                    }
                    for comp in comparisons
                ],
                "utest": {
                    "id": str(utest["id"]),
                    "assignment_id": str(utest["assignment_id"]),
                    "module_name": utest["module_name"],
                    "utest_name": utest["utest_name"],
                    "max_points": utest["max_points"],
                    "aggregation": utest["aggregation"],
                    "num_comparisons": utest["num_comparisons"],
                    "created_at": utest.get("created_at"),
                    "updated_at": utest.get("updated_at"),
                },
            }
            attempts_with_comparisons.append(attempt_with_comparisons)

        return attempts_with_comparisons

    return app


if __name__ == "__main__":
    import uvicorn
    app = create_app(local_db_file="phigrade_db.json", teacher_mode=True)
    uvicorn.run(app, host="0.0.0.0", port=8765)
