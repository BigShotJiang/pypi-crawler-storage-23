# Import version from package metadata
try:
    from importlib.metadata import version, PackageNotFoundError
    try:
        __version__ = version("phigrade")
    except PackageNotFoundError:
        # Fallback for development environments where package isn't installed
        __version__ = "0.0.0-dev"
except ImportError:
    # Fallback for Python < 3.8 (though we require 3.12+)
    __version__ = "0.0.0-dev"

# Import all functions from phigrade module
from .phigrade import (
    weight,
    phigrade_allclose,
    phigrade_isequal,
    PhiGradeConfig,
    load_phigrade_config,
)

# Make everything available at package level
__all__ = [
    '__version__',
    'weight',
    'phigrade_allclose',
    'phigrade_isequal',
    'PhiGradeConfig',
    'load_phigrade_config',
]