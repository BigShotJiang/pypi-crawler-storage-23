"""Agent Zero tool modules for DomiNode.

Each module in this package follows Agent Zero's numeric-prefix convention:

- ``01_proxy_fetch`` -- Proxied HTTP fetch, proxy config, active sessions
- ``02_wallet`` -- Balance check, usage stats, PayPal top-up
- ``03_agentic_wallets`` -- Sub-wallet CRUD, funding, freeze/unfreeze
- ``04_teams`` -- Team CRUD, funding, API keys, member management
"""
