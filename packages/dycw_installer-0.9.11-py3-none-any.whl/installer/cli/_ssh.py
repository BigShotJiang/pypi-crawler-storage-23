from __future__ import annotations

from typing import TYPE_CHECKING

from click import Command, command
from utilities.click import CONTEXT_SETTINGS, Str, argument, flag
from utilities.core import is_pytest, set_up_logging

from installer import __version__
from installer._click import (
    home_option,
    permit_root_login_option,
    retry_option,
    root_option,
    ssh_option,
    sudo_option,
)
from installer._ssh import set_up_authorized_keys, set_up_ssh_config, set_up_sshd_config

if TYPE_CHECKING:
    from collections.abc import Callable

    from utilities.types import PathLike, Retry

    from installer._types import SSH


def make_keys_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @argument("keys", type=Str(), nargs=-1)
    @home_option
    @ssh_option
    @sudo_option
    @flag("--batch-mode", default=None, help="SSH batch mode")
    @retry_option
    def func(
        *,
        keys: tuple[str, ...],
        home: PathLike | None,
        ssh: SSH | None,
        sudo: bool,
        batch_mode: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_authorized_keys(
            list(keys),
            home=home,
            ssh=ssh,
            sudo=sudo,
            batch_mode=batch_mode,
            retry=retry,
        )

    return cli(name=name, help="Set up authorized keys", **CONTEXT_SETTINGS)(func)


def make_ssh_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @home_option
    @ssh_option
    @sudo_option
    @retry_option
    def func(
        *, home: PathLike | None, ssh: SSH | None, sudo: bool, retry: Retry | None
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_ssh_config(home=home, ssh=ssh, sudo=sudo, retry=retry)

    return cli(name=name, help="Set up SSH config", **CONTEXT_SETTINGS)(func)


def make_sshd_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @permit_root_login_option
    @root_option
    @ssh_option
    @sudo_option
    @retry_option
    def func(
        *,
        permit_root_login: bool,
        root: PathLike,
        ssh: SSH | None,
        sudo: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_sshd_config(
            permit_root_login=permit_root_login,
            root=root,
            ssh=ssh,
            sudo=sudo,
            retry=retry,
        )

    return cli(name=name, help="Set up SSHD config", **CONTEXT_SETTINGS)(func)


__all__ = ["make_keys_cmd", "make_ssh_cmd", "make_sshd_cmd"]
