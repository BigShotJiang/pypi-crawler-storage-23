from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import utilities.subprocess
from utilities.core import always_iterable, to_logger, write_text
from utilities.subprocess import HOST_KEY_ALGORITHMS, cp, ssh_keyscan

from installer._constants import GIT_CLONE_HOST, GIT_CLONE_USER
from installer._ssh import set_up_ssh_config
from installer._utilities import get_home

if TYPE_CHECKING:
    from collections.abc import Iterator

    from utilities.types import PathLike, Retry


_LOGGER = to_logger(__name__)


##


def git_clone_deploy_key(
    key: PathLike,
    owner: str,
    repo: str,
    /,
    *,
    home: PathLike | None = None,
    user: str = GIT_CLONE_USER,
    host: str = GIT_CLONE_HOST,
    port: int | None = None,
    retry: Retry | None = None,
    dest: PathLike | None = None,
    branch: str | None = None,
) -> None:
    _LOGGER.info("Cloning repository...")
    set_up_ssh_config(home=home)
    _set_up_deploy_key(key, home=home)
    _set_up_ssh_conf(key, home=home, user=user, host=host, port=port)
    _set_up_known_hosts(  # last step
        host=host, home=home, retry=retry, port=port
    )
    stem = Path(key).stem
    utilities.subprocess.git_clone(
        f"{user}@{stem}:{owner}/{repo}", path=dest, branch=branch
    )


def _set_up_deploy_key(path: PathLike, /, *, home: PathLike | None = None) -> None:
    _LOGGER.info("Setting up deploy key...")
    dest = _get_path_deploy_key(path, home=home)
    cp(path, dest, perms="u=rw,g=,o=")


def _get_path_deploy_key(path: PathLike, /, *, home: PathLike | None = None) -> Path:
    stem = Path(path).stem
    return get_home(home=home) / ".ssh/deploy-keys" / stem


def _set_up_known_hosts(
    *,
    host: str = GIT_CLONE_HOST,
    home: PathLike | None = None,
    retry: Retry | None = None,
    port: int | None = None,
) -> None:
    _LOGGER.info("Setting up known hosts...")
    path = get_home(home=home) / ".ssh/known_hosts"
    ssh_keyscan(host, path=path, retry=retry, port=port)


def _set_up_ssh_conf(
    path: PathLike,
    /,
    *,
    home: PathLike | None = None,
    user: str = GIT_CLONE_USER,
    host: str = GIT_CLONE_HOST,
    port: int | None = None,
) -> None:
    _LOGGER.info("Setting up SSH conf...")
    config = _get_path_conf(path, home=home)
    text = "\n".join(
        _yield_conf_lines(path, user=user, home=home, host=host, port=port)
    )
    write_text(config, text, overwrite=True)


def _get_path_conf(path: PathLike, /, *, home: PathLike | None = None) -> Path:
    stem = Path(path).stem
    return get_home(home=home) / f".ssh/config.d/{stem}.conf"


def _yield_conf_lines(
    path: PathLike,
    /,
    *,
    user: str = GIT_CLONE_USER,
    host: str = GIT_CLONE_HOST,
    port: int | None = None,
    home: PathLike | None = None,
) -> Iterator[str]:
    stem = Path(path).stem
    yield f"Host {stem}"
    lines = _yield_conf_lines_core(path, user=user, host=host, port=port, home=home)
    for line in lines:
        yield f"    {line}"


def _yield_conf_lines_core(
    path: PathLike,
    /,
    *,
    user: str = GIT_CLONE_USER,
    host: str = GIT_CLONE_HOST,
    port: int | None = None,
    home: PathLike | None = None,
) -> Iterator[str]:
    yield f"User {user}"
    yield f"HostName {host}"
    if port is not None:
        yield f"Port {port}"
    yield f"IdentityFile {_get_path_deploy_key(path, home=home)}"
    yield "IdentitiesOnly yes"
    yield "BatchMode yes"
    yield f"HostKeyAlgorithms {','.join(always_iterable(HOST_KEY_ALGORITHMS))}"
    yield "StrictHostKeyChecking yes"


__all__ = ["git_clone_deploy_key"]
