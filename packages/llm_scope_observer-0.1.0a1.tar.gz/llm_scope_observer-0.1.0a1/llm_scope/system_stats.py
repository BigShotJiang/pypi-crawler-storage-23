from typing import Dict

import psutil

try:
    from pynvml import (
        nvmlDeviceGetHandleByIndex,
        nvmlDeviceGetUtilizationRates,
        nvmlInit,
        nvmlShutdown,
    )

    GPU_AVAILABLE = True
except Exception:
    GPU_AVAILABLE = False


def get_system_stats() -> Dict[str, float]:
    stats: Dict[str, float] = {
        "cpu_percent": float(psutil.cpu_percent()),
        "memory_percent": float(psutil.virtual_memory().percent),
    }

    if GPU_AVAILABLE:
        stats.update(get_gpu_stats())

    return stats


def get_gpu_stats() -> Dict[str, float]:
    if not GPU_AVAILABLE:
        return {}

    nvmlInit()

    try:
        handle = nvmlDeviceGetHandleByIndex(0)
        util = nvmlDeviceGetUtilizationRates(handle)
        return {"gpu_percent": float(util.gpu)}
    finally:
        nvmlShutdown()

