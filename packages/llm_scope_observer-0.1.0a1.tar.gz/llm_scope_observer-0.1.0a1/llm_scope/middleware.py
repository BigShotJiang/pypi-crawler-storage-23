import functools
import inspect
import time
from typing import Any, Callable, Dict, Optional

from .metrics import collect_metrics
from .storage import save_record


def _extract_prompt(args: tuple, kwargs: dict, prompt_key: str) -> str:
    if prompt_key in kwargs:
        value = kwargs[prompt_key]
        return "" if value is None else str(value)
    if args:
        value = args[0]
        return "" if value is None else str(value)
    return ""


def monitor(model: str, prompt_arg: str = "prompt", tags: Optional[Dict[str, Any]] = None) -> Callable:
    def decorator(func: Callable) -> Callable:
        is_async = inspect.iscoroutinefunction(func)

        if not is_async:

            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                start = time.time()
                prompt = _extract_prompt(args, kwargs, prompt_arg)

                try:
                    response = func(*args, **kwargs)
                    error = None
                except Exception as exc:
                    response = None
                    error = str(exc)
                    end = time.time()
                    record = collect_metrics(
                        model=model,
                        prompt=prompt,
                        response=response,
                        start=start,
                        end=end,
                        error=error,
                        tags=tags,
                    )
                    save_record(record)
                    raise

                end = time.time()
                record = collect_metrics(
                    model=model,
                    prompt=prompt,
                    response=response,
                    start=start,
                    end=end,
                    error=error,
                    tags=tags,
                )
                save_record(record)

                return response

            return wrapper

        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.time()
            prompt = _extract_prompt(args, kwargs, prompt_arg)

            try:
                response = await func(*args, **kwargs)
                error = None
            except Exception as exc:
                response = None
                error = str(exc)
                end = time.time()
                record = collect_metrics(
                    model=model,
                    prompt=prompt,
                    response=response,
                    start=start,
                    end=end,
                    error=error,
                    tags=tags,
                )
                save_record(record)
                raise

            end = time.time()
            record = collect_metrics(
                model=model,
                prompt=prompt,
                response=response,
                start=start,
                end=end,
                error=error,
                tags=tags,
            )
            save_record(record)

            return response

        return functools.wraps(func)(async_wrapper)

    return decorator

