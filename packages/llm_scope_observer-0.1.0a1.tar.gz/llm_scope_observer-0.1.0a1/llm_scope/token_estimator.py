from typing import Any, Dict, Optional


def estimate_tokens(prompt: Optional[str], response: Any, model: Optional[str] = None) -> Dict[str, int]:
    prompt_text = prompt or ""
    response_text = "" if response is None else str(response)

    input_tokens = _estimate_text_tokens(prompt_text, model)
    output_tokens = _estimate_text_tokens(response_text, model)

    return {
        "input": input_tokens,
        "output": output_tokens,
        "total": input_tokens + output_tokens,
    }


def _estimate_text_tokens(text: str, model: Optional[str] = None) -> int:
    if not text:
        return 0

    avg_chars_per_token = 4
    return max(1, len(text) // avg_chars_per_token)

