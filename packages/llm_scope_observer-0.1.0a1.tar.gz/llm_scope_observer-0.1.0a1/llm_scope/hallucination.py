from typing import Optional


def hallucination_score(prompt: Optional[str], response: Optional[str]) -> float:
    prompt_text = prompt or ""
    response_text = response or ""

    if not response_text:
        return 0.0

    score = 0.0

    if len(response_text) > 2000 and len(prompt_text) < 200:
        score += 0.3

    if _has_strong_claims_without_references(response_text):
        score += 0.3

    if _has_repetition(response_text):
        score += 0.2

    if _has_self_contradiction(response_text):
        score += 0.2

    if score < 0.0:
        return 0.0

    if score > 1.0:
        return 1.0

    return score


def _has_strong_claims_without_references(text: str) -> bool:
    lowered = text.lower()
    markers = ["always", "never", "guaranteed", "proven", "undeniable"]
    has_marker = any(marker in lowered for marker in markers)
    has_reference = "http://" in lowered or "https://" in lowered or "[[" in lowered
    return has_marker and not has_reference


def _has_repetition(text: str) -> bool:
    words = text.split()
    if len(words) < 50:
        return False

    window = set(words[:50])
    rest = words[50:]
    repeated = sum(1 for word in rest if word in window)

    return repeated > len(rest) * 0.4


def _has_self_contradiction(text: str) -> bool:
    lowered = text.lower()
    patterns = [
        "however, this is not correct",
        "on the other hand, this is wrong",
        "previously i said",
    ]
    return any(pattern in lowered for pattern in patterns)

