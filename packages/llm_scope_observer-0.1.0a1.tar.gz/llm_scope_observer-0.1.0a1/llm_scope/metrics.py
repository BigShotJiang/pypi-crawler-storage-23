from typing import Any, Dict, Optional

from .hallucination import hallucination_score
from .system_stats import get_system_stats
from .token_estimator import estimate_tokens


def collect_metrics(
    model: str,
    prompt: Optional[str],
    response: Any,
    start: float,
    end: float,
    error: Optional[str] = None,
    tags: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    duration = end - start
    tokens = estimate_tokens(prompt, response, model=model)
    system = get_system_stats()

    prompt_text = prompt or ""
    response_text = "" if response is None else str(response)

    hallucination = hallucination_score(prompt_text, response_text)

    total_tokens = tokens["total"]
    tokens_per_second = total_tokens / duration if duration > 0 else None

    record: Dict[str, Any] = {
        "model": model,
        "prompt_hash": _hash_prompt(prompt_text),
        "duration": duration,
        "input_tokens": tokens["input"],
        "output_tokens": tokens["output"],
        "total_tokens": total_tokens,
        "tokens_per_second": tokens_per_second,
        "cpu_percent": system.get("cpu_percent"),
        "memory_percent": system.get("memory_percent"),
        "gpu_percent": system.get("gpu_percent"),
        "hallucination_score": hallucination,
        "error": error,
        "tags": tags or {},
    }

    return record


def _hash_prompt(prompt: str) -> str:
    import hashlib

    data = prompt.encode("utf-8")
    return hashlib.sha256(data).hexdigest()

