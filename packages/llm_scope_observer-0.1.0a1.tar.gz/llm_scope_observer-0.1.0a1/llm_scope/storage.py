import json
import os
import sqlite3
import time
from contextlib import contextmanager
from typing import Any, Dict, Iterable, List, Tuple

DB_PATH = os.getenv("LLM_SCOPE_DB_PATH", "llm_scope.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS llm_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    model TEXT,
    prompt_hash TEXT,
    duration REAL,
    input_tokens INTEGER,
    output_tokens INTEGER,
    total_tokens INTEGER,
    tokens_per_second REAL,
    cpu_percent REAL,
    memory_percent REAL,
    gpu_percent REAL,
    hallucination_score REAL,
    error TEXT,
    tags TEXT
);
"""


def init_db() -> None:
    with _get_conn() as conn:
        conn.execute(SCHEMA)
        conn.commit()


@contextmanager
def _get_conn():
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
    finally:
        conn.close()


def save_record(record: Dict[str, Any]) -> None:
    init_db()
    ts = time.time()
    tags = json.dumps(record.get("tags") or {})

    values: Tuple[Any, ...] = (
        ts,
        record.get("model"),
        record.get("prompt_hash"),
        record.get("duration"),
        record.get("input_tokens"),
        record.get("output_tokens"),
        record.get("total_tokens"),
        record.get("tokens_per_second"),
        record.get("cpu_percent"),
        record.get("memory_percent"),
        record.get("gpu_percent"),
        record.get("hallucination_score"),
        record.get("error"),
        tags,
    )

    with _get_conn() as conn:
        conn.execute(
            """
            INSERT INTO llm_calls (
                ts,
                model,
                prompt_hash,
                duration,
                input_tokens,
                output_tokens,
                total_tokens,
                tokens_per_second,
                cpu_percent,
                memory_percent,
                gpu_percent,
                hallucination_score,
                error,
                tags
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            values,
        )
        conn.commit()


def fetch_summary() -> List[Dict[str, Any]]:
    init_db()
    query = """
    SELECT
        model,
        COUNT(*) as count,
        AVG(duration) as avg_duration,
        AVG(total_tokens) as avg_total_tokens,
        AVG(tokens_per_second) as avg_tokens_per_second,
        AVG(cpu_percent) as avg_cpu_percent,
        AVG(memory_percent) as avg_memory_percent,
        AVG(gpu_percent) as avg_gpu_percent,
        AVG(hallucination_score) as avg_hallucination_score,
        SUM(CASE WHEN error IS NOT NULL THEN 1 ELSE 0 END) as error_count
    FROM llm_calls
    GROUP BY model
    ORDER BY avg_duration DESC
    """

    with _get_conn() as conn:
        cursor = conn.execute(query)
        columns = [column[0] for column in cursor.description]
        rows = cursor.fetchall()

    return [dict(zip(columns, row)) for row in rows]


def fetch_slowest(limit: int = 20) -> List[Dict[str, Any]]:
    init_db()
    query = """
    SELECT
        ts,
        model,
        duration,
        total_tokens,
        tokens_per_second,
        cpu_percent,
        memory_percent,
        gpu_percent,
        hallucination_score,
        error
    FROM llm_calls
    ORDER BY duration DESC
    LIMIT ?
    """

    with _get_conn() as conn:
        cursor = conn.execute(query, (limit,))
        columns = [column[0] for column in cursor.description]
        rows = cursor.fetchall()

    return [dict(zip(columns, row)) for row in rows]

