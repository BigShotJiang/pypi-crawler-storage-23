from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import uvicorn

from ..storage import fetch_summary, fetch_slowest


BASE_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = BASE_DIR / "templates"

app = FastAPI()
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@app.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    summary = fetch_summary()
    slowest = fetch_slowest()
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "summary": summary,
            "slowest": slowest,
        },
    )


def run(host: str = "127.0.0.1", port: int = 8000) -> None:
    uvicorn.run("llm_scope.dashboard.app:app", host=host, port=port, reload=False)


if __name__ == "__main__":
    run()

