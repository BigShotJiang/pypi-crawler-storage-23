import argparse

from .dashboard.app import run as run_dashboard


def main() -> None:
    parser = argparse.ArgumentParser(prog="llm-scope")
    subparsers = parser.add_subparsers(dest="command")

    ui_parser = subparsers.add_parser("ui")
    ui_parser.add_argument("--host", default="127.0.0.1")
    ui_parser.add_argument("--port", type=int, default=8000)

    args = parser.parse_args()

    if args.command == "ui":
        run_dashboard(host=args.host, port=args.port)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
