=======
History
=======

0.1.0 (2023-09-04)
------------------

* First release on PyPI.
