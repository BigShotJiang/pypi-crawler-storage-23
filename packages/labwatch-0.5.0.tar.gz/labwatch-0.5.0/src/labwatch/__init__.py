"""labwatch - General-purpose homelab monitoring CLI."""

__version__ = "0.5.0"
