"""Caching utilities for the Plotmon application."""
