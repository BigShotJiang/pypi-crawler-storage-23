"""Plot monitoring visualization modules."""
