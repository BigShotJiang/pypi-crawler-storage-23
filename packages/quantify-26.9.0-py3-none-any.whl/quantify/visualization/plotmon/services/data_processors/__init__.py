"""Data processing services for the Plotmon application."""
