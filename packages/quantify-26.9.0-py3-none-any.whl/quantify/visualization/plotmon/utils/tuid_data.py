# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""
A module defining the TuidData class for
managing TUID-related data in the Plotmon application.
"""

from bokeh.core.types import ID
from pydantic import BaseModel


class TuidData(BaseModel):
    """
    A container for TUID related data in the Plotmon application.
    """

    tuids: set[str]
    active_tuid: str
    selected_tuid: dict[ID | int, str]
    session_id: ID | int = -1  # Default session ID for non-session-specific data
