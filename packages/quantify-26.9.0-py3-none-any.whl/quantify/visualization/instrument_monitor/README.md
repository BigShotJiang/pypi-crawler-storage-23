# Instrument Monitor

Bokeh dashboard for live monitoring of QCoDeS instruments and parameters.

## Runtime Summary

- `launch_instrument_monitor()` starts a Bokeh server in a background thread.
- `InstrumentMonitorApp` wires UI + ingestion and refreshes UI every ~333 ms.
- `SnapshotPoller` performs warmup snapshot passes, then callback-driven deltas.
- `StateStore` is the thread-safe source of current readings + recent changes.
- UI includes current-state table, hierarchy tree, and parameter edit logs.

## Public API

```python
from quantify.visualization.instrument_monitor import launch_instrument_monitor

handle = launch_instrument_monitor(
    host="localhost",
    port=None,
    log_level="INFO",
)

print(handle.url)
handle.stop()
```

Streaming-only (no UI):

```python
from quantify.visualization.instrument_monitor import start_instrument_monitor_stream


def on_update(update):
    # update.mode: "snapshot" | "delta"
    # update.readings / update.change_events / update.current_state()
    pass


stream = start_instrument_monitor_stream(on_update)
stream.stop()
```

## Module Map

- `server.py`: Bokeh server lifecycle (`MonitorHandle`, launcher)
- `app.py`: UI + ingestion wiring, periodic update gating
- `discovery.py`: QCoDeS discovery + state delegation
- `poller.py`: warmup snapshots + callback queue draining
- `callbacks.py`: global QCoDeS on-set callback bridge
- `state_store.py`: thread-safe readings/change-event store
- `snapshot_parser.py`: snapshot -> `Reading` transformation
- `parameter_setter.py`: resolve/set parameter values from UI input
- `ui.py`, `ui_layout.py`, `ui_js.py`: UI behavior/layout/client listeners
- `components/`: table/tree/log/theme helpers

## Design Constraints

- Keep ingestion overhead low after warmup.
- Keep UI responsive during typing/scrolling.
- Preserve both parameter identities:
  - display: `instrument.submodule.parameter`
  - canonical: `instrument_submodule_parameter`

## Documentation

- User docs: `docs/source/howto/instrument-monitor/index.md`
- Deep architecture: `docs/source/howto/instrument-monitor/technical-architecture.md`
