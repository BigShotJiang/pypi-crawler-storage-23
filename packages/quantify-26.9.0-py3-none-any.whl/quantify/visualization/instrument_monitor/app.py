# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Bokeh application for instrument monitoring."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from bokeh.application import Application
from bokeh.application.handlers import FunctionHandler

from quantify.visualization.instrument_monitor.discovery import InstrumentDiscovery
from quantify.visualization.instrument_monitor.logging_setup import get_logger
from quantify.visualization.instrument_monitor.parameter_setter import (
    set_parameter_from_text,
)
from quantify.visualization.instrument_monitor.poller import SnapshotPoller
from quantify.visualization.instrument_monitor.ui import InstrumentMonitorUI
from quantify.visualization.instrument_monitor.utils import safe_value_format

if TYPE_CHECKING:
    from bokeh.document import Document

    from quantify.visualization.instrument_monitor.config import IngestionConfig
    from quantify.visualization.instrument_monitor.models import Reading

logger = get_logger(__name__)


def _format_user_error_message(exc: Exception) -> str:
    """Build a concise, user-facing error message from an exception.

    Keep the exception type while dropping low-level QCoDeS context suffixes
    like ``; Parameter: ...`` that add noise in the inline UI feedback.
    """
    exc_name = type(exc).__name__
    detail = ""
    args = getattr(exc, "args", ())
    if args:
        first = args[0]
        detail = first if isinstance(first, str) else str(first)
    if not detail:
        detail = str(exc).strip()
    if not detail:
        return exc_name

    for marker in ("; Parameter:", "\nParameter:"):
        if marker in detail:
            detail = detail.split(marker, 1)[0].strip()
            break

    if detail.startswith(f"{exc_name}:"):
        return detail
    return f"{exc_name}: {detail}"


class InstrumentMonitorApp:
    """Instrument monitor with dependency-injected discovery and poller.

    This allows swapping out real components with fakes in tests, while keeping
    the UI logic independent from ingestion details.
    """

    def __init__(
        self,
        config: IngestionConfig | None = None,
        *,
        discovery: InstrumentDiscovery | None = None,
        poller: SnapshotPoller | None = None,
        start_poller: bool = True,
    ) -> None:
        """Initialize instrument monitor application.

        Parameters
        ----------
        config
            Optional ingestion configuration used when constructing the default
            poller. Ignored if a custom ``poller`` is provided.
        discovery
            Optional discovery port implementation. Defaults to the built-in
            QCoDeS-backed discovery.
        poller
            Optional snapshot poller port implementation. Defaults to the
            built-in snapshot poller when not provided.
        start_poller
            When ``True`` (default) start the provided or default poller.
            Set to ``False`` to disable polling entirely, allowing data to be fed
            into the discovery externally via ``app.discovery.update_readings()``
            or ``app.discovery.direct_update_readings()``.

        """
        # Use None default to avoid mutable default argument pitfall
        self.discovery: InstrumentDiscovery = discovery or InstrumentDiscovery()
        self.poller: SnapshotPoller | None
        if poller is not None:
            self.poller = poller
        elif start_poller:
            self.poller = SnapshotPoller(
                self.discovery, poll_interval=0.5, config=config
            )
        else:
            self.poller = None
        self._poller_started = False
        self._should_start_poller = start_poller and self.poller is not None
        # Backward-compatible references to the latest created session models.
        # Do not use these for periodic updates because multiple sessions may exist.
        self.ui: InstrumentMonitorUI | None = None
        self.doc: Document | None = None

    def create_document(self, doc: Document) -> None:
        """Create and configure the Bokeh document."""
        logger.debug("Creating instrument monitor document")

        doc.title = "Quantify Instrument Monitor"

        # Create a fresh UI per session and keep session-local references in
        # callbacks to avoid cross-session document mutations.
        ui = InstrumentMonitorUI()
        ui.set_value_handler(self._set_parameter_from_ui)

        # Create layout
        layout = ui.create_layout()
        doc.add_root(layout)

        # Attach client-side listeners and tree toggle bridges via UI/components
        try:
            ui.attach_client_listeners(doc)
        except Exception:
            logger.warning("Failed to attach client listeners", exc_info=True)
        try:
            ui.snapshot_tree.bind_js(doc)
            ui.snapshot_tree.bind_python_toggle_handler()
        except Exception:
            logger.warning("Failed to bind tree events", exc_info=True)

        # Start background polling only once per server lifetime
        self._ensure_poller_started()

        # 333ms update interval for smooth performance
        doc.add_periodic_callback(
            lambda: self._periodic_update(ui=ui),
            period_milliseconds=333,
        )

        # Session cleanup
        doc.on_session_destroyed(
            lambda _: logger.debug("Session for instrument monitor ended")
        )

        # Expose latest references for compatibility/debugging only.
        self.doc = doc
        self.ui = ui

        logger.debug("Instrument monitor document created successfully")

    def _ensure_poller_started(self) -> None:
        """Start background polling only once per server lifetime."""
        if self.poller is None or not self._should_start_poller:
            return

        if not self._poller_started:
            self.poller.start()
            self._poller_started = True

    def _periodic_update(self, *, ui: InstrumentMonitorUI) -> None:
        """Gather data and apply UI updates in the periodic callback."""
        try:
            current_readings = self.discovery.get_current_state()
            self._apply_updates(ui, current_readings)
        except Exception as e:
            logger.error("UI update failed", extra={"error": str(e)}, exc_info=True)

    def _apply_updates(
        self,
        ui: InstrumentMonitorUI,
        current_readings: list[Reading],
    ) -> None:
        """Apply gated UI updates."""
        focused = False
        scrolling = False
        interaction_locked = False
        try:
            data = ui.ui_state.data
            if isinstance(data, dict):
                focused_list = data.get("filter_focused")
                if isinstance(focused_list, list) and focused_list:
                    focused = bool(focused_list[0])
                scrolling_list = data.get("table_scrolling")
                if isinstance(scrolling_list, list) and scrolling_list:
                    scrolling = bool(scrolling_list[0])
                deadline_list = data.get("interaction_deadline_ms")
                if isinstance(deadline_list, list) and deadline_list:
                    with_deadline = deadline_list[0]
                    if isinstance(with_deadline, (int, float)):
                        interaction_locked = (time.time() * 1000) < float(with_deadline)
        except Exception:
            focused = False
            scrolling = False
            interaction_locked = False

        if not (focused or scrolling or interaction_locked):
            try:
                ui.current_state_table.update_readings(current_readings)
            except Exception as e:
                logger.warning(
                    "Current state update failed",
                    extra={"error": str(e)},
                    exc_info=True,
                )

            try:
                ui.snapshot_tree.update_readings(current_readings)
            except Exception as e:
                logger.warning(
                    "Snapshot tree update failed",
                    extra={"error": str(e)},
                    exc_info=True,
                )

    def _set_parameter_from_ui(
        self, full_name: str, raw_value: str, current_value: object
    ) -> tuple[bool, str]:
        """Handle a UI value-set request for a selected parameter."""
        try:
            applied_value = set_parameter_from_text(
                full_name=full_name,
                raw_value=raw_value,
                current_value=current_value,
            )
            return True, f"Set '{full_name}' to {safe_value_format(applied_value)}."
        except Exception as e:
            logger.warning(
                "Failed to set parameter from UI",
                extra={"full_name": full_name, "error": str(e)},
                exc_info=True,
            )
            return False, _format_user_error_message(e)


def create_bokeh_app(
    config: IngestionConfig | None = None,
    *,
    discovery: InstrumentDiscovery | None = None,
    poller: SnapshotPoller | None = None,
) -> Application:
    """Create the Bokeh application with optional dependency injection."""
    monitor_app = InstrumentMonitorApp(
        config=config, discovery=discovery, poller=poller
    )
    handler = FunctionHandler(monitor_app.create_document)
    return Application(handler)


def create_instrument_monitor_app(config: IngestionConfig | None = None) -> Application:
    """Create the instrument monitor application (alias for compatibility)."""
    return create_bokeh_app(config)
