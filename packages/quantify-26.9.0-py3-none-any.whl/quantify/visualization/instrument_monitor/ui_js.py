# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Client-side JavaScript payloads for instrument monitor UI hooks."""

from __future__ import annotations


def instrument_monitor_ready_js() -> str:
    """Return the DocumentReady JS used for viewport fit and interaction tracking."""
    return """
                // Keep the monitor inside the available viewport.
                const fitViewport = () => {
                  const rootView = Bokeh.index[root_layout.id];
                  if (rootView && rootView.el) {
                    const h = Math.max(420, window.innerHeight - 12);
                    rootView.el.style.height = `${h}px`;
                    rootView.el.style.maxHeight = `${h}px`;
                    rootView.el.style.overflow = 'hidden';
                  }
                };
                fitViewport();
                window.addEventListener('resize', fitViewport);

                const setState = (updates) => {
                  const d = Object.assign({}, state.data);
                  Object.assign(d, updates);
                  state.data = d;
                };
                const setInteractionWindow = (ms = 900) => {
                  setState({ interaction_deadline_ms: [Date.now() + ms] });
                };
                const addListener = (el, eventName, handler, options = null) => {
                  if (!el) return;
                  try {
                    if (options === null) {
                      el.addEventListener(eventName, handler);
                    } else {
                      el.addEventListener(eventName, handler, options);
                    }
                  } catch (e) {
                    // Safari fallback for unsupported options objects.
                    try { el.addEventListener(eventName, handler); } catch (_e) {}
                  }
                };

                // Track focus on filter/value inputs and lock redraw briefly.
                const filterView = Bokeh.index[inp.id];
                const editView = Bokeh.index[edit_inp.id];
                const getFilterFocused = () =>
                  Boolean(filterView && filterView.input_el &&
                    document.activeElement === filterView.input_el);
                const getEditFocused = () =>
                  Boolean(editView && editView.input_el &&
                    document.activeElement === editView.input_el);
                const refreshFocused = () => {
                  setState({
                    filter_focused: [getFilterFocused() || getEditFocused()],
                  });
                };
                if (filterView && filterView.input_el) {
                  refreshFocused();
                  addListener(filterView.input_el, 'focus', () => {
                    setInteractionWindow(1200);
                    refreshFocused();
                  });
                  addListener(filterView.input_el, 'blur', () => {
                    setInteractionWindow(700);
                    setTimeout(refreshFocused, 0);
                  });
                  addListener(filterView.input_el, 'keydown', () => {
                    setInteractionWindow(1200);
                  });
                }
                if (editView && editView.input_el) {
                  refreshFocused();
                  addListener(editView.input_el, 'focus', () => {
                    setInteractionWindow(1200);
                    refreshFocused();
                  });
                  addListener(editView.input_el, 'blur', () => {
                    setInteractionWindow(700);
                    setTimeout(refreshFocused, 0);
                  });
                  addListener(editView.input_el, 'keydown', () => {
                    setInteractionWindow(1200);
                  });
                }

                const applyView = Bokeh.index[apply_btn.id];
                if (applyView && applyView.el) {
                  addListener(applyView.el, 'click', () => {
                    setInteractionWindow(1200);
                  });
                }

                // Track scrolling on the DataTable and gate redraw while scrolling.
                const tview = Bokeh.index[table.id];
                if (tview && tview.el) {
                  const viewport =
                    tview.el.querySelector('.slick-viewport') || tview.el;
                  const setScrolling = (v) => {
                    setState({ table_scrolling: [v] });
                  };
                  let scrollTimer = null;
                  const onScroll = () => {
                    setInteractionWindow(900);
                    setScrolling(true);
                    if (scrollTimer) clearTimeout(scrollTimer);
                    scrollTimer = setTimeout(() => setScrolling(false), 400);
                  };
                  const onInteract = () => setInteractionWindow(900);
                  addListener(viewport, 'wheel', onScroll, { passive: true });
                  addListener(viewport, 'scroll', onScroll, { passive: true });
                  addListener(viewport, 'touchmove', onScroll, { passive: true });
                  addListener(viewport, 'mousedown', onInteract);
                  addListener(viewport, 'click', onInteract);
                  addListener(viewport, 'touchstart', onInteract, { passive: true });
                  addListener(viewport, 'keydown', onInteract);
                }

                const findInRoot = (rootEl, selector) => {
                  if (!rootEl) return null;
                  try {
                    const found = rootEl.querySelector(selector);
                    if (found) return found;
                  } catch (_e) {}
                  const shadow = rootEl.shadowRoot;
                  if (shadow) {
                    try {
                      const found = shadow.querySelector(selector);
                      if (found) return found;
                    } catch (_e) {}
                  }
                  return null;
                };

                const resolveTreeElement = () => {
                  try {
                    const treeView = Bokeh.index[tree_rows.id];
                    if (treeView && treeView.el) return treeView.el;
                  } catch (_e) {}

                  try {
                    const rootView = Bokeh.index[root_layout.id];
                    if (rootView && rootView.el) {
                      const byModel = findInRoot(
                        rootView.el, `[data-model-id="${tree_rows.id}"]`
                      );
                      if (byModel) return byModel;
                      const byClass = findInRoot(rootView.el, '.tree-container');
                      if (byClass) return byClass;
                    }
                  } catch (_e) {}
                  return null;
                };

                const scrollFocusedTreeRow = (treeEl) => {
                  if (!treeEl) return;
                  const focused = treeEl.querySelector('.tree-item--focused');
                  if (!focused) return;
                  try {
                    focused.scrollIntoView({ block: 'nearest', inline: 'nearest' });
                  } catch (_e) {
                    try { focused.scrollIntoView(); } catch (__e) {}
                  }
                };

                const bindTreeInteractions = () => {
                  const treeEl = resolveTreeElement();
                  if (!treeEl) return false;

                  const onTreeInteract = () => setInteractionWindow(900);
                  if (!treeEl.__insmonInteractionBound) {
                    treeEl.__insmonInteractionBound = true;
                    addListener(treeEl, 'mousedown', onTreeInteract);
                    addListener(treeEl, 'click', onTreeInteract);
                    addListener(
                      treeEl, 'touchstart', onTreeInteract, { passive: true }
                    );
                  }

                  if (!treeEl.__insmonFocusObserver) {
                    const observer = new MutationObserver(() => {
                      scrollFocusedTreeRow(treeEl);
                    });
                    observer.observe(treeEl, { childList: true, subtree: true });
                    treeEl.__insmonFocusObserver = observer;
                  }
                  scrollFocusedTreeRow(treeEl);
                  return true;
                };

                // Lock redraw briefly while interacting with hierarchy explorer.
                if (!bindTreeInteractions()) {
                  let attempts = 0;
                  const retryTimer = setInterval(() => {
                    attempts += 1;
                    if (bindTreeInteractions() || attempts >= 20) {
                      clearInterval(retryTimer);
                    }
                  }, 250);
                }

                """
