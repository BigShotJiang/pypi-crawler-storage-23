# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Layout builders for the instrument monitor UI."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

from bokeh.layouts import column, row
from bokeh.models import Button, Div, TextInput

from quantify.visualization.instrument_monitor.components.theme import (
    STYLES,
    create_header,
    create_section_label,
)

CARD_STYLES = {
    **STYLES["card"],
    "display": "flex",
    "flex-direction": "column",
    "min-height": "0",
    "min-width": "0",
}

TABLE_CONTAINER_STYLES = {
    "position": "relative",
    "display": "flex",
    "flex-direction": "column",
    "flex": "1 1 auto",
    "min-height": "0",
    "overflow-y": "auto",
}

TREE_CONTAINER_STYLES = {
    "position": "relative",
    "display": "flex",
    "flex-direction": "column",
    "flex": "1 1 auto",
    "min-height": "0",
}

FLEX_COLUMN_STYLES = {
    "display": "flex",
    "flex-direction": "column",
    "min-height": "0",
    "min-width": "0",
}

ROOT_ROW_STYLES = {
    "overflow": "hidden",
    "box-sizing": "border-box",
    "padding": "4px",
}

INPUT_ACTION_ROW_STYLES = {
    "display": "flex",
    "gap": "8px",
    "align-items": "flex-start",
}


def create_filter_widgets(
    on_filter_change: Callable[[str, str, str], None],
    on_clear_filter: Callable[[], None],
) -> tuple[Div, TextInput, Button]:
    """Create filter label/input controls and attach callbacks."""
    filter_label = create_section_label("Filter (Instruments / Parameters)", "🔍")
    filter_input = TextInput(
        title="",
        value="",
        placeholder="Type to filter",
        sizing_mode="stretch_width",
    )
    filter_input.on_change("value", on_filter_change)
    clear_filter_button = Button(
        label="Clear",
        button_type="default",
        width=110,
        styles=STYLES["button_secondary"],
    )
    clear_filter_button.on_click(on_clear_filter)
    return filter_label, filter_input, clear_filter_button


def create_value_editor_widgets(
    on_apply_value: Callable[[], None],
) -> tuple[Div, Div, TextInput, Button, Div]:
    """Create selected parameter view and value editor controls."""
    selected_parameter = Div(
        text=(
            "<b>Selected:</b> "
            "<span style='color:#6b7280;'>Select a parameter row to edit.</span>"
        ),
        sizing_mode="stretch_width",
    )
    value_editor_label = create_section_label("Edit selected value", "✏️")
    value_input = TextInput(
        title="",
        value="",
        placeholder="Type a new value",
        sizing_mode="stretch_width",
    )
    apply_button = Button(
        label="Set Value",
        button_type="default",
        width=110,
        styles=STYLES["button_primary"],
    )
    apply_button.on_click(on_apply_value)
    edit_feedback = Div(text="", sizing_mode="stretch_width")
    return (
        selected_parameter,
        value_editor_label,
        value_input,
        apply_button,
        edit_feedback,
    )


def create_current_state_card(
    *,
    filter_label: Div,
    filter_input: TextInput,
    clear_filter_button: Button,
    selected_parameter: Div,
    value_editor_label: Div,
    value_input: TextInput,
    apply_button: Button,
    edit_feedback: Div,
    table_empty_message: Div,
    table_widget: Any,
) -> Any:
    """Build the current-state card with controls and table."""
    filter_row = row(
        filter_input,
        clear_filter_button,
        sizing_mode="stretch_width",
        styles=INPUT_ACTION_ROW_STYLES,
    )
    value_editor_row = row(
        value_input,
        apply_button,
        sizing_mode="stretch_width",
        styles=INPUT_ACTION_ROW_STYLES,
    )
    table_container = column(
        table_empty_message,
        table_widget,
        sizing_mode="stretch_both",
        styles=TABLE_CONTAINER_STYLES,
        min_height=240,
        height_policy="max",
    )
    return column(
        create_header("Current State of Instruments", "📊"),
        filter_label,
        filter_row,
        selected_parameter,
        value_editor_label,
        value_editor_row,
        edit_feedback,
        table_container,
        sizing_mode="stretch_both",
        styles=CARD_STYLES,
        min_height=360,
        height_policy="max",
    )


def create_tree_card(*, tree_empty_message: Div, tree_wrapper: Any) -> Any:
    """Build hierarchy explorer card."""
    tree_container = column(
        tree_empty_message,
        tree_wrapper,
        sizing_mode="stretch_both",
        styles=TREE_CONTAINER_STYLES,
        min_height=240,
        height_policy="max",
    )
    return column(
        create_header("Hierarchy Explorer", "🧭"),
        tree_container,
        sizing_mode="stretch_both",
        styles=CARD_STYLES,
        min_height=360,
        height_policy="max",
    )


def create_logs_card(layout_children: Sequence[Any]) -> Any:
    """Build fixed-height parameter-edit logs card."""
    return column(
        *layout_children,
        sizing_mode="stretch_width",
        styles=STYLES["card"],
        min_height=260,
        height=260,
        height_policy="fixed",
    )


def create_root_layout(
    *,
    current_state_card: Any,
    tree_card: Any,
    logs_card: Any,
) -> Any:
    """Compose left/right columns and return root row layout."""
    left_column = column(
        current_state_card,
        sizing_mode="stretch_both",
        styles=FLEX_COLUMN_STYLES,
    )
    right_column = column(
        tree_card,
        logs_card,
        sizing_mode="stretch_both",
        styles=FLEX_COLUMN_STYLES,
    )
    return row(
        left_column,
        right_column,
        sizing_mode="stretch_both",
        min_height=420,
        styles=ROOT_ROW_STYLES,
    )
