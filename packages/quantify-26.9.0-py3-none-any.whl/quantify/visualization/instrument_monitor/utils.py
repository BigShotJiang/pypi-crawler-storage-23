# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Utility functions for the instrument monitor."""

import contextlib
import math
from typing import Any

import numpy as np

from quantify.visualization.instrument_monitor.logging_setup import get_logger

logger = get_logger(__name__)

_SI_PREFIX_TO_POWER = {
    "y": -24,
    "z": -21,
    "a": -18,
    "f": -15,
    "p": -12,
    "n": -9,
    "u": -6,
    "m": -3,
    "": 0,
    "k": 3,
    "M": 6,
    "G": 9,
    "T": 12,
    "P": 15,
    "E": 18,
    "Z": 21,
    "Y": 24,
}
_SI_POWER_TO_PREFIX = {power: prefix for prefix, power in _SI_PREFIX_TO_POWER.items()}
# Base units that support SI prefixes in monitor displays.
_SI_BASE_UNITS = {
    "m",
    "s",
    "g",
    "W",
    "J",
    "V",
    "A",
    "F",
    "T",
    "Hz",
    "Ohm",
    "S",
    "N",
    "C",
    "px",
    "b",
    "B",
    "K",
    "Bar",
    "Vpeak",
    "Vpp",
    "Vp",
    "Vrms",
    "A/s",
}


def _split_prefixed_unit(unit: str) -> tuple[int, str] | None:
    """Split SI-prefixed units into prefix power and base unit."""
    if unit in _SI_BASE_UNITS:
        return 0, unit

    for prefix, power in _SI_PREFIX_TO_POWER.items():
        if not prefix:
            continue
        if unit.startswith(prefix):
            base = unit[len(prefix) :]
            if base in _SI_BASE_UNITS:
                return power, base
    return None


def _auto_scale_si_value(value: float, unit: str) -> tuple[float, str]:
    """Scale numeric values to SI-prefixed magnitudes when possible."""
    split = _split_prefixed_unit(unit)
    if split is None or not math.isfinite(value):
        return value, unit

    current_power, base_unit = split
    value_in_base = value * (10.0**current_power)

    if value_in_base == 0:
        return 0.0, base_unit

    prefix_power = int(math.floor(math.log10(abs(value_in_base)) / 3.0) * 3)
    prefix_power = max(-24, min(24, prefix_power))
    scaled_value = value_in_base / (10.0**prefix_power)
    scaled_unit = f"{_SI_POWER_TO_PREFIX.get(prefix_power, '')}{base_unit}"
    return scaled_value, scaled_unit


def safe_value_format(value: object) -> str:
    """Value formatting with paths for common types.

    - None -> ""
    - Scalar types -> str
    - Numpy arrays -> scalar if size 1 else array<shape>
    - Sequences (non-strings) -> show "[N items]" if long
    """
    if value is None:
        return ""

    if isinstance(value, (str, int, float, bool)):
        return str(value)

    try:
        if hasattr(value, "__array__"):
            arr = np.asarray(value)
            return str(arr.item()) if arr.size == 1 else f"array{arr.shape}"

        if hasattr(value, "__len__") and not isinstance(value, (str, bytes)):
            size = len(value)  # type: ignore[arg-type]
            return str(value) if size <= 5 else f"[{size} items]"

        return str(value)
    except Exception:
        return f"<{type(value).__name__}>"


def safe_value_with_unit_format(value: object, unit: str | None) -> str:
    """Format a value and unit, scaling supported SI units by magnitude."""
    if value is None:
        return ""

    is_numeric = isinstance(value, (int, float, np.integer, np.floating))
    is_bool = isinstance(value, (bool, np.bool_))
    if unit and is_numeric and not is_bool:
        scaled_value, scaled_unit = _auto_scale_si_value(float(value), unit)
        return f"{scaled_value:.6g} {scaled_unit}".strip()

    value_text = safe_value_format(value)
    if unit and value_text:
        return f"{value_text} {unit}"
    return value_text


def safe_value_and_unit_format(value: object, unit: str | None) -> tuple[str, str]:
    """Format value/unit as separate display fields with SI-aware scaling."""
    if value is None:
        return "", ""

    is_numeric = isinstance(value, (int, float, np.integer, np.floating))
    is_bool = isinstance(value, (bool, np.bool_))
    if unit and is_numeric and not is_bool:
        scaled_value, scaled_unit = _auto_scale_si_value(float(value), unit)
        return f"{scaled_value:.6g}", scaled_unit

    value_text = safe_value_format(value)
    return value_text, unit or ""


def values_equal(val1: Any, val2: Any) -> bool:
    """Compare two values for equality."""
    result = False

    if val1 is val2:
        result = True
    elif val1 is None or val2 is None:
        result = val1 is val2
    elif type(val1) is type(val2) and isinstance(val1, (int, float, str, bool)):
        result = val1 == val2

    # Handle numpy arrays
    try:
        if hasattr(val1, "shape") and hasattr(val2, "shape"):
            result = bool(np.array_equal(val1, val2, equal_nan=True))
    except Exception:
        logger.warning("Failed to compare numpy arrays", exc_info=True)

    with contextlib.suppress(Exception):
        result = bool(val1 == val2)

    return result
