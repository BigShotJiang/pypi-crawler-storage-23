# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Utilities for setting QCoDeS parameters from monitor UI interactions."""

from __future__ import annotations

import json
from typing import Any

from qcodes.instrument import Instrument
from qcodes.station import Station


def resolve_parameter_from_full_name(full_name: str) -> Any:
    """Resolve a monitor parameter identifier to a QCoDeS parameter object.

    Supported identifier formats:
    - UI dotted path: ``instrument.submodule.parameter``
    - Canonical QCoDeS path: ``instrument_submodule_parameter``
    """
    if "." in full_name:
        return _resolve_parameter_from_dotted_path(full_name)
    return _resolve_parameter_from_qcodes_full_name(full_name)


def _resolve_parameter_from_dotted_path(full_name: str) -> Any:
    """Resolve ``instrument.submodule.parameter`` to a QCoDeS parameter object."""
    instrument_name, separator, parameter_path = full_name.partition(".")
    if not separator or not instrument_name or not parameter_path:
        raise ValueError(
            "Expected parameter name in '<instrument>.<parameter>' format."
        )

    instrument = Instrument.find_instrument(instrument_name)
    if instrument is None:
        raise ValueError(f"Instrument '{instrument_name}' is not available.")

    target = instrument
    parts = [segment for segment in parameter_path.split(".") if segment]
    if not parts:
        raise ValueError(f"Invalid parameter path in '{full_name}'.")

    for segment in parts[:-1]:
        submodules = getattr(target, "submodules", None)
        if isinstance(submodules, dict) and segment in submodules:
            target = submodules[segment]
            continue
        attr = getattr(target, segment, None)
        if attr is not None:
            target = attr
            continue
        raise ValueError(f"Cannot resolve submodule '{segment}' in '{full_name}'.")

    parameter_name = parts[-1]
    parameters = getattr(target, "parameters", None)
    if isinstance(parameters, dict) and parameter_name in parameters:
        return parameters[parameter_name]

    param_attr = getattr(target, parameter_name, None)
    if param_attr is not None:
        return param_attr

    raise ValueError(f"Cannot resolve parameter '{parameter_name}' in '{full_name}'.")


def _resolve_parameter_from_qcodes_full_name(full_name: str) -> Any:
    """Resolve canonical QCoDeS ``full_name`` via station/component APIs."""
    if not full_name or "." in full_name:
        raise ValueError("Expected QCoDeS full_name in underscore format.")

    station = Station.default
    if station is not None:
        try:
            return station.get_component(full_name)
        except Exception:
            pass

    matched_instrument = _find_best_matching_instrument(full_name)
    if matched_instrument is None:
        raise ValueError(f"Instrument for '{full_name}' is not available.")

    instrument_name = str(getattr(matched_instrument, "name", ""))
    if not instrument_name or not full_name.startswith(instrument_name):
        raise ValueError(f"Cannot resolve '{full_name}' from instrument registry.")

    remainder = full_name[len(instrument_name) :].lstrip("_")
    if not remainder:
        raise ValueError(f"Identifier '{full_name}' points to an instrument.")

    getter = getattr(matched_instrument, "get_component", None)
    if callable(getter):
        return getter(remainder)
    raise ValueError(f"Instrument '{instrument_name}' does not expose get_component().")


def _find_best_matching_instrument(full_name: str) -> Any | None:
    """Find the best instrument name prefix match for a QCoDeS full_name."""
    best_match = None
    best_len = -1
    for instrument in Instrument.instances():
        name = str(getattr(instrument, "name", ""))
        if not name:
            continue
        if (full_name == name or full_name.startswith(f"{name}_")) and (
            len(name) > best_len
        ):
            best_match = instrument
            best_len = len(name)
    return best_match


def coerce_raw_value(raw_value: str, current_value: object) -> object:
    """Convert raw user text into a type guided by the current value."""
    stripped = raw_value.strip()

    if isinstance(current_value, bool):
        lowered = stripped.lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
        raise ValueError("Invalid boolean value. Use true/false, yes/no, on/off, 1/0.")

    if isinstance(current_value, int) and not isinstance(current_value, bool):
        return int(stripped)

    if isinstance(current_value, float):
        return float(stripped)

    if isinstance(current_value, (list, tuple, dict)):
        return json.loads(stripped)

    if isinstance(current_value, str):
        return raw_value

    if current_value is None:
        try:
            return json.loads(stripped)
        except Exception:
            return raw_value

    try:
        return json.loads(stripped)
    except Exception:
        return raw_value


def set_parameter_from_text(
    *,
    full_name: str,
    raw_value: str,
    current_value: object,
) -> object:
    """Set a parameter value from text and return the value that was applied."""
    parameter = resolve_parameter_from_full_name(full_name)

    if hasattr(parameter, "settable") and not bool(parameter.settable):
        raise ValueError(f"Parameter '{full_name}' is read-only.")

    setter = getattr(parameter, "set", None)
    if not callable(setter):
        raise ValueError(f"Parameter '{full_name}' does not support set().")

    typed_value = coerce_raw_value(raw_value, current_value)
    try:
        setter(typed_value)
        return typed_value
    except Exception as typed_error:
        if typed_value != raw_value:
            try:
                setter(raw_value)
                return raw_value
            except Exception as raw_error:
                # Preserve the primary failure (typed coercion path) as the
                # user-facing/root cause while retaining fallback context.
                raise typed_error from raw_error
        raise typed_error
