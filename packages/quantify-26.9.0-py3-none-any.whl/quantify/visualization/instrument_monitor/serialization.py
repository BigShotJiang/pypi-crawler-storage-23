# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""JSON-safe serialization helpers for instrument monitor transport boundaries."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, cast

_MISSING = object()


def _try_call(func: Callable[[], Any]) -> Any:
    """Call a converter and return a sentinel when conversion is not applicable."""
    try:
        return func()
    except (AttributeError, TypeError, ValueError):
        return _MISSING


def _model_dump_jsonable(model_dump: Callable[..., Any]) -> Any:
    """Serialize pydantic models across versions with minimal branching."""
    try:
        return model_dump(mode="json", fallback=to_jsonable)
    except ValueError:
        return model_dump(mode="python")
    except TypeError:
        # Older pydantic versions do not support `fallback`.
        try:
            return model_dump(mode="json")
        except ValueError:
            return model_dump(mode="python")


def to_jsonable(obj: Any) -> Any:
    """Convert arbitrary monitor payloads into JSON-serializable structures.

    This helper is intended for transport/storage boundaries where ``Reading.value``
    may contain rich Python objects (e.g. numpy arrays).
    """
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj

    if isinstance(obj, complex):
        return str(obj)

    if isinstance(obj, (bytes, bytearray)):
        return bytes(obj).decode("utf-8", errors="replace")

    if hasattr(obj, "model_dump") and callable(obj.model_dump):
        model_dump = cast("Any", obj.model_dump)
        return to_jsonable(_model_dump_jsonable(model_dump))

    if isinstance(obj, dict):
        items = cast("dict[Any, Any]", obj).items()
        return {str(to_jsonable(k)): to_jsonable(v) for k, v in items}

    if isinstance(obj, (list, tuple, set, frozenset)):
        seq = cast("list[Any] | tuple[Any, ...] | set[Any] | frozenset[Any]", obj)
        return [to_jsonable(v) for v in seq]

    if hasattr(obj, "tolist") and callable(obj.tolist):
        converted = _try_call(obj.tolist)
        if converted is not _MISSING:
            return to_jsonable(converted)

    if hasattr(obj, "item") and hasattr(obj, "dtype"):
        converted = _try_call(obj.item)
        if converted is not _MISSING:
            return to_jsonable(converted)

    if hasattr(obj, "isoformat") and callable(obj.isoformat):
        converted = _try_call(obj.isoformat)
        if converted is not _MISSING:
            return converted

    return str(obj)
