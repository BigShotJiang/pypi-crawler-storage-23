# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Shared UI theme elements for the instrument monitor."""

from __future__ import annotations

from bokeh.models import Div

STYLES: dict[str, dict[str, str | None]] = {
    "brand": {
        "primary": "#00AEEF",
        "secondary": "#ED2024",
        "neutral": "#62525B",
    },
    "card": {
        "background-color": "#ffffff",
        "border": "1px solid #e1e5e9",
        "border-radius": "12px",
        "box-shadow": "0 4px 6px rgba(0, 0, 0, 0.05)",
        "padding": "16px",
        "margin": "8px",
    },
    "table": {
        "font-family": "'Segoe UI', -apple-system BlinkMacSystemFont, sans-serif",
        "border-radius": "6px",
        "border": "1px solid #e1e5e9",
    },
    "header": {
        "margin": "0",
        "font-family": "Segoe UI, sans-serif",
        "font-size": "16px",
        "font-weight": "600",
        "color": "#1f2937",
    },
    "header_bar": {
        "background-color": "#f2f9fc",
        "border": "1px solid #d9edf7",
        "border-left": "4px solid #00AEEF",
        "border-radius": "8px",
        "padding": "8px 10px",
        "margin": "0 0 14px 0",
    },
    "section_label": {
        "background-color": "#fbfdff",
        "border": "1px solid #e8eff4",
        "border-left": "2px solid #7fcdec",
        "border-radius": "6px",
        "padding": "4px 8px",
        "font-family": "Segoe UI, sans-serif",
        "font-size": "14px",
        "font-weight": "500",
        "color": "#334155",
        "margin": "2px 0 4px 0",
    },
    "button_primary": {
        "background-color": "#00AEEF",
        "border": "1px solid #0098d4",
        "color": "#ffffff",
        "font-weight": "600",
    },
    "button_secondary": {
        "background-color": "#f2f9fc",
        "border": "1px solid #bfe4f4",
        "color": "#0b5f82",
        "font-weight": "500",
    },
    "empty_state": {
        "color": "#6b7280",
        "font-family": "Segoe UI, sans-serif",
        "font-size": "13px",
        "text-align": "center",
        "padding": "8px 4px",
        "margin": "4px 0 0 0",
        "white-space": "pre-line",
    },
}


def create_header(title: str, icon: str) -> Div:
    """Create a styled header with icon."""
    header_style = "; ".join(f"{k}: {v}" for k, v in STYLES["header"].items())
    bar_style = "; ".join(f"{k}: {v}" for k, v in STYLES["header_bar"].items())
    return Div(
        text=(
            f"<div style='{bar_style}'>"
            f"<h3 style='{header_style}'>{icon} {title}</h3>"
            "</div>"
        ),
        sizing_mode="stretch_width",
    )


def create_section_label(text: str, icon: str) -> Div:
    """Create a compact label used above input rows."""
    style_str = "; ".join(f"{k}: {v}" for k, v in STYLES["section_label"].items())
    return Div(
        text=f"<div style='{style_str}'>{icon} {text}</div>",
        sizing_mode="stretch_width",
    )
