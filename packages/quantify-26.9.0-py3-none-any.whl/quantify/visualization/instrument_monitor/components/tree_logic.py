# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Pure tree-building helpers for the hierarchy explorer component."""

from __future__ import annotations

from collections.abc import Sequence

from quantify.visualization.instrument_monitor.models import (
    Reading,
    TreeNode,
    _TreeEntry,
)
from quantify.visualization.instrument_monitor.utils import safe_value_with_unit_format


def node_id(instrument: str, path: tuple[str, ...]) -> str:
    """Create a stable node identifier from instrument and dotted path parts."""
    if not path:
        return instrument
    return "::".join((instrument, *path))


def parameter_segments(parameter: str | None) -> list[str]:
    """Split a dotted parameter path into non-empty segments."""
    if not parameter:
        return []
    return [segment.strip() for segment in parameter.split(".") if segment.strip()]


def ensure_expanded_path(
    expanded: set[str],
    instrument: str,
    segments: Sequence[str],
) -> None:
    """Mark all ancestors of a path as expanded."""
    expanded.add(instrument)
    prefix: list[str] = []
    for segment in segments:
        prefix.append(segment)
        expanded.add(node_id(instrument, tuple(prefix)))


def build_tree_entries(readings: Sequence[Reading]) -> list[_TreeEntry]:
    """Build mutable tree entries from flat readings."""
    roots: dict[str, _TreeEntry] = {}
    for reading in readings:
        instrument = reading.instrument or "unknown"
        root = roots.get(instrument)
        if root is None:
            root = _TreeEntry(name=instrument, instrument=instrument, path=())
            roots[instrument] = root

        segments = parameter_segments(reading.parameter)
        if not segments:
            node = root.children.get(reading.parameter or reading.full_name)
            if node is None:
                node = _TreeEntry(
                    name=reading.parameter or reading.full_name,
                    instrument=instrument,
                    path=(reading.parameter or reading.full_name,),
                )
                root.children[node.name] = node
            node.reading = reading
            continue

        current = root
        path: list[str] = []
        for index, segment in enumerate(segments):
            path.append(segment)
            child = current.children.get(segment)
            if child is None:
                child = _TreeEntry(
                    name=segment,
                    instrument=instrument,
                    path=tuple(path),
                )
                current.children[segment] = child
            if index == len(segments) - 1:
                child.reading = reading
            current = child

    return list(roots.values())


def flatten_tree_entries(
    tree_roots: Sequence[_TreeEntry],
    expanded: set[str],
) -> list[TreeNode]:
    """Flatten recursive tree entries into renderable nodes."""
    nodes: list[TreeNode] = []
    for root in sorted(tree_roots, key=lambda r: r.instrument.lower()):
        nodes.extend(_flatten_entry(root, expanded, level=0))
    return nodes


def collect_node_ids(entries: Sequence[_TreeEntry]) -> set[str]:
    """Collect all node ids from a tree, used for expand-all behavior."""
    ids: set[str] = set()
    stack = list(entries)
    while stack:
        entry = stack.pop()
        ids.add(node_id(entry.instrument, entry.path))
        if entry.children:
            stack.extend(entry.children.values())
    return ids


def _flatten_entry(entry: _TreeEntry, expanded: set[str], level: int) -> list[TreeNode]:
    node_key = node_id(entry.instrument, entry.path)
    is_group = bool(entry.children)
    is_expanded = node_key in expanded

    label = entry.name if level > 0 else entry.instrument
    value_text = ""
    if not is_group and entry.reading is not None:
        value_text = safe_value_with_unit_format(
            entry.reading.value, entry.reading.unit
        )

    node = TreeNode(
        node_id=node_key,
        label=label,
        value_text=value_text,
        level=level,
        is_group=is_group,
        expanded=is_expanded,
    )

    nodes = [node]
    if is_group and is_expanded:
        for child_name in sorted(entry.children.keys(), key=lambda n: n.lower()):
            child = entry.children[child_name]
            nodes.extend(_flatten_entry(child, expanded, level + 1))
    return nodes
