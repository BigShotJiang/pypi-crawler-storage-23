# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Action log panel component for instrument monitor interactions."""

from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from typing import Any, cast

from bokeh.layouts import column
from bokeh.models import (
    ColumnDataSource,
    DataTable,
    Div,
    HTMLTemplateFormatter,
    TableColumn,
)

from quantify.visualization.instrument_monitor.components.theme import (
    STYLES,
    create_header,
)


class ActionLogPanel:
    """Compact table that records parameter set attempts from the UI."""

    def __init__(self, *, max_entries: int = 250) -> None:
        self._max_entries = max_entries
        self.header = create_header("Parameter Edit Logs", "📝")
        self.source = ColumnDataSource(
            data={
                "time": [],
                "full_name": [],
                "old_value": [],
                "new_value": [],
                "status": [],
                "message": [],
                "message_html": [],
                "message_title": [],
            }
        )

        self.table = DataTable(
            source=self.source,
            columns=[
                TableColumn(field="time", title="Time", width=90),
                TableColumn(field="status", title="Status", width=80),
                TableColumn(field="full_name", title="Parameter", width=220),
                TableColumn(field="old_value", title="Old", width=100),
                TableColumn(field="new_value", title="New", width=100),
                TableColumn(
                    field="message_html",
                    title="Message",
                    width=420,
                    formatter=HTMLTemplateFormatter(
                        template=(
                            '<div title="<%= message_title %>" '
                            'style="white-space:nowrap; overflow:hidden; '
                            "text-overflow:ellipsis; max-width:100%; "
                            'user-select:text; cursor:text;">'
                            "<%= message_html %></div>"
                        )
                    ),
                ),
            ],
            index_position=None,
            selectable=False,
            reorderable=False,
            sizing_mode="stretch_both",
            styles={**STYLES["table"], "user-select": "text"},
        )

        self.empty_message = Div(
            text="No edit actions yet.",
            styles={
                **STYLES["empty_state"],
                "position": "absolute",
                "left": "50%",
                "top": "50%",
                "transform": "translate(-50%, -50%)",
                "pointer-events": "none",
                "z-index": "1",
                "width": "80%",
            },
            visible=True,
        )

        self.table_container = column(
            self.empty_message,
            self.table,
            sizing_mode="stretch_both",
            styles={"position": "relative"},
        )

    @property
    def layout_children(self) -> list:
        """Return child models to be included in a column layout."""
        return [self.header, self.table_container]

    def add_entry(
        self,
        *,
        full_name: str,
        old_value: str,
        new_value: str,
        success: bool,
        message: str,
    ) -> None:
        """Append one action entry to the log table."""
        data: dict[str, list[Any]] = {
            str(key): list(values) for key, values in self.source.data.items()
        }
        data["time"].append(datetime.now(timezone.utc).strftime("%H:%M:%S"))
        data["full_name"].append(full_name)
        data["old_value"].append(old_value)
        data["new_value"].append(new_value)
        data["status"].append("ok" if success else "error")
        data["message"].append(message)
        data["message_html"].append(escape(message))
        data["message_title"].append(escape(message, quote=True))

        extra = len(data["time"]) - self._max_entries
        if extra > 0:
            for key in data:
                data[key] = data[key][extra:]

        # ColumnDataSource.data expects DataDictLike; cast keeps pyright happy.
        self.source.data = cast("Any", data)
        self.empty_message.visible = len(data["time"]) == 0
