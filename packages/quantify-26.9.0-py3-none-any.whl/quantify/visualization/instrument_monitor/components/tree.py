# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Tree component for the instrument monitor UI."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

from bokeh.events import DocumentReady
from bokeh.layouts import column, row
from bokeh.models import Button, ColumnDataSource, CustomJS, Div

from quantify.visualization.instrument_monitor.components.theme import STYLES
from quantify.visualization.instrument_monitor.components.tree_logic import (
    build_tree_entries,
    collect_node_ids,
    ensure_expanded_path,
    flatten_tree_entries,
    node_id,
    parameter_segments,
)
from quantify.visualization.instrument_monitor.components.tree_rendering import (
    TREE_LEGEND_HTML,
    TREE_STYLESHEET,
    render_tree_row,
)
from quantify.visualization.instrument_monitor.logging_setup import get_logger

if TYPE_CHECKING:
    from bokeh.document import Document

    from quantify.visualization.instrument_monitor.models import (
        Reading,
        TreeNode,
        _TreeEntry,
    )


logger = get_logger(__name__)


class SnapshotTree:
    """Interactive tree view showing instrument hierarchy."""

    def __init__(self) -> None:
        """Initialize the tree view component."""
        self.rows_container = Div(
            sizing_mode="stretch_both",
            styles={
                "position": "relative",
                "overflow-y": "auto",
                "overflow-x": "hidden",
                # Allow this area to shrink/grow within the card while keeping
                # controls and legend fixed at the top.
                "flex": "1 1 auto",
                "min-height": "0",
            },
            css_classes=["tree-container"],
        )

        # Bridge for tree toggle events from JS to Python
        # JS will set node_id and bump tick to trigger on_change
        self.events = ColumnDataSource(
            data={
                "node_id": [""],
                "tick": [0],
            }
        )

        # Control buttons
        self.expand_all_btn = Button(
            label="Expand All",
            button_type="default",
            width=80,
            height=25,
            styles={"font-size": "11px"},
        )
        self.collapse_all_btn = Button(
            label="Collapse All",
            button_type="default",
            width=80,
            height=25,
            styles={"font-size": "11px"},
        )

        # Connect button callbacks
        self.expand_all_btn.on_click(self._expand_all)
        self.collapse_all_btn.on_click(self._collapse_all)

        controls = row(
            self.expand_all_btn,
            self.collapse_all_btn,
            styles={
                "display": "flex",
                "gap": "8px",
                "align-items": "center",
            },
        )
        toolbar = row(
            controls,
            self._create_legend(),
            sizing_mode="stretch_width",
            styles={
                "display": "flex",
                "justify-content": "space-between",
                "align-items": "center",
                "flex-wrap": "wrap",
                "gap": "8px",
                "margin-bottom": "8px",
            },
        )

        self.wrapper = column(
            toolbar,
            self.rows_container,
            sizing_mode="stretch_both",
            styles={
                "position": "relative",
                "padding": "12px 12px 8px 12px",
                "display": "flex",
                "flex-direction": "column",
            },
        )

        self.empty_message = Div(
            text=(
                "⏳ No data available right now.\n"
                "Once instrument snapshots are ingested, the hierarchy will appear."
            ),
            styles={
                **STYLES["empty_state"],
                "position": "absolute",
                "left": "50%",
                "top": "50%",
                "transform": "translate(-50%, -50%)",
                "pointer-events": "none",
                "z-index": "1",
                "width": "80%",
                "background": "rgba(255,255,255,0.9)",
                "border-radius": "8px",
                "padding": "16px",
            },
            visible=True,
        )

        self._expanded: set[str] = set()
        self._nodes: list[TreeNode] = []
        self._tree_roots: list[_TreeEntry] = []
        self._readings: Sequence[Reading] = []
        self._focused_node_id: str | None = None

    def bind_js(self, doc: Document) -> None:
        """Attach client-side bridge for row click -> Python node toggle.

        This binds a DocumentReady CustomJS that:
        - defines ``window.toggleTreeNode(nodeId)`` for compatibility, and
        - installs delegated click handling on rendered group rows.
        """
        tree_toggle_js = CustomJS(
            args=dict(
                tree_events=self.events,
                tree_rows=self.rows_container,
            ),
            code="""
            const emitToggle = function(nodeId) {
              const node = String(nodeId || '').trim();
              if (!node) return;
              // Write nodeId and bump tick to trigger a change
              const d = Object.assign({}, tree_events.data);
              d.node_id = [node];
              const hasTick = Array.isArray(d.tick) && d.tick.length;
              const t = hasTick ? Number(d.tick[0]) : 0;
              d.tick = [t + 1];
              tree_events.data = d;
            };

            // Backward-compatible global hook.
            window.toggleTreeNode = emitToggle;

            const queryDeep = (rootEl, selector) => {
              if (!rootEl) return null;
              const queue = [rootEl];
              while (queue.length > 0) {
                const current = queue.shift();
                if (!current || typeof current.querySelector !== 'function') {
                  continue;
                }
                try {
                  const found = current.querySelector(selector);
                  if (found) return found;
                } catch (_e) {}
                const children = current.children ? Array.from(current.children) : [];
                for (const child of children) {
                  queue.push(child);
                  if (child && child.shadowRoot) {
                    queue.push(child.shadowRoot);
                  }
                }
              }
              return null;
            };

            const resolveTreeElement = () => {
              try {
                const treeView = Bokeh.index[tree_rows.id];
                if (treeView && treeView.el) return treeView.el;
              } catch (_e) {}

              try {
                const views = Object.values(Bokeh.index || {});
                for (const view of views) {
                  if (!view || !view.el) continue;
                  const byModel = queryDeep(
                    view.el, `[data-model-id="${tree_rows.id}"]`
                  );
                  if (byModel) return byModel;
                  const byClass = queryDeep(view.el, '.tree-container');
                  if (byClass) return byClass;
                }
              } catch (_e) {}
              return null;
            };

            const bindRowToggle = () => {
              const treeEl = resolveTreeElement();
              if (!treeEl) return false;
              if (treeEl.__insmonRowToggleBound) return true;
              treeEl.__insmonRowToggleBound = true;

              const findGroupRow = (event) => {
                if (!event) return null;
                if (typeof event.composedPath === 'function') {
                  const path = event.composedPath();
                  for (const entry of path) {
                    if (!entry || typeof entry.getAttribute !== 'function') continue;
                    if (entry.getAttribute('data-is-group') !== '1') continue;
                    const nodeId = entry.getAttribute('data-node-id');
                    if (nodeId) return entry;
                  }
                }
                const target = event.target;
                if (!target || typeof target.closest !== 'function') return null;
                return target.closest('[data-is-group=\"1\"][data-node-id]');
              };

              treeEl.addEventListener('click', (event) => {
                const row = findGroupRow(event);
                if (!row) return;
                const nodeId = row.getAttribute('data-node-id') || '';
                if (!nodeId) return;
                emitToggle(nodeId);
                event.preventDefault();
              });
              return true;
            };

            if (!bindRowToggle()) {
              let attempts = 0;
              const retryTimer = setInterval(() => {
                attempts += 1;
                if (bindRowToggle() || attempts >= 20) {
                  clearInterval(retryTimer);
                }
              }, 250);
            }
            """,
        )
        # Bokeh's DocumentReady event binding
        try:
            doc.js_on_event(DocumentReady, tree_toggle_js)
        except Exception:
            logger.warning("Failed to bind tree toggle JS", exc_info=True)

    def bind_python_toggle_handler(self) -> None:
        """Attach Python-side handler for JS-originated toggle events."""
        try:
            self.events.on_change("data", self._on_events_change)
        except Exception:
            logger.warning("Failed to attach tree toggle handler", exc_info=True)

    def _on_events_change(self, _attr: str, _old: object, _new: object) -> None:
        """Handle changes to ``self.events`` from JS and toggle nodes."""
        try:
            data = self.events.data
            node_id_list = data.get("node_id", []) if isinstance(data, dict) else []
            node_id = ""
            if (
                isinstance(node_id_list, Sequence)
                and not isinstance(node_id_list, (str, bytes))
                and len(node_id_list) > 0
            ):
                node_id = str(node_id_list[0])
            if node_id:
                try:
                    expanded_before = node_id in self._expanded  # type: ignore[attr-defined]
                except Exception:
                    expanded_before = False
                logger.debug(
                    "Tree toggle requested",
                    extra={"node_id": node_id, "expanded_before": expanded_before},
                )
                self.toggle_node(node_id)
                try:
                    expanded_after = node_id in self._expanded  # type: ignore[attr-defined]
                except Exception:
                    expanded_after = False
                logger.debug(
                    "Tree toggle applied",
                    extra={"node_id": node_id, "expanded_after": expanded_after},
                )
        except Exception as e:
            logger.warning("Tree toggle handler failed: %s", str(e), exc_info=True)

    def update_readings(self, readings: Sequence[Reading]) -> None:
        """Update tree with new readings."""
        self._rebuild_view(readings)

    def focus_on_full_name(self, full_name: str) -> None:
        """Expand path to and highlight a specific parameter."""
        if not full_name:
            return

        if "." not in full_name and "_" in full_name:
            for reading in self._readings:
                if reading.qcodes_full_name == full_name and reading.full_name:
                    full_name = reading.full_name
                    break

        instrument, _, tail = full_name.partition(".")
        segments = parameter_segments(tail) if tail else []
        instrument_name = instrument or "unknown"
        ensure_expanded_path(self._expanded, instrument_name, segments)
        self._focused_node_id = node_id(instrument_name, tuple(segments))
        # Rebuild so that expanded path's children are included
        self._rebuild_view(self._readings)

    def _rebuild_view(self, readings: Sequence[Reading]) -> None:
        self._readings = readings
        tree_roots = build_tree_entries(readings)
        self._tree_roots = tree_roots

        if not tree_roots:
            self._nodes = []
            self._render_rows()
            self._show_empty_state(readings_present=bool(readings))
            return

        # Build flat list of nodes
        nodes = flatten_tree_entries(tree_roots, self._expanded)

        if not nodes:
            self._nodes = []
            self._render_rows()
            self._show_empty_state(readings_present=bool(readings), filter_active=False)
            return
        self._nodes = nodes
        self._render_rows()
        self.empty_message.visible = False

    def _render_rows(self) -> None:
        if not self._nodes:
            self.rows_container.text = ""
            return

        rows_html = [
            render_tree_row(
                label=node.label,
                value_text=node.value_text,
                level=node.level,
                is_group=node.is_group,
                expanded=node.expanded,
                node_id=node.node_id,
                focused=node.node_id == self._focused_node_id,
            )
            for node in self._nodes
        ]

        # JS handlers are injected once in app.py via CustomJS
        self.rows_container.text = TREE_STYLESHEET + "".join(rows_html)
        # Focus is transient to avoid repeated auto-scroll on every periodic refresh.
        self._focused_node_id = None

    def toggle_node(self, node_id: str) -> None:
        """Toggle expansion state of a specific node."""
        if node_id in self._expanded:
            self._expanded.remove(node_id)
        else:
            self._expanded.add(node_id)
        self._rebuild_view(self._readings)

    def _create_legend(self) -> Div:
        """Create a Bokeh Div legend so it can be placed in layouts (LayoutDOM)."""
        return Div(
            text=TREE_LEGEND_HTML,
            css_classes=["tree-legend"],
            styles={},
        )

    def _show_empty_state(
        self, *, readings_present: bool, filter_active: bool = False
    ) -> None:
        if not readings_present:
            self.empty_message.text = (
                "⏳ No data available right now.\n"
                "Once instrument snapshots are ingested, the hierarchy will appear."
            )
        elif filter_active:
            self.empty_message.text = (
                "🔎 No results match your filter.\n"
                "Adjust the search to explore other parts of the hierarchy."
            )
        else:
            self.empty_message.text = (
                "✨ Instruments discovered, but no parameters are reporting values yet."
            )
        self.empty_message.visible = True

    def _expand_all(self) -> None:
        """Expand all nodes in the tree."""
        if not self._tree_roots:
            return

        self._expanded.update(collect_node_ids(self._tree_roots))
        # Rebuild to include all newly expanded nodes
        self._rebuild_view(self._readings)

    def _collapse_all(self) -> None:
        """Collapse all nodes in the tree."""
        self._expanded.clear()
        # Rebuild to reflect collapsed state
        self._rebuild_view(self._readings)
