# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Tree HTML rendering helpers for the instrument monitor."""

from __future__ import annotations

TREE_STYLESHEET = """
<style>
    .tree-container {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 13px;
        line-height: 1.6;
        color: #333;
    }
    .tree-item {
        display: flex;
        align-items: center;
        padding: 3px 0;
        user-select: none;
        border-left: 1px solid #eee;
    }
    .tree-item:hover {
        background: #f5f5f5;
    }
    .tree-toggle {
        display: inline-flex;
        width: 16px;
        margin-right: 4px;
        color: #999;
        font-size: 10px;
        cursor: pointer;
        flex-shrink: 0;
        transition: transform 0.15s ease;
    }
    .tree-toggle--expanded {
        transform: rotate(90deg);
    }
    .tree-label {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        flex: 1 1 auto;
        min-width: 0;
    }
    .tree-value {
        margin-left: 8px;
        color: #4b5563;
        white-space: nowrap;
        font-size: 12px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        flex-shrink: 0;
    }
    .tree-item--module .tree-label {
        color: #0f766e;
        font-weight: 600;
    }
    .tree-item--instrument .tree-label {
        color: #0079a8;
        font-weight: 600;
    }
    .tree-item--param .tree-label {
        color: #4b5563;
    }
    .tree-item--focused {
        background: #e8f3ff;
        outline: 1px solid #bfdbfe;
        border-radius: 4px;
    }
    .tree-legend {
        display: flex;
        gap: 12px;
        font-size: 12px;
        color: #374151;
        background: #fff;
        border: 1px solid #e5e5e5;
        border-radius: 6px;
        padding: 4px 6px;
        flex-wrap: wrap;
    }
    .legend-item {
        display: flex;
        align-items: center;
        gap: 4px;
    }
    .legend-color {
        width: 12px;
        height: 12px;
        border-radius: 2px;
    }
    .tree-controls {
        display: flex;
        gap: 8px;
        margin-bottom: 8px;
    }
    .tree-control-btn {
        padding: 4px 8px;
        font-size: 11px;
        border: 1px solid #ddd;
        border-radius: 3px;
        background: #f8f9fa;
        cursor: pointer;
    }
    .tree-control-btn:hover {
        background: #e9ecef;
    }
    .tree-leaf-bullet {
        width: 16px;
        display: inline-block;
        text-align: center;
        color: #bbb;
        font-size: 10px;
        margin-right: 4px;
        flex-shrink: 0;
    }
</style>
"""

TREE_LEGEND_HTML = (
    '<div class="legend-item">'
    '<div class="legend-color" style="display:inline-block; '
    "width:12px; height:12px; border-radius:2px; "
    'background: #00aeef; margin-right: 4px;"></div>'
    "<span>Instrument</span>"
    "</div>"
    '<div class="legend-item">'
    '<div class="legend-color" style="display:inline-block; '
    "width:12px; height:12px; border-radius:2px; "
    'background: #0f766e; margin-right: 4px;"></div>'
    "<span>Module</span>"
    "</div>"
    '<div class="legend-item">'
    '<div class="legend-color" style="display:inline-block; '
    "width:12px; height:12px; border-radius:2px; "
    'background: #4b5563; margin-right: 4px;"></div>'
    "<span>Parameter</span>"
    "</div>"
)


def escape_tree_html(text: str) -> str:
    """Escape HTML special characters for tree labels and values."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def render_tree_row(
    *,
    label: str,
    value_text: str,
    level: int,
    is_group: bool,
    expanded: bool,
    node_id: str,
    focused: bool = False,
) -> str:
    """Render one tree row as HTML."""
    indent_px = level * 16
    item_class = "tree-item"

    if level == 0:
        item_class += " tree-item--instrument"
    elif is_group:
        item_class += " tree-item--module"
    else:
        item_class += " tree-item--param"
    if focused:
        item_class += " tree-item--focused"

    toggle_html = ""
    cursor_style = ""
    if is_group:
        toggle_class = "tree-toggle"
        if expanded:
            toggle_class += " tree-toggle--expanded"
        toggle_html = (
            '<span class="'
            f"{toggle_class}"
            '" data-node-id="'
            f"{escape_tree_html(node_id)}"
            '">▶</span>'
        )
        cursor_style = "cursor: pointer;"
    else:
        toggle_html = '<span class="tree-leaf-bullet">•</span>'

    value_html = ""
    if value_text:
        value_html = f'<span class="tree-value">{escape_tree_html(value_text)}</span>'

    return (
        '<div class="'
        f"{item_class}"
        '" style="padding-left:'
        f"{indent_px}"
        "px; "
        f"{cursor_style}"
        '" data-node-id="'
        f"{escape_tree_html(node_id)}"
        '" data-is-group="'
        f"{'1' if is_group else '0'}"
        '"'
        ">"
        f"{toggle_html}"
        '<span class="tree-label">'
        f"{escape_tree_html(label)}"
        "</span>"
        f"{value_html}"
        "</div>"
    )
