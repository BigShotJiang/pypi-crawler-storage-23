# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""Bokeh UI composition for the instrument monitor."""

from __future__ import annotations

from collections.abc import Callable
from html import escape
from typing import TYPE_CHECKING, cast

from bokeh.events import DocumentReady
from bokeh.models import ColumnDataSource, CustomJS

from quantify.visualization.instrument_monitor.components.logs import ActionLogPanel
from quantify.visualization.instrument_monitor.components.tables import (
    CurrentStateTable,
)
from quantify.visualization.instrument_monitor.components.tree import SnapshotTree
from quantify.visualization.instrument_monitor.logging_setup import get_logger
from quantify.visualization.instrument_monitor.ui_js import instrument_monitor_ready_js
from quantify.visualization.instrument_monitor.ui_layout import (
    create_current_state_card,
    create_filter_widgets,
    create_logs_card,
    create_root_layout,
    create_tree_card,
    create_value_editor_widgets,
)

if TYPE_CHECKING:
    from bokeh.document import Document
    from bokeh.models.layouts import Row


logger = get_logger(__name__)

SetValueHandler = Callable[[str, str, object], tuple[bool, str]]


class InstrumentMonitorUI:
    """Bokeh UI with minimal, responsive interaction controls."""

    def __init__(self) -> None:
        """Initialize the UI components."""
        self.current_state_table = CurrentStateTable()
        self.snapshot_tree = SnapshotTree()
        self.action_log_panel = ActionLogPanel()

        self.current_state_table.source.selected.on_change(
            "indices", self._on_current_state_selection
        )

        # UI state: track whether the filter TextInput is focused on the client.
        self.ui_state = ColumnDataSource(
            data={
                "filter_focused": [False],
                "table_scrolling": [False],
                # Client-side interaction lock; app skips redraws while now < deadline.
                "interaction_deadline_ms": [0],
            }
        )

        self._selected_identifier: str | None = None
        self._selected_display_name: str | None = None
        self._set_value_handler: SetValueHandler | None = None

    def set_value_handler(self, handler: SetValueHandler) -> None:
        """Register handler used for applying value edits."""
        self._set_value_handler = handler

    def _set_feedback(self, *, success: bool, message: str) -> None:
        color = "#0f7b0f" if success else "#b00020"
        self._edit_feedback.text = (
            f"<span style='color:{color}; font-size:12px;'>{escape(message)}</span>"
        )

    def _set_selected_parameter(self, display_name: str, identifier: str) -> None:
        self._selected_display_name = display_name
        self._selected_identifier = identifier
        self._selected_parameter.text = (
            "<b>Selected:</b> "
            f"<code style='font-size:12px;'>{escape(display_name)}</code>"
        )
        self._value_input.value = self.current_state_table.get_full_value_for(
            identifier
        )

    def _apply_selected_value(self) -> None:
        identifier = self._selected_identifier
        if not identifier:
            self._set_feedback(
                success=False, message="Select a parameter row before setting a value."
            )
            return

        if self._set_value_handler is None:
            self._set_feedback(
                success=False,
                message="No parameter setter is configured.",
            )
            return

        new_value = self._value_input.value
        old_value = self.current_state_table.get_full_value_for(identifier)
        raw_current = self.current_state_table.get_raw_value_for(identifier)
        display_name = self._selected_display_name or identifier

        try:
            success, message = self._set_value_handler(
                identifier, new_value, raw_current
            )
        except Exception as e:
            success = False
            message = str(e)

        self._set_feedback(success=success, message=message)
        self.action_log_panel.add_entry(
            full_name=display_name,
            old_value=old_value,
            new_value=new_value,
            success=success,
            message=message,
        )

    def _on_current_state_selection(
        self, _attr: str, _old: object, new: list[int]
    ) -> None:
        try:
            if not new:
                return
            data = self.current_state_table.source.data
            data_dict = cast("dict[str, list[object]]", data)
            idx = new[0]

            if (
                "is_group" in data_dict
                and idx < len(data_dict.get("is_group", []))
                and bool(data_dict["is_group"][idx])
            ):
                return

            full_names = data_dict.get("full_name", [])
            if idx < len(full_names):
                full_name_obj = full_names[idx]
                display_name = str(full_name_obj)
                qcodes_names = data_dict.get("qcodes_full_name", [])
                identifier = display_name
                if idx < len(qcodes_names):
                    qcodes_name = str(qcodes_names[idx] or "")
                    if qcodes_name:
                        identifier = qcodes_name
                self.snapshot_tree.focus_on_full_name(display_name)
                self._set_selected_parameter(display_name, identifier)
        except Exception as e:
            logger.error(
                "Error handling current state selection",
                extra={"error": str(e)},
                exc_info=True,
            )

    def _on_filter_change(self, _attr: str, _old: str, new: str) -> None:
        try:
            self.current_state_table.set_filter(new)
        except Exception as e:
            logger.error(
                "Error applying filter",
                extra={"error": str(e)},
                exc_info=True,
            )

    def _clear_filter(self) -> None:
        try:
            if self._filter_input.value:
                self._filter_input.value = ""
                return
            self.current_state_table.set_filter("")
        except Exception as e:
            logger.error(
                "Error clearing filter",
                extra={"error": str(e)},
                exc_info=True,
            )

    def create_layout(self) -> Row:
        """Create dashboard layout with two columns."""
        self._filter_label, self._filter_input, self._clear_filter_button = (
            create_filter_widgets(self._on_filter_change, self._clear_filter)
        )
        (
            self._selected_parameter,
            self._value_editor_label,
            self._value_input,
            self._apply_button,
            self._edit_feedback,
        ) = create_value_editor_widgets(self._apply_selected_value)

        current_state_card = create_current_state_card(
            filter_label=self._filter_label,
            filter_input=self._filter_input,
            clear_filter_button=self._clear_filter_button,
            selected_parameter=self._selected_parameter,
            value_editor_label=self._value_editor_label,
            value_input=self._value_input,
            apply_button=self._apply_button,
            edit_feedback=self._edit_feedback,
            table_empty_message=self.current_state_table.empty_message,
            table_widget=self.current_state_table.table,
        )
        tree_card = create_tree_card(
            tree_empty_message=self.snapshot_tree.empty_message,
            tree_wrapper=self.snapshot_tree.wrapper,
        )
        logs_card = create_logs_card(self.action_log_panel.layout_children)
        self._root_row = create_root_layout(
            current_state_card=current_state_card,
            tree_card=tree_card,
            logs_card=logs_card,
        )

        return self._root_row

    def attach_client_listeners(self, doc: Document) -> None:
        """Attach client-side focus, scroll, and viewport fit listeners."""
        try:
            ready_js = CustomJS(
                args=dict(
                    inp=self._filter_input,
                    edit_inp=self._value_input,
                    apply_btn=self._apply_button,
                    state=self.ui_state,
                    table=self.current_state_table.table,
                    table_source=self.current_state_table.source,
                    tree_rows=self.snapshot_tree.rows_container,
                    root_layout=self._root_row,
                ),
                code=instrument_monitor_ready_js(),
            )
            doc.js_on_event(DocumentReady, ready_js)
        except Exception as e:
            logger.warning(
                f"Failed to attach focus/scroll listeners: {e}", exc_info=True
            )
