# Repository: https://gitlab.com/quantify-os/quantify
# Licensed according to the LICENSE file on the main branch
"""
Data acquisition framework focused on Quantum Computing and solid-state physics
experiments.

.. list-table::
    :header-rows: 1

    * - Import alias
      - Target
    * - :class:`.QuantumDevice`
      - :class:`!quantify.QuantumDevice`
    * - :class:`.Schedule`
      - :class:`!quantify.Schedule`
    * - :class:`.Resource`
      - :class:`!quantify.Resource`
    * - :class:`.ClockResource`
      - :class:`!quantify.ClockResource`
    * - :class:`.BasebandClockResource`
      - :class:`!quantify.BasebandClockResource`
    * - :class:`.DigitalClockResource`
      - :class:`!quantify.DigitalClockResource`
    * - :class:`.Operation`
      - :class:`!quantify.Operation`
    * - :obj:`.structure`
      - :obj:`!quantify.structure`
    * - :class:`.BasicTransmonElement`
      - :class:`!quantify.BasicTransmonElement`
    * - :class:`.CompositeSquareEdge`
      - :class:`!quantify.CompositeSquareEdge`
    * - :class:`.InstrumentCoordinator`
      - :class:`!quantify.InstrumentCoordinator`
    * - :class:`.GenericInstrumentCoordinatorComponent`
      - :class:`!quantify.GenericInstrumentCoordinatorComponent`
    * - :class:`.SerialCompiler`
      - :class:`!quantify.SerialCompiler`
    * - :class:`.MockLocalOscillator`
      - :class:`!quantify.MockLocalOscillator`
"""

from importlib import import_module
import os
import sys
import warnings

_PY310_DEPRECATION_MESSAGE = (
    "Quantify will drop support for Python 3.10 on 2026-04-01. "
    "Please upgrade your environment to Python 3.11 or newer."
)


def _should_warn_py310() -> bool:
    if os.environ.get("QUANTIFY_SUPPRESS_PY310_WARNING") == "1":
        return False
    return sys.version_info < (3, 11)


if _should_warn_py310():
    warnings.warn(_PY310_DEPRECATION_MESSAGE, UserWarning, stacklevel=2)

# these imports are required in this order to avoid RuntimeError issues
import h5netcdf
import netCDF4

# Core modules
from quantify import structure, waveforms

# Version handling
try:
    from importlib.metadata import version

    __version__ = version("quantify")
except Exception:
    __version__ = "unknown"

from typing import TYPE_CHECKING

# Lazy-load modules to avoid import cycles during docs builds.
_LAZY_MODULES = {"analysis", "measurement"}
_LAZY_OBJECTS = {"MeasurementControl": "quantify.measurement.control"}
from quantify.analysis.base_analysis import BaseAnalysis
from quantify.backends import SerialCompiler
from quantify.device_under_test import BasicTransmonElement, QuantumDevice
from quantify.instrument_coordinator.components.generic import (
    GenericInstrumentCoordinatorComponent,
)
from quantify.instrument_coordinator.instrument_coordinator import InstrumentCoordinator
from quantify.measurement.types import Settable
from quantify.operations import Operation
from quantify.resources import (
    BasebandClockResource,
    ClockResource,
    DigitalClockResource,
    Resource,
)
from quantify.schedules import Schedule

if TYPE_CHECKING:
    from quantify import analysis, measurement
    from quantify.measurement.control import MeasurementControl
    from quantify.visualization.color_utilities import color_utilities
    from quantify.visualization.instrument_monitor import (
        MonitorHandle,
        launch_instrument_monitor,
    )
    from quantify.visualization.mpl_plotting import mpl_plotting
    from quantify.visualization.plot_interpolation import plot_interpolation
    from quantify.visualization.plotmon.caching.in_memory_cache import InMemoryCache
    from quantify.visualization.plotmon.plotmon_app import PlotmonApp
    from quantify.visualization.plotmon.plotmon_server import process_messages
    from quantify.visualization.plotmon.utils.communication import Message
    from quantify.visualization.SI_utilities import SI_utilities


__all__ = [
    "BaseAnalysis",
    "BasebandClockResource",
    "BasicTransmonElement",
    "ClockResource",
    "DigitalClockResource",
    "GenericInstrumentCoordinatorComponent",
    "InstrumentCoordinator",
    "MeasurementControl",
    "Operation",
    "QuantumDevice",
    "Resource",
    "Schedule",
    "SerialCompiler",
    "Settable",
    "__version__",
    "analysis",
    "measurement",
    # Core modules
    "structure",
    "waveforms",
]


def __getattr__(name: str):
    if name in _LAZY_MODULES:
        module = import_module(f"quantify.{name}")
        globals()[name] = module
        return module
    if name in _LAZY_OBJECTS:
        module = import_module(_LAZY_OBJECTS[name])
        value = getattr(module, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
