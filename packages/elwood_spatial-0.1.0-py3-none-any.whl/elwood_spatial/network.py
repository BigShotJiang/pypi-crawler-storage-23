"""Spatial network generation from GeoDataFrames using distance-band weights."""

from __future__ import annotations

import geopandas as gpd
from libpysal.weights import DistanceBand

# Network type: {device_id: {"neighbors": [...], "weights": [...]}}
Network = dict[str, dict[str, list]]


def build_network(
    gdf: gpd.GeoDataFrame,
    threshold: float,
    id_column: str,
    max_neighbors: int = 20,
    min_neighbors: int = 3,
    projected_crs: str | int | None = None,
) -> Network:
    """Build a spatial neighbor network from a GeoDataFrame using distance-band weights.

    Wraps ``libpysal.weights.DistanceBand.from_dataframe()`` to create a
    neighbor network where devices within ``threshold`` distance are connected.

    Parameters
    ----------
    gdf : GeoDataFrame
        GeoDataFrame with point geometries for each device.
    threshold : float
        Distance threshold in the CRS units (meters if projected).
    id_column : str
        Column name containing device IDs.
    max_neighbors : int
        Maximum neighbors to retain per device (sorted by weight descending).
    min_neighbors : int
        Minimum neighbor count; devices with fewer are excluded from the network.
    projected_crs : str or int or None
        If provided, reproject the GeoDataFrame to this CRS before computing distances.

    Returns
    -------
    Network
        Dict mapping device IDs to their neighbors and weights.
    """
    gdf = gdf.copy()
    if projected_crs is not None:
        gdf = gdf.to_crs(projected_crs)

    ids = gdf[id_column].tolist()
    w = DistanceBand.from_dataframe(
        gdf, ids=ids, threshold=threshold, binary=False, silence_warnings=True
    )

    network: Network = {}
    for device_id in w.id_order:
        neighbors = w.neighbors.get(device_id, [])
        weights = w.weights.get(device_id, [])

        # Sort by weight descending and cap at max_neighbors
        if neighbors:
            pairs = sorted(zip(neighbors, weights), key=lambda x: x[1], reverse=True)
            pairs = pairs[:max_neighbors]
            neighbors, weights = zip(*pairs)
            neighbors = list(neighbors)
            weights = list(weights)
        else:
            neighbors = []
            weights = []

        network[str(device_id)] = {
            "neighbors": [str(n) for n in neighbors],
            "weights": [float(w) for w in weights],
        }

    # Filter out devices below min_neighbors
    return {
        k: v for k, v in network.items() if len(v["neighbors"]) >= min_neighbors
    }


def filter_network(
    network: Network,
    active_ids: set[str] | list[str],
    min_neighbors: int = 3,
) -> Network:
    """Filter a network to only include active devices with enough neighbors.

    Parameters
    ----------
    network : Network
        Full network dict.
    active_ids : set or list of str
        Device IDs that are currently active/reporting.
    min_neighbors : int
        Minimum neighbor count after filtering.

    Returns
    -------
    Network
        Filtered network containing only active devices with sufficient neighbors.
    """
    active = set(str(i) for i in active_ids)
    filtered: Network = {}
    for device_id, data in network.items():
        if device_id not in active:
            continue
        # Filter neighbor list to only active devices
        pairs = [
            (n, w)
            for n, w in zip(data["neighbors"], data["weights"])
            if n in active
        ]
        if len(pairs) >= min_neighbors:
            neighbors, weights = zip(*pairs) if pairs else ([], [])
            filtered[device_id] = {
                "neighbors": list(neighbors),
                "weights": list(weights),
            }
    return filtered


def get_neighbors(network: Network, device_id: str) -> list[str]:
    """Get the neighbor IDs for a device.

    Parameters
    ----------
    network : Network
        The network dict.
    device_id : str
        The device to look up.

    Returns
    -------
    list[str]
        List of neighbor device IDs, or empty list if not found.
    """
    entry = network.get(str(device_id), {})
    return entry.get("neighbors", [])
