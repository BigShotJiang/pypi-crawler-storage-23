"""Air quality domain module with EPA AQI presets and PM2.5 conversion."""

from __future__ import annotations

from elwood_spatial.bins import BinSpec

# Standard EPA 6-bin AQI categories
AQI_BINS = BinSpec.from_tuples([
    (0, 50),
    (51, 100),
    (101, 150),
    (151, 200),
    (201, 300),
    (301, 500),
])

# 12-bin modified percentile AQI from the paper
AQI_MODIFIED_BINS = BinSpec.from_dicts([
    {"cat": "G", "range": [0, 44.9]},
    {"cat": "GM", "range": [45, 55.9]},
    {"cat": "M", "range": [56, 95]},
    {"cat": "MUSG", "range": [95.1, 105.9]},
    {"cat": "USG", "range": [106, 145]},
    {"cat": "USGU", "range": [145.1, 155.9]},
    {"cat": "U", "range": [156, 195]},
    {"cat": "UVU", "range": [195.1, 210.9]},
    {"cat": "VU", "range": [211, 290]},
    {"cat": "VUH", "range": [290.1, 320.9]},
    {"cat": "H", "range": [321, 500]},
    {"cat": "BH", "range": [501, 99999]},
])

# EPA breakpoint tables (40 CFR 58 Appendix G.12.ii)
_PM_RANGE_LOW = [0.0, 9.1, 35.5, 55.5, 125.5, 225.5, 225.5]
_PM_RANGE_HIGH = [9.0, 35.4, 55.4, 125.4, 225.4, 325.4, 325.4]
_AQI_RANGE_LOW = [0, 51, 101, 151, 201, 301, 301]
_AQI_RANGE_HIGH = [50, 100, 150, 200, 300, 500, 500]


def _find_breakpoint_index(value: float, high_breakpoints: list[float]) -> int:
    """Find the breakpoint index for a value given the high breakpoints."""
    idx = 0
    for i, threshold in enumerate(high_breakpoints):
        if value > threshold:
            idx = i + 1
    return min(idx, len(high_breakpoints) - 1)


def pm25_to_aqi(pm25: float) -> int | None:
    """Convert PM2.5 concentration (µg/m³) to AQI using EPA breakpoints.

    Parameters
    ----------
    pm25 : float
        PM2.5 concentration in µg/m³.

    Returns
    -------
    int or None
        AQI value, or None if input is None.
    """
    if pm25 is None:
        return None
    if pm25 <= 0:
        return 0

    idx = _find_breakpoint_index(pm25, _PM_RANGE_HIGH)
    pm_hi = _PM_RANGE_HIGH[idx]
    pm_lo = _PM_RANGE_LOW[idx]
    aqi_hi = _AQI_RANGE_HIGH[idx]
    aqi_lo = _AQI_RANGE_LOW[idx]

    aqi = (aqi_hi - aqi_lo) / (pm_hi - pm_lo) * (pm25 - pm_lo) + aqi_lo
    return round(aqi)


def aqi_to_pm25(aqi: float) -> float | None:
    """Convert AQI value back to PM2.5 concentration (µg/m³).

    Parameters
    ----------
    aqi : float
        AQI value.

    Returns
    -------
    float or None
        PM2.5 concentration, or None if input is None.
    """
    if aqi is None:
        return None
    if aqi <= 0:
        return 0.0

    idx = _find_breakpoint_index(aqi, _AQI_RANGE_HIGH)
    pm_hi = _PM_RANGE_HIGH[idx]
    pm_lo = _PM_RANGE_LOW[idx]
    aqi_hi = _AQI_RANGE_HIGH[idx]
    aqi_lo = _AQI_RANGE_LOW[idx]

    pm25 = (pm_hi - pm_lo) / (aqi_hi - aqi_lo) * (aqi - aqi_lo) + pm_lo
    return round(pm25, 1)
