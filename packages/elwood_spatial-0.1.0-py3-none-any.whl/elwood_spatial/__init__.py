"""elwood-spatial: Information-theoretic outlier detection for spatial time series networks."""

from elwood_spatial._version import __version__
from elwood_spatial.bins import BinSpec, compute_bin_index, compute_bin_indices
from elwood_spatial.detect import (
    PARAMS_OPERATIONAL,
    DetectionParams,
    detect_outliers,
    detect_outliers_batch,
    is_outlier,
)
from elwood_spatial.entropy import (
    bin_deviation,
    bin_probabilities,
    compute_network_metrics,
    entropy_at_agreement,
    information_content,
    shannon_entropy,
)
from elwood_spatial.features import (
    add_neighbor_deviation_features,
    add_network_features,
    add_rolling_features,
    coefficient_of_variation,
)
from elwood_spatial.network import build_network, filter_network, get_neighbors

__all__ = [
    "__version__",
    # bins
    "BinSpec",
    "compute_bin_index",
    "compute_bin_indices",
    # entropy
    "bin_probabilities",
    "shannon_entropy",
    "information_content",
    "bin_deviation",
    "compute_network_metrics",
    "entropy_at_agreement",
    # network
    "build_network",
    "filter_network",
    "get_neighbors",
    # detect
    "DetectionParams",
    "PARAMS_OPERATIONAL",
    "is_outlier",
    "detect_outliers",
    "detect_outliers_batch",
    # features
    "coefficient_of_variation",
    "add_rolling_features",
    "add_network_features",
    "add_neighbor_deviation_features",
]
