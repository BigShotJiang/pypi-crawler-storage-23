"""Rule-based outlier detection using information-theoretic metrics (Eq. 4)."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from elwood_spatial.bins import BinSpec
from elwood_spatial.entropy import (
    bin_deviation,
    information_content,
    shannon_entropy,
)
from elwood_spatial.network import Network, get_neighbors


@dataclass(frozen=True)
class DetectionParams:
    """Parameters for rule-based outlier detection.

    Parameters
    ----------
    theta : float
        Information content threshold. A device is suspicious when its
        information content >= theta.
    entropy_limit : float
        Network entropy ceiling. Detection only fires when network
        entropy < entropy_limit (indicating neighborhood agreement).
    beta : float
        Bin deviation divisor. The bin deviation threshold is
        ``num_bins / beta``.
    """

    theta: float
    entropy_limit: float
    beta: float


# Operational defaults from the paper / production system
PARAMS_OPERATIONAL = DetectionParams(theta=1.75, entropy_limit=1.75, beta=3.5)


def is_outlier(
    information: float,
    entropy: float,
    bin_dev: float,
    num_bins: int,
    params: DetectionParams,
) -> bool:
    """Apply the rule-based detection equation (Eq. 4 from the paper).

    A device is flagged as an outlier when all three conditions hold:
    1. Information content >= theta
    2. Network entropy < entropy_limit
    3. Bin deviation >= num_bins / beta

    Parameters
    ----------
    information : float
        Shannon information content of the target device.
    entropy : float
        Shannon entropy of the neighborhood.
    bin_dev : float
        Bin deviation of the target from its neighbors.
    num_bins : int
        Total number of bins in the BinSpec.
    params : DetectionParams
        Detection thresholds.

    Returns
    -------
    bool
        True if the device is flagged as an outlier.
    """
    return (
        information >= params.theta
        and entropy < params.entropy_limit
        and bin_dev >= (num_bins / params.beta)
    )


def detect_outliers(
    values: dict[str, float],
    bins: BinSpec,
    network: Network,
    params: DetectionParams,
    target_id: str | None = None,
) -> dict[str, bool]:
    """Detect outliers across a network of devices for a single timestep.

    For each device (or just ``target_id`` if specified), computes the
    information-theoretic metrics from its neighborhood and applies the
    rule-based detection.

    Parameters
    ----------
    values : dict[str, float]
        Mapping from device ID to its current measurement value.
    bins : BinSpec
        Bin specification for discretizing values.
    network : Network
        Spatial network dict.
    params : DetectionParams
        Detection thresholds.
    target_id : str or None
        If provided, only evaluate this device.

    Returns
    -------
    dict[str, bool]
        Mapping from device ID to outlier flag.
    """
    results: dict[str, bool] = {}
    device_ids = [target_id] if target_id is not None else list(network.keys())

    for device_id in device_ids:
        if device_id not in values:
            results[device_id] = False
            continue

        neighbors = get_neighbors(network, device_id)
        if not neighbors:
            results[device_id] = False
            continue

        # Build bin indices for the neighborhood (target + neighbors)
        neighborhood_ids = [device_id] + [n for n in neighbors if n in values]
        bin_indices = [bins.bin_index(values[did]) for did in neighborhood_ids]

        # Filter out devices with invalid bin indices
        valid = [(did, bi) for did, bi in zip(neighborhood_ids, bin_indices) if bi >= 0]
        if len(valid) < 2:
            results[device_id] = False
            continue

        valid_ids, valid_bins = zip(*valid)
        target_bin = bins.bin_index(values[device_id])
        if target_bin < 0:
            results[device_id] = False
            continue

        all_bins = list(valid_bins)
        other_bins = [bi for did, bi in valid if did != device_id]

        h = shannon_entropy(all_bins)
        ic = information_content(target_bin, all_bins)
        bd = bin_deviation(target_bin, other_bins)

        results[device_id] = is_outlier(ic, h, bd, bins.num_bins, params)

    return results


def detect_outliers_batch(
    df: pd.DataFrame,
    bins: BinSpec,
    network: Network,
    params: DetectionParams,
    id_column: str = "id",
    time_column: str = "timestamp",
    value_column: str = "value",
) -> pd.DataFrame:
    """Detect outliers across a DataFrame of time series observations.

    Applies ``detect_outliers`` at each unique timestamp.

    Parameters
    ----------
    df : DataFrame
        Must contain columns for device ID, timestamp, and measurement value.
    bins : BinSpec
        Bin specification for discretizing values.
    network : Network
        Spatial network dict.
    params : DetectionParams
        Detection thresholds.
    id_column : str
        Column name for device IDs.
    time_column : str
        Column name for timestamps.
    value_column : str
        Column name for measurement values.

    Returns
    -------
    DataFrame
        Input DataFrame with added columns: ``bin_index``, ``is_outlier``,
        ``information``, ``entropy``, ``bin_deviation``.
    """
    df = df.copy()
    df["bin_index"] = bins.bin_values(df[value_column].values)
    df["is_outlier"] = False
    df["information"] = 0.0
    df["entropy"] = 0.0
    df["bin_deviation"] = 0.0

    for ts, group in df.groupby(time_column):
        values_at_ts = dict(zip(group[id_column], group[value_column]))
        outlier_flags = detect_outliers(values_at_ts, bins, network, params)

        # Compute per-device metrics for this timestep
        for device_id in group[id_column].unique():
            mask = (df[time_column] == ts) & (df[id_column] == device_id)
            if device_id in outlier_flags:
                df.loc[mask, "is_outlier"] = outlier_flags[device_id]

            # Compute metrics
            neighbors = get_neighbors(network, device_id)
            neighborhood_ids = [device_id] + [n for n in neighbors if n in values_at_ts]
            bin_indices = [bins.bin_index(values_at_ts[did]) for did in neighborhood_ids if did in values_at_ts]
            valid_bins = [bi for bi in bin_indices if bi >= 0]

            if len(valid_bins) >= 2:
                target_bin = bins.bin_index(values_at_ts.get(device_id, float("nan")))
                if target_bin >= 0:
                    other_bins = [bi for did, bi in zip(neighborhood_ids, bin_indices) if did != device_id and did in values_at_ts and bi >= 0]
                    df.loc[mask, "entropy"] = shannon_entropy(valid_bins)
                    df.loc[mask, "information"] = information_content(target_bin, valid_bins)
                    df.loc[mask, "bin_deviation"] = bin_deviation(target_bin, other_bins)

    return df
