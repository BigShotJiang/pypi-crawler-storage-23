"""Feature engineering for ML-based outlier detection."""

from __future__ import annotations

import numpy as np
import pandas as pd

from elwood_spatial.bins import BinSpec
from elwood_spatial.entropy import (
    bin_deviation,
    information_content,
    shannon_entropy,
)
from elwood_spatial.network import Network, get_neighbors


def coefficient_of_variation(values: pd.Series | np.ndarray) -> float:
    """Compute the coefficient of variation (CV) as a percentage.

    Parameters
    ----------
    values : Series or array-like
        Numeric values.

    Returns
    -------
    float
        CV as a percentage (std/mean * 100). Returns NaN if mean is zero
        or if computation fails.
    """
    values = np.asarray(values, dtype=float)
    values = values[~np.isnan(values)]
    if len(values) == 0:
        return float("nan")
    mean = np.mean(values)
    if mean == 0:
        return float("nan")
    std = np.std(values, ddof=1) if len(values) > 1 else 0.0
    return float((std / mean) * 100)


def add_rolling_features(
    df: pd.DataFrame,
    id_column: str = "id",
    time_column: str = "timestamp",
    value_column: str = "value",
    windows: list[str] = None,
) -> pd.DataFrame:
    """Add rolling statistical features per device.

    Computes rolling coefficient of variation, delta (change), range,
    directionality, measurement entropy proxy, and outage indicators.

    Parameters
    ----------
    df : DataFrame
        Input data with device ID, timestamp, and value columns.
    id_column : str
        Column for device IDs.
    time_column : str
        Column for timestamps (must be datetime-like).
    value_column : str
        Column for measurement values.
    windows : list of str
        Pandas offset strings for rolling windows (e.g., ["3h", "6h"]).
        Defaults to ["3h", "6h"].

    Returns
    -------
    DataFrame
        Input with added feature columns.
    """
    if windows is None:
        windows = ["3h", "6h"]

    df = df.copy()
    df = df.sort_values([id_column, time_column]).reset_index(drop=True)

    for window in windows:
        suffix = window.replace("h", "H")
        cv_col = f"cv_{suffix}"
        range_col = f"range_{suffix}"
        std_col = f"std_{suffix}"

        df[cv_col] = np.nan
        df[range_col] = np.nan
        df[std_col] = np.nan

        for device_id, idx in df.groupby(id_column).groups.items():
            sub = df.loc[idx].set_index(time_column)
            rolling = sub[value_column].rolling(window, min_periods=2)
            df.loc[idx, cv_col] = rolling.apply(
                lambda x: coefficient_of_variation(x), raw=True
            ).values
            df.loc[idx, range_col] = (rolling.max() - rolling.min()).values
            df.loc[idx, std_col] = rolling.std().values

    # Per-device delta and directionality (not window-dependent)
    df = df.sort_values([id_column, time_column]).reset_index(drop=True)
    df["delta"] = df.groupby(id_column)[value_column].diff()
    df["directionality"] = np.sign(df["delta"])

    # Outage indicator: flag if value is NaN
    df["outage"] = df[value_column].isna().astype(int)

    return df


def add_network_features(
    df: pd.DataFrame,
    network: Network,
    bins: BinSpec,
    id_column: str = "id",
    time_column: str = "timestamp",
    value_column: str = "value",
) -> pd.DataFrame:
    """Add information-theoretic network features per device per timestep.

    Computes network entropy, information content, bin deviation, and
    neighbor count for each observation.

    Parameters
    ----------
    df : DataFrame
        Input data.
    network : Network
        Spatial network dict.
    bins : BinSpec
        Bin specification for discretizing values.
    id_column : str
        Column for device IDs.
    time_column : str
        Column for timestamps.
    value_column : str
        Column for measurement values.

    Returns
    -------
    DataFrame
        Input with added columns: ``network_entropy``, ``information``,
        ``bin_deviation``, ``neighbor_count``.
    """
    df = df.copy()
    df["network_entropy"] = 0.0
    df["information"] = 0.0
    df["bin_deviation"] = 0.0
    df["neighbor_count"] = 0

    for ts, group in df.groupby(time_column):
        values_at_ts = dict(zip(group[id_column], group[value_column]))

        for device_id in group[id_column].unique():
            mask = (df[time_column] == ts) & (df[id_column] == device_id)
            neighbors = get_neighbors(network, device_id)
            active_neighbors = [n for n in neighbors if n in values_at_ts]
            df.loc[mask, "neighbor_count"] = len(active_neighbors)

            neighborhood_ids = [device_id] + active_neighbors
            bin_indices = []
            for did in neighborhood_ids:
                if did in values_at_ts:
                    val = values_at_ts[did]
                    if pd.notna(val):
                        bi = bins.bin_index(val)
                        if bi >= 0:
                            bin_indices.append((did, bi))

            if len(bin_indices) < 2:
                continue

            all_bins = [bi for _, bi in bin_indices]
            target_bin = bins.bin_index(values_at_ts.get(device_id, float("nan")))
            if target_bin < 0:
                continue

            other_bins = [bi for did, bi in bin_indices if did != device_id]

            df.loc[mask, "network_entropy"] = shannon_entropy(all_bins)
            df.loc[mask, "information"] = information_content(target_bin, all_bins)
            df.loc[mask, "bin_deviation"] = bin_deviation(target_bin, other_bins)

    return df


def add_neighbor_deviation_features(
    df: pd.DataFrame,
    network: Network,
    feature_columns: list[str],
    id_column: str = "id",
    time_column: str = "timestamp",
) -> pd.DataFrame:
    """Add neighbor deviation features for specified columns.

    For each feature column, computes the absolute deviation of the device's
    value from the mean of its neighbors' values at the same timestep.

    Parameters
    ----------
    df : DataFrame
        Input data with feature columns already computed.
    network : Network
        Spatial network dict.
    feature_columns : list of str
        Column names to compute neighbor deviations for.
    id_column : str
        Column for device IDs.
    time_column : str
        Column for timestamps.

    Returns
    -------
    DataFrame
        Input with added ``{col}_neighbor_dev`` columns.
    """
    df = df.copy()
    for col in feature_columns:
        df[f"{col}_neighbor_dev"] = 0.0

    for ts, group in df.groupby(time_column):
        for device_id in group[id_column].unique():
            mask = (df[time_column] == ts) & (df[id_column] == device_id)
            neighbors = get_neighbors(network, device_id)
            neighbor_rows = group[group[id_column].isin(neighbors)]

            if len(neighbor_rows) == 0:
                continue

            device_row = group[group[id_column] == device_id]
            if len(device_row) == 0:
                continue

            for col in feature_columns:
                device_val = device_row[col].iloc[0]
                neighbor_mean = neighbor_rows[col].mean()
                if pd.notna(device_val) and pd.notna(neighbor_mean):
                    df.loc[mask, f"{col}_neighbor_dev"] = abs(device_val - neighbor_mean)

    return df
