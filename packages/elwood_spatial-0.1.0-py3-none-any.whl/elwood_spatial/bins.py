"""Generic bin definition and validation for discretizing continuous values."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class BinSpec:
    """Validated, immutable specification of contiguous value bins.

    Each bin is defined by a (low, high) tuple. Values are assigned to the
    first bin whose range contains them (inclusive on both ends).

    Parameters
    ----------
    edges : tuple[tuple[float, float], ...]
        Sequence of (low, high) pairs defining each bin.
    labels : tuple[str, ...] | None
        Optional category labels, one per bin.
    """

    edges: tuple[tuple[float, float], ...]
    labels: tuple[str, ...] | None = None

    def __post_init__(self):
        if len(self.edges) == 0:
            raise ValueError("BinSpec requires at least one bin.")
        for i, (lo, hi) in enumerate(self.edges):
            if lo > hi:
                raise ValueError(f"Bin {i}: low ({lo}) > high ({hi}).")
        if self.labels is not None and len(self.labels) != len(self.edges):
            raise ValueError(
                f"labels length ({len(self.labels)}) != edges length ({len(self.edges)})."
            )

    @classmethod
    def from_tuples(cls, bins: Sequence[tuple[float, float]]) -> BinSpec:
        """Create a BinSpec from a sequence of (low, high) tuples.

        >>> BinSpec.from_tuples([(0, 50), (51, 100)])
        BinSpec(edges=((0, 50), (51, 100)), labels=None)
        """
        return cls(edges=tuple(tuple(b) for b in bins))

    @classmethod
    def from_dicts(
        cls,
        bins: Sequence[dict],
        range_key: str = "range",
        label_key: str = "cat",
    ) -> BinSpec:
        """Create a BinSpec from a sequence of dicts with range and label keys.

        >>> BinSpec.from_dicts([{"cat": "Low", "range": [0, 50]}])
        BinSpec(edges=((0, 50),), labels=('Low',))
        """
        edges = tuple(tuple(b[range_key]) for b in bins)
        labels = tuple(b[label_key] for b in bins) if label_key in bins[0] else None
        return cls(edges=edges, labels=labels)

    @property
    def num_bins(self) -> int:
        """Number of bins."""
        return len(self.edges)

    def bin_index(self, value: float) -> int:
        """Return the bin index for a scalar value, or -1 if out of range.

        Returns ``-1`` if the value falls outside all bins.
        Returns ``-1`` for NaN or None values.
        """
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return -1
        for i, (lo, hi) in enumerate(self.edges):
            if lo <= value <= hi:
                return i
        return -1

    def bin_values(self, values: np.ndarray) -> np.ndarray:
        """Vectorized bin assignment for an array of values.

        Parameters
        ----------
        values : array-like
            1-D array of numeric values.

        Returns
        -------
        np.ndarray
            Integer array of bin indices. Out-of-range values get ``-1``.
        """
        values = np.asarray(values, dtype=float)
        result = np.full(values.shape, -1, dtype=int)
        for i, (lo, hi) in enumerate(self.edges):
            mask = (values >= lo) & (values <= hi) & (result == -1)
            result[mask] = i
        return result


def compute_bin_index(value: float, bins: BinSpec) -> int:
    """Return the bin index for a scalar value.

    Convenience wrapper around ``BinSpec.bin_index``.
    """
    return bins.bin_index(value)


def compute_bin_indices(values: np.ndarray, bins: BinSpec) -> np.ndarray:
    """Return bin indices for an array of values.

    Convenience wrapper around ``BinSpec.bin_values``.
    """
    return bins.bin_values(values)
