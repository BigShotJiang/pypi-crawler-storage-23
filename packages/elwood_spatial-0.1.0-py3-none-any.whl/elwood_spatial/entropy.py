"""Information-theoretic core: Shannon entropy, information content, and bin deviation."""

from __future__ import annotations

import math
from collections import Counter
from typing import Sequence


def bin_probabilities(bin_indices: Sequence[int]) -> dict[int, float]:
    """Compute the probability distribution over bin indices.

    Parameters
    ----------
    bin_indices : sequence of int
        Bin index for each device in the neighborhood.

    Returns
    -------
    dict[int, float]
        Mapping from bin index to its probability.
    """
    counts = Counter(bin_indices)
    total = len(bin_indices)
    return {k: v / total for k, v in counts.items()}


def shannon_entropy(bin_indices: Sequence[int]) -> float:
    """Compute Shannon entropy H = -sum(p * log2(p)) over bin indices.

    Parameters
    ----------
    bin_indices : sequence of int
        Bin index for each device in the neighborhood.

    Returns
    -------
    float
        Shannon entropy in bits. Returns 0.0 for empty input.
    """
    if len(bin_indices) == 0:
        return 0.0
    probs = bin_probabilities(bin_indices)
    entropy = 0.0
    for p in probs.values():
        if p > 0:
            entropy -= p * math.log2(p)
    return entropy


def information_content(bin_index: int, bin_indices: Sequence[int]) -> float:
    """Compute Shannon information content I_k = -log2(p_k) for a specific bin.

    Parameters
    ----------
    bin_index : int
        The bin index of the target device.
    bin_indices : sequence of int
        Bin indices for all devices in the neighborhood (including target).

    Returns
    -------
    float
        Information content in bits. Returns 0.0 if the bin is not present.
    """
    if len(bin_indices) == 0:
        return 0.0
    probs = bin_probabilities(bin_indices)
    p = probs.get(bin_index, 0)
    if p <= 0:
        return 0.0
    return -math.log2(p)


def bin_deviation(bin_index: int, other_bin_indices: Sequence[int]) -> float:
    """Compute bin deviation D_k = |B_k - mean(B_j)| for a target device.

    Parameters
    ----------
    bin_index : int
        The bin index of the target device.
    other_bin_indices : sequence of int
        Bin indices for the neighbor devices (excluding the target).

    Returns
    -------
    float
        Absolute deviation of the target bin from the neighbor mean.
        Returns 0.0 if there are no neighbors.
    """
    if len(other_bin_indices) == 0:
        return 0.0
    mean_other = sum(other_bin_indices) / len(other_bin_indices)
    return abs(bin_index - mean_other)


def compute_network_metrics(
    bin_indices: dict[str, int],
) -> dict[str, dict[str, float]]:
    """Compute per-device entropy, information, and bin deviation for a network.

    Parameters
    ----------
    bin_indices : dict[str, int]
        Mapping from device ID to its bin index.

    Returns
    -------
    dict[str, dict[str, float]]
        Per-device dict with keys ``entropy``, ``information``, ``bin_deviation``.
    """
    all_indices = list(bin_indices.values())
    h = shannon_entropy(all_indices)
    results = {}
    for device_id, idx in bin_indices.items():
        others = [v for k, v in bin_indices.items() if k != device_id]
        results[device_id] = {
            "entropy": h,
            "information": information_content(idx, all_indices),
            "bin_deviation": bin_deviation(idx, others),
        }
    return results


def entropy_at_agreement(
    n_devices: int,
    agreement_fraction: float = 0.75,
    n_bins: int = 12,
) -> float:
    """Compute theoretical entropy when a fraction of devices agree.

    Calculates the Shannon entropy when ``agreement_fraction`` of devices
    fall in one bin and the remainder are spread evenly across other bins.

    Parameters
    ----------
    n_devices : int
        Total number of devices.
    agreement_fraction : float
        Fraction of devices in the dominant bin.
    n_bins : int
        Total number of bins.

    Returns
    -------
    float
        Theoretical Shannon entropy in bits.
    """
    if n_devices == 0:
        return 0.0

    dominant_count = int(round(agreement_fraction * n_devices))
    remaining = n_devices - dominant_count
    other_bins = n_bins - 1

    counts = [0] * n_bins
    counts[0] = dominant_count

    if other_bins > 0:
        base = remaining // other_bins
        extra = remaining % other_bins
        for i in range(1, n_bins):
            counts[i] = base + (1 if i - 1 < extra else 0)

    entropy = 0.0
    for count in counts:
        if count > 0:
            p = count / n_devices
            entropy -= p * math.log2(p)

    return entropy
