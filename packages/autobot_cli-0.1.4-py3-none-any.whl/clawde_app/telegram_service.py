from __future__ import annotations

import asyncio
import logging
import os
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .activity_feed import activity_feed
from .actions import ActionExecContext, ActionExecutor
from .agent_profile import resolve_agent, ensure_agent_scaffold
from .agent_tag import extract_agent_tag
from .backend_tag import extract_backend_tag
from .claude_runner import ClaudeRunner
from .codex_runner import CodexRunner
from .gemini_runner import GeminiRunner
from pydantic import SecretStr
from .config import AgentConfig, AppConfig, AppPaths
from .context_builder import ContextBuilder
from .db import Database
from .formatting import format_and_split_for_telegram, format_telegram_html, needs_send_as_file
from .models import (
    ChatStatus,
    EventRole,
    EventSource,
    RunMode,
    StructuredResponse,
)
from .security import generate_pairing_code, should_respond_in_group


# python-telegram-bot is required at runtime
try:
    from telegram import Update
    from telegram.constants import ChatAction, ParseMode
    from telegram.ext import (
        Application,
        ApplicationBuilder,
        CommandHandler,
        ContextTypes,
        MessageHandler,
        filters,
    )
except Exception as e:  # pragma: no cover
    raise RuntimeError(
        "python-telegram-bot is required. Install it (e.g. pip install python-telegram-bot)."
    ) from e


@dataclass
class TelegramSendResult:
    first_message_id: Optional[int]
    parts_sent: int


@dataclass
class ActiveRun:
    """Tracks a CLI run in progress for a specific chat, allowing cancellation.

    Created early (before pre-run setup) so /stop can find it immediately.
    Fields like task/progress_task are filled in later as the run progresses.
    """
    chat_id: int
    cancel_event: asyncio.Event  # set by _cancel_active_run; checked during setup
    task: Optional[asyncio.Task] = None
    proc: Optional[asyncio.subprocess.Process] = None
    pid: Optional[int] = None
    progress_task: Optional[asyncio.Task] = None
    progress_queue: Optional[asyncio.Queue] = None
    backend: Optional[str] = None
    run_id: Optional[int] = None
    cancelled: bool = False


log = logging.getLogger("clawde.telegram")


def _build_agent_edit_prompt(name: str, soul_content: str, topic_files: list[str]) -> str:
    """Build a system prompt for AI-powered agent profile editing."""
    topics_list = "\n".join(f"- `{f}`" for f in topic_files) if topic_files else "(none)"
    return (
        f"# Agent Profile Editor\n\n"
        f"You are editing the profile files for agent '{name}'.\n"
        f"Your working directory is the agent's profile directory.\n\n"
        f"## Files you can edit\n"
        f"- `soul.md` — Defines the agent's personality and behavior. Injected into every prompt.\n"
        f"- `memory/MEMORY.md` — Index of memory topics (keep short).\n"
        f"- `memory/topics/*.md` — Durable facts (user preferences, project info, etc.)\n\n"
        f"## Current soul.md\n{soul_content}\n\n"
        f"## Existing memory topics\n{topics_list}\n\n"
        f"## Guidelines\n"
        f"- Personality/behavior/identity changes → edit soul.md\n"
        f"- Remembering facts/preferences → write to memory/topics/*.md (create if needed), update MEMORY.md index\n"
        f"- Preserve existing content not contradicted by the instruction\n"
        f"- Keep soul.md concise — it's injected on every run\n"
        f"- Do NOT modify files outside this directory\n"
    )


class TelegramService:
    """
    Telegram gateway: sessionful chat mode using Claude Code `--resume <session_id>`.

    - Maintains per-chat locks so Claude sessions aren't interleaved.
    - Writes all inbound/outbound messages to the ledger (events table).
    - Builds a context pack each run and appends it to Claude system prompt.

    SchedulerService can use:
      - send_cron_post(...) to post a cron message and then ingest into session.
      - get_chat_lock(chat_id) to serialize with user messages.
    """

    def __init__(
        self,
        cfg: AppConfig,
        paths: AppPaths,
        db: Database,
        claude: ClaudeRunner,
        codex: CodexRunner,
        gemini: GeminiRunner,
        context_builder: ContextBuilder,
        actions: ActionExecutor,
        *,
        agent_name: str,
        agent_cfg: AgentConfig,
    ):
        self.cfg = cfg
        self.paths = paths
        self.db = db
        self.claude = claude
        self.codex = codex
        self.gemini = gemini
        self.context_builder = context_builder
        self.actions = actions
        self.agent_name = agent_name
        self.agent_cfg = agent_cfg

        self.app: Optional[Application] = None
        self.bot_username: Optional[str] = None

        # Set by main after both services are created.
        self.scheduler_service: Any = None

        self._chat_locks: Dict[int, asyncio.Lock] = {}
        self._active_runs: Dict[int, ActiveRun] = {}

    # ----------------------------
    # Runner selection
    # ----------------------------
    def _get_runner(self, backend: Optional[str] = None):
        """Return the appropriate runner based on backend string."""
        b = backend or self.agent_cfg.default_backend
        if b == "codex":
            return self.codex
        if b == "gemini":
            return self.gemini
        return self.claude

    @staticmethod
    def _parse_cli_timeout(env_value: str) -> Optional[int]:
        """Parse a CLI timeout environment value.

        Returns None for empty/invalid/<=0 values so callers keep default behavior.
        """
        raw = (env_value or "").strip()
        if not raw:
            return None
        try:
            parsed = int(raw)
        except ValueError:
            return None
        return parsed if parsed > 0 else None

    @staticmethod
    def _backend_for_runner(runner: object) -> str:
        if isinstance(runner, CodexRunner):
            return "codex"
        if isinstance(runner, GeminiRunner):
            return "gemini"
        return "claude"

    def _resolve_run_timeout(self, backend: Optional[str] = None) -> Optional[int]:
        backend_key = (backend or "claude").upper()
        timeout_candidates = [
            f"CLAWDE_{backend_key}_CLI_TIMEOUT_SECONDS",
            "CLAWDE_CLI_TIMEOUT_SECONDS",
        ]
        for key in timeout_candidates:
            val = os.getenv(key, "")
            timeout = self._parse_cli_timeout(val)
            if timeout is not None:
                return timeout
        return None

    # ----------------------------
    # Lifecycle
    # ----------------------------
    async def start(self) -> None:
        """
        Start Telegram polling (async, non-blocking).
        """
        token = self.agent_cfg.bot_token.get_secret_value()

        self.app = ApplicationBuilder().token(token).concurrent_updates(True).build()
        self._register_handlers(self.app)

        await self.app.initialize()
        await self.app.start()
        await self.app.updater.start_polling()

        # Determine username for mention detection in groups
        try:
            me = await self.app.bot.get_me()
            self.bot_username = me.username
        except Exception:
            self.bot_username = None

        # Register command menu with Telegram so commands show on /
        try:
            from telegram import BotCommand
            commands = [
                BotCommand("help", "Show available commands"),
                BotCommand("status", "Show pairing, session, profile, project"),
                BotCommand("mode", "Set tool profile (safe/read_only/dev/full)"),
                BotCommand("project", "Set working directory for Claude"),
                BotCommand("jobs", "List scheduled jobs"),
                BotCommand("job", "Add/enable/disable/delete a job"),
                BotCommand("backend", "Switch AI backend (claude/codex/gemini)"),
                BotCommand("model", "Set model override (e.g. sonnet, opus)"),
                BotCommand("reasoning", "Set reasoning effort (low/medium/high)"),
                BotCommand("clear", "Clear session, start fresh conversation"),
                BotCommand("memory", "Show memory or add a daily note"),
                BotCommand("agent", "Manage agents: list/add/remove/soul (admin)"),
                BotCommand("skill", "Manage skills: list/enable/disable"),
                BotCommand("stop", "Cancel the current AI run"),
                BotCommand("pair", "Pair this chat with a code"),
                BotCommand("activity", "Show recent activity feed"),
            ]
            if self.cfg.features.goals:
                commands.append(BotCommand("goal", "Manage goals: create/list/status/delete"))
            await self.app.bot.set_my_commands(commands)
        except Exception:
            pass

    async def stop(self) -> None:
        """
        Stop Telegram polling and shutdown application.
        """
        if not self.app:
            return
        try:
            await self.app.updater.stop()
        except Exception:
            pass
        try:
            await self.app.stop()
        except Exception:
            pass
        try:
            await self.app.shutdown()
        except Exception:
            pass
        self.app = None

    # ----------------------------
    # Locks
    # ----------------------------
    def get_chat_lock(self, chat_id: int) -> asyncio.Lock:
        lock = self._chat_locks.get(chat_id)
        if lock is None:
            lock = asyncio.Lock()
            self._chat_locks[chat_id] = lock
        return lock

    # ----------------------------
    # Run cancellation
    # ----------------------------
    def _on_run_proc_started(self, chat_id: int, proc: asyncio.subprocess.Process) -> None:
        """Called by the runner when the subprocess is created."""
        active = self._active_runs.get(chat_id)
        if active is not None:
            active.proc = proc
            active.pid = proc.pid

    async def _cancel_active_run(self, chat_id: int, reason: str = "cancelled") -> bool:
        """Cancel the active run for a chat. Returns True if a run was cancelled."""
        active = self._active_runs.pop(chat_id, None)
        if active is None:
            return False

        active.cancelled = True
        active.cancel_event.set()
        log.info("Cancelling active run for chat %d (reason: %s, pid: %s)",
                 chat_id, reason, active.pid)

        # 1. Kill the subprocess tree (most important — stops the CLI)
        if active.pid is not None:
            from .codex_runner import kill_process_tree
            kill_process_tree(active.pid)
        elif active.proc is not None:
            try:
                active.proc.kill()
            except Exception:
                pass

        # 2. Cancel the asyncio task (if it exists yet)
        if active.task is not None and not active.task.done():
            active.task.cancel()

        # 3. Stop the progress updater (if it exists yet)
        if active.progress_queue is not None:
            try:
                await active.progress_queue.put(None)
            except Exception:
                pass
        if active.progress_task is not None and not active.progress_task.done():
            active.progress_task.cancel()

        # 4. Wait briefly for cleanup
        for t in [active.task, active.progress_task]:
            if t is not None and not t.done():
                try:
                    await asyncio.wait_for(asyncio.shield(t), timeout=3.0)
                except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                    pass

        # 5. Mark the DB run as cancelled (if one was started)
        if active.run_id is not None:
            try:
                await self.db.finish_run(
                    run_id=active.run_id,
                    stdout_json=None,
                    exit_code=-2,
                    error=f"Run cancelled: {reason}",
                )
            except Exception:
                pass

        return True

    # ----------------------------
    # Public: Cron posting API
    # ----------------------------
    async def send_cron_post(self, chat_id: int, text: str, *, job_id: int, job_name: str, skip_ingest: bool = False) -> None:
        """
        Post a cron-generated assistant message into Telegram AND ingest it into the chat session
        so future chat turns "remember" it.

        IMPORTANT: Telegram bots do not receive updates for their own sent messages, so we must:
          - write the message to our ledger ourselves
          - optionally ingest it into the Claude session

        We always write to ledger. We ingest if a session exists.
        """
        async with self.get_chat_lock(chat_id):
            # Ensure chat exists; cron should only target paired chats, but be resilient.
            chat = await self.db.get_chat(self.agent_name, chat_id)
            if chat is None:
                # Create as paired to allow cron posting
                await self.db.create_chat(self.agent_name, chat_id, status=ChatStatus.paired, pairing_code=None, tool_profile="safe_chat")
                chat = await self.db.get_chat(self.agent_name, chat_id)

            # Send message to Telegram
            activity_feed.emit(self.agent_name, "run", f"Cron reply sent to chat {chat_id} (job #{job_id} {job_name})")
            send_res = await self._send_text(chat_id, text)
            telegram_message_id = send_res.first_message_id

            # Ledger write (assistant/cron)
            cron_event_id = await self.db.insert_event(
                agent_name=self.agent_name,
                chat_id=chat_id,
                role=EventRole.assistant,
                source=EventSource.cron,
                text=text,
                telegram_message_id=telegram_message_id,
                meta={"job_id": job_id, "job_name": job_name, "parts_sent": send_res.parts_sent},
            )
            self._append_daily_log("assistant", f"cron:{job_name}", text)

            # If chat has a session, ingest into session and advance last_ingested_event_id.
            # When skip_ingest=True (use_chat_session jobs), the message is already in the
            # shared session from the cron run itself — just advance the pointer.
            if skip_ingest:
                await self.db.update_last_ingested_event_id(self.agent_name, chat_id, cron_event_id)
            elif chat and chat.claude_session_id:
                ok = await self._ingest_assistant_message_into_session(
                    chat_id=chat_id,
                    session_id=chat.claude_session_id,
                    message_text=text,
                    job_id=job_id,
                    job_name=job_name,
                )
                if ok:
                    await self.db.update_last_ingested_event_id(self.agent_name, chat_id, cron_event_id)

    # ----------------------------
    # Handlers registration
    # ----------------------------
    def _register_handlers(self, app: Application) -> None:
        app.add_handler(CommandHandler("help", self._cmd_help))
        app.add_handler(CommandHandler("start", self._cmd_help))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("pair", self._cmd_pair))
        app.add_handler(CommandHandler("mode", self._cmd_mode))
        app.add_handler(CommandHandler("jobs", self._cmd_jobs))
        app.add_handler(CommandHandler("job", self._cmd_job))
        app.add_handler(CommandHandler("memory", self._cmd_memory))
        app.add_handler(CommandHandler("project", self._cmd_project))
        app.add_handler(CommandHandler("backend", self._cmd_backend))
        app.add_handler(CommandHandler("model", self._cmd_model))
        app.add_handler(CommandHandler("reasoning", self._cmd_reasoning))
        app.add_handler(CommandHandler("clear", self._cmd_clear))
        app.add_handler(CommandHandler("agent", self._cmd_agent))
        app.add_handler(CommandHandler("skill", self._cmd_skill))
        app.add_handler(CommandHandler("stop", self._cmd_stop))
        app.add_handler(CommandHandler("activity", self._cmd_activity))
        if self.cfg.features.goals:
            app.add_handler(CommandHandler("goal", self._cmd_goal))

        # Non-command text
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._on_text))

    # ----------------------------
    # Command handlers
    # ----------------------------
    async def _cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)

        help_text = (
            "clawde commands:\n"
            "- /status — show pairing + session + tool profile + project\n"
            "- /pair <code> — pair this chat\n"
            "- /mode safe|read_only|dev|full — set tool profile (dev/full require admin)\n"
            "- /project <path> — set working directory (admin only)\n"
            "- /project reset — reset to default (clawde repo)\n"
            "- /backend claude|codex|gemini — switch AI backend\n"
            "- /model <name> — set model override (e.g. sonnet, opus, gpt-5.3-codex)\n"
            "- /model default — reset to backend default\n"
            "- /reasoning <level> — set reasoning effort (low/medium/high)\n"
            "- /reasoning default — reset to default\n"
            "- /clear — clear session and start fresh\n"
            "- /jobs — list scheduled jobs\n"
            "- /job add <name> | <type> | <schedule> | <prompt> [| key=value ...]\n"
            "  Keys: tool_profile, backend, target_chat_id, timezone, model, thinking\n"
            "- /job set <id> key=value ... — modify job settings (use 'default' to clear)\n"
            "- /job enable <id>\n"
            "- /job disable <id>\n"
            "- /job delete <id>\n"
            "- /memory show — show MEMORY.md\n"
            "- /memory note <text> — append to today's daily log\n"
            "- /agent list — list configured agents\n"
            "- /agent add <name> <token> — create a new agent (admin)\n"
            "- /agent remove <name> — remove an agent (admin)\n"
            "- /agent soul <name> [text] — view/update agent personality (admin)\n"
            "- /agent update <name> <instruction> — AI-edit agent profile (admin)\n"
            "- /skill list — show skills with enabled/disabled status\n"
            "- /skill enable <name> — enable a skill for this chat\n"
            "- /skill disable <name> — disable a skill for this chat\n"
            "- /activity — show recent activity feed\n"
            "- /activity run — show active run log for this chat\n"
        )
        if self.cfg.features.goals:
            help_text += (
                "- /goal create <objective> — create a new goal workspace\n"
                "- /goal list — list active goals\n"
                "- /goal status [slug] — show goal status\n"
                "- /goal delete <slug> — remove a goal (admin)\n"
            )
        help_text += (
            "\nTip: You can also talk naturally; if you ask to schedule something, I may propose a job via actions."
        )
        await self._send_text(chat_id, help_text)

    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        row = await self.db.get_chat(self.agent_name, chat_id)
        if not row:
            await self._send_text(chat_id, "No chat state found.")
            return

        is_admin = self.agent_cfg.is_admin_chat(chat_id)
        session_short = (row.claude_session_id[:8] + "…") if row.claude_session_id else "(none)"
        project_display = row.project_dir if row.project_dir else "(default: clawde repo)"
        backend_display = row.backend if row.backend else f"(default: {self.agent_cfg.default_backend})"
        msg = (
            f"Status:\n"
            f"- agent: {self.agent_name}\n"
            f"- paired: {row.status == ChatStatus.paired.value}\n"
            f"- admin: {is_admin}\n"
            f"- backend: {backend_display}\n"
            f"- model: {row.model if row.model else '(default)'}\n"
            f"- reasoning: {row.thinking if row.thinking else '(default)'}\n"
            f"- tool_profile: {row.tool_profile}\n"
            f"- project_dir: {project_display}\n"
            f"- session_id: {session_short}\n"
            f"- last_ingested_event_id: {row.last_ingested_event_id}\n"
        )
        await self._send_text(chat_id, msg)

    async def _cmd_pair(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        row = await self._ensure_chat_row(chat_id)
        if row and row.status == ChatStatus.paired.value:
            await self._send_text(chat_id, "✅ This chat is already paired.")
            return

        args = context.args or []
        if not args:
            # Show pairing code
            row = await self.db.get_chat(self.agent_name, chat_id)
            code = row.pairing_code if row else None
            await self._send_text(chat_id, f"Send `/pair {code}` to pair this chat.",)
            return

        code = args[0].strip()
        row = await self.db.get_chat(self.agent_name, chat_id)
        if not row:
            await self._send_text(chat_id, "No pairing request found. Send any message first.")
            return

        if code and row.pairing_code and code == row.pairing_code:
            await self.db.update_chat_status(self.agent_name, chat_id, ChatStatus.paired, pairing_code=None)
            await self._send_text(chat_id, "✅ Paired. You can now chat normally.")
        else:
            await self._send_text(chat_id, "❌ Pairing code incorrect. Use /pair to see your code.")

    async def _cmd_mode(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        is_admin = self.agent_cfg.is_admin_chat(chat_id)

        args = context.args or []
        if not args:
            await self._send_text(chat_id, "Usage: /mode safe|read_only|dev|full")
            return

        mode = args[0].strip().lower()
        mapping = {
            "safe": "safe_chat",
            "safe_chat": "safe_chat",
            "read_only": "read_only",
            "readonly": "read_only",
            "dev": "dev",
            "full": "full",
        }
        profile = mapping.get(mode)
        if not profile:
            await self._send_text(chat_id, "Unknown mode. Use: safe, read_only, dev, full")
            return

        if profile in ("dev", "full") and not is_admin:
            await self._send_text(chat_id, "⚠️ Only admins can enable dev/full mode.")
            return

        if profile != "safe_chat" and profile not in self.cfg.claude.tool_profiles:
            await self._send_text(chat_id, f"⚠️ Tool profile `{profile}` is not configured in config.yaml.")
            return

        await self.db.update_chat_tool_profile(self.agent_name, chat_id, profile)
        await self._send_text(chat_id, f"✅ Tool profile set to `{profile}`.")

    async def _cmd_project(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        is_admin = self.agent_cfg.is_admin_chat(chat_id)

        args = context.args or []
        if not args:
            row = await self.db.get_chat(self.agent_name, chat_id)
            current = row.project_dir if row and row.project_dir else "(default: clawde repo)"
            await self._send_text(
                chat_id,
                f"Current project directory: {current}\n\n"
                "Usage: /project <absolute_path> or /project reset",
            )
            return

        if args[0].strip().lower() == "reset":
            await self.db.update_chat_project_dir(self.agent_name, chat_id, None)
            await self._send_text(chat_id, "Project directory reset to default (clawde repo). Session cleared.")
            return

        if not is_admin:
            await self._send_text(chat_id, "Only admins can set the project directory.")
            return

        raw_path = " ".join(args).strip()
        p = Path(raw_path)
        if not p.is_absolute():
            await self._send_text(chat_id, "Path must be absolute.")
            return
        if not p.exists():
            await self._send_text(chat_id, f"Directory does not exist: {raw_path}")
            return
        if not p.is_dir():
            await self._send_text(chat_id, f"Path is not a directory: {raw_path}")
            return

        await self.db.update_chat_project_dir(self.agent_name, chat_id, str(p))
        await self._send_text(chat_id, f"Project directory set to: {p}\nSession cleared (new codebase context).")

    async def _cmd_backend(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)

        args = context.args or []
        if not args:
            row = await self.db.get_chat(self.agent_name, chat_id)
            current = row.backend if row and row.backend else self.agent_cfg.default_backend
            await self._send_text(
                chat_id,
                f"Current backend: {current}\n\nUsage: /backend claude|codex|gemini",
            )
            return

        requested = args[0].strip().lower()
        if requested not in ("claude", "codex", "gemini"):
            await self._send_text(chat_id, "Unknown backend. Use: /backend claude, codex, or gemini")
            return

        await self.db.update_chat_backend(self.agent_name, chat_id, requested)
        await self._send_text(chat_id, f"Backend switched to `{requested}`. Session cleared (sessions are not cross-compatible).")

    _MODEL_HINTS = {
        "claude": "sonnet, opus, haiku",
        "codex": "gpt-5.3-codex, gpt-5.3-codex-spark, gpt-5.2-codex",
        "gemini": "gemini-2.5-pro, gemini-2.5-flash, gemini-3-pro-preview",
    }
    _REASONING_HINTS = {
        "claude": "low, medium, high",
        "codex": "minimal, low, medium, high, xhigh",
        "gemini": "(not supported)",
    }

    async def _cmd_model(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)

        row = await self.db.get_chat(self.agent_name, chat_id)
        backend = (row.backend if row and row.backend else self.agent_cfg.default_backend) or "claude"
        known = self._MODEL_HINTS.get(backend, self._MODEL_HINTS["claude"])

        args = context.args or []
        if not args:
            current = row.model if row and row.model else "(default)"
            await self._send_text(
                chat_id,
                f"Current model: {current}\n"
                f"Backend: {backend}\n\n"
                f"Known models: {known}\n"
                "Or any custom model name/alias.\n\n"
                "Usage: /model <name> or /model default",
            )
            return

        requested = args[0].strip()
        if requested.lower() == "default":
            await self.db.update_chat_model(self.agent_name, chat_id, None)
            await self._send_text(chat_id, "Model reset to default.")
        else:
            await self.db.update_chat_model(self.agent_name, chat_id, requested)
            await self._send_text(chat_id, f"Model set to `{requested}`.")

    async def _cmd_reasoning(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)

        row = await self.db.get_chat(self.agent_name, chat_id)
        backend = (row.backend if row and row.backend else self.agent_cfg.default_backend) or "claude"
        levels = self._REASONING_HINTS.get(backend, self._REASONING_HINTS["claude"])

        args = context.args or []
        if not args:
            current = row.thinking if row and row.thinking else "(default)"
            await self._send_text(
                chat_id,
                f"Current reasoning effort: {current}\n"
                f"Backend: {backend}\n\n"
                f"Levels: {levels}\n\n"
                "Usage: /reasoning <level> or /reasoning default",
            )
            return

        requested = args[0].strip().lower()
        if requested == "default":
            await self.db.update_chat_thinking(self.agent_name, chat_id, None)
            await self._send_text(chat_id, "Reasoning effort reset to default.")
        else:
            await self.db.update_chat_thinking(self.agent_name, chat_id, requested)
            await self._send_text(chat_id, f"Reasoning effort set to `{requested}`.")

    async def _cmd_stop(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        cancelled = await self._cancel_active_run(chat_id, reason="/stop command")
        if cancelled:
            await self._send_text(chat_id, "Stopped.")
        else:
            await self._send_text(chat_id, "Nothing running.")

    async def _cmd_activity(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Show recent activity feed or active run log."""
        import datetime as _dt

        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        args = context.args or []
        subcommand = args[0].lower() if args else ""

        # --- /activity run — tail the active run's log file for this chat ---
        if subcommand == "run":
            active = self._active_runs.get(chat_id)
            if not active:
                await self._send_text(chat_id, "No active run in this chat.")
                return

            if active.run_id:
                run_data = await self.db.get_run(str(active.run_id))
                log_file = run_data.get("log_file") if run_data else None
                if log_file and Path(log_file).exists():
                    try:
                        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
                            all_lines = f.readlines()
                        tail = all_lines[-30:]
                        tail_text = "".join(tail).strip()
                        if tail_text:
                            max_len = 3400
                            if len(tail_text) > max_len:
                                tail_text = "...\n" + tail_text[-(max_len - 4):]
                            header = f"Active run log (last {len(tail)} lines):\n\n"
                            await self._send_text(chat_id, header + tail_text)
                            return
                    except Exception:
                        pass

            backend_label = active.backend or "claude"
            await self._send_text(
                chat_id,
                f"Active run (backend: {backend_label}, pid: {active.pid or '?'}) — log not available yet.",
            )
            return

        # --- /activity — global activity feed from ring buffer ---
        buffer = activity_feed.get_buffer()

        if not buffer:
            await self._send_text(chat_id, "No recent activity.")
            return

        max_events = 30
        tail = buffer[-max_events:]

        lines = []
        for event in tail:
            ts = event.get("ts", 0)
            agent = event.get("agent", "?")
            summary = event.get("summary", "")
            time_str = _dt.datetime.fromtimestamp(ts).strftime("%H:%M:%S")
            if len(summary) > 100:
                summary = summary[:97] + "..."
            lines.append(f"{time_str} [{agent}] {summary}")

        header = "Recent activity:\n\n"
        body = "\n".join(lines)

        max_len = 3400
        while len(header) + len(body) > max_len and lines:
            lines.pop(0)
            body = "\n".join(lines)

        await self._send_text(chat_id, header + body)

    async def _cmd_clear(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        await self.db.clear_chat_session(self.agent_name, chat_id)
        await self._send_text(
            chat_id,
            "Session cleared. Next message starts a fresh conversation.",
        )

    async def _cmd_jobs(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        is_admin = self.agent_cfg.is_admin_chat(chat_id)

        jobs = await self.db.list_jobs(enabled_only=False)
        if not is_admin:
            jobs = [j for j in jobs if j.get("target_chat_id") == chat_id]

        if not jobs:
            await self._send_text(chat_id, "No jobs found.")
            return

        lines = ["Jobs:"]
        for j in jobs:
            jid = j["job_id"]
            name = j["name"]
            enabled = bool(j["enabled"])
            stype = j["schedule_type"]
            sval = j["schedule_value"]
            target = j.get("target_chat_id")
            sf = " 🔄" if bool(j.get("sessionful", 0)) else ""
            pdir = j.get("project_dir")
            pdir_label = f" cwd={Path(pdir).name}" if pdir else ""
            model_label = f" model={j['model']}" if j.get("model") else ""
            thinking_label = f" thinking={j['thinking']}" if j.get("thinking") else ""
            lines.append(f"- #{jid} {'✅' if enabled else '⏸️'}{sf} {name} [{stype}] `{sval}` target={target}{pdir_label}{model_label}{thinking_label}")
        await self._send_text(chat_id, "\n".join(lines))

    async def _cmd_job(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        /job add ...
        /job enable <id>
        /job disable <id>
        /job delete <id>
        """
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        is_admin = self.agent_cfg.is_admin_chat(chat_id)

        raw = update.effective_message.text or ""
        # strip "/job"
        rest = raw.split(" ", 1)[1].strip() if " " in raw else ""

        if not rest:
            await self._send_text(chat_id, "Usage: /job add|enable|disable|delete ... (see /help)")
            return

        sub = rest.split(" ", 1)[0].strip().lower()
        arg_rest = rest.split(" ", 1)[1].strip() if " " in rest else ""

        if sub == "add":
            # Pipe-separated: name | type | schedule | prompt | [key=value ...]
            parts = [p.strip() for p in arg_rest.split("|")] if arg_rest else []
            if len(parts) < 4:
                await self._send_text(
                    chat_id,
                    "Usage:\n"
                    "/job add <name> | <cron|interval|once> | <schedule> | <prompt>"
                    " [| key=value ...]\n"
                    "Keys: tool_profile, backend, target_chat_id, timezone, model, thinking\n"
                    "Example:\n"
                    "/job add morning_digest | cron | 0 9 * * * | Write my morning digest."
                    " | model=sonnet",
                )
                return

            name = parts[0]
            stype = parts[1].lower()
            schedule_value = parts[2]
            prompt = parts[3]
            extras = parts[4:] if len(parts) > 4 else []

            # Inherit defaults from current chat state
            chat_row = await self.db.get_chat(self.agent_name, chat_id)
            tool_profile = (chat_row.tool_profile if chat_row else None) or "read_only"
            target_chat_id = chat_id
            timezone_str = self.cfg.scheduler.timezone
            backend: Optional[str] = chat_row.backend if chat_row else None
            model_override: Optional[str] = chat_row.model if chat_row else None
            thinking_override: Optional[str] = chat_row.thinking if chat_row else None

            for ex in extras:
                if "=" in ex:
                    k, v = ex.split("=", 1)
                    k = k.strip().lower()
                    v = v.strip()
                    if k == "tool_profile":
                        tool_profile = v
                    elif k == "target_chat_id":
                        try:
                            target_chat_id = int(v)
                        except Exception:
                            pass
                    elif k == "timezone":
                        timezone_str = v
                    elif k == "backend":
                        if v.lower() in ("claude", "codex", "gemini"):
                            backend = v.lower()
                    elif k == "model":
                        model_override = v
                    elif k == "thinking":
                        thinking_override = v

            # Non-admin can only target their own chat
            if (not is_admin) and (target_chat_id != chat_id):
                await self._send_text(chat_id, "⚠️ You can't target other chats.")
                return

            if tool_profile != "safe_chat" and tool_profile not in self.cfg.claude.tool_profiles:
                await self._send_text(chat_id, f"⚠️ Unknown tool_profile `{tool_profile}`.")
                return

            if stype not in ("cron", "interval", "once", "gapped"):
                await self._send_text(chat_id, "⚠️ schedule type must be cron, interval, once, or gapped.")
                return

            from .models import JobScheduleType  # local import to avoid cycles

            job_id = await self.db.create_job(
                name=name,
                enabled=True,
                schedule_type=JobScheduleType(stype),
                schedule_value=schedule_value.strip(),
                timezone_str=timezone_str,
                prompt=prompt.strip(),
                target_chat_id=target_chat_id,
                tool_profile=tool_profile,
                backend=backend,
                agent_profile=self.agent_name,
                model=model_override,
                thinking=thinking_override,
            )

            await self._send_text(chat_id, f"✅ Created job #{job_id}: `{name}`. Reloading scheduler…")
            if self.scheduler_service is not None:
                await self.scheduler_service.reload_jobs()
            return

        if sub in ("enable", "disable", "delete"):
            if not arg_rest.strip().isdigit():
                await self._send_text(chat_id, f"Usage: /job {sub} <id>")
                return
            jid = int(arg_rest.strip())

            job = await self.db.get_job(jid)
            if not job:
                await self._send_text(chat_id, f"⚠️ Job #{jid} not found.")
                return

            # Authorization
            target = job.get("target_chat_id")
            if not is_admin and target != chat_id:
                await self._send_text(chat_id, "⚠️ You don't have permission to modify that job.")
                return

            if sub == "enable":
                await self.db.set_job_enabled(jid, True)
                await self._send_text(chat_id, f"✅ Enabled job #{jid}.")
            elif sub == "disable":
                await self.db.set_job_enabled(jid, False)
                await self._send_text(chat_id, f"✅ Disabled job #{jid}.")
            else:
                await self.db.delete_job(jid)
                await self._send_text(chat_id, f"✅ Deleted job #{jid}.")

            if self.scheduler_service is not None:
                await self.scheduler_service.reload_jobs()
            return

        if sub == "set":
            # /job set <id> key=value [key=value ...]
            set_parts = arg_rest.split()
            if len(set_parts) < 2 or not set_parts[0].isdigit():
                await self._send_text(
                    chat_id,
                    "Usage: /job set <id> key=value [key=value ...]\n"
                    "Keys: model, thinking, backend, tool_profile\n"
                    "Use 'default' as value to clear back to default.",
                )
                return

            jid = int(set_parts[0])
            job = await self.db.get_job(jid)
            if not job:
                await self._send_text(chat_id, f"⚠️ Job #{jid} not found.")
                return

            # Authorization
            target = job.get("target_chat_id")
            if not is_admin and target != chat_id:
                await self._send_text(chat_id, "⚠️ You don't have permission to modify that job.")
                return

            _SETTABLE = {"model", "thinking", "backend", "tool_profile"}
            updates: dict = {}
            for token in set_parts[1:]:
                if "=" not in token:
                    continue
                k, v = token.split("=", 1)
                k = k.strip().lower()
                if k not in _SETTABLE:
                    continue
                if v.strip().lower() == "default":
                    updates[k] = None  # Clear to NULL
                else:
                    updates[k] = v.strip()

            if not updates:
                await self._send_text(chat_id, "No valid key=value pairs found.")
                return

            ok = await self.db.update_job_fields(jid, **updates)
            if ok:
                summary = ", ".join(f"{k}={v or 'default'}" for k, v in updates.items())
                await self._send_text(chat_id, f"✅ Updated job #{jid}: {summary}. Reloading scheduler…")
                if self.scheduler_service is not None:
                    await self.scheduler_service.reload_jobs()
            else:
                await self._send_text(chat_id, f"⚠️ Failed to update job #{jid}.")
            return

        await self._send_text(chat_id, "Unknown /job subcommand. Use /help.")

    async def _cmd_memory(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)

        raw = update.effective_message.text or ""
        rest = raw.split(" ", 1)[1].strip() if " " in raw else ""
        sub = rest.split(" ", 1)[0].strip().lower() if rest else "show"
        arg_rest = rest.split(" ", 1)[1].strip() if " " in rest else ""

        if sub in ("show", "index"):
            agent = resolve_agent(self.paths.agents_dir, self.agent_name)
            mem_dir = agent.memory_dir if agent else self.paths.memory_dir
            mem_path = mem_dir / "MEMORY.md"
            if not mem_path.exists():
                await self._send_text(chat_id, "MEMORY.md not found yet.")
                return
            content = mem_path.read_text(encoding="utf-8", errors="replace")
            # Keep it readable; send as file if too long
            await self._send_text(chat_id, content)
            return

        if sub == "note":
            if not arg_rest.strip():
                await self._send_text(chat_id, "Usage: /memory note <text>")
                return
            today = datetime_now_ymd()
            daily_dir = self._get_agent_daily_dir()
            daily_path = daily_dir / f"{today}.md"
            daily_path.parent.mkdir(parents=True, exist_ok=True)
            if not daily_path.exists():
                daily_path.write_text(f"# Daily log {today}\n\n", encoding="utf-8")
            with daily_path.open("a", encoding="utf-8") as f:
                f.write(f"- {arg_rest.strip()}\n")
            await self._send_text(chat_id, "📝 Added to today's daily log.")
            return

        await self._send_text(chat_id, "Usage: /memory show | /memory note <text>")

    # ----------------------------
    # Agent management (admin only)
    # ----------------------------
    # ------------------------------------------------------------------
    # /skill  list | enable | disable
    # ------------------------------------------------------------------
    async def _cmd_skill(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        /skill list
        /skill enable <name>
        /skill disable <name>
        """
        import json as _json
        from .skills import list_all_skills, filter_skills

        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)

        raw = update.effective_message.text or ""
        rest = raw.split(" ", 1)[1].strip() if " " in raw else ""

        if not rest:
            await self._send_text(
                chat_id,
                "Usage:\n"
                "- /skill list\n"
                "- /skill enable <name>\n"
                "- /skill disable <name>",
            )
            return

        sub = rest.split(" ", 1)[0].strip().lower()
        arg_rest = rest.split(" ", 1)[1].strip() if " " in rest else ""

        # Resolve agent for this chat
        from ._bundled import get_builtin_skills_dir
        agent = resolve_agent(self.paths.agents_dir, self.agent_name)
        agent_skills_dir = agent.skills_dir if agent else None
        all_skills = list_all_skills(
            self.paths.skills_dir, agent_skills_dir,
            builtin_dir=get_builtin_skills_dir(),
        )

        # Load current overrides from DB
        chat_row = await self.db.get_chat(self.agent_name, chat_id)
        overrides: dict = {}
        if chat_row and chat_row.disabled_skills:
            try:
                overrides = _json.loads(chat_row.disabled_skills)
            except Exception:
                overrides = {}

        if sub == "list":
            if not all_skills:
                await self._send_text(chat_id, "No skills installed.")
                return
            enabled_list, disabled_list = filter_skills(all_skills, overrides)
            enabled_names = {s.name for s in enabled_list}
            lines: list = []
            global_skills = [s for s in all_skills if not s.is_agent_skill]
            agent_specific = [s for s in all_skills if s.is_agent_skill]
            if global_skills:
                lines.append("Global skills:")
                for s in global_skills:
                    icon = "\u2705" if s.name in enabled_names else "\u23f8\ufe0f"
                    lines.append(f"  {icon} {s.name} \u2014 {s.description}")
            if agent_specific:
                lines.append(f"\nAgent skills ({self.agent_name}):")
                for s in agent_specific:
                    icon = "\u2705" if s.name in enabled_names else "\u23f8\ufe0f"
                    lines.append(f"  {icon} {s.name} \u2014 {s.description}")
            await self._send_text(chat_id, "\n".join(lines))

        elif sub == "enable":
            name = arg_rest.strip()
            if not name:
                await self._send_text(chat_id, "Usage: /skill enable <name>")
                return
            known = {s.name for s in all_skills}
            if name not in known:
                await self._send_text(chat_id, f"Unknown skill: {name}")
                return
            disabled_set = set(overrides.get("disabled", []))
            enabled_set = set(overrides.get("enabled", []))
            disabled_set.discard(name)
            enabled_set.add(name)
            overrides["disabled"] = sorted(disabled_set)
            overrides["enabled"] = sorted(enabled_set)
            await self.db.update_chat_skill_overrides(self.agent_name, chat_id, _json.dumps(overrides))
            await self._send_text(chat_id, f"Skill '{name}' enabled for this chat.")

        elif sub == "disable":
            name = arg_rest.strip()
            if not name:
                await self._send_text(chat_id, "Usage: /skill disable <name>")
                return
            known = {s.name for s in all_skills}
            if name not in known:
                await self._send_text(chat_id, f"Unknown skill: {name}")
                return
            disabled_set = set(overrides.get("disabled", []))
            enabled_set = set(overrides.get("enabled", []))
            disabled_set.add(name)
            enabled_set.discard(name)
            overrides["disabled"] = sorted(disabled_set)
            overrides["enabled"] = sorted(enabled_set)
            await self.db.update_chat_skill_overrides(self.agent_name, chat_id, _json.dumps(overrides))
            await self._send_text(chat_id, f"Skill '{name}' disabled for this chat.")

        else:
            await self._send_text(chat_id, "Unknown subcommand. Use: list, enable, disable")

    # ------------------------------------------------------------------
    # /goal  create | list | status | delete
    # ------------------------------------------------------------------
    async def _cmd_goal(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        /goal create <objective>
        /goal list
        /goal status [slug]
        /goal delete <slug>
        """
        import asyncio as _asyncio
        import json as _json
        import shutil as _shutil

        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)

        raw = update.effective_message.text or ""
        rest = raw.split(" ", 1)[1].strip() if " " in raw else ""

        if not rest:
            await self._send_text(
                chat_id,
                "Usage:\n"
                "- /goal create <objective>\n"
                "- /goal list\n"
                "- /goal status [slug]\n"
                "- /goal delete <slug>",
            )
            return

        sub = rest.split(" ", 1)[0].strip().lower()
        arg_rest = rest.split(" ", 1)[1].strip() if " " in rest else ""

        agent = resolve_agent(self.paths.agents_dir, self.agent_name)
        if not agent:
            await self._send_text(chat_id, "Agent not found.")
            return

        goals_dir = agent.goals_dir
        goals_dir.mkdir(parents=True, exist_ok=True)
        cli_path = self.paths.skills_dir / "goal-achiever" / "goalachiever.py"

        if sub == "create":
            if not arg_rest:
                await self._send_text(chat_id, "Usage: /goal create <objective text>")
                return
            if not cli_path.exists():
                await self._send_text(chat_id, "Goal achiever CLI not found. Is the skill installed?")
                return
            agent_dir = self.paths.agents_dir / self.agent_name
            cmd = [
                sys.executable, str(cli_path),
                "--root", str(agent_dir),
                "--workspaces-dir", "goals",
                "init", "--goal", arg_rest,
            ]
            try:
                proc = await _asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=_asyncio.subprocess.PIPE,
                    stderr=_asyncio.subprocess.PIPE,
                )
                stdout, stderr = await proc.communicate()
                if proc.returncode == 0:
                    ws_path = stdout.decode("utf-8").strip().splitlines()[0] if stdout else "?"
                    await self._send_text(chat_id, f"Goal created:\n{ws_path}")
                else:
                    err = stderr.decode("utf-8", errors="replace").strip()[:500]
                    await self._send_text(chat_id, f"Failed to create goal:\n{err}")
            except Exception as e:
                await self._send_text(chat_id, f"Error creating goal: {e}")

        elif sub == "list":
            registry_path = goals_dir / "REGISTRY.json"
            if not registry_path.exists():
                await self._send_text(chat_id, "No goals found.")
                return
            try:
                registry = _json.loads(registry_path.read_text(encoding="utf-8"))
                workspaces = registry.get("workspaces", [])
                if not workspaces:
                    await self._send_text(chat_id, "No goals found.")
                    return
                lines = ["Active goals:"]
                for ws in workspaces:
                    slug = ws.get("slug", "?")
                    goal = ws.get("goal", "(no goal text)")[:100]
                    lines.append(f"  \U0001f4ce {slug} \u2014 {goal}")
                await self._send_text(chat_id, "\n".join(lines))
            except Exception as e:
                await self._send_text(chat_id, f"Error reading goals: {e}")

        elif sub == "status":
            slug = arg_rest.strip()
            if not slug:
                # Show most recent goal's status
                registry_path = goals_dir / "REGISTRY.json"
                if registry_path.exists():
                    try:
                        registry = _json.loads(registry_path.read_text(encoding="utf-8"))
                        workspaces = registry.get("workspaces", [])
                        if workspaces:
                            slug = workspaces[-1].get("slug", "")
                    except Exception:
                        pass
                if not slug:
                    await self._send_text(chat_id, "No goals found. Usage: /goal status <slug>")
                    return
            status_file = goals_dir / slug / "status" / "STATUS.md"
            if not status_file.exists():
                await self._send_text(chat_id, f"Goal '{slug}' not found or has no status file.")
                return
            try:
                content = status_file.read_text(encoding="utf-8", errors="replace")
                # Truncate to fit Telegram message limits
                if len(content) > 3500:
                    content = content[:3500] + "\n\n...(truncated)"
                await self._send_text(chat_id, f"Status for {slug}:\n\n{content}")
            except Exception as e:
                await self._send_text(chat_id, f"Error reading status: {e}")

        elif sub == "delete":
            slug = arg_rest.strip()
            if not slug:
                await self._send_text(chat_id, "Usage: /goal delete <slug>")
                return
            is_admin = self.agent_cfg.is_admin_chat(chat_id)
            if not is_admin:
                await self._send_text(chat_id, "Only admins can delete goals.")
                return
            ws_dir = goals_dir / slug
            if not ws_dir.is_dir():
                await self._send_text(chat_id, f"Goal '{slug}' not found.")
                return
            try:
                _shutil.rmtree(str(ws_dir))
                # Update registry to remove the entry
                registry_path = goals_dir / "REGISTRY.json"
                if registry_path.exists():
                    try:
                        registry = _json.loads(registry_path.read_text(encoding="utf-8"))
                        workspaces = [w for w in registry.get("workspaces", [])
                                      if w.get("slug") != slug]
                        registry["workspaces"] = workspaces
                        registry_path.write_text(_json.dumps(registry, indent=2, sort_keys=True) + "\n",
                                                 encoding="utf-8")
                    except Exception:
                        pass
                await self._send_text(chat_id, f"Goal '{slug}' deleted.")
            except Exception as e:
                await self._send_text(chat_id, f"Error deleting goal: {e}")

        else:
            await self._send_text(chat_id, "Unknown subcommand. Use: create, list, status, delete")

    async def _cmd_agent(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id
        await self._ensure_chat_row(chat_id)
        is_admin = self.agent_cfg.is_admin_chat(chat_id)

        if not is_admin:
            await self._send_text(chat_id, "Only admins can manage agents.")
            return

        raw = update.effective_message.text or ""
        rest = raw.split(" ", 1)[1].strip() if " " in raw else ""

        if not rest:
            await self._send_text(
                chat_id,
                "Usage:\n"
                "- /agent list\n"
                "- /agent add <name> <bot_token>\n"
                "- /agent remove <name>\n"
                "- /agent soul <name> [new soul text]\n"
                "- /agent update <name> <instruction> — AI-edit agent profile",
            )
            return

        sub = rest.split(" ", 1)[0].strip().lower()
        arg_rest = rest.split(" ", 1)[1].strip() if " " in rest else ""

        if sub == "list":
            await self._agent_list(chat_id)
        elif sub == "add":
            await self._agent_add(chat_id, arg_rest)
        elif sub == "remove":
            await self._agent_remove(chat_id, arg_rest)
        elif sub == "soul":
            await self._agent_soul(chat_id, arg_rest)
        elif sub == "update":
            await self._agent_update(chat_id, arg_rest)
        else:
            await self._send_text(chat_id, "Unknown subcommand. Use: list, add, remove, soul, update")

    async def _agent_list(self, chat_id: int) -> None:
        lines = ["Configured agents:"]
        running_services = {}
        if self.scheduler_service and hasattr(self.scheduler_service, "telegram_services"):
            running_services = self.scheduler_service.telegram_services

        for name in self.cfg.agents:
            status = "running" if name in running_services else "stopped"
            lines.append(f"  {name} [{status}]")

        if len(lines) == 1:
            lines.append("  (none)")

        await self._send_text(chat_id, "\n".join(lines))

    async def _agent_add(self, chat_id: int, arg_rest: str) -> None:
        from .agent_profile import (
            create_agent_scaffold,
            validate_agent_name,
            validate_bot_token_format,
        )
        from .config import AgentConfig, save_config

        parts = arg_rest.split(None, 1)
        if len(parts) < 2:
            await self._send_text(chat_id, "Usage: /agent add <name> <bot_token>")
            return

        name = parts[0].strip().lower()
        token = parts[1].strip()

        # Validate name
        name_err = validate_agent_name(name)
        if name_err:
            await self._send_text(chat_id, f"Invalid name: {name_err}")
            return

        if name in self.cfg.agents:
            await self._send_text(chat_id, f"Agent '{name}' already exists.")
            return

        # Validate token format
        token_err = validate_bot_token_format(token)
        if token_err:
            await self._send_text(chat_id, f"Invalid token: {token_err}")
            return

        # Verify token with Telegram
        try:
            from telegram import Bot
            test_bot = Bot(token=token)
            me = await test_bot.get_me()
            bot_username = me.username
        except Exception as e:
            await self._send_text(
                chat_id,
                f"Token verification failed: {e}\nCheck the token and try again.",
            )
            return

        # Create directory scaffold (reuse if exists from a previous removal)
        try:
            create_agent_scaffold(self.paths.agents_dir, name)
        except FileExistsError:
            agent = resolve_agent(self.paths.agents_dir, name)
            if agent:
                ensure_agent_scaffold(agent)

        # Create config with auto-paired chat_id
        new_agent_cfg = AgentConfig(
            bot_token=SecretStr(token),
            allowed_chat_ids=[chat_id],
            admin_chat_ids=[chat_id],
        )

        # Add to in-memory config
        self.cfg.agents[name] = new_agent_cfg

        # Persist to disk
        try:
            save_config(self.cfg, self.paths.config_path)
        except Exception as e:
            del self.cfg.agents[name]
            await self._send_text(chat_id, f"Failed to save config: {e}")
            return

        # Hot-start the new agent
        try:
            new_ts = TelegramService(
                self.cfg, self.paths, self.db,
                self.claude, self.codex, self.gemini,
                self.context_builder, self.actions,
                agent_name=name, agent_cfg=new_agent_cfg,
            )
            new_ts.scheduler_service = self.scheduler_service

            if self.scheduler_service:
                self.scheduler_service.telegram_services[name] = new_ts

            await new_ts.start()
        except Exception as e:
            await self._send_text(
                chat_id,
                f"Agent '{name}' saved but failed to start: {e}\n"
                "It will start on next restart.",
            )
            return

        await self._send_text(
            chat_id,
            f"Agent '{name}' created and started!\n"
            f"Open @{bot_username} on Telegram to chat with it.\n\n"
            f"This chat ({chat_id}) is auto-added as admin.\n"
            f"Customize personality: /agent soul {name} <text>",
        )

    async def _agent_remove(self, chat_id: int, arg_rest: str) -> None:
        from .config import save_config

        name = arg_rest.strip().lower()
        if not name:
            await self._send_text(chat_id, "Usage: /agent remove <name>")
            return

        if name not in self.cfg.agents:
            await self._send_text(chat_id, f"Agent '{name}' not found.")
            return

        if name == self.agent_name:
            await self._send_text(chat_id, "You can't remove the agent you're talking to.")
            return

        # Stop the agent's TelegramService
        if self.scheduler_service:
            ts = self.scheduler_service.telegram_services.get(name)
            if ts:
                try:
                    await ts.stop()
                except Exception:
                    pass
                del self.scheduler_service.telegram_services[name]

        # Remove from in-memory config
        removed_cfg = self.cfg.agents.pop(name, None)

        # Persist
        try:
            save_config(self.cfg, self.paths.config_path)
        except Exception as e:
            if removed_cfg:
                self.cfg.agents[name] = removed_cfg
            await self._send_text(chat_id, f"Failed to save config: {e}")
            return

        await self._send_text(
            chat_id,
            f"Agent '{name}' removed and stopped.\n"
            f"Files preserved at agents/{name}/ (soul, memory).",
        )

    async def _agent_soul(self, chat_id: int, arg_rest: str) -> None:
        parts = arg_rest.split(None, 1)
        if not parts:
            await self._send_text(chat_id, "Usage: /agent soul <name> [new soul text]")
            return

        name = parts[0].strip().lower()
        new_text = parts[1].strip() if len(parts) > 1 else None

        # Resolve or create agent dir
        agent = resolve_agent(self.paths.agents_dir, name)
        if agent is None:
            if name in self.cfg.agents:
                from .agent_profile import create_agent_scaffold
                try:
                    agent = create_agent_scaffold(self.paths.agents_dir, name)
                except FileExistsError:
                    pass
            if agent is None:
                await self._send_text(chat_id, f"Agent '{name}' not found.")
                return

        if new_text is None:
            # Show current soul
            if agent.soul_file.exists():
                content = agent.soul_file.read_text(encoding="utf-8", errors="replace")
                await self._send_text(chat_id, f"Soul for '{name}':\n\n{content}")
            else:
                await self._send_text(chat_id, f"No soul.md found for '{name}'.")
        else:
            agent.soul_file.write_text(new_text, encoding="utf-8")
            await self._send_text(chat_id, f"Updated soul.md for '{name}'.")

    async def _agent_update(self, chat_id: int, arg_rest: str) -> None:
        """AI-powered agent profile editing via Claude CLI (with Codex fallback)."""
        parts = arg_rest.split(None, 1)
        if not parts or len(parts) < 2:
            await self._send_text(
                chat_id,
                "Usage: /agent update <name> <instruction>\n"
                "Example: /agent update clawde Make the agent more cheerful",
            )
            return

        name = parts[0].strip().lower()
        instruction = parts[1].strip()

        # Resolve or create agent directory
        agent = resolve_agent(self.paths.agents_dir, name)
        if agent is None:
            if name in self.cfg.agents:
                from .agent_profile import create_agent_scaffold
                try:
                    agent = create_agent_scaffold(self.paths.agents_dir, name)
                except FileExistsError:
                    agent = resolve_agent(self.paths.agents_dir, name)
            if agent is None:
                await self._send_text(chat_id, f"Agent '{name}' not found.")
                return

        ensure_agent_scaffold(agent)

        # Read current state for context
        soul_content = "(empty)"
        if agent.soul_file.exists():
            soul_content = agent.soul_file.read_text(encoding="utf-8", errors="replace")

        topic_files: list[str] = []
        if agent.memory_topics_dir.exists():
            topic_files = [f.name for f in agent.memory_topics_dir.iterdir() if f.is_file()]

        # Write temporary system prompt file
        prompt_text = _build_agent_edit_prompt(name, soul_content, topic_files)
        prompt_dir = self.paths.runtime_dir / "context"
        prompt_dir.mkdir(parents=True, exist_ok=True)
        prompt_file = prompt_dir / f"agent_edit_{name}.md"
        prompt_file.write_text(prompt_text, encoding="utf-8")

        agent_dir = self.paths.agents_dir / name
        await self._send_text(chat_id, f"Updating agent '{name}'...")

        # Progress queue for real-time status updates
        progress_queue: asyncio.Queue[Optional[Dict[str, Any]]] = asyncio.Queue()

        def _on_event(event: Dict[str, Any]) -> None:
            try:
                progress_queue.put_nowait(event)
            except Exception:
                pass
            line = TelegramService._format_progress_line(event)
            if line:
                activity_feed.emit(self.agent_name, "cli", line)

        progress_task = asyncio.create_task(
            self._progress_updater(chat_id, progress_queue)
        )

        result = None
        backend_used = "Claude"
        try:
            # Try Claude first
            result = await self.claude.run(
                prompt=instruction,
                mode=RunMode.cron,
                tool_profile_name="dev",
                no_session_persistence=True,
                append_system_prompt_file=prompt_file,
                cwd_override=agent_dir,
                max_turns=10,
                timeout_seconds=120,
                on_event=_on_event,
            )
        except Exception as exc:
            log.warning("Claude failed for agent update: %s", exc)
            result = None

        # Fallback to Codex if Claude failed
        if result is None or not result.ok:
            if result is not None:
                log.warning(
                    "Claude returned error for agent update, falling back to Codex: %s",
                    result.error,
                )
            backend_used = "Codex"
            try:
                result = await self.codex.run(
                    prompt=instruction,
                    mode=RunMode.cron,
                    tool_profile_name="dev",
                    no_session_persistence=True,
                    append_system_prompt_file=prompt_file,
                    cwd_override=agent_dir,
                    timeout_seconds=120,
                    on_event=_on_event,
                )
            except Exception as exc:
                log.error("Codex also failed for agent update: %s", exc)
                result = None

        # Stop progress updates
        await progress_queue.put(None)
        try:
            await asyncio.wait_for(progress_task, timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            progress_task.cancel()

        # Clean up temp prompt file
        try:
            prompt_file.unlink(missing_ok=True)
        except Exception:
            pass

        if result is None or not result.ok:
            error_detail = result.error if result else "both Claude and Codex failed"
            await self._send_text(chat_id, f"Failed to update agent '{name}': {error_detail}")
            return

        # Show the reply from the AI
        reply = "(no reply)"
        if result.structured and result.structured.reply:
            reply = result.structured.reply
        elif result.stdout_text:
            reply = result.stdout_text[:2000]

        # Read updated soul.md to show a preview
        updated_soul = ""
        if agent.soul_file.exists():
            new_soul = agent.soul_file.read_text(encoding="utf-8", errors="replace")
            if new_soul != soul_content:
                preview = new_soul[:500] + ("..." if len(new_soul) > 500 else "")
                updated_soul = f"\n\nUpdated soul.md:\n{preview}"

        await self._send_text(
            chat_id,
            f"[{backend_used}] {reply}{updated_soul}",
        )

    # ----------------------------
    # Main message handler
    # ----------------------------
    async def _on_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        msg = update.effective_message
        if msg is None:
            return

        chat = update.effective_chat
        if chat is None:
            return

        chat_id = chat.id
        text = (msg.text or "").strip()
        if not text:
            return

        # Extract inline overrides and strip from text
        backend_override, text = extract_backend_tag(text)
        agent_override, text = extract_agent_tag(text)
        if not text:
            return  # message was only tags

        # Resolve effective agent: inline override or bot's own agent
        effective_agent = agent_override or self.agent_name

        # Group policy check
        if chat.type in ("group", "supergroup"):
            is_reply_to_bot = False
            try:
                if msg.reply_to_message and msg.reply_to_message.from_user:
                    is_reply_to_bot = bool(self.bot_username and msg.reply_to_message.from_user.username == self.bot_username)
            except Exception:
                is_reply_to_bot = False

            if not should_respond_in_group(
                respond_in_groups=self.agent_cfg.respond_in_groups,
                require_mention=self.agent_cfg.require_mention_in_groups,
                bot_username=self.bot_username,
                message_text=text,
                is_reply_to_bot=is_reply_to_bot,
            ):
                return

        # --- Cancel any active run for this chat ---
        await self._cancel_active_run(chat_id, reason="new message")

        # Register a placeholder ActiveRun immediately so /stop can find it
        # even while pre-run setup (context building, MCP sync) is in progress.
        cancel_event = asyncio.Event()
        active_placeholder = ActiveRun(chat_id=chat_id, cancel_event=cancel_event)
        self._active_runs[chat_id] = active_placeholder

        # --- Pre-run setup (short lock) ---
        # Variables populated inside the lock, used after it's released
        run_id: Optional[int] = None
        backend: Optional[str] = None
        runner = None
        session_id: Optional[str] = None
        tool_profile: Optional[str] = None
        is_admin = False
        is_override = False
        effective_agent_resolved = effective_agent
        project_dir: Optional[Path] = None
        max_turns: Optional[int] = None
        progress_queue: asyncio.Queue[Optional[Dict[str, Any]]] = asyncio.Queue()
        progress_task: Optional[asyncio.Task] = None
        run_task: Optional[asyncio.Task] = None
        ctx_file: Optional[Path] = None

        async with self.get_chat_lock(chat_id):
            chat_row = await self._ensure_chat_row(chat_id)

            # Pairing gate (unless chat_id is pre-allowed)
            if not self._is_chat_paired(chat_row, chat_id):
                code = chat_row.pairing_code if chat_row else None
                await self._send_text(
                    chat_id,
                    f"🔒 Not paired. Send `/pair {code}` to pair this chat.\n"
                    f"(If you don't see a code, send any message again.)",
                )
                return

            # Persist inbound event
            user_event_id = await self.db.insert_event(
                agent_name=self.agent_name,
                chat_id=chat_id,
                role=EventRole.user,
                source=EventSource.telegram_in,
                text=text,
                telegram_message_id=msg.message_id,
            )
            self._append_daily_log("user", "telegram", text)

            # Update last_update_id if available
            try:
                if update.update_id:
                    await self.db.update_chat_last_update_id(self.agent_name, chat_id, int(update.update_id))
            except Exception:
                pass

            # Re-fetch row to get latest state
            chat_row = await self.db.get_chat(self.agent_name, chat_id)
            session_id = chat_row.claude_session_id if chat_row else None
            tool_profile = chat_row.tool_profile if chat_row else "safe_chat"
            last_ingested_event_id = chat_row.last_ingested_event_id if chat_row else 0
            is_admin = self.agent_cfg.is_admin_chat(chat_id)
            project_dir = Path(chat_row.project_dir) if chat_row and chat_row.project_dir else None

            # --- Pre-compaction memory flush (background, non-blocking) ---
            if session_id and self.cfg.memory.flush.enabled:
                asyncio.create_task(
                    self._maybe_flush_memory(chat_id, session_id, effective_agent, project_dir)
                )

            # Build context pack (with agent identity + memory)
            ctx_info = await self.context_builder.build_and_write(
                mode=RunMode.telegram,
                query_text=text,
                chat_id=chat_id,
                is_admin=is_admin,
                tool_profile=tool_profile,
                last_ingested_event_id=last_ingested_event_id,
                clear_after_event_id=chat_row.clear_after_event_id if chat_row else 0,
                project_dir=chat_row.project_dir if chat_row else None,
                agent_name=effective_agent,
                disabled_skills=chat_row.disabled_skills if chat_row else None,
            )
            ctx_file = ctx_info.context_file

            # Select backend runner (inline @backend-X override takes priority)
            stored_backend = chat_row.backend if chat_row and chat_row.backend else self.agent_cfg.default_backend
            if backend_override:
                backend = backend_override
            else:
                backend = stored_backend
            is_backend_override = backend_override is not None and backend != stored_backend
            is_agent_override = agent_override is not None and agent_override != self.agent_name
            is_override = is_backend_override or is_agent_override
            runner = self._get_runner(backend)

            # Pre-create log path so it's in DB before the run starts (for live streaming)
            run_log_path = runner.make_log_path(RunMode.telegram)

            # Log run in DB
            run_id = await self.db.start_run(
                mode=RunMode.telegram,
                chat_id=chat_id,
                claude_session_id=session_id,
                prompt_preview=(text[:200] + "…") if len(text) > 200 else text,
                agent_name=self.agent_name,
                log_file=str(run_log_path),
                prompt_full=text,
            )
            activity_feed.emit(self.agent_name, "run", f"Run started (telegram, {backend})")
            activity_feed.emit(self.agent_name, "run", f"User: {text[:300]}")

            # When overriding to a different backend/agent, don't resume the stored session
            if is_override:
                session_id = None

            # Determine max_turns based on backend
            if backend == "codex":
                max_turns = self.cfg.codex.max_turns_telegram
            elif backend == "gemini":
                max_turns = self.cfg.gemini.max_turns_telegram
            else:
                max_turns = self.cfg.claude.max_turns_telegram

            def _on_agent_event(event: Dict[str, Any]) -> None:
                try:
                    progress_queue.put_nowait(event)
                except Exception:
                    pass
                line = TelegramService._format_progress_line(event)
                if line:
                    activity_feed.emit(self.agent_name, "cli", line)

            # Sync MCP server configs into working directory before run
            try:
                from .mcp_sync import sync_mcp_to_cwd, ensure_mcp_scaffold
                ensure_mcp_scaffold(self.paths.mcp_servers_dir)
                effective_cwd = project_dir or self.paths.repo_root
                sync_mcp_to_cwd(
                    self.paths.mcp_servers_dir, effective_cwd, backend,
                    agent_name=self.agent_name, repo_root=self.paths.repo_root,
                )
            except Exception:
                log.debug("MCP sync skipped", exc_info=True)

            # Check if cancelled during setup (e.g. /stop arrived while building context)
            if cancel_event.is_set():
                self._active_runs.pop(chat_id, None)
                log.info("Run for chat %d cancelled during setup", chat_id)
                return

            # Per-chat model + thinking overrides
            chat_extra_args: list = []
            chat_env_overrides: dict = {}
            if chat_row and chat_row.model:
                chat_extra_args += ["--model", chat_row.model]
            if chat_row and chat_row.thinking:
                if backend == "claude":
                    chat_env_overrides["CLAUDE_CODE_EFFORT_LEVEL"] = chat_row.thinking
                elif backend == "codex":
                    chat_extra_args += ["-c", f'model_reasoning_effort="{chat_row.thinking}"']

            # Start progress updater
            progress_task = asyncio.create_task(
                self._progress_updater(chat_id, progress_queue)
            )

            # Create the runner task (starts executing immediately)
            run_task = asyncio.create_task(runner.run(
                prompt=text,
                mode=RunMode.telegram,
                tool_profile_name=tool_profile,
                resume_session_id=session_id,
                no_session_persistence=False,
                append_system_prompt_file=ctx_file,
                max_turns=max_turns,
                timeout_seconds=self._resolve_run_timeout(backend),
                cwd_override=project_dir,
                log_path=run_log_path,
                on_event=_on_agent_event,
                on_proc_started=lambda proc: self._on_run_proc_started(chat_id, proc),
                extra_args=chat_extra_args or None,
                env_overrides=chat_env_overrides or None,
            ))

            # Update the placeholder with the real task/progress info
            active_placeholder.task = run_task
            active_placeholder.progress_task = progress_task
            active_placeholder.progress_queue = progress_queue
            active_placeholder.backend = backend
            active_placeholder.run_id = run_id
        # --- Lock released: await the runner ---

        try:
            res = await run_task
        except asyncio.CancelledError:
            # Run was cancelled by /stop or new message
            log.info("Run cancelled for chat %d", chat_id)
            return
        except Exception as exc:
            self._active_runs.pop(chat_id, None)
            log.error("Runner failed: %s", exc, exc_info=True)
            await self.db.finish_run(run_id=run_id, stdout_json=None, exit_code=-1, error=str(exc))
            activity_feed.emit(self.agent_name, "error", f"Run failed: {exc}")
            backend_label = {"codex": "Codex", "gemini": "Gemini"}.get(backend, "Claude Code")
            await self._send_text(chat_id, f"⚠️ {backend_label} failed to start: {exc}")
            return
        finally:
            # Clean up active run tracking and progress updater
            self._active_runs.pop(chat_id, None)
            await progress_queue.put(None)
            try:
                await asyncio.wait_for(progress_task, timeout=5.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                progress_task.cancel()

        # --- Post-run processing (short lock) ---
        async with self.get_chat_lock(chat_id):
            await self.db.finish_run(
                run_id=run_id,
                stdout_json=res.stdout_text if res.stdout_text else None,
                exit_code=res.exit_code,
                error=res.error,
                log_file=res.log_file,
            )
            activity_feed.emit(self.agent_name, "run", f"Run completed (exit={res.exit_code})")

            if not res.ok or not res.structured:
                backend_label = {"codex": "Codex", "gemini": "Gemini"}.get(backend, "Claude Code")
                error_detail = ""
                if res.error:
                    # Truncate for Telegram but show useful context
                    err_preview = res.error[:300]
                    error_detail = f"\n\n{err_preview}"
                err_msg = f"Something went wrong while running {backend_label}.{error_detail}"
                await self._send_text(chat_id, f"⚠️ {err_msg}")
                activity_feed.emit(self.agent_name, "error", err_msg[:300])
                return

            # Persist session id if newly created/changed (skip for one-off overrides)
            if res.session_id and res.session_id != session_id and not is_override:
                await self.db.update_chat_session_id(self.agent_name, chat_id, res.session_id)
                session_id = res.session_id

            structured = res.structured
            reply_text = (structured.reply or "").strip()
            if not reply_text:
                reply_text = "(no reply)"

            # Execute actions deterministically
            action_summary = await self.actions.execute_actions(
                structured,
                ctx=ActionExecContext(
                    mode=RunMode.telegram,
                    actor_chat_id=chat_id,
                    actor_is_admin=is_admin,
                    agent_name=effective_agent,
                    tool_profile=tool_profile,
                    backend=backend,
                ),
            )

            if action_summary.user_notices:
                reply_text = reply_text.rstrip() + "\n\n" + "\n".join(action_summary.user_notices)

            # Send reply to Telegram
            send_res = await self._send_text(chat_id, reply_text)
            activity_feed.emit(self.agent_name, "run", f"Reply: {reply_text[:300]}")

            # Ledger write assistant out
            assistant_event_id = await self.db.insert_event(
                agent_name=self.agent_name,
                chat_id=chat_id,
                role=EventRole.assistant,
                source=EventSource.telegram_out,
                text=reply_text,
                telegram_message_id=send_res.first_message_id,
                meta={"parts_sent": send_res.parts_sent},
            )
            self._append_daily_log("assistant", "telegram", reply_text)

            # Advance last_ingested_event_id: session now contains both user and assistant turns
            await self.db.update_last_ingested_event_id(self.agent_name, chat_id, assistant_event_id)

            # Update flush tracking (turns + text length since last flush)
            try:
                turns, text_len = await self.db.get_flush_tracking(self.agent_name, chat_id)
                turns += 1
                text_len += len(text or "") + len(reply_text or "")
                await self.db.update_flush_tracking(self.agent_name, chat_id, turns, text_len)
            except Exception:
                pass  # Non-critical

            # Reload scheduler if actions changed jobs
            if action_summary.scheduler_changed and self.scheduler_service is not None:
                await self.scheduler_service.reload_jobs()

            # Trigger any requested jobs
            if action_summary.trigger_job_ids and self.scheduler_service is not None:
                for jid in action_summary.trigger_job_ids:
                    try:
                        await self.scheduler_service.trigger_job(jid)
                    except (RuntimeError, ValueError):
                        pass

    # ----------------------------
    # Helpers
    # ----------------------------
    async def _ensure_chat_row(self, chat_id: int):
        row = await self.db.get_chat(self.agent_name, chat_id)
        if row is not None:
            return row

        # Pre-allowed chats auto-pair; admins default to dev profile
        if self.agent_cfg.is_allowed_chat(chat_id):
            default_profile = "dev" if self.agent_cfg.is_admin_chat(chat_id) else "safe_chat"
            await self.db.create_chat(self.agent_name, chat_id, status=ChatStatus.paired, pairing_code=None, tool_profile=default_profile)
        else:
            code = generate_pairing_code()
            await self.db.create_chat(self.agent_name, chat_id, status=ChatStatus.unpaired, pairing_code=code, tool_profile="safe_chat")
        return await self.db.get_chat(self.agent_name, chat_id)

    def _is_chat_paired(self, row, chat_id: int) -> bool:
        # Config allowlist always paired
        if self.agent_cfg.is_allowed_chat(chat_id):
            return True
        if not row:
            return False
        return row.status == ChatStatus.paired.value

    def _get_agent_daily_dir(self, agent_name: Optional[str] = None) -> Path:
        """Return the daily log directory for the given (or own) agent."""
        name = agent_name or self.agent_name
        agent = resolve_agent(self.paths.agents_dir, name)
        if agent:
            return agent.memory_daily_dir
        return self.paths.memory_daily_dir

    async def _maybe_flush_memory(
        self, chat_id: int, session_id: str, agent_name: Optional[str], project_dir: Optional[Path]
    ) -> None:
        """Run a memory flush if session has accumulated enough context."""
        flush_cfg = self.cfg.memory.flush
        try:
            turns, text_len = await self.db.get_flush_tracking(self.agent_name, chat_id)
        except Exception:
            return

        if turns < flush_cfg.turn_threshold and text_len < flush_cfg.text_len_threshold:
            return

        log.info(
            "Memory flush triggered for chat %d (turns=%d, text_len=%d)",
            chat_id, turns, text_len,
        )

        runner = self._get_runner(
            (await self.db.get_chat(self.agent_name, chat_id)).backend
            or self.agent_cfg.default_backend
        )

        flush_prompt = (
            "MEMORY FLUSH: This session is approaching the context limit. "
            "Review the conversation and save any important facts, decisions, preferences, "
            "or technical details to memory using write_memory and append_daily_log actions. "
            "Focus on information that is NOT already in your memory files. "
            "Reply with a brief summary of what you saved."
        )

        try:
            flush_ctx = await self.context_builder.build_and_write(
                mode=RunMode.telegram,
                query_text=flush_prompt,
                chat_id=chat_id,
                is_admin=False,
                tool_profile="dev",
                last_ingested_event_id=0,
                agent_name=agent_name,
            )

            res = await runner.run(
                prompt=flush_prompt,
                mode=RunMode.telegram,
                tool_profile_name="dev",
                resume_session_id=session_id,
                append_system_prompt_file=flush_ctx.context_file,
                max_turns=3,
                timeout_seconds=self._resolve_run_timeout(self._backend_for_runner(runner)),
                cwd_override=project_dir or self.paths.repo_root,
            )

            if res.ok and res.structured:
                await self.actions.execute_actions(
                    res.structured,
                    ctx=ActionExecContext(
                        mode=RunMode.telegram,
                        actor_chat_id=chat_id,
                        actor_is_admin=False,
                        agent_name=agent_name,
                        tool_profile="dev",
                        backend=runner.backend_name if hasattr(runner, 'backend_name') else "claude",
                    ),
                )
                # Update session ID if it changed
                if res.session_id and res.session_id != session_id:
                    await self.db.update_chat_session_id(self.agent_name, chat_id, res.session_id)

            # Reset flush counters
            await self.db.update_flush_tracking(self.agent_name, chat_id, 0, 0)
            log.info("Memory flush completed for chat %d", chat_id)

        except Exception:
            log.warning("Memory flush failed for chat %d", chat_id, exc_info=True)

    def _append_daily_log(self, role: str, source: str, text: str, agent_name: Optional[str] = None) -> None:
        """Append a message entry to today's daily log file."""
        today = datetime_now_ymd()
        daily_dir = self._get_agent_daily_dir(agent_name)
        daily_path = daily_dir / f"{today}.md"
        daily_path.parent.mkdir(parents=True, exist_ok=True)
        if not daily_path.exists():
            daily_path.write_text(f"# Daily log {today}\n\n", encoding="utf-8")
        preview = text[:500] + "\u2026" if len(text) > 500 else text
        entry = f"### [{role}][{source}]\n{preview}\n\n"
        with daily_path.open("a", encoding="utf-8") as f:
            f.write(entry)

    async def _typing_loop(self, chat_id: int, stop: asyncio.Event) -> None:
        """Send 'typing...' indicator every 4s until stop is set."""
        while not stop.is_set():
            try:
                await self.app.bot.send_chat_action(chat_id, ChatAction.TYPING)
            except Exception:
                pass
            try:
                await asyncio.wait_for(stop.wait(), timeout=4.0)
            except asyncio.TimeoutError:
                continue

    @staticmethod
    def _format_progress_line(event: Dict[str, Any]) -> Optional[str]:
        """Convert a stream-json/codex-json event into a short Telegram-friendly progress line."""
        etype = event.get("type", "")

        # --- Claude stream-json events ---

        if etype == "system" and event.get("subtype") == "init":
            model = event.get("model", "?")
            tools = event.get("tools", [])
            tool_count = len(tools) if isinstance(tools, list) else 0
            return f"Starting... (model: {model}, {tool_count} tools)"

        if etype == "assistant":
            msg = event.get("message", {})
            content = msg.get("content", [])
            for block in content:
                btype = block.get("type", "")
                if btype == "tool_use":
                    name = block.get("name", "?")
                    inp = block.get("input", {})
                    if name == "Read":
                        path = inp.get("file_path", "?")
                        short = path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
                        return f"Reading: {short[:60]}"
                    elif name in ("Write", "Edit"):
                        path = inp.get("file_path", "?")
                        short = path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
                        return f"{'Writing' if name == 'Write' else 'Editing'}: {short[:60]}"
                    elif name == "Bash":
                        cmd = inp.get("command", "")
                        preview = cmd[:120] + "..." if len(cmd) > 120 else cmd
                        return f"Running: {preview}"
                    elif name == "Grep":
                        pattern = inp.get("pattern", "?")
                        return f"Searching: {pattern[:60]}"
                    elif name == "Glob":
                        pattern = inp.get("pattern", "?")
                        return f"Finding files: {pattern[:60]}"
                    elif name == "WebFetch":
                        url = inp.get("url", "?")
                        return f"Fetching: {url[:80]}"
                    elif name == "WebSearch":
                        query = inp.get("query", "?")
                        return f"Searching web: {query[:60]}"
                    elif name == "TodoWrite":
                        return "Updating task list..."
                    elif name == "Task":
                        desc = inp.get("description", "?")
                        return f"Agent: {desc[:60]}"
                    elif name == "NotebookEdit":
                        return "Editing notebook..."
                    elif name == "StructuredOutput":
                        return "Preparing response..."
                    elif name.startswith("mcp__"):
                        parts = name.split("__", 2)
                        server = parts[1] if len(parts) > 1 else "?"
                        tool = parts[2] if len(parts) > 2 else "?"
                        short_server = server.split("-")[0]
                        return f"{short_server}: {tool[:40]}"
                    else:
                        return f"Using tool: {name}"
                elif btype == "text":
                    text = block.get("text", "").strip()
                    if text:
                        return "Thinking..."
            return None

        # --- Codex JSONL events ---

        if etype == "thread.started":
            return "Starting Codex..."

        if etype == "turn.started":
            return "Thinking..."

        if etype == "item.started":
            item = event.get("item", {})
            itype = item.get("type", "")
            if itype == "mcp_tool_call":
                server = item.get("server", "?")
                tool = item.get("tool", "?")
                return f"MCP: {server}/{tool}"
            return None

        if etype == "item.completed":
            item = event.get("item", {})
            itype = item.get("type", "")
            if itype == "tool_call":
                name = item.get("name", "?")
                return f"Using tool: {name}"
            if itype == "mcp_tool_call":
                server = item.get("server", "?")
                tool = item.get("tool", "?")
                return f"MCP done: {server}/{tool}"
            if itype == "tool_output":
                return "Processing tool output..."
            if itype == "reasoning":
                return "Reasoning..."
            if itype == "agent_message":
                return "Preparing response..."
            return None

        if etype == "turn.completed":
            return "Finishing up..."

        # --- Gemini CLI events ---

        if etype == "init" and event.get("session_id"):
            model = event.get("model", "?")
            return f"Starting Gemini ({model})..."

        if etype == "message":
            role = event.get("role", "")
            if role == "assistant":
                return "Preparing response..."
            return None

        if etype == "tool_use":
            name = event.get("tool_name", "?")
            return f"Using tool: {name}"

        if etype == "tool_result":
            return "Processing tool output..."

        if etype == "result" and event.get("status"):
            return "Finishing up..."

        return None

    async def _progress_updater(
        self,
        chat_id: int,
        event_queue: "asyncio.Queue[Optional[Dict[str, Any]]]",
        min_update_interval: float = 2.0,
    ) -> None:
        """
        Consume stream events and maintain a single editable status message
        in Telegram. Deletes the status message when a None sentinel is received.
        """
        status_message_id: Optional[int] = None
        last_update_time: float = 0.0
        pending_lines: List[str] = []
        lines_history: List[str] = []
        max_history = 6
        last_typing_time: float = 0.0

        async def _flush_pending() -> None:
            nonlocal status_message_id, last_update_time
            if not pending_lines:
                return
            for pl in pending_lines:
                status_message_id = await self._update_progress_msg(
                    chat_id, status_message_id, lines_history, pl, max_history,
                )
            pending_lines.clear()
            last_update_time = time.monotonic()

        try:
            while True:
                try:
                    event = await asyncio.wait_for(event_queue.get(), timeout=2.0)
                except asyncio.TimeoutError:
                    now = time.monotonic()
                    if now - last_typing_time >= 4.0:
                        try:
                            await self.app.bot.send_chat_action(chat_id, ChatAction.TYPING)
                        except Exception:
                            pass
                        last_typing_time = now
                    # Flush any pending updates that were throttled
                    if pending_lines and now - last_update_time >= min_update_interval:
                        await _flush_pending()
                    continue

                if event is None:
                    break

                line = self._format_progress_line(event)
                if line is None:
                    continue

                pending_lines.append(line)
                now = time.monotonic()

                if now - last_update_time >= min_update_interval:
                    await _flush_pending()
        except asyncio.CancelledError:
            pass
        finally:
            if status_message_id is not None:
                try:
                    await self.app.bot.delete_message(chat_id, status_message_id)
                except Exception:
                    pass

    async def _update_progress_msg(
        self,
        chat_id: int,
        msg_id: Optional[int],
        lines_history: List[str],
        new_line: str,
        max_history: int,
    ) -> Optional[int]:
        """Send or edit the progress status message. Returns the message id."""
        if new_line not in lines_history:
            lines_history.append(new_line)
            if len(lines_history) > max_history:
                del lines_history[: len(lines_history) - max_history]

        display = "\n".join(f"• {ln}" for ln in lines_history)

        if msg_id is None:
            try:
                sent = await self.app.bot.send_message(
                    chat_id=chat_id, text=display, disable_notification=True,
                )
                return getattr(sent, "message_id", None)
            except Exception:
                return None
        else:
            try:
                await self.app.bot.edit_message_text(
                    chat_id=chat_id, message_id=msg_id, text=display,
                )
            except Exception:
                pass
            return msg_id

    async def _send_text(self, chat_id: int, text: str) -> TelegramSendResult:
        """
        Send text to Telegram using HTML parse mode + chunking/file fallback.
        """
        if not self.app:
            raise RuntimeError("Telegram app not started")

        max_chars = int(self.agent_cfg.max_reply_chars)

        split_res = format_and_split_for_telegram(text, max_chars=max_chars)
        if needs_send_as_file(split_res) and self.agent_cfg.send_long_as_file:
            # Send as file to preserve content
            with tempfile.NamedTemporaryFile("w+", suffix=".txt", delete=False, encoding="utf-8") as f:
                f.write(text)
                tmp_path = f.name

            try:
                sent = await self.app.bot.send_document(
                    chat_id=chat_id,
                    document=open(tmp_path, "rb"),
                    caption="(message too long; sent as file)",
                )
                # A document message still has message_id
                return TelegramSendResult(first_message_id=getattr(sent, "message_id", None), parts_sent=1)
            finally:
                try:
                    Path(tmp_path).unlink(missing_ok=True)  # type: ignore[arg-type]
                except Exception:
                    pass

        # Normal multi-part send
        first_id: Optional[int] = None
        parts_sent = 0
        for part in split_res.parts:
            if not part:
                continue
            sent = await self.app.bot.send_message(
                chat_id=chat_id,
                text=part,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True,
            )
            parts_sent += 1
            if first_id is None:
                first_id = getattr(sent, "message_id", None)

        if parts_sent == 0:
            sent = await self.app.bot.send_message(chat_id=chat_id, text="(empty)")
            first_id = getattr(sent, "message_id", None)
            parts_sent = 1

        return TelegramSendResult(first_message_id=first_id, parts_sent=parts_sent)

    async def _ingest_assistant_message_into_session(
        self,
        *,
        chat_id: int,
        session_id: str,
        message_text: str,
        job_id: int,
        job_name: str,
    ) -> bool:
        """
        Add a "system event" assistant message into the session by resuming it
        and sending a one-turn prompt to acknowledge it.

        We intentionally do NOT send anything to Telegram.
        """
        prompt = (
            f"SYSTEM EVENT (cron job {job_name} #{job_id}):\n"
            "The gateway sent the following assistant message to the user in Telegram.\n"
            "Treat it as a message you already sent. Do NOT ask the user anything.\n"
            "Return JSON with reply='(ingested)' and no actions.\n\n"
            "Message:\n"
            f"{message_text}"
        )

        # Use the chat's backend for ingestion
        chat_row = await self.db.get_chat(self.agent_name, chat_id)
        backend = chat_row.backend if chat_row and chat_row.backend else self.agent_cfg.default_backend
        runner = self._get_runner(backend)
        if backend == "codex":
            max_turns_ingest = self.cfg.codex.max_turns_ingest
        elif backend == "gemini":
            max_turns_ingest = self.cfg.gemini.max_turns_ingest
        else:
            max_turns_ingest = self.cfg.claude.max_turns_ingest

        # Pre-create log path so it's in DB before the run starts
        run_log_path = runner.make_log_path(RunMode.ingest)

        run_id = await self.db.start_run(
            mode=RunMode.ingest,
            chat_id=chat_id,
            claude_session_id=session_id,
            prompt_preview=f"INGEST cron #{job_id} {job_name}",
            agent_name=self.agent_name,
            log_file=str(run_log_path),
            prompt_full=prompt,
        )

        # Use chat's project_dir so the CLI finds the correct session store
        cwd = Path(chat_row.project_dir) if chat_row and chat_row.project_dir else None

        res = await runner.run(
            prompt=prompt,
            mode=RunMode.ingest,
            tool_profile_name="safe_chat",
            resume_session_id=session_id,
            no_session_persistence=False,
            append_system_prompt_file=None,
            max_turns=max_turns_ingest,
            cwd_override=cwd,
            timeout_seconds=self._resolve_run_timeout(self._backend_for_runner(runner)),
            log_path=run_log_path,
        )

        await self.db.finish_run(
            run_id=run_id,
            stdout_json=res.stdout_text if res.stdout_text else None,
            exit_code=res.exit_code,
            error=res.error,
            log_file=res.log_file,
        )
        return bool(res.ok)


def datetime_now_ymd() -> str:
    from datetime import datetime

    return datetime.now().strftime("%Y-%m-%d")
