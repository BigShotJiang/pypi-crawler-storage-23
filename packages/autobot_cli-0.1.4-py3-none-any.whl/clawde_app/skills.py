"""Skills management: listing, reading, writing."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


_SKILL_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_\-]{0,63}$")


@dataclass(frozen=True)
class SkillInfo:
    """Metadata about a single skill."""
    name: str
    description: str
    skill_md_path: Path
    is_agent_skill: bool = False
    enabled_by_default: bool = True


def sanitize_skill_name(name: str) -> str:
    """Validate and return a cleaned skill name, or raise ValueError."""
    n = (name or "").strip()
    if not n:
        raise ValueError("Skill name cannot be empty")
    if not _SKILL_NAME_RE.match(n):
        raise ValueError(
            f"Invalid skill name '{n}'. "
            "Must be 1-64 chars, alphanumeric/dash/underscore, starting with letter or digit."
        )
    return n


def _extract_description(content: str) -> str:
    """Extract a short description from SKILL.md content.

    Looks for YAML frontmatter ``description:`` field first,
    then falls back to the first markdown heading.
    """
    lines = content.strip().splitlines()
    if not lines:
        return "(no description)"

    # YAML frontmatter
    if lines[0].strip() == "---":
        for i, line in enumerate(lines[1:], 1):
            if line.strip() == "---":
                for fm_line in lines[1:i]:
                    stripped = fm_line.strip()
                    if stripped.lower().startswith("description:"):
                        desc = stripped.split(":", 1)[1].strip().strip('"').strip("'").strip(">").strip()
                        if desc:
                            return desc[:200]
                break

    # First heading
    for line in lines:
        s = line.strip()
        if s.startswith("#"):
            return s.lstrip("#").strip()[:200]

    return "(no description)"


def _load_skill_meta(skill_dir: Path) -> Dict[str, Any]:
    """Read skill.json from a skill directory. Returns {} on missing/error."""
    meta_path = skill_dir / "skill.json"
    if not meta_path.exists():
        return {}
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def list_skills(skills_dir: Path, *, is_agent: bool = False) -> List[SkillInfo]:
    """List skills in a single directory. Each skill is a subdirectory with SKILL.md."""
    if not skills_dir.is_dir():
        return []
    results: List[SkillInfo] = []
    for d in sorted(skills_dir.iterdir()):
        if not d.is_dir():
            continue
        skill_md = d / "SKILL.md"
        if not skill_md.exists():
            continue
        try:
            content = skill_md.read_text(encoding="utf-8", errors="replace")
        except Exception:
            content = ""
        meta = _load_skill_meta(d)
        results.append(SkillInfo(
            name=d.name,
            description=_extract_description(content),
            skill_md_path=skill_md,
            is_agent_skill=is_agent,
            enabled_by_default=bool(meta.get("enabled", True)),
        ))
    return results


def list_all_skills(
    global_dir: Path,
    agent_dir: Optional[Path] = None,
    builtin_dir: Optional[Path] = None,
) -> List[SkillInfo]:
    """Merge built-in + user global + per-agent skills.

    Override priority (highest wins): agent > user global > built-in.
    """
    seen: Dict[str, SkillInfo] = {}

    # 1. Built-in skills (lowest priority)
    if builtin_dir and builtin_dir.is_dir():
        for s in list_skills(builtin_dir, is_agent=False):
            seen[s.name] = s

    # 2. User global skills
    for s in list_skills(global_dir, is_agent=False):
        seen[s.name] = s

    # 3. Per-agent skills (highest priority)
    if agent_dir:
        for s in list_skills(agent_dir, is_agent=True):
            seen[s.name] = s

    return sorted(seen.values(), key=lambda s: s.name)


def ensure_skills_scaffold(skills_dir: Path) -> None:
    """Create the skills directory if it doesn't exist."""
    skills_dir.mkdir(parents=True, exist_ok=True)


def filter_skills(
    all_skills: List[SkillInfo],
    overrides: Optional[Dict[str, Any]] = None,
) -> Tuple[List[SkillInfo], List[SkillInfo]]:
    """Partition skills into (enabled, disabled) based on per-chat overrides.

    *overrides* is a dict with optional keys ``"disabled"`` and ``"enabled"``,
    each a list of skill names.  Priority:

    1. Explicitly disabled → disabled (overrides enabled_by_default=True)
    2. Explicitly enabled → enabled (overrides enabled_by_default=False)
    3. Fall back to ``skill.enabled_by_default``
    """
    if not overrides:
        overrides = {}
    disabled_set = set(overrides.get("disabled", []))
    enabled_set = set(overrides.get("enabled", []))
    enabled: List[SkillInfo] = []
    disabled: List[SkillInfo] = []
    for s in all_skills:
        if s.name in disabled_set:
            disabled.append(s)
        elif s.name in enabled_set:
            enabled.append(s)
        elif s.enabled_by_default:
            enabled.append(s)
        else:
            disabled.append(s)
    return enabled, disabled


def write_skill(skills_dir: Path, name: str, content_md: str) -> Path:
    """Write a skill to the given skills directory. Returns the SKILL.md path."""
    clean_name = sanitize_skill_name(name)
    skill_dir = skills_dir / clean_name
    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_md = skill_dir / "SKILL.md"
    skill_md.write_text(content_md.rstrip() + "\n", encoding="utf-8")
    return skill_md
