from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shlex
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

from .config import AppConfig, AppPaths
from .models import RunMode, StructuredResponse, parse_structured_response

# Re-use ClaudeRunResult as the common result type for all backends.
from .claude_runner import ClaudeRunResult


_CODE_FENCE_RE = re.compile(r"^```(?:json)?\s*\n?(.*?)\n?\s*```$", re.DOTALL)


def _strip_code_fences(text: str) -> str:
    """Strip markdown code fences that Gemini often wraps around JSON output."""
    text = text.strip()
    m = _CODE_FENCE_RE.match(text)
    if m:
        return m.group(1).strip()
    return text


class GeminiRunnerError(RuntimeError):
    pass


class GeminiRunner:
    """
    Async wrapper around the Google `gemini` CLI.

    Uses `gemini` for new runs and `gemini --resume <session_id>` for
    session continuation.  Output is captured via `--output-format stream-json`
    (NDJSON event stream on stdout).
    """

    def __init__(self, cfg: AppConfig, paths: AppPaths):
        self.cfg = cfg
        self.paths = paths

    @staticmethod
    def _resolve_executable(exe: str) -> str:
        """Resolve a runnable gemini command on the current platform."""
        exe = (exe or "gemini").strip().strip('"')
        if os.name != "nt":
            exe_normalized = exe.replace("\\", "/")
            direct = shutil.which(exe_normalized)
            if direct:
                return direct

            exe_name = Path(exe_normalized).name
            base_name = exe_name
            if exe_name.lower().endswith((".cmd", ".bat", ".exe")):
                base_name = exe_name.rsplit(".", 1)[0]

            fallback = shutil.which(base_name)
            if fallback:
                return fallback

            return base_name
        resolved = shutil.which(exe)
        return resolved or exe

    @staticmethod
    async def _read_stream(stream) -> bytes:
        chunks = []
        while True:
            chunk = await stream.read(8192)
            if not chunk:
                break
            chunks.append(chunk)
        return b"".join(chunks)

    def _map_tool_profile_to_approval(self, tool_profile_name: str) -> str:
        profile = self.cfg.get_tool_profile(tool_profile_name)
        if profile.dangerously_skip_permissions:
            return "yolo"
        if not profile.tools:  # empty = no tools
            return "default"  # no-tool safe mode without requiring experimental flag
        return "auto_edit"  # allow edits but prompt for shell

    def _build_command(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str] = None,
        append_system_prompt_file: Optional[Path] = None,
        extra_args: Optional[Sequence[str]] = None,
    ) -> tuple[List[str], str]:
        """Build the gemini CLI command and return (cmd, full_prompt)."""

        # Prepend context to prompt if a system prompt file is provided
        if append_system_prompt_file is not None:
            try:
                context_text = append_system_prompt_file.read_text(encoding="utf-8")
                full_prompt = f"{context_text}\n\n---\n\nUser message:\n{prompt}"
            except Exception:
                full_prompt = prompt
        else:
            full_prompt = prompt

        # Resolve executable path (on Windows, npm installs .cmd shims that
        # asyncio.create_subprocess_exec can't find without the full path)
        exe = self._resolve_executable(self.cfg.gemini.executable)
        cmd: List[str] = [exe]

        # Session resume
        if resume_session_id:
            cmd += ["--resume", resume_session_id]

        # Model
        if self.cfg.gemini.model:
            cmd += ["--model", self.cfg.gemini.model]

        # Always stream-json for real-time logging + event capture
        cmd += ["--output-format", "stream-json"]

        # Approval mode (mapped from tool_profile)
        approval = self._map_tool_profile_to_approval(tool_profile_name)
        cmd += ["--approval-mode", approval]

        if extra_args:
            cmd += list(extra_args)

        # Gemini reads from stdin automatically when piped (no -p flag needed).
        # Do NOT use -p - (the "-" becomes a literal string in the prompt).
        return cmd, full_prompt

    def _format_stream_event(self, event: Dict[str, Any]) -> str:
        etype = event.get("type", "?")

        if etype == "init":
            sid = event.get("session_id", "?")[:12]
            model = event.get("model", "?")
            return f"[init] session={sid}... model={model}\n"

        if etype == "message":
            role = event.get("role", "?")
            text = event.get("content", "")
            preview = text[:200] + "..." if len(text) > 200 else text
            return f"[{role}] {preview}\n"

        if etype == "tool_use":
            name = event.get("tool_name", "?")
            return f"[tool_call] {name}\n"

        if etype == "tool_result":
            status = event.get("status", "?")
            output = event.get("output", "")
            preview = output[:200] + "..." if len(output) > 200 else output
            return f"[tool_result] {status}: {preview}\n"

        if etype == "result":
            status = event.get("status", "?")
            stats = event.get("stats", {})
            tokens = stats.get("total_tokens", 0)
            duration = stats.get("duration_ms", 0)
            return f"[result] status={status} tokens={tokens} duration={duration}ms\n"

        return f"[{etype}] {json.dumps(event, ensure_ascii=False)[:300]}\n"

    def make_log_path(self, mode: RunMode) -> Path:
        """Generate the log file path for a run."""
        log_dir = self.paths.stderr_log_dir
        log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return log_dir / f"gemini_{mode.value}_{timestamp}.log"

    async def run(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str] = None,
        no_session_persistence: bool = False,
        append_system_prompt_file: Optional[Path] = None,
        max_turns: Optional[int] = None,
        json_schema: Optional[str] = None,
        extra_args: Optional[Sequence[str]] = None,
        timeout_seconds: Optional[int] = None,
        raise_on_error: bool = False,
        env_overrides: Optional[Dict[str, str]] = None,
        cwd_override: Optional[Path] = None,
        on_event: Optional[Callable[[Dict[str, Any]], Any]] = None,
        on_proc_started: Optional[Callable[[asyncio.subprocess.Process], Any]] = None,
        log_path: Optional[Path] = None,
    ) -> ClaudeRunResult:
        """
        Execute the `gemini` CLI and parse its output.

        Returns ClaudeRunResult to maintain interface compatibility.
        """
        return await self._run_impl(
            prompt,
            mode=mode,
            tool_profile_name=tool_profile_name,
            resume_session_id=resume_session_id,
            append_system_prompt_file=append_system_prompt_file,
            extra_args=extra_args,
            timeout_seconds=timeout_seconds,
            raise_on_error=raise_on_error,
            env_overrides=env_overrides,
            cwd_override=cwd_override,
            on_event=on_event,
            on_proc_started=on_proc_started,
            log_path=log_path,
        )

    async def _run_impl(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str],
        append_system_prompt_file: Optional[Path],
        extra_args: Optional[Sequence[str]],
        timeout_seconds: Optional[int],
        raise_on_error: bool,
        env_overrides: Optional[Dict[str, str]],
        cwd_override: Optional[Path],
        on_event: Optional[Callable[[Dict[str, Any]], Any]],
        on_proc_started: Optional[Callable[[asyncio.subprocess.Process], Any]] = None,
        log_path: Optional[Path] = None,
    ) -> ClaudeRunResult:
        cmd, full_prompt = self._build_command(
            prompt,
            mode=mode,
            tool_profile_name=tool_profile_name,
            resume_session_id=resume_session_id,
            append_system_prompt_file=append_system_prompt_file,
            extra_args=extra_args,
        )

        cwd = str(cwd_override) if cwd_override else str(self.paths.repo_root)

        env = os.environ.copy()
        if env_overrides:
            env.update(env_overrides)

        # Prepare log file
        if log_path is None:
            log_path = self.make_log_path(mode)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = open(log_path, "w", encoding="utf-8")

        log = logging.getLogger("clawde.gemini_runner")
        log.info("Gemini streaming to: %s", log_path)

        start = time.monotonic()
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=cwd,
            env=env,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        # Feed prompt via stdin (avoids Windows command-line length limits)
        assert proc.stdin is not None
        proc.stdin.write(full_prompt.encode("utf-8"))
        proc.stdin.close()

        if on_proc_started is not None:
            try:
                on_proc_started(proc)
            except Exception:
                pass

        stdout_lines: List[str] = []
        session_id: Optional[str] = None
        assistant_chunks: List[str] = []
        had_error: Optional[str] = None
        result_status: Optional[str] = None

        async def _stream_stdout_ndjson():
            nonlocal session_id, had_error, result_status
            assert proc.stdout is not None
            while True:
                line_b = await proc.stdout.readline()
                if not line_b:
                    break
                line = line_b.decode("utf-8", errors="replace").rstrip("\n\r")
                if not line:
                    continue
                stdout_lines.append(line)
                try:
                    event = json.loads(line)
                    formatted = self._format_stream_event(event)
                    log_file.write(formatted)
                    log_file.flush()

                    # Capture session_id from init event
                    if event.get("type") == "init":
                        session_id = event.get("session_id")

                    # Collect assistant message chunks
                    if (event.get("type") == "message"
                            and event.get("role") == "assistant"):
                        content = event.get("content", "")
                        if content:
                            assistant_chunks.append(content)

                    # Capture result status
                    if event.get("type") == "result":
                        result_status = event.get("status")
                        if result_status != "success":
                            had_error = f"Gemini result status: {result_status}"

                    if on_event is not None:
                        try:
                            ret = on_event(event)
                            if asyncio.iscoroutine(ret):
                                await ret
                        except Exception:
                            pass

                except json.JSONDecodeError:
                    log_file.write(f"[raw] {line[:500]}\n")
                    log_file.flush()

        try:
            if timeout_seconds is None:
                _, stderr_b = await asyncio.gather(
                    _stream_stdout_ndjson(),
                    self._read_stream(proc.stderr),
                )
                await proc.wait()
            else:
                async def _run_stream():
                    _, stderr_b_ = await asyncio.gather(
                        _stream_stdout_ndjson(),
                        self._read_stream(proc.stderr),
                    )
                    await proc.wait()
                    return stderr_b_

                stderr_b = await asyncio.wait_for(_run_stream(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            duration = time.monotonic() - start
            res = ClaudeRunResult(
                ok=False,
                exit_code=124,
                duration_seconds=duration,
                command=cmd,
                cwd=cwd,
                stdout_text="",
                stderr_text="",
                raw_json=None,
                session_id=session_id,
                structured=None,
                error=f"Gemini CLI timed out after {timeout_seconds}s",
                log_file=str(log_path),
            )
            if raise_on_error:
                raise GeminiRunnerError(res.error or "Timeout")
            return res
        finally:
            log_file.close()

        exit_code = int(proc.returncode or 0)
        duration = time.monotonic() - start
        stderr_text = stderr_b.decode("utf-8", errors="replace")

        # Log stderr and exit code
        if stderr_text.strip():
            log_path.open("a", encoding="utf-8").write(f"[stderr] {stderr_text.strip()}\n")
        if exit_code != 0:
            log_path.open("a", encoding="utf-8").write(f"[exit] code={exit_code}\n")

        stdout_text = "\n".join(stdout_lines)
        structured: Optional[StructuredResponse] = None
        err: Optional[str] = had_error

        if exit_code != 0 and not err:
            err = f"Gemini CLI exited with code {exit_code}"

        # Build full response from assistant message chunks
        full_response = "".join(assistant_chunks).strip()

        # Gemini often wraps JSON in markdown code fences (```json ... ```).
        # Strip them before attempting to parse.
        json_text = _strip_code_fences(full_response)

        if json_text and not err:
            try:
                raw = json.loads(json_text)
                structured = parse_structured_response(raw)
            except json.JSONDecodeError:
                # Model returned non-JSON text — wrap it as a plain reply
                structured = StructuredResponse(reply=full_response, actions=[])
            except Exception:
                # Schema validation failed — try plain text fallback
                structured = StructuredResponse(reply=full_response, actions=[])

        if not structured and not err:
            if full_response:
                structured = StructuredResponse(reply=full_response, actions=[])
            else:
                err = "No output received from Gemini CLI"

        ok = (exit_code == 0) and (structured is not None) and (err is None)

        res = ClaudeRunResult(
            ok=ok,
            exit_code=exit_code,
            duration_seconds=duration,
            command=cmd,
            cwd=cwd,
            stdout_text=stdout_text,
            stderr_text=stderr_text,
            raw_json=None,
            session_id=session_id,
            structured=structured,
            error=err,
            log_file=str(log_path),
        )

        if raise_on_error and not ok:
            debug = (
                f"{res.error}\n"
                f"cwd={res.cwd}\n"
                f"cmd={shlex.join(res.command)}\n"
                f"stderr={res.stderr_text[-4000:]}"
            )
            raise GeminiRunnerError(debug)

        return res
