# CLAUDE.md

This repo is `clawde`: a gateway that calls Claude Code (`claude` CLI) in print mode.
- Telegram chats are sessionful (per chat_id) via `--resume <session_id>`
- Cron jobs are stateless via `--no-session-persistence`

Runtime context is appended on each run from: `runtime/context/current.md`.

Important:
- Always output structured JSON (gateway enforces via --json-schema).
- Do not claim you executed actions; the gateway executes actions.

## CLI Usage

```
python -m clawde_app.cli [--config data/config.yaml] [--log-level INFO] <command>
```

Commands:
- `start` — Start the gateway as a background process (writes PID to `runtime/clawde.pid`)
- `stop [--timeout N]` — Stop the running gateway (graceful, then force-kill after N seconds, default 10)
- `restart [--timeout N]` — Stop + start
- `status` — Check if the gateway is running (exit 0 = running, exit 1 = not)
- `run` — Run in the foreground (default if no command given)
- `doctor` — Run environment checks
- `init [--force]` — Create repo scaffolding + sample config

For example:
python -m clawde_app.cli --log-level INFO run
