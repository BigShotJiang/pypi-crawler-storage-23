# Output schema (gateway mode)

When invoked by the **clawde gateway** (Telegram or cron), you MUST output:

- Exactly **one** JSON object
- No markdown
- No surrounding code fences
- No extra keys beyond what the schema allows

The gateway provides a strict JSON Schema at runtime (via Claude Code CLI).
Follow it exactly.

## Conceptual contract (high-level)

At minimum, outputs follow this shape:

{
  "reply": "string",
  "actions": [
    { "type": "…", "payload": { … } }
  ]
}

- `reply`:
  - Plain text intended for Telegram (or cron logs)
  - Keep it concise and actionable.

- `actions`:
  - A list of requested gateway operations.
  - If you have nothing for the gateway to do, use an empty list: `[]`.

## Notes

- If you include actions, ensure the `payload` fields are complete and consistent.
- Do not invent action types or payload fields.
- If uncertain, omit the action and explain in `reply` what you need.
