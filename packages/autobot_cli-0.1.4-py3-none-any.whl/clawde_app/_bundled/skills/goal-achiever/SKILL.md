---
name: goal-achiever
description: >
  Long-horizon goal pursuit framework. Create structured goal workspaces
  with hypotheses, experiments, tasks, and metrics tracking.
---

# Goal Achiever Skill

## Overview

A file-based framework for pursuing **open-ended, long-horizon goals** through repeated bounded iterations. Each goal gets its own workspace directory created from a template, containing structured files for planning, tracking, and experimentation.

The workspace is the **control plane**: goal definition, tasks, hypotheses, experiments, decisions, logs, metrics. Work can also happen in **external repositories** — but state always gets written back to the workspace.

## Paths

All paths are relative to **this skill's directory** (the directory containing this SKILL.md file):

- **CLI tool**: `goalachiever.py` (in this directory)
- **Template**: `template/` (in this directory)
- **Workspaces**: `agents/<your_agent_name>/goals/` (in the repo root)

## CLI commands

All commands use `python` with the script's absolute path. Workspaces are stored per-agent using the `--root` and `--workspaces-dir` flags.

Replace `<SKILL_DIR>` with this skill's absolute directory path (parent of this SKILL.md) and `<AGENT_DIR>` with your agent's directory path (e.g., `agents/clawde`).

### Verify template
```bash
python "<SKILL_DIR>/goalachiever.py" doctor
```

### Create a new goal workspace
```bash
python "<SKILL_DIR>/goalachiever.py" --root "<AGENT_DIR>" --workspaces-dir goals init --goal "Your objective here"
```

Optional flags:
- `--slug "<slug>"` — explicit directory name
- `--external <path>` — link an external repo (repeatable)

### List goals
```bash
python "<SKILL_DIR>/goalachiever.py" --root "<AGENT_DIR>" --workspaces-dir goals list
```

### Goal info
```bash
python "<SKILL_DIR>/goalachiever.py" --root "<AGENT_DIR>" --workspaces-dir goals info <slug>
```

### Link external repo
```bash
python "<SKILL_DIR>/goalachiever.py" --root "<AGENT_DIR>" --workspaces-dir goals link <slug> --external /path/to/repo
```

### Update goal text
```bash
python "<SKILL_DIR>/goalachiever.py" --root "<AGENT_DIR>" --workspaces-dir goals set-goal <slug> --goal "Updated objective"
```

## Working on a goal (iteration protocol)

1. **Read the workspace's `CLAUDE.md`** — it defines the full iteration protocol in detail.
2. **Read status files**: `status/STATUS.md`, `status/NEXT_ACTIONS.md`, `status/METRICS.md`
3. **Choose 1-3 concrete actions** (the highest-priority from NEXT_ACTIONS.md)
4. **Execute** within your tool profile constraints
5. **Write back state** to the workspace:
   - `status/STATUS.md` — current truth
   - `status/NEXT_ACTIONS.md` — concrete next steps
   - `tasks/BOARD.md` — move task IDs
   - `logs/ITERATIONS.md` — append iteration entry
   - `memory/MEMORY.md` — if working memory changes
6. **Stop cleanly** — do not attempt unbounded loops

## Important rules

- **Bounded iterations**: One invocation = one iteration. Do NOT try to "finish everything."
- **Evidence-driven**: Use hypotheses + experiments. Record what you tried, what happened, and conclusions.
- **File hygiene**: Keep `memory/MEMORY.md` under 200 lines, `status/STATUS.md` under 160 lines, `status/NEXT_ACTIONS.md` under 60 lines. Compact into logs/daily when they grow.
- **Write state back**: Always update status files before finishing. The next invocation depends on this.

## Autonomous goal iteration via cron

Goals are designed for **repeated bounded iterations** over time. The recommended way to work on a goal continuously is via a **gapped cron job** — this prevents overlapping runs and respects the one-invocation-one-iteration rule.

### After creating a goal

When you create a goal (via `create_goal` action or `/goal create`), **ask the user** whether they want you to set up a recurring job to iterate on it automatically. Do NOT auto-schedule — always confirm first.

Suggest a gapped schedule (e.g., every 30–60 minutes). Example reply:

> Goal workspace created. Would you like me to set up a recurring job to work on this goal automatically? I'd suggest a gapped schedule (runs every 30 minutes after the previous run completes) so I can iterate on it continuously without overlap.

### Scheduling the iteration job

If the user confirms, emit a `schedule_job` action with:
- `schedule_type`: `"gapped"` (prevents overlap — next run starts only after previous completes)
- `schedule_value`: `{"minutes": 30}` (or whatever the user prefers)
- `sessionful`: Set to `true` for goal iteration jobs. This resumes the same CLI session across runs so the agent has full continuity of what it did in previous iterations. Trade-off: costs more tokens per run (~$0.45+) because the full session history is re-read, but provides much better context than stateless runs.
- `prompt`: The iteration instruction. With `sessionful: true`, the prompt can be shorter since the agent remembers prior iterations. It still needs the workspace path and basic instructions, but doesn't need to be fully self-contained. See the example below.
- `tool_profile`: Should match the current chat's tool profile (or `"dev"` if the goal requires writing code)
- `target_chat_id`: The current chat ID so the user sees progress updates
- `agent_profile`: Should be set to the current agent name (e.g., `"clawde"`) so the cron job runs as the correct agent with the right soul, memory, and goals context

### Example schedule_job action
```json
{
  "type": "schedule_job",
  "payload": {
    "name": "goal-iterate-api-latency",
    "schedule_type": "gapped",
    "schedule_value": "{\"minutes\": 30}",
    "sessionful": true,
    "prompt": "You are iterating on goal 'api-latency'. This is a stateless cron invocation — you have no chat history.\n\nWorkspace: agents/clawde/goals/api-latency\n\nSteps:\n1. Read the workspace CLAUDE.md for the full iteration protocol\n2. Read status/STATUS.md, status/NEXT_ACTIONS.md, and status/METRICS.md to understand current state\n3. Read tasks/BOARD.md for the task backlog\n4. Choose 1-3 highest-priority actions from NEXT_ACTIONS.md\n5. Execute them (read/write files, run commands as needed)\n6. Write back state: update STATUS.md, NEXT_ACTIONS.md, BOARD.md, and append to logs/ITERATIONS.md\n7. If working memory changed, update memory/MEMORY.md (keep under 200 lines)\n8. Write your reply as a Telegram update for the user. MUST include:\n   - Goal name and workspace path\n   - What you did this iteration (brief)\n   - Current blockers or questions (if any) — be specific about what you need from the user\n   - What's planned next\n\nSleep-aware scheduling: The user is typically unavailable 23:00–09:00. During these hours, focus on non-blocked tasks and do NOT post questions. If you have accumulated questions, note them in status/NEXT_ACTIONS.md for the first morning iteration to ask.\n\nThis is ONE bounded iteration. Do not loop or try to finish everything.",
    "tool_profile": "dev",
    "target_chat_id": 12345,
    "agent_profile": "clawde"
  }
}
```

### Active window and sleep-aware scheduling

If the user only wants work during certain hours, add `active_start` and `active_end` (e.g., `"09:00"` to `"22:00"`).

Even without an active window, the cron prompt should include sleep-awareness guidance. The user is typically unavailable 23:00–09:00. During these hours the agent should:
- Focus on non-blocked tasks (don't stall waiting for answers)
- Accumulate questions and post them in the first morning iteration (~09:00)
- Avoid posting non-urgent updates during sleep hours

### User answers and Telegram flow

Cron job updates are posted to Telegram via `target_chat_id`. The user may reply with answers, decisions, or new direction. Here's how that flows back to the workspace:

1. The **cron job reply** must include: goal name, workspace path, what was done, and any questions/blockers. This gives the Telegram agent (which is sessionful and sees the full chat history) all the context it needs.
2. When the **user replies** in Telegram, the sessionful agent sees both the cron update and the user's answer.
3. The **Telegram agent should write the answer back** to the goal workspace:
   - Update `status/STATUS.md` and `status/NEXT_ACTIONS.md` to reflect the decision
   - If it's a strategic decision, create an ADR in `decisions/` using the template
   - Unblock tasks on `tasks/BOARD.md` if the answer resolves a blocker
4. The **next cron iteration** reads the updated workspace files and continues with the unblocked work.

The workspace is the single source of truth — cron and Telegram agents coordinate through it.

## External repository workflow

When the goal involves changes in another repo:
1. Plan in the workspace first (tasks, hypotheses)
2. Execute in the external repo
3. Write evidence back to workspace (commit hashes, test results, metric changes)

Do not copy external repo contents into the workspace — store references and summaries only.

## Naming conventions

- Tasks: `T-YYYYMMDD-###`
- Hypotheses: `H-YYYYMMDD-###`
- Experiments: `E-YYYYMMDD-###`
- Decisions: `ADR-####`

## Creating a goal via action

You can also create goals by emitting a `create_goal` action:
```json
{"type": "create_goal", "payload": {"goal": "Your objective", "slug": "optional-slug"}}
```
