
# Playbook: Compaction (anti-bloat)

This workspace is meant to run indefinitely. Files must not grow without bound.

## Working docs (keep short)
- status/STATUS.md: target <= 160 lines
- status/NEXT_ACTIONS.md: target <= 60 lines
- memory/MEMORY.md: target <= 200 lines

## How to compact a doc
1. Identify the “current truth” (what must stay)
2. Summarize old details into:
   - logs/ITERATIONS.md (append a summary)
   - memory/daily/YYYY-MM-DD.md (date-stamped summary)
   - or specific hypothesis/experiment files
3. Replace verbose history with:
   - a short bullet summary
   - links to where details were moved

## What not to do
- Don’t delete evidence.
- Don’t keep copying the same context into multiple files.
- Don’t rewrite history unless correcting errors; prefer append-only logs.

## When in doubt
- Keep only the current plan + current blockers in working docs.
- Push everything else into logs/archives with links.
