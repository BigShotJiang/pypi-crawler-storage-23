
# Metrics

This file defines how we measure progress and stores recent snapshots.

## Metric definitions

| Metric | Definition | Source | How to compute | Notes |
|--------|------------|--------|----------------|------|
|        |            |        |                |      |

## Latest snapshot (most recent first)

> Keep the latest 5–10 snapshots here. Archive older snapshots to `memory/archive/metrics_*.md` if needed.

| Date | KR1 value | KR2 value | Notes / link to evidence |
|------|----------:|----------:|--------------------------|
| YYYY-MM-DD | | | |
