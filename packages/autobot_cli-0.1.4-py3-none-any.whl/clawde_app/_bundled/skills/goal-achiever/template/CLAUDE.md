
# Goal Achiever Workspace (Claude Code)

This repository is a **goal-conditioned, long-horizon workspace**.
It is meant to be operated by an agent (you) via repeated short runs (iterations).

The user will typically start Claude Code in this repo and prompt something like:
- “iterate the project”
- “do the next iteration”
- “advance toward the goal”

Your job is to **move the measurable goal forward** by:
- planning,
- creating/choosing tasks,
- running experiments,
- executing work (code, docs, analysis),
- validating results against metrics,
- and writing back state so the next run can continue.

## Non-negotiable rules

1. **Work in bounded iterations**
   - One invocation = one iteration.
   - Do not attempt “finish everything” in one run.
   - End every iteration with updated `status/NEXT_ACTIONS.md`.

2. **Keep the workspace readable**
   - Prefer short, current “working” docs + detailed logs/archives.
   - No file should grow without bound. Use compaction rules below.

3. **Be evidence-driven**
   - Use hypotheses + experiments.
   - Record what you tried, what happened, and what you concluded.
   - If an idea doesn’t work, **reject it explicitly** with evidence so we don’t loop.

4. **Write decisions down**
   - If you choose a strategy, record it as an ADR in `decisions/`.

5. **Avoid leaking internal reasoning**
   - Do **not** write long internal deliberations.
   - Write concise rationales, assumptions, and decision summaries.

## Always-read context (in this order)

At the start of every iteration, read:

1. `GOAL.md` (the objective, key results, constraints, definition of done)
2. `status/STATUS.md` (current state)
3. `status/METRICS.md` (how progress is measured; latest snapshots)
4. `status/NEXT_ACTIONS.md` (what to do next; keep it short)
5. `tasks/BOARD.md` (task Kanban overview)
6. `memory/MEMORY.md` (compact working memory; do not let it bloat)

Then read any linked/needed supporting documents:
- active hypotheses in `hypotheses/active/`
- recent experiments in `experiments/`
- recent decisions in `decisions/`
- latest entries in `logs/ITERATIONS.md`

## Iteration loop (what to do each time)

### Step 0 — Preflight & compaction (fast)
- If any “working” file exceeds its size limits, compact it **before** doing new work:
  - `memory/MEMORY.md` target: <= 200 lines
  - `status/STATUS.md` target: <= 160 lines
  - `status/NEXT_ACTIONS.md` target: <= 60 lines
- Move details to:
  - `memory/daily/` (date-stamped summaries)
  - `logs/ITERATIONS.md` (append-only iteration log)
  - hypothesis/experiment files

### Step 1 — Re-state the goal in your own words (1–3 sentences)
- Confirm what “done” means (key results / metrics).
- Note any hard constraints.

Write a short “Goal focus” line into the new iteration entry in `logs/ITERATIONS.md`.

### Step 2 — Observe current reality (facts, not ideas)
- Update or verify the latest metrics snapshot in `status/METRICS.md` **if possible**.
- Identify the biggest blocker or uncertainty.

If a metric can’t be updated due to missing access, record:
- what source is needed,
- how to obtain it,
- and create a task for it.

### Step 3 — Choose the next best bet (hypothesis-first)
Pick **1–3 actions** max for this iteration, based on expected impact and evidence needs.

Actions usually fall into one of these buckets:
- (A) **Measurement**: establish/verify baseline, instrumentation, data sources
- (B) **Experiment**: test a hypothesis cheaply to learn fast
- (C) **Execution**: implement a validated approach
- (D) **Decision**: resolve a strategic choice (record ADR)
- (E) **Unblock**: remove a dependency or ambiguity

Update `status/NEXT_ACTIONS.md` and move tasks on the board accordingly.

### Step 4 — Execute (do the work)
- Create or update tasks in `tasks/`.
- If experimenting, create an `experiments/E-*/` folder from the template and run the experiment.
- If implementing, change code/docs and run tests where applicable.
- Prefer small, reversible changes.

### Step 5 — Evaluate & learn
- Record results in the relevant experiment file(s).
- Update hypothesis status:
  - **validated** (promising + evidence),
  - **rejected** (doesn’t work + evidence),
  - **active** (still plausible; needs more evidence),
  - **parked** (low priority; not disproven).

### Step 6 — Write back state (required outputs)
You MUST update the workspace so the next iteration can continue without rereading everything.

Required updates:
- `status/STATUS.md` (current truth + what changed)
- `status/NEXT_ACTIONS.md` (concrete next 1–3 steps)
- `tasks/BOARD.md` (move task IDs across columns)
- `logs/ITERATIONS.md` (append one iteration entry with date/time, actions, outcomes)
- `memory/MEMORY.md` (only if the “current working memory” should change)

Optional updates:
- `decisions/ADR-*.md` (if a strategic choice was made)
- new/updated hypothesis files
- new/updated experiment folders

### Step 7 — Stop cleanly
End the run after state is written.
If something requires user input/access, explicitly list:
- the exact question,
- what you need,
- and why it blocks progress.

### Handling user input (from Telegram)

When working on a goal through Telegram (not cron), you may see cron-posted updates and user replies in the chat history. If the user has answered a question or made a decision that affects the goal:

1. Navigate to the goal workspace (path is in the cron update message)
2. Update `status/STATUS.md` to reflect the new information
3. Update `status/NEXT_ACTIONS.md` — remove the blocker, add the unblocked next steps
4. If it's a strategic decision, create an ADR in `decisions/` (use `decisions/ADR-TEMPLATE.md`)
5. Move affected tasks on `tasks/BOARD.md` (e.g., Blocked → Next)
6. Append a brief note to `logs/ITERATIONS.md`

This ensures the next cron iteration picks up the user's input without needing chat history.

## How to represent "multiple chains of thought"

Do **not** keep multiple long narrative thought streams in chat.
Instead, represent parallel thinking as structured artifacts:

- A **hypothesis thread** = one file in `hypotheses/active/`
- A **test** = one experiment folder in `experiments/`
- A **decision** = one ADR in `decisions/`
- A **task** = one task file in `tasks/` + an entry on `tasks/BOARD.md`

This gives you parallel tracks without infinite context growth.

## Workspace conventions

### IDs
Use date-based IDs to avoid collisions:
- Tasks: `T-YYYYMMDD-###`
- Hypotheses: `H-YYYYMMDD-###`
- Experiments: `E-YYYYMMDD-###`
- ADRs: `ADR-YYYYMMDD-###`

### Linking
When you create something new, link it:
- Task ↔ hypothesis ↔ experiment ↔ decision ↔ status

### Compaction rules (anti-bloat)
- If a “working” doc is too long, summarize and move details out.
- Never delete information outright; archive it.

Suggested approach:
- Keep “now” in `STATUS.md`
- Keep “how we got here” in `logs/ITERATIONS.md` and `memory/daily/*`

## Optional: external memory / associative retrieval

This repo works without external memory.
If an external memory MCP or API is available, you may:
- store embeddings for files (by path + hash),
- retrieve top-K relevant snippets for the current iteration,
- and write the retrieval result into the iteration log as “Retrieved context”.

If no external memory is available, approximate retrieval using:
- `rg` / grep across `hypotheses/`, `experiments/`, `decisions/`, `tasks/`, and `memory/topics/`.

## Security & safety
- Don’t exfiltrate secrets from environment files.
- Don’t run destructive commands unless explicitly required and clearly justified.
- Prefer dry-runs, backups, and small changes.
