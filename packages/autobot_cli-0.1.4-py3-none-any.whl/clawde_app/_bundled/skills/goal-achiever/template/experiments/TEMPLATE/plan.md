
# Experiment plan (E-YYYYMMDD-###)

## Linked hypothesis
- H-YYYYMMDD-###: `hypotheses/active/H-YYYYMMDD-###.md`

## Question
(What are we trying to learn?)

## Method
- Setup:
- Procedure:
- Tools / commands:
- Data sources:

## Success criteria
- …

## Failure criteria
- …

## Timeline
- Start:
- End:

## Risks / mitigation
- …
