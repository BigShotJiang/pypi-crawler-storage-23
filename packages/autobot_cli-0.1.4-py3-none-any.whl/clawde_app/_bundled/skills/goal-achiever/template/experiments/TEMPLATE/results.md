
# Experiment results

## Outcome
- Result: (success / fail / inconclusive)
- Summary (3–7 bullets):

## Data / evidence
- Links to files, screenshots, dashboards, logs, etc.

## Decision
- What we will do next:
- Hypothesis status update recommendation:
