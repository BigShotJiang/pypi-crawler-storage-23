
# External repositories / systems

Use this file when work is performed outside this goal workspace.

## External locations
List external repos, dashboards, docs, etc.

| Name | Type | Location | What it's for | Notes |
|------|------|----------|---------------|------|
|      | repo |          |               |      |

## Logging rule
If you change something external:
1. Create/Update a task describing it
2. Record what changed in `logs/ITERATIONS.md`
3. Add pointers/evidence links here (PR links, commit hashes, screenshots, etc.)
