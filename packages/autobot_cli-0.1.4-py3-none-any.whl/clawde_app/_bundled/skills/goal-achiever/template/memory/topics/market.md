# Market / customers

- (add notes)
