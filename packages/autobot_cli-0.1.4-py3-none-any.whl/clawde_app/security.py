from __future__ import annotations

import fnmatch
import secrets
import string
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional


def generate_pairing_code(length: int = 6) -> str:
    """
    Generate a short, human-typeable pairing code.
    Default: 6 digits.
    """
    digits = string.digits
    return "".join(secrets.choice(digits) for _ in range(max(4, int(length))))


def is_secret_path(path: Path, repo_root: Path, globs: Iterable[str]) -> bool:
    """
    Determine if a path should be considered secret/sensitive based on glob patterns.
    Used for defense-in-depth (e.g., deny reads/writes to config/db files).

    Patterns are matched against:
      - repo-relative posix path (preferred)
      - basename (fallback)
    """
    try:
        rel = path.resolve().relative_to(repo_root.resolve()).as_posix()
    except Exception:
        rel = path.as_posix()

    name = path.name
    for pat in globs:
        pat = (pat or "").strip()
        if not pat:
            continue
        # match rel path
        if fnmatch.fnmatch(rel, pat):
            return True
        # match basename
        if fnmatch.fnmatch(name, pat):
            return True
    return False


def deny_bash_command(cmd: str, deny_patterns: Iterable[str]) -> Optional[str]:
    """
    Return a reason string if cmd should be denied, else None.

    This is a lightweight check for gateway-level policy or hooks.
    """
    s = (cmd or "").lower()
    for pat in deny_patterns:
        p = (pat or "").strip().lower()
        if not p:
            continue
        if p in s:
            return f"command matched deny pattern: {pat}"
    return None


def should_respond_in_group(
    *,
    respond_in_groups: bool,
    require_mention: bool,
    bot_username: Optional[str],
    message_text: str,
    is_reply_to_bot: bool,
) -> bool:
    """
    Determine whether we should respond to a group chat message.

    Policy:
      - If respond_in_groups is False => never respond
      - Else respond if:
          - message is a reply to the bot OR
          - (require_mention is False) OR
          - bot username is mentioned as @username
    """
    if not respond_in_groups:
        return False

    if is_reply_to_bot:
        return True

    if not require_mention:
        return True

    if not bot_username:
        return False

    text = message_text or ""
    return f"@{bot_username.lower()}" in text.lower()


@dataclass(frozen=True)
class ActionPolicy:
    """
    Simple authorization rules enforced by the gateway (defense-in-depth),
    independent of what Claude suggests.
    """
    allow_non_admin_scheduling: bool = True
    allow_non_admin_job_mutation: bool = True
    allow_non_admin_tool_profile_change: bool = False
    # Non-admin may only select from these tool profiles if tool profile change is allowed
    non_admin_tool_profiles: tuple[str, ...] = ("safe_chat", "read_only")


def policy_allows_tool_profile(
    *,
    requested_profile: str,
    actor_is_admin: bool,
    policy: ActionPolicy,
) -> bool:
    if actor_is_admin:
        return True
    if not policy.allow_non_admin_tool_profile_change:
        return False
    return requested_profile in set(policy.non_admin_tool_profiles)
