"""Cron job management endpoints."""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ...models import JobScheduleType
from ..dependencies import get_db, get_scheduler

router = APIRouter()


def _enrich_job(job: Dict[str, Any]) -> Dict[str, Any]:
    """Parse autodev_config from JSON string to dict for API responses."""
    raw = job.get("autodev_config")
    if raw and isinstance(raw, str):
        try:
            job["autodev_config"] = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            pass
    return job


class JobCreate(BaseModel):
    name: str
    schedule_type: str
    schedule_value: str
    prompt: str = ""
    enabled: bool = True
    timezone: str = "UTC"
    tool_profile: str = "safe_chat"
    target_chat_id: Optional[int] = None
    backend: Optional[str] = None
    agent_profile: Optional[str] = None
    sessionful: bool = False
    use_chat_session: bool = False
    project_dir: Optional[str] = None
    active_start: Optional[str] = None
    active_end: Optional[str] = None
    autodev_config: Optional[dict] = None
    custom_instructions: Optional[str] = None
    model: Optional[str] = None
    thinking: Optional[str] = None


class JobUpdate(BaseModel):
    name: Optional[str] = None
    enabled: Optional[bool] = None
    prompt: Optional[str] = None
    schedule_type: Optional[str] = None
    schedule_value: Optional[str] = None
    timezone: Optional[str] = None
    tool_profile: Optional[str] = None
    backend: Optional[str] = None
    agent_profile: Optional[str] = None
    sessionful: Optional[bool] = None
    use_chat_session: Optional[bool] = None
    project_dir: Optional[str] = None
    target_chat_id: Optional[int] = None
    active_start: Optional[str] = None
    active_end: Optional[str] = None
    autodev_config: Optional[dict] = None
    custom_instructions: Optional[str] = None
    model: Optional[str] = None
    thinking: Optional[str] = None


class AutodevPromptPreview(BaseModel):
    config: dict
    custom_instructions: Optional[str] = None


class JobLinkCreate(BaseModel):
    linked_job_id: int
    enabled: bool = True


class JobLinkUpdate(BaseModel):
    enabled: bool


@router.get("")
async def list_jobs(db=Depends(get_db)):
    jobs = await db.list_jobs()
    return [_enrich_job(j) for j in jobs]


@router.get("/running")
async def running_jobs(scheduler=Depends(get_scheduler)):
    if scheduler is None:
        return {"running": []}
    return {"running": list(scheduler.running_job_ids)}


@router.post("/preview-autodev-prompt")
async def preview_autodev_prompt(body: AutodevPromptPreview):
    """Preview the prompt that would be generated from an autodev config."""
    from ...actions import build_autodev_prompt

    try:
        prompt = build_autodev_prompt(body.config, body.custom_instructions)
    except KeyError as e:
        raise HTTPException(400, f"Missing required config field: {e}")
    return {"prompt": prompt}


@router.post("")
async def create_job(body: JobCreate, db=Depends(get_db), scheduler=Depends(get_scheduler)):
    try:
        stype = JobScheduleType(body.schedule_type)
    except ValueError:
        raise HTTPException(400, f"Invalid schedule_type: {body.schedule_type}")

    prompt = body.prompt
    autodev_config_str: Optional[str] = None
    custom_instructions: Optional[str] = body.custom_instructions

    # If autodev_config is provided, build the prompt from it
    if body.autodev_config:
        from ...actions import build_autodev_prompt

        try:
            prompt = build_autodev_prompt(body.autodev_config, custom_instructions)
        except KeyError as e:
            raise HTTPException(400, f"Missing required autodev config field: {e}")
        autodev_config_str = json.dumps(body.autodev_config)

    if not prompt:
        raise HTTPException(400, "prompt is required (or provide autodev_config to auto-generate)")

    if body.use_chat_session:
        if body.target_chat_id is None:
            raise HTTPException(400, "use_chat_session requires target_chat_id")
        chat_row = await db.get_chat(body.agent_profile or "", body.target_chat_id)
        if chat_row and chat_row.backend:
            job_backend = body.backend or "claude"
            if chat_row.backend != job_backend:
                raise HTTPException(
                    400,
                    f"use_chat_session: backend mismatch — job uses '{job_backend}' "
                    f"but chat uses '{chat_row.backend}'. Sessions are not cross-compatible.",
                )

    job_id = await db.create_job(
        name=body.name,
        enabled=body.enabled,
        schedule_type=stype,
        schedule_value=body.schedule_value,
        timezone_str=body.timezone,
        prompt=prompt,
        target_chat_id=body.target_chat_id,
        tool_profile=body.tool_profile,
        active_start=body.active_start,
        active_end=body.active_end,
        backend=body.backend,
        agent_profile=body.agent_profile,
        sessionful=body.sessionful or body.use_chat_session,
        project_dir=body.project_dir,
        autodev_config=autodev_config_str,
        custom_instructions=custom_instructions,
        use_chat_session=body.use_chat_session,
        model=body.model or None,
        thinking=body.thinking or None,
    )
    if scheduler:
        await scheduler.reload_jobs()
    return {"ok": True, "job_id": job_id}


@router.get("/{job_id}")
async def get_job(job_id: int, db=Depends(get_db)):
    job = await db.get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return _enrich_job(job)


@router.patch("/{job_id}")
async def update_job(job_id: int, body: JobUpdate, db=Depends(get_db), scheduler=Depends(get_scheduler)):
    job = await db.get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")

    updates = body.model_dump(exclude_none=True)
    if not updates:
        return {"ok": True, "message": "No changes"}

    # Allow clearing model/thinking back to default via empty string
    for field in ("model", "thinking"):
        if field in updates and updates[field] == "":
            updates[field] = None  # Store as NULL = use backend default

    # Handle autodev_config: serialize to JSON and rebuild prompt
    if "autodev_config" in updates:
        from ...actions import build_autodev_prompt

        new_config = updates["autodev_config"]
        ci = updates.get("custom_instructions", job.get("custom_instructions"))
        try:
            updates["prompt"] = build_autodev_prompt(new_config, ci)
        except KeyError as e:
            raise HTTPException(400, f"Missing required autodev config field: {e}")
        updates["autodev_config"] = json.dumps(new_config)
    elif "custom_instructions" in updates and job.get("autodev_config"):
        # Only custom_instructions changed but job has autodev_config — rebuild prompt
        from ...actions import build_autodev_prompt

        existing_config = job["autodev_config"]
        if isinstance(existing_config, str):
            existing_config = json.loads(existing_config)
        ci = updates["custom_instructions"]
        try:
            updates["prompt"] = build_autodev_prompt(existing_config, ci)
        except KeyError:
            pass  # Fall through, keep existing prompt

    # use_chat_session implies sessionful
    if updates.get("use_chat_session"):
        updates["sessionful"] = True

    ok = await db.update_job_fields(job_id, **updates)
    if ok and scheduler:
        await scheduler.reload_jobs()
    return {"ok": ok, "message": "Updated" if ok else "No rows affected"}


@router.delete("/{job_id}")
async def delete_job(job_id: int, db=Depends(get_db), scheduler=Depends(get_scheduler)):
    job = await db.get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    await db.delete_job(job_id)
    if scheduler:
        await scheduler.reload_jobs()
    return {"ok": True}


@router.post("/{job_id}/trigger")
async def trigger_job(job_id: int, db=Depends(get_db), scheduler=Depends(get_scheduler)):
    job = await db.get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if scheduler is None:
        raise HTTPException(503, "Scheduler not available")
    try:
        await scheduler.trigger_job(job_id)
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    return {"ok": True, "message": f"Job {job_id} triggered"}


@router.post("/{job_id}/stop")
async def stop_job(job_id: int, scheduler=Depends(get_scheduler)):
    if scheduler is None:
        raise HTTPException(503, "Scheduler not available")
    stopped = await scheduler.stop_job(job_id)
    if not stopped:
        raise HTTPException(404, "Job is not currently running")
    return {"ok": True, "message": f"Job {job_id} stopped"}


@router.get("/{job_id}/runs")
async def job_runs(job_id: int, db=Depends(get_db)):
    runs = await db.get_runs_for_job(job_id)
    return runs


# ----------------------------
# Job links (post-completion triggers)
# ----------------------------

@router.get("/{job_id}/links")
async def list_job_links(job_id: int, db=Depends(get_db)):
    job = await db.get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    links = await db.list_job_links(job_id)
    enriched = []
    for link in links:
        target = await db.get_job(link["linked_job_id"])
        enriched.append({
            **link,
            "linked_job_name": target["name"] if target else "(deleted)",
            "linked_job_enabled": bool(target["enabled"]) if target else False,
        })
    return enriched


@router.post("/{job_id}/links")
async def create_job_link(job_id: int, body: JobLinkCreate, db=Depends(get_db)):
    if body.linked_job_id == job_id:
        raise HTTPException(400, "A job cannot be linked to itself")
    job = await db.get_job(job_id)
    if not job:
        raise HTTPException(404, "Source job not found")
    target = await db.get_job(body.linked_job_id)
    if not target:
        raise HTTPException(404, "Target job not found")
    try:
        link_id = await db.create_job_link(job_id, body.linked_job_id, body.enabled)
    except Exception:
        raise HTTPException(409, "Link already exists")
    return {"ok": True, "id": link_id}


@router.patch("/{job_id}/links/{link_id}")
async def update_job_link(job_id: int, link_id: int, body: JobLinkUpdate, db=Depends(get_db)):
    ok = await db.update_job_link_enabled(link_id, body.enabled)
    if not ok:
        raise HTTPException(404, "Link not found")
    return {"ok": True}


@router.delete("/{job_id}/links/{link_id}")
async def delete_job_link(job_id: int, link_id: int, db=Depends(get_db)):
    await db.delete_job_link(link_id)
    return {"ok": True}
