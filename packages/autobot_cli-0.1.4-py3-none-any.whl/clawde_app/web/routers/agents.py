"""Agent registry endpoints."""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ...agent_profile import create_agent_scaffold, validate_agent_name
from ..dependencies import get_cfg, get_paths, get_db

router = APIRouter()


class AgentCreate(BaseModel):
    name: str
    soul: str = ""


@router.get("")
async def list_agents(cfg=Depends(get_cfg), paths=Depends(get_paths), db=Depends(get_db)):
    result = []
    for name in cfg.agents:
        agent_dir = paths.agents_dir / name
        soul_path = agent_dir / "soul.md"
        soul_preview = ""
        if soul_path.exists():
            text = soul_path.read_text(encoding="utf-8", errors="replace")
            soul_preview = text[:200]

        chats = await db.list_chats(agent_name=name)
        result.append({
            "name": name,
            "default_backend": cfg.agents[name].default_backend,
            "chat_count": len(chats),
            "soul_preview": soul_preview,
            "has_goals": (agent_dir / "goals" / "REGISTRY.json").exists(),
        })
    return result


@router.post("")
async def create_agent(body: AgentCreate, paths=Depends(get_paths)):
    err = validate_agent_name(body.name)
    if err:
        raise HTTPException(400, err)
    try:
        create_agent_scaffold(paths.agents_dir, body.name, soul_text=body.soul or None)
    except FileExistsError:
        raise HTTPException(409, f"Agent '{body.name}' already exists")
    return {"ok": True, "name": body.name}


@router.get("/{name}")
async def get_agent(name: str, cfg=Depends(get_cfg), paths=Depends(get_paths), db=Depends(get_db)):
    if name not in cfg.agents:
        raise HTTPException(404, "Agent not found")

    agent_dir = paths.agents_dir / name
    soul_path = agent_dir / "soul.md"
    soul = ""
    if soul_path.exists():
        soul = soul_path.read_text(encoding="utf-8", errors="replace")

    memory_index = ""
    mem_index_path = agent_dir / "memory" / "MEMORY.md"
    if mem_index_path.exists():
        memory_index = mem_index_path.read_text(encoding="utf-8", errors="replace")

    chats = await db.list_chats(agent_name=name)

    # Goals
    goals = []
    registry_path = agent_dir / "goals" / "REGISTRY.json"
    if registry_path.exists():
        try:
            reg = json.loads(registry_path.read_text(encoding="utf-8"))
            goals = list(reg.get("workspaces", {}).keys())
        except Exception:
            pass

    # Skills
    skills_list = []
    agent_skills_dir = agent_dir / "skills"
    if agent_skills_dir.is_dir():
        for sd in agent_skills_dir.iterdir():
            if sd.is_dir() and (sd / "SKILL.md").exists():
                skills_list.append(sd.name)

    return {
        "name": name,
        "default_backend": cfg.agents[name].default_backend,
        "soul": soul,
        "memory_index": memory_index,
        "chat_count": len(chats),
        "chats": chats,
        "goals": goals,
        "skills": skills_list,
    }


@router.get("/{name}/soul")
async def get_soul(name: str, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    if name not in cfg.agents:
        raise HTTPException(404, "Agent not found")
    soul_path = paths.agents_dir / name / "soul.md"
    if not soul_path.exists():
        return {"content": ""}
    return {"content": soul_path.read_text(encoding="utf-8", errors="replace")}


class SoulUpdate(BaseModel):
    content: str


@router.put("/{name}/soul")
async def update_soul(name: str, body: SoulUpdate, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    if name not in cfg.agents:
        raise HTTPException(404, "Agent not found")
    soul_path = paths.agents_dir / name / "soul.md"
    soul_path.parent.mkdir(parents=True, exist_ok=True)
    soul_path.write_text(body.content, encoding="utf-8")
    return {"ok": True}
