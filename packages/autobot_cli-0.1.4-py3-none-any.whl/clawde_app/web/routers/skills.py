"""Skills registry endpoints."""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from ...skills import write_skill, sanitize_skill_name
from ..dependencies import get_paths, get_cfg

router = APIRouter()


def _list_skills_in_dir(skills_dir: Path, scope: str) -> list:
    """List skills in a directory."""
    result = []
    if not skills_dir.is_dir():
        return result
    for entry in sorted(skills_dir.iterdir()):
        if entry.is_dir():
            skill_md = entry / "SKILL.md"
            if skill_md.exists():
                text = skill_md.read_text(encoding="utf-8", errors="replace")
                # Extract description from first non-frontmatter paragraph
                desc = ""
                in_frontmatter = False
                for line in text.split("\n"):
                    if line.strip() == "---":
                        in_frontmatter = not in_frontmatter
                        continue
                    if not in_frontmatter and line.strip() and not line.startswith("#"):
                        desc = line.strip()[:120]
                        break
                result.append({
                    "name": entry.name,
                    "scope": scope,
                    "description": desc,
                    "has_skill_md": True,
                })
    return result


def _resolve_skill_dir(name: str, scope: str, paths, cfg) -> Path:
    """Resolve the directory for a skill given its scope."""
    if scope.startswith("agent:"):
        agent_name = scope.split(":", 1)[1]
        if agent_name not in cfg.agents:
            raise HTTPException(400, f"Unknown agent: {agent_name}")
        return paths.agents_dir / agent_name / "skills"
    return paths.skills_dir


@router.get("")
async def list_skills(paths=Depends(get_paths), cfg=Depends(get_cfg)):
    skills = _list_skills_in_dir(paths.skills_dir, "global")
    for agent_name in cfg.agents:
        agent_skills = paths.agents_dir / agent_name / "skills"
        skills.extend(_list_skills_in_dir(agent_skills, f"agent:{agent_name}"))
    return skills


class SkillCreate(BaseModel):
    name: str
    content: str
    scope: str = "global"


@router.post("")
async def create_skill(body: SkillCreate, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    try:
        clean_name = sanitize_skill_name(body.name)
    except ValueError as e:
        raise HTTPException(400, str(e))

    skills_dir = _resolve_skill_dir(clean_name, body.scope, paths, cfg)
    skill_dir = skills_dir / clean_name
    if skill_dir.exists():
        raise HTTPException(409, f"Skill '{clean_name}' already exists")

    write_skill(skills_dir, clean_name, body.content)
    return {"ok": True, "name": clean_name}


class SkillUpdate(BaseModel):
    content: str
    scope: Optional[str] = None


@router.put("/{name}")
async def update_skill(name: str, body: SkillUpdate, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    # Find the skill to determine its location
    if body.scope:
        skills_dir = _resolve_skill_dir(name, body.scope, paths, cfg)
    else:
        # Auto-detect: check global first, then agent skills
        skill_dir = paths.skills_dir / name
        if skill_dir.is_dir():
            skills_dir = paths.skills_dir
        else:
            skills_dir = None
            for agent_name in cfg.agents:
                candidate = paths.agents_dir / agent_name / "skills" / name
                if candidate.is_dir():
                    skills_dir = paths.agents_dir / agent_name / "skills"
                    break
            if skills_dir is None:
                raise HTTPException(404, "Skill not found")

    write_skill(skills_dir, name, body.content)
    return {"ok": True}


@router.delete("/{name}")
async def delete_skill(name: str, scope: str = Query("global"), paths=Depends(get_paths), cfg=Depends(get_cfg)):
    skills_dir = _resolve_skill_dir(name, scope, paths, cfg)
    skill_dir = skills_dir / name
    if not skill_dir.is_dir():
        # Try auto-detect if scope is global but not found
        if scope == "global":
            for agent_name in cfg.agents:
                candidate = paths.agents_dir / agent_name / "skills" / name
                if candidate.is_dir():
                    skill_dir = candidate
                    break
        if not skill_dir.is_dir():
            raise HTTPException(404, "Skill not found")

    shutil.rmtree(skill_dir)
    return {"ok": True}


@router.get("/{name}/content")
async def get_skill_content(name: str, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    # Check global skills first
    skill_md = paths.skills_dir / name / "SKILL.md"
    if skill_md.exists():
        return {"name": name, "scope": "global", "content": skill_md.read_text(encoding="utf-8", errors="replace")}

    # Check agent skills
    for agent_name in cfg.agents:
        agent_skill_md = paths.agents_dir / agent_name / "skills" / name / "SKILL.md"
        if agent_skill_md.exists():
            return {
                "name": name,
                "scope": f"agent:{agent_name}",
                "content": agent_skill_md.read_text(encoding="utf-8", errors="replace"),
            }

    raise HTTPException(404, "Skill not found")
