from __future__ import annotations

import asyncio
import json
import logging
import os
import shlex
import shutil
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .config import AppConfig, AppPaths, ToolProfile
from .models import RunMode, StructuredResponse, parse_structured_response, structured_response_json_schema_str


@dataclass
class ClaudeRunResult:
    ok: bool
    exit_code: int
    duration_seconds: float

    command: List[str]
    cwd: str

    stdout_text: str
    stderr_text: str

    raw_json: Optional[Dict[str, Any]]
    session_id: Optional[str]
    structured: Optional[StructuredResponse]

    error: Optional[str] = None
    log_file: Optional[str] = None


class ClaudeRunnerError(RuntimeError):
    pass


def _split_allowed_tools(allowed_tools: str) -> List[str]:
    """
    `--allowedTools` supports multiple values (space-separated args). We store them
    in config as a comma-separated string so patterns like `Bash(git diff *)`
    (which contain spaces) remain intact as a single argv token.

    Example config string:
      'Read,Grep,Glob,Bash(git status *),Bash(git diff *)'
    -> argv tokens: ["Read", "Grep", "Glob", "Bash(git status *)", "Bash(git diff *)"]
    """
    s = (allowed_tools or "").strip()
    if not s:
        return []
    # Split on commas only; preserve spaces inside tool patterns.
    parts = [p.strip() for p in s.split(",")]
    return [p for p in parts if p]


class ClaudeRunner:
    """
    Thin async wrapper around the `claude` CLI (Claude Code).

    We always run in print mode (-p) and request JSON output.

    Official docs:
      - Print/headless mode + JSON output: https://code.claude.com/docs/en/headless
      - CLI flags: https://code.claude.com/docs/en/cli-reference
    """

    def __init__(self, cfg: AppConfig, paths: AppPaths):
        self.cfg = cfg
        self.paths = paths

    def _resolve_executable(self) -> str:
        """
        Resolve the configured Claude executable to a runnable command on the
        current platform.

        Windows-specific paths (e.g. `C:\\...\\claude.cmd`) can be carried over
        from existing configs; on Linux we normalize those to the CLI name and
        use PATH lookup.
        """
        exe = (self.cfg.claude.executable or "claude").strip().strip('"')
        if os.name != "nt":
            exe_normalized = exe.replace("\\", "/")

            # Direct PATH lookup (handles `claude`, `/usr/bin/claude`, etc.).
            direct = shutil.which(exe_normalized)
            if direct:
                return direct

            # Handle Windows-style paths/commands such as `C:\\...\\claude.cmd`.
            exe_name = Path(exe_normalized).name
            base_name = exe_name
            if exe_name.lower().endswith(".cmd") or exe_name.lower().endswith(".bat"):
                base_name = exe_name.rsplit(".", 1)[0]
            elif exe_name.lower().endswith(".exe"):
                base_name = exe_name.rsplit(".", 1)[0]

            fallback = shutil.which(base_name)
            if fallback:
                return fallback

            return base_name

        # On Windows, asyncio.create_subprocess_exec needs the full path
        # to .cmd shims — shutil.which resolves e.g. "claude" -> "...\\claude.cmd"
        resolved = shutil.which(exe)
        return resolved or exe

    @staticmethod
    async def _read_stream(stream) -> bytes:
        """Read an entire asyncio stream into bytes."""
        chunks = []
        while True:
            chunk = await stream.read(8192)
            if not chunk:
                break
            chunks.append(chunk)
        return b"".join(chunks)

    def _build_command(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str] = None,
        no_session_persistence: bool = False,
        append_system_prompt_file: Optional[Path] = None,
        max_turns: Optional[int] = None,
        json_schema: Optional[str] = None,
        extra_args: Optional[Sequence[str]] = None,
    ) -> List[str]:
        if mode == RunMode.telegram and no_session_persistence:
            raise ValueError("Telegram runs must be sessionful; do not set no_session_persistence=True.")
        profile: ToolProfile = self.cfg.get_tool_profile(tool_profile_name)
        schema_str = json_schema or structured_response_json_schema_str(minified=True)

        cmd: List[str] = [self._resolve_executable(), "-p"]

        # Model override (optional)
        if self.cfg.claude.model:
            cmd += ["--model", self.cfg.claude.model]

        # System prompt append file (print-only; we are in print mode)
        if append_system_prompt_file is not None:
            cmd += ["--append-system-prompt-file", str(append_system_prompt_file)]

        # Session behavior
        if resume_session_id:
            cmd += ["--resume", resume_session_id]
        if no_session_persistence:
            cmd += ["--no-session-persistence"]

        if profile.dangerously_skip_permissions:
            # YOLO mode: bypass all permission checks, no tool restrictions.
            cmd.append("--dangerously-skip-permissions")
        else:
            # Tool restriction
            # "*" means all tools (omit --tools flag entirely).
            # "" means no tools (--tools "" disables all tools).
            # Anything else is a comma-separated whitelist.
            if profile.tools != "*":
                cmd += ["--tools", profile.tools]

            # Auto-approval to avoid hanging for permission prompts in print mode.
            allowed_list = _split_allowed_tools(profile.allowed_tools)
            if allowed_list:
                cmd.append("--allowedTools")
                cmd.extend(allowed_list)

        # Output format + schema
        cmd += ["--output-format", self.cfg.claude.output_format]
        if self.cfg.claude.output_format == "stream-json":
            cmd.append("--verbose")
        cmd += ["--json-schema", schema_str]

        # Max turns guardrail
        if max_turns is not None:
            cmd += ["--max-turns", str(max_turns)]

        if extra_args:
            cmd += list(extra_args)

        # Prompt is positional at the end (matches docs examples)
        cmd.append(prompt)
        return cmd

    def _format_stream_event(self, event: Dict[str, Any]) -> str:
        """Format a stream-json event as a human-readable log line."""
        etype = event.get("type", "?")

        if etype == "system" and event.get("subtype") == "init":
            model = event.get("model", "?")
            sid = event.get("session_id", "?")[:12]
            tools = event.get("tools", [])
            return f"[init] session={sid}... model={model} tools={tools}\n"

        if etype == "assistant":
            msg = event.get("message", {})
            content = msg.get("content", [])
            parts: List[str] = []
            for block in content:
                if block.get("type") == "text":
                    text = block.get("text", "")
                    preview = text[:200] + "..." if len(text) > 200 else text
                    parts.append(f"[assistant] {preview}")
                elif block.get("type") == "tool_use":
                    name = block.get("name", "?")
                    inp = block.get("input", {})
                    inp_str = json.dumps(inp, ensure_ascii=False)
                    if len(inp_str) > 200:
                        inp_str = inp_str[:200] + "..."
                    parts.append(f"[tool_call] {name}: {inp_str}")
            return "\n".join(parts) + "\n" if parts else f"[assistant] (empty)\n"

        if etype == "user":
            msg = event.get("message", {})
            content = msg.get("content", [])
            for block in content:
                if block.get("type") == "tool_result":
                    result_text = str(block.get("content", ""))
                    preview = result_text[:200] + "..." if len(result_text) > 200 else result_text
                    return f"[tool_result] {preview}\n"
            return "[user] (tool result)\n"

        if etype == "result":
            subtype = event.get("subtype", "?")
            cost = event.get("total_cost_usd", 0)
            turns = event.get("num_turns", 0)
            dur = event.get("duration_ms", 0)
            return f"[result] {subtype}, cost=${cost:.4f}, turns={turns}, duration={dur/1000:.1f}s\n"

        return f"[{etype}] {json.dumps(event, ensure_ascii=False)[:300]}\n"

    def make_log_path(self, mode: RunMode) -> Path:
        """Generate the log file path for a run. Call before run() to get the
        path early (e.g. to store in DB at start_run time)."""
        log_dir = self.paths.stderr_log_dir
        log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return log_dir / f"claude_{mode.value}_{timestamp}.log"

    async def run(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str] = None,
        no_session_persistence: bool = False,
        append_system_prompt_file: Optional[Path] = None,
        max_turns: Optional[int] = None,
        json_schema: Optional[str] = None,
        extra_args: Optional[Sequence[str]] = None,
        timeout_seconds: Optional[int] = None,
        raise_on_error: bool = False,
        env_overrides: Optional[Dict[str, str]] = None,
        cwd_override: Optional[Path] = None,
        on_event: Optional[Callable[[Dict[str, Any]], Any]] = None,
        on_proc_started: Optional[Callable[[asyncio.subprocess.Process], Any]] = None,
        log_path: Optional[Path] = None,
    ) -> ClaudeRunResult:
        """
        Execute the `claude` CLI and parse its output.

        When output_format is 'stream-json', reads NDJSON lines from stdout in real time,
        logs each event to a file, and extracts the final result. When 'json', buffers
        stdout and parses a single JSON blob.

        Returns:
          ClaudeRunResult where `.structured` contains the validated output (reply/actions).
        """
        cmd = self._build_command(
            prompt,
            mode=mode,
            tool_profile_name=tool_profile_name,
            resume_session_id=resume_session_id,
            no_session_persistence=no_session_persistence,
            append_system_prompt_file=append_system_prompt_file,
            max_turns=max_turns,
            json_schema=json_schema,
            extra_args=extra_args,
        )

        cwd = str(cwd_override) if cwd_override else str(self.paths.repo_root)

        env = os.environ.copy()
        # Claude CLI rejects --dangerously-skip-permissions when running as root.
        # IS_SANDBOX=1 signals to the CLI that we're in a sandboxed environment.
        if getattr(os, "getuid", lambda: -1)() == 0:
            env.setdefault("IS_SANDBOX", "1")
        if env_overrides:
            env.update(env_overrides)

        is_streaming = self.cfg.claude.output_format == "stream-json"

        # Prepare log file for real-time monitoring
        if log_path is None:
            log_path = self.make_log_path(mode)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = open(log_path, "w", encoding="utf-8")
        latest_path = log_path.parent / "latest.log"

        log = logging.getLogger("clawde.runner")
        log.info("Claude streaming to: %s", log_path)

        # NOTE: We intentionally do NOT set shell=True.
        start = time.monotonic()
        # Use a large buffer limit (16 MB) so that big tool results
        # (e.g. reading large files) don't crash readline() with
        # LimitOverrunError.  The default is only 64 KB.
        _STREAM_LIMIT = 16 * 1024 * 1024  # 16 MB
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=cwd,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=_STREAM_LIMIT,
        )

        if on_proc_started is not None:
            try:
                on_proc_started(proc)
            except Exception:
                pass

        stdout_lines: List[str] = []
        result_event: Optional[Dict[str, Any]] = None
        last_assistant_text: List[str] = []
        init_session_id: Optional[str] = None

        async def _stream_stdout_ndjson():
            """Read stdout line-by-line, log events, capture result."""
            nonlocal result_event, init_session_id
            assert proc.stdout is not None
            while True:
                line_b = await proc.stdout.readline()
                if not line_b:
                    break
                line = line_b.decode("utf-8", errors="replace").rstrip("\n\r")
                if not line:
                    continue
                stdout_lines.append(line)
                try:
                    event = json.loads(line)
                    formatted = self._format_stream_event(event)
                    log_file.write(formatted)
                    log_file.flush()
                    if on_event is not None:
                        try:
                            ret = on_event(event)
                            if asyncio.iscoroutine(ret):
                                await ret
                        except Exception:
                            pass
                    if event.get("type") == "result":
                        result_event = event
                    elif event.get("type") == "assistant":
                        # Capture assistant text for fallback if CLI dies mid-run
                        for block in event.get("message", {}).get("content", []):
                            if block.get("type") == "text" and block.get("text", "").strip():
                                last_assistant_text.append(block["text"].strip())
                    elif event.get("type") == "system" and event.get("subtype") == "init":
                        init_session_id = event.get("session_id")
                except json.JSONDecodeError:
                    log_file.write(f"[raw] {line[:500]}\n")
                    log_file.flush()

        try:
            if is_streaming:
                # Stream NDJSON from stdout, capture stderr for diagnostics
                if timeout_seconds is None:
                    _, stderr_b = await asyncio.gather(
                        _stream_stdout_ndjson(),
                        self._read_stream(proc.stderr),
                    )
                    await proc.wait()
                else:
                    async def _run_stream():
                        _, stderr_b_ = await asyncio.gather(
                            _stream_stdout_ndjson(),
                            self._read_stream(proc.stderr),
                        )
                        await proc.wait()
                        return stderr_b_

                    stderr_b = await asyncio.wait_for(_run_stream(), timeout=timeout_seconds)
            else:
                # Legacy json mode: buffer everything
                if timeout_seconds is None:
                    stdout_b, stderr_b = await proc.communicate()
                else:
                    stdout_b, stderr_b = await asyncio.wait_for(
                        proc.communicate(), timeout=timeout_seconds
                    )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            duration = time.monotonic() - start
            res = ClaudeRunResult(
                ok=False,
                exit_code=124,
                duration_seconds=duration,
                command=cmd,
                cwd=cwd,
                stdout_text="",
                stderr_text="",
                raw_json=None,
                session_id=None,
                structured=None,
                error=f"Claude CLI timed out after {timeout_seconds}s",
                log_file=str(log_path),
            )
            if raise_on_error:
                raise ClaudeRunnerError(res.error or "Timeout")
            return res
        finally:
            log_file.close()
            try:
                latest_path.write_text(str(log_path), encoding="utf-8")
            except Exception:
                pass

        exit_code = int(proc.returncode or 0)
        duration = time.monotonic() - start
        stderr_text = stderr_b.decode("utf-8", errors="replace")

        # Log stderr and exit code for diagnostics
        if stderr_text.strip():
            log_path.open("a", encoding="utf-8").write(f"[stderr] {stderr_text.strip()}\n")
        if exit_code != 0:
            log_path.open("a", encoding="utf-8").write(f"[exit] code={exit_code}\n")

        raw_json: Optional[Dict[str, Any]] = None
        session_id: Optional[str] = None
        structured: Optional[StructuredResponse] = None
        err: Optional[str] = None

        if is_streaming:
            stdout_text = "\n".join(stdout_lines)
            if result_event is not None:
                raw_json = result_event
                if exit_code != 0:
                    # Non-zero exit (e.g. last tool call failed) but we still
                    # got a result event with structured output — use it.
                    err = f"Claude CLI exited with code {exit_code}"
            elif last_assistant_text:
                # CLI died mid-run (no result event) but we captured assistant
                # text from the stream. Use it as a degraded fallback reply.
                fallback_reply = last_assistant_text[-1]
                structured = StructuredResponse(reply=fallback_reply, actions=[])
                session_id = init_session_id
                err = f"Claude CLI exited with code {exit_code} (reply recovered from stream)"
            elif exit_code != 0:
                err = f"Claude CLI exited with code {exit_code}"
            else:
                err = "No result event received from Claude CLI stream"
        else:
            stdout_text = stdout_b.decode("utf-8", errors="replace")
            if exit_code != 0:
                err = f"Claude CLI exited with code {exit_code}"
            else:
                try:
                    raw_json = json.loads(stdout_text)
                except Exception as e:
                    err = f"Failed to parse Claude JSON output: {e}"

        if raw_json is not None:
            # Capture session_id if present (prefer result event, fall back to init)
            if isinstance(raw_json.get("session_id"), str):
                session_id = raw_json.get("session_id")
            elif init_session_id:
                session_id = init_session_id

            # Parse validated structured output
            try:
                structured = parse_structured_response(raw_json)
            except Exception:
                # Fallback: degrade gracefully if schema didn't validate
                result_text = raw_json.get("result")
                if isinstance(result_text, str) and result_text.strip():
                    structured = StructuredResponse(reply=result_text, actions=[])
                else:
                    err = err or "Missing or invalid structured output from Claude CLI"

        # Consider the run successful if we got valid structured output,
        # even if exit_code != 0 (e.g. last tool call failed but reply is fine).
        ok = structured is not None

        res = ClaudeRunResult(
            ok=ok,
            exit_code=exit_code,
            duration_seconds=duration,
            command=cmd,
            cwd=cwd,
            stdout_text=stdout_text,
            stderr_text=stderr_text,
            raw_json=raw_json,
            session_id=session_id,
            structured=structured,
            error=err,
            log_file=str(log_path),
        )

        if raise_on_error and not ok:
            debug = (
                f"{res.error}\n"
                f"cwd={res.cwd}\n"
                f"cmd={shlex.join(res.command)}\n"
                f"stderr={res.stderr_text[-4000:]}"
            )
            raise ClaudeRunnerError(debug)

        return res
