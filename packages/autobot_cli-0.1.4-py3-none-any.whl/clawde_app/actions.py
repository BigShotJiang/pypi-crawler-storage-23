from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .agent_profile import resolve_agent, ensure_agent_scaffold
from .config import AppConfig, AppPaths
from .db import Database
from .models import (
    Action,
    ActionType,
    AppendDailyLogPayload,
    ChatStatus,
    EnableDisableDeleteJobPayload,
    JobScheduleType,
    ModifyJobPayload,
    RunMode,
    ScheduleJobPayload,
    SetBackendPayload,
    StructuredResponse,
    WriteMemoryPayload,
    SetToolProfilePayload,
    SetProjectDirPayload,
    WriteSkillPayload,
    ToggleSkillPayload,
    CreateGoalPayload,
    RegisterMCPServerPayload,
    RemoveMCPServerPayload,
    SetupAutonomousDevPayload,
)
from .memory_retrieval import ensure_memory_scaffold
from .skills import write_skill as do_write_skill

# Lazy-loaded autonomous dev prompt template
_AUTODEV_TEMPLATE: Optional[str] = None


def _load_autonomous_dev_template() -> str:
    global _AUTODEV_TEMPLATE
    if _AUTODEV_TEMPLATE is None:
        template_path = Path(__file__).parent / "templates" / "autonomous_dev_prompt.md"
        _AUTODEV_TEMPLATE = template_path.read_text(encoding="utf-8")
    return _AUTODEV_TEMPLATE


def build_autodev_prompt(config: dict, custom_instructions: Optional[str] = None) -> str:
    """Rebuild the autonomous dev prompt from structured pipeline config.

    Used by the scheduler at runtime and by the API when creating/updating
    autodev jobs, so that config changes take effect on the next run.
    """
    template = _load_autonomous_dev_template()

    kanban_base_url = config.get("kanban_base_url", "http://kanbanboard.local:3000")
    project_id = config["project_id"]
    include_pipeline = config.get("include_pipeline_run", True)

    if include_pipeline:
        pipeline_body = json.dumps(
            {
                "sync_status": config.get("sync_status", True),
                "evolve_methods": config.get("evolve_methods", ["unified"]),
                "include_project_evolve": config.get("include_project_evolve", False),
                "max_depth": config.get("max_depth", 3),
                "max_new_tasks": config.get("max_new_tasks", 15),
                "max_milestone_tasks": config.get("max_milestone_tasks", 50),
                "ground_hierarchy_evolve": config.get("ground_hierarchy_evolve", True),
                "codebase_evolve_goal": config.get("codebase_evolve_goal", ""),
                "milestone_creation_llm": config.get("milestone_creation_llm", False),
                "milestone_creation_cli": config.get("milestone_creation_cli", True),
                "exclude_status": config.get("exclude_status", ["done", "ideas", "review", "testing"]),
                "prefer_status": config.get("prefer_status", ["in_progress", "todo"]),
                "max_candidates": config.get("max_candidates", 40),
            },
            indent=2,
        )
        no_task_instruction = "- If `selected` IS null: no tasks available. Go to STEP 2."
        pipeline_section = _build_pipeline_section(kanban_base_url, project_id, pipeline_body)
        step_implement = 3
        step_report = 4
        pipeline_rule = "- Do NOT skip STEP 2 when no tasks are available. The autonomous pipeline generates new work.\n"
        retry_subject = "the pipeline or "
    else:
        no_task_instruction = "- If `selected` IS null: no tasks available. Report this and stop."
        pipeline_section = ""
        step_implement = 2
        step_report = 3
        pipeline_rule = ""
        retry_subject = ""

    prompt = template.format(
        project_id=project_id,
        kanban_base_url=kanban_base_url,
        no_task_instruction=no_task_instruction,
        pipeline_section=pipeline_section,
        step_implement=step_implement,
        step_report=step_report,
        pipeline_rule=pipeline_rule,
        retry_subject=retry_subject,
    )

    if config.get("use_project_manager", False):
        prompt += _build_project_manager_section(kanban_base_url, project_id)

    if custom_instructions:
        prompt += "\n\n=== CUSTOM INSTRUCTIONS ===\n" + custom_instructions.strip() + "\n"
    return prompt


def _build_pipeline_section(kanban_base_url: str, project_id: str, pipeline_body: str) -> str:
    return (
        f"\n=== STEP 2: RUN AUTONOMOUS PIPELINE (only if no tasks available) ===\n"
        f"\n"
        f"Start the async pipeline:\n"
        f"POST {kanban_base_url}/api/ai/projects/{project_id}/autonomous-next/start\n"
        f"Content-Type: application/json\n"
        f"Body:\n"
        f"{pipeline_body}\n"
        f"\n"
        f'This returns {{"job_id": "...", "status": "running"}} (HTTP 202).\n'
        f"If you get 409 Conflict, a pipeline is already running — use the returned job_id to poll.\n"
        f"\n"
        f"Now poll for completion every 30 seconds (max 20 minutes):\n"
        f"GET {kanban_base_url}/api/ai/jobs/{{job_id}}\n"
        f"\n"
        f"Keep polling until `status` is `completed` or `failed`.\n"
        f"- If `completed`: read `result.selected` for the task and `result.context.agent_instructions` for the full task brief. Go to STEP 3.\n"
        f"- If `completed` but `result.selected` is null: no tasks could be generated. Report this and stop.\n"
        f"- If `failed`: report the error and stop.\n"
        f"- If still `running` after 20 minutes: report timeout and stop.\n"
        f"\n"
        f"IMPORTANT: The pipeline can take 2-20 minutes. Be patient and keep polling every 30 seconds. Do NOT give up early.\n"
        f"\n"
    )


def _build_project_manager_section(kanban_base_url: str, project_id: str) -> str:
    return f"""

=== PROJECT MANAGER ===

This project has a built-in AI Project Manager with full context about the project scope, status, all tasks, and milestones. It can both answer questions and make changes.

When to use the Project Manager:
- Clarifying unclear task requirements before implementation
- Getting project context ("What is this project about?", "What milestones are in progress?")
- Asking for guidance ("Is there a task that covers database migrations?")
- Requesting task/milestone changes via natural language

Send a message:
POST {kanban_base_url}/api/projects/{project_id}/chat
Body: {{"message": "Your question or instruction here"}}

Response:
- `message.content` — The PM's natural language reply
- `actions_performed` — Array of any changes it made (tasks created, updated, deleted). If non-empty, the Kanban board was modified.

Get conversation history:
GET {kanban_base_url}/api/projects/{project_id}/chat?limit=50

IMPORTANT: Use the Project Manager to clarify requirements BEFORE implementing. If a task description is vague, ask the PM rather than guessing.
"""


@dataclass
class ActionExecContext:
    """
    Context about who/what initiated this run.
    """
    mode: RunMode
    actor_chat_id: Optional[int] = None
    actor_is_admin: bool = False
    agent_name: Optional[str] = None
    tool_profile: Optional[str] = None
    backend: Optional[str] = None


@dataclass
class ActionExecSummary:
    """
    Result of executing actions.
    - user_notices: safe to append to Telegram reply
    - internal_logs: good for logs/diagnostics
    - scheduler_changed: caller should reload APScheduler jobs if True
    """
    user_notices: List[str]
    internal_logs: List[str]
    scheduler_changed: bool
    trigger_job_ids: List[int] = field(default_factory=list)


_TOPIC_SAFE_RE = re.compile(r"[^a-zA-Z0-9_\-]+")


def sanitize_topic_name(topic: str) -> str:
    """
    Prevent path traversal / weird filenames for memory topic files.

    - Lowercase
    - Replace unsafe characters with underscore
    - Strip leading/trailing underscores
    - Fallback to "misc" if empty
    """
    t = (topic or "").strip().lower()
    t = _TOPIC_SAFE_RE.sub("_", t)
    t = t.strip("_")
    return t or "misc"


def _today_ymd() -> str:
    return datetime.now().date().strftime("%Y-%m-%d")


def _validate_cron_5_fields(expr: str) -> bool:
    # Very light validation: 5 fields separated by spaces.
    parts = [p for p in (expr or "").strip().split() if p]
    return len(parts) == 5


def _canonical_interval_json(s: str) -> Tuple[Optional[str], Optional[Dict[str, int]], Optional[str]]:
    """
    Accept either:
      - a JSON object string: {"minutes": 30}
      - key=value pairs: "minutes=30 hours=1"
      - key:value pairs: "minutes:30,hours:1"

    Returns (canonical_json_string, parsed_dict, error)
    """
    raw = (s or "").strip()
    if not raw:
        return None, None, "interval schedule_value is empty"

    # Try JSON first
    if raw.startswith("{") and raw.endswith("}"):
        try:
            obj = json.loads(raw)
            if not isinstance(obj, dict):
                return None, None, "interval schedule_value JSON must be an object"
            parsed: Dict[str, int] = {}
            for k, v in obj.items():
                if not isinstance(k, str):
                    continue
                if isinstance(v, bool):
                    continue
                if isinstance(v, (int, float)) and int(v) > 0:
                    parsed[k] = int(v)
                elif isinstance(v, str) and v.strip().isdigit():
                    parsed[k] = int(v.strip())
                else:
                    return None, None, f"interval schedule_value contains invalid value for '{k}'"
            if not parsed:
                return None, None, "interval schedule_value JSON produced empty schedule"
            canon = json.dumps(parsed, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            return canon, parsed, None
        except Exception as e:
            return None, None, f"invalid interval JSON: {e}"

    # Parse key/value pairs
    norm = raw.replace(",", " ")
    parts = [p for p in norm.split() if p]
    parsed2: Dict[str, int] = {}
    for p in parts:
        if "=" in p:
            k, v = p.split("=", 1)
        elif ":" in p:
            k, v = p.split(":", 1)
        else:
            return None, None, f"invalid interval token '{p}' (expected key=value)"
        k = k.strip()
        v = v.strip()
        if not k:
            continue
        if not v.isdigit():
            return None, None, f"invalid interval value '{v}' for '{k}'"
        iv = int(v)
        if iv <= 0:
            return None, None, f"interval value must be > 0 for '{k}'"
        parsed2[k] = iv

    if not parsed2:
        return None, None, "interval schedule_value produced empty schedule"

    canon = json.dumps(parsed2, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return canon, parsed2, None


def _safe_append_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text("", encoding="utf-8")
    # Ensure exactly one trailing newline on append content
    to_add = content
    if not to_add.endswith("\n"):
        to_add += "\n"
    with path.open("a", encoding="utf-8") as f:
        f.write(to_add)


class ActionExecutor:
    """
    Deterministically executes actions returned by Claude.
    """
    def __init__(self, cfg: AppConfig, paths: AppPaths, db: Database, *, memory_index=None):
        self.cfg = cfg
        self.paths = paths
        self.db = db
        self.memory_index = memory_index  # Optional MemoryIndex for reindex after writes

    async def _reindex_file(self, agent_name: str, path: Path) -> None:
        """Trigger memory index reindex for a file, if hybrid search is active."""
        if self.memory_index is not None:
            try:
                await self.memory_index.reindex_file(agent_name, path)
            except Exception:
                pass  # Non-critical; file watcher will catch it too

    def _resolve_memory_dirs(self, agent_name: Optional[str]) -> Tuple[Path, Path]:
        """Return (topics_dir, daily_dir) for the given agent (or global fallback)."""
        if agent_name:
            agent = resolve_agent(self.paths.agents_dir, agent_name)
            if agent:
                ensure_agent_scaffold(agent)
                return agent.memory_topics_dir, agent.memory_daily_dir
        return self.paths.memory_topics_dir, self.paths.memory_daily_dir

    async def execute_actions(
        self,
        structured: StructuredResponse,
        ctx: ActionExecContext,
    ) -> ActionExecSummary:
        topics_dir, daily_dir = self._resolve_memory_dirs(ctx.agent_name)
        ensure_memory_scaffold(
            self.paths,
            topics_dir=topics_dir,
            daily_dir=daily_dir,
        )

        user_notices: List[str] = []
        internal_logs: List[str] = []
        scheduler_changed = False
        trigger_job_ids: List[int] = []

        for action in structured.actions or []:
            try:
                # trigger_job is special: collect job IDs for the caller to execute
                if action.type == ActionType.trigger_job:
                    job_id = (action.payload or {}).get("job_id")
                    if not isinstance(job_id, int):
                        user_notices.append("[!] trigger_job requires job_id (int).")
                        internal_logs.append("trigger_job_invalid_payload")
                        continue
                    job = await self.db.get_job(job_id)
                    if not job:
                        user_notices.append(f"[!] Job #{job_id} not found.")
                        internal_logs.append(f"trigger_job_not_found id={job_id}")
                        continue
                    trigger_job_ids.append(job_id)
                    user_notices.append(f"[OK] Triggering job #{job_id}.")
                    internal_logs.append(f"trigger_job id={job_id}")
                    continue

                changed, notice, log = await self._execute_one(action, ctx, topics_dir, daily_dir)
                scheduler_changed = scheduler_changed or changed
                if notice:
                    user_notices.append(notice)
                if log:
                    internal_logs.append(log)
            except Exception as e:
                internal_logs.append(f"action_failed type={getattr(action, 'type', None)} err={e}")
                user_notices.append("[!] I couldn't apply one of the requested actions due to an internal error.")

        return ActionExecSummary(
            user_notices=user_notices,
            internal_logs=internal_logs,
            scheduler_changed=scheduler_changed,
            trigger_job_ids=trigger_job_ids,
        )

    async def _execute_one(
        self, action: Action, ctx: ActionExecContext,
        topics_dir: Path, daily_dir: Path,
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        atype = action.type

        if atype == ActionType.schedule_job:
            return await self._schedule_job(action.payload, ctx)

        if atype in (ActionType.enable_job, ActionType.disable_job, ActionType.delete_job):
            return await self._mutate_job(atype, action.payload, ctx)

        if atype == ActionType.modify_job:
            return await self._modify_job(action.payload, ctx)

        if atype == ActionType.write_memory:
            return await self._write_memory(action.payload, ctx, topics_dir)

        if atype == ActionType.append_daily_log:
            return await self._append_daily_log(action.payload, ctx, daily_dir)

        if atype == ActionType.set_tool_profile:
            return await self._set_tool_profile(action.payload, ctx)

        if atype == ActionType.set_project_dir:
            return await self._set_project_dir(action.payload, ctx)

        if atype == ActionType.set_backend:
            return await self._set_backend(action.payload, ctx)

        if atype == ActionType.write_skill:
            return await self._write_skill(action.payload, ctx)

        if atype == ActionType.enable_skill:
            return await self._toggle_skill(action.payload, ctx, enable=True)

        if atype == ActionType.disable_skill:
            return await self._toggle_skill(action.payload, ctx, enable=False)

        if atype == ActionType.create_goal:
            if not self.cfg.features.goals:
                return False, "[!] Goals feature is disabled.", "goals_disabled"
            return await self._create_goal(action.payload, ctx)

        if atype == ActionType.register_mcp_server:
            return await self._register_mcp_server(action.payload, ctx)

        if atype == ActionType.remove_mcp_server:
            return await self._remove_mcp_server(action.payload, ctx)

        if atype == ActionType.setup_autonomous_dev:
            return await self._setup_autonomous_dev(action.payload, ctx)

        # Unknown action types should not crash.
        return False, None, f"ignored_unknown_action type={atype}"

    # ----------------------------
    # Action implementations
    # ----------------------------
    async def _schedule_job(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        # Normalize schedule_value: agent may send a dict like {"hours": 4}
        # instead of the JSON string '{"hours": 4}'
        sv = payload.get("schedule_value")
        if isinstance(sv, dict):
            payload["schedule_value"] = json.dumps(sv)

        # Validate
        try:
            m = ScheduleJobPayload(**payload)
        except Exception as e:
            detail = str(e)
            if len(detail) > 300:
                detail = detail[:300] + "..."
            return False, f"[!] I couldn't schedule that job (invalid payload: {detail}).", f"schedule_job_invalid_payload err={e}"

        # Inherit chat/job defaults when payload uses Pydantic defaults
        # (explicit values in the payload win over context)
        def _pcopy(obj, updates):
            """Pydantic v1/v2 compat copy."""
            fn = getattr(obj, "model_copy", None) or obj.copy
            return fn(update=updates)

        if m.tool_profile == "read_only" and ctx.tool_profile:
            m = _pcopy(m, {"tool_profile": ctx.tool_profile})
        if m.backend is None and ctx.backend:
            m = _pcopy(m, {"backend": ctx.backend})

        # Default target chat id in telegram mode
        target_chat_id = m.target_chat_id
        if target_chat_id is None and ctx.mode == RunMode.telegram and ctx.actor_chat_id is not None:
            target_chat_id = ctx.actor_chat_id

        # Authorization
        if target_chat_id is not None and ctx.actor_chat_id is not None:
            if (target_chat_id != ctx.actor_chat_id) and (not ctx.actor_is_admin):
                return False, "[!] I can't schedule jobs into other chats.", "schedule_job_denied_target_chat"

        # Tool profile must exist
        if m.tool_profile not in self.cfg.claude.tool_profiles and m.tool_profile != "safe_chat":
            # allow safe_chat fallback even if not explicitly configured
            return False, f"[!] Unknown tool profile: {m.tool_profile}", "schedule_job_unknown_tool_profile"

        # Normalize schedule_value
        schedule_value = (m.schedule_value or "").strip()

        if m.schedule_type == JobScheduleType.cron:
            if not _validate_cron_5_fields(schedule_value):
                return False, "[!] Invalid cron expression. Use 5 fields like `0 9 * * *`.", "schedule_job_invalid_cron"

        elif m.schedule_type == JobScheduleType.interval:
            canon, _parsed, err = _canonical_interval_json(schedule_value)
            if err:
                return False, f"[!] Invalid interval schedule: {err}", f"schedule_job_invalid_interval err={err}"
            schedule_value = canon or schedule_value

        elif m.schedule_type == JobScheduleType.once:
            # Accept ISO string; validate parseability loosely
            try:
                # datetime.fromisoformat accepts "YYYY-MM-DDTHH:MM:SS" or with offset
                _ = datetime.fromisoformat(schedule_value.replace("Z", "+00:00"))
            except Exception:
                return False, "[!] Invalid once schedule datetime. Use ISO like `2026-02-07T09:00:00`.", "schedule_job_invalid_once"

        elif m.schedule_type == JobScheduleType.gapped:
            canon, _parsed, err = _canonical_interval_json(schedule_value)
            if err:
                return False, f"[!] Invalid gapped schedule: {err}", f"schedule_job_invalid_gapped err={err}"
            schedule_value = canon or schedule_value

        # Validate active window
        active_start = (m.active_start or "").strip() or None
        active_end = (m.active_end or "").strip() or None
        if bool(active_start) != bool(active_end):
            return False, "[!] Both active_start and active_end must be set (or both omitted).", "schedule_job_partial_active_window"
        if active_start:
            import re
            hhmm = re.compile(r"^\d{2}:\d{2}$")
            if not hhmm.match(active_start) or not hhmm.match(active_end):
                return False, "[!] active_start/active_end must be HH:MM format.", "schedule_job_invalid_active_window"

        # use_chat_session requires a target chat
        if m.use_chat_session and target_chat_id is None:
            return (
                False,
                "[!] use_chat_session requires target_chat_id.",
                "schedule_job_use_chat_session_no_target",
            )

        # use_chat_session: validate backend compatibility
        if m.use_chat_session and target_chat_id is not None:
            agent_profile = m.agent_profile or ctx.agent_name
            chat_row = await self.db.get_chat(agent_profile or "", target_chat_id)
            if chat_row and chat_row.backend:
                job_backend = m.backend or (
                    self.cfg.agents[agent_profile].default_backend
                    if agent_profile and agent_profile in self.cfg.agents
                    else self.cfg.default_backend
                )
                if chat_row.backend != job_backend:
                    return (
                        False,
                        f"[!] use_chat_session: backend mismatch — job uses '{job_backend}' "
                        f"but chat uses '{chat_row.backend}'. Sessions are not cross-compatible.",
                        "schedule_job_use_chat_session_backend_mismatch",
                    )

        # Inherit project_dir from chat if not explicitly set
        project_dir = m.project_dir
        if project_dir is None and ctx.actor_chat_id is not None:
            chat_row = await self.db.get_chat(ctx.agent_name or "", ctx.actor_chat_id)
            if chat_row and chat_row.project_dir:
                project_dir = chat_row.project_dir

        # Create in DB enabled=True
        agent_profile = m.agent_profile or ctx.agent_name
        job_id = await self.db.create_job(
            name=m.name,
            enabled=True,
            schedule_type=m.schedule_type,
            schedule_value=schedule_value,
            timezone_str=m.timezone or self.cfg.scheduler.timezone,
            prompt=m.prompt,
            target_chat_id=target_chat_id,
            tool_profile=m.tool_profile,
            active_start=active_start,
            active_end=active_end,
            backend=m.backend,
            agent_profile=agent_profile,
            sessionful=m.sessionful or m.use_chat_session,
            project_dir=project_dir,
            use_chat_session=m.use_chat_session,
        )
        if m.use_chat_session:
            session_label = ", use_chat_session"
        elif m.sessionful:
            session_label = ", sessionful"
        else:
            session_label = ""
        notice = f"[OK] Scheduled job #{job_id}: `{m.name}` ({m.schedule_type.value}{session_label})"
        log = f"scheduled_job id={job_id} name={m.name} type={m.schedule_type.value} target_chat_id={target_chat_id}"
        return True, notice, log

    async def _setup_autonomous_dev(
        self, payload: Dict[str, Any], ctx: ActionExecContext,
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = SetupAutonomousDevPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid setup_autonomous_dev payload.", f"setup_autodev_invalid err={e}"

        # Validate project_dir
        p = Path(m.project_dir)
        if not p.is_absolute():
            return False, "[!] project_dir must be an absolute path.", "setup_autodev_not_absolute"
        if not p.exists() or not p.is_dir():
            return False, f"[!] Directory not found: {m.project_dir}", "setup_autodev_dir_missing"

        # Build structured autodev config
        autodev_config: Dict[str, Any] = {
            "project_id": m.project_id,
            "kanban_base_url": m.kanban_base_url,
            "evolve_methods": m.evolve_methods,
            "sync_status": m.sync_status,
            "include_project_evolve": m.include_project_evolve,
            "max_depth": m.max_depth,
            "max_new_tasks": m.max_new_tasks,
            "max_milestone_tasks": m.max_milestone_tasks,
            "ground_hierarchy_evolve": m.ground_hierarchy_evolve,
            "codebase_evolve_goal": m.codebase_evolve_goal,
            "milestone_creation_llm": m.milestone_creation_llm,
            "milestone_creation_cli": m.milestone_creation_cli,
            "exclude_status": m.exclude_status,
            "prefer_status": m.prefer_status,
            "max_candidates": m.max_candidates,
            "use_project_manager": m.use_project_manager,
            "include_pipeline_run": m.include_pipeline_run,
        }

        prompt = build_autodev_prompt(autodev_config, m.custom_instructions)

        # Build a schedule_job payload and delegate
        job_name = m.job_name or f"kanban_autodev_{m.project_id[:8]}"
        schedule_payload: Dict[str, Any] = {
            "name": job_name,
            "schedule_type": m.schedule_type.value,
            "schedule_value": m.schedule_value,
            "prompt": prompt,
            "tool_profile": "full",
            "sessionful": True,
            "project_dir": m.project_dir,
        }
        if m.backend:
            schedule_payload["backend"] = m.backend
        if m.active_start:
            schedule_payload["active_start"] = m.active_start
        if m.active_end:
            schedule_payload["active_end"] = m.active_end

        ok, notice, log = await self._schedule_job(schedule_payload, ctx)
        if ok and notice:
            # Extract job_id from notice and store autodev config
            import re as _re
            match = _re.search(r"job #(\d+)", notice)
            if match:
                job_id = int(match.group(1))
                await self.db.update_job_fields(
                    job_id,
                    autodev_config=json.dumps(autodev_config),
                    custom_instructions=m.custom_instructions,
                )
        return ok, notice, log

    async def _mutate_job(self, atype: ActionType, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = EnableDisableDeleteJobPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid job action payload.", f"job_mutation_invalid_payload type={atype} err={e}"

        job = await self.db.get_job(m.job_id)
        if not job:
            return False, f"[!] Job #{m.job_id} not found.", f"job_not_found id={m.job_id}"

        target_chat_id = job.get("target_chat_id")

        # Authorization:
        # - admin can mutate any job
        # - non-admin can only mutate jobs that target their chat_id
        if not ctx.actor_is_admin:
            if ctx.actor_chat_id is None or (target_chat_id != ctx.actor_chat_id):
                return False, "[!] You don't have permission to modify that job.", "job_mutation_denied"

        if atype == ActionType.enable_job:
            await self.db.set_job_enabled(m.job_id, True)
            return True, f"[OK] Enabled job #{m.job_id}.", f"job_enabled id={m.job_id}"

        if atype == ActionType.disable_job:
            await self.db.set_job_enabled(m.job_id, False)
            return True, f"[OK] Disabled job #{m.job_id}.", f"job_disabled id={m.job_id}"

        if atype == ActionType.delete_job:
            await self.db.delete_job(m.job_id)
            return True, f"[OK] Deleted job #{m.job_id}.", f"job_deleted id={m.job_id}"

        return False, None, f"job_mutation_ignored type={atype} id={m.job_id}"

    async def _modify_job(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        # Normalize schedule_value if present (agent may send dict instead of string)
        sv = payload.get("schedule_value")
        if isinstance(sv, dict):
            payload["schedule_value"] = json.dumps(sv)

        try:
            m = ModifyJobPayload(**payload)
        except Exception as e:
            detail = str(e)
            if len(detail) > 300:
                detail = detail[:300] + "..."
            return False, f"[!] Invalid modify_job payload: {detail}", f"modify_job_invalid_payload err={e}"

        job = await self.db.get_job(m.job_id)
        if not job:
            return False, f"[!] Job #{m.job_id} not found.", f"modify_job_not_found id={m.job_id}"

        # Authorization (same as _mutate_job)
        target_chat_id = job.get("target_chat_id")
        if not ctx.actor_is_admin:
            if ctx.actor_chat_id is None or (target_chat_id != ctx.actor_chat_id):
                return False, "[!] You don't have permission to modify that job.", "modify_job_denied"

        # Validate fields
        if m.tool_profile is not None:
            if m.tool_profile not in self.cfg.claude.tool_profiles and m.tool_profile != "safe_chat":
                return False, f"[!] Unknown tool profile: {m.tool_profile}", "modify_job_unknown_tool_profile"
        if m.backend is not None:
            if m.backend not in ("claude", "codex", "gemini"):
                return False, f"[!] Unknown backend: {m.backend}", "modify_job_unknown_backend"

        updates: Dict[str, Any] = {}
        if m.tool_profile is not None:
            updates["tool_profile"] = m.tool_profile
        if m.backend is not None:
            updates["backend"] = m.backend
        if m.prompt is not None:
            updates["prompt"] = m.prompt
        if m.enabled is not None:
            updates["enabled"] = m.enabled
        if m.schedule_value is not None:
            updates["schedule_value"] = m.schedule_value
        if m.sessionful is not None:
            updates["sessionful"] = m.sessionful
        if m.use_chat_session is not None:
            updates["use_chat_session"] = m.use_chat_session
            if m.use_chat_session:
                updates["sessionful"] = True
        if m.project_dir is not None:
            # Empty string means "clear back to default"
            updates["project_dir"] = m.project_dir if m.project_dir else None
        if m.autodev_config is not None:
            updates["autodev_config"] = json.dumps(m.autodev_config)
            # Rebuild prompt from the new config
            custom_instructions = job.get("custom_instructions")
            try:
                updates["prompt"] = build_autodev_prompt(m.autodev_config, custom_instructions)
            except Exception:
                pass  # Keep existing prompt if rebuild fails

        if not updates:
            return False, "[!] No fields to update.", "modify_job_no_fields"

        ok = await self.db.update_job_fields(m.job_id, **updates)
        if not ok:
            return False, f"[!] Failed to update job #{m.job_id}.", f"modify_job_failed id={m.job_id}"

        # Clear stored session when disabling sessionful or changing backend
        if m.sessionful is False or m.backend is not None:
            await self.db.update_job_session_id(m.job_id, None)

        changed = ", ".join(f"{k}={v}" for k, v in updates.items())
        return True, f"[OK] Updated job #{m.job_id}: {changed}", f"modify_job id={m.job_id} {changed}"

    async def _write_memory(self, payload: Dict[str, Any], ctx: ActionExecContext, topics_dir: Path) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = WriteMemoryPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid memory write payload.", f"write_memory_invalid_payload err={e}"

        topic = sanitize_topic_name(m.topic)
        path = topics_dir / f"{topic}.md"
        path.parent.mkdir(parents=True, exist_ok=True)

        content = (m.content_md or "").strip()
        if not content:
            return False, None, "write_memory_empty_content"

        if m.mode == "replace":
            # Preserve a basic header if file doesn't exist
            if not path.exists():
                header = f"# {topic}\n\n"
                path.write_text(header, encoding="utf-8")
            path.write_text(content.rstrip() + "\n", encoding="utf-8")
            await self._reindex_file(ctx.agent_name or "", path)
            return False, "[OK] Updated memory topic.", f"write_memory_replace topic={topic} path={path.as_posix()}"

        # append
        if not path.exists():
            path.write_text(f"# {topic}\n\n", encoding="utf-8")

        _safe_append_file(path, "\n" + content.strip() + "\n")
        await self._reindex_file(ctx.agent_name or "", path)
        return False, "[OK] Added to memory.", f"write_memory_append topic={topic} path={path.as_posix()}"

    async def _append_daily_log(self, payload: Dict[str, Any], ctx: ActionExecContext, daily_dir: Path) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = AppendDailyLogPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid daily log payload.", f"append_daily_log_invalid_payload err={e}"

        d = (m.date or "").strip()
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", d):
            d = _today_ymd()

        path = daily_dir / f"{d}.md"
        path.parent.mkdir(parents=True, exist_ok=True)

        content = (m.content_md or "").strip()
        if not content:
            return False, None, "append_daily_log_empty_content"

        if not path.exists():
            path.write_text(f"# Daily log {d}\n\n", encoding="utf-8")

        # Always append as bullet if not already a list item
        to_add = content
        if not to_add.lstrip().startswith(("-", "*")):
            to_add = "- " + to_add

        _safe_append_file(path, to_add + "\n")
        await self._reindex_file(ctx.agent_name or "", path)
        return False, "[OK] Logged to daily notes.", f"append_daily_log date={d} path={path.as_posix()}"

    async def _set_tool_profile(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = SetToolProfilePayload(**payload)
        except Exception as e:
            return False, "[!] Invalid tool profile payload.", f"set_tool_profile_invalid_payload err={e}"

        requested = (m.tool_profile or "").strip()
        if not requested:
            return False, "[!] Empty tool profile.", "set_tool_profile_empty"

        # Tool profile must exist in config (or safe_chat fallback)
        if requested not in self.cfg.claude.tool_profiles and requested != "safe_chat":
            return False, f"[!] Unknown tool profile: {requested}", "set_tool_profile_unknown"

        # Authorization:
        # - admin can set any chat's profile
        # - non-admin can only set their own profile AND only to safe ones
        if not ctx.actor_is_admin:
            if ctx.actor_chat_id is None or m.chat_id != ctx.actor_chat_id:
                return False, "[!] You don't have permission to change that.", "set_tool_profile_denied_other_chat"
            if requested not in ("safe_chat", "read_only"):
                return False, "[!] Only admins can enable powerful tool profiles.", "set_tool_profile_denied_nonadmin"

        agent_name = ctx.agent_name or "default"
        chat = await self.db.get_chat(agent_name, m.chat_id)
        if not chat:
            # Create the chat row if missing (rare)
            await self.db.create_chat(agent_name, m.chat_id, status=ChatStatus.paired, pairing_code=None, tool_profile=requested)
        else:
            await self.db.update_chat_tool_profile(agent_name, m.chat_id, requested)

        return False, f"[OK] Tool profile set to `{requested}`.", f"set_tool_profile chat_id={m.chat_id} profile={requested}"

    async def _set_project_dir(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = SetProjectDirPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid project dir payload.", f"set_project_dir_invalid_payload err={e}"

        # Admin-only
        if not ctx.actor_is_admin:
            return False, "[!] Only admins can change the project directory.", "set_project_dir_denied_nonadmin"

        agent_name = ctx.agent_name or "default"
        raw = (m.project_dir or "").strip() if m.project_dir else None
        if not raw:
            # Reset to default
            await self.db.update_chat_project_dir(agent_name, m.chat_id, None)
            return False, "[OK] Project directory reset to default (clawde repo). Session cleared.", f"set_project_dir_reset chat_id={m.chat_id}"

        p = Path(raw)
        if not p.is_absolute():
            return False, "[!] Project path must be absolute.", "set_project_dir_not_absolute"
        if not p.exists():
            return False, f"[!] Directory does not exist: {raw}", "set_project_dir_not_found"
        if not p.is_dir():
            return False, f"[!] Path is not a directory: {raw}", "set_project_dir_not_dir"

        await self.db.update_chat_project_dir(agent_name, m.chat_id, str(p))
        return False, f"[OK] Project directory set to `{p}`. Session cleared.", f"set_project_dir chat_id={m.chat_id} dir={p}"

    async def _set_backend(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = SetBackendPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid backend payload.", f"set_backend_invalid_payload err={e}"

        requested = (m.backend or "").strip().lower()
        if requested not in ("claude", "codex", "gemini"):
            return False, "[!] Backend must be 'claude', 'codex', or 'gemini'.", "set_backend_invalid_value"

        # Authorization: admin can set any chat, non-admin only their own
        if not ctx.actor_is_admin:
            if ctx.actor_chat_id is None or m.chat_id != ctx.actor_chat_id:
                return False, "[!] You don't have permission to change that.", "set_backend_denied_other_chat"

        agent_name = ctx.agent_name or "default"
        await self.db.update_chat_backend(agent_name, m.chat_id, requested)
        return False, f"[OK] Backend switched to `{requested}`. Session cleared (sessions are not cross-compatible).", f"set_backend chat_id={m.chat_id} backend={requested}"

    async def _write_skill(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = WriteSkillPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid skill write payload.", f"write_skill_invalid_payload err={e}"

        content = (m.content_md or "").strip()
        if not content:
            return False, "[!] Skill content cannot be empty.", "write_skill_empty_content"

        # Resolve target directory based on scope
        if m.scope == "global":
            target_dir = self.paths.skills_dir
        else:
            # Per-agent skills
            if ctx.agent_name:
                agent = resolve_agent(self.paths.agents_dir, ctx.agent_name)
                if agent:
                    target_dir = agent.skills_dir
                else:
                    target_dir = self.paths.skills_dir  # fallback to global
            else:
                target_dir = self.paths.skills_dir

        try:
            skill_path = do_write_skill(target_dir, m.name, content)
        except ValueError as e:
            return False, f"[!] {e}", f"write_skill_invalid_name err={e}"
        except Exception as e:
            return False, "[!] Failed to write skill.", f"write_skill_error err={e}"

        scope_label = "global" if m.scope == "global" else f"agent:{ctx.agent_name or 'global'}"
        return False, f"[OK] Skill '{m.name}' written ({scope_label}).", f"write_skill name={m.name} scope={scope_label} path={skill_path.as_posix()}"

    async def _toggle_skill(self, payload: Dict[str, Any], ctx: ActionExecContext, *, enable: bool) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = ToggleSkillPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid skill toggle payload.", f"toggle_skill_invalid err={e}"

        if not ctx.actor_chat_id:
            return False, "[!] No chat context for skill toggle.", "toggle_skill_no_chat"

        agent_name = ctx.agent_name or ""

        # Load current overrides
        chat_row = await self.db.get_chat(agent_name, ctx.actor_chat_id)
        overrides: dict = {}
        if chat_row and chat_row.disabled_skills:
            try:
                overrides = json.loads(chat_row.disabled_skills)
            except Exception:
                overrides = {}

        disabled_set = set(overrides.get("disabled", []))
        enabled_set = set(overrides.get("enabled", []))

        if enable:
            disabled_set.discard(m.name)
            enabled_set.add(m.name)
            verb = "enabled"
        else:
            disabled_set.add(m.name)
            enabled_set.discard(m.name)
            verb = "disabled"

        overrides["disabled"] = sorted(disabled_set)
        overrides["enabled"] = sorted(enabled_set)
        await self.db.update_chat_skill_overrides(agent_name, ctx.actor_chat_id, json.dumps(overrides))

        return False, f"[OK] Skill '{m.name}' {verb} for this chat.", f"toggle_skill name={m.name} {verb}"

    async def _create_goal(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        import asyncio

        try:
            m = CreateGoalPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid create_goal payload.", f"create_goal_invalid_payload err={e}"

        goal_text = (m.goal or "").strip()
        if not goal_text:
            return False, "[!] Goal objective text cannot be empty.", "create_goal_empty_goal"

        # Resolve agent
        agent_name = ctx.agent_name
        if not agent_name:
            return False, "[!] No agent context for goal creation.", "create_goal_no_agent"

        agent = resolve_agent(self.paths.agents_dir, agent_name)
        if not agent:
            return False, f"[!] Agent '{agent_name}' not found.", f"create_goal_agent_not_found name={agent_name}"

        ensure_agent_scaffold(agent)

        # Locate goalachiever.py
        cli_path = self.paths.skills_dir / "goal-achiever" / "goalachiever.py"
        if not cli_path.exists():
            return False, "[!] Goal achiever CLI not found.", f"create_goal_cli_missing path={cli_path}"

        # Build command
        cmd = [
            sys.executable, str(cli_path),
            "--root", str(self.paths.agents_dir / agent_name),
            "--workspaces-dir", "goals",
            "init",
            "--goal", goal_text,
        ]
        if m.slug:
            cmd.extend(["--slug", m.slug])
        if m.external:
            for ext_path in m.external:
                cmd.extend(["--external", ext_path])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
        except asyncio.TimeoutError:
            return False, "[!] Goal creation timed out.", "create_goal_timeout"
        except Exception as e:
            return False, "[!] Failed to run goal achiever CLI.", f"create_goal_exec_error err={e}"

        if proc.returncode != 0:
            err_msg = stderr.decode("utf-8", errors="replace").strip()[:200]
            return False, f"[!] Goal creation failed: {err_msg}", f"create_goal_failed rc={proc.returncode} err={err_msg}"

        out = stdout.decode("utf-8", errors="replace").strip()
        slug_display = m.slug or "(auto)"
        return False, f"[OK] Goal workspace created for: {goal_text[:80]}\n{out}", f"create_goal agent={agent_name} slug={slug_display}"

    async def _register_mcp_server(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = RegisterMCPServerPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid register_mcp_server payload.", f"register_mcp_invalid err={e}"

        # Validate name
        name_re = re.compile(r"^[A-Za-z0-9_-]+$")
        if not name_re.match(m.name):
            return False, "[!] Server name must be alphanumeric with dashes/underscores.", "register_mcp_bad_name"

        if m.type not in ("stdio", "http", "sse"):
            return False, f"[!] Invalid MCP server type: {m.type}. Must be stdio, http, or sse.", "register_mcp_bad_type"

        if m.type == "stdio" and not m.command:
            return False, "[!] stdio servers require a `command` field.", "register_mcp_no_command"
        if m.type in ("http", "sse"):
            # Managed HTTP: command + port (gateway wraps via supergateway)
            # Remote HTTP: url (external server)
            has_managed = bool(m.command and m.port)
            has_remote = bool(m.url)
            if not has_managed and not has_remote:
                return False, (
                    f"[!] {m.type} servers require either `url` (remote) "
                    f"or `command` + `port` (gateway-managed)."
                ), "register_mcp_no_url_or_managed"
        if m.port is not None:
            if not (1 <= m.port <= 65535):
                return False, "[!] Port must be between 1 and 65535.", "register_mcp_bad_port"

        # Write server file
        servers_dir = self.paths.mcp_servers_dir
        servers_dir.mkdir(parents=True, exist_ok=True)
        server_file = servers_dir / f"{m.name}.json"

        server_data: Dict[str, Any] = {
            "name": m.name,
            "description": m.description,
            "type": m.type,
            "enabled": m.enabled,
        }
        if m.command:
            server_data["command"] = m.command
        if m.args:
            server_data["args"] = m.args
        if m.env:
            server_data["env"] = m.env
        if m.url:
            server_data["url"] = m.url
        if m.headers:
            server_data["headers"] = m.headers
        if m.port is not None:
            server_data["port"] = m.port
        if m.pre_launch is not None:
            pl_data: Dict[str, Any] = {"command": m.pre_launch.command}
            if m.pre_launch.args:
                pl_data["args"] = m.pre_launch.args
            if m.pre_launch.port is not None:
                pl_data["port"] = m.pre_launch.port
            if m.pre_launch.find_executable:
                pl_data["find_executable"] = m.pre_launch.find_executable
            if m.pre_launch.env:
                pl_data["env"] = m.pre_launch.env
            server_data["pre_launch"] = pl_data

        server_file.write_text(
            json.dumps(server_data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

        is_managed = bool(m.command and m.port)
        has_pl = m.pre_launch is not None
        if is_managed or has_pl:
            mode_label = "managed, requires gateway restart"
        else:
            mode_label = m.type
        return False, f"[OK] MCP server `{m.name}` registered ({mode_label}).", f"register_mcp name={m.name} type={m.type} managed={is_managed} pre_launch={has_pl}"

    async def _remove_mcp_server(self, payload: Dict[str, Any], ctx: ActionExecContext) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            m = RemoveMCPServerPayload(**payload)
        except Exception as e:
            return False, "[!] Invalid remove_mcp_server payload.", f"remove_mcp_invalid err={e}"

        server_file = self.paths.mcp_servers_dir / f"{m.name}.json"
        if not server_file.exists():
            return False, f"[!] MCP server `{m.name}` not found.", f"remove_mcp_not_found name={m.name}"

        server_file.unlink()
        return False, f"[OK] MCP server `{m.name}` removed.", f"remove_mcp name={m.name}"
