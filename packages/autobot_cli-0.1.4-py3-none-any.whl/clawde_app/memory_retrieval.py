from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Set, Tuple

from .config import AppConfig, AppPaths


_STOPWORDS: Set[str] = {
    # Core English stopwords (small set; keep deterministic + light)
    "the", "a", "an", "and", "or", "but", "if", "then", "else", "when", "while",
    "to", "of", "in", "on", "for", "from", "with", "without", "at", "by", "as",
    "is", "are", "was", "were", "be", "been", "being",
    "it", "its", "this", "that", "these", "those",
    "i", "me", "my", "mine", "we", "us", "our", "ours",
    "you", "your", "yours", "he", "him", "his", "she", "her", "hers", "they", "them", "their", "theirs",
    "not", "no", "yes",
    "do", "does", "did", "doing",
    "can", "could", "should", "would", "will", "won", "may", "might", "must",
    "have", "has", "had", "having",
    "there", "here",
    "what", "which", "who", "whom", "why", "how",
    "about", "into", "over", "under", "again", "once",
    "just", "really", "very", "pretty", "kind", "sort",
    "also", "too", "either", "neither",
}

_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")


@dataclass(frozen=True)
class MemorySnippet:
    source_path: Path
    score: float
    kind: str  # "topic" | "daily" | "other"
    title: Optional[str]
    excerpt: str

    def to_markdown(self, repo_root: Path) -> str:
        rel = self.source_path
        try:
            rel = self.source_path.relative_to(repo_root)
        except Exception:
            pass
        title = self.title or rel.as_posix()
        return (
            f"### {title}\n"
            f"- source: `{rel.as_posix()}`\n"
            f"- score: {self.score:.2f}\n\n"
            f"```md\n{self.excerpt.strip()}\n```\n"
        )


def ensure_memory_scaffold(
    paths: AppPaths,
    *,
    memory_dir: Optional[Path] = None,
    topics_dir: Optional[Path] = None,
    daily_dir: Optional[Path] = None,
) -> None:
    """
    Create memory directories and baseline files if missing.
    This makes the repo usable immediately on first run.

    Optional overrides allow per-agent memory directories.
    """
    mem = memory_dir or paths.memory_dir
    topics = topics_dir or paths.memory_topics_dir
    daily = daily_dir or paths.memory_daily_dir

    mem.mkdir(parents=True, exist_ok=True)
    topics.mkdir(parents=True, exist_ok=True)
    daily.mkdir(parents=True, exist_ok=True)

    memory_index = mem / "MEMORY.md"
    if not memory_index.exists():
        memory_index.write_text(
            "# MEMORY\n\n"
            "This file is a curated index of long-term facts and pointers.\n"
            "Keep it short. Put detail in `memory/topics/*.md`.\n\n"
            "## Topics\n"
            "- projects: see `memory/topics/projects.md`\n"
            "- preferences: see `memory/topics/preferences.md`\n"
            "- systems: see `memory/topics/systems.md`\n",
            encoding="utf-8",
        )

    for topic in ["projects", "preferences", "systems"]:
        p = topics / f"{topic}.md"
        if not p.exists():
            p.write_text(
                f"# {topic}\n\n"
                f"(Write durable information here about {topic}.)\n",
                encoding="utf-8",
            )


def _safe_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


def _head_text(text: str, max_chars: int, max_lines: int) -> str:
    if not text:
        return ""
    lines = text.splitlines()
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        text = "\n".join(lines)
    if len(text) > max_chars:
        return text[:max_chars].rstrip() + "\n…"
    return text


def _tail_text(text: str, max_chars: int) -> str:
    if not text:
        return ""
    if len(text) <= max_chars:
        return text
    return "…\n" + text[-max_chars:]


def _extract_first_heading(text: str) -> Optional[str]:
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("#"):
            # normalize multiple hashes
            return s.lstrip("#").strip() or None
    return None


def _parse_daily_date(path: Path) -> Optional[date]:
    """
    daily filenames are YYYY-MM-DD.md
    """
    m = re.match(r"^(\d{4}-\d{2}-\d{2})\.md$", path.name)
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%Y-%m-%d").date()
    except Exception:
        return None


def list_recent_daily_files(memory_daily_dir: Path, days_back: int) -> List[Path]:
    """
    Return up to `days_back` daily files, including today if present, descending by date.
    """
    files: List[Tuple[date, Path]] = []
    for p in memory_daily_dir.glob("*.md"):
        d = _parse_daily_date(p)
        if d is None:
            continue
        files.append((d, p))
    files.sort(key=lambda t: t[0], reverse=True)
    return [p for _, p in files[: max(0, days_back)]]


def _extract_keywords(query: str, max_keywords: int = 12) -> List[str]:
    """
    Deterministic keyword extraction:
      - collect tokens via regex
      - keep ALLCAPS tokens from original query (boost retention)
      - lowercase
      - drop stopwords
      - require len >= 4 (except ALLCAPS retained if len>=2)
    """
    q = query or ""
    tokens = _TOKEN_RE.findall(q)
    allcaps = {t for t in tokens if len(t) >= 2 and t.isupper()}
    out: List[str] = []
    seen: Set[str] = set()

    for t in tokens:
        low = t.lower()
        if low in _STOPWORDS:
            continue

        if low in seen:
            continue

        if (len(low) >= 4) or (t in allcaps):
            seen.add(low)
            out.append(low)

        if len(out) >= max_keywords:
            break

    return out


def _score_text_for_keywords(text: str, keywords: Sequence[str]) -> Tuple[int, int]:
    """
    Returns (hits, heading_hits).
    """
    if not text or not keywords:
        return 0, 0
    lower = text.lower()
    hits = 0
    for kw in keywords:
        if not kw:
            continue
        hits += lower.count(kw)

    heading_hits = 0
    for line in text.splitlines():
        if not line.lstrip().startswith("#"):
            continue
        ll = line.lower()
        for kw in keywords:
            if kw and (kw in ll):
                heading_hits += 1
    return hits, heading_hits


def _excerpt_around_match(text: str, keywords: Sequence[str], max_chars: int) -> str:
    """
    Build a snippet around the earliest keyword match.
    """
    if not text:
        return ""
    lower = text.lower()
    match_positions: List[int] = []
    for kw in keywords:
        if not kw:
            continue
        idx = lower.find(kw)
        if idx != -1:
            match_positions.append(idx)
    if not match_positions:
        # fallback: head
        return _head_text(text, max_chars=max_chars, max_lines=120)

    idx0 = min(match_positions)
    half = max_chars // 2
    start = max(0, idx0 - half)
    end = min(len(text), idx0 + (max_chars - (idx0 - start)))

    # Expand to line boundaries where possible
    nl_before = text.rfind("\n", 0, start)
    if nl_before != -1 and (start - nl_before) < 200:
        start = nl_before + 1
    nl_after = text.find("\n", end)
    if nl_after != -1 and (nl_after - end) < 200:
        end = nl_after

    snippet = text[start:end].strip("\n")
    if start > 0:
        snippet = "…\n" + snippet
    if end < len(text):
        snippet = snippet + "\n…"
    return snippet[:max_chars].rstrip()


class KeywordMemoryRetriever:
    """
    Keyword-based retrieval for `memory/topics/*.md` and recent daily logs.

    Phase 1 retriever. Deterministic and zero external dependencies.
    """

    def __init__(self, cfg: AppConfig, paths: AppPaths):
        self.cfg = cfg
        self.paths = paths

    def retrieve(
        self,
        query: str,
        *,
        exclude_paths: Optional[Set[Path]] = None,
        daily_search_days: int = 30,
        topics_dir: Optional[Path] = None,
        daily_dir: Optional[Path] = None,
    ) -> List[MemorySnippet]:
        t_dir = topics_dir or self.paths.memory_topics_dir
        d_dir = daily_dir or self.paths.memory_daily_dir
        ensure_memory_scaffold(
            self.paths,
            topics_dir=t_dir,
            daily_dir=d_dir,
        )

        exclude_paths = exclude_paths or set()
        exclude_resolved = {p.resolve() for p in exclude_paths}

        keywords = _extract_keywords(query)
        if not keywords:
            return []

        # Candidate files:
        topic_files = sorted(t_dir.glob("*.md"))
        daily_files = sorted(d_dir.glob("*.md"))

        # Filter daily to recent N days
        cutoff = date.today() - timedelta(days=daily_search_days)
        daily_recent: List[Path] = []
        for p in daily_files:
            d = _parse_daily_date(p)
            if d is None:
                continue
            if d >= cutoff:
                daily_recent.append(p)

        candidates: List[Tuple[str, Path]] = [("topic", p) for p in topic_files] + [("daily", p) for p in daily_recent]

        snippets: List[MemorySnippet] = []
        max_chars = self.cfg.memory.retrieval.max_chars_per_snippet
        min_hits = self.cfg.memory.retrieval.keyword_min_hits

        for kind, p in candidates:
            try:
                rp = p.resolve()
            except Exception:
                rp = p
            if rp in exclude_resolved:
                continue

            text = _safe_read(p)
            if not text.strip():
                continue

            hits, heading_hits = _score_text_for_keywords(text, keywords)
            if hits < min_hits:
                continue

            # Base score
            score = float(hits) + float(heading_hits) * 1.5

            # Recency boost for daily files
            if kind == "daily":
                d = _parse_daily_date(p)
                if d is not None:
                    days_ago = max(0, (date.today() - d).days)
                    # 0..30 -> 0.5..0
                    recency_boost = max(0.0, (30.0 - float(days_ago)) / 30.0) * 0.5
                    score += recency_boost

            title = _extract_first_heading(text) if kind == "topic" else p.stem
            excerpt = _excerpt_around_match(text, keywords, max_chars=max_chars)

            snippets.append(
                MemorySnippet(
                    source_path=p,
                    score=score,
                    kind=kind,
                    title=title,
                    excerpt=excerpt,
                )
            )

        # Sort by score desc and take top N
        snippets.sort(key=lambda s: s.score, reverse=True)
        return snippets[: self.cfg.memory.retrieval.max_snippets]
