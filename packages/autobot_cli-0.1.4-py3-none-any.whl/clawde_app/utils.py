from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from .config import AppPaths


def ensure_runtime_scaffold(paths: AppPaths) -> None:
    """
    Create directories that the app expects. Safe to call on every start.
    """
    paths.data_dir.mkdir(parents=True, exist_ok=True)
    (paths.runtime_dir / "logs").mkdir(parents=True, exist_ok=True)
    (paths.runtime_dir / "logs" / "runs").mkdir(parents=True, exist_ok=True)
    (paths.runtime_dir / "context").mkdir(parents=True, exist_ok=True)
    paths.memory_dir.mkdir(parents=True, exist_ok=True)
    paths.memory_topics_dir.mkdir(parents=True, exist_ok=True)
    paths.memory_daily_dir.mkdir(parents=True, exist_ok=True)
    paths.claude_rules_dir.mkdir(parents=True, exist_ok=True)
    (paths.runtime_dir / "mcp_pids").mkdir(parents=True, exist_ok=True)


def setup_logging(paths: AppPaths, level: int = logging.INFO) -> None:
    """
    Configure logging to both console and runtime/logs/clawde.log.

    Keep it simple and dependency-free (no structlog).
    """
    ensure_runtime_scaffold(paths)
    log_file = paths.runtime_dir / "logs" / "clawde.log"

    # Avoid double handlers if called twice
    root = logging.getLogger()
    if root.handlers:
        return

    root.setLevel(level)

    fmt = logging.Formatter(
        fmt="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    sh.setLevel(level)
    root.addHandler(sh)

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(level)
    root.addHandler(fh)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def shorten(text: str, max_chars: int = 200) -> str:
    s = (text or "").strip().replace("\n", " ")
    if len(s) <= max_chars:
        return s
    return s[: max_chars - 1] + "…"


def safe_json_dumps(obj: Any, *, max_chars: int = 20000) -> str:
    """
    JSON-dump for logs with a max size guard.
    """
    try:
        s = json.dumps(obj, ensure_ascii=False, indent=2)
    except Exception:
        s = repr(obj)
    if len(s) > max_chars:
        return s[:max_chars] + "\n…(truncated)…"
    return s


def write_text_if_missing(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(content, encoding="utf-8")


def atomic_write_text(path: Path, content: str, encoding: str = "utf-8") -> None:
    """
    Best-effort atomic write: write to temp file then replace.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding=encoding)
    tmp.replace(path)


def env_bool(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "y", "on")
