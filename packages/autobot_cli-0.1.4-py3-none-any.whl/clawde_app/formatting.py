from __future__ import annotations

import html
from dataclasses import dataclass
from typing import List, Tuple


@dataclass(frozen=True)
class SplitResult:
    parts: List[str]
    too_long_for_message: bool  # True if any single atomic segment exceeds max_chars


def _escape(s: str) -> str:
    return html.escape(s or "", quote=False)


def _format_inline_code_plain_to_html(text: str) -> str:
    """
    Convert inline backticks `code` to <code>code</code>, while escaping everything else.
    If backticks are unbalanced, treat the remainder literally.
    """
    if not text:
        return ""

    out: List[str] = []
    buf: List[str] = []
    in_code = False

    for ch in text:
        if ch == "`":
            if in_code:
                # close code
                code = "".join(buf)
                out.append(f"<code>{_escape(code)}</code>")
                buf = []
                in_code = False
            else:
                # flush plain
                plain = "".join(buf)
                out.append(_escape(plain))
                buf = []
                in_code = True
        else:
            buf.append(ch)

    # Flush remainder
    rem = "".join(buf)
    if in_code:
        # Unclosed backtick: include the literal backtick + remainder
        out.append(_escape("`" + rem))
    else:
        out.append(_escape(rem))

    return "".join(out)


def _parse_fenced_code_blocks(text: str) -> List[Tuple[str, str]]:
    """
    Parse triple-backtick fenced blocks.

    Returns list of segments: (kind, content) where kind is 'plain' or 'code'.
    For code blocks, content is the inside of the fence (language line stripped if present).

    This parser is intentionally simple and deterministic.
    """
    s = text or ""
    segments: List[Tuple[str, str]] = []
    i = 0
    while True:
        j = s.find("```", i)
        if j == -1:
            segments.append(("plain", s[i:]))
            break

        # Plain text before fence
        if j > i:
            segments.append(("plain", s[i:j]))

        # Find end fence
        k = s.find("```", j + 3)
        if k == -1:
            # Unclosed fence -> treat as plain
            segments.append(("plain", s[j:]))
            break

        # Determine code content boundaries
        fence_head_end = s.find("\n", j + 3)
        if fence_head_end == -1 or fence_head_end > k:
            # no newline before closing fence
            content_start = j + 3
        else:
            # strip optional language tag line
            content_start = fence_head_end + 1

        content = s[content_start:k]
        segments.append(("code", content))

        i = k + 3

    return segments


def format_telegram_html(text: str) -> str:
    """
    Convert a plain assistant reply into Telegram-safe HTML:
      - Escape HTML special chars
      - Convert triple-backtick fenced blocks into <pre><code>...</code></pre>
      - Convert inline backticks into <code>...</code>

    IMPORTANT: Telegram supports a limited subset of HTML tags.
    We use only <code> and <pre><code>.
    """
    segs = _parse_fenced_code_blocks(text or "")
    out: List[str] = []

    for kind, content in segs:
        if kind == "code":
            out.append(f"<pre><code>{_escape(content)}</code></pre>")
        else:
            out.append(_format_inline_code_plain_to_html(content))

    return "".join(out).strip()


def format_and_split_for_telegram(text: str, max_chars: int) -> SplitResult:
    """
    Format to Telegram HTML and split into multiple messages if needed.

    Splitting rules:
    - We avoid splitting inside a <pre><code>...</code></pre> block by treating each
      parsed segment (plain or code block) as atomic.
    - We try to split on natural boundaries (newlines) within plain segments.

    If a single atomic segment exceeds max_chars, we mark too_long_for_message=True.
    Caller should send as file in that case.
    """
    segs = _parse_fenced_code_blocks(text or "")

    # First convert each segment into HTML "atoms"
    atoms: List[str] = []
    too_long = False
    for kind, content in segs:
        if kind == "code":
            atom = f"<pre><code>{_escape(content)}</code></pre>"
            atoms.append(atom)
            if len(atom) > max_chars:
                too_long = True
        else:
            # plain can still be long; we can split it further on newlines
            plain = content or ""
            if not plain:
                continue
            # Split plain on newline boundaries into smaller atoms
            # (keeps formatting stable)
            chunks = plain.splitlines(keepends=True)
            for c in chunks:
                atom = _format_inline_code_plain_to_html(c)
                atoms.append(atom)
                if len(atom) > max_chars:
                    too_long = True

    if not atoms:
        return SplitResult(parts=[""], too_long_for_message=False)

    # Now pack atoms into message parts
    parts: List[str] = []
    cur: List[str] = []
    cur_len = 0

    for atom in atoms:
        if not atom:
            continue
        if cur and (cur_len + len(atom) > max_chars):
            parts.append("".join(cur).strip())
            cur = [atom]
            cur_len = len(atom)
        else:
            cur.append(atom)
            cur_len += len(atom)

    if cur:
        parts.append("".join(cur).strip())

    # Remove empty parts
    parts = [p for p in parts if p]

    return SplitResult(parts=parts, too_long_for_message=too_long)


def needs_send_as_file(split_result: SplitResult, max_parts: int = 8) -> bool:
    """
    Heuristic: if message requires too many parts, suggest sending as a file
    (better UX).
    """
    if split_result.too_long_for_message:
        return True
    if len(split_result.parts) > max_parts:
        return True
    return False
