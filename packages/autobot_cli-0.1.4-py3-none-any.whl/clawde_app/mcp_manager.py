"""
MCP server process lifecycle manager.

For MCP servers that need persistence (type=http with command+port),
wraps them via ``supergateway`` as long-lived HTTP daemons.
The gateway starts them at boot and stops them at shutdown.
"""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import AppPaths
from .mcp_sync import (
    MCPServerDef,
    PreLaunchDef,
    has_pre_launch,
    is_managed_mcp_server,
    list_enabled_mcp_servers,
    managed_mcp_url,
)

log = logging.getLogger("clawde.mcp_manager")

_MCP_PIDS_DIR = "mcp_pids"


def _pids_dir(paths: AppPaths) -> Path:
    return paths.runtime_dir / _MCP_PIDS_DIR


def _pid_file(paths: AppPaths, name: str) -> Path:
    return _pids_dir(paths) / f"{name}.pid"


def _write_pid(path: Path, pid: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(pid), encoding="utf-8")


def _read_pid(path: Path) -> Optional[int]:
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return None


def _remove_pid(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except Exception:
        pass


def _is_pid_alive(pid: int) -> bool:
    if sys.platform == "win32":
        try:
            r = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                capture_output=True, text=True, timeout=5,
            )
            return str(pid) in r.stdout
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False


def _kill_pid(pid: int, timeout: int = 5) -> None:
    """Kill a process by PID. Graceful then forceful.
    On Windows, uses /T to kill the entire process tree (important for
    supergateway which spawns child processes like npx/node).
    """
    if sys.platform == "win32":
        try:
            subprocess.run(["taskkill", "/T", "/PID", str(pid)], capture_output=True, timeout=5)
        except Exception:
            pass
        for _ in range(timeout):
            if not _is_pid_alive(pid):
                return
            time.sleep(1)
        try:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, timeout=5)
        except Exception:
            pass
    else:
        try:
            try:
                os.killpg(os.getpgid(pid), signal.SIGTERM)
            except Exception:
                os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        for _ in range(timeout):
            if not _is_pid_alive(pid):
                return
            time.sleep(1)
        try:
            try:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
            except Exception:
                os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def _is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        return sock.connect_ex((host, port)) == 0


def _disabled_prelaunch_names() -> set[str]:
    raw = os.getenv("CLAWDE_SKIP_PRELAUNCH_SERVERS", "").strip()
    if not raw:
        return set()
    return {name.strip().lower() for name in raw.split(",") if name.strip()}


def _is_pre_launch_disabled(server_name: str, pre_launch: PreLaunchDef) -> bool:
    raw = os.getenv("CLAWDE_DISABLE_DOCKER_PRELAUNCH", "").strip().lower()
    pre_launch_command = (pre_launch.command or "").strip().lower()
    if raw in {"1", "true", "yes", "on"} and os.path.basename(pre_launch_command) == "docker":
        return True

    skipped = _disabled_prelaunch_names()
    if not skipped:
        return False
    return server_name.lower() in skipped


def _find_chrome() -> Optional[str]:
    """Cross-platform Chrome executable discovery."""
    if sys.platform == "win32":
        candidates = []
        for env_var in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData"):
            base = os.environ.get(env_var)
            if base:
                candidates.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
        for c in candidates:
            if os.path.isfile(c):
                return c
    elif sys.platform == "darwin":
        mac_path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.isfile(mac_path):
            return mac_path
    else:
        for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
            found = shutil.which(name)
            if found:
                return found
    return shutil.which("chrome")


def _find_executable(hint: str) -> Optional[str]:
    """Resolve an executable from a hint name. Dispatches to specific finders."""
    if hint == "chrome":
        return _find_chrome()
    return shutil.which(hint)


def _resolve_pre_launch_command(pre_launch: PreLaunchDef, paths: AppPaths) -> List[str]:
    """Build the command list for a pre-launch process, resolving executable and <runtime> placeholders."""
    exe = pre_launch.command
    if pre_launch.find_executable:
        resolved = _find_executable(pre_launch.find_executable)
        if resolved:
            exe = resolved
        else:
            log.warning("Could not find executable for hint '%s', using raw command '%s'",
                        pre_launch.find_executable, pre_launch.command)

    cmd = [exe]
    if pre_launch.args:
        runtime_str = str(paths.runtime_dir)
        for arg in pre_launch.args:
            cmd.append(arg.replace("<runtime>", runtime_str))

    # Docker/headless environment adjustments for Chrome
    if pre_launch.find_executable == "chrome":
        # Chromium refuses to run as root without --no-sandbox
        if getattr(os, "getuid", lambda: -1)() == 0 and "--no-sandbox" not in cmd:
            cmd.append("--no-sandbox")
        # No display server available (Linux without X/Wayland) — run headless.
        # Windows/macOS always have a display, so skip this check there.
        if os.name != "nt" and not os.environ.get("DISPLAY") and not any(a.startswith("--headless") for a in cmd):
            cmd.append("--headless=new")

    return cmd


def _pre_launch_pid_file(paths: AppPaths, name: str) -> Path:
    return _pids_dir(paths) / f"{name}__prelaunch.pid"


async def _wait_for_port(port: int, timeout: float = 15.0, interval: float = 0.5) -> bool:
    """Wait until a TCP port is accepting connections."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _is_port_in_use(port):
            return True
        await asyncio.sleep(interval)
    return False


def _build_supergateway_command(server: MCPServerDef) -> List[str]:
    """Build the npx supergateway command for a managed server."""
    inner_parts: List[str] = []
    if server.command:
        inner_parts.append(server.command)
    if server.args:
        inner_parts.extend(server.args)
    inner_cmd = " ".join(inner_parts)

    # Resolve npx path (Windows .cmd shim needs full path)
    npx = shutil.which("npx") or "npx"

    return [
        npx, "-y", "supergateway",
        "--stdio", inner_cmd,
        "--outputTransport", "streamableHttp",
        "--port", str(server.port),
    ]


async def _check_health(url: str, timeout: float = 30.0, interval: float = 1.0) -> bool:
    """Wait until the MCP HTTP endpoint responds (or timeout)."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            req = urllib.request.Request(url, method="GET")
            urllib.request.urlopen(req, timeout=3)
            return True
        except urllib.error.HTTPError:
            # HTTP error (e.g. 405) means the server is listening
            return True
        except (urllib.error.URLError, ConnectionError, OSError):
            pass
        await asyncio.sleep(interval)
    return False


async def start_pre_launch_processes(paths: AppPaths) -> Dict[str, bool]:
    """Start all pre-launch background dependencies for enabled MCP servers."""
    servers = list_enabled_mcp_servers(paths.mcp_servers_dir)
    with_pre = [s for s in servers if has_pre_launch(s)]

    if not with_pre:
        return {}

    pdir = _pids_dir(paths)
    pdir.mkdir(parents=True, exist_ok=True)

    results: Dict[str, bool] = {}

    for server in with_pre:
        pl = server.pre_launch
        assert pl is not None
        name = server.name
        pid_path = _pre_launch_pid_file(paths, name)

        if _is_pre_launch_disabled(name, pl):
            log.info("Pre-launch for '%s' disabled by environment, skipping launch.", name)
            results[name] = True
            continue

        # Check if already running
        existing_pid = _read_pid(pid_path)
        if existing_pid is not None and _is_pid_alive(existing_pid):
            log.info("Pre-launch for '%s' already running (PID %d), skipping", name, existing_pid)
            results[name] = True
            continue

        # Clean up stale PID
        _remove_pid(pid_path)

        # If port is specified and already in use, skip (user's own process may be running)
        if pl.port and _is_port_in_use(pl.port):
            log.info("Pre-launch for '%s': port %d already in use (external process?), skipping launch",
                      name, pl.port)
            results[name] = True  # Consider it OK — the dependency is available
            continue

        # Resolve executable
        if pl.find_executable:
            exe = _find_executable(pl.find_executable)
            if not exe:
                log.warning("Pre-launch for '%s': could not find '%s' executable. "
                            "Is it installed?", name, pl.find_executable)
                results[name] = False
                continue

        cmd = _resolve_pre_launch_command(pl, paths)
        log.info("Starting pre-launch for '%s': %s", name, " ".join(cmd))

        # Clean up stale Docker containers (e.g. from a crash) to allow restart
        if pl.command == "docker" and pl.args and "--name" in pl.args:
            try:
                name_idx = pl.args.index("--name")
                container_name = pl.args[name_idx + 1] if name_idx + 1 < len(pl.args) else None
                if container_name:
                    subprocess.run(
                        ["docker", "rm", "-f", container_name],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        timeout=10,
                    )
            except Exception:
                pass  # Best-effort cleanup

        # Clean up stale Chrome profile locks (survives container restarts on volumes)
        if pl.find_executable == "chrome" and pl.args:
            for arg in pl.args:
                if arg.startswith("--user-data-dir="):
                    profile_dir = Path(arg.split("=", 1)[1].replace("<runtime>", str(paths.runtime_dir)))
                    for lock_name in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
                        lock_file = profile_dir / lock_name
                        try:
                            lock_file.unlink(missing_ok=True)
                        except OSError:
                            pass

        try:
            env = os.environ.copy()
            if pl.env:
                env.update(pl.env)

            kwargs: dict = {
                "stdout": subprocess.DEVNULL,
                "stderr": subprocess.DEVNULL,
                "stdin": subprocess.DEVNULL,
                "env": env,
            }

            if sys.platform == "win32":
                CREATE_NEW_PROCESS_GROUP = 0x00000200
                DETACHED_PROCESS = 0x00000008
                kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            else:
                kwargs["start_new_session"] = True

            proc = subprocess.Popen(cmd, **kwargs)
            _write_pid(pid_path, proc.pid)

            if pl.port:
                ready = await _wait_for_port(pl.port, timeout=15.0)
                if ready:
                    log.info("Pre-launch for '%s' ready (PID %d, port %d)", name, proc.pid, pl.port)
                    results[name] = True
                else:
                    log.warning("Pre-launch for '%s' started (PID %d) but port %d not responding yet",
                                name, proc.pid, pl.port)
                    results[name] = False
            else:
                log.info("Pre-launch for '%s' started (PID %d)", name, proc.pid)
                results[name] = True

        except Exception as e:
            log.warning("Failed to start pre-launch for '%s': %s", name, e)
            _remove_pid(pid_path)
            results[name] = False

    return results


def stop_pre_launch_processes(paths: AppPaths) -> Dict[str, bool]:
    """Stop all pre-launch background processes by reading PID files."""
    pdir = _pids_dir(paths)
    if not pdir.is_dir():
        return {}

    results: Dict[str, bool] = {}

    for pid_file_path in pdir.glob("*__prelaunch.pid"):
        name = pid_file_path.stem.replace("__prelaunch", "")
        pid = _read_pid(pid_file_path)
        if pid is None:
            _remove_pid(pid_file_path)
            continue

        if _is_pid_alive(pid):
            log.info("Stopping pre-launch for '%s' (PID %d)", name, pid)
            _kill_pid(pid, timeout=5)
            results[name] = True
        else:
            log.debug("Pre-launch for '%s' PID %d already dead, cleaning up", name, pid)
            results[name] = True

        _remove_pid(pid_file_path)

    return results


async def start_mcp_servers(paths: AppPaths) -> Dict[str, bool]:
    """
    Start all enabled managed MCP servers via supergateway,
    and all pre-launch background dependencies.

    Returns dict of {server_name: started_ok}.
    Failures are logged as warnings; the gateway continues without them.
    """
    # Start pre-launch dependencies first (e.g. Chrome for chrome-devtools)
    pre_results = await start_pre_launch_processes(paths)

    servers = list_enabled_mcp_servers(paths.mcp_servers_dir)
    managed = [s for s in servers if is_managed_mcp_server(s)]

    if not managed and not pre_results:
        return {}

    if not managed:
        return pre_results

    pdir = _pids_dir(paths)
    pdir.mkdir(parents=True, exist_ok=True)

    results: Dict[str, bool] = {}

    for server in managed:
        name = server.name
        pid_path = _pid_file(paths, name)

        # Check if already running
        existing_pid = _read_pid(pid_path)
        if existing_pid is not None and _is_pid_alive(existing_pid):
            log.info("MCP server '%s' already running (PID %d), skipping", name, existing_pid)
            results[name] = True
            continue

        # Clean up stale PID
        _remove_pid(pid_path)

        # Check port
        if _is_port_in_use(server.port):
            log.warning("MCP server '%s': port %d already in use, skipping", name, server.port)
            results[name] = False
            continue

        cmd = _build_supergateway_command(server)
        log.info("Starting managed MCP server '%s': %s", name, " ".join(cmd))

        try:
            env = os.environ.copy()
            if server.env:
                env.update(server.env)

            kwargs: dict = {
                "stdout": subprocess.DEVNULL,
                "stderr": subprocess.DEVNULL,
                "stdin": subprocess.DEVNULL,
                "env": env,
            }

            if sys.platform == "win32":
                CREATE_NEW_PROCESS_GROUP = 0x00000200
                DETACHED_PROCESS = 0x00000008
                kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            else:
                kwargs["start_new_session"] = True

            proc = subprocess.Popen(cmd, **kwargs)
            _write_pid(pid_path, proc.pid)

            url = managed_mcp_url(server)
            healthy = await _check_health(url, timeout=30.0)

            if healthy:
                log.info("MCP server '%s' ready (PID %d, port %d)", name, proc.pid, server.port)
                results[name] = True
            else:
                log.warning(
                    "MCP server '%s' started (PID %d) but health check timed out. "
                    "It may still be starting up.",
                    name, proc.pid,
                )
                results[name] = False

        except Exception as e:
            log.warning("Failed to start MCP server '%s': %s", name, e)
            _remove_pid(pid_path)
            results[name] = False

    # Merge pre-launch results
    results.update(pre_results)
    return results


def stop_mcp_servers(paths: AppPaths) -> Dict[str, bool]:
    """
    Stop all managed MCP servers and pre-launch processes.

    Returns dict of {server_name: stopped_ok}.
    """
    pdir = _pids_dir(paths)
    if not pdir.is_dir():
        return {}

    results: Dict[str, bool] = {}

    # Stop managed MCP servers first (they depend on pre-launch processes)
    for pid_file_path in pdir.glob("*.pid"):
        # Skip pre-launch PID files (handled separately below)
        if "__prelaunch" in pid_file_path.stem:
            continue
        name = pid_file_path.stem
        pid = _read_pid(pid_file_path)
        if pid is None:
            _remove_pid(pid_file_path)
            continue

        if _is_pid_alive(pid):
            log.info("Stopping MCP server '%s' (PID %d)", name, pid)
            _kill_pid(pid, timeout=5)
            results[name] = True
        else:
            log.debug("MCP server '%s' PID %d already dead, cleaning up", name, pid)
            results[name] = True

        _remove_pid(pid_file_path)

    # Stop pre-launch processes last (dependencies stopped after dependents)
    pre_results = stop_pre_launch_processes(paths)
    results.update(pre_results)

    return results


def mcp_server_status(paths: AppPaths) -> List[Dict[str, Any]]:
    """Return status info for all managed MCP servers and pre-launch processes."""
    servers = list_enabled_mcp_servers(paths.mcp_servers_dir)

    statuses: List[Dict[str, Any]] = []

    for server in servers:
        # Managed HTTP servers (supergateway)
        if is_managed_mcp_server(server):
            pid_path = _pid_file(paths, server.name)
            pid = _read_pid(pid_path)
            alive = pid is not None and _is_pid_alive(pid)
            statuses.append({
                "name": server.name,
                "port": server.port,
                "pid": pid,
                "running": alive,
                "url": managed_mcp_url(server),
            })

        # Pre-launch processes
        if has_pre_launch(server):
            pl = server.pre_launch
            assert pl is not None
            pid_path = _pre_launch_pid_file(paths, server.name)
            pid = _read_pid(pid_path)
            alive = pid is not None and _is_pid_alive(pid)
            # If prelaunch was skipped (e.g. external compose service), check port directly.
            # Try localhost first, then the server name as hostname (Docker Compose networking).
            if not alive and pl.port and _is_pre_launch_disabled(server.name, pl):
                alive = _is_port_in_use(pl.port) or _is_port_in_use(pl.port, server.name)
            statuses.append({
                "name": server.name,
                "port": pl.port,
                "pid": pid,
                "running": alive,
                "pre_launch": True,
            })

    return statuses
