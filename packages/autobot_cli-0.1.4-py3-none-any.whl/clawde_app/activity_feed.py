"""Module-level activity feed broadcaster (singleton)."""
from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, Optional, Set

_MAX_BUFFER = 200


class ActivityBroadcaster:
    """In-memory pub/sub for real-time activity events.

    Connected WebSocket handlers register a queue via subscribe()/unsubscribe().
    Producers call emit() which fans out to all subscribers and appends to ring buffer.
    """

    def __init__(self, max_buffer: int = _MAX_BUFFER):
        self._subscribers: Set[asyncio.Queue] = set()
        self._buffer: list[dict] = []
        self._max_buffer = max_buffer

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=500)
        self._subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subscribers.discard(q)

    def get_buffer(self) -> list[dict]:
        return list(self._buffer)

    def emit(self, agent: str, category: str, summary: str) -> None:
        """Broadcast an event to all subscribers (non-blocking).

        Safe to call from sync on_event callbacks (uses put_nowait).
        """
        event = {
            "ts": time.time(),
            "agent": agent,
            "category": category,
            "summary": summary,
        }
        self._buffer.append(event)
        if len(self._buffer) > self._max_buffer:
            self._buffer = self._buffer[-self._max_buffer:]

        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                try:
                    q.get_nowait()
                    q.put_nowait(event)
                except Exception:
                    pass
            except Exception:
                pass


# Module-level singleton
activity_feed = ActivityBroadcaster()
