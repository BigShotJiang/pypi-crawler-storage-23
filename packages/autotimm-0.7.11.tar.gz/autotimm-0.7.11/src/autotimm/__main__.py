"""Allow running AutoTimm as ``python -m autotimm``."""

from autotimm.cli import main

main()
