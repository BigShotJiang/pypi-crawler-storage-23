"""LLM Orchestrator: decomposes tasks, assigns specialists, plans execution.

The orchestrator can assign predefined specialist templates (engineering,
research, enterprise_research) or compose dynamic packs by selecting tools
and describing roles.  When the LLM selects specialist_id="dynamic", it must
also provide a ``tools`` list and ``role`` description.

Falls back to the first available template on any error — zero regression.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from agentic_concierge.config import ConciergeConfig

if TYPE_CHECKING:
    from agentic_concierge.application.ports import ChatClient

logger = logging.getLogger(__name__)


@dataclass
class SpecialistBrief:
    """A targeted sub-task description for a specific specialist."""

    specialist_id: str
    brief: str  # targeted instructions / sub-task for this specialist
    tools: Optional[List[str]] = None  # tool names for dynamic packs
    role: Optional[str] = None  # role description for dynamic packs


@dataclass
class OrchestrationPlan:
    """The orchestrator's task decomposition and assignment plan.

    ``specialist_assignments`` is an ordered list of (specialist_id, brief) pairs.
    ``mode`` is ``"sequential"`` or ``"parallel"``.
    ``synthesis_required`` is True when a synthesis step is needed after execution.
    ``routing_method`` is ``"orchestrator"`` on success or the fallback's method.
    ``required_capabilities`` is derived from the assigned specialists' capabilities
    for RunResult / runlog compatibility with the existing RecruitmentResult shape.
    """

    specialist_assignments: List[SpecialistBrief]
    mode: str  # "sequential" | "parallel"
    synthesis_required: bool
    reasoning: str
    routing_method: str  # "orchestrator" | "template_fallback"
    required_capabilities: List[str] = field(default_factory=list)
    recommended_model_key: str = "quality"  # "fast" or "quality"


def _build_orchestrator_tool_def() -> Dict[str, Any]:
    """Build the create_plan tool definition."""
    return {
        "type": "function",
        "function": {
            "name": "create_plan",
            "description": (
                "Create a task execution plan by assigning sub-tasks to specialists. "
                "Call this tool exactly once with the complete plan."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "assignments": {
                        "type": "array",
                        "description": "Ordered list of specialist assignments.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "specialist_id": {
                                    "type": "string",
                                    "description": (
                                        "Specialist ID: one of the available templates "
                                        "(e.g. 'engineering', 'research', 'enterprise_research') "
                                        "or 'dynamic' for a custom tool composition."
                                    ),
                                },
                                "brief": {
                                    "type": "string",
                                    "description": "Specific sub-task instructions for this specialist.",
                                },
                                "tools": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": (
                                        "Tool names to include when specialist_id='dynamic'. "
                                        "Ignored for template specialists."
                                    ),
                                },
                                "role": {
                                    "type": "string",
                                    "description": (
                                        "Role description when specialist_id='dynamic'. "
                                        "Ignored for template specialists."
                                    ),
                                },
                            },
                            "required": ["specialist_id", "brief"],
                        },
                    },
                    "mode": {
                        "type": "string",
                        "enum": ["sequential", "parallel"],
                        "description": (
                            "'sequential' when specialists depend on each other's outputs; "
                            "'parallel' when tasks are independent."
                        ),
                    },
                    "synthesis_required": {
                        "type": "boolean",
                        "description": "True when a final synthesis step is needed to combine outputs.",
                    },
                    "reasoning": {
                        "type": "string",
                        "description": "One sentence explaining the orchestration decision.",
                    },
                    "model_tier": {
                        "type": "string",
                        "enum": ["fast", "quality"],
                        "description": (
                            "Model tier for task execution. Use 'fast' for simple tasks "
                            "(lookups, searches, single-step queries, summarisation). "
                            "Use 'quality' for complex tasks (multi-step engineering, "
                            "code generation, analysis requiring deep reasoning)."
                        ),
                    },
                },
                "required": ["assignments", "mode", "synthesis_required", "reasoning"],
            },
        },
    }


def _build_orchestrator_messages(prompt: str, config: ConciergeConfig) -> List[Dict[str, Any]]:
    """Build the system + user messages for the orchestrator LLM call."""
    from agentic_concierge.infrastructure.specialists.tool_catalog import tool_catalog_summary
    from agentic_concierge.infrastructure.specialists.dynamic_pack import PACK_TEMPLATES

    specialist_lines = "\n".join(
        f"- {name}: {spec.description}"
        for name, spec in config.specialists.items()
    )

    template_lines = "\n".join(
        f"- {tid}: tools=[{', '.join(tpl.tool_names)}]"
        for tid, tpl in PACK_TEMPLATES.items()
    )

    tools_summary = tool_catalog_summary()

    system = (
        "You are a task orchestrator. Decompose the given task into clear sub-task assignments "
        "for specialist agents.\n\n"
        f"Available specialist templates:\n{template_lines}\n\n"
        f"Available specialists in config:\n{specialist_lines}\n\n"
        f"Available tools (for dynamic packs):\n{tools_summary}\n\n"
        "Guidelines:\n"
        "- For tasks that fit a template, use the template specialist_id.\n"
        "- For tasks that need a mix of tools not covered by any template, use "
        "specialist_id='dynamic' with a tools list and role description.\n"
        "- Assign each specialist a specific, actionable brief.\n"
        "- Use 'sequential' mode when later specialists need earlier specialists' outputs.\n"
        "- Use 'parallel' mode when tasks are independent and can run concurrently.\n"
        "- Set synthesis_required=true when multiple specialists produce outputs that need combining.\n"
        "- For single-specialist tasks, assign only that specialist.\n"
        "- Set model_tier='fast' for simple tasks (lookups, web searches, quick questions, "
        "summarisation). Set model_tier='quality' only for complex multi-step tasks, "
        "code generation, or deep analysis. Default to 'fast' when in doubt.\n"
        "Call create_plan with the complete assignment plan."
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": f"Task: {prompt}"},
    ]


def _derive_required_capabilities(
    specialist_ids: List[str], config: ConciergeConfig
) -> List[str]:
    """Derive required capabilities from the assigned specialists' declared capabilities."""
    caps: List[str] = []
    for sid in specialist_ids:
        spec_cfg = config.specialists.get(sid)
        if spec_cfg:
            for cap in spec_cfg.capabilities:
                if cap not in caps:
                    caps.append(cap)
    return caps


async def orchestrate_task(
    prompt: str,
    config: ConciergeConfig,
    *,
    chat_client: "ChatClient",
    model: str,
) -> OrchestrationPlan:
    """Decompose a task, assign specialists, and plan execution mode.

    Makes one LLM call with the ``create_plan`` tool.  Falls back to the
    first available template on any error or when the LLM returns no
    usable tool call — zero regression.

    Args:
        prompt: The task prompt to decompose.
        config: Concierge config (specialists, models).
        chat_client: LLM interface.
        model: Model name to use for the orchestrator call.

    Returns:
        ``OrchestrationPlan`` with routing_method ``"orchestrator"`` on success,
        or a plan built from the template fallback result.
    """
    from agentic_concierge.infrastructure.telemetry import get_tracer

    tracer = get_tracer()

    try:
        messages = _build_orchestrator_messages(prompt, config)
        tool_def = _build_orchestrator_tool_def()
        with tracer.start_as_current_span("concierge.orchestrator_call") as span:
            span.set_attribute("model", model)
            response = await chat_client.chat(
                messages,
                model,
                tools=[tool_def],
                temperature=0.0,
                max_tokens=512,
            )
            span.set_attribute("tool_call_returned", bool(response.tool_calls))
    except Exception as exc:
        logger.warning("Orchestrator LLM call failed (%s); falling back to template", exc)
        return _template_fallback_plan(prompt, config)

    # Parse the create_plan tool call
    if not response.tool_calls:
        logger.info("Orchestrator returned no tool call; falling back to template")
        return _template_fallback_plan(prompt, config)

    tc = response.tool_calls[0]
    if tc.tool_name != "create_plan":
        logger.info("Orchestrator called unexpected tool %r; falling back", tc.tool_name)
        return _template_fallback_plan(prompt, config)

    raw_assignments = tc.arguments.get("assignments", [])
    mode = tc.arguments.get("mode", "sequential")
    synthesis_required = tc.arguments.get("synthesis_required", False)
    reasoning = tc.arguments.get("reasoning", "")
    model_tier = tc.arguments.get("model_tier", "quality")
    if model_tier not in ("fast", "quality"):
        model_tier = "quality"

    # Validate assignments: known template IDs or "dynamic" with tools
    known_ids = set(config.specialists.keys())
    from agentic_concierge.infrastructure.specialists.dynamic_pack import PACK_TEMPLATES
    known_templates = set(PACK_TEMPLATES.keys())

    assignments: List[SpecialistBrief] = []
    for a in raw_assignments:
        sid = a.get("specialist_id", "")
        brief = a.get("brief", "")
        tools = a.get("tools")
        role = a.get("role")

        if sid == "dynamic" and tools:
            assignments.append(SpecialistBrief(
                specialist_id="dynamic",
                brief=brief,
                tools=tools,
                role=role,
            ))
        elif sid in known_ids or sid in known_templates:
            assignments.append(SpecialistBrief(specialist_id=sid, brief=brief))
        else:
            logger.warning("Orchestrator assigned unknown specialist %r; skipping", sid)

    if not assignments:
        logger.info("Orchestrator produced no valid assignments; falling back")
        return _template_fallback_plan(prompt, config)

    specialist_ids = [a.specialist_id for a in assignments]
    required_capabilities = _derive_required_capabilities(specialist_ids, config)

    # Force synthesis when multiple specialists assigned
    if len(assignments) > 1:
        synthesis_required = True

    logger.info(
        "Orchestrator plan: specialists=%s mode=%s model_tier=%s synthesis=%s reasoning=%r",
        specialist_ids, mode, model_tier, synthesis_required, reasoning,
    )
    return OrchestrationPlan(
        specialist_assignments=assignments,
        mode=mode,
        synthesis_required=synthesis_required,
        reasoning=reasoning,
        routing_method="orchestrator",
        required_capabilities=required_capabilities,
        recommended_model_key=model_tier,
    )


def _template_fallback_plan(
    prompt: str,
    config: ConciergeConfig,
) -> OrchestrationPlan:
    """Fall back to the first available template specialist."""
    from agentic_concierge.infrastructure.specialists.dynamic_pack import PACK_TEMPLATES

    # Use first template that exists in config.
    # Default to "fast" model — adaptive escalation will upgrade if needed.
    for tid in PACK_TEMPLATES:
        if tid in config.specialists:
            logger.info("Template fallback: using %r", tid)
            return OrchestrationPlan(
                specialist_assignments=[SpecialistBrief(specialist_id=tid, brief="")],
                mode="sequential",
                synthesis_required=False,
                reasoning="template_fallback",
                routing_method="template_fallback",
                required_capabilities=[],
                recommended_model_key="fast",
            )

    # Last resort: first specialist in config
    first_id = next(iter(config.specialists))
    logger.info("Template fallback (last resort): using %r", first_id)
    return OrchestrationPlan(
        specialist_assignments=[SpecialistBrief(specialist_id=first_id, brief="")],
        mode="sequential",
        synthesis_required=False,
        reasoning="template_fallback",
        routing_method="template_fallback",
        required_capabilities=[],
        recommended_model_key="fast",
    )
