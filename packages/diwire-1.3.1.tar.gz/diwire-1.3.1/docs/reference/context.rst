resolver_context
=================

.. autodata:: diwire.resolver_context
