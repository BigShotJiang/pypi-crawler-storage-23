Exceptions
==========

.. automodule:: diwire.exceptions
   :members:
   :member-order: bysource
