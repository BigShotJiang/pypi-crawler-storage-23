"""Local Sphinx extensions vendored for diwire docs."""
