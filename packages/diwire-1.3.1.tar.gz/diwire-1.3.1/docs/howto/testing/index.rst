.. meta::
   :description: Testing with diwire: override registrations, create per-test containers, and use the optional pytest plugin for Injected[T] parameter injection.

Testing
=======

diwire is easy to test because registrations are explicit and replaceable.

.. toctree::
   :maxdepth: 1

   overrides
   pytest
