from __future__ import annotations

from prediction_sdk.utils.config import Config


class TestConfigFromEnv:
    """Tests for Config.from_env() reading environment variables."""

    def test_defaults_when_no_env_vars_set(self, monkeypatch):
        """from_env() should return hardcoded defaults when no env vars are set."""
        for var in [
            "POLYMARKET_GAMMA_URL",
            "POLYMARKET_CLOB_URL",
            "KALSHI_API_URL",
            "KALSHI_API_KEY",
        ]:
            monkeypatch.delenv(var, raising=False)

        cfg = Config.from_env()

        assert cfg.polymarket_gamma_url == "https://gamma-api.polymarket.com"
        assert cfg.polymarket_clob_url == "https://clob.polymarket.com"
        assert cfg.kalshi_api_url == "https://api.elections.kalshi.com/trade-api/v2"
        assert cfg.kalshi_api_key == ""

    def test_env_vars_override_defaults(self, monkeypatch):
        """from_env() should pick up every URL override from the environment."""
        monkeypatch.setenv("POLYMARKET_GAMMA_URL", "http://gamma.local")
        monkeypatch.setenv("POLYMARKET_CLOB_URL", "http://clob.local")
        monkeypatch.setenv("KALSHI_API_URL", "http://kalshi.local")

        cfg = Config.from_env()

        assert cfg.polymarket_gamma_url == "http://gamma.local"
        assert cfg.polymarket_clob_url == "http://clob.local"
        assert cfg.kalshi_api_url == "http://kalshi.local"

    def test_kalshi_api_key_read_from_env(self, monkeypatch):
        """from_env() should read KALSHI_API_KEY from the environment."""
        monkeypatch.setenv("KALSHI_API_KEY", "test-secret-key")
        cfg = Config.from_env()
        assert cfg.kalshi_api_key == "test-secret-key"

    def test_partial_env_override(self, monkeypatch):
        """Setting only some env vars should leave others at their defaults."""
        for var in [
            "POLYMARKET_GAMMA_URL",
            "POLYMARKET_CLOB_URL",
            "KALSHI_API_URL",
            "KALSHI_API_KEY",
        ]:
            monkeypatch.delenv(var, raising=False)

        monkeypatch.setenv("KALSHI_API_URL", "http://kalshi.custom")

        cfg = Config.from_env()

        assert cfg.kalshi_api_url == "http://kalshi.custom"
        # others stay at defaults
        assert cfg.polymarket_gamma_url == "https://gamma-api.polymarket.com"
        assert cfg.polymarket_clob_url == "https://clob.polymarket.com"
