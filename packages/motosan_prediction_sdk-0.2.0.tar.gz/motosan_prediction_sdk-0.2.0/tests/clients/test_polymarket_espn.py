from datetime import date

import httpx
import pytest
import respx

from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.clients.polymarket.espn import (
    fetch_espn_schedule,
    fetch_polymarket_game_event,
)
from prediction_sdk.models.common import Platform, Sport

SAMPLE_ESPN_RESPONSE = {
    "events": [
        {
            "date": "2026-02-26T00:00Z",
            "competitions": [
                {
                    "competitors": [
                        {
                            "homeAway": "away",
                            "team": {
                                "abbreviation": "MIA",
                                "shortDisplayName": "Heat",
                            },
                        },
                        {
                            "homeAway": "home",
                            "team": {
                                "abbreviation": "PHI",
                                "shortDisplayName": "76ers",
                            },
                        },
                    ]
                }
            ],
        },
        {
            "date": "2026-02-26T02:00Z",
            "competitions": [
                {
                    "competitors": [
                        {
                            "homeAway": "away",
                            "team": {
                                "abbreviation": "LAL",
                                "shortDisplayName": "Lakers",
                            },
                        },
                        {
                            "homeAway": "home",
                            "team": {
                                "abbreviation": "BOS",
                                "shortDisplayName": "Celtics",
                            },
                        },
                    ]
                }
            ],
        },
    ]
}

SAMPLE_ESPN_OVERRIDES_RESPONSE = {
    "events": [
        {
            "date": "2026-02-26T01:00Z",
            "competitions": [
                {
                    "competitors": [
                        {
                            "homeAway": "away",
                            "team": {
                                "abbreviation": "SA",
                                "shortDisplayName": "Spurs",
                            },
                        },
                        {
                            "homeAway": "home",
                            "team": {
                                "abbreviation": "GS",
                                "shortDisplayName": "Warriors",
                            },
                        },
                    ]
                }
            ],
        },
        {
            "date": "2026-02-26T02:00Z",
            "competitions": [
                {
                    "competitors": [
                        {
                            "homeAway": "away",
                            "team": {
                                "abbreviation": "NY",
                                "shortDisplayName": "Knicks",
                            },
                        },
                        {
                            "homeAway": "home",
                            "team": {
                                "abbreviation": "NO",
                                "shortDisplayName": "Pelicans",
                            },
                        },
                    ]
                }
            ],
        },
    ]
}

SAMPLE_GAMMA_EVENT = {
    "id": "99",
    "title": "MIA Heat vs PHI 76ers (Feb 26)",
    "slug": "nba-mia-phi-2026-02-26",
    "startDate": "2026-02-26T00:00:00Z",
    "endDate": "2026-02-27T00:00:00Z",
    "active": True,
    "closed": False,
    "markets": [
        {
            "id": "m1",
            "question": "Will Miami Heat win?",
            "conditionId": "0xdef",
            "slug": "heat-win",
            "outcomePrices": '["0.45", "0.55"]',
            "outcomes": '["Yes", "No"]',
            "volume": "50000",
            "active": True,
            "closed": False,
        }
    ],
}

ESPN_SCOREBOARD_URL = "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard"
GAMMA_EVENTS_URL = "https://gamma-api.polymarket.com/events"


class TestFetchEspnSchedule:
    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_espn_schedule(self):
        respx.get(ESPN_SCOREBOARD_URL).mock(return_value=httpx.Response(200, json=SAMPLE_ESPN_RESPONSE))
        async with httpx.AsyncClient() as http:
            games = await fetch_espn_schedule(http, Sport.NBA, target_date=date(2026, 2, 26))

        assert len(games) == 2
        assert games[0].slug == "nba-mia-phi-2026-02-26"
        assert games[0].away_team == "Heat"
        assert games[0].home_team == "76ers"
        assert games[0].away_abbr == "mia"
        assert games[0].home_abbr == "phi"
        assert games[1].slug == "nba-lal-bos-2026-02-26"
        assert games[1].away_team == "Lakers"
        assert games[1].home_team == "Celtics"

    @respx.mock
    @pytest.mark.asyncio
    async def test_abbrev_overrides(self):
        respx.get(ESPN_SCOREBOARD_URL).mock(return_value=httpx.Response(200, json=SAMPLE_ESPN_OVERRIDES_RESPONSE))
        async with httpx.AsyncClient() as http:
            games = await fetch_espn_schedule(http, Sport.NBA, target_date=date(2026, 2, 26))

        assert len(games) == 2
        # SA → sas, GS → gsw
        assert games[0].slug == "nba-sas-gsw-2026-02-26"
        assert games[0].away_abbr == "sas"
        assert games[0].home_abbr == "gsw"
        # NY → nyk, NO → nop
        assert games[1].slug == "nba-nyk-nop-2026-02-26"
        assert games[1].away_abbr == "nyk"
        assert games[1].home_abbr == "nop"

    @respx.mock
    @pytest.mark.asyncio
    async def test_missing_competitor_skipped(self):
        """Games with missing away/home data should be skipped."""
        incomplete = {
            "events": [
                {
                    "date": "2026-02-26T00:00Z",
                    "competitions": [
                        {
                            "competitors": [
                                {
                                    "homeAway": "home",
                                    "team": {
                                        "abbreviation": "PHI",
                                        "shortDisplayName": "76ers",
                                    },
                                }
                            ]
                        }
                    ],
                }
            ]
        }
        respx.get(ESPN_SCOREBOARD_URL).mock(return_value=httpx.Response(200, json=incomplete))
        async with httpx.AsyncClient() as http:
            games = await fetch_espn_schedule(http, Sport.NBA, target_date=date(2026, 2, 26))
        assert len(games) == 0

    @respx.mock
    @pytest.mark.asyncio
    async def test_unsupported_sport(self):
        async with httpx.AsyncClient() as http:
            games = await fetch_espn_schedule(http, Sport.SOCCER, target_date=date(2026, 2, 26))
        assert games == []


class TestFetchPolymarketGameEvent:
    @respx.mock
    @pytest.mark.asyncio
    async def test_found(self):
        respx.get(GAMMA_EVENTS_URL).mock(return_value=httpx.Response(200, json=[SAMPLE_GAMMA_EVENT]))
        async with httpx.AsyncClient() as http:
            event = await fetch_polymarket_game_event(
                http, "https://gamma-api.polymarket.com", "nba-mia-phi-2026-02-26"
            )
        assert event is not None
        assert event.id == "99"
        assert event.slug == "nba-mia-phi-2026-02-26"
        assert len(event.markets) == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_not_found(self):
        respx.get(GAMMA_EVENTS_URL).mock(return_value=httpx.Response(200, json=[]))
        async with httpx.AsyncClient() as http:
            event = await fetch_polymarket_game_event(
                http, "https://gamma-api.polymarket.com", "nba-xxx-yyy-2026-02-26"
            )
        assert event is None


class TestPolymarketDailyGames:
    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_daily_games(self):
        """ESPN returns games, Gamma returns matching events."""
        respx.get(ESPN_SCOREBOARD_URL).mock(return_value=httpx.Response(200, json=SAMPLE_ESPN_RESPONSE))
        # First game found on Polymarket
        respx.get(GAMMA_EVENTS_URL, params={"slug": "nba-mia-phi-2026-02-26"}).mock(
            return_value=httpx.Response(200, json=[SAMPLE_GAMMA_EVENT])
        )
        # Second game not on Polymarket
        respx.get(GAMMA_EVENTS_URL, params={"slug": "nba-lal-bos-2026-02-26"}).mock(
            return_value=httpx.Response(200, json=[])
        )

        client = PolymarketClient()
        try:
            events = await client.fetch_daily_games(sport=Sport.NBA, target_date=date(2026, 2, 26))
            assert len(events) == 1
            assert events[0].platform == Platform.POLYMARKET
            assert events[0].platform_event_id == "99"
            assert events[0].metadata.home_team == "76ers"
            assert events[0].metadata.away_team == "Heat"
            assert events[0].metadata.slug == "nba-mia-phi-2026-02-26"
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_game_not_on_polymarket(self):
        """All games missing from Polymarket → empty list."""
        single_game = {"events": [SAMPLE_ESPN_RESPONSE["events"][0]]}
        respx.get(ESPN_SCOREBOARD_URL).mock(return_value=httpx.Response(200, json=single_game))
        respx.get(GAMMA_EVENTS_URL, params={"slug": "nba-mia-phi-2026-02-26"}).mock(
            return_value=httpx.Response(200, json=[])
        )

        client = PolymarketClient()
        try:
            events = await client.fetch_daily_games(sport=Sport.NBA, target_date=date(2026, 2, 26))
            assert len(events) == 0
        finally:
            await client.close()


class TestFetchEventWithMarkets:
    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_event_with_markets(self):
        respx.get(GAMMA_EVENTS_URL, params={"slug": "nba-mia-phi-2026-02-26"}).mock(
            return_value=httpx.Response(200, json=[SAMPLE_GAMMA_EVENT])
        )

        client = PolymarketClient()
        try:
            result = await client.fetch_event_with_markets("nba-mia-phi-2026-02-26")
            assert result is not None
            event, markets = result
            assert event.platform == Platform.POLYMARKET
            assert event.platform_event_id == "99"
            assert len(markets) == 1
            assert markets[0].question == "Will Miami Heat win?"
            assert len(markets[0].outcomes) == 2
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_event_with_markets_not_found(self):
        respx.get(GAMMA_EVENTS_URL, params={"slug": "nba-xxx-yyy-2026-02-26"}).mock(
            return_value=httpx.Response(200, json=[])
        )

        client = PolymarketClient()
        try:
            result = await client.fetch_event_with_markets("nba-xxx-yyy-2026-02-26")
            assert result is None
        finally:
            await client.close()
