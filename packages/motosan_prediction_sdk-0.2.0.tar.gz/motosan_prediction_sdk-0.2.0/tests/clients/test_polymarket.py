from decimal import Decimal

import httpx
import pytest
import respx

from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.clients.polymarket.models import GammaEvent, GammaMarket
from prediction_sdk.clients.polymarket.normalize import normalize_event, normalize_market
from prediction_sdk.errors import PlatformError
from prediction_sdk.models.common import EventStatus, MarketType, Platform, Sport

SAMPLE_EVENT = {
    "id": "123",
    "title": "Will the Lakers win the NBA Championship?",
    "slug": "will-lakers-win-nba",
    "startDate": "2026-03-01T00:00:00Z",
    "endDate": "2026-06-01T00:00:00Z",
    "active": True,
    "closed": False,
    "markets": [
        {
            "id": "456",
            "question": "Will the Lakers win the NBA Championship?",
            "conditionId": "0xabc",
            "slug": "lakers-win",
            "outcomePrices": '["0.65", "0.35"]',
            "outcomes": '["Yes", "No"]',
            "volume": "150000",
            "active": True,
            "closed": False,
        }
    ],
}


class TestGammaModels:
    def test_gamma_market_from_dict(self):
        raw = SAMPLE_EVENT["markets"][0]
        market = GammaMarket.from_dict(raw)
        assert market.id == "456"
        assert market.question == "Will the Lakers win the NBA Championship?"
        assert market.outcome_prices == '["0.65", "0.35"]'

    def test_gamma_event_from_dict(self):
        event = GammaEvent.from_dict(SAMPLE_EVENT)
        assert event.id == "123"
        assert event.title == "Will the Lakers win the NBA Championship?"
        assert len(event.markets) == 1


class TestPolymarketNormalize:
    def test_normalize_event(self):
        raw = GammaEvent.from_dict(SAMPLE_EVENT)
        event = normalize_event(raw)
        assert event.platform == Platform.POLYMARKET
        assert event.platform_event_id == "123"
        assert event.category == Sport.NBA
        assert event.status == EventStatus.OPEN
        assert event.start_time is not None

    def test_normalize_market(self):
        raw_market = GammaMarket.from_dict(SAMPLE_EVENT["markets"][0])
        market = normalize_market(raw_market, "123")
        assert market.platform == Platform.POLYMARKET
        assert market.market_type == MarketType.BINARY
        assert len(market.outcomes) == 2
        assert market.outcomes[0].name == "Yes"
        assert market.outcomes[0].implied_probability == Decimal("0.65")
        assert market.outcomes[1].implied_probability == Decimal("0.35")
        # decimal_odds = 1 / price
        assert market.outcomes[0].decimal_odds > Decimal("1")


class TestPolymarketClient:
    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_events(self):
        respx.get("https://gamma-api.polymarket.com/events").mock(return_value=httpx.Response(200, json=[SAMPLE_EVENT]))
        client = PolymarketClient()
        try:
            events = await client.fetch_events()
            assert len(events) == 1
            assert events[0].platform == Platform.POLYMARKET
            assert events[0].category == Sport.NBA
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_events_with_category_filter(self):
        respx.get("https://gamma-api.polymarket.com/events").mock(return_value=httpx.Response(200, json=[SAMPLE_EVENT]))
        client = PolymarketClient()
        try:
            events = await client.fetch_events(category=Sport.POLITICS)
            assert len(events) == 0  # NBA event filtered out
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_markets(self):
        raw_market = SAMPLE_EVENT["markets"][0]
        respx.get("https://gamma-api.polymarket.com/markets").mock(return_value=httpx.Response(200, json=[raw_market]))
        client = PolymarketClient()
        try:
            markets = await client.fetch_markets("123")
            assert len(markets) == 1
            assert markets[0].platform == Platform.POLYMARKET
            assert len(markets[0].outcomes) == 2
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_events_raises_platform_error_on_http_error(self):
        respx.get("https://gamma-api.polymarket.com/events").mock(
            return_value=httpx.Response(429, text="Too Many Requests")
        )
        client = PolymarketClient()
        try:
            with pytest.raises(PlatformError) as exc_info:
                await client.fetch_events()
            assert exc_info.value.status_code == 429
            assert exc_info.value.platform == Platform.POLYMARKET
            assert exc_info.value.retryable is True
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_markets_raises_platform_error_on_http_error(self):
        respx.get("https://gamma-api.polymarket.com/markets").mock(
            return_value=httpx.Response(500, text="Internal Server Error")
        )
        client = PolymarketClient()
        try:
            with pytest.raises(PlatformError) as exc_info:
                await client.fetch_markets("123")
            assert exc_info.value.status_code == 500
            assert exc_info.value.retryable is False
        finally:
            await client.close()
