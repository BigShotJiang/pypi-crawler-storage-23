from decimal import Decimal

import httpx
import pytest
import respx

from prediction_sdk.clients.kalshi.client import KalshiClient
from prediction_sdk.clients.kalshi.models import KalshiEvent, KalshiMarket
from prediction_sdk.clients.kalshi.normalize import normalize_event, normalize_market
from prediction_sdk.errors import PlatformError
from prediction_sdk.models.common import EventStatus, MarketType, Platform, Sport

SAMPLE_MARKET = {
    "ticker": "NBA-LAKERS-WIN-YES",
    "event_ticker": "NBA-LAKERS-WIN",
    "title": "Will the Lakers win?",
    "subtitle": "NBA",
    "yes_bid": 60,
    "yes_ask": 62,
    "no_bid": 38,
    "no_ask": 40,
    "last_price": 61,
    "volume": 50000,
    "status": "active",
    "open_time": "2026-03-01T00:00:00Z",
    "close_time": "2026-03-02T00:00:00Z",
    "result": "",
}

SAMPLE_EVENT = {
    "event_ticker": "NBA-LAKERS-WIN",
    "title": "Will the Lakers win the NBA game?",
    "category": "Sports",
    "sub_title": "NBA Game",
    "mutually_exclusive": True,
    "markets": [SAMPLE_MARKET],
}


class TestKalshiModels:
    def test_kalshi_market_from_dict(self):
        market = KalshiMarket.from_dict(SAMPLE_MARKET)
        assert market.ticker == "NBA-LAKERS-WIN-YES"
        assert market.yes_bid == 60
        assert market.yes_ask == 62

    def test_kalshi_event_from_dict(self):
        event = KalshiEvent.from_dict(SAMPLE_EVENT)
        assert event.event_ticker == "NBA-LAKERS-WIN"
        assert len(event.markets) == 1


class TestKalshiNormalize:
    def test_normalize_event(self):
        raw = KalshiEvent.from_dict(SAMPLE_EVENT)
        event = normalize_event(raw)
        assert event.platform == Platform.KALSHI
        assert event.platform_event_id == "NBA-LAKERS-WIN"
        assert event.category == Sport.NBA
        assert event.status == EventStatus.OPEN
        assert event.start_time is not None

    def test_normalize_market(self):
        raw = KalshiMarket.from_dict(SAMPLE_MARKET)
        market = normalize_market(raw, "NBA-LAKERS-WIN")
        assert market.platform == Platform.KALSHI
        assert market.market_type == MarketType.BINARY
        assert len(market.outcomes) == 2
        # midpoint: (60+62)/2/100 = 0.61
        assert market.outcomes[0].name == "Yes"
        assert market.outcomes[0].implied_probability == Decimal("0.61")
        # midpoint: (38+40)/2/100 = 0.39
        assert market.outcomes[1].name == "No"
        assert market.outcomes[1].implied_probability == Decimal("0.39")


class TestKalshiClientAuth:
    """Tests for KalshiClient API key authentication."""

    @pytest.mark.asyncio
    async def test_api_key_sets_authorization_header(self):
        """When api_key is provided, the internal httpx client should carry an Authorization header."""
        client = KalshiClient(api_key="my-secret-key")
        try:
            assert client._api_key == "my-secret-key"
            assert client._http.headers["authorization"] == "Bearer my-secret-key"
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_no_api_key_omits_authorization_header(self):
        """When api_key is not provided, no Authorization header should be set."""
        client = KalshiClient()
        try:
            assert client._api_key is None
            assert "authorization" not in client._http.headers
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_custom_http_client_preserves_api_key(self):
        """When a custom http_client is given, api_key is stored but the client is not modified."""
        custom = httpx.AsyncClient()
        client = KalshiClient(http_client=custom, api_key="key-123")
        try:
            assert client._api_key == "key-123"
            # The custom client is used as-is; headers are not injected.
            assert client._http is custom
        finally:
            await custom.aclose()


class TestKalshiClient:
    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_events(self):
        respx.get("https://api.elections.kalshi.com/trade-api/v2/events").mock(
            return_value=httpx.Response(200, json={"events": [SAMPLE_EVENT], "cursor": ""})
        )
        client = KalshiClient()
        try:
            events = await client.fetch_events()
            assert len(events) == 1
            assert events[0].platform == Platform.KALSHI
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_markets(self):
        respx.get("https://api.elections.kalshi.com/trade-api/v2/events/NBA-LAKERS-WIN/markets").mock(
            return_value=httpx.Response(200, json={"markets": [SAMPLE_MARKET]})
        )
        client = KalshiClient()
        try:
            markets = await client.fetch_markets("NBA-LAKERS-WIN")
            assert len(markets) == 1
            assert markets[0].outcomes[0].implied_probability == Decimal("0.61")
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_events_raises_platform_error_on_http_error(self):
        respx.get("https://api.elections.kalshi.com/trade-api/v2/events").mock(
            return_value=httpx.Response(503, text="Service Unavailable")
        )
        client = KalshiClient()
        try:
            with pytest.raises(PlatformError) as exc_info:
                await client.fetch_events()
            assert exc_info.value.status_code == 503
            assert exc_info.value.platform == Platform.KALSHI
            assert exc_info.value.retryable is True
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_fetch_markets_raises_platform_error_on_http_error(self):
        respx.get("https://api.elections.kalshi.com/trade-api/v2/events/NBA-LAKERS-WIN/markets").mock(
            return_value=httpx.Response(401, text="Unauthorized")
        )
        client = KalshiClient()
        try:
            with pytest.raises(PlatformError) as exc_info:
                await client.fetch_markets("NBA-LAKERS-WIN")
            assert exc_info.value.status_code == 401
            assert exc_info.value.retryable is False
        finally:
            await client.close()
