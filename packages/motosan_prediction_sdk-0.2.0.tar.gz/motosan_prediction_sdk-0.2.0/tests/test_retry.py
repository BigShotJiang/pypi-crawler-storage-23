from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock

import pytest

from prediction_sdk.errors import PlatformError
from prediction_sdk.models.common import Platform
from prediction_sdk.utils.retry import with_retry


def _make_retryable_error(status: int = 429) -> PlatformError:
    return PlatformError(
        platform=Platform.POLYMARKET,
        status_code=status,
        message="rate limited",
        retryable=True,
    )


def _make_non_retryable_error(status: int = 400) -> PlatformError:
    return PlatformError(
        platform=Platform.POLYMARKET,
        status_code=status,
        message="bad request",
        retryable=False,
    )


@pytest.mark.asyncio
async def test_succeeds_first_attempt(monkeypatch: pytest.MonkeyPatch) -> None:
    """No retry needed when the function succeeds immediately."""
    monkeypatch.setattr(asyncio, "sleep", AsyncMock())
    fn = AsyncMock(return_value="ok")

    result = await with_retry(fn)

    assert result == "ok"
    fn.assert_awaited_once()
    asyncio.sleep.assert_not_awaited()  # type: ignore[attr-defined]


@pytest.mark.asyncio
async def test_retries_on_retryable_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Should retry on retryable error and succeed on second attempt."""
    monkeypatch.setattr(asyncio, "sleep", AsyncMock())
    fn = AsyncMock(side_effect=[_make_retryable_error(), "ok"])

    result = await with_retry(fn)

    assert result == "ok"
    assert fn.await_count == 2
    asyncio.sleep.assert_awaited_once_with(1.0)  # type: ignore[attr-defined]


@pytest.mark.asyncio
async def test_raises_immediately_on_non_retryable_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-retryable errors should propagate immediately without retry."""
    monkeypatch.setattr(asyncio, "sleep", AsyncMock())
    err = _make_non_retryable_error()
    fn = AsyncMock(side_effect=err)

    with pytest.raises(PlatformError) as exc_info:
        await with_retry(fn)

    assert exc_info.value is err
    fn.assert_awaited_once()
    asyncio.sleep.assert_not_awaited()  # type: ignore[attr-defined]


@pytest.mark.asyncio
async def test_raises_after_max_attempts_exhausted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Should raise the last retryable error after all attempts are exhausted."""
    monkeypatch.setattr(asyncio, "sleep", AsyncMock())
    errors = [_make_retryable_error() for _ in range(3)]
    fn = AsyncMock(side_effect=errors)

    with pytest.raises(PlatformError) as exc_info:
        await with_retry(fn, max_attempts=3)

    assert exc_info.value is errors[2]
    assert fn.await_count == 3
    # sleep called for attempt 0 (delay=1.0) and attempt 1 (delay=2.0), not for the last
    assert asyncio.sleep.await_count == 2  # type: ignore[attr-defined]
