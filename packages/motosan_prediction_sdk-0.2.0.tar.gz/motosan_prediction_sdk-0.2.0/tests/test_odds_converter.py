from decimal import Decimal

import pytest

from prediction_sdk.arbitrage.odds_converter import (
    american_to_decimal,
    american_to_implied_prob,
    decimal_to_american,
    decimal_to_implied_prob,
    implied_prob_to_american,
    implied_prob_to_decimal,
)


class TestImpliedProbToDecimal:
    def test_even_odds(self):
        assert implied_prob_to_decimal(Decimal("0.5")) == Decimal("2")

    def test_favorite(self):
        result = implied_prob_to_decimal(Decimal("0.8"))
        assert result == Decimal("1.25")

    def test_underdog(self):
        result = implied_prob_to_decimal(Decimal("0.25"))
        assert result == Decimal("4")

    def test_certainty(self):
        assert implied_prob_to_decimal(Decimal("1")) == Decimal("1")

    def test_zero_raises(self):
        with pytest.raises(ValueError):
            implied_prob_to_decimal(Decimal("0"))

    def test_negative_raises(self):
        with pytest.raises(ValueError):
            implied_prob_to_decimal(Decimal("-0.5"))


class TestDecimalToImpliedProb:
    def test_even_odds(self):
        assert decimal_to_implied_prob(Decimal("2")) == Decimal("0.5")

    def test_favorite(self):
        assert decimal_to_implied_prob(Decimal("1.25")) == Decimal("0.8")

    def test_below_one_raises(self):
        with pytest.raises(ValueError):
            decimal_to_implied_prob(Decimal("0.5"))


class TestAmericanToImpliedProb:
    def test_positive(self):
        result = american_to_implied_prob(200)
        expected = Decimal("100") / Decimal("300")
        assert abs(result - expected) < Decimal("0.0001")

    def test_negative(self):
        result = american_to_implied_prob(-150)
        expected = Decimal("150") / Decimal("250")
        assert abs(result - expected) < Decimal("0.0001")

    def test_zero_raises(self):
        with pytest.raises(ValueError):
            american_to_implied_prob(0)


class TestImpliedProbToAmerican:
    def test_favorite(self):
        result = implied_prob_to_american(Decimal("0.6"))
        assert result == -150

    def test_underdog(self):
        result = implied_prob_to_american(Decimal("0.4"))
        assert result == 150

    def test_even(self):
        result = implied_prob_to_american(Decimal("0.5"))
        assert result == -100

    def test_zero_raises(self):
        with pytest.raises(ValueError):
            implied_prob_to_american(Decimal("0"))

    def test_one_raises(self):
        with pytest.raises(ValueError):
            implied_prob_to_american(Decimal("1"))


class TestRoundTrips:
    def test_decimal_roundtrip(self):
        prob = Decimal("0.65")
        odds = implied_prob_to_decimal(prob)
        back = decimal_to_implied_prob(odds)
        assert abs(back - prob) < Decimal("0.0001")

    def test_american_roundtrip_positive(self):
        prob = Decimal("0.3")
        american = implied_prob_to_american(prob)
        back = american_to_implied_prob(american)
        assert abs(back - prob) < Decimal("0.01")

    def test_american_roundtrip_negative(self):
        prob = Decimal("0.7")
        american = implied_prob_to_american(prob)
        back = american_to_implied_prob(american)
        assert abs(back - prob) < Decimal("0.01")

    def test_decimal_to_american_to_decimal(self):
        odds = Decimal("2.5")
        american = decimal_to_american(odds)
        back = american_to_decimal(american)
        assert abs(back - odds) < Decimal("0.1")
