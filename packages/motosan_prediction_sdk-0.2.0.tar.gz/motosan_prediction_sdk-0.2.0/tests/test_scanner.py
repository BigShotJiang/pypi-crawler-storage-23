"""Tests for the arbitrage scanner orchestration."""

from decimal import Decimal
from unittest.mock import AsyncMock, Mock, patch

import pytest

from prediction_sdk.arbitrage.scanner import ScanResult, scan_arbitrage
from prediction_sdk.models.common import MarketType, Platform, Sport
from prediction_sdk.models.event import EventMetadata, UnifiedEvent
from prediction_sdk.models.market import Outcome, UnifiedMarket


def _make_event(platform: Platform, event_id: str, title: str, sport: Sport = Sport.NBA) -> UnifiedEvent:
    return UnifiedEvent(
        platform=platform,
        platform_event_id=event_id,
        title=title,
        title_original=title,
        category=sport,
        metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
    )


def _make_market(platform: Platform, market_id: str, event_id: str, outcomes: list[Outcome]) -> UnifiedMarket:
    return UnifiedMarket(
        platform=platform,
        platform_market_id=market_id,
        event_id=event_id,
        market_type=MarketType.MONEYLINE,
        question="test",
        outcomes=outcomes,
    )


_POLY_EVENT = _make_event(Platform.POLYMARKET, "pe1", "Lakers vs Celtics")
_KALSHI_EVENT = _make_event(Platform.KALSHI, "ke1", "Lakers vs Celtics")

_POLY_MARKET = _make_market(
    Platform.POLYMARKET,
    "pm1",
    "pe1",
    outcomes=[
        Outcome(name="lakers", implied_probability=Decimal("0.35"), decimal_odds=Decimal("2.857"), raw_odds="0.35"),
        Outcome(name="celtics", implied_probability=Decimal("0.67"), decimal_odds=Decimal("1.493"), raw_odds="0.67"),
    ],
)
_KALSHI_MARKET = _make_market(
    Platform.KALSHI,
    "km1",
    "ke1",
    outcomes=[
        Outcome(name="lakers", implied_probability=Decimal("0.40"), decimal_odds=Decimal("2.50"), raw_odds="40"),
        Outcome(name="celtics", implied_probability=Decimal("0.625"), decimal_odds=Decimal("1.60"), raw_odds="62.5"),
    ],
)


@pytest.fixture
def _mock_config():
    with patch("prediction_sdk.arbitrage.scanner.Config") as mock:
        cfg = mock.from_env.return_value
        cfg.polymarket_gamma_url = "https://gamma-api.polymarket.com"
        cfg.polymarket_clob_url = "https://clob.polymarket.com"
        cfg.kalshi_api_url = "https://api.elections.kalshi.com/trade-api/v2"
        yield mock


@pytest.fixture
def _mock_clients():
    poly_client = AsyncMock()
    poly_client.platform = Mock(return_value=Platform.POLYMARKET)
    poly_client.fetch_events.return_value = [_POLY_EVENT]
    poly_client.fetch_markets.return_value = [_POLY_MARKET]

    kalshi_client = AsyncMock()
    kalshi_client.platform = Mock(return_value=Platform.KALSHI)
    kalshi_client.fetch_events.return_value = [_KALSHI_EVENT]
    kalshi_client.fetch_markets.return_value = [_KALSHI_MARKET]

    tw_client = AsyncMock()
    tw_client.platform = Mock(return_value=Platform.KALSHI)
    tw_client.fetch_events.return_value = []
    tw_client.fetch_markets.return_value = []

    with (
        patch("prediction_sdk.arbitrage.scanner.PolymarketClient", return_value=poly_client),
        patch("prediction_sdk.arbitrage.scanner.KalshiClient", return_value=kalshi_client),
    ):
        yield {
            "polymarket": poly_client,
            "kalshi": kalshi_client,
        }


class TestScanArbitrage:
    async def test_returns_opportunities(self, _mock_config, _mock_clients):
        result = await scan_arbitrage(sport=Sport.NBA, platforms=[Platform.POLYMARKET, Platform.KALSHI])

        assert isinstance(result, ScanResult)
        assert result.events_fetched == 2
        assert Platform.POLYMARKET in result.platforms_used
        assert Platform.KALSHI in result.platforms_used

    async def test_platform_filtering(self, _mock_config, _mock_clients):
        result = await scan_arbitrage(sport=Sport.NBA, platforms=[Platform.POLYMARKET])

        assert result.platforms_used == [Platform.POLYMARKET]
        # Only one platform — no cross-platform matches possible
        assert result.mappings_found == 0
        assert result.opportunities == []

    async def test_empty_when_no_matches(self, _mock_config, _mock_clients):
        event_a = UnifiedEvent(
            platform=Platform.POLYMARKET,
            platform_event_id="pe2",
            title="Unrelated Event A",
            title_original="Unrelated Event A",
            category=Sport.NBA,
            metadata=EventMetadata(home_team="Warriors", away_team="Suns"),
        )
        event_b = UnifiedEvent(
            platform=Platform.KALSHI,
            platform_event_id="ke2",
            title="Completely Different Event B",
            title_original="Completely Different Event B",
            category=Sport.NBA,
            metadata=EventMetadata(home_team="Bucks", away_team="Heat"),
        )
        _mock_clients["polymarket"].fetch_events.return_value = [event_a]
        _mock_clients["kalshi"].fetch_events.return_value = [event_b]

        result = await scan_arbitrage(sport=Sport.NBA, platforms=[Platform.POLYMARKET, Platform.KALSHI])

        assert result.events_fetched == 2
        assert result.mappings_found == 0
        assert result.opportunities == []

    async def test_clients_closed_on_success(self, _mock_config, _mock_clients):
        await scan_arbitrage(sport=Sport.NBA, platforms=[Platform.POLYMARKET, Platform.KALSHI])

        _mock_clients["polymarket"].close.assert_awaited_once()
        _mock_clients["kalshi"].close.assert_awaited_once()

    async def test_clients_closed_on_error(self, _mock_config, _mock_clients):
        """Even when a platform fails, clients are still closed."""
        _mock_clients["polymarket"].fetch_events.side_effect = RuntimeError("API error")

        result = await scan_arbitrage(sport=Sport.NBA, platforms=[Platform.POLYMARKET, Platform.KALSHI])

        _mock_clients["polymarket"].close.assert_awaited_once()
        _mock_clients["kalshi"].close.assert_awaited_once()
        # The scan should still succeed with partial results
        assert isinstance(result, ScanResult)

    async def test_one_platform_event_failure_still_returns_other(self, _mock_config, _mock_clients):
        """If one platform raises during fetch_events, the other platform's events are still processed."""
        _mock_clients["polymarket"].fetch_events.side_effect = RuntimeError("polymarket down")

        result = await scan_arbitrage(sport=Sport.NBA, platforms=[Platform.POLYMARKET, Platform.KALSHI])

        assert isinstance(result, ScanResult)
        # Only kalshi events should be fetched
        assert result.events_fetched == 1
        # Both platforms are listed as used (they were attempted)
        assert Platform.POLYMARKET in result.platforms_used
        assert Platform.KALSHI in result.platforms_used

    async def test_one_platform_market_failure_still_returns_results(self, _mock_config, _mock_clients):
        """If one platform raises during fetch_markets, the scan still completes without crashing."""
        _mock_clients["polymarket"].fetch_markets.side_effect = RuntimeError("polymarket markets down")

        result = await scan_arbitrage(sport=Sport.NBA, platforms=[Platform.POLYMARKET, Platform.KALSHI])

        assert isinstance(result, ScanResult)
        # Events from both platforms are still fetched
        assert result.events_fetched == 2
