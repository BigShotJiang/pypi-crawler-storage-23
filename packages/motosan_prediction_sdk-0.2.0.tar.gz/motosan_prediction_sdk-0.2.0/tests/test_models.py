from decimal import Decimal

from prediction_sdk.models import (
    ArbitrageOpportunity,
    ArbLeg,
    EventMapping,
    EventStatus,
    MappingEntry,
    MarketType,
    Outcome,
    Platform,
    Sport,
    UnifiedEvent,
    UnifiedMarket,
)


def test_platform_enum():
    assert Platform.POLYMARKET.value == "polymarket"
    assert Platform.KALSHI.value == "kalshi"


def test_sport_enum():
    assert Sport.NBA.value == "nba"
    assert Sport.POLITICS.value == "politics"


def test_unified_event_creation():
    event = UnifiedEvent(
        platform=Platform.POLYMARKET,
        platform_event_id="abc123",
        title="Lakers vs Celtics",
        title_original="Lakers vs Celtics",
        category=Sport.NBA,
        status=EventStatus.OPEN,
    )
    assert event.platform == Platform.POLYMARKET
    assert event.platform_event_id == "abc123"
    assert event.title == "Lakers vs Celtics"
    assert event.category == Sport.NBA
    assert event.status == EventStatus.OPEN
    assert event.fetched_at is not None


def test_outcome_creation():
    outcome = Outcome(
        name="YES",
        implied_probability=Decimal("0.65"),
        decimal_odds=Decimal("1.538"),
        price=Decimal("0.65"),
        raw_odds="0.65",
    )
    assert outcome.name == "YES"
    assert outcome.implied_probability == Decimal("0.65")


def test_unified_market_creation():
    market = UnifiedMarket(
        platform=Platform.KALSHI,
        platform_market_id="market-1",
        event_id="event-1",
        market_type=MarketType.BINARY,
        question="Will Lakers win?",
        outcomes=[
            Outcome(
                name="YES",
                implied_probability=Decimal("0.60"),
                decimal_odds=Decimal("1.667"),
                raw_odds="60",
            ),
            Outcome(
                name="NO",
                implied_probability=Decimal("0.40"),
                decimal_odds=Decimal("2.50"),
                raw_odds="40",
            ),
        ],
    )
    assert market.platform == Platform.KALSHI
    assert len(market.outcomes) == 2
    assert market.outcomes[0].implied_probability == Decimal("0.60")


def test_event_mapping():
    event = UnifiedEvent(
        platform=Platform.POLYMARKET,
        platform_event_id="e1",
        title="Lakers vs Celtics",
        title_original="Lakers vs Celtics",
        category=Sport.NBA,
    )
    market = UnifiedMarket(
        platform=Platform.POLYMARKET,
        platform_market_id="m1",
        event_id="e1",
        market_type=MarketType.MONEYLINE,
        question="Who will win?",
    )
    entry = MappingEntry(
        platform=Platform.POLYMARKET,
        event=event,
        market=market,
        outcome_mapping={"YES": "Lakers", "NO": "Celtics"},
    )
    mapping = EventMapping(
        canonical_title="Lakers vs Celtics",
        entries=[entry],
        match_confidence=0.95,
        match_method="rule_based",
    )
    assert mapping.canonical_title == "Lakers vs Celtics"
    assert len(mapping.entries) == 1
    assert mapping.match_confidence == 0.95


def test_arbitrage_opportunity():
    market = UnifiedMarket(
        platform=Platform.POLYMARKET,
        platform_market_id="m1",
        event_id="e1",
        market_type=MarketType.BINARY,
        question="test",
    )
    mapping = EventMapping(canonical_title="Test Event")
    leg = ArbLeg(
        platform=Platform.POLYMARKET,
        market=market,
        outcome="YES",
        implied_probability=Decimal("0.35"),
        decimal_odds=Decimal("2.857"),
        stake_fraction=Decimal("0.50"),
    )
    opp = ArbitrageOpportunity(
        mapping=mapping,
        legs=[leg],
        total_implied_prob=Decimal("0.975"),
        profit_margin=Decimal("0.025"),
    )
    assert opp.profit_margin == Decimal("0.025")
    assert opp.total_implied_prob < Decimal("1.0")
