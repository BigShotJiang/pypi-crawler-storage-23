from __future__ import annotations

from dataclasses import dataclass

import pytest

from prediction_sdk.errors import PlatformError
from prediction_sdk.models.common import Platform


@dataclass
class FakeResponse:
    """Minimal stand-in for an httpx.Response."""

    status_code: int
    text: str = "error body"


class TestPlatformErrorFromResponse:
    @pytest.mark.parametrize(
        "status_code,expected_retryable",
        [
            (429, True),
            (502, True),
            (503, True),
            (504, True),
            (400, False),
            (401, False),
            (404, False),
            (500, False),
        ],
    )
    def test_retryable_flag(self, status_code: int, expected_retryable: bool):
        resp = FakeResponse(status_code=status_code, text="some error")
        err = PlatformError.from_response(Platform.POLYMARKET, resp)
        assert err.retryable is expected_retryable
        assert err.status_code == status_code
        assert err.platform == Platform.POLYMARKET

    def test_message_truncated_to_200_chars(self):
        long_body = "x" * 500
        resp = FakeResponse(status_code=500, text=long_body)
        err = PlatformError.from_response(Platform.KALSHI, resp)
        assert len(err.message) == 200
        assert err.message == "x" * 200

    def test_message_short_body_preserved(self):
        resp = FakeResponse(status_code=404, text="not found")
        err = PlatformError.from_response(Platform.KALSHI, resp)
        assert err.message == "not found"

    def test_is_exception(self):
        resp = FakeResponse(status_code=500, text="fail")
        err = PlatformError.from_response(Platform.POLYMARKET, resp)
        assert isinstance(err, Exception)

    def test_can_be_raised_and_caught(self):
        resp = FakeResponse(status_code=401, text="unauthorized")
        err = PlatformError.from_response(Platform.KALSHI, resp)
        with pytest.raises(PlatformError) as exc_info:
            raise err
        assert exc_info.value.status_code == 401
        assert exc_info.value.retryable is False
