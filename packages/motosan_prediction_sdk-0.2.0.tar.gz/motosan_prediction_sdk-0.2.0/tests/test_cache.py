"""Tests for TTL caching in Polymarket and Kalshi clients."""

from __future__ import annotations

import httpx
import pytest
import respx

from prediction_sdk.clients.kalshi.client import KalshiClient
from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.models.common import Sport

# ---------------------------------------------------------------------------
# Sample payloads (reused from client test modules)
# ---------------------------------------------------------------------------

POLY_SAMPLE_EVENT = {
    "id": "123",
    "title": "Will the Lakers win the NBA Championship?",
    "slug": "will-lakers-win-nba",
    "startDate": "2026-03-01T00:00:00Z",
    "endDate": "2026-06-01T00:00:00Z",
    "active": True,
    "closed": False,
    "markets": [
        {
            "id": "456",
            "question": "Will the Lakers win the NBA Championship?",
            "conditionId": "0xabc",
            "slug": "lakers-win",
            "outcomePrices": '["0.65", "0.35"]',
            "outcomes": '["Yes", "No"]',
            "volume": "150000",
            "active": True,
            "closed": False,
        }
    ],
}

POLY_SAMPLE_MARKET = POLY_SAMPLE_EVENT["markets"][0]

KALSHI_SAMPLE_MARKET = {
    "ticker": "NBA-LAKERS-WIN-YES",
    "event_ticker": "NBA-LAKERS-WIN",
    "title": "Will the Lakers win?",
    "subtitle": "NBA",
    "yes_bid": 60,
    "yes_ask": 62,
    "no_bid": 38,
    "no_ask": 40,
    "last_price": 61,
    "volume": 50000,
    "status": "active",
    "open_time": "2026-03-01T00:00:00Z",
    "close_time": "2026-03-02T00:00:00Z",
    "result": "",
}

KALSHI_SAMPLE_EVENT = {
    "event_ticker": "NBA-LAKERS-WIN",
    "title": "Will the Lakers win the NBA game?",
    "category": "Sports",
    "sub_title": "NBA Game",
    "mutually_exclusive": True,
    "markets": [KALSHI_SAMPLE_MARKET],
}

# ===== Polymarket cache tests =============================================


class TestPolymarketEventCache:
    @respx.mock
    @pytest.mark.asyncio
    async def test_second_call_returns_cached_result(self):
        """HTTP should only be called once; second call uses cache."""
        route = respx.get("https://gamma-api.polymarket.com/events").mock(
            return_value=httpx.Response(200, json=[POLY_SAMPLE_EVENT])
        )
        client = PolymarketClient()
        try:
            first = await client.fetch_events()
            second = await client.fetch_events()
            assert first == second
            assert route.call_count == 1
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_different_params_make_separate_cache_entries(self):
        """Different (category, limit) combos each hit the API."""
        route = respx.get("https://gamma-api.polymarket.com/events").mock(
            return_value=httpx.Response(200, json=[POLY_SAMPLE_EVENT])
        )
        client = PolymarketClient()
        try:
            await client.fetch_events(category=None, limit=100)
            await client.fetch_events(category=Sport.NBA, limit=50)
            # Two distinct cache keys -> two HTTP calls
            assert route.call_count == 2
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_clear_cache_forces_fresh_fetch(self):
        """After clear_cache(), the next call must hit the API again."""
        route = respx.get("https://gamma-api.polymarket.com/events").mock(
            return_value=httpx.Response(200, json=[POLY_SAMPLE_EVENT])
        )
        client = PolymarketClient()
        try:
            await client.fetch_events()
            assert route.call_count == 1
            client.clear_cache()
            await client.fetch_events()
            assert route.call_count == 2
        finally:
            await client.close()


class TestPolymarketMarketCache:
    @respx.mock
    @pytest.mark.asyncio
    async def test_second_call_returns_cached_result(self):
        route = respx.get("https://gamma-api.polymarket.com/markets").mock(
            return_value=httpx.Response(200, json=[POLY_SAMPLE_MARKET])
        )
        client = PolymarketClient()
        try:
            first = await client.fetch_markets("123")
            second = await client.fetch_markets("123")
            assert first == second
            assert route.call_count == 1
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_different_event_ids_make_separate_cache_entries(self):
        route = respx.get("https://gamma-api.polymarket.com/markets").mock(
            return_value=httpx.Response(200, json=[POLY_SAMPLE_MARKET])
        )
        client = PolymarketClient()
        try:
            await client.fetch_markets("123")
            await client.fetch_markets("456")
            assert route.call_count == 2
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_clear_cache_forces_fresh_fetch(self):
        route = respx.get("https://gamma-api.polymarket.com/markets").mock(
            return_value=httpx.Response(200, json=[POLY_SAMPLE_MARKET])
        )
        client = PolymarketClient()
        try:
            await client.fetch_markets("123")
            assert route.call_count == 1
            client.clear_cache()
            await client.fetch_markets("123")
            assert route.call_count == 2
        finally:
            await client.close()


# ===== Kalshi cache tests =================================================


class TestKalshiEventCache:
    @respx.mock
    @pytest.mark.asyncio
    async def test_second_call_returns_cached_result(self):
        route = respx.get("https://api.elections.kalshi.com/trade-api/v2/events").mock(
            return_value=httpx.Response(200, json={"events": [KALSHI_SAMPLE_EVENT], "cursor": ""})
        )
        client = KalshiClient()
        try:
            first = await client.fetch_events()
            second = await client.fetch_events()
            assert first == second
            assert route.call_count == 1
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_different_params_make_separate_cache_entries(self):
        route = respx.get("https://api.elections.kalshi.com/trade-api/v2/events").mock(
            return_value=httpx.Response(200, json={"events": [KALSHI_SAMPLE_EVENT], "cursor": ""})
        )
        client = KalshiClient()
        try:
            await client.fetch_events(category=None, limit=100)
            await client.fetch_events(category=Sport.NBA, limit=50)
            assert route.call_count == 2
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_clear_cache_forces_fresh_fetch(self):
        route = respx.get("https://api.elections.kalshi.com/trade-api/v2/events").mock(
            return_value=httpx.Response(200, json={"events": [KALSHI_SAMPLE_EVENT], "cursor": ""})
        )
        client = KalshiClient()
        try:
            await client.fetch_events()
            assert route.call_count == 1
            client.clear_cache()
            await client.fetch_events()
            assert route.call_count == 2
        finally:
            await client.close()


class TestKalshiMarketCache:
    @respx.mock
    @pytest.mark.asyncio
    async def test_second_call_returns_cached_result(self):
        route = respx.get("https://api.elections.kalshi.com/trade-api/v2/events/NBA-LAKERS-WIN/markets").mock(
            return_value=httpx.Response(200, json={"markets": [KALSHI_SAMPLE_MARKET]})
        )
        client = KalshiClient()
        try:
            first = await client.fetch_markets("NBA-LAKERS-WIN")
            second = await client.fetch_markets("NBA-LAKERS-WIN")
            assert first == second
            assert route.call_count == 1
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_different_event_ids_make_separate_cache_entries(self):
        route_a = respx.get("https://api.elections.kalshi.com/trade-api/v2/events/EVT-A/markets").mock(
            return_value=httpx.Response(200, json={"markets": [KALSHI_SAMPLE_MARKET]})
        )
        route_b = respx.get("https://api.elections.kalshi.com/trade-api/v2/events/EVT-B/markets").mock(
            return_value=httpx.Response(200, json={"markets": [KALSHI_SAMPLE_MARKET]})
        )
        client = KalshiClient()
        try:
            await client.fetch_markets("EVT-A")
            await client.fetch_markets("EVT-B")
            assert route_a.call_count == 1
            assert route_b.call_count == 1
        finally:
            await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_clear_cache_forces_fresh_fetch(self):
        route = respx.get("https://api.elections.kalshi.com/trade-api/v2/events/NBA-LAKERS-WIN/markets").mock(
            return_value=httpx.Response(200, json={"markets": [KALSHI_SAMPLE_MARKET]})
        )
        client = KalshiClient()
        try:
            await client.fetch_markets("NBA-LAKERS-WIN")
            assert route.call_count == 1
            client.clear_cache()
            await client.fetch_markets("NBA-LAKERS-WIN")
            assert route.call_count == 2
        finally:
            await client.close()
