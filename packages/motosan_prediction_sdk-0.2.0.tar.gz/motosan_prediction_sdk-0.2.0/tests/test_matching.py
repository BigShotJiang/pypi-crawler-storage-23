from datetime import UTC, datetime, timedelta

from prediction_sdk.matching.matcher import EventMatcher
from prediction_sdk.matching.strategies import DateMatch, TeamMatch, TitleSimilarity
from prediction_sdk.matching.team_aliases import canonicalize_team, teams_match
from prediction_sdk.models.common import EventStatus, Platform, Sport
from prediction_sdk.models.event import EventMetadata, UnifiedEvent


def _make_event(
    platform: Platform,
    event_id: str,
    title: str,
    category: Sport = Sport.NBA,
    start_time: datetime | None = None,
    metadata: EventMetadata | None = None,
) -> UnifiedEvent:
    return UnifiedEvent(
        platform=platform,
        platform_event_id=event_id,
        title=title,
        title_original=title,
        category=category,
        start_time=start_time,
        status=EventStatus.OPEN,
        metadata=metadata or EventMetadata(),
    )


class TestTeamAliases:
    def test_canonicalize_english(self):
        assert canonicalize_team("Lakers") == "lakers"
        assert canonicalize_team("Los Angeles Lakers") == "lakers"
        assert canonicalize_team("LA Lakers") == "lakers"

    def test_canonicalize_abbr(self):
        assert canonicalize_team("LAL") == "lakers"
        assert canonicalize_team("GSW") == "warriors"
        assert canonicalize_team("BOS") == "celtics"

    def test_canonicalize_chinese(self):
        assert canonicalize_team("湖人") == "lakers"
        assert canonicalize_team("勇士") == "warriors"

    def test_canonicalize_unknown(self):
        assert canonicalize_team("Unknown Team XYZ") is None

    def test_teams_match(self):
        assert teams_match("Lakers", "湖人") is True
        assert teams_match("LAL", "Los Angeles Lakers") is True
        assert teams_match("Lakers", "Celtics") is False

    def test_teams_match_unknown(self):
        assert teams_match("Unknown", "Lakers") is False


class TestDateMatch:
    def test_same_time(self):
        now = datetime.now(UTC)
        a = _make_event(Platform.POLYMARKET, "1", "Test", start_time=now)
        b = _make_event(Platform.KALSHI, "2", "Test", start_time=now)
        strategy = DateMatch()
        assert strategy.score(a, b) == 1.0

    def test_within_tolerance(self):
        now = datetime.now(UTC)
        a = _make_event(Platform.POLYMARKET, "1", "Test", start_time=now)
        b = _make_event(Platform.KALSHI, "2", "Test", start_time=now + timedelta(hours=12))
        strategy = DateMatch()
        score = strategy.score(a, b)
        assert 0.5 < score < 1.0

    def test_outside_tolerance(self):
        now = datetime.now(UTC)
        a = _make_event(Platform.POLYMARKET, "1", "Test", start_time=now)
        b = _make_event(Platform.KALSHI, "2", "Test", start_time=now + timedelta(days=3))
        strategy = DateMatch()
        assert strategy.score(a, b) == 0.0

    def test_missing_time(self):
        a = _make_event(Platform.POLYMARKET, "1", "Test")
        b = _make_event(Platform.KALSHI, "2", "Test")
        strategy = DateMatch()
        assert strategy.score(a, b) == 0.0


class TestTeamMatch:
    def test_matching_teams_from_metadata(self):
        a = _make_event(
            Platform.POLYMARKET,
            "1",
            "Game",
            metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
        )
        b = _make_event(
            Platform.KALSHI,
            "2",
            "比賽",
            metadata=EventMetadata(home_team="湖人", away_team="塞爾提克"),
        )
        strategy = TeamMatch()
        assert strategy.score(a, b) == 1.0

    def test_one_team_matches(self):
        a = _make_event(
            Platform.POLYMARKET,
            "1",
            "Game",
            metadata=EventMetadata(home_team="Lakers", away_team="Warriors"),
        )
        b = _make_event(
            Platform.KALSHI,
            "2",
            "比賽",
            metadata=EventMetadata(home_team="湖人", away_team="火箭"),
        )
        strategy = TeamMatch()
        score = strategy.score(a, b)
        assert 0.0 < score < 1.0

    def test_no_teams_match(self):
        a = _make_event(
            Platform.POLYMARKET,
            "1",
            "Game",
            metadata=EventMetadata(home_team="Lakers", away_team="Warriors"),
        )
        b = _make_event(
            Platform.KALSHI,
            "2",
            "比賽",
            metadata=EventMetadata(home_team="火箭", away_team="公牛"),
        )
        strategy = TeamMatch()
        assert strategy.score(a, b) == 0.0

    def test_teams_from_title_parsing(self):
        a = _make_event(Platform.POLYMARKET, "1", "Celtics @ Lakers")
        b = _make_event(Platform.KALSHI, "2", "Lakers vs Celtics")
        strategy = TeamMatch()
        assert strategy.score(a, b) == 1.0


class TestTitleSimilarity:
    def test_identical_titles(self):
        a = _make_event(Platform.POLYMARKET, "1", "Will Biden win?", category=Sport.POLITICS)
        b = _make_event(Platform.KALSHI, "2", "Will Biden win?", category=Sport.POLITICS)
        strategy = TitleSimilarity()
        assert strategy.score(a, b) == 1.0

    def test_similar_titles(self):
        a = _make_event(Platform.POLYMARKET, "1", "Will Biden win the 2026 election?", category=Sport.POLITICS)
        b = _make_event(Platform.KALSHI, "2", "Biden wins 2026 election", category=Sport.POLITICS)
        strategy = TitleSimilarity()
        score = strategy.score(a, b)
        assert score > 0.0

    def test_dissimilar_titles(self):
        a = _make_event(Platform.POLYMARKET, "1", "Will Bitcoin reach 100k?", category=Sport.CRYPTO)
        b = _make_event(Platform.KALSHI, "2", "Lakers NBA Championship", category=Sport.CRYPTO)
        strategy = TitleSimilarity()
        assert strategy.score(a, b) == 0.0


class TestEventMatcher:
    def test_match_sports_events_cross_platform(self):
        now = datetime.now(UTC)
        events = [
            _make_event(
                Platform.POLYMARKET,
                "p1",
                "Lakers vs Celtics",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.KALSHI,
                "t1",
                "Celtics @ Lakers",
                start_time=now + timedelta(hours=1),
                metadata=EventMetadata(home_team="湖人", away_team="塞爾提克"),
            ),
        ]
        matcher = EventMatcher()
        mappings = matcher.find_matches(events)
        assert len(mappings) == 1
        assert mappings[0].match_confidence > 0.5
        assert len(mappings[0].entries) == 2

    def test_no_match_same_platform(self):
        now = datetime.now(UTC)
        events = [
            _make_event(
                Platform.POLYMARKET,
                "p1",
                "Game 1",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.POLYMARKET,
                "p2",
                "Game 1",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
        ]
        matcher = EventMatcher()
        mappings = matcher.find_matches(events)
        assert len(mappings) == 0

    def test_no_match_different_categories(self):
        now = datetime.now(UTC)
        events = [
            _make_event(
                Platform.POLYMARKET,
                "p1",
                "Lakers game",
                category=Sport.NBA,
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.KALSHI,
                "k1",
                "Lakers game",
                category=Sport.MLB,
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
        ]
        matcher = EventMatcher()
        mappings = matcher.find_matches(events)
        # Different categories → separate groups → no cross-match
        assert len(mappings) == 0

    def test_two_platform_grouping(self):
        """2 platforms with same event should produce 1 mapping with 2 entries.

        A third event from a different sport category should not be grouped.
        """
        now = datetime.now(UTC)
        events = [
            _make_event(
                Platform.POLYMARKET,
                "p1",
                "Lakers vs Celtics",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.KALSHI,
                "k1",
                "Celtics @ Lakers",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.POLYMARKET,
                "p2",
                "Warriors vs Bulls",
                start_time=now + timedelta(days=3),  # far enough to not match by date
                category=Sport.MLB,  # different category
                metadata=EventMetadata(home_team="Warriors", away_team="Bulls"),
            ),
        ]
        matcher = EventMatcher()
        mappings = matcher.find_matches(events)
        assert len(mappings) == 1
        assert len(mappings[0].entries) == 2

    def test_chain_merge_grouping(self):
        """Events that form a chain (A-B, B-C) should merge into one group.

        Since we only have 2 Platform enum values, we simulate this by
        having 2 events from POLYMARKET and 1 from KALSHI where both
        POLYMARKET events match the KALSHI event (same teams).
        The two POLYMARKET events won't match each other (same platform),
        but both match KALSHI, so all 3 end up in one group via union-find.
        """
        now = datetime.now(UTC)
        events = [
            _make_event(
                Platform.POLYMARKET,
                "p1",
                "Lakers vs Celtics",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.POLYMARKET,
                "p2",
                "Lakers vs Celtics duplicate",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.KALSHI,
                "k1",
                "Celtics @ Lakers",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
        ]
        matcher = EventMatcher()
        mappings = matcher.find_matches(events)
        # p1-k1 match, p2-k1 match → union-find merges into 1 group with 3 entries
        assert len(mappings) == 1
        assert len(mappings[0].entries) == 3
        platforms = {e.platform for e in mappings[0].entries}
        assert Platform.POLYMARKET in platforms
        assert Platform.KALSHI in platforms

    def test_group_confidence_is_minimum(self):
        """Group match_confidence should be the minimum of all pairwise confidences."""
        now = datetime.now(UTC)
        # Two POLYMARKET events match one KALSHI event with potentially different scores
        events = [
            _make_event(
                Platform.POLYMARKET,
                "p1",
                "Lakers vs Celtics",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.POLYMARKET,
                "p2",
                "Lakers vs Celtics",
                start_time=now + timedelta(hours=12),  # slightly different time → lower score
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
            _make_event(
                Platform.KALSHI,
                "k1",
                "Celtics @ Lakers",
                start_time=now,
                metadata=EventMetadata(home_team="Lakers", away_team="Celtics"),
            ),
        ]
        matcher = EventMatcher()
        mappings = matcher.find_matches(events)
        assert len(mappings) == 1
        # The confidence should be the minimum of the two pairwise scores
        # (p1-k1 should have higher confidence than p2-k1 due to time difference)
        assert mappings[0].match_confidence > 0.5

    def test_match_politics_by_title(self):
        events = [
            _make_event(
                Platform.POLYMARKET,
                "p1",
                "Will Biden win the 2026 election?",
                category=Sport.POLITICS,
            ),
            _make_event(
                Platform.KALSHI,
                "k1",
                "Biden wins 2026 election",
                category=Sport.POLITICS,
            ),
        ]
        matcher = EventMatcher(min_confidence=0.5)
        mappings = matcher.find_matches(events)
        assert len(mappings) == 1
        assert mappings[0].match_method == "title_similarity"
