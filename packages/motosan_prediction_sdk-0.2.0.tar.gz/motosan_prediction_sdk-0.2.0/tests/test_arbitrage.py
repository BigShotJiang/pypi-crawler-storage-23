from decimal import Decimal

from prediction_sdk.arbitrage.detector import ArbitrageDetector
from prediction_sdk.models.common import MarketType, Platform
from prediction_sdk.models.mapping import EventMapping, MappingEntry
from prediction_sdk.models.market import Outcome, UnifiedMarket


def _make_market(
    platform: Platform,
    market_id: str,
    event_id: str,
    outcomes: list[Outcome],
) -> UnifiedMarket:
    return UnifiedMarket(
        platform=platform,
        platform_market_id=market_id,
        event_id=event_id,
        market_type=MarketType.MONEYLINE,
        question="test",
        outcomes=outcomes,
    )


class TestArbitrageDetector:
    def test_detects_arb_opportunity(self):
        """Example from plan:
        - JBot: Lakers ML 2.50 (40%), Celtics ML 1.60 (62.5%) → total 102.5%
        - Polymarket: Lakers $0.35 (35%), Celtics $0.67 (67%) → total 102%
        - Best: Lakers 35% (Poly) + Celtics 62.5% (JBot) = 97.5% → 2.5% margin
        """
        jbot_market = _make_market(
            Platform.KALSHI,
            "jbot-m1",
            "jbot-e1",
            outcomes=[
                Outcome(
                    name="lakers",
                    implied_probability=Decimal("0.40"),
                    decimal_odds=Decimal("2.50"),
                    raw_odds="2.50",
                ),
                Outcome(
                    name="celtics",
                    implied_probability=Decimal("0.625"),
                    decimal_odds=Decimal("1.60"),
                    raw_odds="1.60",
                ),
            ],
        )
        poly_market = _make_market(
            Platform.POLYMARKET,
            "poly-m1",
            "poly-e1",
            outcomes=[
                Outcome(
                    name="lakers",
                    implied_probability=Decimal("0.35"),
                    decimal_odds=Decimal("2.857"),
                    price=Decimal("0.35"),
                    raw_odds="0.35",
                ),
                Outcome(
                    name="celtics",
                    implied_probability=Decimal("0.67"),
                    decimal_odds=Decimal("1.493"),
                    price=Decimal("0.67"),
                    raw_odds="0.67",
                ),
            ],
        )

        mapping = EventMapping(
            canonical_title="Lakers vs Celtics",
            entries=[
                MappingEntry(
                    platform=Platform.KALSHI,
                    event=None,
                    market=jbot_market,
                    outcome_mapping={},
                ),
                MappingEntry(
                    platform=Platform.POLYMARKET,
                    event=None,
                    market=poly_market,
                    outcome_mapping={},
                ),
            ],
        )

        detector = ArbitrageDetector()
        opp = detector.detect(mapping)

        assert opp is not None
        assert opp.profit_margin > Decimal("0")
        assert opp.total_implied_prob < Decimal("1.0")
        assert len(opp.legs) == 2
        # Best Lakers is Polymarket (0.35), best Celtics is JBot (0.625)
        for leg in opp.legs:
            if leg.outcome == "lakers":
                assert leg.platform == Platform.POLYMARKET
                assert leg.implied_probability == Decimal("0.35")
            elif leg.outcome == "celtics":
                assert leg.platform == Platform.KALSHI
                assert leg.implied_probability == Decimal("0.625")

        # Total = 0.35 + 0.625 = 0.975 → margin = 0.025
        assert opp.total_implied_prob == Decimal("0.975")
        assert opp.profit_margin == Decimal("0.025")

    def test_no_arb_when_overround(self):
        """When total implied prob > 1.0, no arbitrage exists."""
        market_a = _make_market(
            Platform.POLYMARKET,
            "m1",
            "e1",
            outcomes=[
                Outcome(
                    name="yes",
                    implied_probability=Decimal("0.60"),
                    decimal_odds=Decimal("1.667"),
                    raw_odds="0.60",
                ),
                Outcome(
                    name="no",
                    implied_probability=Decimal("0.45"),
                    decimal_odds=Decimal("2.222"),
                    raw_odds="0.45",
                ),
            ],
        )
        market_b = _make_market(
            Platform.KALSHI,
            "m2",
            "e2",
            outcomes=[
                Outcome(name="yes", implied_probability=Decimal("0.58"), decimal_odds=Decimal("1.724"), raw_odds="58"),
                Outcome(name="no", implied_probability=Decimal("0.44"), decimal_odds=Decimal("2.273"), raw_odds="44"),
            ],
        )

        mapping = EventMapping(
            canonical_title="Test",
            entries=[
                MappingEntry(platform=Platform.POLYMARKET, event=None, market=market_a, outcome_mapping={}),
                MappingEntry(platform=Platform.KALSHI, event=None, market=market_b, outcome_mapping={}),
            ],
        )

        detector = ArbitrageDetector()
        opp = detector.detect(mapping)
        assert opp is None

    def test_arb_with_markets_dict(self):
        """Test using the markets dict parameter instead of inline markets."""
        market_a = _make_market(
            Platform.POLYMARKET,
            "m1",
            "e1",
            outcomes=[
                Outcome(
                    name="yes",
                    implied_probability=Decimal("0.30"),
                    decimal_odds=Decimal("3.333"),
                    raw_odds="0.30",
                ),
                Outcome(
                    name="no",
                    implied_probability=Decimal("0.72"),
                    decimal_odds=Decimal("1.389"),
                    raw_odds="0.72",
                ),
            ],
        )
        market_b = _make_market(
            Platform.KALSHI,
            "m2",
            "e2",
            outcomes=[
                Outcome(
                    name="yes",
                    implied_probability=Decimal("0.35"),
                    decimal_odds=Decimal("2.857"),
                    raw_odds="35",
                ),
                Outcome(
                    name="no",
                    implied_probability=Decimal("0.60"),
                    decimal_odds=Decimal("1.667"),
                    raw_odds="60",
                ),
            ],
        )

        from prediction_sdk.models.common import Sport
        from prediction_sdk.models.event import UnifiedEvent

        event_a = UnifiedEvent(
            platform=Platform.POLYMARKET,
            platform_event_id="e1",
            title="Test",
            title_original="Test",
            category=Sport.OTHER,
        )
        event_b = UnifiedEvent(
            platform=Platform.KALSHI,
            platform_event_id="e2",
            title="Test",
            title_original="Test",
            category=Sport.OTHER,
        )

        mapping = EventMapping(
            canonical_title="Test",
            entries=[
                MappingEntry(platform=Platform.POLYMARKET, event=event_a, market=None, outcome_mapping={}),
                MappingEntry(platform=Platform.KALSHI, event=event_b, market=None, outcome_mapping={}),
            ],
        )

        detector = ArbitrageDetector()
        opp = detector.detect(mapping, markets={"e1": [market_a], "e2": [market_b]})

        assert opp is not None
        # Best yes = 0.30 (Poly), Best no = 0.60 (Kalshi) → total = 0.90 → margin = 0.10
        assert opp.total_implied_prob == Decimal("0.90")
        assert opp.profit_margin == Decimal("0.10")

    def test_stake_fractions_sum_to_one(self):
        """Verify that stake fractions computed sum to 1.0."""
        market_a = _make_market(
            Platform.POLYMARKET,
            "m1",
            "e1",
            outcomes=[
                Outcome(
                    name="yes",
                    implied_probability=Decimal("0.30"),
                    decimal_odds=Decimal("3.333"),
                    raw_odds="0.30",
                ),
                Outcome(
                    name="no",
                    implied_probability=Decimal("0.80"),
                    decimal_odds=Decimal("1.25"),
                    raw_odds="0.80",
                ),
            ],
        )
        market_b = _make_market(
            Platform.KALSHI,
            "m2",
            "e2",
            outcomes=[
                Outcome(
                    name="yes",
                    implied_probability=Decimal("0.40"),
                    decimal_odds=Decimal("2.50"),
                    raw_odds="40",
                ),
                Outcome(
                    name="no",
                    implied_probability=Decimal("0.55"),
                    decimal_odds=Decimal("1.818"),
                    raw_odds="55",
                ),
            ],
        )

        mapping = EventMapping(
            canonical_title="Test",
            entries=[
                MappingEntry(platform=Platform.POLYMARKET, event=None, market=market_a, outcome_mapping={}),
                MappingEntry(platform=Platform.KALSHI, event=None, market=market_b, outcome_mapping={}),
            ],
        )

        detector = ArbitrageDetector()
        opp = detector.detect(mapping)

        assert opp is not None
        total_stake = sum(leg.stake_fraction for leg in opp.legs)
        assert abs(total_stake - Decimal("1")) < Decimal("0.01")

    def test_min_profit_margin_filters_low_margin(self):
        """Detector with min_profit_margin=0.05 filters out a 2.5% margin opportunity."""
        jbot_market = _make_market(
            Platform.KALSHI,
            "jbot-m1",
            "jbot-e1",
            outcomes=[
                Outcome(
                    name="lakers",
                    implied_probability=Decimal("0.40"),
                    decimal_odds=Decimal("2.50"),
                    raw_odds="2.50",
                ),
                Outcome(
                    name="celtics",
                    implied_probability=Decimal("0.625"),
                    decimal_odds=Decimal("1.60"),
                    raw_odds="1.60",
                ),
            ],
        )
        poly_market = _make_market(
            Platform.POLYMARKET,
            "poly-m1",
            "poly-e1",
            outcomes=[
                Outcome(
                    name="lakers",
                    implied_probability=Decimal("0.35"),
                    decimal_odds=Decimal("2.857"),
                    price=Decimal("0.35"),
                    raw_odds="0.35",
                ),
                Outcome(
                    name="celtics",
                    implied_probability=Decimal("0.67"),
                    decimal_odds=Decimal("1.493"),
                    price=Decimal("0.67"),
                    raw_odds="0.67",
                ),
            ],
        )

        mapping = EventMapping(
            canonical_title="Lakers vs Celtics",
            entries=[
                MappingEntry(platform=Platform.KALSHI, event=None, market=jbot_market, outcome_mapping={}),
                MappingEntry(platform=Platform.POLYMARKET, event=None, market=poly_market, outcome_mapping={}),
            ],
        )

        # Opportunity has 2.5% margin; min_profit_margin=5% should filter it out
        detector = ArbitrageDetector(min_profit_margin=Decimal("0.05"))
        opp = detector.detect(mapping)
        assert opp is None

    def test_max_legs_passes_when_within_limit(self):
        """Detector with max_legs=2 passes a 2-leg opportunity."""
        market_a = _make_market(
            Platform.POLYMARKET,
            "m1",
            "e1",
            outcomes=[
                Outcome(
                    name="yes",
                    implied_probability=Decimal("0.30"),
                    decimal_odds=Decimal("3.333"),
                    raw_odds="0.30",
                ),
                Outcome(
                    name="no",
                    implied_probability=Decimal("0.72"),
                    decimal_odds=Decimal("1.389"),
                    raw_odds="0.72",
                ),
            ],
        )
        market_b = _make_market(
            Platform.KALSHI,
            "m2",
            "e2",
            outcomes=[
                Outcome(name="yes", implied_probability=Decimal("0.35"), decimal_odds=Decimal("2.857"), raw_odds="35"),
                Outcome(name="no", implied_probability=Decimal("0.60"), decimal_odds=Decimal("1.667"), raw_odds="60"),
            ],
        )

        mapping = EventMapping(
            canonical_title="Test",
            entries=[
                MappingEntry(platform=Platform.POLYMARKET, event=None, market=market_a, outcome_mapping={}),
                MappingEntry(platform=Platform.KALSHI, event=None, market=market_b, outcome_mapping={}),
            ],
        )

        detector = ArbitrageDetector(max_legs=2)
        opp = detector.detect(mapping)
        assert opp is not None
        assert len(opp.legs) == 2

    def test_max_legs_filters_when_exceeded(self):
        """Detector with max_legs=1 filters out a 2-leg opportunity."""
        market_a = _make_market(
            Platform.POLYMARKET,
            "m1",
            "e1",
            outcomes=[
                Outcome(
                    name="yes",
                    implied_probability=Decimal("0.30"),
                    decimal_odds=Decimal("3.333"),
                    raw_odds="0.30",
                ),
                Outcome(
                    name="no",
                    implied_probability=Decimal("0.72"),
                    decimal_odds=Decimal("1.389"),
                    raw_odds="0.72",
                ),
            ],
        )
        market_b = _make_market(
            Platform.KALSHI,
            "m2",
            "e2",
            outcomes=[
                Outcome(name="yes", implied_probability=Decimal("0.35"), decimal_odds=Decimal("2.857"), raw_odds="35"),
                Outcome(name="no", implied_probability=Decimal("0.60"), decimal_odds=Decimal("1.667"), raw_odds="60"),
            ],
        )

        mapping = EventMapping(
            canonical_title="Test",
            entries=[
                MappingEntry(platform=Platform.POLYMARKET, event=None, market=market_a, outcome_mapping={}),
                MappingEntry(platform=Platform.KALSHI, event=None, market=market_b, outcome_mapping={}),
            ],
        )

        detector = ArbitrageDetector(max_legs=1)
        opp = detector.detect(mapping)
        assert opp is None
