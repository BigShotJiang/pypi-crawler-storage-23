# CLAUDE.md

## Project Overview
Cross-platform prediction market SDK for comparing odds across Polymarket and Kalshi.

## Tech Stack
- Python 3.12+, async/await with httpx
- Pydantic 2.0 for API responses, dataclasses for internal models
- Decimal for all financial calculations (never float)
- Package manager: uv

## Quick Commands
- Install: `uv sync`
- Test: `uv run pytest tests/ -v`
- Lint: `uv run ruff check .`
- Format: `uv run ruff format .`
- Run CLI: `uv run arb-scan --sport nba --platforms polymarket,kalshi`

## Project Structure
```
prediction_sdk/
├── models/         # Unified data models (common.py, event.py, market.py, opportunity.py, mapping.py)
├── clients/        # Platform clients (polymarket/, kalshi/)
│   └── base.py     # PredictionClient ABC — all clients implement this
├── matching/       # Cross-platform event matching (strategy pattern, team aliases)
├── arbitrage/      # Arbitrage detection, odds conversion, daily scanner
├── utils/          # Config loading
└── cli.py          # CLI entry point
```

## Key Conventions
- All clients implement `PredictionClient` ABC from `clients/base.py`
- Each client has: `client.py`, `models.py`, `normalize.py`
- Use `Decimal` for money/odds — never `float`
- Timestamps always UTC via `datetime.UTC`
- Enums inherit from `(str, Enum)`
- Async tests use `pytest-asyncio` with `asyncio_mode = "auto"`
- HTTP mocking uses `respx`
- Integration tests marked with `@pytest.mark.integration`
## Environment
- Copy `.env.example` to `.env`
- Polymarket requires no authentication
- Kalshi API URL is configurable via `KALSHI_API_URL`

## Code Style
- Ruff with: E, F, I, N, W, UP rules
- Line length: 120
- Target: Python 3.12

## Adding a New Platform Client
1. Create `prediction_sdk/clients/<name>/` with `client.py`, `models.py`, `normalize.py`
2. Implement `PredictionClient` ABC
3. Add normalization to unified `UnifiedEvent`/`UnifiedMarket` models
4. Add matching strategy in `matching/strategies.py` if needed
5. Add tests in `tests/clients/`
