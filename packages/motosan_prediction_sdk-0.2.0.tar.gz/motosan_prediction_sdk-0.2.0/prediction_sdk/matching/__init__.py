"""Event matching module."""
