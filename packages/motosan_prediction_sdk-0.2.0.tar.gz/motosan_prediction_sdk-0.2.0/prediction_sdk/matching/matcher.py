from __future__ import annotations

from itertools import combinations

from prediction_sdk.models.common import Sport
from prediction_sdk.models.event import UnifiedEvent
from prediction_sdk.models.mapping import EventMapping, MappingEntry

from .strategies import DateMatch, MatchStrategy, TeamMatch, TitleSimilarity

# Sports categories that use team-based matching
_SPORTS_CATEGORIES = {Sport.NBA, Sport.MLB, Sport.NFL, Sport.SOCCER}


class EventMatcher:
    """Orchestrates cross-platform event matching using layered strategies."""

    def __init__(
        self,
        strategies: list[MatchStrategy] | None = None,
        min_confidence: float = 0.5,
    ) -> None:
        if strategies is None:
            strategies = [DateMatch(), TeamMatch(), TitleSimilarity()]
        self._strategies = strategies
        self._min_confidence = min_confidence

    def find_matches(self, events: list[UnifiedEvent]) -> list[EventMapping]:
        """Find matching events across platforms.

        Groups events by category, then compares all cross-platform pairs
        using the configured strategies.
        """
        # Group by category
        by_category: dict[Sport, list[UnifiedEvent]] = {}
        for event in events:
            by_category.setdefault(event.category, []).append(event)

        mappings: list[EventMapping] = []
        for category, category_events in by_category.items():
            matches = self._match_within_category(category, category_events)
            mappings.extend(matches)

        # Sort by confidence descending
        mappings.sort(key=lambda m: m.match_confidence, reverse=True)
        return mappings

    def _match_within_category(self, category: Sport, events: list[UnifiedEvent]) -> list[EventMapping]:
        # Step 1: Find all pairwise matches (existing logic)
        pairwise_matches: list[tuple[UnifiedEvent, UnifiedEvent, float, str]] = []
        for a, b in combinations(events, 2):
            if a.platform == b.platform:
                continue
            confidence, method = self._compute_match(category, a, b)
            if confidence >= self._min_confidence:
                pairwise_matches.append((a, b, confidence, method))

        # Step 2: Union-find to group matched events
        parent: dict[int, int] = {}

        def find(x: int) -> int:
            while parent.get(x, x) != x:
                parent[x] = parent.get(parent[x], parent[x])
                x = parent[x]
            return x

        def union(x: int, y: int) -> None:
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py

        for a, b, _, _ in pairwise_matches:
            union(id(a), id(b))

        # Step 3: Group events by their root
        groups: dict[int, dict] = {}
        event_by_id: dict[int, UnifiedEvent] = {}
        for a, b, conf, method in pairwise_matches:
            event_by_id[id(a)] = a
            event_by_id[id(b)] = b
            root = find(id(a))
            if root not in groups:
                groups[root] = {"events": set(), "min_conf": conf, "methods": []}
            groups[root]["events"].add(id(a))
            groups[root]["events"].add(id(b))
            groups[root]["min_conf"] = min(groups[root]["min_conf"], conf)
            groups[root]["methods"].append(method)

        # Step 4: Build EventMappings — one per group
        mappings: list[EventMapping] = []
        for group in groups.values():
            events_in_group = [event_by_id[eid] for eid in group["events"]]
            canonical = _canonical_title(*events_in_group)
            methods: list[str] = group["methods"]
            if "rule_based" in methods:
                match_method = "rule_based"
            else:
                match_method = max(set(methods), key=methods.count)
            mapping = EventMapping(
                canonical_title=canonical,
                entries=[
                    MappingEntry(platform=e.platform, event=e, market=None, outcome_mapping={}) for e in events_in_group
                ],
                match_confidence=group["min_conf"],
                match_method=match_method,
            )
            mappings.append(mapping)

        return mappings

    def _compute_match(self, category: Sport, a: UnifiedEvent, b: UnifiedEvent) -> tuple[float, str]:
        """Compute the best match score across strategies."""
        best_score = 0.0
        best_method = ""

        is_sports = category in _SPORTS_CATEGORIES

        for strategy in self._strategies:
            # For sports events, prioritize team+date matching
            # For non-sports, use title similarity
            if is_sports and isinstance(strategy, TitleSimilarity):
                continue
            if not is_sports and isinstance(strategy, (TeamMatch, DateMatch)):
                continue

            score = strategy.score(a, b)
            if score > best_score:
                best_score = score
                best_method = strategy.name

        # For sports: combine date + team scores
        if is_sports:
            date_score = 0.0
            team_score = 0.0
            for s in self._strategies:
                if isinstance(s, DateMatch):
                    date_score = s.score(a, b)
                elif isinstance(s, TeamMatch):
                    team_score = s.score(a, b)

            if team_score > 0 and date_score > 0:
                combined = team_score * 0.6 + date_score * 0.4
                if combined > best_score:
                    best_score = combined
                    best_method = "rule_based"

        return best_score, best_method


def _canonical_title(*events: UnifiedEvent) -> str:
    """Pick the best canonical title from a group of matched events.

    Prefers English (non-CJK) titles.
    """
    for event in events:
        if all(ord(c) < 0x3000 for c in event.title):
            return event.title
    return events[0].title
