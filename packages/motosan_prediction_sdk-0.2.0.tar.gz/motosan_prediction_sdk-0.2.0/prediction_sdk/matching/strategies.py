from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import timedelta

from rapidfuzz import fuzz

from prediction_sdk.models.event import UnifiedEvent

from .team_aliases import teams_match


class MatchStrategy(ABC):
    @abstractmethod
    def score(self, event_a: UnifiedEvent, event_b: UnifiedEvent) -> float:
        """Return a match confidence score between 0.0 and 1.0."""
        ...

    @property
    @abstractmethod
    def name(self) -> str: ...


class DateMatch(MatchStrategy):
    """Match events whose start times are within a tolerance window."""

    def __init__(self, tolerance: timedelta = timedelta(days=1)) -> None:
        self._tolerance = tolerance

    @property
    def name(self) -> str:
        return "date_match"

    def score(self, event_a: UnifiedEvent, event_b: UnifiedEvent) -> float:
        if event_a.start_time is None or event_b.start_time is None:
            return 0.0
        delta = abs(event_a.start_time - event_b.start_time)
        if delta <= self._tolerance:
            # Score inversely proportional to delta, 1.0 at 0, ~0.5 at tolerance
            ratio = delta / self._tolerance
            return max(0.0, 1.0 - ratio * 0.5)
        return 0.0


class TeamMatch(MatchStrategy):
    """Match sports events by comparing team names from metadata."""

    @property
    def name(self) -> str:
        return "team_match"

    def score(self, event_a: UnifiedEvent, event_b: UnifiedEvent) -> float:
        teams_a = self._extract_teams(event_a)
        teams_b = self._extract_teams(event_b)
        if not teams_a or not teams_b:
            return 0.0

        matched = 0
        for ta in teams_a:
            for tb in teams_b:
                if teams_match(ta, tb):
                    matched += 1
                    break

        if matched == 0:
            return 0.0
        # 2 teams matched = 1.0, 1 team matched = 0.5
        return min(1.0, matched / max(len(teams_a), len(teams_b)))

    def _extract_teams(self, event: UnifiedEvent) -> list[str]:
        teams: list[str] = []
        home = event.metadata.home_team
        away = event.metadata.away_team
        if home:
            teams.append(home)
        if away:
            teams.append(away)
        if not teams:
            # Try parsing from title "TeamA @ TeamB" or "TeamA vs TeamB"
            title = event.title
            for sep in [" @ ", " vs ", " vs. ", " v "]:
                if sep in title:
                    parts = title.split(sep, 1)
                    teams = [p.strip() for p in parts]
                    break
        return teams


class TitleSimilarity(MatchStrategy):
    """Match events by fuzzy title comparison using rapidfuzz."""

    def __init__(self, threshold: float = 0.80) -> None:
        self._threshold = threshold

    @property
    def name(self) -> str:
        return "title_similarity"

    def score(self, event_a: UnifiedEvent, event_b: UnifiedEvent) -> float:
        ratio = fuzz.token_sort_ratio(event_a.title.lower(), event_b.title.lower()) / 100.0
        if ratio >= self._threshold:
            return ratio
        return 0.0
