from __future__ import annotations

TEAM_ALIASES: dict[str, dict[str, list[str]]] = {
    # NBA Teams
    "lakers": {
        "en": ["los angeles lakers", "lakers", "la lakers"],
        "zh": ["湖人", "洛杉磯湖人"],
        "abbr": ["LAL"],
    },
    "celtics": {
        "en": ["boston celtics", "celtics"],
        "zh": ["塞爾提克", "波士頓塞爾提克"],
        "abbr": ["BOS"],
    },
    "warriors": {
        "en": ["golden state warriors", "warriors", "gs warriors"],
        "zh": ["勇士", "金州勇士"],
        "abbr": ["GSW", "GS"],
    },
    "nets": {
        "en": ["brooklyn nets", "nets"],
        "zh": ["籃網", "布魯克林籃網"],
        "abbr": ["BKN"],
    },
    "knicks": {
        "en": ["new york knicks", "knicks", "ny knicks"],
        "zh": ["乃克", "紐約乃克"],
        "abbr": ["NYK"],
    },
    "76ers": {
        "en": ["philadelphia 76ers", "76ers", "sixers"],
        "zh": ["乃隊", "費城乃隊"],
        "abbr": ["PHI"],
    },
    "bucks": {
        "en": ["milwaukee bucks", "bucks"],
        "zh": ["公鹿", "密爾瓦基公鹿"],
        "abbr": ["MIL"],
    },
    "heat": {
        "en": ["miami heat", "heat"],
        "zh": ["熱火", "邁阿密熱火"],
        "abbr": ["MIA"],
    },
    "suns": {
        "en": ["phoenix suns", "suns"],
        "zh": ["太陽", "鳳凰城太陽"],
        "abbr": ["PHX"],
    },
    "nuggets": {
        "en": ["denver nuggets", "nuggets"],
        "zh": ["金塊", "丹佛金塊"],
        "abbr": ["DEN"],
    },
    "mavericks": {
        "en": ["dallas mavericks", "mavericks", "mavs"],
        "zh": ["獨行俠", "達拉斯獨行俠"],
        "abbr": ["DAL"],
    },
    "thunder": {
        "en": ["oklahoma city thunder", "thunder", "okc thunder"],
        "zh": ["雷霆", "奧克拉荷馬雷霆"],
        "abbr": ["OKC"],
    },
    "timberwolves": {
        "en": ["minnesota timberwolves", "timberwolves", "wolves"],
        "zh": ["灰狼", "乃乃灰狼"],
        "abbr": ["MIN"],
    },
    "clippers": {
        "en": ["los angeles clippers", "clippers", "la clippers"],
        "zh": ["快艇", "洛杉磯快艇"],
        "abbr": ["LAC"],
    },
    "cavaliers": {
        "en": ["cleveland cavaliers", "cavaliers", "cavs"],
        "zh": ["騎士", "克里夫蘭騎士"],
        "abbr": ["CLE"],
    },
    "hawks": {
        "en": ["atlanta hawks", "hawks"],
        "zh": ["老鷹", "亞特蘭大老鷹"],
        "abbr": ["ATL"],
    },
    "bulls": {
        "en": ["chicago bulls", "bulls"],
        "zh": ["公牛", "芝加哥公牛"],
        "abbr": ["CHI"],
    },
    "raptors": {
        "en": ["toronto raptors", "raptors"],
        "zh": ["暴龍", "多倫多暴龍"],
        "abbr": ["TOR"],
    },
    "spurs": {
        "en": ["san antonio spurs", "spurs"],
        "zh": ["馬刺", "聖安東尼奧馬刺"],
        "abbr": ["SAS", "SA"],
    },
    "rockets": {
        "en": ["houston rockets", "rockets"],
        "zh": ["火箭", "休士頓火箭"],
        "abbr": ["HOU"],
    },
    "grizzlies": {
        "en": ["memphis grizzlies", "grizzlies"],
        "zh": ["灰熊", "孟菲斯灰熊"],
        "abbr": ["MEM"],
    },
    "pelicans": {
        "en": ["new orleans pelicans", "pelicans"],
        "zh": ["鵜鶘", "紐奧良鵜鶘"],
        "abbr": ["NOP", "NO"],
    },
    "kings": {
        "en": ["sacramento kings", "kings"],
        "zh": ["國王", "沙加緬度國王"],
        "abbr": ["SAC"],
    },
    "pacers": {
        "en": ["indiana pacers", "pacers"],
        "zh": ["乃隊", "印第安納乃隊"],
        "abbr": ["IND"],
    },
    "wizards": {
        "en": ["washington wizards", "wizards"],
        "zh": ["巫師", "華盛頓巫師"],
        "abbr": ["WAS"],
    },
    "magic": {
        "en": ["orlando magic", "magic"],
        "zh": ["魔術", "奧蘭多魔術"],
        "abbr": ["ORL"],
    },
    "pistons": {
        "en": ["detroit pistons", "pistons"],
        "zh": ["活塞", "底特律活塞"],
        "abbr": ["DET"],
    },
    "hornets": {
        "en": ["charlotte hornets", "hornets"],
        "zh": ["黃蜂", "夏洛特黃蜂"],
        "abbr": ["CHA"],
    },
    "trail blazers": {
        "en": ["portland trail blazers", "trail blazers", "blazers"],
        "zh": ["拓荒者", "波特蘭拓荒者"],
        "abbr": ["POR"],
    },
    "jazz": {
        "en": ["utah jazz", "jazz"],
        "zh": ["爵士", "猶他爵士"],
        "abbr": ["UTA"],
    },
    # MLB Teams (subset)
    "yankees": {
        "en": ["new york yankees", "yankees", "ny yankees"],
        "zh": ["洋基", "紐約洋基"],
        "abbr": ["NYY"],
    },
    "dodgers": {
        "en": ["los angeles dodgers", "dodgers", "la dodgers"],
        "zh": ["道奇", "洛杉磯道奇"],
        "abbr": ["LAD"],
    },
    "red sox": {
        "en": ["boston red sox", "red sox"],
        "zh": ["紅襪", "波士頓紅襪"],
        "abbr": ["BOS-MLB"],
    },
    "astros": {
        "en": ["houston astros", "astros"],
        "zh": ["太空人", "休士頓太空人"],
        "abbr": ["HOU"],
    },
    "braves": {
        "en": ["atlanta braves", "braves"],
        "zh": ["勇士隊", "亞特蘭大勇士"],
        "abbr": ["ATL-MLB"],
    },
    "cubs": {
        "en": ["chicago cubs", "cubs"],
        "zh": ["小熊", "芝加哥小熊"],
        "abbr": ["CHC"],
    },
    "mets": {
        "en": ["new york mets", "mets", "ny mets"],
        "zh": ["大都會", "紐約大都會"],
        "abbr": ["NYM"],
    },
    "phillies": {
        "en": ["philadelphia phillies", "phillies"],
        "zh": ["費城人", "費城費城人"],
        "abbr": ["PHI"],
    },
}


def _build_lookup() -> dict[str, str]:
    """Build a reverse lookup: any alias → canonical key."""
    lookup: dict[str, str] = {}
    for canonical, langs in TEAM_ALIASES.items():
        lookup[canonical.lower()] = canonical
        for lang_aliases in langs.values():
            for alias in lang_aliases:
                lookup[alias.lower()] = canonical
    return lookup


_ALIAS_LOOKUP: dict[str, str] = _build_lookup()


def canonicalize_team(name: str) -> str | None:
    """Return the canonical team key for any alias, or None if not found."""
    return _ALIAS_LOOKUP.get(name.lower().strip())


def teams_match(name_a: str, name_b: str) -> bool:
    """Check if two team names refer to the same team."""
    canon_a = canonicalize_team(name_a)
    canon_b = canonicalize_team(name_b)
    if canon_a is None or canon_b is None:
        return False
    return canon_a == canon_b
