"""CLI entry point for arbitrage scanning."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from prediction_sdk.arbitrage.scanner import ScanResult, scan_arbitrage
from prediction_sdk.models.common import Platform, Sport


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Scan prediction markets for arbitrage opportunities")
    parser.add_argument(
        "--sport",
        choices=[s.value for s in Sport],
        default="nba",
        help="Sport category to scan (default: nba)",
    )
    parser.add_argument(
        "--platforms",
        type=str,
        default=None,
        help="Comma-separated platforms: polymarket,kalshi (default: all)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output as JSON instead of a table",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Max events per platform (default: 50)",
    )
    parser.add_argument(
        "--min-confidence",
        type=float,
        default=0.5,
        help="Match confidence threshold (default: 0.5)",
    )
    return parser.parse_args(argv)


def _parse_platforms(raw: str | None) -> list[Platform] | None:
    if raw is None:
        return None
    names = [n.strip() for n in raw.split(",") if n.strip()]
    platforms = []
    for name in names:
        try:
            platforms.append(Platform(name))
        except ValueError:
            print(f"Unknown platform: {name}", file=sys.stderr)
            sys.exit(1)
    return platforms


def _result_to_dict(result: ScanResult) -> dict:
    opps = []
    for opp in result.opportunities:
        legs = []
        for leg in opp.legs:
            legs.append(
                {
                    "platform": leg.platform.value,
                    "outcome": leg.outcome,
                    "implied_probability": str(leg.implied_probability),
                    "decimal_odds": str(leg.decimal_odds),
                    "stake_fraction": str(leg.stake_fraction),
                }
            )
        opps.append(
            {
                "event": opp.mapping.canonical_title,
                "profit_margin": str(opp.profit_margin),
                "total_implied_prob": str(opp.total_implied_prob),
                "legs": legs,
            }
        )
    return {
        "events_fetched": result.events_fetched,
        "mappings_found": result.mappings_found,
        "platforms_used": [p.value for p in result.platforms_used],
        "opportunities": opps,
    }


def _print_table(result: ScanResult) -> None:
    from rich.console import Console
    from rich.table import Table

    console = Console()

    console.print(
        f"\n[bold]Scan complete:[/bold] {result.events_fetched} events, "
        f"{result.mappings_found} matches, {len(result.opportunities)} opportunities\n"
    )

    if not result.opportunities:
        console.print("[dim]No arbitrage opportunities found.[/dim]")
        return

    for opp in result.opportunities:
        table = Table(title=opp.mapping.canonical_title, show_lines=True)
        table.add_column("Platform", style="cyan")
        table.add_column("Outcome", style="green")
        table.add_column("Implied Prob", justify="right")
        table.add_column("Decimal Odds", justify="right")
        table.add_column("Stake %", justify="right")

        for leg in opp.legs:
            table.add_row(
                leg.platform.value,
                leg.outcome,
                f"{leg.implied_probability:.2%}",
                str(leg.decimal_odds),
                f"{leg.stake_fraction:.2%}",
            )

        table.caption = f"Profit margin: {opp.profit_margin:.2%} | Total implied prob: {opp.total_implied_prob:.4f}"
        console.print(table)
        console.print()


def main(argv: list[str] | None = None) -> None:
    args = _parse_args(argv)

    sport = Sport(args.sport)
    platforms = _parse_platforms(args.platforms)

    result = asyncio.run(
        scan_arbitrage(
            sport=sport,
            platforms=platforms,
            min_confidence=args.min_confidence,
            limit=args.limit,
        )
    )

    if args.json_output:
        print(json.dumps(_result_to_dict(result), indent=2))
    else:
        _print_table(result)


if __name__ == "__main__":
    main()
