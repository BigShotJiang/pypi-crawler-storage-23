from __future__ import annotations

from decimal import Decimal

ZERO = Decimal("0")
ONE = Decimal("1")
HUNDRED = Decimal("100")


def implied_prob_to_decimal(prob: Decimal) -> Decimal:
    if prob <= ZERO or prob > ONE:
        raise ValueError(f"Implied probability must be in (0, 1], got {prob}")
    return ONE / prob


def decimal_to_implied_prob(odds: Decimal) -> Decimal:
    if odds < ONE:
        raise ValueError(f"Decimal odds must be >= 1, got {odds}")
    return ONE / odds


def american_to_implied_prob(american: int) -> Decimal:
    if american > 0:
        return HUNDRED / (Decimal(american) + HUNDRED)
    elif american < 0:
        abs_american = Decimal(abs(american))
        return abs_american / (abs_american + HUNDRED)
    else:
        raise ValueError("American odds cannot be zero")


def implied_prob_to_american(prob: Decimal) -> int:
    if prob <= ZERO or prob >= ONE:
        raise ValueError(f"Implied probability must be in (0, 1), got {prob}")
    if prob >= Decimal("0.5"):
        return -int((prob / (ONE - prob)) * HUNDRED)
    else:
        return int(((ONE - prob) / prob) * HUNDRED)


def decimal_to_american(odds: Decimal) -> int:
    prob = decimal_to_implied_prob(odds)
    return implied_prob_to_american(prob)


def american_to_decimal(american: int) -> Decimal:
    prob = american_to_implied_prob(american)
    return implied_prob_to_decimal(prob)
