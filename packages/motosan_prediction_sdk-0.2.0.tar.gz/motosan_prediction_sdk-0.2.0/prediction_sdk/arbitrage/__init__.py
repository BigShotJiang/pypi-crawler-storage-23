"""Arbitrage detection module."""
