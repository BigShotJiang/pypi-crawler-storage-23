"""End-to-end arbitrage scanner orchestrating clients, matcher, and detector."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

from prediction_sdk.arbitrage.detector import ArbitrageDetector
from prediction_sdk.clients.base import PredictionClient
from prediction_sdk.clients.kalshi.client import KalshiClient
from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.matching.matcher import EventMatcher
from prediction_sdk.models.common import Platform, Sport
from prediction_sdk.models.event import UnifiedEvent
from prediction_sdk.models.opportunity import ArbitrageOpportunity
from prediction_sdk.utils.config import Config

logger = logging.getLogger(__name__)


@dataclass
class ScanResult:
    opportunities: list[ArbitrageOpportunity] = field(default_factory=list)
    events_fetched: int = 0
    mappings_found: int = 0
    platforms_used: list[Platform] = field(default_factory=list)


async def scan_arbitrage(
    sport: Sport = Sport.NBA,
    platforms: list[Platform] | None = None,
    min_confidence: float = 0.5,
    limit: int = 50,
    clients: list[PredictionClient] | None = None,
) -> ScanResult:
    """Run a full arbitrage scan across prediction market platforms.

    Args:
        sport: Sport category to scan.
        platforms: Platforms to include (default: all three).
        min_confidence: Minimum match confidence threshold.
        limit: Max events to fetch per platform.
        clients: Optional pre-created clients to reuse. When provided the
            caller is responsible for their lifecycle and ``scan_arbitrage``
            will **not** close them.  When *None* (the default), clients are
            created internally and closed after the scan (backward compatible).

    Returns:
        ScanResult with any detected arbitrage opportunities.
    """
    owns_clients = clients is None

    if clients is None:
        if platforms is None:
            platforms = list(Platform)

        config = Config.from_env()
        clients = []

        for p in platforms:
            if p == Platform.POLYMARKET:
                clients.append(
                    PolymarketClient(
                        gamma_url=config.polymarket_gamma_url,
                        clob_url=config.polymarket_clob_url,
                    )
                )
            elif p == Platform.KALSHI:
                clients.append(
                    KalshiClient(
                        api_url=config.kalshi_api_url,
                        api_key=config.kalshi_api_key or None,
                    )
                )

    platforms_used = [c.platform() for c in clients]

    try:
        # Fetch events concurrently — tolerate individual platform failures
        raw_event_results = await asyncio.gather(
            *(c.fetch_events(category=sport, limit=limit) for c in clients),
            return_exceptions=True,
        )
        event_lists: list[list[UnifiedEvent]] = []
        for client, result in zip(clients, raw_event_results):
            if isinstance(result, BaseException):
                logger.warning(
                    "Platform %s failed to fetch events: %s",
                    client.platform(),
                    result,
                )
            else:
                event_lists.append(result)
        all_events = [e for sublist in event_lists for e in sublist]
        events_fetched = len(all_events)

        # Match events across platforms
        matcher = EventMatcher(min_confidence=min_confidence)
        mappings = matcher.find_matches(all_events)
        mappings_found = len(mappings)

        # Fetch markets and detect arbitrage for each mapping
        detector = ArbitrageDetector()
        opportunities: list[ArbitrageOpportunity] = []

        for mapping in mappings:
            # Fetch markets for each entry concurrently
            market_tasks = []
            for entry in mapping.entries:
                for c in clients:
                    if c.platform() == entry.platform:
                        eid = entry.event.platform_event_id
                        market_tasks.append((eid, c.fetch_markets(eid)))
                        break

            market_results = await asyncio.gather(
                *(task for _, task in market_tasks),
                return_exceptions=True,
            )
            markets_dict = {}
            for (eid, _), result in zip(market_tasks, market_results):
                if isinstance(result, BaseException):
                    logger.warning(
                        "Failed to fetch markets for event %s: %s",
                        eid,
                        result,
                    )
                else:
                    markets_dict[eid] = result

            opp = detector.detect(mapping, markets=markets_dict)
            if opp is not None:
                opportunities.append(opp)

        # Sort by profit margin descending
        opportunities.sort(key=lambda o: o.profit_margin, reverse=True)

        return ScanResult(
            opportunities=opportunities,
            events_fetched=events_fetched,
            mappings_found=mappings_found,
            platforms_used=platforms_used,
        )
    finally:
        if owns_clients:
            await asyncio.gather(*(c.close() for c in clients), return_exceptions=True)
