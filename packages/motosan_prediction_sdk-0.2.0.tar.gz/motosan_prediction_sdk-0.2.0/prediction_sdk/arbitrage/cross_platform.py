from __future__ import annotations

from decimal import Decimal

from prediction_sdk.models.mapping import EventMapping
from prediction_sdk.models.market import UnifiedMarket
from prediction_sdk.models.opportunity import ArbitrageOpportunity, ArbLeg

ONE = Decimal("1")
ZERO = Decimal("0")


def find_cross_platform_arb(
    mapping: EventMapping,
    markets: dict[str, list[UnifiedMarket]],
) -> ArbitrageOpportunity | None:
    """Find arbitrage across platforms for a matched event.

    Args:
        mapping: The matched event across platforms.
        markets: Dict of platform_event_id -> list of UnifiedMarket for each entry.

    For each distinct outcome name, find the best (lowest) implied probability
    across all platforms. If the sum < 1.0, arbitrage exists.
    """
    # Collect best odds per outcome across all platforms
    best_by_outcome: dict[str, ArbLeg] = {}

    for entry in mapping.entries:
        if entry.market is None and entry.event is not None:
            entry_markets = markets.get(entry.event.platform_event_id, [])
        elif entry.market is not None:
            entry_markets = [entry.market]
        else:
            continue

        for market in entry_markets:
            for outcome in market.outcomes:
                name = _normalize_outcome_name(outcome.name, entry.outcome_mapping)
                if outcome.implied_probability <= ZERO:
                    continue

                existing = best_by_outcome.get(name)
                if existing is None or outcome.implied_probability < existing.implied_probability:
                    best_by_outcome[name] = ArbLeg(
                        platform=market.platform,
                        market=market,
                        outcome=outcome.name,
                        implied_probability=outcome.implied_probability,
                        decimal_odds=outcome.decimal_odds,
                    )

    if len(best_by_outcome) < 2:
        return None

    legs = list(best_by_outcome.values())
    total_prob = sum(leg.implied_probability for leg in legs)
    profit_margin = ONE - total_prob

    if profit_margin <= ZERO:
        return None

    # Calculate optimal stake fractions (proportional to 1/odds)
    inv_odds_sum = sum(ONE / leg.decimal_odds for leg in legs if leg.decimal_odds > ZERO)
    if inv_odds_sum > ZERO:
        for leg in legs:
            if leg.decimal_odds > ZERO:
                leg.stake_fraction = (ONE / leg.decimal_odds) / inv_odds_sum

    return ArbitrageOpportunity(
        mapping=mapping,
        legs=legs,
        total_implied_prob=total_prob,
        profit_margin=profit_margin,
    )


def _normalize_outcome_name(name: str, outcome_mapping: dict[str, str]) -> str:
    """Normalize outcome name using the mapping if available."""
    for mapped_from, mapped_to in outcome_mapping.items():
        if name.lower() == mapped_from.lower():
            return mapped_to
    return name.lower().strip()
