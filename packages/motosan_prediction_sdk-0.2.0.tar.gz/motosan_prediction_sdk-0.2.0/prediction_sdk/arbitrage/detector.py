from __future__ import annotations

from decimal import Decimal

from prediction_sdk.models.mapping import EventMapping
from prediction_sdk.models.market import UnifiedMarket
from prediction_sdk.models.opportunity import ArbitrageOpportunity

from .cross_platform import find_cross_platform_arb


class ArbitrageDetector:
    """Detects arbitrage opportunities from matched events.

    Args:
        min_profit_margin: Filter out opportunities with a profit margin below
            this threshold.  Defaults to ``Decimal("0")`` (no filtering).
        max_legs: If set, filter out opportunities whose number of legs exceeds
            this value.
    """

    def __init__(
        self,
        min_profit_margin: Decimal = Decimal("0"),
        max_legs: int | None = None,
    ) -> None:
        self.min_profit_margin = min_profit_margin
        self.max_legs = max_legs

    def detect(
        self,
        mapping: EventMapping,
        markets: dict[str, list[UnifiedMarket]] | None = None,
    ) -> ArbitrageOpportunity | None:
        """Detect arbitrage for a matched event.

        Args:
            mapping: The matched event with entries from multiple platforms.
            markets: Optional dict of platform_event_id -> markets.
                     If not provided, uses markets already attached to mapping entries.
        """
        if markets is None:
            markets = {}
        opp = find_cross_platform_arb(mapping, markets)

        if opp is None:
            return None

        if opp.profit_margin < self.min_profit_margin:
            return None

        if self.max_legs is not None and len(opp.legs) > self.max_legs:
            return None

        return opp
