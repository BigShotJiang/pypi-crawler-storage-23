from __future__ import annotations

import os
from dataclasses import dataclass, field

from dotenv import load_dotenv


@dataclass
class Config:
    polymarket_gamma_url: str = "https://gamma-api.polymarket.com"
    polymarket_clob_url: str = "https://clob.polymarket.com"
    kalshi_api_url: str = "https://api.elections.kalshi.com/trade-api/v2"
    kalshi_api_key: str = ""
    extra: dict = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> Config:
        load_dotenv()
        return cls(
            polymarket_gamma_url=os.getenv("POLYMARKET_GAMMA_URL", "https://gamma-api.polymarket.com"),
            polymarket_clob_url=os.getenv("POLYMARKET_CLOB_URL", "https://clob.polymarket.com"),
            kalshi_api_url=os.getenv(
                "KALSHI_API_URL",
                "https://api.elections.kalshi.com/trade-api/v2",
            ),
            kalshi_api_key=os.getenv("KALSHI_API_KEY", ""),
        )
