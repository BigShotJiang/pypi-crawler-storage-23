from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable

from prediction_sdk.errors import PlatformError

logger = logging.getLogger(__name__)


async def with_retry[T](
    fn: Callable[[], Awaitable[T]],
    max_attempts: int = 3,
    base_delay: float = 1.0,
) -> T:
    """Call *fn()* with exponential back-off on retryable ``PlatformError``."""
    for attempt in range(max_attempts):
        try:
            return await fn()
        except PlatformError as e:
            if not e.retryable or attempt == max_attempts - 1:
                raise
            delay = base_delay * (2**attempt)
            logger.warning(
                "Retryable error from %s (attempt %d/%d, status %d), retrying in %.1fs",
                e.platform.value,
                attempt + 1,
                max_attempts,
                e.status_code,
                delay,
            )
            await asyncio.sleep(delay)
    raise RuntimeError("unreachable")  # make type checker happy
