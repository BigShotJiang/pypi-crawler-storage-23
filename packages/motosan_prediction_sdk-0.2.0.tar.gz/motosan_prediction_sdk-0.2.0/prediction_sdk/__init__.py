"""Cross-platform prediction market SDK."""

from prediction_sdk.arbitrage.scanner import ScanResult, scan_arbitrage
from prediction_sdk.clients.kalshi.client import KalshiClient
from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.errors import PlatformError
from prediction_sdk.models import (
    ArbitrageOpportunity,
    ArbLeg,
    EventMapping,
    EventMetadata,
    EventStatus,
    MappingEntry,
    MarketType,
    Outcome,
    Platform,
    Sport,
    UnifiedEvent,
    UnifiedMarket,
)
from prediction_sdk.utils.config import Config

__all__ = [
    "scan_arbitrage",
    "ScanResult",
    "PolymarketClient",
    "KalshiClient",
    "PlatformError",
    "Config",
    "Platform",
    "Sport",
    "EventStatus",
    "MarketType",
    "UnifiedEvent",
    "UnifiedMarket",
    "Outcome",
    "EventMapping",
    "MappingEntry",
    "EventMetadata",
    "ArbLeg",
    "ArbitrageOpportunity",
]
