from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class GammaMarket:
    """Raw market data from the Polymarket Gamma API."""

    id: str
    question: str
    condition_id: str
    slug: str
    outcome_prices: str  # JSON string, e.g. '["0.65", "0.35"]'
    outcomes: str  # JSON string, e.g. '["Yes", "No"]'
    volume: str
    active: bool
    closed: bool

    @classmethod
    def from_dict(cls, data: dict) -> GammaMarket:
        return cls(
            id=str(data.get("id", "")),
            question=data.get("question", ""),
            condition_id=data.get("conditionId", ""),
            slug=data.get("slug", ""),
            outcome_prices=data.get("outcomePrices", "[]"),
            outcomes=data.get("outcomes", "[]"),
            volume=data.get("volume", "0"),
            active=data.get("active", False),
            closed=data.get("closed", False),
        )


@dataclass
class GammaEvent:
    """Raw event data from the Polymarket Gamma API."""

    id: str
    title: str
    slug: str
    start_date: str
    end_date: str
    active: bool
    closed: bool
    markets: list[GammaMarket] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> GammaEvent:
        raw_markets = data.get("markets", [])
        markets = [GammaMarket.from_dict(m) for m in raw_markets]
        return cls(
            id=str(data.get("id", "")),
            title=data.get("title", ""),
            slug=data.get("slug", ""),
            start_date=data.get("startDate", ""),
            end_date=data.get("endDate", ""),
            active=data.get("active", False),
            closed=data.get("closed", False),
            markets=markets,
        )
