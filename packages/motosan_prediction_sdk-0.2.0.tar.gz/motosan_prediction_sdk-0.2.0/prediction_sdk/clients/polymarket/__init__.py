"""Polymarket client."""

from .client import PolymarketClient
from .espn import GameInfo, fetch_espn_schedule, fetch_polymarket_game_event
from .models import GammaEvent, GammaMarket
from .normalize import normalize_event, normalize_market

__all__ = [
    "GameInfo",
    "GammaEvent",
    "GammaMarket",
    "PolymarketClient",
    "fetch_espn_schedule",
    "fetch_polymarket_game_event",
    "normalize_event",
    "normalize_market",
]
