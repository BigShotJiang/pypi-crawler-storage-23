from __future__ import annotations

import json
import logging
from datetime import datetime
from decimal import Decimal, InvalidOperation

from prediction_sdk.models.common import EventStatus, MarketType, Platform, Sport
from prediction_sdk.models.event import EventMetadata, UnifiedEvent
from prediction_sdk.models.market import Outcome, UnifiedMarket

from .models import GammaEvent, GammaMarket

logger = logging.getLogger(__name__)

_SPORT_KEYWORDS: dict[Sport, list[str]] = {
    Sport.NBA: ["nba", "basketball"],
    Sport.MLB: ["mlb", "baseball"],
    Sport.NFL: ["nfl", "football"],
    Sport.SOCCER: ["soccer", "football", "fifa", "premier league", "la liga", "mls"],
    Sport.POLITICS: ["election", "president", "senate", "congress", "political", "politics"],
    Sport.CRYPTO: ["bitcoin", "ethereum", "crypto", "btc", "eth"],
}


def _infer_sport(title: str) -> Sport:
    """Infer the sport/category from an event title using keyword heuristics."""
    title_lower = title.lower()
    for sport, keywords in _SPORT_KEYWORDS.items():
        for keyword in keywords:
            if keyword in title_lower:
                return sport
    return Sport.OTHER


def _determine_status(active: bool, closed: bool) -> EventStatus:
    if closed:
        return EventStatus.CLOSED
    if active:
        return EventStatus.OPEN
    return EventStatus.CLOSED


def _parse_datetime(value: str) -> datetime | None:
    if not value:
        return None
    try:
        # Handle ISO-8601 strings with or without trailing Z
        cleaned = value.replace("Z", "+00:00")
        return datetime.fromisoformat(cleaned)
    except (ValueError, TypeError):
        logger.warning("Failed to parse datetime: %s", value)
        return None


def normalize_event(raw: GammaEvent) -> UnifiedEvent:
    """Convert a raw Gamma API event to a UnifiedEvent."""
    return UnifiedEvent(
        platform=Platform.POLYMARKET,
        platform_event_id=raw.id,
        title=raw.title,
        title_original=raw.title,
        category=_infer_sport(raw.title),
        start_time=_parse_datetime(raw.start_date),
        end_time=_parse_datetime(raw.end_date),
        status=_determine_status(raw.active, raw.closed),
        metadata=EventMetadata(slug=raw.slug),
    )


def normalize_market(raw: GammaMarket, event_id: str) -> UnifiedMarket:
    """Convert a raw Gamma API market to a UnifiedMarket."""
    outcomes = _parse_outcomes(raw)
    return UnifiedMarket(
        platform=Platform.POLYMARKET,
        platform_market_id=raw.id,
        event_id=event_id,
        market_type=MarketType.BINARY,
        question=raw.question,
        outcomes=outcomes,
    )


def _parse_outcomes(raw: GammaMarket) -> list[Outcome]:
    """Parse outcome names and prices from the JSON-encoded strings."""
    try:
        names: list[str] = json.loads(raw.outcomes)
    except (json.JSONDecodeError, TypeError):
        logger.warning("Failed to parse outcomes JSON: %s", raw.outcomes)
        names = []

    try:
        prices: list[str] = json.loads(raw.outcome_prices)
    except (json.JSONDecodeError, TypeError):
        logger.warning("Failed to parse outcomePrices JSON: %s", raw.outcome_prices)
        prices = []

    volume = _safe_decimal(raw.volume)
    outcomes: list[Outcome] = []
    for i, name in enumerate(names):
        price_str = prices[i] if i < len(prices) else "0"
        price = _safe_decimal(price_str)
        # In prediction markets, the price IS the implied probability.
        implied_probability = price
        # Decimal odds = 1 / price (guard against zero).
        decimal_odds = Decimal(1) / price if price > 0 else Decimal(0)
        outcomes.append(
            Outcome(
                name=name,
                implied_probability=implied_probability,
                decimal_odds=decimal_odds,
                price=price,
                volume=volume,
                raw_odds=price_str,
            )
        )
    return outcomes


def _safe_decimal(value: str) -> Decimal:
    try:
        return Decimal(value)
    except (InvalidOperation, TypeError, ValueError):
        return Decimal(0)
