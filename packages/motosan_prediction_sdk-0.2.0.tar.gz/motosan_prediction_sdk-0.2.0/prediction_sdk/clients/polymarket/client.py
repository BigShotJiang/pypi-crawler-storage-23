from __future__ import annotations

import asyncio
import logging
from datetime import date

import httpx
from cachetools import TTLCache

from prediction_sdk.clients.base import PredictionClient
from prediction_sdk.errors import PlatformError
from prediction_sdk.models.common import Platform, Sport
from prediction_sdk.models.event import UnifiedEvent
from prediction_sdk.models.market import UnifiedMarket
from prediction_sdk.utils.retry import with_retry

from .espn import GameInfo, fetch_espn_schedule, fetch_polymarket_game_event
from .models import GammaEvent, GammaMarket
from .normalize import normalize_event, normalize_market

logger = logging.getLogger(__name__)


class PolymarketClient(PredictionClient):
    """Async client for the Polymarket Gamma and CLOB APIs."""

    def __init__(
        self,
        gamma_url: str = "https://gamma-api.polymarket.com",
        clob_url: str = "https://clob.polymarket.com",
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._gamma_url = gamma_url
        self._clob_url = clob_url
        self._event_cache: TTLCache[tuple, list[UnifiedEvent]] = TTLCache(maxsize=200, ttl=60)
        self._market_cache: TTLCache[str, list[UnifiedMarket]] = TTLCache(maxsize=500, ttl=30)
        if http_client is not None:
            self._http = http_client
            self._owns_http = False
        else:
            self._http = httpx.AsyncClient(timeout=30)
            self._owns_http = True

    async def fetch_events(self, category: Sport | None = None, limit: int = 100) -> list[UnifiedEvent]:
        """Fetch active events from the Gamma API.

        If *category* is provided, events are filtered post-fetch by the
        sport/category heuristic since the Gamma API does not support
        category-level filtering natively.

        Results are cached by ``(category, limit)`` with a 60-second TTL.
        """
        cache_key = (category, limit)
        cached = self._event_cache.get(cache_key)
        if cached is not None:
            logger.debug("Event cache hit for key %s", cache_key)
            return cached

        params: dict[str, str | int] = {
            "limit": limit,
            "active": "true",
            "closed": "false",
        }

        async def _do_fetch() -> list[dict]:
            response = await self._http.get(f"{self._gamma_url}/events", params=params)
            if response.is_error:
                raise PlatformError.from_response(self.platform(), response)
            return response.json()

        raw_events: list[dict] = await with_retry(_do_fetch)
        events: list[UnifiedEvent] = []
        for item in raw_events:
            gamma_event = GammaEvent.from_dict(item)
            unified = normalize_event(gamma_event)
            if category is not None and unified.category != category:
                continue
            events.append(unified)

        self._event_cache[cache_key] = events
        return events

    async def fetch_markets(self, event_id: str) -> list[UnifiedMarket]:
        """Fetch markets for a given event from the Gamma API.

        Results are cached by *event_id* with a 30-second TTL.
        """
        cached = self._market_cache.get(event_id)
        if cached is not None:
            logger.debug("Market cache hit for event %s", event_id)
            return cached

        params: dict[str, str] = {"event_id": event_id}

        async def _do_fetch() -> list[dict]:
            response = await self._http.get(f"{self._gamma_url}/markets", params=params)
            if response.is_error:
                raise PlatformError.from_response(self.platform(), response)
            return response.json()

        raw_markets: list[dict] = await with_retry(_do_fetch)
        markets: list[UnifiedMarket] = []
        for item in raw_markets:
            gamma_market = GammaMarket.from_dict(item)
            unified = normalize_market(gamma_market, event_id)
            markets.append(unified)

        self._market_cache[event_id] = markets
        return markets

    def platform(self) -> Platform:
        return Platform.POLYMARKET

    async def fetch_daily_games(
        self,
        sport: Sport = Sport.NBA,
        target_date: date | None = None,
    ) -> list[UnifiedEvent]:
        """Fetch today's games from ESPN and look up their Polymarket events.

        This method is Polymarket-specific and not part of the PredictionClient
        ABC.  It uses ESPN's schedule API to discover game slugs, then looks up
        each game on Polymarket by slug.
        """
        games = await fetch_espn_schedule(self._http, sport, target_date)

        async def _lookup(game: GameInfo) -> UnifiedEvent | None:
            gamma_event = await fetch_polymarket_game_event(self._http, self._gamma_url, game.slug)
            if gamma_event is None:
                return None
            unified = normalize_event(gamma_event)
            unified.metadata.game_time = game.game_time
            unified.metadata.home_team = game.home_team
            unified.metadata.away_team = game.away_team
            return unified

        results = await asyncio.gather(*[_lookup(g) for g in games])
        return [e for e in results if e is not None]

    async def fetch_event_with_markets(self, slug: str) -> tuple[UnifiedEvent, list[UnifiedMarket]] | None:
        """Look up a Polymarket event by slug and return it with embedded markets.

        Unlike ``fetch_markets(event_id)``, this uses the markets already
        embedded in the Gamma event response, which is more reliable for
        daily game events.
        """
        gamma_event = await fetch_polymarket_game_event(self._http, self._gamma_url, slug)
        if gamma_event is None:
            return None

        unified_event = normalize_event(gamma_event)
        unified_markets = [normalize_market(m, gamma_event.id) for m in gamma_event.markets]
        return unified_event, unified_markets

    def clear_cache(self) -> None:
        """Clear both the event and market TTL caches."""
        self._event_cache.clear()
        self._market_cache.clear()

    async def close(self) -> None:
        """Close the underlying HTTP client if this instance owns it."""
        if self._owns_http:
            await self._http.aclose()
