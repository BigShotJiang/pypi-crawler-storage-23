"""ESPN schedule fetcher and Polymarket slug builder for daily game markets."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, date, datetime

import httpx

from prediction_sdk.models.common import Sport

from .models import GammaEvent

logger = logging.getLogger(__name__)

ESPN_BASE_URL = "https://site.api.espn.com/apis/site/v2/sports"

# ESPN abbreviation → Polymarket abbreviation overrides per sport.
NBA_ABBREV_OVERRIDES: dict[str, str] = {
    "SA": "sas",
    "GS": "gsw",
    "NY": "nyk",
    "NO": "nop",
    "WSH": "was",
    "PHO": "phx",
    "PHX": "phx",
    "BKN": "bkn",
    "CHA": "cha",
    "UTH": "uta",
    "UTAH": "uta",
}

MLB_ABBREV_OVERRIDES: dict[str, str] = {
    "WSH": "was",
    "SF": "sfg",
    "SD": "sdp",
    "TB": "tbr",
    "KC": "kcr",
    "CWS": "chw",
}

NFL_ABBREV_OVERRIDES: dict[str, str] = {
    "WSH": "was",
    "LV": "lvr",
    "LAR": "lar",
    "LAC": "lac",
}

# Sport → (ESPN path, slug prefix, abbreviation overrides)
SPORT_ESPN_CONFIG: dict[Sport, tuple[str, str, dict[str, str]]] = {
    Sport.NBA: ("basketball/nba", "nba", NBA_ABBREV_OVERRIDES),
    Sport.MLB: ("baseball/mlb", "mlb", MLB_ABBREV_OVERRIDES),
    Sport.NFL: ("football/nfl", "nfl", NFL_ABBREV_OVERRIDES),
}


@dataclass
class GameInfo:
    slug: str
    away_team: str
    home_team: str
    away_abbr: str
    home_abbr: str
    game_time: str | None = None


def _map_abbrev(abbr: str, overrides: dict[str, str]) -> str:
    """Map an ESPN abbreviation to a Polymarket slug abbreviation."""
    upper = abbr.upper()
    if upper in overrides:
        return overrides[upper]
    return abbr.lower()


async def fetch_espn_schedule(
    http: httpx.AsyncClient,
    sport: Sport,
    target_date: date | None = None,
) -> list[GameInfo]:
    """Fetch today's game schedule from the ESPN public API.

    Returns a list of GameInfo with pre-built Polymarket slugs.
    """
    config = SPORT_ESPN_CONFIG.get(sport)
    if config is None:
        logger.warning("No ESPN config for sport %s", sport)
        return []

    espn_path, prefix, overrides = config

    if target_date is None:
        target_date = datetime.now(UTC).date()

    date_str = target_date.strftime("%Y%m%d")
    url = f"{ESPN_BASE_URL}/{espn_path}/scoreboard"
    params = {"dates": date_str}

    response = await http.get(url, params=params)
    response.raise_for_status()
    data = response.json()

    games: list[GameInfo] = []
    for event in data.get("events", []):
        competitions = event.get("competitions", [])
        if not competitions:
            continue

        competitors = competitions[0].get("competitors", [])
        away_comp = None
        home_comp = None
        for comp in competitors:
            if comp.get("homeAway") == "away":
                away_comp = comp
            elif comp.get("homeAway") == "home":
                home_comp = comp

        if away_comp is None or home_comp is None:
            continue

        away_team_data = away_comp.get("team", {})
        home_team_data = home_comp.get("team", {})

        away_raw = away_team_data.get("abbreviation", "")
        home_raw = home_team_data.get("abbreviation", "")
        if not away_raw or not home_raw:
            continue

        away_abbr = _map_abbrev(away_raw, overrides)
        home_abbr = _map_abbrev(home_raw, overrides)
        iso_date = target_date.isoformat()
        slug = f"{prefix}-{away_abbr}-{home_abbr}-{iso_date}"

        game_time = event.get("date")

        games.append(
            GameInfo(
                slug=slug,
                away_team=away_team_data.get("shortDisplayName", away_raw),
                home_team=home_team_data.get("shortDisplayName", home_raw),
                away_abbr=away_abbr,
                home_abbr=home_abbr,
                game_time=game_time,
            )
        )

    return games


async def fetch_polymarket_game_event(
    http: httpx.AsyncClient,
    gamma_url: str,
    slug: str,
) -> GammaEvent | None:
    """Look up a Polymarket event by slug.

    Returns None if the event is not found (empty response).
    """
    response = await http.get(f"{gamma_url}/events", params={"slug": slug})
    response.raise_for_status()
    data = response.json()

    if not data:
        return None

    return GammaEvent.from_dict(data[0])
