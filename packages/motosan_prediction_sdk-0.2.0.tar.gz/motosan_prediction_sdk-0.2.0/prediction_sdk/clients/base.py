from __future__ import annotations

from abc import ABC, abstractmethod

from prediction_sdk.models.common import Platform, Sport
from prediction_sdk.models.event import UnifiedEvent
from prediction_sdk.models.market import UnifiedMarket


class PredictionClient(ABC):
    @abstractmethod
    async def fetch_events(self, category: Sport | None = None, limit: int = 100) -> list[UnifiedEvent]: ...

    @abstractmethod
    async def fetch_markets(self, event_id: str) -> list[UnifiedMarket]: ...

    @abstractmethod
    def platform(self) -> Platform: ...

    @abstractmethod
    async def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        ...

    async def __aenter__(self) -> PredictionClient:
        return self

    async def __aexit__(self, *_args: object) -> None:
        await self.close()
