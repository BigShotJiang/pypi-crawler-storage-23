from __future__ import annotations

import logging

import httpx
from cachetools import TTLCache

from prediction_sdk.clients.base import PredictionClient
from prediction_sdk.errors import PlatformError
from prediction_sdk.models.common import Platform, Sport
from prediction_sdk.models.event import UnifiedEvent
from prediction_sdk.models.market import UnifiedMarket
from prediction_sdk.utils.retry import with_retry

from .models import KalshiEvent, KalshiMarket
from .normalize import normalize_event, normalize_market

logger = logging.getLogger(__name__)


class KalshiClient(PredictionClient):
    """Async client for the Kalshi REST v2 API."""

    def __init__(
        self,
        api_url: str = "https://api.elections.kalshi.com/trade-api/v2",
        http_client: httpx.AsyncClient | None = None,
        api_key: str | None = None,
    ) -> None:
        self._api_url = api_url
        self._api_key = api_key
        self._event_cache: TTLCache[tuple, list[UnifiedEvent]] = TTLCache(maxsize=200, ttl=60)
        self._market_cache: TTLCache[str, list[UnifiedMarket]] = TTLCache(maxsize=500, ttl=30)

        headers: dict[str, str] = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        if http_client is not None:
            self._http = http_client
            self._owns_http = False
        else:
            self._http = httpx.AsyncClient(timeout=30, headers=headers)
            self._owns_http = True

    async def fetch_events(self, category: Sport | None = None, limit: int = 100) -> list[UnifiedEvent]:
        """Fetch open events from the Kalshi API.

        If *category* is provided, events are filtered post-fetch by the
        sport/category heuristic since the Kalshi API does not support
        fine-grained category filtering.

        Results are cached by ``(category, limit)`` with a 60-second TTL.
        """
        cache_key = (category, limit)
        cached = self._event_cache.get(cache_key)
        if cached is not None:
            logger.debug("Event cache hit for key %s", cache_key)
            return cached

        params: dict[str, str | int] = {
            "limit": limit,
            "status": "open",
        }
        if category is not None:
            params["category"] = category.value

        async def _do_fetch() -> dict:
            response = await self._http.get(f"{self._api_url}/events", params=params)
            if response.is_error:
                raise PlatformError.from_response(self.platform(), response)
            return response.json()

        data = await with_retry(_do_fetch)
        raw_events: list[dict] = data.get("events", [])
        events: list[UnifiedEvent] = []
        for item in raw_events:
            kalshi_event = KalshiEvent.from_dict(item)
            unified = normalize_event(kalshi_event)
            if category is not None and unified.category != category:
                continue
            events.append(unified)

        self._event_cache[cache_key] = events
        return events

    async def fetch_markets(self, event_id: str) -> list[UnifiedMarket]:
        """Fetch markets for a given event from the Kalshi API.

        Results are cached by *event_id* with a 30-second TTL.
        """
        cached = self._market_cache.get(event_id)
        if cached is not None:
            logger.debug("Market cache hit for event %s", event_id)
            return cached

        async def _do_fetch() -> dict:
            response = await self._http.get(f"{self._api_url}/events/{event_id}/markets")
            if response.is_error:
                raise PlatformError.from_response(self.platform(), response)
            return response.json()

        data = await with_retry(_do_fetch)
        raw_markets: list[dict] = data.get("markets", [])
        markets: list[UnifiedMarket] = []
        for item in raw_markets:
            kalshi_market = KalshiMarket.from_dict(item)
            unified = normalize_market(kalshi_market, event_id)
            markets.append(unified)

        self._market_cache[event_id] = markets
        return markets

    def platform(self) -> Platform:
        return Platform.KALSHI

    def clear_cache(self) -> None:
        """Clear both the event and market TTL caches."""
        self._event_cache.clear()
        self._market_cache.clear()

    async def close(self) -> None:
        """Close the underlying HTTP client if this instance owns it."""
        if self._owns_http:
            await self._http.aclose()
