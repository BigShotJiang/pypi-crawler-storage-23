from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class KalshiMarket:
    """Raw market data from the Kalshi REST v2 API."""

    ticker: str
    event_ticker: str
    title: str
    subtitle: str
    yes_bid: int
    yes_ask: int
    no_bid: int
    no_ask: int
    last_price: int
    volume: int
    status: str
    open_time: str
    close_time: str
    result: str

    @classmethod
    def from_dict(cls, data: dict) -> KalshiMarket:
        return cls(
            ticker=data.get("ticker", ""),
            event_ticker=data.get("event_ticker", ""),
            title=data.get("title", ""),
            subtitle=data.get("subtitle", ""),
            yes_bid=data.get("yes_bid", 0),
            yes_ask=data.get("yes_ask", 0),
            no_bid=data.get("no_bid", 0),
            no_ask=data.get("no_ask", 0),
            last_price=data.get("last_price", 0),
            volume=data.get("volume", 0),
            status=data.get("status", ""),
            open_time=data.get("open_time", ""),
            close_time=data.get("close_time", ""),
            result=data.get("result", ""),
        )


@dataclass
class KalshiEvent:
    """Raw event data from the Kalshi REST v2 API."""

    event_ticker: str
    title: str
    category: str
    sub_title: str
    mutually_exclusive: bool
    markets: list[KalshiMarket] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> KalshiEvent:
        raw_markets = data.get("markets", [])
        markets = [KalshiMarket.from_dict(m) for m in raw_markets]
        return cls(
            event_ticker=data.get("event_ticker", ""),
            title=data.get("title", ""),
            category=data.get("category", ""),
            sub_title=data.get("sub_title", ""),
            mutually_exclusive=data.get("mutually_exclusive", False),
            markets=markets,
        )
