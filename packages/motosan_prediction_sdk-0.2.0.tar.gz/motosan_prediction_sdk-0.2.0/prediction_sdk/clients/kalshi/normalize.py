from __future__ import annotations

import logging
from datetime import datetime
from decimal import Decimal

from prediction_sdk.models.common import EventStatus, MarketType, Platform, Sport
from prediction_sdk.models.event import EventMetadata, UnifiedEvent
from prediction_sdk.models.market import Outcome, UnifiedMarket

from .models import KalshiEvent, KalshiMarket

logger = logging.getLogger(__name__)

_SPORT_KEYWORDS: dict[Sport, list[str]] = {
    Sport.NBA: ["nba", "basketball"],
    Sport.MLB: ["mlb", "baseball"],
    Sport.NFL: ["nfl", "football", "super bowl"],
    Sport.SOCCER: ["soccer", "fifa", "premier league", "la liga", "mls"],
    Sport.POLITICS: ["election", "president", "senate", "congress", "political", "politics"],
    Sport.CRYPTO: ["bitcoin", "ethereum", "crypto", "btc", "eth"],
}


def _infer_sport(category: str, title: str) -> Sport:
    """Infer the sport/category from the Kalshi category field and event title."""
    combined = f"{category} {title}".lower()
    for sport, keywords in _SPORT_KEYWORDS.items():
        for keyword in keywords:
            if keyword in combined:
                return sport
    return Sport.OTHER


def _determine_status(status: str, result: str) -> EventStatus:
    """Map a Kalshi market status string to an EventStatus."""
    if result:
        return EventStatus.RESOLVED
    if status == "active":
        return EventStatus.OPEN
    return EventStatus.CLOSED


def _parse_datetime(value: str) -> datetime | None:
    if not value:
        return None
    try:
        cleaned = value.replace("Z", "+00:00")
        return datetime.fromisoformat(cleaned)
    except (ValueError, TypeError):
        logger.warning("Failed to parse datetime: %s", value)
        return None


def normalize_event(raw: KalshiEvent) -> UnifiedEvent:
    """Convert a raw Kalshi API event to a UnifiedEvent."""
    # Derive start/end time from the earliest open_time and latest close_time
    # across all markets in the event.
    start_time: datetime | None = None
    end_time: datetime | None = None
    status = EventStatus.OPEN

    for m in raw.markets:
        parsed_open = _parse_datetime(m.open_time)
        parsed_close = _parse_datetime(m.close_time)
        if parsed_open is not None and (start_time is None or parsed_open < start_time):
            start_time = parsed_open
        if parsed_close is not None and (end_time is None or parsed_close > end_time):
            end_time = parsed_close
        mkt_status = _determine_status(m.status, m.result)
        if mkt_status != EventStatus.OPEN:
            status = mkt_status

    return UnifiedEvent(
        platform=Platform.KALSHI,
        platform_event_id=raw.event_ticker,
        title=raw.title,
        title_original=raw.title,
        category=_infer_sport(raw.category, raw.title),
        start_time=start_time,
        end_time=end_time,
        status=status,
        metadata=EventMetadata(
            extra={
                "sub_title": raw.sub_title,
                "mutually_exclusive": raw.mutually_exclusive,
                "category": raw.category,
            }
        ),
    )


def normalize_market(raw: KalshiMarket, event_id: str) -> UnifiedMarket:
    """Convert a raw Kalshi API market to a UnifiedMarket.

    Kalshi prices are in cents (0-100). The midpoint of bid/ask is used
    as the implied probability after dividing by 100.
    """
    yes_price = Decimal(raw.yes_bid + raw.yes_ask) / 2 / 100
    no_price = Decimal(raw.no_bid + raw.no_ask) / 2 / 100
    volume = Decimal(raw.volume)

    yes_odds = Decimal(1) / yes_price if yes_price > 0 else Decimal(0)
    no_odds = Decimal(1) / no_price if no_price > 0 else Decimal(0)

    outcomes = [
        Outcome(
            name="Yes",
            implied_probability=yes_price,
            decimal_odds=yes_odds,
            price=yes_price,
            volume=volume,
            raw_odds=f"{raw.yes_bid}/{raw.yes_ask}",
        ),
        Outcome(
            name="No",
            implied_probability=no_price,
            decimal_odds=no_odds,
            price=no_price,
            volume=volume,
            raw_odds=f"{raw.no_bid}/{raw.no_ask}",
        ),
    ]

    return UnifiedMarket(
        platform=Platform.KALSHI,
        platform_market_id=raw.ticker,
        event_id=event_id,
        market_type=MarketType.BINARY,
        question=raw.title,
        outcomes=outcomes,
    )
