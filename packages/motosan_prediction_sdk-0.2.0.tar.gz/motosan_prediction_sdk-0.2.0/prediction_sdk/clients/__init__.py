"""Platform clients module."""
