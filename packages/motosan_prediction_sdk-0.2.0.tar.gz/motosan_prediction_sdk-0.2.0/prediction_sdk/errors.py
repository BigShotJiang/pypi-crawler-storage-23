from __future__ import annotations

from dataclasses import dataclass

from prediction_sdk.models.common import Platform


@dataclass
class PlatformError(Exception):
    platform: Platform
    status_code: int
    message: str
    retryable: bool

    def __post_init__(self) -> None:
        super().__init__(self.message)

    @classmethod
    def from_response(cls, platform: Platform, response) -> PlatformError:
        retryable = response.status_code in (429, 502, 503, 504)
        return cls(
            platform=platform,
            status_code=response.status_code,
            message=response.text[:200],
            retryable=retryable,
        )
