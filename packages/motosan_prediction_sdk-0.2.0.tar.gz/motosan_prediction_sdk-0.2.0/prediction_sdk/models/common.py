from enum import StrEnum


class Platform(StrEnum):
    POLYMARKET = "polymarket"
    KALSHI = "kalshi"


class Sport(StrEnum):
    NBA = "nba"
    MLB = "mlb"
    NFL = "nfl"
    SOCCER = "soccer"
    POLITICS = "politics"
    CRYPTO = "crypto"
    OTHER = "other"


class EventStatus(StrEnum):
    OPEN = "open"
    CLOSED = "closed"
    RESOLVED = "resolved"


class MarketType(StrEnum):
    BINARY = "binary"
    MONEYLINE = "moneyline"
    SPREAD = "spread"
    OVER_UNDER = "over_under"
