from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal

from .common import MarketType, Platform


@dataclass
class Outcome:
    name: str
    implied_probability: Decimal
    decimal_odds: Decimal
    price: Decimal | None = None
    volume: Decimal | None = None
    raw_odds: str = ""


@dataclass
class UnifiedMarket:
    platform: Platform
    platform_market_id: str
    event_id: str
    market_type: MarketType
    question: str
    outcomes: list[Outcome] = field(default_factory=list)
    fetched_at: datetime = field(default_factory=lambda: datetime.now(UTC))
