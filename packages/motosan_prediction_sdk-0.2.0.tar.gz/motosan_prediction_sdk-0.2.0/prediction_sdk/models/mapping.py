from __future__ import annotations

from dataclasses import dataclass, field

from .common import Platform
from .event import UnifiedEvent
from .market import UnifiedMarket


@dataclass
class MappingEntry:
    platform: Platform
    event: UnifiedEvent
    market: UnifiedMarket | None
    outcome_mapping: dict[str, str] = field(default_factory=dict)


@dataclass
class EventMapping:
    canonical_title: str
    entries: list[MappingEntry] = field(default_factory=list)
    match_confidence: float = 0.0
    match_method: str = "manual"
