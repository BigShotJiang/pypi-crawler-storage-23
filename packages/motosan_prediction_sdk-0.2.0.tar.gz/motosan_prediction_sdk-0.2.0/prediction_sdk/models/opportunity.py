from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .common import Platform
from .mapping import EventMapping
from .market import UnifiedMarket


@dataclass
class ArbLeg:
    platform: Platform
    market: UnifiedMarket
    outcome: str
    implied_probability: Decimal
    decimal_odds: Decimal
    stake_fraction: Decimal = Decimal("0")


@dataclass
class ArbitrageOpportunity:
    mapping: EventMapping
    legs: list[ArbLeg] = field(default_factory=list)
    total_implied_prob: Decimal = Decimal("0")
    profit_margin: Decimal = Decimal("0")
