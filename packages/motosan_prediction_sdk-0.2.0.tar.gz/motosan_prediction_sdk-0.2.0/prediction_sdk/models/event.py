from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime

from .common import EventStatus, Platform, Sport


@dataclass
class EventMetadata:
    """Typed metadata for unified events (replaces untyped dict)."""

    home_team: str = ""
    away_team: str = ""
    game_time: str | None = None
    slug: str = ""
    extra: dict = field(default_factory=dict)


@dataclass
class UnifiedEvent:
    platform: Platform
    platform_event_id: str
    title: str
    title_original: str
    category: Sport
    start_time: datetime | None = None
    end_time: datetime | None = None
    status: EventStatus = EventStatus.OPEN
    metadata: EventMetadata = field(default_factory=EventMetadata)
    fetched_at: datetime = field(default_factory=lambda: datetime.now(UTC))
