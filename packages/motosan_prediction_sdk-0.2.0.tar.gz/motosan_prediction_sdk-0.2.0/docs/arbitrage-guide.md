# Cross-Platform Arbitrage Guide

## What Is Cross-Platform Arbitrage?

Cross-platform arbitrage exploits price differences for the same event across different prediction markets and sportsbooks. When one platform underprices an outcome relative to another, you can bet on complementary outcomes across platforms to guarantee a profit regardless of the result.

## How Implied Probability Works

Every odds format can be converted to an **implied probability** — the market's estimate of how likely an outcome is. This is the unifying field that makes cross-platform comparison possible.

- A Polymarket contract trading at $0.65 implies 65% probability
- Decimal odds of 2.50 imply 40% probability (1/2.50)
- American odds of +150 imply 40% probability (100/250)

The SDK normalizes all platforms to implied probability using `Decimal` arithmetic for precision.

## Odds Format Conversions

### Decimal Odds

The simplest format. Your return per unit staked.

```
decimal_odds = 1 / implied_probability
implied_probability = 1 / decimal_odds
```

- Odds of 2.00 = 50% implied probability, $2 return per $1 staked
- Odds of 1.50 = 66.7% implied probability, $1.50 return per $1 staked

### American Odds

Positive = profit on a $100 bet. Negative = amount to bet to win $100.

```
# Positive American odds (+150)
implied_prob = 100 / (american + 100) = 100 / 250 = 0.40

# Negative American odds (-200)
implied_prob = |american| / (|american| + 100) = 200 / 300 = 0.667
```

### Implied Probability (Prediction Markets)

Polymarket and Kalshi use binary contracts priced 0-1. The price **is** the implied probability.

```
# Polymarket Yes contract at $0.65
implied_probability = 0.65
decimal_odds = 1 / 0.65 = 1.538
```

## The Arbitrage Condition

Arbitrage exists when the **sum of the best implied probabilities** for each outcome across all platforms is **less than 1.0**:

```
sum(best_implied_prob_per_outcome) < 1.0
```

The **profit margin** is:

```
profit_margin = 1.0 - sum(best_implied_prob_per_outcome)
```

A positive margin means guaranteed profit. The larger the margin, the more profitable the trade.

## Stake Calculation

Once an arbitrage is found, optimal stakes are proportional to ensure equal payoff on any outcome:

```
stake_fraction_i = (1 / decimal_odds_i) / sum(1 / decimal_odds_j for all j)
```

This ensures your total investment is distributed so that every outcome yields the same return.

## Worked Example

**Event: Lakers vs Celtics**

| Platform | Outcome | Implied Prob | Decimal Odds |
|----------|---------|-------------|-------------|
| Taiwan Lottery (JBot) | Lakers | 0.400 | 2.50 |
| Taiwan Lottery (JBot) | Celtics | 0.625 | 1.60 |
| Polymarket | Lakers | 0.350 | 2.857 |
| Polymarket | Celtics | 0.670 | 1.493 |

**Best prices per outcome** (lowest implied probability = best odds):

| Outcome | Best Platform | Best Implied Prob | Best Decimal Odds |
|---------|--------------|-------------------|-------------------|
| Lakers | Polymarket | 0.350 | 2.857 |
| Celtics | JBot | 0.625 | 1.600 |

**Arbitrage check:**

```
total_implied_prob = 0.350 + 0.625 = 0.975
profit_margin = 1.0 - 0.975 = 0.025 (2.5%)
```

**Stake allocation** (for a $1000 total bet):

```
sum_inverse_odds = 1/2.857 + 1/1.600 = 0.350 + 0.625 = 0.975

stake_lakers = (1/2.857) / 0.975 = 0.3590 → $359.00 on Polymarket
stake_celtics = (1/1.600) / 0.975 = 0.6410 → $641.00 on JBot
```

**Payoff verification:**

```
If Lakers win:  $359.00 * 2.857 = $1,025.64
If Celtics win: $641.00 * 1.600 = $1,025.60
Total invested: $1,000.00
Guaranteed profit: ~$25.60 (2.56%)
```

## Risk Factors

### Execution Risk
Odds can move between detection and placing bets. The arbitrage may vanish before you can act on both platforms.

### Liquidity Risk
Markets may not have enough depth to fill your desired stake at the quoted price, especially on prediction markets with thin order books.

### Platform Risk
- Withdrawal delays can tie up capital
- Different settlement rules across platforms
- Account limits or restrictions

### Fee Drag
Platform fees (trading fees, withdrawal fees) reduce actual profit margins. A 2% theoretical margin may become unprofitable after a 1% fee on each platform.

### Overround
Sportsbooks build in a margin (overround/vig) that makes their odds sum to >100%. Cross-platform arb exploits situations where competing overrounds create gaps.

### Data Freshness
Taiwan Lottery (JBot) provides close-line odds that may lag real-time markets. Always verify current odds before executing.
