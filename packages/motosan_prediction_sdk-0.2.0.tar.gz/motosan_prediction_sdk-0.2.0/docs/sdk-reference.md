# SDK Reference

## Clients

All clients implement the `PredictionClient` abstract base class.

### PredictionClient (ABC)

```python
from prediction_sdk.clients.base import PredictionClient
```

| Method | Signature | Description |
|--------|-----------|-------------|
| `fetch_events` | `async (category: Sport \| None = None, limit: int = 100) -> list[UnifiedEvent]` | Fetch events, optionally filtered by sport |
| `fetch_markets` | `async (event_id: str) -> list[UnifiedMarket]` | Fetch markets for an event |
| `platform` | `() -> Platform` | Returns the platform enum value |

### PolymarketClient

```python
from prediction_sdk.clients.polymarket.client import PolymarketClient

client = PolymarketClient(
    gamma_url="https://gamma-api.polymarket.com",  # default
    clob_url="https://clob.polymarket.com",         # default
)
```

- Uses Gamma API for event/market data
- All markets are `MarketType.BINARY`
- Sport category inferred from title keywords (post-fetch filtering)
- Price = implied probability directly
- Call `await client.close()` when done

### KalshiClient

```python
from prediction_sdk.clients.kalshi.client import KalshiClient

client = KalshiClient(
    api_url="https://api.elections.kalshi.com/trade-api/v2",  # default
)
```

- All markets are `MarketType.BINARY`
- Yes price = `(yes_bid + yes_ask) / 2 / 100` (cents to probability)
- Has native category field, plus title-based sport inference
- `platform_market_id` uses the market ticker
- Call `await client.close()` when done

### TaiwanLotteryClient

```python
from prediction_sdk.clients.taiwan_lottery.client import TaiwanLotteryClient

client = TaiwanLotteryClient(
    token="your-jbot-token",                    # required (JBOT_TOKEN env var)
    api_url="https://api.sportsbot.tech/v2",    # default
)
```

- Requires `JBOT_TOKEN` authentication header (`X-JBot-Token`)
- Supports multiple market types: `MONEYLINE`, `SPREAD`, `OVER_UNDER`
- Defaults to `Sport.NBA` when no category specified
- Rate limited: 20 calls/day, 5-second minimum interval between calls
- Event titles formatted as `"{away_team} @ {home_team}"`
- `fetch_markets` re-fetches NBA games filtered by `game_id`
- Call `await client.close()` when done

## Models

All models are Python dataclasses. Import from `prediction_sdk.models`.

### Enums

```python
from prediction_sdk.models import Platform, Sport, EventStatus, MarketType
```

| Enum | Values |
|------|--------|
| `Platform` | `POLYMARKET`, `KALSHI`, `TAIWAN_LOTTERY` |
| `Sport` | `NBA`, `MLB`, `NFL`, `SOCCER`, `POLITICS`, `CRYPTO`, `OTHER` |
| `EventStatus` | `OPEN`, `CLOSED`, `RESOLVED` |
| `MarketType` | `BINARY`, `MONEYLINE`, `SPREAD`, `OVER_UNDER` |

All enums are `(str, Enum)` — their `.value` is a lowercase string (e.g., `Platform.POLYMARKET.value == "polymarket"`).

### UnifiedEvent

```python
from prediction_sdk.models import UnifiedEvent
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `platform` | `Platform` | required | Source platform |
| `platform_event_id` | `str` | required | Platform-specific event ID |
| `title` | `str` | required | Event title (English/normalized) |
| `title_original` | `str` | required | Original title from platform |
| `category` | `Sport` | required | Sport/category classification |
| `start_time` | `datetime \| None` | `None` | Event start time (UTC) |
| `end_time` | `datetime \| None` | `None` | Event end time (UTC) |
| `status` | `EventStatus` | `OPEN` | Current event status |
| `metadata` | `dict` | `{}` | Platform-specific extra data |
| `fetched_at` | `datetime` | `now(UTC)` | When this data was fetched |

### UnifiedMarket

```python
from prediction_sdk.models import UnifiedMarket
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `platform` | `Platform` | required | Source platform |
| `platform_market_id` | `str` | required | Platform-specific market ID |
| `event_id` | `str` | required | Parent event ID |
| `market_type` | `MarketType` | required | Type of market |
| `question` | `str` | required | Market question text |
| `outcomes` | `list[Outcome]` | `[]` | Available outcomes |
| `fetched_at` | `datetime` | `now(UTC)` | When this data was fetched |

### Outcome

```python
from prediction_sdk.models import Outcome
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `name` | `str` | required | Outcome name (e.g., "Yes", "Lakers") |
| `implied_probability` | `Decimal` | required | Implied probability (0-1) |
| `decimal_odds` | `Decimal` | required | European decimal odds |
| `price` | `Decimal \| None` | `None` | Raw contract price |
| `volume` | `Decimal \| None` | `None` | Trading volume |
| `raw_odds` | `str` | `""` | Original odds string from platform |

### EventMapping

```python
from prediction_sdk.models import EventMapping
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `canonical_title` | `str` | required | Unified event title |
| `entries` | `list[MappingEntry]` | `[]` | Platform-specific entries |
| `match_confidence` | `float` | `0.0` | Match confidence score (0-1) |
| `match_method` | `str` | `"manual"` | How the match was determined |

### MappingEntry

```python
from prediction_sdk.models import MappingEntry
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `platform` | `Platform` | required | Source platform |
| `event` | `UnifiedEvent` | required | The platform's event |
| `market` | `UnifiedMarket \| None` | `None` | Optional pre-attached market |
| `outcome_mapping` | `dict[str, str]` | `{}` | Platform name -> canonical name |

### ArbitrageOpportunity

```python
from prediction_sdk.models import ArbitrageOpportunity
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `mapping` | `EventMapping` | required | The matched event |
| `legs` | `list[ArbLeg]` | `[]` | Individual arbitrage legs |
| `total_implied_prob` | `Decimal` | `0` | Sum of best implied probs |
| `profit_margin` | `Decimal` | `0` | `1 - total_implied_prob` |

### ArbLeg

```python
from prediction_sdk.models import ArbLeg
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `platform` | `Platform` | required | Which platform to bet on |
| `market` | `UnifiedMarket` | required | The specific market |
| `outcome` | `str` | required | Outcome name |
| `implied_probability` | `Decimal` | required | Best implied prob found |
| `decimal_odds` | `Decimal` | required | Corresponding decimal odds |
| `stake_fraction` | `Decimal` | `0` | Optimal stake proportion |

## Matching

### EventMatcher

```python
from prediction_sdk.matching.matcher import EventMatcher

matcher = EventMatcher(
    strategies=None,         # default: [DateMatch(), TeamMatch(), TitleSimilarity()]
    min_confidence=0.5,      # minimum match confidence threshold
)

mappings = matcher.find_matches(events)  # list[UnifiedEvent] -> list[EventMapping]
```

**Strategy selection** is automatic based on sport category:

| Category | Strategies Used | Score Formula |
|----------|----------------|---------------|
| NBA, MLB, NFL, SOCCER | DateMatch + TeamMatch | `team * 0.6 + date * 0.4` |
| POLITICS, CRYPTO, OTHER | TitleSimilarity only | `title_similarity` |

Results are sorted by `match_confidence` descending. Only cross-platform pairs are matched (same-platform events are skipped).

### Built-in Strategies

| Strategy | What It Compares |
|----------|-----------------|
| `DateMatch` | `start_time` proximity |
| `TeamMatch` | Team names from metadata/title, supports aliases |
| `TitleSimilarity` | Fuzzy string similarity of event titles |

## Arbitrage

### ArbitrageDetector

```python
from prediction_sdk.arbitrage.detector import ArbitrageDetector

detector = ArbitrageDetector()

opportunity = detector.detect(
    mapping=event_mapping,                              # EventMapping
    markets={"event_id": [market1, market2], ...},      # optional dict
)
# Returns ArbitrageOpportunity | None
```

The `markets` parameter is a dict mapping `platform_event_id` to `list[UnifiedMarket]`. If `None`, falls back to markets attached via `MappingEntry.market`.

### Odds Converter Functions

```python
from prediction_sdk.arbitrage.odds_converter import (
    implied_prob_to_decimal,    # Decimal -> Decimal
    decimal_to_implied_prob,    # Decimal -> Decimal
    american_to_implied_prob,   # int -> Decimal
    implied_prob_to_american,   # Decimal -> int
    decimal_to_american,        # Decimal -> int
    american_to_decimal,        # int -> Decimal
)
```

All functions use `Decimal` for precision. Invalid inputs raise `ValueError` (e.g., probability <= 0 or > 1, odds < 1, American odds = 0).

## Configuration

### Config

```python
from prediction_sdk.utils.config import Config

config = Config.from_env()  # loads .env file, reads JBOT_TOKEN
```

| Field | Type | Default | Env Var |
|-------|------|---------|---------|
| `jbot_token` | `str` | `""` | `JBOT_TOKEN` |
| `polymarket_gamma_url` | `str` | `https://gamma-api.polymarket.com` | - |
| `polymarket_clob_url` | `str` | `https://clob.polymarket.com` | - |
| `kalshi_api_url` | `str` | `https://api.elections.kalshi.com/trade-api/v2` | - |
| `jbot_api_url` | `str` | `https://api.sportsbot.tech/v2` | - |
| `extra` | `dict` | `{}` | - |
