# motosan-prediction

Cross-platform prediction market SDK for fetching and normalizing event data from **Polymarket**, **Kalshi**, and **台灣運彩** (Taiwan Lottery via JBot API). Provides unified models, async clients, event matching, and arbitrage detection.

## Installation

```bash
uv sync
```

## Quick Start

```python
import asyncio
from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.clients.kalshi.client import KalshiClient
from prediction_sdk.clients.taiwan_lottery.client import TaiwanLotteryClient
from prediction_sdk.matching.matcher import EventMatcher
from prediction_sdk.arbitrage.detector import ArbitrageDetector
from prediction_sdk.models.common import Sport

async def main():
    poly = PolymarketClient()
    kalshi = KalshiClient()
    jbot = TaiwanLotteryClient(token="your-jbot-token")

    # Fetch events from all platforms
    events = []
    events += await poly.fetch_events(category=Sport.NBA, limit=50)
    events += await kalshi.fetch_events(category=Sport.NBA, limit=50)
    events += await jbot.fetch_events(category=Sport.NBA)

    # Match events across platforms
    matcher = EventMatcher()
    mappings = matcher.find_matches(events)

    # Detect arbitrage
    detector = ArbitrageDetector()
    for mapping in mappings:
        # Fetch markets for each matched event
        markets = {}
        for entry in mapping.entries:
            if entry.event:
                client = {
                    "polymarket": poly,
                    "kalshi": kalshi,
                    "taiwan_lottery": jbot,
                }[entry.platform.value]
                markets[entry.event.platform_event_id] = await client.fetch_markets(
                    entry.event.platform_event_id
                )

        opp = detector.detect(mapping, markets=markets)
        if opp:
            print(f"ARB: {opp.mapping.canonical_title} — margin {opp.profit_margin:.2%}")

    await poly.close()
    await kalshi.close()
    await jbot.close()

asyncio.run(main())
```

## Data Sources

| Platform | API | Auth | Rate Limits |
|----------|-----|------|-------------|
| Polymarket | Gamma API + CLOB | None for reads | 100 req/min |
| Kalshi | REST v2 | None for reads | Tier-based |
| 台灣運彩 | JBot API | `X-JBot-Token` header | 20 calls/day, 5s min interval |

## Architecture

```
prediction_sdk/
├── models/          # Unified data models (UnifiedEvent, UnifiedMarket, Outcome, etc.)
├── clients/
│   ├── polymarket/  # Gamma + CLOB API client
│   ├── kalshi/      # REST v2 client
│   └── taiwan_lottery/  # JBot API client with rate limiter
├── matching/        # Cross-platform event matching (team aliases, fuzzy title, date)
├── arbitrage/       # Arbitrage detection and odds conversion
└── utils/           # Config and env loading
```

### Unified Model

All platforms are normalized to a common `implied_probability` field (Decimal, 0–1):

- **Polymarket/Kalshi:** YES price = implied probability
- **Taiwan Lottery:** `implied_probability = 1 / decimal_odds`

### Event Matching

Layered strategy for cross-platform event pairing:

1. **Category filter** — only match within the same sport
2. **Rule-based** (sports) — match by date ± 1 day + team names via alias dictionary (EN/ZH/abbreviations)
3. **Fuzzy title** (politics/crypto) — `rapidfuzz.token_sort_ratio > 0.80`

### Arbitrage Detection

For matched events, finds the cheapest implied probability for each outcome across platforms. If the sum < 1.0, arbitrage exists.

## Configuration

Copy `.env.example` to `.env` and set your JBot token:

```bash
cp .env.example .env
```

## Testing

```bash
uv run pytest tests/ -v
```

## License

Private — all rights reserved.
