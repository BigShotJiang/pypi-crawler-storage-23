---
name: cross-platform-arb
description: Use when analyzing cross-platform prediction market arbitrage, comparing odds across Polymarket/Kalshi, or when the user says 'find arb', 'cross-platform', 'compare odds'
---

# Cross-Platform Arbitrage Analysis

## Overview

End-to-end workflow for detecting arbitrage opportunities across prediction market platforms (Polymarket, Kalshi). This skill guides you through fetching events, matching them cross-platform, and identifying profitable price discrepancies.

## Prerequisites

- `motosan-prediction` SDK installed (`uv sync` or `pip install -e .`)
- Python 3.11+

## Workflow

```dot
digraph arb_workflow {
    rankdir=LR;
    Start -> "Configure clients";
    "Configure clients" -> "Fetch events";
    "Fetch events" -> "Match events cross-platform";
    "Match events cross-platform" -> "Fetch markets";
    "Fetch markets" -> "Detect arbitrage";
    "Detect arbitrage" -> "Report opportunities";
}
```

## Step-by-Step Guide

### 1. Configure Clients

```python
from prediction_sdk.utils.config import Config
from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.clients.kalshi.client import KalshiClient

config = Config.from_env()

poly_client = PolymarketClient(gamma_url=config.polymarket_gamma_url)
kalshi_client = KalshiClient(api_url=config.kalshi_api_url)
```

### 2. Fetch Events by Sport Category

```python
from prediction_sdk.models import Sport

poly_events = await poly_client.fetch_events(category=Sport.NBA, limit=50)
kalshi_events = await kalshi_client.fetch_events(category=Sport.NBA, limit=50)

all_events = poly_events + kalshi_events
```

### 3. Match Events Cross-Platform

```python
from prediction_sdk.matching.matcher import EventMatcher

matcher = EventMatcher(min_confidence=0.5)
# Default strategies: DateMatch, TeamMatch, TitleSimilarity
# Sports use DateMatch + TeamMatch (weighted 0.4 + 0.6)
# Non-sports use TitleSimilarity only

mappings = matcher.find_matches(all_events)
# Returns list[EventMapping] sorted by match_confidence descending
```

### 4. Fetch Markets for Matched Events

```python
client_lookup = {
    "polymarket": poly_client,
    "kalshi": kalshi_client,
}

for mapping in mappings:
    markets = {}
    for entry in mapping.entries:
        client = client_lookup[entry.platform.value]
        entry_markets = await client.fetch_markets(entry.event.platform_event_id)
        markets[entry.event.platform_event_id] = entry_markets
```

### 5. Detect Arbitrage

```python
from prediction_sdk.arbitrage.detector import ArbitrageDetector

detector = ArbitrageDetector()

for mapping in mappings:
    opp = detector.detect(mapping, markets=markets)
    if opp is not None:
        print(f"ARB FOUND: {mapping.canonical_title}")
        print(f"  Profit margin: {opp.profit_margin:.4f}")
        print(f"  Total implied prob: {opp.total_implied_prob:.4f}")
        for leg in opp.legs:
            print(f"  {leg.platform.value}: {leg.outcome} "
                  f"@ {leg.decimal_odds:.3f} "
                  f"(stake {leg.stake_fraction:.2%})")
```

### 6. Clean Up

```python
await poly_client.close()
await kalshi_client.close()
```

## Key Metrics

| Metric | Description |
|--------|-------------|
| `implied_probability` | Each outcome's probability derived from its price/odds (Decimal) |
| `total_implied_prob` | Sum of best implied probabilities across platforms for each outcome |
| `profit_margin` | `1 - total_implied_prob`. Positive = arbitrage exists |
| `stake_fraction` | Optimal proportion of total stake for each leg: `(1/odds) / sum(1/odds)` |
| `decimal_odds` | European-format odds (`1 / implied_probability`) |

## Signal Interpretation

- **`profit_margin > 0`** — Arbitrage opportunity exists
- **`profit_margin > 0.01` (1%)** — Potentially actionable after fees
- **`profit_margin > 0.03` (3%)** — Strong opportunity worth investigating
- **`profit_margin > 0.10` (10%)** — Unusually large; verify data accuracy

### Risk Caveats

- Odds can move between detection and execution
- Platform withdrawal/deposit times add settlement risk
- Each platform has different fee structures that eat into margins
- Liquidity limits may prevent full stake placement
- Binary markets have platform-specific fee structures

## Platform Notes

| Platform | Rate Limits | Data Freshness | Notes |
|----------|------------|----------------|-------|
| Polymarket | No strict limit | Real-time | Binary markets only, category inferred from title |
| Kalshi | No strict limit | Real-time | Binary markets, has native category field |

## Output Format

Present results as a table:

| Platform | Outcome | Implied Prob | Decimal Odds | Stake % |
|----------|---------|-------------|-------------|---------|
| polymarket | Yes | 0.3500 | 2.857 | 38.5% |
| kalshi | No | 0.6250 | 1.600 | 61.5% |
| **Total** | | **0.9750** | | **100%** |
| **Margin** | | **2.50%** | | |
