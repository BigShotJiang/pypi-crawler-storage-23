---
name: odds-lookup
description: Use when looking up odds from prediction markets, converting between odds formats, or when the user says 'check odds', 'convert odds', 'odds lookup'
---

# Odds Lookup & Conversion

## Overview

Quick odds retrieval from a single prediction market platform and format conversion between implied probability, decimal odds, and American odds.

## Workflow

```dot
digraph odds_flow {
    rankdir=LR;
    "Choose platform" -> "Fetch events";
    "Fetch events" -> "Fetch markets";
    "Fetch markets" -> "Display odds";
    "Display odds" -> "Convert formats";
}
```

## Usage

### Single-Platform Odds Fetch

```python
from prediction_sdk.clients.polymarket.client import PolymarketClient
from prediction_sdk.models import Sport

client = PolymarketClient()
events = await client.fetch_events(category=Sport.NBA, limit=10)

for event in events:
    markets = await client.fetch_markets(event.platform_event_id)
    for market in markets:
        print(f"{market.question}")
        for outcome in market.outcomes:
            print(f"  {outcome.name}: "
                  f"prob={outcome.implied_probability:.4f} "
                  f"decimal={outcome.decimal_odds:.3f}")

await client.close()
```

### Odds Conversion Functions

All functions use `Decimal` for precision.

```python
from decimal import Decimal
from prediction_sdk.arbitrage.odds_converter import (
    implied_prob_to_decimal,
    decimal_to_implied_prob,
    american_to_implied_prob,
    implied_prob_to_american,
    decimal_to_american,
    american_to_decimal,
)

# Implied probability -> Decimal odds
implied_prob_to_decimal(Decimal("0.40"))   # Decimal("2.5")

# Decimal odds -> Implied probability
decimal_to_implied_prob(Decimal("2.50"))   # Decimal("0.4")

# American -> Implied probability
american_to_implied_prob(150)    # positive: 100/(150+100) = 0.4
american_to_implied_prob(-200)   # negative: 200/(200+100) = 0.667

# Implied probability -> American
implied_prob_to_american(Decimal("0.40"))  # 150
implied_prob_to_american(Decimal("0.75"))  # -300

# Decimal <-> American (composed conversions)
decimal_to_american(Decimal("2.50"))   # 150
american_to_decimal(150)               # Decimal("2.5")
```

## Odds Conversion Reference

### Formulas

| Conversion | Formula |
|------------|---------|
| Implied prob -> Decimal | `decimal = 1 / prob` |
| Decimal -> Implied prob | `prob = 1 / decimal` |
| American (positive) -> Implied prob | `prob = 100 / (american + 100)` |
| American (negative) -> Implied prob | `prob = abs(american) / (abs(american) + 100)` |
| Implied prob -> American (prob < 0.5) | `american = (100 / prob) - 100` (positive) |
| Implied prob -> American (prob >= 0.5) | `american = -(prob * 100 / (1 - prob))` (negative) |

## Quick Reference

| Implied Prob | Decimal Odds | American Odds | Interpretation |
|-------------|-------------|---------------|----------------|
| 0.20 | 5.00 | +400 | Long shot |
| 0.25 | 4.00 | +300 | Underdog |
| 0.33 | 3.00 | +200 | Moderate underdog |
| 0.40 | 2.50 | +150 | Slight underdog |
| 0.50 | 2.00 | +100 | Even money |
| 0.60 | 1.67 | -150 | Slight favorite |
| 0.67 | 1.50 | -200 | Moderate favorite |
| 0.75 | 1.33 | -300 | Strong favorite |
| 0.80 | 1.25 | -400 | Heavy favorite |
| 0.90 | 1.11 | -900 | Near certainty |

## Platform-Specific Notes

- **Polymarket**: Odds derived from binary market prices (0-1 range). Price = implied probability. No auth required.
- **Kalshi**: Odds derived from binary market prices (0-1 range). Price = implied probability.
