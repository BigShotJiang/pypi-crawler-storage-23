# Changelog

## [0.2.0] - 2026-03-03

### Added
- Structured `PlatformError` with `retryable` flag for 429/502/503/504 (#7)
- Exponential backoff retry via `with_retry()` (#17)
- TTL cache for events (60s) and markets (30s) (#19)
- Optional Kalshi API key authentication (#21)
- N-platform event grouping via union-find in EventMatcher (#9)
- Configurable `ArbitrageDetector` with `min_profit_margin` and `max_legs` (#10)
- `PredictionClient` async context manager support (#6)
- Public API exports in `prediction_sdk.__init__` (#27)
- GitHub Actions CI workflow for lint + test (#30)

### Changed
- `UnifiedEvent.metadata` is now typed `EventMetadata` dataclass (#20)
- `Config.from_env()` reads all platform URLs from environment (#5)
- `PredictionClient` supports injectable `httpx.AsyncClient` for connection reuse (#6)
- `asyncio.gather` uses `return_exceptions=True` for graceful partial failures (#8)
- Enums migrated to `StrEnum` (Python 3.11+) (#28)

### Removed
- Taiwan Lottery / JBot integration (#18)
- `daily_scanner.py` (Polymarket x Taiwan Lottery specific workflow)
- Dead `market_parser.py` (#29)

### Fixed
- All 26 ruff lint errors cleaned up (#28)

## [0.1.0] - 2026-02-01

### Added
- Initial SDK with Polymarket, Kalshi, and Taiwan Lottery clients
- Cross-platform event matching with team aliases
- Arbitrage detection and opportunity scoring
- CLI entry point (`arb-scan`)
