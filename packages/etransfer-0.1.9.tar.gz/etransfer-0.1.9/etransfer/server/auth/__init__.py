"""User authentication system with OIDC and pluggable DB backend."""
