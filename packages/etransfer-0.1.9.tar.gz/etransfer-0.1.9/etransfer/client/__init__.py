"""EasyTransfer client module - CLI and GUI tools."""
