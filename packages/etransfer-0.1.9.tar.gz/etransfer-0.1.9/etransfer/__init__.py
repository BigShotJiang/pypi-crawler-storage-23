"""EasyTransfer - TUS-based file transfer tool."""

__version__ = "0.1.9"
__author__ = "ETransfer Team"
