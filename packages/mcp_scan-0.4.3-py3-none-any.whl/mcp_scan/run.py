import os
import sys
import shutil


def run():
    print(
        "\033[33m"
        "WARNING: The 'mcp-scan' package has been renamed to 'snyk-agent-scan'.\n"
        "Please update your installation and use 'uvx snyk-agent-scan@latest' instead.",
        file=sys.stderr,
    )

    exe = shutil.which("snyk-agent-scan")
    if exe is None:
        print(
            "Error: 'snyk-agent-scan' executable not found. "
            "Please install it with: pip install snyk-agent-scan",
            file=sys.stderr,
        )
        sys.exit(1)

    os.execvp(exe, [exe] + sys.argv[1:])
