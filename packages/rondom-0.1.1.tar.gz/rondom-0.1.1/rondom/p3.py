P3_CODE = '''
# 3 plotting

%Triangular membership function
x = (0.0:1.0:10.0);
y1 = trimf(x,[1 3 5]);
subplot(311)
plot(x,y1);

%Trapezoidal membership function
x = (0.0:1.0:10.0);
y2 = trapmf(x,[1 3 5 7]);
subplot(312)
plot(x,y2);

%Bell-shaped membership function
x = (0.0:0.2:10.0);
y3 = gbellmf(x,[3 5 7]);
subplot(313)
plot(x,y3);
'''

def main():
    # print("")
    print(P3_CODE)


if __name__ == "__main__":
    main()
