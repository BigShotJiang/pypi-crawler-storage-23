P5_CONTENT = '''
# 5 Implementation of Fuzzy Inference System

AIM: To implement a Fuzzy Inference System (FIS) for the given inputs, output, and rules using MATLAB Fuzzy Logic Toolbox.

SOFTWARE REQUIRED:
MATLAB with Fuzzy Logic Toolbox

THEORY: A Fuzzy Inference System (FIS) is a rule-based system that uses fuzzy logic to map inputs to outputs.

In this practical:

Inputs:
Temperature
Cloud Cover

Output:
Speed
FIS Type: Mamdani

Membership Function Types:
Trapezoidal (trapmf)
Triangular (trimf)

INPUT VARIABLES
1️ Temperature
Range:
[0 110]
Membership Functions:
MF Name	Type	Parameters
Freezing	trapmf	[0 0 30 50]
Cool	trimf	[30 50 70]
Warm	trimf	[50 70 90]
Hot	trapmf	[70 90 110 110]
Steps:

Double-click Temperature

Delete default membership functions

Click Edit → Add MFs

Add 4 membership functions

Rename and assign parameters as above

2️ Cloud Cover
Range:
[0 100]
Membership Functions:
MF Name	Type	Parameters
Sunny	trimf	[0 20 40]
PartlyCloudy	trimf	[30 50 70]
Overcast	trimf	[60 80 100]

Repeat same steps as Temperature to configure Cloud Cover.

OUTPUT VARIABLE
3️ Speed
Range:
[0 100]
Membership Functions:
MF Name	Type	Parameters
Slow	trapmf	[0 0 25 75]
Fast	trapmf	[25 75 100 100]

Steps:

Double-click Speed

Remove default MFs

Add 2 trapezoidal membership functions

Set names and parameters as above

RULE BASE

Go to:

Edit → Rules
Add the following rules:

1️ If Cloud Cover is Sunny AND Temperature is Warm
→ Speed is Fast

2️ If Cloud Cover is PartlyCloudy AND Temperature is Cool
→ Speed is Slow
Click Add Rule to insert them.
VIEW RULES

Go to:
View → Rules
Or open Surface Viewer to observe relationship between:
Temperature
Cloud Cover
Speed

SAMPLE INPUT AND OUTPUT
Temperature	Cloud Cover	Output Speed
65 (Warm)	15 (Sunny)	Fast
45 (Cool)	50 (Cloudy)	Slow

RESULT:

The Fuzzy Inference System was successfully implemented using MATLAB.
The system determines vehicle speed based on temperature and cloud cover using fuzzy rules.
'''

def main():
    # print("")
    print(P5_CONTENT)

if __name__ == "__main__":
    main()
