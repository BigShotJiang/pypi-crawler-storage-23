P7_CONTENT = '''
# 7 Generation of ANDNOT function using McCulloch-Pitts neural net

clc;
clear;

disp('Enter the weight');
w1 = input('weight w1= ');
w2 = input('weight w2= ');

disp('Enter threshold value');
theta = input('theta= ');

y = [0 0 0 0];
x1 = [0 0 1 1];
x2 = [0 1 0 1];
Z  = [0 0 1 0];

con = 1;

while con
    
    zin = x1*w1 + x2*w2;
    
    for i = 1:4
        if zin(i) >= theta
            y(i) = 1;
        else
            y(i) = 0;
        end
    end
    
    disp('Output of net=');
    disp(y);
    
    if isequal(y, Z)
        con = 0;
    else
        disp('Net is not learning enter another set of weights and threshold value');
        w1 = input('Weight w1= ');
        w2 = input('Weight w2= ');
        theta = input('theta= ');
    end
end

disp('McCulloch Pitts Net for ANDNOT function');
disp('Weights of neuron');
disp(w1);
disp(w2);
disp('Threshold value=');
disp(theta);
'''

def main():
    # print("")
    print(P7_CONTENT)

if __name__ == "__main__":
    main()
