P4_CODE = '''
# 4 MATLAB with Fuzzy Logic Toolbox

AIM: To use Fuzzy Logic Toolbox in MATLAB to model the tip value given after dinner based on quality (not good, satisfying, delightful) and service (poor, average, good), where tip value ranges from Rs. 10 to Rs. 100.

SOFTWARE REQUIRED:
MATLAB with Fuzzy Logic Toolbox

THEORY:
Fuzzy Logic is a rule-based decision-making system that works with degrees of truth (0 to 1) instead of binary values (0 or 1).

In this practical:
Inputs: Quality and Service

Output: Tip Value
FIS Type: Mamdani Fuzzy Inference System
Membership Function Type: Triangular (trimf)

PROCEDURE:
Step 1: Open Fuzzy Logic Designer
Open MATLAB.
Go to Command Window.

Type:
fuzzy
Fuzzy Logic Designer window will open.
Step 2: Add Input and Output Variables

Add Inputs:
Click Edit → Add Variable → Input

Add two input variables:
Quality
Service

Add Output:
Click Edit → Add Variable → Output
Add output variable:

Tip
INPUT VARIABLES CONFIGURATION

1️ Quality
Range:
[0 10]
Membership Functions:
MF Name	Type	Parameters
not_good	trimf	[1 3 5]
satisfied	trimf	[3 5 7]
delightful	trimf	[5 7 9]
Steps:

Double-click Quality
Delete default membership functions
Click Edit → Add MFs
Add 3 triangular membership functions
Rename and set parameters as above

2️ Service
Range:
[0 10]
Membership Functions:
MF Name	Type	Parameters
poor	trimf	[1 3 5]
average	trimf	[3 5 7]
good	trimf	[5 7 9]

Repeat same steps as Quality.

OUTPUT VARIABLE CONFIGURATION
3️ Tip
Range:
[10 100]
Membership Functions:
MF Name	Type	Parameters
less	trimf	[10 20 30]
medium	trimf	[25 45 70]
high	trimf	[60 80 100]

Steps:
Double-click Tip
Remove default MFs
Add 3 triangular membership functions
Rename and set parameters

Step 3: Add Fuzzy Rules

Go to:

Edit → Rules
Sample Rule Base:

If Quality is not_good AND Service is poor → Tip is less
If Quality is not_good AND Service is average → Tip is less
If Quality is satisfied AND Service is average → Tip is medium
If Quality is satisfied AND Service is good → Tip is medium
If Quality is delightful AND Service is good → Tip is high
If Quality is delightful AND Service is average → Tip is high

Click Add Rule to insert rules.

Step 4: View Rule Surface

Go to:
View → Rules
Or open Surface Viewer
Observe 3D surface between:
Quality
Service
Tip

RESULT:
The fuzzy inference system successfully models the tip value based on food quality and service. The output tip ranges between Rs. 10 and Rs. 100 depending on input conditions.

'''

def main():
    # print("")
    print(P4_CODE)

if __name__ == "__main__":
    main()
