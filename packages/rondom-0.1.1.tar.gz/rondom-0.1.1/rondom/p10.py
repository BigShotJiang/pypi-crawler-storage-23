P10_CONTENT = '''
# 10  Genetic Algorithm II
import random

weights = [2, 3, 4, 5]
values = [6, 10, 12, 13]
capacity = 8

POP_SIZE = 6
GENES = len(weights)
GENERATIONS = 15
MUT_RATE = 0.1

# Initial Population
population = [[random.randint(0, 1) for _ in range(GENES)]
              for _ in range(POP_SIZE)]

# Fitness Function
def fitness(chrom):
    total_weight = 0
    total_value = 0
    
    for i in range(GENES):
        if chrom[i] == 1:
            total_weight += weights[i]
            total_value += values[i]
    
    if total_weight > capacity:
        return 0
    
    return total_value

# Genetic Algorithm Loop
for gen in range(GENERATIONS):
    
    fit_vals = [fitness(c) for c in population]
    
    best_fit = max(fit_vals)
    best_idx = fit_vals.index(best_fit)
    
    print(f"Gen {gen+1}: Best solution = {population[best_idx]}, Value = {best_fit}")
    
    new_pop = []
    
    # Tournament Selection
    for _ in range(POP_SIZE):
        a, b = random.sample(range(POP_SIZE), 2)
        winner = population[a] if fit_vals[a] > fit_vals[b] else population[b]
        new_pop.append(winner[:])
    
    # Crossover
    for i in range(0, POP_SIZE, 2):
        if random.random() < 0.8:
            cp = random.randint(1, GENES - 1)
            new_pop[i][:cp], new_pop[i+1][:cp] = \
                new_pop[i+1][:cp], new_pop[i][:cp]
    
    # Mutation
    for i in range(POP_SIZE):
        for j in range(GENES):
            if random.random() < MUT_RATE:
                new_pop[i][j] ^= 1
    
    population = new_pop

'''

def main():
    # print("")
    print(P10_CONTENT)

if __name__ == "__main__":
    main()
