P2_CODE = '''
# 2  Implementation of De-Morgan Law

u = input('enter the membership value of first fuzzy set');
v = input('enter the membership value of second fuzzy set');

w = max(u,v);
p = min(u,v);

q1 = 1-u;
q2 = 2-v;

x1 = 1-w;
x2 = min(q1,q2);

y1 =1-p;
y2 =max(q1-q2);


disp('union of two fuzzy set is ');
disp(w);

disp('intersection of two fuzzy set is ');
disp(p);

disp('complement of one fuzzy set is ');
disp(q1);

disp('complement of two fuzzy set is ');
disp(q2);

disp('de morgan law');
disp('LHS');
disp(x1);
disp('RHS');
disp(x2);
disp('LHS');
disp(y1);
disp('RHS');
disp(y2);

'''

def main():
    # print("")
    print(P2_CODE)

if __name__ == "__main__":
    main()
