P6_CONTENT = '''⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
# 6  Simple Fuzzy Set Operations

a = input('Enter fuzzy set A: ');
b = input('Enter fuzzy set B: ');

c = a + b;
d = a .* b;

as = c - d;          
ad = a .* (1 - b);   
ap = d;             

bs = min(1, c);  
bd = max(0, a - b);  
bp = max(0, c - 1);

disp('Algebraic Sum'); disp(as)
disp('Algebraic Difference'); disp(ad)
disp('Algebraic Product'); disp(ap)
disp('Bounded Sum'); disp(bs)
disp('Bounded Difference'); disp(bd)
disp('Bounded Product'); disp(bp)
'''

def main():
    # print("")
    # print("=" * 70)
    print(P6_CONTENT)
    
if __name__ == "__main__":
    main()
