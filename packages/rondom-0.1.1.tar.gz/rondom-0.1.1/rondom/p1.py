P1_CODE = '''
# 1 Performing Union, Intersection and Complement Operations

u = input('enter the membership value of first fuzzy set');
v = input('enter the membership value of second fuzzy set');

w = max(u,v);
p = min(u,v);

q1 = 1-u;
q2 = 2-v;

disp('union of two fuzzy set is ');
disp(w);

disp('intersection of two fuzzy set is ');
disp(p);

disp('complement of one fuzzy set is ');
disp(q1);

disp('complement of two fuzzy set is ');
disp(q2);
'''

def main():
    # print("")
    print(P1_CODE)

if __name__ == "__main__":
    main()