"""rondom Library made by Mannny"""
__version__ = "0.1.0"
