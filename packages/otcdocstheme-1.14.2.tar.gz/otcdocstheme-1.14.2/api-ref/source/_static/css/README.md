<!--
This directory is set in conf.py as html_static_path.
See http://www.sphinx-doc.org/en/stable/config.html#confval-html_static_path
for further details.
-->