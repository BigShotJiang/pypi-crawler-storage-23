# 🪐 Saturn2D

Saturn2D is a lightweight 2D game engine built on top of Pygame.

It provides a clean, modular architecture for building 2D games with:

- 🎮 Scene system
- 🧍 Entity system
- 🧠 Collision detection
- 📷 Camera support
- 🖼 Texture loading (local files + web URLs)
- 🧩 UI system (Buttons, Labels)
- 🎬 Scene transitions (fade in/out)
- ⏱ Delta time support

---

## 📦 Installation

Install from PyPI:

```bash
pip install saturn2d