# src/saturn2d/utils.py
import pygame
import requests
from io import BytesIO

def load_texture(path_or_url):
    """
    Load a texture from a local file or a web URL.
    Returns a pygame.Surface with alpha.
    """
    if path_or_url.startswith("http"):
        response = requests.get(path_or_url)
        image = pygame.image.load(BytesIO(response.content)).convert_alpha()
    else:
        image = pygame.image.load(path_or_url).convert_alpha()
    return image