# src/saturn2d/time.py
import time

class Time:
    def __init__(self):
        self.last_time = time.time()
        self.delta_time = 0

    def update(self):
        current = time.time()
        self.delta_time = current - self.last_time
        self.last_time = current