# src/saturn2d/scene.py

class Scene:
    def __init__(self):
        self.entities = []
        self.ui_elements = []   # 👈 NEW
        self.camera = None

    def add_entity(self, entity):
        self.entities.append(entity)

    def add_ui(self, ui_element):
        self.ui_elements.append(ui_element)

    def handle_event(self, event):
        # Send events to world entities
        for entity in self.entities:
            entity.handle_event(event)

        # Send events to UI
        for ui in self.ui_elements:
            ui.handle_event(event)

    def update(self, dt):
        for entity in self.entities:
            obstacles = [e for e in self.entities if e != entity] \
                if getattr(entity, "is_player", False) else None
            entity.update(dt, obstacles=obstacles)

        for ui in self.ui_elements:
            ui.update(dt)

        if self.camera and self.entities:
            self.camera.follow(self.entities[0])

    def render(self, screen):
        screen.fill((0, 0, 0))

        # Render world
        for entity in self.entities:
            entity.render(screen, camera=self.camera)

        # Render UI (NO camera offset)
        for ui in self.ui_elements:
            ui.render(screen)