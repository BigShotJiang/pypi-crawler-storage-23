# src/saturn2d/camera.py
class Camera:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.x = 0
        self.y = 0

    def follow(self, target):
        self.x = target.x + target.width // 2 - self.width // 2
        self.y = target.y + target.height // 2 - self.height // 2
        self.x = max(0, self.x)
        self.y = max(0, self.y)