# Math Demo (Python)

This example demonstrates a basic Python library.

[View the Spec in the repository](https://github.com/symbolfarm/specular/blob/main/src/math_demo.spec.md)

### Key Features
-   Pure functions.
-   Factorial and Primality testing.
-   Automatic test generation with `pytest`.
