
def main():
    print("Hello World! Ver 1")

