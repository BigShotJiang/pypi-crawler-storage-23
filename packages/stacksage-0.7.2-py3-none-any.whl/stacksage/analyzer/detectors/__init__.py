"""
StackSage Detectors Module

All cost optimization and waste detection logic organized by resource type.
"""

# CloudWatch Detectors
from .cloudwatch import detect_cloudwatch_logs_retention, detect_overprovisioned_lambda

# EBS Detectors
from .ebs import (
    detect_ebs_overprovisioned_performance,
    detect_gp2_to_gp3_migration,
    detect_old_snapshots,
    detect_snapshot_consolidation,
    detect_unattached_ebs,
)

# EC2 Detectors
from .ec2 import detect_ec2_generation_upgrades, detect_idle_ec2, detect_stopped_ec2

# Cost guardrails
from .guardrails import detect_anomaly_detection_guardrail, detect_budgets_guardrail

# Network Detectors
from .network import (
    detect_idle_elb,
    detect_lb_empty_target_groups,
    detect_missing_s3_endpoint,
    detect_nat_gateways,
    detect_unused_eips,
)

# RDS Detectors
from .rds import detect_underutilized_rds

# S3 Detectors
from .s3 import detect_s3_lifecycle_suggestions

# Tagging Detector
from .tagging import detect_untagged_resources

__all__ = [
    # EBS
    "detect_unattached_ebs",
    "detect_ebs_overprovisioned_performance",
    "detect_gp2_to_gp3_migration",
    "detect_old_snapshots",
    "detect_snapshot_consolidation",
    # EC2
    "detect_stopped_ec2",
    "detect_idle_ec2",
    "detect_ec2_generation_upgrades",
    # RDS
    "detect_underutilized_rds",
    # Network
    "detect_unused_eips",
    "detect_idle_elb",
    "detect_lb_empty_target_groups",
    "detect_nat_gateways",
    "detect_missing_s3_endpoint",
    # CloudWatch
    "detect_overprovisioned_lambda",
    "detect_cloudwatch_logs_retention",
    # Cost guardrails
    "detect_budgets_guardrail",
    "detect_anomaly_detection_guardrail",
    # Tagging
    "detect_untagged_resources",
    # S3
    "detect_s3_lifecycle_suggestions",
]
