# Taplo CLI

A command line tool for linting and formatting TOML files.

More information on the [website](https://taplo.tamasfe.dev/cli/introduction.html)
