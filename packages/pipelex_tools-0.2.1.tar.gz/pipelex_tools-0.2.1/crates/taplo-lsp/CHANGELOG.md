# Change Log

## 0.8.0

### Features

- Improve error locations for unexpected properties ([#664](https://github.com/tamasfe/taplo/pull/664))

## 0.7.2

Re-release of 0.7.1

## 0.7.1

### Fixes

- Do not enable default-tls unconditionally ([#554](https://github.com/tamasfe/taplo/pull/554))

## 0.7.0

### Fixes

- fix: language server include rule matching ([#378](https://github.com/tamasfe/taplo/pull/378))
- fix hover content ([#453](https://github.com/tamasfe/taplo/pull/453))
