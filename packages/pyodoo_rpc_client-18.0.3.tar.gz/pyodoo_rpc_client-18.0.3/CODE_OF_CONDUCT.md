# Code of Conduct

## Our Commitment

We are committed to making participation in this project a harassment-free experience for everyone.

## Expected Behavior

- Be respectful and constructive.
- Assume good intent and collaborate in good faith.
- Give and receive feedback professionally.

## Unacceptable Behavior

- Harassment, insults, or discriminatory language.
- Personal attacks or trolling.
- Publishing private information without permission.

## Scope

This Code of Conduct applies in project spaces, including Issues, Pull Requests, and Discussions.

## Enforcement

Project maintainers may remove or edit comments, close threads, or block participation for behavior that violates this policy. Thanks
