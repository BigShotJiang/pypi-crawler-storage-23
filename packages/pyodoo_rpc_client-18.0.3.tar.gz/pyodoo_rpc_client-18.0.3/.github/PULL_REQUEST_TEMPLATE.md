## Summary

Describe what this PR changes.

## Why

Explain motivation and context.

## Related issues

Link Issues (for example: `Fixes #123`).

## Changes made

-

## Checklist

- [ ] I have kept this PR focused.
- [ ] I updated docs/README if needed.
- [ ] I ran local checks (`python -m build`, `python -m twine check dist/*`).
- [ ] I verified behavior for the changed code path.
