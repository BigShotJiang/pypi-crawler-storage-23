from __future__ import annotations

from readerctl.cli import cli

if __name__ == "__main__":
    cli()
