from __future__ import annotations

from sysup.cli import cli

if __name__ == "__main__":
    cli()
