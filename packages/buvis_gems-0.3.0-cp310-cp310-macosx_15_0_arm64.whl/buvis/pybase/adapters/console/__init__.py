from __future__ import annotations

from .console import console, logging_to_console

__all__ = ["console", "logging_to_console"]
