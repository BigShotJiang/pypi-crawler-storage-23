"""
Zettel module.

This module contains the Zettel class which represents a Zettel entity.
"""

from __future__ import annotations

from datetime import datetime
from typing import cast

from buvis.pybase.zettel.domain.entities.zettel.services.consistency.zettel_consistency_service import (
    ZettelConsistencyService,
)
from buvis.pybase.zettel.domain.entities.zettel.services.migration.zettel_migration_service import (
    ZettelMigrationService,
)
from buvis.pybase.zettel.domain.value_objects.zettel_data import ZettelData


class Zettel:
    """Zettel class representing a Zettel entity.

    Args:
        zettel_data: Optional ZettelData object to initialize the Zettel.
    """

    def __init__(self, zettel_data: ZettelData | None = None, *, from_rust: bool = False) -> None:
        """Initialize a new Zettel instance."""
        self._data = ZettelData()
        self._from_rust = from_rust
        if zettel_data:
            self.replace_data(zettel_data)

    def get_data(self) -> ZettelData:
        """Get the Zettel data.

        Returns:
            The ZettelData object.
        """
        return self._data

    def replace_data(self, zettel_data: ZettelData) -> None:
        """Replace the Zettel data.

        Args:
            zettel_data: The new ZettelData object.

        Returns:
            None. The function modifies the Zettel data in place.
        """
        self._data = zettel_data

    @property
    def data(self) -> ZettelData:
        """Return the Zettel data."""
        return self._data

    @property
    def from_rust(self) -> bool:
        """Return whether the Zettel was created from Rust data."""
        return self._from_rust

    def migrate(self) -> None:
        """Migrate the Zettel data."""
        ZettelMigrationService.migrate(self._data)

    def ensure_consistency(self) -> None:
        """Ensure the consistency of the Zettel data."""
        ZettelConsistencyService.ensure_consistency(self._data)

    @property
    def id(self) -> int | None:
        """Get the Zettel ID.

        Returns:
            The Zettel ID.
        """
        if self._data.metadata.get("id") is None:
            return None
        try:
            return int(self._data.metadata["id"])
        except ValueError:
            return None

    @id.setter
    def id(self, value: int) -> None:
        """Set the Zettel ID.

        Args:
            value: The new Zettel ID.

        Raises:
            ValueError: If the provided value is not a valid integer.
        """
        self._data.metadata["id"] = int(value)

    @property
    def title(self) -> str | None:
        """Get the Zettel title.

        Returns:
            The Zettel title.
        """
        if self._data.metadata.get("title") is None:
            return None
        return str(self._data.metadata["title"])

    @title.setter
    def title(self, value: str | None) -> None:
        """Set the Zettel title.

        Args:
            value: The new Zettel title.
        """
        if value is None:
            self._data.metadata["title"] = None
        else:
            self._data.metadata["title"] = str(value)

    @property
    def date(self) -> datetime | None:
        """Get the Zettel date.

        Returns:
            The Zettel date.
        """
        if self._data.metadata.get("date") is None:
            return None
        return cast(datetime, self._data.metadata["date"])

    @date.setter
    def date(self, value: datetime) -> None:
        """Set the Zettel date.

        Args:
            value: The new Zettel date.
        """
        self._data.metadata["date"] = value

    @property
    def type(self) -> str | None:
        """Get the Zettel type.

        Returns:
            The Zettel type.
        """
        if self._data.metadata.get("type") is None:
            return None
        return str(self._data.metadata["type"])

    @type.setter
    def type(self, value: str | None) -> None:
        """Set the Zettel type.

        Args:
            value: The new Zettel type.
        """
        if value is None:
            self._data.metadata["type"] = None
        else:
            self._data.metadata["type"] = str(value)

    @property
    def tags(self) -> list[str] | None:
        """Get the Zettel tags.

        Returns:
            The Zettel tags.
        """
        if self._data.metadata.get("tags") is None:
            return None
        return cast(list[str], self._data.metadata["tags"])

    @tags.setter
    def tags(self, value: list[str] | str) -> None:
        """Set the Zettel tags.

        Args:
            value: The new Zettel tags.
        """
        if value and not isinstance(value, list):
            value = [value]
        self._data.metadata["tags"] = value

    @property
    def publish(self) -> bool:
        """Get the Zettel publish status.

        Returns:
            The Zettel publish status.
        """
        if self._data.metadata.get("publish") is None:
            return False
        return cast(bool, self._data.metadata["publish"])

    @publish.setter
    def publish(self, value: bool) -> None:
        """Set the Zettel publish status.

        Args:
            value: The new Zettel publish status.
        """
        self._data.metadata["publish"] = bool(value)

    @property
    def processed(self) -> bool:
        """Get the Zettel processed status.

        Returns:
            The Zettel processed status.
        """
        if self._data.metadata.get("processed") is None:
            return False
        return cast(bool, self._data.metadata["processed"])

    @processed.setter
    def processed(self, value: bool) -> None:
        """Set the Zettel processed status.

        Args:
            value: The new Zettel processed status.
        """
        self._data.metadata["processed"] = bool(value)
