from __future__ import annotations

from .project import ProjectZettel

__all__ = ["ProjectZettel"]
