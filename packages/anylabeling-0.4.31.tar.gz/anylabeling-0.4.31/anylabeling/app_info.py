__appname__ = "AnyLabeling"
__appdescription__ = "Effortless data labeling with AI support"
__version__ = "0.4.31"
__preferred_device__ = "CPU"  # GPU or CPU"
