import fitz  # pymupdf
from ..models import DocumentContent, TextSegment


def parse_pdf(buffer: bytes) -> DocumentContent:
    doc = fitz.open(stream=buffer, filetype="pdf")
    page_count = doc.page_count

    segments: list[TextSegment] = []
    page_dimensions: list[dict] = []
    raw_text = ""

    for page_idx in range(page_count):
        page = doc[page_idx]
        page_number = page_idx + 1

        rect = page.rect
        page_dimensions.append({"width": rect.width, "height": rect.height})

        for block in page.get_text("dict")["blocks"]:
            if block.get("type") != 0:
                continue
            for line in block.get("lines", []):
                line_text = "".join(span.get("text", "") for span in line.get("spans", []))
                trimmed = line_text.strip()
                if not trimmed:
                    continue

                bbox = line.get("bbox") or block.get("bbox")
                segments.append(TextSegment(
                    text=trimmed,
                    charOffset=len(raw_text),
                    pageNumber=page_number,
                    x=bbox[0] if bbox else None,
                    y=bbox[1] if bbox else None,
                    width=(bbox[2] - bbox[0]) if bbox else None,
                    height=(bbox[3] - bbox[1]) if bbox else None,
                ))
                raw_text += trimmed + "\n"

        if page_idx < page_count - 1:
            raw_text += "\n"

    doc.close()
    return DocumentContent(
        rawText=raw_text.rstrip(),
        segments=segments,
        pageCount=page_count,
        pageDimensions=page_dimensions,
    )
