import os
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), "../../.env"))


class Settings:
    anthropic_api_key: str = os.environ["ANTHROPIC_API_KEY"]
    database_url: str = os.environ["DATABASE_URL"]
    port: int = int(os.environ.get("PORT", "3001"))


settings = Settings()
