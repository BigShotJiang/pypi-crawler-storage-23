from aiogram_webhook.config.bot import BotConfig
from aiogram_webhook.config.webhook import WebhookConfig
from aiogram_webhook.engines.simple import SimpleEngine
from aiogram_webhook.engines.token import TokenEngine

__all__ = ["BotConfig", "SimpleEngine", "TokenEngine", "WebhookConfig"]


try:
    from aiogram_webhook.adapters.aiohttp.adapter import AiohttpWebAdapter  # noqa: F401

    __all__.insert(0, "AiohttpWebAdapter")
except ImportError:
    pass

try:
    from aiogram_webhook.adapters.fastapi.adapter import FastApiWebAdapter  # noqa: F401

    __all__.insert(1, "FastApiWebAdapter")
except ImportError:
    pass
