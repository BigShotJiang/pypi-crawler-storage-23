from clipy import BaseCommand, BaseGroup, Option


class WebCommand(BaseCommand):
    """21312"""
    host: str = "localhost"
    port: int = 8000
    is_bitch: bool = True
    # doom: dict[str, str]
    # door: list[str]

    def __call__(self) -> None:
        print(self.host, self.port, self.dim)


class BotCommand(BaseCommand):
    """21312"""
    host: str = "localhost"
    port: int = 8000


class MainCli(BaseGroup):
    __cli_name__ = "my-cli"

    web: WebCommand
    bot: BotCommand


def main() -> None:
    MainCli.run()


if __name__ == "__main__":
    main()