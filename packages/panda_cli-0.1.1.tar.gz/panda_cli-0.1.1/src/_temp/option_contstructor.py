from __future__ import annotations

import typing as t

import click
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined

from _temp.base_option import get_click_meta
from _temp.tools import _is_bool_flag, _is_multiple, _resolve_click_type


def field_to_click_option(
    field_name: str,
    field: FieldInfo,
    annotation: t.Any,
) -> click.Option:
    meta = get_click_meta(field)

    flags = list(meta.get("flags", ()))
    flags.append(f"--{field_name.replace('_', '-')}")

    has_default = field.default is not PydanticUndefined
    default = (
        field.default
        if has_default
        else (field.default_factory() if field.default_factory else None)  # type: ignore
    )
    required = not has_default and field.default_factory is None  # type: ignore

    multiple = meta.get("multiple", _is_multiple(annotation))
    is_flag  = meta.get("is_flag",  _is_bool_flag(annotation) and not multiple)
    click_type = _resolve_click_type(annotation)

    return click.Option(
        param_decls=flags,
        type=None if is_flag else click_type,   # ← ключевой фикс
        default=default,
        required=required,
        multiple=multiple,
        is_flag=is_flag,
        # ← не передаём flag_value вообще если None
        **({"flag_value": meta["flag_value"]} if meta.get("flag_value") is not None else {}),
        help=field.description,
        show_default=meta.get("show_default", has_default),
        prompt=meta.get("prompt", False),
        confirmation_prompt=meta.get("confirmation_prompt", False),
        prompt_required=meta.get("prompt_required", True),
        hide_input=meta.get("hide_input", False),
        count=meta.get("count", False),
        allow_from_autoenv=meta.get("allow_from_autoenv", True),
        hidden=meta.get("hidden", False),
        show_choices=meta.get("show_choices", True),
        show_envvar=meta.get("show_envvar", False),
        deprecated=meta.get("deprecated", False),
    )