from __future__ import annotations

import types
import typing as t

import click



_TYPE_MAP_CLICK: t.Final[dict[t.Any, t.Any]] = {
    str: click.STRING,
    int: click.INT,
    float: click.FLOAT,
    bool: click.BOOL,
    bytes: click.STRING,
}


def _resolve_click_type(annotation: t.Any) -> click.ParamType:
    origin = t.get_origin(annotation)

    # Optional[X] | X | None
    if origin in (t.Union, types.UnionType):
        args = [a for a in t.get_args(annotation) if a is not type(None)]
        if len(args) == 1:
            return _resolve_click_type(args[0])

    # Literal["a", "b"] → Choice
    if origin is t.Literal:
        return click.Choice([str(c) for c in t.get_args(annotation)])

    # list[X] / set[X] → тип элемента (multiple обрабатывается отдельно)
    if origin in (list, tuple, set, frozenset):
        args = t.get_args(annotation)  # type: ignore
        return _resolve_click_type(args[0]) if args else click.STRING

    return _TYPE_MAP_CLICK.get(annotation, click.STRING)


def _is_multiple(annotation: t.Any) -> bool:
    origin = t.get_origin(annotation)
    if origin in (t.Union, types.UnionType):
        args = [a for a in t.get_args(annotation) if a is not type(None)]
        return _is_multiple(args[0]) if len(args) == 1 else False
    return origin in (list, tuple, set, frozenset)


def _is_bool_flag(annotation: t.Any) -> bool:
    origin = t.get_origin(annotation)
    if origin in (t.Union, types.UnionType):
        args = [a for a in t.get_args(annotation) if a is not type(None)]
        return _is_bool_flag(args[0]) if len(args) == 1 else False
    return annotation is bool

