from __future__ import annotations

import typing as t
import collections.abc as cabc

import click
from pydantic import BaseModel, ConfigDict

from _temp.option_contstructor import field_to_click_option


class BaseCommand(BaseModel):
    """
    Базовый класс команды.
    Поля (Option / Field) автоматически становятся click-опциями.
    Переопределите __call__ для логики команды.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # -- внутреннее построение ----------------------------------------------

    @classmethod
    def _build_click_params(cls) -> list[click.Option]:
        hints = t.get_type_hints(cls)
        params: list[click.Option] = []
        for name, field in cls.model_fields.items():
            ann = hints.get(name, field.annotation)
            # Пропускаем поля, тип которых сам является BaseCommand/BaseGroup
            if isinstance(ann, type) and issubclass(ann, (BaseCommand, BaseGroup)):
                continue
            params.append(field_to_click_option(name, field, ann))
        return params

    @classmethod
    def _build_click_command(cls, field_name: str) -> click.Command:
        def _callback(**kwargs: t.Any) -> t.Any:
            instance = cls(**kwargs)
            return instance()

        return click.Command(
            name=cls._cli_name(field_name),
            params=cls._build_click_params(),  # type: ignore
            callback=_callback,
            help=cls.__doc__,
        )

    @classmethod
    def _cli_name(cls, field_name: str) -> str:
        # Можно переопределить через ClassVar или оставить авто
        override = getattr(cls, "__cli_name__", None)
        return override or field_name

    # -- публичный интерфейс ------------------------------------------------

    def __call__(self) -> t.Any:
        """Логика команды. Переопределите в подклассе."""
        raise NotImplementedError(f"{self.__class__.__name__}.__call__ not implemented")

    @classmethod
    def run(cls, args: cabc.Sequence[str] | None = None) -> None:
        """Запустить команду как самостоятельный CLI."""
        cls._build_click_command()(standalone_mode=True, args=args)


class BaseGroup(BaseModel):
    """
    Базовый класс группы.
    Поля, тип которых — подкласс BaseCommand, автоматически становятся
    подкомандами. Остальные поля — групповые опции.

    Пример::

        class CLI(BaseGroup):
            __cli_name__ = "my-cli"

            deploy:  DeployCommand
            migrate: MigrateCommand
    """

    __cli_name__: t.ClassVar[str | None] = None

    model_config = {"arbitrary_types_allowed": True}

    @classmethod
    def _cli_name(cls, field_name: str | None) -> str:
        override = getattr(cls, "__cli_name__", None)
        return override or field_name or cls.__name__.lower().removesuffix("group").removesuffix("cli")

    @classmethod
    def _build_click_group(cls, _field_name: str | None = None) -> click.Group:
        hints = t.get_type_hints(cls)

        group_params: list[click.Option] = []
        subcommands: list[click.Command] = []

        for field_name, field in cls.model_fields.items():
            ann = hints.get(field_name, field.annotation)
            # Поле-команда → подкоманда группы
            if isinstance(ann, type) and issubclass(ann, BaseCommand):
                subcommands.append(ann._build_click_command(field_name))
            # Поле-группа → вложенная группа
            elif isinstance(ann, type) and issubclass(ann, BaseGroup):
                subcommands.append(ann._build_click_group(field_name))
            # Всё остальное → групповая опция
            else:
                group_params.append(field_to_click_option(field_name, field, ann))

        def _callback(**kwargs: t.Any) -> None:
            pass

        grp = click.Group(
            name=cls._cli_name(_field_name),
            params=group_params,
            callback=_callback,
            invoke_without_command=True,
            help=cls.__doc__,
        )
        for cmd in subcommands:
            grp.add_command(cmd)

        return grp

    @classmethod
    def run(cls, args: cabc.Sequence[str] | None = None) -> None:
        """Запустить группу как корневой CLI."""
        cls._build_click_group()(standalone_mode=True, args=args)
