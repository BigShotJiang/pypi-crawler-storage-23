from __future__ import annotations

import typing as t

from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined


# ---------------------------------------------------------------------------
# Option — симбиоз pydantic.Field + click метаданных
# ---------------------------------------------------------------------------

_CLICK_META_KEY = "__click_meta__"


class OptionMeta(t.TypedDict, total=False):
    flags: t.Sequence[str]
    """Click-специфичные параметры, хранящиеся внутри FieldInfo.metadata."""
    show_default: bool | str | None
    prompt: bool | str
    confirmation_prompt: bool | str
    prompt_required: bool
    hide_input: bool
    is_flag: bool | None
    flag_value: t.Any
    multiple: bool
    count: bool
    allow_from_autoenv: bool
    hidden: bool
    show_choices: bool
    show_envvar: bool
    deprecated: bool | str


def Option(
    *flags: str,
    # pydantic Field-совместимые
    default: t.Any = PydanticUndefined,
    description: str | None = None,
    # click-специфичные
    show_default: bool | str | None = None,
    prompt: bool | str = False,
    confirmation_prompt: bool | str = False,
    prompt_required: bool = True,
    hide_input: bool = False,
    is_flag: bool | None = None,
    flag_value: t.Any | None = None,
    multiple: bool = False,
    count: bool = False,
    allow_from_autoenv: bool = True,
    hidden: bool = False,
    show_choices: bool = True,
    show_envvar: bool = False,
    deprecated: bool | str = False,
    **field_kwargs: t.Any,
) -> t.Any:
    """
    Замена/расширение pydantic.Field с поддержкой click-параметров.
    Можно использовать вместо Field, сохраняя все возможности Pydantic.
    """
    from pydantic import Field

    click_meta: OptionMeta = dict(  # type: ignore[assignment]
        flags=flags,
        show_default=show_default,
        prompt=prompt,
        confirmation_prompt=confirmation_prompt,
        prompt_required=prompt_required,
        hide_input=hide_input,
        is_flag=is_flag,
        flag_value=flag_value,
        multiple=multiple,
        count=count,
        allow_from_autoenv=allow_from_autoenv,
        hidden=hidden,
        show_choices=show_choices,
        show_envvar=show_envvar,
        deprecated=deprecated,
    )
    # if param_decls:
    #     click_meta["param_decls"] = param_decls

    kw: dict[str, t.Any] = dict(description=description, **field_kwargs)
    if default is not PydanticUndefined:
        kw["default"] = default

    field = Field(**kw)
    # Прячем click-мету в metadata списке FieldInfo
    object.__setattr__(
        field, "metadata", [*field.metadata, {_CLICK_META_KEY: click_meta}]
    )
    return field


def get_click_meta(field: FieldInfo) -> OptionMeta:
    for item in field.metadata:
        if isinstance(item, dict) and _CLICK_META_KEY in item:
            return item[_CLICK_META_KEY]
    return {}  # type: ignore[return-value]
