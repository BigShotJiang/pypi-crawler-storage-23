"""overflask.testing — utilities for test fixture loading and creation."""

import importlib
import inspect
import json
from pathlib import Path

import pytest


def fixture_file(*filenames: str):
    """Mark a test with fixture files to load into db_session.

    File paths are relative to the test file's directory.
    Loaded instances are inserted into db_session and returned via the
    fixture_data fixture.

    Usage:
        from overflask.testing.testing import fixture_file

        @fixture_file("fixtures/roles.json")
        def test_something(db_session, fixture_data):
            assert fixture_data[0].name == "admin"

        # Multiple files:
        @fixture_file("fixtures/roles.json", "fixtures/plans.json")
        def test_something(db_session, fixture_data):
            ...
    """
    return pytest.mark.fixture_file(filenames=filenames)


def load_fixture_files(paths: list[Path], session) -> list:
    """Load one or more JSON fixture files into a SQLAlchemy session.

    Creates model instances via from_json_object() and hands them to the
    session. SQLAlchemy's unit of work handles insertion ordering and FK
    dependency resolution. If models have circular FKs, the user is
    responsible for configuring post_update=True on the appropriate
    relationship — SQLAlchemy will raise a clear error otherwise.

    Args:
        paths: List of Path objects pointing to JSON fixture files.
        session: SQLAlchemy session to insert instances into.

    Returns:
        List of all inserted model instances.
    """
    instances = []
    for path in paths:
        for entry in json.loads(path.read_text()):
            model_cls = _resolve_model(entry["model"])
            for fields in entry["records"]:
                instances.append(model_cls.from_json_object(fields))

    session.add_all(instances)
    session.commit()
    return instances


def create_data_fixture(instances: list, filepath: str):
    """Serialize SQLAlchemy instances to a JSON fixture file.

    The file path is relative to the caller's file. Raises RuntimeError
    if called from outside a components/ directory.

    Each instance is serialized via ModelBase.to_json_object(). Instances
    must extend ModelBase — plain SQLAlchemy models without it will raise
    AttributeError. Records are grouped by model class in the output.

    The model reference is inferred from the instance's module path:
        components.auth.models.Role -> 'auth.Role'

    Usage:
        # from components/auth/tests/test_views.py:
        create_data_fixture([Role(name="admin")], "fixtures/roles.json")
        # writes to components/auth/tests/fixtures/roles.json
    """
    caller_file = Path(inspect.stack()[1].filename).resolve()
    if "components" not in caller_file.parts:
        raise RuntimeError(
            f"create_data_fixture() must be called from within a components/ "
            f"directory, got: {caller_file}"
        )
    dest = caller_file.parent / filepath

    groups = {}
    for instance in instances:
        ref = _model_ref(instance)
        groups.setdefault(ref, []).append(instance.to_json_object())

    data = [{"model": ref, "records": records} for ref, records in groups.items()]
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(data, indent=2))


def _resolve_model(ref: str):
    """Resolve 'component.ModelName' shorthand to a SQLAlchemy model class.

    Example: 'auth.Role' -> components.auth.models.Role
    """
    component, model_name = ref.rsplit(".", 1)
    module = importlib.import_module(f"components.{component}.models")
    return getattr(module, model_name)


def _model_ref(instance) -> str:
    """Derive 'component.ModelName' from a model instance's module path.

    Example: components.auth.models.Role -> 'auth.Role'
    """
    module = type(instance).__module__  # e.g. 'components.auth.models'
    parts = module.split(".")           # ['components', 'auth', 'models']
    component = parts[1]                # 'auth'
    return f"{component}.{type(instance).__name__}"