"""Flask config accessors for overflask projects."""

from pathlib import Path

from flask import current_app


class Config:
    """Typed accessors for Flask config keys."""

    @staticmethod
    def project_name() -> str:
        return current_app.config["PROJECT_NAME"]

    @staticmethod
    def elasticsearch_url() -> str:
        return current_app.config["ELASTICSEARCH_URL"]

    @staticmethod
    def elasticsearch_username() -> str | None:
        return current_app.config.get("ELASTICSEARCH_USERNAME")

    @staticmethod
    def elasticsearch_password() -> str | None:
        return current_app.config.get("ELASTICSEARCH_PASSWORD")

    @staticmethod
    def registered_retention_days() -> int:
        return current_app.config["TASKS_REGISTERED_RETENTION_DAYS"]

    @staticmethod
    def dispatched_retention_days() -> int:
        return current_app.config["TASKS_DISPATCHED_RETENTION_DAYS"]

    @staticmethod
    def completed_retention_days() -> int:
        return current_app.config["TASKS_COMPLETED_RETENTION_DAYS"]

    @staticmethod
    def metrics_retention_days() -> int:
        return current_app.config["TASKS_METRICS_RETENTION_DAYS"]

    @staticmethod
    def redis_url() -> str:
        return current_app.config["REDIS_URL"]

    @staticmethod
    def kibana_url() -> str:
        return current_app.config["KIBANA_URL"]

    @staticmethod
    def kibana_username() -> str | None:
        return current_app.config.get("KIBANA_USERNAME")

    @staticmethod
    def kibana_password() -> str | None:
        return current_app.config.get("KIBANA_PASSWORD")

    @staticmethod
    def tasks_redis_db() -> int:
        return 15

    @staticmethod
    def components() -> list[str]:
        return current_app.config["COMPONENTS"]

    @staticmethod
    def analytics_environment() -> str:
        return current_app.config.get("ANALYTICS_ENVIRONMENT", "production")

    @staticmethod
    def analytics_flush_interval() -> int:
        return current_app.config.get("ANALYTICS_FLUSH_INTERVAL_SECONDS", 5)

    @staticmethod
    def analytics_flush_batch_size() -> int:
        return current_app.config.get("ANALYTICS_FLUSH_BATCH_SIZE", 500)

    @staticmethod
    def analytics_retention_days() -> int:
        return current_app.config.get("ANALYTICS_RETENTION_DAYS", 365)

    @staticmethod
    def is_testing() -> bool:
        return current_app.testing

    @staticmethod
    def templates_dir() -> Path:
        return Path(__file__).parent.parent / 'templates'

    @staticmethod
    def component_templates_dir() -> Path:
        return Config.templates_dir() / 'component'
