"""Component discovery for overflask projects.

This module scans all registered components and imports their modules
(models, views, tasks, cli) for registration with the application.

Supports both single files and folders:
- components/myapp/models.py (single file)
- components/myapp/models/*.py (folder with multiple files)
"""

import importlib
import pkgutil
from dataclasses import dataclass, field
from types import ModuleType


@dataclass
class DiscoveredModules:
    """Container for discovered component modules."""

    models: list[ModuleType] = field(default_factory=list)
    views: list[ModuleType] = field(default_factory=list)
    tasks: list[ModuleType] = field(default_factory=list)
    cli: list[ModuleType] = field(default_factory=list)


def _import_module_or_package(module_path: str, target_list: list):
    """Import a module or all submodules if it's a package (folder).

    Args:
        module_path: Dotted module path like "components.myapp.models"
        target_list: List to append imported modules to
    """
    try:
        module = importlib.import_module(module_path)
        target_list.append(module)

        # Check if it's a package (folder) with submodules
        if hasattr(module, "__path__"):
            # It's a package - import all submodules
            for importer, submodule_name, is_pkg in pkgutil.iter_modules(module.__path__):
                if not submodule_name.startswith("_"):
                    submodule = importlib.import_module(f"{module_path}.{submodule_name}")
                    target_list.append(submodule)
    except ModuleNotFoundError:
        pass  # Module doesn't exist for this component


def discover(components: list[str]) -> DiscoveredModules:
    """Scan all components and import their modules.

    For each component, it looks for models, views, tasks, and cli.
    Each can be either:
    - A single file (e.g., models.py)
    - A folder with multiple files (e.g., models/__init__.py, models/user.py)

    Args:
        components: List of component names to discover.

    Returns:
        DiscoveredModules dataclass containing all discovered modules.
    """
    result = DiscoveredModules()

    for component in components:
        for module_name, target_list in [
            ("models", result.models),
            ("views", result.views),
            ("tasks", result.tasks),
            ("cli", result.cli),
        ]:
            _import_module_or_package(f"components.{component}.{module_name}", target_list)

    return result
