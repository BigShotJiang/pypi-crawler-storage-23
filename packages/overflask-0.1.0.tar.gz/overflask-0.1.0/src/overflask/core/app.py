"""OverFlask application class."""

from flask import Blueprint, Flask

from overflask.core.discovery import DiscoveredModules, discover


class OverFlask(Flask):
    """Flask application configured for overflask projects.

    Args:
        settings: A settings module with SECRET_KEY, SQLALCHEMY_DATABASE_URI,
            SQLALCHEMY_TRACK_MODIFICATIONS, and COMPONENTS attributes.
    """

    registry: DiscoveredModules

    def __init__(self, settings):
        super().__init__(settings.__name__)

        self.config.from_object(settings)
        self.registry = discover(settings.COMPONENTS)

        for views_module in self.registry.views:
            for name in dir(views_module):
                obj = getattr(views_module, name)
                if isinstance(obj, Blueprint):
                    self.register_blueprint(obj)
