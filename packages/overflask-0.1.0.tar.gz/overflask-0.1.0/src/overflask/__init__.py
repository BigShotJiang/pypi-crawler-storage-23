"""overflask - A CLI tool to scaffold Flask projects with component-based architecture."""

from overflask.analytics.analytics import Analytics
from overflask.core.app import OverFlask
from overflask.core.config import Config
from overflask.db.model_base import ModelBase
from overflask.redis.cache import CachePopulationTimeoutError, cached
from overflask.redis.redis import get_redis
from overflask.tasks.tasks import async_task, delete, recurring_task

__version__ = '0.1.0'
__all__ = [
    'Analytics',
    'CachePopulationTimeoutError',
    'Config',
    'ModelBase',
    'OverFlask',
    'async_task',
    'cached',
    'delete',
    'get_redis',
    'recurring_task',
]
