"""Command implementations for overflask projects."""

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import click
from flask import Flask
from jinja2 import Environment, FileSystemLoader

from overflask.core.config import Config
from overflask.core.discovery import DiscoveredModules


def _get_jinja_env(template_dir: Path) -> Environment:
    """Create Jinja2 environment for template rendering."""
    return Environment(
        loader=FileSystemLoader(str(template_dir)),
        keep_trailing_newline=True,
    )


def get_next_revision_id(migrations_dir: Path) -> str:
    """Get the next auto-incremented revision ID."""
    versions_dir = migrations_dir / "versions"
    existing = list(versions_dir.glob("*.py"))
    if not existing:
        return "001"

    max_num = 0
    for f in existing:
        match = re.match(r"(\d+)_", f.name)
        if match:
            max_num = max(max_num, int(match.group(1)))

    return f"{max_num + 1:03d}"


def run_server(app: Flask, host: str, port: int, is_debug: bool) -> None:
    """Run the development server."""
    os.environ.setdefault("FLASK_DEBUG", "1" if is_debug else "0")
    app.run(host=host, port=port, debug=is_debug)


def add_component(project_root: Path, name: str) -> None:
    """Add a new component to the project."""
    component_dir = project_root / "components" / name

    if component_dir.exists():
        raise click.ClickException(f"Component '{name}' already exists.")

    component_templates_dir = Config.component_templates_dir()

    if not component_templates_dir.exists():
        raise click.ClickException(
            "Component templates not found. Is overflask installed?"
        )

    # Create component directory
    component_dir.mkdir(parents=True)

    # Context for Jinja2 templates
    env = _get_jinja_env(component_templates_dir)

    # Process all files in the component template
    for template_file in component_templates_dir.rglob("*"):
        if template_file.is_dir():
            continue

        # Calculate relative path and destination
        rel_path = template_file.relative_to(component_templates_dir)
        dest_path = component_dir / rel_path

        # Create parent directories
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        if template_file.suffix == ".jinja":
            # Render Jinja2 template
            dest_path = dest_path.with_suffix("")  # Remove .jinja extension
            template = env.get_template(str(rel_path))
            content = template.render(component_name=name)
            dest_path.write_text(content)
        else:
            # Copy static file
            shutil.copy2(template_file, dest_path)

    # Update settings.py to add component to COMPONENTS list
    settings_path = project_root / "settings.py"
    settings_content = settings_path.read_text()
    settings_content = settings_content.replace(
        "COMPONENTS = [", f'COMPONENTS = [\n    "{name}",'
    )
    settings_path.write_text(settings_content)

    click.echo(f"Component '{name}' created successfully!")
    click.echo("Added to COMPONENTS in settings.py")


def db_migrate(project_root: Path, migrations_dir: Path, message: str) -> None:
    """Create a new migration based on model changes."""
    rev_id = get_next_revision_id(migrations_dir)

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "alembic",
            "-c",
            str(migrations_dir / "alembic.ini"),
            "revision",
            "--autogenerate",
            "-m",
            message,
            "--rev-id",
            rev_id,
        ],
        cwd=project_root,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise click.ClickException(f"Migration failed:\n{result.stderr}")

    if result.stdout.strip():
        click.echo(result.stdout)
    click.echo(f"Created migration {rev_id}")


def db_upgrade(project_root: Path, migrations_dir: Path, revision: str) -> None:
    """Upgrade database to a revision."""
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "alembic",
            "-c",
            str(migrations_dir / "alembic.ini"),
            "upgrade",
            revision,
        ],
        cwd=project_root,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise click.ClickException(f"Upgrade failed:\n{result.stderr}")

    if result.stdout.strip():
        click.echo(result.stdout)
    click.echo(f"Upgraded to {revision}")


def db_downgrade(project_root: Path, migrations_dir: Path, revision: str) -> None:
    """Downgrade database to a revision."""
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "alembic",
            "-c",
            str(migrations_dir / "alembic.ini"),
            "downgrade",
            revision,
        ],
        cwd=project_root,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise click.ClickException(f"Downgrade failed:\n{result.stderr}")

    if result.stdout.strip():
        click.echo(result.stdout)
    click.echo(f"Downgraded to {revision}")


def register_component_commands(cli: click.Group, registry: DiscoveredModules) -> None:
    """Register CLI commands from discovered components.

    Args:
        cli: The click group to register commands to.
        registry: The discovered modules from component discovery.
    """
    for cli_module in registry.cli:
        for name in dir(cli_module):
            obj = getattr(cli_module, name)
            if isinstance(obj, click.Command) and obj.name != "cli":
                cli.add_command(obj)