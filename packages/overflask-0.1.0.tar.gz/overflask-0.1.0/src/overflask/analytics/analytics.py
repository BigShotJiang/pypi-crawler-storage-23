"""Analytics static class for recording events."""

import re
from datetime import datetime, timezone
from typing import Any

from flask import g, request

from overflask.analytics.events import AnalyticsEvents
from overflask.analytics.flusher import AnalyticsFlusher
from overflask.core.config import Config


def _normalize_area(area: str) -> str:
    """Lowercase and replace non-alphanumeric characters with underscores."""
    return re.sub(r"[^a-z0-9]+", "_", area.lower()).strip("_")


class Analytics:
    """Record analytics events. Thread-safe; buffered in-process."""

    @staticmethod
    def record(event: str, *, area: str, **data: Any) -> None:
        """Record an analytics event.

        Args:
            event: Event name (e.g. "user.registered").
            area: Required domain/component label (e.g. "auth"). Determines the ES index.
            **data: Arbitrary key-value pairs stored under ``data`` in the event envelope.
        """
        doc = Analytics._build_doc(event, area, data)
        AnalyticsEvents.queue(doc)
        AnalyticsFlusher.ensure()

    @staticmethod
    def _build_doc(event: str, area: str, data: dict) -> dict:
        """Build the full event envelope with optional request context enrichment."""
        doc: dict[str, Any] = {
            "event": event,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "project": Config.project_name(),
            "environment": Config.analytics_environment(),
            "area": _normalize_area(area),
            "data": data,
        }

        # Auto-enrich with Flask request context if available.
        try:
            ctx: dict[str, str] = {
                "http_method": request.method,
                "http_path": request.path,
            }
            request_id = getattr(g, "request_id", None) or request.headers.get("X-Request-ID")
            if request_id:
                ctx["request_id"] = request_id
            user_id = getattr(g, "user_id", None)
            if user_id is not None:
                ctx["user_id"] = str(user_id)
            doc["context"] = ctx
        except RuntimeError:
            # No Flask request context — omit context entirely.
            pass

        return doc

    @staticmethod
    def flush_now() -> int:
        """Drain the buffer and bulk-write to ES immediately.

        Returns the number of events flushed.
        """
        return AnalyticsFlusher.flush_now()
