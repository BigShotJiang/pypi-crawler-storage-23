"""Shared analytics event storage used by Analytics and AnalyticsFlusher."""

import threading
from collections import deque

from overflask.core.config import Config


class AnalyticsEvents:
    """Holds the in-process event buffer."""

    buffer: deque = deque()
    _buffer_lock: threading.Lock = threading.Lock()

    @staticmethod
    def queue(doc: dict):
        """Append a single event doc to the buffer. Thread-safe via deque append."""
        AnalyticsEvents.buffer.append(doc)

    @staticmethod
    def get_batch() -> list[dict]:
        """Atomically drain up to ANALYTICS_FLUSH_BATCH_SIZE events from the buffer.

        Returns the drained batch. Returns an empty list if the buffer is empty.
        """
        batch_size = Config.analytics_flush_batch_size()
        with AnalyticsEvents._buffer_lock:
            batch = []
            for _ in range(batch_size):
                if not AnalyticsEvents.buffer:
                    break
                batch.append(AnalyticsEvents.buffer.popleft())
        return batch

    @staticmethod
    def put_back_batch(batch: list[dict]) -> None:
        """Prepend a batch back to the front of the buffer, preserving order.

        Called by the flusher on a failed bulk write so events are not lost.
        """
        with AnalyticsEvents._buffer_lock:
            for doc in reversed(batch):
                AnalyticsEvents.buffer.appendleft(doc)
