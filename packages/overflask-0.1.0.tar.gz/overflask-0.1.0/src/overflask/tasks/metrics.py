"""Metrics: task count recording and index retention."""

from datetime import datetime, timedelta, timezone

from overflask.core.config import Config
from overflask.es.elastic import get_es_client
from overflask.tasks.es_index_templates import EsIndexTemplates


class Metrics:
    """Task metrics recording and index retention management."""

    @staticmethod
    def record() -> None:
        """Write a snapshot of task counts across all three lifecycle indices."""
        es = get_es_client()
        project = Config.project_name()
        now = datetime.now(tz=timezone.utc)
        counts = {}
        for group in ("registered", "dispatched", "completed"):
            try:
                resp = es.count(
                    index=f"{project}_tasks_{group}-*",
                    ignore_unavailable=True,
                )
                counts[f"{group}_count"] = resp["count"]
            except Exception:
                counts[f"{group}_count"] = 0
        es.index(
            index=EsIndexTemplates.metrics_index(project, now),
            document={"timestamp": now.isoformat(), **counts},
        )

    @staticmethod
    def purge_old() -> None:
        """Delete indices older than the configured retention period.

        Reads TASKS_*_RETENTION_DAYS from Flask config.
        Runs once daily from the scheduler.
        """
        es = get_es_client()
        project = Config.project_name()
        patterns = {
            f"{project}_tasks_registered": Config.registered_retention_days(),
            f"{project}_tasks_dispatched": Config.dispatched_retention_days(),
            f"{project}_tasks_completed": Config.completed_retention_days(),
            f"{project}_tasks_metrics": Config.metrics_retention_days(),
        }
        now = datetime.now(tz=timezone.utc)
        for prefix, retention_days in patterns.items():
            cutoff = now - timedelta(days=retention_days)
            try:
                indices = es.indices.get(index=f"{prefix}-*", ignore_unavailable=True)
            except Exception:
                continue
            for index_name in indices:
                suffix = index_name[len(prefix) + 1:]  # "YYYY.MM" or "YYYY.MM.DD"
                try:
                    parts = [int(p) for p in suffix.split(".")]
                    if len(parts) == 2:
                        index_dt = datetime(parts[0], parts[1], 1, tzinfo=timezone.utc)
                    elif len(parts) == 3:
                        index_dt = datetime(
                            parts[0], parts[1], parts[2], tzinfo=timezone.utc
                        )
                    else:
                        continue
                    if index_dt < cutoff:
                        es.indices.delete(index=index_name)
                except (ValueError, IndexError):
                    continue
