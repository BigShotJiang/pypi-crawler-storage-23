"""Validation helpers for task decoration and queue calls."""

import inspect
import json
import sys
from datetime import datetime, timedelta, timezone
from typing import Callable, Any, get_origin, Union, get_args


def validate_annotations(fn: Callable) -> None:
    """Raise TypeError if any parameter of fn lacks a type annotation or uses variadic params."""
    sig = inspect.signature(fn)
    for name, param in sig.parameters.items():
        if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            raise TypeError(
                f"Task function '{fn.__name__}' cannot use variadic parameters (*{name} or **{name}). "
                "Use explicit named parameters only."
            )
        if param.annotation is inspect.Parameter.empty:
            raise TypeError(
                f"Task function '{fn.__name__}' parameter '{name}' must have a type annotation."
            )


def validate_queue_call(
    sig: inspect.Signature,
    when: datetime | timedelta | None,
    args: tuple,
    kwargs: dict,
) -> tuple[datetime, dict]:
    """Validate a .queue() call and return (run_at, all_kwargs).

    Raises:
        ValueError: On invalid `when` type, missing/unexpected params, or non-serializable args.
        TypeError: On argument type mismatch against annotations.
    """
    # Validation 1: when type
    if when is not None and not isinstance(when, (datetime, timedelta)):
        raise ValueError(
            f"'when' must be None, datetime, or timedelta, got {type(when).__name__}"
        )

    now = datetime.now(tz=timezone.utc)
    if isinstance(when, datetime):
        run_at = when if when.tzinfo is not None else when.replace(tzinfo=timezone.utc)
    elif isinstance(when, timedelta):
        run_at = now + when
    else:
        run_at = now

    # Validations 2 & 3: missing required params / unexpected kwargs
    try:
        bound = sig.bind(*args, **kwargs)
    except TypeError as e:
        raise ValueError(str(e)) from e

    all_kwargs = dict(bound.arguments)

    # Validation 4: JSON-serializable
    try:
        json.dumps({"args": [], "kwargs": all_kwargs})
    except (TypeError, ValueError) as e:
        raise ValueError(f"Task arguments are not JSON-serializable: {e}") from e

    # Validation 5: type checking against annotations
    for param_name, value in bound.arguments.items():
        param = sig.parameters[param_name]
        if param.annotation is inspect.Parameter.empty:
            continue
        check_type(param_name, value, param.annotation)

    return run_at, all_kwargs


def check_type(param_name: str, value: Any, annotation: Any) -> None:
    """Raise TypeError if value does not match the given annotation."""
    origin = get_origin(annotation)

    # Union / Optional (handles both `Union[X, Y]` and `X | Y` in Python 3.10+)
    is_union = origin is Union or (
            sys.version_info >= (3, 10) and isinstance(annotation, __import__("types").UnionType)
    )

    if is_union:
        union_args = get_args(annotation)
        if value is None and type(None) in union_args:
            return
        for t in union_args:
            if t is type(None):
                continue
            if isinstance(t, type) and isinstance(value, t):
                return
        raise TypeError(
            f"Parameter '{param_name}': expected {annotation}, got {type(value).__name__}"
        )

    if origin is not None:
        # Generic container: List[str], Dict[str, int], etc. — check outer type only
        if not isinstance(value, origin):
            raise TypeError(
                f"Parameter '{param_name}': expected {annotation}, got {type(value).__name__}"
            )
        return

    if isinstance(annotation, type):
        if not isinstance(value, annotation):
            raise TypeError(
                f"Parameter '{param_name}': expected {annotation.__name__}, got {type(value).__name__}"
            )
