"""CallableRegistry: in-memory registry of decorated task functions."""

from overflask.tasks.callable_data import CallableData


class CallableRegistry:
    """In-memory registry of task functions decorated with @async_task or @recurring_task."""

    registry: list[CallableData] = []
