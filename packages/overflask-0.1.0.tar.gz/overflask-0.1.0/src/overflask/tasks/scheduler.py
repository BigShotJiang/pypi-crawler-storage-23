"""Task scheduler: claims due tasks from Registered, dispatches to Redis."""

import logging
import secrets
import time
from datetime import datetime, timezone

from croniter import croniter

from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates
from overflask.analytics.purge import AnalyticsPurge
from overflask.core.config import Config
from overflask.core.discovery import discover
from overflask.redis.redis import get_redis
from overflask.tasks.es_index_templates import EsIndexTemplates
from overflask.tasks.kibana import is_provisioned, provision_kibana
from overflask.tasks.metrics import Metrics
from overflask.tasks.task_store import TaskStore

logger = logging.getLogger(__name__)

_POLL_INTERVAL = 1        # seconds between scheduler ticks
_METRICS_INTERVAL = 60    # seconds between metrics snapshots
_PURGE_INTERVAL = 86400   # seconds between retention purges (1 day)
_BATCH_SIZE = 50


def run() -> None:
    """Run the scheduler process. Blocks until interrupted. Requires an active app context."""
    _startup()
    _loop()


def _startup() -> None:
    """Initialize ES templates, discover task callables, and sync recurring tasks."""
    EsIndexTemplates.ensure()
    AnalyticsEsIndexTemplates.ensure()
    discover(Config.components())
    TaskStore.sync_recurring()
    if not is_provisioned():
        provision_kibana()


def _loop() -> None:
    """Poll for due tasks and dispatch them until interrupted."""
    project = Config.project_name()
    redis = get_redis(Config.tasks_redis_db())
    queue_key = f"{project}:tasks:queue"
    last_metrics = time.monotonic()
    last_purge = time.monotonic()

    while True:
        now = datetime.now(tz=timezone.utc)
        batch_id = secrets.randbits(63)
        tasks = TaskStore.claim_batch(now, batch_id, _BATCH_SIZE)

        for task_id, task_doc in tasks:
            try:
                TaskStore.move_to_dispatched(task_id, task_doc)
                redis.rpush(queue_key, task_id)
                if task_doc.get("type") == "recurring" and task_doc.get("cron"):
                    _schedule_next(task_doc, now)
            except Exception:
                logger.exception("Failed to dispatch task %s", task_id)

        mono = time.monotonic()
        if mono - last_metrics >= _METRICS_INTERVAL:
            try:
                Metrics.record()
            except Exception:
                logger.exception("Error recording metrics")
            last_metrics = mono

        if mono - last_purge >= _PURGE_INTERVAL:
            try:
                Metrics.purge_old()
            except Exception:
                logger.exception("Error purging old indices")
            try:
                AnalyticsPurge.purge_old()
            except Exception:
                logger.exception("Error purging old analytics indices")
            last_purge = mono

        time.sleep(_POLL_INTERVAL)


def _schedule_next(task_doc: dict, now: datetime) -> None:
    """Persist the next occurrence of a recurring task."""
    run_at = croniter(task_doc["cron"], now).get_next(datetime)
    TaskStore.persist({
        "id": secrets.randbits(63),
        "key": task_doc.get("key"),
        "type": "recurring",
        "function": task_doc["function"],
        "args": [],
        "kwargs": task_doc.get("kwargs", {}),
        "created_at": now.isoformat(),
        "run_at": run_at.replace(tzinfo=timezone.utc).isoformat(),
        "cron": task_doc["cron"],
    })
