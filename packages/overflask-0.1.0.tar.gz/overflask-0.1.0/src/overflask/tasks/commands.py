"""Click commands for the tasks system."""

import click
from flask import Flask

from overflask.tasks import scheduler
from overflask.tasks import worker
from overflask.tasks.kibana import provision_kibana


@click.group()
def tasks():
    """Task management commands."""


@tasks.command("scheduler")
@click.pass_obj
def scheduler_cmd(app: Flask) -> None:
    """Run the task scheduler (polls ES and dispatches due tasks to Redis)."""
    with app.app_context():
        scheduler.run()


@tasks.command("worker")
@click.pass_obj
def worker_cmd(app: Flask) -> None:
    """Run a task worker (pops from Redis and executes tasks). Scale via compose replicas."""
    with app.app_context():
        worker.run()


@tasks.command("kibana")
@click.pass_obj
def kibana_cmd(app: Flask) -> None:
    """Overwrite Kibana data view, visualizations, and dashboard with current definitions."""
    with app.app_context():
        provision_kibana()