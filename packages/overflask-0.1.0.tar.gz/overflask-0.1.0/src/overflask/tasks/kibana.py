"""Kibana provisioning: data view, visualizations, and dashboard for task monitoring."""

import base64
import json
import logging
from urllib.error import URLError
from urllib.request import Request, urlopen

from overflask.core.config import Config

logger = logging.getLogger(__name__)


def is_provisioned() -> bool:
    """Return True if all Kibana objects are present, False if any are missing.

    Non-fatal — returns False if Kibana is unreachable or raises an error.
    """
    try:
        project = Config.project_name()
        base_url = Config.kibana_url().rstrip("/")
        return (
            _find_data_view(base_url, f"{project}_tasks_metrics-*") is not None
            and _find_saved_object(base_url, "visualization", f"{project} Task Counts") is not None
            and _find_saved_object(base_url, "visualization", f"{project} Task History") is not None
            and _find_saved_object(base_url, "dashboard", f"{project} Tasks") is not None
        )
    except Exception:
        return False


def provision_kibana() -> None:
    """Create or overwrite the Kibana data view, visualizations, and dashboard.

    Always writes — use is_provisioned() to skip if already up to date.
    Non-fatal if Kibana is unreachable.
    """
    try:
        _provision()
    except URLError:
        logger.warning("Kibana unreachable at %s — skipping provisioning", Config.kibana_url())
    except Exception:
        logger.warning("Kibana provisioning failed (non-fatal)", exc_info=True)


def _provision() -> None:
    project = Config.project_name()
    base_url = Config.kibana_url().rstrip("/")

    data_view_id = _write_data_view(base_url, project)
    counts_id, history_id = _write_visualizations(base_url, project, data_view_id)
    _write_dashboard(base_url, project, counts_id, history_id)


# --- Data view ---

def _write_data_view(base_url: str, project: str) -> str:
    """Create or overwrite the metrics data view; return its ID."""
    title = f"{project}_tasks_metrics-*"
    existing_id = _find_data_view(base_url, title)

    body = {"data_view": {"title": title, "timeFieldName": "timestamp"}}
    if existing_id:
        _request(base_url, "PUT", f"/api/data_views/data_view/{existing_id}", body)
        return existing_id

    resp = _request(base_url, "POST", "/api/data_views/data_view", body)
    return resp["data_view"]["id"]


def _find_data_view(base_url: str, title: str) -> str | None:
    """Return the ID of an existing data view by title, or None."""
    resp = _request(base_url, "GET", "/api/data_views")
    for dv in resp.get("data_view", []):
        if dv.get("title") == title:
            return dv["id"]
    return None


# --- Visualizations ---

def _write_visualizations(base_url: str, project: str, data_view_id: str) -> tuple[str, str]:
    """Create or overwrite task count visualizations; return their IDs."""
    counts_id = _write_saved_object(
        base_url, "visualization",
        f"{project} Task Counts",
        _counts_vis_attrs(project, data_view_id),
    )
    history_id = _write_saved_object(
        base_url, "visualization",
        f"{project} Task History",
        _history_vis_attrs(project, data_view_id),
    )
    return counts_id, history_id


def _counts_vis_attrs(project: str, data_view_id: str) -> dict:
    """Metric visualization showing latest registered/dispatched/completed counts."""
    vis_state = {
        "title": f"{project} Task Counts",
        "type": "metric",
        "params": {
            "addTooltip": True,
            "addLegend": False,
            "type": "metric",
            "metric": {
                "percentageMode": False,
                "useRanges": False,
                "colorSchema": "Green to Red",
                "metricColorMode": "None",
                "colorsRange": [{"from": 0, "to": 10000}],
                "labels": {"show": True},
                "invertColors": False,
                "style": {"bgFill": "#000", "bgColor": False, "labelColor": False, "subText": "", "fontSize": 60},
            },
        },
        "aggs": [
            {"id": "1", "enabled": True, "type": "max", "schema": "metric",
             "params": {"field": "registered_count", "customLabel": "Registered"}},
            {"id": "2", "enabled": True, "type": "max", "schema": "metric",
             "params": {"field": "dispatched_count", "customLabel": "Dispatched"}},
            {"id": "3", "enabled": True, "type": "max", "schema": "metric",
             "params": {"field": "completed_count", "customLabel": "Completed"}},
        ],
    }
    return {
        "title": vis_state["title"],
        "visState": json.dumps(vis_state),
        "uiStateJSON": "{}",
        "description": "",
        "kibanaSavedObjectMeta": {
            "searchSourceJSON": json.dumps({
                "index": data_view_id,
                "query": {"query": "", "language": "kuery"},
                "filter": [],
            })
        },
    }


def _history_vis_attrs(project: str, data_view_id: str) -> dict:
    """Line chart showing registered/dispatched/completed counts over time."""
    vis_state = {
        "title": f"{project} Task History",
        "type": "line",
        "params": {
            "type": "line",
            "grid": {"categoryLines": False},
            "categoryAxes": [{
                "id": "CategoryAxis-1",
                "type": "category",
                "position": "bottom",
                "show": True,
                "scale": {"type": "linear"},
                "labels": {"show": True, "truncate": 100},
                "title": {},
            }],
            "valueAxes": [{
                "id": "ValueAxis-1",
                "name": "LeftAxis-1",
                "type": "value",
                "position": "left",
                "show": True,
                "scale": {"type": "linear", "mode": "normal"},
                "labels": {"show": True, "rotate": 0, "filter": False, "truncate": 100},
                "title": {"text": "Count"},
            }],
            "seriesParams": [
                {"show": True, "type": "line", "mode": "normal", "valueAxis": "ValueAxis-1",
                 "drawLinesBetweenPoints": True, "showCircles": True,
                 "data": {"label": "Registered", "id": "1"}},
                {"show": True, "type": "line", "mode": "normal", "valueAxis": "ValueAxis-1",
                 "drawLinesBetweenPoints": True, "showCircles": True,
                 "data": {"label": "Dispatched", "id": "2"}},
                {"show": True, "type": "line", "mode": "normal", "valueAxis": "ValueAxis-1",
                 "drawLinesBetweenPoints": True, "showCircles": True,
                 "data": {"label": "Completed", "id": "3"}},
            ],
            "addTooltip": True,
            "addLegend": True,
            "legendPosition": "right",
            "times": [],
            "addTimeMarker": False,
        },
        "aggs": [
            {"id": "1", "enabled": True, "type": "max", "schema": "metric",
             "params": {"field": "registered_count", "customLabel": "Registered"}},
            {"id": "2", "enabled": True, "type": "max", "schema": "metric",
             "params": {"field": "dispatched_count", "customLabel": "Dispatched"}},
            {"id": "3", "enabled": True, "type": "max", "schema": "metric",
             "params": {"field": "completed_count", "customLabel": "Completed"}},
            {"id": "4", "enabled": True, "type": "date_histogram", "schema": "segment",
             "params": {"field": "timestamp", "useNormalizedEsInterval": True,
                        "interval": "auto", "drop_partials": False, "min_doc_count": 1,
                        "extended_bounds": {}}},
        ],
    }
    return {
        "title": vis_state["title"],
        "visState": json.dumps(vis_state),
        "uiStateJSON": "{}",
        "description": "",
        "kibanaSavedObjectMeta": {
            "searchSourceJSON": json.dumps({
                "index": data_view_id,
                "query": {"query": "", "language": "kuery"},
                "filter": [],
            })
        },
    }


# --- Dashboard ---

def _write_dashboard(base_url: str, project: str, counts_id: str, history_id: str) -> None:
    """Create or overwrite the tasks dashboard."""
    title = f"{project} Tasks"
    existing_id = _find_saved_object(base_url, "dashboard", title)

    panels = [
        {"panelIndex": "1", "gridData": {"x": 0, "y": 0, "w": 12, "h": 8, "i": "1"},
         "panelRefName": "panel_0"},
        {"panelIndex": "2", "gridData": {"x": 12, "y": 0, "w": 36, "h": 8, "i": "2"},
         "panelRefName": "panel_1"},
    ]
    attrs = {
        "title": title,
        "hits": 0,
        "description": f"Task monitoring for {project}",
        "panelsJSON": json.dumps(panels),
        "optionsJSON": json.dumps({"useMargins": True, "syncColors": False, "hidePanelTitles": False}),
        "version": 1,
        "timeRestore": False,
        "kibanaSavedObjectMeta": {
            "searchSourceJSON": json.dumps({"query": {"query": "", "language": "kuery"}, "filter": []})
        },
    }
    references = [
        {"id": counts_id, "name": "panel_0", "type": "visualization"},
        {"id": history_id, "name": "panel_1", "type": "visualization"},
    ]
    body = {"attributes": attrs, "references": references}

    if existing_id:
        _request(base_url, "PUT", f"/api/saved_objects/dashboard/{existing_id}", body)
    else:
        _request(base_url, "POST", "/api/saved_objects/dashboard", body)


# --- Helpers ---

def _write_saved_object(base_url: str, type_: str, title: str, attrs: dict) -> str:
    """Create or overwrite a saved object by title; return its ID."""
    existing_id = _find_saved_object(base_url, type_, title)
    if existing_id:
        _request(base_url, "PUT", f"/api/saved_objects/{type_}/{existing_id}", {"attributes": attrs})
        return existing_id
    resp = _request(base_url, "POST", f"/api/saved_objects/{type_}", {"attributes": attrs})
    return resp["id"]


def _find_saved_object(base_url: str, type_: str, title: str) -> str | None:
    """Return the ID of a saved object matching type and title, or None."""
    path = f"/api/saved_objects/_find?type={type_}&search_fields=title&search={title}&per_page=10"
    resp = _request(base_url, "GET", path)
    for obj in resp.get("saved_objects", []):
        if obj["attributes"].get("title") == title:
            return obj["id"]
    return None


def _request(base_url: str, method: str, path: str, body: dict | None = None) -> dict:
    """Make a Kibana API request and return the parsed JSON response."""
    url = f"{base_url}{path}"
    data = json.dumps(body).encode() if body is not None else None
    headers = {"Content-Type": "application/json", "kbn-xsrf": "true"}

    username = Config.kibana_username()
    password = Config.kibana_password()
    if username and password:
        token = base64.b64encode(f"{username}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {token}"

    req = Request(url, data=data, headers=headers, method=method)
    with urlopen(req, timeout=10) as resp:
        return json.loads(resp.read())
