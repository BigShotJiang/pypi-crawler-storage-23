"""Task worker: pops task IDs from Redis, executes them, marks completed."""

import importlib
import logging

from overflask.core.config import Config
from overflask.core.discovery import discover
from overflask.redis.redis import get_redis
from overflask.tasks.es_index_templates import EsIndexTemplates
from overflask.tasks.task_store import TaskStore

logger = logging.getLogger(__name__)

_BLPOP_TIMEOUT = 5  # seconds


def run() -> None:
    """Run the worker process. Blocks until interrupted. Requires an active app context."""
    _startup()
    _loop()


def _startup() -> None:
    """Ensure ES templates and discover task callables."""
    EsIndexTemplates.ensure()
    discover(Config.components())


def _loop() -> None:
    """Pop task IDs from Redis and execute them until interrupted."""
    project = Config.project_name()
    redis = get_redis(Config.tasks_redis_db())
    queue_key = f"{project}:tasks:queue"

    while True:
        result = redis.blpop(queue_key, timeout=_BLPOP_TIMEOUT)
        if result is None:
            continue

        _, raw_id = result
        task_id = int(raw_id)

        task_doc = TaskStore.get_dispatched(task_id)
        if task_doc is None:
            logger.warning("Task %s not found in dispatched index; skipping", task_id)
            continue

        try:
            fn = _resolve(task_doc["function"])
            fn(**task_doc.get("kwargs", {}))
            TaskStore.mark_completed(task_id)
        except Exception as exc:
            logger.exception("Task %s failed: %s", task_id, exc)
            TaskStore.record_failure(task_id, exc)


def _resolve(function_path: str):
    """Import and return the callable identified by a dotted module.function path."""
    module_path, func_name = function_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, func_name)