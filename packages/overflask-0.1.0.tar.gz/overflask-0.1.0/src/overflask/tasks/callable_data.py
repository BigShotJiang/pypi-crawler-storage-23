"""CallableData: task function metadata extracted at decoration time."""

import inspect
from typing import Callable


class CallableData:
    """Holds metadata extracted from a task function at decoration time."""

    def __init__(self, fn: Callable, cron: str) -> None:
        self.fn = fn
        self.cron = cron
        self.signature = inspect.signature(fn)
        self.function_path = f"{fn.__module__}.{fn.__qualname__}"
