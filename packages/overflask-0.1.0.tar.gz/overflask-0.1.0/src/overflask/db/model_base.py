"""ModelBase — SQLAlchemy declarative base with JSON serialization."""

import json
import re
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from uuid import UUID

from sqlalchemy import MetaData, inspect as sa_inspect
from sqlalchemy.orm import DeclarativeBase

# Naming convention for constraints (helps with Alembic migrations)
_naming_convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


def _to_snake_case(name: str) -> str:
    s = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s).lower()


def _pluralize(word: str) -> str:
    if word.endswith(("s", "x", "z", "ch", "sh")):
        return word + "es"
    if word.endswith("y") and len(word) > 1 and word[-2] not in "aeiou":
        return word[:-1] + "ies"
    return word + "s"


def _to_json_safe(value):
    if value is None:
        return None
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8")
    if isinstance(value, Enum):
        return value.value
    return value


class ModelBase(DeclarativeBase):
    """Base class for all SQLAlchemy models in overflask projects.

    Automatically sets __tablename__ as '{component}_{plural_snake_case}'
    derived from the model class name and its component module, unless
    __tablename__ or __abstract__ is explicitly set on the class.

        components.workshop.models.User     -> workshop_users
        components.workshop.models.UserRole -> workshop_user_roles
        components.blog.models.Category     -> blog_categories

    Provides JSON serialization via to_json_object() and from_json_object().
    """

    metadata = MetaData(naming_convention=_naming_convention)

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)

        if cls.__dict__.get("__abstract__") or "__tablename__" in cls.__dict__:
            return

        parts = cls.__module__.split(".")
        # Expected: components.<component>.models[.*]
        if len(parts) >= 2 and parts[0] == "components":
            prefix = parts[1] + "_"
        else:
            prefix = ""

        cls.__tablename__ = prefix + _pluralize(_to_snake_case(cls.__name__))

    def to_json_object(self) -> dict:
        """Return a JSON-safe dict of this model's fields.

        Column values are converted to JSON-safe types. Relationships are
        represented as PK values only (single) or lists of PK values (plural).
        Unloaded relationships are skipped to avoid implicit queries.
        """
        result = {}
        mapper = sa_inspect(type(self))
        instance_state = sa_inspect(self)

        for col in mapper.columns:
            result[col.key] = _to_json_safe(getattr(self, col.key))

        for rel in mapper.relationships:
            if rel.key not in instance_state.dict:
                continue  # Not loaded — skip

            related = getattr(self, rel.key)

            if related is None:
                result[rel.key] = None
            elif hasattr(related, "__iter__"):
                pk_attr = sa_inspect(rel.mapper).primary_key[0].key
                result[rel.key] = [getattr(obj, pk_attr) for obj in related]
            else:
                pk_attr = sa_inspect(rel.mapper).primary_key[0].key
                result[rel.key] = getattr(related, pk_attr)

        return result

    @classmethod
    def from_json_object(cls, json_obj: str | dict):
        """Create an instance from a JSON string or dict.

        Only column fields are assigned; relationships and unknown keys
        are ignored.
        """
        data = json.loads(json_obj) if isinstance(json_obj, str) else json_obj
        mapper = sa_inspect(cls)
        column_keys = {col.key for col in mapper.columns}
        return cls(**{k: v for k, v in data.items() if k in column_keys})
