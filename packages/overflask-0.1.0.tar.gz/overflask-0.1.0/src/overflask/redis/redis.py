"""Redis connection management for overflask projects."""

from redis import Redis

from overflask.core.config import Config

_connections: dict[int, Redis] = {}


def get_redis(db: int) -> Redis:
    """Get a Redis connection for the specified database number.

    Args:
        db: Redis database number (0-15)

    Returns:
        Redis connection instance for the specified database.
    """
    if db not in _connections:
        _connections[db] = Redis.from_url(Config.redis_url(), db=db)

    return _connections[db]
