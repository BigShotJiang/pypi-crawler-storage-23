"""overflask CLI - Create Flask projects with component-based architecture."""

import re
import secrets
import shutil
import subprocess
from pathlib import Path
from typing import Any

import click

from overflask.core.config import Config


def render_template(template_path: Path, context: dict) -> str:
    """Render a template file by replacing {{ key }} placeholders."""
    content = template_path.read_text()
    for key, value in context.items():
        content = content.replace('{{ ' + key + ' }}', str(value))
    return content


def copy_static_file(src: Path, dest: Path):
    """Copy a static (non-template) file."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)


def write_rendered_template(template_dir: Path, template_name: str, dest: Path, context: dict):
    """Render a template and write it to the destination."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    content = render_template(template_dir / template_name, context)
    dest.write_text(content)


def generate_secret_key() -> str:
    """Generate a secure secret key."""
    return secrets.token_hex(32)


def prompt_config(
    keys: list[str],
    defaults: dict[str, str] | None = None,
    required: list[str] | None = None,
) -> tuple[dict[str, str], list[str]]:
    """Prompt for configuration values.

    Args:
        keys: List of environment variable names to prompt for.
        defaults: Optional dict of default values for specific keys.
        required: List of keys that are required (missing values will be tracked).

    Returns:
        Tuple of (values dict, list of missing required keys).
    """
    defaults = defaults or {}
    required = required or []
    values = {}
    missing = []

    for key in keys:
        default = defaults.get(key)
        prompt = f'  {key}'
        if default:
            prompt += f' [{default}]'
        prompt += ': '

        value = click.prompt(prompt, default=default or '', show_default=False).strip()
        values[key] = value
        if not value and key in required:
            missing.append(key)

    return values, missing


def populate_env_content(content: str, *value_dicts: dict[str, str]) -> str:
    """Replace placeholder values in env template content.

    Args:
        content: The env template content.
        value_dicts: One or more dicts of key-value pairs to substitute.

    Returns:
        The content with values substituted.
    """
    for values in value_dicts:
        for key, value in values.items():
            if value:
                content = content.replace(f'{key}=', f'{key}={value}')
    return content


def get_overflask_source() -> str:
    """Get the overflask dependency string for requirements.pip.

    Returns git URL for proper installs, file:// URL for development installs.
    """
    import overflask

    package_path = Path(overflask.__file__).parent
    if 'site-packages' in str(package_path):
        return 'overflask @ git+https://gitlab.com/hamdarsi/overflask.git'
    else:
        # Development install - point to the source directory (parent of src/overflask)
        source_dir = package_path.parent.parent
        return f'overflask @ file://{source_dir}'


def create_component(project_dir: Path, component_name: str):
    """Create a component using the package's component templates."""
    component_dir = project_dir / 'components' / component_name
    context = {'component_name': component_name}

    templates = [
        ('__init__.py.jinja', component_dir / '__init__.py'),
        ('models.py.jinja', component_dir / 'models.py'),
        ('views.py.jinja', component_dir / 'views.py'),
        ('services.py.jinja', component_dir / 'services.py'),
        ('cli.py.jinja', component_dir / 'cli.py'),
        ('tasks.py.jinja', component_dir / 'tasks.py'),
        ('tests.py.jinja', component_dir / 'tests.py'),
    ]

    for template_name, dest in templates:
        write_rendered_template(Config.component_templates_dir(), template_name, dest, context)


@click.group()
@click.version_option()
def main():
    """overflask - Scaffold Flask projects with component-based architecture."""
    pass


@main.command()
@click.argument('name')
def create(name: str):
    """Create a new Flask project with the given NAME."""
    project_dir = Path.cwd() / name

    if not re.match(r'^[a-z][a-z0-9_]*$', name):
        raise click.ClickException(
            f"Invalid project name '{name}'. "
            "Use lowercase letters, digits, and underscores only, starting with a letter."
        )

    if project_dir.exists():
        raise click.ClickException(f"Directory '{name}' already exists.")

    click.echo(f"Creating project '{name}'...")

    # Ask for initial component name
    component_name = click.prompt('\nInitial component name', default=name, show_default=True).strip()

    # Create project directory
    project_dir.mkdir(parents=True)

    context: dict[Any, Any] = {
        'project_name': name,
        'secret_key': generate_secret_key(),
        'initial_component': component_name,
        'overflask_source': get_overflask_source(),
    }

    # Prompt for Postgres configuration
    click.echo('\nPostgres configuration (press Enter to skip):')
    postgres_keys = ['POSTGRES_HOST', 'POSTGRES_PORT', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'POSTGRES_DB']
    postgres_required = ['POSTGRES_HOST', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'POSTGRES_DB']
    postgres_values, missing_values = prompt_config(
        postgres_keys,
        defaults={'POSTGRES_PORT': '5432'},
        required=postgres_required,
    )
    context['postgres'] = postgres_values

    # Prompt for Redis configuration
    click.echo('\nRedis configuration (press Enter to skip):')
    redis_keys = ['REDIS_HOST', 'REDIS_PORT', 'REDIS_PASSWORD']
    redis_values, redis_missing = prompt_config(
        redis_keys,
        defaults={'REDIS_PORT': '6379'},
        required=['REDIS_HOST'],
    )
    missing_values.extend(redis_missing)
    context['redis'] = redis_values

    # Render root templates
    templates_to_render = [
        ('README.md.jinja', project_dir / 'README.md'),
        ('manage.py.jinja', project_dir / 'manage.py'),
        ('settings.py.jinja', project_dir / 'settings.py'),
        ('compose.yaml.jinja', project_dir / 'compose.yaml'),
        ('requirements.pip.jinja', project_dir / 'requirements.pip'),
        ('conftest.py.jinja', project_dir / 'conftest.py'),
        ('pytest.ini.jinja', project_dir / 'pytest.ini'),
        ('ops/migrations/alembic.ini.jinja', project_dir / 'ops' / 'migrations' / 'alembic.ini'),
        ('ops/migrations/env.py.jinja', project_dir / 'ops' / 'migrations' / 'env.py'),
    ]

    templates_dir = Config.templates_dir()

    for template_name, dest in templates_to_render:
        write_rendered_template(templates_dir, template_name, dest, context)

    # Copy static files
    static_files = [
        ('gitignore', project_dir / '.gitignore'),
        ('dockerignore', project_dir / '.dockerignore'),
        ('ops/env.template', project_dir / 'ops' / 'env.template'),
        ('ops/setup-traefik.sh', project_dir / 'ops' / 'setup-traefik.sh'),
        ('docs/gunicorn.md', project_dir / 'docs' / 'gunicorn.md'),
        ('docs/README-overflask.md', project_dir / 'docs' / 'README-overflask.md'),
        ('docs/traefik.md', project_dir / 'docs' / 'traefik.md'),
        ('ops/migrations/script.py.mako', project_dir / 'ops' / 'migrations' / 'script.py.mako'),
    ]

    for src_name, dest in static_files:
        copy_static_file(templates_dir / src_name, dest)

    # Create migrations versions directory
    (project_dir / 'ops' / 'migrations' / 'versions').mkdir(parents=True, exist_ok=True)

    # Create .env file from env.template with values
    env_content = (templates_dir / 'ops' / 'env.template').read_text()
    env_content = populate_env_content(
        env_content,
        postgres_values,
        redis_values,
        {'SECRET_KEY': context['secret_key']},
    )
    (project_dir / '.env').write_text(env_content)

    # Create the initial component
    create_component(project_dir, component_name)

    click.echo(f"\nProject '{name}' created successfully!")
    click.echo(f"Initial component '{component_name}' created.")

    if missing_values:
        click.echo('\nNote: The following values were not provided and need to be configured in .env:')
        for key in missing_values:
            click.echo(f'  - {key}')
        click.echo('\nAfter configuring .env, start the services with:')
        click.echo(f'  cd {name} && docker compose up -d db redis')
    else:
        # All values provided, offer to start services
        if click.confirm('\nStart Postgres and Redis containers now?', default=True):
            click.echo('Starting services...')
            try:
                subprocess.run(
                    ['docker', 'compose', 'up', '-d', 'db', 'redis'],
                    cwd=project_dir,
                    check=True,
                    capture_output=True,
                )
                click.echo('Postgres and Redis started successfully!')
            except subprocess.CalledProcessError as e:
                click.echo(f'Failed to start services: {e.stderr.decode()}', err=True)
            except FileNotFoundError:
                click.echo('Docker not found. Please start the services manually.', err=True)

    click.echo('\nNext steps:')
    click.echo(f'  cd {name}')
    click.echo('  pip install -r requirements.pip')
    click.echo('  python manage.py run')


if __name__ == '__main__':
    main()
