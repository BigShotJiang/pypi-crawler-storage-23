"""Elasticsearch client singleton for the tasks system."""

from elasticsearch import Elasticsearch

from overflask.core.config import Config

_es_client: Elasticsearch | None = None


def get_es_client() -> Elasticsearch:
    """Return a cached Elasticsearch client built from Flask config."""
    global _es_client
    if _es_client is None:
        kwargs = {"hosts": [Config.elasticsearch_url()]}
        if Config.elasticsearch_username():
            kwargs["basic_auth"] = [
                Config.elasticsearch_username(),
                Config.elasticsearch_password(),
            ]
        _es_client = Elasticsearch(**kwargs)
    return _es_client
