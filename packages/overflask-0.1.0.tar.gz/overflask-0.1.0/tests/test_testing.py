"""Tests for overflask.testing — fixture utilities."""

import json
from pathlib import Path

import pytest
from sqlalchemy import String, create_engine
from sqlalchemy.orm import Mapped, mapped_column, Session

from overflask import ModelBase
from overflask.testing.testing import (
    _model_ref,
    create_data_fixture,
    fixture_file,
    load_fixture_files,
)


# ---------------------------------------------------------------------------
# Test models
# ---------------------------------------------------------------------------

class Widget(ModelBase):
    __tablename__ = "test_widgets"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))


# ---------------------------------------------------------------------------
# DB fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def engine():
    engine = create_engine("sqlite:///:memory:")
    ModelBase.metadata.create_all(engine)
    yield engine
    ModelBase.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def session(engine):
    with Session(engine) as s:
        yield s
        s.rollback()


# ---------------------------------------------------------------------------
# TestFixtureFile
# ---------------------------------------------------------------------------

class TestFixtureFile:
    def test_creates_pytest_mark(self):
        mark = fixture_file("fixtures/roles.json")
        assert mark.mark.name == "fixture_file"
        assert mark.mark.kwargs["filenames"] == ("fixtures/roles.json",)

    def test_multiple_files(self):
        mark = fixture_file("a.json", "b.json")
        assert mark.mark.kwargs["filenames"] == ("a.json", "b.json")

    def test_single_file_tuple(self):
        mark = fixture_file("only.json")
        assert len(mark.mark.kwargs["filenames"]) == 1


# ---------------------------------------------------------------------------
# TestLoadFixtureFiles
# ---------------------------------------------------------------------------

class TestLoadFixtureFiles:
    def _fixture_path(self, tmp_path, data):
        f = tmp_path / "fixture.json"
        f.write_text(json.dumps(data))
        return f

    def test_loads_records(self, session, tmp_path, monkeypatch):
        data = [{"model": "test.Widget", "records": [
            {"id": 1, "name": "foo"},
            {"id": 2, "name": "bar"},
        ]}]
        path = self._fixture_path(tmp_path, data)
        monkeypatch.setattr("overflask.testing.testing._resolve_model", lambda ref: Widget)

        result = load_fixture_files([path], session)

        assert len(result) == 2
        assert result[0].name == "foo"
        assert result[1].name == "bar"

    def test_returns_model_instances(self, session, tmp_path, monkeypatch):
        data = [{"model": "test.Widget", "records": [{"id": 3, "name": "baz"}]}]
        path = self._fixture_path(tmp_path, data)
        monkeypatch.setattr("overflask.testing.testing._resolve_model", lambda ref: Widget)

        result = load_fixture_files([path], session)

        assert isinstance(result[0], Widget)

    def test_multiple_files_merged(self, session, tmp_path, monkeypatch):
        f1 = tmp_path / "a.json"
        f1.write_text(json.dumps([{"model": "x.Widget", "records": [{"id": 4, "name": "a"}]}]))
        f2 = tmp_path / "b.json"
        f2.write_text(json.dumps([{"model": "x.Widget", "records": [{"id": 5, "name": "b"}]}]))
        monkeypatch.setattr("overflask.testing.testing._resolve_model", lambda ref: Widget)

        result = load_fixture_files([f1, f2], session)

        assert len(result) == 2
        names = {r.name for r in result}
        assert names == {"a", "b"}

    def test_inserts_into_session(self, session, tmp_path, monkeypatch):
        data = [{"model": "test.Widget", "records": [{"id": 6, "name": "persisted"}]}]
        path = self._fixture_path(tmp_path, data)
        monkeypatch.setattr("overflask.testing.testing._resolve_model", lambda ref: Widget)

        load_fixture_files([path], session)

        fetched = session.get(Widget, 6)
        assert fetched is not None
        assert fetched.name == "persisted"


# ---------------------------------------------------------------------------
# TestModelRef
# ---------------------------------------------------------------------------

class TestModelRef:
    def _fake_instance(self, module: str, class_name: str):
        cls = type(class_name, (), {"__module__": module})
        return cls()

    def test_simple_component_module(self):
        instance = self._fake_instance("components.auth.models", "Role")
        assert _model_ref(instance) == "auth.Role"

    def test_nested_models_package(self):
        instance = self._fake_instance("components.auth.models.user", "User")
        assert _model_ref(instance) == "auth.User"

    def test_component_name_used(self):
        instance = self._fake_instance("components.billing.models", "Invoice")
        assert _model_ref(instance) == "billing.Invoice"


# ---------------------------------------------------------------------------
# TestCreateDataFixture
# ---------------------------------------------------------------------------

class TestCreateDataFixture:
    def _fake_inspect(self, fake_file: str):
        """Return a fake inspect module whose stack() points at fake_file."""
        class FakeInspect:
            @staticmethod
            def stack():
                frame = type("FrameInfo", (), {"filename": fake_file})()
                return [None, frame]  # [0]=create_data_fixture, [1]=caller
        return FakeInspect

    def test_raises_outside_components(self, tmp_path, monkeypatch):
        fake_file = str(tmp_path / "tests" / "test_views.py")
        monkeypatch.setattr(
            "overflask.testing.testing.inspect",
            self._fake_inspect(fake_file),
        )
        with pytest.raises(RuntimeError, match="components"):
            create_data_fixture([Widget(id=1, name="x")], "fixtures/out.json")

    def test_writes_json_to_file(self, tmp_path, monkeypatch):
        caller_dir = tmp_path / "components" / "shop" / "tests"
        caller_dir.mkdir(parents=True)
        fake_file = str(caller_dir / "test_views.py")

        monkeypatch.setattr(
            "overflask.testing.testing.inspect",
            self._fake_inspect(fake_file),
        )
        monkeypatch.setattr("overflask.testing.testing._model_ref", lambda inst: "shop.Widget")

        widget = Widget(id=10, name="sprocket")
        create_data_fixture([widget], "fixtures/widgets.json")

        out = caller_dir / "fixtures" / "widgets.json"
        assert out.exists()
        data = json.loads(out.read_text())
        assert data[0]["model"] == "shop.Widget"
        assert data[0]["records"][0]["name"] == "sprocket"

    def test_groups_by_model(self, tmp_path, monkeypatch):
        caller_dir = tmp_path / "components" / "shop" / "tests"
        caller_dir.mkdir(parents=True)
        fake_file = str(caller_dir / "test_views.py")

        monkeypatch.setattr(
            "overflask.testing.testing.inspect",
            self._fake_inspect(fake_file),
        )
        monkeypatch.setattr("overflask.testing.testing._model_ref", lambda inst: "shop.Widget")

        widgets = [Widget(id=1, name="a"), Widget(id=2, name="b")]
        create_data_fixture(widgets, "fixtures/many.json")

        data = json.loads((caller_dir / "fixtures" / "many.json").read_text())
        assert len(data) == 1  # one group
        assert len(data[0]["records"]) == 2

    def test_creates_parent_directories(self, tmp_path, monkeypatch):
        caller_dir = tmp_path / "components" / "shop" / "tests"
        caller_dir.mkdir(parents=True)
        fake_file = str(caller_dir / "test_views.py")

        monkeypatch.setattr(
            "overflask.testing.testing.inspect",
            self._fake_inspect(fake_file),
        )
        monkeypatch.setattr("overflask.testing.testing._model_ref", lambda inst: "shop.Widget")

        # fixtures/nested/ does not exist — create_data_fixture must create it.
        create_data_fixture([Widget(id=3, name="c")], "fixtures/nested/out.json")

        assert (caller_dir / "fixtures" / "nested" / "out.json").exists()
