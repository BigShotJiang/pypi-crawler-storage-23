"""Tests for the overflask tasks system."""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest
from flask import Flask


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def app():
    """Flask app in testing mode."""
    flask_app = Flask(__name__)
    flask_app.config.update({
        "TESTING": True,
        "PROJECT_NAME": "testproject",
        "COMPONENTS": [],
        "ELASTICSEARCH_URL": "http://localhost:9200",
        "ELASTICSEARCH_USERNAME": "",
        "ELASTICSEARCH_PASSWORD": "",
        "TASKS_REGISTERED_RETENTION_DAYS": 7,
        "TASKS_DISPATCHED_RETENTION_DAYS": 7,
        "TASKS_COMPLETED_RETENTION_DAYS": 7,
        "TASKS_METRICS_RETENTION_DAYS": 365,
    })
    return flask_app


@pytest.fixture
def app_ctx(app):
    """Active Flask application context (TESTING=True)."""
    with app.app_context():
        yield app


@pytest.fixture
def prod_app():
    """Flask app with TESTING=False for tests that exercise the ES path."""
    flask_app = Flask(__name__)
    flask_app.config.update({
        "TESTING": False,
        "PROJECT_NAME": "testproject",
        "COMPONENTS": [],
        "ELASTICSEARCH_URL": "http://localhost:9200",
        "ELASTICSEARCH_USERNAME": "",
        "ELASTICSEARCH_PASSWORD": "",
        "TASKS_REGISTERED_RETENTION_DAYS": 7,
        "TASKS_DISPATCHED_RETENTION_DAYS": 7,
        "TASKS_COMPLETED_RETENTION_DAYS": 7,
        "TASKS_METRICS_RETENTION_DAYS": 365,
    })
    return flask_app


@pytest.fixture
def prod_ctx(prod_app):
    """Active Flask application context (TESTING=False)."""
    with prod_app.app_context():
        yield prod_app


@pytest.fixture
def mock_es():
    """Shared MagicMock ES client patched into all task modules."""
    es = MagicMock()
    with (
        patch("overflask.tasks.task_store.get_es_client", return_value=es),
        patch("overflask.tasks.metrics.get_es_client", return_value=es),
        patch("overflask.tasks.es_index_templates.get_es_client", return_value=es),
    ):
        yield es


@pytest.fixture(autouse=True)
def _clear_registry():
    """Isolate CallableRegistry state across tests."""
    from overflask.tasks.callable_registry import CallableRegistry
    CallableRegistry.registry.clear()
    yield
    CallableRegistry.registry.clear()


@pytest.fixture(autouse=True)
def _clear_queued():
    """Isolate TaskStore.queued state across tests."""
    from overflask.tasks.task_store import TaskStore
    TaskStore.queued.clear()
    yield
    TaskStore.queued.clear()


# ---------------------------------------------------------------------------
# TestTasksDecorators
# ---------------------------------------------------------------------------

class TestTasksDecorators:

    def test_async_task_returns_callable_wrapper(self):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.callable_wrapper import CallableWrapper

        @async_task
        def my_task(x: str) -> None:
            pass

        assert isinstance(my_task, CallableWrapper)

    def test_async_task_registers_in_registry(self):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.callable_registry import CallableRegistry

        @async_task
        def my_task(x: str) -> None:
            pass

        assert len(CallableRegistry.registry) == 1
        assert CallableRegistry.registry[0].fn is my_task.fn

    def test_async_task_cron_is_empty_string(self):
        from overflask.tasks.tasks import async_task

        @async_task
        def my_task(x: str) -> None:
            pass

        assert my_task.cron == ''

    def test_async_task_missing_annotation_raises_type_error(self):
        from overflask.tasks.tasks import async_task

        with pytest.raises(TypeError, match="unannotated"):
            @async_task
            def bad_task(unannotated):
                pass

    def test_recurring_task_sets_cron(self):
        from overflask.tasks.tasks import recurring_task
        from overflask.tasks.callable_registry import CallableRegistry

        @recurring_task("0 * * * *")
        def my_task() -> None:
            pass

        assert len(CallableRegistry.registry) == 1
        assert my_task.cron == "0 * * * *"

    def test_recurring_task_missing_annotation_raises_type_error(self):
        from overflask.tasks.tasks import recurring_task

        with pytest.raises(TypeError, match="unannotated"):
            @recurring_task("0 * * * *")
            def bad_task(unannotated):
                pass

    def test_zero_param_function_succeeds(self):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.callable_registry import CallableRegistry

        @async_task
        def no_params() -> None:
            pass

        assert len(CallableRegistry.registry) == 1


# ---------------------------------------------------------------------------
# TestCallableWrapperQueue
# ---------------------------------------------------------------------------

class TestCallableWrapperQueue:

    def test_missing_required_param_raises_value_error(self, app_ctx):
        from overflask.tasks.tasks import async_task

        @async_task
        def send_email(to: str) -> None:
            pass

        with pytest.raises(ValueError):
            send_email.queue()

    def test_unexpected_kwarg_raises_value_error(self, app_ctx):
        from overflask.tasks.tasks import async_task

        @async_task
        def send_email(to: str) -> None:
            pass

        with pytest.raises(ValueError):
            send_email.queue(to="a@b.com", unknown_param="x")

    def test_when_wrong_type_raises_value_error(self, app_ctx):
        from overflask.tasks.tasks import async_task

        @async_task
        def send_email(to: str) -> None:
            pass

        with pytest.raises(ValueError, match="when"):
            send_email.queue(42, to="a@b.com")

    def test_non_json_serializable_arg_raises_value_error(self, app_ctx):
        from overflask.tasks.tasks import async_task

        @async_task
        def my_task(obj: object) -> None:
            pass

        with pytest.raises(ValueError, match="JSON"):
            my_task.queue(obj=object())

    def test_wrong_type_raises_type_error(self, app_ctx):
        from overflask.tasks.tasks import async_task

        @async_task
        def my_task(count: int) -> None:
            pass

        with pytest.raises(TypeError):
            my_task.queue(count="not_an_int")

    def test_valid_call_produces_correct_task_doc(self, app_ctx):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.task_store import TaskStore

        @async_task
        def send_email(to: str, subject: str) -> None:
            pass

        task_id = send_email.queue(to="a@b.com", subject="Hi")

        assert isinstance(task_id, int)
        assert len(TaskStore.queued) == 1
        doc = TaskStore.queued[0]
        assert doc["id"] == task_id
        assert doc["function"].endswith(".send_email")
        assert doc["kwargs"] == {"to": "a@b.com", "subject": "Hi"}
        assert doc["type"] == "async"
        assert doc["cron"] is None

    def test_when_none_sets_type_async(self, app_ctx):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        my_task.queue(x="hello")
        assert TaskStore.queued[0]["type"] == "async"

    def test_when_timedelta_sets_run_at_and_type_run_at(self, app_ctx):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        before = datetime.now(tz=timezone.utc)
        my_task.queue(timedelta(hours=2), x="hello")
        after = datetime.now(tz=timezone.utc)

        doc = TaskStore.queued[0]
        assert doc["type"] == "run_at"
        run_at = datetime.fromisoformat(doc["run_at"])
        assert before + timedelta(hours=2) <= run_at <= after + timedelta(hours=2)

    def test_when_datetime_uses_exact_run_at(self, app_ctx):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        target = datetime(2026, 6, 1, 9, 0, tzinfo=timezone.utc)
        my_task.queue(target, x="hello")

        doc = TaskStore.queued[0]
        assert doc["type"] == "run_at"
        assert datetime.fromisoformat(doc["run_at"]) == target

    def test_key_is_stored_in_task_doc(self, app_ctx):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        my_task.queue(x="hello", key="my-key")
        assert TaskStore.queued[0]["key"] == "my-key"

    def test_return_value_is_int(self, app_ctx):
        from overflask.tasks.tasks import async_task

        @async_task
        def my_task(x: str) -> None:
            pass

        result = my_task.queue(x="hello")
        assert isinstance(result, int)


# ---------------------------------------------------------------------------
# TestTasksTestingMode
# ---------------------------------------------------------------------------

class TestTasksTestingMode:

    def test_queue_appends_to_store_queued(self, app_ctx):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        my_task.queue(x="hello")
        assert len(TaskStore.queued) == 1

    def test_multiple_queue_calls_accumulate(self, app_ctx):
        from overflask.tasks.tasks import async_task
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        my_task.queue(x="one")
        my_task.queue(x="two")
        my_task.queue(x="three")
        assert len(TaskStore.queued) == 3

    def test_delete_removes_matching_key(self, app_ctx):
        from overflask.tasks.tasks import async_task, delete
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        my_task.queue(x="hello", key="batch-1")
        assert len(TaskStore.queued) == 1
        delete(key="batch-1")
        assert len(TaskStore.queued) == 0

    def test_delete_nonmatching_key_leaves_queued_unchanged(self, app_ctx):
        from overflask.tasks.tasks import async_task, delete
        from overflask.tasks.task_store import TaskStore

        @async_task
        def my_task(x: str) -> None:
            pass

        my_task.queue(x="hello", key="batch-1")
        delete(key="other-key")
        assert len(TaskStore.queued) == 1


# ---------------------------------------------------------------------------
# TestTaskStore
# ---------------------------------------------------------------------------

class TestTaskStore:

    def test_ensure_creates_four_index_templates(self, prod_ctx, mock_es):
        from overflask.tasks.es_index_templates import EsIndexTemplates

        EsIndexTemplates.ensure()

        assert mock_es.indices.put_index_template.call_count == 4

    def test_ensure_is_idempotent(self, prod_ctx, mock_es):
        from overflask.tasks.es_index_templates import EsIndexTemplates

        EsIndexTemplates.ensure()
        EsIndexTemplates.ensure()

        assert mock_es.indices.put_index_template.call_count == 8

    def test_persist_indexes_into_registered(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        task_doc = {
            "id": 12345,
            "type": "async",
            "function": "components.auth.tasks.send_email",
            "kwargs": {"to": "a@b.com"},
            "run_at": "2026-03-01T09:00:00+00:00",
        }
        TaskStore.persist(task_doc)

        mock_es.index.assert_called_once()
        call_kwargs = mock_es.index.call_args.kwargs
        assert call_kwargs["id"] == 12345
        assert "testproject_tasks_registered-" in call_kwargs["index"]

    def test_claim_batch_stamps_batch_id_then_searches(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        mock_es.search.return_value = {"hits": {"hits": []}}

        now = datetime.now(tz=timezone.utc)
        result = TaskStore.claim_batch(now, batch_id=42, batch_size=10)

        mock_es.update_by_query.assert_called_once()
        mock_es.search.assert_called_once()
        assert result == []

    def test_claim_batch_returns_id_doc_pairs(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        source = {"id": 99, "type": "async", "function": "fn"}
        mock_es.search.return_value = {"hits": {"hits": [{"_source": source}]}}

        now = datetime.now(tz=timezone.utc)
        result = TaskStore.claim_batch(now, batch_id=1, batch_size=10)

        assert result == [(99, source)]

    def test_move_to_dispatched_indexes_and_deletes_from_registered(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        task_doc = {"id": 99, "type": "async", "function": "test.fn"}
        TaskStore.move_to_dispatched(99, task_doc)

        mock_es.index.assert_called_once()
        index_kwargs = mock_es.index.call_args.kwargs
        assert "testproject_tasks_dispatched-" in index_kwargs["index"]
        assert "dispatched_at" in index_kwargs["document"]

        mock_es.delete_by_query.assert_called_once()
        del_kwargs = mock_es.delete_by_query.call_args.kwargs
        assert del_kwargs.get("conflicts") == "proceed"
        assert "testproject_tasks_registered-*" in del_kwargs["index"]

    def test_mark_completed_moves_doc_to_completed(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        mock_es.search.return_value = {
            "hits": {
                "hits": [{
                    "_index": "testproject_tasks_dispatched-2026.03",
                    "_id": "99",
                    "_source": {"id": 99, "type": "async"},
                }]
            }
        }

        TaskStore.mark_completed(99)

        mock_es.index.assert_called_once()
        assert "completed_at" in mock_es.index.call_args.kwargs["document"]
        mock_es.delete.assert_called_once_with(
            index="testproject_tasks_dispatched-2026.03",
            id="99",
        )

    def test_mark_completed_is_noop_when_task_not_found(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        mock_es.search.return_value = {"hits": {"hits": []}}

        TaskStore.mark_completed(99)

        mock_es.index.assert_not_called()
        mock_es.delete.assert_not_called()

    def test_record_failure_updates_dispatched_doc(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        mock_es.search.return_value = {
            "hits": {
                "hits": [{
                    "_index": "testproject_tasks_dispatched-2026.03",
                    "_id": "99",
                    "_source": {},
                }]
            }
        }

        try:
            raise ValueError("something went wrong")
        except ValueError as exc:
            TaskStore.record_failure(99, exc)

        mock_es.update.assert_called_once()
        update_kwargs = mock_es.update.call_args.kwargs
        assert update_kwargs["index"] == "testproject_tasks_dispatched-2026.03"
        assert update_kwargs["doc"]["error"] == "something went wrong"
        assert "failed_at" in update_kwargs["doc"]
        assert "error_traceback" in update_kwargs["doc"]

    def test_delete_by_key_queries_all_three_lifecycle_patterns(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        TaskStore.delete_by_key("batch-1")

        assert mock_es.delete_by_query.call_count == 3
        indices = {call.kwargs["index"] for call in mock_es.delete_by_query.call_args_list}
        assert "testproject_tasks_registered-*" in indices
        assert "testproject_tasks_dispatched-*" in indices
        assert "testproject_tasks_completed-*" in indices

    def test_get_dispatched_returns_source_doc(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        source = {"id": 42, "function": "components.auth.tasks.send_email"}
        mock_es.search.return_value = {"hits": {"hits": [{"_source": source}]}}

        result = TaskStore.get_dispatched(42)
        assert result == source

    def test_get_dispatched_returns_none_when_not_found(self, prod_ctx, mock_es):
        from overflask.tasks.task_store import TaskStore

        mock_es.search.return_value = {"hits": {"hits": []}}

        result = TaskStore.get_dispatched(42)
        assert result is None

    def test_metrics_record_counts_three_groups(self, prod_ctx, mock_es):
        from overflask.tasks.metrics import Metrics

        mock_es.count.return_value = {"count": 5}

        Metrics.record()

        assert mock_es.count.call_count == 3
        mock_es.index.assert_called_once()
        doc = mock_es.index.call_args.kwargs["document"]
        assert doc["registered_count"] == 5
        assert doc["dispatched_count"] == 5
        assert doc["completed_count"] == 5
        assert "timestamp" in doc

    def test_metrics_purge_deletes_old_indices_leaves_recent(self, prod_ctx, mock_es):
        from overflask.tasks.metrics import Metrics

        # Only mock the registered prefix — other prefixes return empty dicts
        def get_indices(index, **kwargs):
            if "registered" in index:
                return {
                    "testproject_tasks_registered-2020.01": {},
                    "testproject_tasks_registered-2025.12": {},
                    "testproject_tasks_registered-2026.03": {},
                }
            return {}

        mock_es.indices.get.side_effect = get_indices

        Metrics.purge_old()

        deleted = [call.kwargs["index"] for call in mock_es.indices.delete.call_args_list]
        assert "testproject_tasks_registered-2020.01" in deleted
        assert "testproject_tasks_registered-2025.12" in deleted
        assert "testproject_tasks_registered-2026.03" not in deleted

    def test_sync_recurring_deletes_old_and_reinserts_from_registry(self, prod_ctx, mock_es):
        from overflask.tasks.tasks import recurring_task
        from overflask.tasks.task_store import TaskStore

        @recurring_task("0 9 * * MON-FRI")
        def daily_report() -> None:
            pass

        TaskStore.sync_recurring()

        mock_es.delete_by_query.assert_called_once()
        mock_es.index.assert_called_once()
        doc = mock_es.index.call_args.kwargs["document"]
        assert doc["function"].endswith(".daily_report")
        assert doc["type"] == "recurring"
        assert doc["cron"] == "0 9 * * MON-FRI"


# ---------------------------------------------------------------------------
# TestSchedulerLoop
# ---------------------------------------------------------------------------

class TestSchedulerLoop:

    def test_due_task_dispatched_and_pushed_to_redis(self, app_ctx):
        from overflask.tasks import scheduler

        task_doc = {
            "id": 42,
            "type": "async",
            "function": "components.auth.tasks.fn",
            "kwargs": {},
            "cron": None,
            "run_at": "2026-01-01T00:00:00+00:00",
        }
        mock_redis = MagicMock()

        with (
            patch("overflask.tasks.scheduler.TaskStore.claim_batch", return_value=[(42, task_doc)]),
            patch("overflask.tasks.scheduler.TaskStore.move_to_dispatched") as mock_dispatch,
            patch("overflask.tasks.scheduler.TaskStore.persist"),
            patch("overflask.tasks.scheduler.get_redis", return_value=mock_redis),
            patch("overflask.tasks.scheduler.time.sleep", side_effect=KeyboardInterrupt),
        ):
            with pytest.raises(KeyboardInterrupt):
                scheduler._loop()

        mock_dispatch.assert_called_once_with(42, task_doc)
        mock_redis.rpush.assert_called_once_with("testproject:tasks:queue", 42)

    def test_empty_batch_does_not_dispatch(self, app_ctx):
        from overflask.tasks import scheduler

        mock_redis = MagicMock()

        with (
            patch("overflask.tasks.scheduler.TaskStore.claim_batch", return_value=[]),
            patch("overflask.tasks.scheduler.TaskStore.move_to_dispatched") as mock_dispatch,
            patch("overflask.tasks.scheduler.get_redis", return_value=mock_redis),
            patch("overflask.tasks.scheduler.time.sleep", side_effect=KeyboardInterrupt),
        ):
            with pytest.raises(KeyboardInterrupt):
                scheduler._loop()

        mock_dispatch.assert_not_called()
        mock_redis.rpush.assert_not_called()

    def test_recurring_task_creates_successor_after_dispatch(self, app_ctx):
        from overflask.tasks import scheduler

        task_doc = {
            "id": 42,
            "type": "recurring",
            "function": "components.tasks.fn",
            "kwargs": {},
            "cron": "0 9 * * MON-FRI",
            "run_at": "2026-01-01T09:00:00+00:00",
        }
        mock_redis = MagicMock()

        with (
            patch("overflask.tasks.scheduler.TaskStore.claim_batch", return_value=[(42, task_doc)]),
            patch("overflask.tasks.scheduler.TaskStore.move_to_dispatched"),
            patch("overflask.tasks.scheduler.TaskStore.persist") as mock_persist,
            patch("overflask.tasks.scheduler.get_redis", return_value=mock_redis),
            patch("overflask.tasks.scheduler.time.sleep", side_effect=KeyboardInterrupt),
        ):
            with pytest.raises(KeyboardInterrupt):
                scheduler._loop()

        mock_persist.assert_called_once()
        successor = mock_persist.call_args.args[0]
        assert successor["function"] == "components.tasks.fn"
        assert successor["cron"] == "0 9 * * MON-FRI"
        assert successor["type"] == "recurring"

    def test_recurring_successor_failure_does_not_prevent_dispatch(self, app_ctx):
        from overflask.tasks import scheduler

        task_doc = {
            "id": 42,
            "type": "recurring",
            "function": "components.tasks.fn",
            "kwargs": {},
            "cron": "0 9 * * MON-FRI",
            "run_at": "2026-01-01T09:00:00+00:00",
        }
        mock_redis = MagicMock()

        with (
            patch("overflask.tasks.scheduler.TaskStore.claim_batch", return_value=[(42, task_doc)]),
            patch("overflask.tasks.scheduler.TaskStore.move_to_dispatched"),
            patch("overflask.tasks.scheduler.TaskStore.persist", side_effect=Exception("ES down")),
            patch("overflask.tasks.scheduler.get_redis", return_value=mock_redis),
            patch("overflask.tasks.scheduler.time.sleep", side_effect=KeyboardInterrupt),
        ):
            with pytest.raises(KeyboardInterrupt):
                scheduler._loop()

        # rpush happened before _schedule_next raised
        mock_redis.rpush.assert_called_once_with("testproject:tasks:queue", 42)

    def test_metrics_recorded_after_60_seconds(self, app_ctx):
        from overflask.tasks import scheduler

        mock_redis = MagicMock()

        with (
            patch("overflask.tasks.scheduler.TaskStore.claim_batch", return_value=[]),
            patch("overflask.tasks.scheduler.get_redis", return_value=mock_redis),
            patch("overflask.tasks.scheduler.Metrics.record") as mock_record,
            patch("overflask.tasks.scheduler.Metrics.purge_old"),
            patch("overflask.tasks.scheduler.time.monotonic", side_effect=[0, 0, 61]),
            patch("overflask.tasks.scheduler.time.sleep", side_effect=KeyboardInterrupt),
        ):
            with pytest.raises(KeyboardInterrupt):
                scheduler._loop()

        mock_record.assert_called_once()

    def test_purge_called_after_one_day(self, app_ctx):
        from overflask.tasks import scheduler

        mock_redis = MagicMock()

        with (
            patch("overflask.tasks.scheduler.TaskStore.claim_batch", return_value=[]),
            patch("overflask.tasks.scheduler.get_redis", return_value=mock_redis),
            patch("overflask.tasks.scheduler.Metrics.record"),
            patch("overflask.tasks.scheduler.Metrics.purge_old") as mock_purge,
            patch("overflask.tasks.scheduler.time.monotonic", side_effect=[0, 0, 86401]),
            patch("overflask.tasks.scheduler.time.sleep", side_effect=KeyboardInterrupt),
        ):
            with pytest.raises(KeyboardInterrupt):
                scheduler._loop()

        mock_purge.assert_called_once()


# ---------------------------------------------------------------------------
# TestWorkerLoop
# ---------------------------------------------------------------------------

class TestWorkerLoop:

    def test_task_executed_and_marked_completed(self, app_ctx):
        from overflask.tasks import worker

        calls = []

        def mock_fn(**kwargs):
            calls.append(kwargs)

        task_doc = {"id": 42, "function": "some.module.fn", "kwargs": {"x": "hello"}}
        mock_redis = MagicMock()
        mock_redis.blpop.side_effect = [("queue", b"42"), KeyboardInterrupt]

        with (
            patch("overflask.tasks.worker.get_redis", return_value=mock_redis),
            patch("overflask.tasks.worker.TaskStore.get_dispatched", return_value=task_doc),
            patch("overflask.tasks.worker.TaskStore.mark_completed") as mock_complete,
            patch("overflask.tasks.worker.TaskStore.record_failure"),
            patch("overflask.tasks.worker._resolve", return_value=mock_fn),
        ):
            with pytest.raises(KeyboardInterrupt):
                worker._loop()

        assert calls == [{"x": "hello"}]
        mock_complete.assert_called_once_with(42)

    def test_exception_calls_record_failure_not_mark_completed(self, app_ctx):
        from overflask.tasks import worker

        def failing_fn(**kwargs):
            raise RuntimeError("boom")

        task_doc = {"id": 42, "function": "some.module.fn", "kwargs": {}}
        mock_redis = MagicMock()
        mock_redis.blpop.side_effect = [("queue", b"42"), KeyboardInterrupt]

        with (
            patch("overflask.tasks.worker.get_redis", return_value=mock_redis),
            patch("overflask.tasks.worker.TaskStore.get_dispatched", return_value=task_doc),
            patch("overflask.tasks.worker.TaskStore.mark_completed") as mock_complete,
            patch("overflask.tasks.worker.TaskStore.record_failure") as mock_failure,
            patch("overflask.tasks.worker._resolve", return_value=failing_fn),
        ):
            with pytest.raises(KeyboardInterrupt):
                worker._loop()

        mock_failure.assert_called_once()
        assert isinstance(mock_failure.call_args.args[1], RuntimeError)
        mock_complete.assert_not_called()

    def test_blpop_timeout_continues_loop(self, app_ctx):
        from overflask.tasks import worker

        mock_redis = MagicMock()
        mock_redis.blpop.side_effect = [None, None, KeyboardInterrupt]

        with (
            patch("overflask.tasks.worker.get_redis", return_value=mock_redis),
            patch("overflask.tasks.worker.TaskStore.mark_completed") as mock_complete,
        ):
            with pytest.raises(KeyboardInterrupt):
                worker._loop()

        mock_complete.assert_not_called()

    def test_task_not_found_in_dispatched_is_skipped(self, app_ctx):
        from overflask.tasks import worker

        mock_redis = MagicMock()
        mock_redis.blpop.side_effect = [("queue", b"42"), KeyboardInterrupt]

        with (
            patch("overflask.tasks.worker.get_redis", return_value=mock_redis),
            patch("overflask.tasks.worker.TaskStore.get_dispatched", return_value=None),
            patch("overflask.tasks.worker.TaskStore.mark_completed") as mock_complete,
            patch("overflask.tasks.worker._resolve") as mock_resolve,
        ):
            with pytest.raises(KeyboardInterrupt):
                worker._loop()

        mock_resolve.assert_not_called()
        mock_complete.assert_not_called()

    def test_resolve_imports_function_by_dotted_path(self, app_ctx):
        import os.path
        from overflask.tasks.worker import _resolve

        fn = _resolve("os.path.join")
        assert fn is os.path.join
