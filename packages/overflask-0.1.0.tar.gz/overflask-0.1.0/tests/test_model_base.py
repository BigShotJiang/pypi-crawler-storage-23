"""Tests for ModelBase — table naming, serialization."""

import json
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from uuid import UUID

import pytest
from sqlalchemy import ForeignKey, String, create_engine
from sqlalchemy.orm import Mapped, mapped_column, relationship, Session

from overflask import ModelBase
from overflask.db.model_base import _pluralize, _to_snake_case


# ---------------------------------------------------------------------------
# Test models
# ---------------------------------------------------------------------------

class Role(ModelBase):
    __tablename__ = "test_roles"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
    users: Mapped[list["User"]] = relationship(back_populates="role")


class User(ModelBase):
    __tablename__ = "test_users"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    role_id: Mapped[int | None] = mapped_column(ForeignKey("test_roles.id"), nullable=True)
    role: Mapped["Role | None"] = relationship(back_populates="users")


class TypeSampler(ModelBase):
    """Model with varied column types for serialization tests."""
    __tablename__ = "test_type_samplers"
    id: Mapped[int] = mapped_column(primary_key=True)
    dt: Mapped[datetime | None] = mapped_column(nullable=True)
    d: Mapped[date | None] = mapped_column(nullable=True)
    uid: Mapped[str | None] = mapped_column(String(36), nullable=True)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def engine():
    engine = create_engine("sqlite:///:memory:")
    ModelBase.metadata.create_all(engine)
    yield engine
    ModelBase.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def session(engine):
    with Session(engine) as s:
        yield s
        s.rollback()


# ---------------------------------------------------------------------------
# TestToJsonObject
# ---------------------------------------------------------------------------

class TestToJsonObject:
    def test_basic_columns(self, session):
        role = Role(id=1, name="admin")
        session.add(role)
        session.flush()

        result = role.to_json_object()
        assert result["id"] == 1
        assert result["name"] == "admin"

    def test_none_value(self, session):
        user = User(id=1, name="alice", role_id=None)
        session.add(user)
        session.flush()

        result = user.to_json_object()
        assert result["role_id"] is None

    def test_datetime_serialized_to_iso(self):
        dt = datetime(2024, 6, 15, 12, 30, 0)
        sampler = TypeSampler(id=1, dt=dt)
        assert sampler.to_json_object()["dt"] == "2024-06-15T12:30:00"

    def test_date_serialized_to_iso(self):
        d = date(2024, 6, 15)
        sampler = TypeSampler(id=2, d=d)
        assert sampler.to_json_object()["d"] == "2024-06-15"

    def test_unloaded_relationship_skipped(self, session):
        role = Role(id=2, name="user")
        user = User(id=2, name="bob", role_id=2)
        session.add_all([role, user])
        session.flush()
        session.expire(user)  # expire to simulate unloaded state

        result = user.to_json_object()
        assert "role" not in result

    def test_loaded_single_relationship_as_pk(self, session):
        role = Role(id=3, name="editor")
        user = User(id=3, name="carol", role=role)
        session.add_all([role, user])
        session.flush()

        result = user.to_json_object()
        assert result["role"] == 3

    def test_loaded_plural_relationship_as_pk_list(self, session):
        role = Role(id=4, name="viewer")
        u1 = User(id=4, name="dave", role=role)
        u2 = User(id=5, name="eve", role=role)
        session.add_all([role, u1, u2])
        session.flush()

        result = role.to_json_object()
        assert sorted(result["users"]) == [4, 5]

    def test_none_relationship(self, session):
        user = User(id=6, name="frank", role=None)
        session.add(user)
        session.flush()
        # Explicitly load the relationship as None
        _ = user.role

        result = user.to_json_object()
        assert result["role"] is None


# ---------------------------------------------------------------------------
# TestFromJsonObject
# ---------------------------------------------------------------------------

class TestFromJsonObject:
    def test_from_dict(self):
        user = User.from_json_object({"id": 1, "name": "alice", "role_id": None})
        assert user.name == "alice"
        assert user.role_id is None

    def test_from_json_string(self):
        data = json.dumps({"id": 2, "name": "bob", "role_id": 1})
        user = User.from_json_object(data)
        assert user.name == "bob"
        assert user.role_id == 1

    def test_unknown_keys_ignored(self):
        user = User.from_json_object({"id": 1, "name": "alice", "unknown": "ignored"})
        assert not hasattr(user, "unknown")

    def test_relationship_keys_ignored(self):
        user = User.from_json_object({"id": 1, "name": "alice", "role": 5})
        assert not hasattr(user, "role") or user.__dict__.get("role") is None


# ---------------------------------------------------------------------------
# TestPluralize
# ---------------------------------------------------------------------------

class TestPluralize:
    def test_regular_word(self):
        assert _pluralize("user") == "users"

    def test_ends_in_s(self):
        assert _pluralize("bus") == "buses"

    def test_ends_in_x(self):
        assert _pluralize("box") == "boxes"

    def test_ends_in_z(self):
        assert _pluralize("quiz") == "quizes"

    def test_ends_in_ch(self):
        assert _pluralize("match") == "matches"

    def test_ends_in_sh(self):
        assert _pluralize("wish") == "wishes"

    def test_ends_in_y_with_consonant(self):
        assert _pluralize("category") == "categories"

    def test_ends_in_y_with_vowel(self):
        assert _pluralize("day") == "days"

    def test_compound_word(self):
        assert _pluralize("user_role") == "user_roles"


# ---------------------------------------------------------------------------
# TestToSnakeCase
# ---------------------------------------------------------------------------

class TestToSnakeCase:
    def test_simple(self):
        assert _to_snake_case("User") == "user"

    def test_compound(self):
        assert _to_snake_case("UserRole") == "user_role"

    def test_acronym(self):
        assert _to_snake_case("HTTPResponse") == "http_response"

    def test_already_snake(self):
        assert _to_snake_case("user_role") == "user_role"
