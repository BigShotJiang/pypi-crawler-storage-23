# HogQL Parser

Blazing fast HogQL parsing. This package can only work in the context of the PostHog Django app, as it imports from `posthog.hogql`.

You can test changes locally by running `pip install ./hogql_parser`
