# import core modules
from OntologyToAPI.core.APIGenerator import APIGenerator
from OntologyToAPI.core.Ontology import Ontology
from OntologyToAPI.core.Queries import *
from OntologyToAPI.core.Utility import *