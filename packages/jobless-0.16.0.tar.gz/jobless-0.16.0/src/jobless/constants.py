from importlib.metadata import version


APP_NAME = "jobless"
APP_VERSION = version(APP_NAME)
