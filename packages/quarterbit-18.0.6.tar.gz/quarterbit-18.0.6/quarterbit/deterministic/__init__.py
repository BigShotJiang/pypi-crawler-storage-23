"""
quarterbit.deterministic - Cross-Hardware Reproducible PyTorch Operations
==========================================================================

Provides bit-exact operations that produce identical results across different
GPU architectures (T4, RTX 4070, A100, H100, etc.)

Usage:
    from quarterbit.deterministic import ops, functional as F

    # Direct operations
    result = ops.dot(a, b)
    C = ops.matmul(A, B)
    s = ops.sum(x)

    # Functional API (drop-in replacement)
    out = F.linear(x, weight, bias)
    out = F.conv2d(x, weight, bias, stride, padding)

Algorithm: VLA (VIGIL Lossless Arithmetic) with 4-limb accumulator
- TwoSum for exact addition
- TwoProduct (FMA) for exact multiplication
- Order-independent: same result regardless of thread scheduling

Verified cross-hardware reproducible on:
- RTX 4070 (Ada Lovelace, sm_89)
- Tesla T4 (Turing, sm_75)

Copyright (c) 2026 Clouthier Simulation Labs
"""

__version__ = "1.0.0"
__all__ = ['ops', 'functional', 'enable', 'disable', 'is_enabled']

from . import ops
from . import functional

# Global state for monkey-patching
_enabled = False
_original_ops = {}

def enable():
    """Enable deterministic operations by monkey-patching torch functions."""
    global _enabled, _original_ops
    if _enabled:
        return

    import torch
    import torch.nn.functional as F_torch

    # Save originals
    _original_ops['torch.mm'] = torch.mm
    _original_ops['torch.matmul'] = torch.matmul
    _original_ops['torch.sum'] = torch.sum
    _original_ops['F.linear'] = F_torch.linear
    _original_ops['F.softmax'] = F_torch.softmax
    _original_ops['F.log_softmax'] = F_torch.log_softmax
    _original_ops['F.cross_entropy'] = F_torch.cross_entropy

    # Patch with deterministic versions
    torch.mm = ops.matmul
    torch.matmul = ops.matmul
    F_torch.linear = functional.linear  # Critical for nn.Linear!
    F_torch.softmax = functional.softmax
    F_torch.log_softmax = functional.log_softmax
    F_torch.cross_entropy = functional.cross_entropy  # Critical for loss!

    _enabled = True
    print(f"[quarterbit.deterministic] Enabled v{__version__} - F.linear, F.cross_entropy patched")

def disable():
    """Restore original torch operations."""
    global _enabled, _original_ops
    if not _enabled:
        return

    import torch
    import torch.nn.functional as F_torch

    # Restore originals
    torch.mm = _original_ops['torch.mm']
    torch.matmul = _original_ops['torch.matmul']
    torch.sum = _original_ops['torch.sum']
    F_torch.linear = _original_ops['F.linear']
    F_torch.softmax = _original_ops['F.softmax']
    F_torch.log_softmax = _original_ops['F.log_softmax']
    F_torch.cross_entropy = _original_ops['F.cross_entropy']

    _enabled = False
    print("[quarterbit.deterministic] Disabled")

def is_enabled():
    """Check if deterministic mode is enabled."""
    return _enabled
