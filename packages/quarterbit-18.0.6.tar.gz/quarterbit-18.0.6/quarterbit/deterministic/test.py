"""
quarterbit.deterministic - Quick Test
=====================================

Verifies cross-hardware reproducible ops work correctly.
RTX 4070 reference checksums embedded for verification.
"""

import torch
import numpy as np
import hashlib
import struct

from quarterbit.deterministic import ops

def lcg_array(seed, n, dtype=np.float32):
    """Deterministic random array (same on all platforms)."""
    a, c, m = 1103515245, 12345, 2**31
    state = seed
    arr = np.zeros(n, dtype=dtype)
    for i in range(n):
        state = (a * state + c) % m
        arr[i] = (state / m - 0.5) * 2.0
    return arr

def checksum(value):
    """SHA256 checksum of float64 value."""
    return hashlib.sha256(struct.pack('d', float(value))).hexdigest()[:16]

print("=" * 60)
print("quarterbit.deterministic TEST")
print("=" * 60)
print(f"Version: {ops.version()}")
print(f"GPU: {torch.cuda.get_device_name(0)}")
print()

# RTX 4070 reference checksums (cross-hardware targets)
RTX4070_REF = {
    'dot': '8536689162a358a3',
    'sum': '452218f19dc2d5e9',
}

# Test dot product
N = 10000
a = torch.from_numpy(lcg_array(42, N)).cuda()
b = torch.from_numpy(lcg_array(123, N)).cuda()

result = ops.dot(a, b)
cs = checksum(result.item())
match = "MATCH" if cs == RTX4070_REF['dot'] else "DIFFER"
print(f"dot:    {cs} [{match}]")

# Test sum
x = torch.from_numpy(lcg_array(42, N)).cuda()
result = ops.sum(x)
cs = checksum(result.item())
match = "MATCH" if cs == RTX4070_REF['sum'] else "DIFFER"
print(f"sum:    {cs} [{match}]")

# Test matmul (verify it runs, checksum varies with size)
M, K, N_mat = 64, 128, 64
A = torch.from_numpy(lcg_array(42, M*K).reshape(M, K)).cuda()
B = torch.from_numpy(lcg_array(123, K*N_mat).reshape(K, N_mat)).cuda()
C = ops.matmul(A, B)
print(f"matmul: {C.shape} OK")

# Test autograd
A.requires_grad = True
B.requires_grad = True
C = ops.matmul(A, B)
loss = C.sum()
loss.backward()
print(f"autograd: grad_A={A.grad.shape}, grad_B={B.grad.shape} OK")

print()
print("=" * 60)
print("All tests passed!")
print("=" * 60)
