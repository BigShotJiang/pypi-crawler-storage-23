"""
VLA Deterministic Operations - Core CUDA Interface
===================================================

Provides cross-hardware reproducible operations using VLA 4-limb accumulator.

Includes full autograd support for training neural networks with
bit-exact reproducibility across different GPU architectures.
"""

import ctypes
import os
import sys
import torch
from torch.autograd import Function
from typing import Optional, Tuple

# Find and load the CUDA library
_lib = None
_lib_loaded = False

def _load_library():
    """Load the VLA deterministic CUDA library."""
    global _lib, _lib_loaded

    if _lib_loaded:
        return _lib is not None

    # Add CUDA to PATH on Windows
    if sys.platform == 'win32':
        cuda_paths = [
            r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\bin',
            r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6\bin',
            r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.4\bin',
            r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.2\bin',
            r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.0\bin',
            r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8\bin',
        ]
        for cp in cuda_paths:
            if os.path.exists(cp):
                try:
                    os.add_dll_directory(cp)
                except Exception:
                    pass  # May fail on older Python
                break

    # Platform-specific library name
    if sys.platform == 'win32':
        lib_name = 'vla_deterministic.dll'
    else:
        lib_name = 'libvla_deterministic.so'

    # Search paths for library
    search_paths = [
        # In deterministic/lib/ (pip install location)
        os.path.join(os.path.dirname(__file__), 'lib', lib_name),
        # Direct in deterministic folder
        os.path.join(os.path.dirname(__file__), lib_name),
        # In quarterbit/lib/ (legacy)
        os.path.join(os.path.dirname(__file__), '..', 'lib', lib_name),
        # Kaggle build location
        '/kaggle/working/build/libvla_deterministic.so',
        '/kaggle/working/libvla_deterministic.so',
    ]

    for lib_path in search_paths:
        if os.path.exists(lib_path):
            try:
                _lib = ctypes.CDLL(lib_path)

                # Setup function signatures
                _lib.vla_deterministic_dot_fp32.argtypes = [
                    ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int
                ]
                _lib.vla_deterministic_dot_fp32.restype = ctypes.c_double

                _lib.vla_deterministic_sum_fp32.argtypes = [
                    ctypes.c_void_p, ctypes.c_int
                ]
                _lib.vla_deterministic_sum_fp32.restype = ctypes.c_double

                _lib.vla_deterministic_matmul.argtypes = [
                    ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                    ctypes.c_int, ctypes.c_int, ctypes.c_int
                ]
                _lib.vla_deterministic_matmul.restype = None

                _lib.vla_deterministic_version.restype = ctypes.c_char_p

                _lib_loaded = True
                return True
            except Exception as e:
                print(f"[VLA] Failed to load {lib_path}: {e}")
                continue

    _lib_loaded = True  # Mark as attempted even if failed
    return False


def _ensure_loaded():
    """Ensure the library is loaded, raise if not."""
    if not _load_library():
        raise RuntimeError(
            "VLA deterministic library not found. "
            "Build with: nvcc -shared -O3 -o libvla_deterministic.so vla_deterministic.cu"
        )
    return _lib


def version() -> str:
    """Get the VLA library version string."""
    lib = _ensure_loaded()
    return lib.vla_deterministic_version().decode()


# =============================================================================
# RAW CUDA OPERATIONS (internal, no autograd)
# =============================================================================

def _vla_matmul_raw(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """
    Raw VLA matmul without autograd. Internal use only.

    Args:
        A: 2D tensor (M, K), float32, CUDA, contiguous
        B: 2D tensor (K, N), float32, CUDA, contiguous

    Returns:
        C: 2D tensor (M, N), float32
    """
    lib = _ensure_loaded()

    M, K = A.shape
    K2, N = B.shape

    C = torch.zeros(M, N, dtype=torch.float32, device=A.device)

    torch.cuda.synchronize()
    lib.vla_deterministic_matmul(
        ctypes.c_void_p(A.data_ptr()),
        ctypes.c_void_p(B.data_ptr()),
        ctypes.c_void_p(C.data_ptr()),
        ctypes.c_int(M),
        ctypes.c_int(K),
        ctypes.c_int(N)
    )
    torch.cuda.synchronize()

    return C


def _vla_dot_raw(a: torch.Tensor, b: torch.Tensor) -> float:
    """Raw VLA dot product without autograd. Returns Python float."""
    lib = _ensure_loaded()
    n = a.shape[0]

    torch.cuda.synchronize()
    result = lib.vla_deterministic_dot_fp32(
        ctypes.c_void_p(a.data_ptr()),
        ctypes.c_void_p(b.data_ptr()),
        ctypes.c_int(n)
    )
    torch.cuda.synchronize()

    return result


def _vla_sum_raw(x: torch.Tensor) -> float:
    """Raw VLA sum without autograd. Returns Python float."""
    lib = _ensure_loaded()
    n = x.numel()
    x_flat = x.contiguous().view(-1)

    torch.cuda.synchronize()
    result = lib.vla_deterministic_sum_fp32(
        ctypes.c_void_p(x_flat.data_ptr()),
        ctypes.c_int(n)
    )
    torch.cuda.synchronize()

    return result


# =============================================================================
# AUTOGRAD FUNCTIONS
# =============================================================================

class VLAMatmulFunction(Function):
    """
    Autograd function for deterministic matrix multiplication.

    Forward: C = A @ B (VLA deterministic)
    Backward: dA = dC @ B^T, dB = A^T @ dC (also VLA deterministic)

    This ensures BOTH forward and backward passes are reproducible.
    """

    @staticmethod
    def forward(ctx, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        # Save for backward
        ctx.save_for_backward(A, B)

        # Ensure float32 contiguous
        A_f32 = A.float().contiguous()
        B_f32 = B.float().contiguous()

        # VLA deterministic matmul
        C = _vla_matmul_raw(A_f32, B_f32)

        return C

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        A, B = ctx.saved_tensors
        grad_A = grad_B = None

        # Ensure grad is float32 contiguous
        grad_f32 = grad_output.float().contiguous()

        if ctx.needs_input_grad[0]:
            # dA = dC @ B^T
            B_t = B.float().t().contiguous()
            grad_A = _vla_matmul_raw(grad_f32, B_t)

        if ctx.needs_input_grad[1]:
            # dB = A^T @ dC
            A_t = A.float().t().contiguous()
            grad_B = _vla_matmul_raw(A_t, grad_f32)

        return grad_A, grad_B


class VLADotFunction(Function):
    """
    Autograd function for deterministic dot product.

    Forward: y = a · b (VLA deterministic)
    Backward: da = dy * b, db = dy * a
    """

    @staticmethod
    def forward(ctx, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        ctx.save_for_backward(a, b)

        a_f32 = a.float().contiguous()
        b_f32 = b.float().contiguous()

        result = _vla_dot_raw(a_f32, b_f32)

        return torch.tensor(result, dtype=torch.float32, device=a.device, requires_grad=True)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        a, b = ctx.saved_tensors
        grad_a = grad_b = None

        # Scalar grad
        dy = grad_output.item()

        if ctx.needs_input_grad[0]:
            grad_a = dy * b.float()

        if ctx.needs_input_grad[1]:
            grad_b = dy * a.float()

        return grad_a, grad_b


class VLASumFunction(Function):
    """
    Autograd function for deterministic sum.

    Forward: y = sum(x) (VLA deterministic)
    Backward: dx = dy * ones_like(x)
    """

    @staticmethod
    def forward(ctx, x: torch.Tensor) -> torch.Tensor:
        ctx.save_for_backward(x)

        x_f32 = x.float().contiguous()
        result = _vla_sum_raw(x_f32)

        return torch.tensor(result, dtype=torch.float32, device=x.device, requires_grad=True)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> torch.Tensor:
        x, = ctx.saved_tensors

        # Gradient is broadcast to all elements
        dy = grad_output.item()
        grad_x = torch.full_like(x, dy, dtype=torch.float32)

        return grad_x


class VLABmmFunction(Function):
    """
    Autograd function for deterministic batched matrix multiplication.

    Forward: C[i] = A[i] @ B[i] for each batch element (VLA deterministic)
    Backward: dA[i] = dC[i] @ B[i]^T, dB[i] = A[i]^T @ dC[i]
    """

    @staticmethod
    def forward(ctx, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        ctx.save_for_backward(A, B)

        batch_size = A.shape[0]
        M, K = A.shape[1], A.shape[2]
        N = B.shape[2]

        C = torch.zeros(batch_size, M, N, dtype=torch.float32, device=A.device)

        A_f32 = A.float().contiguous()
        B_f32 = B.float().contiguous()

        for i in range(batch_size):
            C[i] = _vla_matmul_raw(A_f32[i].contiguous(), B_f32[i].contiguous())

        return C

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        A, B = ctx.saved_tensors
        grad_A = grad_B = None

        batch_size = A.shape[0]
        grad_f32 = grad_output.float().contiguous()

        if ctx.needs_input_grad[0]:
            grad_A = torch.zeros_like(A, dtype=torch.float32)
            for i in range(batch_size):
                B_t = B[i].float().t().contiguous()
                grad_A[i] = _vla_matmul_raw(grad_f32[i].contiguous(), B_t)

        if ctx.needs_input_grad[1]:
            grad_B = torch.zeros_like(B, dtype=torch.float32)
            for i in range(batch_size):
                A_t = A[i].float().t().contiguous()
                grad_B[i] = _vla_matmul_raw(A_t, grad_f32[i].contiguous())

        return grad_A, grad_B


# =============================================================================
# PUBLIC API (with autograd support)
# =============================================================================

def dot(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """
    Deterministic dot product of two 1D tensors.

    Cross-hardware reproducible: same bits on any GPU architecture.
    Supports autograd for backpropagation.

    Args:
        a: 1D tensor (float32, CUDA)
        b: 1D tensor (float32, CUDA)

    Returns:
        Scalar tensor with the dot product result
    """
    # Validate inputs
    assert a.dim() == 1 and b.dim() == 1, "Inputs must be 1D"
    assert a.shape[0] == b.shape[0], "Inputs must have same length"
    assert a.is_cuda and b.is_cuda, "Inputs must be on CUDA"

    return VLADotFunction.apply(a, b)


def sum(x: torch.Tensor) -> torch.Tensor:
    """
    Deterministic sum of all elements in a tensor.

    Cross-hardware reproducible: same bits on any GPU architecture.
    Supports autograd for backpropagation.

    Args:
        x: Tensor (float32, CUDA)

    Returns:
        Scalar tensor with the sum
    """
    # Validate inputs
    assert x.is_cuda, "Input must be on CUDA"

    return VLASumFunction.apply(x)


def matmul(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """
    Deterministic matrix multiplication: C = A @ B

    Cross-hardware reproducible: same bits on any GPU architecture.
    Supports autograd for backpropagation (backward is also deterministic).

    Args:
        A: 2D tensor of shape (M, K), CUDA
        B: 2D tensor of shape (K, N), CUDA

    Returns:
        C: 2D tensor of shape (M, N), float32
    """
    # Handle 1D tensors (vector-matrix, matrix-vector)
    squeeze_A = False
    squeeze_B = False

    if A.dim() == 1:
        A = A.unsqueeze(0)
        squeeze_A = True
    if B.dim() == 1:
        B = B.unsqueeze(1)
        squeeze_B = True

    # Validate inputs
    assert A.dim() == 2 and B.dim() == 2, "Inputs must be 2D"
    assert A.shape[1] == B.shape[0], f"Shape mismatch: {A.shape} @ {B.shape}"
    assert A.is_cuda and B.is_cuda, "Inputs must be on CUDA"

    # Use autograd function
    C = VLAMatmulFunction.apply(A, B)

    # Squeeze back if needed
    if squeeze_A:
        C = C.squeeze(0)
    if squeeze_B:
        C = C.squeeze(1)

    return C


def mm(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """Alias for matmul."""
    return matmul(A, B)


def bmm(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """
    Deterministic batched matrix multiplication.

    Cross-hardware reproducible: same bits on any GPU architecture.
    Supports autograd for backpropagation.

    Args:
        A: 3D tensor of shape (B, M, K)
        B: 3D tensor of shape (B, K, N)

    Returns:
        C: 3D tensor of shape (B, M, N)
    """
    assert A.dim() == 3 and B.dim() == 3, "Inputs must be 3D"
    assert A.shape[0] == B.shape[0], "Batch sizes must match"
    assert A.is_cuda and B.is_cuda, "Inputs must be on CUDA"

    return VLABmmFunction.apply(A, B)
