"""
Verity Operations - Cross-Hardware Reproducible PyTorch Ops
============================================================

VLA-based operations with full autograd support.
Produces bit-exact results across different GPU architectures.

Verified: RTX 4070 <-> P100 <-> T4, up to 162M parameters.
"""

import ctypes
import os
import sys
import torch
from torch.autograd import Function
from typing import Optional

__all__ = ['matmul', 'dot', 'sum', 'softmax', 'linear', 'version']

# =============================================================================
# LIBRARY LOADING
# =============================================================================

_lib = None
_lib_loaded = False


def _load_library():
    """Load the Verity CUDA library."""
    global _lib, _lib_loaded

    if _lib_loaded:
        return _lib is not None

    # Platform-specific library name
    if sys.platform == 'win32':
        lib_name = 'verity_kernels.dll'
    else:
        lib_name = 'libverity_kernels.so'

    # Search paths
    module_dir = os.path.dirname(__file__)
    search_paths = [
        os.path.join(module_dir, 'kernels', lib_name),
        os.path.join(module_dir, 'lib', lib_name),
        os.path.join(module_dir, lib_name),
        # Kaggle/Linux build location
        '/tmp/libverity_kernels.so',
    ]

    for lib_path in search_paths:
        if os.path.exists(lib_path):
            try:
                _lib = ctypes.CDLL(lib_path)

                # Setup function signatures
                _lib.verity_matmul.argtypes = [
                    ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                    ctypes.c_int, ctypes.c_int, ctypes.c_int
                ]
                _lib.verity_matmul.restype = None

                _lib.verity_row_sum.argtypes = [
                    ctypes.c_void_p, ctypes.c_void_p,
                    ctypes.c_int, ctypes.c_int
                ]
                _lib.verity_row_sum.restype = None

                _lib.verity_dot.argtypes = [
                    ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int
                ]
                _lib.verity_dot.restype = ctypes.c_double

                _lib.verity_sum.argtypes = [ctypes.c_void_p, ctypes.c_int]
                _lib.verity_sum.restype = ctypes.c_double

                _lib.verity_version.restype = ctypes.c_char_p

                _lib.verity_layernorm.argtypes = [
                    ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                    ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_float
                ]
                _lib.verity_layernorm.restype = None

                _lib.verity_sqrt.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
                _lib.verity_sqrt.restype = None

                _lib.verity_rsqrt.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_float]
                _lib.verity_rsqrt.restype = None

                _lib_loaded = True
                return True
            except Exception as e:
                print(f"[Verity] Failed to load {lib_path}: {e}")
                continue

    _lib_loaded = True
    return False


def _ensure_loaded():
    """Ensure library is loaded, raise if not."""
    if not _load_library():
        raise RuntimeError(
            "Verity CUDA library not found. "
            "Build with: nvcc -shared -O3 -o libverity_kernels.so vla_kernels.cu"
        )
    return _lib


def version() -> str:
    """Get Verity version string."""
    lib = _ensure_loaded()
    return lib.verity_version().decode()


# =============================================================================
# RAW OPERATIONS (no autograd)
# =============================================================================

def _matmul_raw(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """Raw VLA matmul without autograd. Supports 2D and 3D (batched)."""
    lib = _ensure_loaded()

    # Handle batched case (3D tensors)
    if A.dim() == 3:
        batch = A.shape[0]
        results = []
        for i in range(batch):
            if B.dim() == 3:
                results.append(_matmul_raw_2d(A[i], B[i]))
            else:
                results.append(_matmul_raw_2d(A[i], B))
        return torch.stack(results)

    return _matmul_raw_2d(A, B)


def _matmul_raw_2d(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """Raw VLA matmul for 2D tensors."""
    lib = _ensure_loaded()
    M, K = A.shape
    K2, N = B.shape
    assert K == K2, f"Shape mismatch: {A.shape} @ {B.shape}"

    A_f32 = A.float().contiguous()
    B_f32 = B.float().contiguous()
    C = torch.zeros(M, N, dtype=torch.float32, device=A.device)

    lib.verity_matmul(
        A_f32.data_ptr(), B_f32.data_ptr(), C.data_ptr(),
        M, K, N
    )
    return C


def _row_sum_raw(x: torch.Tensor) -> torch.Tensor:
    """Raw VLA row sum without autograd."""
    lib = _ensure_loaded()
    x_f32 = x.float().contiguous()
    rows, cols = x_f32.shape
    sums = torch.zeros(rows, dtype=torch.float32, device=x.device)
    lib.verity_row_sum(x_f32.data_ptr(), sums.data_ptr(), rows, cols)
    return sums


def _dot_raw(a: torch.Tensor, b: torch.Tensor) -> float:
    """Raw VLA dot product without autograd."""
    lib = _ensure_loaded()
    a_f32 = a.float().contiguous()
    b_f32 = b.float().contiguous()
    return lib.verity_dot(a_f32.data_ptr(), b_f32.data_ptr(), a.numel())


def _sum_raw(x: torch.Tensor) -> float:
    """Raw VLA sum without autograd."""
    lib = _ensure_loaded()
    x_f32 = x.float().contiguous().view(-1)
    return lib.verity_sum(x_f32.data_ptr(), x_f32.numel())


def _layernorm_raw(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """Raw VLA LayerNorm with deterministic sqrt - cross-hardware reproducible."""
    lib = _ensure_loaded()
    orig_shape = x.shape
    x_2d = x.reshape(-1, x.shape[-1]).float().contiguous()
    rows, cols = x_2d.shape
    weight_f32 = weight.float().contiguous()
    bias_f32 = bias.float().contiguous()
    output = torch.zeros_like(x_2d)

    lib.verity_layernorm(
        x_2d.data_ptr(), weight_f32.data_ptr(), bias_f32.data_ptr(),
        output.data_ptr(), rows, cols, eps
    )
    return output.reshape(orig_shape)


def _sqrt_raw(x: torch.Tensor) -> torch.Tensor:
    """Deterministic sqrt via Newton-Raphson - cross-hardware reproducible."""
    lib = _ensure_loaded()
    x_f32 = x.float().contiguous()
    output = torch.zeros_like(x_f32)
    lib.verity_sqrt(x_f32.data_ptr(), output.data_ptr(), x_f32.numel())
    return output


def _rsqrt_raw(x: torch.Tensor, eps: float = 0.0) -> torch.Tensor:
    """Deterministic rsqrt (1/sqrt) via Newton-Raphson - cross-hardware reproducible."""
    lib = _ensure_loaded()
    x_f32 = x.float().contiguous()
    output = torch.zeros_like(x_f32)
    lib.verity_rsqrt(x_f32.data_ptr(), output.data_ptr(), x_f32.numel(), eps)
    return output


# =============================================================================
# AUTOGRAD FUNCTIONS
# =============================================================================

class VerityMatmul(Function):
    """Autograd function for deterministic matmul."""

    @staticmethod
    def forward(ctx, A, B):
        ctx.save_for_backward(A, B)
        return _matmul_raw(A, B)

    @staticmethod
    def backward(ctx, grad_output):
        A, B = ctx.saved_tensors
        grad_A = grad_B = None
        grad_f32 = grad_output.float().contiguous()

        if A.dim() == 3:
            # Batched backward
            if ctx.needs_input_grad[0]:
                if B.dim() == 3:
                    grad_A = _matmul_raw(grad_f32, B.transpose(-2, -1).contiguous())
                else:
                    grad_A = _matmul_raw(grad_f32, B.t().contiguous().unsqueeze(0).expand(A.shape[0], -1, -1))
            if ctx.needs_input_grad[1]:
                grad_B = _matmul_raw(A.transpose(-2, -1).contiguous(), grad_f32)
                if B.dim() == 2:
                    grad_B = grad_B.sum(dim=0)
        else:
            if ctx.needs_input_grad[0]:
                grad_A = _matmul_raw(grad_f32, B.t().contiguous())
            if ctx.needs_input_grad[1]:
                grad_B = _matmul_raw(A.t().contiguous(), grad_f32)

        return grad_A, grad_B


class VeritySoftmax(Function):
    """Autograd function for deterministic softmax."""

    @staticmethod
    def forward(ctx, x):
        x_max = x.max(dim=-1, keepdim=True)[0]
        x_exp = torch.exp(x - x_max)
        sums = _row_sum_raw(x_exp)
        result = x_exp / sums.unsqueeze(-1)
        ctx.save_for_backward(result)
        return result

    @staticmethod
    def backward(ctx, grad_output):
        softmax_out, = ctx.saved_tensors
        sum_term = _row_sum_raw(grad_output * softmax_out)
        grad_input = softmax_out * (grad_output - sum_term.unsqueeze(-1))
        return grad_input


class VerityDot(Function):
    """Autograd function for deterministic dot product."""

    @staticmethod
    def forward(ctx, a, b):
        ctx.save_for_backward(a, b)
        result = _dot_raw(a, b)
        return torch.tensor(result, dtype=torch.float32, device=a.device)

    @staticmethod
    def backward(ctx, grad_output):
        a, b = ctx.saved_tensors
        dy = grad_output.item()
        grad_a = dy * b.float() if ctx.needs_input_grad[0] else None
        grad_b = dy * a.float() if ctx.needs_input_grad[1] else None
        return grad_a, grad_b


class VeritySum(Function):
    """Autograd function for deterministic sum."""

    @staticmethod
    def forward(ctx, x):
        ctx.save_for_backward(x)
        result = _sum_raw(x)
        return torch.tensor(result, dtype=torch.float32, device=x.device)

    @staticmethod
    def backward(ctx, grad_output):
        x, = ctx.saved_tensors
        dy = grad_output.item()
        return torch.full_like(x, dy, dtype=torch.float32)


class VerityLayerNorm(Function):
    """Autograd function for deterministic LayerNorm with VLA + Newton-Raphson sqrt."""

    @staticmethod
    def forward(ctx, x, weight, bias, eps):
        output = _layernorm_raw(x, weight, bias, eps)
        # Save for backward
        ctx.save_for_backward(x, weight, output)
        ctx.eps = eps
        ctx.normalized_shape = x.shape[-1]
        return output

    @staticmethod
    def backward(ctx, grad_output):
        x, weight, output = ctx.saved_tensors
        eps = ctx.eps
        N = ctx.normalized_shape

        # Reshape for computation
        orig_shape = x.shape
        x_2d = x.reshape(-1, N)
        grad_2d = grad_output.reshape(-1, N)
        out_2d = output.reshape(-1, N)

        # Recompute mean and rstd using VLA + deterministic sqrt
        mean = _row_sum_raw(x_2d) / N
        diff = x_2d - mean.unsqueeze(-1)
        var = _row_sum_raw(diff * diff) / N

        # DETERMINISTIC rsqrt via Newton-Raphson for cross-hardware training
        rstd = _rsqrt_raw(var, eps)

        # x_norm = (x - mean) * rstd
        x_norm = diff * rstd.unsqueeze(-1)

        # Gradients
        grad_weight = _row_sum_raw((grad_2d * x_norm).t().contiguous())
        grad_bias = _row_sum_raw(grad_2d.t().contiguous())

        # grad_x
        grad_x_norm = grad_2d * weight
        grad_var = _row_sum_raw(grad_x_norm * diff) * (-0.5) * (rstd ** 3)
        grad_mean = _row_sum_raw(grad_x_norm) * (-rstd) + grad_var * _row_sum_raw(-2.0 * diff) / N
        grad_x = grad_x_norm * rstd.unsqueeze(-1) + grad_var.unsqueeze(-1) * 2.0 * diff / N + grad_mean.unsqueeze(-1) / N

        return grad_x.reshape(orig_shape), grad_weight, grad_bias, None


# =============================================================================
# PUBLIC API
# =============================================================================

def matmul(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """
    Deterministic matrix multiplication: C = A @ B

    Cross-hardware reproducible: identical bits on any GPU.

    Args:
        A: 2D tensor (M, K)
        B: 2D tensor (K, N)

    Returns:
        C: 2D tensor (M, N)
    """
    return VerityMatmul.apply(A, B)


def dot(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """
    Deterministic dot product of two 1D tensors.

    Args:
        a, b: 1D tensors of same length

    Returns:
        Scalar tensor
    """
    return VerityDot.apply(a.view(-1), b.view(-1))


def sum(x: torch.Tensor) -> torch.Tensor:
    """
    Deterministic sum of all elements.

    Args:
        x: Tensor of any shape

    Returns:
        Scalar tensor
    """
    return VeritySum.apply(x)


def softmax(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """
    Deterministic softmax.

    Args:
        x: Input tensor
        dim: Dimension to apply softmax

    Returns:
        Softmax output (same shape as input)
    """
    if dim != -1:
        x = x.movedim(dim, -1)

    orig_shape = x.shape
    x_flat = x.reshape(-1, x.shape[-1])

    result = VeritySoftmax.apply(x_flat)
    result = result.reshape(orig_shape)

    if dim != -1:
        result = result.movedim(-1, dim)

    return result


def linear(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor] = None
) -> torch.Tensor:
    """
    Deterministic linear transformation: y = x @ W^T + b

    Args:
        input: (*, in_features) tensor
        weight: (out_features, in_features) tensor
        bias: optional (out_features,) tensor

    Returns:
        output: (*, out_features) tensor
    """
    orig_shape = input.shape
    in_features = weight.shape[1]
    out_features = weight.shape[0]

    # Flatten batch dims
    input_flat = input.reshape(-1, in_features)

    # y = x @ W^T
    output = matmul(input_flat, weight.t())

    # Add bias
    if bias is not None:
        output = output + bias

    # Restore shape
    return output.reshape(*orig_shape[:-1], out_features)


def layernorm(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    eps: float = 1e-5
) -> torch.Tensor:
    """
    Deterministic LayerNorm with VLA mean/variance and Newton-Raphson sqrt.

    Cross-hardware reproducible: identical bits on any GPU.

    Args:
        input: (*, normalized_shape) tensor
        weight: (normalized_shape,) tensor
        bias: (normalized_shape,) tensor
        eps: small value for numerical stability

    Returns:
        output: same shape as input
    """
    return VerityLayerNorm.apply(input, weight, bias, eps)


# =============================================================================
# VERITY ADAM OPTIMIZER - Cross-hardware reproducible
# =============================================================================

class VerityAdam:
    """
    Adam optimizer with deterministic sqrt for cross-hardware reproducibility.

    Uses Newton-Raphson sqrt instead of hardware sqrt.

    Usage:
        optimizer = VerityAdam(model.parameters(), lr=1e-3)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    """

    def __init__(
        self,
        params,
        lr: float = 1e-3,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.0
    ):
        self.params = list(params)
        self.lr = lr
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.step_count = 0

        # Initialize state
        self.m = [torch.zeros_like(p) for p in self.params]
        self.v = [torch.zeros_like(p) for p in self.params]

    def zero_grad(self):
        for p in self.params:
            if p.grad is not None:
                p.grad.zero_()

    def step(self):
        self.step_count += 1

        for i, p in enumerate(self.params):
            if p.grad is None:
                continue

            grad = p.grad.data

            # Weight decay (decoupled)
            if self.weight_decay > 0:
                p.data.mul_(1 - self.lr * self.weight_decay)

            # Update biased first moment
            self.m[i].mul_(self.beta1).add_(grad, alpha=1 - self.beta1)

            # Update biased second moment
            self.v[i].mul_(self.beta2).addcmul_(grad, grad, value=1 - self.beta2)

            # Bias correction
            bias_correction1 = 1 - self.beta1 ** self.step_count
            bias_correction2 = 1 - self.beta2 ** self.step_count

            m_hat = self.m[i] / bias_correction1
            v_hat = self.v[i] / bias_correction2

            # DETERMINISTIC SQRT via Newton-Raphson
            v_sqrt = _sqrt_raw(v_hat)

            # Update parameters
            p.data.addcdiv_(m_hat, v_sqrt + self.eps, value=-self.lr)

    def state_dict(self):
        return {
            'step_count': self.step_count,
            'm': [m.clone() for m in self.m],
            'v': [v.clone() for v in self.v],
        }

    def load_state_dict(self, state_dict):
        self.step_count = state_dict['step_count']
        for i in range(len(self.m)):
            self.m[i].copy_(state_dict['m'][i])
            self.v[i].copy_(state_dict['v'][i])
