# Verity CUDA kernels - compiled binaries only
