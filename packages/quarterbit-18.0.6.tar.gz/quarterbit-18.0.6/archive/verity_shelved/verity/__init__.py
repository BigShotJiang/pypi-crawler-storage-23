"""
Verity - Cross-Hardware Reproducible Training
==============================================

Bit-exact neural network training across different GPU architectures.
Verified: RTX 4070 <-> P100 <-> T4 <-> A100

Three ways to use Verity:

1. CONVERT EXISTING MODELS (recommended):
    from quarterbit.verity import convert

    model = GPT2LMHeadModel.from_pretrained("gpt2")
    model = convert(model)  # Now reproducible on any GPU!

2. USE VLA LAYERS DIRECTLY:
    from quarterbit.verity.layers import VLALinear, VLATransformer

    model = VLATransformer(vocab_size=50257, dim=768, ...)

3. MONKEY-PATCH (simple models only):
    from quarterbit import verity
    verity.enable()  # Patches torch.mm, F.linear, F.softmax

Algorithm: VLA (VIGIL Lossless Arithmetic)
- 4-limb FP64 accumulator with TwoSum error propagation
- Order-independent: same result regardless of thread scheduling
- Architecture-independent: identical bits on any NVIDIA GPU

Copyright (c) 2026 Clouthier Simulation Labs
"""

__version__ = "1.0.0"

from . import ops
from . import layers
from .convert import convert, conversion_report, is_converted

__all__ = [
    # Main API
    'convert',
    'conversion_report',
    'is_converted',
    # Layers
    'layers',
    # Ops
    'ops',
    # Monkey-patching (simple models)
    'enable',
    'disable',
    'is_enabled',
    # Version
    '__version__',
]

# Global state for monkey-patching
_enabled = False
_original_ops = {}


def enable():
    """
    Enable Verity mode by patching PyTorch operations.

    After calling enable(), the following operations become
    cross-hardware reproducible:
    - torch.mm, torch.matmul
    - torch.nn.functional.linear
    - torch.nn.functional.softmax
    - torch.nn.functional.log_softmax

    This affects ALL code using these operations, including
    nn.Linear layers and attention mechanisms.
    """
    global _enabled, _original_ops

    if _enabled:
        print("[Verity] Already enabled")
        return

    import torch
    import torch.nn.functional as F

    # Save originals
    _original_ops['torch.mm'] = torch.mm
    _original_ops['torch.matmul'] = torch.matmul
    _original_ops['F.linear'] = F.linear
    _original_ops['F.softmax'] = F.softmax
    _original_ops['F.log_softmax'] = F.log_softmax

    # Patch with Verity versions
    def verity_mm(a, b, **kwargs):
        return ops.matmul(a, b)

    def verity_matmul(a, b, **kwargs):
        # Handle batched case
        if a.dim() > 2 or b.dim() > 2:
            # Fall back to loop for batched
            if a.dim() == 3 and b.dim() == 3:
                batch = a.shape[0]
                results = []
                for i in range(batch):
                    results.append(ops.matmul(a[i], b[i]))
                return torch.stack(results)
            elif a.dim() == 3 and b.dim() == 2:
                batch = a.shape[0]
                results = []
                for i in range(batch):
                    results.append(ops.matmul(a[i], b))
                return torch.stack(results)
            else:
                # Complex case - use original
                return _original_ops['torch.matmul'](a, b, **kwargs)
        return ops.matmul(a, b)

    def verity_linear(input, weight, bias=None):
        return ops.linear(input, weight, bias)

    def verity_softmax(input, dim=-1, **kwargs):
        return ops.softmax(input, dim=dim)

    def verity_log_softmax(input, dim=-1, **kwargs):
        return torch.log(ops.softmax(input, dim=dim))

    torch.mm = verity_mm
    torch.matmul = verity_matmul
    F.linear = verity_linear
    F.softmax = verity_softmax
    F.log_softmax = verity_log_softmax

    _enabled = True
    print(f"[Verity] Enabled v{__version__} - Cross-hardware reproducible training")


def disable():
    """Restore original PyTorch operations."""
    global _enabled, _original_ops

    if not _enabled:
        print("[Verity] Already disabled")
        return

    import torch
    import torch.nn.functional as F

    torch.mm = _original_ops['torch.mm']
    torch.matmul = _original_ops['torch.matmul']
    F.linear = _original_ops['F.linear']
    F.softmax = _original_ops['F.softmax']
    F.log_softmax = _original_ops['F.log_softmax']

    _enabled = False
    print("[Verity] Disabled - Using standard PyTorch ops")


def is_enabled() -> bool:
    """Check if Verity mode is enabled."""
    return _enabled


def version() -> str:
    """Get Verity version string."""
    return ops.version()
