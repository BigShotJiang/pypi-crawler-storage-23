"""
Verity Layers - Cross-Hardware Reproducible Neural Network Layers
=================================================================

Drop-in replacements for PyTorch layers that produce bit-exact
results across different GPU architectures.

Usage:
    from quarterbit.verity.layers import VLALinear, VLATransformer

    # Single layer
    linear = VLALinear(768, 768).cuda()

    # Full transformer
    model = VLATransformer(
        vocab_size=50257,
        dim=768,
        n_heads=12,
        n_layers=12,
        max_seq_len=1024
    ).cuda()

All layers are verified cross-hardware reproducible:
    RTX 4070 <-> P100 <-> T4 <-> A100
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Optional

from . import ops

__all__ = [
    'VLALinear',
    'VLALayerNorm',
    'VLAAttention',
    'VLAMLP',
    'VLATransformerBlock',
    'VLATransformer',
]


class VLALinear(nn.Module):
    """
    Linear layer using VLA matmul.

    Cross-hardware reproducible: identical output on any GPU.
    """

    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        self.weight = nn.Parameter(torch.empty(out_features, in_features))
        self.bias = nn.Parameter(torch.empty(out_features)) if bias else None

        self.reset_parameters()

    def reset_parameters(self):
        """Xavier uniform initialization."""
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return ops.linear(x, self.weight, self.bias)

    def extra_repr(self) -> str:
        return f'in_features={self.in_features}, out_features={self.out_features}, bias={self.bias is not None}'


class VLALayerNorm(nn.Module):
    """
    Layer normalization with full VLA CUDA kernel.

    Uses VLA row_sum for mean/variance AND Newton-Raphson sqrt
    for cross-hardware reproducibility. Standard PyTorch uses
    hardware sqrt which differs between GPU architectures.
    """

    def __init__(self, normalized_shape: int, eps: float = 1e-5):
        super().__init__()
        self.normalized_shape = normalized_shape
        self.eps = eps

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Use full CUDA kernel with deterministic sqrt
        return ops.layernorm(x, self.weight, self.bias, self.eps)

    def extra_repr(self) -> str:
        return f'{self.normalized_shape}, eps={self.eps}'


class VLAAttention(nn.Module):
    """
    Multi-head attention using VLA ops.

    Cross-hardware reproducible: identical attention weights and output.
    """

    def __init__(self, dim: int, n_heads: int, dropout: float = 0.0):
        super().__init__()
        assert dim % n_heads == 0, f"dim {dim} must be divisible by n_heads {n_heads}"

        self.dim = dim
        self.n_heads = n_heads
        self.head_dim = dim // n_heads
        self.scale = self.head_dim ** -0.5
        self.dropout = dropout

        # Combined QKV projection
        self.qkv = VLALinear(dim, 3 * dim, bias=True)
        self.proj = VLALinear(dim, dim, bias=True)

    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        B, T, C = x.shape

        # QKV projection
        qkv = self.qkv(x)
        qkv = qkv.reshape(B, T, 3, self.n_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # (3, B, H, T, D)
        q, k, v = qkv[0], qkv[1], qkv[2]

        # Compute attention scores using VLA matmul
        # q: (B, H, T, D), k: (B, H, T, D)
        # attn: (B, H, T, T)
        attn = torch.zeros(B, self.n_heads, T, T, device=x.device, dtype=torch.float32)

        for b in range(B):
            for h in range(self.n_heads):
                # Q @ K^T
                attn[b, h] = ops.matmul(
                    q[b, h].contiguous(),
                    k[b, h].t().contiguous()
                ) * self.scale

        # Apply mask if provided (for causal attention)
        if mask is not None:
            attn = attn.masked_fill(mask == 0, float('-inf'))

        # Softmax with VLA
        attn_shape = attn.shape
        attn_flat = attn.reshape(-1, T)
        attn_soft = ops.softmax(attn_flat, dim=-1)
        attn = attn_soft.reshape(attn_shape)

        # Apply dropout during training
        if self.training and self.dropout > 0:
            attn = F.dropout(attn, p=self.dropout)

        # Apply attention to values using VLA matmul
        out = torch.zeros(B, self.n_heads, T, self.head_dim, device=x.device, dtype=torch.float32)

        for b in range(B):
            for h in range(self.n_heads):
                out[b, h] = ops.matmul(
                    attn[b, h].contiguous(),
                    v[b, h].contiguous()
                )

        # Reshape and project
        out = out.permute(0, 2, 1, 3).reshape(B, T, C)
        out = self.proj(out)

        return out


class VLAMLP(nn.Module):
    """
    MLP block using VLA linear layers.
    """

    def __init__(self, dim: int, hidden_dim: Optional[int] = None, dropout: float = 0.0):
        super().__init__()
        hidden_dim = hidden_dim or dim * 4

        self.fc1 = VLALinear(dim, hidden_dim)
        self.fc2 = VLALinear(hidden_dim, dim)
        self.dropout = dropout

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.fc1(x)
        x = F.gelu(x)
        if self.training and self.dropout > 0:
            x = F.dropout(x, p=self.dropout)
        x = self.fc2(x)
        if self.training and self.dropout > 0:
            x = F.dropout(x, p=self.dropout)
        return x


class VLATransformerBlock(nn.Module):
    """
    Transformer block with VLA ops.

    Pre-norm architecture (like GPT-2):
        x = x + attn(ln1(x))
        x = x + mlp(ln2(x))
    """

    def __init__(self, dim: int, n_heads: int, dropout: float = 0.0):
        super().__init__()
        self.ln1 = VLALayerNorm(dim)
        self.attn = VLAAttention(dim, n_heads, dropout=dropout)
        self.ln2 = VLALayerNorm(dim)
        self.mlp = VLAMLP(dim, dropout=dropout)

    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        x = x + self.attn(self.ln1(x), mask=mask)
        x = x + self.mlp(self.ln2(x))
        return x


class VLATransformer(nn.Module):
    """
    GPT-style transformer using VLA ops throughout.

    Cross-hardware reproducible: bit-exact training across any GPU.
    Verified: RTX 4070 <-> P100, up to 162M parameters.

    Args:
        vocab_size: Size of vocabulary
        dim: Model dimension
        n_heads: Number of attention heads
        n_layers: Number of transformer blocks
        max_seq_len: Maximum sequence length
        dropout: Dropout probability (default 0.0 for determinism)
    """

    def __init__(
        self,
        vocab_size: int,
        dim: int,
        n_heads: int,
        n_layers: int,
        max_seq_len: int,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.vocab_size = vocab_size
        self.dim = dim
        self.n_layers = n_layers
        self.max_seq_len = max_seq_len

        # Embeddings
        self.tok_emb = nn.Embedding(vocab_size, dim)
        self.pos_emb = nn.Embedding(max_seq_len, dim)

        # Transformer blocks
        self.blocks = nn.ModuleList([
            VLATransformerBlock(dim, n_heads, dropout=dropout)
            for _ in range(n_layers)
        ])

        # Output
        self.ln_f = VLALayerNorm(dim)
        self.head = VLALinear(dim, vocab_size, bias=False)

        # Initialize
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, VLALinear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
        elif isinstance(module, VLALayerNorm):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)

    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        B, T = x.shape
        assert T <= self.max_seq_len, f"Sequence length {T} > max {self.max_seq_len}"

        # Embeddings
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        x = self.tok_emb(x) + self.pos_emb(pos)

        # Transformer blocks
        for block in self.blocks:
            x = block(x, mask=mask)

        # Output
        x = self.ln_f(x)
        logits = self.head(x)

        return logits

    def generate(
        self,
        idx: torch.Tensor,
        max_new_tokens: int,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
    ) -> torch.Tensor:
        """Generate tokens autoregressively."""
        for _ in range(max_new_tokens):
            # Crop to max_seq_len
            idx_cond = idx[:, -self.max_seq_len:]

            # Forward
            logits = self(idx_cond)
            logits = logits[:, -1, :] / temperature

            # Top-k sampling
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = float('-inf')

            # Sample
            probs = ops.softmax(logits, dim=-1)
            idx_next = torch.multinomial(probs, num_samples=1)
            idx = torch.cat([idx, idx_next], dim=1)

        return idx

    @property
    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())
