"""
Verity Model Converter - Convert Any PyTorch Model to Cross-Hardware Reproducible
==================================================================================

Automatically replaces standard PyTorch layers with VLA equivalents.
After conversion, model produces bit-exact results on ANY GPU.

Usage:
    from quarterbit.verity import convert

    # Convert existing model
    model = AutoModelForCausalLM.from_pretrained("gpt2")
    model = convert(model)

    # Now training is reproducible across GPUs
    # RTX 4070 == P100 == A100 == H100

Supported conversions:
    nn.Linear      → VLALinear
    nn.LayerNorm   → VLALayerNorm
    Conv1D (HF)    → VLALinear (HuggingFace attention layers)
    nn.Embedding   → (kept as-is, already deterministic)

Enterprise feature: https://quarterbit.dev/verity
"""

import torch
import torch.nn as nn
from typing import Optional, Set, Tuple, Dict, Any
from .layers import VLALinear, VLALayerNorm

__all__ = ['convert', 'convert_linear', 'convert_layernorm', 'convert_conv1d', 'conversion_report']


def convert_linear(module: nn.Linear) -> VLALinear:
    """Convert nn.Linear to VLALinear, preserving weights."""
    vla = VLALinear(
        in_features=module.in_features,
        out_features=module.out_features,
        bias=module.bias is not None
    )
    # Copy weights
    vla.weight.data.copy_(module.weight.data)
    if module.bias is not None:
        vla.bias.data.copy_(module.bias.data)
    return vla


def convert_layernorm(module: nn.LayerNorm) -> VLALayerNorm:
    """Convert nn.LayerNorm to VLALayerNorm, preserving weights."""
    # Handle tuple normalized_shape
    if isinstance(module.normalized_shape, tuple):
        normalized_shape = module.normalized_shape[-1]
    else:
        normalized_shape = module.normalized_shape

    vla = VLALayerNorm(
        normalized_shape=normalized_shape,
        eps=module.eps
    )
    # Copy weights
    vla.weight.data.copy_(module.weight.data)
    vla.bias.data.copy_(module.bias.data)
    return vla


def convert_conv1d(module) -> VLALinear:
    """
    Convert HuggingFace Conv1D to VLALinear, preserving weights.

    HF Conv1D stores weights as (in_features, out_features),
    while nn.Linear stores as (out_features, in_features).
    """
    # HF Conv1D has weight shape (in_features, out_features)
    in_features = module.weight.shape[0]
    out_features = module.weight.shape[1]

    vla = VLALinear(
        in_features=in_features,
        out_features=out_features,
        bias=module.bias is not None
    )
    # Conv1D weight is (in, out), VLALinear expects (out, in)
    vla.weight.data.copy_(module.weight.data.t())
    if module.bias is not None:
        vla.bias.data.copy_(module.bias.data)
    return vla


def _is_hf_conv1d(module) -> bool:
    """Check if module is HuggingFace Conv1D."""
    # Check class name since we don't want to import transformers
    return module.__class__.__name__ == 'Conv1D'


def _get_parent_and_name(model: nn.Module, target_name: str) -> Tuple[nn.Module, str]:
    """Get parent module and attribute name for a nested module path."""
    parts = target_name.split('.')
    parent = model
    for part in parts[:-1]:
        parent = getattr(parent, part)
    return parent, parts[-1]


def convert(
    model: nn.Module,
    convert_linear: bool = True,
    convert_layernorm: bool = True,
    convert_conv1d: bool = True,
    inplace: bool = True,
    verbose: bool = False
) -> nn.Module:
    """
    Convert a PyTorch model to use VLA layers for cross-hardware reproducibility.

    Args:
        model: Any PyTorch model (HuggingFace, custom, etc.)
        convert_linear: Replace nn.Linear with VLALinear
        convert_layernorm: Replace nn.LayerNorm with VLALayerNorm
        convert_conv1d: Replace HuggingFace Conv1D with VLALinear
        inplace: Modify model in place (default True)
        verbose: Print conversion progress

    Returns:
        Converted model with VLA layers

    Example:
        >>> from transformers import GPT2LMHeadModel
        >>> from quarterbit.verity import convert
        >>> model = GPT2LMHeadModel.from_pretrained("gpt2")
        >>> model = convert(model)
        >>> # Now bit-exact on any GPU!
    """
    if not inplace:
        import copy
        model = copy.deepcopy(model)

    # Collect modules to convert (can't modify during iteration)
    to_convert = []

    for name, module in model.named_modules():
        if convert_linear and isinstance(module, nn.Linear) and not isinstance(module, VLALinear):
            to_convert.append((name, module, 'linear'))
        elif convert_layernorm and isinstance(module, nn.LayerNorm) and not isinstance(module, VLALayerNorm):
            to_convert.append((name, module, 'layernorm'))
        elif convert_conv1d and _is_hf_conv1d(module):
            to_convert.append((name, module, 'conv1d'))

    # Perform conversions
    linear_count = 0
    layernorm_count = 0
    conv1d_count = 0

    for name, module, conv_type in to_convert:
        if not name:  # Skip root module
            continue

        parent, attr_name = _get_parent_and_name(model, name)

        if conv_type == 'linear':
            new_module = globals()['convert_linear'](module)
            linear_count += 1
            if verbose:
                print(f"  Linear: {name} ({module.in_features}→{module.out_features})")
        elif conv_type == 'conv1d':
            new_module = globals()['convert_conv1d'](module)
            conv1d_count += 1
            if verbose:
                in_f, out_f = module.weight.shape
                print(f"  Conv1D: {name} ({in_f}→{out_f})")
        else:
            new_module = globals()['convert_layernorm'](module)
            layernorm_count += 1
            if verbose:
                print(f"  LayerNorm: {name} ({module.normalized_shape})")

        # Move to same device
        device = next(module.parameters(), torch.tensor(0)).device
        new_module = new_module.to(device)

        # Replace
        setattr(parent, attr_name, new_module)

    if verbose:
        print(f"\nConverted: {linear_count} Linear, {conv1d_count} Conv1D, {layernorm_count} LayerNorm")

    return model


def conversion_report(model: nn.Module) -> Dict[str, Any]:
    """
    Generate a report of what would be converted in a model.

    Returns dict with:
        - linear_count: Number of nn.Linear layers
        - conv1d_count: Number of HuggingFace Conv1D layers
        - layernorm_count: Number of nn.LayerNorm layers
        - total_convertible_params: Total parameters that will be converted
        - layers: List of (name, type, params, shape) tuples
    """
    linear_count = 0
    conv1d_count = 0
    layernorm_count = 0
    linear_params = 0
    conv1d_params = 0
    layernorm_params = 0
    layers = []

    for name, module in model.named_modules():
        if isinstance(module, nn.Linear) and not isinstance(module, VLALinear):
            params = module.weight.numel() + (module.bias.numel() if module.bias is not None else 0)
            linear_count += 1
            linear_params += params
            layers.append((name, 'Linear', params, f"{module.in_features}→{module.out_features}"))
        elif _is_hf_conv1d(module):
            params = module.weight.numel() + (module.bias.numel() if module.bias is not None else 0)
            conv1d_count += 1
            conv1d_params += params
            in_f, out_f = module.weight.shape
            layers.append((name, 'Conv1D', params, f"{in_f}→{out_f}"))
        elif isinstance(module, nn.LayerNorm) and not isinstance(module, VLALayerNorm):
            params = module.weight.numel() + module.bias.numel()
            layernorm_count += 1
            layernorm_params += params
            layers.append((name, 'LayerNorm', params, str(module.normalized_shape)))

    return {
        'linear_count': linear_count,
        'conv1d_count': conv1d_count,
        'layernorm_count': layernorm_count,
        'linear_params': linear_params,
        'conv1d_params': conv1d_params,
        'layernorm_params': layernorm_params,
        'total_convertible_params': linear_params + conv1d_params + layernorm_params,
        'layers': layers
    }


def is_converted(model: nn.Module) -> bool:
    """Check if a model has been converted to VLA layers."""
    has_vla = False
    has_standard = False

    for module in model.modules():
        if isinstance(module, (VLALinear, VLALayerNorm)):
            has_vla = True
        elif isinstance(module, nn.Linear):
            has_standard = True
        elif isinstance(module, nn.LayerNorm):
            has_standard = True

    return has_vla and not has_standard
