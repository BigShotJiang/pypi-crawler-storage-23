# Package init for xase_cli.errors
