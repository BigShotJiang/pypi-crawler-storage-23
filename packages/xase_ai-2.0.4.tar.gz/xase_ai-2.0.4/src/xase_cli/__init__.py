"""
Xase CLI - Enterprise-grade AI Lab command-line interface
"""

__version__ = "2.0.0"
__author__ = "Xase AI Labs"
