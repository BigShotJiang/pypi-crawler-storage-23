import itertools
import numpy as np
import pandas as pd
import re
from collections import OrderedDict
from sdrf_pipelines.openms.openms import UnimodDatabase
from multiqc.plots import table
import os

from pmultiqc.modules.common.histogram import Histogram
from pmultiqc.modules.common.stats import (
    qual_uniform,
    cal_hm_charge
)
from pmultiqc.modules.common.plots import dia as dia_plots
from pmultiqc.modules.common.file_utils import file_prefix
from pmultiqc.modules.common.common_utils import (
    evidence_rt_count,
    cal_num_table_at_sample,
    summarize_modifications
)
from pmultiqc.modules.core.section_groups import add_sub_section
from pmultiqc.modules.common.plots.id import draw_ids_rt_count

from pmultiqc.modules.common.file_utils import drop_empty_row
from pmultiqc.modules.common.logging import get_logger

log = get_logger("pmultiqc.modules.common.dia_utils")

DEFAULT_BINS = 500


def parse_diann_report(
        sub_sections,
        diann_report_path,
        heatmap_color_list,
        sample_df,
        ms_with_psm,
        quantms_modified,
        ms_paths,
        file_df=None,
        msstats_input_valid=False
):
    """Parse DIA-NN report and generate plots and statistics.

    Args:
        file_df: Optional DataFrame. If None, an empty DataFrame will be used.
    """
    log.info(f"Parsing {diann_report_path}...")

    # Convert None to empty DataFrame for consistent handling
    if file_df is None:
        file_df = pd.DataFrame()

    # Load and preprocess report data
    report_data = _load_and_preprocess_diann_data(diann_report_path)

    # Draw various plots
    _draw_diann_plots(sub_sections, report_data, heatmap_color_list, sample_df, file_df, msstats_input_valid)

    # Process statistics and modifications
    total_protein_quantified, total_peptide_count, pep_plot = _process_diann_statistics(report_data)
    peptide_search_score = _process_peptide_search_scores(report_data)
    modifications_ok = _process_modifications(report_data)

    # Process run-specific data (requires Modifications column from _process_modifications)
    if modifications_ok:
        cal_num_table_data = _process_run_data(report_data, ms_with_psm, quantms_modified, file_df)
    else:
        log.warning("Skipping run data processing due to missing modifications data")
        cal_num_table_data = {"sdrf_samples": {}, "ms_runs": {}}

    # Handle files without PSM
    ms_without_psm = _handle_files_without_psm(ms_paths, ms_with_psm, cal_num_table_data)

    # Peptide Length Distribution
    peptide_length = _get_peptide_length(report_data)

    return (
        total_protein_quantified,
        total_peptide_count,
        pep_plot,
        peptide_search_score,
        ms_with_psm,
        cal_num_table_data,
        quantms_modified,
        ms_without_psm,
        peptide_length
    )


def _load_and_preprocess_diann_data(diann_report_path):
    """Load DIA-NN report data and perform initial preprocessing."""
    from pmultiqc.modules.common.ms.diann import DiannReader
    diann_reader = DiannReader(file_path=diann_report_path)
    diann_reader.parse()
    report_data = diann_reader.report_data

    # Filter out decoy entries if present
    if "Decoy" in report_data.columns:
        report_data = report_data[report_data["Decoy"] == 0].copy()

    # Calculate normalisation factor if needed
    _calculate_normalisation_factor(report_data)

    return report_data


def _calculate_normalisation_factor(report_data):
    """Calculate normalisation factor if not present."""
    required_cols = ["Precursor.Normalised", "Precursor.Quantity"]
    if "Normalisation.Factor" not in report_data.columns and all(
            col in report_data.columns for col in required_cols
    ):
        report_data["Normalisation.Factor"] = np.divide(
            report_data[required_cols[0]],
            report_data[required_cols[1]],
            out=np.full_like(report_data[required_cols[0]], np.nan, dtype="float64"),
            where=report_data[required_cols[1]].to_numpy(dtype="float64") != 0,
        )


def _draw_diann_plots(sub_sections, report_data, heatmap_color_list, sample_df, file_df, msstats_input_valid):
    """Draw all DIA-NN plots."""
    # Draw intensity plots and heatmap
    if "Precursor.Quantity" in report_data.columns:
        draw_dia_intensitys(sub_sections["quantification"], report_data, file_df)
        _draw_heatmap(sub_sections["summary"], report_data, heatmap_color_list)

    # Draw other plots
    log.info("Draw the DIA MS1 subsection.")
    draw_dia_ms1(sub_sections["ms1"], report_data)

    log.info("Draw the DIA MS2 subsection.")
    draw_dia_ms2s(sub_sections["ms2"], report_data, file_df)

    log.info("Draw the DIA mass_error subsection.")
    draw_dia_mass_error(sub_sections["mass_error"], report_data)

    log.info("Draw the DIA rt_qc subsection.")
    draw_dia_rt_qc(sub_sections["rt_qc"], report_data)

    # Draw quantification table if not using msstats
    if not msstats_input_valid:
        log.info("Draw the DIA quant table subsection.")
        draw_diann_quant_table(
            sub_sections["quantification"], report_data, sample_df, file_df
        )


def _draw_heatmap(sub_section, report_data, heatmap_color_list):
    """Draw heatmap for DIA-NN data."""
    log.info("Compute the Heatmap.")
    heatmap_data = cal_dia_heatmap(report_data)

    if heatmap_data:
        dia_plots.draw_heatmap(sub_section, heatmap_color_list, heatmap_data)
        log.info("Heatmap calculation is done.")


def _process_diann_statistics(report_data):
    """Process DIA-NN statistics and create peptide plot."""
    required_cols = ["Protein.Group", "Modified.Sequence"]
    if not all(col in report_data.columns for col in required_cols):
        log.warning(f"Missing required columns for statistics: {[c for c in required_cols if c not in report_data.columns]}")
        return 0, 0, None

    total_protein_quantified = len(set(report_data["Protein.Group"]))
    total_peptide_count = len(set(report_data["Modified.Sequence"]))

    # Create peptide plot
    log.info("Processing DIA pep_plot.")
    protein_pep_map = report_data.groupby("Protein.Group")["Modified.Sequence"].agg(list).to_dict()
    pep_plot = Histogram("number of peptides per proteins", plot_category="frequency")
    for _, peps in protein_pep_map.items():
        number = len(set(peps))
        pep_plot.add_value(number)

    categorys = OrderedDict()
    categorys["Frequency"] = {
        "name": "Frequency",
        "description": "number of peptides per proteins",
    }

    pep_plot.to_dict(percentage=True, cats=categorys)

    return total_protein_quantified, total_peptide_count, pep_plot


def _process_peptide_search_scores(report_data):
    """Process peptide search scores."""
    required_cols = ["Modified.Sequence", "Q.Value"]
    if not all(col in report_data.columns for col in required_cols):
        log.warning(f"Missing required columns for peptide search scores: {[c for c in required_cols if c not in report_data.columns]}")
        return {}

    log.info("Processing DIA peptide_search_score.")
    peptide_search_score = dict()
    pattern = re.compile(r"\((.*?)\)")
    unimod_data = UnimodDatabase()

    for peptide, group in report_data.groupby("Modified.Sequence"):
        origianl_mods = re.findall(pattern, peptide)
        for mod in set(origianl_mods):
            name = unimod_data.get_by_accession(mod.upper()).get_name()
            peptide = peptide.replace(mod, name)
        if peptide.startswith("("):
            peptide = peptide + "."

        peptide_search_score[peptide] = np.min(group["Q.Value"])

    return peptide_search_score


def _process_modifications(report_data):
    """Process modifications in the report data."""
    if "Modified.Sequence" not in report_data.columns:
        log.warning("Missing Modified.Sequence column for modifications processing")
        return False

    log.info("Processing DIA Modifications.")
    mod_pattern = re.compile(r"\((.*?)\)")
    unimod_data = UnimodDatabase()

    def find_diann_modified(peptide):
        if isinstance(peptide, str):
            mods = mod_pattern.findall(peptide)
            if mods:
                mod_type = [
                    unimod_data.get_by_accession(mod.upper()).get_name() for mod in set(mods)
                ]
                return ",".join(mod_type)
            else:
                return "Unmodified"
        return None

    report_data["Modifications"] = report_data["Modified.Sequence"].apply(find_diann_modified)
    return True


def _process_run_data(df, ms_with_psm, quantms_modified, sdrf_file_df):
    """
    Process run-specific data including modifications and statistics.
    """
    required_cols = ["Run", "Modified.Sequence", "Modifications", "Protein.Group"]
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        log.warning(f"Missing required columns for run data processing: {missing_cols}")
        return {"sdrf_samples": {}, "ms_runs": {}}

    log.info("Processing DIA mod_plot_dict.")

    report_data = df[required_cols].copy()
    if "Proteotypic" in df.columns:
        report_data["Proteotypic"] = df["Proteotypic"]
    else:
        log.warning("Missing Proteotypic column; treating all peptides as proteotypic.")
        report_data["Proteotypic"] = 1

    mod_plot_by_run = dict()
    modified_cats = list()

    statistics_at_run = dict()
    data_per_run = dict()

    for run_file, group in report_data.groupby("Run"):
        run_file = str(run_file)
        ms_with_psm.append(run_file)

        # Process modifications for this run
        mod_plot_dict, modified_cat = summarize_modifications(group.drop_duplicates())
        mod_plot_by_run[run_file] = mod_plot_dict
        modified_cats.extend(modified_cat)

        # Calculate statistics for this run
        statistics_at_run[run_file], data_per_run[run_file] = _calculate_run_statistics(group)

    num_table_at_sample = cal_num_table_at_sample(sdrf_file_df, data_per_run)

    cal_num_table_data = {
        "sdrf_samples": num_table_at_sample,
        "ms_runs": statistics_at_run
    }

    mod_plot_by_sample = dia_sample_level_modifications(
        df=report_data,
        sdrf_file_df=sdrf_file_df
    )

    # Update quantms_modified with processed data
    quantms_modified["plot_data"] = [mod_plot_by_run, mod_plot_by_sample]
    quantms_modified["cats"] = list(
        sorted(modified_cats, key=lambda x: (x == "Modified (Total)", x))
    )

    return cal_num_table_data


def _calculate_run_statistics(group):
    """Calculate statistics for a specific run."""

    peptides = set(group["Modified.Sequence"])
    unique_peptides = set(
        group.loc[group["Proteotypic"] == 1, "Modified.Sequence"]
    )
    modified_pep = list(
        filter(lambda x: re.match(r".*?\(.*?\).*?", x) is not None, peptides)
    )

    stat_run = {
        "protein_num": len(set(group["Protein.Group"])),
        "peptide_num": len(peptides),
        "unique_peptide_num": len(unique_peptides),
        "modified_peptide_num": len(modified_pep)
    }

    data_per_run = {
        "proteins": set(group["Protein.Group"]),
        "peptides": peptides,
        "unique_peptides": unique_peptides,
        "modified_peps": modified_pep
    }

    return stat_run, data_per_run


def _handle_files_without_psm(ms_paths, ms_with_psm, cal_num_table_data):
    """Handle files that don't have PSM data."""
    ms_without_psm = set([file_prefix(i) for i in ms_paths]) - set(ms_with_psm)

    for i in ms_without_psm:
        log.warning(f"No PSM found in '{i}'!")
        cal_num_table_data["ms_runs"][i] = {
            "protein_num": 0,
            "peptide_num": 0,
            "unique_peptide_num": 0,
            "modified_peptide_num": 0,
        }

    return ms_without_psm


def _get_peptide_length(df):

    if "Stripped.Sequence" not in df.columns:
        return None

    df_sub = df[["Run", "Stripped.Sequence"]].copy()
    df_sub["length"] = df_sub["Stripped.Sequence"].str.len()

    plot_data = {}
    for run, group in df_sub.groupby("Run"):
        stats_dict = group["length"].value_counts().sort_index().to_dict()
        plot_data[run] = stats_dict

    return plot_data


## Removed draw_dia_heatmap wrapper; call cal_dia_heatmap and dia_plots.draw_heatmap directly.


def draw_dia_intensitys(sub_section, report_df, sdrf_file_df):
    df_sub = report_df[report_df["Precursor.Quantity"] > 0].copy()
    df_sub["log_intensity"] = np.log2(df_sub["Precursor.Quantity"])

    dia_plots.draw_dia_intensity_dis(sub_section, df_sub, sdrf_file_df)

    dia_plots.draw_dia_intensity_std(sub_section, df_sub, sdrf_file_df)


def draw_dia_ms1(sub_section, df):
    # Ms1.Area: non-normalised MS1 peak area
    if "Ms1.Area" in df.columns:
        df_sub = df[df["Ms1.Area"] > 0][["Ms1.Area", "Run"]].copy()
        if len(df_sub) > 0:
            df_sub["log_ms1_area"] = np.log2(df_sub["Ms1.Area"])
            dia_plots.draw_dia_ms1_area(sub_section, df_sub)


def draw_dia_ms2s(sub_section, df, sdrf_file_df):
    # Distribution of Precursor Charges
    if "Precursor.Charge" in df.columns:
        dia_plots.draw_dia_whole_exp_charge(sub_section, df)

        # Charge-state of Per File
        dia_plots.draw_dia_ms2_charge(sub_section, df, sdrf_file_df)


def draw_dia_mass_error(sub_section, df):
    # Ms1.Apex.Mz.Delta: difference between observed precursor m/z and the theoretical value
    if "Ms1.Apex.Mz.Delta" in df.columns:
        dia_plots.draw_dia_delta_mass(sub_section, df)


# DIA-NN: RT Quality Control
def draw_dia_rt_qc(sub_section, report_df):
    df = report_df.copy()

    # IDs over RT
    draw_dia_ids_rt(sub_section, df)

    # 1. Normalisation Factor over RT
    #   Normalisation.Factor: normalisation factor applied to the precursor in the specific run,
    #   i.e. normalised quantity = normalisation factor X non-normalised quantity
    if "Normalisation.Factor" in df.columns:
        log.info("Draw[rt_qc]: norm_factor_rt")
        norm_factor_rt = cal_feature_avg_rt(df, "Normalisation.Factor")

        if norm_factor_rt:
            dia_plots.draw_norm_factor_rt(sub_section, norm_factor_rt)

    # 2. FWHM over RT
    #   FWHM: estimated peak width at half-maximum
    if "FWHM" in df.columns:
        log.info("Draw[rt_qc]: draw_fwhm_rt")
        fwhm_rt = cal_feature_avg_rt(df, "FWHM")

        if fwhm_rt:
            dia_plots.draw_fwhm_rt(sub_section, fwhm_rt)

    # 3. Peak Width over RT
    #   RT.Start and RT.Stop peak boundaries
    if all(col in df.columns for col in ["RT.Start", "RT.Stop"]):
        log.info("Draw[rt_qc]: draw_peak_width_rt")
        df["peak_width"] = df["RT.Stop"] - df["RT.Start"]
        peak_width_rt = cal_feature_avg_rt(df, "peak_width")

        if peak_width_rt:
            dia_plots.draw_peak_width_rt(sub_section, peak_width_rt)

    # 4. Absolute RT Error over RT
    if all(col in df.columns for col in ["RT", "Predicted.RT"]):
        log.info("Draw[rt_qc]: draw_rt_error_rt")
        df["rt_error"] = abs(df["RT"] - df["Predicted.RT"])
        rt_error_rt = cal_feature_avg_rt(df, "rt_error")

        if rt_error_rt:
            dia_plots.draw_rt_error_rt(sub_section, rt_error_rt)

    # 5. loess(RT ~ iRT)
    if all(col in df.columns for col in ["RT", "iRT"]):
        log.info("Draw[rt_qc]: draw_loess_rt_irt")
        rt_irt_loess = cal_rt_irt_loess(df)

        if rt_irt_loess:
            dia_plots.draw_loess_rt_irt(sub_section, rt_irt_loess)


# DIA-NN: IDs over RT
def draw_dia_ids_rt(sub_section, report_df):
    required_cols = ["Run", "RT"]
    if not all(col in report_df.columns for col in required_cols):
        log.warning(f"Missing required columns for IDs over RT plot: {[c for c in required_cols if c not in report_df.columns]}")
        return

    rt_df = report_df[["Run", "RT"]].copy()
    rt_df.rename(columns={"Run": "raw file", "RT": "retention time"}, inplace=True)
    ids_over_rt = evidence_rt_count(rt_df)
    draw_ids_rt_count(sub_section, ids_over_rt, "dia")


# DIA-NN: Quantification Table
def draw_diann_quant_table(sub_section, diann_report, sample_df, file_df):
    # Peptides Quantification Table
    peptides_table, peptides_headers = create_peptides_table(
        diann_report, sample_df, file_df
    )
    if peptides_table is not None and peptides_headers is not None:
        draw_peptides_table(sub_section, peptides_table, peptides_headers, "DIA-NN")
    else:
        log.warning("Skipping peptides quantification table due to missing data")

    # Protein Quantification Table
    protein_table, protein_headers = create_protein_table(
        diann_report, sample_df, file_df
    )
    if protein_table is not None and protein_headers is not None:
        draw_protein_table(sub_section, protein_table, protein_headers, "DIA-NN")
    else:
        log.warning("Skipping protein quantification table due to missing data")


# Draw: Peptides Quantification Table
def draw_peptides_table(sub_section, table_data, headers, report_type):
    draw_config = {
        "id": "peptides_quantification_table",
        "title": "Peptides Quantification Table",
        "save_file": False,
        "sort_rows": False,
        "only_defined_headers": True,
        "col1_header": "PeptideID",
        "no_violin": True,
        "save_data_file": False,
    }

    # only use the first 50 lines for the table
    display_rows = 50
    table_html = table.plot(
        dict(itertools.islice(table_data.items(), display_rows)),
        headers=headers,
        pconfig=draw_config,
    )

    if report_type == "DIA-NN":
        description_text = """
            This plot shows the quantification information of peptides in the final result (DIA-NN report).
            """
        helptext_text = """
            The quantification information of peptides is obtained from the DIA-NN output file.
            The table shows the quantitative level and distribution of peptides in different study variables,
            run and peptiforms. The distribution show all the intensity values in a bar plot above and below
            the average intensity for all the fractions, runs and peptiforms.

            * BestSearchScore: It is equal to min(1 - Q.Value) for DIA-NN datasets.
            * Average Intensity: Average intensity of each peptide sequence across all conditions (0 or NA ignored).
            * Peptide intensity in each condition (Eg. `CT=Mixture;CN=UPS1;QY=0.1fmol`).
            """
    elif report_type == "mzIdentML":
        description_text = """
            This plot shows the quantification information of peptides in the final result (mzIdentML).
            """
        helptext_text = """
            The quantification information of peptides is obtained from the mzIdentML.
            The table shows the quantitative level and distribution of peptides in different study variables,
            run and peptiforms. The distribution show all the intensity values in a bar plot above and below
            the average intensity for all the fractions, runs and peptiforms.

            * BestSearchScore: It is equal to max(search_engine_score) for mzIdentML datasets.
            * Average Intensity: Average intensity of each peptide sequence (0 or NA ignored).
            """
    else:
        description_text = ""
        helptext_text = ""

    add_sub_section(
        sub_section=sub_section,
        plot=table_html,
        order=1,
        description=description_text,
        helptext=helptext_text,
    )


# Draw: Protein Quantification Table
def draw_protein_table(sub_sections, table_data, headers, report_type):
    draw_config = {
        "id": "protein_quant_result",
        "title": "Protein Quantification Table",
        "save_file": False,
        "sort_rows": False,
        "only_defined_headers": True,
        "col1_header": "ProteinID",
        "no_violin": True,
        "save_data_file": False,
    }

    display_rows = 50
    table_html = table.plot(
        dict(itertools.islice(table_data.items(), display_rows)),
        headers=headers,
        pconfig=draw_config,
    )

    if report_type == "DIA-NN":
        description_text = """
            This plot shows the quantification information of proteins in the final result (DIA-NN report).
            """
        helptext_text = """
            The quantification information of proteins is obtained from the DIA-NN output file.
            The table shows the quantitative level and distribution of proteins in different study variables and run.

            * Peptides_Number: The number of peptides for each protein.
            * Average Intensity: Average intensity of each protein across all conditions (0 or NA ignored).
            * Protein intensity in each condition (Eg. `CT=Mixture;CN=UPS1;QY=0.1fmol`): Summarize intensity of peptides.
            """
    elif report_type == "mzIdentML":
        description_text = """
            This plot shows the quantification information of proteins in the final result (mzIdentML).
            """
        helptext_text = """
            The quantification information of proteins is obtained from the mzIdentML.
            The table shows the quantitative level and distribution of proteins in different study variables and run.

            * Peptides_Number: The number of peptides for each protein.
            * Average Intensity: Average intensity of each protein(0 or NA ignored).
            """
    else:
        description_text = ""
        helptext_text = ""

    add_sub_section(
        sub_section=sub_sections,
        plot=table_html,
        order=2,
        description=description_text,
        helptext=helptext_text,
    )


# DIA-NN: HeatMap
def cal_dia_heatmap(report_df):
    # "Contaminants" & "Peptide Intensity"
    pep_intensity = heatmap_cont_pep_intensity(report_df)

    # missed tryptic cleavages: there is no available data

    return pep_intensity


def heatmap_cont_pep_intensity(report_df):
    require_cols = [
        "Run",
        "Protein.Names",
        "Precursor.Quantity",
        "RT",
        "Predicted.RT",
        "Precursor.Charge",
        "Normalisation.Factor",
        "RT.Stop",
        "RT.Start",
    ]

    if not all(col in report_df.columns for col in require_cols):
        log.warning("Missing require column. Skipping heatmap.")
        return {}

    df = report_df[require_cols].copy()

    # TODO "CON"?
    df["is_contaminant"] = df["Protein.Names"].str.startswith("CON", na=False)

    # 3. "Charge"
    heatmap_charge = cal_hm_charge(
        df=df,
        run_col="Run",
        charge_col="Precursor.Charge"
    )

    heatmap_dict = {}
    for run, group in df.groupby("Run"):

        # 1. "Contaminants"
        cont_intensity_sum = group[group["is_contaminant"]]["Precursor.Quantity"].sum()
        if np.isnan(cont_intensity_sum) or cont_intensity_sum == 0:
            contaminant = 1
        else:
            intensity_sum = group["Precursor.Quantity"].sum()
            contaminant = 1 - cont_intensity_sum / intensity_sum

        # 2. "Peptide Intensity"
        pep_median = np.nanmedian(group["Precursor.Quantity"].to_numpy())
        pep_intensity = float(np.fmin(1.0, pep_median / (2 ** 23)))

        # 4. "RT Alignment"
        rt_alignment = max(0.0, 1 - float(np.mean(np.abs(group["RT"] - group["Predicted.RT"]))))

        # 5. "ID rate over RT"
        ids_rate_over_rt = qual_uniform(group["RT"])

        # 6. Normalization Factor MAD
        def mean_abs_dev(x):
            mean_x = x.mean()
            return float(1 - np.mean(np.abs(x - mean_x)))

        norm_factor_mad = mean_abs_dev(group["Normalisation.Factor"])

        # 7. Peak Width = RT.Stop - RT.Start
        peak_width = max(0.0, 1 - float(np.mean(group["RT.Stop"] - group["RT.Start"])))

        # All Dict
        heatmap_dict[run] = {
            "Contaminants": contaminant,
            "Peptide Intensity": pep_intensity,
            "Charge": heatmap_charge.get(run, 0),
            "RT Alignment": rt_alignment,
            "ID rate over RT": ids_rate_over_rt,
            "Norm Factor": norm_factor_mad,
            "Peak Width": peak_width,
        }

    return heatmap_dict


def cal_feature_avg_rt(report_data, col):
    # RT: the retention time (RT) of the PSM in minutes
    sub_df = report_data[[col, "Run", "RT"]].copy()

    # RT bin
    if sub_df["RT"].notna().sum() < 2 or sub_df["RT"].min() == sub_df["RT"].max():
        return {}

    sub_df["RT_bin"] = pd.cut(
        sub_df["RT"],
        bins=DEFAULT_BINS,
        include_lowest=True,
        duplicates="drop"
    )
    sub_df = sub_df.dropna(subset=["RT_bin"])
    sub_df["RT_bin_mid"] = sub_df["RT_bin"].apply(lambda x: x.mid if hasattr(x, 'mid') else x)

    result = sub_df.groupby(["Run", "RT_bin_mid"], observed=False)[col].mean().reset_index()
    result[col] = result[col].fillna(0)

    plot_dict = {
        str(run): group.set_index("RT_bin_mid")[col].to_dict()
        for run, group in result.groupby("Run")
    }

    return plot_dict


# DIA-NN: Lowess (Loess)
def cal_rt_irt_loess(report_df, frac=0.3, data_bins: int = DEFAULT_BINS):
    if len(report_df) > 1000000:
        log.warning(f"Dataset too large ({len(report_df)} rows). Skipping LOWESS computation.")
        return None

    log.info("Start compute loess...")

    from statsmodels.nonparametric.smoothers_lowess import lowess

    df = report_df.copy()

    # bin
    x_min, x_max = df["iRT"].min(), df["iRT"].max()

    if pd.isna(x_min) or pd.isna(x_max) or x_min == x_max:
        log.warning("iRT values are incorrect. Skipping LOWESS computation.")
        return None

    bins = np.linspace(x_min, x_max, data_bins)

    plot_dict = dict()
    for run, group in df.groupby("Run"):

        group_sorted = group.sort_values("iRT")
        x = group_sorted["iRT"].values
        y = group_sorted["RT"].values

        # lowess
        smoothed = lowess(y, x, frac=frac)
        smoothed_x = smoothed[:, 0]
        smoothed_y = smoothed[:, 1]

        bin_indices = np.digitize(smoothed_x, bins)
        binned_dict = dict()
        for i in range(1, len(bins)):
            mask = bin_indices == i
            if np.any(mask):
                x_bin_mean = float(smoothed_x[mask].mean())
                y_bin_mean = float(smoothed_y[mask].mean())
                binned_dict[x_bin_mean] = y_bin_mean

        plot_dict[run] = binned_dict

    return plot_dict


def _prepare_quant_table_data(report_df):
    """
    Common preprocessing for quantification table creation.

    Returns:
        pd.DataFrame: Preprocessed report data with positive intensity values,
                      or None if required columns are missing.
    """
    # Check for required columns
    required_cols = ["Protein.Names", "Stripped.Sequence"]
    missing_cols = [col for col in required_cols if col not in report_df.columns]
    if missing_cols:
        log.warning(f"Missing required columns for quantification table: {missing_cols}")
        return None

    # Use Precursor.Normalised if available, otherwise fall back to Precursor.Quantity
    if "Precursor.Normalised" in report_df.columns:
        intensity_col = "Precursor.Normalised"
    elif "Precursor.Quantity" in report_df.columns:
        intensity_col = "Precursor.Quantity"
        log.info("Using Precursor.Quantity as fallback (Precursor.Normalised not available)")
    else:
        log.warning("Neither Precursor.Normalised nor Precursor.Quantity found. Skipping quantification table.")
        return None

    report_data = report_df[report_df[intensity_col] > 0].copy()
    # Store which intensity column is being used for downstream functions
    report_data.attrs["intensity_col"] = intensity_col
    return drop_empty_row(report_data, ["Protein.Names", "Stripped.Sequence"])


def _merge_condition_data(report_data, sample_df, file_df):
    """
    Merge report data with condition information from sample/file DataFrames.

    Returns:
        tuple: (merged DataFrame with condition info, list of unique conditions) or (None, [])
    """
    if sample_df.empty or file_df.empty:
        return None, []

    # Get the intensity column used (stored by _prepare_quant_table_data)
    intensity_col = report_data.attrs.get("intensity_col", "Precursor.Normalised")
    if intensity_col not in report_data.columns:
        # Fallback check
        if "Precursor.Normalised" in report_data.columns:
            intensity_col = "Precursor.Normalised"
        elif "Precursor.Quantity" in report_data.columns:
            intensity_col = "Precursor.Quantity"
        else:
            log.warning("No intensity column found for condition data merge")
            return None, []

    sample_cond_df = pd.merge(
        sample_df[["Sample", "MSstats_Condition"]],
        file_df[["Sample", "Spectra_Filepath"]],
        on="Sample",
    )
    # Vectorized path splitting (more efficient than apply with lambda)
    sample_cond_df["Run"] = sample_cond_df["Spectra_Filepath"].str.rsplit(".", n=1).str[0]

    cond_report_data = pd.merge(
        report_data[["Stripped.Sequence", "Protein.Names", intensity_col, "Run"]],
        sample_cond_df[["Run", "MSstats_Condition"]].drop_duplicates(),
        on="Run",
    )
    # Store intensity column for downstream use
    cond_report_data.attrs["intensity_col"] = intensity_col

    unique_conditions = sample_df["MSstats_Condition"].drop_duplicates().tolist()
    return cond_report_data, unique_conditions


def _add_condition_headers(headers, conditions):
    """Add condition-based headers to the headers dictionary."""
    for exp_condition in conditions:
        headers[str(exp_condition)] = {
            "title": str(exp_condition),
            "description": "MSstats Condition",
            "format": "{:,.4f}",
        }


# DIA-NN: Peptides Quantification Table
def create_peptides_table(report_df, sample_df, file_df):
    """Create peptides quantification table from DIA-NN report.

    Returns:
        tuple: (table_dict, headers) or (None, None) if required columns are missing.
    """
    report_data = _prepare_quant_table_data(report_df)
    if report_data is None or report_data.empty:
        log.warning("Cannot create peptides table: missing required data")
        return None, None

    # Get the intensity column being used
    intensity_col = report_data.attrs.get("intensity_col", "Precursor.Normalised")

    # Check for Q.Value column for search score
    has_qvalue = "Q.Value" in report_data.columns
    if has_qvalue:
        report_data["BestSearchScore"] = 1 - report_data["Q.Value"]

    table_dict = {}
    for sequence_protein, group in report_data.groupby(["Stripped.Sequence", "Protein.Names"]):
        entry = {
            "ProteinName": sequence_protein[1],
            "PeptideSequence": sequence_protein[0],
            "Average Intensity": np.log10(group[intensity_col].mean()),
        }
        if has_qvalue:
            entry["BestSearchScore"] = group["BestSearchScore"].min()
        table_dict[sequence_protein] = entry

    headers = {
        "ProteinName": {
            "title": "Protein Name",
            "description": "Name/Identifier(s) of the protein (group)",
            "minrange": "200",
        },
        "PeptideSequence": {"title": "Peptide Sequence"},
        "Average Intensity": {
            "title": "Average Intensity",
            "description": "Average intensity across all conditions",
            "format": "{:,.4f}",
        },
    }
    if has_qvalue:
        headers["BestSearchScore"] = {"title": "Best Search Score", "format": "{:,.4f}"}

    cond_report_data, unique_conditions = _merge_condition_data(report_data, sample_df, file_df)
    if cond_report_data is not None and not cond_report_data.empty:
        cond_intensity_col = cond_report_data.attrs.get("intensity_col", intensity_col)
        for sequence_protein, group in cond_report_data.groupby(
                ["Stripped.Sequence", "Protein.Names"]
        ):
            condition_data = {
                str(cond): np.log10(sub_group[cond_intensity_col].mean())
                for cond, sub_group in group.groupby("MSstats_Condition")
            }
            if sequence_protein in table_dict:
                table_dict[sequence_protein].update(condition_data)

        _add_condition_headers(headers, unique_conditions)

    result_dict = {i: v for i, (_, v) in enumerate(table_dict.items(), start=1)}
    return result_dict, headers


# DIA-NN: Protein Quantification Table
def create_protein_table(report_df, sample_df, file_df):
    """Create protein quantification table from DIA-NN report.

    Returns:
        tuple: (table_dict, headers) or (None, None) if required columns are missing.
    """
    report_data = _prepare_quant_table_data(report_df)
    if report_data is None or report_data.empty:
        log.warning("Cannot create protein table: missing required data")
        return None, None

    # Get the intensity column being used
    intensity_col = report_data.attrs.get("intensity_col", "Precursor.Normalised")

    table_dict = {}
    for protein_name, group in report_data.groupby("Protein.Names"):
        table_dict[protein_name] = {
            "ProteinName": protein_name,
            "Peptides_Number": group["Stripped.Sequence"].nunique(),
            "Average Intensity": np.log10(group[intensity_col].mean()),
        }

    headers = {
        "ProteinName": {
            "title": "Protein Name",
            "description": "Name/Identifier(s) of the protein (group)",
        },
        "Peptides_Number": {
            "title": "Number of Peptides",
            "description": "Number of peptides per proteins",
            "format": "{:,.0f}",
        },
        "Average Intensity": {
            "title": "Average Intensity",
            "description": "Average intensity across all conditions",
            "format": "{:,.4f}",
        },
    }

    cond_report_data, unique_conditions = _merge_condition_data(report_data, sample_df, file_df)
    if cond_report_data is not None and not cond_report_data.empty:
        cond_intensity_col = cond_report_data.attrs.get("intensity_col", intensity_col)
        for protein_name, group in cond_report_data.groupby("Protein.Names"):
            condition_data = {
                str(cond): np.log10(sub_group[cond_intensity_col].mean())
                for cond, sub_group in group.groupby("MSstats_Condition")
            }
            if protein_name in table_dict:
                table_dict[protein_name].update(condition_data)

        _add_condition_headers(headers, unique_conditions)

    result_dict = {i: v for i, (_, v) in enumerate(table_dict.items(), start=1)}
    return result_dict, headers


def dia_sample_level_modifications(df, sdrf_file_df):

    if sdrf_file_df is None or sdrf_file_df.empty:
        return {}

    report_data = df.copy()

    report_data = report_data.merge(
        right=sdrf_file_df[["Sample", "Run"]].drop_duplicates(),
        on="Run"
    )

    report_data["Sample"] = report_data["Sample"].astype(int)

    mod_plot = dict()
    for sample, group in report_data.groupby("Sample", sort=True):

        mod_plot_dict, _ = summarize_modifications(
            group.drop_duplicates()
        )
        mod_plot[f"Sample {str(sample)}"] = mod_plot_dict

    return mod_plot


def parse_diann_version(log_file_path):
    """Parse the DIA-NN version from a DIA-NN log file (report.log.txt).

    The DIA-NN log file typically starts with a line like:
        DIA-NN 1.8.1 (Data-Independent Acquisition by Neural Networks)

    Args:
        log_file_path: Path to the DIA-NN log file.

    Returns:
        Version string (e.g. "1.8.1") or None if not found.
    """
    version_pattern = re.compile(r"^DIA-NN\s+(\d+(?:\.\d+)*)", re.IGNORECASE)
    try:
        with open(log_file_path, "r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                match = version_pattern.match(line.strip())
                if match:
                    return match.group(1)
                # Version line is expected near the top; stop after 20 lines
                if i >= 20:
                    break
    except Exception as e:
        log.warning(f"Could not parse DIA-NN version from {log_file_path}: {e}")
    return None


def draw_diann_metadata_table(sub_section, diann_version):
    """Draw a metadata table showing DIA-NN software version.

    Args:
        sub_section: The sub-section list to add the table to.
        diann_version: DIA-NN version string to display.
    """
    if not diann_version:
        return

    table_data = {
        1: {
            "parameter": "DIA-NN Version",
            "value": diann_version,
        }
    }

    draw_config = {
        "id": "diann_metadata",
        "title": "DIA-NN Metadata",
        "save_file": False,
        "sort_rows": False,
        "only_defined_headers": True,
        "col1_header": "No.",
        "no_violin": True,
        "save_data_file": False,
    }

    headers = {
        "parameter": {"title": "Parameter"},
        "value": {"title": "Value"},
    }

    table_html = table.plot(data=table_data, headers=headers, pconfig=draw_config)

    add_sub_section(
        sub_section=sub_section,
        plot=table_html,
        order=0,
        description="This table presents the DIA-NN software version used for the analysis.",
        helptext="""
            DIA-NN metadata, extracted from the DIA-NN log file (report.log.txt), shows the
            version of DIA-NN used for data-independent acquisition analysis.
            """,
    )
