# Package init for common plots

