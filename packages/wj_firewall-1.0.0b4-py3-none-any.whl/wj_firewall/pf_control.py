# ────────────────────────────────────────────────────────────────────────────────────────
#   pf_control.py
#   ─────────────
#
#   Controls PF via pfctl commands. Expects the process to already be
#   running as root (the CLI relaunches itself under sudo if needed).
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import logging
import subprocess
from pathlib import Path

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

PFCTL = "/sbin/pfctl"
DEFAULT_PF_CONF = Path("/etc/pf.conf")
ANCHOR_NAME = "wj-firewall"
ANCHOR_PATH = Path("/etc/pf.anchors/wj-firewall")

LAUNCHD_LABEL = "com.waterjuice.wj-firewall"
LAUNCHD_PLIST_PATH = Path(f"/Library/LaunchDaemons/{LAUNCHD_LABEL}.plist")
_LAUNCHD_PLIST_CONTENT = f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" \
"http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
\t<key>Label</key>
\t<string>{LAUNCHD_LABEL}</string>
\t<key>Program</key>
\t<string>{PFCTL}</string>
\t<key>ProgramArguments</key>
\t<array>
\t\t<string>pfctl</string>
\t\t<string>-e</string>
\t</array>
\t<key>RunAtLoad</key>
\t<true/>
</dict>
</plist>
"""

log = logging.getLogger(__name__)

# ────────────────────────────────────────────────────────────────────────────────────────
#   Functions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def is_pf_enabled() -> bool:
    """
    Check if PF is currently enabled.
    Parses output of ``pfctl -s info``. Requires root privileges
    (``/dev/pf`` is not world-readable on macOS).
    """
    ok, output = _run_privileged(f"{PFCTL} -s info")
    if not ok:
        log.error("Failed to check PF status: %s", output)
        return False
    for line in output.splitlines():
        if line.strip().startswith("Status:"):
            return "Enabled" in line
    return False


# ────────────────────────────────────────────────────────────────────────────────────────
def enable_pf() -> tuple[bool, str]:
    """
    Enable PF. Requires root privileges.
    Returns (success, message).
    """
    return _run_privileged(f"{PFCTL} -e")


# ────────────────────────────────────────────────────────────────────────────────────────
def reload_pf_conf(config_path: Path = DEFAULT_PF_CONF) -> tuple[bool, str]:
    """
    Reload the full PF configuration from the given file.
    Requires root privileges. Returns (success, message).
    """
    return _run_privileged(f"{PFCTL} -f {config_path}")


# ────────────────────────────────────────────────────────────────────────────────────────
def reload_anchor(
    anchor: str = ANCHOR_NAME, path: Path = ANCHOR_PATH
) -> tuple[bool, str]:
    """
    Reload only the wj-firewall anchor from its anchor file.
    This is faster than reloading all of pf.conf and does not disturb
    other PF rules. Returns (success, message).
    """
    return _run_privileged(f"{PFCTL} -a {anchor} -f {path}")


# ────────────────────────────────────────────────────────────────────────────────────────
def flush_states_on_interface(iface: str) -> tuple[bool, str]:
    """
    Flush all PF state entries associated with a given interface.

    Existing state entries bypass rule evaluation entirely, so after
    adding block rules for an interface we must flush its states —
    otherwise previously established connections continue to pass.
    """
    return _run_privileged(f"{PFCTL} -i {iface} -Fs")


# ────────────────────────────────────────────────────────────────────────────────────────
def write_file_privileged(content: str, path: Path) -> tuple[bool, str]:
    """
    Write *content* to *path* using elevated privileges.
    Returns (success, message).
    """
    # Escape single quotes and backslashes for the shell command.
    escaped = content.replace("\\", "\\\\").replace("'", "'\\''")
    command = f"printf '%s' '{escaped}' > {path}"
    return _run_privileged(command)


# ────────────────────────────────────────────────────────────────────────────────────────
def delete_file_privileged(path: Path) -> tuple[bool, str]:
    """
    Delete *path* using elevated privileges.
    Returns (success, message).
    """
    return _run_privileged(f"rm -f {path}")


# ────────────────────────────────────────────────────────────────────────────────────────
def is_launch_daemon_installed() -> bool:
    """Check whether the wj-firewall launch daemon plist exists."""
    return LAUNCHD_PLIST_PATH.exists()


# ────────────────────────────────────────────────────────────────────────────────────────
def install_launch_daemon() -> tuple[bool, str]:
    """
    Install a launchd daemon that enables PF at boot.

    Writes the plist to ``/Library/LaunchDaemons/`` and loads it via
    ``launchctl``. If the plist already exists, it is overwritten and
    reloaded.
    """
    ok, msg = write_file_privileged(_LAUNCHD_PLIST_CONTENT, LAUNCHD_PLIST_PATH)
    if not ok:
        return False, f"Failed to write launch daemon plist: {msg}"
    ok, msg = _run_privileged(f"launchctl load -w {LAUNCHD_PLIST_PATH}")
    if not ok:
        return False, f"Failed to load launch daemon: {msg}"
    return True, "Launch daemon installed."


# ────────────────────────────────────────────────────────────────────────────────────────
def remove_launch_daemon() -> tuple[bool, str]:
    """
    Remove the wj-firewall launch daemon.

    Unloads the daemon via ``launchctl`` and deletes the plist file.
    """
    if not LAUNCHD_PLIST_PATH.exists():
        return True, "Launch daemon not installed."
    _run_privileged(f"launchctl unload {LAUNCHD_PLIST_PATH}")
    ok, msg = delete_file_privileged(LAUNCHD_PLIST_PATH)
    if not ok:
        return False, f"Failed to delete launch daemon plist: {msg}"
    return True, "Launch daemon removed."


# ────────────────────────────────────────────────────────────────────────────────────────
def _run_privileged(command: str) -> tuple[bool, str]:
    """
    Run a shell command that requires root privileges.

    The process must already be running as root — the CLI entry point
    relaunches itself under ``sudo`` before any privileged commands
    are executed.
    """
    log.debug("Running privileged command: %s", command)
    shell_cmd = ["sh", "-c", command]

    try:
        result = subprocess.run(
            shell_cmd,  # noqa: S603
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            log.debug("Privileged command succeeded")
            # pfctl writes most output to stderr, so combine both streams.
            combined = (result.stdout + "\n" + result.stderr).strip()
            return True, combined
        error = result.stderr.strip() or result.stdout.strip()
        log.error("Privileged command failed: %s", error)
        return False, error
    except subprocess.TimeoutExpired:
        log.error("Privileged command timed out")
        return False, "Command timed out"
    except (subprocess.SubprocessError, OSError) as e:
        log.error("Failed to run privileged command: %s", e)
        return False, str(e)
