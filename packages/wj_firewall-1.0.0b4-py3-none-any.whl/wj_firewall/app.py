# ────────────────────────────────────────────────────────────────────────────────────────
#   app.py
#   ──────
#
#   Interactive curses TUI for configuring macOS PF firewall rules.
#   Allows per-interface blocking of incoming traffic.
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import curses
import locale
import logging
import sys
import traceback
from dataclasses import dataclass
from dataclasses import field
from .apply import apply_rules
from .interfaces import NetworkInterface
from .interfaces import get_interfaces
from .pf_config import check_pf_conf_anchor
from .pf_config import read_blocked_interfaces
from .pf_control import is_launch_daemon_installed
from .pf_control import is_pf_enabled
from .rules import BlockedInterfaces
from .version import VERSION_STR

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

# Colour pair IDs.
_PAIR_GREEN = 1
_PAIR_RED = 2
_PAIR_DIM = 3
_PAIR_YELLOW = 4
_PAIR_CYAN = 5


# ────────────────────────────────────────────────────────────────────────────────────────
#   Application State
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class AppState:
    """All mutable state for the TUI."""

    interfaces: list[NetworkInterface] = field(
        default_factory=lambda: list[NetworkInterface]()
    )
    blocked: BlockedInterfaces = field(default_factory=BlockedInterfaces)
    saved_blocked: BlockedInterfaces = field(default_factory=BlockedInterfaces)
    cursor_row: int = 0
    scroll_offset: int = 0
    pf_enabled: bool = False
    anchor_ok: bool = False
    boot_enabled: bool = False
    status_message: str = ""
    status_is_error: bool = False
    editing_ports: bool = False
    port_input_buffer: str = ""
    last_apply_error: str = ""


# ────────────────────────────────────────────────────────────────────────────────────────
#   Rendering
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _render(stdscr: curses.window, state: AppState) -> None:
    """Redraw the entire screen."""
    stdscr.erase()
    height, width = stdscr.getmaxyx()

    usable_w = width - 1  # avoid writing to the very last column

    # Compute column layout based on terminal width.
    # Fixed columns up to col 60, then Open Ports stretches to fill
    # available width (capped at 99 usable / 100 terminal columns).
    c_if, c_ip, c_in, c_ic, c_pt = 2, 22, 42, 53, 60
    table_w = min(99, max(60, usable_w))
    if usable_w >= 79:
        # Standard layout (80+ column terminals).
        h_if, h_ip, h_in = "Interface", "IP Address", "Incoming"
        h_ic, h_pt = "ICMP", "Open Ports"
        u_if, u_ip, u_in, u_ic = 18, 18, 10, 5
        u_pt = table_w - c_pt - 1
        show_icmp = show_ports = True
    elif usable_w >= 55:
        # Compact layout (55\u201378 column terminals).
        c_if, c_ip, c_in, c_ic, c_pt = 1, 14, 30, 41, 47
        h_if, h_ip, h_in = "Iface", "IP", "Incoming"
        h_ic, h_pt = "ICMP", "Ports"
        u_if, u_ip, u_in, u_ic = 11, 14, 10, 5
        u_pt = max(5, usable_w - c_pt - 1)
        show_icmp = show_ports = True
        table_w = usable_w
    else:
        # Minimal layout (< 55 column terminals).
        c_if, c_ip, c_in = 1, 13, 28
        c_ic = c_pt = 0
        h_if, h_ip, h_in = "Iface", "IP", "In"
        h_ic = h_pt = ""
        u_if, u_ip, u_in = 10, 13, max(5, usable_w - 29)
        u_ic = u_pt = 0
        show_icmp = show_ports = False
        table_w = usable_w

    sep = "\u2500" * min(table_w, usable_w)
    row = 0

    # Title row
    title = f" WaterJuice Firewall {VERSION_STR}"
    _safe_addstr(stdscr, row, 0, title, curses.A_BOLD | curses.color_pair(_PAIR_CYAN))
    cli_hint = "CLI: wj-firewall --help "
    hint_x = max(0, min(table_w, usable_w) - len(cli_hint))
    if hint_x > len(title):
        _safe_addstr(stdscr, row, hint_x, cli_hint, curses.color_pair(_PAIR_DIM))
    row += 1

    # Status indicators
    pf_text = "PF: Enabled" if state.pf_enabled else "PF: Disabled"
    pf_attr = (
        curses.color_pair(_PAIR_GREEN)
        if state.pf_enabled
        else curses.color_pair(_PAIR_RED)
    )
    _safe_addstr(stdscr, row, 2, pf_text, pf_attr | curses.A_BOLD)

    anchor_text = "Anchor: OK" if state.anchor_ok else "Anchor: Missing"
    anchor_attr = (
        curses.color_pair(_PAIR_GREEN)
        if state.anchor_ok
        else curses.color_pair(_PAIR_RED)
    )
    anchor_col = max(0, len(pf_text) + 5)
    _safe_addstr(stdscr, row, anchor_col, anchor_text, anchor_attr | curses.A_BOLD)

    boot_text = "Boot: Enabled" if state.boot_enabled else "Boot: Off"
    boot_attr = (
        curses.color_pair(_PAIR_GREEN)
        if state.boot_enabled
        else curses.color_pair(_PAIR_DIM)
    )
    boot_col = anchor_col + len(anchor_text) + 5
    _safe_addstr(stdscr, row, boot_col, boot_text, boot_attr | curses.A_BOLD)

    # Hint when PF or anchor needs fixing.
    if not state.pf_enabled or not state.anchor_ok:
        hint_col = boot_col + len(boot_text) + 3
        _safe_addstr(
            stdscr,
            row,
            hint_col,
            "(press a to fix)",
            curses.color_pair(_PAIR_YELLOW),
        )
    row += 1

    # Separator
    _safe_addstr(stdscr, row, 0, sep, curses.color_pair(_PAIR_DIM))
    row += 2

    # Column headers
    _safe_addstr(stdscr, row, c_if, h_if, curses.A_BOLD)
    _safe_addstr(stdscr, row, c_ip, h_ip, curses.A_BOLD)
    _safe_addstr(stdscr, row, c_in, h_in, curses.A_BOLD)
    if show_icmp:
        _safe_addstr(stdscr, row, c_ic, h_ic, curses.A_BOLD)
    if show_ports:
        _safe_addstr(stdscr, row, c_pt, h_pt, curses.A_BOLD)
    row += 1
    _safe_addstr(stdscr, row, c_if, "\u2500" * u_if, curses.color_pair(_PAIR_DIM))
    _safe_addstr(stdscr, row, c_ip, "\u2500" * u_ip, curses.color_pair(_PAIR_DIM))
    _safe_addstr(stdscr, row, c_in, "\u2500" * u_in, curses.color_pair(_PAIR_DIM))
    if show_icmp:
        _safe_addstr(stdscr, row, c_ic, "\u2500" * u_ic, curses.color_pair(_PAIR_DIM))
    if show_ports:
        _safe_addstr(stdscr, row, c_pt, "\u2500" * u_pt, curses.color_pair(_PAIR_DIM))
    row += 1

    # Interface rows (scrolled viewport).
    # Reserve rows for: bottom separator (2), help bar (1), unsaved indicator (1), status (1).
    max_iface_rows = max(1, height - row - 5)
    visible_start = state.scroll_offset
    visible_end = min(len(state.interfaces), visible_start + max_iface_rows)

    for i in range(visible_start, visible_end):
        iface = state.interfaces[i]
        is_selected = i == state.cursor_row
        base_attr = curses.A_REVERSE if is_selected else 0

        # Highlight bar spans the table width, not the full screen.
        if is_selected:
            bar_w = min(table_w, usable_w)
            _safe_addstr(stdscr, row, 0, " " * bar_w, base_attr)

        # Interface name — truncate with ellipsis if too long.
        label = iface.name
        if iface.description:
            label = f"{iface.name} ({iface.description})"
        max_label = c_ip - c_if - 1
        if len(label) > max_label:
            label = label[: max_label - 1] + "\u2026"
        _safe_addstr(
            stdscr,
            row,
            c_if,
            label,
            base_attr | curses.color_pair(_PAIR_GREEN),
        )

        # IP address — prefer IPv4, fall back to [IPv6] label.
        ipv4 = [a for a in iface.addresses if "." in a]
        if ipv4:
            ip_text = ipv4[0]
            max_ip = c_in - c_ip - 1
            _safe_addstr(
                stdscr,
                row,
                c_ip,
                ip_text[:max_ip],
                base_attr | curses.color_pair(_PAIR_CYAN),
            )
        elif iface.addresses:
            _safe_addstr(
                stdscr,
                row,
                c_ip,
                "[IPv6]",
                base_attr | curses.color_pair(_PAIR_DIM),
            )
        else:
            _safe_addstr(
                stdscr,
                row,
                c_ip,
                "\u2014",
                base_attr | curses.color_pair(_PAIR_DIM),
            )

        # Incoming toggle
        if state.blocked.is_blocked(iface.name):
            _safe_addstr(
                stdscr,
                row,
                c_in,
                "\u25a0 BLOCKED",
                base_attr | curses.color_pair(_PAIR_RED) | curses.A_BOLD,
            )
            # ICMP column
            if show_icmp and state.blocked.is_icmp_blocked(iface.name):
                _safe_addstr(
                    stdscr,
                    row,
                    c_ic,
                    "block",
                    base_attr | curses.color_pair(_PAIR_RED) | curses.A_BOLD,
                )
            # Exceptions column (ports only)
            if show_ports:
                detail = _format_exceptions(state, iface.name)
                if detail:
                    _safe_addstr(
                        stdscr,
                        row,
                        c_pt,
                        detail,
                        base_attr | curses.color_pair(_PAIR_YELLOW),
                    )
        else:
            _safe_addstr(
                stdscr,
                row,
                c_in,
                "\u25a1 allowed",
                base_attr | curses.color_pair(_PAIR_DIM),
            )

        row += 1

    # Bottom separator
    row += 1
    if row < height - 2:
        _safe_addstr(stdscr, row, 0, sep, curses.color_pair(_PAIR_DIM))
        row += 1

    # Help bar / port editing prompt
    if row < height - 1:
        if state.editing_ports:
            prompt = (
                f" Port: {state.port_input_buffer}\u2588"
                "  (Enter=toggle  i=ICMP  Esc=cancel)"
            )
            _safe_addstr(
                stdscr,
                row,
                0,
                prompt,
                curses.color_pair(_PAIR_YELLOW) | curses.A_BOLD,
            )
        else:
            help_text = (
                " \u2191\u2193 Navigate   Space Toggle   p Ports"
                "   i ICMP   a Apply   r Revert   q Quit"
            )
            _safe_addstr(stdscr, row, 0, help_text, curses.color_pair(_PAIR_CYAN))
        row += 1

    # Unsaved changes indicator
    if _has_unsaved_changes(state) and row < height:
        _safe_addstr(
            stdscr,
            row,
            1,
            "[unsaved changes]",
            curses.color_pair(_PAIR_YELLOW),
        )
        row += 1

    # Status message
    if state.status_message and row < height:
        msg_attr = (
            curses.color_pair(_PAIR_RED)
            if state.status_is_error
            else curses.color_pair(_PAIR_GREEN)
        )
        _safe_addstr(stdscr, row, 1, state.status_message, msg_attr)

    stdscr.refresh()


# ────────────────────────────────────────────────────────────────────────────────────────
def _safe_addstr(stdscr: curses.window, y: int, x: int, text: str, attr: int) -> None:
    """Write text to the screen, silently ignoring curses errors (e.g. writing past edge)."""
    try:
        stdscr.addstr(y, x, text, attr)
    except curses.error:
        pass


# ────────────────────────────────────────────────────────────────────────────────────────
#   Actions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _toggle_current(state: AppState) -> None:
    """Toggle the blocked state of the currently selected interface."""
    if 0 <= state.cursor_row < len(state.interfaces):
        iface = state.interfaces[state.cursor_row]
        state.blocked.toggle(iface.name)


# ────────────────────────────────────────────────────────────────────────────────────────
def _apply(state: AppState) -> None:
    """Write the anchor file and reload PF."""
    ok, msg = apply_rules(state.blocked)
    if not ok:
        state.status_message = "Apply failed — press a to retry."
        state.status_is_error = True
        state.last_apply_error = msg
        return

    state.saved_blocked = state.blocked.copy()
    state.pf_enabled = is_pf_enabled()
    state.anchor_ok = check_pf_conf_anchor()
    state.boot_enabled = is_launch_daemon_installed()
    state.status_message = msg
    state.status_is_error = False
    state.last_apply_error = ""


# ────────────────────────────────────────────────────────────────────────────────────────
def _revert(state: AppState) -> None:
    """Discard changes and restore the last applied state."""
    state.blocked = state.saved_blocked.copy()
    state.status_message = "Reverted to last applied state."
    state.status_is_error = False


# ────────────────────────────────────────────────────────────────────────────────────────
def _adjust_scroll(state: AppState, visible_rows: int) -> None:
    """Ensure cursor_row is visible within the scrolled viewport."""
    if state.cursor_row < state.scroll_offset:
        state.scroll_offset = state.cursor_row
    elif state.cursor_row >= state.scroll_offset + visible_rows:
        state.scroll_offset = state.cursor_row - visible_rows + 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _format_exceptions(state: AppState, iface_name: str) -> str:
    """Format the port exceptions list for an interface (e.g. '22, 80, 443')."""
    parts = [str(p) for p in sorted(state.blocked.get_allowed_ports(iface_name))]
    return ", ".join(parts)


# ────────────────────────────────────────────────────────────────────────────────────────
def _handle_port_input(state: AppState) -> None:
    """Process the port input buffer: validate and toggle the port."""
    text = state.port_input_buffer.strip()
    state.port_input_buffer = ""

    if not text:
        return

    try:
        port = int(text)
    except ValueError:
        state.status_message = f"Invalid port: {text}"
        state.status_is_error = True
        state.editing_ports = False
        return

    if port < 1 or port > 65535:
        state.status_message = f"Port must be 1\u201365535, got {port}."
        state.status_is_error = True
        state.editing_ports = False
        return

    iface = state.interfaces[state.cursor_row]
    state.blocked.toggle_allowed_port(iface.name, port)

    # Stay in editing mode for quick multi-port entry.
    detail = _format_exceptions(state, iface.name)
    if detail:
        state.status_message = f"Allowed on {iface.name}: {detail}"
    else:
        state.status_message = f"No exceptions on {iface.name}."
    state.status_is_error = False


# ────────────────────────────────────────────────────────────────────────────────────────
def _has_unsaved_changes(state: AppState) -> bool:
    """Check whether the current state differs from the last applied state."""
    return (
        state.blocked.interfaces != state.saved_blocked.interfaces
        or state.blocked.allowed_ports != state.saved_blocked.allowed_ports
        or state.blocked.block_icmp != state.saved_blocked.block_icmp
    )


# ────────────────────────────────────────────────────────────────────────────────────────
#   Curses Main
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _init_colours() -> None:
    """Set up curses colour pairs."""
    curses.start_color()
    curses.use_default_colors()
    curses.init_pair(_PAIR_GREEN, curses.COLOR_GREEN, -1)
    curses.init_pair(_PAIR_RED, curses.COLOR_RED, -1)
    curses.init_pair(_PAIR_DIM, curses.COLOR_WHITE, -1)
    curses.init_pair(_PAIR_YELLOW, curses.COLOR_YELLOW, -1)
    curses.init_pair(_PAIR_CYAN, curses.COLOR_CYAN, -1)


# ────────────────────────────────────────────────────────────────────────────────────────
def _curses_main(stdscr: curses.window) -> tuple[int, str]:
    """Main curses loop."""
    _init_colours()
    curses.curs_set(0)

    # Load initial state.
    blocked = read_blocked_interfaces()
    interfaces = get_interfaces(keep_interfaces=blocked.interfaces)
    state = AppState(
        interfaces=interfaces,
        blocked=blocked,
        saved_blocked=blocked.copy(),
        pf_enabled=is_pf_enabled(),
        anchor_ok=check_pf_conf_anchor(),
        boot_enabled=is_launch_daemon_installed(),
    )

    # If there are no interfaces, show an error and exit.
    if not interfaces:
        state.status_message = "No network interfaces detected."
        state.status_is_error = True
        _render(stdscr, state)
        stdscr.getch()
        return 1, ""

    quit_pending = False

    while True:
        _render(stdscr, state)
        key = stdscr.getch()

        # Port editing mode — intercept all keys.
        if state.editing_ports:
            if key == 27:  # Escape
                state.editing_ports = False
                state.port_input_buffer = ""
            elif key in (ord("i"), ord("I")) and not state.port_input_buffer:
                # Toggle ICMP blocking (instant, no Enter needed).
                iface = state.interfaces[state.cursor_row]
                state.blocked.toggle_icmp(iface.name)
                if state.blocked.is_icmp_blocked(iface.name):
                    state.status_message = f"ICMP blocked on {iface.name}."
                else:
                    state.status_message = f"ICMP allowed on {iface.name}."
                state.status_is_error = False
            elif key in (curses.KEY_ENTER, ord("\n"), ord("\r")):
                _handle_port_input(state)
            elif key in (curses.KEY_BACKSPACE, 127, ord("\b")):
                state.port_input_buffer = state.port_input_buffer[:-1]
            elif 48 <= key <= 57:  # digits 0-9
                if len(state.port_input_buffer) < 5:  # max 65535
                    state.port_input_buffer += chr(key)
            continue

        # Clear transient status on any keypress (unless confirming quit).
        if not quit_pending:
            state.status_message = ""
            state.status_is_error = False

        # Quit (with unsaved confirmation).
        if key in (ord("q"), ord("Q")):
            if quit_pending:
                break
            if _has_unsaved_changes(state):
                state.status_message = "Unsaved changes! Press q again to quit."
                state.status_is_error = True
                quit_pending = True
                continue
            break

        quit_pending = False

        # Navigation.
        if key in (curses.KEY_UP, ord("k")):
            state.cursor_row = max(0, state.cursor_row - 1)
        elif key in (curses.KEY_DOWN, ord("j")):
            state.cursor_row = min(len(state.interfaces) - 1, state.cursor_row + 1)

        # Toggle.
        elif key == ord(" "):
            _toggle_current(state)

        # Port editing.
        elif key in (ord("p"), ord("P")):
            if 0 <= state.cursor_row < len(state.interfaces):
                iface = state.interfaces[state.cursor_row]
                if state.blocked.is_blocked(iface.name):
                    state.editing_ports = True
                    state.port_input_buffer = ""
                else:
                    state.status_message = (
                        "Block the interface first, then add port exceptions."
                    )
                    state.status_is_error = True

        # ICMP toggle.
        elif key in (ord("i"), ord("I")):
            if 0 <= state.cursor_row < len(state.interfaces):
                iface = state.interfaces[state.cursor_row]
                if state.blocked.is_blocked(iface.name):
                    state.blocked.toggle_icmp(iface.name)
                    if state.blocked.is_icmp_blocked(iface.name):
                        state.status_message = f"ICMP blocked on {iface.name}."
                    else:
                        state.status_message = f"ICMP allowed on {iface.name}."
                    state.status_is_error = False
                else:
                    state.status_message = (
                        "Block the interface first, then toggle ICMP."
                    )
                    state.status_is_error = True

        # Apply.
        elif key in (ord("a"), ord("A")):
            _apply(state)

        # Revert.
        elif key in (ord("r"), ord("R")):
            _revert(state)

        # Terminal resize — just redraw.
        elif key == curses.KEY_RESIZE:
            pass

        # Adjust scroll so cursor stays visible.
        height, _ = stdscr.getmaxyx()
        # header(1) + separator(1) + blank(1) + col_headers(1) + col_underlines(1) = 5 rows above
        # bottom reserve: separator gap(1) + separator(1) + help(1) + unsaved(1) + status(1) = 5
        visible_rows = max(1, height - 10)
        _adjust_scroll(state, visible_rows)

    return 0, state.last_apply_error


# ────────────────────────────────────────────────────────────────────────────────────────
#   Main Entry Point
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def launch_tui() -> int:
    """
    Launch the interactive curses TUI.
    """
    if sys.platform != "darwin":
        print("wj-firewall requires macOS.", file=sys.stderr)
        return 1

    locale.setlocale(locale.LC_ALL, "")

    # Suppress log output to stderr — Python's lastResort handler would
    # write WARNING+ messages over the curses display, corrupting it.
    root_logger = logging.getLogger()
    root_logger.addHandler(logging.NullHandler())

    try:
        exit_code, apply_error = curses.wrapper(_curses_main)
        if apply_error:
            print(
                f"\nLast apply error:\n{apply_error}",
                file=sys.stderr,
            )
        return exit_code
    except KeyboardInterrupt:
        return 0
    except SystemExit:
        raise
    except BaseException as e:
        t = "-------------------------------------------------------------------\n"
        t += "UNHANDLED EXCEPTION OCCURRED!!\n"
        t += "\n"
        t += traceback.format_exc()
        t += "\n"
        t += f"EXCEPTION: {type(e)} {e}\n"
        t += "-------------------------------------------------------------------\n"
        print(t, file=sys.stderr)
        return 1
