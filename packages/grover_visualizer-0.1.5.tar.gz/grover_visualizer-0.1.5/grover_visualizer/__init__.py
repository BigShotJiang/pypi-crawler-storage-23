from .grover import main
from .animation import startQuantumAnimation

__version__ = "0.1.5"