from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import json

from ..error_handling.exceptions import ValidationError, PathError
from ..error_handling.validation import ValidateFile
from ..messages import MESSAGES

def read_json(file_path: Path | str) -> Dict[Any, Any]:
    path: Path = Path(file_path)
    
    if not ValidateFile(path).is_ok:
        raise PathError(f"Invalid or non existent file")

    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.json.read_failed"].format(path=path, reason=exc)) from exc

def write_json(file_path: Path | str, data: Any) -> None:
    path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError(f"Invalid or non existent file")
    
    try:
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except (OSError, TypeError, ValueError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.json.write_failed"].format(path=path, reason=exc)) from exc