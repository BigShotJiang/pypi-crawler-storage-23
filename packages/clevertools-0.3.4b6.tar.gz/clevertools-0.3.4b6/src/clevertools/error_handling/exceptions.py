from __future__ import annotations

class AppError(Exception):
    """Base class for all domain-specific errors in clevertools."""


class RecoverableError(AppError):
    """Error indicating the current operation can be skipped safely."""


class FatalError(AppError):
    """Error indicating execution should stop immediately."""


class ValidationError(RecoverableError):
    """Raised when input values fail semantic or structural validation."""


class TypeValidationError(ValidationError):
    """Raised when a value has an unexpected type."""


class ValueValidationError(ValidationError):
    """Raised when a value is syntactically valid but semantically unacceptable."""


class SchemaValidationError(ValidationError):
    """Raised when structured input violates the expected schema."""


class ParseError(ValidationError):
    """Raised when a value or payload cannot be parsed into the expected format."""


class FileFormatError(ParseError):
    """Raised when a file exists but its content format is invalid."""


class PathTraversalError(ValidationError):
    """Raised when a path attempts to escape an allowed root."""


class RangeValidationError(ValidationError):
    """Raised when a numeric value is outside the accepted range."""


class LengthValidationError(ValidationError):
    """Raised when a value exceeds or falls below expected length constraints."""


class DependencyError(FatalError):
    """Raised when a required dependency, binary, or runtime component is unavailable."""


class MissingResourceError(DependencyError):
    """Raised when a mandatory file, folder, or other resource cannot be found."""


class ResourceLockedError(RecoverableError):
    """Raised when a resource is temporarily locked by another process."""


class OptionalDependencyError(RecoverableError):
    """Raised when an optional dependency is unavailable and a fallback may be used."""


class SetupError(FatalError):
    """Raised when required setup steps could not be completed."""


class ConfigurationError(FatalError):
    """Raised when configuration values are missing, inconsistent, or invalid."""


class ConfigurationMissingError(ConfigurationError):
    """Raised when a required configuration key or section is missing."""


class ConfigurationConflictError(ConfigurationError):
    """Raised when configuration values are mutually inconsistent."""


class StartError(FatalError):
    """Raised when application start-up fails before normal execution begins."""


class InitializationError(StartError):
    """Raised when a component cannot be initialized during startup."""


class ExecutionError(FatalError):
    """Raised when a core runtime step fails during execution."""


class OperationError(ExecutionError):
    """Raised when a single operation fails during runtime processing."""


class StateError(ExecutionError):
    """Raised when runtime state is invalid for the requested operation."""


class ConcurrencyError(ExecutionError):
    """Raised for synchronization or concurrent access problems."""


class RetryLimitExceededError(ExecutionError):
    """Raised when a retry loop exceeds the configured maximum attempts."""


class CircuitOpenError(ExecutionError):
    """Raised when an operation is blocked by an open circuit-breaker policy."""


class APIError(FatalError):
    """Raised for failures while interacting with external APIs or services."""


class AuthenticationError(APIError):
    """Raised when API credentials are missing, invalid, or expired."""


class AuthorizationError(APIError):
    """Raised when credentials are valid but permissions are insufficient."""


class RequestError(APIError):
    """Raised when an outgoing request cannot be built or sent successfully."""


class ConnectivityError(RequestError):
    """Raised when a remote endpoint cannot be reached."""


class DNSResolutionError(ConnectivityError):
    """Raised when hostname resolution fails."""


class SSLHandshakeError(ConnectivityError):
    """Raised when TLS/SSL negotiation fails."""


class TimeoutRequestError(RequestError):
    """Raised when an external request exceeds the configured timeout."""


class RateLimitError(RequestError):
    """Raised when an API request is rejected due to throttling or quotas."""


class ResponseError(APIError):
    """Raised when an API response is malformed or semantically invalid."""


class ResponseParseError(ResponseError):
    """Raised when an API response body cannot be parsed."""


class ResponseStatusError(ResponseError):
    """Raised when an API response status code indicates failure."""


class ProtocolError(APIError):
    """Raised when a transport or protocol contract is violated."""


class StorageError(FatalError):
    """Raised for persistent storage related failures."""


class FileSystemError(StorageError):
    """Raised when filesystem operations fail unexpectedly."""


class FileReadError(FileSystemError):
    """Raised when file content cannot be read."""


class FileWriteError(FileSystemError):
    """Raised when file content cannot be written."""


class FileDeleteError(FileSystemError):
    """Raised when a file cannot be removed."""


class DirectoryCreateError(FileSystemError):
    """Raised when a directory cannot be created."""


class DirectoryReadError(FileSystemError):
    """Raised when a directory cannot be inspected."""


class DirectoryDeleteError(FileSystemError):
    """Raised when a directory cannot be removed."""


class DiskSpaceError(StorageError):
    """Raised when an operation fails due to insufficient disk space."""


class QuotaExceededError(StorageError):
    """Raised when a storage or service quota has been exceeded."""


class IntegrityError(StorageError):
    """Raised when stored data fails integrity checks."""


class SerializationError(ExecutionError):
    """Raised when structured data cannot be serialized."""


class DeserializationError(ParseError):
    """Raised when structured data cannot be deserialized."""


class DataError(RecoverableError):
    """Raised for logical data-level issues that may be recoverable."""


class DataNotFoundError(DataError):
    """Raised when requested data cannot be found."""


class DuplicateDataError(DataError):
    """Raised when duplicate data violates uniqueness expectations."""


class ConflictError(DataError):
    """Raised when an operation conflicts with the current data state."""


class StaleDataError(DataError):
    """Raised when data is outdated and no longer valid for the operation."""


class SecurityError(FatalError):
    """Raised for security-sensitive failures."""


class PermissionDeniedError(SecurityError):
    """Raised when an action is denied due to insufficient privileges."""


class TokenError(SecurityError):
    """Raised when tokens are missing, invalid, or expired."""


class EncryptionError(SecurityError):
    """Raised when encryption or decryption fails."""


class SignatureVerificationError(SecurityError):
    """Raised when a digital signature cannot be verified."""


class LoggingError(RecoverableError):
    """Raised when logging infrastructure fails but core execution may continue."""


class LoggerConfigurationError(LoggingError):
    """Raised when logger setup or structure definitions are invalid."""


class MessageFormatError(LoggingError):
    """Raised when a log message cannot be rendered in the expected format."""


class CLIError(RecoverableError):
    """Raised for command-line invocation and argument processing problems."""


class MissingArgumentError(CLIError):
    """Raised when a required command-line argument is missing."""


class InvalidArgumentError(CLIError):
    """Raised when a command-line argument value is invalid."""


class CacheError(RecoverableError):
    """Raised for cache-specific failures where fallback paths may exist."""


class CacheMissError(CacheError):
    """Raised when a requested key is not present in cache."""


class CacheSerializationError(CacheError):
    """Raised when cached payload serialization or deserialization fails."""


class LimitExceededError(RecoverableError):
    """Raised when an operation exceeds a configured logical limit."""


class ExecutionHaltedError(FatalError):
    """Raised when execution is intentionally stopped by failure policy."""


class PathError(ValidationError):
    """Raised when a path is invalid or not existent."""