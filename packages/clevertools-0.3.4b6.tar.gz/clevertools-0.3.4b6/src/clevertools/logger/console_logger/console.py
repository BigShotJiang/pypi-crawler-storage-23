from __future__ import annotations

from typing import Any
import logging

from ..core import add_console_handler as configure_console
from ..core import log as structured_log


def add_console_handler(level: int = logging.INFO, fmt: str = "%(process_name)s | [ %(levelname)s ] = %(message)s") -> None:
    configure_console(level=level, fmt=fmt)


def log(process: str, level: str, message: str, **meta: Any) -> None:
    structured_log(process, level, message, **meta)