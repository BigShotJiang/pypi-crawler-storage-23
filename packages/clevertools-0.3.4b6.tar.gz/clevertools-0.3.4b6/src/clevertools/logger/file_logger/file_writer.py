from __future__ import annotations

from typing import Optional
from pathlib import Path

from ..core import add_file_handler as configure_file


def add_file_handler(filename: Optional[str | Path] = None, level: Optional[int] = None, fmt: str = "%(process_name)s | [ %(levelname)s ] = %(message)s", mirror_console_output: bool = True) -> Path:
    return configure_file(
        filename=filename,
        level=level,
        fmt=fmt,
        mirror_console_output=mirror_console_output,
    )