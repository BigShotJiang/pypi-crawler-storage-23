from __future__ import annotations

from ..messages import MESSAGES
from .core import log as structured_log

def log(process: str, level: str, message: str) -> None:
    try:
        structured_log(process=process, level=level, message=message)
    except Exception as exc:
        raise RuntimeError(MESSAGES["logger.failed"].format(process=process, reason=exc)) from exc