# clevertools

`clevertools` is a Python utility library for practical filesystem workflows.
It bundles focused helper modules for:
- file and folder creation
- JSON/TOML/YAML IO
- cleanup operations (including `__pycache__` cleanup)
- structured logging
- typed error handling and path validation

This repository contains:
- library source code in `src/clevertools`
- a local test sub-program in `tests`
- detailed technical documentation in `docs`

## Project goals
- Reduce repetitive utility boilerplate.
- Keep behavior predictable across modules.
- Provide reusable validation and clear exception types.
- Offer configurable logging for both CLI and scripts.

## Installation
Install local dependencies:

```bash
python -m pip install -r requirements.txt
```

Package metadata and build configuration are defined in `pyproject.toml`.

## Python version
- Required: Python `>=3.10`

## Import style
The top-level package currently does not re-export module APIs (`src/clevertools/__init__.py` is intentionally empty).
Import from submodules directly:

```python
from clevertools.file_handling import create_folder, create_file, read_json, write_json
from clevertools.cleaning import clean_folder, clean_pycaches
from clevertools.error_handling.validation import ValidateFile, ValidateFolder
from clevertools.error_handling import AppError, ValidationError, PathError
from clevertools.logger import configure_default_logging, add_file_handler, log
from clevertools.messages import MESSAGES
```

## Quick start

### 1. Create project files
```python
from pathlib import Path
from clevertools.file_handling import create_folder, create_file, write_json

base = Path("tmp_demo")
create_folder(base)
create_file(base / "config.json")
write_json(base / "config.json", {"mode": "dev", "enabled": True})
```

### 2. Read and validate data
```python
from clevertools.file_handling import read_json

data = read_json("tmp_demo/config.json")
print(data["mode"])
```

### 3. Configure logging
```python
from clevertools.logger import configure_default_logging, add_file_handler, log

configure_default_logging(include_date=True, include_time=True)
add_file_handler("tmp_demo/run.log")
log("Bootstrap", "INFO", "Startup complete")
```

### 4. Cleanup generated artifacts
```python
from clevertools.cleaning import clean_folder

clean_folder("tmp_demo", skipped_dirs=["keep_me"])
```

## Modules at a glance

### `error_handling`
- Rich typed exception hierarchy for domain-level errors.
- Validation helpers (`ValidateFile`, `ValidateFolder`).
- Clear split between recoverable and fatal error classes.

### `file_handling`
- `create_file`, `create_folder`
- `read_json`, `write_json`
- `read_toml`, `write_toml`
- `read_yaml`, `write_yaml`

### `cleaning`
- `clean_file`
- `clean_folder`
- `clean_pycaches`

### `logger`
- Structured logger with named log structures.
- Console and file handlers.
- Optional stdout/stderr mirroring into log files.

### `messages`
- Central message dictionary (`MESSAGES`) used by all modules.
- Runtime overrides supported.

## Error behavior model
The library primarily follows this pattern:
- Successful operations return normal Python values (`None`, `dict`, `TomlData`, ...).
- Failures raise typed exceptions (`ValidationError`, `PathError`, etc.) or `RuntimeError` with standardized message text.

## Logging behavior model
- Use `configure_default_logging(...)` to set default format and handler quickly.
- Use `add_new_log_structure(...)` + `get_structure(...)` for custom structured records.
- Use `add_file_handler(...)` to persist logs to file.

## Documentation map
Detailed docs are in `docs/`:
- `docs/README.md`
- `docs/error_handling_overview.md`
- `docs/error_handling_validation.md`
- `docs/error_handling_status.md` (legacy migration note)
- `docs/file_handling.md`
- `docs/cleaning.md`
- `docs/logger.md`
- `docs/messages.md`
- `docs/test_program.md`

## Local test sub-program
Run:

```bash
python tests/start.py
```

The test sub-program is config-driven via `tests/config/config.toml`.

## Repository structure
- `src/clevertools/`: library source code
- `tests/`: local integration-style test sub-program
- `docs/`: module and usage documentation

## Legal notices
Please read:
- `LICENSE`
- `NOTICE`
- `CONTRIBUTORS`

By using, copying, or redistributing this project, you agree to their terms.