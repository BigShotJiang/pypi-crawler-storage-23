# -*- coding: utf-8 -*-
"""
Runner with long-context memory for AtendentePro.

run_with_memory: load user context, retrieve memories, enrich messages, run agent, save turn.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


def _last_user_message(messages: List[Dict[str, Any]]) -> str:
    """Extract the last user message content for memory search query."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content")
            if isinstance(content, str):
                return content.strip()
            break
    return ""


async def run_with_memory(
    network: Any,
    agent: Any,
    messages: List[Dict[str, Any]],
    *,
    memory_backend: Optional[Any] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    session_id_factory: Optional[Callable[[Any, List[Dict[str, Any]]], Optional[str]]] = None,
    search_method: str = "graph",
    memory_limit: int = 5,
    memory_threshold: float = 0.3,
    memory_header: str = "Memória relevante (conversas anteriores):",
    strict_memory: bool = False,
) -> Any:
    """
    Run agent with optional long-context memory: search before run, inject context, save after.

    1. Load user context via network.user_loader(messages) if configured.
    2. Resolve user_id from param or network.loaded_user_context.user_id. session_id is a
       session key (conversation/channel/request), not client metadata: it is not taken from
       UserContext or user_loader. Use only the session_id parameter or session_id_factory
       (request/channel). Do not supply both with different values (single source of truth).
    3. If memory_backend (or network.memory_backend): search with last user message,
       prepend a system message with memory_header + context.
    4. Run agent with Runner.run(agent, messages).
    5. Save turn with memory_backend.save_conversation_async(messages + assistant).

    Args:
        network: AgentNetwork (with optional user_loader and memory_backend).
        agent: Agent to run.
        messages: List of message dicts (role, content).
        memory_backend: Optional MemoryBackend (e.g. GRKMemoryBackend). If None,
            uses getattr(network, "memory_backend", None).
        user_id: Optional user id for memory isolation. If None, uses
            network.loaded_user_context.user_id after user_loader runs.
        session_id: Optional session id (session key, not client metadata). Pass explicitly or
            set network.session_id_factory; do not use UserContext/user_loader for session_id.
            If both param and factory provide a value and they differ, ValueError is raised.
        session_id_factory: Optional callable to derive session_id from (network, messages).
            The network may also have session_id_factory set (e.g. network.session_id_factory = ...)
            for the same effect without passing it on every call.
        search_method: Passed to backend search_async (e.g. "graph", "embedding").
        memory_limit: Max results for search.
        memory_threshold: Minimum similarity threshold for search.
        memory_header: Text prepended to the injected memory block.
        strict_memory: If True, re-raise on memory backend errors; else log and continue.

    Returns:
        RunResult from Runner.run(agent, messages).
    """
    from agents import Runner

    # 1. Load user context (same as run_with_user_context)
    if hasattr(network, "user_loader") and network.user_loader:
        try:
            user_context = network.user_loader(messages)
            if user_context:
                network.loaded_user_context = user_context
        except Exception:
            pass

    # 2. Resolve user_id / session_id (fonte única: UserContext tem prioridade sobre parâmetro)
    ctx_user_id: Optional[str] = None
    if hasattr(network, "loaded_user_context") and network.loaded_user_context:
        ctx_user_id = getattr(network.loaded_user_context, "user_id", None)
        if ctx_user_id is not None and not str(ctx_user_id).strip():
            ctx_user_id = None
    if ctx_user_id is not None:
        if user_id is not None and user_id != ctx_user_id:
            raise ValueError(
                "user_id deve ser o mesmo do UserContext; não informe user_id em dois lugares ou use o mesmo valor."
            )
        user_id = ctx_user_id
    elif user_id is None and hasattr(network, "loaded_user_context") and network.loaded_user_context:
        user_id = getattr(network.loaded_user_context, "user_id", None)

    # session_id: chave de sessão (não vem de UserContext/user_loader). Fonte única: param ou session_id_factory.
    def _norm_sid(s: Optional[str]) -> Optional[str]:
        if s is None or not str(s).strip():
            return None
        return str(s).strip()

    param_session_id = _norm_sid(session_id)
    factory_session_id: Optional[str] = None
    network_factory = getattr(network, "session_id_factory", None)
    if callable(network_factory):
        factory_session_id = _norm_sid(network_factory(network, messages))
    if factory_session_id is None and session_id_factory is not None:
        factory_session_id = _norm_sid(session_id_factory(network, messages))

    if param_session_id is not None and factory_session_id is not None and param_session_id != factory_session_id:
        raise ValueError(
            "session_id deve vir de uma única fonte: use apenas o parâmetro session_id ou apenas session_id_factory, com o mesmo valor."
        )
    session_id = param_session_id if param_session_id is not None else factory_session_id

    backend = memory_backend if memory_backend is not None else getattr(network, "memory_backend", None)

    # Validação: sessão e memória exigem user_id
    if session_id is not None and (user_id is None or not str(user_id).strip()):
        raise ValueError(
            "Toda sessão deve estar associada a um usuário. "
            "Informe user_id ou garanta que o user_loader retorne um UserContext com user_id preenchido."
        )
    if backend is not None and (user_id is None or not str(user_id).strip()):
        raise ValueError(
            "Memória exige identificação do usuário para isolar conversas. "
            "Passe user_id ou garanta que o user_loader retorne um UserContext com user_id preenchido."
        )

    # 3. Search and enrich messages
    messages_to_run: List[Dict[str, Any]] = list(messages)
    if backend is not None:
        query = _last_user_message(messages)
        if query:
            try:
                context_str = await backend.search_async(
                    query,
                    user_id=user_id,
                    session_id=session_id,
                    method=search_method,
                    limit=memory_limit,
                    threshold=memory_threshold,
                )
            except Exception as exc:
                if strict_memory:
                    raise
                logger.warning("Memory search failed: %s", exc)
                context_str = ""
        else:
            context_str = ""

        if context_str and context_str.strip():
            block = f"{memory_header}\n{context_str.strip()}"
            system_msg = {"role": "system", "content": block}
            messages_to_run = [system_msg] + list(messages)

    # 4. Run agent
    result = await Runner.run(agent, messages_to_run)

    # 5. Save turn
    if backend is not None:
        try:
            assistant_content = getattr(result, "final_output", None) or ""
            turn_messages = list(messages) + [{"role": "assistant", "content": assistant_content}]
            await backend.save_conversation_async(
                turn_messages,
                user_id=user_id,
                session_id=session_id,
            )
        except Exception as exc:
            if strict_memory:
                raise
            logger.warning("Memory save_conversation failed: %s", exc)

    return result
