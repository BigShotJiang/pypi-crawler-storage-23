# Memória de contexto longo (GRKMemory)

Módulo opcional que integra o [GRKMemory](https://pypi.org/project/grkmemory/) ao AtendentePro: antes de cada execução do agente, busca memórias relevantes e injeta no contexto; após a resposta, persiste o turno para recuperação futura. Suporte async e multi-tenant (`user_id` / `session_id`).

## Instalação

```bash
pip install atendentepro[memory]
```

## Variáveis de ambiente

- `GRKMEMORY_API_KEY` – Token MonkAI para o GRKMemory (obrigatório se usar autenticação)
- `OPENAI_API_KEY` – OpenAI (ou variáveis Azure conforme documentação do GRKMemory)

## Uso mínimo

```python
from pathlib import Path
from atendentepro import create_standard_network
from atendentepro.memory import run_with_memory, create_grk_backend

network = create_standard_network(templates_root=Path("templates"), client="standard")

# Criar backend GRK e atribuir à rede
backend = create_grk_backend()  # usa GRKMEMORY_API_KEY do ambiente
network.memory_backend = backend

# Rodar com memória: busca memórias, injeta contexto, executa agente, salva turno
messages = [{"role": "user", "content": "O que combinamos na última vez?"}]
result = await run_with_memory(network, network.triage, messages)
print(result.final_output)
```

## user_id e session_id

Ao usar memória ou sessão, **user_id é obrigatório** (para isolar conversas e evitar confusão entre usuários). Toda sessão deve estar associada a um **user_id**. O **user_id deve vir de um único lugar (UserContext)** quando houver user_loader: não informe user_id em dois lugares; `run_with_memory` usa `loaded_user_context.user_id` e não aceita um parâmetro `user_id` diferente do do UserContext.

Para isolar memórias por usuário ou sessão, use `user_id` e opcionalmente `session_id`. Exemplos completos e executáveis: [docs/examples/memory_user_session/](../../docs/examples/memory_user_session/).

**Recomendação:** o **user_loader** deve ser usado apenas para **dados do usuário armazenados em banco** (perfil, role, dados estatísticos daquele usuário). **Não** use user_loader para memória ou sessão — session_id e memória vêm de parâmetro, `network.session_id_factory` e memory_backend. **session_id** é chave de sessão (conversa/canal/request), não informação de UserContext/user_loader: use apenas o **parâmetro** `session_id` ou o **session_id_factory**; não informe em dois lugares com valores diferentes (fonte única). O user_loader deve retornar um UserContext com **user_id preenchido**. Se a rede tiver `user_loader` configurado, `run_with_memory` usará `network.loaded_user_context.user_id` (fonte única).

```python
# Explícito
result = await run_with_memory(
    network, network.triage, messages,
    user_id="user_123",
    session_id="sess_abc",
)

# Ou deixar o user_loader preencher loaded_user_context e usar run_with_memory sem user_id
# (run_with_memory usa network.loaded_user_context.user_id quando user_id não é passado)
```

Em cenários com mais de um usuário, sempre informar `user_id` (ou user_loader que o defina por request). Em **canal compartilhado** (um WhatsApp/e-mail/Teams para vários clientes — caso comum), `session_id` pode ser o ID do canal e `user_id` deve identificar o cliente naquela conversa (ex.: número do contato, e-mail do remetente). Se `session_id` for derivado por hash das mensagens, incluir `user_id` no hash. Isso evita que mensagens/memórias de um usuário sejam vistas por outro.

Para gerar `session_id` por conversa, use `session_id_factory`:

```python
import hashlib

def by_conversation(network, messages):
    # Exemplo: uma sessão por hash das últimas mensagens e user_id (evita colisão entre usuários)
    user_id = None
    if getattr(network, "loaded_user_context", None):
        user_id = getattr(network.loaded_user_context, "user_id", None)
    last_n = 6
    recent = messages[-last_n:] if len(messages) >= last_n else messages
    h = hashlib.sha256((str(user_id or "") + str(recent)).encode()).hexdigest()[:16]
    return f"sess_{h}"

result = await run_with_memory(
    network, network.triage, messages,
    session_id_factory=by_conversation,
)
```

### Session ID: parâmetro ou session_id_factory (fonte única)

**session_id** é chave de sessão (conversa/canal/request), não dado de perfil do cliente. Não é obtido de UserContext nem do user_loader. Use **apenas uma** das fontes: parâmetro `session_id` ou `session_id_factory`. Se ambas forem preenchidas com valores diferentes, `run_with_memory` levanta `ValueError`.

1. **Parâmetro:** passe `session_id="sess_xyz"` (ou valor do request) em `run_with_memory`.
2. **session_id_factory na rede:** atribua `network.session_id_factory = lambda network, messages: get_conversation_id_from_request()` (ou função que derive o ID do canal/request). O `run_with_memory` usa essa factory quando o parâmetro `session_id` não é passado.

```python
# Recomendado: session_id da rede (ex.: do request/canal)
network.session_id_factory = lambda n, msgs: get_conversation_id_from_request()
result = await run_with_memory(network, network.triage, messages)

# Ou explícito por chamada
result = await run_with_memory(network, network.triage, messages, session_id="sess_abc")
```

## Parâmetros de busca e cabeçalho

- `search_method`: método de busca no GRK (`"graph"`, `"embedding"`, `"tags"`, `"entities"`).
- `memory_limit`: número máximo de memórias retornadas.
- `memory_threshold`: limiar mínimo de similaridade.
- `memory_header`: texto que precede o bloco de memória injetado no prompt.

```python
result = await run_with_memory(
    network, network.triage, messages,
    search_method="graph",
    memory_limit=5,
    memory_threshold=0.3,
    memory_header="Contexto de conversas anteriores:",
)
```

## Backend customizado

Você pode passar uma instância de GRKMemory ou AuthenticatedGRK já configurada:

```python
from grkmemory import GRKMemory, MemoryConfig
from atendentepro.memory import GRKMemoryBackend, run_with_memory

config = MemoryConfig(
    memory_file="cliente_memories.json",
    background_memory_method="graph",
    background_memory_limit=5,
)
grk = GRKMemory(config=config)
backend = GRKMemoryBackend(grk)

network.memory_backend = backend
result = await run_with_memory(network, network.triage, messages)
```

## Sem memória

Se `memory_backend` for `None` (e `network.memory_backend` também), `run_with_memory` apenas carrega o user context (se houver `user_loader`) e chama o agente, sem busca nem persistência.
