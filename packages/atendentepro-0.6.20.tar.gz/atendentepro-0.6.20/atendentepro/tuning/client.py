# -*- coding: utf-8 -*-
"""
Client for fetching feedback (Supabase) and records (MonkAI Trace), then merging.
"""

from __future__ import annotations

import os
from datetime import datetime
from typing import Any, Dict, List, Optional

_FEEDBACK_TABLE = "conversation_message_feedback"


def _get_supabase_client():  # type: ignore[no-any-unimported]
    try:
        from supabase import create_client
    except ImportError as e:
        raise ImportError(
            "Supabase client required for tuning. Install with: pip install atendentepro[tuning]"
        ) from e
    url = os.environ.get("SUPABASE_URL")
    key = os.environ.get("SUPABASE_SERVICE_KEY") or os.environ.get("SUPABASE_ANON_KEY")
    if not url or not key:
        raise ValueError("SUPABASE_URL and SUPABASE_SERVICE_KEY (or SUPABASE_ANON_KEY) must be set")
    return create_client(url, key)


def _get_trace_client(tracer_token: Optional[str] = None):  # type: ignore[no-any-unimported]
    try:
        from monkai_trace import MonkAIClient
    except ImportError as e:
        raise ImportError(
            "MonkAI Trace required for tuning. Install with: pip install atendentepro[tuning]"
        ) from e
    token = tracer_token or os.environ.get("MONKAI_TRACER_TOKEN")
    if not token:
        raise ValueError("MONKAI_TRACER_TOKEN or tracer_token must be set")
    return MonkAIClient(tracer_token=token)


def fetch_feedback(
    namespace: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    user_ids: Optional[List[str]] = None,
    feedback_value: str = "negative",
    limit: int = 500,
) -> List[Dict[str, Any]]:
    """
    Fetch feedback rows from Supabase conversation_message_feedback.

    Args:
        namespace: Workspace/namespace to filter by.
        start_date: Optional ISO date string (inclusive).
        end_date: Optional ISO date string (inclusive).
        user_ids: Optional list of user_id to restrict to.
        feedback_value: "positive" or "negative". Default "negative" for tuning.
        limit: Max rows to return.

    Returns:
        List of dicts with id, user_id, namespace, session_id, message_id,
        feedback, description, agent_name, created_at, updated_at.
    """
    client = _get_supabase_client()
    q = (
        client.table(_FEEDBACK_TABLE)
        .select("*")
        .eq("namespace", namespace)
        .eq("feedback", feedback_value)
    )
    if start_date:
        q = q.gte("created_at", start_date)
    if end_date:
        q = q.lte("created_at", end_date)
    if user_ids:
        q = q.in_("user_id", user_ids)
    q = q.limit(limit).order("created_at", desc=True)
    response = q.execute()
    return list(response.data) if response.data else []


def load_trace_records(
    namespace: str,
    tracer_token: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    agent: Optional[str] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """
    Load conversation records from MonkAI Trace via query_records.

    Args:
        namespace: Workspace/namespace.
        tracer_token: Optional; else MONKAI_TRACER_TOKEN env.
        start_date: Optional ISO date string.
        end_date: Optional ISO date string (if API supports).
        agent: Optional agent name filter.
        limit: Max records.

    Returns:
        List of record dicts (structure depends on Trace API; expect session_id, messages, etc.).
    """
    client = _get_trace_client(tracer_token)
    kwargs: Dict[str, Any] = {"namespace": namespace, "limit": limit}
    if start_date:
        kwargs["start_date"] = start_date
    if end_date:
        kwargs["end_date"] = end_date
    if agent:
        kwargs["agent"] = agent
    try:
        result = client.query_records(**kwargs)
    except TypeError:
        kwargs.pop("end_date", None)
        result = client.query_records(**kwargs)
    # Normalize to list of dicts
    if hasattr(result, "data"):
        return list(result.data) if result.data else []
    if isinstance(result, list):
        return [r if isinstance(r, dict) else dict(r) for r in result]
    return []


def merge_feedback_with_records(
    feedback_rows: List[Dict[str, Any]],
    records: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Merge feedback rows with trace records by session_id (and message_id when present).

    For each feedback row, finds the record with matching session_id and optionally
    message_id; attaches agent_name, feedback, description, user_id, created_at to the record.

    Args:
        feedback_rows: List from fetch_feedback.
        records: List from load_trace_records.

    Returns:
        List of enriched records (record + feedback fields). Records without
        matching feedback are omitted so the list is focused on feedback items.
    """
    # Index records by session_id (and by (session_id, message_id) if message_id present)
    by_session: Dict[str, List[Dict[str, Any]]] = {}
    for r in records:
        sid = r.get("session_id")
        if sid is None:
            continue
        by_session.setdefault(str(sid), []).append(r)

    enriched: List[Dict[str, Any]] = []
    for row in feedback_rows:
        sid = row.get("session_id")
        mid = row.get("message_id")
        if not sid:
            continue
        session_records = by_session.get(str(sid), [])
        if not session_records:
            # No matching record; still append a minimal enriched item from feedback only
            enriched.append({
                "session_id": sid,
                "message_id": mid,
                "messages": [],
                "agent_name": row.get("agent_name"),
                "feedback": row.get("feedback"),
                "description": row.get("description") or "",
                "user_id": row.get("user_id"),
                "created_at": row.get("created_at"),
            })
            continue
        for rec in session_records:
            rec_mid = rec.get("message_id")
            if mid and rec_mid and str(rec_mid) != str(mid):
                continue
            merged = dict(rec)
            merged["agent_name"] = row.get("agent_name")
            merged["feedback"] = row.get("feedback")
            merged["description"] = row.get("description") or ""
            merged["user_id"] = row.get("user_id")
            merged["feedback_created_at"] = row.get("created_at")
            enriched.append(merged)
            break
        else:
            # No message_id match; attach to first record of session
            merged = dict(session_records[0])
            merged["agent_name"] = row.get("agent_name")
            merged["feedback"] = row.get("feedback")
            merged["description"] = row.get("description") or ""
            merged["user_id"] = row.get("user_id")
            merged["feedback_created_at"] = row.get("created_at")
            enriched.append(merged)

    return enriched
