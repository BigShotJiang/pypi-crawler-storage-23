# flake8: noqa: I003
CONTEXT_PARAMETER = 'context'
UNUSED_FABRIC_CONTEXT_PARAMETER = 'notusedfabriccontext'
REQ_PARAMETER = 'req'
ADDITIONAL_PARAMETERS_HEADER = 'x-ms-fabric-additional-parameters'