"""FastTransfer MCP Server - A Model Context Protocol server for FastTransfer CLI tool."""

__version__ = "0.1.1"
