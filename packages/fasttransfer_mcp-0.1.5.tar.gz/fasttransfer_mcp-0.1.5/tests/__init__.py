"""Tests for FastTransfer MCP Server."""
