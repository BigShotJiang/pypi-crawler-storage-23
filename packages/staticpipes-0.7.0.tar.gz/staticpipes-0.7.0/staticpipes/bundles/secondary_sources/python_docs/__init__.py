import os

DIRECTORY = os.path.dirname(__file__)
