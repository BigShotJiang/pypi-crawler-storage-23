from staticpipes.processes.jinja2_render_source_file import (
    ProcessJinja2RenderSourceFile,
)


class ProcessJinja2(ProcessJinja2RenderSourceFile):
    """
    Deprecated. Use staticpipes.processes.jinja2_render_source_file.ProcessJinja2RenderSourceFile instead.
    """  # noqa

    pass
