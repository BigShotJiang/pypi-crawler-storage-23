import copy
import logging
import os
import sys

from .build_directory import BuildDirectory
from .bundle_base import BaseBundle
from .config import Config
from .current_info import CurrentInfo
from .exceptions import WatchFunctionalityNotImplementedException
from .source_directory import SourceDirectory
from .worker_storage import WorkerStorage

logger = logging.getLogger(__name__)


class Worker:

    def __init__(
        self,
        config: Config,
        source_dir: str,
        build_directory: str,
        secondary_source_directories: dict | None = None,
    ):
        self._config: Config = config
        self._source_directory: SourceDirectory = SourceDirectory(source_dir)
        self._build_directory: BuildDirectory = BuildDirectory(build_directory)
        self._secondary_source_directories: dict = {}
        if isinstance(secondary_source_directories, dict):
            for name, directory in secondary_source_directories.items():
                self._secondary_source_directories[name] = SourceDirectory(directory)
        self._current_info: CurrentInfo = None  # type: ignore
        self._check_reports: list = []
        self._worker_storage = WorkerStorage()

        # Look for extra Secondary Source Dirs from Bundles
        for pipe_or_bundle in self._config.pipes_and_groups_of_pipes:
            if isinstance(pipe_or_bundle, BaseBundle):
                for (
                    k,
                    v,
                ) in pipe_or_bundle.get_secondary_source_directory_paths().items():
                    self._secondary_source_directories[k] = SourceDirectory(v)
            pipe_or_bundle.setup_for_worker(
                self._config,
                self._source_directory,
                self._secondary_source_directories,
                self._build_directory,
            )

        for check in self._config.checks:
            check.setup_for_worker(self._config, self._build_directory)

    def build(self, run_checks=True, sys_exit_after_checks=False):
        self._current_info = CurrentInfo(
            context=copy.copy(self._config.context), watch=False
        )
        self._build(run_checks=run_checks, sys_exit_after_checks=sys_exit_after_checks)

    def check(self, sys_exit_after_checks=False):
        if not self._config.checks:
            logger.warn("No checks defined")
            if sys_exit_after_checks:
                sys.exit(1)
            else:
                return

        self._current_info = CurrentInfo(
            context=copy.copy(self._config.context), watch=False
        )
        self._build(run_checks=True, sys_exit_after_checks=sys_exit_after_checks)

    def _build(
        self, run_checks: bool = True, sys_exit_after_checks: bool = False
    ) -> None:
        # Prepare ...
        self._build_directory.prepare()
        # List files into storage
        real_path_source_dir = self._source_directory.dir
        for root, dirs, files in os.walk(real_path_source_dir):
            if not self._build_directory.is_equal_to_source_dir(root):
                for file in files:
                    dir: str = root[len(real_path_source_dir) + 1 :]
                    if not dir:
                        dir = "/"
                    self._worker_storage.store_file_details(dir, file)
        # For each pipe or pipe-grouping, process
        for pipe_or_bundle in self._config.pipes_and_groups_of_pipes:
            if isinstance(pipe_or_bundle, BaseBundle):
                logger.info(
                    "Processing Bundle {} ...".format(
                        pipe_or_bundle.get_description_for_logs()
                    )
                )
                for pipe in pipe_or_bundle.get_pipes():
                    self._build_pipe(pipe)
            else:
                self._build_pipe(pipe_or_bundle)
        # Tidy up
        self._build_directory.remove_all_files_we_did_not_write()
        # Check
        if run_checks:
            self._check(sys_exit_after_checks=sys_exit_after_checks)

    def _build_pipe(self, pipe) -> None:
        logger.info("Processing Pipe {} ...".format(pipe.get_description_for_logs()))
        # start build
        pipe.start_build(self._current_info)
        # files
        for dir, file, excluded in self._worker_storage.get_source_files():
            self._current_info.set_current_file_excluded(excluded)
            if excluded:
                logger.debug("Processing Excluded File {} {} ...".format(dir, file))
                pipe.source_file_excluded_during_build(dir, file, self._current_info)
            else:
                logger.debug("Processing File {} {} ...".format(dir, file))
                pipe.build_source_file(dir, file, self._current_info)
                if self._current_info.current_file_excluded:
                    self._worker_storage.exclude_file(dir, file)
        # end build
        pipe.end_build(self._current_info)

    def _check(self, sys_exit_after_checks: bool = False) -> None:
        if not self._config.checks:
            logger.info("No checks defined")
            return

        # start
        for check in self._config.checks:
            for c_r in check.start_check():
                self._check_reports.append(c_r)
        # files
        real_path_source_dir = self._build_directory.dir
        for root, dirs, files in os.walk(real_path_source_dir):
            for file in files:
                relative_dir = root[len(real_path_source_dir) + 1 :]
                if not relative_dir:
                    relative_dir = "/"
                for check in self._config.checks:
                    for c_r in check.check_build_file(relative_dir, file):
                        self._check_reports.append(c_r)
        # end
        for check in self._config.checks:
            for c_r in check.end_check():
                self._check_reports.append(c_r)

        # Log
        if len(self._check_reports) == 0:
            logger.info("Check Reports count: 0")
            if sys_exit_after_checks:
                sys.exit(0)
        else:
            logger.warn("Check Reports count: {}".format(len(self._check_reports)))
            for check_report in self._check_reports:
                logger.warn(check_report.get_description_for_logs())
            if sys_exit_after_checks:
                sys.exit(1)

    def watch(self):
        # Only import this when watch function called,
        # so we can use build part without watch dependencies
        from .watcher import Watcher

        self._current_info = CurrentInfo(
            context=copy.copy(self._config.context), watch=True
        )
        # Build first - so we have complete site
        self._build()

        # Check
        if self._config.checks:
            logger.info(
                "Checks do not work in watch yet, so no future checks will be done"  # noqa
            )
        # start watching
        for pipe_or_bundle in self._config.pipes_and_groups_of_pipes:
            if isinstance(pipe_or_bundle, BaseBundle):
                for pipe in pipe_or_bundle.get_pipes():
                    pipe.start_watch(self._current_info)
            else:
                pipe_or_bundle.start_watch(self._current_info)
        # Now watch
        watcher = Watcher(self)
        logger.info("Watching ...")
        watcher.watch()

    def serve(self, server_address: str, server_port: int):

        # Only import this when watch function called,
        # so we can use build part without watch dependencies
        import threading

        from .serve import server
        from .watcher import Watcher

        self._current_info = CurrentInfo(
            context=copy.copy(self._config.context), watch=True
        )
        # Build first - so we have complete site
        self._build()

        # Check
        if self._config.checks:
            logger.info(
                "Checks do not work in serve yet, so no future checks will be done"  # noqa
            )

        # Start HTTP server in background
        threading.Thread(
            target=server,
            args=(self._build_directory.dir, server_address, server_port),
        ).start()

        # start watching
        for pipe_or_bundle in self._config.pipes_and_groups_of_pipes:
            if isinstance(pipe_or_bundle, BaseBundle):
                for pipe in pipe_or_bundle.get_pipes():
                    pipe.start_watch(self._current_info)
            else:
                pipe_or_bundle.start_watch(self._current_info)
        # Now watch
        watcher = Watcher(self)
        logger.info("Watching ...")
        watcher.watch()

    def process_file_during_watch(self, dir: str, filename: str) -> None:
        # Check if we should process
        if self._build_directory.is_equal_to_source_dir(
            os.path.join(self._source_directory.dir, dir)
        ):
            return
        # Setup
        logger.info("Processing during watch {} {} ...".format(dir, filename))
        context_version: int = self._current_info.get_context_version()
        # For this file, start processing
        self._current_info.set_current_file_excluded(False)
        for pipe_or_bundle in self._config.pipes_and_groups_of_pipes:
            # Call each pipe for file
            if isinstance(pipe_or_bundle, BaseBundle):
                for pipe in pipe_or_bundle.get_pipes():
                    self._process_file_during_watch_pipe(dir, filename, pipe)
            else:
                self._process_file_during_watch_pipe(dir, filename, pipe_or_bundle)
            # TODO Should save back to worker storage if excluded?
            #  But that is not used for anything in watch yet.
        #  If context changed, call each pipe for context
        if context_version != self._current_info.get_context_version():
            for pipe_or_bundle in self._config.pipes_and_groups_of_pipes:
                if isinstance(pipe_or_bundle, BaseBundle):
                    for pipe in pipe_or_bundle.get_pipes():
                        pipe.context_changed_during_watch(
                            self._current_info,
                            context_version,
                            self._current_info.get_context_version(),
                        )
                else:
                    pipe_or_bundle.context_changed_during_watch(
                        self._current_info,
                        context_version,
                        self._current_info.get_context_version(),
                    )

    def _process_file_during_watch_pipe(self, dir: str, filename: str, pipe) -> None:
        try:
            if self._current_info.current_file_excluded:
                pipe.source_file_changed_but_excluded_during_watch(
                    dir, filename, self._current_info
                )
            else:
                pipe.source_file_changed_during_watch(dir, filename, self._current_info)
        except WatchFunctionalityNotImplementedException:
            logger.error(
                (
                    "WATCH FEATURE NOT IMPLEMENTED IN PIPE, "
                    + "YOU MAY HAVE TO BUILD MANUALLY: {}"
                ).format(pipe.get_description_for_logs())
            )
