"""Tests for merged hook features — ported from MVP.

Tests the 5 features missing from V2 hooks:
1. KnowledgeDB semantic search in session_start
2. Session prompt capture in prompt_submit
3. Mechanical enforcer checks on commit
4. Session learning on hook_stop
5. Inferred rule storage to knowledge.db
"""

import json
import time
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_compliance_gate,
    hook_stop,
)
from tlm.state import write_state, read_state
from tlm.config import save_project_config
from tlm.knowledge_db import KnowledgeDB


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": "proj_1",
    })
    return tmp_path


@pytest.fixture
def tlm_project_with_db(tlm_project):
    """Create a TLM project with knowledge.db containing rules."""
    db = KnowledgeDB(str(tlm_project / ".tlm"))
    db.init_db()
    db.add_rule(
        text="Always use JWT tokens for API authentication",
        source="learned",
        tags=["auth", "security", "jwt"],
    )
    db.add_rule(
        text="Maintain 80% test coverage on all modules",
        source="learned",
        tags=["testing", "coverage"],
    )
    db.add_rule(
        text="Always deploy to staging before production",
        source="learned",
        tags=["deployment", "staging"],
    )
    db.close()
    return tlm_project


@pytest.fixture
def tlm_project_with_enforcement(tlm_project):
    """Create a TLM project with enforcement.json config."""
    enforcement = {
        "checks": [
            {"name": "Tests", "command": "pytest tests/ -v", "blocker": True, "category": "testing"},
            {"name": "Lint", "command": "flake8 .", "blocker": False, "category": "linting"},
        ],
    }
    (tlm_project / ".tlm" / "enforcement.json").write_text(json.dumps(enforcement, indent=2))
    return tlm_project


# =============================================================================
# 1. KnowledgeDB semantic search in session_start
# =============================================================================

class TestSessionStartKnowledgeDB:
    def test_session_start_loads_rules_from_db(self, tlm_project_with_db):
        """session_start should include rules from knowledge.db when available."""
        result = hook_session_start(str(tlm_project_with_db))
        # Should mention knowledge DB rules
        assert "rule" in result.lower() or "knowledge" in result.lower()

    def test_session_start_shows_rule_count(self, tlm_project_with_db):
        """session_start should show how many rules are in knowledge.db."""
        result = hook_session_start(str(tlm_project_with_db))
        # Should reference the 3 rules we added
        assert "3" in result or "rules" in result.lower()

    def test_session_start_shows_rule_text(self, tlm_project_with_db):
        """session_start should show some rule text from knowledge.db."""
        result = hook_session_start(str(tlm_project_with_db))
        # Should include at least one rule text snippet
        assert ("jwt" in result.lower() or "coverage" in result.lower()
                or "staging" in result.lower())

    def test_session_start_works_without_db(self, tlm_project):
        """session_start should still work when knowledge.db doesn't exist."""
        result = hook_session_start(str(tlm_project))
        assert isinstance(result, str)
        assert "TLM" in result


# =============================================================================
# 2. Session prompt capture in prompt_submit
# =============================================================================

class TestPromptCapture:
    def test_prompt_submit_captures_prompt(self, tlm_project):
        """prompt_submit should capture user prompts to session_prompts.jsonl."""
        hook_prompt_submit(str(tlm_project), "Add authentication feature")

        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        assert prompts_file.exists(), "session_prompts.jsonl should be created"

    def test_captured_prompt_contains_text(self, tlm_project):
        """Captured prompt should contain the user's text."""
        hook_prompt_submit(str(tlm_project), "Add authentication feature")

        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        line = prompts_file.read_text().strip()
        entry = json.loads(line)
        assert entry["prompt"] == "Add authentication feature"

    def test_captured_prompt_has_timestamp(self, tlm_project):
        """Captured prompt should include a timestamp."""
        hook_prompt_submit(str(tlm_project), "Fix the login bug")

        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        line = prompts_file.read_text().strip()
        entry = json.loads(line)
        assert "timestamp" in entry

    def test_multiple_prompts_appended(self, tlm_project):
        """Multiple prompts should be appended as separate lines."""
        hook_prompt_submit(str(tlm_project), "First prompt")
        hook_prompt_submit(str(tlm_project), "Second prompt")

        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        lines = [l for l in prompts_file.read_text().strip().split("\n") if l]
        assert len(lines) == 2
        assert json.loads(lines[0])["prompt"] == "First prompt"
        assert json.loads(lines[1])["prompt"] == "Second prompt"

    def test_empty_prompt_not_captured(self, tlm_project):
        """Empty prompts should not be captured."""
        hook_prompt_submit(str(tlm_project), "")

        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        assert not prompts_file.exists() or prompts_file.read_text().strip() == ""

    def test_prompt_capture_includes_phase(self, tlm_project):
        """Captured prompt should include the current phase."""
        write_state(str(tlm_project), {"phase": "implementation"})
        hook_prompt_submit(str(tlm_project), "Write the handler code")

        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        entry = json.loads(prompts_file.read_text().strip())
        assert entry.get("phase") == "implementation"


# =============================================================================
# 3. Mechanical enforcer checks on commit
# =============================================================================

class TestComplianceGateEnforcer:
    def test_commit_runs_enforcement_checks(self, tlm_project_with_enforcement):
        """git commit should attempt to run enforcement checks."""
        with patch("tlm.hooks._run_enforcement_checks") as mock_enforce:
            mock_enforce.return_value = {"passed": True, "results": []}
            result = hook_compliance_gate(str(tlm_project_with_enforcement), {
                "command": "git commit -m 'test'",
            })
            mock_enforce.assert_called_once()

    def test_commit_enforcement_failures_in_context(self, tlm_project_with_enforcement):
        """Failed enforcement checks should appear in compliance context."""
        with patch("tlm.hooks._run_enforcement_checks") as mock_enforce:
            mock_enforce.return_value = {
                "passed": False,
                "results": [
                    {"name": "Tests", "passed": False, "output": "2 tests failed"},
                ],
            }
            with patch("tlm.hooks._run_code_review") as mock_review:
                mock_review.return_value = {"error": "Not authenticated"}
                result = hook_compliance_gate(str(tlm_project_with_enforcement), {
                    "command": "git commit -m 'test'",
                })

        ctx = result.get("additionalContext", "") + result.get("reason", "")
        # Should mention failed checks
        assert "Tests" in ctx or "enforcement" in ctx.lower() or "check" in ctx.lower()

    def test_commit_enforcement_pass_no_block(self, tlm_project_with_enforcement):
        """Passing enforcement checks should not block commit."""
        with patch("tlm.hooks._run_enforcement_checks") as mock_enforce:
            mock_enforce.return_value = {"passed": True, "results": []}
            with patch("tlm.hooks._run_code_review") as mock_review:
                mock_review.return_value = {"error": "Not authenticated"}
                result = hook_compliance_gate(str(tlm_project_with_enforcement), {
                    "command": "git commit -m 'test'",
                })

        # Should not block (enforcement passed, code review degraded)
        assert result.get("decision") != "block"

    def test_enforcement_blocker_failure_blocks_in_high(self, tlm_project_with_enforcement):
        """Blocker check failure in HIGH quality should block commit."""
        save_project_config(str(tlm_project_with_enforcement), {"quality_control": "high"})
        with patch("tlm.hooks._run_enforcement_checks") as mock_enforce:
            mock_enforce.return_value = {
                "passed": False,
                "results": [
                    {"name": "Tests", "passed": False, "blocker": True, "output": "FAILED"},
                ],
            }
            result = hook_compliance_gate(str(tlm_project_with_enforcement), {
                "command": "git commit -m 'test'",
            })

        assert result.get("decision") == "block"

    def test_no_enforcement_config_skips_checks(self, tlm_project):
        """Without enforcement.json, mechanical checks should be skipped."""
        with patch("tlm.hooks._run_code_review") as mock_review:
            mock_review.return_value = {"error": "Not authenticated"}
            result = hook_compliance_gate(str(tlm_project), {
                "command": "git commit -m 'test'",
            })

        # Should still work (text-only compliance context)
        assert "additionalContext" in result or "decision" in result


# =============================================================================
# 4. Session learning on hook_stop
# =============================================================================

class TestHookStopLearning:
    def test_stop_triggers_session_learning(self, tlm_project):
        """hook_stop should attempt session learning when prompts exist."""
        # Write some session prompts
        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text(
            json.dumps({"prompt": "Add auth", "timestamp": 1234567890, "phase": "idle"}) + "\n"
            + json.dumps({"prompt": "Use JWT", "timestamp": 1234567891, "phase": "tlm_active"}) + "\n"
        )

        with patch("tlm.hooks._run_session_learning") as mock_learn:
            mock_learn.return_value = {"rules_learned": 1}
            hook_stop(str(tlm_project))
            mock_learn.assert_called_once()

    def test_stop_no_prompts_skips_learning(self, tlm_project):
        """hook_stop should skip learning when no prompts captured."""
        with patch("tlm.hooks._run_session_learning") as mock_learn:
            hook_stop(str(tlm_project))
            mock_learn.assert_not_called()

    def test_stop_cleans_session_prompts(self, tlm_project):
        """hook_stop should clean up session_prompts.jsonl."""
        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text(json.dumps({"prompt": "test"}) + "\n")

        with patch("tlm.hooks._run_session_learning"):
            hook_stop(str(tlm_project))

        assert not prompts_file.exists()

    def test_stop_learning_failure_doesnt_crash(self, tlm_project):
        """Session learning failure should not crash hook_stop."""
        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text(json.dumps({"prompt": "test"}) + "\n")

        with patch("tlm.hooks._run_session_learning") as mock_learn:
            mock_learn.side_effect = Exception("Network error")
            # Should not raise
            result = hook_stop(str(tlm_project))
            assert isinstance(result, dict)


# =============================================================================
# 5. Inferred rule storage to knowledge.db
# =============================================================================

class TestSessionLearningRuleStorage:
    def test_session_learning_stores_rules_in_db(self, tlm_project):
        """_run_session_learning should store inferred rules in knowledge.db."""
        from tlm.hooks import _run_session_learning

        prompts = [
            {"prompt": "Add JWT auth", "timestamp": 1234567890, "phase": "idle"},
            {"prompt": "Use RS256 algorithm", "timestamp": 1234567891, "phase": "tlm_active"},
        ]

        mock_client = MagicMock()
        mock_client.learn_session.return_value = {
            "rules": [
                {"id": "auth-pattern", "text": "Use JWT with RS256 for API auth", "tags": ["auth"]},
            ],
        }

        with patch("tlm.hooks._get_review_client", return_value=mock_client):
            _run_session_learning(str(tlm_project), prompts)

        # Check rules are stored in knowledge.db
        db = KnowledgeDB(str(tlm_project / ".tlm"))
        rules = db.list_rules()
        db.close()
        assert len(rules) >= 1
        rule_texts = [r["rule_text"] for r in rules]
        assert any("JWT" in t or "RS256" in t for t in rule_texts)

    def test_session_learning_calls_server(self, tlm_project):
        """_run_session_learning should call server learn_session endpoint."""
        from tlm.hooks import _run_session_learning

        prompts = [{"prompt": "test prompt", "timestamp": 123, "phase": "idle"}]

        mock_client = MagicMock()
        mock_client.learn_session.return_value = {"rules": []}

        with patch("tlm.hooks._get_review_client", return_value=mock_client):
            _run_session_learning(str(tlm_project), prompts)

        mock_client.learn_session.assert_called_once()

    def test_session_learning_no_client_skips(self, tlm_project):
        """_run_session_learning should skip when no client (not authenticated)."""
        from tlm.hooks import _run_session_learning

        prompts = [{"prompt": "test", "timestamp": 123, "phase": "idle"}]

        with patch("tlm.hooks._get_review_client", return_value=None):
            # Should not raise
            _run_session_learning(str(tlm_project), prompts)

        # No rules should be stored (no client)
        db_path = tlm_project / ".tlm" / "knowledge.db"
        if db_path.exists():
            db = KnowledgeDB(str(tlm_project / ".tlm"))
            rules = db.list_rules()
            db.close()
            assert len(rules) == 0

    def test_session_learning_builds_summary(self, tlm_project):
        """_run_session_learning should build session summary from prompts."""
        from tlm.hooks import _run_session_learning

        prompts = [
            {"prompt": "Add authentication", "timestamp": 100, "phase": "idle"},
            {"prompt": "Use OAuth 2.0", "timestamp": 200, "phase": "tlm_active"},
            {"prompt": "Add refresh tokens", "timestamp": 300, "phase": "implementation"},
        ]

        mock_client = MagicMock()
        mock_client.learn_session.return_value = {"rules": []}

        with patch("tlm.hooks._get_review_client", return_value=mock_client):
            _run_session_learning(str(tlm_project), prompts)

        # Server should receive summary that includes the prompts
        call_args = mock_client.learn_session.call_args
        summary = call_args[1].get("summary", "") or call_args[0][1] if len(call_args[0]) > 1 else ""
        # The summary/prompts should have been passed to the server
        mock_client.learn_session.assert_called_once()
