"""
Tests for compliance.py — Spec compliance checking.

Adapted from mvp/tests/test_engine_api.py::TestComplianceCheckerAPI.
ComplianceChecker uses direct file paths (no Project class).
"""

import json
from unittest.mock import MagicMock, patch
from pathlib import Path

import pytest


@pytest.fixture
def project_dir(tmp_path):
    """Set up a .tlm/ directory with specs."""
    tlm = tmp_path / ".tlm"
    tlm.mkdir()
    specs = tlm / "specs"
    specs.mkdir()
    (tlm / "profile.md").write_text("## Stack\nPython, FastAPI")
    (tlm / "config.json").write_text(json.dumps({"project_name": "test"}))
    return tmp_path


@pytest.fixture
def mock_client():
    return MagicMock()


class TestComplianceCheckWithSpec:
    def test_check_calls_api(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        # Create a spec
        spec_path = project_dir / ".tlm" / "specs" / "test-spec.md"
        spec_path.write_text("# Test Spec\n\nMust have tests.")

        mock_client.compliance_check.return_value = {
            "result": "### Verdict: PASS\n\nAll changes match spec."
        }

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        with patch.object(checker, '_get_diff', return_value="diff --git a/foo.py"):
            result = checker.check(str(spec_path))

        assert "PASS" in result
        mock_client.compliance_check.assert_called_once()

    def test_check_passes_spec_and_diff(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        spec_path = project_dir / ".tlm" / "specs" / "test-spec.md"
        spec_path.write_text("# Auth Spec\n\nImplement OAuth2.")

        mock_client.compliance_check.return_value = {"result": "PASS"}

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        with patch.object(checker, '_get_diff', return_value="diff content"):
            checker.check(str(spec_path))

        call_args = mock_client.compliance_check.call_args
        assert call_args[0][0] == "proj_123"
        assert "OAuth2" in call_args[0][1]  # spec content
        assert "diff content" in call_args[0][2]  # diff


class TestComplianceCheckWithoutSpec:
    def test_uses_latest_spec(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        # Create two specs — checker should use the latest (reverse sorted)
        (project_dir / ".tlm" / "specs" / "2024-01-01-old.md").write_text("# Old Spec")
        (project_dir / ".tlm" / "specs" / "2024-06-01-new.md").write_text("# New Spec")

        mock_client.compliance_check.return_value = {"result": "PASS"}

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        with patch.object(checker, '_get_diff', return_value="diff"):
            checker.check()

        call_args = mock_client.compliance_check.call_args
        assert "New Spec" in call_args[0][1]

    def test_no_specs_returns_message(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        with patch.object(checker, '_get_diff', return_value="diff"):
            result = checker.check()

        assert "No specs" in result
        mock_client.compliance_check.assert_not_called()


class TestComplianceCheckNoDiff:
    def test_no_diff_returns_message(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        with patch.object(checker, '_get_diff', return_value=""):
            result = checker.check()

        assert "No changes" in result
        mock_client.compliance_check.assert_not_called()


class TestComplianceGetDiff:
    def test_get_diff_uses_cached_first(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        staged = "diff --git a/staged.py"
        with patch("tlm.compliance.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout=staged)
            diff = checker._get_diff()

        assert diff == staged
        # Should call git diff --cached
        mock_run.assert_called_once()
        assert "--cached" in mock_run.call_args[0][0]

    def test_get_diff_falls_back_to_unstaged(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        with patch("tlm.compliance.subprocess.run") as mock_run:
            # First call (staged) returns empty, second call (unstaged) returns diff
            mock_run.side_effect = [
                MagicMock(stdout=""),
                MagicMock(stdout="diff --git a/unstaged.py"),
            ]
            diff = checker._get_diff()

        assert "unstaged.py" in diff
        assert mock_run.call_count == 2

    def test_get_diff_returns_empty_on_git_not_found(self, project_dir, mock_client):
        from tlm.compliance import ComplianceChecker

        checker = ComplianceChecker(str(project_dir), mock_client, "proj_123")

        with patch("tlm.compliance.subprocess.run", side_effect=FileNotFoundError):
            diff = checker._get_diff()

        assert diff == ""
