"""Tests for tlm.session_learner -- build_session_summary, _find_repeated_instructions, analyze_session."""

import json
import datetime
from unittest.mock import MagicMock

import pytest

from tlm.session_learner import build_session_summary, _find_repeated_instructions, analyze_session


class TestBuildSessionSummary:
    def test_returns_none_when_no_data(self, tmp_path):
        """No session_prompts.jsonl and no transcript -> None."""
        result = build_session_summary(str(tmp_path), transcript_path="")
        assert result is None

    def test_reads_from_session_prompts_jsonl(self, tmp_path):
        prompts_file = tmp_path / "session_prompts.jsonl"
        now = datetime.datetime.now()
        entries = [
            {"prompt": "Add user auth", "timestamp": now.isoformat()},
            {"prompt": "Fix the login bug", "timestamp": (now + datetime.timedelta(minutes=30)).isoformat()},
        ]
        prompts_file.write_text("\n".join(json.dumps(e) for e in entries))

        result = build_session_summary(str(tmp_path))
        assert result is not None
        assert len(result["user_prompts"]) == 2
        assert result["user_prompts"][0] == "Add user auth"
        assert result["user_prompts"][1] == "Fix the login bug"
        assert result["session_duration_minutes"] == 30

    def test_detects_repeated_instructions(self, tmp_path):
        prompts_file = tmp_path / "session_prompts.jsonl"
        now = datetime.datetime.now()

        # Same instruction repeated 3 times
        entries = [
            {"prompt": "always run tests before committing", "timestamp": now.isoformat()},
            {"prompt": "always run tests before committing", "timestamp": (now + datetime.timedelta(minutes=5)).isoformat()},
            {"prompt": "always run tests before committing", "timestamp": (now + datetime.timedelta(minutes=10)).isoformat()},
        ]
        prompts_file.write_text("\n".join(json.dumps(e) for e in entries))

        result = build_session_summary(str(tmp_path))
        assert result is not None
        assert len(result["repeated_instructions"]) >= 1
        # Should contain the repeated instruction with count
        found = any("always run tests before committing" in r for r in result["repeated_instructions"])
        assert found

    def test_returns_empty_repeated_when_all_unique(self, tmp_path):
        prompts_file = tmp_path / "session_prompts.jsonl"
        now = datetime.datetime.now()

        entries = [
            {"prompt": "Add user auth feature", "timestamp": now.isoformat()},
            {"prompt": "Fix the database query issue", "timestamp": (now + datetime.timedelta(minutes=5)).isoformat()},
        ]
        prompts_file.write_text("\n".join(json.dumps(e) for e in entries))

        result = build_session_summary(str(tmp_path))
        assert result is not None
        assert result["repeated_instructions"] == []


class TestFindRepeatedInstructions:
    def test_finds_exact_duplicates(self):
        prompts = [
            "always use type hints in Python",
            "always use type hints in Python",
            "something else entirely different here",
        ]
        repeated = _find_repeated_instructions(prompts)
        assert len(repeated) >= 1
        assert any("always use type hints in python" in r for r in repeated)

    def test_finds_instruction_patterns(self):
        """Instructions containing 'always', 'never', etc. that repeat."""
        prompts = [
            "you should always validate input data before processing.",
            "make sure you always validate input data before processing.",
            "remember to check edge cases in tests.",
            "remember to check edge cases in tests.",
        ]
        repeated = _find_repeated_instructions(prompts)
        assert len(repeated) >= 1

    def test_returns_empty_for_no_repeats(self):
        prompts = [
            "add a feature",
            "fix a bug",
            "deploy to staging",
        ]
        repeated = _find_repeated_instructions(prompts)
        assert repeated == []

    def test_ignores_short_phrases(self):
        """Phrases <= 10 chars should be ignored even if repeated."""
        prompts = ["do it", "do it", "do it"]
        repeated = _find_repeated_instructions(prompts)
        assert repeated == []


class TestAnalyzeSession:
    def test_swallows_exceptions(self):
        """analyze_session should not raise -- returns default on failure."""
        mock_client = MagicMock()
        mock_client.learn_session.side_effect = Exception("Server unreachable")

        result = analyze_session(mock_client, {"user_prompts": ["test"]})
        assert result == {"inferred_rules": [], "workflow_patterns": []}

    def test_returns_server_response_on_success(self):
        mock_client = MagicMock()
        mock_client.learn_session.return_value = {
            "inferred_rules": ["Always test first"],
            "workflow_patterns": ["TDD cycle"],
        }

        result = analyze_session(mock_client, {"user_prompts": ["add auth"]})
        assert result["inferred_rules"] == ["Always test first"]
        assert result["workflow_patterns"] == ["TDD cycle"]
        mock_client.learn_session.assert_called_once()
