"""Tests for `tlm review` CLI command — spec and code review subcommands."""

import json
import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner
from pathlib import Path

from tlm.cli import main
from tlm.state import write_state
from tlm.config import save_project_config


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "implementation"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": 42,
    })
    return tmp_path


class TestReviewSpecCommand:
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://test:8003")
    @patch("tlm.cli.TLMClient")
    def test_review_spec_with_path(self, mock_client_cls, mock_url, mock_key, tlm_project):
        """tlm review spec <path> should review the specified spec."""
        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec\n\nImplement OAuth2")

        mock_client = MagicMock()
        mock_client.review_spec = MagicMock(return_value={
            "severity": "pass",
            "gaps": [],
            "follow_up_questions": [],
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "spec", str(spec_path), "--path", str(tlm_project)
        ])

        assert result.exit_code == 0
        mock_client.review_spec.assert_called_once()

    def test_review_spec_requires_path(self, tlm_project):
        """tlm review spec (no path) should error — spec_path is required."""
        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "spec", "--path", str(tlm_project)
        ])

        assert result.exit_code != 0

    @patch("tlm.cli.get_api_key", return_value="")
    def test_review_spec_not_authenticated(self, mock_key, tlm_project):
        """Should fail when not authenticated."""
        spec_path = tlm_project / ".tlm" / "specs" / "test.md"
        spec_path.write_text("# Test")

        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "spec", str(spec_path), "--path", str(tlm_project)
        ])

        assert result.exit_code != 0
        assert "auth" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://test:8003")
    @patch("tlm.cli.TLMClient")
    def test_review_spec_shows_gaps(self, mock_client_cls, mock_url, mock_key, tlm_project):
        """Should display gaps from the review."""
        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec")

        mock_client = MagicMock()
        mock_client.review_spec = MagicMock(return_value={
            "severity": "warn",
            "gaps": [{"description": "Missing error handling", "severity": "medium"}],
            "follow_up_questions": ["What about timeouts?"],
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "spec", str(spec_path), "--path", str(tlm_project)
        ])

        assert result.exit_code == 0
        assert "error handling" in result.output.lower() or "gap" in result.output.lower() or "warn" in result.output.lower()


class TestReviewCodeCommand:
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://test:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.subprocess.run")
    def test_review_code_success(self, mock_run, mock_client_cls, mock_url, mock_key, tlm_project):
        """tlm review code should show code review results."""
        # Set active spec
        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec")
        write_state(str(tlm_project), {
            "phase": "implementation",
            "active_spec": str(spec_path),
        })

        mock_run.side_effect = [
            MagicMock(stdout="diff --git a/app.py\n+new code", returncode=0),
            MagicMock(stdout="app.py\n", returncode=0),
        ]

        mock_client = MagicMock()
        mock_client.review_code = MagicMock(return_value={
            "combined_verdict": "pass",
            "reviews": [{"model": "anthropic", "verdict": "pass"}],
            "issues": [],
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "code", "--path", str(tlm_project)
        ])

        assert result.exit_code == 0
        mock_client.review_code.assert_called_once()

    @patch("tlm.cli.get_api_key", return_value="")
    def test_review_code_not_authenticated(self, mock_key, tlm_project):
        """Should fail when not authenticated."""
        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "code", "--path", str(tlm_project)
        ])

        assert result.exit_code != 0
        assert "auth" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://test:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.subprocess.run")
    def test_review_code_empty_diff(self, mock_run, mock_client_cls, mock_url, mock_key, tlm_project):
        """Should handle empty git diff gracefully."""
        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec")
        write_state(str(tlm_project), {
            "phase": "implementation",
            "active_spec": str(spec_path),
        })

        mock_run.side_effect = [
            MagicMock(stdout="", returncode=0),
            MagicMock(stdout="", returncode=0),
        ]

        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "code", "--path", str(tlm_project)
        ])

        assert result.exit_code != 0 or "no" in result.output.lower() or "empty" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://test:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.subprocess.run")
    def test_review_code_with_commit_sha(self, mock_run, mock_client_cls, mock_url, mock_key, tlm_project):
        """tlm review code <commit> should use git diff <sha>~1 <sha>."""
        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec")
        write_state(str(tlm_project), {
            "phase": "implementation",
            "active_spec": str(spec_path),
        })

        mock_run.side_effect = [
            MagicMock(stdout="diff --git a/app.py\n+new code", returncode=0),
            MagicMock(stdout="app.py\n", returncode=0),
        ]

        mock_client = MagicMock()
        mock_client.review_code = MagicMock(return_value={
            "combined_verdict": "pass",
            "reviews": [{"model": "anthropic", "verdict": "pass"}],
            "issues": [],
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "code", "abc123", "--path", str(tlm_project)
        ])

        assert result.exit_code == 0
        mock_client.review_code.assert_called_once()
        # Verify it used commit-based diff, not --cached
        diff_call = mock_run.call_args_list[0]
        assert "abc123~1" in diff_call[0][0] or "abc123" in str(diff_call)


class TestReviewShowLast:
    def test_show_last_with_cached_review(self, tlm_project):
        """--show-last should display cached review."""
        cache = tlm_project / ".tlm" / "cache" / "last_review.json"
        cache.write_text(json.dumps({
            "severity": "pass",
            "gaps": [],
            "follow_up_questions": [],
        }))

        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "--show-last", "--path", str(tlm_project)
        ])

        assert result.exit_code == 0
        assert "pass" in result.output.lower()

    def test_show_last_no_cache(self, tlm_project):
        """--show-last should show message when no cached review exists."""
        runner = CliRunner()
        result = runner.invoke(main, [
            "review", "--show-last", "--path", str(tlm_project)
        ])

        assert result.exit_code == 0
        assert "no" in result.output.lower() or "not found" in result.output.lower()


class TestHookSpecReviewDispatch:
    def test_hook_spec_review_dispatch(self, tlm_project):
        """_hook spec_review should call hook_spec_review."""
        tool_input = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/src/app.py"},
        })

        runner = CliRunner()
        result = runner.invoke(
            main, ["_hook", "spec_review", "--path", str(tlm_project)],
            input=tool_input,
        )
        assert result.exit_code == 0
