"""
Tests for config_generator.py — LLM-powered enforcement config generation.

Adapted from mvp/tests/test_engine_api.py::TestConfigGeneratorAPI.
ConfigGenerator uses direct file paths (no Project class).
"""

import json
from unittest.mock import MagicMock, patch
from pathlib import Path

import pytest


SAMPLE_PROFILE = "## Stack\nPython, FastAPI\n## Testing\npytest"

SAMPLE_CONFIG = {
    "project_summary": "Python FastAPI app",
    "environments": {
        "staging": {"description": "Staging", "deploy_command": "deploy staging"},
        "production": {"description": "Production", "deploy_command": "deploy prod"},
    },
    "checks": [
        {"name": "Tests", "command": "pytest", "blocker": True, "when": "pre_commit"},
    ],
    "coverage": {"command": "pytest --cov", "min_line_coverage": 70},
    "drift_files": ["requirements.txt"],
}


@pytest.fixture
def project_dir(tmp_path):
    """Set up a minimal .tlm/ directory."""
    tlm = tmp_path / ".tlm"
    tlm.mkdir()
    (tlm / "profile.md").write_text(SAMPLE_PROFILE)
    (tlm / "config.json").write_text(json.dumps({"project_name": "test"}))
    # Create a dummy file so scan_files has something
    (tmp_path / "main.py").write_text("print('hello')")
    return tmp_path


@pytest.fixture
def mock_client():
    return MagicMock()


class TestConfigGeneratorGenerate:
    def test_generate_calls_api_client(self, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        mock_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")

        config = gen.generate()

        assert config == SAMPLE_CONFIG
        mock_client.generate_config.assert_called_once()

    def test_generate_passes_profile_and_files(self, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        mock_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(str(project_dir), mock_client, "proj_42")

        gen.generate()

        call_args = mock_client.generate_config.call_args
        assert call_args[0][0] == "proj_42"  # project_id
        assert SAMPLE_PROFILE in call_args[0][1]  # profile

    def test_generate_reads_profile_from_file(self, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        mock_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")

        gen.generate()

        call_args = mock_client.generate_config.call_args
        assert "FastAPI" in call_args[0][1]

    @patch("tlm.config_generator.ConfigGenerator._get_local_config", return_value={"project_summary": "local"})
    def test_generate_passes_local_config(self, mock_local, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        mock_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")

        gen.generate()

        call_kwargs = mock_client.generate_config.call_args
        assert call_kwargs[1].get("local_config") == {"project_summary": "local"}

    @patch("tlm.config_generator.ConfigGenerator._get_local_config", return_value=None)
    def test_generate_works_without_local_config(self, mock_local, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        mock_client.generate_config.return_value = {"config": SAMPLE_CONFIG}
        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")

        config = gen.generate()
        assert config == SAMPLE_CONFIG


class TestConfigGeneratorUpdate:
    def test_update_config_calls_api(self, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        updated = {**SAMPLE_CONFIG, "project_summary": "Updated"}
        mock_client.update_config.return_value = {"config": updated}
        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")

        result = gen.update_config(SAMPLE_CONFIG, "Change the summary")

        assert result["project_summary"] == "Updated"
        mock_client.update_config.assert_called_once()


class TestConfigGeneratorSaveApproved:
    def test_save_approved_creates_enforcement_json(self, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")
        gen.save_approved(SAMPLE_CONFIG)

        enforcement_path = project_dir / ".tlm" / "enforcement.json"
        assert enforcement_path.exists()
        saved = json.loads(enforcement_path.read_text())
        assert saved["approved"] is True

    def test_save_approved_marks_as_approved(self, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")
        gen.save_approved(SAMPLE_CONFIG)

        from tlm.enforcer import EnforcementConfig
        ec = EnforcementConfig(str(project_dir / ".tlm"))
        assert ec.approved is True


class TestGetLocalConfig:
    @patch("tlm.config_generator.shutil.which", return_value=None)
    def test_claude_not_found_returns_none(self, mock_which, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None

    @patch("tlm.config_generator.subprocess.run")
    @patch("tlm.config_generator.shutil.which", return_value="/usr/bin/claude")
    def test_success_returns_parsed_json(self, mock_which, mock_run, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        config_json = json.dumps(SAMPLE_CONFIG)
        mock_run.return_value = MagicMock(returncode=0, stdout=config_json)

        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")
        result = gen._get_local_config("profile", "tree", "samples")

        assert result == SAMPLE_CONFIG

    @patch("tlm.config_generator.subprocess.run")
    @patch("tlm.config_generator.shutil.which", return_value="/usr/bin/claude")
    def test_timeout_returns_none(self, mock_which, mock_run, project_dir, mock_client):
        import subprocess
        from tlm.config_generator import ConfigGenerator

        mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=90)

        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None

    @patch("tlm.config_generator.subprocess.run")
    @patch("tlm.config_generator.shutil.which", return_value="/usr/bin/claude")
    def test_invalid_json_returns_none(self, mock_which, mock_run, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        mock_run.return_value = MagicMock(returncode=0, stdout="not valid json")

        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None

    @patch("tlm.config_generator.subprocess.run")
    @patch("tlm.config_generator.shutil.which", return_value="/usr/bin/claude")
    def test_nonzero_exit_returns_none(self, mock_which, mock_run, project_dir, mock_client):
        from tlm.config_generator import ConfigGenerator

        mock_run.return_value = MagicMock(returncode=1, stdout="")

        gen = ConfigGenerator(str(project_dir), mock_client, "proj_123")
        result = gen._get_local_config("profile", "tree", "samples")
        assert result is None
