"""Tests for tlm.enforcer -- CheckResult, EnforcementReport, EnforcementConfig, Enforcer."""

import json
import hashlib
from unittest.mock import patch, MagicMock

import pytest

from tlm.enforcer import CheckResult, EnforcementReport, EnforcementConfig, Enforcer


# --- CheckResult ---

class TestCheckResult:
    def test_str_pass_icon(self):
        result = CheckResult(name="Lint", passed=True, message="All good", blocker=True)
        assert str(result) == "  + Lint: All good"

    def test_str_blocker_fail_icon(self):
        result = CheckResult(name="Tests", passed=False, message="3 failures", blocker=True)
        assert str(result) == "  x Tests: 3 failures"

    def test_str_warning_fail_icon(self):
        result = CheckResult(name="Style", passed=False, message="Nitpicks", blocker=False)
        assert str(result) == "  ! Style: Nitpicks"


# --- EnforcementReport ---

class TestEnforcementReport:
    def test_passed_when_all_blockers_pass(self):
        report = EnforcementReport(checks=[
            CheckResult("A", True, "ok", blocker=True),
            CheckResult("B", True, "ok", blocker=True),
            CheckResult("C", False, "fail", blocker=False),  # warning, not blocker
        ])
        assert report.passed is True

    def test_passed_false_when_blocker_fails(self):
        report = EnforcementReport(checks=[
            CheckResult("A", True, "ok", blocker=True),
            CheckResult("B", False, "fail", blocker=True),
        ])
        assert report.passed is False

    def test_warnings_returns_non_blocker_failures(self):
        report = EnforcementReport(checks=[
            CheckResult("A", True, "ok", blocker=True),
            CheckResult("B", False, "fail", blocker=False),
            CheckResult("C", False, "also fail", blocker=False),
            CheckResult("D", False, "blocker fail", blocker=True),
        ])
        warnings = report.warnings
        assert len(warnings) == 2
        assert all(not w.blocker for w in warnings)
        assert all(not w.passed for w in warnings)

    def test_blockers_returns_failed_blockers(self):
        report = EnforcementReport(checks=[
            CheckResult("A", False, "fail", blocker=True),
            CheckResult("B", False, "fail", blocker=False),
        ])
        assert len(report.blockers) == 1
        assert report.blockers[0].name == "A"

    def test_passed_true_when_empty(self):
        report = EnforcementReport()
        assert report.passed is True


# --- EnforcementConfig ---

class TestEnforcementConfig:
    def test_exists_false_when_no_file(self, tmp_path):
        config = EnforcementConfig(str(tmp_path))
        assert config.exists is False

    def test_load_returns_empty_dict_when_no_file(self, tmp_path):
        config = EnforcementConfig(str(tmp_path))
        assert config.load() == {}

    def test_save_and_load_roundtrip(self, tmp_path):
        config = EnforcementConfig(str(tmp_path))
        data = {
            "checks": [{"name": "lint", "command": "flake8", "when": "pre_commit"}],
            "environments": {"dev": {"description": "Local dev"}},
        }
        config.save(data)
        loaded = config.load()
        assert loaded == data
        assert config.exists is True

    def test_approve_sets_approved_and_drift_hashes(self, tmp_path):
        # Create a project structure: tmp_path is the project root,
        # .tlm is inside it. The config path is .tlm/enforcement.json.
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        # Create a drift file at project root level
        (tmp_path / "requirements.txt").write_text("flask==3.0\n")

        config = EnforcementConfig(str(tlm_dir))
        config.save({
            "checks": [],
            "drift_files": ["requirements.txt"],
        })
        config.approve()

        loaded = config.load()
        assert loaded["approved"] is True
        assert "approved_at" in loaded
        assert "drift_hashes" in loaded
        assert "requirements.txt" in loaded["drift_hashes"]
        # Hash should be a 16-char hex string
        hash_val = loaded["drift_hashes"]["requirements.txt"]
        assert len(hash_val) == 16

    def test_check_drift_detects_file_changes(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        req_file = tmp_path / "requirements.txt"
        req_file.write_text("flask==3.0\n")

        config = EnforcementConfig(str(tlm_dir))
        config.save({
            "checks": [],
            "drift_files": ["requirements.txt"],
        })
        config.approve()

        # No drift yet
        drift = config.check_drift()
        assert drift["drifted"] is False
        assert drift["changed_files"] == []

        # Modify the file
        req_file.write_text("flask==4.0\nrequests==2.31\n")

        drift = config.check_drift()
        assert drift["drifted"] is True
        assert "requirements.txt" in drift["changed_files"]
        assert drift["details"]["requirements.txt"] == "modified"

    def test_check_drift_no_drift_when_unapproved(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        config = EnforcementConfig(str(tlm_dir))
        config.save({"checks": [], "drift_files": ["foo.txt"]})
        # Not approved
        drift = config.check_drift()
        assert drift["drifted"] is False


# --- Enforcer ---

class TestEnforcer:
    def test_run_checks_returns_no_config_error_when_unapproved(self, tmp_path):
        # No .tlm/enforcement.json at all
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        enforcer = Enforcer(project_root=str(tmp_path))
        report = enforcer.run_checks("pre_commit")
        assert report.passed is False
        assert len(report.checks) == 1
        assert "No approved enforcement config" in report.checks[0].message

    def test_run_checks_executes_matching_checks(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        config = EnforcementConfig(str(tlm_dir))
        config.save({
            "approved": True,
            "checks": [
                {"name": "Lint", "command": "echo lint ok", "when": "pre_commit", "blocker": True},
                {"name": "Build", "command": "echo build ok", "when": "pre_build", "blocker": True},
            ],
        })

        enforcer = Enforcer(project_root=str(tmp_path))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "lint ok\n"
        mock_result.stderr = ""

        with patch("tlm.enforcer.subprocess.run", return_value=mock_result) as mock_run:
            report = enforcer.run_checks("pre_commit")

        # Only the "Lint" check should run (matches "pre_commit")
        assert len(report.checks) == 1
        assert report.checks[0].name == "Lint"
        assert report.checks[0].passed is True
        mock_run.assert_called_once()

    def test_parse_coverage_from_stdout_total_line(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        enforcer = Enforcer(project_root=str(tmp_path))
        output = (
            "Name                 Stmts   Miss  Cover\n"
            "app/main.py             50     10    80%\n"
            "app/utils.py            30      6    80%\n"
            "TOTAL                   80     16    80%\n"
        )
        line_cov, branch_cov = enforcer._parse_coverage(output, None, None)
        assert line_cov == 80.0
        assert branch_cov is None

    def test_parse_coverage_json_summary_format(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        # Write a JSON summary report file
        report_data = {
            "total": {
                "lines": {"pct": 85.5},
                "branches": {"pct": 72.3},
            }
        }
        report_path = tmp_path / "coverage-summary.json"
        report_path.write_text(json.dumps(report_data))

        enforcer = Enforcer(project_root=str(tmp_path))
        line_cov, branch_cov = enforcer._parse_coverage(
            "", "coverage-summary.json", "json_summary"
        )
        assert line_cov == 85.5
        assert branch_cov == 72.3

    def test_parse_coverage_json_summary_totals_format(self, tmp_path):
        """Test the alternative 'totals' key format (e.g. coverage.py JSON)."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        report_data = {
            "totals": {
                "percent_covered": 91.0,
                "percent_covered_branches": 67.5,
            }
        }
        report_path = tmp_path / "cov.json"
        report_path.write_text(json.dumps(report_data))

        enforcer = Enforcer(project_root=str(tmp_path))
        line_cov, branch_cov = enforcer._parse_coverage(
            "", "cov.json", "json_summary"
        )
        assert line_cov == 91.0
        assert branch_cov == 67.5
