"""Tests for tlm.learner -- GitReader, CommitAnalyzer, LearningSynthesizer, KnowledgeUpdater."""

import json
import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from tlm.learner import GitReader, CommitAnalyzer, LearningSynthesizer, KnowledgeUpdater


# --- GitReader ---

class TestGitReader:
    def test_parse_commit_log_parses_format_correctly(self):
        reader = GitReader("/tmp/fake-project")

        log_output = (
            "abc123|||Add user auth|||Alice|||2025-05-01T10:00:00+00:00\n"
            "def456|||Fix login bug|||Bob|||2025-05-02T11:00:00+00:00\n"
        )

        with patch.object(reader, "_get_commit_diff", return_value="diff --git ..."):
            commits = reader._parse_commit_log(log_output)

        assert len(commits) == 2

        assert commits[0]["hash"] == "abc123"
        assert commits[0]["message"] == "Add user auth"
        assert commits[0]["author"] == "Alice"
        assert commits[0]["date"] == "2025-05-01T10:00:00+00:00"
        assert commits[0]["diff"] == "diff --git ..."

        assert commits[1]["hash"] == "def456"
        assert commits[1]["message"] == "Fix login bug"
        assert commits[1]["author"] == "Bob"

    def test_parse_commit_log_skips_malformed_lines(self):
        reader = GitReader("/tmp/fake-project")

        log_output = (
            "abc123|||Add auth|||Alice|||2025-05-01\n"
            "malformed line without delimiters\n"
            "\n"
            "def456|||Fix bug|||Bob|||2025-05-02\n"
        )

        with patch.object(reader, "_get_commit_diff", return_value=""):
            commits = reader._parse_commit_log(log_output)

        assert len(commits) == 2
        assert commits[0]["hash"] == "abc123"
        assert commits[1]["hash"] == "def456"


# --- CommitAnalyzer ---

class TestCommitAnalyzer:
    def test_analyze_batch_retries_on_failure(self):
        mock_client = MagicMock()
        analyzer = CommitAnalyzer(api_client=mock_client, project_id="proj-1")

        commit = {"hash": "abc123", "message": "Fix bug", "diff": "..."}

        # First call fails, second (retry) succeeds
        mock_client.analyze_commit.side_effect = [
            Exception("timeout"),
            {"analysis": {"hash": "abc123", "category": "bugfix", "lessons": []}},
        ]

        results = analyzer.analyze_batch([commit])

        assert len(results) == 1
        assert results[0]["category"] == "bugfix"
        assert mock_client.analyze_commit.call_count == 2

    def test_analyze_batch_returns_placeholder_on_double_failure(self):
        mock_client = MagicMock()
        analyzer = CommitAnalyzer(api_client=mock_client, project_id="proj-1")

        commit = {"hash": "abc123", "message": "Fix bug", "diff": "..."}

        # Both calls fail
        mock_client.analyze_commit.side_effect = Exception("server down")

        results = analyzer.analyze_batch([commit])

        assert len(results) == 1
        assert results[0]["hash"] == "abc123"
        assert results[0]["category"] == "unknown"
        assert results[0]["planned"] is False
        assert "Analysis failed" in results[0]["unplanned_reason"]

    def test_analyze_batch_calls_progress_callback(self):
        mock_client = MagicMock()
        mock_client.analyze_commit.return_value = {
            "analysis": {"hash": "abc", "category": "feature", "summary": "test"}
        }
        analyzer = CommitAnalyzer(api_client=mock_client, project_id="proj-1")

        commits = [
            {"hash": "abc", "message": "A", "diff": ""},
            {"hash": "def", "message": "B", "diff": ""},
        ]
        callback = MagicMock()
        analyzer.analyze_batch(commits, progress_callback=callback)

        assert callback.call_count == 2
        # First call: (1, 2, "abc", ...)
        assert callback.call_args_list[0][0][0] == 1
        assert callback.call_args_list[0][0][1] == 2


# --- LearningSynthesizer ---

class TestLearningSynthesizer:
    def test_synthesize_calls_api_client(self):
        mock_client = MagicMock()
        mock_client.synthesize.return_value = {
            "synthesis": {
                "period": "2025-W20",
                "total_commits": 5,
                "spec_accuracy_percent": 80,
            }
        }
        synthesizer = LearningSynthesizer(api_client=mock_client, project_id="proj-1")

        analyzed = [{"hash": "abc", "category": "feature"}]
        result = synthesizer.synthesize(analyzed)

        mock_client.synthesize.assert_called_once_with("proj-1", analyzed)
        assert result["period"] == "2025-W20"
        assert result["total_commits"] == 5


# --- KnowledgeUpdater ---

class TestKnowledgeUpdater:
    @pytest.fixture
    def project(self, tmp_path):
        """Create a minimal project with .tlm directory."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        # config.json is needed by load_project_config
        (tlm_dir / "config.json").write_text(json.dumps({}))
        return tmp_path

    def _make_synthesis(self):
        return {
            "period": "2025-05-01 to 2025-05-07",
            "total_commits": 10,
            "spec_accuracy_percent": 85,
            "planned_commits": 8,
            "unplanned_commits": 2,
            "bug_patterns": [
                {
                    "pattern": "Missing null check",
                    "frequency": 3,
                    "severity": "high",
                    "lesson": "Always validate inputs",
                    "interview_questions": ["How do you handle null inputs?"],
                }
            ],
            "unplanned_features": [
                {
                    "what": "Caching layer",
                    "lesson": "Caching was needed earlier",
                    "interview_questions": ["Do you need caching?"],
                }
            ],
            "architecture_evolutions": [
                {"what": "Moved to microservices", "lesson": "Plan service boundaries"}
            ],
            "interview_improvements": ["Ask about error handling patterns"],
        }

    def test_update_from_synthesis_writes_to_knowledge_md(self, project):
        updater = KnowledgeUpdater(str(project))
        synthesis = self._make_synthesis()
        updater.update_from_synthesis(synthesis)

        knowledge_file = project / ".tlm" / "knowledge.md"
        assert knowledge_file.exists()
        content = knowledge_file.read_text()
        assert "Lessons from commits" in content
        assert "10 commits analyzed, 85% spec accuracy" in content
        assert "Missing null check" in content
        assert "Caching layer" in content
        assert "Ask about error handling patterns" in content

    def test_update_from_synthesis_updates_config_json(self, project):
        updater = KnowledgeUpdater(str(project))
        synthesis = self._make_synthesis()
        updater.update_from_synthesis(synthesis)

        config_file = project / ".tlm" / "config.json"
        config = json.loads(config_file.read_text())
        assert "spec_accuracy_history" in config
        assert len(config["spec_accuracy_history"]) == 1
        assert config["spec_accuracy_history"][0]["accuracy"] == 85
        assert config["total_commits_analyzed"] == 10
        assert "last_learning_at" in config

    def test_update_from_synthesis_saves_synthesis_file(self, project):
        updater = KnowledgeUpdater(str(project))
        synthesis = self._make_synthesis()
        updater.update_from_synthesis(synthesis)

        lessons_dir = project / ".tlm" / "lessons"
        assert lessons_dir.exists()
        synthesis_files = list(lessons_dir.glob("*-synthesis.json"))
        assert len(synthesis_files) == 1

        saved = json.loads(synthesis_files[0].read_text())
        assert saved["total_commits"] == 10
        assert saved["spec_accuracy_percent"] == 85

    def test_update_from_synthesis_appends_to_existing_knowledge(self, project):
        knowledge_file = project / ".tlm" / "knowledge.md"
        knowledge_file.write_text("# Existing Knowledge\n\n- Old rule\n")

        updater = KnowledgeUpdater(str(project))
        synthesis = self._make_synthesis()
        updater.update_from_synthesis(synthesis)

        content = knowledge_file.read_text()
        assert "# Existing Knowledge" in content
        assert "Old rule" in content
        assert "Lessons from commits" in content

    def test_update_from_synthesis_writes_to_db(self, project):
        updater = KnowledgeUpdater(str(project))
        synthesis = self._make_synthesis()
        updater.update_from_synthesis(synthesis)

        # Verify metrics in DB
        metrics = updater.db.list_metrics()
        assert len(metrics) == 1
        assert metrics[0]["total_commits"] == 10

        # Verify rules from bug patterns and improvements
        rules = updater.db.list_rules()
        rule_texts = [r["rule_text"] for r in rules]
        assert "Always validate inputs" in rule_texts
        assert "Ask about error handling patterns" in rule_texts
