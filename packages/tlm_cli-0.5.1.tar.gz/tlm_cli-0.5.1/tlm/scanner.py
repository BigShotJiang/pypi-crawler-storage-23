"""Scanner — collects file tree and samples from a project directory."""

import os
from pathlib import Path

# Directories to always skip
SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__",
    ".tox", ".mypy_cache", ".pytest_cache", "venv", ".venv",
    "env", ".env", "dist", "build", ".eggs", "*.egg-info",
    ".next", ".nuxt", ".output", "coverage", ".coverage",
}

# File extensions to skip
SKIP_EXTENSIONS = {
    ".pyc", ".pyo", ".so", ".o", ".a", ".dylib",
    ".class", ".jar", ".war",
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg",
    ".woff", ".woff2", ".ttf", ".eot",
    ".zip", ".tar", ".gz", ".bz2", ".7z",
    ".lock", ".min.js", ".min.css",
}

# Key files to prioritize for sampling
KEY_FILES = {
    "pyproject.toml", "setup.py", "setup.cfg",
    "package.json", "tsconfig.json",
    "Cargo.toml", "go.mod", "go.sum",
    "Gemfile", "build.gradle", "pom.xml",
    "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
    "Makefile", "CMakeLists.txt",
    ".github/workflows/ci.yml", ".github/workflows/main.yml",
    ".gitlab-ci.yml", "Jenkinsfile",
    "requirements.txt", "Pipfile",
    "app.py", "main.py", "index.js", "index.ts",
    "README.md",
}

MAX_TREE_DEPTH = 8
MAX_SAMPLE_FILES = 10
MAX_SAMPLE_SIZE = 2000  # chars per file


def _should_skip_dir(name: str) -> bool:
    return name in SKIP_DIRS or name.startswith(".")


def _should_skip_file(name: str) -> bool:
    _, ext = os.path.splitext(name)
    return ext.lower() in SKIP_EXTENSIONS


def _collect_tree(root: str, max_depth: int = MAX_TREE_DEPTH) -> list[str]:
    """Collect file tree as list of relative paths."""
    files = []
    root_path = Path(root)

    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        depth = 0 if rel_dir == "." else rel_dir.count(os.sep) + 1

        if depth >= max_depth:
            dirnames.clear()
            continue

        # Filter directories in-place
        dirnames[:] = [d for d in dirnames if not _should_skip_dir(d)]

        for f in sorted(filenames):
            if _should_skip_file(f):
                continue
            rel_path = os.path.join(rel_dir, f) if rel_dir != "." else f
            files.append(rel_path)

    return sorted(files)


def _collect_samples(root: str, file_list: list[str]) -> str:
    """Read key files for sampling. Prioritize manifest/config files."""
    sampled = []
    sampled_count = 0

    # Priority: key files first
    priority = []
    rest = []
    for f in file_list:
        basename = os.path.basename(f)
        if basename in KEY_FILES or f in KEY_FILES:
            priority.append(f)
        else:
            rest.append(f)

    candidates = priority + rest

    for rel_path in candidates:
        if sampled_count >= MAX_SAMPLE_FILES:
            break

        full_path = os.path.join(root, rel_path)
        try:
            with open(full_path, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read(MAX_SAMPLE_SIZE)
            sampled.append(f"=== {rel_path} ===\n{content}")
            sampled_count += 1
        except (OSError, UnicodeDecodeError):
            continue

    return "\n\n".join(sampled)


def scan_project(root: str = ".") -> dict[str, str]:
    """Scan a project directory and return file_tree + samples.

    Returns dict with 'file_tree' and 'samples' keys.
    """
    root = os.path.abspath(root)
    file_list = _collect_tree(root)
    file_tree = "\n".join(file_list)
    samples = _collect_samples(root, file_list)

    return {
        "file_tree": file_tree,
        "samples": samples,
    }
