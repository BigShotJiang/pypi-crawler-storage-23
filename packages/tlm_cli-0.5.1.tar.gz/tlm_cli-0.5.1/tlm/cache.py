"""
TLM Cache -- Local cache manager for server sync data.

Caches data from GET /sync endpoint to .tlm/cache.json.
Provides fallback to raw .tlm/ files when cache is empty.
"""

import json
import datetime
from pathlib import Path
from typing import Optional

DEFAULT_TTL_SECONDS = 3600


class TLMCache:
    """Local cache for server sync data."""

    def __init__(self, tlm_dir: str, ttl_seconds: int = DEFAULT_TTL_SECONDS):
        self.tlm_dir = Path(tlm_dir)
        self.cache_file = self.tlm_dir / "cache.json"
        self.ttl_seconds = ttl_seconds

    def write_sync(self, data: dict):
        self.cache_file.write_text(json.dumps({
            "synced_at": datetime.datetime.now().isoformat(),
            "data": data,
        }, indent=2))

    def read_sync(self) -> Optional[dict]:
        if not self.cache_file.exists():
            return None
        try:
            cache_data = json.loads(self.cache_file.read_text())
            if "data" not in cache_data:
                return None
            return cache_data["data"]
        except (json.JSONDecodeError, OSError, KeyError):
            return None

    def is_stale(self) -> bool:
        if not self.cache_file.exists():
            return True
        try:
            cache_data = json.loads(self.cache_file.read_text())
            synced_at = datetime.datetime.fromisoformat(cache_data["synced_at"])
            age = (datetime.datetime.now() - synced_at).total_seconds()
            return age > self.ttl_seconds
        except (json.JSONDecodeError, OSError, KeyError, ValueError):
            return True

    def clear(self):
        if self.cache_file.exists():
            self.cache_file.unlink()

    # --- Field Accessors ---

    def _get_field(self, field: str):
        data = self.read_sync()
        if data is None:
            return None
        return data.get(field)

    def get_knowledge(self) -> Optional[str]:
        return self._get_field("knowledge")

    def get_profile(self) -> Optional[str]:
        return self._get_field("profile")

    def get_enforcement_config(self) -> Optional[dict]:
        return self._get_field("enforcement_config")

    def get_latest_synthesis(self) -> Optional[dict]:
        return self._get_field("latest_synthesis")

    def get_specs(self) -> Optional[list]:
        return self._get_field("specs")

    def get_project_lessons(self) -> Optional[str]:
        return self._get_field("project_lessons")

    # --- Fallback Accessors ---

    def get_knowledge_with_fallback(self) -> Optional[str]:
        cached = self.get_knowledge()
        if cached is not None:
            return cached
        raw_file = self.tlm_dir / "knowledge.md"
        if raw_file.exists():
            return raw_file.read_text()
        return None

    def get_profile_with_fallback(self) -> Optional[str]:
        cached = self.get_profile()
        if cached is not None:
            return cached
        raw_file = self.tlm_dir / "profile.md"
        if raw_file.exists():
            return raw_file.read_text()
        return None

    def get_enforcement_config_with_fallback(self) -> Optional[dict]:
        cached = self.get_enforcement_config()
        if cached is not None:
            return cached
        raw_file = self.tlm_dir / "enforcement.json"
        if raw_file.exists():
            try:
                return json.loads(raw_file.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        return None
