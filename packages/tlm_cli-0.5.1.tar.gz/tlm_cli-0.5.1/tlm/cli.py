"""CLI entry point — tlm auth, install, scan, gaps, fix, review, status, logout, uninstall, upgrade."""

import atexit
import functools
import json
import logging
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from tlm.config import (
    get_server_url,
    get_api_key,
    save_credentials,
    load_project_config,
)
from tlm.client import (
    TLMClient,
    TLMCreditsError,
    TLMAuthError,
    TLMProjectLimitError,
    TLMServerError,
    TLMConnectionError,
)
from tlm.config_generator import ConfigGenerator
from tlm.installer import Installer
from tlm.gaps import load_gaps, get_active_gaps, get_gap_by_id, update_gap_status, GapStatus, extract_gaps_from_profile
from tlm.state import read_state, write_state, set_phase
from tlm.interviewer import Interviewer
from tlm.executor import Executor
from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
    hook_plan_approved,
    hook_spec_review,
    hook_stop,
)

console = Console()

# ── Terminal state management ────────────────────────────────

_saved_termios = None


def _save_terminal():
    """Save terminal state so we can restore on messy exit."""
    global _saved_termios
    try:
        import termios
        _saved_termios = termios.tcgetattr(sys.stdin.fileno())
    except (ImportError, OSError, ValueError):
        pass


def _restore_terminal():
    """Restore terminal to saved state + show cursor. Called via atexit."""
    global _saved_termios
    try:
        import termios
        if _saved_termios is not None:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, _saved_termios)
    except (ImportError, OSError, ValueError):
        pass
    # Always try to show cursor (Rich may have hidden it)
    try:
        sys.stdout.write("\033[?25h")  # ANSI: show cursor
        sys.stdout.flush()
    except (OSError, ValueError):
        pass


# ── Error handling ───────────────────────────────────────────

def _setup_logger() -> logging.Logger:
    """Configure logger that writes to .tlm/tlm.log. Never writes to terminal."""
    _logger = logging.getLogger("tlm")
    if not _logger.handlers:
        tlm_dir = Path(".tlm")
        if tlm_dir.exists():
            handler = logging.FileHandler(tlm_dir / "tlm.log")
            handler.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)s %(name)s: %(message)s"
            ))
            _logger.addHandler(handler)
        _logger.setLevel(logging.DEBUG)
    return _logger


def _log_error(e: Exception):
    """Log exception with full traceback to .tlm/tlm.log. Never to terminal."""
    logger = _setup_logger()
    logger.error("%s: %s", type(e).__name__, e, exc_info=True)


def _handle_api_errors(f):
    """Decorator: catch TLM API exceptions → friendly messages, never stacktraces."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except KeyboardInterrupt:
            _restore_terminal()
            console.print("\n[yellow]Interrupted.[/yellow]")
            raise SystemExit(130)
        except TLMCreditsError as e:
            _log_error(e)
            detail = e.args[0] if e.args else {}
            tier = detail.get("tier", "free") if isinstance(detail, dict) else "free"
            upgrade_url = detail.get("upgrade_url", "https://tlmforge.dev/#pricing") if isinstance(detail, dict) else "https://tlmforge.dev/#pricing"
            console.print(f"\n[red bold]You've used all {tier} credits.[/red bold]")
            console.print(f"[dim]Upgrade at: {upgrade_url}[/dim]")
            raise SystemExit(1)
        except TLMProjectLimitError as e:
            _log_error(e)
            detail = e.args[0] if e.args else {}
            if isinstance(detail, dict):
                max_allowed = detail.get("max_allowed", 1)
                tier = detail.get("tier", "free")
            else:
                max_allowed = 1
                tier = "free"
            console.print(f"\n[red bold]Project limit reached. Your {tier} plan allows {max_allowed} project(s).[/red bold]")
            console.print("[dim]Upgrade your plan to add more projects.[/dim]")
            raise SystemExit(1)
        except TLMAuthError as e:
            _log_error(e)
            console.print("\n[red bold]Authentication failed.[/red bold]")
            console.print("[dim]Run 'tlm auth' to re-authenticate.[/dim]")
            raise SystemExit(1)
        except TLMConnectionError as e:
            _log_error(e)
            console.print("\n[red bold]Cannot reach TLM server.[/red bold]")
            console.print("[dim]Check your internet connection and try again.[/dim]")
            raise SystemExit(1)
        except KeyboardInterrupt:
            # Defense-in-depth: catch here too in case exception chain mutates
            _restore_terminal()
            console.print("\n[yellow]Interrupted.[/yellow]")
            raise SystemExit(130)
        except (TLMServerError, Exception) as e:
            _log_error(e)
            console.print("\n[red bold]Internal error. Please try again later.[/red bold]")
            console.print("[dim]Details logged to .tlm/tlm.log[/dim]")
            raise SystemExit(1)
    return wrapper

AUTH_URL = "https://tlmforge.dev/auth"


def _is_firebase_token(token: str) -> bool:
    """Detect if a token is a Firebase JWT (3-part dot-separated, >100 chars)."""
    parts = token.split(".")
    return len(parts) == 3 and len(token) > 100


@click.group()
def main():
    """TLM — Tech Lead & Manager for your codebase."""
    _save_terminal()
    atexit.register(_restore_terminal)


# ── Auth ──────────────────────────────────────────────────────

@main.command()
@click.argument("token", required=False, default=None)
@click.option("--server", default=None, help="TLM server URL")
def auth(token: str, server: str):
    """Authenticate with TLM. Shows status if already logged in."""
    server_url = server or get_server_url()

    # Pre-check: already logged in?
    if token is None:
        existing_key = get_api_key()
        if existing_key:
            try:
                client = TLMClient(server_url=server_url, api_key=existing_key)
                user = client.me()
                email = user.get("email", user.get("user_id", "unknown"))
                console.print(f"[green]Already authenticated as {email}[/green]")
                console.print("[dim]Run 'tlm logout' to switch accounts.[/dim]")
                return
            except Exception:
                pass  # stale creds, fall through to interactive prompt

    # Interactive mode: no token provided
    if token is None:
        console.print(f"\n1. Open: [bold]{AUTH_URL}[/bold]")
        console.print("2. Sign in with Google or email")
        console.print("3. Copy your token and paste it below\n")
        token = click.prompt("Paste your token").strip()

    client = TLMClient(server_url=server_url, api_key="")

    if token.startswith("tlm_sk_"):
        # Direct API key — save first, then verify
        save_credentials(server_url, token)
        client.api_key = token
        try:
            user = client.me()
            console.print(f"[green]Authenticated as {user.get('email', user.get('user_id', 'unknown'))}[/green]")
        except Exception:
            console.print("[yellow]Warning: could not verify credentials, but saved.[/yellow]")

    elif _is_firebase_token(token):
        # Firebase JWT — exchange for API key
        try:
            result = (client.exchange_firebase_token(token))
        except Exception as e:
            console.print(f"[red]Token exchange failed: {e}[/red]")
            raise SystemExit(1)
        api_key = result["api_key"]
        save_credentials(server_url, api_key)
        console.print(f"[green]Authenticated as {result.get('email', result.get('user_id', 'unknown'))}[/green]")

    else:
        console.print("[red]Invalid token. Expected a TLM API key (tlm_sk_...) or a Firebase token.[/red]")
        raise SystemExit(1)

    console.print("Credentials saved to ~/.tlm/credentials.json")


# ── Install ───────────────────────────────────────────────────

def _display_config(config: dict):
    """Display enforcement config as a Rich table."""
    table = Table(title="Enforcement Config", border_style="cyan")
    table.add_column("Section", style="bold")
    table.add_column("Details")

    for check in config.get("checks", []):
        blocker = "[red]BLOCKER[/red]" if check.get("blocker") else "[yellow]warning[/yellow]"
        table.add_row(f"Check: {check['name']}", f"{blocker} — {check.get('command', '?')}")

    for name, env in config.get("environments", {}).items():
        table.add_row(f"Env: {name}", env.get("deploy_command", "?"))

    cov = config.get("coverage", {})
    if cov:
        table.add_row("Coverage", f"min {cov.get('min_line_coverage', '?')}%")

    console.print(table)


@main.command()
@click.option("--path", default=".", help="Project root path")
@click.pass_context
@_handle_api_errors
def install(ctx, path: str):
    """Install TLM in a project: scan, configure, and set up hooks."""
    server_url = get_server_url()
    api_key = get_api_key()

    # 1. Auto-auth if not authenticated
    if not api_key:
        console.print("[yellow]Not authenticated. Starting auth...[/yellow]")
        ctx.invoke(auth)
        api_key = get_api_key()
        if not api_key:
            console.print("[red]Authentication failed. Cannot install.[/red]")
            raise SystemExit(1)

    # 2. Welcome banner
    logo = Text()
    logo.append("████████╗██╗     ███╗   ███╗\n", style="bold cyan")
    logo.append("╚══██╔══╝██║     ████╗ ████║\n", style="bold cyan")
    logo.append("   ██║   ██║     ██╔████╔██║\n", style="bold cyan")
    logo.append("   ██║   ██║     ██║╚██╔╝██║\n", style="bold cyan")
    logo.append("   ██║   ███████╗██║ ╚═╝ ██║\n", style="bold cyan")
    logo.append("   ╚═╝   ╚══════╝╚═╝     ╚═╝\n", style="bold cyan")
    logo.append("  The annoying agent that makes you ship better code", style="dim")
    console.print(Panel(logo, border_style="cyan", padding=(1, 4)))

    installer = Installer(path, server_url=server_url, api_key=api_key)

    # 3. Init + ensure project on server
    with console.status("[cyan]Scanning your project...[/cyan]", spinner="dots"):
        installer.init_project_dir()
        project_id = installer.ensure_project()
        scan_data = installer.scan_project()
    console.print("  [green]✓[/green] Project structure analyzed")

    # 4. Assess
    with console.status("[cyan]Analyzing recommendations...[/cyan]", spinner="dots"):
        result = installer.assess(scan_data)
    console.print("  [green]✓[/green] Recommendations ready")

    profile = result.get("profile", {})
    if profile:
        console.print(f"  [dim]Stack: {profile.get('stack', 'unknown')}[/dim]")

    # 5. Config generation + approval
    client = TLMClient(server_url=server_url, api_key=api_key)
    config_gen = ConfigGenerator(path, client, str(project_id))

    with console.status("[cyan]Generating enforcement config...[/cyan]", spinner="dots"):
        config = config_gen.generate()

    _display_config(config)

    while True:
        choice = click.prompt(
            "[A]pprove / [C]orrect / [R]eject",
            default="a",
            show_default=False,
        ).strip().lower()

        if choice in ("a", "approve", ""):
            config_gen.save_approved(config)
            console.print("  [green]✓[/green] Enforcement config approved")
            break
        elif choice in ("c", "correct"):
            feedback = click.prompt("What should change?")
            with console.status("[cyan]Updating config...[/cyan]", spinner="dots"):
                config = config_gen.update_config(config, feedback)
            _display_config(config)
        elif choice in ("r", "reject"):
            console.print("[red]Install cancelled.[/red]")
            raise SystemExit(0)

    # 6. Quality tier
    console.print("\n[bold]Quality tier[/bold] — how strict should TLM be?\n")
    console.print(
        "  [bold]HIGH[/bold]     — Block on any gap. Spec review required. Multi-model code review.\n"
        "  [bold]STANDARD[/bold] — Block on critical gaps. Spec review on blockers. Single-model review.\n"
        "  [bold]RELAXED[/bold]  — Warn only. No spec blocking. Mechanical checks only.\n"
    )

    tier_input = click.prompt(
        "Recommended: HIGH [Enter to accept, or type standard/relaxed]",
        default="high",
        show_default=False,
    ).strip().lower()

    if tier_input not in ("high", "standard", "relaxed"):
        tier_input = "high"

    installer.save_quality_tier(tier_input)
    console.print(f"  [green]✓[/green] Quality tier: [bold]{tier_input}[/bold]")

    # 7. Gap extraction + population
    recommendations = result.get("recommendations", [])

    # Also extract gaps from profile if available
    profile_path = Path(path) / ".tlm" / "profile.md"
    if profile_path.exists():
        try:
            profile_gaps = extract_gaps_from_profile(profile_path.read_text())
            for pg in profile_gaps:
                if not any(r["id"] == pg["id"] for r in recommendations):
                    recommendations.append(pg)
        except OSError:
            pass

    if recommendations:
        console.print(f"\n[yellow]⚠[/yellow] [bold]{len(recommendations)} gap(s) found[/bold]")

        table = Table()
        table.add_column("Severity", style="bold")
        table.add_column("Category")
        table.add_column("Description")

        severity_colors = {
            "critical": "red",
            "high": "yellow",
            "medium": "blue",
            "low": "dim",
        }

        for rec in recommendations:
            sev = rec.get("severity", "medium")
            color = severity_colors.get(sev, "white")
            table.add_row(
                f"[{color}]{sev}[/{color}]",
                rec.get("category", ""),
                rec.get("description", ""),
            )

        console.print(table)
        installer.populate_gaps(recommendations)
    else:
        console.print("\n[green]✓ No gaps detected![/green]")

    # 8. Full install — rules, hooks, hook scripts, git hooks, finalize
    installer.install_full()
    console.print("  [green]✓[/green] Rules, hooks, and git hooks installed")

    # 9. Final message
    console.print("\n[green bold]✓ TLM installed![/green bold]")
    console.print("\n[bold]Next step:[/bold] restart Claude Code so hooks take effect.")
    console.print("[dim]  Press [bold]q[/bold] or [bold]Ctrl+C[/bold] to exit, then:[/dim]")
    console.print("[dim]  • [bold]claude[/bold]                        → start fresh[/dim]")
    console.print("[dim]  • [bold]claude --continue[/bold]             → resume last conversation[/dim]")
    console.print("[dim]  • [bold]claude --resume <session_id>[/bold]  → resume a specific session[/dim]")


# ── Fix ──────────────────────────────────────────────────────

@main.command()
@click.argument("gap_id", required=False, default=None)
@click.option("--path", default=".", help="Project root path")
@click.option("--skip-review", is_flag=True, help="Skip server review step")
@_handle_api_errors
def fix(gap_id: str, path: str, skip_review: bool):
    """Fix a project gap: interview → plan → execute → review."""
    api_key = get_api_key()
    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    active = get_active_gaps(path)
    if not active:
        console.print("[green]No active gaps to fix.[/green]")
        return

    # Gap selection
    if gap_id:
        gap = get_gap_by_id(path, gap_id)
        if not gap:
            console.print(f"[red]Gap '{gap_id}' not found.[/red]")
            raise SystemExit(1)
    else:
        console.print("[bold]Active gaps:[/bold]")
        for i, g in enumerate(active, 1):
            console.print(f"  {i}. [{g['severity']}] {g['id']} — {g['description']}")

        choice = click.prompt("Select gap to fix", type=int)
        if choice < 1 or choice > len(active):
            console.print("[red]Invalid selection.[/red]")
            raise SystemExit(1)
        gap = active[choice - 1]
        gap_id = gap["id"]

    server_url = get_server_url()
    config = load_project_config(path)
    project_id = config.get("project_id")
    quality_tier = config.get("quality_tier", "high")
    project_state = read_state(path)

    client = TLMClient(server_url=server_url, api_key=api_key)

    # Phase 1: Interview
    write_state(path, {"phase": "tlm_active", "activity_type": "gap_fix"})
    console.print(f"\n[bold]Fixing gap: {gap_id}[/bold]")

    interview_data = (
        client.get_interview(project_id, gap_id, project_state, quality_tier)
    )

    intro = interview_data.get("intro", "")
    questions = interview_data.get("questions", [])

    if intro:
        console.print(f"\n{intro}\n")

    interviewer = Interviewer(questions)
    answers = interviewer.run()

    # Phase 2: Build context
    context = (
        client.build_context(project_id, gap_id, answers, project_state, quality_tier)
    )

    system_prompt = context.get("system_prompt", "")
    instructions = context.get("instructions", "")

    # Phase 3: Plan + Execute
    set_phase(path, "implementation")

    executor = Executor()
    plan_output = executor.plan(system_prompt, instructions)

    console.print("\n[bold]Plan:[/bold]")
    console.print(plan_output)

    approve = click.prompt("\nApprove this plan? [y/n]", default="y").strip().lower()
    if approve != "y":
        set_phase(path, "idle")
        console.print("[yellow]Plan rejected. Gap not fixed.[/yellow]")
        return

    execution_output = executor.execute(plan_output)
    console.print("\n[bold]Execution complete.[/bold]")

    # Phase 4: Review
    if not skip_review:
        review = (
            client.review_plan(project_id, gap_id, plan_output, project_state, quality_tier)
        )

        verdict = review.get("verdict", "unknown")
        feedback = review.get("feedback", "")

        console.print(f"\n[bold]Review verdict: {verdict}[/bold]")
        if feedback:
            console.print(f"Feedback: {feedback}")

        if verdict in ("pass", "warn"):
            update_gap_status(path, gap_id, GapStatus.RESOLVED)
            console.print(f"[green]Gap '{gap_id}' resolved.[/green]")
        else:
            console.print(f"[yellow]Gap '{gap_id}' not resolved — review failed.[/yellow]")
    else:
        update_gap_status(path, gap_id, GapStatus.RESOLVED)
        console.print(f"[green]Gap '{gap_id}' resolved (review skipped).[/green]")

    set_phase(path, "idle")


# ── Scan ──────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
@_handle_api_errors
def scan(path: str):
    """Re-scan project and show updated recommendations."""
    server_url = get_server_url()
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    installer = Installer(path, server_url=server_url, api_key=api_key)
    installer.init_project_dir()
    installer.ensure_project()

    scan_data = installer.scan_project()
    result = installer.assess(scan_data)

    recommendations = result.get("recommendations", [])
    if not recommendations:
        console.print("[green]No issues found![/green]")
        return

    table = Table(title="Project Recommendations")
    table.add_column("ID", style="cyan")
    table.add_column("Category", style="white")
    table.add_column("Severity", style="bold")
    table.add_column("Description")

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "blue",
        "low": "dim",
    }

    for rec in recommendations:
        sev = rec["severity"]
        color = severity_colors.get(sev, "white")
        table.add_row(
            rec["id"],
            rec["category"],
            f"[{color}]{sev}[/{color}]",
            rec["description"],
        )

    console.print(table)


# ── Gaps ──────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
def gaps(path: str):
    """Show active project gaps and their severity."""
    active = get_active_gaps(path)

    if not active:
        console.print("[green]No active gaps. Project is clean.[/green]")
        return

    table = Table(title=f"Active Gaps ({len(active)})")
    table.add_column("ID", style="cyan")
    table.add_column("Severity", style="bold")
    table.add_column("Category")
    table.add_column("Description")
    table.add_column("Status")

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "blue",
        "low": "dim",
    }

    for gap in active:
        sev = gap["severity"]
        color = severity_colors.get(sev, "white")
        table.add_row(
            gap["id"],
            f"[{color}]{sev}[/{color}]",
            gap.get("category", ""),
            gap["description"],
            gap["status"],
        )

    console.print(table)


# ── Review ───────────────────────────────────────────────────

@main.group(invoke_without_command=True)
@click.option("--show-last", is_flag=True, default=False, help="Display cached last review result")
@click.option("--path", default=".", help="Project root path")
@click.pass_context
def review(ctx, show_last: bool, path: str):
    """Review specs or staged code against TLM server."""
    ctx.ensure_object(dict)
    ctx.obj["path"] = path

    if not show_last and ctx.invoked_subcommand is not None:
        return

    if show_last:
        cache_file = Path(path) / ".tlm" / "cache" / "last_review.json"
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text())
                severity = data.get("severity", data.get("combined_verdict", "unknown"))
                console.print(f"[bold]Last review result:[/bold] {severity}")

                gaps = data.get("gaps", [])
                if gaps:
                    console.print(f"\nGaps ({len(gaps)}):")
                    for gap in gaps:
                        console.print(f"  [{gap.get('severity', 'medium')}] {gap.get('description', '')}")

                issues = data.get("issues", [])
                if issues:
                    console.print(f"\nIssues ({len(issues)}):")
                    for issue in issues:
                        console.print(f"  [{issue.get('severity', 'medium')}] {issue.get('description', '')}")

                questions = data.get("follow_up_questions", [])
                if questions:
                    console.print("\nFollow-up questions:")
                    for q in questions:
                        console.print(f"  - {q}")
            except (json.JSONDecodeError, OSError):
                console.print("[red]Cannot read cached review.[/red]")
        else:
            console.print("[dim]No cached review found. Run 'tlm review spec' or 'tlm review code' first.[/dim]")


@review.command(name="spec")
@click.argument("spec_path")
@click.option("--path", default=".", help="Project root path")
def review_spec(spec_path: str, path: str):
    """Review a spec/plan file. Pass the file path as argument."""
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    # Read spec
    try:
        spec_content = Path(spec_path).read_text()
    except OSError:
        console.print(f"[red]Cannot read spec: {spec_path}[/red]")
        raise SystemExit(1)

    # Load config
    config = load_project_config(path)
    project_id = config.get("project_id", 0)
    quality = config.get("quality_control", "standard")

    # Read knowledge
    knowledge = ""
    knowledge_path = Path(path) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    # Call server
    server_url = get_server_url()
    client = TLMClient(server_url=server_url, api_key=api_key)

    console.print("[dim]Reviewing spec...[/dim]")
    try:
        result = (client.review_spec(
            project_id=project_id,
            spec=spec_content,
            project_knowledge=knowledge,
            quality_level=quality,
        ))
    except Exception as e:
        console.print(f"[red]Review failed: {e}[/red]")
        raise SystemExit(1)

    # Cache result
    cache_dir = Path(path) / ".tlm" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / "last_review.json").write_text(json.dumps(result, indent=2))

    # Display
    severity = result.get("severity", "unknown")
    severity_colors = {"pass": "green", "warn": "yellow", "fail": "red"}
    color = severity_colors.get(severity, "white")
    console.print(f"\n[bold]Spec Review: [{color}]{severity.upper()}[/{color}][/bold]")

    gaps = result.get("gaps", [])
    if gaps:
        table = Table(title=f"Gaps ({len(gaps)})")
        table.add_column("Severity", style="bold")
        table.add_column("Description")
        for gap in gaps:
            table.add_row(gap.get("severity", "medium"), gap.get("description", ""))
        console.print(table)

    questions = result.get("follow_up_questions", [])
    if questions:
        console.print("\n[bold]Follow-up questions:[/bold]")
        for q in questions:
            console.print(f"  - {q}")


@review.command(name="code")
@click.argument("commit", required=False, default=None)
@click.option("--path", default=".", help="Project root path")
def review_code(commit: str, path: str):
    """Review staged changes or a specific commit against the active spec."""
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    # Get git diff
    try:
        if commit:
            diff_cmd = ["git", "diff", f"{commit}~1", commit]
            names_cmd = ["git", "diff", f"{commit}~1", commit, "--name-only"]
        else:
            diff_cmd = ["git", "diff", "--cached"]
            names_cmd = ["git", "diff", "--cached", "--name-only"]

        diff_result = subprocess.run(
            diff_cmd,
            capture_output=True, text=True, cwd=path, timeout=10,
        )
        names_result = subprocess.run(
            names_cmd,
            capture_output=True, text=True, cwd=path, timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        console.print(f"[red]git diff failed: {e}[/red]")
        raise SystemExit(1)

    diff_text = diff_result.stdout.strip()
    files_changed = [f for f in names_result.stdout.strip().split("\n") if f]

    if not diff_text:
        if commit:
            console.print(f"[yellow]No changes in commit {commit}.[/yellow]")
        else:
            console.print("[yellow]No staged changes to review. Stage changes with 'git add' first.[/yellow]")
        raise SystemExit(1)

    # Load active spec
    state = read_state(path)
    active_spec = state.get("active_spec")
    spec_content = ""
    if active_spec:
        try:
            spec_content = Path(active_spec).read_text()
        except OSError:
            pass

    if not spec_content:
        console.print("[yellow]No active spec found. Run 'tlm review spec' first.[/yellow]")
        raise SystemExit(1)

    # Read knowledge
    knowledge = ""
    knowledge_path = Path(path) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    config = load_project_config(path)
    project_id = config.get("project_id", 0)

    server_url = get_server_url()
    client = TLMClient(server_url=server_url, api_key=api_key)

    console.print(f"[dim]Reviewing {len(files_changed)} changed file(s)...[/dim]")
    try:
        result = (client.review_code(
            project_id=project_id,
            spec=spec_content,
            code=diff_text,
            files_changed=files_changed,
            project_knowledge=knowledge,
        ))
    except Exception as e:
        console.print(f"[red]Code review failed: {e}[/red]")
        raise SystemExit(1)

    # Cache result
    cache_dir = Path(path) / ".tlm" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / "last_review.json").write_text(json.dumps(result, indent=2))

    # Display
    verdict = result.get("combined_verdict", "unknown")
    verdict_colors = {"pass": "green", "warn": "yellow", "fail": "red"}
    color = verdict_colors.get(verdict, "white")
    console.print(f"\n[bold]Code Review: [{color}]{verdict.upper()}[/{color}][/bold]")

    issues = result.get("issues", [])
    if issues:
        table = Table(title=f"Issues ({len(issues)})")
        table.add_column("Severity", style="bold")
        table.add_column("Description")
        for issue in issues:
            table.add_row(issue.get("severity", "medium"), issue.get("description", ""))
        console.print(table)

    reviews = result.get("reviews", [])
    if reviews:
        console.print("\n[bold]Model reviews:[/bold]")
        for r in reviews:
            console.print(f"  {r.get('model', 'unknown')}: {r.get('verdict', 'unknown')}")


# ── Logout ────────────────────────────────────────────────────

@main.command()
def logout():
    """Remove stored TLM credentials."""
    creds_file = Path.home() / ".tlm" / "credentials.json"
    if creds_file.exists():
        creds_file.unlink()
        console.print("[green]Credentials removed.[/green]")
    else:
        console.print("[dim]No credentials found.[/dim]")


# ── Uninstall ─────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def uninstall(path: str, yes: bool):
    """Remove TLM from this project (config, hooks, rules)."""
    tlm_dir = Path(path) / ".tlm"
    if not tlm_dir.exists():
        console.print("[dim]TLM is not installed in this project.[/dim]")
        return

    if not yes:
        warning = Text()
        warning.append("WARNING: This will permanently remove:\n\n", style="bold red")
        warning.append("  - .tlm/ directory (config, specs, gaps, enforcement)\n")
        warning.append("  - .claude/settings.json hook entries\n")
        warning.append("  - .claude/hooks/tlm-* wrapper scripts\n")
        warning.append("  - .claude/rules/tlm-*.md rule files\n")
        warning.append("  - .git/hooks/post-commit (TLM learner)\n")
        warning.append("  - CLAUDE.md TLM section (if present)\n\n")
        warning.append("This cannot be undone. You will need to run 'tlm install' again.", style="dim")
        console.print(Panel(warning, border_style="red", title="[red bold]Uninstall TLM[/red bold]"))

        confirm = click.prompt(
            'Type "UNINSTALL" to confirm',
            default="",
            show_default=False,
        ).strip()
        if confirm != "UNINSTALL":
            console.print("[dim]Cancelled.[/dim]")
            return

    installer = Installer(path)
    installer.uninstall()

    console.print("  [green]✓[/green] Hook entries removed from .claude/settings.json")
    console.print("  [green]✓[/green] Hook scripts removed")
    console.print("  [green]✓[/green] Rule files removed")
    console.print("  [green]✓[/green] Git hooks removed")
    console.print("  [green]✓[/green] .tlm/ directory removed")
    console.print("\n[green bold]TLM fully removed.[/green bold]")
    console.print("[dim]To reinstall: tlm install[/dim]")


# ── Status ────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
def status(path: str):
    """Show TLM project status: config, gaps, enforcement."""
    tlm_dir = Path(path) / ".tlm"

    if not tlm_dir.exists():
        console.print("[yellow]TLM not installed in this project. Run 'tlm install' first.[/yellow]")
        return

    config = load_project_config(path)
    state = read_state(path)

    table = Table(title="TLM Status")
    table.add_column("Property", style="bold")
    table.add_column("Value")

    table.add_row("Project", config.get("project_name", Path(path).resolve().name))
    table.add_row("Phase", state.get("phase", "unknown"))
    table.add_row("Quality Tier", config.get("quality_control", "not set"))
    table.add_row("Project ID", str(config.get("project_id", "not set")))

    # Gaps
    active = get_active_gaps(path)
    table.add_row("Active Gaps", str(len(active)))

    # Specs
    specs_dir = tlm_dir / "specs"
    spec_count = len(list(specs_dir.glob("*.md"))) if specs_dir.exists() else 0
    table.add_row("Specs", str(spec_count))

    # Enforcement
    enforcement = tlm_dir / "enforcement.json"
    if enforcement.exists():
        try:
            ec = json.loads(enforcement.read_text())
            table.add_row("Enforcement", "approved" if ec.get("approved") else "draft")
        except json.JSONDecodeError:
            table.add_row("Enforcement", "invalid")
    else:
        table.add_row("Enforcement", "not configured")

    console.print(table)


# ── Upgrade ───────────────────────────────────────────────────

@main.command()
def upgrade():
    """Upgrade TLM CLI to the latest version via pipx or pip."""
    import subprocess as sp
    console.print("[dim]Upgrading tlm-cli...[/dim]")
    try:
        result = sp.run(
            ["pipx", "upgrade", "tlm-cli"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            console.print(f"[green]{result.stdout.strip()}[/green]")
        else:
            # Try pip as fallback
            result = sp.run(
                ["pip", "install", "--upgrade", "tlm-cli"],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0:
                console.print("[green]Upgraded successfully.[/green]")
            else:
                console.print(f"[red]Upgrade failed: {result.stderr.strip()}[/red]")
    except FileNotFoundError:
        console.print("[red]Neither pipx nor pip found. Install manually.[/red]")
    except sp.TimeoutExpired:
        console.print("[red]Upgrade timed out.[/red]")


# ── Hook dispatch ─────────────────────────────────────────────

@main.command(name="_hook", hidden=True)
@click.argument("hook_name")
@click.option("--path", default=".", help="Project root path")
def hook_dispatch(hook_name: str, path: str):
    """Internal: dispatch to hook handlers. Called by Claude Code hooks."""
    if hook_name == "session_start":
        result = hook_session_start(path)
        # session_start returns a string, print it directly
        print(result)

    elif hook_name == "prompt_submit":
        # Read prompt from stdin if available
        prompt_text = ""
        if not sys.stdin.isatty():
            try:
                data = json.loads(sys.stdin.read())
                prompt_text = data.get("prompt", "")
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_prompt_submit(path, prompt_text)
        print(json.dumps(result))

    elif hook_name == "guard":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_guard(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "compliance":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_compliance_gate(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "deployment":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_deployment_gate(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "plan_approved":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_plan_approved(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "spec_review":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_spec_review(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "stop":
        result = hook_stop(path)
        print(json.dumps(result))

    else:
        console.print(f"[red]Unknown hook: {hook_name}[/red]")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
