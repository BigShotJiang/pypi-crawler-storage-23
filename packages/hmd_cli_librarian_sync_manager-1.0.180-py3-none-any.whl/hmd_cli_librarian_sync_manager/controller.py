import logging
import os
from datetime import datetime, timedelta
from importlib.metadata import version
from pathlib import Path

from cement import CaughtSignal, Controller, ex
from dotenv import load_dotenv
from hmd_cli_tools.hmd_cli_tools import get_env_var

from .log import build_dd_sender, get_dd_tags, setup_root_logger

VERSION_BANNER = """
hmd librarian-sync-manager version: {}
"""


class LocalController(Controller):
    class Meta:
        label = "librarian_sync_manager"
        stacked_type = "nested"
        stacked_on = "base"

        # text displayed at the top of --help output
        description = "Sync local files with librarian"

        arguments = (
            (
                ["-v", "--version"],
                {
                    "help": "display the version of the librarian-sync-manager command.",
                    "action": "version",
                    "version": VERSION_BANNER.format(
                        version("hmd_cli_librarian_sync_manager")
                    ),
                },
            ),
        )

    def _default(self):
        """Default action if no sub-command is passed."""
        self.app.args.print_help()

    @ex(
        help="read local sqlite database and push files to librarian",
        arguments=[
            (
                ["--config-file"],
                {"action": "store", "dest": "config_file", "required": False},
            )
        ],
    )
    def sync(self):
        hmd_home = Path(os.path.expandvars(get_env_var("HMD_HOME")))
        config_path_default = hmd_home / ".config" / "librarian-sync.json"
        log_file_path = hmd_home / "log" / "librarian-sync-manager.log"
        log_level = logging.INFO
        if self.app.pargs.debug:
            log_level = logging.DEBUG
        setup_root_logger(log_file_path, log_level)

        logger = logging.getLogger(__name__)

        send_datadog_event = build_dd_sender(logger)
        from .hmd_cli_librarian_sync_manager import LibrarianSyncManager

        try:
            env_path = hmd_home / ".config" / "hmd.env"
            if Path(env_path).exists():
                load_dotenv(dotenv_path=Path(env_path), override=True)
            config_path = os.environ.get("HMD_LIBRARIAN_SYNC_MANAGER_CONFIG")
            if not config_path:
                config_path = (
                    Path(self.app.pargs.config_file)
                    if self.app.pargs.config_file is not None
                    else config_path_default
                )
            logger.info(f"config: {config_path}")
            manager = LibrarianSyncManager(config_path)
            manager.sync()
        except CaughtSignal as cs:
            logger.error("Caught signal", exc_info=cs)
            send_datadog_event(
                event_type="error",
                data="Librarian Sync Manager caught signal during sync",
                ex=str(cs),
                tags=get_dd_tags(),
            )
        except BaseException as e:
            logger.error("Execution failed", exc_info=e)
            send_datadog_event(
                event_type="error",
                data="Librarian Sync Manager failed during sync",
                ex=str(e),
                tags=get_dd_tags(),
            )
        logger.info("exiting")

    @ex(
        help="watch the local sqlite database and push files to librarian",
        arguments=[
            (
                ["--config-file"],
                {"action": "store", "dest": "config_file", "required": False},
            )
        ],
    )
    def watch(self):
        hmd_home = Path(os.path.expandvars(get_env_var("HMD_HOME")))
        log_file_path = hmd_home / "log" / "librarian-sync-manager.log"
        log_level = logging.INFO
        if self.app.pargs.debug:
            log_level = logging.DEBUG
        setup_root_logger(log_file_path, log_level)

        logger = logging.getLogger(__name__)
        send_datadog_event = build_dd_sender(logger)
        from .hmd_cli_librarian_sync_manager import LibrarianSyncManager

        manager = None
        try:
            hmd_home = Path(os.path.expandvars(get_env_var("HMD_HOME")))
            env_path = hmd_home / ".config" / "hmd.env"
            if Path(env_path).exists():
                load_dotenv(dotenv_path=Path(env_path), override=True)
            config_path_default = hmd_home / ".config" / "librarian-sync.json"
            config_path = os.environ.get("HMD_LIBRARIAN_SYNC_MANAGER_CONFIG")
            logger.info(f"config path: {config_path}")
            if not config_path:
                config_path = (
                    Path(self.app.pargs.config_file)
                    if self.app.pargs.config_file is not None
                    else config_path_default
                )
            manager = LibrarianSyncManager(config_path)
            manager.start()
        except CaughtSignal as cs:
            logger.error("Caught signal", exc_info=cs)
            send_datadog_event(
                event_type="error",
                data="Librarian Sync Manager caught signal during watch",
                ex=str(cs),
                tags=get_dd_tags(),
            )
            if manager:
                manager.stop()
        except BaseException as e:
            logger.error("Execution failed", exc_info=e)
            send_datadog_event(
                event_type="error",
                data="Librarian Sync Manager failed during watch",
                ex=str(e),
                tags=get_dd_tags(),
            )
            if manager:
                manager.stop()
        logger.info("exiting")

    @ex(
        help="query recent file upload activity and status",
        arguments=[
            (
                ["--config-file"],
                {"action": "store", "dest": "config_file", "required": False},
            ),
            (
                ["--start-date"],
                {
                    "action": "store",
                    "dest": "start_date",
                    "required": False,
                    "help": "Start date for the query (YYYY-MM-DD format). Defaults to 7 days ago.",
                },
            ),
            (
                ["--end-date"],
                {
                    "action": "store",
                    "dest": "end_date",
                    "required": False,
                    "help": "End date for the query (YYYY-MM-DD format). Defaults to now.",
                },
            ),
            (
                ["--status"],
                {
                    "action": "store",
                    "dest": "upload_status",
                    "required": False,
                    "choices": [
                        "pending",
                        "success",
                        "failed",
                    ],
                    "help": "Filter by file status (pending=awaiting upload, success=uploaded, failed=upload failed).",
                },
            ),
            (
                ["--limit"],
                {
                    "action": "store",
                    "dest": "limit",
                    "type": int,
                    "default": 100,
                    "required": False,
                    "help": "Maximum number of results to return. Defaults to 100.",
                },
            ),
            (
                ["--format"],
                {
                    "action": "store",
                    "dest": "output_format",
                    "choices": ["table", "json"],
                    "default": "table",
                    "required": False,
                    "help": "Output format (table or json). Defaults to table.",
                },
            ),
            (
                ["--path"],
                {
                    "action": "store",
                    "dest": "file_path",
                    "required": False,
                    "help": "Filter by file path (substring match). Filters uploads by the related File's path.",
                },
            ),
        ],
    )
    def status(self):
        """Query recent file upload activity and display status."""
        import json
        from hmd_entity_storage import SqliteEngine
        from hmd_graphql_client.hmd_db_engine_client import DbEngineClient
        from hmd_lang_librarian_sync.hmd_lang_librarian_sync_client import (
            HmdLangLibrarianSyncClient,
            get_client_schema_root,
        )
        from hmd_schema_loader import DefaultLoader

        hmd_home = Path(os.path.expandvars(get_env_var("HMD_HOME")))
        config_path_default = hmd_home / ".config" / "librarian-sync.json"
        log_file_path = hmd_home / "log" / "librarian-sync-manager.log"
        log_level = logging.INFO
        if self.app.pargs.debug:
            log_level = logging.DEBUG
        setup_root_logger(log_file_path, log_level)

        logger = logging.getLogger(__name__)

        try:
            env_path = hmd_home / ".config" / "hmd.env"
            if Path(env_path).exists():
                load_dotenv(dotenv_path=Path(env_path), override=True)

            config_path = os.environ.get("HMD_LIBRARIAN_SYNC_MANAGER_CONFIG")
            if not config_path:
                config_path = (
                    Path(self.app.pargs.config_file)
                    if self.app.pargs.config_file is not None
                    else config_path_default
                )

            from .config.validate_config import load_and_validate_config

            load_and_validate_config(config_path, True)
            config = load_and_validate_config(config_path, False)

            # Parse date arguments
            end_date = datetime.now()
            start_date = end_date - timedelta(days=7)

            if self.app.pargs.start_date:
                try:
                    start_date = datetime.strptime(
                        self.app.pargs.start_date, "%Y-%m-%d"
                    )
                except ValueError:
                    print(
                        f"Invalid start date format: {self.app.pargs.start_date}. Use YYYY-MM-DD."
                    )
                    return

            if self.app.pargs.end_date:
                try:
                    end_date = datetime.strptime(self.app.pargs.end_date, "%Y-%m-%d")
                    # Set to end of day
                    end_date = end_date.replace(hour=23, minute=59, second=59)
                except ValueError:
                    print(
                        f"Invalid end date format: {self.app.pargs.end_date}. Use YYYY-MM-DD."
                    )
                    return

            # Convert to timestamps
            start_timestamp = int(start_date.timestamp())
            end_timestamp = int(end_date.timestamp())

            # Initialize database connection
            db_location = Path(
                os.path.expandvars(config.get("db_location", "$HMD_HOME/sqlite/data/"))
            )
            db_file = db_location / "librarian-sync.db"

            if not db_file.exists():
                print(f"Database file not found: {db_file}")
                return

            schema_loader = DefaultLoader(str(get_client_schema_root()))
            db_engine = SqliteEngine(db_file)
            db_client = DbEngineClient(db_engine, schema_loader)
            librarian_sync_client = HmdLangLibrarianSyncClient(db_client)

            # Build query for File entities based on status and date range
            query = self._build_file_status_query(
                status_filter=self.app.pargs.upload_status,
                start_timestamp=start_timestamp,
                end_timestamp=end_timestamp,
            )

            # Execute query
            if query:
                files = librarian_sync_client.search_file_hmd_lang_librarian_sync(query)
            else:
                # Get all files if no filters
                files = librarian_sync_client.search_file_hmd_lang_librarian_sync({})

            # Filter by path if specified
            if self.app.pargs.file_path:
                path_filter = self.app.pargs.file_path.lower()
                files = [f for f in files if f.path and path_filter in f.path.lower()]

            # Sort by modified timestamp descending (most recent first)
            files = sorted(files, key=lambda f: f.modified or 0, reverse=True)

            # Apply limit
            limit = self.app.pargs.limit
            files = files[:limit]

            if not files:
                status_msg = (
                    f" with status '{self.app.pargs.upload_status}'"
                    if self.app.pargs.upload_status
                    else ""
                )
                date_msg = f" between {start_date.strftime('%Y-%m-%d')} and {end_date.strftime('%Y-%m-%d')}"
                print(f"No files found{status_msg}{date_msg}")
                return

            # Enrich files with upload details
            file_data = []
            for f in files:
                upload_details = self._get_file_upload_details(f, librarian_sync_client)

                # Determine status string from schedule_upload value
                if f.schedule_upload is None or f.schedule_upload < 1:
                    status_str = "pending"
                elif f.schedule_upload == 1:
                    status_str = "success"
                elif f.schedule_upload == 2:
                    status_str = "failed"
                else:
                    status_str = "unknown"

                file_data.append(
                    {
                        "file": f,
                        "status": status_str,
                        "upload_count": upload_details["upload_count"],
                        "file_size": upload_details["file_size"],
                        "error_message": upload_details["error_message"],
                        "latest_upload": upload_details["latest_upload"],
                    }
                )

            # Calculate summary statistics
            status_counts = {}
            total_size = 0
            for item in file_data:
                status = item["status"]
                status_counts[status] = status_counts.get(status, 0) + 1
                if item["file_size"]:
                    total_size += item["file_size"]

            if self.app.pargs.output_format == "json":
                # JSON output
                output = {
                    "query": {
                        "start_date": start_date.isoformat(),
                        "end_date": end_date.isoformat(),
                        "status_filter": self.app.pargs.upload_status,
                        "path_filter": self.app.pargs.file_path,
                        "limit": limit,
                    },
                    "summary": {
                        "total_files": len(file_data),
                        "total_size_bytes": total_size,
                        "status_counts": status_counts,
                    },
                    "files": [
                        {
                            "identifier": item["file"].identifier,
                            "path": item["file"].path,
                            "status": item["status"],
                            "file_size": item["file_size"],
                            "upload_attempts": item["upload_count"],
                            "modified": (
                                datetime.fromtimestamp(
                                    item["file"].modified
                                ).isoformat()
                                if item["file"].modified
                                else None
                            ),
                            "error_message": item["error_message"],
                        }
                        for item in file_data
                    ],
                }
                print(json.dumps(output, indent=2))
            else:
                # Table output
                date_range_str = f": {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}"

                print(f"\nFile Status{date_range_str}")
                print("=" * 200)

                # Summary
                print(f"\nSummary:")
                print(f"  Total files: {len(file_data)}")
                print(f"  Total size: {self._format_size(total_size)}")
                print(f"  Status breakdown:")
                for status, count in sorted(status_counts.items()):
                    print(f"    - {status}: {count}")

                # Details
                print(f"\nFiles (showing {len(file_data)} of {limit} max):")
                print("-" * 200)
                print(
                    f"{'Status':<10} {'Size':>10} {'Attempts':>10} {'Modified':<20} {'File Path'}"
                )
                print("-" * 200)

                for item in file_data:
                    status = item["status"]
                    size = (
                        self._format_size(item["file_size"])
                        if item["file_size"]
                        else "N/A"
                    )
                    attempts = (
                        str(item["upload_count"]) if item["upload_count"] > 0 else "0"
                    )
                    modified = (
                        datetime.fromtimestamp(item["file"].modified).strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )
                        if item["file"].modified
                        else "N/A"
                    )
                    file_path = item["file"].path or "N/A"

                    print(
                        f"{status:<10} {size:>10} {attempts:>10} {modified:<20} {file_path}"
                    )

                print("-" * 200)

        except Exception as e:
            logger.error("Failed to query upload status", exc_info=e)
            print(f"Error: {e}")

    def _format_size(self, size_bytes):
        """Format bytes to human-readable size."""
        if size_bytes is None:
            return "N/A"
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if abs(size_bytes) < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} PB"

    def _get_process_memory(self, process_name: str):
        """Find running librarian-sync process and return memory usage.

        Args:
            process_name: Either 'librarian-sync-manager' or 'librarian-sync-watcher'

        Returns:
            dict with pid, rss_bytes or None if not running
        """
        import psutil

        for proc in psutil.process_iter(["pid", "cmdline", "memory_info"]):
            try:
                cmdline = proc.info.get("cmdline") or []
                cmdline_str = " ".join(cmdline)
                if process_name in cmdline_str:
                    mem_info = proc.info.get("memory_info")
                    if mem_info:
                        return {
                            "pid": proc.info["pid"],
                            "rss_bytes": mem_info.rss,
                        }
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return None

    def _aggregate_errors(self, failed_uploads):
        """Aggregate error messages by frequency.

        Args:
            failed_uploads: List of FileUpload objects with complete_failed status

        Returns:
            List of tuples (count, error_message) sorted by count descending
        """
        from collections import Counter

        error_counts = Counter()
        for upload in failed_uploads:
            error_msg = upload.error_message or "Unknown error"
            error_counts[error_msg] += 1

        return sorted(error_counts.items(), key=lambda x: x[1], reverse=True)

    def _get_file_upload_details(self, file, librarian_sync_client):
        """Get upload details for a File by traversing FileToUpload relationships.

        Args:
            file: File entity
            librarian_sync_client: HmdLangLibrarianSyncClient instance

        Returns:
            dict with keys:
                - upload_count: int - number of FileUpload records
                - file_size: int or None - size from most recent FileUpload
                - latest_upload: FileUpload or None - most recent upload record
                - error_message: str or None - error from latest failed upload
        """
        try:
            file_to_uploads = (
                librarian_sync_client.get_from_file_to_upload_hmd_lang_librarian_sync(
                    file
                )
            )

            if not file_to_uploads:
                return {
                    "upload_count": 0,
                    "file_size": None,
                    "latest_upload": None,
                    "error_message": None,
                }

            # Get all FileUpload entities
            uploads = []
            for ftu in file_to_uploads:
                try:
                    upload = (
                        librarian_sync_client.get_file_upload_hmd_lang_librarian_sync(
                            ftu.ref_to
                        )
                    )
                    if upload:
                        uploads.append(upload)
                except Exception:
                    pass

            if not uploads:
                return {
                    "upload_count": 0,
                    "file_size": None,
                    "latest_upload": None,
                    "error_message": None,
                }

            # Sort by librarian_put_timestamp descending to get most recent
            sorted_uploads = sorted(
                uploads,
                key=lambda u: u.librarian_put_timestamp or 0,
                reverse=True,
            )

            latest_upload = sorted_uploads[0]

            error_message = None
            for upload in sorted_uploads:
                if upload.upload_status == "complete_failed" and upload.error_message:
                    error_message = upload.error_message
                    break

            return {
                "upload_count": len(uploads),
                "file_size": latest_upload.file_size,
                "latest_upload": latest_upload,
                "error_message": error_message,
            }
        except Exception:
            return {
                "upload_count": 0,
                "file_size": None,
                "latest_upload": None,
                "error_message": None,
            }

    def _build_file_status_query(
        self, status_filter, start_timestamp=None, end_timestamp=None
    ):
        """Build a query for File entities based on status and date range.

        Args:
            status_filter: str - "pending", "success", "failed", or None for all
            start_timestamp: int or None - filter by File.modified >= this value
            end_timestamp: int or None - filter by File.modified <= this value

        Returns:
            dict - query suitable for search_file_hmd_lang_librarian_sync
        """
        conditions = []

        # Status mapping: schedule_upload values
        # <1 (typically 0 or None) = pending
        # 1 = success (completed)
        # 2 = failed
        if status_filter == "pending":
            conditions.append(
                {
                    "attribute": "schedule_upload",
                    "operator": "<",
                    "value": 1,
                }
            )
        elif status_filter == "success":
            conditions.append(
                {
                    "attribute": "schedule_upload",
                    "operator": "=",
                    "value": 1,
                }
            )
        elif status_filter == "failed":
            conditions.append(
                {
                    "attribute": "schedule_upload",
                    "operator": "=",
                    "value": 2,
                }
            )

        # Add date range filters based on File.modified
        if start_timestamp:
            conditions.append(
                {
                    "attribute": "modified",
                    "operator": ">=",
                    "value": start_timestamp,
                }
            )

        if end_timestamp:
            conditions.append(
                {
                    "attribute": "modified",
                    "operator": "<=",
                    "value": end_timestamp,
                }
            )

        if len(conditions) == 0:
            return None  # Return all files
        elif len(conditions) == 1:
            return conditions[0]
        else:
            return {"and": conditions}

    @ex(
        help="generate a comprehensive report on upload health and system status",
        arguments=[
            (
                ["--config-file"],
                {"action": "store", "dest": "config_file", "required": False},
            ),
            (
                ["--days"],
                {
                    "action": "store",
                    "dest": "days",
                    "type": int,
                    "default": 7,
                    "required": False,
                    "help": "Number of days to look back for upload history. Defaults to 7.",
                },
            ),
            (
                ["--show-paths"],
                {
                    "action": "store_true",
                    "dest": "show_paths",
                    "default": False,
                    "help": "Show file paths in the report output.",
                },
            ),
            (
                ["--output"],
                {
                    "action": "store",
                    "dest": "output_file",
                    "required": False,
                    "help": "Save the report to the specified file path.",
                },
            ),
            (
                ["--format"],
                {
                    "action": "store",
                    "dest": "output_format",
                    "choices": ["table", "json"],
                    "default": "table",
                    "required": False,
                    "help": "Output format (table or json). Defaults to table.",
                },
            ),
            (
                ["--top-errors"],
                {
                    "action": "store",
                    "dest": "top_errors",
                    "type": int,
                    "default": 10,
                    "required": False,
                    "help": "Number of top errors to display. Defaults to 10.",
                },
            ),
        ],
    )
    def report(self):
        """Generate a comprehensive report on upload health and system status."""
        import json
        from collections import Counter

        from hmd_entity_storage import SqliteEngine
        from hmd_graphql_client.hmd_db_engine_client import DbEngineClient
        from hmd_lang_librarian_sync.hmd_lang_librarian_sync_client import (
            HmdLangLibrarianSyncClient,
            get_client_schema_root,
        )
        from hmd_schema_loader import DefaultLoader

        hmd_home = Path(os.path.expandvars(get_env_var("HMD_HOME")))
        config_path_default = hmd_home / ".config" / "librarian-sync.json"
        log_file_path = hmd_home / "log" / "librarian-sync-manager.log"
        log_level = logging.INFO
        if self.app.pargs.debug:
            log_level = logging.DEBUG
        setup_root_logger(log_file_path, log_level)

        logger = logging.getLogger(__name__)

        try:
            env_path = hmd_home / ".config" / "hmd.env"
            if Path(env_path).exists():
                load_dotenv(dotenv_path=Path(env_path), override=True)

            config_path = os.environ.get("HMD_LIBRARIAN_SYNC_MANAGER_CONFIG")
            if not config_path:
                config_path = (
                    Path(self.app.pargs.config_file)
                    if self.app.pargs.config_file is not None
                    else config_path_default
                )

            from .config.validate_config import load_and_validate_config

            load_and_validate_config(config_path, True)
            config = load_and_validate_config(config_path, False)

            # Calculate time range
            days = self.app.pargs.days
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            start_timestamp = int(start_date.timestamp())
            end_timestamp = int(end_date.timestamp())

            # Initialize database connection
            db_location = Path(
                os.path.expandvars(config.get("db_location", "$HMD_HOME/sqlite/data/"))
            )
            db_file = db_location / "librarian-sync.db"

            if not db_file.exists():
                print(f"Database file not found: {db_file}")
                return

            schema_loader = DefaultLoader(str(get_client_schema_root()))
            db_engine = SqliteEngine(db_file)
            db_client = DbEngineClient(db_engine, schema_loader)
            librarian_sync_client = HmdLangLibrarianSyncClient(db_client)

            # Gather system status
            manager_mem = self._get_process_memory("librarian-sync-manager")
            watcher_mem = self._get_process_memory("librarian-sync-watcher")
            db_size_bytes = db_file.stat().st_size

            # Query pending files (schedule_upload < 1, no date filter)
            pending_query = self._build_file_status_query(status_filter="pending")
            pending_files = librarian_sync_client.search_file_hmd_lang_librarian_sync(
                pending_query
            )

            # Query success files (schedule_upload = 1) in time range
            success_query = self._build_file_status_query(
                status_filter="success",
                start_timestamp=start_timestamp,
                end_timestamp=end_timestamp,
            )
            success_files = librarian_sync_client.search_file_hmd_lang_librarian_sync(
                success_query
            )

            # Query failed files (schedule_upload = 2) in time range
            failed_query = self._build_file_status_query(
                status_filter="failed",
                start_timestamp=start_timestamp,
                end_timestamp=end_timestamp,
            )
            failed_files = librarian_sync_client.search_file_hmd_lang_librarian_sync(
                failed_query
            )

            # Enrich files with upload details
            success_file_data = []
            total_completed_size = 0
            for f in success_files:
                details = self._get_file_upload_details(f, librarian_sync_client)
                success_file_data.append(
                    {
                        "file": f,
                        "upload_details": details,
                    }
                )
                if details["file_size"]:
                    total_completed_size += details["file_size"]

            failed_file_data = []
            for f in failed_files:
                details = self._get_file_upload_details(f, librarian_sync_client)
                failed_file_data.append(
                    {
                        "file": f,
                        "upload_details": details,
                    }
                )

            # Calculate statistics
            total_uploads = len(success_files) + len(failed_files)
            success_rate = (
                (len(success_files) / total_uploads * 100) if total_uploads > 0 else 0
            )
            files_per_day = len(success_files) / days if days > 0 else 0
            bytes_per_day = total_completed_size / days if days > 0 else 0

            # Aggregate errors from failed files' latest upload
            error_counts = Counter()
            for item in failed_file_data:
                error_msg = item["upload_details"]["error_message"] or "Unknown error"
                error_counts[error_msg] += 1
            top_errors = sorted(error_counts.items(), key=lambda x: x[1], reverse=True)
            top_errors = top_errors[: self.app.pargs.top_errors]

            # Build file path and details lists if needed
            pending_paths = []
            completed_paths = []
            failed_paths = []

            if self.app.pargs.show_paths:
                pending_paths = [f.path for f in pending_files]
                completed_paths = [item["file"].path for item in success_file_data]
                failed_paths = [item["file"].path for item in failed_file_data]

            # Generate output
            report_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if self.app.pargs.output_format == "json":
                output = {
                    "generated_at": report_time,
                    "time_range": {
                        "days": days,
                        "start_date": start_date.isoformat(),
                        "end_date": end_date.isoformat(),
                    },
                    "system_status": {
                        "sync_manager": {
                            "running": manager_mem is not None,
                            "pid": manager_mem["pid"] if manager_mem else None,
                            "memory_bytes": (
                                manager_mem["rss_bytes"] if manager_mem else None
                            ),
                        },
                        "sync_watcher": {
                            "running": watcher_mem is not None,
                            "pid": watcher_mem["pid"] if watcher_mem else None,
                            "memory_bytes": (
                                watcher_mem["rss_bytes"] if watcher_mem else None
                            ),
                        },
                        "database": {
                            "size_bytes": db_size_bytes,
                            "path": str(db_file),
                        },
                    },
                    "pending_uploads": {
                        "count": len(pending_files),
                        "paths": pending_paths if self.app.pargs.show_paths else None,
                    },
                    "completed_files": {
                        "count": len(success_files),
                        "total_size_bytes": total_completed_size,
                        "files_per_day": round(files_per_day, 1),
                        "bytes_per_day": round(bytes_per_day, 0),
                        "paths": completed_paths if self.app.pargs.show_paths else None,
                    },
                    "failed_files": {
                        "count": len(failed_files),
                        "top_errors": [
                            {"error": err, "count": cnt} for err, cnt in top_errors
                        ],
                        "paths": failed_paths if self.app.pargs.show_paths else None,
                    },
                    "summary": {
                        "total_files": total_uploads,
                        "success_rate_percent": round(success_rate, 1),
                    },
                }
                report_content = json.dumps(output, indent=2)
            else:
                # Table format
                lines = []
                lines.append("=" * 80)
                lines.append("               LIBRARIAN SYNC MANAGER REPORT")
                lines.append(f"               Generated: {report_time}")
                lines.append("=" * 80)
                lines.append("")

                # System Status
                lines.append("SYSTEM STATUS")
                lines.append("-" * 80)
                if manager_mem:
                    lines.append(
                        f"  Sync Manager:     Running (PID: {manager_mem['pid']}, "
                        f"Memory: {self._format_size(manager_mem['rss_bytes'])})"
                    )
                else:
                    lines.append("  Sync Manager:     Not running")

                if watcher_mem:
                    lines.append(
                        f"  Sync Watcher:     Running (PID: {watcher_mem['pid']}, "
                        f"Memory: {self._format_size(watcher_mem['rss_bytes'])})"
                    )
                else:
                    lines.append("  Sync Watcher:     Not running")

                lines.append(f"  Database Size:    {self._format_size(db_size_bytes)}")
                lines.append(f"  Database Path:    {db_file}")
                lines.append("")

                # Pending Uploads
                lines.append("PENDING UPLOADS")
                lines.append("-" * 80)
                lines.append(f"  Files awaiting upload: {len(pending_files)}")
                if self.app.pargs.show_paths and pending_paths:
                    lines.append("")
                    for path in pending_paths[:50]:  # Limit to 50 paths
                        lines.append(f"    {path}")
                    if len(pending_paths) > 50:
                        lines.append(f"    ... and {len(pending_paths) - 50} more")
                lines.append("")

                # Completed Files
                lines.append(f"COMPLETED FILES (Last {days} days)")
                lines.append("-" * 80)
                lines.append(f"  Files uploaded:   {len(success_files)}")
                lines.append(
                    f"  Total size:       {self._format_size(total_completed_size)}"
                )
                lines.append(f"  Avg per day:      {files_per_day:.1f} files/day")
                if self.app.pargs.show_paths and completed_paths:
                    lines.append("")
                    for path in completed_paths[:50]:
                        lines.append(f"    {path}")
                    if len(completed_paths) > 50:
                        lines.append(f"    ... and {len(completed_paths) - 50} more")
                lines.append("")

                # Failed Files
                lines.append(f"FAILED FILES (Last {days} days)")
                lines.append("-" * 80)
                lines.append(f"  Total failures:   {len(failed_files)}")
                if top_errors:
                    lines.append("")
                    lines.append("  Top Errors:")
                    for error_msg, count in top_errors:
                        lines.append(f"    {count}x  {error_msg}")
                if self.app.pargs.show_paths and failed_paths:
                    lines.append("")
                    lines.append("  Failed Files:")
                    for path in failed_paths[:50]:
                        lines.append(f"    {path}")
                    if len(failed_paths) > 50:
                        lines.append(f"    ... and {len(failed_paths) - 50} more")
                lines.append("")

                # Summary
                lines.append("SUMMARY")
                lines.append("-" * 80)
                lines.append(
                    f"  Success Rate:     {success_rate:.1f}% "
                    f"({len(success_files)}/{total_uploads})"
                )
                lines.append("")
                lines.append("=" * 80)

                report_content = "\n".join(lines)

            # Output to file or stdout
            if self.app.pargs.output_file:
                output_path = Path(self.app.pargs.output_file)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, "w") as f:
                    f.write(report_content)
                print(f"Report saved to: {output_path}")
            else:
                print(report_content)

        except Exception as e:
            logger.error("Failed to generate report", exc_info=e)
            print(f"Error: {e}")
