"""
AttachmentService for managing attachments to parent entities.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Dict, Any, Optional, List
from boto3.dynamodb.conditions import Key
from boto3_assist.dynamodb.dynamodb import DynamoDB
from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.lambda_handlers._base.decorators import service_method
from geek_cafe_saas_sdk.core.error_codes import ErrorCode
from geek_cafe_saas_sdk.core.service_errors import ValidationError, NotFoundError
from geek_cafe_saas_sdk.core.request_context import RequestContext
from geek_cafe_saas_sdk.modules.attachments.models.attachment import Attachment
from aws_lambda_powertools import Logger

logger = Logger(__name__)


class AttachmentService(DatabaseService[Attachment]):
    """
    Service for managing attachments to parent entities.
    
    Handles:
    - Creating attachments (file references, inline data, URLs)
    - Querying attachments by parent
    - Querying attachments by reference (reverse lookup)
    - Deleting attachments
    """

    def __init__(
        self,
        *,
        dynamodb: Optional[DynamoDB] = None,
        table_name: Optional[str] = None,
        request_context: RequestContext,
    ):
        """
        Initialize AttachmentService.

        Args:
            dynamodb: DynamoDB instance
            table_name: DynamoDB table name
            request_context: Security context (REQUIRED)
        """
        super().__init__(
            dynamodb=dynamodb,
            table_name=table_name,
            request_context=request_context,
        )
        self._model_class = Attachment

    # Required abstract method implementations
    
    @service_method
    def create(self, **kwargs) -> ServiceResult[Attachment]:
        """Create a new attachment (generic interface)."""
        attachment = Attachment()
        attachment.map(kwargs)
        attachment.tenant_id = self.request_context.target_tenant_id
        attachment.user_id = self.request_context.target_user_id
        attachment.prep_for_save()
        return self._save_model(attachment)
    
    @service_method
    def get_by_id(self, resource_id: str) -> ServiceResult[Attachment]:
        """Get attachment by ID with access control."""
        attachment = self._get_by_id(resource_id, Attachment)
        if not attachment:
            raise NotFoundError(f"Attachment not found: {resource_id}")
        return ServiceResult.success_result(attachment)
    
    @service_method
    def update(self, resource_id: str, updates: Dict[str, Any]) -> ServiceResult[Attachment]:
        """Update attachment with access control."""
        attachment = self._get_by_id(resource_id, Attachment)
        if not attachment:
            raise NotFoundError(f"Attachment not found: {resource_id}")
        
        # Apply updates
        for key, value in updates.items():
            if hasattr(attachment, key):
                setattr(attachment, key, value)
        
        attachment.prep_for_save()
        return self._save_model(attachment, old_model=attachment)
    
    @service_method
    def delete(self, resource_id: str) -> ServiceResult[bool]:
        """Delete attachment with access control."""
        attachment = self._get_by_id(resource_id, Attachment)
        if not attachment:
            raise NotFoundError(f"Attachment not found: {resource_id}")
        
        result = self._delete_model(attachment)
        return ServiceResult.success_result(result)

    def create_attachment(
        self,
        parent_id: str,
        parent_type: str,
        attachment_type: str,
        reference_type: str,
        reference_id: Optional[str] = None,
        inline_data: Optional[Dict[str, Any]] = None,
        name: Optional[str] = None,
        category: Optional[str] = None,
        description: Optional[str] = None,
        sequence: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ServiceResult[Attachment]:
        """
        Create a new attachment.

        Args:
            parent_id: ID of the parent entity
            parent_type: Type of parent (e.g., "execution", "workflow")
            attachment_type: Type of attachment (e.g., "input", "output")
            reference_type: Type of reference ("file", "inline", "url")
            reference_id: ID of referenced resource (for file/url types)
            inline_data: Inline data (for inline type)
            name: Descriptive name
            category: Category (e.g., "cleaned", "raw")
            description: Description
            sequence: Sequence number for ordering
            metadata: Additional metadata

        Returns:
            ServiceResult with created Attachment
        """
        # Validate required fields
        if not parent_id or not parent_type:
            return ServiceResult.failure_result(
                "parent_id and parent_type are required",
                error_code=ErrorCode.VALIDATION_ERROR,
            )

        if reference_type not in ["file", "inline", "url", "config", "metadata"]:
            return ServiceResult.failure_result(
                "reference_type must be 'file', 'inline', 'url', 'config', or 'metadata'",
                error_code=ErrorCode.VALIDATION_ERROR,
            )

        if reference_type in ["file", "url"] and not reference_id:
            return ServiceResult.failure_result(
                f"reference_id is required for reference_type '{reference_type}'",
                error_code=ErrorCode.VALIDATION_ERROR,
            )

        if reference_type == "inline" and not inline_data:
            return ServiceResult.failure_result(
                "inline_data is required for reference_type 'inline'",
                error_code=ErrorCode.VALIDATION_ERROR,
            )

        # Create attachment
        attachment = Attachment()
        attachment.tenant_id = self.request_context.target_tenant_id
        attachment.user_id = self.request_context.target_user_id
        attachment.parent_id = parent_id
        attachment.parent_type = parent_type
        attachment.attachment_type = attachment_type
        attachment.reference_type = reference_type
        attachment.reference_id = reference_id
        attachment.inline_data = inline_data
        attachment.name = name
        attachment.category = category
        attachment.description = description
        attachment.sequence = sequence
        attachment.metadata = metadata
        attachment.prep_for_save()
        return self._save_model(attachment)
        

    def list_by_parent(
        self,
        parent_id: str,
        parent_type: str,
        attachment_type: Optional[str] = None,
        category: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> ServiceResult[List[Attachment]]:
        """
        List attachments for a parent entity.

        Args:
            parent_id: ID of the parent entity
            parent_type: Type of parent
            attachment_type: Filter by attachment type (optional)
            category: Filter by category (optional)

        Returns:
            ServiceResult with list of Attachments
        """
        try:
            # Build partition key
            query: Attachment = Attachment()
            query.parent_id = parent_id
            query.parent_type = parent_type
            query.attachment_type = attachment_type
            query.category = category

            key = query.get_key("gsi1")

            response = self.dynamodb.query(
                table_name=self.table_name,
                key=key,
                index_name="gsi1",
                limit=limit,
            )
            
            items = response.get("Items", [])
            attachments = [Attachment().map(item) for item in items]

            return ServiceResult.success_result(
                data=attachments
            )

        except Exception as e:
            logger.exception("Error listing attachments by parent")
            return ServiceResult.failure_result(
                f"Failed to list attachments: {str(e)}",
                error_code=ErrorCode.INTERNAL_ERROR,
            )

    def get_by_category(
        self,
        parent_id: str,
        parent_type: str,
        attachment_type: str,
        category: str,
    ) -> ServiceResult[Optional[Attachment]]:
        """
        Get a single attachment by its compound category.

        Uses GSI1 with begins_with on the sort key to match the exact
        compound category (e.g., "input#original_request").

        Args:
            parent_id: ID of the parent entity
            parent_type: Type of parent
            attachment_type: Attachment type filter
            category: Compound category (e.g., "input#original_request")

        Returns:
            ServiceResult with the Attachment or None if not found
        """
        result = self.list_by_parent(
            parent_id=parent_id,
            parent_type=parent_type,
            attachment_type=attachment_type,
            category=category,
            limit=1,
        )

        if not result.success:
            return result

        attachments = result.data or []
        if not attachments:
            return ServiceResult.success_result(data=None)

        return ServiceResult.success_result(data=attachments[0])

    def list_by_reference(
        self,
        reference_type: str,
        reference_id: str,
    ) -> ServiceResult[List[Attachment]]:
        """
        List attachments that reference a specific resource (reverse lookup).

        Args:
            reference_type: Type of reference ("file", "url")
            reference_id: ID of referenced resource

        Returns:
            ServiceResult with list of Attachments
        """
        try:
            # Build partition key
            query: Attachment = Attachment()
            query.reference_type = reference_type
            query.reference_id = reference_id

            key = query.get_key("gsi3")
            
            response = self.dynamodb.query(
                table_name=self.table_name,
                key=key,
                index_name="gsi3",
            )

            items = response.get("Items", [])
            attachments = [Attachment().map(item) for item in items]

            return ServiceResult.success_result(
                data=attachments, message=f"Found {len(attachments)} attachments"
            )

        except Exception as e:
            logger.exception("Error listing attachments by reference")
            return ServiceResult.failure_result(
                f"Failed to list attachments: {str(e)}",
                error_code=ErrorCode.INTERNAL_ERROR,
            )

    def delete_by_parent(
        self,
        parent_id: str,
        parent_type: str,
    ) -> ServiceResult[Dict[str, Any]]:
        """
        Delete all attachments for a parent entity.

        Args:
            parent_id: ID of the parent entity
            parent_type: Type of parent

        Returns:
            ServiceResult with deletion count
        """
        try:
            # List all attachments for this parent
            list_result = self.list_by_parent(parent_id, parent_type)
            if not list_result.success:
                return list_result

            attachments = list_result.data
            deleted_count = 0

            # Delete each attachment
            for attachment in attachments:
                delete_result = self.delete(attachment.id)
                if delete_result.success:
                    deleted_count += 1

            return ServiceResult.success_result(
                data={"deleted_count": deleted_count},
                message=f"Deleted {deleted_count} attachments",
            )

        except Exception as e:
            logger.exception("Error deleting attachments by parent")
            return ServiceResult.failure_result(
                f"Failed to delete attachments: {str(e)}",
                error_code=ErrorCode.INTERNAL_ERROR,
            )
