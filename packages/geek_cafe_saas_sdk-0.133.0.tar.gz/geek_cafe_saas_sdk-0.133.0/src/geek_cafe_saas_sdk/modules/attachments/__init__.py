"""
Attachment module for linking resources to parent entities.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from .models.attachment import Attachment
from .services.attachment_service import AttachmentService

__all__ = ["Attachment", "AttachmentService"]
