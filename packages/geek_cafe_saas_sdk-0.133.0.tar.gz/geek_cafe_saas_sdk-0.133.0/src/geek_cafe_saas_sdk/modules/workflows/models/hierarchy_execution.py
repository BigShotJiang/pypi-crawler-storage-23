"""
Hierarchical execution models for workflow orchestration.

Extends the existing Workflow model to support wrapper executions that coordinate
multiple child executions with proper completion tracking and atomic operations.

Follows the established DynamoDB-friendly model patterns with proper indexes.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Dict, List, Optional, Any
from boto3_assist.dynamodb.dynamodb_index import DynamoDBIndex, DynamoDBKey

from .execution import WorkflowBase, WorkflowStatus


class HierarchyStatus:
    """Hierarchy coordination status constants."""
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    
    ALL = [IN_PROGRESS, COMPLETED, FAILED]
    
    # Terminal states
    TERMINAL = [COMPLETED, FAILED]
    
    @classmethod
    def is_terminal(cls, status: str) -> bool:
        """Check if status is a terminal state."""
        return status in cls.TERMINAL


class WrapperExecution(WorkflowBase):
    """
    Wrapper execution that coordinates multiple child executions.
    
    Inherits from WorkflowBase (not Workflow) to define its own indexes without conflicts.
    
    Access Patterns (DynamoDB Keys):
    - pk: EXECUTION#{wrapper_id}
    - sk: wrapper#metadata
    - gsi1: Executions by owner + root_id (wrapper is root)
    - gsi2: Child executions by parent_id (wrapper_id)
    - gsi3: Wrappers by status + timestamp (for monitoring)
    - gsi4: Wrappers by execution_type + timestamp
    - gsi5: Wrappers by tenant/owner + execution_type + status + timestamp
    """

    def __init__(self):
        # Call WorkflowBase.__init__ which does NOT setup indexes
        super().__init__()
        
        # Override execution type for wrapper executions
        self._execution_type = "wrapper_execution"
        
        # Wrapper-specific fields
        self._original_request: Dict[str, Any] = {}
        self._child_execution_plan: List[Dict[str, Any]] = []
        
        # Hierarchy coordination state
        self._expected_child_count: int = 0
        self._hierarchy_status: str = HierarchyStatus.IN_PROGRESS
        
        # Setup wrapper-specific indexes
        self._setup_indexes()

    def _setup_indexes(self):
        """Setup wrapper-specific indexes."""
        # Primary index: Wrapper by ID with wrapper-specific sort key
        primary = DynamoDBIndex()
        primary.name = "primary"
        primary.partition_key.attribute_name = "pk"
        primary.partition_key.value = lambda: DynamoDBKey.build_key(("execution", self.id))
        primary.sort_key.attribute_name = "sk"
        primary.sort_key.value = lambda: DynamoDBKey.build_key(("wrapper", "metadata"))
        self.indexes.add_primary(primary)
        
        # Setup GSIs (same as Workflow model)
        self._setup_gsi1()
        self._setup_gsi2()
        self._setup_gsi3()
        self._setup_gsi4()
        self._setup_gsi5()

    @classmethod
    def create_new(
        cls,
        tenant_id: str,
        user_id: str,
        name: str,
        original_request: Dict[str, Any],
        child_execution_plan: List[Dict[str, Any]],
        description: Optional[str] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> "WrapperExecution":
        """Create a new wrapper execution with proper initialization."""
        wrapper = cls()
        
        # Set required properties
        wrapper.tenant_id = tenant_id
        wrapper.owner_id = user_id  # Using owner_id as per SDK pattern
        wrapper.name = name or f"Wrapper Execution"
        wrapper.description = description or "Hierarchical workflow wrapper execution"
        wrapper.status = WorkflowStatus.PENDING
        wrapper.correlation_id = correlation_id
        wrapper.metadata = metadata
        
        # Set wrapper-specific properties
        wrapper.original_request = original_request
        wrapper.child_execution_plan = child_execution_plan
        wrapper.expected_child_count = len(child_execution_plan)
        
        # Set hierarchy properties (wrapper is root of its hierarchy)
        wrapper.root_id = None  # Will be set to self.id after prep_for_save
        wrapper.parent_id = None  # Wrapper has no parent
        
        # Initialize child tracking
        wrapper.child_count = len(child_execution_plan)
        wrapper.completed_child_count = 0
        wrapper.failed_child_count = 0
        
        return wrapper

    @property
    def original_request(self) -> Dict[str, Any]:
        """Original user request that initiated this wrapper execution."""
        return self._original_request

    @original_request.setter
    def original_request(self, value: Dict[str, Any]):
        self._original_request = value or {}

    @property
    def child_execution_plan(self) -> List[Dict[str, Any]]:
        """List of planned child executions."""
        return self._child_execution_plan

    @child_execution_plan.setter
    def child_execution_plan(self, value: List[Dict[str, Any]]):
        if not value:
            raise ValueError("child_execution_plan cannot be empty")
        self._child_execution_plan = value

    @property
    def expected_child_count(self) -> int:
        """Expected number of child executions."""
        return self._expected_child_count

    @expected_child_count.setter
    def expected_child_count(self, value: int):
        if value < 0:
            raise ValueError("expected_child_count cannot be negative")
        self._expected_child_count = value

    @property
    def hierarchy_status(self) -> str:
        """Hierarchy coordination status."""
        return self._hierarchy_status

    @hierarchy_status.setter
    def hierarchy_status(self, value: str):
        if value not in HierarchyStatus.ALL:
            raise ValueError(f"Invalid hierarchy status: {value}")
        self._hierarchy_status = value

    def prep_for_save(self, preserve_timestamps: bool = False):
        """Override to set root_id to self after ID generation."""
        super().prep_for_save(preserve_timestamps)
        
        # Set root_id to self for wrapper executions (they are roots)
        if not self.root_id:
            self.root_id = self.id

    def is_wrapper_complete(self) -> bool:
        """Check if wrapper should be marked as complete based on child states."""
        return (
            self.completed_child_count == self.expected_child_count and
            self.failed_child_count == 0
        )

    def should_wrapper_fail(self) -> bool:
        """Check if wrapper should be marked as failed based on child states."""
        return self.failed_child_count > 0

    def get_completion_percentage(self) -> float:
        """Calculate completion percentage based on child execution states."""
        if self.expected_child_count == 0:
            return 100.0
        
        terminal_children = self.completed_child_count + self.failed_child_count
        return (terminal_children / self.expected_child_count) * 100.0

    def is_hierarchy_complete(self) -> bool:
        """Check if all children are in terminal states."""
        return (self.completed_child_count + self.failed_child_count) == self.expected_child_count


class HierarchyCoordinationRecord(WorkflowBase):
    """
    Coordination record for tracking hierarchy state and atomic operations.
    
    This is a separate model from WrapperExecution to handle atomic counter
    operations without affecting the main wrapper execution record.
    
    Inherits from WorkflowBase (not Workflow) to define its own indexes without conflicts.
    
    The coordination record uses the wrapper_id as its own id for direct lookup.
    
    Access Patterns (DynamoDB Keys):
    - pk: EXECUTION#{id} (where id = wrapper_id)
    - sk: coordination#metadata
    - gsi3: Coordination records by status + timestamp (for monitoring)
    """

    def __init__(self):
        # Call WorkflowBase.__init__ which does NOT setup indexes
        super().__init__()
        
        # Override execution type for coordination records
        self._execution_type = "hierarchy_coordination"
        
        # Coordination-specific fields
        self._wrapper_id: str | None = None
        self._expected_child_count: int = 0
        self._completed_child_count: int = 0
        self._failed_child_count: int = 0
        self._child_executions: Dict[str, Dict[str, Any]] = {}
        self._coordination_status: str = HierarchyStatus.IN_PROGRESS
        
        # Setup coordination-specific indexes
        self._setup_indexes()

    def _setup_indexes(self):
        """Setup coordination-specific indexes."""
        # Primary index: Coordination record by wrapper ID with coordination-specific sort key
        primary = DynamoDBIndex()
        primary.name = "primary"
        primary.partition_key.attribute_name = "pk"
        primary.partition_key.value = lambda: DynamoDBKey.build_key(("execution", self.id))
        primary.sort_key.attribute_name = "sk"
        primary.sort_key.value = lambda: DynamoDBKey.build_key(("coordination", "metadata"))
        self.indexes.add_primary(primary)
        
        # GSI3: Coordination records by status (for monitoring)
        gsi3 = DynamoDBIndex()
        gsi3.name = "gsi3"
        gsi3.partition_key.attribute_name = "gsi3_pk"
        gsi3.partition_key.value = lambda: DynamoDBKey.build_key(
            ("tenant", self.tenant_id),
            ("owner", self.owner_id)
        )
        gsi3.sort_key.attribute_name = "gsi3_sk"
        gsi3.sort_key.value = lambda: DynamoDBKey.build_key(
            ("status", self._status),
            ("ts", self._started_utc_ts or 0)
        )
        self.indexes.add_secondary(gsi3)

    @classmethod
    def create_new(
        cls,
        wrapper_id: str,
        tenant_id: str,
        user_id: str,
        expected_child_count: int
    ) -> "HierarchyCoordinationRecord":
        """Create a new coordination record."""
        record = cls()
        
        # Set the id to wrapper_id for direct lookup
        record.id = wrapper_id
        
        # Set required properties
        record.tenant_id = tenant_id
        record.owner_id = user_id
        record.expected_child_count = expected_child_count
        record.name = f"Coordination for {wrapper_id}"
        record.status = WorkflowStatus.RUNNING  # Coordination is active
        
        # Initialize counters
        record.completed_child_count = 0
        record.failed_child_count = 0
        record.child_executions = {}
        
        return record
    
    @property
    def wrapper_id(self) -> str | None:
        """Wrapper execution ID this record coordinates (same as id)."""
        return self.id

    @wrapper_id.setter
    def wrapper_id(self, value: str | None):
        """Set wrapper_id (updates id as well)."""
        self.id = value

    @property
    def expected_child_count(self) -> int:
        """Expected number of child executions."""
        return self._expected_child_count

    @expected_child_count.setter
    def expected_child_count(self, value: int):
        if value < 0:
            raise ValueError("expected_child_count cannot be negative")
        self._expected_child_count = value

    @property
    def completed_child_count(self) -> int:
        """Number of completed child executions."""
        return self._completed_child_count

    @completed_child_count.setter
    def completed_child_count(self, value: int):
        if value < 0:
            raise ValueError("completed_child_count cannot be negative")
        # Note: We don't validate against expected_child_count here because during
        # DynamoDB mapping, properties may be set in arbitrary order, causing
        # validation to fail if completed_child_count is set before expected_child_count
        self._completed_child_count = value

    @property
    def failed_child_count(self) -> int:
        """Number of failed child executions."""
        return self._failed_child_count

    @failed_child_count.setter
    def failed_child_count(self, value: int):
        if value < 0:
            raise ValueError("failed_child_count cannot be negative")
        # Note: We don't validate against expected_child_count here because during
        # DynamoDB mapping, properties may be set in arbitrary order
        self._failed_child_count = value

    @property
    def child_executions(self) -> Dict[str, Dict[str, Any]]:
        """Child execution information."""
        return self._child_executions

    @child_executions.setter
    def child_executions(self, value: Dict[str, Dict[str, Any]]):
        self._child_executions = value or {}

    @property
    def coordination_status(self) -> str:
        """Coordination status."""
        return self._coordination_status

    @coordination_status.setter
    def coordination_status(self, value: str):
        if value not in HierarchyStatus.ALL:
            raise ValueError(f"Invalid coordination status: {value}")
        self._coordination_status = value

    def is_complete(self) -> bool:
        """Check if all children are in terminal states."""
        return (self.completed_child_count + self.failed_child_count) >= self.expected_child_count

    def should_complete_wrapper(self) -> bool:
        """Check if wrapper should be marked as complete (all children completed successfully)."""
        return self.completed_child_count >= self.expected_child_count and self.failed_child_count == 0

    def should_fail_wrapper(self) -> bool:
        """Check if wrapper should be marked as failed (any child failed)."""
        return self.failed_child_count > 0

    def add_child_execution(self, child_execution_id: str, child_info: Dict[str, Any]) -> None:
        """Add child execution information."""
        if not child_execution_id:
            raise ValueError("child_execution_id cannot be empty")
        self._child_executions[child_execution_id] = child_info

    def update_child_status(self, child_execution_id: str, status: str, error_message: Optional[str] = None) -> None:
        """Update child execution status."""
        if child_execution_id not in self._child_executions:
            raise ValueError(f"Child execution {child_execution_id} not found")
        
        self._child_executions[child_execution_id]["status"] = status
        if error_message:
            self._child_executions[child_execution_id]["error_message"] = error_message
        if status in WorkflowStatus.TERMINAL:
            self._child_executions[child_execution_id]["completed_utc"] = self.modified_utc_ts

    def get_atomic_increment_key(self) -> Dict[str, Any]:
        """
        Get DynamoDB key for atomic operations.
        
        Returns:
            Dict with pk and sk for this coordination record
        """
        return self.get_key("primary").key()

    @staticmethod
    def get_atomic_completed_increment_expression(child_execution_id: str = None) -> Dict[str, Any]:
        """
        Get DynamoDB update expression for atomically incrementing completed_child_count.
        
        This uses DynamoDB's atomic ADD operation to safely increment the counter
        even with concurrent updates from multiple Lambda invocations.
        
        If child_execution_id is provided, also marks the child's status as
        'succeeded' in the child_executions map (same atomic operation).
        
        Args:
            child_execution_id: Optional child execution ID to mark as succeeded
        
        Returns:
            Dict with update_expression and expression_attribute_values for DynamoDB update_item
        """
        from decimal import Decimal
        import time
        
        if child_execution_id:
            return {
                "update_expression": (
                    "ADD completed_child_count :inc "
                    "SET modified_utc_ts = :ts, "
                    f"child_executions.#cid.#st = :succeeded"
                ),
                "expression_attribute_values": {
                    ":inc": 1,
                    ":ts": Decimal(str(time.time())),
                    ":succeeded": WorkflowStatus.SUCCEEDED,
                },
                "expression_attribute_names": {
                    "#cid": child_execution_id,
                    "#st": "status",
                },
            }
        
        return {
            "update_expression": "ADD completed_child_count :inc SET modified_utc_ts = :ts",
            "expression_attribute_values": {
                ":inc": 1,
                ":ts": Decimal(str(time.time()))
            }
        }

    @staticmethod
    def get_atomic_failed_increment_expression(child_execution_id: str = None) -> Dict[str, Any]:
        """
        Get DynamoDB update expression for atomically incrementing failed_child_count.
        
        This uses DynamoDB's atomic ADD operation to safely increment the counter
        even with concurrent updates from multiple Lambda invocations.
        
        If child_execution_id is provided, also marks the child's status as
        'failed' in the child_executions map (same atomic operation).
        
        Args:
            child_execution_id: Optional child execution ID to mark as failed
        
        Returns:
            Dict with update_expression and expression_attribute_values for DynamoDB update_item
        """
        from decimal import Decimal
        import time
        
        if child_execution_id:
            return {
                "update_expression": (
                    "ADD failed_child_count :inc "
                    "SET modified_utc_ts = :ts, "
                    f"child_executions.#cid.#st = :failed"
                ),
                "expression_attribute_values": {
                    ":inc": 1,
                    ":ts": Decimal(str(time.time())),
                    ":failed": WorkflowStatus.FAILED,
                },
                "expression_attribute_names": {
                    "#cid": child_execution_id,
                    "#st": "status",
                },
            }
        
        return {
            "update_expression": "ADD failed_child_count :inc SET modified_utc_ts = :ts",
            "expression_attribute_values": {
                ":inc": 1,
                ":ts": Decimal(str(time.time()))
            }
        }