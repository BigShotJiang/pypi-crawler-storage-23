"""
Workflow Lineage model for tracking cross-workflow parent-child relationships.

This model is separate from the internal execution hierarchy (root_id/parent_id)
which handles coordination within a single workflow. WorkflowLineage tracks
relationships between independently submitted workflows.

Example:
    analysis workflow → custom_calcs workflow → visualization workflow

Each workflow has its own internal hierarchy (wrapper → phases), but the
lineage model tracks the chain between them.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Any, Dict, Optional
from boto3_assist.dynamodb.dynamodb_index import DynamoDBIndex, DynamoDBKey
from geek_cafe_saas_sdk.core.models.base_tenant_user_model import BaseTenantUserModel


class WorkflowLineage(BaseTenantUserModel):
    """
    Tracks cross-workflow parent-child relationships.
    
    Stored as a separate sort key (LINEAGE#) under the execution's partition key,
    co-located with the execution record for efficient single-item reads.
    
    Access Patterns:
    - pk: EXECUTION#{execution_id}, sk: LINEAGE# — direct lookup
    - gsi1: by tenant/owner + lineage_root_id — get entire workflow chain
    
    Fields:
    - execution_id: This workflow's root/wrapper execution ID
    - parent_workflow_id: The parent workflow's root/wrapper execution ID (null for first)
    - lineage_root_id: The original ancestor workflow ID (for chain queries)
    - sequence_number: Position in chain (0 = first, 1 = second, etc.)
    - metadata: Optional context (why this child was created, phase info, etc.)
    """

    def __init__(self):
        super().__init__()

        self._execution_id: str | None = None
        self._parent_workflow_id: str | None = None
        self._lineage_root_id: str | None = None
        self._sequence_number: int | None = None
        self._status: str | None = "active"
        self._metadata: Dict[str, Any] | None = None

        # Timestamps
        self._created_utc: str | None = None
        self._created_utc_ts: float | None = None

        # CRITICAL: Call _setup_indexes() as LAST line in __init__
        self._setup_indexes()

    def _setup_indexes(self):
        """Setup DynamoDB indexes for lineage queries."""

        # Primary index: co-located with execution record
        primary = DynamoDBIndex()
        primary.name = "primary"
        primary.partition_key.attribute_name = "pk"
        primary.partition_key.value = lambda: DynamoDBKey.build_key(
            ("execution", self._execution_id or self.id)
        )
        primary.sort_key.attribute_name = "sk"
        primary.sort_key.value = lambda: DynamoDBKey.build_key(("lineage", ""))
        self.indexes.add_primary(primary)

        # GSI1: Get entire workflow chain by lineage_root_id
        # Query: "give me all workflows in this chain"
        gsi1 = DynamoDBIndex()
        gsi1.name = "gsi1"
        gsi1.partition_key.attribute_name = "gsi1_pk"
        gsi1.partition_key.value = lambda: DynamoDBKey.build_key(
            ("tenant", self.tenant_id),
            ("owner", self.owner_id),
            ("lineage_root", self._lineage_root_id or self._execution_id or self.id),
        )
        gsi1.sort_key.attribute_name = "gsi1_sk"
        gsi1.sort_key.value = lambda: self._build_gsi1_sk()
        self.indexes.add_secondary(gsi1)

    def _build_gsi1_sk(self) -> str:
        """Build GSI1 sort key. Returns prefix-only for begins_with queries."""
        if self._sequence_number is None:
            return "seq#"  # Prefix only — allows begins_with to match all
        return DynamoDBKey.build_key(("seq", f"{self._sequence_number:06d}"))

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def execution_id(self) -> str | None:
        """This workflow's root/wrapper execution ID."""
        return self._execution_id

    @execution_id.setter
    def execution_id(self, value: str | None):
        self._execution_id = value
        if value:
            self.id = value

    @property
    def parent_workflow_id(self) -> str | None:
        """Parent workflow's root/wrapper execution ID. None for the first in a chain."""
        return self._parent_workflow_id

    @parent_workflow_id.setter
    def parent_workflow_id(self, value: str | None):
        self._parent_workflow_id = value

    @property
    def lineage_root_id(self) -> str | None:
        """Original ancestor workflow ID. For the first workflow, this equals execution_id."""
        return self._lineage_root_id or self._execution_id

    @lineage_root_id.setter
    def lineage_root_id(self, value: str | None):
        self._lineage_root_id = value

    @property
    def sequence_number(self) -> int:
        """Position in the workflow chain (0 = first, 1 = second, etc.)."""
        return self._sequence_number if self._sequence_number is not None else 0

    @sequence_number.setter
    def sequence_number(self, value: int | None):
        if value is not None and value < 0:
            raise ValueError("sequence_number cannot be negative")
        self._sequence_number = value

    @property
    def status(self) -> str | None:
        """Lineage record status."""
        return self._status

    @status.setter
    def status(self, value: str | None):
        self._status = value

    @property
    def metadata(self) -> Dict[str, Any] | None:
        """Optional context about this lineage relationship."""
        return self._metadata

    @metadata.setter
    def metadata(self, value: Dict[str, Any] | None):
        self._metadata = value

    @property
    def created_utc(self) -> str | None:
        return self._created_utc

    @created_utc.setter
    def created_utc(self, value: str | None):
        self._created_utc = value
        if value and not self._created_utc_ts:
            try:
                from datetime import datetime, timezone
                dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
                self._created_utc_ts = dt.timestamp()
            except (ValueError, TypeError):
                pass

    @property
    def created_utc_ts(self) -> float | None:
        return self._created_utc_ts

    @created_utc_ts.setter
    def created_utc_ts(self, value: float | None):
        self._created_utc_ts = value

    # =========================================================================
    # Convenience
    # =========================================================================

    @property
    def is_root(self) -> bool:
        """True if this is the first workflow in the chain (no parent)."""
        return self._parent_workflow_id is None

    @is_root.setter
    def is_root(self, value: bool):
        """No-op setter — is_root is derived from parent_workflow_id."""
        pass

    @classmethod
    def create_root(
        cls,
        execution_id: str,
        tenant_id: str,
        user_id: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "WorkflowLineage":
        """
        Create a lineage record for the first workflow in a chain.
        
        Args:
            execution_id: This workflow's root/wrapper execution ID
            tenant_id: Tenant ID
            user_id: User ID
            metadata: Optional context
            
        Returns:
            WorkflowLineage with sequence_number=0, no parent
        """
        from datetime import datetime, UTC as _UTC
        lineage = cls()
        lineage.execution_id = execution_id
        lineage.tenant_id = tenant_id
        lineage.owner_id = user_id
        lineage.lineage_root_id = execution_id
        lineage.parent_workflow_id = None
        lineage.sequence_number = 0
        lineage.created_utc = datetime.now(_UTC).isoformat()
        lineage.metadata = metadata
        return lineage

    @classmethod
    def create_child(
        cls,
        execution_id: str,
        parent_workflow_id: str,
        lineage_root_id: str,
        sequence_number: int,
        tenant_id: str,
        user_id: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "WorkflowLineage":
        """
        Create a lineage record for a child workflow in a chain.
        
        Args:
            execution_id: This workflow's root/wrapper execution ID
            parent_workflow_id: Parent workflow's root/wrapper execution ID
            lineage_root_id: Original ancestor workflow ID
            sequence_number: Position in chain (1, 2, 3, ...)
            tenant_id: Tenant ID
            user_id: User ID
            metadata: Optional context
            
        Returns:
            WorkflowLineage linked to parent
        """
        from datetime import datetime, UTC as _UTC
        lineage = cls()
        lineage.execution_id = execution_id
        lineage.tenant_id = tenant_id
        lineage.owner_id = user_id
        lineage.parent_workflow_id = parent_workflow_id
        lineage.lineage_root_id = lineage_root_id
        lineage.sequence_number = sequence_number
        lineage.created_utc = datetime.now(_UTC).isoformat()
        lineage.metadata = metadata
        return lineage
