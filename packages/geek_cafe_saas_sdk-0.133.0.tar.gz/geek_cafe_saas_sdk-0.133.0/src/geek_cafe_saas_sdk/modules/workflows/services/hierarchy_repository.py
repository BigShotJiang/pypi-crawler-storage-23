"""
Service interfaces for hierarchical workflow execution.

Defines abstract interfaces for persisting and managing hierarchical workflow
execution data with atomic operations and optimistic locking support.

Follows the established service patterns with proper error handling and service results.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any

from geek_cafe_saas_sdk.core.service_result import ServiceResult
from ..models.hierarchy_execution import WrapperExecution, HierarchyCoordinationRecord


class WrapperExecutionService(ABC):
    """Service interface for managing wrapper executions."""

    @abstractmethod
    def create_wrapper_execution(
        self,
        name: str,
        user_request: Dict[str, Any],
        child_execution_plan: List[Dict[str, Any]],
        description: Optional[str] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> ServiceResult[WrapperExecution]:
        """
        Create top-level wrapper execution and plan child executions.
        
        Args:
            name: Human-readable name for the wrapper execution
            user_request: The original user request payload
            child_execution_plan: List of planned child executions
            description: Optional description
            correlation_id: Optional correlation ID for tracking
            metadata: Optional additional metadata
            
        Returns:
            ServiceResult[WrapperExecution]: The created wrapper execution
        """
        pass

    @abstractmethod
    def get_wrapper_execution(self, wrapper_id: str) -> ServiceResult[WrapperExecution]:
        """
        Get wrapper execution by ID.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[WrapperExecution]: The wrapper execution
        """
        pass

    @abstractmethod
    def update_wrapper_status(
        self,
        wrapper_id: str,
        status: str,
        error_message: Optional[str] = None
    ) -> ServiceResult[WrapperExecution]:
        """
        Update wrapper execution status.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            status: New execution status (WorkflowStatus value)
            error_message: Error message if status is FAILED
            
        Returns:
            ServiceResult[WrapperExecution]: Updated wrapper execution
        """
        pass

    @abstractmethod
    def complete_wrapper_execution(self, wrapper_id: str) -> ServiceResult[WrapperExecution]:
        """
        Mark wrapper as complete when all children finish.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[WrapperExecution]: Updated wrapper execution
        """
        pass

    @abstractmethod
    def fail_wrapper_execution(
        self, 
        wrapper_id: str, 
        error_message: str
    ) -> ServiceResult[WrapperExecution]:
        """
        Mark wrapper as failed with error details.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            error_message: Description of the failure
            
        Returns:
            ServiceResult[WrapperExecution]: Updated wrapper execution
        """
        pass


class HierarchyCoordinationService(ABC):
    """Service interface for coordinating hierarchy completion tracking."""

    @abstractmethod
    def create_coordination_record(
        self,
        wrapper_id: str,
        expected_child_count: int
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Create hierarchy coordination record.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            expected_child_count: Number of child executions expected
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: The created coordination record
        """
        pass

    @abstractmethod
    def register_child_execution(
        self,
        wrapper_id: str,
        child_execution_id: str,
        execution_type: str,
        phase: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Register a child execution with its wrapper.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            child_execution_id: Unique identifier for the child execution
            execution_type: Type of execution
            phase: Execution phase
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Updated coordination record
        """
        pass

    @abstractmethod
    def notify_child_completion(
        self,
        wrapper_id: str,
        child_execution_id: str,
        status: str,
        error_message: Optional[str] = None
    ) -> ServiceResult[Dict[str, Any]]:
        """
        Notify wrapper of child completion, return coordination state.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            child_execution_id: Unique identifier for the child execution
            status: Final status of the child execution (WorkflowStatus value)
            error_message: Error message if status is FAILED
            
        Returns:
            ServiceResult[Dict[str, Any]]: Coordination state with completion info
        """
        pass

    @abstractmethod
    def get_coordination_record(
        self, 
        wrapper_id: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Get current coordination state for wrapper.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Current coordination record
        """
        pass

    @abstractmethod
    def increment_completed_children(
        self, 
        wrapper_id: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Atomically increment completed child counter.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Updated coordination record
        """
        pass

    @abstractmethod
    def increment_failed_children(
        self, 
        wrapper_id: str
    ) -> ServiceResult[HierarchyCoordinationRecord]:
        """
        Atomically increment failed child counter.
        
        Args:
            wrapper_id: Unique identifier for the wrapper execution
            
        Returns:
            ServiceResult[HierarchyCoordinationRecord]: Updated coordination record
        """
        pass