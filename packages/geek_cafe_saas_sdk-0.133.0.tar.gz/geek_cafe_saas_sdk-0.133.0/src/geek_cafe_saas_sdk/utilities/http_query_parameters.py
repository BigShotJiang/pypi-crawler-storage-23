"""
Case-insensitive query parameter resolver for Lambda handlers.

Resolves query parameters regardless of the case convention used by the
caller (snake_case, camelCase, PascalCase, kebab-case).  Uses
:class:`CaseConverter.to_all` to generate all variants of a canonical
parameter name and returns the first match found in the raw dict.

Usage::

    # From a Lambda event
    qp = QueryParams.from_event(event)
    status = qp.get("execution_type")
    # Finds: execution_type, executionType, ExecutionType, execution-type

    # From a raw dict
    qp = QueryParams({"executionType": "nca_analysis", "limit": "50"})
    qp.get("execution_type")   # "nca_analysis"
    qp.get_int("limit")        # 50
    qp.get_bool("hard_delete") # False (missing → default)

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import Any, Dict, List, Optional

from geek_cafe_saas_sdk.utilities.case_conversion import CaseConverter


class QueryParams:
    """Case-insensitive query parameter resolver.

    Wraps a raw ``queryStringParameters`` dict and exposes typed accessors
    that check all case variants of the requested key.
    """

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        self._params: Dict[str, Any] = params or {}

    # ------------------------------------------------------------------
    # Construction helpers
    # ------------------------------------------------------------------

    @classmethod
    def from_event(cls, event: Dict[str, Any]) -> "QueryParams":
        """Create from a Lambda event dict.

        Extracts ``queryStringParameters`` (or ``queryparams`` /
        ``query_params`` as fallback).
        """
        params = (
            event.get("queryStringParameters")
            or event.get("queryparams")
            or event.get("query_params")
            or {}
        )
        return cls(params)

    # ------------------------------------------------------------------
    # Core accessor
    # ------------------------------------------------------------------

    def get(self, key: str, default: Any = None) -> Any:
        """Look up *key* in all case variants, return first match.

        Args:
            key: Canonical parameter name in **any** case convention.
                 Internally converted to snake, camel, pascal, and kebab
                 variants for lookup.
            default: Value returned when no variant matches.

        Returns:
            The parameter value (always a ``str`` from API Gateway) or
            *default*.
        """
        for variant in CaseConverter.to_all(key):
            if variant in self._params:
                return self._params[variant]
        return default

    # ------------------------------------------------------------------
    # Typed accessors
    # ------------------------------------------------------------------

    def get_str(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Return the parameter as a string, or *default*."""
        value = self.get(key)
        if value is None:
            return default
        return str(value)

    def get_int(
        self, key: str, default: Optional[int] = None
    ) -> Optional[int]:
        """Return the parameter as an ``int``, or *default*.

        Returns *default* if the value is missing or not a valid integer.
        """
        value = self.get(key)
        if value is None:
            return default
        try:
            return int(value)
        except (ValueError, TypeError):
            return default

    def get_float(
        self, key: str, default: Optional[float] = None
    ) -> Optional[float]:
        """Return the parameter as a ``float``, or *default*."""
        value = self.get(key)
        if value is None:
            return default
        try:
            return float(value)
        except (ValueError, TypeError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Return the parameter as a ``bool``.

        Truthy strings: ``"true"``, ``"1"``, ``"yes"`` (case-insensitive).
        Everything else (including missing) returns *default*.
        """
        value = self.get(key)
        if value is None:
            return default
        return str(value).lower() in ("true", "1", "yes")

    def get_list(
        self, key: str, separator: str = ",", default: Optional[List[str]] = None
    ) -> List[str]:
        """Split a comma-separated parameter into a list of strings.

        Args:
            key: Parameter name.
            separator: Delimiter (default ``","``).
            default: Returned when the parameter is missing.

        Returns:
            List of stripped, non-empty strings.
        """
        value = self.get(key)
        if value is None:
            return default if default is not None else []
        return [v.strip() for v in str(value).split(separator) if v.strip()]

    # ------------------------------------------------------------------
    # Dict-like helpers
    # ------------------------------------------------------------------

    def has(self, key: str) -> bool:
        """Return ``True`` if any case variant of *key* is present."""
        return self.get(key) is not None

    @property
    def raw(self) -> Dict[str, Any]:
        """Return the underlying raw parameter dict."""
        return self._params

    def __repr__(self) -> str:
        return f"QueryParams({self._params!r})"
