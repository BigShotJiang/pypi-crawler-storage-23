"""CI-1T async client for OpenClaw agent monitoring.

Thin async wrapper that keeps only the fleet session methods needed for
real-time agent monitoring. Types and constants are re-exported from the
ci1t SDK package.

For sync/general use, use ci1t.Client directly:
    pip install ci1t

Auth: X-API-Key header with ci_... API key from the CI-1T dashboard.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

# Re-export from ci1t SDK so existing `from .client import Q16_MAX` still works
from ci1t.types import Q16_MAX  # noqa: F401

DEFAULT_BASE_URL = "https://collapseindex.org/api"
DEFAULT_TIMEOUT = 30.0


class Ci1tClient:
    """Async HTTP client for CI-1T fleet sessions.

    This is the async counterpart to ci1t.Client (sync). OpenClaw needs
    async because the monitor tails logs in an asyncio loop.

    Only fleet session methods are exposed here -- evaluate() and
    fleet_evaluate() are available via the ci1t SDK directly.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key or os.getenv("CI1T_API_KEY", "")
        self.base_url = (base_url or os.getenv("CI1T_API_URL", DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout

        if not self.api_key:
            raise ValueError(
                "CI1T_API_KEY is required. "
                "Get one at https://collapseindex.org/dashboard (API Keys panel)."
            )

    @property
    def _headers(self) -> dict[str, str]:
        return {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

    # -- Fleet sessions (persistent, stateful) --

    async def fleet_session_create(
        self, node_count: int, node_names: list[str] | None = None
    ) -> dict[str, Any]:
        """Create a persistent fleet monitoring session."""
        body: dict[str, Any] = {"action": "create", "node_count": node_count}
        if node_names:
            body["node_names"] = node_names
        return await self._fleet_session(body)

    async def fleet_session_round(
        self, session_id: str, scores: list[list[int]]
    ) -> dict[str, Any]:
        """Push a scoring round to a fleet session."""
        body: dict[str, Any] = {
            "action": "round",
            "session_id": session_id,
            "scores": scores,
        }
        return await self._fleet_session(body)

    async def fleet_session_delete(self, session_id: str) -> dict[str, Any]:
        """Delete a fleet session."""
        return await self._fleet_session({"action": "delete", "session_id": session_id})

    # -- Internal --

    async def _fleet_session(self, body: dict[str, Any]) -> dict[str, Any]:
        """Send an action to the fleet-session proxy endpoint."""
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                f"{self.base_url}/fleet-session",
                headers=self._headers,
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
            return resp.json()
