"""CLI entry point -- python -m ci1t_openclaw.

Usage:
    python -m ci1t_openclaw --watch /path/to/gateway.log
    python -m ci1t_openclaw --watch /path/to/gateway.log --policy-gating
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import signal
import sys

from . import __version__
from .client import Ci1tClient
from .monitor import Ci1tMonitor
from .policy import PolicyGate
from .scorer import RiskConfig


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ci1t-openclaw",
        description="CI-1T stability monitoring for OpenClaw agents",
    )

    parser.add_argument(
        "--api-key",
        default=None,
        help="CI-1T API key (ci_...). Also reads CI1T_API_KEY env var.",
    )
    parser.add_argument(
        "--api-url",
        default=None,
        help="CI-1T API base URL. Default: https://collapseindex.org/api",
    )
    parser.add_argument(
        "--watch",
        metavar="LOG_PATH",
        required=True,
        help="Path to the OpenClaw gateway log to monitor.",
    )
    parser.add_argument(
        "--policy-gating",
        action="store_true",
        help="Enable AL enforcement. OFF = monitor only. ON = gate/block at AL3+.",
    )
    parser.add_argument(
        "--agent-name",
        default="openclaw-agent",
        help="Name for the monitored agent (default: openclaw-agent).",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"ci1t-openclaw v{__version__}",
    )

    return parser


async def run(args: argparse.Namespace) -> int:
    """Run the monitor."""
    client = Ci1tClient(api_key=args.api_key, base_url=args.api_url)
    policy = PolicyGate(enabled=args.policy_gating)
    risk_config = RiskConfig()
    monitor = Ci1tMonitor(
        client=client,
        policy=policy,
        agent_name=args.agent_name,
        risk_config=risk_config,
    )

    def _signal_handler(sig, frame):
        print(f"\n  Stopping monitor...")
        monitor.stop()

    signal.signal(signal.SIGINT, _signal_handler)

    await monitor.run_watch(log_path=args.watch)
    return 0


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    log_level = logging.DEBUG if args.debug else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    return asyncio.run(run(args))


if __name__ == "__main__":
    sys.exit(main())
