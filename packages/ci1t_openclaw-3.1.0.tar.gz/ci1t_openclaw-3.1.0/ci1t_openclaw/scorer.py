"""Config-driven action scorer.

Converts OpenClaw action types to Q0.16 scores (0-65535) via a
configurable risk map. This is a simple lookup table -- the temporal
analysis (what CI-1T does with the sequence) is where the real
intelligence lives.

    Score range: 0-65535 (Q0.16 fixed-point)
    0     = completely safe / expected
    32768 = borderline / uncertain
    65535 = completely unsafe / unexpected
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any

from .client import Q16_MAX

# -- Risk Config: action_type -> risk float --

DEFAULT_RISK_MAP: dict[str, float] = {
    # File operations (generally low risk)
    "file_read": 0.05,
    "file_write": 0.25,
    "search": 0.05,
    "delete_file": 0.40,

    # Execution (moderate risk)
    "terminal_exec": 0.50,
    "bash_execute": 0.50,

    # Web / API (moderate risk)
    "web_browse": 0.20,
    "api_call": 0.30,

    # Messaging (moderate-high risk)
    "message": 0.40,

    # Agent management (high risk)
    "spawn_agent": 0.60,

    # Package management (moderate-high risk)
    "install_package": 0.45,

    # System config (high risk)
    "config_modify": 0.65,

    # Dangerous escalations (very high risk)
    "credential_access": 0.90,
    "self_modify": 0.90,
    "permission_change": 0.85,
    "external_upload": 0.90,

    # Unknown actions (uncertain = moderate)
    "unknown": 0.50,
}

# Flat boost added when hook.py flags an action as escalation
ESCALATION_BOOST = 0.25


@dataclass
class RiskConfig:
    """User-configurable risk mapping for action types.

    Supply your own overrides or load from a dict. Actions not
    in the map fall through to DEFAULT_RISK_MAP, then to 'unknown'.
    """
    risk_map: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_RISK_MAP))
    escalation_boost: float = ESCALATION_BOOST

    def score(self, action_type: str, is_escalation: bool = False) -> int:
        """Convert an action type to a Q0.16 score.

        Args:
            action_type: From hook.py's AgentAction.action_type.
            is_escalation: Whether hook.py flagged this as dangerous.

        Returns:
            u16 integer (0-65535).
        """
        base = self.risk_map.get(action_type, self.risk_map.get("unknown", 0.50))

        if is_escalation:
            base = min(1.0, base + self.escalation_boost)

        # Add a tiny bit of natural jitter so the engine doesn't
        # see perfectly identical scores, which would look like a ghost
        jitter = random.uniform(-0.02, 0.02)
        base = max(0.0, min(1.0, base + jitter))

        return int(base * Q16_MAX)

    @classmethod
    def from_dict(cls, overrides: dict[str, float], **kwargs: Any) -> RiskConfig:
        """Create a config with custom risk overrides merged onto defaults."""
        merged = dict(DEFAULT_RISK_MAP)
        merged.update(overrides)
        return cls(risk_map=merged, **kwargs)

