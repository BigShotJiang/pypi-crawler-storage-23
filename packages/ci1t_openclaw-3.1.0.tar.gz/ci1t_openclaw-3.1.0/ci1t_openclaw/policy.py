"""Authority Level policy gating — the on/off switch.

When ENABLED, enforces CI-1T authority levels on agent actions:
    AL 0-1: Full trust — no intervention
    AL 2:   Warning — logged, agent notified
    AL 3:   Gate — high-risk actions held for human confirmation
    AL 4:   Block — agent fully stopped

When DISABLED (default), monitor-only mode: logs everything but blocks nothing.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

logger = logging.getLogger("ci1t-openclaw.policy")

# ── Authority level descriptions ──

AL_DESCRIPTIONS: dict[int, str] = {
    0: "Full trust",
    1: "High trust",
    2: "Moderate trust — warnings active",
    3: "Low trust — gating active",
    4: "No authority — blocked",
    7: "Fault — engine error",
}


class PolicyDecision(Enum):
    """What happens to an agent action based on its AL."""
    ALLOW = "allow"           # Action proceeds normally
    WARN = "warn"             # Action proceeds, warning logged
    GATE = "gate"             # Action held for human confirmation
    BLOCK = "block"           # Action rejected entirely


@dataclass
class PolicyResult:
    """Result of a policy check for one agent."""
    agent_name: str
    al_level: int
    ci_raw: int                   # Q0.16
    ci_ema: int                   # Q0.16
    decision: PolicyDecision
    ghost_suspect: bool = False
    ghost_confirmed: bool = False
    message: str = ""

    @property
    def ci_normalized(self) -> float:
        """CI as a 0.0–1.0 float."""
        return self.ci_raw / 65535.0

    @property
    def ci_ema_normalized(self) -> float:
        """CI EMA as a 0.0–1.0 float."""
        return self.ci_ema / 65535.0


class PolicyGate:
    """Enforces or monitors Authority Level policy for OpenClaw agents.

    The core switch: enabled=True enforces AL gating, enabled=False is monitor-only.
    """

    def __init__(self, enabled: bool = False) -> None:
        self.enabled = enabled
        self._history: list[PolicyResult] = []

    @property
    def mode(self) -> str:
        return "ENFORCE" if self.enabled else "MONITOR"

    def toggle(self) -> bool:
        """Toggle policy gating on/off. Returns new state."""
        self.enabled = not self.enabled
        logger.info("Policy gating %s", "ENABLED" if self.enabled else "DISABLED")
        return self.enabled

    def check(self, agent_name: str, episode: dict[str, Any]) -> PolicyResult:
        """Evaluate a CI-1T episode result and decide what to do.

        Args:
            agent_name: Human-readable agent identifier.
            episode: CI-1T episode output dict with ci_out, ci_ema_out, al_out, etc.

        Returns:
            PolicyResult with the decision (allow/warn/gate/block).
        """
        al = episode.get("al_out", 0)
        ci_raw = episode.get("ci_out", 0)
        ci_ema = episode.get("ci_ema_out", 0)
        ghost_suspect = episode.get("ghost_suspect", False)
        ghost_confirmed = episode.get("ghost_confirmed", False)

        # Determine decision based on AL
        if self.enabled:
            decision = self._enforce(al, ghost_confirmed)
        else:
            decision = PolicyDecision.ALLOW  # monitor-only

        # Build message
        al_desc = AL_DESCRIPTIONS.get(al, f"Unknown AL={al}")
        message = self._build_message(agent_name, al, al_desc, decision, ghost_suspect, ghost_confirmed)

        result = PolicyResult(
            agent_name=agent_name,
            al_level=al,
            ci_raw=ci_raw,
            ci_ema=ci_ema,
            decision=decision,
            ghost_suspect=ghost_suspect,
            ghost_confirmed=ghost_confirmed,
            message=message,
        )

        # Log
        log_level = {
            PolicyDecision.ALLOW: logging.DEBUG,
            PolicyDecision.WARN: logging.WARNING,
            PolicyDecision.GATE: logging.WARNING,
            PolicyDecision.BLOCK: logging.ERROR,
        }[decision]
        logger.log(log_level, message)

        # Track history (bounded)
        self._history.append(result)
        if len(self._history) > 1000:
            self._history = self._history[-500:]

        return result

    def check_fleet(self, node_results: list[dict[str, Any]], agent_names: list[str]) -> list[PolicyResult]:
        """Evaluate an entire fleet round.

        Args:
            node_results: Per-node result dicts from CI-1T fleet response.
            agent_names: Agent names matching node order.

        Returns:
            List of PolicyResult, one per agent.
        """
        results: list[PolicyResult] = []
        for i, node in enumerate(node_results):
            name = agent_names[i] if i < len(agent_names) else f"agent-{i}"
            result = self.check(name, node)
            results.append(result)
        return results

    @staticmethod
    def _enforce(al: int, ghost_confirmed: bool) -> PolicyDecision:
        """Map AL + ghost status to a policy decision."""
        # Confirmed ghost is always gated regardless of AL
        if ghost_confirmed:
            return PolicyDecision.BLOCK

        if al <= 1:
            return PolicyDecision.ALLOW
        elif al == 2:
            return PolicyDecision.WARN
        elif al == 3:
            return PolicyDecision.GATE
        else:  # AL 4+
            return PolicyDecision.BLOCK

    @staticmethod
    def _build_message(
        agent_name: str, al: int, al_desc: str,
        decision: PolicyDecision, ghost_suspect: bool, ghost_confirmed: bool
    ) -> str:
        parts = [f"[{agent_name}] AL={al} ({al_desc}) → {decision.value.upper()}"]

        if ghost_confirmed:
            parts.append("GHOST CONFIRMED — agent producing suspiciously consistent outputs")
        elif ghost_suspect:
            parts.append("ghost suspect — monitoring closely")

        return " | ".join(parts)

    @property
    def history(self) -> list[PolicyResult]:
        """Full bounded policy decision history."""
        return self._history

    @property
    def recent_history(self) -> list[PolicyResult]:
        """Last 20 policy decisions."""
        return self._history[-20:]
