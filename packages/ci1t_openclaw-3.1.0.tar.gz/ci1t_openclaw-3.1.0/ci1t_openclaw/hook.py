"""Real-time OpenClaw action hook — watches gateway logs and classifies agent actions.

Parses OpenClaw gateway logs into AgentAction objects for downstream processing.
Scoring is NOT done here — that's the user's responsibility (or use /evaluate).

Flow:
1. Tails the OpenClaw gateway verbose log (or watches workspace dir)
2. Parses tool calls from the event stream
3. Classifies each action into an AgentAction with type and escalation flag
4. Yields actions for external scoring and policy enforcement

Supported log formats:

1. Console verbose (captured by `script` PTY wrapper):
    11:55:09 [agent/embedded] tool_use: read {path: "/foo"}
    11:55:09 [ws] → event agent ... tool=read
    11:55:09 [agent/embedded] embedded run start: runId=abc sessionId=stress-test-1

2. Structured JSON (/tmp/openclaw/openclaw-YYYY-MM-DD.log):
    {"0": "tool invocation: read", "_meta": {"logLevelName": "INFO"}, "time": "2026-03-03T..."}

3. Legacy structured format (if present):
    [2026-03-03T10:15:32.123Z] [session:main] tool:bash {command: "ls -la"}

Actions are classified into types (file_read, bash_execute, etc.) and flagged
for escalation if they match dangerous patterns.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator

logger = logging.getLogger("ci1t-openclaw.hook")


@dataclass
class AgentAction:
    """A classified agent action from log parsing."""
    action_type: str
    target: str = ""
    is_escalation: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

# ── OpenClaw tool → scorer action type mapping ──

TOOL_ACTION_MAP: dict[str, str] = {
    # Shell / process
    "bash": "terminal_exec",
    "system.run": "terminal_exec",
    "shell": "terminal_exec",
    "exec": "terminal_exec",
    "process": "terminal_exec",
    "command": "terminal_exec",
    "spawn": "spawn_agent",

    # File operations
    "file_read": "file_read",
    "file_write": "file_write",
    "file_edit": "file_write",
    "file_delete": "delete_file",
    "file_move": "file_write",
    "file_copy": "file_write",
    "file_search": "search",
    "read": "file_read",
    "write": "file_write",
    "edit": "file_write",
    "delete": "delete_file",
    "glob": "search",
    "grep": "search",
    "search": "search",

    # Browser / web
    "browser": "web_browse",
    "browser.navigate": "web_browse",
    "browser.click": "web_browse",
    "browser.type": "web_browse",
    "browser.screenshot": "web_browse",
    "browser.fetch": "web_browse",
    "navigate": "web_browse",
    "web_search": "search",
    "web_fetch": "api_call",
    "fetch": "api_call",

    # Messaging
    "send_message": "message",
    "send_email": "message",
    "message": "message",
    "message_send": "message",
    "tts": "message",

    # Session / agent management
    "sessions_create": "spawn_agent",
    "sessions_list": "search",
    "sessions_send": "message",
    "sessions_spawn": "spawn_agent",
    "sessions_history": "search",
    "session_status": "search",
    "agents_list": "search",
    "subagents": "spawn_agent",

    # Memory
    "memory_search": "search",
    "memory_get": "file_read",

    # Canvas / UI
    "canvas": "file_write",
    "nodes": "api_call",

    # Cron / scheduling
    "cron": "config_modify",
    "cron.create": "config_modify",
    "cron.list": "search",
    "cron.delete": "config_modify",
    "cron_create": "config_modify",
    "cron_delete": "config_modify",

    # System / gateway
    "gateway": "config_modify",

    # Package management
    "pip_install": "install_package",
    "npm_install": "install_package",
    "apt_install": "install_package",
}

# Patterns that indicate dangerous target content
DANGEROUS_PATTERNS: list[tuple[str, str]] = [
    # Credential access
    (r"\.env|\.key|\.pem|\.secret|password|credential|token|api.?key|oauth", "credential_access"),
    # Self-modification
    (r"openclaw\.json|SKILL\.md|SOUL\.md|AGENTS\.md|TOOLS\.md", "self_modify"),
    # Permission escalation
    (r"chmod|chown|sudo|su\b|visudo|/etc/passwd|/etc/shadow", "permission_change"),
    # Data exfiltration
    (r"curl.*-X\s*POST|wget.*--post|nc\b.*-e|base64.*\|", "external_upload"),
    # Config modification
    (r"~/.ssh|~/.gnupg|~/.config|/etc/", "config_modify"),
]

# Spam detection: message-type actions within a time window
SPAM_WINDOW_SECS = 30
SPAM_THRESHOLD = 5  # >5 messages in 30 seconds = spam indicator


@dataclass
class ParsedToolCall:
    """A parsed tool call from OpenClaw gateway logs."""
    timestamp: str
    session: str
    tool: str
    args: dict[str, str]
    raw_line: str


@dataclass
class HookState:
    """Shared state for the action hook."""
    # Recent message timestamps for spam detection
    message_times: list[float] = field(default_factory=list)
    # Task scope tracking (what was the original request)
    task_scope: str = ""
    # Total actions seen
    action_count: int = 0
    # Actions blocked by policy
    blocked_count: int = 0


# ── Log parsing ──

# Pattern 1: Original expected format
# [timestamp] [session:name] tool:name {args}
LOG_PATTERN = re.compile(
    r"\[([^\]]+)\]\s+"           # timestamp
    r"\[session:([^\]]+)\]\s+"   # session name
    r"tool:(\S+)\s+"             # tool name
    r"(\{.*\})?",                # optional JSON args
    re.DOTALL,
)

# Pattern 2: OpenClaw console verbose format (captured by script PTY)
# HH:MM:SS [agent/embedded] tool_use: read {path: "/foo"}
# HH:MM:SS [agent/embedded] tool invocation: exec(command: "ls -la")
# The gateway logs tool calls in various formats depending on version
CONSOLE_TOOL_PATTERN = re.compile(
    r"(\d{2}:\d{2}:\d{2})\s+"                       # HH:MM:SS timestamp
    r"\[([^\]]+)\]\s+"                                # [subsystem]
    r"(?:tool[_\s]?(?:use|call|invocation|invoke)?:?\s*)"  # tool prefix
    r"(\w+)"                                          # tool name
    r"(?:\s*\(([^)]*)\))?"                            # optional (args)
    r"(?:\s*(\{.*\}))?",                              # optional {json_args}
    re.IGNORECASE | re.DOTALL,
)

# Pattern 3: OpenClaw gateway event format — tool calls appear in agent events
# HH:MM:SS [ws] → event agent ... stream=tool aseq=N tool=read
CONSOLE_EVENT_PATTERN = re.compile(
    r"(\d{2}:\d{2}:\d{2})\s+"                   # HH:MM:SS
    r"\[([^\]]*)\]\s+"                           # [subsystem]
    r".*?"                                       # any text
    r"(?:tool[=:](\w+)|"                         # tool=name or
    r"stream=tool\b.*?name=(\w+))",              # stream=tool...name=tool
    re.IGNORECASE,
)

# Pattern 4: Generic action detection — catches any line that indicates
# an agent action was performed (read, write, exec, browse, message etc.)
CONSOLE_ACTION_PATTERN = re.compile(
    r"(\d{2}:\d{2}:\d{2})\s+"                   # HH:MM:SS
    r"\[([^\]]+)\]\s+"                           # [subsystem]
    r".*?"                                       # prefix
    r"(?:"
    r"(?:file[_\s])?(?:read|write|edit|delete|search|glob|grep)\b"  # file ops
    r"|(?:exec|bash|shell|command|spawn)\b"      # execution
    r"|(?:browser|navigate|fetch|web_search)\b"  # web ops
    r"|(?:send_message|message\.send)\b"         # messaging
    r"|(?:sessions?_?(?:create|send|spawn))\b"   # session ops
    r"|(?:cron\.(?:create|delete))\b"            # cron ops
    r"|(?:pip_install|npm_install|apt_install)\b" # installs
    r")"
    r".*?"
    r"(?:path=([^\s,]+)|command=([^\s,]+)|url=([^\s,]+)|to=([^\s,]+)|"
    r"target=([^\s,]+)|file=([^\s,]+))?",        # optional target
    re.IGNORECASE,
)


def parse_log_line(line: str) -> ParsedToolCall | None:
    """Parse a single gateway log line into a ParsedToolCall, or None if not actionable.

    Supports multiple log formats:
    1. Original structured format: [ts] [session:main] tool:read {path: ...}
    2. Console verbose format: HH:MM:SS [agent/embedded] tool_use: read ...
    3. Event format: HH:MM:SS [ws] → event agent ... tool=read
    4. Generic action detection: HH:MM:SS [subsystem] ... read path=... 
    """
    line = line.strip()
    if not line:
        return None

    # Strip ANSI escape codes for parsing
    clean = re.sub(r'\x1b\[[0-9;]*m', '', line)

    # Skip result/diagnostic lines that aren't tool invocations
    if any(skip in clean for skip in [
        "tool_result:", "result:", "diagnostic", "lane enqueue",
        "lane dequeue", "lane task done", "session state:",
        "run registered:", "run cleared:"
    ]):
        return None

    # Try Pattern 1: Original structured format
    if "tool:" in clean and "session:" in clean:
        match = LOG_PATTERN.match(clean)
        if match:
            timestamp, session, tool, args_str = match.groups()
            args = {}
            if args_str:
                try:
                    args = json.loads(args_str)
                except json.JSONDecodeError:
                    args = {"raw": args_str}
            return ParsedToolCall(
                timestamp=timestamp,
                session=session,
                tool=tool,
                args=args if isinstance(args, dict) else {"raw": str(args)},
                raw_line=line,
            )

    # Try Pattern 2: Console tool_use format
    match = CONSOLE_TOOL_PATTERN.match(clean)
    if match:
        timestamp, subsystem, tool, paren_args, json_args = match.groups()
        args = {}
        if json_args:
            try:
                args = json.loads(json_args)
            except json.JSONDecodeError:
                args = {"raw": json_args}
        elif paren_args:
            # Parse key=value pairs from parenthesized args
            for kv in paren_args.split(","):
                kv = kv.strip()
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    args[k.strip()] = v.strip().strip('"\'')
                elif ":" in kv:
                    k, v = kv.split(":", 1)
                    args[k.strip()] = v.strip().strip('"\'')
        # Derive session from subsystem or default to "main"
        session = "main"
        if "session:" in subsystem.lower():
            session = subsystem.split("session:")[-1].split("]")[0].strip()
        return ParsedToolCall(
            timestamp=timestamp,
            session=session,
            tool=tool,
            args=args,
            raw_line=line,
        )

    # Try Pattern 3: Tool in event stream
    match = CONSOLE_EVENT_PATTERN.search(clean)
    if match:
        timestamp, subsystem = match.group(1), match.group(2)
        tool = match.group(3) or match.group(4)
        if tool:
            return ParsedToolCall(
                timestamp=timestamp,
                session="main",
                tool=tool,
                args={},
                raw_line=line,
            )

    # Try Pattern 4: Generic action detection (broadest pattern)
    match = CONSOLE_ACTION_PATTERN.search(clean)
    if match:
        timestamp, subsystem = match.group(1), match.group(2)
        # Don't parse from ws/diagnostic subsystems (those are system events)
        if subsystem.startswith(("agent", "embedded", "session")):
            # Extract the action verb from the match
            action_part = clean[match.start():match.end()]
            # Find first known action keyword
            for keyword in ["read", "write", "edit", "delete", "exec", "bash",
                            "shell", "browse", "navigate", "fetch", "web_search",
                            "send_message", "message.send", "sessions_create",
                            "sessions_send", "sessions_spawn", "cron.create",
                            "pip_install", "npm_install", "search", "glob", "grep"]:
                if keyword in action_part.lower():
                    # Get target from named groups
                    target = ""
                    for g in match.groups()[2:]:  # skip timestamp + subsystem
                        if g:
                            target = g
                            break
                    return ParsedToolCall(
                        timestamp=timestamp,
                        session="main",
                        tool=keyword.replace(".", "_"),
                        args={"raw": target} if target else {},
                        raw_line=line,
                    )

    return None


def parse_json_log_line(line: str) -> ParsedToolCall | None:
    """Parse a structured JSON log line from /tmp/openclaw/openclaw-YYYY-MM-DD.log.

    Real OpenClaw format uses numbered fields:
      "0": subsystem JSON string (e.g. '{"subsystem":"agent/tool"}')
      "1": message string OR data object
      "2": message string (when "1" is a data object)

    Tool calls appear in string message fields with tool names.
    """
    line = line.strip()
    if not line or not line.startswith("{"):
        return None

    try:
        entry = json.loads(line)
    except json.JSONDecodeError:
        return None

    # Extract message from numbered fields (OpenClaw uses "0", "1", "2", ...)
    # "0" is usually the subsystem; message is in "1" or "2"
    message = ""
    for key in ("1", "2", "3", "0"):
        val = entry.get(key, "")
        if isinstance(val, str) and len(val) > 5:
            # Skip subsystem JSON like '{"subsystem":"gateway"}'
            if val.strip().startswith('{"subsystem"'):
                continue
            message = val
            break

    if not message:
        return None

    meta = entry.get("_meta", {})
    timestamp = entry.get("time", "")

    # Known tool names from OpenClaw
    known_tools = {
        "read", "write", "edit", "exec", "process", "browser", "canvas",
        "nodes", "cron", "message", "tts", "gateway", "agents_list",
        "sessions_list", "sessions_history", "sessions_send", "sessions_spawn",
        "subagents", "session_status", "web_search", "web_fetch",
        "memory_search", "memory_get", "bash", "shell", "fetch",
        "send_message", "file_read", "file_write", "file_edit", "glob", "grep",
    }

    # Look for tool references in the message
    msg_lower = message.lower()

    # Check for explicit tool invocation patterns
    for pattern in [
        r"tool[_\s]?(?:use|call|invocation|invoke)?:?\s*(\w+)",
        r"invoking\s+(\w+)",
        r"calling\s+tool\s+(\w+)",
        r"tool=(\w+)",
    ]:
        match = re.search(pattern, msg_lower)
        if match:
            tool_name = match.group(1)
            if tool_name in known_tools or tool_name in TOOL_ACTION_MAP:
                # Try to extract JSON args from the message
                args: dict = {"message": message}
                json_match = re.search(r"\{.*\}", message)
                if json_match:
                    try:
                        parsed_args = json.loads(json_match.group())
                        args.update(parsed_args)
                    except json.JSONDecodeError:
                        pass
                return ParsedToolCall(
                    timestamp=timestamp[:19] if len(timestamp) > 19 else timestamp,
                    session="main",
                    tool=tool_name,
                    args=args,
                    raw_line=line,
                )

    return None


def classify_tool_call(call: ParsedToolCall) -> AgentAction:
    """Convert a parsed tool call into a classified AgentAction."""
    # Map tool name to action type
    action_type = TOOL_ACTION_MAP.get(call.tool, "unknown")

    # Build target string for pattern matching
    target_parts = []
    for key in ("command", "cmd", "path", "file", "url", "to", "channel"):
        if key in call.args:
            target_parts.append(str(call.args[key]))
    target = " ".join(target_parts) if target_parts else call.args.get("raw", "")

    # Check for dangerous patterns in target
    is_escalation = False
    for pattern, escalated_type in DANGEROUS_PATTERNS:
        if re.search(pattern, target, re.IGNORECASE):
            action_type = escalated_type
            is_escalation = True
            logger.warning(
                "Dangerous pattern detected in %s: %s → %s",
                call.tool, pattern, escalated_type,
            )
            break

    return AgentAction(
        action_type=action_type,
        target=target,
        is_escalation=is_escalation,
        metadata={
            "tool": call.tool,
            "session": call.session,
            "timestamp": call.timestamp,
            "args": call.args,
        },
    )


# ── Log tailing ──

async def tail_log(
    log_path: str | Path,
    poll_interval: float = 0.2,
    start_offset: int | None = None,
) -> AsyncIterator[str]:
    """Async generator that tails a log file, yielding new lines as they appear.

    Similar to `tail -f` but async and cross-platform.

    Args:
        log_path: Path to the log file.
        poll_interval: Seconds between read attempts when no new data.
        start_offset: Byte offset to start reading from. If None, seeks to end.
            Use 0 to read from beginning, or pass a saved file position.
    """
    path = Path(log_path)

    # Wait for file to exist
    while not path.exists():
        logger.debug("Waiting for log file: %s", path)
        await asyncio.sleep(1.0)

    logger.info("Tailing log file: %s (offset=%s)", path, start_offset)

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        if start_offset is not None:
            f.seek(start_offset)
        else:
            # Seek to end (we only want new lines)
            f.seek(0, 2)

        while True:
            line = f.readline()
            if line:
                yield line
            else:
                await asyncio.sleep(poll_interval)


async def watch_actions(
    log_path: str | Path,
    state: HookState,
    start_offset: int | None = None,
) -> AsyncIterator[AgentAction]:
    """Watch OpenClaw gateway log and yield classified AgentAction objects.

    Parses tool calls from the log and classifies them into action types.
    Does NOT score them — that's the caller's responsibility (or use
    CI-1T's /evaluate endpoint with your own scoring).

    Args:
        log_path: Path to the gateway log file.
        state: Shared hook state for spam detection.
        start_offset: Byte offset to start reading from. If None, reads from end.
    """
    async for line in tail_log(log_path, start_offset=start_offset):
        call = parse_log_line(line)
        # Fallback: try JSON structured format
        if call is None:
            call = parse_json_log_line(line)
        if call is None:
            continue

        # Classify the tool call
        action = classify_tool_call(call)

        # Spam detection for message-type actions
        if action.action_type == "message":
            now = time.monotonic()
            state.message_times.append(now)
            # Clean old entries
            state.message_times = [
                t for t in state.message_times
                if now - t < SPAM_WINDOW_SECS
            ]
            if len(state.message_times) > SPAM_THRESHOLD:
                logger.warning(
                    "SPAM DETECTED: %d messages in %ds window (session: %s)",
                    len(state.message_times), SPAM_WINDOW_SECS, call.session,
                )
                action.action_type = "external_upload"
                action.is_escalation = True

        state.action_count += 1

        logger.debug(
            "Action #%d [%s] %s → %s",
            state.action_count,
            call.session,
            call.tool,
            action.action_type,
        )

        yield action
