"""Core monitoring loop -- watches OpenClaw gateway logs via CI-1T fleet sessions.

Flow:
    hook.py tails gateway log -> action classified -> risk config -> u16 score
    -> fleet_session_round() -> CI/AL/ghost -> PolicyGate -> ALLOW/WARN/GATE/BLOCK
"""

from __future__ import annotations

import asyncio
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .client import Ci1tClient, Q16_MAX
from .hook import AgentAction, HookState, watch_actions
from .policy import PolicyDecision, PolicyGate, PolicyResult
from .scorer import RiskConfig

logger = logging.getLogger("ci1t-openclaw.monitor")

# Fix Windows console encoding (cp1252 can't handle box-drawing chars)
if sys.stdout.encoding and sys.stdout.encoding.lower().startswith("cp"):
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

# Force unbuffered output so terminal sees prints immediately
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:
        pass

# -- ANSI colors for terminal output --

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
MAGENTA = "\033[95m"
CYAN = "\033[96m"
WHITE = "\033[97m"

AL_COLORS: dict[int, str] = {
    0: GREEN,
    1: GREEN,
    2: YELLOW,
    3: RED,
    4: f"{RED}{BOLD}",
    7: MAGENTA,
}


def _ci_bar(ci_norm: float, width: int = 20) -> str:
    """Render a text-based CI gauge bar."""
    filled = int(ci_norm * width)
    filled = max(0, min(width, filled))
    empty = width - filled

    if ci_norm < 0.15:
        color = GREEN
    elif ci_norm < 0.45:
        color = YELLOW
    elif ci_norm < 0.70:
        color = RED
    else:
        color = f"{RED}{BOLD}"

    return f"{color}{'#' * filled}{DIM}{'.' * empty}{RESET}"


def _al_badge(al: int) -> str:
    """Render an AL badge with color."""
    color = AL_COLORS.get(al, WHITE)
    return f"{color}AL{al}{RESET}"


def _ghost_badge(suspect: bool, confirmed: bool) -> str:
    """Render ghost status badge."""
    if confirmed:
        return f"{MAGENTA}{BOLD}GHOST{RESET}"
    elif suspect:
        return f"{MAGENTA}ghost?{RESET}"
    return f"{DIM}clean{RESET}"


def _decision_badge(decision: PolicyDecision) -> str:
    """Render policy decision badge."""
    badges = {
        PolicyDecision.ALLOW: f"{GREEN}ALLOW{RESET}",
        PolicyDecision.WARN: f"{YELLOW}WARN{RESET}",
        PolicyDecision.GATE: f"{RED}GATE{RESET}",
        PolicyDecision.BLOCK: f"{RED}{BOLD}BLOCK{RESET}",
    }
    return badges.get(decision, "???")


class Ci1tMonitor:
    """Agent monitor backed by CI-1T fleet sessions.

    Watches a live OpenClaw gateway log, scores actions via RiskConfig,
    pushes to a fleet session, and enforces policy in real-time.
    """

    def __init__(
        self,
        client: Ci1tClient,
        policy: PolicyGate,
        agent_name: str = "openclaw-agent",
        interval: float = 0.5,
        risk_config: RiskConfig | None = None,
    ) -> None:
        self.client = client
        self.policy = policy
        self.agent_name = agent_name
        self.interval = interval
        self.risk_config = risk_config or RiskConfig()
        self._running: bool = False
        self._session_id: str | None = None

    # -- WATCH MODE (fleet sessions, real-time, 1 credit/round) --

    async def run_watch(
        self,
        log_path: str | Path,
        scores_per_round: int = 3,
    ) -> None:
        """Watch a live OpenClaw gateway log and monitor via fleet sessions.

        Flow:
            1. Create a fleet session (1 node)
            2. Tail gateway log -> parse actions -> score via risk config
            3. Every `scores_per_round` actions, push a round to fleet session
            4. Read CI/AL/ghost from response -> enforce PolicyGate

        Args:
            log_path: Path to the OpenClaw gateway log.
            scores_per_round: Actions to batch before each fleet round (3 = 1 episode).
        """
        self._running = True
        round_num = 0
        score_buffer: list[int] = []
        state = HookState()

        # Print header
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        print(f"\n{BOLD}{'=' * 72}{RESET}")
        print(f"{BOLD}{CYAN}  CI-1T Fleet Session -- Live Agent Monitoring{RESET}")
        print(f"{DIM}  {ts}{RESET}")
        print(f"{BOLD}{'=' * 72}{RESET}")
        print(f"  Policy:   {BOLD}{'ENFORCE' if self.policy.enabled else 'MONITOR ONLY'}{RESET}")
        print(f"  Log:      {log_path}")
        print(f"  Agent:    {self.agent_name}")
        print(f"  Batch:    {scores_per_round} actions per round")
        print(f"  API:      {self.client.base_url}")

        # Step 1: Create fleet session
        try:
            session = await self.client.fleet_session_create(
                node_count=1, node_names=[self.agent_name]
            )
            self._session_id = session.get("session_id")
            print(f"  Session:  {self._session_id}")
        except Exception as e:
            print(f"\n  {RED}Failed to create fleet session: {e}{RESET}")
            return

        print(f"\n{DIM}{'-' * 72}{RESET}")
        print(f"  {DIM}Watching gateway log for agent actions...{RESET}\n")

        # Step 2: Tail log -> score -> push
        try:
            async for action in watch_actions(log_path, state, start_offset=0):
                if not self._running:
                    break

                # Score the action via risk config
                score = self.risk_config.score(action.action_type, action.is_escalation)
                score_buffer.append(score)

                risk_pct = score / Q16_MAX * 100
                esc_tag = f" {RED}[ESCALATION]{RESET}" if action.is_escalation else ""
                print(
                    f"  {DIM}#{state.action_count:>4}{RESET} "
                    f"{action.action_type:<20s} "
                    f"-> {risk_pct:5.1f}%{esc_tag}"
                )

                # Push when we have enough for one episode
                if len(score_buffer) >= scores_per_round:
                    round_num += 1
                    try:
                        result = await self.client.fleet_session_round(
                            self._session_id, [score_buffer[:scores_per_round]]
                        )
                        score_buffer = score_buffer[scores_per_round:]

                        snapshot = result.get("snapshot", result)
                        nodes = snapshot.get("nodes", [])
                        if nodes:
                            node = nodes[0]
                            ep = {
                                "ci_out": node.get("ci_out", 0),
                                "ci_ema_out": node.get("ci_ema_out", 0),
                                "al_out": node.get("al_out", 0),
                                "ghost_suspect": node.get("ghost_suspect", False),
                                "ghost_confirmed": node.get("ghost_confirmed", False),
                                "warn": node.get("warn", False),
                                "fault": node.get("fault", False),
                            }
                            pr = self.policy.check(self.agent_name, ep)
                            ci_norm = pr.ci_normalized
                            bar = _ci_bar(ci_norm)
                            al = _al_badge(pr.al_level)
                            ghost = _ghost_badge(pr.ghost_suspect, pr.ghost_confirmed)
                            decision = _decision_badge(pr.decision)

                            print(
                                f"  {BOLD}Round {round_num:>3}{RESET} "
                                f"CI={ci_norm:.3f} {bar} "
                                f"{al}  {ghost}  {decision}"
                            )

                            if pr.decision == PolicyDecision.BLOCK:
                                print(f"  {RED}{BOLD}  AGENT BLOCKED -- AL{pr.al_level}{RESET}")
                                if pr.ghost_confirmed:
                                    print(f"  {MAGENTA}  Ghost confirmed -- suspiciously consistent outputs{RESET}")

                    except Exception as e:
                        logger.error("Fleet round failed: %s", e)
                        print(f"  {RED}Round push failed: {e}{RESET}")

        except KeyboardInterrupt:
            pass
        finally:
            # Cleanup: delete session
            if self._session_id:
                print(f"\n  {DIM}Cleaning up fleet session {self._session_id}...{RESET}")
                try:
                    await self.client.fleet_session_delete(self._session_id)
                    print(f"  {DIM}Session deleted.{RESET}")
                except Exception as e:
                    logger.error("Session cleanup failed: %s", e)

            self._print_summary(round_num)
            self._running = False

    def stop(self) -> None:
        """Signal the monitor to stop after the current round."""
        self._running = False

    # -- Terminal output --

    def _print_summary(self, total_rounds: int) -> None:
        """Print final summary."""
        print(f"\n{DIM}{'-' * 72}{RESET}")
        print(f"{BOLD}  Summary -- {total_rounds} rounds{RESET}\n")

        if not self.policy.history:
            print(f"  {DIM}No data collected.{RESET}")
            return

        results = self.policy.history
        last = results[-1]
        recent = results[-5:] if len(results) >= 5 else results
        recent_max_al = max(r.al_level for r in recent)
        avg_ci = sum(r.ci_normalized for r in results) / len(results)
        blocks = sum(1 for r in results if r.decision == PolicyDecision.BLOCK)
        warns = sum(1 for r in results if r.decision == PolicyDecision.WARN)
        ghosts = sum(1 for r in results if r.ghost_confirmed)

        status = f"{GREEN}HEALTHY{RESET}"
        if ghosts > 0:
            status = f"{MAGENTA}{BOLD}GHOST{RESET}"
        elif blocks > len(results) // 3:
            status = f"{RED}{BOLD}BLOCKED{RESET}"
        elif recent_max_al >= 4:
            status = f"{RED}{BOLD}CRITICAL{RESET}"
        elif recent_max_al >= 3:
            status = f"{RED}UNSTABLE{RESET}"
        elif recent_max_al >= 2:
            status = f"{YELLOW}DRIFTING{RESET}"

        print(
            f"  {self.agent_name:<20s} "
            f"status={status}  "
            f"avg_ci={avg_ci:.3f}  "
            f"last_al={last.al_level}  "
            f"blocks={blocks}  warns={warns}  ghosts={ghosts}"
        )

        print(f"\n{DIM}{'=' * 72}{RESET}\n")