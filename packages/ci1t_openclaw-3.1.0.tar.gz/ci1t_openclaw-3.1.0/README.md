# CI-1T OpenClaw Monitor v3.1.0

Real-time stability monitoring for [OpenClaw](https://openclaw.ai) agents, powered by [CI-1T](https://collapseindex.org).

Watches your agent's actions, scores them, and detects drift, rogue behavior, ghost patterns, and prompt injection -- before they cause damage.

Built on the [CI-1T Python SDK](https://github.com/collapseindex/ci1t-sdk) (`ci1t`) for all API communication.

## Setup

```bash
pip install ci1t-openclaw
```

Dependencies: `ci1t` (SDK) and `httpx`. Both installed automatically.

## Get an API Key

Sign up at [collapseindex.org/dashboard](https://collapseindex.org/dashboard). You get 1,000 free credits. Each monitoring round costs 1 credit.

## Run

```bash
# Set your key
export CI1T_API_KEY=ci_YOUR_KEY

# Monitor a live OpenClaw agent
python -m ci1t_openclaw --watch /path/to/gateway.log

# Same, but enforce policy gating (block dangerous agents)
python -m ci1t_openclaw --watch /path/to/gateway.log --policy-gating
```

That's it. The monitor tails the gateway log, scores each tool call, and pushes episodes to CI-1T for temporal analysis.

## What It Detects

| Pattern | What Happens |
|---------|-------------|
| Drift | Agent gradually escalating risk over time |
| Rogue | Sudden dangerous behavior (credential access, self-modification) |
| Ghost | Suspiciously consistent outputs hiding silent failures |
| Injection | Behavioral phase-shift from prompt injection |
| Spam | Rapid-fire identical dangerous actions |

## Policy Gating

Off by default (monitor-only). Add `--policy-gating` to enforce:

| Authority Level | Action |
|----------------|--------|
| AL 0-1 | Allow |
| AL 2 | Warn |
| AL 3 | Gate (hold for human confirmation) |
| AL 4 | Block |

## How It Works

```
Agent tool call -> hook.py (parse) -> RiskConfig (score) -> CI-1T API -> PolicyGate
```

1. `hook.py` tails the gateway log and classifies each tool call
2. `scorer.py` converts action types to risk scores (configurable lookup table)
3. Scores are pushed to a CI-1T fleet session for temporal analysis
4. `policy.py` reads CI/AL/ghost output and decides: allow, warn, gate, or block

## Custom Risk Scoring

Override the default risk map:

```python
from ci1t_openclaw.scorer import RiskConfig

config = RiskConfig.from_dict({
    "bash_execute": 0.70,   # make shell commands riskier
    "file_read": 0.02,      # make reads safer
})
```

## OpenClaw Skill

Install the CI-1T monitor skill so agents are aware of monitoring:

```bash
cp -r skill/ci1t-monitor ~/.openclaw/skills/
```

## CLI Reference

```
python -m ci1t_openclaw --watch LOG_PATH [OPTIONS]

Options:
  --api-key KEY       CI-1T API key (or set CI1T_API_KEY env var)
  --watch LOG_PATH    Path to OpenClaw gateway log (required)
  --policy-gating     Enable AL enforcement (default: off)
  --agent-name NAME   Agent name (default: openclaw-agent)
  --debug             Debug logging
  --version           Show version
```

## Project Structure

```
ci1t-openclaw/
  ci1t_openclaw/
    __main__.py    CLI entry point
    client.py      Async fleet session wrapper (uses ci1t SDK)
    hook.py        Gateway log parser + action classifier
    scorer.py      RiskConfig (action type -> Q0.16 score)
    monitor.py     Watch loop (tail -> score -> push -> enforce)
    policy.py      Authority level policy gate (on/off)
  skill/
    ci1t-monitor/
      SKILL.md     OpenClaw skill (agent reads this)
```

## Relationship to the SDK

This package is the agent-specific monitoring layer. The [ci1t SDK](https://github.com/collapseindex/ci1t-sdk) handles all API communication (auth, Q0.16 conversion, sessions, fleet monitoring). If you need generic stability monitoring without agent-specific tooling, use the SDK directly:

```bash
pip install ci1t-sdk
```

## License

MIT + Commons Clause. Free to use, modify, and integrate. Cannot be resold as a standalone product. See [LICENSE](LICENSE).
