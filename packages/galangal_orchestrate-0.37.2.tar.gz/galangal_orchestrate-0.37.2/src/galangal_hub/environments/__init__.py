"""
Hub-hosted development environments.

Provides repository cloning, credential management, dev server lifecycle,
and local AI agent spawning for browser-based development from anywhere.
"""
