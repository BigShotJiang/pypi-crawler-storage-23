"""Structured logging setup — configures structlog with stdlib integration."""

import logging
import os
import sys
from typing import Optional

import structlog


def setup_logging(
    level: int = logging.INFO,
    log_format: Optional[str] = None,
    module_levels: Optional[dict[str, str]] = None,
) -> None:
    """Configure structlog processors and stdlib logging integration.

    Call once at application startup (in main.py before routes are registered).

    Args:
        level: Global log level.
        log_format: "console" or "json". Overridden by ACTFLARE_LOG_FORMAT env var.
        module_levels: Per-module log level overrides, e.g. {"uvicorn": "WARNING"}.
    """
    fmt = os.environ.get("ACTFLARE_LOG_FORMAT", log_format or "console").lower()

    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    if fmt == "json":
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer()

    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
        foreign_pre_chain=shared_processors,
    )

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)

    # Apply per-module level overrides
    if module_levels:
        for module_name, level_str in module_levels.items():
            numeric_level = getattr(logging, level_str.upper(), logging.INFO)
            logging.getLogger(module_name).setLevel(numeric_level)


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Return a structlog bound logger for the given module name."""
    return structlog.get_logger(name)
