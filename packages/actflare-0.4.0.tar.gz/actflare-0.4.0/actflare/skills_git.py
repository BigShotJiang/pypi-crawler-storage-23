"""Git version control for skills directory — auto-commit after modifications."""

import subprocess
from pathlib import Path
from typing import Optional

from actflare.log import get_logger

logger = get_logger(__name__)

_GIT_AUTHOR = "ActFlare Bot <actflare@localhost>"


def _run_git(skills_dir: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    """Run a git command in the skills directory."""
    cmd = ["git", "-C", str(skills_dir)] + list(args)
    return subprocess.run(cmd, capture_output=True, text=True, check=check, timeout=30)


def ensure_git_repo(skills_dir: Path) -> bool:
    """Initialize git repo in skills dir if not already initialized.

    Returns True if newly initialized. Silently skips if git is not installed.
    """
    git_dir = skills_dir / ".git"
    if git_dir.is_dir():
        return False

    try:
        _run_git(skills_dir, "init")
        _run_git(skills_dir, "config", "user.email", "actflare@localhost")
        _run_git(skills_dir, "config", "user.name", "ActFlare Bot")
        # Create .gitignore for temp files
        gitignore = skills_dir / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("*.tmp\n*.swp\n__pycache__/\n", encoding="utf-8")
        # Initial commit
        _run_git(skills_dir, "add", "-A")
        _run_git(skills_dir, "commit", "-m", "Initial skills snapshot", "--allow-empty",
                 "--author", _GIT_AUTHOR)
        logger.info("Initialized skills git repo", path=str(skills_dir))
        return True
    except FileNotFoundError:
        logger.warning("Git not installed, skipping skills version control")
        return False
    except subprocess.CalledProcessError as e:
        logger.warning("Failed to initialize skills git repo", error=str(e))
        return False


def auto_commit(skills_dir: Path, message: str, author: Optional[str] = None) -> bool:
    """Stage all changes and commit if there are any. Returns True if committed."""
    if not (skills_dir / ".git").is_dir():
        return False

    try:
        _run_git(skills_dir, "add", "-A")
        # Check if there are staged changes
        result = _run_git(skills_dir, "diff", "--cached", "--quiet", check=False)
        if result.returncode == 0:
            return False  # No changes

        author_arg = author or _GIT_AUTHOR
        _run_git(skills_dir, "commit", "-m", message, "--author", author_arg)
        logger.info("Skills auto-committed", message=message)
        return True
    except FileNotFoundError:
        return False
    except subprocess.CalledProcessError as e:
        logger.warning("Skills auto-commit failed", error=str(e))
        return False


def get_log(skills_dir: Path, limit: int = 20) -> list[dict]:
    """Return recent git log entries."""
    if not (skills_dir / ".git").is_dir():
        return []

    try:
        result = _run_git(skills_dir, "log", f"--max-count={limit}",
                          "--format=%H|%ai|%s", check=False)
        if result.returncode != 0:
            return []
        entries = []
        for line in result.stdout.strip().splitlines():
            parts = line.split("|", 2)
            if len(parts) == 3:
                entries.append({"hash": parts[0][:8], "date": parts[1], "message": parts[2]})
        return entries
    except Exception:
        return []
