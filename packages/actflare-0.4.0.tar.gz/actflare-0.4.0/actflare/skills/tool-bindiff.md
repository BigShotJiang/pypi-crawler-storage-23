# 差异基因分析（bindiff）

## 工具信息

- **工具名**: bindiff
- **投递模式**: annotask
- **工具路径**: `/path/to/bindiff`（需在部署时配置实际路径）

## 功能说明

差异基因分析工具，支持 SGE 集群并行和本地并行两种模式。用于比较不同条件/分组间的基因表达差异。

## 模式一：SGE 集群并行（qsubsge）

### 资源配置

| 参数 | 默认值 | 说明 |
|------|--------|------|
| cpu | 2 | 每个子任务的 CPU 核数 |
| h_vmem | 8 | 每个子任务的内存上限（GB） |
| line | 2 | 每个子任务包含的输入行数 |

### 命令模板

```bash
annotask qsubsge /path/to/bindiff -i <input_file> -l 2 --cpu 2 --h_vmem 8 --project <task_id>
```

### 输入文件格式

每 2 行为一个子任务（line=2），具体格式由工具定义。

## 模式二：本地并行（local）

### 资源配置

| 参数 | 默认值 | 说明 |
|------|--------|------|
| thread | 4 | 本地并行线程数 |
| line | 1 | 每个子任务包含的输入行数 |

### 命令模板

```bash
annotask local /path/to/bindiff -i <input_file> -l 1 -t 4
```

## 状态查询

```bash
annotask stat -p <task_id>
```

## 使用场景

- 多组差异比较：每个比较对作为一个子任务
- 大样本量项目：利用集群并行加速
- 小规模测试：使用 local 模式在本地执行
