# annotask 投递模式指南

## 概述

annotask 是并行任务执行工具，将多个独立子任务投递到 SGE 集群或本地并行执行。每行输入文件代表一个独立子任务。

## qsubsge 模式（SGE 集群并行）

### 命令格式

```bash
annotask qsubsge <tool_path> -i <input_file> -l <lines_per_task> --cpu <cpu> --h_vmem <memory_gb> [--project <task_id>]
```

### 参数说明

| 参数 | 说明 |
|------|------|
| `<tool_path>` | 工具脚本的绝对路径 |
| `-i` | 输入文件路径（每行一个子任务） |
| `-l` | 每个子任务包含的行数（通常为 1 或 2） |
| `--cpu` | **每个子任务**的 CPU 核数 |
| `--h_vmem` | **每个子任务**的内存上限（GB） |
| `--project` | 任务 ID（可选，用于跟踪） |

**重要**：`--cpu` 和 `--h_vmem` 是每个子任务的资源配置，不是总量。annotask 会将每个子任务作为独立 SGE job 投递。

### 输入文件格式

输入文件每行代表一个独立子任务的参数。例如：

```
/data/sample1/input.fastq.gz /data/sample1/output/
/data/sample2/input.fastq.gz /data/sample2/output/
/data/sample3/input.fastq.gz /data/sample3/output/
```

当用户需要处理 N 个样本时，agent 应：
1. 通过数据库查询或文件系统定位所有样本路径
2. 按工具要求的格式生成输入文件（每行一个子任务）
3. 使用 annotask 批量投递

## local 模式（本地并行）

### 命令格式

```bash
annotask local <tool_path> -i <input_file> -l <lines_per_task> -t <threads>
```

### 参数说明

| 参数 | 说明 |
|------|------|
| `-t` | 本地并行线程数 |

其他参数同 qsubsge 模式。

## 状态查询

```bash
annotask stat -p <task_id>
```

## 使用场景

- 用户请求处理多个样本的同一分析步骤（如 QC、比对、定量）
- 需要将单样本脚本批量应用到项目所有样本
- 需要集群资源进行大规模并行计算
