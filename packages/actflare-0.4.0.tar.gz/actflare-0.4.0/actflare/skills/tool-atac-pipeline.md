# ATAC-seq 全流程分析（atac_pipeline）

## 工具信息

- **工具名**: atac_pipeline
- **投递模式**: annoeva
- **项目类型 (-t)**: atac

## 功能说明

ATAC-seq（包括 10X scATAC、bulk ATAC）的标准分析流水线。包含数据质控、比对、peak calling、差异可及性分析等步骤。

## 使用方法

### 1. 准备元数据

通过数据库查询或用户提供获取：
- 合同号、项目分期号
- 样本列表及对应的过滤数据路径

### 2. 准备工作目录

```bash
# 工作目录结构
<workdir>/annoeva/<task_id>/
├── Analysis/
├── info/
│   └── info.xls    # 填写样本信息
└── Filter/
    └── GO.sign     # 过滤数据就绪标记
```

### 3. 投递命令

```bash
annoeva addproject -p <task_id> -t atac -d <workdir>
```

### 4. 状态查询

```bash
annoeva stat -p <task_id>
```

## 数据准备参考

- 过滤数据路径：参考 data_io skill 中的 10XATAC 产品路径
- info.xls 模板：包含样本名、数据路径、分组信息等字段
