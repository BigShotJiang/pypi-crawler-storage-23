# 云存储下载

## 概述

从云端对象存储（如阿里云 OSS）下载数据到本地分析环境。常用于回迁过滤数据或中间结果。

## 前置条件

需要配置 ossutil 工具路径和认证信息（含公司内部地址，不提交到版本控制）。

## 命令模板

```bash
# TODO: 由用户配置实际路径和认证
# ossutil_path=<ossutil 路径>
# config_file=<ossutil 配置文件路径>

# 列出目录
# $ossutil_path --config-file=$config_file ls <oss_path>

# 下载文件
# $ossutil_path --config-file=$config_file cp <oss_path> <local_path> -r
```

## 常用场景

### 下载过滤数据
```bash
# 源路径格式: oss://annoroad-cloud-product/user/project/<合同号>/<项目分期号>/
# TODO: 填写实际 ossutil 路径和配置
```

### 下载分析结果
```bash
# 源路径格式: oss://sci-scv/standard/Commercial/<产品子目录>/<合同号>/<项目分期号>/
# TODO: 填写实际 ossutil 路径和配置
```

## 配置说明

请在首次使用时填写实际的 ossutil 路径和配置文件位置。此文件包含公司内部信息，已被 gitignore。
