"""CLI entry point for ActFlare — uses Click with subcommands."""

import shutil
import subprocess
import sys
from pathlib import Path

import click

from actflare.config import DEFAULT_CONFIG_PATH


def _find_example_config() -> Path:
    """Locate config.example.yml shipped with the package or in the repo root."""
    pkg_dir = Path(__file__).resolve().parent
    candidate = pkg_dir / "config.example.yml"
    if candidate.exists():
        return candidate
    repo_root = pkg_dir.parent
    candidate = repo_root / "config.example.yml"
    if candidate.exists():
        return candidate
    raise FileNotFoundError("config.example.yml not found. Reinstall the package.")


def _ensure_config(explicit_path: str | None) -> str | None:
    """Ensure a config file exists. Auto-creates from template if missing."""
    if explicit_path is not None:
        return explicit_path

    if DEFAULT_CONFIG_PATH.exists():
        return None

    try:
        example = _find_example_config()
        DEFAULT_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(example, DEFAULT_CONFIG_PATH)
        click.echo(f"Config file created at {DEFAULT_CONFIG_PATH}")
        click.echo("Edit it to fill in your channel credentials and Claude CLI path.")
    except FileNotFoundError:
        pass

    return None


@click.group()
def cli():
    """ActFlare — WeChat Work callback service powered by Claude Agent SDK."""


@cli.command()
@click.option("-c", "--config", default=None, help="Path to config.yml")
def server(config):
    """Start the API server."""
    import uvicorn
    from actflare.config import load_config

    config_path = _ensure_config(config)
    cfg = load_config(config_path)

    uvicorn.run("actflare.main:app", host=cfg.server.host, port=cfg.server.port)


@cli.command()
@click.option("-c", "--config", default=None, help="Path to config.yml")
def worker(config):
    """Start the Huey task worker."""
    from actflare.config import load_config

    config_path = _ensure_config(config)
    cfg = load_config(config_path)

    cmd = [
        sys.executable, "-m", "huey.bin.huey_consumer",
        "actflare.tasks.huey_queue",
        "-w", str(cfg.worker.concurrency),
        "-k", cfg.worker.worker_type,
    ]
    sys.exit(subprocess.call(cmd))


@cli.command("status")
@click.argument("task_id")
def status_cmd(task_id):
    """Query the status of a dispatched task."""
    from actflare.config import get_config
    from actflare.task_db import TaskDB

    cfg = get_config()
    task_db = TaskDB(cfg.paths.task_db)
    task = task_db.get_task(task_id)
    if task is None:
        click.echo(f"未找到任务: {task_id}")
        return
    click.echo(f"任务 ID: {task['task_id']}")
    click.echo(f"工具: {task['tool_name']}")
    click.echo(f"后端: {task['backend']}")
    click.echo(f"工作目录: {task['workdir']}")
    click.echo(f"状态: {task['status']}")
    click.echo(f"创建时间: {task['created_at']}")


@cli.command("skills")
def skills_cmd():
    """List loaded skill files."""
    from actflare.skills import ensure_skills_dir, list_skills

    ensure_skills_dir()
    skill_list = list_skills()
    if not skill_list:
        click.echo("No skills found. Add .md files to ~/.config/actflare/skills/")
        return

    click.echo(f"{'文件名':<28} {'来源':<10} {'标题'}")
    click.echo("-" * 78)
    for s in skill_list:
        click.echo(f"{s['name']:<28} {s['source']:<10} {s['title']}")


@cli.command("skills-log")
@click.option("--limit", default=20, help="Number of log entries to show")
def skills_log_cmd(limit):
    """Show skills version history (git log)."""
    from actflare.skills import _default_skills_dir
    from actflare.skills_git import get_log

    entries = get_log(_default_skills_dir(), limit)
    if not entries:
        click.echo("无 Git 历史记录（skills 目录可能尚未初始化 Git）。")
        return

    for e in entries:
        click.echo(f"  {e['hash']}  {e['date']}  {e['message']}")


@cli.command("distill")
@click.option("-c", "--config", default=None, help="Path to config.yml")
@click.option("--min-feedback", default=0.5, help="Minimum feedback score to include")
@click.option("--limit", default=50, help="Max cases to analyze")
@click.option("--ai-summarize/--no-ai-summarize", default=True, help="Use Claude to summarize clusters")
def distill_cmd(config, min_feedback, limit, ai_summarize):
    """Distill high-quality memory cases into skill drafts."""
    import asyncio
    from collections import defaultdict
    from datetime import datetime

    from actflare.config import DEFAULT_CONFIG_DIR, load_config
    from actflare.memory import MemoryStore

    config_path = _ensure_config(config)
    cfg = load_config(config_path)
    memory = MemoryStore(cfg.paths.memory_db)

    stats = memory.get_stats()
    click.echo(f"记忆库统计: 总案例={stats['total_cases']}, 平均评分={stats['avg_feedback']}, 已隔离={stats['error_isolated']}")

    cases = memory.top_cases(min_feedback=min_feedback, limit=limit)
    if not cases:
        click.echo(f"未找到评分 >= {min_feedback} 的高质量案例。")
        return

    click.echo(f"找到 {len(cases)} 条高质量案例，按关键词聚类...")
    if ai_summarize:
        click.echo("已启用 AI 总结 (--ai-summarize)，每个聚类将使用 Claude 提炼通用规律。")

    # Group cases by overlapping keywords
    clusters: defaultdict[str, list[dict]] = defaultdict(list)
    for case in cases:
        kws = case["keywords"].split()[:3]
        cluster_key = " ".join(sorted(kws)) if kws else "其他"
        clusters[cluster_key].append(case)

    # Write drafts
    drafts_dir = DEFAULT_CONFIG_DIR / "skills" / "drafts"
    drafts_dir.mkdir(parents=True, exist_ok=True)

    date_str = datetime.now().strftime("%Y%m%d")
    draft_count = 0
    for cluster_key, cluster_cases in clusters.items():
        if len(cluster_cases) < 2:
            continue  # Skip singleton clusters

        draft_name = f"draft_{date_str}_{cluster_key.replace(' ', '_')[:30]}.md"
        draft_path = drafts_dir / draft_name

        # 构建案例文本
        case_lines = []
        for i, c in enumerate(cluster_cases, 1):
            case_lines.append(f"### 案例 {i} (评分: {c['feedback_score']}, 轮次: {c['turns_used']})")
            case_lines.append(f"**问题**: {c['query']}")
            case_lines.append(f"**解决方案**: {c['answer'][:500]}")
            case_lines.append("")
        cases_text = "\n".join(case_lines)

        # 尝试 AI 总结
        ai_summary = ""
        if ai_summarize:
            click.echo(f"  正在总结聚类: {cluster_key} ...")
            try:
                from actflare.tasks import DISTILL_PROMPT_TEMPLATE, DISTILL_TIMEOUT

                async def _cli_summarize() -> str:
                    from actflare.agent import run_claude_agent

                    prompt = DISTILL_PROMPT_TEMPLATE.format(cluster_key=cluster_key, cases_text=cases_text)
                    result_text, _ = await asyncio.wait_for(
                        run_claude_agent(prompt),
                        timeout=DISTILL_TIMEOUT,
                    )
                    return result_text.strip() if result_text else ""

                ai_summary = asyncio.run(_cli_summarize())
            except Exception as exc:
                click.echo(f"  AI 总结失败 ({exc})，退化为模板格式。")

        # 构建草稿内容
        lines = [
            f"# 知识草稿: {cluster_key}",
            "",
            f"> 自动提炼自 {len(cluster_cases)} 条高质量案例 ({date_str})",
            f"> 审核后请移动到 ~/.config/actflare/skills/ 正式目录",
            "",
        ]

        if ai_summary:
            lines.append("## 通用规律")
            lines.append("")
            lines.append(ai_summary)
            lines.append("")
            lines.append("## 原始案例参考")
            lines.append("")
            lines.append(cases_text)
        else:
            lines.append("## 案例汇总")
            lines.append("")
            lines.append(cases_text)
            lines.append("## 待提炼的通用规律")
            lines.append("")
            lines.append("<!-- 请根据上述案例总结通用规律，然后删除案例部分 -->")
            lines.append("")

        draft_path.write_text("\n".join(lines), encoding="utf-8")
        draft_count += 1
        click.echo(f"  生成草稿: {draft_path}")

    click.echo(f"\n共生成 {draft_count} 份草稿，保存在 {drafts_dir}")
    click.echo("请审核后将有价值的草稿移动到 ~/.config/actflare/skills/ 目录。")

    # 自动提交到 git
    if draft_count:
        from actflare.skills_git import auto_commit

        committed = auto_commit(DEFAULT_CONFIG_DIR / "skills", f"distill: {draft_count} drafts ({date_str})")
        if committed:
            click.echo("已自动提交到 git。")


@cli.command("memory-stats")
@click.option("-c", "--config", default=None, help="Path to config.yml")
def memory_stats_cmd(config):
    """Show memory system statistics."""
    from actflare.config import load_config
    from actflare.memory import MemoryStore

    config_path = _ensure_config(config)
    cfg = load_config(config_path)
    memory = MemoryStore(cfg.paths.memory_db)
    stats = memory.get_stats()

    click.echo(f"总案例数: {stats['total_cases']}")
    click.echo(f"平均评分: {stats['avg_feedback']}")
    click.echo(f"已隔离(error>=3): {stats['error_isolated']}")


@cli.command("reindex")
@click.option("-c", "--config", default=None, help="Path to config.yml")
def reindex_cmd(config):
    """Re-extract keywords for all memory cases using jieba segmentation."""
    from actflare.config import load_config
    from actflare.memory import MemoryStore

    config_path = _ensure_config(config)
    cfg = load_config(config_path)
    memory = MemoryStore(cfg.paths.memory_db)
    count = memory.reindex_keywords()
    click.echo(f"已重建 {count} 条案例的关键词索引。")


@cli.command("conversation-stats")
@click.option("-c", "--config", default=None, help="Path to config.yml")
def conversation_stats_cmd(config):
    """Show conversation system statistics."""
    from actflare.config import load_config
    from actflare.conversation import ConversationStore

    config_path = _ensure_config(config)
    cfg = load_config(config_path)
    store = ConversationStore(cfg.paths.conversation_db)
    stats = store.get_stats()

    click.echo(f"总会话数: {stats['total_conversations']}")
    click.echo(f"总消息数: {stats['total_messages']}")
    click.echo(f"活跃会话: {stats['active_conversations']}")


@cli.command("migrate-config")
@click.option("-c", "--config", default=None, help="Path to config.yml")
def migrate_config_cmd(config):
    """Migrate old wechat: config to new channels: format."""
    import shutil

    import yaml

    from actflare.config import _resolve_config_path

    path = _resolve_config_path(config)

    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    if "channels" in raw:
        click.echo("配置已是新格式，无需迁移。")
        return

    if "wechat" not in raw:
        click.echo("未找到 wechat 配置段，无法迁移。")
        return

    wechat = raw.pop("wechat")
    raw["channels"] = {
        "wecom": {
            "enabled": True,
            "default_account": "app",
            "accounts": {
                "app": {
                    "mode": "app",
                    "webhook_path": "/wecom/app",
                    "corpid": wechat.get("corpid", ""),
                    "corpsecret": wechat.get("corpsecret", ""),
                    "agent_id": wechat.get("agent_id", 0),
                    "token": wechat.get("token", ""),
                    "encoding_aes_key": wechat.get("encoding_aes_key", ""),
                },
            },
        },
    }

    backup_path = path + ".bak"
    shutil.copy2(path, backup_path)

    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(raw, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    click.echo(f"已迁移 wechat → channels.wecom.accounts.app")
    click.echo(f"原配置备份为 {backup_path}")
