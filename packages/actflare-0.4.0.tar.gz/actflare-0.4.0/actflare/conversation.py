"""Conversation management — multi-turn session tracking with SQLite."""

import sqlite3
from pathlib import Path

from actflare.log import get_logger

logger = get_logger(__name__)

# Session timeout: messages within this window share a conversation
SESSION_TIMEOUT_MINUTES = 5
# Maximum number of history messages injected into prompt
MAX_HISTORY_MESSAGES = 10
# Truncate individual messages in prompt to this length
MAX_MESSAGE_CHARS = 800
# Auto-cleanup conversations older than this many days
CLEANUP_DAYS = 7
# 保留最近 N 条完整消息（长对话摘要时使用）
KEEP_RECENT_MESSAGES = 4
# 超过此数量才生成摘要
SUMMARY_THRESHOLD = 6
# 摘要最大字符数
MAX_SUMMARY_CHARS = 600


class ConversationStore:
    """SQLite-backed conversation history for multi-turn sessions."""

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS conversations (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id         TEXT NOT NULL,
                    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
                    last_active_at  TEXT NOT NULL DEFAULT (datetime('now'))
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id INTEGER NOT NULL,
                    role            TEXT NOT NULL,
                    content         TEXT NOT NULL,
                    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
                    FOREIGN KEY (conversation_id) REFERENCES conversations(id)
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS conversation_summaries (
                    conversation_id INTEGER PRIMARY KEY,
                    summary         TEXT NOT NULL,
                    message_count   INTEGER NOT NULL DEFAULT 0,
                    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_conv_active ON conversations(last_active_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id)")
            conn.commit()

    def get_or_create_conversation(self, user_id: str) -> int:
        """Find an active conversation or create a new one.

        A conversation is active if its last_active_at is within SESSION_TIMEOUT_MINUTES.
        """
        with sqlite3.connect(self._db_path) as conn:
            row = conn.execute(
                """
                SELECT id FROM conversations
                WHERE user_id = ?
                  AND last_active_at > datetime('now', ?)
                ORDER BY last_active_at DESC
                LIMIT 1
                """,
                (user_id, f"-{SESSION_TIMEOUT_MINUTES} minutes"),
            ).fetchone()

            if row:
                return row[0]

            cursor = conn.execute(
                "INSERT INTO conversations (user_id) VALUES (?)",
                (user_id,),
            )
            conn.commit()
            return cursor.lastrowid

    def add_message(self, conversation_id: int, role: str, content: str) -> None:
        """Record a message and update the conversation's last_active_at."""
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                "INSERT INTO messages (conversation_id, role, content) VALUES (?, ?, ?)",
                (conversation_id, role, content),
            )
            conn.execute(
                "UPDATE conversations SET last_active_at = datetime('now') WHERE id = ?",
                (conversation_id,),
            )
            conn.commit()

    def get_recent_messages(
        self, conversation_id: int, limit: int = MAX_HISTORY_MESSAGES
    ) -> list[dict]:
        """Return the most recent messages in a conversation, ordered chronologically."""
        with sqlite3.connect(self._db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT role, content, created_at FROM messages
                WHERE conversation_id = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (conversation_id, limit),
            ).fetchall()
        # Reverse to chronological order
        return [dict(row) for row in reversed(rows)]

    def cleanup_old_conversations(self, days: int = CLEANUP_DAYS) -> int:
        """Delete conversations (and their messages) older than N days. Returns deleted count."""
        with sqlite3.connect(self._db_path) as conn:
            # Find old conversation IDs
            old_ids = conn.execute(
                """
                SELECT id FROM conversations
                WHERE last_active_at < datetime('now', ?)
                """,
                (f"-{days} days",),
            ).fetchall()

            if not old_ids:
                return 0

            id_list = [row[0] for row in old_ids]
            placeholders = ",".join("?" for _ in id_list)

            conn.execute(f"DELETE FROM messages WHERE conversation_id IN ({placeholders})", id_list)
            conn.execute(f"DELETE FROM conversations WHERE id IN ({placeholders})", id_list)
            conn.commit()

        logger.info("Cleaned up old conversations", count=len(id_list), older_than_days=days)
        return len(id_list)

    def get_stats(self) -> dict:
        """Return conversation statistics."""
        with sqlite3.connect(self._db_path) as conn:
            total_conversations = conn.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
            total_messages = conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
            active_conversations = conn.execute(
                """
                SELECT COUNT(*) FROM conversations
                WHERE last_active_at > datetime('now', ?)
                """,
                (f"-{SESSION_TIMEOUT_MINUTES} minutes",),
            ).fetchone()[0]
        return {
            "total_conversations": total_conversations,
            "total_messages": total_messages,
            "active_conversations": active_conversations,
        }

    @staticmethod
    def _generate_summary(messages: list[dict]) -> str:
        """基于模板生成对话摘要：提取每条消息的首句或前 80 字符。"""
        lines: list[str] = []
        for msg in messages:
            role_label = "用户问" if msg["role"] == "user" else "助手答"
            content = msg["content"].strip()
            # 取首句（句号/问号/感叹号截断）或前 80 字符
            first_sentence = content
            for sep in ("。", "？", "！", "\n"):
                idx = content.find(sep)
                if idx != -1 and idx < 80:
                    first_sentence = content[: idx + 1]
                    break
            else:
                if len(content) > 80:
                    first_sentence = content[:80] + "..."
            lines.append(f"- {role_label}: {first_sentence}")

        summary = "\n".join(lines)
        # 截断到 MAX_SUMMARY_CHARS
        if len(summary) > MAX_SUMMARY_CHARS:
            summary = summary[:MAX_SUMMARY_CHARS] + "..."
        return summary

    def get_or_update_summary(self, conversation_id: int, all_messages: list[dict]) -> str:
        """当消息数超过阈值时，生成或更新对话摘要并缓存到数据库。

        Args:
            conversation_id: 会话 ID.
            all_messages: 当前会话的所有消息列表。

        Returns:
            摘要字符串，若消息数不足则返回空字符串。
        """
        if len(all_messages) <= SUMMARY_THRESHOLD:
            return ""

        with sqlite3.connect(self._db_path) as conn:
            row = conn.execute(
                "SELECT summary, message_count FROM conversation_summaries WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()

            # 如果缓存的摘要消息数量与当前一致，直接返回
            if row and row[1] == len(all_messages):
                return row[0]

        # 对早期消息（排除最近 KEEP_RECENT_MESSAGES 条）生成摘要
        early_messages = all_messages[:-KEEP_RECENT_MESSAGES] if len(all_messages) > KEEP_RECENT_MESSAGES else []
        if not early_messages:
            return ""

        summary = self._generate_summary(early_messages)

        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                INSERT INTO conversation_summaries (conversation_id, summary, message_count, updated_at)
                VALUES (?, ?, ?, datetime('now'))
                ON CONFLICT(conversation_id)
                DO UPDATE SET summary = excluded.summary,
                              message_count = excluded.message_count,
                              updated_at = excluded.updated_at
                """,
                (conversation_id, summary, len(all_messages)),
            )
            conn.commit()

        logger.info(
            "Session summary updated",
            conv_id=conversation_id,
            early_count=len(early_messages),
            summary_len=len(summary),
        )
        return summary


def build_conversation_prompt(
    query: str, history: list[dict], cases: list[dict], summary: str = ""
) -> str:
    """Build prompt with conversation history and memory cases.

    Args:
        query: The current user question.
        history: Previous messages in the conversation (excluding the current one).
        cases: Historical cases from the memory system.
        summary: 长对话摘要（早期对话的压缩总结），由 get_or_update_summary 生成。
    """
    parts: list[str] = []

    # 长对话摘要 + 近期对话历史
    if summary:
        parts.append("[对话摘要（早期对话）]")
        parts.append(summary)
        parts.append("")
        if history:
            parts.append("[近期对话历史]")
            for msg in history:
                role_label = "用户" if msg["role"] == "user" else "助手"
                content = msg["content"]
                if len(content) > MAX_MESSAGE_CHARS:
                    content = content[:MAX_MESSAGE_CHARS] + "..."
                parts.append(f"{role_label}: {content}")
            parts.append("")
    elif history:
        # 无摘要时保持原有逻辑
        parts.append("[对话历史]")
        for msg in history:
            role_label = "用户" if msg["role"] == "user" else "助手"
            content = msg["content"]
            if len(content) > MAX_MESSAGE_CHARS:
                content = content[:MAX_MESSAGE_CHARS] + "..."
            parts.append(f"{role_label}: {content}")
        parts.append("")

    # Current question
    parts.append("[当前问题]")
    parts.append(query)

    # Historical cases section
    if cases:
        parts.append("")
        parts.append("---")
        parts.append("[历史案例参考]")
        parts.append("")
        for i, case in enumerate(cases, 1):
            date = case["created_at"][:10] if case.get("created_at") else "未知"
            parts.append(f"### 案例 {i} ({date})")
            parts.append(f"问题: {case['query']}")
            parts.append(f"解决方案: {case['answer']}")
            parts.append("")
        parts.append("---")

    return "\n".join(parts)
