"""Task tracking database — records dispatched tool tasks for status queries."""

import secrets
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

from actflare.log import get_logger

logger = get_logger(__name__)


def generate_task_id(tool_name: str) -> str:
    """Generate a unique task ID: {tool_name}_{YYYYMMDD}_{6hex}."""
    date_str = datetime.now().strftime("%Y%m%d")
    rand_hex = secrets.token_hex(3)
    return f"{tool_name}_{date_str}_{rand_hex}"


class TaskDB:
    """SQLite-backed store for tracking dispatched bioinformatics tasks."""

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tasks (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id     TEXT NOT NULL UNIQUE,
                    user_id     TEXT NOT NULL,
                    tool_name   TEXT NOT NULL,
                    backend     TEXT NOT NULL,
                    workdir     TEXT NOT NULL,
                    status      TEXT NOT NULL DEFAULT 'created',
                    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
                    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_tasks_task_id ON tasks(task_id)"
            )
            conn.commit()

    def create_task(
        self,
        user_id: str,
        tool_name: str,
        backend: str,
        task_id: str,
        workdir: str,
    ) -> dict:
        """Record a new dispatched task. Returns the task record as a dict."""
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                INSERT INTO tasks (task_id, user_id, tool_name, backend, workdir)
                VALUES (?, ?, ?, ?, ?)
                """,
                (task_id, user_id, tool_name, backend, workdir),
            )
            conn.commit()
        logger.info("Task created", task_id=task_id, tool_name=tool_name, backend=backend)
        return {
            "task_id": task_id,
            "user_id": user_id,
            "tool_name": tool_name,
            "backend": backend,
            "workdir": workdir,
            "status": "created",
        }

    def get_task(self, task_id: str) -> Optional[dict]:
        """Look up a task by its ID. Returns None if not found."""
        with sqlite3.connect(self._db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM tasks WHERE task_id = ?", (task_id,)
            ).fetchone()
        if row is None:
            return None
        return dict(row)

    def list_tasks(
        self,
        user_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
    ) -> list[dict]:
        """List tasks with optional user_id and status filters."""
        conditions: list[str] = []
        params: list[str] = []
        if user_id:
            conditions.append("user_id = ?")
            params.append(user_id)
        if status:
            conditions.append("status = ?")
            params.append(status)

        where = ""
        if conditions:
            where = "WHERE " + " AND ".join(conditions)

        sql = f"SELECT * FROM tasks {where} ORDER BY created_at DESC LIMIT ?"
        params.append(str(limit))

        with sqlite3.connect(self._db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def update_status(self, task_id: str, status: str) -> bool:
        """Update the status of a task. Returns True if the task was found."""
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute(
                """
                UPDATE tasks SET status = ?, updated_at = datetime('now')
                WHERE task_id = ?
                """,
                (status, task_id),
            )
            conn.commit()
        updated = cursor.rowcount > 0
        if updated:
            logger.info("Task status updated", task_id=task_id, status=status)
        return updated
