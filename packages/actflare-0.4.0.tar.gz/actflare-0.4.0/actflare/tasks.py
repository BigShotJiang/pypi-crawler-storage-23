"""Huey task queue — SQLite-backed, no Redis required."""

import asyncio
import uuid
from collections import defaultdict
from datetime import datetime

from huey import SqliteHuey, crontab

from actflare.circuit_breaker import CircuitBreaker
from actflare.config import get_config, DEFAULT_CONFIG_DIR
from actflare.conversation import ConversationStore, build_conversation_prompt, SUMMARY_THRESHOLD, KEEP_RECENT_MESSAGES
from actflare.log import get_logger
from actflare.memory import MemoryStore

logger = get_logger(__name__)

cfg = get_config()
huey_queue = SqliteHuey(filename=cfg.paths.huey_db)
memory_store = MemoryStore(cfg.paths.memory_db)
conversation_store = ConversationStore(cfg.paths.conversation_db)

# Maximum WeChat text message length
MAX_MSG_LEN = 2000

# Agent execution timeout (seconds)
AGENT_TIMEOUT = 120

# Circuit breaker for agent calls — shared across Huey workers
agent_breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=60)

# Distillation prompt template — used by periodic_distill and CLI distill command
DISTILL_PROMPT_TEMPLATE = """你是知识管理专家。根据以下案例总结通用规律和最佳实践。
## 案例集合: {cluster_key}
{cases_text}
## 要求
1. 提炼可复用模式，非复述案例
2. 条目式表述，每条 1-2 句
3. 标注适用条件和注意事项
4. 输出纯 Markdown，不含原始案例"""

# Timeout for each distillation summarization call (seconds)
DISTILL_TIMEOUT = 60


async def _run_agent_with_timeout(prompt: str, timeout: int = AGENT_TIMEOUT):
    """Run Claude agent with asyncio timeout protection."""
    from actflare.agent import run_claude_agent

    return await asyncio.wait_for(run_claude_agent(prompt), timeout=timeout)


async def _summarize_cluster(cluster_key: str, cases_text: str) -> str:
    """Use Claude agent to summarize a cluster of cases into reusable patterns."""
    from actflare.agent import run_claude_agent

    prompt = DISTILL_PROMPT_TEMPLATE.format(cluster_key=cluster_key, cases_text=cases_text)
    try:
        result_text, _ = await asyncio.wait_for(
            run_claude_agent(prompt),
            timeout=DISTILL_TIMEOUT,
        )
        return result_text.strip() if result_text else ""
    except Exception:
        logger.exception("Distill: AI summarization failed", cluster_key=cluster_key)
        return ""


@huey_queue.task(retries=3, retry_delay=10)
def process_message(
    user_id: str,
    content: str,
    sender_type: str = "app",
    response_url: str = "",
    account_id: str = "",
    trace_id: str = "",
) -> None:
    """Process a user message: run Claude agent and push the reply via ChannelSender."""
    from actflare.sender import build_sender

    trace_id = trace_id or uuid.uuid4().hex[:8]
    log = logger.bind(trace_id=trace_id, user_id=user_id)
    log.info("Processing message", content_preview=content[:80])

    # 1. Get or create conversation session and save user message
    conv_id = conversation_store.get_or_create_conversation(user_id)
    conversation_store.add_message(conv_id, "user", content)

    # 2. Retrieve conversation history (excluding the message we just added)
    all_messages = conversation_store.get_recent_messages(conv_id)
    history = all_messages[:-1] if all_messages else []
    if history:
        log.info("Conversation history loaded", conv_id=conv_id, history_count=len(history))

    # 3. 长对话摘要：超过阈值时生成摘要，仅保留近期消息
    summary = ""
    if len(all_messages) > SUMMARY_THRESHOLD:
        summary = conversation_store.get_or_update_summary(conv_id, all_messages)
        if summary:
            history = history[-KEEP_RECENT_MESSAGES:]
            log.info("Session summary applied", conv_id=conv_id, recent_count=len(history))

    # 4. Search for relevant historical cases
    keywords = MemoryStore.extract_keywords(content)
    cases = memory_store.search_cases(keywords) if keywords else []
    if cases:
        log.info("Found historical cases", case_count=len(cases))

    # 5. Build augmented prompt with conversation history, summary, and cases
    augmented_prompt = build_conversation_prompt(content, history, cases, summary=summary)

    # 6. Run agent with timeout protection + circuit breaker
    turns_used = 1
    if not agent_breaker.allow_request():
        log.warning("Circuit breaker open, rejecting request")
        result = "抱歉，系统暂时繁忙，请稍后再试。"
    else:
        try:
            result, turns_used = asyncio.run(_run_agent_with_timeout(augmented_prompt))
            agent_breaker.record_success()
        except asyncio.TimeoutError:
            log.error("Agent timeout", timeout_seconds=AGENT_TIMEOUT)
            agent_breaker.record_failure()
            result = "抱歉，处理超时，请稍后重试或简化您的问题。"
        except Exception:
            log.exception("Agent failed")
            agent_breaker.record_failure()
            result = "抱歉，处理您的请求时出现了错误，请稍后再试。"

    # 7. Save assistant reply to conversation history
    if result and not result.startswith("抱歉"):
        conversation_store.add_message(conv_id, "assistant", result)

    # Auto-commit any skill edits by the agent
    from actflare.skills_git import auto_commit
    auto_commit(DEFAULT_CONFIG_DIR / "skills", f"agent: auto-edit after trace {trace_id}")

    # 8. Save case if: multi-turn OR substantial answer (>200 chars), and not error
    should_save = (turns_used > 1 or len(result) > 200) and result and not result.startswith("抱歉")
    if should_save:
        try:
            memory_store.save_case(
                user_id=user_id,
                query=content,
                answer=result,
                turns_used=turns_used,
                trace_id=trace_id,
            )
        except Exception:
            log.exception("Failed to save case to memory")

    # Append trace_id and feedback hint for user reference
    if result and not result.startswith("抱歉"):
        result = result.rstrip() + f"\n\n[任务编号: {trace_id}]\n收到结果后，回复「评价 {trace_id} 好」或「评价 {trace_id} 不好」帮助我改进"

    # Truncate if the reply exceeds WeChat's limit
    if len(result) > MAX_MSG_LEN:
        result = result[: MAX_MSG_LEN - 3] + "..."

    sender = build_sender(sender_type, response_url=response_url, account_id=account_id)
    try:
        sender.send_text(user_id, result)
    except Exception:
        log.exception("Failed to send reply")


# ---------------------------------------------------------------------------
# Periodic tasks — run automatically by Huey worker
# ---------------------------------------------------------------------------


@huey_queue.periodic_task(crontab(minute="0", hour="*/6"))
def periodic_memory_stats():
    """Log memory system statistics every 6 hours."""
    stats = memory_store.get_stats()
    logger.info(
        "Memory stats",
        total_cases=stats["total_cases"],
        avg_feedback=round(stats["avg_feedback"], 3),
        error_isolated=stats["error_isolated"],
    )


@huey_queue.periodic_task(crontab(minute="0", hour="3", day_of_week="0"))
def periodic_distill():
    """Distill high-quality cases into skill drafts every Sunday 3:00 AM.

    Uses Claude agent to summarize case clusters into reusable patterns.
    Falls back to template-only format if AI summarization fails.
    """
    cases = memory_store.top_cases(min_feedback=0.5, limit=50)
    if not cases:
        logger.info("Distill: no high-quality cases to process")
        return

    # Group by first 3 keywords
    clusters: defaultdict[str, list[dict]] = defaultdict(list)
    for case in cases:
        kws = case["keywords"].split()[:3]
        cluster_key = " ".join(sorted(kws)) if kws else "其他"
        clusters[cluster_key].append(case)

    drafts_dir = DEFAULT_CONFIG_DIR / "skills" / "drafts"
    drafts_dir.mkdir(parents=True, exist_ok=True)

    date_str = datetime.now().strftime("%Y%m%d")
    draft_count = 0
    for cluster_key, cluster_cases in clusters.items():
        if len(cluster_cases) < 2:
            continue

        draft_name = f"draft_{date_str}_{cluster_key.replace(' ', '_')[:30]}.md"
        draft_path = drafts_dir / draft_name
        if draft_path.exists():
            continue  # Don't overwrite existing drafts

        # 构建案例文本用于 AI 总结
        case_lines = []
        for i, c in enumerate(cluster_cases, 1):
            case_lines.append(f"### 案例 {i} (评分: {c['feedback_score']}, 轮次: {c['turns_used']})")
            case_lines.append(f"**问题**: {c['query']}")
            case_lines.append(f"**解决方案**: {c['answer'][:500]}")
            case_lines.append("")
        cases_text = "\n".join(case_lines)

        # 尝试 AI 总结
        ai_summary = ""
        try:
            ai_summary = asyncio.run(_summarize_cluster(cluster_key, cases_text))
        except Exception:
            logger.exception("Distill: asyncio.run failed for AI summarization", cluster_key=cluster_key)

        # 构建草稿内容
        lines = [
            f"# 知识草稿: {cluster_key}",
            "",
            f"> 自动提炼自 {len(cluster_cases)} 条高质量案例 ({date_str})",
            f"> 审核后请移动到 ~/.config/actflare/skills/ 正式目录",
            "",
        ]

        if ai_summary:
            # AI 总结成功：通用规律 + 原始案例参考
            lines.append("## 通用规律")
            lines.append("")
            lines.append(ai_summary)
            lines.append("")
            lines.append("## 原始案例参考")
            lines.append("")
            lines.append(cases_text)
        else:
            # AI 总结失败：退化为旧格式，保留占位符
            lines.append("## 案例汇总")
            lines.append("")
            lines.append(cases_text)
            lines.append("## 待提炼的通用规律")
            lines.append("")
            lines.append("<!-- 请根据上述案例总结通用规律，然后删除案例部分 -->")
            lines.append("")

        draft_path.write_text("\n".join(lines), encoding="utf-8")
        draft_count += 1

    if draft_count:
        logger.info("Distill: generated skill drafts", count=draft_count, path=str(drafts_dir))

        # 自动提交到 git
        from actflare.skills_git import auto_commit

        auto_commit(DEFAULT_CONFIG_DIR / "skills", f"distill: {draft_count} drafts ({date_str})")


@huey_queue.periodic_task(crontab(minute="30", hour="4"))
def periodic_conversation_cleanup():
    """Clean up conversations older than 7 days, daily at 4:30 AM."""
    deleted = conversation_store.cleanup_old_conversations()
    if deleted:
        logger.info("Conversation cleanup: removed old conversations", count=deleted)
