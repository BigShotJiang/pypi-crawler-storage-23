"""WXBizMsgCrypt - WeChat Work message encryption/decryption.

Implements AES-256-CBC encryption with PKCS#7 padding and SHA1 signature
verification, compatible with the WeChat Work callback protocol.
"""

import base64
import hashlib
import socket
import struct
import time
import xml.etree.ElementTree as ET
from typing import Optional

from Crypto.Cipher import AES


class WXBizMsgCrypt:
    """WeChat Work callback message crypto helper."""

    def __init__(self, token: str, encoding_aes_key: str, receive_id: str):
        self.token = token
        self.receive_id = receive_id
        # EncodingAESKey is 43 chars base64, decode to 32-byte AES key
        self.aes_key = base64.b64decode(encoding_aes_key + "=")
        assert len(self.aes_key) == 32, "AES key must be 32 bytes"

    # ------------------------------------------------------------------
    # Signature
    # ------------------------------------------------------------------

    @staticmethod
    def _sha1_sign(token: str, timestamp: str, nonce: str, encrypt: str) -> str:
        parts = sorted([token, timestamp, nonce, encrypt])
        return hashlib.sha1("".join(parts).encode("utf-8")).hexdigest()

    def _verify_signature(self, msg_signature: str, timestamp: str, nonce: str, encrypt: str) -> bool:
        return self._sha1_sign(self.token, timestamp, nonce, encrypt) == msg_signature

    # ------------------------------------------------------------------
    # PKCS#7 padding
    # ------------------------------------------------------------------

    @staticmethod
    def _pkcs7_pad(data: bytes, block_size: int = 32) -> bytes:
        pad_len = block_size - (len(data) % block_size)
        return data + bytes([pad_len] * pad_len)

    @staticmethod
    def _pkcs7_unpad(data: bytes) -> bytes:
        pad_len = data[-1]
        return data[:-pad_len]

    # ------------------------------------------------------------------
    # AES encrypt / decrypt
    # ------------------------------------------------------------------

    def _encrypt(self, plaintext: str) -> str:
        """Encrypt plaintext and return base64-encoded ciphertext."""
        random_bytes = socket.inet_aton("0.0.0.0") * 4  # 16 random bytes placeholder
        import os
        random_bytes = os.urandom(16)

        text_bytes = plaintext.encode("utf-8")
        corpid_bytes = self.receive_id.encode("utf-8")

        # random(16) + msg_len(4, network order) + msg + corpid
        content = random_bytes + struct.pack("!I", len(text_bytes)) + text_bytes + corpid_bytes
        padded = self._pkcs7_pad(content)

        iv = self.aes_key[:16]
        cipher = AES.new(self.aes_key, AES.MODE_CBC, iv)
        encrypted = cipher.encrypt(padded)
        return base64.b64encode(encrypted).decode("utf-8")

    def _decrypt(self, ciphertext_b64: str) -> str:
        """Decrypt base64-encoded ciphertext and return plaintext."""
        ciphertext = base64.b64decode(ciphertext_b64)
        iv = self.aes_key[:16]
        cipher = AES.new(self.aes_key, AES.MODE_CBC, iv)
        decrypted = cipher.decrypt(ciphertext)
        unpadded = self._pkcs7_unpad(decrypted)

        # Skip 16 random bytes, then read 4-byte msg length
        msg_len = struct.unpack("!I", unpadded[16:20])[0]
        msg = unpadded[20: 20 + msg_len].decode("utf-8")
        from_corpid = unpadded[20 + msg_len:].decode("utf-8")

        if from_corpid != self.receive_id:
            raise ValueError(f"receive_id mismatch: expected {self.receive_id}, got {from_corpid}")

        return msg

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def verify_url(self, msg_signature: str, timestamp: str, nonce: str, echostr: str) -> str:
        """Verify callback URL (GET request). Returns decrypted echostr."""
        if not self._verify_signature(msg_signature, timestamp, nonce, echostr):
            raise ValueError("Signature verification failed")
        return self._decrypt(echostr)

    def decrypt_msg(
        self,
        post_data: str,
        msg_signature: str,
        timestamp: str,
        nonce: str,
    ) -> str:
        """Decrypt an incoming POST message XML. Returns the inner XML string."""
        root = ET.fromstring(post_data)
        encrypt_node = root.find("Encrypt")
        if encrypt_node is None or encrypt_node.text is None:
            raise ValueError("Missing <Encrypt> node in XML")

        encrypt_text = encrypt_node.text
        if not self._verify_signature(msg_signature, timestamp, nonce, encrypt_text):
            raise ValueError("Signature verification failed")

        return self._decrypt(encrypt_text)

    def decrypt_msg_raw(
        self,
        encrypt_text: str,
        msg_signature: str,
        timestamp: str,
        nonce: str,
    ) -> str:
        """Decrypt raw encrypted string (for JSON-based Bot callbacks)."""
        if not self._verify_signature(msg_signature, timestamp, nonce, encrypt_text):
            raise ValueError("Signature verification failed")
        return self._decrypt(encrypt_text)

    def encrypt_msg(self, reply_msg: str, nonce: Optional[str] = None, timestamp: Optional[str] = None) -> str:
        """Encrypt a reply message and wrap it in the response XML envelope."""
        if timestamp is None:
            timestamp = str(int(time.time()))
        if nonce is None:
            import random
            nonce = str(random.randint(100000000, 999999999))

        encrypt = self._encrypt(reply_msg)
        signature = self._sha1_sign(self.token, timestamp, nonce, encrypt)

        return (
            "<xml>"
            f"<Encrypt><![CDATA[{encrypt}]]></Encrypt>"
            f"<MsgSignature><![CDATA[{signature}]]></MsgSignature>"
            f"<TimeStamp>{timestamp}</TimeStamp>"
            f"<Nonce><![CDATA[{nonce}]]></Nonce>"
            "</xml>"
        )
