"""Memory system — stores and retrieves successful multi-turn agent cases."""

import math
import re
import sqlite3
from pathlib import Path
from typing import Optional

import jieba
import jieba.analyse

# Suppress jieba's default debug logging
import logging as _logging
_logging.getLogger("jieba").setLevel(_logging.WARNING)

from actflare.log import get_logger

logger = get_logger(__name__)

# Common Chinese stopwords (short list, no external dependency)
_CHINESE_STOPWORDS = frozenset(
    "的了是在我有和就不人都一个上也这中大为来以到说时要没出会"
    "那你她他它们被把让给从对于而且但又或还很更比最其如果因已"
    "吗呢吧啊哦嗯哈么着过将所能可以之与及等则只而已好才想看"
    "用怎什么谁哪里这个那个什么样怎么样为什么因为所以如果虽然"
    "但是或者而且那么就是可以应该必须可能"
)

# Maximum number of cases to inject
MAX_INJECT_CASES = 5
# Maximum characters per answer in injected context
MAX_ANSWER_CHARS = 500
# Maximum total cases before cleanup
MAX_CASES = 10000


class MemoryStore:
    """SQLite-backed store for successful multi-turn agent cases."""

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS cases (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id     TEXT NOT NULL,
                    query       TEXT NOT NULL,
                    keywords    TEXT NOT NULL,
                    answer      TEXT NOT NULL,
                    turns_used  INTEGER NOT NULL DEFAULT 1,
                    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
                    token_cost  INTEGER DEFAULT 0
                )
                """
            )
            # Enable WAL mode for better concurrent read/write performance
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")

            # Migrate: add new columns if they don't exist
            for col_def in [
                ("feedback_score", "REAL DEFAULT 0.0"),
                ("error_count", "INTEGER DEFAULT 0"),
                ("trace_id", "TEXT DEFAULT ''"),
            ]:
                try:
                    conn.execute(f"ALTER TABLE cases ADD COLUMN {col_def[0]} {col_def[1]}")
                except sqlite3.OperationalError:
                    pass  # Column already exists

            # Create indexes if they don't exist
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cases_keywords ON cases(keywords)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cases_user_id ON cases(user_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cases_trace_id ON cases(trace_id)")
            conn.commit()

    @staticmethod
    def extract_keywords(text: str, topk: int = 15) -> list[str]:
        """Extract keywords using jieba TF-IDF keyword extraction.

        Primary: jieba.analyse.extract_tags() for TF-IDF based extraction.
        Fallback: jieba.cut() with stopword filtering if TF-IDF fails.
        """
        if not text.strip():
            return []

        # Primary: TF-IDF keyword extraction (returns most relevant terms)
        try:
            keywords = jieba.analyse.extract_tags(text, topK=topk)
            if keywords:
                return keywords
        except Exception:
            pass

        # Fallback: standard segmentation with stopword filtering
        words = jieba.cut(text, cut_all=False)
        seen: set[str] = set()
        result: list[str] = []
        for word in words:
            word = word.strip()
            if len(word) < 2:
                continue
            if word in _CHINESE_STOPWORDS:
                continue
            if word not in seen:
                seen.add(word)
                result.append(word)
            if len(result) >= topk:
                break
        return result

    def search_cases(self, keywords: list[str], limit: int = MAX_INJECT_CASES) -> list[dict]:
        """Search cases by keyword overlap, ranked by match count * recency decay.

        Time decay: exp(-days_old / 30) gives ~50% weight at ~21 days.
        Cases with error_count >= 3 or feedback_score <= -0.5 are excluded.
        """
        if not keywords:
            return []

        like_clauses = " + ".join(
            f"(CASE WHEN keywords LIKE ? THEN 1 ELSE 0 END)" for _ in keywords
        )
        params: list = [f"%{kw}%" for kw in keywords]

        # Time decay: EXP(-days_old / 30.0) — requires registered EXP function
        sql = f"""
            SELECT id, query, answer, created_at, feedback_score,
                   ({like_clauses}) AS match_count,
                   EXP(-CAST((julianday('now') - julianday(created_at)) AS REAL) / 30.0) AS recency
            FROM cases
            WHERE match_count > 0
              AND error_count < 3
              AND feedback_score > -0.5
            ORDER BY (match_count * recency) DESC, created_at DESC
            LIMIT ?
        """
        params.append(limit)

        with sqlite3.connect(self._db_path) as conn:
            conn.create_function("EXP", 1, math.exp)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql, params).fetchall()

        return [
            {
                "id": row["id"],
                "query": row["query"],
                "answer": row["answer"][:MAX_ANSWER_CHARS],
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def save_case(
        self,
        user_id: str,
        query: str,
        answer: str,
        turns_used: int,
        token_cost: int = 0,
        trace_id: str = "",
    ) -> None:
        """Persist a successful multi-turn case."""
        keywords = self.extract_keywords(query)
        if not keywords:
            logger.debug("No keywords extracted, skipping save", query_preview=query[:60])
            return
        keywords_str = " ".join(keywords)

        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                INSERT INTO cases (user_id, query, keywords, answer, turns_used, token_cost, trace_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (user_id, query, keywords_str, answer, turns_used, token_cost, trace_id),
            )
            conn.commit()
        logger.info("Saved case", user_id=user_id, turns_used=turns_used, keywords=keywords_str[:80])

        # Capacity management: delete oldest low-quality cases when over limit
        with sqlite3.connect(self._db_path) as conn:
            total = conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0]
            if total > MAX_CASES:
                delete_count = total // 10
                conn.execute(
                    """DELETE FROM cases WHERE id IN (
                        SELECT id FROM cases ORDER BY feedback_score ASC, created_at ASC LIMIT ?
                    )""",
                    (delete_count,),
                )
                conn.commit()
                logger.info("Memory cleanup: deleted old/low-quality cases", count=delete_count)

    def update_feedback(self, case_id: int, score: float) -> None:
        """Update feedback score for a case. Score range: -1.0 to 1.0."""
        score = max(-1.0, min(1.0, score))
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("UPDATE cases SET feedback_score = ? WHERE id = ?", (score, case_id))
            conn.commit()

    def update_feedback_by_trace(self, trace_id: str, score: float) -> bool:
        """Update feedback score by trace_id. Returns True if found."""
        score = max(-1.0, min(1.0, score))
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute("UPDATE cases SET feedback_score = ? WHERE trace_id = ?", (score, trace_id))
            conn.commit()
        return cursor.rowcount > 0

    def increment_error(self, case_id: int) -> None:
        """Increment error count for a case."""
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("UPDATE cases SET error_count = error_count + 1 WHERE id = ?", (case_id,))
            conn.commit()

    def get_stats(self) -> dict:
        """Return memory system statistics."""
        with sqlite3.connect(self._db_path) as conn:
            total = conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0]
            avg_feedback = conn.execute("SELECT AVG(feedback_score) FROM cases").fetchone()[0] or 0.0
            error_cases = conn.execute("SELECT COUNT(*) FROM cases WHERE error_count >= 3").fetchone()[0]
        return {"total_cases": total, "avg_feedback": round(avg_feedback, 3), "error_isolated": error_cases}

    def top_cases(self, min_feedback: float = 0.5, limit: int = 50) -> list[dict]:
        """Return top-quality cases for knowledge distillation into skills."""
        with sqlite3.connect(self._db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT id, query, keywords, answer, turns_used, feedback_score, created_at
                FROM cases
                WHERE feedback_score >= ? AND error_count = 0
                ORDER BY feedback_score DESC, turns_used DESC
                LIMIT ?
                """,
                (min_feedback, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def reindex_keywords(self, batch_size: int = 100) -> int:
        """Re-extract keywords for all cases using current tokenizer. Returns count updated."""
        with sqlite3.connect(self._db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT id, query FROM cases").fetchall()

        updated = 0
        for i in range(0, len(rows), batch_size):
            batch = rows[i : i + batch_size]
            with sqlite3.connect(self._db_path) as conn:
                for row in batch:
                    new_keywords = self.extract_keywords(row["query"])
                    if new_keywords:
                        conn.execute(
                            "UPDATE cases SET keywords = ? WHERE id = ?",
                            (" ".join(new_keywords), row["id"]),
                        )
                        updated += 1
                conn.commit()

        logger.info("Reindexed keywords", updated=updated, total=len(rows))
        return updated


def build_augmented_prompt(
    original_query: str, cases: list[dict]
) -> str:
    """Build the final prompt with historical cases injected."""
    if not cases:
        return original_query

    parts = [original_query, "", "---"]
    parts.append("[以下是可能相关的历史成功案例，仅供参考，请自行判断是否适用]")
    parts.append("")

    for i, case in enumerate(cases, 1):
        date = case["created_at"][:10] if case.get("created_at") else "未知"
        parts.append(f"### 案例 {i} ({date})")
        parts.append(f"问题: {case['query']}")
        parts.append(f"解决方案: {case['answer']}")
        parts.append("")

    parts.append("---")
    return "\n".join(parts)
