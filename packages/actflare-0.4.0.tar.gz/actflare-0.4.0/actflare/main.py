"""FastAPI application — thin entry point with channel plugin architecture."""

import logging as _logging

from fastapi import FastAPI
from starlette.responses import JSONResponse

from actflare.channels import ChannelRegistry
from actflare.channels.wecom import WecomChannelHandler
from actflare.config import get_config
from actflare.log import setup_logging, get_logger

cfg = get_config()
_log_level = getattr(_logging, cfg.logging.level.upper(), _logging.INFO)
setup_logging(level=_log_level, log_format=cfg.logging.format, module_levels=cfg.logging.module_levels)
logger = get_logger(__name__)

app = FastAPI(title="ActFlare", description="WeChat Work callback service")

# 渠道注册表
channel_registry = ChannelRegistry()
channel_registry.register(WecomChannelHandler())


@app.get("/health")
async def health_check():
    """Health check endpoint exposing system component status."""
    from actflare.tasks import agent_breaker, memory_store, conversation_store

    components = {}
    overall_ok = True

    # 熔断器状态
    breaker_info = agent_breaker.to_dict()
    components["circuit_breaker"] = breaker_info
    if breaker_info["state"] == "open":
        overall_ok = False

    # 记忆库
    try:
        components["memory"] = {"status": "ok", **memory_store.get_stats()}
    except Exception as e:
        components["memory"] = {"status": "error", "detail": str(e)}
        overall_ok = False

    # 会话库
    try:
        components["conversation"] = {"status": "ok", **conversation_store.get_stats()}
    except Exception as e:
        components["conversation"] = {"status": "error", "detail": str(e)}
        overall_ok = False

    status_code = 200 if overall_ok else 503
    return JSONResponse(
        content={"status": "healthy" if overall_ok else "degraded", "components": components},
        status_code=status_code,
    )


# 注册所有渠道路由
channel_registry.register_all_routes(app)
