"""Circuit breaker pattern for protecting against cascading agent failures."""

import threading
import time
from enum import Enum

from actflare.log import get_logger

logger = get_logger(__name__)


class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Thread-safe circuit breaker with three states: CLOSED, OPEN, HALF_OPEN.

    - CLOSED: requests pass through normally; consecutive failures are counted.
    - OPEN: requests are blocked immediately; after *recovery_timeout* seconds the
      circuit transitions to HALF_OPEN.
    - HALF_OPEN: one probe request is allowed through.  On success the circuit
      resets to CLOSED; on failure it returns to OPEN.
    """

    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 60) -> None:
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout

        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: float = 0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            return self._state

    def allow_request(self) -> bool:
        """Return True if the request should proceed, False if blocked."""
        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True

            if self._state == CircuitState.OPEN:
                if time.monotonic() - self._last_failure_time >= self._recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    logger.info("Circuit breaker: OPEN -> HALF_OPEN (recovery timeout elapsed)")
                    return True
                return False

            # HALF_OPEN: allow one probe request
            return True

    def record_success(self) -> None:
        """Record a successful call — reset to CLOSED."""
        with self._lock:
            prev = self._state
            self._failure_count = 0
            self._state = CircuitState.CLOSED
            if prev != CircuitState.CLOSED:
                logger.info("Circuit breaker: state changed to CLOSED", prev_state=prev.value)

    def to_dict(self) -> dict:
        """Return circuit breaker status as a dict for health checks."""
        with self._lock:
            return {
                "state": self._state.value,
                "failure_count": self._failure_count,
                "failure_threshold": self._failure_threshold,
                "recovery_timeout": self._recovery_timeout,
            }

    def record_failure(self) -> None:
        """Record a failed call — increment counter and open circuit if threshold reached."""
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.monotonic()

            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
                logger.warning("Circuit breaker: HALF_OPEN -> OPEN (probe failed)")
            elif self._state == CircuitState.CLOSED and self._failure_count >= self._failure_threshold:
                self._state = CircuitState.OPEN
                logger.warning(
                    "Circuit breaker: CLOSED -> OPEN",
                    failures=self._failure_count,
                    threshold=self._failure_threshold,
                )
