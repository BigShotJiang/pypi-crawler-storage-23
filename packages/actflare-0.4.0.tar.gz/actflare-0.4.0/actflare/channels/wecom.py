"""WeChat Work (企业微信) channel handler implementation."""

import json
import re
import uuid
import xml.etree.ElementTree as ET
from typing import Optional

from fastapi import FastAPI, Query, Request
from fastapi.responses import PlainTextResponse

from actflare.channels.base import ChannelHandler
from actflare.config import AccountConfig
from actflare.crypto import WXBizMsgCrypt
from actflare.log import get_logger

logger = get_logger(__name__)

# 输入消息最大长度
MAX_INPUT_LEN = 5000

# 反馈指令匹配：「评价 <trace_id> 好/不好/有用/没用」等
_FEEDBACK_RE = re.compile(
    r"^评价\s+([a-f0-9]{8})\s+(好|不好|有用|没用|满意|不满意|👍|👎)$",
    re.IGNORECASE,
)
_POSITIVE_WORDS = frozenset({"好", "有用", "满意", "👍"})


class WecomChannelHandler(ChannelHandler):
    """企业微信渠道处理器，支持 bot 和 app 两种模式"""

    @property
    def channel_type(self) -> str:
        return "wecom"

    def register_routes(self, app: FastAPI, account_id: str, account: AccountConfig) -> None:
        """根据账户模式注册对应的 HTTP 路由"""
        if account.mode == "bot":
            self._register_bot_routes(app, account_id, account)
        elif account.mode == "app":
            self._register_app_routes(app, account_id, account)
        else:
            logger.warning("Unknown mode for account", mode=account.mode, account_id=account_id)

    def build_sender(self, account: AccountConfig, **kwargs):
        """构造 ChannelSender 实例"""
        from actflare.sender import build_sender

        return build_sender(account, **kwargs)

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------

    @staticmethod
    def _make_crypt(account: AccountConfig) -> WXBizMsgCrypt:
        """构造加解密实例"""
        receive_id = account.receive_id if account.mode == "bot" else account.corpid
        return WXBizMsgCrypt(
            token=account.token,
            encoding_aes_key=account.encoding_aes_key,
            receive_id=receive_id,
        )

    @staticmethod
    def _try_process_feedback(content: str, user_id: str) -> Optional[str]:
        """如果内容匹配反馈格式，处理并返回回复；否则返回 None"""
        m = _FEEDBACK_RE.match(content.strip())
        if not m:
            return None

        trace_id = m.group(1)
        sentiment = m.group(2)
        score = 1.0 if sentiment in _POSITIVE_WORDS else -1.0

        from actflare.tasks import memory_store

        found = memory_store.update_feedback_by_trace(trace_id, score)
        if found:
            label = "好评 👍" if score > 0 else "差评"
            logger.info("Feedback recorded", trace_id=trace_id, score=score, user_id=user_id)
            return f"已记录您对任务 {trace_id} 的{label}，感谢反馈！"
        else:
            logger.warning("Feedback trace_id not found", trace_id=trace_id, user_id=user_id)
            return f"未找到任务编号 {trace_id}，请确认编号是否正确。"

    def _register_bot_routes(self, app: FastAPI, account_id: str, account: AccountConfig) -> None:
        """注册 Bot 模式的 GET（验证）和 POST（接收消息）路由"""
        path = account.webhook_path

        @app.get(path, name=f"verify_{account_id}")
        async def bot_verify(
            msg_signature: str = Query(...),
            timestamp: str = Query(...),
            nonce: str = Query(...),
            echostr: str = Query(...),
            _account: AccountConfig = account,
        ):
            try:
                crypt = self._make_crypt(_account)
                echo = crypt.verify_url(msg_signature, timestamp, nonce, echostr)
                return PlainTextResponse(echo)
            except Exception:
                logger.exception("Bot URL verification failed", account_id=account_id)
                return PlainTextResponse("error", status_code=403)

        @app.post(path, name=f"receive_{account_id}")
        async def bot_receive(
            request: Request,
            msg_signature: str = Query(...),
            timestamp: str = Query(...),
            nonce: str = Query(...),
            _account: AccountConfig = account,
            _account_id: str = account_id,
        ):
            from actflare.tasks import process_message

            try:
                body = await request.json()
            except Exception:
                logger.exception("Bot invalid JSON body")
                return PlainTextResponse("error", status_code=400)

            encrypt = body.get("encrypt", "") or body.get("Encrypt", "")
            if not encrypt:
                return PlainTextResponse("missing encrypt", status_code=400)

            try:
                crypt = self._make_crypt(_account)
                plain = crypt.decrypt_msg_raw(encrypt, msg_signature, timestamp, nonce)
            except Exception:
                logger.exception("Bot message decryption failed")
                return PlainTextResponse("error", status_code=403)

            try:
                msg = json.loads(plain)
            except json.JSONDecodeError:
                logger.error("Bot decrypted content is not valid JSON", content_preview=plain[:200])
                return PlainTextResponse("error", status_code=400)

            user_id = ""
            from_info = msg.get("from", {})
            if isinstance(from_info, dict):
                user_id = from_info.get("userid", "")
            user_id = user_id or msg.get("FromUserName", "")

            msg_type = msg.get("msgtype", msg.get("MsgType", ""))
            content = ""
            if msg_type == "text":
                text_obj = msg.get("text", {})
                if isinstance(text_obj, dict):
                    content = text_obj.get("content", "")
                elif isinstance(text_obj, str):
                    content = text_obj

            if content and len(content) > MAX_INPUT_LEN:
                logger.warning("Message too long, truncating", chars=len(content), user_id=user_id)
                content = content[:MAX_INPUT_LEN]

            response_url = msg.get("response_url", "")

            trace_id = uuid.uuid4().hex[:8]
            logger.info(
                "Bot received message",
                trace_id=trace_id,
                msg_type=msg_type,
                user_id=user_id,
                content_preview=(content or "")[:80],
            )

            if msg_type == "text" and user_id and content:
                # 拦截反馈消息 — 直接处理，不经过 Claude
                feedback_reply = self._try_process_feedback(content, user_id)
                if feedback_reply is not None:
                    from actflare.sender import build_sender

                    sender = build_sender("bot", response_url=response_url)
                    sender.send_text(user_id, feedback_reply)
                else:
                    process_message(user_id, content, sender_type="bot", response_url=response_url, trace_id=trace_id)
            else:
                logger.info("Bot ignoring non-text or empty message", msg_type=msg_type)

            return PlainTextResponse("")

    def _register_app_routes(self, app: FastAPI, account_id: str, account: AccountConfig) -> None:
        """注册 App 模式的 GET（验证）和 POST（接收消息）路由"""
        path = account.webhook_path

        @app.get(path, name=f"verify_{account_id}")
        async def app_verify(
            msg_signature: str = Query(...),
            timestamp: str = Query(...),
            nonce: str = Query(...),
            echostr: str = Query(...),
            _account: AccountConfig = account,
        ):
            try:
                crypt = self._make_crypt(_account)
                echo = crypt.verify_url(msg_signature, timestamp, nonce, echostr)
                return PlainTextResponse(echo)
            except Exception:
                logger.exception("App URL verification failed", account_id=account_id)
                return PlainTextResponse("error", status_code=403)

        @app.post(path, name=f"receive_{account_id}")
        async def app_receive(
            request: Request,
            msg_signature: str = Query(...),
            timestamp: str = Query(...),
            nonce: str = Query(...),
            _account: AccountConfig = account,
            _account_id: str = account_id,
        ):
            from actflare.tasks import process_message

            body = await request.body()
            post_data = body.decode("utf-8")

            try:
                crypt = self._make_crypt(_account)
                xml_str = crypt.decrypt_msg(post_data, msg_signature, timestamp, nonce)
            except Exception:
                logger.exception("App message decryption failed")
                return PlainTextResponse("error", status_code=403)

            root = ET.fromstring(xml_str)
            msg_type = root.findtext("MsgType", "")
            from_user = root.findtext("FromUserName", "")
            content = root.findtext("Content", "")

            if content and len(content) > MAX_INPUT_LEN:
                logger.warning("Message too long, truncating", chars=len(content), user_id=from_user)
                content = content[:MAX_INPUT_LEN]

            trace_id = uuid.uuid4().hex[:8]
            logger.info(
                "App received message",
                trace_id=trace_id,
                msg_type=msg_type,
                user_id=from_user,
                content_preview=(content or "")[:80],
            )

            if msg_type == "text" and from_user and content:
                # 拦截反馈消息 — 直接处理，不经过 Claude
                feedback_reply = self._try_process_feedback(content, from_user)
                if feedback_reply is not None:
                    from actflare.sender import build_sender

                    sender = build_sender("app", account_id=_account_id)
                    sender.send_text(from_user, feedback_reply)
                else:
                    process_message(from_user, content, sender_type="app", account_id=_account_id, trace_id=trace_id)
            else:
                logger.info("App ignoring non-text or empty message", msg_type=msg_type)

            return PlainTextResponse("")
