"""Abstract base classes for channel handlers."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

from fastapi import FastAPI


@dataclass
class IncomingMessage:
    """标准化入站消息"""

    user_id: str
    content: str
    msg_type: str
    trace_id: str
    raw: dict


class ChannelHandler(ABC):
    """渠道处理器抽象基类"""

    @property
    @abstractmethod
    def channel_type(self) -> str:
        """渠道类型标识，如 'wecom', 'dingtalk'"""
        ...

    @abstractmethod
    def register_routes(self, app: FastAPI, account_id: str, account) -> None:
        """注册 HTTP 路由到 FastAPI 应用"""
        ...

    @abstractmethod
    def build_sender(self, account, **kwargs):
        """构造 ChannelSender 实例"""
        ...


class ChannelRegistry:
    """渠道注册表，管理所有渠道处理器"""

    def __init__(self):
        self._handlers: dict[str, ChannelHandler] = {}

    def register(self, handler: ChannelHandler) -> None:
        self._handlers[handler.channel_type] = handler

    def get(self, channel_type: str) -> Optional[ChannelHandler]:
        return self._handlers.get(channel_type)

    def register_all_routes(self, app: FastAPI) -> None:
        """遍历配置中的渠道，注册所有路由"""
        from actflare.config import get_config

        cfg = get_config()

        for channel_name, channel_cfg in cfg.channels.items():
            if not channel_cfg.enabled:
                continue
            handler = self._handlers.get(channel_name)
            if handler is None:
                continue
            for account_id, account in channel_cfg.accounts.items():
                handler.register_routes(app, account_id, account)
