"""Channel plugin package for ActFlare."""

from actflare.channels.base import ChannelHandler, ChannelRegistry

__all__ = ["ChannelHandler", "ChannelRegistry"]
