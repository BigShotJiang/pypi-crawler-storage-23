```bash
uv run ezrules api --port 8888
```

