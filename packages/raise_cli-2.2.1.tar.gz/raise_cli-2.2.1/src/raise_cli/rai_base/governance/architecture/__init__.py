"""Bundled architecture document templates."""
