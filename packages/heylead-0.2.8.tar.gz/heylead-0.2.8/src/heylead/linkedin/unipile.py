"""Unipile HTTP client for HeyLead — all LinkedIn operations go through here.

Handles all LinkedIn operations for HeyLead's scope:
- Hosted auth link creation (setup flow)
- Account listing / polling / verification
- Profile fetching
- People search
- Invitation sending
- Chat/message fetching

Uses direct httpx calls — no Unipile SDK dependency.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from .. import config
from ..constants import UNIPILE_POLL_INTERVAL_SECONDS, UNIPILE_POLL_TIMEOUT_SECONDS

logger = logging.getLogger(__name__)

_TIMEOUT = httpx.Timeout(30.0, connect=30.0, read=60.0, write=60.0)

# Retry configuration for transient failures (send operations only)
_MAX_RETRIES = 3
_RETRY_BACKOFF = [2, 4, 8]  # seconds
_RETRYABLE_STATUS_CODES = {502, 503, 504}


# ──────────────────────────────────────────────
# Exceptions
# ──────────────────────────────────────────────

class UnipileError(Exception):
    """Base error for Unipile API failures."""


class UnipileAuthError(UnipileError):
    """Raised when the Unipile account is disconnected or auth fails."""

    def __init__(self, message: str = "") -> None:
        self.message = message or (
            "🔑 LinkedIn account disconnected.\n\n"
            "Run setup_profile again to reconnect your LinkedIn account."
        )
        super().__init__(self.message)


# ──────────────────────────────────────────────
# Client
# ──────────────────────────────────────────────

class UnipileClient:
    """Async Unipile HTTP client for LinkedIn operations.

    Config loaded from ~/.heylead/config.json:
        unipile_api_url: e.g. "https://apiXX.unipile.com:XXXXX"
        unipile_api_key: X-API-KEY header value
    """

    def __init__(self, api_url: str, api_key: str) -> None:
        # Clean URL: remove non-printable chars, ensure https://
        raw = re.sub(r"[^\x20-\x7E]", "", api_url.strip()).rstrip("/")
        if not raw.startswith("http://") and not raw.startswith("https://"):
            raw = f"https://{raw}"
        self.base_url = raw
        self.api_key = api_key.strip()
        self._client = httpx.AsyncClient(timeout=_TIMEOUT)

    def _headers(self) -> dict[str, str]:
        return {
            "accept": "application/json",
            "content-type": "application/json",
            "X-API-KEY": self.api_key,
        }

    async def close(self) -> None:
        await self._client.aclose()

    async def _retry_request(
        self,
        method: str,
        url: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
    ) -> httpx.Response:
        """HTTP request with retry on transient failures.

        Used for send operations (invitation, message, comment, reaction, posts).
        Setup/auth operations should NOT use this — they fail fast.
        """
        last_error: Exception | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                if method.upper() == "GET":
                    resp = await self._client.get(url, headers=self._headers(), params=params)
                else:
                    resp = await self._client.post(url, json=json, headers=self._headers())

                if resp.status_code in _RETRYABLE_STATUS_CODES and attempt < _MAX_RETRIES - 1:
                    delay = _RETRY_BACKOFF[attempt]
                    logger.info(f"Retry {method} {url} (HTTP {resp.status_code}, attempt {attempt + 1}, {delay}s)")
                    await asyncio.sleep(delay)
                    continue
                return resp

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_error = e
                if attempt < _MAX_RETRIES - 1:
                    delay = _RETRY_BACKOFF[attempt]
                    logger.info(f"Retry {method} {url} ({type(e).__name__}, attempt {attempt + 1}, {delay}s)")
                    await asyncio.sleep(delay)
                else:
                    raise
        raise last_error or httpx.TimeoutException("All retries exhausted")

    # ── Auth / Account Management ──

    async def create_hosted_auth_link(self, success_redirect_url: str = "") -> str:
        """Create a hosted auth link for LinkedIn OAuth.

        Returns the URL the user should open in their browser.
        """
        # expiresOn: 24h from now, ISO 8601 with exactly 3ms digits
        future = datetime.now(timezone.utc) + timedelta(hours=24)
        expires_on = future.strftime("%Y-%m-%dT%H:%M:%S") + f".{future.microsecond // 1000:03d}Z"

        payload: dict[str, Any] = {
            "expiresOn": expires_on,
            "api_url": self.base_url,
            "type": "create",
            "providers": ["LINKEDIN"],
        }

        if success_redirect_url:
            payload["success_redirect_url"] = success_redirect_url

        url = f"{self.base_url}/api/v1/hosted/accounts/link"
        try:
            resp = await self._client.post(url, json=payload, headers=self._headers())
            resp.raise_for_status()
            result = resp.json()
            auth_url = result.get("url")
            if not auth_url:
                raise UnipileError(f"Unipile response missing 'url': {result}")
            return auth_url
        except httpx.HTTPStatusError as e:
            detail = ""
            try:
                detail = str(e.response.json())
            except Exception:
                detail = e.response.text[:300]
            raise UnipileError(f"Failed to create auth link: {e.response.status_code} — {detail}") from e

    async def list_accounts(self) -> list[dict[str, Any]]:
        """List all accounts from Unipile."""
        url = f"{self.base_url}/api/v1/accounts"
        resp = await self._client.get(url, headers=self._headers())
        resp.raise_for_status()
        data = resp.json()

        if isinstance(data, list):
            return data
        elif isinstance(data, dict):
            return data.get("items") or data.get("accounts") or data.get("data") or []
        return []

    async def find_linkedin_account(self) -> tuple[str | None, str]:
        """Find a LinkedIn account among connected Unipile accounts.

        Returns (account_id, message).
        """
        try:
            accounts = await self.list_accounts()
        except Exception as e:
            return None, f"Failed to list accounts: {e}"

        if not accounts:
            return None, "No accounts found in Unipile."

        def _is_linkedin(acc: dict) -> bool:
            provider = acc.get("provider") or acc.get("provider_type") or acc.get("type") or ""
            return "LINKEDIN" in str(provider).upper()

        linkedin_accounts = [a for a in accounts if _is_linkedin(a)]
        if not linkedin_accounts:
            providers = [a.get("provider") for a in accounts]
            return None, f"No LinkedIn accounts found. Providers: {providers}"

        account = linkedin_accounts[0]
        account_id = (
            account.get("id")
            or account.get("account_id")
            or account.get("accountId")
            or account.get("uuid")
        )
        if account_id:
            return str(account_id), "Found LinkedIn account"
        return None, "LinkedIn account found but no ID field"

    async def verify_account(self, account_id: str) -> tuple[bool, str]:
        """Check if a Unipile account is still connected.

        Returns (is_connected, message).
        """
        try:
            url = f"{self.base_url}/api/v1/accounts/{account_id}"
            resp = await self._client.get(url, headers=self._headers())
            if resp.status_code == 404:
                return False, "Account not found in Unipile"
            resp.raise_for_status()
            data = resp.json()

            status = data.get("status") or data.get("state") or data.get("connection_status") or ""
            if isinstance(status, str) and status.lower() in ("disconnected", "error", "failed", "expired"):
                return False, f"Account status: {status}"

            provider = (data.get("provider") or "").upper()
            if provider and "LINKEDIN" not in provider:
                return False, f"Account is not LinkedIn (provider: {provider})"

            return True, "Connected"
        except Exception as e:
            return False, f"Verification error: {e}"

    async def poll_for_account(
        self,
        timeout_seconds: int = UNIPILE_POLL_TIMEOUT_SECONDS,
        interval: int = UNIPILE_POLL_INTERVAL_SECONDS,
    ) -> tuple[str | None, str]:
        """Poll for a LinkedIn account to appear after OAuth.

        Loops every `interval` seconds until timeout.
        Returns (account_id, message).
        """
        elapsed = 0
        while elapsed < timeout_seconds:
            account_id, msg = await self.find_linkedin_account()
            if account_id:
                # Verify it's actually connected
                connected, status = await self.verify_account(account_id)
                if connected:
                    return account_id, "LinkedIn account connected!"
            await asyncio.sleep(interval)
            elapsed += interval

        return None, f"Timed out after {timeout_seconds}s waiting for LinkedIn connection."

    async def get_existing_account_ids(self) -> set[str]:
        """Snapshot all current account IDs (used to detect new accounts)."""
        try:
            accounts = await self.list_accounts()
        except Exception:
            return set()
        ids: set[str] = set()
        for acc in accounts:
            aid = acc.get("id") or acc.get("account_id") or acc.get("accountId") or acc.get("uuid")
            if aid:
                ids.add(str(aid))
        return ids

    async def poll_for_new_account(
        self,
        known_ids: set[str],
        timeout_seconds: int = UNIPILE_POLL_TIMEOUT_SECONDS,
        interval: int = UNIPILE_POLL_INTERVAL_SECONDS,
    ) -> tuple[str | None, str]:
        """Poll for a NEW LinkedIn account that wasn't in known_ids.

        This ensures we only pick up the account the current user just connected,
        not pre-existing accounts from other users on the same Unipile workspace.

        Returns (account_id, message).
        """
        elapsed = 0
        while elapsed < timeout_seconds:
            try:
                accounts = await self.list_accounts()
            except Exception:
                await asyncio.sleep(interval)
                elapsed += interval
                continue

            for acc in accounts:
                aid = acc.get("id") or acc.get("account_id") or acc.get("accountId") or acc.get("uuid")
                if not aid or str(aid) in known_ids:
                    continue
                provider = acc.get("provider") or acc.get("provider_type") or acc.get("type") or ""
                if "LINKEDIN" not in str(provider).upper():
                    continue
                # Found a new LinkedIn account
                account_id = str(aid)
                connected, status = await self.verify_account(account_id)
                if connected:
                    return account_id, "LinkedIn account connected!"

            await asyncio.sleep(interval)
            elapsed += interval

        return None, f"Timed out after {timeout_seconds}s waiting for LinkedIn connection."

    # ── Profile ──

    async def get_own_profile(self, account_id: str) -> dict[str, Any]:
        """Fetch the authenticated user's LinkedIn profile.

        Returns a normalized profile dict matching HeyLead's format.
        """
        url = f"{self.base_url}/api/v1/users/me?account_id={account_id}"
        resp = await self._client.get(url, headers=self._headers())

        if resp.status_code in (401, 403):
            raise UnipileAuthError()
        resp.raise_for_status()

        data = resp.json()
        if isinstance(data, list) and data:
            data = data[0]

        # Normalize to HeyLead profile format
        first_name = data.get("first_name") or data.get("firstName") or ""
        last_name = data.get("last_name") or data.get("lastName") or ""
        headline = data.get("headline") or data.get("occupation") or ""
        public_id = data.get("public_identifier") or data.get("publicIdentifier") or ""
        provider_id = data.get("provider_id") or data.get("id") or ""

        # Parse title + company from headline ("Title at Company")
        title = headline
        company = ""
        if " at " in headline:
            parts = headline.rsplit(" at ", 1)
            title = parts[0]
            company = parts[1]

        # Try to get from experience if available
        experience = data.get("experience") or data.get("positions") or []
        if isinstance(experience, list) and experience:
            current = experience[0]
            if isinstance(current, dict):
                title = current.get("title") or current.get("role") or title
                company = current.get("company") or current.get("company_name") or company

        # Extract location
        location = data.get("location") or ""
        if isinstance(location, dict):
            location = location.get("name") or location.get("default") or str(location)

        # Extract skills
        skills_raw = data.get("skills") or []
        skills: list[str] = []
        if isinstance(skills_raw, list):
            for s in skills_raw:
                if isinstance(s, str):
                    skills.append(s)
                elif isinstance(s, dict):
                    skills.append(s.get("name") or s.get("skill") or str(s))

        return {
            "name": f"{first_name} {last_name}".strip(),
            "first_name": first_name,
            "last_name": last_name,
            "headline": headline,
            "title": title,
            "company": company,
            "location": location,
            "summary": data.get("summary") or data.get("about") or "",
            "industry": data.get("industry") or "",
            "public_id": public_id,
            "provider_id": str(provider_id),
            "profile_url": f"https://www.linkedin.com/in/{public_id}" if public_id else "",
            "connections": data.get("connections_count") or data.get("network_info", {}).get("connections_count", 0),
            "skills": skills,
            "experience": experience if isinstance(experience, list) else [],
            "posts": [],  # Populated separately via get_posts()
        }

    async def get_posts(
        self, account_id: str, provider_id: str = "", limit: int = 10,
    ) -> list[dict[str, str]]:
        """Fetch recent LinkedIn posts for the user.

        Returns list of {"text": "...", "urn": "..."}.
        """
        identifier = provider_id or account_id
        url = f"{self.base_url}/api/v1/users/{identifier}/posts?account_id={account_id}&limit={limit}"

        try:
            resp = await self._client.get(url, headers=self._headers())
            if resp.status_code in (404, 400):
                logger.info(f"Posts endpoint returned {resp.status_code}, trying fallback")
                return []
            resp.raise_for_status()
            data = resp.json()

            items = []
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                items = data.get("items") or data.get("data") or data.get("posts") or []

            posts: list[dict[str, str]] = []
            for item in items[:limit]:
                text = ""
                if isinstance(item, dict):
                    text = item.get("text") or item.get("body") or item.get("content") or ""
                elif isinstance(item, str):
                    text = item
                if text:
                    urn = ""
                    if isinstance(item, dict):
                        urn = item.get("id") or item.get("urn") or item.get("social_id") or ""
                    posts.append({"text": str(text), "urn": str(urn)})

            return posts
        except Exception as e:
            logger.warning(f"Failed to fetch posts: {e}")
            return []

    # ── Search ──

    async def search_people(
        self,
        account_id: str,
        keywords: str = "",
        title: str = "",
        location: str = "",
        count: int = 25,
        *,
        # Structured search filters (Gap 1 — from ICP enriched codes)
        industry_codes: list[str] | None = None,
        location_codes: list[str] | None = None,
        title_keywords: list[str] | None = None,
        seniority: list[str] | None = None,
        company_headcount: dict[str, int] | None = None,
        company_types: list[str] | None = None,
        department_codes: list[str] | None = None,
        tenure: dict[str, int] | None = None,
        # Sales Navigator support (Gap 2)
        use_sales_navigator: bool = False,
        # Role codes for Sales Navigator
        role_codes: list[str] | None = None,
        # Pagination cursor (Gap 3)
        cursor: str | None = None,
    ) -> tuple[list[dict[str, Any]], str | None]:
        """Search LinkedIn for people matching criteria via Unipile.

        Supports both Classic and Sales Navigator search with structured filters.
        Returns (results, next_cursor) tuple for pagination.
        """
        search_query = keywords
        if title and title.lower() not in keywords.lower():
            search_query = f"{title} {keywords}"

        url = f"{self.base_url}/api/v1/linkedin/search?account_id={account_id}"

        # ── Build payload based on search mode ──
        if use_sales_navigator:
            payload = self._build_navigator_payload(
                keywords=search_query,
                count=count,
                industry_codes=industry_codes,
                location_codes=location_codes,
                role_codes=role_codes,
                seniority=seniority,
                company_headcount=company_headcount,
                company_types=company_types,
                department_codes=department_codes,
                tenure=tenure,
            )
        else:
            payload = self._build_classic_payload(
                keywords=search_query,
                count=count,
                industry_codes=industry_codes,
                location_codes=location_codes,
                title_keywords=title_keywords,
            )

        if cursor:
            payload["cursor"] = cursor

        try:
            resp = await self._client.post(url, json=payload, headers=self._headers())
            if resp.status_code in (401, 403):
                raise UnipileAuthError()
            resp.raise_for_status()
            data = resp.json()

            items = data.get("items") or data.get("results") or data.get("data") or []
            if isinstance(data, list):
                items = data

            # Extract pagination cursor
            next_cursor = None
            if isinstance(data, dict):
                next_cursor = data.get("cursor") or data.get("next_cursor") or data.get("paging", {}).get("cursor")

            results = self._parse_search_results(items)
            return results, next_cursor
        except UnipileAuthError:
            raise
        except Exception as e:
            logger.warning(f"Unipile search error: {e}")
            return [], None

    def _build_classic_payload(
        self,
        keywords: str,
        count: int,
        industry_codes: list[str] | None = None,
        location_codes: list[str] | None = None,
        title_keywords: list[str] | None = None,
    ) -> dict[str, Any]:
        """Build a Classic LinkedIn search payload with structured filters."""
        payload: dict[str, Any] = {
            "api": "classic",
            "category": "people",
            "limit": min(count, 50),
        }

        if keywords:
            payload["keywords"] = keywords

        # Structured filters (LinkedIn internal codes)
        if industry_codes:
            payload["industry"] = industry_codes
        if location_codes:
            payload["location"] = location_codes
        if title_keywords:
            # Classic uses advanced_keywords.title with OR logic
            payload["advanced_keywords"] = {
                "title": " OR ".join(title_keywords),
            }

        return payload

    def _build_navigator_payload(
        self,
        keywords: str,
        count: int,
        industry_codes: list[str] | None = None,
        location_codes: list[str] | None = None,
        role_codes: list[str] | None = None,
        seniority: list[str] | None = None,
        company_headcount: dict[str, int] | None = None,
        company_types: list[str] | None = None,
        department_codes: list[str] | None = None,
        tenure: dict[str, int] | None = None,
    ) -> dict[str, Any]:
        """Build a Sales Navigator search payload with full structured filters."""
        payload: dict[str, Any] = {
            "api": "sales_navigator",
            "category": "people",
            "limit": min(count, 100),  # Navigator supports up to 100 per page
        }

        if keywords:
            payload["keywords"] = keywords

        # Include/exclude patterns for Navigator
        if industry_codes:
            payload["industry"] = {"include": industry_codes}
        if location_codes:
            payload["location"] = {"include": location_codes}
        if role_codes:
            payload["role"] = {"include": role_codes}
        if seniority:
            payload["seniority"] = {"include": seniority}
        if company_headcount:
            payload["company_headcount"] = [company_headcount]
        if company_types:
            payload["company_type"] = company_types
        if department_codes:
            payload["function"] = {"include": department_codes}
        if tenure:
            payload["tenure"] = [tenure]

        return payload

    @staticmethod
    def _parse_search_results(items: list) -> list[dict[str, Any]]:
        """Parse Unipile search result items into normalized prospect dicts."""
        results: list[dict[str, Any]] = []
        for item in items:
            if not isinstance(item, dict):
                continue

            name_parts = []
            if item.get("first_name") or item.get("firstName"):
                name_parts.append(item.get("first_name") or item.get("firstName") or "")
            if item.get("last_name") or item.get("lastName"):
                name_parts.append(item.get("last_name") or item.get("lastName") or "")
            name = " ".join(name_parts).strip() or item.get("name") or ""

            if not name:
                continue

            headline = item.get("headline") or ""
            pub_id = item.get("public_identifier") or item.get("publicIdentifier") or ""
            prov_id = item.get("provider_id") or item.get("id") or item.get("member_urn") or ""

            # Parse title + company from headline
            parsed_title = headline
            parsed_company = ""
            if " at " in headline:
                parts = headline.rsplit(" at ", 1)
                parsed_title = parts[0]
                parsed_company = parts[1]

            loc = item.get("location") or ""
            if isinstance(loc, dict):
                loc = loc.get("name") or loc.get("default") or ""

            profile_url = item.get("profile_url") or item.get("public_profile_url") or ""
            if not profile_url and pub_id:
                profile_url = f"https://www.linkedin.com/in/{pub_id}"

            results.append({
                "name": name,
                "title": parsed_title,
                "company": parsed_company,
                "headline": headline,
                "location": str(loc),
                "linkedin_url": profile_url,
                "public_id": pub_id,
                "provider_id": str(prov_id),
            })
        return results

    # ── Sales Navigator Detection (Gap 2) ──

    async def detect_sales_navigator(self, account_id: str) -> bool:
        """Check if the LinkedIn account has Sales Navigator access.

        Tries a minimal Sales Navigator search. If it succeeds, the account
        has Sales Navigator. If it 403s or errors, it doesn't.
        """
        url = f"{self.base_url}/api/v1/linkedin/search?account_id={account_id}"
        payload = {
            "api": "sales_navigator",
            "category": "people",
            "keywords": "test",
            "limit": 1,
        }
        try:
            resp = await self._client.post(url, json=payload, headers=self._headers())
            # 200 = Sales Navigator works, anything else = no access
            return resp.status_code == 200
        except Exception:
            return False

    # ── Full Profile Enrichment (Gap 4) ──

    async def get_profile(
        self,
        account_id: str,
        identifier: str,
        use_sales_navigator: bool = False,
    ) -> dict[str, Any]:
        """Fetch full LinkedIn profile with all sections (experience, skills, etc.).

        Unlike get_own_profile() which fetches the authenticated user's profile,
        this fetches ANY user's profile by their public_id or provider_id.

        Args:
            account_id: The Unipile account ID.
            identifier: The user's public_identifier or provider_id.
            use_sales_navigator: If True, use Sales Navigator API for richer data.

        Returns:
            Full profile dict with all available LinkedIn sections.
        """
        url = f"{self.base_url}/api/v1/users/{identifier}"
        params: dict[str, str] = {
            "account_id": account_id,
            "linkedin_sections": "*",  # Request ALL sections
        }
        if use_sales_navigator:
            params["linkedin_api"] = "sales_navigator"

        try:
            resp = await self._retry_request("GET", url, params=params)
            if resp.status_code in (404, 400):
                logger.info(f"Profile not found for {identifier}")
                return {}
            if resp.status_code in (401, 403):
                raise UnipileAuthError()
            resp.raise_for_status()
            data = resp.json()

            if isinstance(data, list) and data:
                data = data[0]
            if not isinstance(data, dict):
                return {}

            # Normalize to HeyLead's profile format
            first_name = data.get("first_name") or data.get("firstName") or ""
            last_name = data.get("last_name") or data.get("lastName") or ""
            headline = data.get("headline") or data.get("occupation") or ""

            parsed_title = headline
            parsed_company = ""
            if " at " in headline:
                parts = headline.rsplit(" at ", 1)
                parsed_title = parts[0]
                parsed_company = parts[1]

            experience = data.get("experience") or data.get("positions") or []
            if isinstance(experience, list) and experience:
                current = experience[0]
                if isinstance(current, dict):
                    parsed_title = current.get("title") or current.get("role") or parsed_title
                    parsed_company = current.get("company") or current.get("company_name") or parsed_company

            loc = data.get("location") or ""
            if isinstance(loc, dict):
                loc = loc.get("name") or loc.get("default") or str(loc)

            skills_raw = data.get("skills") or []
            skills: list[str] = []
            if isinstance(skills_raw, list):
                for s in skills_raw:
                    if isinstance(s, str):
                        skills.append(s)
                    elif isinstance(s, dict):
                        skills.append(s.get("name") or s.get("skill") or str(s))

            pub_id = data.get("public_identifier") or data.get("publicIdentifier") or ""
            prov_id = data.get("provider_id") or data.get("id") or ""

            return {
                "name": f"{first_name} {last_name}".strip(),
                "first_name": first_name,
                "last_name": last_name,
                "headline": headline,
                "title": parsed_title,
                "company": parsed_company,
                "location": str(loc),
                "summary": data.get("summary") or data.get("about") or "",
                "industry": data.get("industry") or "",
                "public_id": pub_id,
                "provider_id": str(prov_id),
                "profile_url": f"https://www.linkedin.com/in/{pub_id}" if pub_id else "",
                "connections": data.get("connections_count") or data.get("network_info", {}).get("connections_count", 0),
                "skills": skills,
                "experience": experience if isinstance(experience, list) else [],
                "education": data.get("education") or [],
                "certifications": data.get("certifications") or [],
            }
        except UnipileAuthError:
            raise
        except Exception as e:
            logger.warning(f"Profile fetch error for {identifier}: {e}")
            return {}

    # ── Relation Pre-check (Gap 5) ──

    async def check_existing_relation(
        self,
        account_id: str,
        provider_id: str,
    ) -> dict[str, Any]:
        """Check if we already have a relation with a prospect.

        Checks for:
        - Existing connection
        - Pending invitation
        - Existing chat/conversation

        Returns:
            {"connected": bool, "pending_invite": bool, "has_chat": bool, "chat_id": str}
        """
        result = {
            "connected": False,
            "pending_invite": False,
            "has_chat": False,
            "chat_id": "",
        }

        # Check pending invitations
        try:
            inv_url = f"{self.base_url}/api/v1/users/invitations?account_id={account_id}&type=sent"
            resp = await self._client.get(inv_url, headers=self._headers())
            if resp.status_code == 200:
                inv_data = resp.json()
                invitations = inv_data.get("items") or inv_data.get("data") or []
                if isinstance(inv_data, list):
                    invitations = inv_data
                for inv in invitations:
                    if not isinstance(inv, dict):
                        continue
                    inv_prov_id = (
                        inv.get("provider_id") or inv.get("id")
                        or inv.get("to_member_id") or ""
                    )
                    if str(inv_prov_id) == str(provider_id):
                        result["pending_invite"] = True
                        break
        except Exception as e:
            logger.debug(f"Invitation check skipped: {e}")

        # Check existing chat (indicates connection)
        try:
            chat_id = await self.find_chat_for_user(account_id, provider_id)
            if chat_id:
                result["has_chat"] = True
                result["chat_id"] = chat_id
                result["connected"] = True
        except Exception as e:
            logger.debug(f"Chat check skipped: {e}")

        return result

    async def find_chat_for_user(
        self,
        account_id: str,
        prospect_linkedin_id: str,
    ) -> str | None:
        """Find the chat_id for a conversation with a specific prospect."""
        url = f"{self.base_url}/api/v1/chats?account_id={account_id}&limit=50"
        try:
            resp = await self._client.get(url, headers=self._headers())
            if resp.status_code != 200:
                return None
            data = resp.json()

            items = data.get("items") or data.get("chats") or data.get("data") or []
            if isinstance(data, list):
                items = data

            for chat in items:
                if not isinstance(chat, dict):
                    continue
                chat_id = chat.get("id") or chat.get("chat_id") or ""
                if not chat_id:
                    continue
                attendees = chat.get("attendees") or []
                for att in attendees:
                    if not isinstance(att, dict):
                        continue
                    att_id = att.get("provider_id") or att.get("id") or ""
                    if str(att_id) == str(prospect_linkedin_id):
                        return str(chat_id)
            return None
        except Exception as e:
            logger.warning(f"find_chat_for_user failed: {e}")
            return None

    # ── Search Parameters ──

    async def get_search_params(
        self, account_id: str, type: str, keywords: str,
    ) -> list[dict[str, str]]:
        """Look up LinkedIn search parameter codes via Unipile.

        Args:
            account_id: The Unipile account ID.
            type: Parameter type (LOCATION, INDUSTRY, JOB_TITLE, DEPARTMENT, etc.)
            keywords: Search keywords to look up codes for.

        Returns:
            List of {name, code} dicts.
        """
        url = f"{self.base_url}/api/v1/linkedin/search/parameters"
        params = {
            "account_id": account_id,
            "type": type,
            "keywords": keywords,
        }
        try:
            resp = await self._client.get(url, headers=self._headers(), params=params)
            resp.raise_for_status()
            data = resp.json()
            items = data.get("items") or []
            return [
                {"name": item.get("title", ""), "code": str(item.get("id", ""))}
                for item in items
                if item.get("title") and item.get("id")
            ]
        except Exception as e:
            logger.warning(f"Search params lookup failed: {e}")
            return []

    # ── Messaging ──

    async def send_invitation(
        self,
        account_id: str,
        provider_id: str,
        message: str = "",
    ) -> dict[str, Any]:
        """Send a LinkedIn connection invitation via Unipile.

        Returns {"success": bool, "error": str, "blocked": bool, "auth_error": bool}.
        """
        result: dict[str, Any] = {"success": False, "error": "", "blocked": False, "auth_error": False}

        url = f"{self.base_url}/api/v1/users/invite"
        payload: dict[str, Any] = {
            "account_id": account_id,
            "provider_id": provider_id,
        }
        if message:
            payload["message"] = message[:200]

        try:
            resp = await self._retry_request("POST", url, json=payload)

            if resp.status_code in (200, 201):
                result["success"] = True
            elif resp.status_code == 429:
                result["error"] = "Rate limited by LinkedIn. Will retry later."
                result["blocked"] = True
            elif resp.status_code in (401, 403):
                result["error"] = "LinkedIn account disconnected."
                result["auth_error"] = True
                result["blocked"] = True
            elif resp.status_code == 409:
                result["error"] = "Already connected or invitation pending."
            else:
                body = resp.text[:200]
                result["error"] = f"Unipile returned {resp.status_code}: {body}"

        except httpx.TimeoutException:
            result["error"] = "Request timed out after retries. Check your internet connection."
        except Exception as e:
            result["error"] = f"Send failed: {e}"

        return result

    # ── DM Messaging ──

    async def send_message(
        self,
        account_id: str,
        chat_id: str,
        text: str,
    ) -> dict[str, Any]:
        """Send a DM message in an existing LinkedIn chat/conversation.

        Args:
            account_id: The Unipile account ID.
            chat_id: The chat/conversation ID to send the message in.
            text: The message text to send.

        Returns:
            {"success": bool, "error": str}
        """
        result: dict[str, Any] = {"success": False, "error": ""}
        url = f"{self.base_url}/api/v1/chats/{chat_id}/messages"
        payload = {
            "account_id": account_id,
            "text": text,
        }
        try:
            resp = await self._retry_request("POST", url, json=payload)
            if resp.status_code in (200, 201):
                result["success"] = True
            elif resp.status_code in (401, 403):
                result["error"] = "LinkedIn account disconnected."
            elif resp.status_code == 429:
                result["error"] = "Rate limited by LinkedIn."
            else:
                body = resp.text[:200]
                result["error"] = f"Unipile returned {resp.status_code}: {body}"
        except httpx.TimeoutException:
            result["error"] = "Request timed out after retries."
        except Exception as e:
            result["error"] = f"Send failed: {e}"
        return result

    async def get_chat_messages(
        self,
        account_id: str,
        chat_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Fetch messages from a specific LinkedIn chat/conversation.

        Args:
            account_id: The Unipile account ID.
            chat_id: The chat/conversation ID.
            limit: Max number of messages to return.

        Returns:
            List of message dicts with sender_id, text, timestamp.
        """
        url = f"{self.base_url}/api/v1/chats/{chat_id}/messages?account_id={account_id}&limit={limit}"
        try:
            resp = await self._client.get(url, headers=self._headers())
            if resp.status_code in (401, 403):
                raise UnipileAuthError()
            resp.raise_for_status()
            data = resp.json()

            items = data.get("items") or data.get("messages") or data.get("data") or []
            if isinstance(data, list):
                items = data

            messages: list[dict[str, Any]] = []
            for msg in items[:limit]:
                if not isinstance(msg, dict):
                    continue
                text = msg.get("text") or msg.get("body") or msg.get("content") or ""
                sender_id = msg.get("sender_id") or msg.get("sender", {}).get("provider_id", "")
                sender_name = msg.get("sender_name") or msg.get("sender", {}).get("display_name", "")
                ts_raw = msg.get("timestamp") or msg.get("created_at") or msg.get("date") or ""
                timestamp = 0
                if isinstance(ts_raw, (int, float)):
                    timestamp = int(ts_raw)
                elif isinstance(ts_raw, str) and ts_raw:
                    try:
                        timestamp = int(datetime.fromisoformat(ts_raw.replace("Z", "+00:00")).timestamp())
                    except (ValueError, TypeError):
                        pass
                messages.append({
                    "sender_id": str(sender_id),
                    "sender_name": str(sender_name),
                    "text": text,
                    "timestamp": timestamp,
                })
            return messages
        except UnipileAuthError:
            raise
        except Exception as e:
            logger.warning(f"Failed to fetch chat messages: {e}")
            return []

    # ── User Posts (for any user, not just self) ──

    async def get_user_posts(
        self,
        account_id: str,
        identifier: str,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Fetch recent posts for any LinkedIn user (by provider_id or public_id).

        Unlike get_posts() which is for the authenticated user's own posts,
        this fetches posts for any user identified by their provider_id.

        Args:
            account_id: The Unipile account ID.
            identifier: The user's provider_id or public_identifier.
            limit: Max number of posts to return.

        Returns:
            List of post dicts with id, text, date, metrics.
        """
        url = f"{self.base_url}/api/v1/users/{identifier}/posts?account_id={account_id}&limit={limit}"
        try:
            resp = await self._retry_request("GET", url)
            if resp.status_code in (404, 400):
                logger.info(f"User posts endpoint returned {resp.status_code}")
                return []
            resp.raise_for_status()
            data = resp.json()

            items = []
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                items = data.get("items") or data.get("data") or data.get("posts") or []

            posts: list[dict[str, Any]] = []
            for item in items[:limit]:
                if not isinstance(item, dict):
                    continue
                text = item.get("text") or item.get("body") or item.get("content") or ""
                if not text:
                    continue
                post_id = item.get("id") or item.get("urn") or item.get("social_id") or ""
                post_date = item.get("date") or item.get("created_at") or ""
                metrics = item.get("metrics") or item.get("social_counts") or {}
                posts.append({
                    "id": str(post_id),
                    "text": str(text),
                    "date": str(post_date),
                    "metrics": metrics if isinstance(metrics, dict) else {},
                })
            return posts
        except Exception as e:
            logger.warning(f"Failed to fetch user posts: {e}")
            return []

    # ── Post Engagement ──

    async def send_post_comment(
        self,
        account_id: str,
        post_id: str,
        text: str,
    ) -> dict[str, Any]:
        """Send a comment on a LinkedIn post.

        Args:
            account_id: The Unipile account ID.
            post_id: The post ID/URN to comment on.
            text: The comment text.

        Returns:
            {"success": bool, "error": str}
        """
        result: dict[str, Any] = {"success": False, "error": ""}
        url = f"{self.base_url}/api/v1/posts/{post_id}/comments"
        payload = {
            "account_id": account_id,
            "text": text,
        }
        try:
            resp = await self._retry_request("POST", url, json=payload)
            if resp.status_code in (200, 201):
                result["success"] = True
            elif resp.status_code in (401, 403):
                result["error"] = "LinkedIn account disconnected."
            elif resp.status_code == 429:
                result["error"] = "Rate limited by LinkedIn."
            else:
                body = resp.text[:200]
                result["error"] = f"Unipile returned {resp.status_code}: {body}"
        except httpx.TimeoutException:
            result["error"] = "Request timed out after retries."
        except Exception as e:
            result["error"] = f"Comment failed: {e}"
        return result

    async def send_post_reaction(
        self,
        account_id: str,
        post_id: str,
        reaction_type: str = "LIKE",
    ) -> dict[str, Any]:
        """React to a LinkedIn post (like, celebrate, etc.).

        Args:
            account_id: The Unipile account ID.
            post_id: The post ID/URN to react to.
            reaction_type: Type of reaction (LIKE, CELEBRATE, SUPPORT, etc.)

        Returns:
            {"success": bool, "error": str}
        """
        result: dict[str, Any] = {"success": False, "error": ""}
        url = f"{self.base_url}/api/v1/posts/{post_id}/reactions"
        payload = {
            "account_id": account_id,
            "reaction_type": reaction_type,
        }
        try:
            resp = await self._retry_request("POST", url, json=payload)
            if resp.status_code in (200, 201):
                result["success"] = True
            elif resp.status_code in (401, 403):
                result["error"] = "LinkedIn account disconnected."
            elif resp.status_code == 429:
                result["error"] = "Rate limited by LinkedIn."
            else:
                body = resp.text[:200]
                result["error"] = f"Unipile returned {resp.status_code}: {body}"
        except httpx.TimeoutException:
            result["error"] = "Request timed out after retries."
        except Exception as e:
            result["error"] = f"Reaction failed: {e}"
        return result

    # ── Relations ──

    async def get_relations(
        self,
        account_id: str,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Fetch the user's LinkedIn connections/relations.

        Args:
            account_id: The Unipile account ID.
            limit: Max number of relations to return.

        Returns:
            List of relation dicts with provider_id, name, headline.
        """
        url = f"{self.base_url}/api/v1/users/relations?account_id={account_id}&limit={limit}"
        try:
            resp = await self._client.get(url, headers=self._headers())
            if resp.status_code in (401, 403):
                raise UnipileAuthError()
            resp.raise_for_status()
            data = resp.json()

            items = data.get("items") or data.get("relations") or data.get("data") or []
            if isinstance(data, list):
                items = data

            relations: list[dict[str, Any]] = []
            for item in items[:limit]:
                if not isinstance(item, dict):
                    continue
                provider_id = item.get("provider_id") or item.get("id") or ""
                name = item.get("display_name") or item.get("name") or ""
                if not name and (item.get("first_name") or item.get("last_name")):
                    name = f"{item.get('first_name', '')} {item.get('last_name', '')}".strip()
                headline = item.get("headline") or ""
                public_id = item.get("public_identifier") or item.get("publicIdentifier") or ""
                relations.append({
                    "provider_id": str(provider_id),
                    "name": name,
                    "headline": headline,
                    "public_id": public_id,
                })
            return relations
        except UnipileAuthError:
            raise
        except Exception as e:
            logger.warning(f"Failed to fetch relations: {e}")
            return []

    # ── Chats ──

    async def get_chats(
        self,
        account_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Fetch recent LinkedIn messages/chats via Unipile.

        Returns normalized message list matching HeyLead's format:
        [{"sender_name", "sender_id", "text", "timestamp", "conversation_urn"}]
        """
        url = f"{self.base_url}/api/v1/chats?account_id={account_id}&limit={limit}"

        try:
            resp = await self._client.get(url, headers=self._headers())
            if resp.status_code in (401, 403):
                raise UnipileAuthError()
            resp.raise_for_status()
            data = resp.json()

            items = data.get("items") or data.get("chats") or data.get("data") or []
            if isinstance(data, list):
                items = data

            messages: list[dict[str, Any]] = []
            for chat in items:
                if not isinstance(chat, dict):
                    continue

                chat_id = chat.get("id") or chat.get("chat_id") or ""

                # Get the last message
                chat_messages = chat.get("messages") or chat.get("last_messages") or []
                if isinstance(chat_messages, list) and chat_messages:
                    last_msg = chat_messages[-1] if isinstance(chat_messages[-1], dict) else {}
                elif isinstance(chat_messages, dict):
                    last_msg = chat_messages
                else:
                    last_msg = {}

                text = last_msg.get("text") or last_msg.get("body") or last_msg.get("content") or ""
                if not text:
                    continue

                # Identify the sender
                sender_id = last_msg.get("sender_id") or last_msg.get("sender", {}).get("provider_id", "")
                sender_name = last_msg.get("sender_name") or last_msg.get("sender", {}).get("display_name", "")

                # If no sender info in message, try attendees
                if not sender_name:
                    attendees = chat.get("attendees") or []
                    for att in attendees:
                        if isinstance(att, dict):
                            att_id = att.get("provider_id") or att.get("id") or ""
                            if att_id and att_id == sender_id:
                                sender_name = att.get("display_name") or att.get("name") or ""
                                break
                            elif not sender_name:
                                sender_name = att.get("display_name") or att.get("name") or ""

                # Parse timestamp
                ts_raw = last_msg.get("timestamp") or last_msg.get("created_at") or last_msg.get("date") or ""
                timestamp = 0
                if isinstance(ts_raw, (int, float)):
                    timestamp = int(ts_raw)
                elif isinstance(ts_raw, str) and ts_raw:
                    try:
                        from datetime import datetime as dt
                        timestamp = int(dt.fromisoformat(ts_raw.replace("Z", "+00:00")).timestamp())
                    except (ValueError, TypeError):
                        pass

                messages.append({
                    "sender_name": sender_name,
                    "sender_id": str(sender_id),
                    "text": text,
                    "timestamp": timestamp,
                    "conversation_urn": str(chat_id),
                })

            return messages
        except UnipileAuthError:
            raise
        except Exception as e:
            logger.warning(f"Failed to fetch chats: {e}")
            return []


# ──────────────────────────────────────────────
# Module-level helpers
# ──────────────────────────────────────────────

def get_unipile_client() -> UnipileClient:
    """Create a UnipileClient from config.json settings."""
    cfg = config.load_config()
    api_url = cfg.get("unipile_api_url", "")
    api_key = cfg.get("unipile_api_key", "")
    if not api_url or not api_key:
        raise UnipileError(
            "Unipile not configured.\n\n"
            "Run setup_profile to configure your Unipile API key and URL."
        )
    return UnipileClient(api_url, api_key)


def get_account_id() -> str | None:
    """Load the stored Unipile account_id from settings DB."""
    from ..db.queries import get_setting
    return get_setting("unipile_account_id", None)
