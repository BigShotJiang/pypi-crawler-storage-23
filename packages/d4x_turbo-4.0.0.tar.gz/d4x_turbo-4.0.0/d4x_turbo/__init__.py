"""
D4X-TURBO: Advanced Hybrid Speed Engine for Python Bots
"""

__version__ = "3.0.0"

from .engine import d4x

# Ye line ensure karti hai ki user sirf engine import kar sake, aur kuch kachra nahi
__all__ = ["d4x"] 
