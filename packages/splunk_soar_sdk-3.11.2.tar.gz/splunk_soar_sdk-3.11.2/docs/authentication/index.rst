.. _authentication:

Authentication
==============

These pages cover authentication mechanisms supported by the SDK for integrating with external services.

.. toctree::
   :maxdepth: 2

   basic
   static_token
   oauth
