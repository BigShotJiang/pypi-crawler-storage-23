# TEI Loop

**Target, Evaluate, Improve** — a self-improving loop for agentic systems.

## Get Started

```bash
pip install tei-loop
```

```bash
python3 -m tei_loop your_agent.py
```

TEI does the rest:
- Finds your agent function automatically
- Generates a test query automatically
- Evaluates across 4 dimensions
- Applies targeted improvements
- Saves results to `tei-results/` folder (created next to your agent file)

> If `pip` is not found, use `pip3` instead.

## What TEI Creates

```
your_project/
  your_agent.py
  tei-results/           <-- created automatically
    run_20260218_071500.json
    latest.json
```

## Options

```bash
python3 -m tei_loop agent.py                             # Auto everything
python3 -m tei_loop agent.py --function my_func          # Pick specific function
python3 -m tei_loop agent.py --query "custom input"      # Custom test query
python3 -m tei_loop agent.py --retries 5                 # More improvement cycles
python3 -m tei_loop agent.py --verbose                   # Detailed output
```

## Python API

```python
import asyncio
from tei_loop import TEILoop

def my_agent(query: str) -> str:
    return result

async def main():
    loop = TEILoop(agent=my_agent)
    result = await loop.run("test query")
    print(result.summary())

asyncio.run(main())
```

## 4 Evaluation Dimensions

| Dimension | What it checks |
|---|---|
| **Target Alignment** | Did the agent pursue the correct objective? |
| **Reasoning Soundness** | Was the reasoning logical? |
| **Execution Accuracy** | Were tools called correctly? |
| **Output Integrity** | Is the output complete and accurate? |

## Two Modes

**Runtime** (default): Per-query improvement in seconds.

**Development**: Across many queries, permanent prompt improvements.

```python
results = await loop.develop(queries=[...], max_iterations=50)
```

## Works With Any Agent

Any Python callable. No framework lock-in: LangGraph, CrewAI, custom Python, FastAPI, anything.

## License

MIT
