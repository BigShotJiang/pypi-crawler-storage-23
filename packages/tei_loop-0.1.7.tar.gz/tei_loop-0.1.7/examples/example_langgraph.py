"""
Example: Using TEI with a LangGraph agent.

TEI wraps the compiled graph as a callable — no changes to your graph needed.
"""
import asyncio
from tei_loop import TEILoop


# Assuming you have a LangGraph compiled graph:
# from my_app import compiled_graph
#
# async def main():
#     loop = TEILoop(
#         agent=lambda q: compiled_graph.invoke({"messages": [("user", q)]}),
#         verbose=True,
#     )
#     result = await loop.run("What restaurants are near me?")
#     print(result.summary())

# Or using the LangGraph adapter for deeper tracing:
# from tei_loop.adapters.langgraph import LangGraphAdapter
#
# adapter = LangGraphAdapter(compiled_graph)
# loop = TEILoop(agent=adapter.run, verbose=True)


def mock_langgraph_agent(query: str) -> str:
    """Placeholder — replace with your actual LangGraph agent."""
    return f"LangGraph would process: {query}"


async def main():
    loop = TEILoop(agent=mock_langgraph_agent, verbose=True)
    result = await loop.evaluate_only("Find Italian restaurants in SF for 4 people tonight")
    print(result.summary())


if __name__ == "__main__":
    asyncio.run(main())
