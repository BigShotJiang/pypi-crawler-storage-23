"""
TEI CLI.

Usage:
    pip install tei-loop
    python3 -m tei_loop your_agent.py

That's it. TEI handles everything else.
"""

from __future__ import annotations

import argparse
import asyncio
import importlib.util
import inspect
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional


GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"

SKIP_NAMES = {
    "load_dotenv", "OpenAI", "AsyncOpenAI", "FastAPI", "Request", "Response",
    "File", "Form", "Cookie", "HTMLResponse", "JSONResponse", "RedirectResponse",
    "UploadFile", "HTTPException", "Base", "asynccontextmanager", "contextmanager",
    "create_engine", "sessionmaker", "declarative_base", "DictLoader", "Environment",
    "app", "router", "client", "session", "engine", "render_template",
    "init_db", "lifespan", "health", "home", "login", "logout",
    "verify_session", "verify_credentials", "create_session_token",
}


def _find_agent_function(agent_file: str) -> tuple[Callable, str]:
    """Smart detection: find the actual agent function in any Python file."""
    path = Path(agent_file).resolve()
    if not path.exists():
        print(f"{RED}Error: File not found: {agent_file}{RESET}")
        sys.exit(1)

    spec = importlib.util.spec_from_file_location("agent_module", path)
    module = importlib.util.module_from_spec(spec)

    orig_dir = os.getcwd()
    os.chdir(path.parent)

    orig_argv = sys.argv
    sys.argv = [str(path)]

    if str(path.parent) not in sys.path:
        sys.path.insert(0, str(path.parent))

    try:
        spec.loader.exec_module(module)
    except SystemExit:
        pass
    except Exception as e:
        print(f"{YELLOW}Note: Module raised {type(e).__name__} during import (this is usually fine){RESET}")
    finally:
        sys.argv = orig_argv
        os.chdir(orig_dir)

    priority_names = ["agent", "run", "main", "invoke", "execute", "process",
                      "generate", "summarize", "analyze", "predict", "respond",
                      "answer", "handle", "complete", "generate_summary",
                      "generate_interview_summary", "run_agent", "call_agent"]
    for name in priority_names:
        fn = getattr(module, name, None)
        if callable(fn) and not isinstance(fn, type) and name not in SKIP_NAMES:
            return fn, name

    all_fns = []
    for name, obj in vars(module).items():
        if (callable(obj)
            and not name.startswith("_")
            and not isinstance(obj, type)
            and not inspect.isclass(obj)
            and name not in SKIP_NAMES):

            source = ""
            try:
                source = inspect.getsource(obj).lower()
            except (OSError, TypeError):
                pass

            is_agent_like = any(kw in source for kw in [
                "openai", "anthropic", "client.", "chat.completions",
                "messages.create", "generate_content", "llm", "model",
            ])

            sig = inspect.signature(obj)
            params = [p for p in sig.parameters.values()
                      if p.default is inspect.Parameter.empty and p.name != "self"]
            takes_one_input = len(params) == 1

            score = 0
            if is_agent_like:
                score += 10
            if takes_one_input:
                score += 5
            if "return" in source:
                score += 2

            all_fns.append((name, obj, score))

    all_fns.sort(key=lambda x: x[2], reverse=True)

    if all_fns:
        best = all_fns[0]
        return best[1], best[0]

    print(f"{RED}Error: No agent function found in {agent_file}{RESET}")
    print(f"{DIM}Tip: TEI looks for a function that takes one input and calls an LLM.{RESET}")
    sys.exit(1)


def _auto_generate_query(agent_fn: Callable, fn_name: str, agent_file: str) -> str:
    """Generate a test query by inspecting what the agent does."""
    source = ""
    try:
        source = inspect.getsource(agent_fn)
    except (OSError, TypeError):
        try:
            source = Path(agent_file).read_text()
        except Exception:
            pass

    source_lower = source.lower()

    if "interview" in source_lower or "transcript" in source_lower:
        return (
            "Q1: Tell me about yourself.\n"
            "A1: I'm Alex, 30, software engineer. I enjoy cooking and hiking.\n\n"
            "Q2: What does a typical day look like?\n"
            "A2: Wake up at 7, coffee, work from 9-5, gym after work, dinner at 7pm.\n\n"
            "Q3: What are your main goals right now?\n"
            "A3: Getting better at system design and training for a half marathon."
        )
    if "summar" in source_lower:
        return (
            "The global renewable energy market reached $1.2 trillion in 2025, "
            "driven by solar and wind installations. China led with 45% of new capacity. "
            "Key challenges include grid storage and supply chain constraints."
        )
    if "classif" in source_lower or "categor" in source_lower or "sentiment" in source_lower:
        return "The product arrived damaged and customer support has been unresponsive for three days."
    if "translat" in source_lower:
        return "Hello, how are you today? I would like to schedule a meeting for next Tuesday."
    if "code" in source_lower or "program" in source_lower:
        return "Write a function that finds the two numbers in a list that add up to a target sum."

    return (
        "Analyze the following: AI agents are becoming mainstream in enterprise workflows. "
        "Companies reported a 40% increase in automation but also cited quality and reliability "
        "as top concerns. What are the key implications?"
    )


def _print_result(result: Any) -> None:
    print(f"\n{BOLD}{CYAN}{'=' * 60}{RESET}")
    print(f"{BOLD}TEI Result{RESET}")
    print(f"{CYAN}{'=' * 60}{RESET}")

    print(f"  Iterations: {result.total_iterations}")

    bc = GREEN if result.baseline_score >= 0.7 else YELLOW if result.baseline_score >= 0.5 else RED
    fc = GREEN if result.final_score >= 0.7 else YELLOW if result.final_score >= 0.5 else RED

    print(f"  Baseline:   {bc}{result.baseline_score:.2f}{RESET}")
    print(f"  Final:      {fc}{result.final_score:.2f}{RESET}")

    delta = result.improvement_delta
    dc = GREEN if delta > 0 else RED if delta < 0 else YELLOW
    print(f"  Delta:      {dc}{delta:+.2f}{RESET}")
    print(f"  Duration:   {result.total_duration_ms / 1000:.1f}s")
    print(f"  Cost:       ${result.total_cost_usd:.4f}")

    print(f"\n  {BOLD}Scores (before -> after):{RESET}")
    for dim_name, before in result.before_scores.items():
        after = result.after_scores.get(dim_name, before)
        d = after - before
        c = GREEN if after >= 0.7 else YELLOW if after >= 0.5 else RED
        print(f"    {dim_name:<25} {before:.2f} -> {c}{after:.2f}{RESET}  {d:+.2f}" if d else
              f"    {dim_name:<25} {before:.2f} -> {c}{after:.2f}{RESET}")

    print(f"{CYAN}{'=' * 60}{RESET}\n")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tei",
        description="TEI: Target -> Evaluate -> Improve your AI agent",
        usage="python3 -m tei_loop <agent_file.py>",
    )
    parser.add_argument("agent_file", nargs="?", help="Path to your agent Python file")
    parser.add_argument("--query", "-q", help="Custom test query (auto-generated if omitted)")
    parser.add_argument("--function", "-f", help="Specific function name to test")
    parser.add_argument("--retries", "-r", type=int, default=3, help="Max improvement cycles")
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()

    if not args.agent_file:
        py_files = [f for f in Path(".").glob("*.py")
                    if not f.name.startswith("_") and not f.name.startswith("test_")]
        if len(py_files) == 1:
            args.agent_file = str(py_files[0])
        else:
            print(f"\n{BOLD}Usage:{RESET} python3 -m tei_loop <agent_file.py>\n")
            if py_files:
                print("Python files in current directory:")
                for f in sorted(py_files):
                    print(f"  {f.name}")
            sys.exit(0)

    from .loop import TEILoop

    agent_path = Path(args.agent_file).resolve()
    results_dir = agent_path.parent / "tei-results"
    results_dir.mkdir(exist_ok=True)

    print(f"\n{BOLD}{CYAN}TEI Loop{RESET} - Target, Evaluate, Improve\n")

    if args.function:
        path = agent_path
        spec = importlib.util.spec_from_file_location("agent_module", path)
        module = importlib.util.module_from_spec(spec)
        orig_dir = os.getcwd()
        os.chdir(path.parent)
        if str(path.parent) not in sys.path:
            sys.path.insert(0, str(path.parent))
        try:
            spec.loader.exec_module(module)
        except (SystemExit, Exception):
            pass
        finally:
            os.chdir(orig_dir)
        fn = getattr(module, args.function, None)
        if not fn:
            print(f"{RED}Function '{args.function}' not found.{RESET}")
            sys.exit(1)
        agent_fn, fn_name = fn, args.function
    else:
        agent_fn, fn_name = _find_agent_function(args.agent_file)

    print(f"  Agent:      {agent_path.name}")
    print(f"  Function:   {fn_name}()")
    print(f"  Results:    {results_dir}/")

    query = args.query or _auto_generate_query(agent_fn, fn_name, args.agent_file)
    if not args.query:
        print(f"  Test query: {DIM}(auto-generated){RESET}")

    print()

    loop = TEILoop(agent=agent_fn, verbose=args.verbose, max_retries=args.retries)

    result = asyncio.run(loop.run(query))
    _print_result(result)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    result_file = results_dir / f"run_{timestamp}.json"
    result_file.write_text(json.dumps(result.model_dump(mode="json"), indent=2, default=str))
    print(f"{GREEN}Results saved to tei-results/run_{timestamp}.json{RESET}")

    summary_file = results_dir / "latest.json"
    summary_file.write_text(json.dumps(result.model_dump(mode="json"), indent=2, default=str))


if __name__ == "__main__":
    main()
