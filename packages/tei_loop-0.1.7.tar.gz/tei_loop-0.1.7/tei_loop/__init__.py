"""
TEI Loop: Target -> Evaluate -> Improve

A self-improving loop for agentic systems.

Usage:
    from tei_loop import TEILoop

    loop = TEILoop(agent=my_agent_function)
    result = await loop.run("user query")
    print(result.summary())
"""

from .models import (
    Dimension,
    TEIConfig,
    TEIResult,
    EvalResult,
    Trace,
    TraceStep,
    Failure,
    Fix,
    RunMode,
)
from .loop import TEILoop
from .tracer import tei_trace
from .evaluator import TEIEvaluator
from .improver import TEIImprover

__version__ = "0.1.7"

__all__ = [
    "TEILoop",
    "TEIConfig",
    "TEIResult",
    "EvalResult",
    "Trace",
    "TraceStep",
    "Dimension",
    "Failure",
    "Fix",
    "RunMode",
    "TEIEvaluator",
    "TEIImprover",
    "tei_trace",
]
