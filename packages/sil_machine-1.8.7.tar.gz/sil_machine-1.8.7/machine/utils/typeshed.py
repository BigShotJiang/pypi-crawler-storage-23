from pathlib import PurePath
from typing import Union

StrPath = Union[str, PurePath]
