from enum import Enum, auto


class TextRowContentType(Enum):
    WORD = auto()
    SEGMENT = auto()
