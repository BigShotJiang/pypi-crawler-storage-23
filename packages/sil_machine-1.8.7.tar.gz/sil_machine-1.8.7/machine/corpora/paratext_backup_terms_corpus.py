from typing import Sequence
from zipfile import ZipFile

from ..utils.typeshed import StrPath
from .dictionary_text_corpus import DictionaryTextCorpus
from .key_term import KeyTerm
from .memory_text import MemoryText
from .text_row import TextRow
from .text_row_content_type import TextRowContentType
from .zip_paratext_project_settings_parser import ZipParatextProjectSettingsParser
from .zip_paratext_project_terms_parser import ZipParatextProjectTermsParser


class ParatextBackupTermsCorpus(DictionaryTextCorpus):
    def __init__(self, filename: StrPath, term_categories: Sequence[str], use_term_glosses: bool = True) -> None:
        super().__init__()

        with ZipFile(filename, "r") as archive:
            settings = ZipParatextProjectSettingsParser(archive).parse()
            key_terms: Sequence[KeyTerm] = ZipParatextProjectTermsParser(archive, settings).parse(
                term_categories, use_term_glosses
            )
            text_id = (
                f"{settings.biblical_terms_list_type}:"
                f"{settings.biblical_terms_project_name}:"
                f"{settings.biblical_terms_file_name}"
            )

            text = MemoryText(
                text_id,
                [
                    TextRow(text_id, key_term.id, [rendering], content_type=TextRowContentType.WORD)
                    for key_term in key_terms
                    for rendering in key_term.renderings
                ],
            )
            self._add_text(text)
