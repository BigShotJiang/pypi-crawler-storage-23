"""Figma REST API client with HTTP/2 support and connection pooling."""

import asyncio
from dataclasses import dataclass, field
from types import TracebackType
from typing import Any, ClassVar, cast

import httpx
from arcade_tdk.errors import FatalToolError, UpstreamError

from arcade_figma.constants import FIGMA_API_URL, FIGMA_MAX_TIMEOUT_SECONDS
from arcade_figma.models.api_responses import (
    ExportImageResponse,
    FileCommentsResponse,
    FileComponentSetsResponse,
    FileComponentsResponse,
    FileMetaResponse,
    FileNodesResponse,
    FileStylesResponse,
    MeResponse,
    PostCommentResponse,
    ProjectFilesResponse,
    SingleComponentResponse,
    SingleComponentSetResponse,
    SingleStyleResponse,
    TeamComponentSetsResponse,
    TeamComponentsResponse,
    TeamProjectsResponse,
    TeamStylesResponse,
)


@dataclass
class FigmaClient:
    """Client for interacting with Figma REST API.

    Supports HTTP/2, connection pooling, and retry logic for server errors.
    Use as async context manager:
        async with FigmaClient(token) as client:
            result = await client.get_me()
    """

    auth_token: str
    base_url: str = FIGMA_API_URL
    timeout_seconds: int = FIGMA_MAX_TIMEOUT_SECONDS

    _clients: ClassVar[dict[str, httpx.AsyncClient]] = {}
    _client_locks: ClassVar[dict[str, asyncio.Lock]] = {}
    _global_lock: ClassVar[asyncio.Lock] = asyncio.Lock()

    _client: httpx.AsyncClient | None = field(default=None, repr=False)

    async def __aenter__(self) -> "FigmaClient":
        """Enter async context - get or create pooled HTTP client."""
        self._client = await self._get_client()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context - client remains pooled for reuse."""
        self._client = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create a pooled HTTP client for the base URL (async-safe)."""
        base_url = self.base_url

        async with self._global_lock:
            if base_url not in self._client_locks:
                self._client_locks[base_url] = asyncio.Lock()
            lock = self._client_locks[base_url]

        async with lock:
            cached_client = self._clients.get(base_url)
            if cached_client:
                return cached_client

            client = httpx.AsyncClient(
                base_url=base_url,
                http2=True,
                limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
                timeout=self.timeout_seconds,
            )
            # Intentionally avoid setting Authorization on the client since it is shared
            # across instances; headers are applied per request instead.
            self._clients[base_url] = client
            return client

    @classmethod
    async def close_all(cls) -> None:
        """Close all pooled HTTP clients and clear the pool.

        Call this on application shutdown or in tests to properly clean up resources.
        """
        async with cls._global_lock:
            for client in cls._clients.values():
                await client.aclose()
            cls._clients.clear()
            cls._client_locks.clear()

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute HTTP request with retry logic for 5xx server errors only.

        4xx client errors are raised immediately without retry.
        """
        if not self._client:
            raise FatalToolError(
                "Client not initialized. Use 'async with FigmaClient() as client:'",
            )

        backoff_delays = [0.3, 0.6, 1.2]

        for attempt, delay in enumerate(backoff_delays):
            try:
                response = await self._client.request(
                    method,
                    endpoint,
                    params=params,
                    json=json,
                    headers={"Authorization": f"Bearer {self.auth_token}"},
                )
                response.raise_for_status()
                return cast(dict[str, Any], response.json())
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if status >= 500:
                    is_last_attempt = attempt == len(backoff_delays) - 1
                    if not is_last_attempt:
                        await asyncio.sleep(delay)
                        continue
                    _handle_server_error(e)
                raise
            except httpx.RequestError as e:
                raise UpstreamError(
                    f"Failed to connect to Figma API: {e}",
                    developer_message=str(e),
                    status_code=503,
                ) from e

        raise RuntimeError("Retry logic exited unexpectedly without returning or raising.")

    async def get_me(self) -> MeResponse:
        """Get authenticated user information."""
        response = await self._request("GET", "/me")
        return cast(MeResponse, response)

    async def get_team_projects(self, team_id: str) -> TeamProjectsResponse:
        """Get projects in a team."""
        response = await self._request("GET", f"/teams/{team_id}/projects")
        return cast(TeamProjectsResponse, response)

    async def get_project_files(self, project_id: str) -> ProjectFilesResponse:
        """Get files in a project."""
        response = await self._request("GET", f"/projects/{project_id}/files")
        return cast(ProjectFilesResponse, response)

    async def get_file(
        self,
        file_key: str,
        depth: int | None = None,
        node_ids: list[str] | None = None,
    ) -> FileMetaResponse:
        """Get file structure."""
        params: dict[str, Any] = {}
        if depth is not None:
            params["depth"] = depth
        if node_ids:
            params["ids"] = ",".join(node_ids)
        response = await self._request("GET", f"/files/{file_key}", params=params or None)
        return cast(FileMetaResponse, response)

    async def get_file_nodes(
        self,
        file_key: str,
        node_ids: list[str],
        depth: int | None = None,
    ) -> FileNodesResponse:
        """Get specific nodes from a file."""
        params: dict[str, Any] = {"ids": ",".join(node_ids)}
        if depth is not None:
            params["depth"] = depth
        response = await self._request("GET", f"/files/{file_key}/nodes", params=params)
        return cast(FileNodesResponse, response)

    async def export_images(
        self,
        file_key: str,
        node_ids: list[str],
        image_format: str = "png",
        scale: float | None = None,
    ) -> ExportImageResponse:
        """Export nodes as images."""
        params: dict[str, Any] = {
            "ids": ",".join(node_ids),
            "format": image_format,
        }
        if scale is not None:
            params["scale"] = scale
        response = await self._request("GET", f"/images/{file_key}", params=params)
        return cast(ExportImageResponse, response)

    async def get_comments(self, file_key: str) -> FileCommentsResponse:
        """Get comments on a file."""
        response = await self._request("GET", f"/files/{file_key}/comments")
        return cast(FileCommentsResponse, response)

    async def post_comment(
        self,
        file_key: str,
        message: str,
        client_meta: dict[str, Any] | None = None,
        comment_id: str | None = None,
    ) -> PostCommentResponse:
        """Post a comment or reply to a file."""
        payload: dict[str, Any] = {"message": message}
        if client_meta:
            payload["client_meta"] = client_meta
        if comment_id:
            payload["comment_id"] = comment_id
        response = await self._request("POST", f"/files/{file_key}/comments", json=payload)
        return cast(PostCommentResponse, response)

    async def get_file_components(self, file_key: str) -> FileComponentsResponse:
        """Get published components in a file library."""
        response = await self._request("GET", f"/files/{file_key}/components")
        return cast(FileComponentsResponse, response)

    async def get_team_components(
        self,
        team_id: str,
        page_size: int = 30,
        after: int | None = None,
        before: int | None = None,
    ) -> TeamComponentsResponse:
        """Get published components in a team library with pagination."""
        params: dict[str, Any] = {"page_size": page_size}
        if after is not None:
            params["after"] = after
        elif before is not None:
            params["before"] = before
        response = await self._request("GET", f"/teams/{team_id}/components", params=params)
        return cast(TeamComponentsResponse, response)

    async def get_component(self, component_key: str) -> SingleComponentResponse:
        """Get a component by key."""
        response = await self._request("GET", f"/components/{component_key}")
        return cast(SingleComponentResponse, response)

    async def get_file_styles(self, file_key: str) -> FileStylesResponse:
        """Get published styles in a file library."""
        response = await self._request("GET", f"/files/{file_key}/styles")
        return cast(FileStylesResponse, response)

    async def get_team_styles(
        self,
        team_id: str,
        page_size: int = 30,
        after: int | None = None,
        before: int | None = None,
    ) -> TeamStylesResponse:
        """Get published styles in a team library with pagination."""
        params: dict[str, Any] = {"page_size": page_size}
        if after is not None:
            params["after"] = after
        elif before is not None:
            params["before"] = before
        response = await self._request("GET", f"/teams/{team_id}/styles", params=params)
        return cast(TeamStylesResponse, response)

    async def get_style(self, style_key: str) -> SingleStyleResponse:
        """Get a style by key."""
        response = await self._request("GET", f"/styles/{style_key}")
        return cast(SingleStyleResponse, response)

    async def get_file_component_sets(self, file_key: str) -> FileComponentSetsResponse:
        """Get published component sets in a file library."""
        response = await self._request("GET", f"/files/{file_key}/component_sets")
        return cast(FileComponentSetsResponse, response)

    async def get_team_component_sets(
        self,
        team_id: str,
        page_size: int = 30,
        after: int | None = None,
        before: int | None = None,
    ) -> TeamComponentSetsResponse:
        """Get published component sets in a team library with pagination."""
        params: dict[str, Any] = {"page_size": page_size}
        if after is not None:
            params["after"] = after
        elif before is not None:
            params["before"] = before
        response = await self._request("GET", f"/teams/{team_id}/component_sets", params=params)
        return cast(TeamComponentSetsResponse, response)

    async def get_component_set(self, component_set_key: str) -> SingleComponentSetResponse:
        """Get a component set by key."""
        response = await self._request("GET", f"/component_sets/{component_set_key}")
        return cast(SingleComponentSetResponse, response)


def _handle_server_error(error: httpx.HTTPStatusError) -> None:
    """Handle 5xx server errors from Figma API after retry exhaustion."""
    status = error.response.status_code
    try:
        body = error.response.json()
        message = body.get("err", f"HTTP {status}")
    except Exception:
        message = f"HTTP {status}"

    raise UpstreamError(
        f"Figma API server error: {message}",
        developer_message=f"Figma API {status}: {error.response.text}",
        status_code=status,
    ) from error
