"""Comment tools for Figma toolkit."""

from typing import Annotated, cast

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Figma
from arcade_tdk.errors import FatalToolError

from arcade_figma.client import FigmaClient
from arcade_figma.constants import COMMENTS_DEFAULT_PAGE_SIZE, COMMENTS_MAX_PAGE_SIZE
from arcade_figma.models.mappers import map_add_comment, map_comment
from arcade_figma.models.tool_outputs import AddCommentOutput, GetCommentsOutput
from arcade_figma.utils.response_utils import remove_none_values_recursive


# =============================================================================
# get_comments
# API Calls: 1
# APIs Used: GET /v1/files/:key/comments (REST)
# Response Complexity: LOW - list of comments
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Comments"
#   readOnlyHint: true       - Only reads comment data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: Figma API returns all comments at once. Pagination is handled client-side.
# =============================================================================
@tool(
    requires_auth=Figma(scopes=["file_comments:read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.DESIGN],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_comments(
    context: ToolContext,
    file_key: Annotated[
        str,
        "File key. Can be found in Figma URL: https://www.figma.com/file/{FILE_KEY}/...",
    ],
    offset: Annotated[
        int,
        "Starting offset for pagination. Default is 0.",
    ] = 0,
    max_items: Annotated[
        int,
        "Maximum number of comments to return (1-50). Default is 10.",
    ] = COMMENTS_DEFAULT_PAGE_SIZE,
) -> Annotated[GetCommentsOutput, "Comments on the file"]:
    """Get comments on a Figma file.

    Returns comments with pagination support.
    """
    effective_max = min(max(1, max_items), COMMENTS_MAX_PAGE_SIZE)
    effective_offset = max(0, offset)

    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        comments_data = await client.get_comments(file_key)

    all_comments = comments_data.get("comments", [])
    total_count = len(all_comments)

    end_index = effective_offset + effective_max
    paginated_comments = all_comments[effective_offset:end_index]
    mapped_comments = [map_comment(c) for c in paginated_comments if c]

    is_last = end_index >= total_count

    result: GetCommentsOutput = {
        "file_key": file_key,
        "comments": mapped_comments,
        "items_returned": len(mapped_comments),
        "total_count": total_count,
        "offset": effective_offset,
        "is_last": is_last,
    }

    return cast(GetCommentsOutput, remove_none_values_recursive(result))


# =============================================================================
# add_comment_or_reply
# API Calls: 1
# APIs Used: POST /v1/files/:key/comments (REST)
# Response Complexity: LOW - single comment
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Add Comment or Reply"
#   readOnlyHint: false      - Creates new content
#   destructiveHint: false   - Additive operation
#   idempotentHint: false    - Each call creates new comment/reply
#   openWorldHint: true      - Interacts with Figma's external API
# =============================================================================
@tool(
    requires_auth=Figma(scopes=["file_comments:write"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.DESIGN],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def add_comment_or_reply(
    context: ToolContext,
    file_key: Annotated[
        str,
        "File key. Can be found in Figma URL: https://www.figma.com/file/{FILE_KEY}/...",
    ],
    message: Annotated[str, "The comment or reply text."],
    parent_comment_id: Annotated[
        str | None,
        "Parent comment ID to reply to. If provided, creates a reply. Default is None.",
    ] = None,
    node_id: Annotated[
        str | None,
        "Node ID to attach the comment to. Ignored for replies. Default is None.",
    ] = None,
    x: Annotated[
        float | None,
        "X position offset on the node. Only used with node_id. Default is None.",
    ] = None,
    y: Annotated[
        float | None,
        "Y position offset on the node. Only used with node_id. Default is None.",
    ] = None,
) -> Annotated[AddCommentOutput, "Created comment or reply details"]:
    """Add a comment to a Figma file or reply to an existing comment.

    If parent_comment_id is provided, creates a reply to that comment.
    Otherwise creates a new comment (optionally attached to a node).
    """
    if not message.strip():
        raise FatalToolError(
            "Message cannot be empty",
            developer_message="The message parameter was empty or contained only whitespace",
        )

    is_reply = parent_comment_id is not None

    client_meta = None
    if not is_reply and node_id:
        client_meta = {
            "node_id": node_id,
            "node_offset": {"x": x or 0, "y": y or 0},
        }

    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        data = await client.post_comment(
            file_key=file_key,
            message=message,
            client_meta=client_meta,
            comment_id=parent_comment_id,
        )

    return cast(AddCommentOutput, remove_none_values_recursive(map_add_comment(data)))
