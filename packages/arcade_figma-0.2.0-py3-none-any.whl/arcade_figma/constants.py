"""Constants for Figma toolkit configuration."""

import os

FIGMA_API_URL = "https://api.figma.com/v1"
FIGMA_WEB_URL = "https://www.figma.com"

try:
    FIGMA_MAX_TIMEOUT_SECONDS = int(os.getenv("FIGMA_MAX_TIMEOUT_SECONDS", 30))
except ValueError:
    FIGMA_MAX_TIMEOUT_SECONDS = 30

DEFAULT_PAGE_SIZE = 30
MAX_PAGE_SIZE = 100

DEFAULT_IMAGE_SCALE = 1.0
MAX_IMAGE_SCALE = 4.0
MIN_IMAGE_SCALE = 0.01

COMMENTS_DEFAULT_PAGE_SIZE = 10
COMMENTS_MAX_PAGE_SIZE = 50
