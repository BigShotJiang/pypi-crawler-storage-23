"""Utility functions for component, style, and component set tools."""

from collections.abc import Mapping
from typing import Any, cast

from arcade_figma.models.tool_outputs.components import (
    ComponentSetSummary,
    ComponentSummary,
    PaginationCursor,
    StyleSummary,
)


def map_component(data: Mapping[str, Any]) -> ComponentSummary:
    """Map component API response to output format."""
    containing_frame = data.get("containing_frame", {})
    return cast(
        ComponentSummary,
        {
            "key": data.get("key"),
            "file_key": data.get("file_key"),
            "node_id": data.get("node_id"),
            "name": data.get("name"),
            "description": data.get("description"),
            "thumbnail_url": data.get("thumbnail_url"),
            "containing_frame_name": containing_frame.get("name") if containing_frame else None,
            "created_at": data.get("created_at"),
            "updated_at": data.get("updated_at"),
        },
    )


def map_style(data: Mapping[str, Any]) -> StyleSummary:
    """Map style API response to output format."""
    return cast(
        StyleSummary,
        {
            "key": data.get("key"),
            "file_key": data.get("file_key"),
            "node_id": data.get("node_id"),
            "style_type": data.get("style_type"),
            "name": data.get("name"),
            "description": data.get("description"),
            "thumbnail_url": data.get("thumbnail_url"),
            "created_at": data.get("created_at"),
            "updated_at": data.get("updated_at"),
        },
    )


def map_component_set(data: Mapping[str, Any]) -> ComponentSetSummary:
    """Map component set API response to output format."""
    containing_frame = data.get("containing_frame", {})
    return cast(
        ComponentSetSummary,
        {
            "key": data.get("key"),
            "file_key": data.get("file_key"),
            "node_id": data.get("node_id"),
            "name": data.get("name"),
            "description": data.get("description"),
            "thumbnail_url": data.get("thumbnail_url"),
            "containing_frame_name": containing_frame.get("name") if containing_frame else None,
            "created_at": data.get("created_at"),
            "updated_at": data.get("updated_at"),
        },
    )


def map_cursor(cursor_data: Mapping[str, Any] | None) -> PaginationCursor | None:
    """Map cursor data to PaginationCursor."""
    if not cursor_data:
        return None
    return cast(
        PaginationCursor,
        {
            "before": cursor_data.get("before"),
            "after": cursor_data.get("after"),
        },
    )
