"""Enum definitions for Figma toolkit."""

from enum import Enum


class LibrarySource(str, Enum):
    """Source type for library assets (components, styles, component sets)."""

    FILE = "file"
    TEAM = "team"


class ImageFormat(str, Enum):
    """Supported image export formats."""

    PNG = "png"
    SVG = "svg"
    PDF = "pdf"
    JPG = "jpg"


class StyleType(str, Enum):
    """Figma style types."""

    FILL = "FILL"
    TEXT = "TEXT"
    EFFECT = "EFFECT"
    GRID = "GRID"


class NodeType(str, Enum):
    """Figma node types."""

    DOCUMENT = "DOCUMENT"
    CANVAS = "CANVAS"
    FRAME = "FRAME"
    GROUP = "GROUP"
    VECTOR = "VECTOR"
    TEXT = "TEXT"
    RECTANGLE = "RECTANGLE"
    ELLIPSE = "ELLIPSE"
    COMPONENT = "COMPONENT"
    COMPONENT_SET = "COMPONENT_SET"
    INSTANCE = "INSTANCE"
