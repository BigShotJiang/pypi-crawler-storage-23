"""API response types for navigation endpoints."""

from typing_extensions import TypedDict


class ProjectResponse(TypedDict, total=False):
    """Project in team projects response."""

    id: str
    name: str


class TeamProjectsResponse(TypedDict, total=False):
    """Response from GET /v1/teams/:team_id/projects."""

    name: str
    projects: list[ProjectResponse]


class FileResponse(TypedDict, total=False):
    """File in project files response."""

    key: str
    name: str
    thumbnail_url: str
    last_modified: str
    editor_type: str


class ProjectFilesResponse(TypedDict, total=False):
    """Response from GET /v1/projects/:project_id/files."""

    name: str
    files: list[FileResponse]
