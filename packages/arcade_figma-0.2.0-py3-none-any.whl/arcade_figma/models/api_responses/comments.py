"""API response types for comment endpoints."""

from typing_extensions import TypedDict


class UserResponse(TypedDict, total=False):
    """User in comment response."""

    id: str
    handle: str
    img_url: str


class ClientMetaResponse(TypedDict, total=False):
    """Client meta (position) in comment."""

    x: float
    y: float
    node_id: str
    node_offset: dict[str, float]


class CommentResponse(TypedDict, total=False):
    """Comment in file comments response."""

    id: str
    uuid: str
    message: str
    file_key: str
    parent_id: str
    user: UserResponse
    created_at: str
    resolved_at: str | None
    client_meta: ClientMetaResponse
    order_id: str


class FileCommentsResponse(TypedDict, total=False):
    """Response from GET /v1/files/:key/comments."""

    comments: list[CommentResponse]


class PostCommentResponse(TypedDict, total=False):
    """Response from POST /v1/files/:key/comments."""

    id: str
    uuid: str
    message: str
    file_key: str
    parent_id: str
    user: UserResponse
    created_at: str
    client_meta: ClientMetaResponse
