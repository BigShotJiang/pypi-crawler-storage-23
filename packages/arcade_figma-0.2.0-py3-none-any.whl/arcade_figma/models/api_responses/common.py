"""Common API response types for Figma toolkit."""

from typing_extensions import TypedDict


class CursorPaginationResponse(TypedDict, total=False):
    """Cursor-based pagination response from Figma API."""

    before: int | None
    after: int | None
