"""Tool output types for component and style tools."""

from typing_extensions import TypedDict


class ComponentSummary(TypedDict, total=False):
    """Component summary."""

    key: str
    """Component key."""

    file_key: str
    """File key containing the component."""

    node_id: str
    """Node ID in the file."""

    name: str
    """Component name."""

    description: str | None
    """Component description."""

    thumbnail_url: str | None
    """Component thumbnail URL."""

    containing_frame_name: str | None
    """Name of the frame containing this component."""


class PaginationCursor(TypedDict, total=False):
    """Cursor-based pagination info."""

    before: int | None
    """Cursor for previous page."""

    after: int | None
    """Cursor for next page."""


class GetComponentsOutput(TypedDict, total=False):
    """Output for get_components tool."""

    source_type: str
    """Source type: 'file' or 'team'."""

    source_id: str
    """File key or team ID."""

    components: list[ComponentSummary]
    """List of components."""

    total_count: int
    """Number of components returned."""

    cursor: PaginationCursor | None
    """Pagination cursors (team mode only)."""


class GetComponentOutput(TypedDict, total=False):
    """Output for get_component tool."""

    key: str
    """Component key."""

    file_key: str
    """File key containing the component."""

    node_id: str
    """Node ID in the file."""

    name: str
    """Component name."""

    description: str | None
    """Component description."""

    thumbnail_url: str | None
    """Component thumbnail URL."""

    containing_frame_name: str | None
    """Name of the frame containing this component."""

    created_at: str | None
    """ISO 8601 timestamp when created."""

    updated_at: str | None
    """ISO 8601 timestamp when last updated."""


class StyleSummary(TypedDict, total=False):
    """Style summary."""

    key: str
    """Style key."""

    file_key: str
    """File key containing the style."""

    node_id: str
    """Node ID in the file."""

    style_type: str
    """Style type: FILL, TEXT, EFFECT, GRID."""

    name: str
    """Style name."""

    description: str | None
    """Style description."""

    thumbnail_url: str | None
    """Style thumbnail URL."""


class GetStylesOutput(TypedDict, total=False):
    """Output for get_styles tool."""

    source_type: str
    """Source type: 'file' or 'team'."""

    source_id: str
    """File key or team ID."""

    styles: list[StyleSummary]
    """List of styles."""

    total_count: int
    """Number of styles returned."""

    cursor: PaginationCursor | None
    """Pagination cursors (team mode only)."""


class GetStyleOutput(TypedDict, total=False):
    """Output for get_style tool."""

    key: str
    """Style key."""

    file_key: str
    """File key containing the style."""

    node_id: str
    """Node ID in the file."""

    style_type: str
    """Style type: FILL, TEXT, EFFECT, GRID."""

    name: str
    """Style name."""

    description: str | None
    """Style description."""

    thumbnail_url: str | None
    """Style thumbnail URL."""

    created_at: str | None
    """ISO 8601 timestamp when created."""

    updated_at: str | None
    """ISO 8601 timestamp when last updated."""


class ComponentSetSummary(TypedDict, total=False):
    """Component set summary (group of component variants)."""

    key: str
    """Component set key."""

    file_key: str
    """File key containing the component set."""

    node_id: str
    """Node ID in the file."""

    name: str
    """Component set name."""

    description: str | None
    """Component set description."""

    thumbnail_url: str | None
    """Component set thumbnail URL."""

    containing_frame_name: str | None
    """Name of the frame containing this component set."""


class GetComponentSetsOutput(TypedDict, total=False):
    """Output for get_component_sets tool."""

    source_type: str
    """Source type: 'file' or 'team'."""

    source_id: str
    """File key or team ID."""

    component_sets: list[ComponentSetSummary]
    """List of component sets."""

    total_count: int
    """Number of component sets returned."""

    cursor: PaginationCursor | None
    """Pagination cursors (team mode only)."""


class GetComponentSetOutput(TypedDict, total=False):
    """Output for get_component_set tool."""

    key: str
    """Component set key."""

    file_key: str
    """File key containing the component set."""

    node_id: str
    """Node ID in the file."""

    name: str
    """Component set name."""

    description: str | None
    """Component set description."""

    thumbnail_url: str | None
    """Component set thumbnail URL."""

    containing_frame_name: str | None
    """Name of the frame containing this component set."""

    created_at: str | None
    """ISO 8601 timestamp when created."""

    updated_at: str | None
    """ISO 8601 timestamp when last updated."""
