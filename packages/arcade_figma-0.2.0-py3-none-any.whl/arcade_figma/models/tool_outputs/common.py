"""Common TypedDict definitions shared across Figma tool outputs."""

from typing_extensions import TypedDict


class PaginationInfo(TypedDict, total=False):
    """Pagination information for paginated tool outputs."""

    has_next_page: bool
    """Whether more results are available."""

    cursor: str | None
    """Cursor for fetching next page of results."""


class UserData(TypedDict, total=False):
    """User information in tool outputs."""

    id: str
    """User's unique identifier."""

    handle: str
    """User's handle/username."""

    email: str | None
    """User's email address."""

    img_url: str | None
    """User's avatar URL."""


class TeamSummary(TypedDict, total=False):
    """Team summary information."""

    id: str
    """Team's unique identifier."""

    name: str
    """Team's name."""


class ProjectSummary(TypedDict, total=False):
    """Project summary information."""

    id: str
    """Project's unique identifier."""

    name: str
    """Project's name."""


class FileSummary(TypedDict, total=False):
    """File summary information."""

    key: str
    """File's unique key."""

    name: str
    """File's name."""

    url: str
    """URL to open file in Figma."""

    thumbnail_url: str | None
    """File's thumbnail URL."""

    last_modified: str
    """ISO 8601 timestamp of last modification."""

    editor_type: str | None
    """Editor type: figma, figjam, or slides."""
