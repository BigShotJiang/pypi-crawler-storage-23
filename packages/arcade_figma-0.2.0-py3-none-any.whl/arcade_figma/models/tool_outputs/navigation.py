"""Tool output types for navigation tools."""

from typing_extensions import TypedDict

from arcade_figma.models.tool_outputs.common import (
    FileSummary,
    ProjectSummary,
)


class GetTeamProjectsOutput(TypedDict, total=False):
    """Output for get_team_projects tool."""

    team_id: str
    """Team ID."""

    team_name: str
    """Team name."""

    projects: list[ProjectSummary]
    """List of projects in the team."""

    total_count: int
    """Total number of projects."""


class GetProjectFilesOutput(TypedDict, total=False):
    """Output for get_project_files tool."""

    project_id: str
    """Project ID."""

    project_name: str
    """Project name."""

    files: list[FileSummary]
    """List of files in the project."""

    total_count: int
    """Total number of files."""
