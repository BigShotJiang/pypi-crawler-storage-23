"""Tool output types for user context."""

from typing_extensions import TypedDict

from arcade_figma.models.tool_outputs.common import TeamSummary


class WhoAmIOutput(TypedDict, total=False):
    """Output for who_am_i tool."""

    id: str
    """User's unique identifier."""

    handle: str
    """User's handle/username."""

    email: str | None
    """User's email address."""

    img_url: str | None
    """User's avatar URL."""

    teams: list[TeamSummary]
    """Teams the user belongs to."""
