"""Mapper functions to transform Figma API responses to tool outputs."""

from collections.abc import Mapping
from typing import Any, cast
from urllib.parse import quote

from arcade_figma.constants import FIGMA_WEB_URL
from arcade_figma.models.tool_outputs.comments import (
    AddCommentOutput,
    CommentAuthor,
    CommentPosition,
    CommentSummary,
    GetCommentsOutput,
)
from arcade_figma.models.tool_outputs.common import (
    FileSummary,
    PaginationInfo,
    ProjectSummary,
    TeamSummary,
    UserData,
)
from arcade_figma.models.tool_outputs.files import (
    ChildNodeData,
    ExportedImage,
    ExportImageOutput,
    FrameSummary,
    GetFileNodesOutput,
    GetFileOutput,
    GetPagesOutput,
    NodeData,
    PageSummary,
)
from arcade_figma.models.tool_outputs.navigation import (
    GetProjectFilesOutput,
    GetTeamProjectsOutput,
)
from arcade_figma.models.tool_outputs.user_context import WhoAmIOutput


def build_file_url(file_key: str) -> str:
    """Build Figma web URL for a file."""
    return f"{FIGMA_WEB_URL}/design/{file_key}"


def build_node_url(file_key: str, node_id: str) -> str:
    """Build Figma web URL for a specific node in a file."""
    encoded_node_id = quote(node_id, safe="")
    return f"{FIGMA_WEB_URL}/design/{file_key}?node-id={encoded_node_id}"


def map_user(api_data: Mapping[str, Any] | None) -> UserData:
    """Map API user response to UserData output."""
    if not api_data:
        return cast(UserData, {})
    return cast(
        UserData,
        {
            "id": api_data.get("id"),
            "handle": api_data.get("handle"),
            "email": api_data.get("email"),
            "img_url": api_data.get("img_url"),
        },
    )


def map_team(api_data: Mapping[str, Any] | None) -> TeamSummary:
    """Map API team response to TeamSummary output."""
    if not api_data:
        return cast(TeamSummary, {})
    return cast(
        TeamSummary,
        {
            "id": api_data.get("id"),
            "name": api_data.get("name"),
        },
    )


def map_project(api_data: Mapping[str, Any] | None) -> ProjectSummary:
    """Map API project response to ProjectSummary output."""
    if not api_data:
        return cast(ProjectSummary, {})
    return cast(
        ProjectSummary,
        {
            "id": api_data.get("id"),
            "name": api_data.get("name"),
        },
    )


def map_file(api_data: Mapping[str, Any] | None) -> FileSummary:
    """Map API file response to FileSummary output."""
    if not api_data:
        return cast(FileSummary, {})
    file_key = api_data.get("key", "")
    return cast(
        FileSummary,
        {
            "key": file_key,
            "name": api_data.get("name"),
            "url": build_file_url(file_key) if file_key else None,
            "thumbnail_url": api_data.get("thumbnail_url"),
            "last_modified": api_data.get("last_modified"),
            "editor_type": api_data.get("editor_type"),
        },
    )


def map_pagination(cursor_data: Mapping[str, Any] | None) -> PaginationInfo:
    """Map cursor-based pagination to PaginationInfo output."""
    if not cursor_data:
        return cast(PaginationInfo, {"has_next_page": False})
    return cast(
        PaginationInfo,
        {
            "has_next_page": cursor_data.get("after") is not None,
            "cursor": cursor_data.get("after"),
        },
    )


def map_who_am_i(api_data: Mapping[str, Any] | None) -> WhoAmIOutput:
    """Map /me response to WhoAmIOutput."""
    if not api_data:
        return cast(WhoAmIOutput, {})

    teams_data = api_data.get("teams") or []

    return cast(
        WhoAmIOutput,
        {
            "id": api_data.get("id"),
            "handle": api_data.get("handle"),
            "email": api_data.get("email"),
            "img_url": api_data.get("img_url"),
            "teams": [map_team(t) for t in teams_data if t],
        },
    )


def map_get_team_projects(
    team_id: str,
    api_data: Mapping[str, Any],
) -> GetTeamProjectsOutput:
    """Map team projects response to GetTeamProjectsOutput."""
    projects_data = api_data.get("projects", [])
    mapped_projects = [map_project(p) for p in projects_data if p]
    return cast(
        GetTeamProjectsOutput,
        {
            "team_id": team_id,
            "team_name": api_data.get("name", ""),
            "projects": mapped_projects,
            "total_count": len(mapped_projects),
        },
    )


def map_get_project_files(
    project_id: str,
    api_data: Mapping[str, Any],
) -> GetProjectFilesOutput:
    """Map project files response to GetProjectFilesOutput."""
    files_data = api_data.get("files", [])
    mapped_files = [map_file(f) for f in files_data if f]
    return cast(
        GetProjectFilesOutput,
        {
            "project_id": project_id,
            "project_name": api_data.get("name", ""),
            "files": mapped_files,
            "total_count": len(mapped_files),
        },
    )


def map_page(node: Mapping[str, Any], file_key: str | None = None) -> PageSummary:
    """Map a canvas node to PageSummary."""
    node_id = node.get("id")
    return cast(
        PageSummary,
        {
            "id": node_id,
            "name": node.get("name"),
            "url": build_node_url(file_key, node_id) if file_key and node_id else None,
        },
    )


def map_frame(node: Mapping[str, Any], file_key: str | None = None) -> FrameSummary:
    """Map a frame node to FrameSummary."""
    node_id = node.get("id")
    return cast(
        FrameSummary,
        {
            "id": node_id,
            "name": node.get("name"),
            "type": node.get("type"),
            "url": build_node_url(file_key, node_id) if file_key and node_id else None,
        },
    )


def map_child_node(node: Mapping[str, Any], file_key: str | None = None) -> ChildNodeData:
    """Map a child node to ChildNodeData output (no further nesting)."""
    node_id = node.get("id")
    return cast(
        ChildNodeData,
        {
            "id": node_id,
            "name": node.get("name"),
            "type": node.get("type"),
            "url": build_node_url(file_key, node_id) if file_key and node_id else None,
        },
    )


def map_node(node: Mapping[str, Any], file_key: str | None = None) -> NodeData:
    """Map a node to NodeData output with one level of children."""
    node_id = node.get("id")
    children = node.get("children")
    mapped_children = None
    if children:
        mapped_children = [map_child_node(c, file_key) for c in children]

    return cast(
        NodeData,
        {
            "id": node_id,
            "name": node.get("name"),
            "type": node.get("type"),
            "url": build_node_url(file_key, node_id) if file_key and node_id else None,
            "children": mapped_children,
        },
    )


def map_get_file_nodes(file_key: str, api_data: Mapping[str, Any]) -> GetFileNodesOutput:
    """Map file nodes response to GetFileNodesOutput."""
    nodes_data = api_data.get("nodes", {})
    mapped_nodes = []
    for _node_id, node_info in nodes_data.items():
        if node_info and node_info.get("document"):
            mapped_nodes.append(map_node(node_info["document"], file_key))

    return cast(
        GetFileNodesOutput,
        {
            "file_key": file_key,
            "file_name": api_data.get("name", ""),
            "file_url": build_file_url(file_key),
            "editor_type": api_data.get("editorType"),
            "role": api_data.get("role"),
            "nodes": mapped_nodes,
            "total_count": len(mapped_nodes),
        },
    )


def map_get_file(file_key: str, api_data: Mapping[str, Any]) -> GetFileOutput:
    """Map file response to GetFileOutput."""
    document = api_data.get("document", {})
    pages_data = document.get("children", [])
    mapped_pages = [map_page(p, file_key) for p in pages_data if p.get("type") == "CANVAS"]

    return cast(
        GetFileOutput,
        {
            "file_key": file_key,
            "name": api_data.get("name", ""),
            "url": build_file_url(file_key),
            "last_modified": api_data.get("lastModified"),
            "thumbnail_url": api_data.get("thumbnailUrl"),
            "version": api_data.get("version"),
            "editor_type": api_data.get("editorType"),
            "role": api_data.get("role"),
            "pages": mapped_pages,
            "total_pages": len(mapped_pages),
        },
    )


def map_get_pages(file_key: str, api_data: Mapping[str, Any]) -> GetPagesOutput:
    """Map file response to GetPagesOutput with pages only."""
    document = api_data.get("document", {})
    pages_data = document.get("children", [])
    mapped_pages = [map_page(p, file_key) for p in pages_data if p.get("type") == "CANVAS"]

    return cast(
        GetPagesOutput,
        {
            "file_key": file_key,
            "file_name": api_data.get("name", ""),
            "file_url": build_file_url(file_key),
            "pages": mapped_pages,
            "total_count": len(mapped_pages),
        },
    )


def map_exported_image(node_id: str, url: str) -> ExportedImage:
    """Map exported image data."""
    return cast(
        ExportedImage,
        {
            "node_id": node_id,
            "url": url,
        },
    )


def map_export_image(
    file_key: str,
    image_format: str,
    scale: float,
    api_data: Mapping[str, Any],
) -> ExportImageOutput:
    """Map export images response to ExportImageOutput."""
    images_data = api_data.get("images", {})
    mapped_images = [
        map_exported_image(node_id, url) for node_id, url in images_data.items() if url
    ]

    return cast(
        ExportImageOutput,
        {
            "file_key": file_key,
            "format": image_format,
            "scale": scale,
            "images": mapped_images,
            "total_count": len(mapped_images),
        },
    )


def map_comment_author(user_data: Mapping[str, Any] | None) -> CommentAuthor:
    """Map user to CommentAuthor."""
    if not user_data:
        return cast(CommentAuthor, {})
    return cast(
        CommentAuthor,
        {
            "id": user_data.get("id"),
            "handle": user_data.get("handle"),
            "img_url": user_data.get("img_url"),
        },
    )


def map_comment_position(
    client_meta: Mapping[str, Any] | None,
) -> CommentPosition | None:
    """Map client_meta to CommentPosition."""
    if not client_meta:
        return None
    return cast(
        CommentPosition,
        {
            "x": client_meta.get("x"),
            "y": client_meta.get("y"),
            "node_id": client_meta.get("node_id"),
        },
    )


def map_comment(comment_data: Mapping[str, Any]) -> CommentSummary:
    """Map comment to CommentSummary."""
    return cast(
        CommentSummary,
        {
            "id": comment_data.get("id"),
            "message": comment_data.get("message"),
            "author": map_comment_author(comment_data.get("user")),
            "created_at": comment_data.get("created_at"),
            "resolved_at": comment_data.get("resolved_at"),
            "parent_id": comment_data.get("parent_id"),
            "position": map_comment_position(comment_data.get("client_meta")),
        },
    )


def map_get_comments(file_key: str, api_data: Mapping[str, Any]) -> GetCommentsOutput:
    """Map comments response to GetCommentsOutput."""
    comments_data = api_data.get("comments", [])
    mapped_comments = [map_comment(c) for c in comments_data if c]

    return cast(
        GetCommentsOutput,
        {
            "file_key": file_key,
            "comments": mapped_comments,
            "total_count": len(mapped_comments),
        },
    )


def map_add_comment(api_data: Mapping[str, Any]) -> AddCommentOutput:
    """Map post comment response to AddCommentOutput."""
    return cast(
        AddCommentOutput,
        {
            "id": api_data.get("id"),
            "message": api_data.get("message"),
            "author": map_comment_author(api_data.get("user")),
            "created_at": api_data.get("created_at"),
            "parent_id": api_data.get("parent_id"),
        },
    )
