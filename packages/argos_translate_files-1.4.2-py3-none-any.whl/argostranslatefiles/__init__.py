from argostranslatefiles.argostranslatefiles import *
