from paintmystring import paint

array = [1, 2, 3]
paint("Hola", end=f"{array}").show()
print(paint("hola"), end=f"{array}")
