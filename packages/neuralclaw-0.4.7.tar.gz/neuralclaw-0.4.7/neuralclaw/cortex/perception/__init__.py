"""Perception Cortex — Input processing, intent classification, threat screening."""
