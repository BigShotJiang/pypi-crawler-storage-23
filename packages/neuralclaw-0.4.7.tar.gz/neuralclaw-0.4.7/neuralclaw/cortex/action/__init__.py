"""Action Cortex — Secure execution with capability-based sandboxing."""
