"""Reasoning Cortex — Multi-layer decision engine."""
