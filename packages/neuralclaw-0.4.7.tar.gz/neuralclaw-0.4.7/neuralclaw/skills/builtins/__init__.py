"""Built-in skills — Core capabilities (web search, files, code, calendar)."""
