"""NeuralClaw — The Self-Evolving Cognitive Agent Framework."""

__version__ = "0.4.7"
