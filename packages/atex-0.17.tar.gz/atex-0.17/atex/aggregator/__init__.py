import abc as _abc
import importlib as _importlib
import pkgutil as _pkgutil


class Aggregator:
    @_abc.abstractmethod
    def ingest(self, platform, test_name, artifacts):
        """
        Process `artifacts` (string/Path) for results reported and files
        uploadedby a test ran by an Executor, aggregating them under
        `platform` (string) as `test_name` (string).

        This is **destructive**, the artifacts are consumed in the process.
        """

    @_abc.abstractmethod
    def start(self):
        """
        Start the Aggregator instance, opening any files / allocating resources
        as necessary.
        """

    @_abc.abstractmethod
    def stop(self):
        """
        Stop the Aggregator instance, freeing all allocated resources.
        """

    def __enter__(self):
        try:
            self.start()
            return self
        except Exception:
            self.stop()
            raise

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()


_submodules = [
    info.name for info in _pkgutil.iter_modules(__spec__.submodule_search_locations)
]

__all__ = [*_submodules, Aggregator.__name__]  # noqa: PLE0604


def __dir__():
    return __all__


# lazily import submodules
def __getattr__(attr):
    if attr in _submodules:
        return _importlib.import_module(f".{attr}", __name__)
    else:
        raise AttributeError(f"module '{__name__}' has no attribute '{attr}'")
