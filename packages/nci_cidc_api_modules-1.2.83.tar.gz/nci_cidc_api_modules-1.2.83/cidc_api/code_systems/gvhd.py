# Stubbed to accept any string
# Should support MAGIC and Modified Glucksberg
def is_gvhd_organ(v):
    if not isinstance(v, str):
        raise TypeError("Value must be a string")
    return v
