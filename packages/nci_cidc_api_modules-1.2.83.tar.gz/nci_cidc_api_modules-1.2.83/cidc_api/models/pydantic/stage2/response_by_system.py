from pydantic import PositiveInt, NonNegativeInt
from cidc_api.models.pydantic.base import forced_validator, forced_validators

from cidc_api.models.errors import ValueLocError
from cidc_api.models.pydantic.base import Base
from cidc_api.models.pydantic.stage2.response import Response
from cidc_api.models.types import ResponseSystem, ResponseSystemVersion, BestOverallResponse, YNUNA, YN

negative_response_values = [
    "Progressive Disease",
    "Stable Disease",
    "immune Unconfirmed Progressive Disease",
    "immune Confirmed Progressive Disease",
    "immune Stable Disease",
    "Not available",
    "Not assessed",
]


@forced_validators
class ResponseBySystem(Base):
    __data_category__ = "response_by_system"
    __cardinality__ = "many"

    # The unique internal identifier for this ResponseBySystem record
    response_by_system_id: int | None = None

    # The unique internal identifier for the associated participant
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=12220014%20and%20ver_nr=1
    participant_id: int | None = None

    # The linked parent response for the participant. Used for cross-model validation.
    response: dict | None = None

    # A standardized method used to evaluate and categorize the participant’s clinical response to treatment based on predefined criteria.
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=13381490%20and%20ver_nr=1
    response_system: ResponseSystem

    # The release version of the clinical assessment system used to evaluate a participant’s response to treatment.
    response_system_version: ResponseSystemVersion

    # Confirmed best overall response to study treatment by the corresponding response system.
    best_overall_response: BestOverallResponse

    # Days from first response to progression.
    response_duration: PositiveInt | None = None

    # The number of days from the start of the treatment to the first signs of disease progression.
    duration_of_stable_disease: NonNegativeInt | None = None

    # Indicates whether a patient achieved a durable clinical benefit.
    durable_clinical_benefit: YN | None = None

    # Number of days between enrollment date and the date of first response to trial treatment.
    days_to_first_response: PositiveInt | None = None

    # Number of days between enrollment date and the date of the best response to trial treatment.
    days_to_best_response: PositiveInt | None = None

    # Indicates whether a participant's disease progressed.
    progression: YNUNA

    # Number of days between enrollment date and date of disease progression.
    days_to_disease_progression: PositiveInt | None = None

    # Indicator to identify whether a patient had a Progression-Free Survival (PFS) event.
    progression_free_survival_event: YNUNA

    # The number of days from the date the patient was enrolled in the study to the date the patient was last verified to be free of progression.
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=5143957%20and%20ver_nr=1
    progression_free_survival: PositiveInt | None = None

    @forced_validator
    @classmethod
    def validate_response_duration_cr(cls, data, info) -> None:
        best_overall_response = data.get("best_overall_response", None)
        response_duration = data.get("response_duration", None)

        if best_overall_response in negative_response_values and response_duration:
            raise ValueLocError(
                "If best_overall_response does not indicate a positive response, "
                "please leave response_duration blank.",
                loc="response_duration",
            )

    @forced_validator
    @classmethod
    def validate_days_to_first_response_cr(cls, data, info) -> None:
        best_overall_response = data.get("best_overall_response", None)
        days_to_first_response = data.get("days_to_first_response", None)

        if best_overall_response in negative_response_values and days_to_first_response:
            raise ValueLocError(
                "If best_overall_response does not indicate a positive response, "
                "please leave days_to_first_response blank.",
                loc="days_to_first_response",
            )

    @forced_validator
    @classmethod
    def validate_days_to_best_response_cr(cls, data, info) -> None:
        best_overall_response = data.get("best_overall_response", None)
        days_to_best_response = data.get("days_to_best_response", None)

        if best_overall_response in negative_response_values and days_to_best_response:
            raise ValueLocError(
                "If best_overall_response does not indicate a positive response, "
                "please leave days_to_best_response blank.",
                loc="days_to_best_response",
            )

    @forced_validator
    @classmethod
    def validate_days_to_disease_progression_cr(cls, data, info) -> None:
        progression = data.get("progression", None)
        days_to_disease_progression = data.get("days_to_disease_progression", None)

        if progression in ["No", "Unknown", "Not Applicable"] and days_to_disease_progression:
            raise ValueLocError(
                "If progression does not indicate confirmed progression of the disease, "
                "please leave days_to_disease_progression blank.",
                loc="days_to_disease_progression",
            )

    @forced_validator
    @classmethod
    def validate_progression_free_survival_cr(cls, data, info) -> None:
        progression_free_survival_event = data.get("progression_free_survival_event", None)
        progression_free_survival = data.get("progression_free_survival", None)

        if progression_free_survival_event in ["Unknown", "Not Applicable"] and progression_free_survival:
            raise ValueLocError(
                "If progression_free_survival_event is not known, " "please leave progression_free_survival blank.",
                loc="progression_free_survival",
            )

    @forced_validator
    @classmethod
    def validate_days_to_best_response_chronology(cls, data, info) -> None:
        days_to_first_response = data.get("days_to_first_response", None)
        days_to_best_response = data.get("days_to_best_response", None)

        try:
            days_to_first_response = int(days_to_first_response)
            days_to_best_response = int(days_to_best_response)
        except (ValueError, TypeError):
            return

        if days_to_best_response < days_to_first_response:
            raise ValueLocError(
                'Violate "days_to_best_response" >= days_to_first_response"',
                loc="days_to_best_response",
            )

    @forced_validator
    @classmethod
    def validate_days_to_disease_progression_chronology(cls, data, info) -> None:
        days_to_disease_progression = data.get("days_to_disease_progression", None)
        days_to_first_response = data.get("days_to_first_response", None)

        try:
            days_to_disease_progression = int(days_to_disease_progression)
            days_to_first_response = int(days_to_first_response)
        except (ValueError, TypeError):
            return

        if days_to_first_response >= days_to_disease_progression:
            raise ValueLocError(
                'Violate "days_to_first_response" < "days_to_disease_progression"',
                loc="days_to_first_response",
            )

    @forced_validator
    @classmethod
    def validate_days_to_best_response_progression_chronology(cls, data, info) -> None:
        days_to_disease_progression = data.get("days_to_disease_progression", None)
        days_to_best_response = data.get("days_to_best_response", None)

        try:
            days_to_disease_progression = int(days_to_disease_progression)
            days_to_best_response = int(days_to_best_response)
        except (ValueError, TypeError):
            return

        if days_to_best_response >= days_to_disease_progression:
            raise ValueLocError(
                'Violate "days_to_best_response" < "days_to_disease_progression"',
                loc="days_to_best_response",
            )

    @forced_validator
    @classmethod
    def validate_progression_free_survival_disease_progression_chronology(cls, data, info) -> None:
        progression = data.get("progression", None)
        days_to_disease_progression = data.get("days_to_disease_progression", None)
        progression_free_survival = data.get("progression_free_survival", None)

        if progression == "Yes" and progression_free_survival != days_to_disease_progression:
            raise ValueLocError(
                'Violate "progression_free_survival" = "days_to_disease_progression" when progression is PFS event',
                loc="progression_free_survival",
            )

    @forced_validator
    @classmethod
    def validate_response_duration_consistent(cls, data, info) -> None:
        response_duration = data.get("response_duration", None)
        days_to_first_response = data.get("days_to_first_response", None)
        days_to_disease_progression = data.get("days_to_disease_progression", None)

        try:
            response_duration = int(response_duration)
            days_to_first_response = int(days_to_first_response)
            days_to_disease_progression = int(days_to_disease_progression)
        except (ValueError, TypeError):
            return

        if response_duration != (days_to_disease_progression - days_to_first_response):
            raise ValueLocError(
                'Inconsistent "response_duration", "days_to_first_response", and "days_to_disease_progression"',
                loc="response_duration",
            )

    @forced_validator
    @classmethod
    def validate_days_to_last_vital_status_chronology(cls, data, info) -> None:
        if not (response := data.get("response", None)):
            return
        if not (days_to_last_vital_status := response.get("days_to_last_vital_status", None)):
            return

        days_to_first_response = data.get("days_to_first_response", None)
        days_to_best_response = data.get("days_to_best_response", None)
        days_to_disease_progression = data.get("days_to_disease_progression", None)

        try:
            days_to_last_vital_status = int(days_to_last_vital_status)
            days_to_first_response = int(days_to_first_response)
            days_to_best_response = int(days_to_best_response)
            days_to_disease_progression = int(days_to_disease_progression)
        except (ValueError, TypeError):
            return

        max_value = max(
            days_to_last_vital_status,
            days_to_first_response,
            days_to_best_response,
            days_to_disease_progression,
        )
        if days_to_last_vital_status != max_value:
            raise ValueLocError(
                '"days_to_last_vital_status" is not the max of all events. Rule: days_to_last_vital_status '
                ">= max(days_to_first_response,days_to_best_response,days_to_disease_progression)",
                loc="days_to_last_vital_status,days_to_first_response,days_to_best_response,days_to_disease_progression",
                cross=True,
            )

    @forced_validator
    @classmethod
    def validate_days_to_death_chronology(cls, data, info) -> None:
        if not (response := data.get("response", None)):
            return
        if not (days_to_death := response.get("days_to_death", None)):
            return

        days_to_first_response = data.get("days_to_first_response", None)
        days_to_best_response = data.get("days_to_best_response", None)
        days_to_disease_progression = data.get("days_to_disease_progression", None)

        try:
            days_to_death = int(days_to_death)
            days_to_first_response = int(days_to_first_response)
            days_to_best_response = int(days_to_best_response)
            days_to_disease_progression = int(days_to_disease_progression)
        except (ValueError, TypeError):
            return

        max_value = max(
            days_to_death,
            days_to_first_response,
            days_to_best_response,
            days_to_disease_progression,
        )

        if days_to_death != max_value:
            raise ValueLocError(
                '"days_to_death" is not the max of all events. Rule: days_to_death'
                ">= max(days_to_first_response,days_to_best_response,days_to_disease_progression)",
                loc="days_to_death,days_to_first_response,days_to_best_response,days_to_disease_progression",
                cross=True,
            )

    @forced_validator
    @classmethod
    def validate_progression_free_survival_death_chronology(cls, data, info) -> None:
        if not (response := data.get("response", None)):
            return

        days_to_death = response.get("days_to_death", None)
        progression_free_survival_event = data.get("progression_free_survival_event", None)
        progression = data.get("progression", None)
        progression_free_survival = data.get("progression_free_survival", None)

        try:
            days_to_death = int(days_to_death)
            progression_free_survival = int(progression_free_survival)
        except (ValueError, TypeError):
            return

        if (
            progression_free_survival_event == "Yes"
            and progression == "No"
            and progression_free_survival != days_to_death
        ):
            raise ValueLocError(
                'Violate "progression_free_survival" = "days_to_death" when death is PFS event',
                loc="progression_free_survival",
                cross=True,
            )

    @forced_validator
    @classmethod
    def validate_progression_free_survival_event_no_or_unknown(cls, data, info) -> None:
        if not (response := data.get("response", None)):
            return
        days_to_death = response.get("days_to_death", None)
        progression_free_survival_event = data.get("progression_free_survival_event", None)
        days_to_disease_progression = data.get("days_to_disease_progression", None)

        pfs_event = progression_free_survival_event
        if pfs_event in ["No", "Unknown"] and (days_to_disease_progression or days_to_death):
            raise ValueLocError(
                'Violate "days_to_death" and "days_to_disease_progression" should be blank when PFS event is "No" or "Unknown"',
                loc="progression_free_survival_event",
                cross=True,
            )

    @forced_validator
    @classmethod
    def validate_progression_free_survival_event_consistent(cls, data, info) -> None:
        if not (response := data.get("response", None)):
            return
        survival_status = response.get("survival_status", None)
        progression = data.get("progression", None)
        progression_free_survival_event = data.get("progression_free_survival_event", None)

        progressed_or_dead = progression == "Yes" or survival_status == "Dead"
        no_progression_and_alive = progression == "No" and survival_status == "Alive"
        pfs_event = progression_free_survival_event

        if (
            (pfs_event == "Yes" and not progressed_or_dead)
            or (progressed_or_dead and pfs_event != "Yes")
            or (pfs_event == "No" and not no_progression_and_alive)
            or (no_progression_and_alive and pfs_event != "No")
        ):
            raise ValueLocError(
                'Inconsistent flags for "progression_free_survival_event","progression" and "survival_status"',
                loc="progression_free_survival_event",
                cross=True,
            )

    @forced_validator
    @classmethod
    def validate_progression_free_survival_overall_chronology(cls, data, info) -> None:
        if not (response := data.get("response", None)):
            return
        if not (progression_free_survival := data.get("progression_free_survival", None)):
            return

        overall_survival = response.get("overall_survival", None)

        try:
            progression_free_survival = int(progression_free_survival)
            overall_survival = int(overall_survival)
        except (ValueError, TypeError):
            return

        if progression_free_survival > overall_survival:
            raise ValueLocError(
                'Violate "progression_free_survival" <= "overall_survival"',
                loc="progression_free_survival",
                cross=True,
            )
