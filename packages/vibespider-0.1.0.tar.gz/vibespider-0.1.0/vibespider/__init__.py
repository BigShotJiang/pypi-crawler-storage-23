from .agent import SpiderAgent

__all__ = ["SpiderAgent"]
__version__ = "0.1.0"
