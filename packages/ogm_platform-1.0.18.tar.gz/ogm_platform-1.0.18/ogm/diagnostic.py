"""
Diagnostic module for comprehensive OGM system diagnostics.
"""

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from rich.columns import Columns
    from rich.console import Console
    from rich.layout import Layout
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.table import Table
    from rich.text import Text

    console = Console()
    TableClass = Table
    PanelClass = Panel
    ColumnsClass = Columns
    TextClass = Text
    LayoutClass = Layout
    ProgressClass = Progress
    SpinnerColumnClass = SpinnerColumn
    TextColumnClass = TextColumn
except ImportError:
    # Fallback for environments without rich
    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

        def rule(self, *args, **kwargs):
            print("=" * 50)

    class MockTable:
        def __init__(self, *args, **kwargs):
            pass

        def add_column(self, *args, **kwargs):
            pass

        def add_row(self, *args, **kwargs):
            pass

    class MockPanel:
        def __init__(self, content, *args, **kwargs):
            self.content = content

    class MockColumns:
        def __init__(self, panels, *args, **kwargs):
            self.panels = panels

    class MockText:
        def __init__(self, text, *args, **kwargs):
            self.plain = text

    class MockLayout:
        def __init__(self, *args, **kwargs):
            pass

    class MockProgress:
        def __init__(self, *args, **kwargs):
            pass

        def add_task(self, *args, **kwargs):
            pass

        def update(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

    console = MockConsole()  # type: ignore
    TableClass = MockTable  # type: ignore
    PanelClass = MockPanel  # type: ignore
    ColumnsClass = MockColumns  # type: ignore
    TextClass = MockText  # type: ignore
    LayoutClass = MockLayout  # type: ignore
    ProgressClass = MockProgress  # type: ignore
    SpinnerColumnClass = object  # type: ignore
    TextColumnClass = object  # type: ignore


class DiagnosticManager:
    """Comprehensive diagnostic checks for OGM system components."""

    def __init__(self, config):
        self.config = config

    def _run_command(self, command: List[str], timeout: int = 10) -> tuple[bool, str, str]:
        """Run a command and return (success, stdout, stderr)."""
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
            return result.returncode == 0, result.stdout.strip(), result.stderr.strip()
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            OSError,
            subprocess.SubprocessError,
        ) as e:
            return False, "", str(e)

    def check_environment_info(self) -> Dict[str, Any]:
        """Check environment information."""
        info: Dict[str, Any] = {
            "current_directory": os.getcwd(),
            "user": os.getenv("USER", "unknown"),
            "environment_variables": {},
        }

        # Check for OGM-related environment variables
        ogm_env_vars = ["ENVIRONMENT", "NAMESPACE", "REMOTE_HOST", "CI", "GITLAB_CI"]
        for var in ogm_env_vars:
            value = os.getenv(var)
            if value:
                info["environment_variables"][var] = value

        return info

    def check_kubectl_status(self) -> Dict[str, Any]:
        """Check kubectl availability and configuration."""
        status = {
            "available": False,
            "version": "Unknown",
            "current_context": "Unknown",
            "config_accessible": False,
            "config_summary": "",
        }

        # Check kubectl availability
        success, stdout, _ = self._run_command(["kubectl", "version", "--client"])
        if success and "Client Version:" in stdout:
            status["available"] = True
            # Extract version from output like "Client Version: v1.28.5+k3s1"
            for line in stdout.split("\n"):
                if line.startswith("Client Version:"):
                    status["version"] = line.split(":", 1)[1].strip()
                    break

        # Check current context
        success, stdout, _ = self._run_command(["kubectl", "config", "current-context"])
        if success:
            status["current_context"] = stdout

        # Check kubeconfig accessibility (redacted)
        success, stdout, _ = self._run_command(["kubectl", "config", "view"])
        if success:
            status["config_accessible"] = True
            # Redact sensitive information
            lines = stdout.split("\n")[:20]  # Limit to first 20 lines
            redacted_lines = []
            for line in lines:
                if "certificate-authority-data:" in line:
                    redacted_lines.append("    certificate-authority-data: [REDACTED]")
                elif "client-certificate-data:" in line:
                    redacted_lines.append("    client-certificate-data: [REDACTED]")
                elif "client-key-data:" in line:
                    redacted_lines.append("    client-key-data: [REDACTED]")
                else:
                    redacted_lines.append(line)
            status["config_summary"] = "\n".join(redacted_lines)

        return status

    def check_cluster_connectivity(self) -> Dict[str, Any]:
        """Check cluster connectivity."""
        connectivity = {
            "cluster_info_accessible": False,
            "nodes_accessible": False,
            "node_count": 0,
        }

        # Test cluster-info
        success, _, _ = self._run_command(["kubectl", "cluster-info"])
        connectivity["cluster_info_accessible"] = success

        # Test nodes access
        success, stdout, _ = self._run_command(["kubectl", "get", "nodes", "-o", "json"])
        if success:
            connectivity["nodes_accessible"] = True
            try:
                nodes_data = json.loads(stdout)
                connectivity["node_count"] = len(nodes_data.get("items", []))
            except json.JSONDecodeError:
                pass

        return connectivity

    def check_k3s_service_status(self) -> Dict[str, Any]:
        """Check K3s service status."""
        status = {
            "systemctl_available": False,
            "k3s_service_status": "Unknown",
            "k3s_processes_running": 0,
        }

        # Check systemctl status
        success, stdout, _ = self._run_command(["systemctl", "status", "k3s", "--no-pager", "-l"])
        if success:
            status["systemctl_available"] = True
            # Extract basic status info
            lines = stdout.split("\n")
            for line in lines[:5]:  # First few lines contain status
                if "Active:" in line:
                    status["k3s_service_status"] = line.strip()
                    break

        # Check running processes
        success, stdout, _ = self._run_command(["ps", "aux"])
        if success:
            k3s_processes = [
                line for line in stdout.split("\n") if "k3s" in line and "grep" not in line
            ]
            status["k3s_processes_running"] = len(k3s_processes)

        return status

    def check_helm_status(self) -> Dict[str, Any]:
        """Check Helm availability and status."""
        status = {
            "available": False,
            "version": "Unknown",
            "releases_count": 0,
            "releases_accessible": False,
        }

        # Check helm availability
        success, stdout, _ = self._run_command(["helm", "version", "--short"])
        if success:
            status["available"] = True
            status["version"] = stdout

        # Check releases
        success, stdout, _ = self._run_command(
            ["helm", "list", "--all-namespaces", "--output", "json"]
        )
        if success:
            status["releases_accessible"] = True
            try:
                releases = json.loads(stdout)
                status["releases_count"] = len(releases)
            except json.JSONDecodeError:
                pass

        return status

    def check_ogm_command_status(self) -> Dict[str, Any]:
        """Check OGM command availability."""
        status = {"available": False, "version": "Unknown"}

        # Check ogm availability
        success, stdout, _ = self._run_command(["ogm", "--version"])
        if success:
            status["available"] = True
            status["version"] = stdout

        return status

    def check_basic_cluster_resources(self) -> Dict[str, Any]:
        """Check basic cluster resource counts."""
        resources = {
            "namespaces": 0,
            "pods": 0,
            "services": 0,
            "deployments": 0,
            "accessible": False,
        }

        # Check namespaces
        success, stdout, _ = self._run_command(["kubectl", "get", "namespaces", "-o", "json"])
        if success:
            resources["accessible"] = True
            try:
                ns_data = json.loads(stdout)
                resources["namespaces"] = len(ns_data.get("items", []))
            except json.JSONDecodeError:
                pass

        # Check pods
        success, stdout, _ = self._run_command(
            ["kubectl", "get", "pods", "--all-namespaces", "-o", "json"]
        )
        if success:
            try:
                pods_data = json.loads(stdout)
                resources["pods"] = len(pods_data.get("items", []))
            except json.JSONDecodeError:
                pass

        # Check services
        success, stdout, _ = self._run_command(
            ["kubectl", "get", "services", "--all-namespaces", "-o", "json"]
        )
        if success:
            try:
                svc_data = json.loads(stdout)
                resources["services"] = len(svc_data.get("items", []))
            except json.JSONDecodeError:
                pass

        # Check deployments
        success, stdout, _ = self._run_command(
            ["kubectl", "get", "deployments", "--all-namespaces", "-o", "json"]
        )
        if success:
            try:
                deploy_data = json.loads(stdout)
                resources["deployments"] = len(deploy_data.get("items", []))
            except json.JSONDecodeError:
                pass

        return resources

    def run_full_diagnostic(self, json_output: bool = False):
        """Run comprehensive diagnostic checks."""

        if json_output:
            self._generate_json_diagnostic()
            return

        console.print("\n[bold cyan]═══════════════════════════════════════[/bold cyan]")
        console.print("[bold cyan]  🔧 OGM DIAGNOSTIC REPORT[/bold cyan]")
        console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]\n")

        # 1. Environment Info
        console.print("[bold blue]1. ENVIRONMENT INFO[/bold blue]")
        console.rule()

        env_info = self.check_environment_info()
        console.print(f"Current directory: {env_info['current_directory']}")
        console.print(f"User: {env_info['user']}")

        if env_info["environment_variables"]:
            console.print("OGM environment variables:")
            for var, value in env_info["environment_variables"].items():
                console.print(f"  {var}={value}")
        else:
            console.print("No OGM environment variables found")
        console.print()

        # 2. kubectl Status
        console.print("[bold blue]2. KUBECTL STATUS[/bold blue]")
        console.rule()

        kubectl_status = self.check_kubectl_status()
        status = (
            "[green]✓ Available[/green]"
            if kubectl_status["available"]
            else "[red]✗ Unavailable[/red]"
        )
        console.print(f"kubectl available: {status}")
        console.print(f"kubectl version: {kubectl_status['version']}")
        console.print(f"Current context: {kubectl_status['current_context']}")

        if kubectl_status["config_accessible"]:
            console.print("Kubeconfig: [green]✓ Accessible[/green]")
            if kubectl_status["config_summary"]:
                console.print("Config summary (redacted):")
                console.print(kubectl_status["config_summary"])
        else:
            console.print("Kubeconfig: [red]✗ Not accessible[/red]")
        console.print()

        # 3. Cluster Connectivity
        console.print("[bold blue]3. CLUSTER CONNECTIVITY[/bold blue]")
        console.rule()

        connectivity = self.check_cluster_connectivity()
        status = (
            "[green]✓ Accessible[/green]"
            if connectivity["cluster_info_accessible"]
            else "[red]✗ Not accessible[/red]"
        )
        console.print(f"Cluster info: {status}")

        status = (
            "[green]✓ Accessible[/green]"
            if connectivity["nodes_accessible"]
            else "[red]✗ Not accessible[/red]"
        )
        console.print(f"Nodes: {status} ({connectivity['node_count']} nodes)")
        console.print()

        # 4. K3s Service Status
        console.print("[bold blue]4. K3S SERVICE STATUS[/bold blue]")
        console.rule()

        k3s_status = self.check_k3s_service_status()
        if k3s_status["systemctl_available"]:
            console.print(f"K3s service status: {k3s_status['k3s_service_status']}")
        else:
            console.print("K3s service: [red]✗ systemctl not available or service not found[/red]")

        console.print(f"K3s processes running: {k3s_status['k3s_processes_running']}")
        console.print()

        # 5. Helm Status
        console.print("[bold blue]5. HELM STATUS[/bold blue]")
        console.rule()

        helm_status = self.check_helm_status()
        status = (
            "[green]✓ Available[/green]" if helm_status["available"] else "[red]✗ Unavailable[/red]"
        )
        console.print(f"Helm available: {status}")
        console.print(f"Helm version: {helm_status['version']}")

        if helm_status["releases_accessible"]:
            console.print(
                f"Helm releases: [green]✓ Accessible[/green] ({helm_status['releases_count']} releases)"
            )
        else:
            console.print("Helm releases: [red]✗ Not accessible[/red]")
        console.print()

        # 6. OGM Command Status
        console.print("[bold blue]6. OGM COMMAND STATUS[/bold blue]")
        console.rule()

        ogm_status = self.check_ogm_command_status()
        status = (
            "[green]✓ Available[/green]" if ogm_status["available"] else "[red]✗ Unavailable[/red]"
        )
        console.print(f"OGM available: {status}")
        console.print(f"OGM version: {ogm_status['version']}")
        console.print()

        # 7. Basic Cluster Resources
        console.print("[bold blue]7. BASIC CLUSTER RESOURCES[/bold blue]")
        console.rule()

        resources = self.check_basic_cluster_resources()
        if resources["accessible"]:
            console.print(f"Namespaces: {resources['namespaces']}")
            console.print(f"Pods: {resources['pods']}")
            console.print(f"Services: {resources['services']}")
            console.print(f"Deployments: {resources['deployments']}")
        else:
            console.print("[red]✗ Cluster resources not accessible[/red]")
        console.print()

        console.print("[bold green]✓ Diagnostic report complete![/bold green]")

    def _generate_json_diagnostic(self):
        """Generate diagnostic report in JSON format."""
        diagnostic_data = {
            "environment": self.check_environment_info(),
            "kubectl": self.check_kubectl_status(),
            "cluster_connectivity": self.check_cluster_connectivity(),
            "k3s_service": self.check_k3s_service_status(),
            "helm": self.check_helm_status(),
            "ogm_command": self.check_ogm_command_status(),
            "cluster_resources": self.check_basic_cluster_resources(),
        }

        console.print(json.dumps(diagnostic_data, indent=2, default=str))
