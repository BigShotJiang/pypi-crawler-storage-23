"""
OGM Platform: Kubernetes Platform for GenAI Applications.

A comprehensive platform for managing Kubernetes clusters, deploying GenAI applications,
and orchestrating development workflows.
"""

__version__ = "1.0.0"
__author__ = "OGM-Dev Team"
__email__ = "dev@ogm.local"

from . import insight
from .config import OGMConfig

__all__ = ["OGMConfig", "insight", "__version__"]
