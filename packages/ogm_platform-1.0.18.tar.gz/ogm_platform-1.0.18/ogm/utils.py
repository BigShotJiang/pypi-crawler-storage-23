"""
Utility functions for OGM-Dev operations.

Common utilities for command execution, validation, and Kubernetes operations.
"""

import json
import os
import platform
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, cast

from rich.console import Console

console = Console()


def run_command(
    cmd: List[str], cwd: Optional[str] = None, capture_output: bool = False, check: bool = True
) -> Optional[str]:
    """
    Run a shell command.

    Args:
        cmd: Command and arguments as list
        cwd: Working directory
        capture_output: Capture and return output
        check: Raise exception on failure

    Returns:
        Command output if capture_output=True, None otherwise
    """
    try:
        if capture_output:
            result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, check=check)
            return result.stdout.strip() if result.stdout else None
        else:
            subprocess.run(cmd, cwd=cwd, check=check)
            return None

    except subprocess.CalledProcessError as e:
        if check:
            console.print(f"[red]Command failed: {' '.join(cmd)}[/red]")
            if capture_output and e.stderr:
                console.print(f"[red]Error: {e.stderr}[/red]")
        return None
    except FileNotFoundError:
        console.print(f"[red]Command not found: {cmd[0]}[/red]")
        return None


def validate_prerequisites() -> Tuple[bool, List[str]]:
    """
    Validate system prerequisites.

    Returns:
        Tuple of (all_ok, missing_tools)
    """
    environment = os.getenv("ENVIRONMENT", "dev").lower()

    # Base required tools for all environments
    required_tools = {
        "kubectl": "Kubernetes CLI",
        "helm": "Helm package manager",
        "git": "Git version control",
    }

    # Docker is only required for full Kubernetes (stage/prod), not for K3s (dev)
    if environment in ["stage", "prod"]:
        required_tools["docker"] = "Docker (required for full Kubernetes)"

    missing = []

    for tool, description in required_tools.items():
        if not shutil.which(tool):
            missing.append(f"{tool} ({description})")

    return len(missing) == 0, missing


def install_prerequisites() -> bool:
    """
    Install missing system prerequisites.

    Returns:
        True if all installed successfully, False otherwise
    """
    console.print("[cyan]Checking and installing prerequisites...[/cyan]")

    system = platform.system().lower()
    if system != "linux":
        console.print(
            "[yellow]Automatic installation not supported on "
            f"{system}. Please install manually: kubectl, helm, git, docker[/yellow]"
        )
        return False

    # Check for sudo access
    has_sudo = False
    try:
        result = subprocess.run(["sudo", "-n", "true"], capture_output=True, timeout=5)
        has_sudo = result.returncode == 0
    except:
        pass

    if not has_sudo:
        console.print("[yellow]⚠️  No sudo access detected[/yellow]")
        console.print("[yellow]Some prerequisites may require manual installation[/yellow]")

    # Check what's missing
    all_ok, missing = validate_prerequisites()
    if all_ok:
        console.print("[green]✓ All prerequisites already installed[/green]")
        return True

    console.print(f"[yellow]Missing tools: {', '.join(missing)}[/yellow]")
    console.print("[cyan]Installing missing prerequisites...[/cyan]")

    environment = os.getenv("ENVIRONMENT", "dev").lower()

    success = True

    # Install kubectl if missing (skip for dev only if K3s is already installed)
    if not shutil.which("kubectl"):
        if environment == "dev" and check_k3s_installed():
            # In dev environment, if K3s is already installed, it provides kubectl
            console.print("K3s is installed, kubectl should be available...")
        else:
            # Install kubectl if K3s isn't installed or not in dev environment
            console.print("Installing kubectl...")
            if not _install_kubectl():
                console.print("[red]Failed to install kubectl[/red]")
                success = False

    # Install helm if missing
    if not shutil.which("helm"):
        console.print("Installing Helm...")
        if not _install_helm():
            console.print("[red]Failed to install Helm[/red]")
            success = False

    # Git should be installed by default on most systems
    if not shutil.which("git"):
        console.print("Installing Git...")
        if not _install_git(has_sudo):
            console.print("[red]Failed to install Git[/red]")
            success = False

    # Install docker if missing (only for stage/prod environments)
    if not shutil.which("docker") and environment in ["stage", "prod"]:
        console.print("Installing Docker...")
        if not _install_docker(has_sudo):
            console.print("[red]Failed to install Docker[/red]")
            success = False

    if success:
        console.print("[green]✓ All prerequisites installed[/green]")
    else:
        console.print("[red]✗ Some prerequisites failed to install[/red]")

    return success


def _install_kubectl() -> bool:
    """Install kubectl on Linux."""
    try:
        import os

        home = os.path.expanduser("~")
        bin_dir = f"{home}/.local/bin"
        os.makedirs(bin_dir, exist_ok=True)

        # Detect architecture
        arch = platform.machine().lower()
        if arch == "x86_64":
            kubectl_arch = "amd64"
        elif arch in ["aarch64", "arm64"]:
            kubectl_arch = "arm64"
        else:
            kubectl_arch = "amd64"  # fallback

        # Download and install kubectl
        cmd = (
            f'curl -LO "https://dl.k8s.io/release/$(curl -L -s '
            f'https://dl.k8s.io/release/stable.txt)/bin/linux/{kubectl_arch}/kubectl"'
        )
        subprocess.run(cmd, shell=True, check=True)
        subprocess.run("chmod +x kubectl", shell=True, check=True)
        subprocess.run(f"mv kubectl {bin_dir}/", shell=True, check=True)
        return True
    except subprocess.CalledProcessError:
        return False


def _install_helm() -> bool:
    """Install Helm on Linux."""
    try:
        import os

        home = os.path.expanduser("~")
        bin_dir = f"{home}/.local/bin"
        os.makedirs(bin_dir, exist_ok=True)

        # Download and install Helm
        cmd = "curl https://get.helm.sh/helm-v3.15.4-linux-amd64.tar.gz -o helm.tar.gz"
        subprocess.run(cmd, shell=True, check=True)
        subprocess.run("tar -zxvf helm.tar.gz", shell=True, check=True)
        subprocess.run(f"mv linux-amd64/helm {bin_dir}/", shell=True, check=True)
        subprocess.run("rm -rf linux-amd64 helm.tar.gz", shell=True, check=True)
        return True
    except subprocess.CalledProcessError:
        return False


def _install_git(has_sudo: bool = False) -> bool:
    """Install Git on Linux."""
    try:
        if has_sudo:
            # Try sudo first
            subprocess.run(
                "sudo apt-get update && sudo apt-get install -y git", shell=True, check=True
            )
            return True
        else:
            console.print("[yellow]No sudo access - attempting user-space installation[/yellow]")
            # Try to install to user space or check if already available
            home = os.path.expanduser("~")
            bin_dir = f"{home}/.local/bin"
            os.makedirs(bin_dir, exist_ok=True)

            # Check if git is available in user space
            if shutil.which("git"):
                console.print("[green]Git found in PATH[/green]")
                return True

            console.print("[red]Cannot install git without sudo - please install manually[/red]")
            return False
    except subprocess.CalledProcessError:
        console.print(
            "[yellow]Failed to install git with sudo, assuming it's already installed[/yellow]"
        )
        return True  # Don't fail, assume git is available


def _install_docker(has_sudo: bool = False) -> bool:
    """Install Docker on Linux."""
    try:
        if has_sudo:
            # Try sudo
            cmd = "curl -fsSL https://get.docker.com -o get-docker.sh && sudo sh get-docker.sh"
            subprocess.run(cmd, shell=True, check=True)
            subprocess.run("rm get-docker.sh", shell=True, check=True)
            return True
        else:
            console.print(
                "[yellow]No sudo access - Docker installation requires root privileges[/yellow]"
            )
            console.print("[red]Cannot install Docker without sudo - please install manually[/red]")
            return False
    except subprocess.CalledProcessError:
        console.print(
            "[yellow]Failed to install docker with sudo, assuming it's already installed[/yellow]"
        )
        return True  # Don't fail, assume docker is available


def check_k3s_installed() -> bool:
    """Check if K3s is installed."""
    return shutil.which("k3s") is not None or shutil.which("kubectl") is not None


def check_namespace_exists(namespace: str) -> bool:
    """
    Check if Kubernetes namespace exists.

    Args:
        namespace: Namespace name

    Returns:
        True if exists, False otherwise
    """
    result = run_command(
        ["kubectl", "get", "namespace", namespace], capture_output=True, check=False
    )
    return result is not None and namespace in result


def get_pod_status(namespace: str, label_selector: Optional[str] = None) -> Optional[str]:
    """
    Get pod status in a namespace.

    Args:
        namespace: Kubernetes namespace
        label_selector: Optional label selector

    Returns:
        Pod status output or None
    """
    cmd = ["kubectl", "get", "pods", "-n", namespace]

    if label_selector:
        cmd.extend(["-l", label_selector])

    return run_command(cmd, capture_output=True, check=False)


def format_bytes(bytes_value: int) -> str:
    """
    Format bytes to human-readable string.

    Args:
        bytes_value: Number of bytes

    Returns:
        Formatted string (e.g., "1.5 GB")
    """
    value = float(bytes_value)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024.0:
            return f"{value:.1f} {unit}"
        value /= 1024.0
    return f"{value:.1f} PB"


def read_yaml_file(file_path: Path) -> Optional[Dict[Any, Any]]:
    """
    Read and parse YAML file.

    Args:
        file_path: Path to YAML file

    Returns:
        Parsed YAML as dictionary or None
    """
    try:
        import yaml

        with open(file_path, "r") as f:
            return cast(Optional[Dict[Any, Any]], yaml.safe_load(f))
    except Exception as e:
        console.print(f"[red]Failed to read YAML file: {e}[/red]")
        return None


def write_yaml_file(file_path: Path, data: dict) -> bool:
    """
    Write dictionary to YAML file.

    Args:
        file_path: Path to YAML file
        data: Dictionary to write

    Returns:
        True if successful, False otherwise
    """
    try:
        import yaml

        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
        return True
    except Exception as e:
        console.print(f"[red]Failed to write YAML file: {e}[/red]")
        return False


def check_port_available(port: int) -> bool:
    """
    Check if a port is available.

    Args:
        port: Port number

    Returns:
        True if available, False if in use
    """
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("", port))
            return True
        except OSError:
            return False


def get_kubectl_context() -> Optional[str]:
    """
    Get current kubectl context.

    Returns:
        Current context name or None
    """
    result = run_command(["kubectl", "config", "current-context"], capture_output=True, check=False)
    return result


def switch_kubectl_context(context: str) -> bool:
    """
    Switch kubectl context.

    Args:
        context: Context name

    Returns:
        True if successful, False otherwise
    """
    try:
        subprocess.run(
            ["kubectl", "config", "use-context", context], check=True, capture_output=True
        )
        return True
    except subprocess.CalledProcessError:
        return False


def get_available_contexts() -> List[str]:
    """
    Get list of available kubectl contexts.

    Returns:
        List of context names
    """
    result = run_command(
        ["kubectl", "config", "get-contexts", "-o", "name"], capture_output=True, check=False
    )
    if result:
        return result.split("\n")
    return []


# --- PVC/PV Finalizer Removal Utility ---
def remove_finalizers(kind: str, name: str, namespace: Optional[str] = None):
    """
    Remove finalizers from a PVC or PV to force deletion.
    """
    if kind == "pvc":
        get_cmd = ["kubectl", "get", "pvc", name, "-o", "json"]
        if namespace:
            get_cmd.extend(["-n", namespace])
    elif kind == "pv":
        get_cmd = ["kubectl", "get", "pv", name, "-o", "json"]
    else:
        return

    obj_json = run_command(get_cmd, capture_output=True, check=False)
    if not obj_json:
        return

    obj = json.loads(obj_json)
    if "finalizers" in obj.get("metadata", {}):
        obj["metadata"]["finalizers"] = []
        with open("/tmp/ogm-finalizer-cleanup.json", "w") as f:
            json.dump(obj, f)
        if kind == "pvc":
            replace_cmd = ["kubectl", "replace", "--force", "-f", "/tmp/ogm-finalizer-cleanup.json"]
        else:
            replace_cmd = ["kubectl", "replace", "-f", "/tmp/ogm-finalizer-cleanup.json"]
        run_command(replace_cmd, check=False)
