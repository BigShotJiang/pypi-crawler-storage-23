"""
Configuration management module.

Handles loading and validation of OGM-Dev configuration using Pydantic models.
"""

import os
from pathlib import Path
from typing import Any, List, Optional

import yaml
from pydantic import BaseModel, Field


class K3sConfig(BaseModel):
    """K3s cluster configuration."""

    version: str = "v1.28.5+k3s1"
    kubeconfig_path: str = "~/.kube/config"
    data_dir: str = "/var/lib/rancher/k3s"
    disabled_components: List[str] = Field(default_factory=lambda: ["traefik", "servicelb"])

    class Config:
        extra = "allow"


class RepositoryConfig(BaseModel):
    """Git repository configuration."""

    name: str
    url: str
    branch: str = "main"
    submodules: bool = False
    build_command: Optional[str] = None

    class Config:
        extra = "allow"


class HelmChartConfig(BaseModel):
    """Helm chart configuration."""

    name: str
    chart: str
    repository: Optional[str] = None
    version: Optional[str] = None
    namespace: str = "default"
    values: Optional[Any] = None  # Can be str (path/inline YAML) or dict (YAML object)
    values_file: Optional[str] = None  # Path to values file
    wait: bool = True
    timeout: str = "5m"

    class Config:
        extra = "allow"


class InfrastructureConfig(BaseModel):
    """Infrastructure components configuration."""

    ingress: bool = True
    monitoring: bool = False
    logging: bool = False
    cert_manager: bool = False

    class Config:
        extra = "allow"


class MonitoringConfig(BaseModel):
    """Monitoring configuration."""

    enabled: bool = False
    prometheus: bool = True
    grafana: bool = True
    retention_days: int = 7

    class Config:
        extra = "allow"


class OGMConfig(BaseModel):
    """Main OGM-Dev configuration."""

    version: str = "1.0.0"
    repos_dir: Path = Field(default_factory=lambda: Path.home() / "ogm-repos")
    state_file: Path = Field(default_factory=lambda: Path.home() / ".ogm" / "state.json")
    namespace: str = Field(default_factory=lambda: os.getenv("ENVIRONMENT", "dev").lower())

    k3s: K3sConfig = Field(default_factory=K3sConfig)
    repositories: List[RepositoryConfig] = Field(default_factory=list)
    helm_charts: List[HelmChartConfig] = Field(default_factory=list)
    infrastructure: InfrastructureConfig = Field(default_factory=InfrastructureConfig)
    monitoring: MonitoringConfig = Field(default_factory=MonitoringConfig)

    @classmethod
    def from_yaml(cls, path: Path) -> "OGMConfig":
        """
        Load configuration from YAML file.

        Args:
            path: Path to YAML configuration file

        Returns:
            OGMConfig instance
        """
        with open(path, "r") as f:
            data = yaml.safe_load(f)

        # Replace environment variables
        data = cls._replace_env_vars(data)

        return cls(**data)

    @classmethod
    def _replace_env_vars(cls, data: Any) -> Any:
        """Replace ${VAR} with environment variables."""
        if isinstance(data, dict):
            return {k: cls._replace_env_vars(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [cls._replace_env_vars(item) for item in data]
        elif isinstance(data, str):
            import re

            # Replace ${VAR} patterns anywhere in the string
            def replace_var(match):
                var_name = match.group(1)
                return os.getenv(var_name, match.group(0))

            return re.sub(r"\$\{([^}]+)\}", replace_var, data)
        return data

    def save_to_yaml(self, path: Path) -> None:
        """
        Save configuration to YAML file.

        Args:
            path: Path to save YAML file
        """
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w") as f:
            yaml.dump(self.dict(), f, default_flow_style=False, sort_keys=False)

    class Config:
        arbitrary_types_allowed = True


def load_config(config_path: Optional[Path] = None) -> OGMConfig:
    """
    Load OGM configuration.

    Args:
        config_path: Optional path to config file

    Returns:
        OGMConfig instance
    """
    if config_path and config_path.exists():
        return OGMConfig.from_yaml(config_path)

    # Look for config in default locations
    default_locations = [
        Path.cwd() / ".ogmconfig",
        Path.home() / ".ogm" / "config.yaml",
        Path.home() / ".ogmconfig",
    ]

    for location in default_locations:
        if location.exists():
            return OGMConfig.from_yaml(location)

    # Return default configuration
    return OGMConfig()
