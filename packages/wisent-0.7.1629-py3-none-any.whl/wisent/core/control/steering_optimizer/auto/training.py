"""
Training helpers for auto steering optimization.
"""

from __future__ import annotations

import logging
from typing import List, Dict, Any

from wisent.core.utils.config_tools.constants import (
    GROM_NUM_DIRECTIONS, GROM_OPTIMIZATION_STEPS, GROM_LEARNING_RATE,
    GROM_WARMUP_STEPS, GROM_BEHAVIOR_WEIGHT, GROM_RETAIN_WEIGHT,
    GROM_SPARSE_WEIGHT, GROM_SMOOTH_WEIGHT, GROM_INDEPENDENCE_WEIGHT,
    GROM_MAX_ALPHA, GROM_GATE_TEMPERATURE,
    DEFAULT_WEIGHT_DECAY, GROM_MAX_GRAD_NORM, GROM_ETA_MIN_FACTOR,
    GROM_LINEAR_THRESHOLD,
    TECZA_NUM_DIRECTIONS, TECZA_LEARNING_RATE, TECZA_RETAIN_WEIGHT,
    TECZA_INDEPENDENCE_WEIGHT, TECZA_MIN_COSINE_SIM, TECZA_MAX_COSINE_SIM,
    DEFAULT_VARIANCE_THRESHOLD, TECZA_MARGINAL_THRESHOLD,
    TECZA_MAX_DIRECTIONS, TECZA_ABLATION_WEIGHT, TECZA_ADDITION_WEIGHT,
    DEFAULT_OPTIMIZATION_STEPS,
    TETNO_CONDITION_THRESHOLD, TETNO_GATE_TEMPERATURE,
    TETNO_MAX_ALPHA, TETNO_ENTROPY_FLOOR, TETNO_ENTROPY_CEILING,
    TETNO_THRESHOLD_SEARCH_STEPS,
)

logger = logging.getLogger(__name__)


def train_recommended_method(
    wisent_model: Any,
    pairs: List[Any],
    method: str,
    layer: int,
    verbose: bool = False
) -> Dict[str, Any]:
    """
    Train the recommended steering method.

    Args:
        wisent_model: WisentModel instance
        pairs: List of contrastive pairs
        method: Recommended method name (CAA, GROM, TECZA, TETNO)
        layer: Layer parameter (not used for multi-layer training)
        verbose: Enable verbose output

    Returns:
        Dictionary with method name, layer count, and trained result
    """
    from wisent.core.primitives.contrastive_pairs.core.set import ContrastivePairSet
    from wisent.core.primitives.model_interface.core.activations.activations_collector import ActivationCollector
    from wisent.core.primitives.model_interface.core.activations import ExtractionStrategy

    num_layers = wisent_model.num_layers
    all_layers = [str(i) for i in range(1, num_layers + 1)]

    if verbose:
        print(f"   Collecting activations for {len(pairs)} pairs...")

    collector = ActivationCollector(model=wisent_model)
    enriched_pairs = []

    for i, pair in enumerate(pairs):
        enriched = collector.collect(pair, strategy=ExtractionStrategy.CHAT_LAST, layers=all_layers)
        enriched_pairs.append(enriched)
        if verbose and (i + 1) % 25 == 0:
            print(f"     {i + 1}/{len(pairs)} pairs processed")

    pair_set = ContrastivePairSet(pairs=enriched_pairs, name=f"{method.lower()}_training")

    if verbose:
        print(f"   Collected activations for {len(enriched_pairs)} pairs")

    if method == "CAA":
        return _train_caa(pair_set, verbose)
    elif method == "GROM":
        return _train_grom(wisent_model, pair_set, all_layers, verbose)
    elif method == "TECZA":
        return _train_tecza(wisent_model, pair_set, verbose)
    elif method == "TETNO":
        return _train_tetno(wisent_model, pair_set, all_layers, verbose)
    else:
        logger.warning(f"Unknown method {method}, falling back to CAA")
        return _train_caa(pair_set, verbose)


def _train_caa(pair_set: Any, verbose: bool) -> Dict[str, Any]:
    """Train CAA method."""
    from wisent.core.control.steering_methods.methods.caa import CAAMethod

    caa_method = CAAMethod()
    result = caa_method.train(pair_set)

    if verbose:
        print(f"   CAA trained on {len(pair_set.pairs)} pairs")
        print(f"     Layers: {len(result.directions)}")

    return {
        "method": "CAA",
        "layers": len(result.directions),
        "result": result,
        "method_params": {"normalize": True},
    }


def _train_grom(wisent_model: Any, pair_set: Any, all_layers: List[str], verbose: bool) -> Dict[str, Any]:
    """Train GROM method."""
    from wisent.core.control.steering_methods.methods.grom import GROMMethod

    layer_indices = [int(l) for l in all_layers]
    first_layer = next(iter(layer_indices))
    grom_method = GROMMethod(
        model=wisent_model,
        num_directions=GROM_NUM_DIRECTIONS,
        steering_layers=layer_indices,
        sensor_layer=first_layer,
        optimization_steps=GROM_OPTIMIZATION_STEPS,
        learning_rate=GROM_LEARNING_RATE,
        warmup_steps=GROM_WARMUP_STEPS,
        behavior_weight=GROM_BEHAVIOR_WEIGHT,
        retain_weight=GROM_RETAIN_WEIGHT,
        sparse_weight=GROM_SPARSE_WEIGHT,
        smooth_weight=GROM_SMOOTH_WEIGHT,
        independence_weight=GROM_INDEPENDENCE_WEIGHT,
        max_alpha=GROM_MAX_ALPHA,
        gate_temperature=GROM_GATE_TEMPERATURE,
        min_cosine_similarity=TECZA_MIN_COSINE_SIM,
        max_cosine_similarity=TECZA_MAX_COSINE_SIM,
        weight_decay=DEFAULT_WEIGHT_DECAY,
        max_grad_norm=GROM_MAX_GRAD_NORM,
        eta_min_factor=GROM_ETA_MIN_FACTOR,
        linear_threshold=GROM_LINEAR_THRESHOLD,
    )

    result = grom_method.train_grom(pair_set)

    if verbose:
        print(f"   GROM trained on {len(pair_set.pairs)} pairs")
        print(f"     Layers: {len(result.layer_order)}")
        print(f"     Directions per layer: {result.directions[result.layer_order[0]].shape[0]}")

    return {
        "method": "GROM",
        "layers": len(result.layer_order),
        "result": result,
        "method_params": grom_method.config.__dict__,
    }


def _train_tecza(wisent_model: Any, pair_set: Any, verbose: bool) -> Dict[str, Any]:
    """Train TECZA method."""
    from wisent.core.control.steering_methods.methods.advanced import TECZAMethod

    tecza_method = TECZAMethod(
        model=wisent_model.hf_model,
        num_directions=TECZA_NUM_DIRECTIONS,
        optimization_steps=DEFAULT_OPTIMIZATION_STEPS,
        learning_rate=TECZA_LEARNING_RATE,
        retain_weight=TECZA_RETAIN_WEIGHT,
        independence_weight=TECZA_INDEPENDENCE_WEIGHT,
        min_cosine_similarity=TECZA_MIN_COSINE_SIM,
        max_cosine_similarity=TECZA_MAX_COSINE_SIM,
        variance_threshold=DEFAULT_VARIANCE_THRESHOLD,
        marginal_threshold=TECZA_MARGINAL_THRESHOLD,
        max_directions=TECZA_MAX_DIRECTIONS,
        ablation_weight=TECZA_ABLATION_WEIGHT,
        addition_weight=TECZA_ADDITION_WEIGHT,
    )

    result = tecza_method.train(pair_set)

    if verbose:
        num_dirs = next(iter(result.directions.values())).shape[0]
        print(f"   TECZA trained on {len(pair_set.pairs)} pairs")
        print(f"     Layers: {len(result.directions)}")
        print(f"     Directions per layer: {num_dirs}")

    return {
        "method": "TECZA",
        "layers": len(result.directions),
        "result": result,
        "method_params": tecza_method.config.__dict__,
    }


def _train_tetno(wisent_model: Any, pair_set: Any, all_layers: List[str], verbose: bool) -> Dict[str, Any]:
    """Train TETNO method."""
    from wisent.core.control.steering_methods.methods.advanced import TETNOMethod

    layer_indices = [int(l) for l in all_layers]
    first_layer = next(iter(layer_indices))
    tetno_method = TETNOMethod(
        model=wisent_model.hf_model,
        steering_layers=layer_indices,
        sensor_layer=first_layer,
        condition_threshold=TETNO_CONDITION_THRESHOLD,
        gate_temperature=TETNO_GATE_TEMPERATURE,
        max_alpha=TETNO_MAX_ALPHA,
        optimization_steps=DEFAULT_OPTIMIZATION_STEPS,
        learning_rate=TECZA_LEARNING_RATE,
        entropy_floor=TETNO_ENTROPY_FLOOR,
        entropy_ceiling=TETNO_ENTROPY_CEILING,
        threshold_search_steps=TETNO_THRESHOLD_SEARCH_STEPS,
    )

    result = tetno_method.train_tetno(pair_set)

    if verbose:
        print(f"   TETNO trained on {len(pair_set.pairs)} pairs")
        print(f"     Layers: {len(result.behavior_vectors)}")
        print(f"     Optimal threshold: {result.optimal_threshold:.3f}")

    return {
        "method": "TETNO",
        "layers": len(result.behavior_vectors),
        "result": result,
        "method_params": tetno_method.config.__dict__,
    }
