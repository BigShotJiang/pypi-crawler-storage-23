"""Steering method definitions: TETNO, GROM, PRZELOM."""

from wisent.core.utils.config_tools.constants import (
    STEERING_STRENGTH_RANGE_WIDE,
    STEERING_STRENGTH_RANGE_NARROW,
)
from wisent.core.control.steering_methods.registry.registry import (
    SteeringMethodDefinition,
    SteeringMethodParameter,
    SteeringMethodType,
)


TETNO_DEFINITION = SteeringMethodDefinition(
    name="tetno",
    method_type=SteeringMethodType.TETNO,
    description="TETNO - Probabilistic Uncertainty-guided Layer Steering Engine. Layer-adaptive conditional steering with uncertainty-guided intensity.",
    method_class_path="wisent.core.control.steering_methods.methods.tetno.TETNOMethod",
    parameters=[
        SteeringMethodParameter(
            name="sensor_layer",
            type=int,
            default=None, required=False,
            help="Layer index where condition gating is computed (auto-computed if not set)",
            cli_flag="--tetno-sensor-layer",
        ),
        SteeringMethodParameter(
            name="steering_layers",
            type=str,
            default=None, required=False,
            help="Comma-separated layer indices where steering is applied (auto-computed if not set)",
            cli_flag="--tetno-steering-layers",
        ),
        SteeringMethodParameter(
            name="per_layer_scaling",
            type=bool,
            default=True, required=False,
            help="Learn different scaling per layer",
            action="store_true",
            cli_flag="--tetno-per-layer-scaling",
        ),
        SteeringMethodParameter(
            name="condition_threshold",
            type=float,
            help="Threshold for condition activation (0-1)",
            cli_flag="--tetno-condition-threshold",
        ),
        SteeringMethodParameter(
            name="gate_temperature",
            type=float,
            help="Temperature for sigmoid gating (lower = sharper)",
            cli_flag="--tetno-gate-temperature",
        ),
        SteeringMethodParameter(
            name="learn_threshold",
            type=bool,
            default=True, required=False,
            help="Learn optimal threshold via grid search",
            action="store_true",
            cli_flag="--tetno-learn-threshold",
        ),
        SteeringMethodParameter(
            name="use_entropy_scaling",
            type=bool,
            default=True, required=False,
            help="Enable entropy-based intensity modulation",
            action="store_true",
            cli_flag="--tetno-use-entropy-scaling",
        ),
        SteeringMethodParameter(
            name="entropy_floor",
            type=float,
            help="Minimum entropy to trigger scaling",
            cli_flag="--tetno-entropy-floor",
        ),
        SteeringMethodParameter(
            name="entropy_ceiling",
            type=float,
            help="Entropy at which max_alpha is reached",
            cli_flag="--tetno-entropy-ceiling",
        ),
        SteeringMethodParameter(
            name="max_alpha",
            type=float,
            help="Maximum steering strength",
            cli_flag="--tetno-max-alpha",
        ),
        SteeringMethodParameter(
            name="optimization_steps",
            type=int,
            help="Steps for condition vector optimization",
            cli_flag="--tetno-optimization-steps",
        ),
        SteeringMethodParameter(
            name="learning_rate",
            type=float,
            help="Learning rate for optimization",
            cli_flag="--tetno-learning-rate",
        ),
        SteeringMethodParameter(
            name="normalize",
            type=bool,
            default=True, required=False,
            help="L2-normalize vectors",
            action="store_true",
            cli_flag="--tetno-normalize",
        ),
    ],
    optimization_config={
        "strength_search_range": STEERING_STRENGTH_RANGE_NARROW,
        "threshold_search_range": (0.0, 1.0),
    },
    strength_range=STEERING_STRENGTH_RANGE_NARROW,
)


GROM_DEFINITION = SteeringMethodDefinition(
    name="grom",
    method_type=SteeringMethodType.GROM,
    description="GROM - Total Integrated Targeted Activation Navigation. Joint optimization of manifold, gating, and intensity.",
    method_class_path="wisent.core.control.steering_methods.methods.grom.GROMMethod",
    parameters=[
        SteeringMethodParameter(
            name="num_directions",
            type=int,
            help="Number of directions per layer in the steering manifold",
            cli_flag="--grom-num-directions",
        ),
        SteeringMethodParameter(
            name="steering_layers",
            type=str,
            default=None, required=False,
            help="Comma-separated layer indices for steering (auto-computed if not set)",
            cli_flag="--grom-steering-layers",
        ),
        SteeringMethodParameter(
            name="sensor_layer",
            type=int,
            default=None, required=False,
            help="Primary layer for gating decisions (auto-computed if not set)",
            cli_flag="--grom-sensor-layer",
        ),
        SteeringMethodParameter(
            name="gate_hidden_dim",
            type=int,
            default=None, required=False,
            help="Hidden dimension for gating network (auto-computed as hidden_dim//16 if not set)",
            cli_flag="--grom-gate-hidden-dim",
        ),
        SteeringMethodParameter(
            name="intensity_hidden_dim",
            type=int,
            default=None, required=False,
            help="Hidden dimension for intensity network (auto-computed as hidden_dim//32 if not set)",
            cli_flag="--grom-intensity-hidden-dim",
        ),
        SteeringMethodParameter(
            name="optimization_steps",
            type=int,
            help="Total optimization steps",
            cli_flag="--grom-optimization-steps",
        ),
        SteeringMethodParameter(
            name="learning_rate",
            type=float,
            help="Learning rate for all components",
            cli_flag="--grom-learning-rate",
        ),
        SteeringMethodParameter(
            name="behavior_weight",
            type=float,
            help="Weight for behavior effectiveness loss",
            cli_flag="--grom-behavior-weight",
        ),
        SteeringMethodParameter(
            name="retain_weight",
            type=float,
            help="Weight for retain loss (minimize side effects)",
            cli_flag="--grom-retain-weight",
        ),
        SteeringMethodParameter(
            name="sparse_weight",
            type=float,
            help="Weight for sparsity loss",
            cli_flag="--grom-sparse-weight",
        ),
        SteeringMethodParameter(
            name="max_alpha",
            type=float,
            help="Maximum steering intensity",
            cli_flag="--grom-max-alpha",
        ),
        SteeringMethodParameter(
            name="normalize",
            type=bool,
            default=True, required=False,
            help="L2-normalize directions",
            action="store_true",
            cli_flag="--grom-normalize",
        ),
    ],
    optimization_config={
        "strength_search_range": STEERING_STRENGTH_RANGE_WIDE,
        "num_directions_range": (3, 10),
    },
    strength_range=STEERING_STRENGTH_RANGE_WIDE,
)


PRZELOM_DEFINITION = SteeringMethodDefinition(
    name="przelom",
    method_type=SteeringMethodType.PRZELOM,
    description="Attention-Transport steering - computes desired transport plan via EOT and inverts through Q-projection pseudoinverse.",
    method_class_path="wisent.core.control.steering_methods.methods.przelom.PrzelomMethod",
    parameters=[
        SteeringMethodParameter(
            name="epsilon",
            type=float,
            help="Entropic regularization (softmax temperature) for transport plan",
            cli_flag="--przelom-epsilon",
        ),
        SteeringMethodParameter(
            name="target_mode",
            type=str,
            required=True,
            help="Target transport plan: uniform or nearest (must be specified explicitly)",
            cli_flag="--przelom-target-mode",
            choices=["uniform", "nearest"],
        ),
        SteeringMethodParameter(
            name="regularization",
            type=float,
            help="Tikhonov regularization for pseudoinverse",
            cli_flag="--przelom-regularization",
        ),
        SteeringMethodParameter(
            name="inference_k",
            type=int,
            help="Nearest source points for inference interpolation",
            cli_flag="--przelom-inference-k",
        ),
    ],
    optimization_config={
        "strength_search_range": STEERING_STRENGTH_RANGE_NARROW,
    },
    strength_range=STEERING_STRENGTH_RANGE_NARROW,
)
