"""GROM config, networks, and geometry adaptation."""
from __future__ import annotations
from typing import List, Dict, Optional
from dataclasses import dataclass, field
import torch
import torch.nn as nn
import torch.nn.functional as F
from wisent.core.primitives.model_interface.core.activations.core.atoms import LayerName
from wisent.core.utils.config_tools.constants import (
    GROM_GATE_DIM_MIN, GROM_GATE_DIM_MAX, GROM_GATE_DIM_DIVISOR,
    GROM_INTENSITY_DIM_MIN, GROM_INTENSITY_DIM_MAX, GROM_INTENSITY_DIM_DIVISOR,
    GATING_HIDDEN_DIM_DIVISOR,
)

@dataclass
class GROMConfig:
    """Configuration for GROM steering method."""

    # Required numerical hyperparameters (no defaults — must come from optimizer)
    num_directions: int
    """Number of directions per layer in the steering manifold."""

    optimization_steps: int
    """Total optimization steps."""

    learning_rate: float
    """Learning rate for all components."""

    warmup_steps: int
    """Steps to warmup (train manifold only before adding networks)."""

    behavior_weight: float
    """Weight for behavior effectiveness loss."""

    retain_weight: float
    """Weight for retain loss (minimize side effects)."""

    sparse_weight: float
    """Weight for sparsity loss (encourage sparse layer activation)."""

    smooth_weight: float
    """Weight for smoothness loss (penalize abrupt intensity changes)."""

    independence_weight: float
    """Weight for direction independence loss."""

    max_alpha: float
    """Maximum steering intensity."""

    gate_temperature: float
    """Temperature for gate sigmoid."""

    min_cosine_similarity: float
    """Minimum cosine similarity between directions."""

    max_cosine_similarity: float
    """Maximum cosine similarity (avoid redundancy)."""

    weight_decay: float
    """Weight decay for AdamW optimizer."""

    max_grad_norm: float
    """Maximum gradient norm for clipping."""

    eta_min_factor: float
    """Factor to compute minimum LR for cosine annealing (eta_min = lr * factor)."""

    linear_threshold: float
    """If linear score > threshold, simplify to single direction."""

    # Auto-computed / optional fields (with defaults)
    steering_layers: Optional[List[int]] = None
    """Layer indices where steering can be applied. If None, auto-computed from num_layers."""

    sensor_layer: Optional[int] = None
    """Primary layer for gating decisions. If None, auto-computed from num_layers."""

    num_layers: Optional[int] = None
    """Total layers in the model. Used to auto-compute steering_layers and sensor_layer."""

    def resolve_layers(self, num_layers: int) -> None:
        """Resolve steering_layers and sensor_layer based on model's num_layers."""
        self.num_layers = num_layers
        if self.sensor_layer is None:
            raise ValueError(
                "sensor_layer must be specified explicitly. "
                "Pass an integer layer index."
            )
        if self.steering_layers is None:
            raise ValueError(
                "steering_layers must be specified explicitly. "
                "Pass a list of integer layer indices."
            )

    # Network architecture (auto-computed from model hidden_dim)
    gate_hidden_dim: Optional[int] = None
    """Hidden dimension for gating network. If None, auto-computed."""

    intensity_hidden_dim: Optional[int] = None
    """Hidden dimension for intensity network. If None, auto-computed."""

    routing_hidden_dim: Optional[int] = None
    """Hidden dimension for direction routing network. If None, auto-computed."""

    input_dependent_routing: bool = True
    """If True, use a network to predict direction weights per-input. If False, use fixed weights."""

    def resolve_network_dims(self, hidden_dim: int) -> None:
        """Resolve network dimensions based on model's hidden dimension."""
        if self.gate_hidden_dim is None:
            self.gate_hidden_dim = max(GROM_GATE_DIM_MIN, min(GROM_GATE_DIM_MAX, hidden_dim // GROM_GATE_DIM_DIVISOR))
        if self.intensity_hidden_dim is None:
            self.intensity_hidden_dim = max(GROM_INTENSITY_DIM_MIN, min(GROM_INTENSITY_DIM_MAX, hidden_dim // GROM_INTENSITY_DIM_DIVISOR))

    # Boolean flags (sensible defaults)
    use_caa_init: bool = True
    """Initialize primary direction with CAA."""

    normalize: bool = True
    """L2-normalize directions."""

    adapt_to_geometry: bool = True
    """Whether to analyze geometry and adapt configuration."""

    geometry_analysis_layer: Optional[int] = None
    """Layer to use for geometry analysis. If None, uses sensor_layer."""

    max_clusters: int = None
    """Maximum clusters for geometry analysis. Must be set by caller."""

    manifold_neighbors: int = None
    """Number of manifold neighbors for geometry analysis. Must be set by caller."""

    skip_gating_if_linear: bool = True
    """Skip gating network if structure is clearly linear."""

    auto_num_directions: bool = True
    """Automatically determine num_directions based on geometry."""


class GatingNetwork(nn.Module):
    """
    Learned gating network that predicts whether steering should activate.
    
    Takes hidden states from sensor layer, outputs gate value in [0, 1].
    """
    
    def __init__(self, input_dim: int, hidden_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim // GATING_HIDDEN_DIM_DIVISOR),
            nn.GELU(),
            nn.Linear(hidden_dim // GATING_HIDDEN_DIM_DIVISOR, 1),
        )
    
    def forward(self, h: torch.Tensor, temperature: float) -> torch.Tensor:
        """
        Predict gate value.
        
        Args:
            h: Hidden state [batch, hidden_dim] or [hidden_dim]
            temperature: Sigmoid temperature
            
        Returns:
            Gate value in [0, 1]
        """
        if h.dim() == 1:
            h = h.unsqueeze(0)
        logit = self.net(h).squeeze(-1)
        return torch.sigmoid(logit / temperature)


class IntensityNetwork(nn.Module):
    """
    Learned intensity network that predicts per-layer steering strength.
    
    Takes hidden states, outputs intensity values for each steering layer.
    """
    
    def __init__(self, input_dim: int, num_layers: int, hidden_dim: int, max_alpha: float):
        super().__init__()
        self.max_alpha = max_alpha
        self.num_layers = num_layers
        
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, num_layers),
        )
    
    def forward(self, h: torch.Tensor) -> torch.Tensor:
        """
        Predict per-layer intensity.
        
        Args:
            h: Hidden state [batch, hidden_dim] or [hidden_dim]
            
        Returns:
            Intensity values [batch, num_layers] in [0, max_alpha]
        """
        if h.dim() == 1:
            h = h.unsqueeze(0)
        raw = self.net(h)
        return torch.sigmoid(raw) * self.max_alpha


class DirectionWeightNetwork(nn.Module):
    """
    Learned network that predicts weights for combining directions in manifold.
    """
    
    def __init__(self, input_dim: int, num_directions: int, hidden_dim: int):
        super().__init__()
        self.num_directions = num_directions
        
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, num_directions),
        )
    
    def forward(self, h: torch.Tensor) -> torch.Tensor:
        """
        Predict direction weights.
        
        Args:
            h: Hidden state [batch, hidden_dim] or [hidden_dim]
            
        Returns:
            Softmax weights [batch, num_directions]
        """
        if h.dim() == 1:
            h = h.unsqueeze(0)
        logits = self.net(h)
        return F.softmax(logits, dim=-1)


@dataclass
class GeometryAdaptation:
    """Results from geometry analysis and adaptations made."""
    
    detected_structure: str
    """Primary detected structure type (linear, cone, manifold, etc.)."""
    
    structure_scores: Dict[str, float]
    """Scores for all structure types."""
    
    adaptations_made: List[str]
    """List of adaptations applied based on geometry."""
    
    original_num_directions: int
    """Originally configured num_directions."""
    
    adapted_num_directions: int
    """Num directions after adaptation."""
    
    gating_enabled: bool
    """Whether gating network is enabled."""
    
    recommendation: str
    """Steering method recommendation based on geometry."""
