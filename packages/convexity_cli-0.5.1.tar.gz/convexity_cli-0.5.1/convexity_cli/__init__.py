"""Convexity CLI - Command-line interface for managing Convexity projects."""

from importlib.metadata import version as _v

__version__ = _v("convexity-cli")
