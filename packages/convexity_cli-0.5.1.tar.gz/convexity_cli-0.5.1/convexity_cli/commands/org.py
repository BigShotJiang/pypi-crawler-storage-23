"""Organization management commands for Convexity CLI.

Commands:
    list   - List all organizations the user has access to
    create - Create a new organization
    delete - Delete an organization
    show   - Show details of an organization
"""

from typing import Annotated

from convexity_api_client.api.v1 import (
    create_organization_v1_organizations_post,
    delete_organization_v1_organizations_organization_id_delete,
    get_organization_v1_organizations_organization_id_get,
    list_organizations_v1_organizations_get,
)
from convexity_api_client.models import CreateOrganizationRequest
import typer

from convexity_cli.commands.utils import get_authenticated_client
from convexity_cli.exceptions import APIError
from convexity_cli.output import output_json, output_list, output_success

app = typer.Typer(
    name="org",
    help="Manage organizations.",
    no_args_is_help=True,
    rich_markup_mode=None,
)


@app.command("list")
def list_organizations() -> None:
    """List all organizations the user has access to."""
    with get_authenticated_client() as client:
        response = list_organizations_v1_organizations_get.sync_detailed(client=client)

        if response.status_code == 200 and response.parsed:
            orgs = [org.to_dict() for org in response.parsed.organizations]
            output_list(orgs)
        else:
            raise APIError(f"Failed to list organizations: {response.status_code}")


@app.command("create")
def create_organization(
    name: Annotated[str, typer.Argument(help="Organization name")],
    slug: Annotated[
        str,
        typer.Option("--slug", "-s", help="Organization slug (URL-friendly identifier)"),
    ],
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Organization description"),
    ] = None,
) -> None:
    """Create a new organization."""
    with get_authenticated_client() as client:
        request = CreateOrganizationRequest(
            name=name,
            slug=slug,
            description=description,
        )

        response = create_organization_v1_organizations_post.sync_detailed(
            client=client,
            body=request,
        )

        if response.status_code == 201 and response.parsed:
            output_json(response.parsed.to_dict())
        else:
            raise APIError(f"Failed to create organization: {response.status_code}")


@app.command("delete")
def delete_organization(
    org_id: Annotated[str, typer.Argument(help="Organization ID to delete")],
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Delete an organization."""
    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete organization '{org_id}'? This cannot be undone.")
        if not confirm:
            raise typer.Abort()

    with get_authenticated_client() as client:
        response = delete_organization_v1_organizations_organization_id_delete.sync_detailed(
            organization_id=org_id,
            client=client,
        )

        if response.status_code in (200, 204):
            output_success(f"Organization '{org_id}' deleted successfully")
        else:
            raise APIError(f"Failed to delete organization: {response.status_code}")


@app.command("show")
def show_organization(
    org_id: Annotated[str, typer.Argument(help="Organization ID")],
) -> None:
    """Show details of an organization."""
    with get_authenticated_client() as client:
        response = get_organization_v1_organizations_organization_id_get.sync_detailed(
            organization_id=org_id,
            client=client,
        )

        if response.status_code == 200 and response.parsed:
            output_json(response.parsed.to_dict())
        else:
            raise APIError(f"Failed to get organization: {response.status_code}")
