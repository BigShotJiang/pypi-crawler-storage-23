from fastmcp import FastMCP

from mcp_tools.dp_base import *
from mcp_tools.dp_html import *
from mcp_tools.dp_cv import *
from tools.browser_manager import browser_manager
from tools.browser_proxy import client_manager

mcp = FastMCP("Jarvis Brain Mcp Tools")

# 根据环境变量加载模块
enabled_modules = os.getenv("MCP_MODULES", "Dp-Base,Dp-Html").split(",")
base_cwd = os.getenv("BASE_CWD", os.path.expanduser('~'))
browser_manager.set_cache_path(base_cwd)

if "Dp-Base" in enabled_modules:
    # 页面管理
    register_close_tab(mcp, browser_manager)
    register_switch_tab(mcp, browser_manager)
    register_get_new_tab(mcp, browser_manager, client_manager)
    register_quit_browser(mcp, browser_manager)
    # 基础功能
    register_visit_url(mcp, browser_manager, client_manager)
    register_get_html(mcp, browser_manager)
    register_get_iframe_html(mcp, browser_manager)
    register_check_selector(mcp, browser_manager)
    register_iframe_check_selector(mcp, browser_manager)
    register_pop_first_packet(mcp, browser_manager, client_manager)
    register_get_ele_info(mcp, browser_manager)
    register_get_current_url(mcp, browser_manager)
    register_get_tab_ids(mcp, browser_manager)
    # 页面交互
    register_scroll_action(mcp, browser_manager)
    register_get_tab_screenshot(mcp, browser_manager)

if "Dp-Html" in enabled_modules:
    # 使用html分析出来的Selector进行交互
    # 页面交互
    register_click_action(mcp, browser_manager)
    register_hover_action(mcp, browser_manager)
    register_select_action(mcp, browser_manager)
    register_input_action(mcp, browser_manager)

if "Dp-Cv" in enabled_modules:
    # 使用Vl模型分析出来的坐标进行交互
    # 页面交互
    register_get_ele_info_cv(mcp, browser_manager)
    register_click_action_by_xy(mcp, browser_manager)


def main():
    mcp.run(transport="stdio", show_banner=False)


if __name__ == '__main__':
    main()
