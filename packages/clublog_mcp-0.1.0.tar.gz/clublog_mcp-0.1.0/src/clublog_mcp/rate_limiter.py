"""Rate limiter for Club Log API — shared across all endpoints."""

from __future__ import annotations

import threading
import time


class RateLimiter:
    """Thread-safe rate limiter for Club Log API calls.

    Club Log has no published numerical limits, but enforcement is real.
    Conservative defaults to avoid IP bans:
    - 500ms minimum delay between requests
    - Token bucket: 30 requests per minute
    - Freeze 3600s on 403 (IP firewall)
    """

    def __init__(
        self,
        min_delay: float = 0.5,
        tokens_per_min: int = 30,
    ) -> None:
        self._min_delay = min_delay
        self._max_tokens = tokens_per_min
        self._tokens = float(tokens_per_min)
        self._last_call = 0.0
        self._last_refill = time.monotonic()
        self._frozen_until = 0.0
        self._lock = threading.Lock()

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self._max_tokens, self._tokens + elapsed * (self._max_tokens / 60.0))
        self._last_refill = now

    def wait(self) -> None:
        """Block until a request is allowed."""
        with self._lock:
            now = time.monotonic()

            if now < self._frozen_until:
                wait = self._frozen_until - now
                self._lock.release()
                time.sleep(wait)
                self._lock.acquire()
                now = time.monotonic()

            self._refill()

            if self._tokens < 1.0:
                deficit = 1.0 - self._tokens
                wait = deficit * (60.0 / self._max_tokens)
                self._lock.release()
                time.sleep(wait)
                self._lock.acquire()
                self._refill()

            since_last = now - self._last_call
            if since_last < self._min_delay:
                self._lock.release()
                time.sleep(self._min_delay - since_last)
                self._lock.acquire()

            self._tokens -= 1.0
            self._last_call = time.monotonic()

    def freeze_ban(self) -> None:
        """Freeze for 1 hour on 403 (IP ban)."""
        with self._lock:
            self._frozen_until = time.monotonic() + 3600.0
