"""clublog-mcp: MCP server for Club Log DX analytics."""

from __future__ import annotations

try:
    from importlib.metadata import version

    __version__ = version("clublog-mcp")
except Exception:
    __version__ = "0.0.0-dev"
