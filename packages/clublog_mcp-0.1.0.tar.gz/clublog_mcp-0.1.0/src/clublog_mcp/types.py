"""Typed records for Club Log API responses."""

from __future__ import annotations

from typing import TypedDict


class DxccRecord(TypedDict, total=False):
    """DXCC entity from Club Log (date-aware resolution)."""

    callsign: str
    dxcc: int
    name: str
    continent: str
    cqzone: int
    lat: float
    lon: float


class LogSearchResult(TypedDict, total=False):
    """Log search result ("am I in the log?")."""

    callsign: str
    log: str
    found: bool
    qsos: dict[str, dict[str, int]]  # band -> {mode_code: count}


class ActivityData(TypedDict, total=False):
    """Hour-by-hour propagation activity between two DXCC entities."""

    source: int
    dest: int
    bands: dict[str, dict[str, float]]  # band -> {hour: proportion}


class MostWantedEntry(TypedDict, total=False):
    """Single entry in the Most Wanted DXCC list."""

    rank: int
    dxcc: int
    name: str
    prefix: str


class ExpeditionEntry(TypedDict, total=False):
    """Active/recent expedition from Club Log."""

    callsign: str
    dxcc: int
    name: str
    total_qsos: int
    last_qso: str
    activations: int


class WatchResult(TypedDict, total=False):
    """Real-time activity monitor for a callsign."""

    callsign: str
    total_qsos: int
    last_24h: dict[str, dict[str, int]]  # band -> {mode_code: count}
    grid: str
    oqrs: bool
    expedition: bool
