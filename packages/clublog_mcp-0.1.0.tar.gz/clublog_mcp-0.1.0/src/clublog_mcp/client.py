"""Club Log API client — wraps all 6 endpoints."""

from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from typing import Any
from urllib.error import HTTPError

from . import __version__
from .cache import TTLCache
from .rate_limiter import RateLimiter
from .types import (
    ActivityData,
    DxccRecord,
    ExpeditionEntry,
    LogSearchResult,
    MostWantedEntry,
    WatchResult,
)

_BASE = "https://clublog.org"

# Cache TTLs
_DXCC_TTL = 3600.0  # 1 hour
_MOST_WANTED_TTL = 86400.0  # 24 hours
_EXPEDITIONS_TTL = 3600.0  # 1 hour
_ACTIVITY_TTL = 3600.0  # 1 hour
_WATCH_TTL = 300.0  # 5 minutes

# Band ID normalization: Club Log uses bare numbers, we return ADIF names
_BAND_MAP: dict[str, str] = {
    "160": "160m", "80": "80m", "60": "60m", "40": "40m",
    "30": "30m", "20": "20m", "17": "17m", "15": "15m",
    "12": "12m", "10": "10m", "6": "6m", "2": "2m", "70": "70cm",
}

# Mode code legend
_MODE_MAP: dict[str, str] = {"C": "CW", "P": "Phone", "D": "Data"}

# Mock data
_MOCK_DXCC = {"DXCC": 241, "Name": "SOUTH SHETLAND ISLANDS", "Continent": "SA", "CQZone": 13, "Lat": -62.0, "Long": -58.0}

_MOCK_SEARCH = {"20": {"C": 1, "P": 1}, "40": {"C": 2}}

_MOCK_ACTIVITY = {
    "20": {"0": 0.05, "1": 0.03, "12": 0.08, "14": 0.15, "15": 0.12, "count": 4521},
    "40": {"0": 0.12, "1": 0.15, "12": 0.04, "count": 2103},
}

_MOCK_MOST_WANTED = [
    {"DXCC": 7, "Name": "BOUVET ISLAND", "Prefix": "3Y/B"},
    {"DXCC": 10, "Name": "HEARD ISLAND", "Prefix": "VK0H"},
    {"DXCC": 90, "Name": "CROZET ISLAND", "Prefix": "FT5W"},
]

_MOCK_EXPEDITIONS = [
    {"Callsign": "3Y0J", "DXCC": 24, "Name": "BOUVET ISLAND", "Total": 82000, "LastQSO": "2026-02-15"},
    {"Callsign": "FT8WW", "DXCC": 90, "Name": "CROZET ISLAND", "Total": 45000, "LastQSO": "2026-01-20"},
]

_MOCK_WATCH = {
    "Callsign": "3Y0J",
    "Total": 82000,
    "Grid": "JD05",
    "OQRS": True,
    "Expedition": True,
    "24h": {"20": {"C": 150, "D": 200}, "40": {"C": 100}},
}


def _is_mock() -> bool:
    return os.getenv("CLUBLOG_MCP_MOCK") == "1"


class ClubLogClient:
    """Club Log API client with rate limiting and caching."""

    def __init__(self, rate_limiter: RateLimiter) -> None:
        self._api_key: str | None = None
        self._agent = f"clublog-mcp/{__version__}"
        self._rate_limiter = rate_limiter
        self._cache = TTLCache()

    def configure(self, api_key: str) -> None:
        self._api_key = api_key

    def _get(self, path: str, params: dict[str, str] | None = None) -> Any:
        """HTTP GET, return parsed JSON."""
        self._rate_limiter.wait()

        url = f"{_BASE}{path}"
        if params:
            qs = urllib.parse.urlencode(params)
            url = f"{url}?{qs}"

        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", self._agent)

        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = resp.read().decode("utf-8", errors="replace")
        except HTTPError as e:
            if e.code == 403:
                self._rate_limiter.freeze_ban()
                raise RuntimeError(
                    "Club Log returned 403 — API key revoked or IP banned. "
                    "All requests frozen for 1 hour. Contact support@clublog.org"
                ) from e
            if e.code == 404:
                return None
            raise
        except ConnectionRefusedError:
            self._rate_limiter.freeze_ban()
            raise

        if not body.strip():
            return None

        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return body

    def _require_api_key(self) -> str:
        if not self._api_key:
            raise ValueError(
                "Club Log API key not configured. "
                "Set CLUBLOG_API_KEY env var or pass --api-key"
            )
        return self._api_key

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    def dxcc(self, callsign: str, date: str | None = None) -> DxccRecord:
        """Resolve callsign to DXCC entity (date-aware)."""
        key = f"dxcc:{callsign.upper()}:{date or ''}"
        cached = self._cache.get(key)
        if cached is not None:
            return cached

        if _is_mock():
            data = _MOCK_DXCC
        else:
            api_key = self._require_api_key()
            params: dict[str, str] = {
                "call": callsign.upper(),
                "api": api_key,
                "full": "1",
            }
            if date:
                params["date"] = date
            data = self._get("/dxcc", params)
            if data is None:
                return DxccRecord(callsign=callsign.upper(), name="Not found")

        rec = DxccRecord(
            callsign=callsign.upper(),
            dxcc=int(data.get("DXCC", 0)),
            name=str(data.get("Name", "")),
            continent=str(data.get("Continent", "")),
            cqzone=int(data.get("CQZone", 0)),
        )
        lat = data.get("Lat")
        lon = data.get("Long") or data.get("Lon")
        if lat is not None:
            rec["lat"] = float(lat)
        if lon is not None:
            rec["lon"] = float(lon)

        self._cache.set(key, rec, _DXCC_TTL)
        return rec

    def search(self, callsign: str, log: str, year: int | None = None) -> LogSearchResult:
        """Search expedition/public logs ("am I in the log?")."""
        if _is_mock():
            raw = _MOCK_SEARCH
        else:
            api_key = self._require_api_key()
            params: dict[str, str] = {
                "call": callsign.upper(),
                "log": log.upper(),
                "api": api_key,
            }
            if year:
                params["year"] = str(year)
            raw = self._get("/logsearchjson.php", params)

        if not raw or not isinstance(raw, dict):
            return LogSearchResult(
                callsign=callsign.upper(),
                log=log.upper(),
                found=False,
                qsos={},
            )

        # Normalize band keys and expand mode codes
        qsos: dict[str, dict[str, int]] = {}
        for band_id, modes in raw.items():
            band_name = _BAND_MAP.get(str(band_id), f"{band_id}m")
            expanded: dict[str, int] = {}
            if isinstance(modes, dict):
                for code, count in modes.items():
                    mode_name = _MODE_MAP.get(code, code)
                    expanded[mode_name] = int(count)
            qsos[band_name] = expanded

        return LogSearchResult(
            callsign=callsign.upper(),
            log=log.upper(),
            found=bool(qsos),
            qsos=qsos,
        )

    def activity(
        self,
        source: int,
        dest: int,
        month: int | None = None,
        last_year_only: bool = False,
        sfi_min: int | None = None,
        sfi_max: int | None = None,
    ) -> ActivityData:
        """Hour-by-hour propagation activity between two DXCC entities."""
        key = f"act:{source}:{dest}:{month}:{last_year_only}:{sfi_min}:{sfi_max}"
        cached = self._cache.get(key)
        if cached is not None:
            return cached

        if _is_mock():
            raw = _MOCK_ACTIVITY
        else:
            api_key = self._require_api_key()
            params: dict[str, str] = {
                "api": api_key,
                "source": str(source),
                "dest": str(dest),
            }
            if month is not None:
                params["month"] = str(month)
            if last_year_only:
                params["lastyearonly"] = "1"
            if sfi_min is not None:
                params["sfimin"] = str(sfi_min)
            if sfi_max is not None:
                params["sfimax"] = str(sfi_max)
            raw = self._get("/activity_json.php", params)

        if not raw or not isinstance(raw, dict):
            return ActivityData(source=source, dest=dest, bands={})

        # Normalize bands
        bands: dict[str, dict[str, float]] = {}
        for band_id, hours in raw.items():
            band_name = _BAND_MAP.get(str(band_id), f"{band_id}m")
            if isinstance(hours, dict):
                bands[band_name] = {k: float(v) for k, v in hours.items()}

        result = ActivityData(source=source, dest=dest, bands=bands)
        self._cache.set(key, result, _ACTIVITY_TTL)
        return result

    def most_wanted(self) -> list[MostWantedEntry]:
        """Current Most Wanted DXCC entity list (public, no API key)."""
        cached = self._cache.get("most_wanted")
        if cached is not None:
            return cached

        if _is_mock():
            raw = _MOCK_MOST_WANTED
        else:
            raw = self._get("/mostwanted.php", {"api": "1"})

        if not raw or not isinstance(raw, list):
            return []

        entries: list[MostWantedEntry] = []
        for i, item in enumerate(raw):
            entries.append(MostWantedEntry(
                rank=i + 1,
                dxcc=int(item.get("DXCC", 0)),
                name=str(item.get("Name", "")),
                prefix=str(item.get("Prefix", "")),
            ))

        self._cache.set("most_wanted", entries, _MOST_WANTED_TTL)
        return entries

    def expeditions(self) -> list[ExpeditionEntry]:
        """List active/recent expeditions (public, no API key)."""
        cached = self._cache.get("expeditions")
        if cached is not None:
            return cached

        if _is_mock():
            raw = _MOCK_EXPEDITIONS
        else:
            raw = self._get("/expeditions.php", {"api": "1"})

        if not raw or not isinstance(raw, list):
            return []

        entries: list[ExpeditionEntry] = []
        for item in raw:
            entries.append(ExpeditionEntry(
                callsign=str(item.get("Callsign", "")),
                dxcc=int(item.get("DXCC", 0)),
                name=str(item.get("Name", "")),
                total_qsos=int(item.get("Total", 0)),
                last_qso=str(item.get("LastQSO", "")),
            ))

        self._cache.set("expeditions", entries, _EXPEDITIONS_TTL)
        return entries

    def watch(self, callsign: str) -> WatchResult:
        """Real-time activity monitor for a callsign."""
        key = f"watch:{callsign.upper()}"
        cached = self._cache.get(key)
        if cached is not None:
            return cached

        if _is_mock():
            data = _MOCK_WATCH
        else:
            api_key = self._require_api_key()
            data = self._get("/watch.php", {"call": callsign.upper(), "api": api_key})

        if not data or not isinstance(data, dict):
            return WatchResult(callsign=callsign.upper())

        # Normalize 24h band activity
        last_24h: dict[str, dict[str, int]] = {}
        raw_24h = data.get("24h", {})
        if isinstance(raw_24h, dict):
            for band_id, modes in raw_24h.items():
                band_name = _BAND_MAP.get(str(band_id), f"{band_id}m")
                expanded: dict[str, int] = {}
                if isinstance(modes, dict):
                    for code, count in modes.items():
                        mode_name = _MODE_MAP.get(code, code)
                        expanded[mode_name] = int(count)
                last_24h[band_name] = expanded

        result = WatchResult(
            callsign=str(data.get("Callsign", callsign.upper())),
            total_qsos=int(data.get("Total", 0)),
            grid=str(data.get("Grid", "")),
            oqrs=bool(data.get("OQRS", False)),
            expedition=bool(data.get("Expedition", False)),
            last_24h=last_24h,
        )

        self._cache.set(key, result, _WATCH_TTL)
        return result
