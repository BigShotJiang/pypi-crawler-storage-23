"""clublog-mcp: MCP server for Club Log DX analytics."""

from __future__ import annotations

import os
import sys
from typing import Any

from fastmcp import FastMCP

from . import __version__
from .client import ClubLogClient
from .rate_limiter import RateLimiter

mcp = FastMCP(
    "clublog-mcp",
    version=__version__,
    instructions=(
        "MCP server for Club Log — DXCC resolution, expedition log search, "
        "propagation activity, Most Wanted, real-time callsign monitoring"
    ),
)

_rate_limiter = RateLimiter()
_client: ClubLogClient | None = None


def _is_mock() -> bool:
    return os.getenv("CLUBLOG_MCP_MOCK") == "1"


def _get_client() -> ClubLogClient:
    """Lazy-init the shared client."""
    global _client
    if _client is None:
        _client = ClubLogClient(_rate_limiter)
        if not _is_mock():
            api_key = os.getenv("CLUBLOG_API_KEY")
            if not api_key:
                raise ValueError(
                    "CLUBLOG_API_KEY env var not set. "
                    "Get your key at https://clublog.org/requestapikey.php"
                )
            _client.configure(api_key)
    return _client


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def clublog_dxcc(callsign: str, date: str | None = None) -> dict[str, Any]:
    """Resolve a callsign to its DXCC entity (date-aware for historical prefix changes).

    Args:
        callsign: Callsign to resolve (e.g., VP8PJ, 3Y0J).
        date: Optional date for resolution (YYYY-MM-DD). Handles prefix changes over time.

    Returns:
        DXCC entity details (code, name, continent, CQ zone, coordinates).
    """
    try:
        return dict(_get_client().dxcc(callsign, date))
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def clublog_search(callsign: str, log: str, year: int | None = None) -> dict[str, Any]:
    """Search an expedition or public log for a callsign ("am I in the log?").

    Args:
        callsign: Your callsign to search for.
        log: DX station or expedition log to search (e.g., 3Y0J).
        year: Optional year filter.

    Returns:
        Whether found, and band x mode breakdown of QSOs.
    """
    try:
        return dict(_get_client().search(callsign, log, year))
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def clublog_activity(
    source: int,
    dest: int,
    month: int | None = None,
    last_year_only: bool = False,
    sfi_min: int | None = None,
    sfi_max: int | None = None,
) -> dict[str, Any]:
    """Hour-by-hour propagation activity between two DXCC entities.

    Shows when paths are open based on historical QSO patterns from Club Log.
    Source and destination are reciprocal — no need to query both directions.

    Args:
        source: Source DXCC entity code (e.g., 291 for USA).
        dest: Destination DXCC entity code (e.g., 339 for Japan).
        month: Optional month filter (1-12).
        last_year_only: Limit to last 12 months of data.
        sfi_min: Optional minimum SFI filter.
        sfi_max: Optional maximum SFI filter.

    Returns:
        Hourly activity proportions per band (normalized to sum 1.0).
    """
    try:
        return dict(_get_client().activity(
            source, dest, month, last_year_only, sfi_min, sfi_max
        ))
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def clublog_most_wanted() -> dict[str, Any]:
    """Get the current Most Wanted DXCC entity list from Club Log.

    Public endpoint — no API key required.

    Returns:
        Ranked list of most-wanted DXCC entities.
    """
    try:
        entries = _get_client().most_wanted()
        return {"total": len(entries), "entities": [dict(e) for e in entries]}
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def clublog_expeditions() -> dict[str, Any]:
    """List active and recent DXpeditions from Club Log.

    Public endpoint — no API key required.

    Returns:
        List of expedition callsigns with QSO counts and last activity.
    """
    try:
        entries = _get_client().expeditions()
        return {"total": len(entries), "expeditions": [dict(e) for e in entries]}
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def clublog_watch(callsign: str) -> dict[str, Any]:
    """Monitor real-time activity for a callsign on Club Log.

    Shows 24-hour QSOs by band/mode, grid locator, OQRS status, and expedition flag.

    Args:
        callsign: Callsign to monitor (e.g., 3Y0J).

    Returns:
        Activity summary including 24h band/mode breakdown.
    """
    try:
        return dict(_get_client().watch(callsign))
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the clublog-mcp server."""
    transport = "stdio"
    port = 8003
    for i, arg in enumerate(sys.argv[1:], 1):
        if arg == "--transport" and i < len(sys.argv) - 1:
            transport = sys.argv[i + 1]
        if arg == "--port" and i < len(sys.argv) - 1:
            port = int(sys.argv[i + 1])

    if transport == "streamable-http":
        mcp.run(transport=transport, port=port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
