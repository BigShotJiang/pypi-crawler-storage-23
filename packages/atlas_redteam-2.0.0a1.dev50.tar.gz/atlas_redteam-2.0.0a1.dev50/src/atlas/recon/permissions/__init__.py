"""atlas.recon.permissions — Permission discovery and attack surface analysis."""

from atlas.recon.permissions.resolver import PermissionResolverCollector
