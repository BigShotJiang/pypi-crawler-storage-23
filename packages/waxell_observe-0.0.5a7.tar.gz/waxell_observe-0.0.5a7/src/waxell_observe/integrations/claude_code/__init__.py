"""Claude Code & Cowork observability integration.

Instruments Claude Code sessions as observable agent runs in Waxell.
Uses Claude Code's hooks system and JSONL transcripts.
"""

from .guard import GuardConfig, GuardResult, check_tool_use, load_config
from .hook_handler import handle_hook
from .setup import setup_hooks
from .transcript import parse_transcript

__all__ = [
    "GuardConfig",
    "GuardResult",
    "check_tool_use",
    "handle_hook",
    "load_config",
    "parse_transcript",
    "setup_hooks",
]
