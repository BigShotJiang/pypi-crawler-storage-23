"""Session state management for Claude Code hooks.

Each hook invocation is a separate process — shared state is stored
in temp files under /tmp/waxell-cc/{session_id}.json.

Writes are atomic (write to .tmp then rename) to avoid corruption
from concurrent async hooks.
"""

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

STATE_DIR = Path(os.environ.get("WAXELL_CC_STATE_DIR", "/tmp/waxell-cc"))
STATE_TTL_SECONDS = 24 * 60 * 60  # 24 hours


@dataclass
class SessionState:
    """State for an active Claude Code session."""

    session_id: str = ""
    run_id: str = ""
    workflow_id: str = ""
    cowork_session_id: str = ""
    started_at: str = ""
    cwd: str = ""
    model: str = ""
    span_count: int = 0
    is_cowork: bool = False
    pending_subagent_spans: dict = field(default_factory=dict)
    modified_files: list = field(default_factory=list)


def _state_path(session_id: str) -> Path:
    return STATE_DIR / f"{session_id}.json"


def save_state(state: SessionState) -> None:
    """Atomically save session state to disk."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    path = _state_path(state.session_id)
    tmp_path = path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(asdict(state)))
    tmp_path.rename(path)


def load_state(session_id: str) -> Optional[SessionState]:
    """Load session state from disk. Returns None if not found."""
    path = _state_path(session_id)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        return SessionState(**{
            k: v for k, v in data.items()
            if k in SessionState.__dataclass_fields__
        })
    except (json.JSONDecodeError, TypeError):
        return None


def delete_state(session_id: str) -> None:
    """Remove session state file."""
    path = _state_path(session_id)
    path.unlink(missing_ok=True)


def find_cowork_peer(cwd: str, exclude_session_id: str) -> Optional[SessionState]:
    """Find an active session in the same working directory (Cowork detection).

    If another session exists with the same cwd, this is likely a Cowork session.
    Returns the peer's state, or None.
    """
    if not STATE_DIR.exists():
        return None
    for f in STATE_DIR.glob("*.json"):
        peer_id = f.stem
        if peer_id == exclude_session_id:
            continue
        peer = load_state(peer_id)
        if peer and peer.run_id and peer.cwd == cwd:
            return peer
    return None


def cleanup_stale_states() -> int:
    """Remove state files older than STATE_TTL_SECONDS. Returns count removed."""
    if not STATE_DIR.exists():
        return 0
    cutoff = time.time() - STATE_TTL_SECONDS
    removed = 0
    for f in STATE_DIR.glob("*.json"):
        try:
            if f.stat().st_mtime < cutoff:
                f.unlink()
                removed += 1
        except OSError:
            pass
    return removed
