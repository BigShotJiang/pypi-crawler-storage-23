"""LangChain callback handler for Waxell Observe.

Intercepts LLM calls, chain executions, and tool usage to send
telemetry to the Waxell controlplane.

Usage:
    from waxell_observe.integrations.langchain import WaxellLangChainHandler

    handler = WaxellLangChainHandler(agent_name="my-langchain-agent")

    # Use with any LangChain component:
    result = chain.invoke(input, config={"callbacks": [handler]})

    # Flush when done (sends buffered data to controlplane):
    handler.flush_sync(result={"output": result})
"""

import asyncio
import logging
from typing import Any, Optional

from ..client import WaxellObserveClient
from ..cost import estimate_cost
from ..errors import PolicyViolationError
from ..tracing._compat import _HAS_OTEL, _provider as _compat_provider
from ..tracing.spans import start_llm_span, start_tool_span, start_step_span
from ..tracing.attributes import GenAIAttributes, WaxellAttributes
from ..types import RunInfo

logger = logging.getLogger(__name__)


def WaxellLangChainHandler(
    agent_name: str,
    workflow_name: str = "default",
    client: Optional[WaxellObserveClient] = None,
    enforce_policy: bool = True,
    auto_start_run: bool = True,
    parent_span=None,
    session_id: str = "",
    user_id: str = "",
    user_group: str = "",
):
    """Create a LangChain callback handler for Waxell telemetry.

    Returns a BaseCallbackHandler subclass instance.

    Args:
        agent_name: Name for this agent in Waxell.
        workflow_name: Workflow name for grouping runs.
        client: Optional pre-configured WaxellObserveClient.
        enforce_policy: Check policies before execution starts.
        auto_start_run: Automatically start a run on first callback.
        parent_span: Optional parent OTel span for nesting under an agent span.
        session_id: Optional session ID for grouping related runs.
    """
    try:
        from langchain_core.callbacks import BaseCallbackHandler
    except ImportError:
        raise ImportError(
            "langchain-core is required for WaxellLangChainHandler. "
            "Install it with: pip install waxell-observe[langchain]"
        )

    class _Handler(BaseCallbackHandler):
        name = "WaxellObserve"

        def __init__(self):
            super().__init__()
            self._client = client or WaxellObserveClient()
            self._agent_name = agent_name
            self._workflow_name = workflow_name
            self._enforce_policy = enforce_policy
            self._auto_start = auto_start_run

            self._run_info: Optional[RunInfo] = None
            self._llm_calls: list[dict] = []
            self._steps: list[dict] = []
            self._step_counter = 0
            self._current_llm_start: dict[str, dict] = {}  # keyed by run_id
            self._started = False

            # OTel span tracking (additive -- active only when OTel is configured)
            self._active_llm_spans: dict[str, Any] = {}
            self._active_chain_spans: dict[str, Any] = {}
            self._active_tool_spans: dict[str, Any] = {}
            self._agent_span = parent_span  # from factory function closure
            self._session_id = session_id
            self._user_id = user_id
            self._user_group = user_group

            # Set identity attributes on agent span if provided
            if self._agent_span is not None:
                try:
                    if session_id:
                        self._agent_span.set_attribute(WaxellAttributes.SESSION_ID, session_id)
                    if user_id:
                        self._agent_span.set_attribute(WaxellAttributes.USER_ID, user_id)
                    if user_group:
                        self._agent_span.set_attribute(WaxellAttributes.USER_GROUP, user_group)
                except Exception:
                    pass

        # ----------------------------------------------------------
        # Run management
        # ----------------------------------------------------------

        def _ensure_run_started(self):
            """Lazily start a run on first callback."""
            if self._started or not self._auto_start:
                return
            self._started = True

            try:
                loop = asyncio.get_running_loop()
                # In async context — create a task (fire and forget)
                loop.create_task(self._async_start_run())
            except RuntimeError:
                # Not in async context — run synchronously
                asyncio.run(self._async_start_run())

        async def _async_start_run(self):
            if self._enforce_policy:
                policy = await self._client.check_policy(
                    agent_name=self._agent_name,
                    workflow_name=self._workflow_name,
                )
                if policy.blocked:
                    raise PolicyViolationError(policy.reason, policy)

            self._run_info = await self._client.start_run(
                agent_name=self._agent_name,
                workflow_name=self._workflow_name,
                session_id=self._session_id,
                user_id=self._user_id,
                user_group=self._user_group,
            )

        # ----------------------------------------------------------
        # Parent span resolution
        # ----------------------------------------------------------

        def _find_parent_span(self, parent_run_id):
            """Resolve parent span from LangChain's parent_run_id."""
            if parent_run_id:
                rid = str(parent_run_id)
                # Check chain spans first (most common parent)
                if rid in self._active_chain_spans:
                    return self._active_chain_spans[rid]
                # Check tool spans
                if rid in self._active_tool_spans:
                    return self._active_tool_spans[rid]
            return self._agent_span  # Fall back to root agent span

        # ----------------------------------------------------------
        # LLM callbacks
        # ----------------------------------------------------------

        def on_llm_start(
            self,
            serialized: dict[str, Any],
            prompts: list[str],
            *,
            run_id,
            parent_run_id=None,
            **kwargs,
        ):
            self._ensure_run_started()

            # Extract model name
            model_name = ""
            if "kwargs" in serialized:
                model_name = serialized["kwargs"].get(
                    "model_name", serialized["kwargs"].get("model", "")
                )
            if not model_name:
                id_parts = serialized.get("id", [])
                model_name = id_parts[-1] if id_parts else "unknown"

            prompt_text = prompts[0][:500] if prompts else ""

            self._current_llm_start[str(run_id)] = {
                "model": model_name,
                "prompt_preview": prompt_text,
            }

            # OTel span (additive -- does not affect HTTP path)
            if _HAS_OTEL and _compat_provider is not None:
                try:
                    parent = self._find_parent_span(parent_run_id)
                    span = start_llm_span(
                        model=model_name,
                        parent_span=parent,
                    )
                    if self._session_id:
                        try:
                            span.set_attribute(WaxellAttributes.SESSION_ID, self._session_id)
                        except Exception:
                            pass
                    self._active_llm_spans[str(run_id)] = span
                except Exception:
                    pass  # Never break callback chain

        def on_llm_end(self, response, *, run_id, **kwargs):
            start_info = self._current_llm_start.pop(str(run_id), {})
            model = start_info.get("model", "unknown")

            # Extract token usage
            token_usage = {}
            if hasattr(response, "llm_output") and response.llm_output:
                token_usage = response.llm_output.get("token_usage", {})

            tokens_in = token_usage.get("prompt_tokens", 0)
            tokens_out = token_usage.get("completion_tokens", 0)
            cost = estimate_cost(model, tokens_in, tokens_out)

            # Extract response preview
            response_text = ""
            if response.generations and response.generations[0]:
                gen = response.generations[0][0]
                response_text = (gen.text or "")[:500]

            self._llm_calls.append(
                {
                    "model": model,
                    "tokens_in": tokens_in,
                    "tokens_out": tokens_out,
                    "cost": cost,
                    "prompt_preview": start_info.get("prompt_preview", ""),
                    "response_preview": response_text,
                }
            )

            # End OTel span
            span = self._active_llm_spans.pop(str(run_id), None)
            if span is not None:
                try:
                    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
                    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
                    span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
                    span.set_attribute(WaxellAttributes.LLM_MODEL, model)
                    span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
                    span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
                    span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
                    span.set_attribute(WaxellAttributes.LLM_COST, cost)
                    span.end()
                except Exception:
                    pass  # Never break callback chain

        def on_llm_error(self, error, *, run_id=None, **kwargs):
            logger.debug(f"LLM error: {error}")
            span = self._active_llm_spans.pop(str(run_id) if run_id else "", None)
            if span is not None:
                try:
                    span.record_exception(error)
                    span.end()
                except Exception:
                    pass

        # ----------------------------------------------------------
        # Chain callbacks
        # ----------------------------------------------------------

        def on_chain_start(self, serialized, inputs, *, run_id, parent_run_id=None, **kwargs):
            self._ensure_run_started()
            self._step_counter += 1
            chain_name = serialized.get("id", ["chain"])[-1] if serialized.get("id") else "chain"
            self._steps.append(
                {
                    "step_name": chain_name,
                    "output": {},
                    "position": self._step_counter,
                }
            )

            if _HAS_OTEL and _compat_provider is not None:
                try:
                    parent = self._find_parent_span(parent_run_id)
                    span = start_step_span(
                        step_name=chain_name,
                        position=self._step_counter,
                        parent_span=parent,
                    )
                    if self._session_id:
                        try:
                            span.set_attribute(WaxellAttributes.SESSION_ID, self._session_id)
                        except Exception:
                            pass
                    self._active_chain_spans[str(run_id)] = span
                except Exception:
                    pass

        def on_chain_end(self, outputs, *, run_id, **kwargs):
            if self._steps:
                self._steps[-1]["output"] = _safe_json(outputs)

            span = self._active_chain_spans.pop(str(run_id), None)
            if span is not None:
                try:
                    span.end()
                except Exception:
                    pass

        def on_chain_error(self, error, *, run_id=None, **kwargs):
            logger.debug(f"Chain error: {error}")
            span = self._active_chain_spans.pop(str(run_id) if run_id else "", None)
            if span is not None:
                try:
                    span.record_exception(error)
                    span.end()
                except Exception:
                    pass

        # ----------------------------------------------------------
        # Tool callbacks
        # ----------------------------------------------------------

        def on_tool_start(self, serialized, input_str, *, run_id=None, parent_run_id=None, **kwargs):
            self._step_counter += 1
            tool_name = serialized.get("name", "tool")
            self._steps.append(
                {
                    "step_name": f"tool:{tool_name}",
                    "output": {},
                    "position": self._step_counter,
                }
            )

            if _HAS_OTEL and _compat_provider is not None:
                try:
                    parent = self._find_parent_span(parent_run_id)
                    span = start_tool_span(
                        tool_name=tool_name,
                        parent_span=parent,
                    )
                    if self._session_id:
                        try:
                            span.set_attribute(WaxellAttributes.SESSION_ID, self._session_id)
                        except Exception:
                            pass
                    self._active_tool_spans[str(run_id)] = span
                except Exception:
                    pass

        def on_tool_end(self, output, *, run_id=None, **kwargs):
            if self._steps:
                self._steps[-1]["output"] = {"result": str(output)[:1000]}

            span = self._active_tool_spans.pop(str(run_id), None)
            if span is not None:
                try:
                    span.end()
                except Exception:
                    pass

        # ----------------------------------------------------------
        # Flush
        # ----------------------------------------------------------

        async def flush(
            self,
            result: Optional[dict] = None,
            status: str = "success",
            error: str = "",
        ) -> None:
            """Flush all buffered telemetry to the controlplane.

            Call this when the chain/agent execution is done.
            """
            if not self._run_info:
                logger.warning(
                    "Cannot flush: no run started. "
                    "Ensure auto_start_run=True or call start manually."
                )
                return

            if self._llm_calls:
                await self._client.record_llm_calls(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
                self._llm_calls = []

            if self._steps:
                await self._client.record_steps(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
                self._steps = []

            await self._client.complete_run(
                run_id=self._run_info.run_id,
                result=result or {},
                status=status,
                error=error,
            )

            # Clean up any leaked OTel spans
            for span in self._active_llm_spans.values():
                try:
                    span.end()
                except Exception:
                    pass
            self._active_llm_spans.clear()
            for span in self._active_chain_spans.values():
                try:
                    span.end()
                except Exception:
                    pass
            self._active_chain_spans.clear()
            for span in self._active_tool_spans.values():
                try:
                    span.end()
                except Exception:
                    pass
            self._active_tool_spans.clear()

        def flush_sync(self, **kwargs) -> None:
            """Synchronous version of flush."""
            try:
                asyncio.get_running_loop()
                raise RuntimeError(
                    "Cannot use flush_sync() in async context. "
                    "Use 'await handler.flush()' instead."
                )
            except RuntimeError as e:
                if "no running event loop" not in str(e).lower():
                    raise
                asyncio.run(self.flush(**kwargs))

        # ----------------------------------------------------------
        # Properties
        # ----------------------------------------------------------

        @property
        def run_id(self) -> str:
            """The run ID from the controlplane."""
            return self._run_info.run_id if self._run_info else ""

    return _Handler()


def _safe_json(obj) -> dict:
    """Convert an object to a JSON-safe dict."""
    if isinstance(obj, dict):
        return {k: _safe_value(v) for k, v in obj.items()}
    return {"value": str(obj)[:1000]}


def _safe_value(v):
    """Convert a value to something JSON-serializable."""
    if isinstance(v, (str, int, float, bool, type(None))):
        return v
    if isinstance(v, (list, tuple)):
        return [_safe_value(i) for i in v[:20]]  # Truncate long lists
    if isinstance(v, dict):
        return {str(k): _safe_value(val) for k, val in list(v.items())[:20]}
    return str(v)[:500]
