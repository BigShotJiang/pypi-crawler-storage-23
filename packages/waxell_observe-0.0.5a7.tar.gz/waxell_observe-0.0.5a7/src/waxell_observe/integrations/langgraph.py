"""LangGraph callback handler for Waxell Observe.

Extends the LangChain callback pattern with graph-specific awareness:
detects LangGraph node executions, conditional edges, and state
transitions to produce richer observability data.

Usage:
    from waxell_observe.integrations.langgraph import WaxellLangGraphHandler

    handler = WaxellLangGraphHandler(agent_name="my-graph-agent")

    # Use with LangGraph:
    result = graph.invoke(input, config={"callbacks": [handler]})

    handler.flush_sync(result={"output": result})
"""

import asyncio
import logging
from typing import Any, Optional

from ..client import WaxellObserveClient
from ..cost import estimate_cost
from ..errors import PolicyViolationError
from ..tracing._compat import _HAS_OTEL, _provider as _compat_provider
from ..tracing.spans import (
    start_llm_span, start_step_span, start_tool_span,
)
from ..tracing.attributes import GenAIAttributes, WaxellAttributes
from ..types import RunInfo

logger = logging.getLogger(__name__)

# Known LangGraph internal chain names to detect graph execution
_LANGGRAPH_MARKERS = {
    "LangGraph", "StateGraph", "CompiledGraph",
    "ChannelWrite", "ChannelRead", "PregelNode",
}


def WaxellLangGraphHandler(
    agent_name: str,
    workflow_name: str = "default",
    client: Optional[WaxellObserveClient] = None,
    enforce_policy: bool = True,
    auto_start_run: bool = True,
    parent_span=None,
    session_id: str = "",
    user_id: str = "",
    user_group: str = "",
):
    """Create a LangGraph callback handler for Waxell telemetry.

    Returns a BaseCallbackHandler subclass that understands LangGraph
    graph structure in addition to standard LangChain events.
    """
    try:
        from langchain_core.callbacks import BaseCallbackHandler
    except ImportError:
        raise ImportError(
            "langchain-core is required for WaxellLangGraphHandler. "
            "Install it with: pip install waxell-observe[langgraph]"
        )

    class _Handler(BaseCallbackHandler):
        name = "WaxellLangGraph"

        def __init__(self):
            super().__init__()
            self._client = client or WaxellObserveClient()
            self._agent_name = agent_name
            self._workflow_name = workflow_name
            self._enforce_policy = enforce_policy
            self._auto_start = auto_start_run

            self._run_info: Optional[RunInfo] = None
            self._llm_calls: list[dict] = []
            self._steps: list[dict] = []
            self._step_counter = 0
            self._current_llm_start: dict[str, dict] = {}
            self._started = False

            # OTel spans
            self._active_llm_spans: dict[str, Any] = {}
            self._active_node_spans: dict[str, Any] = {}
            self._active_tool_spans: dict[str, Any] = {}
            self._agent_span = parent_span
            self._session_id = session_id
            self._user_id = user_id
            self._user_group = user_group

            # Graph-specific tracking
            self._node_execution_order: list[str] = []
            self._graph_depth = 0

        def _ensure_run_started(self):
            if self._started or not self._auto_start:
                return
            self._started = True
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._async_start_run())
            except RuntimeError:
                asyncio.run(self._async_start_run())

        async def _async_start_run(self):
            if self._enforce_policy:
                policy = await self._client.check_policy(
                    agent_name=self._agent_name,
                    workflow_name=self._workflow_name,
                )
                if policy.blocked:
                    raise PolicyViolationError(policy.reason, policy)

            self._run_info = await self._client.start_run(
                agent_name=self._agent_name,
                workflow_name=self._workflow_name,
                session_id=self._session_id,
                user_id=self._user_id,
                user_group=self._user_group,
            )

        def _find_parent_span(self, parent_run_id):
            if parent_run_id:
                rid = str(parent_run_id)
                if rid in self._active_node_spans:
                    return self._active_node_spans[rid]
                if rid in self._active_tool_spans:
                    return self._active_tool_spans[rid]
            return self._agent_span

        def _is_graph_node(self, serialized: dict) -> bool:
            """Detect if a chain_start event is a LangGraph node."""
            chain_id = serialized.get("id", [])
            name = serialized.get("name", "")
            if any(marker in str(chain_id) for marker in _LANGGRAPH_MARKERS):
                return True
            if any(marker in name for marker in _LANGGRAPH_MARKERS):
                return True
            # LangGraph nodes often have specific metadata
            if "langgraph" in str(serialized.get("kwargs", {})).lower():
                return True
            return False

        def _get_node_name(self, serialized: dict) -> str:
            """Extract a meaningful node name."""
            name = serialized.get("name", "")
            if name and name not in _LANGGRAPH_MARKERS:
                return name
            chain_id = serialized.get("id", [])
            if chain_id:
                return chain_id[-1]
            return "graph_node"

        # ----------------------------------------------------------
        # LLM callbacks
        # ----------------------------------------------------------

        def on_llm_start(self, serialized, prompts, *, run_id, parent_run_id=None, **kwargs):
            self._ensure_run_started()

            model_name = ""
            if "kwargs" in serialized:
                model_name = serialized["kwargs"].get(
                    "model_name", serialized["kwargs"].get("model", "")
                )
            if not model_name:
                id_parts = serialized.get("id", [])
                model_name = id_parts[-1] if id_parts else "unknown"

            self._current_llm_start[str(run_id)] = {
                "model": model_name,
                "prompt_preview": (prompts[0][:500] if prompts else ""),
            }

            if _HAS_OTEL and _compat_provider is not None:
                try:
                    parent = self._find_parent_span(parent_run_id)
                    span = start_llm_span(model=model_name, parent_span=parent)
                    self._active_llm_spans[str(run_id)] = span
                except Exception:
                    pass

        def on_llm_end(self, response, *, run_id, **kwargs):
            start_info = self._current_llm_start.pop(str(run_id), {})
            model = start_info.get("model", "unknown")

            token_usage = {}
            if hasattr(response, "llm_output") and response.llm_output:
                token_usage = response.llm_output.get("token_usage", {})

            tokens_in = token_usage.get("prompt_tokens", 0)
            tokens_out = token_usage.get("completion_tokens", 0)
            cost = estimate_cost(model, tokens_in, tokens_out)

            response_text = ""
            if response.generations and response.generations[0]:
                gen = response.generations[0][0]
                response_text = (gen.text or "")[:500]

            self._llm_calls.append({
                "model": model,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "cost": cost,
                "prompt_preview": start_info.get("prompt_preview", ""),
                "response_preview": response_text,
            })

            span = self._active_llm_spans.pop(str(run_id), None)
            if span is not None:
                try:
                    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
                    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
                    span.set_attribute(WaxellAttributes.LLM_MODEL, model)
                    span.set_attribute(WaxellAttributes.LLM_COST, cost)
                    span.end()
                except Exception:
                    pass

        def on_llm_error(self, error, *, run_id=None, **kwargs):
            span = self._active_llm_spans.pop(str(run_id) if run_id else "", None)
            if span is not None:
                try:
                    span.record_exception(error)
                    span.end()
                except Exception:
                    pass

        # ----------------------------------------------------------
        # Chain callbacks (graph nodes appear as chains)
        # ----------------------------------------------------------

        def on_chain_start(self, serialized, inputs, *, run_id, parent_run_id=None, **kwargs):
            self._ensure_run_started()
            self._step_counter += 1

            is_node = self._is_graph_node(serialized)
            node_name = self._get_node_name(serialized)

            if is_node:
                self._node_execution_order.append(node_name)
                self._graph_depth += 1

            self._steps.append({
                "step_name": f"node:{node_name}" if is_node else node_name,
                "output": {},
                "position": self._step_counter,
            })

            if _HAS_OTEL and _compat_provider is not None:
                try:
                    parent = self._find_parent_span(parent_run_id)
                    span = start_step_span(
                        step_name=f"node:{node_name}" if is_node else node_name,
                        position=self._step_counter,
                        parent_span=parent,
                    )
                    if is_node:
                        span.set_attribute("waxell.langgraph.node_name", node_name)
                        span.set_attribute("waxell.langgraph.graph_depth", self._graph_depth)
                        span.set_attribute("waxell.langgraph.execution_order",
                                          len(self._node_execution_order))
                    self._active_node_spans[str(run_id)] = span
                except Exception:
                    pass

        def on_chain_end(self, outputs, *, run_id, **kwargs):
            if self._steps:
                self._steps[-1]["output"] = _safe_json(outputs)

            span = self._active_node_spans.pop(str(run_id), None)
            if span is not None:
                try:
                    span.end()
                except Exception:
                    pass

            if self._graph_depth > 0:
                self._graph_depth -= 1

        def on_chain_error(self, error, *, run_id=None, **kwargs):
            span = self._active_node_spans.pop(str(run_id) if run_id else "", None)
            if span is not None:
                try:
                    span.record_exception(error)
                    span.end()
                except Exception:
                    pass

        # ----------------------------------------------------------
        # Tool callbacks
        # ----------------------------------------------------------

        def on_tool_start(self, serialized, input_str, *, run_id=None, parent_run_id=None, **kwargs):
            self._step_counter += 1
            tool_name = serialized.get("name", "tool")
            self._steps.append({
                "step_name": f"tool:{tool_name}",
                "output": {},
                "position": self._step_counter,
            })

            if _HAS_OTEL and _compat_provider is not None:
                try:
                    parent = self._find_parent_span(parent_run_id)
                    span = start_tool_span(tool_name=tool_name, parent_span=parent)
                    self._active_tool_spans[str(run_id)] = span
                except Exception:
                    pass

        def on_tool_end(self, output, *, run_id=None, **kwargs):
            if self._steps:
                self._steps[-1]["output"] = {"result": str(output)[:1000]}

            span = self._active_tool_spans.pop(str(run_id), None)
            if span is not None:
                try:
                    span.end()
                except Exception:
                    pass

        # ----------------------------------------------------------
        # Flush
        # ----------------------------------------------------------

        async def flush(
            self,
            result: Optional[dict] = None,
            status: str = "success",
            error: str = "",
        ) -> None:
            if not self._run_info:
                logger.warning("Cannot flush: no run started.")
                return

            if self._llm_calls:
                await self._client.record_llm_calls(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
                self._llm_calls = []

            if self._steps:
                await self._client.record_steps(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
                self._steps = []

            await self._client.complete_run(
                run_id=self._run_info.run_id,
                result=result or {},
                status=status,
                error=error,
            )

            for spans_dict in [self._active_llm_spans, self._active_node_spans, self._active_tool_spans]:
                for span in spans_dict.values():
                    try:
                        span.end()
                    except Exception:
                        pass
                spans_dict.clear()

        def flush_sync(self, **kwargs) -> None:
            try:
                asyncio.get_running_loop()
                raise RuntimeError(
                    "Cannot use flush_sync() in async context. "
                    "Use 'await handler.flush()' instead."
                )
            except RuntimeError as e:
                if "no running event loop" not in str(e).lower():
                    raise
                asyncio.run(self.flush(**kwargs))

        @property
        def run_id(self) -> str:
            return self._run_info.run_id if self._run_info else ""

        @property
        def node_execution_order(self) -> list[str]:
            """Return the ordered list of graph nodes that executed."""
            return list(self._node_execution_order)

    return _Handler()


def _safe_json(obj) -> dict:
    if isinstance(obj, dict):
        return {k: _safe_value(v) for k, v in obj.items()}
    return {"value": str(obj)[:1000]}


def _safe_value(v):
    if isinstance(v, (str, int, float, bool, type(None))):
        return v
    if isinstance(v, (list, tuple)):
        return [_safe_value(i) for i in v[:20]]
    if isinstance(v, dict):
        return {str(k): _safe_value(val) for k, val in list(v.items())[:20]}
    return str(v)[:500]
