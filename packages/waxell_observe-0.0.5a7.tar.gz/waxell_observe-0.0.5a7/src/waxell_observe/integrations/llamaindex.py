"""LlamaIndex callback handler for Waxell Observe.

Intercepts LLM calls, retrieval events, embedding calls, and query
engine execution to send telemetry to the Waxell controlplane.

Usage:
    from waxell_observe.integrations.llamaindex import WaxellLlamaIndexHandler

    handler = WaxellLlamaIndexHandler(agent_name="my-rag-agent")

    # Set as global callback handler:
    from llama_index.core import Settings
    Settings.callback_manager.add_handler(handler)

    # Or pass to specific components:
    index = VectorStoreIndex.from_documents(docs, callback_manager=callback_manager)

    # Flush when done:
    handler.flush_sync(result={"output": "..."})
"""

import asyncio
import logging
from typing import Any, Optional

from ..client import WaxellObserveClient
from ..cost import estimate_cost
from ..errors import PolicyViolationError
from ..tracing._compat import _HAS_OTEL, _provider as _compat_provider
from ..tracing.spans import (
    start_llm_span, start_retrieval_span, start_step_span,
)
from ..tracing.attributes import WaxellAttributes
from ..types import RunInfo

logger = logging.getLogger(__name__)


def WaxellLlamaIndexHandler(
    agent_name: str,
    workflow_name: str = "default",
    client: Optional[WaxellObserveClient] = None,
    enforce_policy: bool = True,
    auto_start_run: bool = True,
    parent_span=None,
    session_id: str = "",
    user_id: str = "",
    user_group: str = "",
):
    """Create a LlamaIndex callback handler for Waxell telemetry.

    Returns a BaseCallbackHandler subclass instance.

    Args:
        agent_name: Name for this agent in Waxell.
        workflow_name: Workflow name for grouping runs.
        client: Optional pre-configured WaxellObserveClient.
        enforce_policy: Check policies before execution starts.
        auto_start_run: Automatically start a run on first callback.
        parent_span: Optional parent OTel span.
        session_id: Optional session ID for grouping related runs.
        user_id: Optional end-user ID.
        user_group: Optional end-user group.
    """
    try:
        from llama_index.core.callbacks import CBEventType, EventPayload
        from llama_index.core.callbacks.base_handler import BaseCallbackHandler
    except ImportError:
        raise ImportError(
            "llama-index-core is required for WaxellLlamaIndexHandler. "
            "Install it with: pip install waxell-observe[llamaindex]"
        )

    class _Handler(BaseCallbackHandler):
        """LlamaIndex callback handler that sends telemetry to Waxell."""

        def __init__(self):
            # LlamaIndex requires event_starts_to_ignore and event_ends_to_ignore
            super().__init__(
                event_starts_to_ignore=[],
                event_ends_to_ignore=[],
            )
            self._client = client or WaxellObserveClient()
            self._agent_name = agent_name
            self._workflow_name = workflow_name
            self._enforce_policy = enforce_policy
            self._auto_start = auto_start_run

            self._run_info: Optional[RunInfo] = None
            self._llm_calls: list[dict] = []
            self._steps: list[dict] = []
            self._step_counter = 0
            self._started = False

            # Track event state by event_id
            self._event_data: dict[str, dict] = {}

            # OTel spans keyed by event_id
            self._active_spans: dict[str, Any] = {}
            self._agent_span = parent_span
            self._session_id = session_id
            self._user_id = user_id
            self._user_group = user_group

        def _ensure_run_started(self):
            if self._started or not self._auto_start:
                return
            self._started = True
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._async_start_run())
            except RuntimeError:
                asyncio.run(self._async_start_run())

        async def _async_start_run(self):
            if self._enforce_policy:
                policy = await self._client.check_policy(
                    agent_name=self._agent_name,
                    workflow_name=self._workflow_name,
                )
                if policy.blocked:
                    raise PolicyViolationError(policy.reason, policy)

            self._run_info = await self._client.start_run(
                agent_name=self._agent_name,
                workflow_name=self._workflow_name,
                session_id=self._session_id,
                user_id=self._user_id,
                user_group=self._user_group,
            )

        def on_event_start(
            self,
            event_type: "CBEventType",
            payload: Optional[dict] = None,
            event_id: str = "",
            parent_id: str = "",
            **kwargs,
        ) -> str:
            """Called when a LlamaIndex event starts."""
            self._ensure_run_started()
            self._step_counter += 1
            payload = payload or {}

            self._event_data[event_id] = {
                "type": event_type,
                "parent_id": parent_id,
                "position": self._step_counter,
                "payload": payload,
            }

            if _HAS_OTEL and _compat_provider is not None:
                try:
                    parent = self._active_spans.get(parent_id, self._agent_span)

                    if event_type == CBEventType.LLM:
                        model = ""
                        serialized = payload.get(EventPayload.SERIALIZED, {})
                        if serialized:
                            model = serialized.get("model", serialized.get("model_name", ""))
                        span = start_llm_span(model=model, parent_span=parent)
                        self._event_data[event_id]["model"] = model

                    elif event_type == CBEventType.RETRIEVE:
                        query = str(payload.get(EventPayload.QUERY_STR, ""))[:200]
                        span = start_retrieval_span(query=query, source="llamaindex", parent_span=parent)

                    elif event_type == CBEventType.EMBEDDING:
                        span = start_step_span(
                            step_name="embedding",
                            position=self._step_counter,
                            parent_span=parent,
                        )

                    elif event_type == CBEventType.QUERY:
                        query = str(payload.get(EventPayload.QUERY_STR, ""))[:200]
                        span = start_step_span(
                            step_name="query_engine",
                            position=self._step_counter,
                            parent_span=parent,
                        )

                    elif event_type == CBEventType.SYNTHESIZE:
                        span = start_step_span(
                            step_name="synthesize",
                            position=self._step_counter,
                            parent_span=parent,
                        )

                    elif event_type == CBEventType.CHUNKING:
                        span = start_step_span(
                            step_name="chunking",
                            position=self._step_counter,
                            parent_span=parent,
                        )

                    else:
                        span = start_step_span(
                            step_name=str(event_type),
                            position=self._step_counter,
                            parent_span=parent,
                        )

                    if self._session_id:
                        try:
                            span.set_attribute(WaxellAttributes.SESSION_ID, self._session_id)
                        except Exception:
                            pass
                    self._active_spans[event_id] = span
                except Exception:
                    pass

            return event_id

        def on_event_end(
            self,
            event_type: "CBEventType",
            payload: Optional[dict] = None,
            event_id: str = "",
            **kwargs,
        ) -> None:
            """Called when a LlamaIndex event ends."""
            payload = payload or {}
            start_data = self._event_data.pop(event_id, {})

            if event_type == CBEventType.LLM:
                self._handle_llm_end(payload, start_data)
            elif event_type == CBEventType.RETRIEVE:
                self._handle_retrieve_end(payload, start_data)
            else:
                self._steps.append({
                    "step_name": str(event_type),
                    "output": {},
                    "position": start_data.get("position", 0),
                })

            # End OTel span
            span = self._active_spans.pop(event_id, None)
            if span is not None:
                try:
                    span.end()
                except Exception:
                    pass

        def _handle_llm_end(self, payload: dict, start_data: dict):
            """Handle LLM event completion."""
            try:
                from llama_index.core.callbacks import EventPayload as EP
            except ImportError:
                return

            model = start_data.get("model", "unknown")
            response = payload.get(EP.RESPONSE, None)
            completion = payload.get(EP.COMPLETION, None)

            tokens_in, tokens_out = 0, 0
            response_text = ""

            if response and hasattr(response, "raw"):
                raw = response.raw
                if hasattr(raw, "usage"):
                    usage = raw.usage
                    tokens_in = getattr(usage, "prompt_tokens",
                                       getattr(usage, "input_tokens", 0)) or 0
                    tokens_out = getattr(usage, "completion_tokens",
                                        getattr(usage, "output_tokens", 0)) or 0
                response_text = str(response)[:500]
            elif completion:
                response_text = str(completion)[:500]

            cost = estimate_cost(model, tokens_in, tokens_out)

            self._llm_calls.append({
                "model": model,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "cost": cost,
                "prompt_preview": "",
                "response_preview": response_text,
            })

            # Update OTel span attributes
            span = self._active_spans.get(start_data.get("_event_id", ""))
            # Span attributes are set before end() in on_event_end

        def _handle_retrieve_end(self, payload: dict, start_data: dict):
            """Handle retrieval event completion."""
            try:
                from llama_index.core.callbacks import EventPayload as EP
            except ImportError:
                return

            nodes = payload.get(EP.NODES, [])
            self._steps.append({
                "step_name": "retrieve",
                "output": {"nodes_count": len(nodes)},
                "position": start_data.get("position", 0),
            })

        def start_trace(self, trace_id: Optional[str] = None) -> None:
            """Called when a trace starts (top-level query)."""
            self._ensure_run_started()

        def end_trace(
            self,
            trace_id: Optional[str] = None,
            trace_map: Optional[dict] = None,
        ) -> None:
            """Called when a trace ends."""
            pass  # Flush is done explicitly

        # ----------------------------------------------------------
        # Flush
        # ----------------------------------------------------------

        async def flush(
            self,
            result: Optional[dict] = None,
            status: str = "success",
            error: str = "",
        ) -> None:
            """Flush all buffered telemetry to the controlplane."""
            if not self._run_info:
                logger.warning("Cannot flush: no run started.")
                return

            if self._llm_calls:
                await self._client.record_llm_calls(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
                self._llm_calls = []

            if self._steps:
                await self._client.record_steps(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
                self._steps = []

            await self._client.complete_run(
                run_id=self._run_info.run_id,
                result=result or {},
                status=status,
                error=error,
            )

            for span in self._active_spans.values():
                try:
                    span.end()
                except Exception:
                    pass
            self._active_spans.clear()

        def flush_sync(self, **kwargs) -> None:
            """Synchronous version of flush."""
            try:
                asyncio.get_running_loop()
                raise RuntimeError(
                    "Cannot use flush_sync() in async context. "
                    "Use 'await handler.flush()' instead."
                )
            except RuntimeError as e:
                if "no running event loop" not in str(e).lower():
                    raise
                asyncio.run(self.flush(**kwargs))

        @property
        def run_id(self) -> str:
            return self._run_info.run_id if self._run_info else ""

    return _Handler()
