"""Role management commands."""
import json

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
)


def _normalize_items(data, key: str = "roles"):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get(key, data.get("results", data.get("items", data)))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


@click.group()
def roles():
    """Manage roles and permissions."""


@roles.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def roles_list(ctx, fmt: str):
    """List all roles."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data, "roles")

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No roles found.")
        return

    print_header("Roles", f"{len(items)} roles")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Role Name", style="bold")
    table.add_column("Type")
    table.add_column("Permissions", justify="right")
    table.add_column("Users", justify="right")

    for r in items:
        role_type = r.get("type", r.get("role_type", "system" if r.get("is_system", False) else "custom"))
        perms = r.get("permissions", [])
        perm_count = len(perms) if isinstance(perms, list) else perms
        user_count = r.get("user_count", r.get("users_count", len(r.get("users", []))))

        table.add_row(
            r.get("name", "-"),
            role_type,
            fmt_number(perm_count),
            fmt_number(user_count),
        )

    console.print(table)
    console.print()


@roles.command("show")
@click.argument("name")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def roles_show(ctx, name: str, fmt: str):
    """Show role details and permissions."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data, "roles")

    role = None
    for r in items:
        if r.get("name", "").lower() == name.lower() or str(r.get("id", "")) == name:
            role = r
            break

    if not role:
        print_warning(f'Role "{name}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(role, indent=2))
        return

    print_header(f"Role: {role.get('name', '-')}")

    role_type = role.get("type", role.get("role_type", "system" if role.get("is_system", False) else "custom"))

    lines = [
        f"[bold]Name:[/bold]        {role.get('name', '-')}",
        f"[bold]ID:[/bold]          {role.get('id', '-')}",
        f"[bold]Type:[/bold]        {role_type}",
        f"[bold]Description:[/bold] {role.get('description', '-')}",
    ]

    console.print(Panel("\n".join(lines), border_style="cyan"))

    # Permissions table
    permissions = role.get("permissions", [])
    if permissions:
        console.print()
        perm_table = Table(
            show_header=True,
            header_style="bold cyan",
            border_style="dim",
            title=f"Permissions ({len(permissions)})",
        )
        perm_table.add_column("Permission", style="bold")
        perm_table.add_column("Description")

        for p in permissions:
            if isinstance(p, dict):
                perm_table.add_row(
                    p.get("name", p.get("codename", str(p))),
                    p.get("description", "-"),
                )
            else:
                perm_table.add_row(str(p), "-")

        console.print(perm_table)

    # Users assigned
    assigned_users = role.get("users", [])
    if assigned_users:
        console.print()
        user_table = Table(
            show_header=True,
            header_style="bold cyan",
            border_style="dim",
            title=f"Assigned Users ({len(assigned_users)})",
        )
        user_table.add_column("Email", style="bold")
        user_table.add_column("Name")

        for u in assigned_users:
            if isinstance(u, dict):
                user_table.add_row(u.get("email", "-"), u.get("name", "-"))
            else:
                user_table.add_row(str(u), "-")

        console.print(user_table)

    console.print()
