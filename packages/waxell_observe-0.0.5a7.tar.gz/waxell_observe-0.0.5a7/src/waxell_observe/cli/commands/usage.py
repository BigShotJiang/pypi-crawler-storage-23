"""Usage analytics commands."""
import json

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    fmt_cost,
    fmt_tokens,
)


def _normalize_items(data):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get("results", data.get("items", data.get("models", data)))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


@click.group()
def usage():
    """View usage analytics and breakdowns."""


@usage.command("summary")
@click.option("--hours", default=24, type=int, help="Look back N hours (default: 24)")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def usage_summary(ctx, hours: int, fmt: str):
    """Show usage summary: tokens, API calls, and cost."""
    data = api_get(ctx, "/v1/observe/query/billing/", params={"hours": hours})

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    if not data:
        print_warning("No usage data available.")
        return

    print_header("Usage Summary", f"Last {hours} hours")

    # Extract usage stats from various response shapes
    if isinstance(data, dict):
        stats = data.get("usage", data.get("summary", data))
    else:
        stats = {}

    total_tokens = stats.get("total_tokens", stats.get("tokens", 0)) or 0
    input_tokens = stats.get("input_tokens", stats.get("prompt_tokens", 0)) or 0
    output_tokens = stats.get("output_tokens", stats.get("completion_tokens", 0)) or 0
    api_calls = stats.get("api_calls", stats.get("total_calls", stats.get("llm_calls", 0))) or 0
    total_cost = stats.get("total_cost", stats.get("cost", 0)) or 0
    runs = stats.get("runs", stats.get("total_runs", 0)) or 0

    lines = [
        "[bold]Token Usage:[/bold]",
        f"  Total:  {fmt_tokens(total_tokens)}",
        f"  Input:  {fmt_tokens(input_tokens)}",
        f"  Output: {fmt_tokens(output_tokens)}",
        "",
        f"[bold]API Calls:[/bold]  {fmt_number(api_calls)}",
        f"[bold]Agent Runs:[/bold] {fmt_number(runs)}",
        "",
        f"[bold]Total Cost:[/bold] {fmt_cost(total_cost)}",
    ]

    # Cost breakdown by category
    cost_breakdown = stats.get("cost_breakdown", stats.get("by_category", {}))
    if cost_breakdown and isinstance(cost_breakdown, dict):
        lines.append("")
        lines.append("[bold]Cost Breakdown:[/bold]")
        for category, amount in cost_breakdown.items():
            lines.append(f"  {category}: {fmt_cost(amount)}")

    # Per-agent breakdown
    by_agent = stats.get("by_agent", {})
    if by_agent and isinstance(by_agent, dict):
        lines.append("")
        lines.append("[bold]By Agent:[/bold]")
        for agent, agent_stats in by_agent.items():
            if isinstance(agent_stats, dict):
                cost = agent_stats.get("cost", 0)
                tokens = agent_stats.get("tokens", 0)
                lines.append(f"  {agent}: {fmt_cost(cost)} ({fmt_tokens(tokens)} tokens)")
            else:
                lines.append(f"  {agent}: {agent_stats}")

    console.print(Panel("\n".join(lines), title="Usage Summary", border_style="cyan"))
    console.print()


@usage.command("by-model")
@click.option("--hours", default=24, type=int, help="Look back N hours (default: 24)")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def usage_by_model(ctx, hours: int, fmt: str):
    """Show usage breakdown by model."""
    data = api_get(ctx, "/v1/observe/query/models/", params={"hours": hours})

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    items = _normalize_items(data)

    if not items:
        print_warning("No model usage data found.")
        return

    print_header("Usage by Model", f"Last {hours} hours")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Model", style="bold")
    table.add_column("Provider")
    table.add_column("Calls", justify="right")
    table.add_column("Input Tokens", justify="right")
    table.add_column("Output Tokens", justify="right")
    table.add_column("Total Tokens", justify="right")
    table.add_column("Cost", justify="right")

    total_cost = 0
    total_calls = 0
    total_tokens_all = 0

    for m in items:
        calls = m.get("call_count", m.get("calls", m.get("count", 0))) or 0
        input_tok = m.get("input_tokens", m.get("prompt_tokens", 0)) or 0
        output_tok = m.get("output_tokens", m.get("completion_tokens", 0)) or 0
        total_tok = m.get("total_tokens", input_tok + output_tok) or 0
        cost = m.get("cost", m.get("total_cost", 0)) or 0

        total_cost += cost
        total_calls += calls
        total_tokens_all += total_tok

        table.add_row(
            m.get("model", m.get("model_name", "-")),
            m.get("provider", "-"),
            fmt_number(calls),
            fmt_tokens(input_tok),
            fmt_tokens(output_tok),
            fmt_tokens(total_tok),
            fmt_cost(cost),
        )

    # Summary row
    table.add_section()
    table.add_row(
        "[bold]Total[/bold]",
        "",
        f"[bold]{fmt_number(total_calls)}[/bold]",
        "",
        "",
        f"[bold]{fmt_tokens(total_tokens_all)}[/bold]",
        f"[bold]{fmt_cost(total_cost)}[/bold]",
    )

    console.print(table)
    console.print()
