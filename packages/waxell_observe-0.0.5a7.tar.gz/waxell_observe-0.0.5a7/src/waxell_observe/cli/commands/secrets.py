"""Secrets management commands."""
import json
from datetime import datetime
from typing import Optional

import click
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
)


def _normalize_items(data, key: str = "secrets"):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get(key, data.get("api_keys", data.get("results", data.get("items", data))))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


def _short_ts(ts: Optional[str]) -> str:
    """Format an ISO timestamp to a short display string."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return str(ts)[:16]


def _mask_value(value: str) -> str:
    """Mask a secret value, showing only last 4 characters."""
    if not value or len(value) < 8:
        return "****"
    return "*" * (len(value) - 4) + value[-4:]


@click.group()
def secrets():
    """Manage secrets and API keys."""


@secrets.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def secrets_list(ctx, fmt: str):
    """List all secrets (values masked)."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data)

    if fmt == "json":
        # Mask values in JSON output too
        safe_items = []
        for item in items:
            safe = dict(item) if isinstance(item, dict) else {"value": str(item)}
            for key in ("value", "secret", "key", "token", "api_key"):
                if key in safe and safe[key]:
                    safe[key] = _mask_value(str(safe[key]))
            safe_items.append(safe)
        console.print_json(json.dumps(safe_items, indent=2))
        return

    if not items:
        print_warning("No secrets found.")
        return

    print_header("Secrets", f"{len(items)} secrets")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Type")
    table.add_column("Created")
    table.add_column("Last Rotated")
    table.add_column("Status", justify="center")

    for s in items:
        is_active = s.get("is_active", s.get("active", s.get("revoked", None) is None))
        if s.get("revoked", False):
            status = "disabled"
        else:
            status = "active" if is_active else "inactive"

        # Determine type
        secret_type = s.get("type", s.get("key_type", "api_key"))

        table.add_row(
            s.get("name", s.get("label", s.get("prefix", "-"))),
            secret_type,
            _short_ts(s.get("created_at", s.get("created"))),
            _short_ts(s.get("last_rotated", s.get("rotated_at"))),
            status_dot(status),
        )

    console.print(table)
    console.print()
