"""Error analysis commands."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    pct_color,
)
from rich.table import Table
from rich.panel import Panel


@click.group()
def errors():
    """Error analysis and diagnostics."""
    pass


@errors.command("summary")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def errors_summary(ctx, hours: int, output_format: str):
    """Show error summary with breakdown by agent."""
    data = api_get(ctx, "/v1/observe/query/errors/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    total_errors = data.get("total_errors", 0)
    error_rate = data.get("error_rate", 0)
    error_pct = error_rate * 100 if error_rate < 1 else error_rate

    print_header("Error Summary", f"Last {hours}h")

    # Overview panel
    rate_color = pct_color(error_pct, warn=5, danger=15)
    summary_text = (
        f"[bold]Total Errors:[/bold] {fmt_number(total_errors)}\n"
        f"[bold]Error Rate:[/bold]   [{rate_color}]{error_pct:.1f}%[/{rate_color}]"
    )
    console.print(Panel(summary_text, title="Overview", border_style="red"))
    console.print()

    # Breakdown by agent
    by_agent = data.get("by_agent", data.get("agent_errors", []))
    if by_agent:
        table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        table.add_column("Agent", style="bold")
        table.add_column("Errors", justify="right")
        table.add_column("Error Rate", justify="right")
        table.add_column("", min_width=20)

        # Calculate max for bar scaling
        max_errors = max((a.get("errors", a.get("count", 0)) for a in by_agent), default=1)

        for agent in by_agent:
            err_count = agent.get("errors", agent.get("count", 0))
            a_rate = agent.get("error_rate", 0)
            a_pct = a_rate * 100 if a_rate < 1 else a_rate
            bar_width = 20
            filled = int((err_count / max_errors) * bar_width) if max_errors > 0 else 0

            bar = f"[red]{'█' * filled}[/red][dim]{'░' * (bar_width - filled)}[/dim]"

            table.add_row(
                agent.get("name", agent.get("agent_name", "unknown")),
                fmt_number(err_count),
                f"{a_pct:.1f}%",
                bar,
            )

        console.print(table)
        console.print()


@errors.command("list")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option("--limit", type=int, default=25, help="Maximum error types to display.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def errors_list(ctx, hours: int, limit: int, output_format: str):
    """List error types with counts and affected agents."""
    data = api_get(ctx, "/v1/observe/query/errors/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    error_types = data.get("error_types", data.get("errors", []))
    if not error_types:
        print_warning("No errors found for the selected period.")
        return

    error_types = error_types[:limit]
    print_header("Errors by Type", f"Last {hours}h")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Error Type", style="bold red")
    table.add_column("Message", max_width=50)
    table.add_column("Count", justify="right")
    table.add_column("Agents Affected")

    for error in error_types:
        message = str(error.get("message", error.get("sample_message", "")))
        if len(message) > 50:
            message = message[:47] + "..."

        agents_affected = error.get("agents", error.get("agents_affected", []))
        if isinstance(agents_affected, list):
            agents_str = ", ".join(str(a) for a in agents_affected[:3])
            if len(agents_affected) > 3:
                agents_str += f" +{len(agents_affected) - 3}"
        else:
            agents_str = str(agents_affected)

        table.add_row(
            error.get("type", error.get("error_type", "Unknown")),
            message,
            fmt_number(error.get("count", 0)),
            agents_str,
        )

    console.print(table)
    console.print()
