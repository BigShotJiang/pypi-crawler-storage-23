"""Sub-tenant management commands."""
import json
from datetime import datetime
from typing import Optional

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
    fmt_number,
)


def _normalize_items(data, key: str = "sub_tenants"):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get(key, data.get("tenants", data.get("results", data.get("items", data))))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


def _short_ts(ts: Optional[str]) -> str:
    """Format an ISO timestamp to a short display string."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        return str(ts)[:10]


@click.group(name="sub-tenants")
def sub_tenants():
    """Manage sub-tenants."""


@sub_tenants.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def sub_tenants_list(ctx, fmt: str):
    """List all sub-tenants."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data)

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No sub-tenants found.")
        return

    print_header("Sub-Tenants", f"{len(items)} sub-tenants")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Slug")
    table.add_column("Plan")
    table.add_column("Users", justify="right")
    table.add_column("Status", justify="center")

    for t in items:
        is_active = t.get("is_active", t.get("status", "") in ("active", "enabled"))
        status = "active" if is_active else "inactive"
        user_count = t.get("user_count", t.get("users_count", len(t.get("users", []))))

        table.add_row(
            t.get("name", "-"),
            t.get("slug", t.get("schema_name", "-")),
            t.get("plan", t.get("plan_type", "-")),
            fmt_number(user_count),
            status_dot(status),
        )

    console.print(table)
    console.print()


@sub_tenants.command("show")
@click.argument("id")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def sub_tenants_show(ctx, id: str, fmt: str):
    """Show sub-tenant details."""
    data = api_get(ctx, "/v1/observe/query/access/")
    items = _normalize_items(data)

    tenant = None
    for t in items:
        if (str(t.get("id", "")) == id
                or t.get("slug", "").lower() == id.lower()
                or t.get("name", "").lower() == id.lower()):
            tenant = t
            break

    if not tenant:
        print_warning(f'Sub-tenant "{id}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(tenant, indent=2))
        return

    print_header(f"Sub-Tenant: {tenant.get('name', '-')}")

    is_active = tenant.get("is_active", tenant.get("status", "") in ("active", "enabled"))
    status = "active" if is_active else "inactive"

    lines = [
        f"[bold]Name:[/bold]      {tenant.get('name', '-')}",
        f"[bold]ID:[/bold]        {tenant.get('id', '-')}",
        f"[bold]Slug:[/bold]      {tenant.get('slug', tenant.get('schema_name', '-'))}",
        f"[bold]Plan:[/bold]      {tenant.get('plan', tenant.get('plan_type', '-'))}",
        f"[bold]Status:[/bold]    {status_dot(status)} {status}",
        f"[bold]Created:[/bold]   {_short_ts(tenant.get('created_at', tenant.get('created')))}",
    ]

    # Domain info
    domains = tenant.get("domains", [])
    if domains:
        lines.append("")
        lines.append("[bold]Domains:[/bold]")
        for d in domains:
            if isinstance(d, dict):
                lines.append(f"  - {d.get('domain', str(d))}")
            else:
                lines.append(f"  - {d}")

    # Users
    users = tenant.get("users", [])
    if users:
        lines.append("")
        lines.append(f"[bold]Users ({len(users)}):[/bold]")
        for u in users[:10]:
            if isinstance(u, dict):
                lines.append(f"  - {u.get('email', str(u))} ({u.get('role', 'member')})")
            else:
                lines.append(f"  - {u}")
        if len(users) > 10:
            lines.append(f"  ... and {len(users) - 10} more")

    # Subscription / limits
    subscription = tenant.get("subscription", {})
    if subscription and isinstance(subscription, dict):
        lines.append("")
        lines.append("[bold]Subscription:[/bold]")
        for k, v in subscription.items():
            lines.append(f"  {k}: {v}")

    console.print(Panel("\n".join(lines), border_style="cyan"))
    console.print()
