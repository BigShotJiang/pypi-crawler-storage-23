"""User analytics commands for observability."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    fmt_cost,
)
from rich.table import Table
from rich.panel import Panel


@click.group(name="observe-users")
def observe_users():
    """User analytics for agent usage (observability)."""
    pass


@observe_users.command("list")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option("--limit", type=int, default=25, help="Maximum users to display.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def observe_users_list(ctx, hours: int, limit: int, output_format: str):
    """List users by agent usage metrics."""
    data = api_get(ctx, "/v1/observe/query/users/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    users_data = data.get("users", [])
    if not users_data:
        print_warning("No user activity found for the selected period.")
        return

    users_data = users_data[:limit]
    print_header("User Analytics", f"Last {hours}h | {len(users_data)} active users")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("User ID", style="bold")
    table.add_column("Group")
    table.add_column("Runs", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Last Seen", style="dim")

    for user in users_data:
        table.add_row(
            str(user.get("user_id", user.get("id", "-"))),
            str(user.get("group", user.get("team", "-"))),
            fmt_number(user.get("runs", user.get("run_count", 0))),
            fmt_cost(user.get("cost", user.get("total_cost", 0))),
            str(user.get("last_seen", user.get("last_activity", "-"))),
        )

    console.print(table)
    console.print()


@observe_users.command("show")
@click.argument("user_id")
@click.option("--hours", type=int, default=168, help="Time window in hours.")
@click.pass_context
def observe_users_show(ctx, user_id: str, hours: int):
    """Show detailed analytics for a specific user."""
    data = api_get(
        ctx,
        "/v1/observe/query/users/",
        params={"user_id": user_id, "hours": hours},
    )

    users_data = data.get("users", [])
    if not users_data:
        print_warning(f"No data found for user '{user_id}'.")
        return

    user = users_data[0]
    print_header(f"User: {user_id}")

    # Summary panel
    summary_lines = [
        f"[bold]User ID:[/bold]   {user.get('user_id', user.get('id', user_id))}",
        f"[bold]Group:[/bold]     {user.get('group', user.get('team', '-'))}",
        f"[bold]Runs:[/bold]      {fmt_number(user.get('runs', user.get('run_count', 0)))}",
        f"[bold]Cost:[/bold]      {fmt_cost(user.get('cost', user.get('total_cost', 0)))}",
        f"[bold]Last Seen:[/bold] {user.get('last_seen', user.get('last_activity', '-'))}",
    ]
    console.print(
        Panel("\n".join(summary_lines), title="User Detail", border_style="cyan")
    )
    console.print()

    # Agent usage breakdown
    agents = user.get("agents", user.get("agent_usage", []))
    if agents:
        agent_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        agent_table.add_column("Agent", style="bold")
        agent_table.add_column("Runs", justify="right")
        agent_table.add_column("Cost", justify="right")

        for agent in agents:
            agent_table.add_row(
                agent.get("name", agent.get("agent_name", "unknown")),
                fmt_number(agent.get("runs", 0)),
                fmt_cost(agent.get("cost", 0)),
            )

        console.print(agent_table)
        console.print()

    # Recent runs
    runs = user.get("recent_runs", [])
    if runs:
        run_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        run_table.add_column("Run ID", style="bold", max_width=14)
        run_table.add_column("Agent")
        run_table.add_column("Status")
        run_table.add_column("Cost", justify="right")
        run_table.add_column("Time", style="dim")

        from .._display import status_dot

        for run in runs[:10]:
            run_status = run.get("status", "unknown")
            run_table.add_row(
                str(run.get("run_id", run.get("id", "")))[:12],
                run.get("agent_name", run.get("agent", "-")),
                f"{status_dot(run_status)} {run_status}",
                fmt_cost(run.get("cost", 0)),
                str(run.get("started_at", run.get("created_at", "-"))),
            )

        console.print(run_table)
        console.print()
