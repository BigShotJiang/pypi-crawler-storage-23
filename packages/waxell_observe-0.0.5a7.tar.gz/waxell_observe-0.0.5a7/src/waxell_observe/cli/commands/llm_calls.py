"""LLM call browser commands."""
import json

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
    fmt_cost,
    fmt_tokens,
    fmt_duration,
)
from rich.table import Table


@click.group(name="llm-calls")
def llm_calls():
    """LLM call browser and model analytics."""
    pass


@llm_calls.command("list")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option("--limit", type=int, default=25, help="Maximum rows to display.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def llm_calls_list(ctx, hours: int, limit: int, output_format: str):
    """List LLM calls aggregated by model."""
    data = api_get(ctx, "/v1/observe/query/models/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    models = data.get("models", data.get("model_breakdown", []))
    if not models:
        print_warning("No LLM call data found for the selected period.")
        return

    models = models[:limit]
    print_header("LLM Calls by Model", f"Last {hours}h")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Model", style="bold")
    table.add_column("Calls", justify="right")
    table.add_column("Tokens In", justify="right")
    table.add_column("Tokens Out", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Avg Latency", justify="right")

    for model in models:
        table.add_row(
            model.get("model", model.get("model_name", "unknown")),
            fmt_number(model.get("calls", model.get("call_count", 0))),
            fmt_tokens(model.get("tokens_in", model.get("input_tokens", 0))),
            fmt_tokens(model.get("tokens_out", model.get("output_tokens", 0))),
            fmt_cost(model.get("cost", model.get("total_cost", 0))),
            fmt_duration(model.get("avg_latency", model.get("avg_latency_ms", 0) / 1000 if model.get("avg_latency_ms") else 0)),
        )

    console.print(table)
    console.print()


@llm_calls.command("by-model")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def llm_calls_by_model(ctx, hours: int, output_format: str):
    """Show model breakdown with cost share visualization."""
    data = api_get(ctx, "/v1/observe/query/models/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    models = data.get("models", data.get("model_breakdown", []))
    if not models:
        print_warning("No model data found for the selected period.")
        return

    # Calculate total cost for percentage bars
    total_cost = sum(
        m.get("cost", m.get("total_cost", 0)) for m in models
    )

    print_header("Model Cost Breakdown", f"Last {hours}h | Total: {fmt_cost(total_cost)}")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Model", style="bold")
    table.add_column("Calls", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Share", justify="right")
    table.add_column("", min_width=20)

    for model in models:
        cost = model.get("cost", model.get("total_cost", 0))
        pct = (cost / total_cost * 100) if total_cost > 0 else 0
        bar_width = 20
        filled = int((pct / 100) * bar_width)

        bar = f"[cyan]{'█' * filled}[/cyan][dim]{'░' * (bar_width - filled)}[/dim]"

        table.add_row(
            model.get("model", model.get("model_name", "unknown")),
            fmt_number(model.get("calls", model.get("call_count", 0))),
            fmt_cost(cost),
            f"{pct:.1f}%",
            bar,
        )

    console.print(table)
    console.print()
