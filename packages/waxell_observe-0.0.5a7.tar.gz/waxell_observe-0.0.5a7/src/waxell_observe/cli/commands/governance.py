"""Governance commands: policies, kill-switches, and budgets."""
import json
from datetime import datetime
from typing import Optional

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
    fmt_number,
    usage_gauge,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_items(data):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get("results", data.get("items", data))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


def _short_ts(ts: Optional[str]) -> str:
    """Format an ISO timestamp to a short display string."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return str(ts)[:16]


# ---------------------------------------------------------------------------
# policies group
# ---------------------------------------------------------------------------

@click.group()
def policies():
    """Manage governance policies."""


@policies.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def policies_list(ctx, fmt: str):
    """List all governance policies."""
    data = api_get(ctx, "/v1/observe/policies/")
    items = _normalize_items(data)

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No policies found.")
        return

    print_header("Governance Policies", f"{len(items)} policies configured")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Category")
    table.add_column("Enabled", justify="center")
    table.add_column("Priority", justify="right")
    table.add_column("Scope")
    table.add_column("Violations (24h)", justify="right")

    for p in items:
        enabled = "enabled" if p.get("enabled", p.get("is_active", False)) else "disabled"
        violations = p.get("violations_24h", p.get("violation_count", 0))
        table.add_row(
            p.get("name", "-"),
            p.get("category", p.get("type", "-")),
            status_dot(enabled),
            str(p.get("priority", "-")),
            p.get("scope", "global"),
            fmt_number(violations),
        )

    console.print(table)
    console.print()


@policies.command("show")
@click.argument("name")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def policies_show(ctx, name: str, fmt: str):
    """Show details for a specific policy."""
    data = api_get(ctx, "/v1/observe/policies/")
    items = _normalize_items(data)

    policy = None
    for p in items:
        if p.get("name", "").lower() == name.lower() or str(p.get("id", "")) == name:
            policy = p
            break

    if not policy:
        print_warning(f'Policy "{name}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(policy, indent=2))
        return

    print_header(f"Policy: {policy.get('name', '-')}")

    enabled = "enabled" if policy.get("enabled", policy.get("is_active", False)) else "disabled"
    lines = [
        f"[bold]Name:[/bold]        {policy.get('name', '-')}",
        f"[bold]Category:[/bold]    {policy.get('category', policy.get('type', '-'))}",
        f"[bold]Enabled:[/bold]     {status_dot(enabled)} {enabled}",
        f"[bold]Priority:[/bold]    {policy.get('priority', '-')}",
        f"[bold]Scope:[/bold]       {policy.get('scope', 'global')}",
        f"[bold]Description:[/bold] {policy.get('description', '-')}",
    ]

    # Rules / conditions
    rules = policy.get("rules", policy.get("conditions", []))
    if rules:
        lines.append("")
        lines.append("[bold]Rules:[/bold]")
        if isinstance(rules, list):
            for r in rules:
                if isinstance(r, dict):
                    lines.append(f"  - {r.get('field', '')} {r.get('operator', '')} {r.get('value', '')}")
                else:
                    lines.append(f"  - {r}")
        elif isinstance(rules, dict):
            for k, v in rules.items():
                lines.append(f"  - {k}: {v}")

    # Actions
    actions = policy.get("actions", policy.get("action", []))
    if actions:
        lines.append("")
        lines.append("[bold]Actions:[/bold]")
        if isinstance(actions, list):
            for a in actions:
                if isinstance(a, dict):
                    lines.append(f"  - {a.get('type', a.get('action', str(a)))}")
                else:
                    lines.append(f"  - {a}")
        elif isinstance(actions, str):
            lines.append(f"  - {actions}")

    console.print(Panel("\n".join(lines), border_style="cyan"))
    console.print()


# ---------------------------------------------------------------------------
# kill-switches group
# ---------------------------------------------------------------------------

@click.group(name="kill-switches")
def kill_switches():
    """Manage kill switches."""


@kill_switches.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def kill_switches_list(ctx, fmt: str):
    """List all kill switches."""
    data = api_get(ctx, "/v1/killswitches/")
    items = _normalize_items(data)

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No kill switches found.")
        return

    print_header("Kill Switches", f"{len(items)} kill switches")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Status", justify="center")
    table.add_column("Scope")
    table.add_column("Trigger Condition")
    table.add_column("Last Triggered")

    for ks in items:
        status = ks.get("status", "armed")
        if ks.get("is_triggered", False):
            status = "triggered"
        elif ks.get("is_armed", ks.get("enabled", True)):
            status = "armed"
        else:
            status = "disabled"

        table.add_row(
            ks.get("name", "-"),
            status_dot({"armed": "active", "triggered": "triggered", "disabled": "disabled"}.get(status, status)),
            ks.get("scope", "global"),
            ks.get("trigger_condition", ks.get("condition", "-")),
            _short_ts(ks.get("last_triggered", ks.get("triggered_at"))),
        )

    console.print(table)
    console.print()


@kill_switches.command("show")
@click.argument("id")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def kill_switches_show(ctx, id: str, fmt: str):
    """Show kill switch details."""
    data = api_get(ctx, "/v1/killswitches/")
    items = _normalize_items(data)

    ks = None
    for item in items:
        if str(item.get("id", "")) == id or item.get("name", "").lower() == id.lower():
            ks = item
            break

    if not ks:
        print_warning(f'Kill switch "{id}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(ks, indent=2))
        return

    print_header(f"Kill Switch: {ks.get('name', '-')}")

    status = "triggered" if ks.get("is_triggered", False) else ("armed" if ks.get("is_armed", ks.get("enabled", True)) else "disabled")
    status_display = {"armed": "active", "triggered": "triggered", "disabled": "disabled"}.get(status, status)

    lines = [
        f"[bold]Name:[/bold]              {ks.get('name', '-')}",
        f"[bold]Status:[/bold]            {status_dot(status_display)} {status}",
        f"[bold]Scope:[/bold]             {ks.get('scope', 'global')}",
        f"[bold]Trigger Condition:[/bold] {ks.get('trigger_condition', ks.get('condition', '-'))}",
        f"[bold]Last Triggered:[/bold]    {_short_ts(ks.get('last_triggered', ks.get('triggered_at')))}",
        f"[bold]Description:[/bold]       {ks.get('description', '-')}",
    ]

    # Affected agents
    affected = ks.get("affected_agents", ks.get("agents", []))
    if affected:
        lines.append("")
        lines.append("[bold]Affected Agents:[/bold]")
        if isinstance(affected, list):
            for a in affected:
                lines.append(f"  - {a}")
        else:
            lines.append(f"  - {affected}")

    console.print(Panel("\n".join(lines), border_style="cyan"))
    console.print()


# ---------------------------------------------------------------------------
# budgets group
# ---------------------------------------------------------------------------

@click.group()
def budgets():
    """Manage governance budgets."""


@budgets.command("list")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def budgets_list(ctx, fmt: str):
    """List all budgets."""
    data = api_get(ctx, "/v1/budgets/")
    items = _normalize_items(data)

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning("No budgets found.")
        return

    print_header("Governance Budgets", f"{len(items)} budgets configured")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Type")
    table.add_column("Used", justify="right")
    table.add_column("Limit", justify="right")
    table.add_column("Usage %", justify="right")
    table.add_column("Resets At")

    for b in items:
        used = b.get("used", b.get("current_usage", 0)) or 0
        limit = b.get("limit", b.get("budget_limit", 0)) or 0
        pct = (used / limit * 100) if limit > 0 else 0

        if pct >= 90:
            pct_str = f"[red]{pct:.1f}%[/red]"
        elif pct >= 70:
            pct_str = f"[yellow]{pct:.1f}%[/yellow]"
        else:
            pct_str = f"[green]{pct:.1f}%[/green]"

        table.add_row(
            b.get("name", "-"),
            b.get("type", b.get("budget_type", "-")),
            fmt_number(used),
            fmt_number(limit),
            pct_str,
            _short_ts(b.get("resets_at", b.get("reset_at"))),
        )

    console.print(table)
    console.print()

    # Usage gauges for each budget
    for b in items:
        used = b.get("used", b.get("current_usage", 0)) or 0
        limit = b.get("limit", b.get("budget_limit", 0)) or 0
        if limit > 0:
            usage_gauge(b.get("name", "Budget"), float(used), float(limit))


@budgets.command("show")
@click.argument("id")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def budgets_show(ctx, id: str, fmt: str):
    """Show budget details."""
    data = api_get(ctx, "/v1/budgets/")
    items = _normalize_items(data)

    budget = None
    for b in items:
        if str(b.get("id", "")) == id or b.get("name", "").lower() == id.lower():
            budget = b
            break

    if not budget:
        print_warning(f'Budget "{id}" not found.')
        return

    if fmt == "json":
        console.print_json(json.dumps(budget, indent=2))
        return

    print_header(f"Budget: {budget.get('name', '-')}")

    used = budget.get("used", budget.get("current_usage", 0)) or 0
    limit = budget.get("limit", budget.get("budget_limit", 0)) or 0
    pct = (used / limit * 100) if limit > 0 else 0

    lines = [
        f"[bold]Name:[/bold]       {budget.get('name', '-')}",
        f"[bold]Type:[/bold]       {budget.get('type', budget.get('budget_type', '-'))}",
        f"[bold]Used:[/bold]       {fmt_number(used)}",
        f"[bold]Limit:[/bold]      {fmt_number(limit)}",
        f"[bold]Usage:[/bold]      {pct:.1f}%",
        f"[bold]Resets At:[/bold]  {_short_ts(budget.get('resets_at', budget.get('reset_at')))}",
        f"[bold]Scope:[/bold]      {budget.get('scope', 'global')}",
    ]

    # History / breakdown
    breakdown = budget.get("breakdown", budget.get("usage_by_agent", {}))
    if breakdown and isinstance(breakdown, dict):
        lines.append("")
        lines.append("[bold]Usage Breakdown:[/bold]")
        for k, v in breakdown.items():
            lines.append(f"  {k}: {fmt_number(v)}")

    console.print(Panel("\n".join(lines), border_style="cyan"))

    if limit > 0:
        console.print()
        usage_gauge(budget.get("name", "Budget"), float(used), float(limit))

    console.print()
