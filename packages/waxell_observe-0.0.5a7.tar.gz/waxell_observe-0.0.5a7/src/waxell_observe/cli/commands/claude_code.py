"""Claude Code & Cowork integration commands."""

import click

from .._display import (
    console,
    print_header,
    print_success,
    print_error,
    print_info,
    print_warning,
    status_dot,
    fmt_number,
)
from rich.table import Table


@click.group("claude-code")
def claude_code():
    """Claude Code & Cowork observability integration."""
    pass


@claude_code.command()
@click.option("--global", "global_config", is_flag=True, help="Write to ~/.claude/ (all projects)")
@click.option("--governance", is_flag=True, help="Enable PreToolUse policy enforcement (blocking hooks)")
@click.option("--mcp", is_flag=True, help="Register MCP server in .mcp.json")
@click.option("--project-dir", default=None, help="Project directory (defaults to cwd)")
def setup(global_config: bool, governance: bool, mcp: bool, project_dir: str):
    """Configure Claude Code hooks for Waxell observability.

    Sets up hooks in .claude/settings.json so Claude Code sessions
    are automatically tracked as agent runs in Waxell.

    \b
    Examples:
      wax claude-code setup                    # Basic observability
      wax claude-code setup --governance       # + policy enforcement
      wax claude-code setup --governance --mcp # + MCP tools for Claude
      wax claude-code setup --global           # Apply to all projects
    """
    from ...integrations.claude_code import setup_hooks

    try:
        result = setup_hooks(
            project_dir=project_dir,
            global_config=global_config,
            governance=governance,
            mcp=mcp,
        )
    except Exception as e:
        print_error(f"Setup failed: {e}")
        raise SystemExit(1)

    print_header("Claude Code Integration", "Setup complete")

    for line in result.get("summary", []):
        print_success(line)

    console.print()

    if not governance:
        print_info("Tip: Use --governance to enable policy enforcement (PreToolUse blocking)")
    if not mcp:
        print_info("Tip: Use --mcp to register the MCP server (gives Claude policy-check & budget tools)")

    console.print()
    print_info("Restart Claude Code to activate hooks.")


@claude_code.command()
def hook():
    """Handle a Claude Code hook event (called by hooks, not directly).

    Reads hook JSON from stdin and dispatches to the appropriate handler.
    This command is invoked automatically by Claude Code's hook system.
    """
    from ...integrations.claude_code import handle_hook

    handle_hook()


@claude_code.command("mcp-server")
def mcp_server():
    """Run the MCP server for Claude Code governance tools.

    Provides tools that Claude Code can call proactively:
    - waxell_check_policy: Check if an action is allowed
    - waxell_budget_status: Query session budget
    - waxell_record_decision: Record a decision for audit trail

    This is registered in .mcp.json and launched by Claude Code.
    """
    from ...integrations.claude_code.mcp_server import run_mcp_server

    run_mcp_server()


@claude_code.command()
def status():
    """Show current Claude Code session state and recent activity."""
    from ...integrations.claude_code.state import STATE_DIR, load_state

    if not STATE_DIR.exists():
        print_warning("No active Claude Code sessions found.")
        print_info(f"State directory: {STATE_DIR}")
        return

    state_files = sorted(
        STATE_DIR.glob("*.json"),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )

    if not state_files:
        print_warning("No active Claude Code sessions found.")
        return

    print_header("Claude Code Sessions", f"{len(state_files)} active")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Session ID", style="bold", max_width=20)
    table.add_column("Run ID", max_width=20)
    table.add_column("Model")
    table.add_column("Spans", justify="right")
    table.add_column("Cowork")
    table.add_column("Started")
    table.add_column("CWD", style="dim", max_width=30)

    for sf in state_files[:10]:
        session_id = sf.stem
        state = load_state(session_id)
        if not state:
            continue

        cowork_status = f"{status_dot('active')} Yes" if state.is_cowork else "[dim]No[/dim]"

        table.add_row(
            state.session_id[:18] + "..." if len(state.session_id) > 18 else state.session_id,
            state.run_id[:18] + "..." if len(state.run_id) > 18 else state.run_id,
            state.model or "[dim]-[/dim]",
            fmt_number(state.span_count),
            cowork_status,
            state.started_at[:19] if state.started_at else "[dim]-[/dim]",
            state.cwd or "[dim]-[/dim]",
        )

    console.print(table)
    console.print()


@claude_code.command()
def clean():
    """Remove stale session state files."""
    from ...integrations.claude_code.state import cleanup_stale_states, STATE_DIR

    if not STATE_DIR.exists():
        print_info("No state directory to clean.")
        return

    removed = cleanup_stale_states()
    if removed:
        print_success(f"Removed {removed} stale session state file(s).")
    else:
        print_info("No stale state files found.")
