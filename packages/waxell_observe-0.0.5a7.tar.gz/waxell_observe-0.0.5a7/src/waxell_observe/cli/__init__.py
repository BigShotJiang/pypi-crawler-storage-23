"""Waxell CLI - Observe, govern, and manage your AI agents."""
from collections import OrderedDict
from typing import List, Tuple

import click


class OrderedGroup(click.Group):
    """A Click group that displays commands in sections."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.command_sections: OrderedDict[str, List[str]] = OrderedDict()

    def add_command_to_section(self, cmd: click.Command, name: str, section: str):
        self.add_command(cmd, name)
        if section not in self.command_sections:
            self.command_sections[section] = []
        self.command_sections[section].append(name)

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        commands_by_section: OrderedDict[str, List[Tuple[str, click.Command]]] = OrderedDict()

        for section, cmd_names in self.command_sections.items():
            commands_by_section[section] = []
            for name in cmd_names:
                cmd = self.get_command(ctx, name)
                if cmd is not None:
                    commands_by_section[section].append((name, cmd))

        all_sectioned = set()
        for names in self.command_sections.values():
            all_sectioned.update(names)

        unsectioned = []
        for name in self.list_commands(ctx):
            if name not in all_sectioned:
                cmd = self.get_command(ctx, name)
                if cmd is not None:
                    unsectioned.append((name, cmd))

        if unsectioned:
            commands_by_section["Other Commands"] = unsectioned

        for section, commands in commands_by_section.items():
            if not commands:
                continue
            with formatter.section(section):
                formatter.write_dl(
                    [(name, cmd.get_short_help_str(limit=formatter.width))
                     for name, cmd in commands]
                )


LOCAL_API_URL = "http://localhost:8001"


@click.group(cls=OrderedGroup)
@click.version_option()
@click.option("--local", is_flag=True, help="Use local dev server (localhost:8001)")
@click.option("--profile", "-p", default=None, help="Config profile to use")
@click.pass_context
def cli(ctx, local: bool, profile: str):
    """Waxell CLI - Observe, govern, and manage your AI agents.

    Use 'wax COMMAND --help' for more information on a command.
    """
    ctx.ensure_object(dict)
    ctx.obj["local"] = local
    ctx.obj["profile"] = profile
    if local:
        ctx.obj["api_url_override"] = LOCAL_API_URL


def _register_commands():
    """Register all built-in commands."""
    from .commands.login import login
    from .commands.whoami import whoami
    from .commands.config_cmd import config as config_cmd
    from .commands.keys import keys
    from .commands.test_cmd import test

    # Core Commands
    cli.add_command_to_section(login, "login", "Core Commands")
    cli.add_command_to_section(whoami, "whoami", "Core Commands")
    cli.add_command_to_section(test, "test", "Core Commands")

    # Observability
    from .commands.agents import agents
    from .commands.runs import runs
    from .commands.llm_calls import llm_calls
    from .commands.traces import traces
    from .commands.sessions import sessions
    from .commands.observe_users import observe_users
    from .commands.errors import errors
    from .commands.metrics import metrics
    from .commands.costs import costs

    cli.add_command_to_section(agents, "agents", "Observability")
    cli.add_command_to_section(runs, "runs", "Observability")
    cli.add_command_to_section(llm_calls, "llm-calls", "Observability")
    cli.add_command_to_section(traces, "traces", "Observability")
    cli.add_command_to_section(sessions, "sessions", "Observability")
    cli.add_command_to_section(observe_users, "observe-users", "Observability")
    cli.add_command_to_section(errors, "errors", "Observability")
    cli.add_command_to_section(metrics, "metrics", "Observability")
    cli.add_command_to_section(costs, "costs", "Observability")

    # Governance
    from .commands.governance import policies, kill_switches, budgets
    from .commands.governance_events import governance

    cli.add_command_to_section(policies, "policies", "Governance")
    cli.add_command_to_section(kill_switches, "kill-switches", "Governance")
    cli.add_command_to_section(budgets, "budgets", "Governance")
    cli.add_command_to_section(governance, "governance", "Governance")

    # Organization
    from .commands.teams import teams
    from .commands.users import users
    from .commands.roles import roles
    from .commands.identities import identities
    from .commands.sub_tenants import sub_tenants

    cli.add_command_to_section(teams, "teams", "Organization")
    cli.add_command_to_section(users, "users", "Organization")
    cli.add_command_to_section(roles, "roles", "Organization")
    cli.add_command_to_section(identities, "identities", "Organization")
    cli.add_command_to_section(sub_tenants, "sub-tenants", "Organization")

    # Billing & Configuration
    from .commands.billing import billing
    from .commands.usage import usage
    from .commands.llm_config import llm_config
    from .commands.secrets import secrets

    cli.add_command_to_section(billing, "billing", "Billing")
    cli.add_command_to_section(usage, "usage", "Analytics")

    # Configuration
    cli.add_command_to_section(config_cmd, "config", "Configuration")
    cli.add_command_to_section(keys, "keys", "Configuration")
    cli.add_command_to_section(llm_config, "llm", "Configuration")
    cli.add_command_to_section(secrets, "secrets", "Configuration")

    # Integrations
    from .commands.claude_code import claude_code
    cli.add_command_to_section(claude_code, "claude-code", "Integrations")

    # SDK plugin discovery
    _discover_sdk_plugins()


def _discover_sdk_plugins():
    """If waxell-sdk is installed, register SDK-specific commands."""
    try:
        from waxell_sdk.cli._plugin import register_sdk_commands
        register_sdk_commands(cli)
    except ImportError:
        pass


_register_commands()


if __name__ == "__main__":
    cli()
