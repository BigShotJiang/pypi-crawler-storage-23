"""Waxell Observe Client - HTTP client for the Waxell Observe API.

This is a thin client — all heavy lifting (policy evaluation, metering,
cost calculation) happens on the controlplane.

Configuration priority (highest to lowest):
1. Explicit constructor arguments
2. Global config (WaxellObserveClient.configure())
3. CLI config file (~/.waxell/config)
4. Environment variables (WAXELL_API_URL/WAXELL_API_KEY)

Usage:
    from waxell_observe import WaxellObserveClient

    # Option 1: Configure globally at app startup
    WaxellObserveClient.configure(
        api_url="https://acme.waxell.dev",
        api_key="wax_sk_...",
    )
    client = WaxellObserveClient()

    # Option 2: Per-instance
    client = WaxellObserveClient(
        api_url="https://acme.waxell.dev",
        api_key="wax_sk_...",
    )

    # Start a run
    run = await client.start_run(agent_name="my-agent")
    await client.record_llm_calls(run.run_id, calls=[...])
    await client.complete_run(run.run_id, result={...})
"""

import asyncio
import logging
from typing import ClassVar, Optional

from .config import ObserveConfig
from .types import PolicyCheckResult, PromptInfo, RunInfo

logger = logging.getLogger(__name__)

try:
    from .tracing.propagation import inject_trace_context
except ImportError:

    def inject_trace_context(headers):
        return headers


# Global configuration (set via WaxellObserveClient.configure())
_global_config: Optional[ObserveConfig] = None


class WaxellObserveClient:
    """HTTP client for the Waxell Observe API."""

    def __init__(
        self,
        api_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        self.config = self._resolve_config(api_url, api_key)
        self._http = None
        self._http_warned = False

    # -----------------------------------------------------------------
    # Global configuration
    # -----------------------------------------------------------------

    @classmethod
    def configure(cls, api_url: str, api_key: str) -> None:
        """Set global configuration for all instances.

        Call this once at application startup.
        """
        global _global_config
        _global_config = ObserveConfig(api_url=api_url, api_key=api_key)
        logger.debug(f"WaxellObserveClient configured: {api_url}")

    @classmethod
    def get_config(cls) -> Optional[ObserveConfig]:
        """Get the current global configuration."""
        return _global_config

    @classmethod
    def is_configured(cls) -> bool:
        """Check if global configuration is set and valid."""
        return _global_config is not None and _global_config.is_configured

    # -----------------------------------------------------------------
    # Run lifecycle
    # -----------------------------------------------------------------

    async def start_run(
        self,
        agent_name: str,
        workflow_name: str = "default",
        inputs: Optional[dict] = None,
        metadata: Optional[dict] = None,
        trace_id: str = "",
        user_id: str = "",
        user_group: str = "",
        session_id: str = "",
        parent_workflow_id: str = "",
        root_workflow_id: str = "",
        pre_execution_evaluations: Optional[list] = None,
    ) -> RunInfo:
        """Start an execution run. Returns RunInfo with run_id."""
        body: dict = {
            "agent_name": agent_name,
            "workflow_name": workflow_name,
            "inputs": inputs or {},
            "metadata": metadata or {},
            "trace_id": trace_id,
        }
        if user_id:
            body["user_id"] = user_id
        if user_group:
            body["user_group"] = user_group
        if session_id:
            body["session_id"] = session_id
        if parent_workflow_id:
            body["parent_workflow_id"] = parent_workflow_id
        if root_workflow_id:
            body["root_workflow_id"] = root_workflow_id
        if pre_execution_evaluations:
            body["pre_execution_evaluations"] = pre_execution_evaluations
        data = await self._post(
            "/api/v1/observe/runs/start/",
            body,
        )
        return RunInfo(
            run_id=data.get("run_id", ""),
            workflow_id=data.get("workflow_id", ""),
            started_at=data.get("started_at", ""),
        )

    async def complete_run(
        self,
        run_id: str,
        result: Optional[dict] = None,
        status: str = "success",
        error: str = "",
        error_type: str = "",
        traceback: str = "",
        steps: Optional[list] = None,
        trace_id: str = "",
        root_span_id: str = "",
    ) -> "RunCompleteResult":
        """Complete an execution run. Returns governance info including retry feedback."""
        from .types import RunCompleteResult

        body: dict = {
            "result": result or {},
            "status": status,
            "error": error,
            "steps": steps or [],
        }
        if error_type:
            body["error_type"] = error_type
        if traceback:
            body["traceback"] = traceback
        if trace_id:
            body["trace_id"] = trace_id
        if root_span_id:
            body["root_span_id"] = root_span_id

        data = await self._post(
            f"/api/v1/observe/runs/{run_id}/complete/",
            body,
        )
        gov = data.get("governance", {}) if isinstance(data, dict) else {}
        return RunCompleteResult(
            run_id=str(data.get("run_id", run_id)) if isinstance(data, dict) else run_id,
            duration=data.get("duration") if isinstance(data, dict) else None,
            governance_action=gov.get("action", "allow"),
            governance_reason=gov.get("reason", ""),
            retry_feedback=gov.get("retry_feedback", ""),
            max_retries=gov.get("max_retries", 0),
        )

    # -----------------------------------------------------------------
    # LLM calls
    # -----------------------------------------------------------------

    async def record_llm_calls(
        self,
        run_id: str,
        calls: list[dict],
    ) -> dict:
        """Record one or more LLM calls for a run. Returns server response."""
        if not calls:
            return {}
        return await self._post(
            f"/api/v1/observe/runs/{run_id}/llm-calls/",
            {"calls": calls},
        )

    # -----------------------------------------------------------------
    # Steps
    # -----------------------------------------------------------------

    async def record_steps(
        self,
        run_id: str,
        steps: list[dict],
    ) -> dict:
        """Record execution steps for a run. Returns server response."""
        if not steps:
            return {}
        return await self._post(
            f"/api/v1/observe/runs/{run_id}/steps/",
            {"steps": steps},
        )

    # -----------------------------------------------------------------
    # Policy check
    # -----------------------------------------------------------------

    async def check_policy(
        self,
        agent_name: str,
        workflow_name: str = "",
        agent_id: str = "",
    ) -> PolicyCheckResult:
        """Check if execution is allowed by policies.

        Returns a PolicyCheckResult with action ("allow", "block", "warn", "throttle").
        """
        data = await self._post(
            "/api/v1/observe/policy-check/",
            {
                "agent_name": agent_name,
                "workflow_name": workflow_name,
                "agent_id": agent_id,
            },
        )
        return PolicyCheckResult(
            action=data.get("action", "allow"),
            reason=data.get("reason", ""),
            metadata=data.get("metadata", {}),
            evaluations=data.get("evaluations", []),
        )

    # -----------------------------------------------------------------
    # Prompt guard
    # -----------------------------------------------------------------

    async def prompt_guard(
        self,
        text: str,
        agent_name: str = "",
        model: str = "",
    ) -> dict:
        """Check a prompt against the server-side guard (ML-powered detection).

        Returns a dict with action, violations, redacted_text, scan_time_ms.
        """
        return await self._post(
            "/api/v1/observe/prompt-guard/",
            {
                "text": text,
                "agent_name": agent_name,
                "model": model,
            },
        )

    def prompt_guard_sync(self, **kwargs) -> dict:
        """Synchronous version of prompt_guard."""
        return self._run_sync(self.prompt_guard(**kwargs))

    # -----------------------------------------------------------------
    # Scores
    # -----------------------------------------------------------------

    async def record_scores(
        self,
        run_id: str,
        scores: list[dict],
    ) -> dict:
        """Record scores for a run. Returns server response."""
        if not scores:
            return {}
        return await self._post(
            f"/api/v1/observe/runs/{run_id}/scores/",
            {"scores": scores},
        )

    # -----------------------------------------------------------------
    # Behavior spans
    # -----------------------------------------------------------------

    async def record_spans(
        self,
        run_id: str,
        spans: list[dict],
    ) -> dict:
        """Record behavior spans (tool calls, decisions, etc.) for a run."""
        if not spans:
            return {}
        return await self._post(
            f"/api/v1/observe/runs/{run_id}/spans/",
            {"spans": spans},
        )

    # -----------------------------------------------------------------
    # Events
    # -----------------------------------------------------------------

    async def record_events(self, events: list[dict]) -> None:
        """Record governance events."""
        if not events:
            return
        await self._post("/api/v1/observe/events/", {"events": events})

    # -----------------------------------------------------------------
    # Prompts
    # -----------------------------------------------------------------

    async def get_prompt(
        self,
        name: str,
        *,
        label: str = "",
        version: int = 0,
    ) -> PromptInfo:
        """Fetch a prompt from the controlplane.

        Args:
            name: Prompt name.
            label: Label to fetch (e.g. "production"). If empty, fetches latest.
            version: Specific version number. Takes precedence over label.

        Returns:
            PromptInfo with content, config, and compile() helper.
        """
        params: dict = {}
        if label:
            params["label"] = label
        if version:
            params["version"] = version

        data = await self._get(
            f"/api/v1/observe/prompts/{name}/",
            params=params,
        )
        return PromptInfo(
            name=data.get("name", name),
            version=data.get("version", 0),
            prompt_type=data.get("prompt_type", "text"),
            content=data.get("content", ""),
            config=data.get("config", {}),
            labels=data.get("labels", []),
        )

    # -----------------------------------------------------------------
    # Sync wrappers
    # -----------------------------------------------------------------

    def start_run_sync(self, **kwargs) -> RunInfo:
        """Synchronous version of start_run."""
        return self._run_sync(self.start_run(**kwargs))

    def complete_run_sync(self, **kwargs) -> "RunCompleteResult":
        """Synchronous version of complete_run."""
        return self._run_sync(self.complete_run(**kwargs))

    def record_llm_calls_sync(self, **kwargs) -> dict:
        """Synchronous version of record_llm_calls."""
        return self._run_sync(self.record_llm_calls(**kwargs))

    def record_steps_sync(self, **kwargs) -> dict:
        """Synchronous version of record_steps."""
        return self._run_sync(self.record_steps(**kwargs))

    def check_policy_sync(self, **kwargs) -> PolicyCheckResult:
        """Synchronous version of check_policy."""
        return self._run_sync(self.check_policy(**kwargs))

    def record_scores_sync(self, **kwargs) -> dict:
        """Synchronous version of record_scores."""
        return self._run_sync(self.record_scores(**kwargs))

    def record_spans_sync(self, **kwargs) -> dict:
        """Synchronous version of record_spans."""
        return self._run_sync(self.record_spans(**kwargs))

    def record_events_sync(self, **kwargs) -> None:
        """Synchronous version of record_events."""
        self._run_sync(self.record_events(**kwargs))

    def get_prompt_sync(self, **kwargs) -> PromptInfo:
        """Synchronous version of get_prompt."""
        return self._run_sync(self.get_prompt(**kwargs))

    # -----------------------------------------------------------------
    # Internal HTTP
    # -----------------------------------------------------------------

    _RETRY_MAX_ATTEMPTS: ClassVar[int] = 3
    _RETRY_BASE_DELAY: ClassVar[float] = 1.0  # seconds

    async def _post(self, path: str, data: dict) -> dict:
        """POST to the controlplane API with exponential backoff retry."""
        if not self.config.is_configured:
            logger.warning(
                "Waxell Observe client not configured. "
                "Call WaxellObserveClient.configure() or set "
                "WAXELL_API_URL/WAXELL_API_KEY environment variables."
            )
            return {}

        import httpx

        url = f"{self.config.api_url.rstrip('/')}{path}"

        headers = {
            "X-Wax-Key": self.config.api_key,
            "Content-Type": "application/json",
        }
        try:
            inject_trace_context(headers)
        except Exception:
            pass  # Never let trace propagation break HTTP calls

        last_exception: Optional[Exception] = None
        for attempt in range(1, self._RETRY_MAX_ATTEMPTS + 1):
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    response = await client.post(url, json=data, headers=headers)
                    response.raise_for_status()
                    return response.json() if response.text else {}
            except httpx.HTTPStatusError as e:
                if e.response.status_code < 500:
                    # 4xx errors are not transient — do not retry
                    logger.warning(
                        "Waxell API error: %s %s -> %d: %s",
                        "POST",
                        path,
                        e.response.status_code,
                        e.response.text[:200] if e.response.text else "",
                    )
                    return {}
                # 5xx — retryable
                last_exception = e
                if attempt < self._RETRY_MAX_ATTEMPTS:
                    delay = self._RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    logger.debug(
                        "Waxell API 5xx on POST %s (attempt %d/%d, status %d). "
                        "Retrying in %.1fs...",
                        path,
                        attempt,
                        self._RETRY_MAX_ATTEMPTS,
                        e.response.status_code,
                        delay,
                    )
                    await asyncio.sleep(delay)
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_exception = e
                if attempt < self._RETRY_MAX_ATTEMPTS:
                    delay = self._RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    logger.debug(
                        "Waxell API transient error on POST %s (attempt %d/%d: %s). "
                        "Retrying in %.1fs...",
                        path,
                        attempt,
                        self._RETRY_MAX_ATTEMPTS,
                        type(e).__name__,
                        delay,
                    )
                    await asyncio.sleep(delay)

        # All retries exhausted — fall through to existing silent failure behavior
        if isinstance(last_exception, httpx.HTTPStatusError):
            logger.warning(
                "Waxell API error: %s %s -> %d: %s",
                "POST",
                path,
                last_exception.response.status_code,
                last_exception.response.text[:200] if last_exception.response.text else "",
            )
        elif last_exception is not None:
            if not self._http_warned:
                logger.warning(
                    "Waxell backend unreachable (%s): %s. "
                    "Telemetry will be dropped. "
                    "Further connection errors will be suppressed.",
                    path,
                    last_exception,
                )
                self._http_warned = True
        return {}

    async def _get(self, path: str, params: Optional[dict] = None) -> dict:
        """GET from the controlplane API with exponential backoff retry."""
        if not self.config.is_configured:
            logger.warning(
                "Waxell Observe client not configured. "
                "Call WaxellObserveClient.configure() or set "
                "WAXELL_API_URL/WAXELL_API_KEY environment variables."
            )
            return {}

        import httpx

        url = f"{self.config.api_url.rstrip('/')}{path}"

        headers = {
            "X-Wax-Key": self.config.api_key,
        }
        try:
            inject_trace_context(headers)
        except Exception:
            pass

        last_exception: Optional[Exception] = None
        for attempt in range(1, self._RETRY_MAX_ATTEMPTS + 1):
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    response = await client.get(url, params=params, headers=headers)
                    response.raise_for_status()
                    return response.json() if response.text else {}
            except httpx.HTTPStatusError as e:
                if e.response.status_code < 500:
                    # 4xx errors are not transient — do not retry
                    logger.warning(
                        "Waxell API error: %s %s -> %d: %s",
                        "GET",
                        path,
                        e.response.status_code,
                        e.response.text[:200] if e.response.text else "",
                    )
                    return {}
                # 5xx — retryable
                last_exception = e
                if attempt < self._RETRY_MAX_ATTEMPTS:
                    delay = self._RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    logger.debug(
                        "Waxell API 5xx on GET %s (attempt %d/%d, status %d). "
                        "Retrying in %.1fs...",
                        path,
                        attempt,
                        self._RETRY_MAX_ATTEMPTS,
                        e.response.status_code,
                        delay,
                    )
                    await asyncio.sleep(delay)
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_exception = e
                if attempt < self._RETRY_MAX_ATTEMPTS:
                    delay = self._RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    logger.debug(
                        "Waxell API transient error on GET %s (attempt %d/%d: %s). "
                        "Retrying in %.1fs...",
                        path,
                        attempt,
                        self._RETRY_MAX_ATTEMPTS,
                        type(e).__name__,
                        delay,
                    )
                    await asyncio.sleep(delay)

        # All retries exhausted — fall through to existing silent failure behavior
        if isinstance(last_exception, httpx.HTTPStatusError):
            logger.warning(
                "Waxell API error: %s %s -> %d: %s",
                "GET",
                path,
                last_exception.response.status_code,
                last_exception.response.text[:200] if last_exception.response.text else "",
            )
        elif last_exception is not None:
            if not self._http_warned:
                logger.warning(
                    "Waxell backend unreachable (%s): %s. "
                    "Telemetry will be dropped. "
                    "Further connection errors will be suppressed.",
                    path,
                    last_exception,
                )
                self._http_warned = True
        return {}

    async def close(self) -> None:
        """Close the HTTP client (no-op, clients are per-request)."""
        pass

    # -----------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------

    @staticmethod
    def _resolve_config(
        api_url: Optional[str],
        api_key: Optional[str],
    ) -> ObserveConfig:
        """Resolve configuration from multiple sources."""
        global _global_config

        # Start with environment (lowest priority)
        config = ObserveConfig.from_env()

        # Layer CLI config on top
        cli_config = ObserveConfig.from_cli_config()
        if cli_config.api_url:
            config.api_url = cli_config.api_url
        if cli_config.api_key:
            config.api_key = cli_config.api_key

        # Layer global config on top
        if _global_config:
            if _global_config.api_url:
                config.api_url = _global_config.api_url
            if _global_config.api_key:
                config.api_key = _global_config.api_key

        # Override with explicit arguments (highest priority)
        if api_url:
            config.api_url = api_url
        if api_key:
            config.api_key = api_key

        return config

    @staticmethod
    def _run_sync(coro):
        """Run an async coroutine synchronously.

        Handles Jupyter notebooks and other environments with
        running event loops by delegating to a background thread.
        """
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            # No running event loop -- normal sync context
            return asyncio.run(coro)

        # Running event loop detected (Jupyter, uvicorn, etc.)
        # Run the coroutine in a separate thread to avoid blocking
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result(timeout=60)
