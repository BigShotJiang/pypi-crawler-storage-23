"""@waxell_agent decorator for wrapping any function with observability.

Usage:
    @waxell_agent(agent_name="my-agent")
    async def run_agent(query: str) -> str:
        return "result"

    # With context injection:
    @waxell_agent(agent_name="my-agent")
    async def run_agent(query: str, waxell_ctx=None) -> str:
        if waxell_ctx:
            waxell_ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
        return "result"
"""

import asyncio
import functools
import inspect
import json
import logging
from typing import Optional

from .client import WaxellObserveClient
from .context import WaxellContext

logger = logging.getLogger(__name__)

# WaxellContext parameter names that can be overridden at call time.
# If a kwarg matches one of these AND the wrapped function doesn't declare
# it in its signature, the decorator intercepts it and passes it to
# WaxellContext instead of the wrapped function.
_CONTEXT_PARAMS = frozenset({
    "session_id", "user_id", "user_group", "enforce_policy",
    "mid_execution_governance", "client", "inputs", "metadata",
    "workflow_name",
})


def waxell_agent(
    agent_name: Optional[str] = None,
    workflow_name: str = "default",
    enforce_policy: bool = True,
    capture_io: bool = True,
    session_id: str = "",
    user_id: str = "",
    user_group: str = "",
    client: Optional[WaxellObserveClient] = None,
    mid_execution_governance: bool = False,
):
    """Decorator to add Waxell governance and telemetry to any function.

    Args:
        agent_name: Name for this agent. Defaults to the function name.
        workflow_name: Workflow name for grouping runs.
        enforce_policy: Check policies before execution. Raises PolicyViolationError if blocked.
        capture_io: Capture function inputs/outputs in the run record.
        session_id: Optional session ID for grouping related runs.
        client: Optional pre-configured client instance.
        mid_execution_governance: If True, flush data on record_step() and halt on policy block.
    """

    def decorator(func):
        _agent_name = agent_name or func.__name__
        _is_async = inspect.iscoroutinefunction(func)
        # Parameters the wrapped function explicitly declares — these are
        # passed to the function even if they overlap with _CONTEXT_PARAMS.
        _func_params = set(inspect.signature(func).parameters.keys())

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Extract context overrides from kwargs.  Only intercept keys
            # that the wrapped function does NOT declare in its signature.
            ctx_overrides: dict = {}
            for key in list(kwargs):
                if key in _CONTEXT_PARAMS and key not in _func_params:
                    ctx_overrides[key] = kwargs.pop(key)

            _inputs = ctx_overrides.pop("inputs", None)
            if _inputs is None:
                _inputs = _build_inputs(args, kwargs) if capture_io else {}

            async with WaxellContext(
                agent_name=_agent_name,
                workflow_name=ctx_overrides.get("workflow_name", workflow_name),
                inputs=_inputs,
                enforce_policy=ctx_overrides.get("enforce_policy", enforce_policy),
                client=ctx_overrides.get("client", client),
                session_id=ctx_overrides.get("session_id", session_id),
                user_id=ctx_overrides.get("user_id", user_id),
                user_group=ctx_overrides.get("user_group", user_group),
                mid_execution_governance=ctx_overrides.get("mid_execution_governance", mid_execution_governance),
                metadata=ctx_overrides.get("metadata", None),
            ) as ctx:
                # Inject context if the function accepts it
                sig = inspect.signature(func)
                if "waxell_ctx" in sig.parameters:
                    kwargs["waxell_ctx"] = ctx

                if _is_async:
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)

                if capture_io and result is not None:
                    ctx.set_result(_safe_serialize(result))

                return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                # No running event loop -- normal sync context
                return asyncio.run(async_wrapper(*args, **kwargs))

            # Running event loop detected (Jupyter, uvicorn, etc.)
            # Run the coroutine in a separate thread to avoid blocking
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, async_wrapper(*args, **kwargs))
                return future.result(timeout=300)

        if _is_async:
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


def _build_inputs(args: tuple, kwargs: dict) -> dict:
    """Build a serializable inputs dict from function arguments."""
    inputs = {}
    if args:
        inputs["args"] = [_safe_value(a) for a in args]
    if kwargs:
        inputs["kwargs"] = {k: _safe_value(v) for k, v in kwargs.items()}
    return inputs


def _safe_value(v):
    """Convert a value to something JSON-serializable."""
    if isinstance(v, (str, int, float, bool, type(None))):
        return v
    if isinstance(v, (list, tuple)):
        return [_safe_value(i) for i in v]
    if isinstance(v, dict):
        return {str(k): _safe_value(val) for k, val in v.items()}
    return str(v)


def _safe_serialize(result) -> dict:
    """Convert a function result to a serializable dict."""
    if isinstance(result, dict):
        return result
    if isinstance(result, str):
        return {"output": result}
    try:
        return {"output": json.loads(json.dumps(result, default=str))}
    except (TypeError, ValueError):
        return {"output": str(result)}


# Convenience alias -- `@observe(...)` reads better for users who
# do not need the "waxell_agent" naming convention.
observe = waxell_agent
