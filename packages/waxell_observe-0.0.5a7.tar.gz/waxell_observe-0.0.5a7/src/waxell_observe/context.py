"""WaxellContext — context manager for manual instrumentation.

Usage:
    # Async
    async with WaxellContext(agent_name="my-agent") as ctx:
        result = await my_agent.run(input)
        ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
        ctx.set_result({"output": result})

    # Sync (native — ContextVar stays in calling thread for auto-instrumentation)
    with WaxellContext(agent_name="my-agent") as ctx:
        result = my_agent.run(input)
        ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
"""

import logging
import time
import traceback as _traceback_mod
import uuid
from contextvars import Token
from typing import Any, Optional

from .client import WaxellObserveClient
from .cost import estimate_cost
from .errors import PolicyViolationError
from .tracing._compat import _HAS_OTEL, NoOpSpan
from .tracing.attributes import WaxellAttributes
from .tracing.spans import (
    _infer_provider,
    start_agent_span,
    start_decision_span,
    start_governance_span,
    start_llm_span,
    start_reasoning_span,
    start_retrieval_span,
    start_retry_span,
    start_step_span,
    start_tool_span,
)
from .types import PolicyCheckResult, RunInfo

logger = logging.getLogger(__name__)


def generate_session_id() -> str:
    """Generate a random session ID.

    Returns a string like ``sess_a1b2c3d4e5f6g7h8``.
    """
    return f"sess_{uuid.uuid4().hex[:16]}"


class WaxellContext:
    """Context manager that wraps agent execution with observability and governance.

    On enter:
    - Checks policies (if enforce_policy=True)
    - Starts an execution run on the controlplane
    - Creates an OTel agent span (if tracing is initialized)

    On exit:
    - Flushes buffered LLM calls and steps
    - Completes the run (with result or error)
    - Ends the OTel agent span
    """

    def __init__(
        self,
        agent_name: str,
        workflow_name: str = "default",
        inputs: Optional[dict] = None,
        metadata: Optional[dict] = None,
        client: Optional[WaxellObserveClient] = None,
        enforce_policy: bool = True,
        session_id: str = "",
        user_id: str = "",
        user_group: str = "",
        mid_execution_governance: bool = False,
    ):
        self.agent_name = agent_name
        self.workflow_name = workflow_name
        self.inputs = inputs or {}
        self.metadata = metadata or {}
        self.enforce_policy = enforce_policy
        self._mid_execution_governance = mid_execution_governance

        # Inherit session/user/client from parent context when not provided.
        # This ensures child agents in a nested @observe pipeline share
        # session_id, user_id, user_group, and the observe client with the
        # parent — so all runs appear linked in the controlplane table.
        parent_ctx = self._get_parent_ctx()
        self.client = client or (parent_ctx.client if parent_ctx else None) or WaxellObserveClient()
        self.session_id = session_id or (parent_ctx.session_id if parent_ctx else "")
        self.user_id = user_id or (parent_ctx.user_id if parent_ctx else "")
        self.user_group = user_group or (parent_ctx.user_group if parent_ctx else "")

        self._run_info: Optional[RunInfo] = None
        self._llm_calls: list[dict] = []
        self._steps: list[dict] = []
        self._spans: list[dict] = []
        self._otel_spans: list[dict] = []  # Populated by WaxellSpanProcessor
        self._governance_spans: list[dict] = []
        self._result: dict = {}
        self._step_counter: int = 0
        self._span = None
        self._otel_token = None
        self._otel_trace_id: str = ""
        self._otel_span_id: str = ""
        self._context_start_ms: float = 0.0
        self._context_start_wall_ms: float = 0.0  # wall-clock ms for OTel offset calc
        self._current_step_position: int | None = None
        self._tags: dict[str, str] = {}
        self._metadata_kv: dict[str, Any] = {}
        self._scores: list[dict] = []
        self._governance_blocked: bool = False
        self._governance_reason: str = ""
        self._context_token: Optional[Token] = None
        self._root_workflow_id: str = ""
        self._parent_ctx_ref: Optional["WaxellContext"] = None
        self._total_tokens_in: int = 0
        self._total_tokens_out: int = 0
        self._total_cost: float = 0.0
        self._total_llm_calls: int = 0
        self._auto_recorded_counts: dict[tuple, int] = {}  # dedup auto vs manual

    # -----------------------------------------------------------------
    # Shared helpers (pure sync, no I/O — used by both async and sync paths)
    # -----------------------------------------------------------------

    @staticmethod
    def _get_parent_ctx() -> Optional["WaxellContext"]:
        """Return the active parent WaxellContext, or None."""
        try:
            from .instrumentors._context_var import _current_context
            return _current_context.get()
        except Exception:
            return None

    def _detect_parent_context(self) -> tuple[str, str]:
        """Detect parent WaxellContext for automatic lineage.

        Returns ``(parent_workflow_id, root_workflow_id)``.
        Pure ContextVar read — no I/O.
        """
        parent_workflow_id = ""
        root_workflow_id = ""
        try:
            from .instrumentors._context_var import _current_context

            parent_ctx = _current_context.get()
            if parent_ctx is not None and parent_ctx._run_info:
                parent_workflow_id = parent_ctx._run_info.workflow_id
                root_workflow_id = (
                    getattr(parent_ctx, "_root_workflow_id", "") or parent_workflow_id
                )
        except Exception:
            pass
        return parent_workflow_id, root_workflow_id

    def _start_run_kwargs(
        self, parent_workflow_id: str, root_workflow_id: str,
    ) -> dict:
        """Build kwargs dict for start_run / start_run_sync."""
        kwargs: dict = dict(
            agent_name=self.agent_name,
            workflow_name=self.workflow_name,
            inputs=self.inputs,
            metadata=self.metadata,
            user_id=self.user_id,
            user_group=self.user_group,
            session_id=self.session_id,
            parent_workflow_id=parent_workflow_id,
            root_workflow_id=root_workflow_id,
            pre_execution_evaluations=self._pre_execution_evaluations or None,
        )
        return kwargs

    def _post_start_run(self, root_workflow_id: str) -> None:
        """Finalize state after start_run returns. No I/O."""
        self._root_workflow_id = root_workflow_id or (
            self._run_info.workflow_id if self._run_info else ""
        )
        if self._run_info and not self._run_info.run_id:
            logger.warning(
                "start_run returned empty run_id for agent=%s — "
                "the controlplane may be down or returned an error. "
                "Telemetry for this run will be dropped.",
                self.agent_name,
            )

    def _create_otel_span(self) -> None:
        """Create and activate the OTel agent span. No I/O."""
        try:
            extra_attrs = {}
            if self.session_id:
                extra_attrs[WaxellAttributes.SESSION_ID] = self.session_id
            if self.user_id:
                extra_attrs[WaxellAttributes.USER_ID] = self.user_id
            if self.user_group:
                extra_attrs[WaxellAttributes.USER_GROUP] = self.user_group

            self._span = start_agent_span(
                agent_name=self.agent_name,
                workflow_name=self.workflow_name,
                run_id=self._run_info.run_id if self._run_info else "",
                extra_attrs=extra_attrs,
            )
        except Exception:
            self._span = NoOpSpan()

        # Extract OTel trace context for correlation with the HTTP run record
        self._otel_trace_id, self._otel_span_id = self._extract_otel_trace_context()

        # Activate span as current context for child span parenting
        if _HAS_OTEL and self._span and not isinstance(self._span, NoOpSpan):
            try:
                from opentelemetry import trace as trace_api, context as context_api

                ctx = trace_api.set_span_in_context(self._span)
                self._otel_token = context_api.attach(ctx)
            except Exception:
                pass

    def _extract_otel_trace_context(self) -> tuple[str, str]:
        """Extract trace_id and span_id from the OTel agent span.

        Returns (trace_id_hex, span_id_hex) or ("", "") if unavailable.
        """
        if _HAS_OTEL and self._span and not isinstance(self._span, NoOpSpan):
            try:
                ctx = self._span.get_span_context()
                if ctx and ctx.trace_id:
                    trace_id = format(ctx.trace_id, "032x")
                    span_id = format(ctx.span_id, "016x")
                    return trace_id, span_id
            except Exception:
                pass
        return "", ""

    def _elapsed_ms(self) -> int:
        """Milliseconds elapsed since context entry."""
        if self._context_start_ms == 0.0:
            return 0
        return int(time.monotonic() * 1000 - self._context_start_ms)

    def _activate_context_var(self) -> None:
        """Set self as current WaxellContext for instrumentor dual-path recording."""
        try:
            from .instrumentors._context_var import _current_context

            self._context_token = _current_context.set(self)
        except Exception:
            pass

    def _emit_governance_otel_spans(self) -> None:
        """Emit OTel spans for pre-execution policy evaluations.

        Server stores governance events+spans during start_run; here we only
        emit OTel spans for the dual-path observability pipeline.
        """
        for ev in self._pre_execution_evaluations:
            try:
                span = start_governance_span(
                    policy_name=ev.get("policy_name", "unknown"),
                    action=ev.get("action", "allow"),
                    category=ev.get("category", ""),
                )
                reason = ev.get("reason", "")
                if reason:
                    span.set_attribute("waxell.policy.reason", reason)
                span.end()
            except Exception:
                pass

    def _determine_exit_status(
        self, exc_type, exc_val, exc_tb=None
    ) -> tuple[str, str, str, str]:
        """Compute run status, error message, error type, and traceback on exit.

        Returns (status, error_message, error_type, traceback_str).
        """
        if self._governance_blocked and not exc_type:
            return "error", f"Policy violation: {self._governance_reason}", "PolicyViolationError", ""
        status = "error" if exc_type else "success"
        error = str(exc_val) if exc_val else ""
        error_type = exc_type.__name__ if exc_type else ""
        tb_str = ""
        if exc_type and exc_val and exc_tb:
            try:
                tb_str = "".join(_traceback_mod.format_exception(exc_type, exc_val, exc_tb))
            except Exception:
                tb_str = ""
        return status, error, error_type, tb_str

    def _end_otel_span(self, exc_type, exc_val) -> None:
        """End the OTel span and set status."""
        if self._span and not isinstance(self._span, NoOpSpan):
            try:
                if _HAS_OTEL:
                    from opentelemetry.trace import StatusCode, Status

                    if exc_type:
                        self._span.set_status(Status(StatusCode.ERROR, str(exc_val)))
                        self._span.record_exception(exc_val)
                    else:
                        self._span.set_status(Status(StatusCode.OK))
                self._span.end()
            except Exception:
                pass

    def _detach_otel_context(self) -> None:
        """Detach OTel context token."""
        if self._otel_token is not None:
            try:
                from opentelemetry import context as context_api

                context_api.detach(self._otel_token)
            except Exception:
                pass
            self._otel_token = None

    def _clear_context_var(self) -> None:
        """Reset the ContextVar token."""
        if self._context_token is not None:
            try:
                from .instrumentors._context_var import _current_context

                _current_context.reset(self._context_token)
            except Exception:
                pass
            self._context_token = None

    def _inject_summary_into_parent(self, status: str) -> None:
        """Inject a summary span into the parent context's span buffer.

        Called from __aexit__/__exit__ after flushing own data. The parent
        has not yet exited, so its _spans buffer is still collecting spans
        that will be flushed when the parent exits.
        """
        parent = self._parent_ctx_ref
        if not parent or not parent._run_info:
            return

        parent._step_counter += 1

        # Calculate time offset relative to parent's start
        start_offset = 0
        if parent._context_start_ms and self._context_start_ms:
            start_offset = max(0, int(self._context_start_ms - parent._context_start_ms))

        parent._spans.append({
            "name": f"{self.agent_name}.{self.workflow_name}",
            "kind": "agent",
            "status": "error" if status == "error" else "ok",
            "duration_ms": self._elapsed_ms(),
            "position": parent._step_counter,
            "start_offset_ms": start_offset,
            "parent_position": parent._current_step_position,
            "attributes": {
                "agent_name": self.agent_name,
                "workflow_name": self.workflow_name,
                "child_run_id": self.run_id,
                "tokens_in": self._total_tokens_in,
                "tokens_out": self._total_tokens_out,
                "total_tokens": self._total_tokens_in + self._total_tokens_out,
                "cost": round(self._total_cost, 6),
                "llm_calls": self._total_llm_calls,
            },
            "input_data": self.inputs if self.inputs else None,
            "output_data": self._result if self._result else None,
        })

        # Transitive rollup: grandchild -> child -> parent
        parent._total_tokens_in += self._total_tokens_in
        parent._total_tokens_out += self._total_tokens_out
        parent._total_cost += self._total_cost
        parent._total_llm_calls += self._total_llm_calls

    # -----------------------------------------------------------------
    # Async context manager
    # -----------------------------------------------------------------

    async def __aenter__(self) -> "WaxellContext":
        # 1. Check policy
        self._pre_execution_evaluations: list[dict] = []
        if self.enforce_policy:
            policy = await self.client.check_policy(
                agent_name=self.agent_name,
                workflow_name=self.workflow_name,
            )
            self._pre_execution_evaluations = policy.evaluations or []
            if policy.blocked:
                try:
                    run_info = await self.client.start_run(
                        agent_name=self.agent_name,
                        workflow_name=self.workflow_name,
                        inputs=self.inputs,
                        metadata=self.metadata,
                        user_id=self.user_id,
                        user_group=self.user_group,
                        session_id=self.session_id,
                        pre_execution_evaluations=self._pre_execution_evaluations or None,
                    )
                    if run_info and run_info.run_id:
                        await self.client.complete_run(
                            run_id=run_info.run_id,
                            status="blocked",
                            error=f"Policy violation: {policy.reason}",
                            result={"blocked_by": policy.reason},
                        )
                except Exception:
                    logger.debug(
                        "Failed to record blocked run for agent=%s: %s",
                        self.agent_name,
                        policy.reason,
                        exc_info=True,
                    )
                raise PolicyViolationError(policy.reason, policy)

        # 2. Save parent reference + detect lineage + start run
        try:
            from .instrumentors._context_var import _current_context
            self._parent_ctx_ref = _current_context.get()
        except Exception:
            self._parent_ctx_ref = None

        parent_workflow_id, root_workflow_id = self._detect_parent_context()
        self._run_info = await self.client.start_run(
            **self._start_run_kwargs(parent_workflow_id, root_workflow_id),
        )
        self._post_start_run(root_workflow_id)

        # 3. OTel span, ContextVar activation, governance spans
        self._create_otel_span()
        self._activate_context_var()
        self._emit_governance_otel_spans()
        self._context_start_ms = time.monotonic() * 1000
        self._context_start_wall_ms = time.time() * 1000
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        status, error, error_type, tb_str = self._determine_exit_status(exc_type, exc_val, exc_tb)
        self._end_otel_span(exc_type, exc_val)
        self._detach_otel_context()
        self._clear_context_var()

        if not self._run_info or not self._run_info.run_id:
            return False

        try:
            if self._llm_calls:
                await self.client.record_llm_calls(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
            if self._steps:
                await self.client.record_steps(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
            if self._scores:
                await self.client.record_scores(
                    run_id=self._run_info.run_id,
                    scores=self._scores,
                )
            # Merge auto-instrumented OTel spans (deduplicating LLM spans
            # that were already recorded via record_llm_call)
            self._merge_otel_spans()
            # Remove placeholder retrieval spans from auto-instrumentors
            # when the user has explicit @waxell.retrieval with real data
            self._deduplicate_retrieval_spans()

            # Insert root agent span with total duration
            root_span = {
                "name": f"{self.agent_name}.{self.workflow_name}",
                "kind": "agent",
                "status": "error" if exc_type else "ok",
                "duration_ms": self._elapsed_ms(),
                "position": 0,
                "start_offset_ms": 0,
                "parent_position": None,
                "attributes": {
                    "agent_name": self.agent_name,
                    "workflow_name": self.workflow_name,
                },
                "input_data": self.inputs if self.inputs else None,
                "output_data": self._result if self._result else None,
            }
            if exc_type:
                root_span["attributes"]["error.type"] = error_type
                root_span["attributes"]["error.message"] = error
                root_span["events"] = [{
                    "name": "exception",
                    "attributes": {
                        "exception.type": error_type,
                        "exception.message": error,
                        "exception.stacktrace": tb_str,
                    },
                }]
            self._spans.insert(0, root_span)
            if self._spans:
                await self.client.record_spans(
                    run_id=self._run_info.run_id,
                    spans=self._spans,
                )
            await self.client.complete_run(
                run_id=self._run_info.run_id,
                result=self._result,
                status=status,
                error=error,
                error_type=error_type,
                traceback=tb_str,
                trace_id=self._otel_trace_id,
                root_span_id=self._otel_span_id,
            )
        except Exception as e:
            logger.warning(f"Failed to flush observe context: {e}")

        # Inject summary span into parent's trace buffer
        try:
            self._inject_summary_into_parent(status)
        except Exception:
            logger.debug(
                "Failed to inject summary into parent for agent=%s",
                self.agent_name,
                exc_info=True,
            )

        return False  # Don't suppress exceptions

    # -----------------------------------------------------------------
    # Sync context manager
    # -----------------------------------------------------------------

    def __enter__(self) -> "WaxellContext":
        # 1. Check policy (sync I/O)
        self._pre_execution_evaluations: list[dict] = []
        if self.enforce_policy:
            policy = self.client.check_policy_sync(
                agent_name=self.agent_name,
                workflow_name=self.workflow_name,
            )
            self._pre_execution_evaluations = policy.evaluations or []
            if policy.blocked:
                try:
                    run_info = self.client.start_run_sync(
                        agent_name=self.agent_name,
                        workflow_name=self.workflow_name,
                        inputs=self.inputs,
                        metadata=self.metadata,
                        user_id=self.user_id,
                        user_group=self.user_group,
                        session_id=self.session_id,
                        pre_execution_evaluations=self._pre_execution_evaluations or None,
                    )
                    if run_info and run_info.run_id:
                        self.client.complete_run_sync(
                            run_id=run_info.run_id,
                            status="blocked",
                            error=f"Policy violation: {policy.reason}",
                            result={"blocked_by": policy.reason},
                        )
                except Exception:
                    logger.debug(
                        "Failed to record blocked run for agent=%s: %s",
                        self.agent_name,
                        policy.reason,
                        exc_info=True,
                    )
                raise PolicyViolationError(policy.reason, policy)

        # 2. Save parent reference + detect lineage + start run (sync I/O)
        try:
            from .instrumentors._context_var import _current_context
            self._parent_ctx_ref = _current_context.get()
        except Exception:
            self._parent_ctx_ref = None

        parent_workflow_id, root_workflow_id = self._detect_parent_context()
        self._run_info = self.client.start_run_sync(
            **self._start_run_kwargs(parent_workflow_id, root_workflow_id),
        )
        self._post_start_run(root_workflow_id)

        # 3. OTel span, ContextVar activation, governance spans
        #    All pure sync — executed in the calling thread so auto-instrumentors
        #    see _current_context via ContextVar.
        self._create_otel_span()
        self._activate_context_var()
        self._emit_governance_otel_spans()
        self._context_start_ms = time.monotonic() * 1000
        self._context_start_wall_ms = time.time() * 1000
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        status, error, error_type, tb_str = self._determine_exit_status(exc_type, exc_val, exc_tb)
        self._end_otel_span(exc_type, exc_val)
        self._detach_otel_context()
        self._clear_context_var()

        if not self._run_info or not self._run_info.run_id:
            return False

        try:
            if self._llm_calls:
                self.client.record_llm_calls_sync(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
            if self._steps:
                self.client.record_steps_sync(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
            if self._scores:
                self.client.record_scores_sync(
                    run_id=self._run_info.run_id,
                    scores=self._scores,
                )
            # Merge auto-instrumented OTel spans (deduplicating LLM spans
            # that were already recorded via record_llm_call)
            self._merge_otel_spans()
            # Remove placeholder retrieval spans from auto-instrumentors
            # when the user has explicit @waxell.retrieval with real data
            self._deduplicate_retrieval_spans()

            # Insert root agent span with total duration
            root_span = {
                "name": f"{self.agent_name}.{self.workflow_name}",
                "kind": "agent",
                "status": "error" if exc_type else "ok",
                "duration_ms": self._elapsed_ms(),
                "position": 0,
                "start_offset_ms": 0,
                "parent_position": None,
                "attributes": {
                    "agent_name": self.agent_name,
                    "workflow_name": self.workflow_name,
                },
                "input_data": self.inputs if self.inputs else None,
                "output_data": self._result if self._result else None,
            }
            if exc_type:
                root_span["attributes"]["error.type"] = error_type
                root_span["attributes"]["error.message"] = error
                root_span["events"] = [{
                    "name": "exception",
                    "attributes": {
                        "exception.type": error_type,
                        "exception.message": error,
                        "exception.stacktrace": tb_str,
                    },
                }]
            self._spans.insert(0, root_span)
            if self._spans:
                self.client.record_spans_sync(
                    run_id=self._run_info.run_id,
                    spans=self._spans,
                )
            self.client.complete_run_sync(
                run_id=self._run_info.run_id,
                result=self._result,
                status=status,
                error=error,
                error_type=error_type,
                traceback=tb_str,
                trace_id=self._otel_trace_id,
                root_span_id=self._otel_span_id,
            )
        except Exception as e:
            logger.warning(f"Failed to flush observe context: {e}")

        # Inject summary span into parent's trace buffer
        try:
            self._inject_summary_into_parent(status)
        except Exception:
            logger.debug(
                "Failed to inject summary into parent for agent=%s",
                self.agent_name,
                exc_info=True,
            )

        return False  # Don't suppress exceptions

    # -----------------------------------------------------------------
    # Recording methods
    # -----------------------------------------------------------------

    @property
    def run_id(self) -> str:
        """The run ID from the controlplane, or empty string if not started."""
        return self._run_info.run_id if self._run_info else ""

    def record_llm_call(
        self,
        *,
        model: str,
        tokens_in: int,
        tokens_out: int,
        cost: float = 0.0,
        task: str = "",
        prompt_preview: str = "",
        response_preview: str = "",
        duration_ms: int | None = None,
        provider: str = "",
        _auto_instrumented: bool = False,
    ) -> None:
        """Buffer an LLM call for later flushing and emit an OTel span.

        Args:
            provider: Explicit provider name (e.g. "groq", "openai").
                When empty, inferred from model name.
            _auto_instrumented: Internal flag set by auto-instrumentors.
                Enables dedup when both auto and manual recording fire
                for the same call.
        """
        # Dedup: prevent double-counting when auto-instrumentation and
        # manual ctx.record_llm_call() both fire for the same LLM call.
        sig = (model, tokens_in, tokens_out)
        if _auto_instrumented:
            self._auto_recorded_counts[sig] = (
                self._auto_recorded_counts.get(sig, 0) + 1
            )
        elif self._auto_recorded_counts.get(sig, 0) > 0:
            # Manual call for something auto-instrumentor already captured
            self._auto_recorded_counts[sig] -= 1
            return

        if cost == 0.0:
            cost = estimate_cost(model, tokens_in, tokens_out)
        self._total_tokens_in += tokens_in
        self._total_tokens_out += tokens_out
        self._total_cost += cost
        self._total_llm_calls += 1
        self._step_counter += 1
        self._llm_calls.append(
            {
                "model": model,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "cost": cost,
                "task": task,
                "prompt_preview": prompt_preview,
                "response_preview": response_preview,
            }
        )

        # Also buffer as a behavior span for the Django Span table
        resolved_provider = provider or _infer_provider(model)
        self._spans.append({
            "name": f"chat {model}",
            "kind": "llm",
            "status": "ok",
            "duration_ms": duration_ms,
            "position": self._step_counter,
            "start_offset_ms": self._elapsed_ms(),
            "parent_position": self._current_step_position,
            "attributes": {
                "model": model,
                "waxell.llm.model": model,
                "gen_ai.provider.name": resolved_provider,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "waxell.llm.input_tokens": tokens_in,
                "waxell.llm.output_tokens": tokens_out,
                "total_tokens": tokens_in + tokens_out,
                "cost": cost,
                "waxell.llm.cost": cost,
                "task": task or None,
            },
            "input_data": {"prompt_preview": prompt_preview} if prompt_preview else None,
            "output_data": {"response_preview": response_preview} if response_preview else None,
        })

        # Emit OTel LLM span (dual data path)
        try:
            capture = False
            try:
                from .tracing import _capture_content

                capture = _capture_content
            except ImportError:
                pass

            span = start_llm_span(
                model=model,
                provider_name=resolved_provider,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                cost=cost,
                task=task,
                capture_content=capture,
                input_messages=prompt_preview,
                output_messages=response_preview,
            )
            span.end()
        except Exception:
            pass

    def record_step(self, step_name: str, output: Optional[dict] = None) -> None:
        """Buffer an execution step and optionally flush for mid-execution governance."""
        self._step_counter += 1
        self._current_step_position = self._step_counter
        self._steps.append(
            {
                "step_name": step_name,
                "output": output or {},
                "position": self._step_counter,
            }
        )

        # Also buffer as a behavior span for the Django Span table (Trace tab)
        self._spans.append({
            "name": step_name,
            "kind": "chain",
            "status": "ok",
            "duration_ms": None,
            "position": self._step_counter,
            "start_offset_ms": self._elapsed_ms(),
            "parent_position": None,
            "attributes": {},
            "input_data": None,
            "output_data": output if output else None,
        })

        # Emit OTel step span (dual data path)
        try:
            span = start_step_span(
                step_name=step_name,
                position=self._step_counter,
            )
            span.end()
        except Exception:
            pass

        # Mid-execution governance: flush and check policy
        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def set_result(self, result: dict) -> None:
        """Set the result to include when the run is completed."""
        self._result = result

    def record_score(
        self,
        name: str,
        value: float | str | bool,
        data_type: str = "numeric",
        comment: str = "",
    ) -> None:
        """Buffer a score (user feedback) for the current run.

        Args:
            name: Score name (e.g. "thumbs_up", "accuracy", "relevance").
            value: Score value — float for numeric, str for categorical, bool for boolean.
            data_type: One of "numeric", "categorical", "boolean".
            comment: Optional free-text comment.
        """
        score: dict = {
            "name": name,
            "data_type": data_type,
            "comment": comment,
        }
        if data_type == "numeric":
            score["numeric_value"] = float(value)
        elif data_type == "boolean":
            score["numeric_value"] = 1.0 if value else 0.0
            score["string_value"] = str(bool(value)).lower()
        else:
            score["string_value"] = str(value)
        self._scores.append(score)

    # -----------------------------------------------------------------
    # Behavior tracking methods
    # -----------------------------------------------------------------

    def record_tool_call(
        self,
        *,
        name: str,
        input: dict | str = "",
        output: dict | str = "",
        duration_ms: int | None = None,
        status: str = "ok",
        tool_type: str = "function",
        error: str = "",
        _skip_otel: bool = False,
    ) -> None:
        """Buffer a tool call event and emit an OTel span.

        Args:
            name: Tool name (e.g. "web_search", "database_query").
            input: Tool input parameters.
            output: Tool output/result.
            duration_ms: Execution time in milliseconds.
            status: "ok" or "error".
            tool_type: Classification ("function", "api", "database", "retriever").
            error: Error message if status is "error".
            _skip_otel: If True, skip creating an OTel span (caller already
                created one that wraps the execution).
        """
        self._step_counter += 1
        self._steps.append({
            "step_name": f"tool:{name}",
            "output": {"_kind": "tool_call", "name": name, "status": status, "error": error},
            "position": self._step_counter,
        })
        self._spans.append({
            "name": name,
            "kind": "tool",
            "status": status,
            "duration_ms": duration_ms,
            "position": self._step_counter,
            "start_offset_ms": self._elapsed_ms(),
            "parent_position": self._current_step_position,
            "attributes": {"tool_type": tool_type, "error": error} if error else {"tool_type": tool_type},
            "input_data": input if isinstance(input, dict) else {"raw": input} if input else None,
            "output_data": output if isinstance(output, dict) else {"raw": output} if output else None,
        })

        if not _skip_otel:
            try:
                span = start_tool_span(tool_name=name, tool_type=tool_type)
                if error:
                    span.set_attribute("error.message", error)
                span.end()
            except Exception:
                pass

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_retrieval(
        self,
        *,
        query: str,
        documents: list[dict],
        source: str = "",
        duration_ms: int | None = None,
        top_k: int | None = None,
        scores: list[float] | None = None,
    ) -> None:
        """Buffer a retrieval operation (RAG document fetch).

        Args:
            query: The retrieval query string.
            documents: List of retrieved docs [{id, title, score, snippet}].
            source: Data source name (e.g. "pinecone", "elasticsearch").
            duration_ms: Retrieval time in milliseconds.
            top_k: Number of documents requested.
            scores: Relevance scores for each retrieved document.
        """
        self._step_counter += 1
        self._steps.append({
            "step_name": f"retrieval:{source or 'search'}",
            "output": {"_kind": "retrieval", "query": query, "doc_count": len(documents)},
            "position": self._step_counter,
        })
        attrs: dict[str, Any] = {"source": source}
        if source:
            attrs["waxell.retrieval.source"] = source
        if top_k is not None:
            attrs["top_k"] = top_k
        attrs["doc_count"] = len(documents)
        attrs["waxell.retrieval.results_count"] = len(documents)
        if scores:
            attrs["top_score"] = max(scores)
            attrs["avg_score"] = sum(scores) / len(scores)
        output_data: dict[str, Any] = {"documents": documents}
        if scores:
            output_data["scores"] = scores
        self._spans.append({
            "name": f"retrieve:{source or 'search'}",
            "kind": "retriever",
            "status": "ok",
            "duration_ms": duration_ms,
            "position": self._step_counter,
            "start_offset_ms": self._elapsed_ms(),
            "parent_position": self._current_step_position,
            "attributes": attrs,
            "input_data": {"query": query, "top_k": top_k},
            "output_data": output_data,
        })

        try:
            span = start_retrieval_span(query=query, source=source)
            span.end()
        except Exception:
            pass

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_decision(
        self,
        *,
        name: str,
        options: list[str],
        chosen: str,
        reasoning: str = "",
        confidence: float | None = None,
        metadata: Optional[dict] = None,
        instrumentation_type: str = "manual",
    ) -> None:
        """Buffer a decision point (branching logic, routing).

        Args:
            name: Decision name (e.g. "route_to_agent", "select_model").
            options: Available choices.
            chosen: The selected option.
            reasoning: Why this option was chosen.
            confidence: Confidence score (0.0-1.0) if applicable.
            metadata: Additional context for the decision.
            instrumentation_type: How this decision was captured —
                ``"manual"`` (record_decision/decide), ``"decorator"``
                (@decision), or ``"auto"`` (from LLM tool_calls).
        """
        self._step_counter += 1
        self._steps.append({
            "step_name": f"decision:{name}",
            "output": {"_kind": "decision", "name": name, "chosen": chosen, "confidence": confidence},
            "position": self._step_counter,
        })
        attrs: dict[str, Any] = {
            "instrumentation_source": instrumentation_type,
        }
        if confidence is not None:
            attrs["confidence"] = confidence
        if metadata:
            attrs.update(metadata)
        self._spans.append({
            "name": name,
            "kind": "decision",
            "status": "ok",
            "duration_ms": None,
            "position": self._step_counter,
            "start_offset_ms": self._elapsed_ms(),
            "parent_position": self._current_step_position,
            "attributes": attrs,
            "input_data": {"options": options, "reasoning": reasoning},
            "output_data": {"chosen": chosen, "confidence": confidence},
        })

        try:
            span = start_decision_span(decision_name=name, options=options, chosen=chosen)
            span.end()
        except Exception:
            pass

    def record_reasoning(
        self,
        *,
        step: str,
        thought: str,
        evidence: list[str] | None = None,
        conclusion: str = "",
    ) -> None:
        """Buffer a reasoning step (chain-of-thought, reflection).

        Args:
            step: Reasoning step name (e.g. "evaluate_sources", "check_consistency").
            thought: The reasoning text/thought process.
            evidence: Supporting evidence or references.
            conclusion: Conclusion reached at this step.
        """
        self._step_counter += 1
        self._steps.append({
            "step_name": f"reasoning:{step}",
            "output": {"_kind": "reasoning", "thought": thought[:200], "conclusion": conclusion},
            "position": self._step_counter,
        })
        self._spans.append({
            "name": step,
            "kind": "reasoning",
            "status": "ok",
            "duration_ms": None,
            "position": self._step_counter,
            "start_offset_ms": self._elapsed_ms(),
            "parent_position": self._current_step_position,
            "attributes": {},
            "input_data": {"thought": thought, "evidence": evidence or []},
            "output_data": {"conclusion": conclusion} if conclusion else None,
        })

        try:
            span = start_reasoning_span(step_name=step)
            span.end()
        except Exception:
            pass

    def record_retry(
        self,
        *,
        attempt: int,
        reason: str,
        strategy: str = "retry",
        original_error: str = "",
        fallback_to: str = "",
        max_attempts: int | None = None,
    ) -> None:
        """Buffer a retry or fallback event.

        Args:
            attempt: Current attempt number (1-based).
            reason: Why a retry/fallback occurred.
            strategy: "retry", "fallback", or "circuit_break".
            original_error: The error that triggered the retry.
            fallback_to: Name of fallback target (model, agent, tool).
            max_attempts: Maximum attempts configured.
        """
        self._step_counter += 1
        self._steps.append({
            "step_name": f"retry:{strategy}",
            "output": {
                "_kind": "retry",
                "attempt": attempt,
                "reason": reason,
                "strategy": strategy,
                "fallback_to": fallback_to,
            },
            "position": self._step_counter,
        })
        attrs: dict[str, Any] = {
            "attempt": attempt,
            "strategy": strategy,
        }
        if max_attempts is not None:
            attrs["max_attempts"] = max_attempts
        if fallback_to:
            attrs["fallback_to"] = fallback_to
        self._spans.append({
            "name": f"{strategy}:{attempt}",
            "kind": "retry",
            "status": "error" if original_error else "ok",
            "duration_ms": None,
            "position": self._step_counter,
            "start_offset_ms": self._elapsed_ms(),
            "parent_position": self._current_step_position,
            "attributes": attrs,
            "input_data": {"reason": reason, "original_error": original_error},
            "output_data": {"fallback_to": fallback_to} if fallback_to else None,
        })

        try:
            span = start_retry_span(attempt=attempt, strategy=strategy)
            if original_error:
                span.set_attribute("error.message", original_error)
            span.end()
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Governance recording
    # -----------------------------------------------------------------

    def record_policy_check(
        self,
        *,
        policy_name: str,
        action: str,
        category: str = "",
        reason: str = "",
        duration_ms: float = 0,
        phase: str = "pre_execution",
        priority: int = 100,
    ) -> None:
        """Buffer a policy evaluation result as a governance span.

        Args:
            policy_name: Name of the policy evaluated.
            action: Evaluation result ("allow", "warn", "block", etc.).
            category: Policy category (e.g. "budget", "rate-limit").
            reason: Reason for the action (empty for allow).
            duration_ms: Evaluation time in milliseconds.
            phase: "pre_execution", "mid_execution", or "post_execution".
            priority: Policy priority (lower = first).
        """
        # Governance data is NOT appended to _steps or _spans.
        # Server-side observe_views creates governance events + spans during
        # policy evaluation. Putting them in _steps triggers duplicate mid-exec
        # checks, and _spans serializer rejects kind="governance" which would
        # fail the entire behavior span batch. Buffer in _governance_spans for
        # OTel emission only.
        self._governance_spans.append({
            "name": f"policy:{policy_name}",
            "kind": "governance",
            "status": "ok" if action == "allow" else action,
            "duration_ms": duration_ms or None,
            "position": self._step_counter,
            "attributes": {
                "policy_name": policy_name,
                "category": category,
                "action": action,
                "priority": priority,
                "phase": phase,
            },
            "input_data": {"phase": phase},
            "output_data": {"action": action, "reason": reason} if reason else {"action": action},
        })

        try:
            span = start_governance_span(policy_name=policy_name, action=action, category=category)
            if reason:
                span.set_attribute("waxell.policy.reason", reason)
            span.end()
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Tag and metadata methods
    # -----------------------------------------------------------------

    def set_tag(self, key: str, value: str) -> None:
        """Set a searchable tag on the current agent span.

        Tags become OTel span attributes prefixed with ``waxell.tag.``
        and are queryable in Grafana TraceQL:
        ``{ span.waxell.tag.user_id = "u_123" }``

        Args:
            key: Tag name (alphanumeric, underscores, hyphens).
            value: Tag value (string).
        """
        self._tags[key] = value
        if self._span and not isinstance(self._span, NoOpSpan):
            try:
                self._span.set_attribute(f"{WaxellAttributes.TAG_PREFIX}{key}", value)
            except Exception:
                pass

    def set_metadata(self, key: str, value: Any) -> None:
        """Set metadata on the current agent span.

        Complex values are JSON-serialized. Queryable in Grafana TraceQL:
        ``{ span.waxell.meta.request != nil }``

        Args:
            key: Metadata key.
            value: Any JSON-serializable value.
        """
        self._metadata_kv[key] = value
        if self._span and not isinstance(self._span, NoOpSpan):
            try:
                from .tracing._compat import _safe_attr

                self._span.set_attribute(
                    f"{WaxellAttributes.META_PREFIX}{key}", _safe_attr(value)
                )
            except Exception:
                pass

    def _merge_otel_spans(self) -> None:
        """Merge auto-instrumented OTel spans into _spans, deduplicating.

        The WaxellSpanProcessor captures OTel spans into _otel_spans.
        Many instrumentors (e.g. OpenAI) ALSO call record_llm_call() which
        adds to _spans. We detect duplicates by checking if an OTel LLM span
        overlaps with a manually-recorded LLM span for the same model.

        Non-LLM OTel spans (tool calls, HTTP, DB, etc.) are always added
        since they're not recorded manually.

        Parent-child relationships are preserved: if an OTel span's
        ``_otel_parent_id`` matches another OTel span's ``_otel_span_id``,
        the child gets the parent's position as ``parent_position``.
        This allows HTTP/DB auto-instrumented spans to nest under
        @waxell.tool decorator spans in the trace tree.
        """
        if not self._otel_spans:
            return

        # Build sets from existing manual spans for dedup
        existing_llm_models: set[str] = set()
        existing_retrieval_sources: set[str] = set()
        for s in self._spans:
            if s.get("kind") == "llm":
                model = (s.get("attributes") or {}).get("model", "")
                if model:
                    existing_llm_models.add(model)
            elif s.get("kind") == "retriever":
                source = (s.get("attributes") or {}).get("retrieval.source", "")
                if source:
                    existing_retrieval_sources.add(source)

        # Use wall-clock ms for OTel offset calculation.  OTel spans use
        # epoch-based time.time_ns() while _context_start_ms uses monotonic
        # time — mixing them produces huge offsets (year 2082 bug).
        run_started_at_wall_ms = self._context_start_wall_ms

        # Two-pass merge to resolve OTel parent-child → position-based hierarchy.
        #
        # Pass 1: Assign positions to all OTel spans, build otel_id → position map.
        # Pass 2: Resolve parent_position using the otel_id → position map.

        otel_id_to_position: dict[str, int] = {}
        merged_entries: list[tuple[dict, dict]] = []  # (otel_span, merged_dict)

        for otel_span in self._otel_spans:
            kind = otel_span.get("kind", "chain")

            # Skip governance spans — server creates those
            if kind == "governance":
                continue

            # Skip agent-level spans — we insert our own root agent span
            if kind == "agent":
                continue

            # Deduplicate LLM spans: if we already have a manual span for
            # the same model, the OTel span is a duplicate from the instrumentor
            if kind == "llm":
                model = (otel_span.get("attributes") or {}).get("model", "")
                if model and model in existing_llm_models:
                    # This is a duplicate — but enrich the existing manual span
                    # with any extra attributes from the OTel span
                    self._enrich_manual_span(model, otel_span)
                    continue

            # Deduplicate retriever spans: auto-instrumentors (e.g. ES)
            # create retrieval spans with generic placeholder documents.
            # When the user has an explicit @waxell.retrieval with the same
            # source, drop the auto-instrumentor duplicates.
            if kind == "retriever" and existing_retrieval_sources:
                source = (otel_span.get("attributes") or {}).get(
                    "retrieval.source", ""
                )
                if source and source in existing_retrieval_sources:
                    continue

            # Convert OTel absolute timestamps to offset from context start
            start_ns = otel_span.get("_otel_start_ns", 0)
            end_ns = otel_span.get("_otel_end_ns", 0)
            duration_ms = otel_span.get("duration_ms")

            if start_ns and run_started_at_wall_ms:
                start_ms = start_ns / 1_000_000
                offset_ms = int(start_ms - run_started_at_wall_ms)
                if offset_ms < 0:
                    offset_ms = 0
            else:
                offset_ms = self._elapsed_ms()

            self._step_counter += 1
            position = self._step_counter

            merged = {
                "name": otel_span.get("name", "otel-span"),
                "kind": kind,
                "status": otel_span.get("status", "ok"),
                "duration_ms": duration_ms,
                "position": position,
                "start_offset_ms": offset_ms,
                "parent_position": self._current_step_position,  # default
                "attributes": otel_span.get("attributes", {}),
                "input_data": otel_span.get("input_data"),
                "output_data": otel_span.get("output_data"),
            }

            # Track OTel span ID → position for parent resolution
            otel_span_id = otel_span.get("_otel_span_id", "")
            if otel_span_id:
                otel_id_to_position[otel_span_id] = position

            merged_entries.append((otel_span, merged))

        # Pass 2: Resolve parent_position from _otel_parent_id and
        # deduplicate stacked instrumentor spans (e.g. httpx + urllib3
        # both fire for the same HTTP request, producing a parent-child
        # pair with identical names like DELETE localhost → DELETE localhost).
        otel_id_to_name: dict[str, str] = {
            otel_span.get("_otel_span_id", ""): merged["name"]
            for otel_span, merged in merged_entries
            if otel_span.get("_otel_span_id")
        }

        for otel_span, merged in merged_entries:
            otel_parent_id = otel_span.get("_otel_parent_id", "")
            if otel_parent_id and otel_parent_id in otel_id_to_position:
                # Check for duplicate: parent is another OTel span with
                # the same display name → drop this child as redundant.
                parent_name = otel_id_to_name.get(otel_parent_id, "")
                if parent_name and parent_name == merged["name"]:
                    continue  # Skip duplicate

                merged["parent_position"] = otel_id_to_position[otel_parent_id]

            self._spans.append(merged)

    def _enrich_manual_span(self, model: str, otel_span: dict) -> None:
        """Enrich an existing manual LLM span with extra OTel attributes."""
        otel_attrs = otel_span.get("attributes", {})
        for s in self._spans:
            if s.get("kind") != "llm":
                continue
            s_attrs = s.get("attributes") or {}
            if s_attrs.get("model") != model:
                continue
            # Merge attributes we don't already have
            for key in ("finish_reasons", "response_model", "system"):
                if key in otel_attrs and key not in s_attrs:
                    s_attrs[key] = otel_attrs[key]
            # Update duration if the OTel span has one and manual doesn't
            if not s.get("duration_ms") and otel_span.get("duration_ms"):
                s["duration_ms"] = otel_span["duration_ms"]
            break  # Only enrich first match

    def _deduplicate_retrieval_spans(self) -> None:
        """Remove placeholder retrieval spans when real ones exist for the same source.

        Auto-instrumentors (e.g. Elasticsearch) call ctx.record_retrieval()
        with placeholder documents like [{"id": "hit_0"}, {"id": "hit_1"}].
        When the user has an explicit @waxell.retrieval decorator with real
        document data for the same source, the placeholder spans are redundant.

        This runs after _merge_otel_spans() so all spans are in _spans.
        """
        # Group retriever spans by source
        retriever_spans_by_source: dict[str, list[int]] = {}
        for i, span in enumerate(self._spans):
            if span.get("kind") != "retriever":
                continue
            attrs = span.get("attributes") or {}
            source = attrs.get("waxell.retrieval.source") or attrs.get("source", "")
            if source:
                retriever_spans_by_source.setdefault(source, []).append(i)

        # For each source with multiple retriever spans, identify placeholders
        indices_to_remove: set[int] = set()
        for source, indices in retriever_spans_by_source.items():
            if len(indices) < 2:
                continue

            # Separate real vs placeholder spans
            real_indices = []
            placeholder_indices = []
            for idx in indices:
                if self._is_placeholder_retrieval(self._spans[idx]):
                    placeholder_indices.append(idx)
                else:
                    real_indices.append(idx)

            # Only remove placeholders if at least one real span exists
            if real_indices and placeholder_indices:
                indices_to_remove.update(placeholder_indices)

        if indices_to_remove:
            self._spans = [
                s for i, s in enumerate(self._spans)
                if i not in indices_to_remove
            ]

    # Prefixes used by auto-instrumentors for placeholder document IDs.
    _PLACEHOLDER_ID_PREFIXES = ("hit_", "match_", "row_", "result_")

    @staticmethod
    def _is_placeholder_retrieval(span: dict) -> bool:
        """Check if a retrieval span has placeholder documents from auto-instrumentors.

        Auto-instrumentors create documents like [{"id": "hit_0"}],
        [{"id": "match_0"}], [{"id": "row_0"}], etc. which contain no real
        content — just a synthetic ID.
        """
        output_data = span.get("output_data") or {}
        documents = output_data.get("documents", [])
        if not documents:
            return True  # Empty documents = placeholder
        # Check if all documents are simple placeholder objects
        for doc in documents:
            if not isinstance(doc, dict):
                continue
            keys = set(doc.keys())
            if keys == {"id"} and isinstance(doc.get("id"), str):
                doc_id = doc["id"]
                if any(doc_id.startswith(p) for p in WaxellContext._PLACEHOLDER_ID_PREFIXES):
                    continue
            # Has real content beyond just a placeholder id
            return False
        return True

    def _flush_and_check_governance(self) -> None:
        """Flush buffered data and check governance response.

        Called from record_step() when mid_execution_governance=True.
        Raises PolicyViolationError if server returns block action.
        """
        if self._governance_blocked:
            raise PolicyViolationError(self._governance_reason)

        if not self._run_info:
            return

        try:
            # Flush LLM calls
            if self._llm_calls:
                resp = self.client.record_llm_calls_sync(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
                self._llm_calls.clear()
                self._check_governance_response(resp)

            # Flush steps
            if self._steps:
                resp = self.client.record_steps_sync(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
                self._steps.clear()
                self._check_governance_response(resp)
        except PolicyViolationError:
            raise  # Re-raise policy violations
        except Exception as e:
            logger.warning(f"Mid-execution governance flush failed: {e}")

    def _check_governance_response(self, response: dict) -> None:
        """Check governance field in server response. Record evaluations. Raise if blocked."""
        gov = response.get("governance", {}) if response else {}

        # Record mid-execution evaluations as governance spans
        for ev in gov.get("evaluations", []):
            try:
                self.record_policy_check(
                    policy_name=ev.get("policy_name", "unknown"),
                    action=ev.get("action", "allow"),
                    category=ev.get("category", ""),
                    reason=ev.get("reason", ""),
                    duration_ms=ev.get("duration_ms", 0),
                    phase="mid_execution",
                )
            except Exception:
                pass

        if gov.get("action") == "block":
            self._governance_blocked = True
            self._governance_reason = gov.get("reason", "Policy violation")
            raise PolicyViolationError(self._governance_reason)

    async def check_policy(self) -> PolicyCheckResult:
        """Manually check policy (useful for mid-execution checks)."""
        return await self.client.check_policy(
            agent_name=self.agent_name,
            workflow_name=self.workflow_name,
        )

    def check_policy_sync(self) -> PolicyCheckResult:
        """Synchronous version of check_policy for mid-execution checks."""
        return self.client.check_policy_sync(
            agent_name=self.agent_name,
            workflow_name=self.workflow_name,
        )
