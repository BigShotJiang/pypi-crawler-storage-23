"""OTLP exporter with quiet failure and endpoint discovery."""

import logging
from dataclasses import dataclass
from typing import Optional, Sequence

logger = logging.getLogger(__name__)

from ._compat import _HAS_OTEL

if _HAS_OTEL:
    from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
else:
    SpanExporter = object
    SpanExportResult = None
    OTLPSpanExporter = None


class QuietExporter(SpanExporter if _HAS_OTEL else object):
    """Wraps an exporter to suppress repeated failure logs.

    Logs ONE warning on first export failure, then suppresses
    further errors to avoid flooding the console.
    """

    def __init__(self, inner: "SpanExporter"):
        self._inner = inner
        self._warned = False

    def export(self, spans: "Sequence"):
        try:
            result = self._inner.export(spans)
            # Track successful exports for diagnostics
            if not self._warned and SpanExportResult is not None:
                if result == SpanExportResult.FAILURE and not self._warned:
                    logger.warning(
                        "Waxell OTel span export returned FAILURE (%d spans dropped). "
                        "Check that the OTLP endpoint is reachable and Tempo is running. "
                        "Span data is still recorded via HTTP API. "
                        "Further export errors will be suppressed.",
                        len(spans),
                    )
                    self._warned = True
            return result
        except Exception as e:
            if not self._warned:
                logger.warning(
                    "Waxell OTel span export failed: %s (%d spans dropped). "
                    "Check that the OTLP endpoint is reachable and Tempo is running. "
                    "Span data is still recorded via HTTP API. "
                    "Further errors will be suppressed.",
                    e,
                    len(spans),
                )
                self._warned = True
            if SpanExportResult is not None:
                return SpanExportResult.FAILURE
            return None

    def shutdown(self):
        try:
            self._inner.shutdown()
        except Exception:
            pass

    def force_flush(self, timeout_millis: int = 30000):
        try:
            return self._inner.force_flush(timeout_millis)
        except Exception:
            pass


def _normalize_traces_endpoint(endpoint: str) -> str:
    """Ensure the endpoint includes the /v1/traces path.

    OTel Python SDK 1.28+ treats the constructor endpoint parameter as the
    full URL and does NOT append /v1/traces automatically. Since the Waxell
    API returns the base collector URL (e.g. http://localhost:4318), we need
    to append the signal-specific path.
    """
    endpoint = endpoint.rstrip("/")
    if not endpoint.endswith("/v1/traces"):
        endpoint = f"{endpoint}/v1/traces"
    return endpoint


def _normalize_logs_endpoint(endpoint: str) -> str:
    """Ensure the endpoint includes the /v1/logs path."""
    endpoint = endpoint.rstrip("/")
    if not endpoint.endswith("/v1/logs"):
        endpoint = f"{endpoint}/v1/logs"
    return endpoint


def create_exporter(
    endpoint: str, headers: Optional[dict] = None
) -> "SpanExporter":
    """Create an OTLP/HTTP exporter wrapped in QuietExporter."""
    endpoint = _normalize_traces_endpoint(endpoint)
    inner = OTLPSpanExporter(endpoint=endpoint, headers=headers or {})
    return QuietExporter(inner)


def discover_otel_endpoint(
    api_url: str, api_key: str
) -> Optional[str]:
    """Discover the OTel collector endpoint from the Waxell API.

    Makes a synchronous HTTP GET to /api/v1/observe/config/.
    Returns the endpoint URL or None on failure.
    """
    try:
        import httpx

        url = f"{api_url.rstrip('/')}/api/v1/observe/config/"
        with httpx.Client(timeout=10.0) as client:
            response = client.get(
                url,
                headers={"X-Wax-Key": api_key},
            )
            response.raise_for_status()
            data = response.json()
            return data.get("otel_endpoint")
    except Exception as e:
        logger.debug("Could not discover OTel endpoint from API: %s", e)
        return None


def resolve_otel_endpoint(
    explicit: Optional[str] = None,
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
) -> Optional[str]:
    """Resolve OTel endpoint from multiple sources.

    Priority: explicit arg > auto-discovery from API > env var > None
    """
    import os

    # 1. Explicit argument
    if explicit:
        return explicit

    # 2. Auto-discovery from API
    if api_url and api_key:
        discovered = discover_otel_endpoint(api_url, api_key)
        if discovered:
            return discovered

    # 3. Standard OTel env var
    env_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    if env_endpoint:
        return env_endpoint

    return None


# ---------------------------------------------------------------------------
# Full config resolution (endpoint + tenant_id in one call)
# ---------------------------------------------------------------------------


@dataclass
class OtelConfig:
    """Resolved OTel configuration from the Waxell API."""

    endpoint: str = ""
    tenant_id: str = ""
    tenant_slug: str = ""


def discover_otel_config(api_url: str, api_key: str) -> OtelConfig:
    """Discover OTel config (endpoint + tenant_id) from the Waxell API.

    Single HTTP GET to /api/v1/observe/config/.
    Returns OtelConfig with endpoint, tenant_id, and tenant_slug.
    """
    try:
        import httpx

        url = f"{api_url.rstrip('/')}/api/v1/observe/config/"
        with httpx.Client(timeout=10.0) as client:
            response = client.get(
                url,
                headers={"X-Wax-Key": api_key},
            )
            response.raise_for_status()
            data = response.json()
            return OtelConfig(
                endpoint=data.get("otel_endpoint", ""),
                tenant_id=data.get("tenant_id", ""),
                tenant_slug=data.get("tenant_slug", ""),
            )
    except Exception as e:
        logger.debug("Could not discover OTel config from API: %s", e)
        return OtelConfig()


def resolve_otel_config(
    explicit_endpoint: Optional[str] = None,
    explicit_tenant_id: Optional[str] = None,
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
) -> OtelConfig:
    """Resolve full OTel config from multiple sources.

    Priority for endpoint: explicit arg > API discovery > env var > None
    Priority for tenant_id: explicit arg > API discovery > None
    """
    import os

    config = OtelConfig()

    # Try API discovery first (gets both endpoint and tenant_id in one call)
    if api_url and api_key:
        config = discover_otel_config(api_url, api_key)

    # Override with explicit values if provided
    if explicit_endpoint:
        config.endpoint = explicit_endpoint
    if explicit_tenant_id:
        config.tenant_id = explicit_tenant_id

    # Fall back to env var for endpoint if still not set
    if not config.endpoint:
        env_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
        if env_endpoint:
            config.endpoint = env_endpoint

    return config
