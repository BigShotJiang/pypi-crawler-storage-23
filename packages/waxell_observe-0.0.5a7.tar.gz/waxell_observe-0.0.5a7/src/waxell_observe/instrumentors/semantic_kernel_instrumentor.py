"""Semantic Kernel auto-instrumentor for waxell-observe.

Monkey-patches ``semantic_kernel.Kernel.invoke`` to emit OTel spans
and record to the Waxell HTTP API.

Microsoft Semantic Kernel uses Kernel.invoke as the primary entry point
for executing plugins and functions.

Also patches ``SemanticTextMemory`` operations (save_information,
save_reference, search, get, remove) for memory operation tracing.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class SemanticKernelInstrumentor(BaseInstrumentor):
    """Instrumentor for Microsoft Semantic Kernel (``semantic-kernel`` package).

    Patches Kernel.invoke, Kernel.invoke_stream, and SemanticTextMemory operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import semantic_kernel  # noqa: F401
        except ImportError:
            logger.debug("semantic_kernel not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Semantic Kernel instrumentation")
            return False

        patched = False

        # Patch Kernel.invoke (async)
        try:
            wrapt.wrap_function_wrapper(
                "semantic_kernel",
                "Kernel.invoke",
                _invoke_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Kernel.invoke: %s", exc)

        # Patch Kernel.invoke_stream (async streaming)
        try:
            wrapt.wrap_function_wrapper(
                "semantic_kernel",
                "Kernel.invoke_stream",
                _invoke_stream_wrapper,
            )
        except Exception:
            pass

        # Patch SemanticTextMemory operations (optional -- module may not exist)
        try:
            wrapt.wrap_function_wrapper(
                "semantic_kernel.memory.semantic_text_memory",
                "SemanticTextMemory.save_information",
                _memory_save_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "semantic_kernel.memory.semantic_text_memory",
                "SemanticTextMemory.save_reference",
                _memory_save_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "semantic_kernel.memory.semantic_text_memory",
                "SemanticTextMemory.search",
                _memory_search_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "semantic_kernel.memory.semantic_text_memory",
                "SemanticTextMemory.get",
                _memory_get_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "semantic_kernel.memory.semantic_text_memory",
                "SemanticTextMemory.remove",
                _memory_remove_wrapper,
            )
            logger.debug("Semantic Kernel memory operations instrumented")
        except Exception:
            pass  # Memory module may not be available

        if not patched:
            logger.debug("Could not find Semantic Kernel methods to patch")
            return False

        self._instrumented = True
        logger.debug("Semantic Kernel instrumented (Kernel.invoke)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import semantic_kernel

            if hasattr(semantic_kernel.Kernel.invoke, "__wrapped__"):
                semantic_kernel.Kernel.invoke = semantic_kernel.Kernel.invoke.__wrapped__
            if hasattr(getattr(semantic_kernel.Kernel, "invoke_stream", None), "__wrapped__"):
                semantic_kernel.Kernel.invoke_stream = semantic_kernel.Kernel.invoke_stream.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore memory operation patches
        try:
            import importlib

            mod = importlib.import_module("semantic_kernel.memory.semantic_text_memory")
            cls = getattr(mod, "SemanticTextMemory", None)
            if cls is not None:
                for method_name in (
                    "save_information",
                    "save_reference",
                    "search",
                    "get",
                    "remove",
                ):
                    method = getattr(cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Semantic Kernel uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


async def _invoke_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Kernel.invoke``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    # Extract function and plugin names
    function_name = ""
    plugin_name = ""
    try:
        # Kernel.invoke(function, plugin_name=..., **kwargs)
        # or Kernel.invoke(function_name, plugin_name, **kwargs)
        func = args[0] if args else kwargs.get("function", None)
        if func is not None:
            if isinstance(func, str):
                function_name = func
            else:
                function_name = getattr(func, "name", "") or getattr(func, "function_name", "") or ""
                plugin_name = getattr(func, "plugin_name", "") or ""

        if not plugin_name:
            plugin_name = (
                args[1] if len(args) > 1 and isinstance(args[1], str)
                else kwargs.get("plugin_name", "")
            )
    except Exception:
        pass

    agent_label = "semantic_kernel"
    if plugin_name:
        agent_label = f"semantic_kernel.{plugin_name}"

    try:
        span = start_agent_span(
            agent_name=agent_label,
            workflow_name="semantic_kernel_invoke",
        )
        if plugin_name:
            span.set_attribute("waxell.semantic_kernel.plugin_name", plugin_name)
        if function_name:
            span.set_attribute("waxell.semantic_kernel.function_name", function_name)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, plugin_name, function_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _invoke_stream_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Kernel.invoke_stream``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    function_name = ""
    plugin_name = ""
    try:
        func = args[0] if args else kwargs.get("function", None)
        if func is not None:
            if isinstance(func, str):
                function_name = func
            else:
                function_name = getattr(func, "name", "") or ""
                plugin_name = getattr(func, "plugin_name", "") or ""
    except Exception:
        pass

    agent_label = "semantic_kernel"
    if plugin_name:
        agent_label = f"semantic_kernel.{plugin_name}"

    try:
        span = start_agent_span(
            agent_name=agent_label,
            workflow_name="semantic_kernel_invoke_stream",
        )
        if plugin_name:
            span.set_attribute("waxell.semantic_kernel.plugin_name", plugin_name)
        if function_name:
            span.set_attribute("waxell.semantic_kernel.function_name", function_name)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_result_attributes(span, result, plugin_name: str, function_name: str) -> None:
    """Set result attributes on the span."""
    try:
        # FunctionResult has .value and .metadata
        value = getattr(result, "value", None)
        if value is not None:
            span.set_attribute("waxell.semantic_kernel.result_type", type(value).__name__)
            span.set_attribute("waxell.semantic_kernel.result_preview", str(value)[:200])
    except Exception:
        pass

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                value = getattr(result, "value", result)
                result_preview = str(value)[:500]
            except Exception:
                pass
            ctx.record_step(
                f"semantic_kernel:{plugin_name}.{function_name}" if plugin_name else f"semantic_kernel:{function_name}",
                output={"result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Memory operation wrappers
# ---------------------------------------------------------------------------


async def _memory_save_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for SemanticTextMemory.save_information / save_reference."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    # Extract collection (first arg) and text (second arg)
    collection = ""
    text = ""
    try:
        collection = args[0] if args else kwargs.get("collection", "")
        text = args[1] if len(args) > 1 else kwargs.get("text", kwargs.get("information", ""))
    except Exception:
        pass

    try:
        span = start_step_span("semantic_kernel.memory.save")
        span.set_attribute("waxell.semantic_kernel.memory_collection", str(collection))
        span.set_attribute("waxell.semantic_kernel.memory_operation", "save")
        if text:
            span.set_attribute("waxell.semantic_kernel.memory_text_length", len(str(text)))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_memory_op("save", collection)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _memory_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for SemanticTextMemory.search."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    # Extract collection (first arg) and query (second arg)
    collection = ""
    query = ""
    min_relevance = 0.0
    try:
        collection = args[0] if args else kwargs.get("collection", "")
        query = args[1] if len(args) > 1 else kwargs.get("query", "")
        min_relevance = (
            args[3] if len(args) > 3
            else kwargs.get("min_relevance_score", kwargs.get("min_relevance", 0.0))
        )
    except Exception:
        pass

    try:
        span = start_retrieval_span(query=str(query), source="semantic_kernel_memory")
        span.set_attribute("waxell.semantic_kernel.memory_collection", str(collection))
        span.set_attribute("waxell.semantic_kernel.memory_operation", "search")
        span.set_attribute("waxell.semantic_kernel.memory_query", str(query)[:500])
        if min_relevance:
            span.set_attribute("waxell.semantic_kernel.memory_min_relevance", float(min_relevance))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = 0
            if result is not None:
                if isinstance(result, (list, tuple)):
                    result_count = len(result)
            span.set_attribute("waxell.semantic_kernel.memory_result_count", result_count)
        except Exception:
            pass

        try:
            _record_memory_retrieval(query, collection, result_count)
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _memory_get_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for SemanticTextMemory.get."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    # Extract collection (first arg) and key (second arg)
    collection = ""
    key = ""
    try:
        collection = args[0] if args else kwargs.get("collection", "")
        key = args[1] if len(args) > 1 else kwargs.get("key", "")
    except Exception:
        pass

    try:
        span = start_step_span("semantic_kernel.memory.get")
        span.set_attribute("waxell.semantic_kernel.memory_collection", str(collection))
        span.set_attribute("waxell.semantic_kernel.memory_operation", "get")
        span.set_attribute("waxell.semantic_kernel.memory_key", str(key))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_memory_op("get", collection)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _memory_remove_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for SemanticTextMemory.remove."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    # Extract collection (first arg) and key (second arg)
    collection = ""
    key = ""
    try:
        collection = args[0] if args else kwargs.get("collection", "")
        key = args[1] if len(args) > 1 else kwargs.get("key", "")
    except Exception:
        pass

    try:
        span = start_step_span("semantic_kernel.memory.remove")
        span.set_attribute("waxell.semantic_kernel.memory_collection", str(collection))
        span.set_attribute("waxell.semantic_kernel.memory_operation", "remove")
        span.set_attribute("waxell.semantic_kernel.memory_key", str(key))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_memory_op("remove", collection)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording helpers for memory operations
# ---------------------------------------------------------------------------


def _record_memory_op(operation: str, collection: str) -> None:
    """Record a memory operation to the context (if active), else collector."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"semantic_kernel:memory.{operation}",
            output={"collection": str(collection)},
        )
    else:
        try:
            from ._collector import _collector

            _collector.record_call({
                "type": "memory_operation",
                "source": "semantic_kernel",
                "operation": operation,
                "collection": str(collection),
            })
        except Exception:
            pass


def _record_memory_retrieval(query: str, collection: str, result_count: int) -> None:
    """Record a memory search to the context (if active), else collector."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=str(query),
            source="semantic_kernel_memory",
            results_count=result_count,
        )
    else:
        try:
            from ._collector import _collector

            _collector.record_call({
                "type": "memory_retrieval",
                "source": "semantic_kernel_memory",
                "query": str(query)[:500],
                "collection": str(collection),
                "result_count": result_count,
            })
        except Exception:
            pass
