"""USearch auto-instrumentor for waxell-observe.

Monkey-patches the USearch library to emit OTel spans for
vector search and index operations.

Patched methods:
  - usearch.index.Index.search  (retrieval span)
  - usearch.index.Index.add     (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's USearch calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class USearchInstrumentor(BaseInstrumentor):
    """Instrumentor for the USearch library (``usearch`` package).

    Patches ``Index.search`` for retrieval spans and
    ``Index.add`` for tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import usearch.index  # noqa: F401
        except ImportError:
            logger.debug("usearch package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping USearch instrumentation")
            return False

        patched_any = False

        # Patch Index.search (nearest-neighbor retrieval)
        try:
            wrapt.wrap_function_wrapper(
                "usearch.index",
                "Index.search",
                _search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch usearch.index.Index.search: %s", exc)

        # Patch Index.add (vector insertion)
        try:
            wrapt.wrap_function_wrapper(
                "usearch.index",
                "Index.add",
                _add_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch usearch.index.Index.add: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any USearch Index methods")
            return False

        self._instrumented = True
        logger.debug("USearch Index instrumented (search, add)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import usearch.index

            cls = getattr(usearch.index, "Index", None)
            if cls is not None:
                for method_name in ("search", "add"):
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("USearch Index uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_metric(instance) -> str:
    """Extract the distance metric from a USearch Index instance."""
    try:
        # USearch Index exposes metric via .metric attribute or .metric_kind
        metric = getattr(instance, "metric", None)
        if metric is not None:
            return str(metric)
        metric_kind = getattr(instance, "metric_kind", None)
        if metric_kind is not None:
            return str(metric_kind)
    except Exception:
        pass
    return ""


def _get_ndim(instance) -> int:
    """Extract the vector dimension from a USearch Index instance."""
    try:
        ndim = getattr(instance, "ndim", None)
        if ndim is not None:
            return int(ndim)
    except Exception:
        pass
    return 0


def _get_size(instance) -> int:
    """Extract the current number of vectors in the index."""
    try:
        # USearch uses len() or .size
        size = getattr(instance, "size", None)
        if size is not None:
            return int(size)
        if hasattr(instance, "__len__"):
            return len(instance)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.search`` (nearest-neighbor retrieval).

    Args layout: index.search(query, count=10, ...)
        query: numpy array or list of query vectors
        count: int, number of nearest neighbors
    Returns: Matches object with .keys, .distances attributes
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    count = 0
    ndim = _get_ndim(instance)
    metric = _get_metric(instance)
    index_size = _get_size(instance)

    try:
        if len(args) > 1:
            count = int(args[1])
        count = int(kwargs.get("count", count))
    except Exception:
        pass

    try:
        span = start_retrieval_span(query="usearch.search", source="usearch")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Count actual results from Matches object
            results_count = 0
            if result is not None:
                keys = getattr(result, "keys", None)
                if keys is not None and hasattr(keys, "__len__"):
                    results_count = len(keys)
                elif hasattr(result, "__len__"):
                    results_count = len(result)

            span.set_attribute("waxell.retrieval.source", "usearch")
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            if count:
                span.set_attribute("waxell.retrieval.top_k", count)
            if ndim:
                span.set_attribute("waxell.usearch.ndim", ndim)
            if metric:
                span.set_attribute("waxell.usearch.metric", metric)
            if index_size:
                span.set_attribute("waxell.usearch.index_size", index_size)
        except Exception as attr_exc:
            logger.debug("Failed to set USearch search span attributes: %s", attr_exc)

        try:
            _record_usearch_retrieval(
                results_count=results_count if "results_count" in dir() else 0,
                top_k=count,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _add_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.add`` (adding vectors to the index).

    Args layout: index.add(keys, vectors, ...)
        keys: array of integer keys
        vectors: numpy array of vectors
    """
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    n_vectors = 0
    ndim = _get_ndim(instance)

    try:
        if args:
            keys = args[0]
            if hasattr(keys, "shape"):
                n_vectors = int(keys.shape[0])
            elif hasattr(keys, "__len__"):
                n_vectors = len(keys)
    except Exception:
        pass

    try:
        span = start_tool_span(tool_name="usearch.add", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "add")
            span.set_attribute("waxell.vectordb.vectors_count", n_vectors)
            if ndim:
                span.set_attribute("waxell.usearch.ndim", ndim)
        except Exception as attr_exc:
            logger.debug("Failed to set USearch add span attributes: %s", attr_exc)

        try:
            _record_usearch_write(
                n_vectors=n_vectors,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_usearch_retrieval(
    results_count: int,
    top_k: int,
) -> None:
    """Record a USearch retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query="usearch.search",
            source="usearch",
            results_count=results_count,
            top_k=top_k,
        )


def _record_usearch_write(
    n_vectors: int,
) -> None:
    """Record a USearch write operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name="usearch.add",
            input={"n_vectors": n_vectors},
            tool_type="vectordb",
        )
