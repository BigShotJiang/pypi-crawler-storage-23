"""LangSmith auto-instrumentor for waxell-observe.

Monkey-patches ``langsmith.Client.create_run``, ``langsmith.Client.update_run``,
and evaluation methods to emit step and guardrail spans tracking LangSmith
run creation, updates, and evaluation operations.

LangSmith is LangChain's tracing and evaluation platform. This instrumentor
captures LangSmith client operations as Waxell spans for unified observability.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LangSmithInstrumentor(BaseInstrumentor):
    """Instrumentor for LangSmith (``langsmith`` package).

    Patches ``Client.create_run()``, ``Client.update_run()``, and
    evaluation methods.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import langsmith  # noqa: F401
        except ImportError:
            logger.debug("langsmith package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping LangSmith instrumentation")
            return False

        patched = False

        # Patch Client.create_run()
        try:
            wrapt.wrap_function_wrapper(
                "langsmith",
                "Client.create_run",
                _create_run_wrapper,
            )
            patched = True
            logger.debug("langsmith.Client.create_run patched")
        except Exception as exc:
            logger.debug("Failed to patch langsmith.Client.create_run: %s", exc)

        # Patch Client.update_run()
        try:
            wrapt.wrap_function_wrapper(
                "langsmith",
                "Client.update_run",
                _update_run_wrapper,
            )
            patched = True
            logger.debug("langsmith.Client.update_run patched")
        except Exception as exc:
            logger.debug("Failed to patch langsmith.Client.update_run: %s", exc)

        # Patch Client.create_feedback()
        try:
            wrapt.wrap_function_wrapper(
                "langsmith",
                "Client.create_feedback",
                _create_feedback_wrapper,
            )
            patched = True
            logger.debug("langsmith.Client.create_feedback patched")
        except Exception as exc:
            logger.debug("Failed to patch langsmith.Client.create_feedback: %s", exc)

        # Patch langsmith.evaluation.evaluate if available
        try:
            wrapt.wrap_function_wrapper(
                "langsmith.evaluation",
                "evaluate",
                _evaluate_wrapper,
            )
            patched = True
            logger.debug("langsmith.evaluation.evaluate patched")
        except Exception as exc:
            logger.debug("Failed to patch langsmith.evaluation.evaluate: %s", exc)

        if not patched:
            logger.debug("Could not find any LangSmith methods to patch")
            return False

        self._instrumented = True
        logger.debug("LangSmith instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import langsmith

            for attr in ("create_run", "update_run", "create_feedback"):
                method = getattr(langsmith.Client, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(langsmith.Client, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        try:
            import langsmith.evaluation as eval_module

            if hasattr(getattr(eval_module, "evaluate", None), "__wrapped__"):
                eval_module.evaluate = eval_module.evaluate.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("LangSmith uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _create_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Client.create_run()`` -- run creation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    run_name = kwargs.get("name", "") or ""
    run_type = kwargs.get("run_type", "") or ""
    inputs = kwargs.get("inputs", None)
    extra = kwargs.get("extra", {})

    try:
        span = start_step_span(
            step_name=f"langsmith.create_run:{run_name}" if run_name else "langsmith.create_run"
        )
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "langsmith")
        span.set_attribute("waxell.langsmith.operation", "create_run")
        if run_name:
            span.set_attribute("waxell.langsmith.run_name", str(run_name)[:200])
        if run_type:
            span.set_attribute("waxell.langsmith.run_type", str(run_type)[:100])
        if inputs is not None:
            span.set_attribute("waxell.langsmith.inputs_preview", str(inputs)[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_langsmith_run("create_run", run_name, run_type, inputs, None)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _update_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Client.update_run()`` -- run update."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    run_id = args[0] if args else kwargs.get("run_id", "")
    outputs = kwargs.get("outputs", None)
    error = kwargs.get("error", None)
    end_time = kwargs.get("end_time", None)

    try:
        span = start_step_span(step_name="langsmith.update_run")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "langsmith")
        span.set_attribute("waxell.langsmith.operation", "update_run")
        if run_id:
            span.set_attribute("waxell.langsmith.run_id", str(run_id)[:100])
        if outputs is not None:
            span.set_attribute("waxell.langsmith.outputs_preview", str(outputs)[:500])
        if error is not None:
            span.set_attribute("waxell.langsmith.error", str(error)[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_langsmith_run("update_run", "", "", None, outputs, error=error)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _create_feedback_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Client.create_feedback()`` -- feedback/evaluation."""
    try:
        from ..tracing.spans import start_guardrail_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    run_id = args[0] if args else kwargs.get("run_id", "")
    key = kwargs.get("key", "") or (args[1] if len(args) > 1 else "")
    score = kwargs.get("score", None)
    value = kwargs.get("value", None)
    comment = kwargs.get("comment", None)

    try:
        span = start_guardrail_span(
            guardrail_name=f"langsmith.feedback:{key}" if key else "langsmith.feedback",
            framework="langsmith",
        )
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "langsmith")
        span.set_attribute("waxell.langsmith.operation", "create_feedback")
        if key:
            span.set_attribute(WaxellAttributes.EVAL_METRIC_NAME, str(key)[:200])
        if score is not None:
            span.set_attribute(WaxellAttributes.EVAL_SCORE, float(score))
        if value is not None:
            span.set_attribute("waxell.langsmith.feedback_value", str(value)[:500])
        if comment:
            span.set_attribute(WaxellAttributes.EVAL_REASON, str(comment)[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_langsmith_feedback(key, score, value, comment)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _evaluate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``langsmith.evaluation.evaluate`` -- batch evaluation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    target = args[0] if args else kwargs.get("target", None)
    data = kwargs.get("data", None)
    evaluators = kwargs.get("evaluators", [])
    experiment_prefix = kwargs.get("experiment_prefix", "")

    dataset_size = 0
    try:
        if data is not None:
            dataset_size = len(data)
    except Exception:
        pass

    evaluators_count = len(evaluators) if isinstance(evaluators, (list, tuple)) else 0

    try:
        span = start_step_span(step_name="langsmith.evaluate")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "langsmith")
        span.set_attribute("waxell.langsmith.operation", "evaluate")
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, dataset_size)
        span.set_attribute(WaxellAttributes.EVAL_METRICS_COUNT, evaluators_count)
        if experiment_prefix:
            span.set_attribute("waxell.langsmith.experiment_prefix", str(experiment_prefix)[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_eval_result(span, result, dataset_size, evaluators_count)
        except Exception:
            pass

        try:
            _record_http_langsmith_eval(result, dataset_size, evaluators_count)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_eval_result(span, result, dataset_size: int, evaluators_count: int) -> None:
    """Extract evaluation results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    try:
        # LangSmith evaluate() returns an EvaluationResults object
        results = getattr(result, "results", None)
        if results is not None and isinstance(results, (list, tuple)):
            passed = 0
            failed = 0
            for r in results:
                eval_results = getattr(r, "evaluation_results", None)
                if eval_results is not None:
                    results_list = getattr(eval_results, "results", [])
                    for er in (results_list if isinstance(results_list, (list, tuple)) else []):
                        score = getattr(er, "score", None)
                        if score is not None and score >= 0.5:
                            passed += 1
                        else:
                            failed += 1

            total = passed + failed
            pass_rate = passed / total if total > 0 else 0.0
            span.set_attribute(WaxellAttributes.EVAL_PASSED, passed)
            span.set_attribute("waxell.eval.failed", failed)
            span.set_attribute(WaxellAttributes.EVAL_PASS_RATE, pass_rate)
    except Exception:
        pass


def _record_http_langsmith_run(operation: str, run_name: str, run_type: str,
                                inputs, outputs, error=None) -> None:
    """Record a LangSmith run operation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"trace:langsmith.{operation}",
            output={
                "framework": "langsmith",
                "operation": operation,
                "run_name": str(run_name)[:200] if run_name else "",
                "run_type": str(run_type)[:100] if run_type else "",
                "inputs_preview": str(inputs)[:500] if inputs else "",
                "outputs_preview": str(outputs)[:500] if outputs else "",
                "error": str(error)[:500] if error else "",
            },
        )


def _record_http_langsmith_feedback(key: str, score, value, comment) -> None:
    """Record a LangSmith feedback to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"eval:langsmith.feedback:{key}" if key else "eval:langsmith.feedback",
            output={
                "framework": "langsmith",
                "key": str(key)[:200] if key else "",
                "score": float(score) if score is not None else None,
                "value": str(value)[:500] if value is not None else "",
                "comment": str(comment)[:500] if comment else "",
            },
        )


def _record_http_langsmith_eval(result, dataset_size: int, evaluators_count: int) -> None:
    """Record a LangSmith evaluation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:langsmith.evaluate",
            output={
                "framework": "langsmith",
                "dataset_size": dataset_size,
                "evaluators_count": evaluators_count,
                "result_preview": str(result)[:500],
            },
        )


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
