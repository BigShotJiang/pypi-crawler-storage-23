"""Qdrant auto-instrumentor for waxell-observe.

Monkey-patches ``qdrant_client.QdrantClient`` and ``qdrant_client.AsyncQdrantClient``
methods to emit OTel spans and record retrieval/write operations to the Waxell
HTTP API.

Patched methods on QdrantClient (sync):
  - ``query_points``  -- retrieval span
  - ``search``        -- retrieval span
  - ``upsert``        -- tool span (write)
  - ``delete``        -- tool span (write)

Patched methods on AsyncQdrantClient (async, if available):
  - ``query_points``  -- retrieval span
  - ``search``        -- retrieval span
  - ``upsert``        -- tool span (write)
  - ``delete``        -- tool span (write)

All wrapper code is wrapped in try/except -- never breaks user code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class QdrantInstrumentor(BaseInstrumentor):
    """Instrumentor for the Qdrant Python client (``qdrant-client`` package).

    Patches sync ``QdrantClient`` and async ``AsyncQdrantClient`` for search
    (retrieval spans) and write operations (tool spans).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import qdrant_client  # noqa: F401
        except ImportError:
            logger.debug("qdrant-client package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Qdrant instrumentation")
            return False

        patched_any = False

        # --- Sync QdrantClient ---
        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "QdrantClient.query_points",
                _sync_query_points_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch QdrantClient.query_points")

        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "QdrantClient.search",
                _sync_search_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch QdrantClient.search")

        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "QdrantClient.upsert",
                _sync_upsert_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch QdrantClient.upsert")

        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "QdrantClient.delete",
                _sync_delete_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch QdrantClient.delete")

        # --- Async AsyncQdrantClient (optional, may not be present) ---
        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "AsyncQdrantClient.query_points",
                _async_query_points_wrapper,
            )
        except Exception:
            logger.debug("Could not patch AsyncQdrantClient.query_points")

        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "AsyncQdrantClient.search",
                _async_search_wrapper,
            )
        except Exception:
            logger.debug("Could not patch AsyncQdrantClient.search")

        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "AsyncQdrantClient.upsert",
                _async_upsert_wrapper,
            )
        except Exception:
            logger.debug("Could not patch AsyncQdrantClient.upsert")

        try:
            wrapt.wrap_function_wrapper(
                "qdrant_client",
                "AsyncQdrantClient.delete",
                _async_delete_wrapper,
            )
        except Exception:
            logger.debug("Could not patch AsyncQdrantClient.delete")

        if not patched_any:
            logger.debug("Could not patch any QdrantClient methods")
            return False

        self._instrumented = True
        logger.debug("Qdrant QdrantClient instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import qdrant_client

            sync_cls = getattr(qdrant_client, "QdrantClient", None)
            if sync_cls is not None:
                for method_name in ("query_points", "search", "upsert", "delete"):
                    method = getattr(sync_cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(sync_cls, method_name, method.__wrapped__)

            async_cls = getattr(qdrant_client, "AsyncQdrantClient", None)
            if async_cls is not None:
                for method_name in ("query_points", "search", "upsert", "delete"):
                    method = getattr(async_cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(async_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Qdrant QdrantClient uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_collection_name(args, kwargs) -> str:
    """Extract collection_name from positional or keyword args."""
    # Most Qdrant methods: first positional arg is collection_name
    if args:
        first = args[0]
        if isinstance(first, str):
            return first
    return kwargs.get("collection_name", "") or ""


def _get_limit(kwargs) -> int:
    """Extract limit from kwargs, defaulting to 0 if not present."""
    limit = kwargs.get("limit", None)
    if limit is not None:
        try:
            return int(limit)
        except (TypeError, ValueError):
            pass
    return 0


def _count_results(response) -> int:
    """Count the number of results returned from a search/query response."""
    try:
        # query_points returns QueryResponse or ScoredPoint list
        if response is None:
            return 0
        # QueryResponse has a .points attribute
        points = getattr(response, "points", None)
        if points is not None:
            return len(points)
        # Direct list of ScoredPoint objects
        if isinstance(response, (list, tuple)):
            return len(response)
    except Exception:
        pass
    return 0


def _count_points_to_write(args, kwargs) -> int:
    """Count the number of points in an upsert operation."""
    try:
        # upsert(collection_name, points=...) or upsert(collection_name, PointsList)
        points = kwargs.get("points", None)
        if points is None and len(args) > 1:
            points = args[1]
        if points is None:
            return 0
        # Batch object: has .ids or .vectors
        ids = getattr(points, "ids", None)
        if ids is not None:
            return len(ids)
        # PointsList or list of PointStruct
        inner = getattr(points, "points", None)
        if inner is not None:
            return len(inner)
        if isinstance(points, (list, tuple)):
            return len(points)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper functions
# ---------------------------------------------------------------------------


def _sync_query_points_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``QdrantClient.query_points``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)
    limit = _get_limit(kwargs)

    try:
        span = start_retrieval_span(query=collection_name, source="qdrant")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            if limit:
                span.set_attribute("waxell.retrieval.limit", limit)
            span.set_attribute("waxell.retrieval.operation", "query_points")
        except Exception:
            pass

        try:
            response = wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        try:
            count = _count_results(response)
            span.set_attribute("waxell.retrieval.results_count", count)
        except Exception:
            count = 0

        try:
            from ._context_var import _current_context
            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_retrieval(query=collection_name, source="qdrant", results_count=count)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


def _sync_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``QdrantClient.search``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)
    limit = _get_limit(kwargs)

    try:
        span = start_retrieval_span(query=collection_name, source="qdrant")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            if limit:
                span.set_attribute("waxell.retrieval.limit", limit)
            span.set_attribute("waxell.retrieval.operation", "search")
        except Exception:
            pass

        try:
            response = wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        try:
            count = _count_results(response)
            span.set_attribute("waxell.retrieval.results_count", count)
        except Exception:
            count = 0

        try:
            from ._context_var import _current_context
            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_retrieval(query=collection_name, source="qdrant", results_count=count)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


def _sync_upsert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``QdrantClient.upsert``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)
    points_count = _count_points_to_write(args, kwargs)

    try:
        span = start_tool_span(tool_name="qdrant.upsert", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            span.set_attribute("waxell.vectordb.operation", "upsert")
            if points_count:
                span.set_attribute("waxell.vectordb.points_count", points_count)
        except Exception:
            pass

        try:
            response = wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


def _sync_delete_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``QdrantClient.delete``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)

    try:
        span = start_tool_span(tool_name="qdrant.delete", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            span.set_attribute("waxell.vectordb.operation", "delete")
        except Exception:
            pass

        try:
            response = wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Async wrapper functions
# ---------------------------------------------------------------------------


async def _async_query_points_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncQdrantClient.query_points``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)
    limit = _get_limit(kwargs)

    try:
        span = start_retrieval_span(query=collection_name, source="qdrant")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            if limit:
                span.set_attribute("waxell.retrieval.limit", limit)
            span.set_attribute("waxell.retrieval.operation", "query_points")
        except Exception:
            pass

        try:
            response = await wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        try:
            count = _count_results(response)
            span.set_attribute("waxell.retrieval.results_count", count)
        except Exception:
            count = 0

        try:
            from ._context_var import _current_context
            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_retrieval(query=collection_name, source="qdrant", results_count=count)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


async def _async_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncQdrantClient.search``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)
    limit = _get_limit(kwargs)

    try:
        span = start_retrieval_span(query=collection_name, source="qdrant")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            if limit:
                span.set_attribute("waxell.retrieval.limit", limit)
            span.set_attribute("waxell.retrieval.operation", "search")
        except Exception:
            pass

        try:
            response = await wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        try:
            count = _count_results(response)
            span.set_attribute("waxell.retrieval.results_count", count)
        except Exception:
            count = 0

        try:
            from ._context_var import _current_context
            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_retrieval(query=collection_name, source="qdrant", results_count=count)
        except Exception:
            pass

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


async def _async_upsert_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncQdrantClient.upsert``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)
    points_count = _count_points_to_write(args, kwargs)

    try:
        span = start_tool_span(tool_name="qdrant.upsert", tool_type="vectordb")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            span.set_attribute("waxell.vectordb.operation", "upsert")
            if points_count:
                span.set_attribute("waxell.vectordb.points_count", points_count)
        except Exception:
            pass

        try:
            response = await wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass


async def _async_delete_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncQdrantClient.delete``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    collection_name = _get_collection_name(args, kwargs)

    try:
        span = start_tool_span(tool_name="qdrant.delete", tool_type="vectordb")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        try:
            span.set_attribute("waxell.retrieval.collection", collection_name)
            span.set_attribute("waxell.vectordb.operation", "delete")
        except Exception:
            pass

        try:
            response = await wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise

        return response
    finally:
        try:
            span.end()
        except Exception:
            pass
