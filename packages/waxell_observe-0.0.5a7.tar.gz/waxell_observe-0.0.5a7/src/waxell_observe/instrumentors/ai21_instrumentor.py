"""AI21 Labs auto-instrumentor for waxell-observe.

Monkey-patches ``ai21.AI21Client.chat.completions.create`` (sync) and
``ai21.AsyncAI21Client.chat.completions.create`` (async) to emit OTel spans
with GenAI semantic convention attributes.

The AI21 SDK (v2+) uses an OpenAI-compatible chat completions interface:
  - ``response.choices[].message.content``
  - ``response.usage.prompt_tokens`` / ``completion_tokens``
  - ``response.model``

Models: jamba-1.5-large, jamba-1.5-mini, jamba-instruct

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AI21Instrumentor(BaseInstrumentor):
    """Instrumentor for the AI21 Labs Python SDK (``ai21`` package).

    Patches ``AI21Client.chat.completions.create`` (sync) and
    ``AsyncAI21Client.chat.completions.create`` (async).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import ai21  # noqa: F401
        except ImportError:
            logger.debug("ai21 package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping AI21 instrumentation")
            return False

        patched = False

        # AI21 SDK v2+ structure: ai21.AI21Client has chat.completions.create
        # The SDK mirrors OpenAI's interface for Jamba models.
        try:
            wrapt.wrap_function_wrapper(
                "ai21.clients.studio.resources.chat",
                "ChatCompletions.create",
                _sync_chat_wrapper,
            )
            patched = True
        except Exception:
            # Try alternative module path for different SDK versions
            try:
                wrapt.wrap_function_wrapper(
                    "ai21.clients.studio.resources.chat.chat_completions",
                    "ChatCompletions.create",
                    _sync_chat_wrapper,
                )
                patched = True
            except Exception:
                pass

        # Async variant
        try:
            wrapt.wrap_function_wrapper(
                "ai21.clients.studio.resources.chat",
                "AsyncChatCompletions.create",
                _async_chat_wrapper,
            )
        except Exception:
            try:
                wrapt.wrap_function_wrapper(
                    "ai21.clients.studio.resources.chat.chat_completions",
                    "AsyncChatCompletions.create",
                    _async_chat_wrapper,
                )
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find AI21 chat completion methods to patch")
            return False

        self._instrumented = True
        logger.debug("AI21 chat.completions instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Try both possible module paths
        for mod_path in (
            "ai21.clients.studio.resources.chat",
            "ai21.clients.studio.resources.chat.chat_completions",
        ):
            try:
                import importlib

                mod = importlib.import_module(mod_path)

                if hasattr(mod, "ChatCompletions"):
                    if hasattr(mod.ChatCompletions.create, "__wrapped__"):
                        mod.ChatCompletions.create = mod.ChatCompletions.create.__wrapped__  # type: ignore[attr-defined]

                if hasattr(mod, "AsyncChatCompletions"):
                    if hasattr(mod.AsyncChatCompletions.create, "__wrapped__"):
                        mod.AsyncChatCompletions.create = mod.AsyncChatCompletions.create.__wrapped__  # type: ignore[attr-defined]
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        logger.debug("AI21 chat.completions uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions (module-level for wrapt compatibility)
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for AI21 ``ChatCompletions.create``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="ai21")
    except Exception:
        return wrapped(*args, **kwargs)

    if is_streaming:
        # Streaming: return response and mark span
        try:
            stream = wrapped(*args, **kwargs)
            # End span immediately for streaming -- token counts unknown
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.end()
            return stream
        except Exception as exc:
            _record_error(span, exc)
            raise

    # Non-streaming: full instrumentation
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            choices = getattr(response, "choices", None)
            finish_reasons = (
                [c.finish_reason for c in choices if c.finish_reason]
                if choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API (never breaks the LLM call)
        try:
            _record_http_ai21(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for AI21 ``AsyncChatCompletions.create``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []), model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="ai21")
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        try:
            stream = await wrapped(*args, **kwargs)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.end()
            return stream
        except Exception as exc:
            _record_error(span, exc)
            raise

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            choices = getattr(response, "choices", None)
            finish_reasons = (
                [c.finish_reason for c in choices if c.finish_reason]
                if choices
                else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_ai21(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_ai21(response, request_model: str, kwargs: dict) -> None:
    """Record an AI21 LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    usage = getattr(response, "usage", None)
    tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
    tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    messages = kwargs.get("messages", [])
    prompt_preview = ""
    if messages:
        first_content = messages[0].get("content", "") if isinstance(messages[0], dict) else ""
        prompt_preview = str(first_content)[:500]

    response_preview = ""
    choices = getattr(response, "choices", None)
    if choices:
        msg = choices[0].message
        if msg and getattr(msg, "content", None):
            response_preview = msg.content[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat.completions",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
