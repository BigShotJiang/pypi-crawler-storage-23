"""SingleStore vector auto-instrumentor for waxell-observe.

Monkey-patches singlestoredb cursor execute methods to detect vector
function operations (DOT_PRODUCT, EUCLIDEAN_DISTANCE, etc.) and emit
retrieval spans.

Patched methods:
  - ``singlestoredb.connection.Cursor.execute``  (retrieval span, vector queries only)

Non-vector queries are passed through without any span creation.
All wrapper code is wrapped in try/except -- never breaks the user's database calls.
"""

from __future__ import annotations

import logging
import re

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Patterns that indicate a SingleStore vector operation.
_VECTOR_PATTERNS = re.compile(
    r"\bDOT_PRODUCT\b"
    r"|\bEUCLIDEAN_DISTANCE\b"
    r"|\bJSON_ARRAY_PACK\b"
    r"|\bJSON_ARRAY_UNPACK\b"
    r"|\bVECTOR_SORT\b"
    r"|\bVECTOR_KTH_ELEMENT\b"
    r"|\bVECTOR_NUM_ELEMENTS\b"
    r"|\bVECTOR_SUB\b"
    r"|\bSCALAR_SUB\b",
    re.IGNORECASE,
)

# Specific distance/similarity functions for classification.
_DISTANCE_FUNCTIONS = {
    "dot_product": re.compile(r"\bDOT_PRODUCT\b", re.IGNORECASE),
    "euclidean_distance": re.compile(r"\bEUCLIDEAN_DISTANCE\b", re.IGNORECASE),
}


def _is_vector_query(sql: str) -> bool:
    """Return True if the SQL string contains SingleStore vector functions."""
    if not sql or not isinstance(sql, str):
        return False
    return _VECTOR_PATTERNS.search(sql) is not None


def _detect_vector_function(sql: str) -> str:
    """Detect which SingleStore vector function is primarily used."""
    for fn_name, pattern in _DISTANCE_FUNCTIONS.items():
        if pattern.search(sql):
            return fn_name
    # Fallback: check for general vector operations
    if _VECTOR_PATTERNS.search(sql):
        return "vector_operation"
    return "unknown"


class SinglestoreInstrumentor(BaseInstrumentor):
    """Instrumentor for SingleStore vector operations via singlestoredb.

    Patches cursor execute methods and detects vector-specific SQL patterns.
    Only creates retrieval spans for queries that contain SingleStore vector
    functions (``DOT_PRODUCT``, ``EUCLIDEAN_DISTANCE``, etc.).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import singlestoredb  # noqa: F401
        except ImportError:
            logger.debug("singlestoredb package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping SingleStore instrumentation")
            return False

        patched_any = False

        # --- Cursor.execute (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "singlestoredb.connection",
                "Cursor.execute",
                _sync_execute_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch singlestoredb Cursor.execute: %s", exc)

        # --- Cursor.executemany (sync, for batch vector operations) ---
        try:
            wrapt.wrap_function_wrapper(
                "singlestoredb.connection",
                "Cursor.executemany",
                _sync_executemany_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch singlestoredb Cursor.executemany: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any singlestoredb Cursor methods")
            return False

        self._instrumented = True
        logger.debug("SingleStore instrumented (Cursor.execute, Cursor.executemany)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import singlestoredb.connection as conn_mod

            cursor_cls = getattr(conn_mod, "Cursor", None)
            if cursor_cls is not None:
                for method_name in ("execute", "executemany"):
                    method = getattr(cursor_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cursor_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("SingleStore uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the SQL query string from positional or keyword args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", kwargs.get("sql", "")))


def _truncate_query(sql: str, max_len: int = 500) -> str:
    """Truncate SQL for span labelling."""
    if len(sql) > max_len:
        return sql[:max_len] + "..."
    return sql


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_execute_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for singlestoredb Cursor.execute -- only instruments vector queries."""
    query = _extract_query(args, kwargs)
    if not _is_vector_query(query):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)
    vector_function = _detect_vector_function(query)

    try:
        span = start_retrieval_span(query=query_preview, source="singlestore")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "singlestore")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.vector_function", vector_function)
        except Exception as attr_exc:
            logger.debug("Failed to set SingleStore execute span attributes: %s", attr_exc)

        # Try to get result count from the cursor
        result_count = 0
        try:
            if hasattr(instance, "rowcount") and instance.rowcount is not None and instance.rowcount >= 0:
                result_count = instance.rowcount
                span.set_attribute("waxell.retrieval.results_count", result_count)
        except Exception:
            pass

        try:
            _record_singlestore_retrieval(
                query=query_preview,
                vector_function=vector_function,
                results_count=result_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_executemany_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for singlestoredb Cursor.executemany -- only instruments vector queries."""
    query = _extract_query(args, kwargs)
    if not _is_vector_query(query):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)
    vector_function = _detect_vector_function(query)

    try:
        span = start_retrieval_span(query=query_preview, source="singlestore")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "singlestore")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.vector_function", vector_function)
            span.set_attribute("waxell.retrieval.operation", "executemany")
        except Exception as attr_exc:
            logger.debug("Failed to set SingleStore executemany span attributes: %s", attr_exc)

        try:
            _record_singlestore_retrieval(
                query=query_preview,
                vector_function=vector_function,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_singlestore_retrieval(
    query: str,
    vector_function: str,
    results_count: int = 0,
) -> None:
    """Record a SingleStore vector retrieval operation to the context path.

    SingleStore vector retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="singlestore",
            results_count=results_count,
        )
