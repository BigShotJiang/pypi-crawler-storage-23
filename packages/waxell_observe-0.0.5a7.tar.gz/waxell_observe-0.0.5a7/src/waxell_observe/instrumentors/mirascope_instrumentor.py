"""Mirascope auto-instrumentor for waxell-observe.

Monkey-patches Mirascope's internal call execution path to emit OTel spans
and record to the Waxell HTTP API.

Mirascope uses decorators like ``@mirascope.openai.call``,
``@mirascope.anthropic.call``, etc. to wrap functions that return prompts
into full LLM calls.  Since Mirascope wraps underlying providers (OpenAI,
Anthropic, etc.), the actual LLM call may already be captured by our
provider-specific instrumentors.  This instrumentor captures the
Mirascope-level context: which decorator was used, which provider was
chosen, and the prompt template.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MirascopeInstrumentor(BaseInstrumentor):
    """Instrumentor for Mirascope (``mirascope`` package).

    Patches the common call execution path to capture framework-level
    context around LLM calls made through Mirascope decorators.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import mirascope  # noqa: F401
        except ImportError:
            logger.debug("mirascope not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Mirascope instrumentation")
            return False

        patched = False

        # Strategy: Mirascope's call decorators funnel through a common
        # create/call path.  We try multiple known internal locations
        # from most general to most specific.

        # Attempt 1: Patch the base call decorator's internal execution
        # mirascope.core.base.call wraps the user function and calls the
        # provider-specific client.  The decorator factory returns a
        # wrapper that calls _call or _create internally.
        try:
            wrapt.wrap_function_wrapper(
                "mirascope.core.base._create",
                "create_factory",
                _create_factory_wrapper,
            )
            patched = True
            logger.debug("Patched mirascope.core.base._create.create_factory")
        except Exception as exc:
            logger.debug("Could not patch mirascope create_factory: %s", exc)

        # Attempt 2: Patch the stream creation factory
        try:
            wrapt.wrap_function_wrapper(
                "mirascope.core.base._stream",
                "stream_factory",
                _stream_factory_wrapper,
            )
            logger.debug("Patched mirascope.core.base._stream.stream_factory")
        except Exception as exc:
            logger.debug("Could not patch mirascope stream_factory: %s", exc)

        # Attempt 3: Patch provider-specific call decorators as fallback
        _providers = [
            ("mirascope.core.openai.call_response", "OpenAICallResponse"),
            ("mirascope.core.anthropic.call_response", "AnthropicCallResponse"),
            ("mirascope.core.gemini.call_response", "GeminiCallResponse"),
            ("mirascope.core.mistral.call_response", "MistralCallResponse"),
        ]
        for module_path, class_name in _providers:
            try:
                wrapt.wrap_function_wrapper(
                    module_path,
                    f"{class_name}.__init__",
                    _call_response_init_wrapper,
                )
                patched = True
                logger.debug("Patched %s.%s.__init__", module_path, class_name)
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find Mirascope methods to patch")
            return False

        self._instrumented = True
        logger.debug("Mirascope instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore create_factory
        try:
            from mirascope.core.base import _create

            if hasattr(_create.create_factory, "__wrapped__"):
                _create.create_factory = _create.create_factory.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore stream_factory
        try:
            from mirascope.core.base import _stream

            if hasattr(_stream.stream_factory, "__wrapped__"):
                _stream.stream_factory = _stream.stream_factory.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore provider-specific call response __init__
        _providers = [
            ("mirascope.core.openai.call_response", "OpenAICallResponse"),
            ("mirascope.core.anthropic.call_response", "AnthropicCallResponse"),
            ("mirascope.core.gemini.call_response", "GeminiCallResponse"),
            ("mirascope.core.mistral.call_response", "MistralCallResponse"),
        ]
        for module_path, class_name in _providers:
            try:
                import importlib

                mod = importlib.import_module(module_path)
                cls = getattr(mod, class_name, None)
                if cls and hasattr(cls.__init__, "__wrapped__"):
                    cls.__init__ = cls.__init__.__wrapped__
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        logger.debug("Mirascope uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _create_factory_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``create_factory`` -- common Mirascope call creation path."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Try to extract provider and model info from the factory arguments
    provider = "mirascope"
    model = "unknown"

    try:
        # create_factory often receives a model kwarg or config
        if args:
            first_arg = args[0]
            # Check if it's a call config or model string
            if isinstance(first_arg, str):
                model = first_arg
            elif hasattr(first_arg, "model"):
                model = str(getattr(first_arg, "model", "unknown"))
    except Exception:
        pass

    try:
        # Detect provider from kwargs
        _provider_name = kwargs.get("provider", "")
        if _provider_name:
            provider = str(_provider_name)
    except Exception:
        pass

    try:
        span = start_llm_span(model=model, provider_name="mirascope")
        span.set_attribute("waxell.mirascope.provider", provider)
        span.set_attribute("waxell.mirascope.model", model)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("waxell.mirascope.latency_ms", latency_ms)

            # Try to extract response details
            if hasattr(result, "response"):
                resp = result.response
                if hasattr(resp, "model"):
                    span.set_attribute("waxell.mirascope.model", str(resp.model))
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_mirascope(result, model, provider)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _stream_factory_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``stream_factory`` -- Mirascope streaming path."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    provider = "mirascope"
    model = "unknown"

    try:
        if args:
            first_arg = args[0]
            if isinstance(first_arg, str):
                model = first_arg
            elif hasattr(first_arg, "model"):
                model = str(getattr(first_arg, "model", "unknown"))
    except Exception:
        pass

    try:
        span = start_llm_span(model=model, provider_name="mirascope")
        span.set_attribute("waxell.mirascope.provider", provider)
        span.set_attribute("waxell.mirascope.model", model)
        span.set_attribute("waxell.mirascope.mode", "streaming")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


def _call_response_init_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for provider-specific CallResponse.__init__.

    Captures the provider and model from the response object after
    it has been constructed by the underlying provider call.
    """
    # Always let the original __init__ run first
    result = wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_llm_span

        provider_name = "mirascope"
        model = "unknown"

        # Extract provider from class name (e.g., OpenAICallResponse -> openai)
        try:
            class_name = type(instance).__name__
            if "OpenAI" in class_name:
                provider_name = "openai"
            elif "Anthropic" in class_name:
                provider_name = "anthropic"
            elif "Gemini" in class_name:
                provider_name = "google"
            elif "Mistral" in class_name:
                provider_name = "mistral"
        except Exception:
            pass

        # Extract model from the response
        try:
            if hasattr(instance, "model"):
                model = str(instance.model)
            elif hasattr(instance, "response") and hasattr(instance.response, "model"):
                model = str(instance.response.model)
        except Exception:
            pass

        # Extract prompt preview
        prompt_preview = ""
        try:
            if hasattr(instance, "prompt"):
                prompt_preview = str(instance.prompt)[:200]
            elif hasattr(instance, "messages") and instance.messages:
                prompt_preview = str(instance.messages[0])[:200]
        except Exception:
            pass

        span = start_llm_span(model=model, provider_name="mirascope")
        span.set_attribute("waxell.mirascope.provider", provider_name)
        span.set_attribute("waxell.mirascope.model", model)
        if prompt_preview:
            span.set_attribute("waxell.mirascope.prompt_preview", prompt_preview)
        span.end()

    except Exception:
        pass

    return result


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_http_mirascope(result, model: str, provider: str) -> None:
    """Record a Mirascope call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    response_preview = ""
    try:
        if hasattr(result, "content"):
            response_preview = str(result.content)[:500]
        elif hasattr(result, "response"):
            response_preview = str(result.response)[:500]
        else:
            response_preview = str(result)[:500]
    except Exception:
        pass

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"mirascope.call:{provider}",
        "prompt_preview": "",
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
