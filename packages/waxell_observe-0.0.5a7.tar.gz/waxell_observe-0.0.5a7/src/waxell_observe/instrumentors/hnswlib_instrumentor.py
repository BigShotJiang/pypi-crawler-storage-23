"""hnswlib auto-instrumentor for waxell-observe.

Monkey-patches the hnswlib library to emit OTel spans for
vector search and index operations.

Patched methods:
  - hnswlib.Index.knn_query   (retrieval span)
  - hnswlib.Index.add_items   (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's hnswlib calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class HnswlibInstrumentor(BaseInstrumentor):
    """Instrumentor for the hnswlib library (``hnswlib`` package).

    Patches ``Index.knn_query`` for retrieval spans and
    ``Index.add_items`` for tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import hnswlib  # noqa: F401
        except ImportError:
            logger.debug("hnswlib package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping hnswlib instrumentation")
            return False

        patched_any = False

        # Patch Index.knn_query (nearest-neighbor retrieval)
        try:
            wrapt.wrap_function_wrapper(
                "hnswlib",
                "Index.knn_query",
                _knn_query_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch hnswlib.Index.knn_query: %s", exc)

        # Patch Index.add_items (vector insertion)
        try:
            wrapt.wrap_function_wrapper(
                "hnswlib",
                "Index.add_items",
                _add_items_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch hnswlib.Index.add_items: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any hnswlib Index methods")
            return False

        self._instrumented = True
        logger.debug("hnswlib Index instrumented (knn_query, add_items)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import hnswlib

            cls = getattr(hnswlib, "Index", None)
            if cls is not None:
                for method_name in ("knn_query", "add_items"):
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("hnswlib Index uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_space(instance) -> str:
    """Extract the space/metric from an hnswlib Index instance."""
    try:
        space = getattr(instance, "space", None)
        if space is not None:
            return str(space)
    except Exception:
        pass
    return ""


def _get_dim(instance) -> int:
    """Extract the vector dimension from an hnswlib Index instance."""
    try:
        dim = getattr(instance, "dim", None)
        if dim is not None:
            return int(dim)
    except Exception:
        pass
    return 0


def _get_num_elements(instance) -> int:
    """Extract the current element count from an hnswlib Index instance."""
    try:
        fn = getattr(instance, "get_current_count", None)
        if callable(fn):
            return int(fn())
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _knn_query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.knn_query`` (nearest-neighbor retrieval).

    Args layout: index.knn_query(data, k=1, num_threads=-1, filter=None)
        data: numpy array of query vectors
        k: int, number of nearest neighbors
    Returns: (labels, distances) tuple of numpy arrays
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    k = 1
    nq = 0
    dimension = _get_dim(instance)
    space = _get_space(instance)
    num_elements = _get_num_elements(instance)

    try:
        if args:
            data = args[0]
            if hasattr(data, "shape"):
                if len(data.shape) == 2:
                    nq = int(data.shape[0])
                elif len(data.shape) == 1:
                    nq = 1
        if len(args) > 1:
            k = int(args[1])
        k = int(kwargs.get("k", k))
    except Exception:
        pass

    try:
        span = start_retrieval_span(query="hnswlib.knn_query", source="hnswlib")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Result is (labels, distances) tuple of numpy arrays
            results_count = 0
            if isinstance(result, (list, tuple)) and len(result) >= 1:
                labels = result[0]
                if hasattr(labels, "shape"):
                    if len(labels.shape) == 2:
                        results_count = int(labels.shape[0] * labels.shape[1])
                    elif len(labels.shape) == 1:
                        results_count = int(labels.shape[0])

            span.set_attribute("waxell.retrieval.source", "hnswlib")
            span.set_attribute("waxell.retrieval.operation", "knn_query")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            span.set_attribute("waxell.retrieval.top_k", k)
            if dimension:
                span.set_attribute("waxell.hnswlib.dimension", dimension)
            if space:
                span.set_attribute("waxell.hnswlib.space", space)
            if num_elements:
                span.set_attribute("waxell.hnswlib.num_elements", num_elements)
            span.set_attribute("waxell.hnswlib.nq", nq)
        except Exception as attr_exc:
            logger.debug("Failed to set hnswlib knn_query span attributes: %s", attr_exc)

        try:
            _record_hnswlib_retrieval(
                results_count=results_count if "results_count" in dir() else 0,
                top_k=k,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _add_items_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.add_items`` (adding vectors to the index).

    Args layout: index.add_items(data, ids=None, num_threads=-1)
        data: numpy array of shape (n, dim)
        ids: optional array of integer ids
    """
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    n_vectors = 0
    dimension = _get_dim(instance)
    space = _get_space(instance)

    try:
        if args:
            data = args[0]
            if hasattr(data, "shape"):
                if len(data.shape) == 2:
                    n_vectors = int(data.shape[0])
                elif len(data.shape) == 1:
                    n_vectors = 1
            elif hasattr(data, "__len__"):
                n_vectors = len(data)
    except Exception:
        pass

    try:
        span = start_tool_span(tool_name="hnswlib.add_items", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "add_items")
            span.set_attribute("waxell.vectordb.vectors_count", n_vectors)
            if dimension:
                span.set_attribute("waxell.hnswlib.dimension", dimension)
            if space:
                span.set_attribute("waxell.hnswlib.space", space)
        except Exception as attr_exc:
            logger.debug("Failed to set hnswlib add_items span attributes: %s", attr_exc)

        try:
            _record_hnswlib_write(
                n_vectors=n_vectors,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_hnswlib_retrieval(
    results_count: int,
    top_k: int,
) -> None:
    """Record an hnswlib retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query="hnswlib.knn_query",
            source="hnswlib",
            results_count=results_count,
            top_k=top_k,
        )


def _record_hnswlib_write(
    n_vectors: int,
) -> None:
    """Record an hnswlib write operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name="hnswlib.add_items",
            input={"n_vectors": n_vectors},
            tool_type="vectordb",
        )
