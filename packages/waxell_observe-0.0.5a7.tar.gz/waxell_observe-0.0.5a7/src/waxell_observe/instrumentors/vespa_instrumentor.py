"""Vespa auto-instrumentor for waxell-observe.

Monkey-patches the pyvespa Python client to emit OTel spans for
query (hybrid search + ML), feed, and delete operations.

Patched methods:
  - ``vespa.application.Vespa.query``           (retrieval span)
  - ``vespa.application.Vespa.feed_data_point`` (tool span)
  - ``vespa.application.Vespa.delete_data``     (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's Vespa calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class VespaInstrumentor(BaseInstrumentor):
    """Instrumentor for the pyvespa Python client (``pyvespa``).

    Patches ``Vespa.query``, ``Vespa.feed_data_point``, and
    ``Vespa.delete_data`` to emit OTel spans with hybrid search awareness.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import vespa  # noqa: F401
        except ImportError:
            logger.debug("pyvespa package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Vespa instrumentation")
            return False

        patched_any = False

        # --- Vespa.query ---
        try:
            wrapt.wrap_function_wrapper(
                "vespa.application",
                "Vespa.query",
                _sync_query_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch Vespa.query")

        # --- Vespa.feed_data_point ---
        try:
            wrapt.wrap_function_wrapper(
                "vespa.application",
                "Vespa.feed_data_point",
                _sync_feed_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch Vespa.feed_data_point")

        # --- Vespa.delete_data ---
        try:
            wrapt.wrap_function_wrapper(
                "vespa.application",
                "Vespa.delete_data",
                _sync_delete_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch Vespa.delete_data")

        if not patched_any:
            logger.debug("Could not patch any Vespa methods")
            return False

        self._instrumented = True
        logger.debug("Vespa instrumented (query, feed_data_point, delete_data)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from vespa import application as vespa_app

            cls = getattr(vespa_app, "Vespa", None)
            if cls is not None:
                for method_name in ("query", "feed_data_point", "delete_data"):
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Vespa uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query_text(args, kwargs) -> str:
    """Extract the query text from Vespa query arguments.

    pyvespa Vespa.query() accepts keyword args like ``yql``, ``query``,
    ``body``, or positional ``body`` dict.
    """
    # Check keyword args first
    yql = kwargs.get("yql", "")
    if yql:
        return str(yql)[:500]

    query = kwargs.get("query", "")
    if query:
        return str(query)[:500]

    # Check body dict
    body = kwargs.get("body", args[0] if args else None)
    if isinstance(body, dict):
        yql = body.get("yql", "")
        if yql:
            return str(yql)[:500]
        query = body.get("query", "")
        if query:
            return str(query)[:500]

    return ""


def _extract_schema_namespace(kwargs) -> tuple[str, str]:
    """Extract schema and namespace from Vespa call kwargs."""
    schema = kwargs.get("schema", "")
    namespace = kwargs.get("namespace", "")
    return str(schema) if schema else "", str(namespace) if namespace else ""


def _extract_hits_count(response) -> int:
    """Extract hits count from a Vespa query response.

    Vespa responses have a ``hits`` list in the JSON body, or
    a ``VespaQueryResponse`` object with ``.hits`` attribute.
    """
    hits_count = 0

    try:
        # VespaQueryResponse object
        hits = getattr(response, "hits", None)
        if isinstance(hits, list):
            return len(hits)

        # Dict response
        if isinstance(response, dict):
            root = response.get("root", {})
            if isinstance(root, dict):
                children = root.get("children", [])
                if isinstance(children, list) and children:
                    return len(children)

            hits = response.get("hits", [])
            if isinstance(hits, list):
                return len(hits)

        # Try json property
        json_body = getattr(response, "json", None)
        if isinstance(json_body, dict):
            root = json_body.get("root", {})
            if isinstance(root, dict):
                children = root.get("children", [])
                if isinstance(children, list):
                    return len(children)
    except Exception:
        pass

    return hits_count


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper functions
# ---------------------------------------------------------------------------


def _sync_query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vespa ``Vespa.query``.

    Creates a retrieval span and extracts query text and hits count.
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_text = _extract_query_text(args, kwargs)
    schema, namespace = _extract_schema_namespace(kwargs)

    query_preview = f"vespa.query({query_text!r}"
    if schema:
        query_preview += f", schema={schema!r}"
    query_preview += ")"

    try:
        span = start_retrieval_span(query=query_preview, source="vespa")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            hits_count = _extract_hits_count(response)

            span.set_attribute("waxell.retrieval.source", "vespa")
            span.set_attribute("waxell.retrieval.operation", "query")
            span.set_attribute("waxell.retrieval.matches_count", hits_count)
            if query_text:
                span.set_attribute("waxell.retrieval.query_text", query_text[:200])
            if schema:
                span.set_attribute("db.vespa.schema", schema)
            if namespace:
                span.set_attribute("db.vespa.namespace", namespace)
        except Exception as attr_exc:
            logger.debug("Failed to set Vespa query span attributes: %s", attr_exc)

        try:
            _record_vespa_retrieval(
                query=query_preview,
                hits_count=hits_count if "hits_count" in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_feed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vespa ``Vespa.feed_data_point`` (document feeding)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    schema, namespace = _extract_schema_namespace(kwargs)
    data_id = kwargs.get("data_id", args[1] if len(args) > 1 else "")

    try:
        span = start_tool_span(tool_name="vespa.feed_data_point", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "feed")
            if schema:
                span.set_attribute("db.vespa.schema", schema)
            if namespace:
                span.set_attribute("db.vespa.namespace", namespace)
            if data_id:
                span.set_attribute("db.vespa.data_id", str(data_id))
        except Exception as attr_exc:
            logger.debug("Failed to set Vespa feed span attributes: %s", attr_exc)

        try:
            _record_vespa_write(
                operation="feed",
                schema=schema,
                vectors_count=1,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_delete_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vespa ``Vespa.delete_data`` (document deletion)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    schema, namespace = _extract_schema_namespace(kwargs)
    data_id = kwargs.get("data_id", args[0] if args else "")

    try:
        span = start_tool_span(tool_name="vespa.delete_data", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "delete")
            if schema:
                span.set_attribute("db.vespa.schema", schema)
            if namespace:
                span.set_attribute("db.vespa.namespace", namespace)
            if data_id:
                span.set_attribute("db.vespa.data_id", str(data_id))
        except Exception as attr_exc:
            logger.debug("Failed to set Vespa delete span attributes: %s", attr_exc)

        try:
            _record_vespa_write(
                operation="delete",
                schema=schema,
                vectors_count=1,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_vespa_retrieval(
    query: str,
    hits_count: int,
) -> None:
    """Record a Vespa retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"hit_{i}"} for i in range(hits_count)]
        ctx.record_retrieval(
            query=query,
            source="vespa",
            documents=documents,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_vespa_write(
    operation: str,
    schema: str,
    vectors_count: int,
) -> None:
    """Record a Vespa write operation (feed/delete) to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"vespa.{operation}",
            input={"schema": schema, "vectors_count": vectors_count},
            tool_type="vectordb",
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass
