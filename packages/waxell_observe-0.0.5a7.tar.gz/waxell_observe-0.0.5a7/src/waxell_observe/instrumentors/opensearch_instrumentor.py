"""OpenSearch auto-instrumentor for waxell-observe.

Monkey-patches the OpenSearch Python client to emit OTel spans for
search operations, with special handling for kNN/vector search, plus
index and bulk write operations.

Patched methods (sync):
  - ``opensearchpy.OpenSearch.search``  (retrieval span; kNN-aware)
  - ``opensearchpy.OpenSearch.index``   (tool span; vector upsert tracking)
  - ``opensearchpy.OpenSearch.bulk``    (tool span; bulk operations)

Patched methods (async):
  - ``opensearchpy.AsyncOpenSearch.search`` (retrieval span; kNN-aware)
  - ``opensearchpy.AsyncOpenSearch.index``  (tool span; vector upsert tracking)

All wrapper code is wrapped in try/except -- never breaks the user's OpenSearch calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class OpenSearchInstrumentor(BaseInstrumentor):
    """Instrumentor for the OpenSearch Python client (``opensearch-py``).

    Patches ``OpenSearch.search``, ``OpenSearch.index``, ``OpenSearch.bulk``,
    and their async counterparts to emit OTel spans with vector search awareness.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import opensearchpy  # noqa: F401
        except ImportError:
            logger.debug("opensearch-py package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping OpenSearch instrumentation")
            return False

        patched_any = False

        # --- Sync OpenSearch ---
        try:
            wrapt.wrap_function_wrapper(
                "opensearchpy",
                "OpenSearch.search",
                _sync_search_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch OpenSearch.search")

        try:
            wrapt.wrap_function_wrapper(
                "opensearchpy",
                "OpenSearch.index",
                _sync_index_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch OpenSearch.index")

        try:
            wrapt.wrap_function_wrapper(
                "opensearchpy",
                "OpenSearch.bulk",
                _sync_bulk_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch OpenSearch.bulk")

        # --- Async AsyncOpenSearch ---
        try:
            wrapt.wrap_function_wrapper(
                "opensearchpy",
                "AsyncOpenSearch.search",
                _async_search_wrapper,
            )
        except Exception:
            logger.debug("Could not patch AsyncOpenSearch.search")

        try:
            wrapt.wrap_function_wrapper(
                "opensearchpy",
                "AsyncOpenSearch.index",
                _async_index_wrapper,
            )
        except Exception:
            logger.debug("Could not patch AsyncOpenSearch.index")

        if not patched_any:
            logger.debug("Could not patch any OpenSearch methods")
            return False

        self._instrumented = True
        logger.debug("OpenSearch instrumented (search, index, bulk + async variants)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import opensearchpy

            sync_cls = getattr(opensearchpy, "OpenSearch", None)
            if sync_cls is not None:
                for method_name in ("search", "index", "bulk"):
                    method = getattr(sync_cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(sync_cls, method_name, method.__wrapped__)

            async_cls = getattr(opensearchpy, "AsyncOpenSearch", None)
            if async_cls is not None:
                for method_name in ("search", "index"):
                    method = getattr(async_cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(async_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("OpenSearch uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _detect_knn(body: dict | None) -> tuple[bool, str, int]:
    """Detect whether a search body contains a kNN vector query.

    Returns (is_knn, query_type, k_value).

    Detects:
      - Top-level ``knn`` key (OpenSearch 2.x neural search)
      - ``script_score`` with ``knn`` in the script source
    """
    if not body or not isinstance(body, dict):
        return False, "keyword", 0

    # Direct knn field
    knn = body.get("knn")
    if knn is not None:
        if isinstance(knn, dict):
            k = knn.get("k", 0)
            return True, "knn", int(k) if k else 0
        return True, "knn", 0

    # script_score with knn
    query = body.get("query", {})
    if isinstance(query, dict):
        script_score = query.get("script_score", {})
        if isinstance(script_score, dict):
            script = script_score.get("script", {})
            if isinstance(script, dict):
                source = script.get("source", "")
                if isinstance(source, str) and "knn" in source.lower():
                    return True, "script_score_knn", 0

    return False, "keyword", 0


def _extract_index_name(args, kwargs) -> str:
    """Extract the index name from positional or keyword args."""
    index = kwargs.get("index", None)
    if index is not None:
        return str(index)
    if args:
        first = args[0]
        if isinstance(first, str):
            return first
    return ""


def _extract_hits(response) -> tuple[int, int]:
    """Extract hits count and took_ms from an OpenSearch response.

    Returns (hits_count, took_ms).
    """
    hits_count = 0
    took_ms = 0

    if isinstance(response, dict):
        took_ms = response.get("took", 0)
        hits_obj = response.get("hits", {})
        if isinstance(hits_obj, dict):
            hits_list = hits_obj.get("hits", [])
            hits_count = len(hits_list) if isinstance(hits_list, list) else 0
    else:
        # ObjectApiResponse or similar -- try attribute access
        try:
            body = response.body if hasattr(response, "body") else response
            if isinstance(body, dict):
                took_ms = body.get("took", 0)
                hits_obj = body.get("hits", {})
                if isinstance(hits_obj, dict):
                    hits_list = hits_obj.get("hits", [])
                    hits_count = len(hits_list) if isinstance(hits_list, list) else 0
        except Exception:
            pass

    return hits_count, took_ms


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper functions
# ---------------------------------------------------------------------------


def _sync_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for OpenSearch ``OpenSearch.search``.

    Detects kNN parameters to distinguish vector search from text search.
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    index = _extract_index_name((), kwargs)
    body = kwargs.get("body", {})
    is_knn, query_type, k_value = _detect_knn(body)

    operation = "knn_search" if is_knn else "search"
    query_preview = f"opensearch.{operation}(index={index!r}"
    if is_knn:
        query_preview += f", type={query_type!r}, k={k_value}"
    query_preview += ")"

    try:
        span = start_retrieval_span(query=query_preview, source="opensearch")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            hits_count, took_ms = _extract_hits(response)

            span.set_attribute("waxell.retrieval.source", "opensearch")
            span.set_attribute("waxell.retrieval.operation", operation)
            span.set_attribute("waxell.retrieval.matches_count", hits_count)
            if index:
                span.set_attribute("db.opensearch.index", index)
            if took_ms:
                span.set_attribute("db.opensearch.took_ms", took_ms)
            if is_knn:
                span.set_attribute("db.opensearch.query_type", query_type)
                if k_value:
                    span.set_attribute("waxell.retrieval.top_k", k_value)
        except Exception as attr_exc:
            logger.debug("Failed to set OpenSearch search span attributes: %s", attr_exc)

        try:
            _record_opensearch_retrieval(
                query=query_preview,
                operation=operation,
                index=index,
                hits_count=hits_count if "hits_count" in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_index_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for OpenSearch ``OpenSearch.index`` (document indexing)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    index = _extract_index_name((), kwargs)
    doc_id = kwargs.get("id", "")

    try:
        span = start_tool_span(tool_name="opensearch.index", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "index")
            if index:
                span.set_attribute("db.opensearch.index", index)
            if doc_id:
                span.set_attribute("db.opensearch.doc_id", str(doc_id))
        except Exception as attr_exc:
            logger.debug("Failed to set OpenSearch index span attributes: %s", attr_exc)

        try:
            _record_opensearch_write(
                operation="index",
                index=index,
                vectors_count=1,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_bulk_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for OpenSearch ``OpenSearch.bulk`` (bulk operations)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    index = _extract_index_name((), kwargs)
    body = kwargs.get("body", args[0] if args else None)
    actions_count = _count_bulk_actions(body)

    try:
        span = start_tool_span(tool_name="opensearch.bulk", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "bulk")
            if index:
                span.set_attribute("db.opensearch.index", index)
            if actions_count:
                span.set_attribute("waxell.vectordb.vectors_count", actions_count)

            # Extract error info from bulk response
            if isinstance(response, dict):
                errors = response.get("errors", False)
                if errors:
                    span.set_attribute("db.opensearch.bulk_errors", True)
        except Exception as attr_exc:
            logger.debug("Failed to set OpenSearch bulk span attributes: %s", attr_exc)

        try:
            _record_opensearch_write(
                operation="bulk",
                index=index,
                vectors_count=actions_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrapper functions
# ---------------------------------------------------------------------------


async def _async_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for OpenSearch ``AsyncOpenSearch.search``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    index = _extract_index_name((), kwargs)
    body = kwargs.get("body", {})
    is_knn, query_type, k_value = _detect_knn(body)

    operation = "knn_search" if is_knn else "search"
    query_preview = f"opensearch.{operation}(index={index!r}"
    if is_knn:
        query_preview += f", type={query_type!r}, k={k_value}"
    query_preview += ")"

    try:
        span = start_retrieval_span(query=query_preview, source="opensearch")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            hits_count, took_ms = _extract_hits(response)

            span.set_attribute("waxell.retrieval.source", "opensearch")
            span.set_attribute("waxell.retrieval.operation", operation)
            span.set_attribute("waxell.retrieval.matches_count", hits_count)
            if index:
                span.set_attribute("db.opensearch.index", index)
            if took_ms:
                span.set_attribute("db.opensearch.took_ms", took_ms)
            if is_knn:
                span.set_attribute("db.opensearch.query_type", query_type)
                if k_value:
                    span.set_attribute("waxell.retrieval.top_k", k_value)
        except Exception as attr_exc:
            logger.debug("Failed to set OpenSearch async search span attributes: %s", attr_exc)

        try:
            _record_opensearch_retrieval(
                query=query_preview,
                operation=operation,
                index=index,
                hits_count=hits_count if "hits_count" in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_index_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for OpenSearch ``AsyncOpenSearch.index``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    index = _extract_index_name((), kwargs)
    doc_id = kwargs.get("id", "")

    try:
        span = start_tool_span(tool_name="opensearch.index", tool_type="vectordb")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "index")
            if index:
                span.set_attribute("db.opensearch.index", index)
            if doc_id:
                span.set_attribute("db.opensearch.doc_id", str(doc_id))
        except Exception as attr_exc:
            logger.debug("Failed to set OpenSearch async index span attributes: %s", attr_exc)

        try:
            _record_opensearch_write(
                operation="index",
                index=index,
                vectors_count=1,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers (bulk)
# ---------------------------------------------------------------------------


def _count_bulk_actions(body) -> int:
    """Count the number of actions in a bulk request body.

    Bulk body is a list of action/metadata pairs followed by optional documents.
    Each action line (index, create, update, delete) counts as one action.
    """
    if body is None:
        return 0
    try:
        if isinstance(body, (list, tuple)):
            # Each action is two items: action_meta + doc (for index/create/update)
            # or one item for delete. Rough heuristic: count action lines.
            count = 0
            for item in body:
                if isinstance(item, dict):
                    for key in ("index", "create", "update", "delete"):
                        if key in item:
                            count += 1
                            break
            return count
        if isinstance(body, str):
            # Newline-delimited JSON -- count action lines
            lines = [ln for ln in body.strip().split("\n") if ln.strip()]
            return len(lines) // 2  # action + doc pairs
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_opensearch_retrieval(
    query: str,
    operation: str,
    index: str,
    hits_count: int,
) -> None:
    """Record an OpenSearch retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"hit_{i}"} for i in range(hits_count)]
        ctx.record_retrieval(
            query=query,
            source="opensearch",
            documents=documents,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_opensearch_write(
    operation: str,
    index: str,
    vectors_count: int,
) -> None:
    """Record an OpenSearch write operation (index/bulk) to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"opensearch.{operation}",
            input={"index": index, "vectors_count": vectors_count},
            tool_type="vectordb",
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass
