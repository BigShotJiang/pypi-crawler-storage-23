"""Stream wrappers for capturing token usage from streaming LLM responses.

OpenAI and Anthropic streaming APIs yield chunks/events without aggregated
token counts.  These wrapper classes proxy the stream iterator, accumulate
content and usage data, and record the LLM call on stream completion.

Design rules:
  - NEVER break the user's stream -- all recording logic in try/except.
  - Every chunk/event is yielded unchanged (transparent proxy).
  - Support both sync and async iteration.
  - Support context manager protocol (OpenAI streams use ``with``).
  - Record to OTel span attributes AND to WaxellContext HTTP path if available.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared helper: record completed LLM call to OTel span + WaxellContext
# ---------------------------------------------------------------------------


def _finalize_llm_span(
    span: Any,
    model: str,
    tokens_in: int,
    tokens_out: int,
    content: str,
    provider: str,
    finish_reason: str = "",
) -> None:
    """Set final attributes on an OTel span and record via WaxellContext HTTP path.

    Called once when the stream is fully consumed.  All errors are swallowed
    to satisfy the "never break the user's stream" invariant.
    """
    try:
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost

        cost = estimate_cost(model, tokens_in, tokens_out)

        span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
        span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
        span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
        if finish_reason:
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, [finish_reason])
        span.set_attribute(WaxellAttributes.LLM_MODEL, model)
        span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
        span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
        span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
        span.set_attribute(WaxellAttributes.LLM_COST, cost)
    except Exception as e:
        logger.debug("Failed to set stream span attributes: %s", e)

    try:
        span.end()
    except Exception:
        pass

    # Dual-path: record to HTTP API via WaxellContext or background collector
    try:
        from ._context_var import _current_context
        from ._collector import _collector
        from ..cost import estimate_cost as _est

        cost_http = _est(model, tokens_in, tokens_out)
        call_data = {
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": cost_http,
            "task": f"chat.stream ({provider})",
            "prompt_preview": "",
            "response_preview": content[:500] if content else "",
        }

        ctx = _current_context.get(None)
        if ctx is not None and hasattr(ctx, "run_id") and ctx.run_id:
            ctx.record_llm_call(**call_data)
        else:
            _collector.record_call(call_data)
    except Exception:
        pass  # No active context or import failed -- that's fine


# ===================================================================
# OpenAI stream wrappers
# ===================================================================


class OpenAISyncStreamWrapper:
    """Wraps an OpenAI sync ``Stream[ChatCompletionChunk]`` to capture usage.

    Proxies ``__iter__`` / ``__next__`` and ``__enter__`` / ``__exit__``
    (context manager) so the user's code is unaffected.
    """

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_usage",
        "_finish_reason",
        "_finalized",
        "_tool_calls",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._usage: Any = None
        self._finish_reason: str = ""
        self._finalized: bool = False
        self._tool_calls: dict[int, dict] = {}  # index -> {name, arguments}

    # -- Iterator protocol --

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
        except StopIteration:
            self._on_stream_end()
            raise

        try:
            self._process_chunk(chunk)
        except Exception:
            pass  # Never break the stream

        return chunk

    # -- Context-manager protocol (OpenAI streams support ``with``) --

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        result = None
        if hasattr(self._stream, "__exit__"):
            result = self._stream.__exit__(*args)
        self._on_stream_end()
        return result

    # -- Proxy attribute access for SDK-specific properties (e.g. response) --

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    # -- Internal helpers --

    def _process_chunk(self, chunk: Any) -> None:
        """Extract content, usage, and tool calls from a ChatCompletionChunk."""
        if hasattr(chunk, "choices") and chunk.choices:
            delta = getattr(chunk.choices[0], "delta", None)
            if delta is not None:
                text = getattr(delta, "content", None)
                if text:
                    self._content_parts.append(text)
                # Accumulate streamed tool calls
                tc_list = getattr(delta, "tool_calls", None)
                if tc_list:
                    for tc in tc_list:
                        idx = getattr(tc, "index", 0)
                        if idx not in self._tool_calls:
                            self._tool_calls[idx] = {"name": "", "arguments": ""}
                        fn = getattr(tc, "function", None)
                        if fn:
                            name = getattr(fn, "name", None)
                            if name:
                                self._tool_calls[idx]["name"] = name
                            args = getattr(fn, "arguments", None)
                            if args:
                                self._tool_calls[idx]["arguments"] += args
            fr = getattr(chunk.choices[0], "finish_reason", None)
            if fr:
                self._finish_reason = fr

        if hasattr(chunk, "usage") and chunk.usage is not None:
            self._usage = chunk.usage

    def _on_stream_end(self) -> None:
        """Record the completed stream as an LLM call."""
        if self._finalized:
            return
        self._finalized = True

        try:
            tokens_in = self._usage.prompt_tokens if self._usage else 0
            tokens_out = self._usage.completion_tokens if self._usage else 0
            content = "".join(self._content_parts)

            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                content=content,
                provider="openai",
                finish_reason=self._finish_reason,
            )
        except Exception:
            # Last resort: at least end the span
            try:
                self._span.end()
            except Exception:
                pass

        # Auto-capture accumulated tool calls from stream
        try:
            if self._tool_calls:
                from ._context_var import _current_context

                ctx = _current_context.get()
                if ctx:
                    for tc_data in self._tool_calls.values():
                        if tc_data.get("name"):
                            ctx.record_tool_call(
                                name=tc_data["name"],
                                input=tc_data.get("arguments", ""),
                                tool_type="function",
                            )
        except Exception:
            pass  # Never break user code


class OpenAIAsyncStreamWrapper:
    """Wraps an OpenAI async ``AsyncStream[ChatCompletionChunk]`` to capture usage.

    Proxies ``__aiter__`` / ``__anext__`` and ``__aenter__`` / ``__aexit__``.
    """

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_usage",
        "_finish_reason",
        "_finalized",
        "_tool_calls",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._usage: Any = None
        self._finish_reason: str = ""
        self._finalized: bool = False
        self._tool_calls: dict[int, dict] = {}  # index -> {name, arguments}

    # -- Async iterator protocol --

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
        except StopAsyncIteration:
            self._on_stream_end()
            raise

        try:
            self._process_chunk(chunk)
        except Exception:
            pass

        return chunk

    # -- Async context-manager protocol --

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        result = None
        if hasattr(self._stream, "__aexit__"):
            result = await self._stream.__aexit__(*args)
        self._on_stream_end()
        return result

    # -- Proxy attribute access --

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    # -- Internal helpers (same logic as sync) --

    def _process_chunk(self, chunk: Any) -> None:
        """Extract content, usage, and tool calls from a ChatCompletionChunk."""
        if hasattr(chunk, "choices") and chunk.choices:
            delta = getattr(chunk.choices[0], "delta", None)
            if delta is not None:
                text = getattr(delta, "content", None)
                if text:
                    self._content_parts.append(text)
                # Accumulate streamed tool calls
                tc_list = getattr(delta, "tool_calls", None)
                if tc_list:
                    for tc in tc_list:
                        idx = getattr(tc, "index", 0)
                        if idx not in self._tool_calls:
                            self._tool_calls[idx] = {"name": "", "arguments": ""}
                        fn = getattr(tc, "function", None)
                        if fn:
                            name = getattr(fn, "name", None)
                            if name:
                                self._tool_calls[idx]["name"] = name
                            args = getattr(fn, "arguments", None)
                            if args:
                                self._tool_calls[idx]["arguments"] += args
            fr = getattr(chunk.choices[0], "finish_reason", None)
            if fr:
                self._finish_reason = fr

        if hasattr(chunk, "usage") and chunk.usage is not None:
            self._usage = chunk.usage

    def _on_stream_end(self) -> None:
        """Record the completed stream as an LLM call."""
        if self._finalized:
            return
        self._finalized = True

        try:
            tokens_in = self._usage.prompt_tokens if self._usage else 0
            tokens_out = self._usage.completion_tokens if self._usage else 0
            content = "".join(self._content_parts)

            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                content=content,
                provider="openai",
                finish_reason=self._finish_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass

        # Auto-capture accumulated tool calls from stream
        try:
            if self._tool_calls:
                from ._context_var import _current_context

                ctx = _current_context.get()
                if ctx:
                    for tc_data in self._tool_calls.values():
                        if tc_data.get("name"):
                            ctx.record_tool_call(
                                name=tc_data["name"],
                                input=tc_data.get("arguments", ""),
                                tool_type="function",
                            )
        except Exception:
            pass  # Never break user code


# ===================================================================
# Anthropic stream wrappers
# ===================================================================


class AnthropicSyncStreamWrapper:
    """Wraps an Anthropic sync stream to capture usage from events.

    Anthropic's streaming uses event types:
      - ``message_start``: contains ``message.usage.input_tokens``
      - ``content_block_start``: contains content block metadata (text or tool_use)
      - ``content_block_delta``: contains ``delta.text`` or ``delta.partial_json``
      - ``message_delta``: contains ``usage.output_tokens``
      - ``message_stop``: stream complete
    """

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_input_tokens",
        "_output_tokens",
        "_stop_reason",
        "_finalized",
        "_tool_calls",
        "_current_tool_index",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._input_tokens: int = 0
        self._output_tokens: int = 0
        self._stop_reason: str = ""
        self._finalized: bool = False
        self._tool_calls: dict[int, dict] = {}  # block index -> {name, input_json}
        self._current_tool_index: int = -1

    # -- Iterator protocol --

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._stream)
        except StopIteration:
            self._on_stream_end()
            raise

        try:
            self._process_event(event)
        except Exception:
            pass

        return event

    # -- Context-manager protocol --

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        result = None
        if hasattr(self._stream, "__exit__"):
            result = self._stream.__exit__(*args)
        self._on_stream_end()
        return result

    # -- Proxy attribute access --

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    # -- Internal helpers --

    def _process_event(self, event: Any) -> None:
        """Extract data from an Anthropic stream event."""
        event_type = getattr(event, "type", "")

        if event_type == "message_start":
            message = getattr(event, "message", None)
            if message is not None:
                usage = getattr(message, "usage", None)
                if usage is not None:
                    self._input_tokens = getattr(usage, "input_tokens", 0)
                # Capture model from message if available
                msg_model = getattr(message, "model", None)
                if msg_model:
                    self._model = msg_model

        elif event_type == "content_block_start":
            # Detect tool_use content blocks starting
            block = getattr(event, "content_block", None)
            if block is not None:
                block_type = getattr(block, "type", "")
                index = getattr(event, "index", -1)
                if block_type == "tool_use" and index >= 0:
                    self._current_tool_index = index
                    self._tool_calls[index] = {
                        "name": getattr(block, "name", "unknown"),
                        "input_json": "",
                    }

        elif event_type == "content_block_delta":
            delta = getattr(event, "delta", None)
            if delta is not None:
                delta_type = getattr(delta, "type", "")
                if delta_type == "text_delta":
                    text = getattr(delta, "text", None)
                    if text:
                        self._content_parts.append(text)
                elif delta_type == "input_json_delta":
                    # Accumulate tool input JSON fragments
                    index = getattr(event, "index", self._current_tool_index)
                    partial = getattr(delta, "partial_json", "")
                    if index in self._tool_calls and partial:
                        self._tool_calls[index]["input_json"] += partial

        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage is not None:
                self._output_tokens = getattr(usage, "output_tokens", 0)
            delta = getattr(event, "delta", None)
            if delta is not None:
                sr = getattr(delta, "stop_reason", None)
                if sr:
                    self._stop_reason = sr

    def _on_stream_end(self) -> None:
        """Record the completed stream as an LLM call."""
        if self._finalized:
            return
        self._finalized = True

        try:
            content = "".join(self._content_parts)

            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=self._input_tokens,
                tokens_out=self._output_tokens,
                content=content,
                provider="anthropic",
                finish_reason=self._stop_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass

        # Auto-capture accumulated tool calls from stream
        try:
            if self._tool_calls:
                from ._context_var import _current_context

                ctx = _current_context.get()
                if ctx:
                    for tc_data in self._tool_calls.values():
                        if tc_data.get("name"):
                            ctx.record_tool_call(
                                name=tc_data["name"],
                                input=tc_data.get("input_json", ""),
                                tool_type="function",
                            )
        except Exception:
            pass  # Never break user code


class AnthropicAsyncStreamWrapper:
    """Wraps an Anthropic async stream to capture usage from events.

    Same event processing as ``AnthropicSyncStreamWrapper`` but for
    async iteration.
    """

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_input_tokens",
        "_output_tokens",
        "_stop_reason",
        "_finalized",
        "_tool_calls",
        "_current_tool_index",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._input_tokens: int = 0
        self._output_tokens: int = 0
        self._stop_reason: str = ""
        self._finalized: bool = False
        self._tool_calls: dict[int, dict] = {}  # block index -> {name, input_json}
        self._current_tool_index: int = -1

    # -- Async iterator protocol --

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            event = await self._stream.__anext__()
        except StopAsyncIteration:
            self._on_stream_end()
            raise

        try:
            self._process_event(event)
        except Exception:
            pass

        return event

    # -- Async context-manager protocol --

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        result = None
        if hasattr(self._stream, "__aexit__"):
            result = await self._stream.__aexit__(*args)
        self._on_stream_end()
        return result

    # -- Proxy attribute access --

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    # -- Internal helpers (same logic as sync) --

    def _process_event(self, event: Any) -> None:
        """Extract data from an Anthropic stream event."""
        event_type = getattr(event, "type", "")

        if event_type == "message_start":
            message = getattr(event, "message", None)
            if message is not None:
                usage = getattr(message, "usage", None)
                if usage is not None:
                    self._input_tokens = getattr(usage, "input_tokens", 0)
                msg_model = getattr(message, "model", None)
                if msg_model:
                    self._model = msg_model

        elif event_type == "content_block_start":
            # Detect tool_use content blocks starting
            block = getattr(event, "content_block", None)
            if block is not None:
                block_type = getattr(block, "type", "")
                index = getattr(event, "index", -1)
                if block_type == "tool_use" and index >= 0:
                    self._current_tool_index = index
                    self._tool_calls[index] = {
                        "name": getattr(block, "name", "unknown"),
                        "input_json": "",
                    }

        elif event_type == "content_block_delta":
            delta = getattr(event, "delta", None)
            if delta is not None:
                delta_type = getattr(delta, "type", "")
                if delta_type == "text_delta":
                    text = getattr(delta, "text", None)
                    if text:
                        self._content_parts.append(text)
                elif delta_type == "input_json_delta":
                    # Accumulate tool input JSON fragments
                    index = getattr(event, "index", self._current_tool_index)
                    partial = getattr(delta, "partial_json", "")
                    if index in self._tool_calls and partial:
                        self._tool_calls[index]["input_json"] += partial

        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage is not None:
                self._output_tokens = getattr(usage, "output_tokens", 0)
            delta = getattr(event, "delta", None)
            if delta is not None:
                sr = getattr(delta, "stop_reason", None)
                if sr:
                    self._stop_reason = sr

    def _on_stream_end(self) -> None:
        """Record the completed stream as an LLM call."""
        if self._finalized:
            return
        self._finalized = True

        try:
            content = "".join(self._content_parts)

            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=self._input_tokens,
                tokens_out=self._output_tokens,
                content=content,
                provider="anthropic",
                finish_reason=self._stop_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass

        # Auto-capture accumulated tool calls from stream
        try:
            if self._tool_calls:
                from ._context_var import _current_context

                ctx = _current_context.get()
                if ctx:
                    for tc_data in self._tool_calls.values():
                        if tc_data.get("name"):
                            ctx.record_tool_call(
                                name=tc_data["name"],
                                input=tc_data.get("input_json", ""),
                                tool_type="function",
                            )
        except Exception:
            pass  # Never break user code


# ===================================================================
# Gemini stream wrappers
# ===================================================================


class GeminiSyncStreamWrapper:
    """Wraps a Gemini sync ``generate_content(stream=True)`` generator.

    Each chunk is a ``GenerateContentResponse`` object:
      - ``chunk.text`` — text fragment
      - ``chunk.usage_metadata.prompt_token_count`` — input tokens (final chunk)
      - ``chunk.usage_metadata.candidates_token_count`` — output tokens (final chunk)
      - ``chunk.candidates[0].finish_reason`` — enum with ``.name`` attribute
    """

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_tokens_in",
        "_tokens_out",
        "_finish_reason",
        "_finalized",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._tokens_in: int = 0
        self._tokens_out: int = 0
        self._finish_reason: str = ""
        self._finalized: bool = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
        except StopIteration:
            self._on_stream_end()
            raise

        try:
            self._process_chunk(chunk)
        except Exception:
            pass  # Never break the stream

        return chunk

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        result = None
        if hasattr(self._stream, "__exit__"):
            result = self._stream.__exit__(*args)
        self._on_stream_end()
        return result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_chunk(self, chunk: Any) -> None:
        """Extract content, usage, and finish reason from a Gemini chunk."""
        try:
            text = getattr(chunk, "text", None)
            if text:
                self._content_parts.append(text)
        except (ValueError, AttributeError):
            pass

        meta = getattr(chunk, "usage_metadata", None)
        if meta:
            prompt_tokens = getattr(meta, "prompt_token_count", 0)
            candidates_tokens = getattr(meta, "candidates_token_count", 0)
            if prompt_tokens:
                self._tokens_in = prompt_tokens
            if candidates_tokens:
                self._tokens_out = candidates_tokens

        candidates = getattr(chunk, "candidates", None)
        if candidates and len(candidates) > 0:
            reason = getattr(candidates[0], "finish_reason", None)
            if reason is not None:
                name = getattr(reason, "name", None)
                if name and name != "FINISH_REASON_UNSPECIFIED":
                    self._finish_reason = str(name)

    def _on_stream_end(self) -> None:
        if self._finalized:
            return
        self._finalized = True

        try:
            content = "".join(self._content_parts)
            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=self._tokens_in,
                tokens_out=self._tokens_out,
                content=content,
                provider="google",
                finish_reason=self._finish_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass


class GeminiAsyncStreamWrapper:
    """Wraps a Gemini async ``generate_content_async(stream=True)`` generator."""

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_tokens_in",
        "_tokens_out",
        "_finish_reason",
        "_finalized",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._tokens_in: int = 0
        self._tokens_out: int = 0
        self._finish_reason: str = ""
        self._finalized: bool = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
        except StopAsyncIteration:
            self._on_stream_end()
            raise

        try:
            self._process_chunk(chunk)
        except Exception:
            pass

        return chunk

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        result = None
        if hasattr(self._stream, "__aexit__"):
            result = await self._stream.__aexit__(*args)
        self._on_stream_end()
        return result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_chunk(self, chunk: Any) -> None:
        """Extract content, usage, and finish reason from a Gemini chunk."""
        try:
            text = getattr(chunk, "text", None)
            if text:
                self._content_parts.append(text)
        except (ValueError, AttributeError):
            pass

        meta = getattr(chunk, "usage_metadata", None)
        if meta:
            prompt_tokens = getattr(meta, "prompt_token_count", 0)
            candidates_tokens = getattr(meta, "candidates_token_count", 0)
            if prompt_tokens:
                self._tokens_in = prompt_tokens
            if candidates_tokens:
                self._tokens_out = candidates_tokens

        candidates = getattr(chunk, "candidates", None)
        if candidates and len(candidates) > 0:
            reason = getattr(candidates[0], "finish_reason", None)
            if reason is not None:
                name = getattr(reason, "name", None)
                if name and name != "FINISH_REASON_UNSPECIFIED":
                    self._finish_reason = str(name)

    def _on_stream_end(self) -> None:
        if self._finalized:
            return
        self._finalized = True

        try:
            content = "".join(self._content_parts)
            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=self._tokens_in,
                tokens_out=self._tokens_out,
                content=content,
                provider="google",
                finish_reason=self._finish_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass


# ===================================================================
# Cohere stream wrappers
# ===================================================================


class CohereSyncStreamWrapper:
    """Wraps a Cohere sync streaming response (iterator of events).

    Cohere V2 streaming events have a ``.type`` attribute:
      - ``"content-delta"`` — ``event.delta.message.content.text``
      - ``"message-end"`` — ``event.delta.finish_reason``,
        ``event.delta.usage.billed_units.input_tokens/output_tokens``
    """

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_tokens_in",
        "_tokens_out",
        "_finish_reason",
        "_finalized",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._tokens_in: int = 0
        self._tokens_out: int = 0
        self._finish_reason: str = ""
        self._finalized: bool = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._stream)
        except StopIteration:
            self._on_stream_end()
            raise

        try:
            self._process_event(event)
        except Exception:
            pass

        return event

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        result = None
        if hasattr(self._stream, "__exit__"):
            result = self._stream.__exit__(*args)
        self._on_stream_end()
        return result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_event(self, event: Any) -> None:
        """Extract data from a Cohere stream event."""
        event_type = getattr(event, "type", "")

        if event_type == "content-delta":
            try:
                delta = getattr(event, "delta", None)
                if delta:
                    msg = getattr(delta, "message", None)
                    if msg:
                        content = getattr(msg, "content", None)
                        if content:
                            text = getattr(content, "text", None)
                            if text:
                                self._content_parts.append(text)
            except Exception:
                pass

        elif event_type == "message-end":
            try:
                delta = getattr(event, "delta", None)
                if delta:
                    fr = getattr(delta, "finish_reason", None)
                    if fr:
                        self._finish_reason = str(fr)
                    usage = getattr(delta, "usage", None)
                    if usage:
                        billed = getattr(usage, "billed_units", None)
                        if billed:
                            self._tokens_in = getattr(billed, "input_tokens", 0) or 0
                            self._tokens_out = getattr(billed, "output_tokens", 0) or 0
                        else:
                            tokens = getattr(usage, "tokens", None)
                            if tokens:
                                self._tokens_in = getattr(tokens, "input_tokens", 0) or 0
                                self._tokens_out = getattr(tokens, "output_tokens", 0) or 0
            except Exception:
                pass

    def _on_stream_end(self) -> None:
        if self._finalized:
            return
        self._finalized = True

        try:
            content = "".join(self._content_parts)
            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=self._tokens_in,
                tokens_out=self._tokens_out,
                content=content,
                provider="cohere",
                finish_reason=self._finish_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass


class CohereAsyncStreamWrapper:
    """Wraps a Cohere async streaming response."""

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_tokens_in",
        "_tokens_out",
        "_finish_reason",
        "_finalized",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._tokens_in: int = 0
        self._tokens_out: int = 0
        self._finish_reason: str = ""
        self._finalized: bool = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            event = await self._stream.__anext__()
        except StopAsyncIteration:
            self._on_stream_end()
            raise

        try:
            self._process_event(event)
        except Exception:
            pass

        return event

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        result = None
        if hasattr(self._stream, "__aexit__"):
            result = await self._stream.__aexit__(*args)
        self._on_stream_end()
        return result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_event(self, event: Any) -> None:
        """Extract data from a Cohere stream event (same logic as sync)."""
        event_type = getattr(event, "type", "")

        if event_type == "content-delta":
            try:
                delta = getattr(event, "delta", None)
                if delta:
                    msg = getattr(delta, "message", None)
                    if msg:
                        content = getattr(msg, "content", None)
                        if content:
                            text = getattr(content, "text", None)
                            if text:
                                self._content_parts.append(text)
            except Exception:
                pass

        elif event_type == "message-end":
            try:
                delta = getattr(event, "delta", None)
                if delta:
                    fr = getattr(delta, "finish_reason", None)
                    if fr:
                        self._finish_reason = str(fr)
                    usage = getattr(delta, "usage", None)
                    if usage:
                        billed = getattr(usage, "billed_units", None)
                        if billed:
                            self._tokens_in = getattr(billed, "input_tokens", 0) or 0
                            self._tokens_out = getattr(billed, "output_tokens", 0) or 0
                        else:
                            tokens = getattr(usage, "tokens", None)
                            if tokens:
                                self._tokens_in = getattr(tokens, "input_tokens", 0) or 0
                                self._tokens_out = getattr(tokens, "output_tokens", 0) or 0
            except Exception:
                pass

    def _on_stream_end(self) -> None:
        if self._finalized:
            return
        self._finalized = True

        try:
            content = "".join(self._content_parts)
            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=self._tokens_in,
                tokens_out=self._tokens_out,
                content=content,
                provider="cohere",
                finish_reason=self._finish_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass


# ===================================================================
# Bedrock stream wrapper
# ===================================================================


class BedrockStreamWrapper:
    """Wraps a Bedrock ConverseStream EventStream to capture usage.

    Bedrock ConverseStream events are dicts with a single key:
      - ``{"contentBlockDelta": {"delta": {"text": "..."}, ...}}``
      - ``{"messageStop": {"stopReason": "end_turn"}}``
      - ``{"metadata": {"usage": {"inputTokens": N, "outputTokens": M}}}``

    The wrapper wraps the ``response["stream"]`` EventStream, not the
    response dict itself.  The instrumentor replaces ``response["stream"]``
    with this wrapper so the response dict structure is preserved.
    """

    __slots__ = (
        "_stream",
        "_span",
        "_model",
        "_content_parts",
        "_tokens_in",
        "_tokens_out",
        "_finish_reason",
        "_finalized",
    )

    def __init__(self, stream: Any, span: Any, model: str) -> None:
        self._stream = stream
        self._span = span
        self._model = model
        self._content_parts: list[str] = []
        self._tokens_in: int = 0
        self._tokens_out: int = 0
        self._finish_reason: str = ""
        self._finalized: bool = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._stream)
        except StopIteration:
            self._on_stream_end()
            raise

        try:
            self._process_event(event)
        except Exception:
            pass

        return event

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        result = None
        if hasattr(self._stream, "__exit__"):
            result = self._stream.__exit__(*args)
        self._on_stream_end()
        return result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_event(self, event: dict) -> None:
        """Extract data from a Bedrock ConverseStream event."""
        if not isinstance(event, dict):
            return

        block_delta = event.get("contentBlockDelta")
        if block_delta:
            delta = block_delta.get("delta", {})
            text = delta.get("text", "")
            if text:
                self._content_parts.append(text)

        msg_stop = event.get("messageStop")
        if msg_stop:
            reason = msg_stop.get("stopReason", "")
            if reason:
                self._finish_reason = reason

        metadata = event.get("metadata")
        if metadata:
            usage = metadata.get("usage", {})
            if usage:
                self._tokens_in = usage.get("inputTokens", 0)
                self._tokens_out = usage.get("outputTokens", 0)

    def _on_stream_end(self) -> None:
        if self._finalized:
            return
        self._finalized = True

        try:
            content = "".join(self._content_parts)
            _finalize_llm_span(
                span=self._span,
                model=self._model,
                tokens_in=self._tokens_in,
                tokens_out=self._tokens_out,
                content=content,
                provider="bedrock",
                finish_reason=self._finish_reason,
            )
        except Exception:
            try:
                self._span.end()
            except Exception:
                pass
