"""Agno auto-instrumentor for waxell-observe.

Monkey-patches ``agno.agent.Agent.run`` (sync) and ``agno.agent.Agent.arun``
(async) to emit OTel spans and record to the Waxell HTTP API.

Agno (formerly Phidata) is an agentic framework for building multi-modal
agents with Agent, Team, and Tool abstractions.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AgnoInstrumentor(BaseInstrumentor):
    """Instrumentor for the Agno framework (``agno`` package).

    Patches Agent.run (sync) and Agent.arun (async) for agent execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import agno  # noqa: F401
        except ImportError:
            logger.debug("agno not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Agno instrumentation")
            return False

        patched = False

        # Patch Agent.run (sync entry point)
        try:
            wrapt.wrap_function_wrapper(
                "agno.agent",
                "Agent.run",
                _run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch agno.agent.Agent.run: %s", exc)

        # Patch Agent.arun (async entry point)
        try:
            wrapt.wrap_function_wrapper(
                "agno.agent",
                "Agent.arun",
                _arun_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch agno.agent.Agent.arun: %s", exc)

        if not patched:
            logger.debug("Could not find Agno Agent methods to patch")
            return False

        self._instrumented = True
        logger.debug("Agno instrumented (Agent.run + Agent.arun)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from agno.agent import Agent

            for method_name in ("run", "arun"):
                method = getattr(Agent, method_name, None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(Agent, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Agno uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _run_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Agent.run``."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = _extract_agent_name(instance)
    model_name = _extract_model_name(instance)
    tool_names = _extract_tool_names(instance)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="agno_run",
        )
        span.set_attribute("waxell.agno.agent_name", agent_name)
        if model_name:
            span.set_attribute("waxell.agno.model", model_name)
        if tool_names:
            span.set_attribute("waxell.agno.tools", tool_names)
            span.set_attribute("waxell.agno.tool_count", len(tool_names))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _arun_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Agent.arun``."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_name = _extract_agent_name(instance)
    model_name = _extract_model_name(instance)
    tool_names = _extract_tool_names(instance)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="agno_arun",
        )
        span.set_attribute("waxell.agno.agent_name", agent_name)
        if model_name:
            span.set_attribute("waxell.agno.model", model_name)
        if tool_names:
            span.set_attribute("waxell.agno.tools", tool_names)
            span.set_attribute("waxell.agno.tool_count", len(tool_names))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_agent_name(instance) -> str:
    """Extract agent name from an Agno Agent instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "agno.agent"


def _extract_model_name(instance) -> str:
    """Extract model name from an Agno Agent instance."""
    try:
        model = getattr(instance, "model", None)
        if model is None:
            return ""
        # agno models have .id attribute
        model_id = getattr(model, "id", None)
        if model_id:
            return str(model_id)
        # Fallback to string representation
        return str(model)
    except Exception:
        return ""


def _extract_tool_names(instance) -> list:
    """Extract tool names from an Agno Agent instance."""
    try:
        tools = getattr(instance, "tools", None)
        if not tools:
            return []
        names = []
        for t in tools:
            try:
                name = getattr(t, "name", None) or getattr(t, "__name__", None) or type(t).__name__
                names.append(str(name))
            except Exception:
                pass
        return names[:20]
    except Exception:
        return []


def _set_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span."""
    try:
        # Agno RunResponse has .content (text), .messages, .metrics
        content = getattr(result, "content", None)
        if content:
            span.set_attribute("waxell.agno.response_preview", str(content)[:200])

        # Extract token metrics if available
        metrics = getattr(result, "metrics", None)
        if metrics:
            if isinstance(metrics, dict):
                input_tokens = metrics.get("input_tokens") or metrics.get("prompt_tokens")
                output_tokens = metrics.get("output_tokens") or metrics.get("completion_tokens")
                if input_tokens is not None:
                    span.set_attribute("waxell.agno.input_tokens", int(input_tokens))
                if output_tokens is not None:
                    span.set_attribute("waxell.agno.output_tokens", int(output_tokens))

        # Count messages if present
        messages = getattr(result, "messages", None)
        if messages:
            span.set_attribute("waxell.agno.message_count", len(messages))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                content = getattr(result, "content", None)
                if content:
                    result_preview = str(content)[:500]
            except Exception:
                pass
            ctx.record_step(
                "agent:agno.run",
                output={"agent_name": agent_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
