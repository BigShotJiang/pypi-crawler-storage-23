"""LiteLLM auto-instrumentor for waxell-observe.

Monkey-patches ``litellm.completion`` and ``litellm.acompletion`` to emit
OTel spans and record to the Waxell HTTP API.

LiteLLM provides a unified interface for 100+ LLM providers (OpenAI, Anthropic,
Bedrock, Azure, Vertex, Cohere, etc.), so instrumenting it covers all those
providers automatically.

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LiteLLMInstrumentor(BaseInstrumentor):
    """Instrumentor for the LiteLLM library (``litellm`` package).

    Patches ``litellm.completion`` and ``litellm.acompletion``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import litellm  # noqa: F401
        except ImportError:
            logger.debug("litellm package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping LiteLLM instrumentation")
            return False

        wrapt.wrap_function_wrapper("litellm", "completion", _sync_completion_wrapper)
        wrapt.wrap_function_wrapper("litellm", "acompletion", _async_completion_wrapper)

        self._instrumented = True
        logger.debug("LiteLLM completion instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import litellm

            if hasattr(litellm.completion, "__wrapped__"):
                litellm.completion = litellm.completion.__wrapped__  # type: ignore[attr-defined]
            if hasattr(litellm.acompletion, "__wrapped__"):
                litellm.acompletion = litellm.acompletion.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("LiteLLM completion uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_completion_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``litellm.completion``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", args[0] if args else ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", args[0] if args else "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="litellm")
    except Exception:
        return wrapped(*args, **kwargs)

    if is_streaming:
        # LiteLLM streaming returns an iterator similar to OpenAI
        try:
            from ._stream_wrappers import OpenAISyncStreamWrapper

            stream = wrapped(*args, **kwargs)
            return OpenAISyncStreamWrapper(stream, span, model)
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # LiteLLM returns OpenAI-compatible response format
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            # LiteLLM may include its own cost calculation
            litellm_cost = getattr(response, "_hidden_params", {}).get("response_cost", None)
            if litellm_cost is not None:
                cost = float(litellm_cost)

            finish_reasons = []
            choices = getattr(response, "choices", None)
            if choices:
                finish_reasons = [c.finish_reason for c in choices if getattr(c, "finish_reason", None)]

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_litellm(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_completion_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``litellm.acompletion``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", args[0] if args else ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", args[0] if args else "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="litellm")
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        try:
            from ._stream_wrappers import OpenAIAsyncStreamWrapper

            stream = await wrapped(*args, **kwargs)
            return OpenAIAsyncStreamWrapper(stream, span, model)
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            litellm_cost = getattr(response, "_hidden_params", {}).get("response_cost", None)
            if litellm_cost is not None:
                cost = float(litellm_cost)

            finish_reasons = []
            choices = getattr(response, "choices", None)
            if choices:
                finish_reasons = [c.finish_reason for c in choices if getattr(c, "finish_reason", None)]

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_litellm(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_litellm(response, request_model: str, kwargs: dict) -> None:
    """Record a LiteLLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    usage = getattr(response, "usage", None)
    tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
    tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    litellm_cost = getattr(response, "_hidden_params", {}).get("response_cost", None)
    if litellm_cost is not None:
        cost = float(litellm_cost)

    messages = kwargs.get("messages", [])
    prompt_preview = ""
    if messages:
        first_msg = messages[0] if messages else {}
        if isinstance(first_msg, dict):
            prompt_preview = str(first_msg.get("content", ""))[:500]

    response_preview = ""
    choices = getattr(response, "choices", None)
    if choices:
        msg = getattr(choices[0], "message", None)
        if msg and getattr(msg, "content", None):
            response_preview = msg.content[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "litellm.completion",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
