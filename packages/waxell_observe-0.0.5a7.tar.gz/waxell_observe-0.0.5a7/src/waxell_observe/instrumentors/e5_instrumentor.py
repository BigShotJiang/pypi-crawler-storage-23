"""Microsoft E5 embeddings auto-instrumentor for waxell-observe.

Monkey-patches ``SentenceTransformer.encode`` when the underlying model
name contains "e5" to emit embedding spans tracking E5 embedding generation.

Microsoft E5 models (e.g. intfloat/e5-large-v2, intfloat/multilingual-e5-large)
run via the sentence-transformers library. Token counts are extracted from
the tokenizer when available. Since E5 models typically run locally,
cost is always 0.0.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class E5Instrumentor(BaseInstrumentor):
    """Instrumentor for Microsoft E5 embedding models via sentence-transformers.

    Patches ``SentenceTransformer.encode`` and filters to E5 models at
    wrapper time (by checking the model name for "e5").
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import sentence_transformers  # noqa: F401
        except ImportError:
            logger.debug("sentence_transformers package not installed -- skipping E5 instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping E5 instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "sentence_transformers",
                "SentenceTransformer.encode",
                _sync_encode_wrapper,
            )

            self._instrumented = True
            logger.debug("E5 embedding instrumented (SentenceTransformer.encode)")
            return True
        except Exception as exc:
            logger.warning(
                "Failed to instrument E5 embeddings (possibly incompatible version): %s",
                exc,
            )
            return False

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import sentence_transformers

            method = getattr(sentence_transformers.SentenceTransformer, "encode", None)
            if method is not None and hasattr(method, "__wrapped__"):
                sentence_transformers.SentenceTransformer.encode = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("E5 embedding uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a SentenceTransformer instance."""
    try:
        card = getattr(instance, "model_card_data", None)
        if card is not None:
            name = getattr(card, "model_name", None) or getattr(card, "base_model", None)
            if name:
                return str(name)
    except Exception:
        pass

    try:
        name = getattr(instance, "_model_name", None)
        if name:
            return str(name)
    except Exception:
        pass

    try:
        first_module = instance[0]
        auto_model = getattr(first_module, "auto_model", None)
        if auto_model is not None:
            config = getattr(auto_model, "config", None)
            if config is not None:
                name = getattr(config, "name_or_path", None) or getattr(config, "_name_or_path", None)
                if name:
                    return str(name)
    except Exception:
        pass

    return "e5-unknown"


def _is_e5_model(model_name: str) -> bool:
    """Check if the model name indicates a Microsoft E5 model."""
    lower = model_name.lower()
    return "e5-" in lower or "/e5" in lower or lower.startswith("e5")


def _estimate_token_count(instance, sentences) -> int:
    """Estimate token count using the model's tokenizer if available."""
    try:
        tokenizer = getattr(instance, "tokenizer", None)
        if tokenizer is None:
            # Try to get tokenizer from first module
            first_module = instance[0]
            tokenizer = getattr(first_module, "tokenizer", None)

        if tokenizer is not None:
            if isinstance(sentences, str):
                sentences = [sentences]
            total = 0
            for s in sentences:
                try:
                    encoded = tokenizer.encode(s, add_special_tokens=True)
                    total += len(encoded)
                except Exception:
                    pass
            return total
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_encode_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``SentenceTransformer.encode`` -- E5 models only."""
    model_name = _get_model_name(instance)

    # Only intercept E5 models; pass through for non-E5 models
    if not _is_e5_model(model_name):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    # Count inputs
    sentences = args[0] if args else kwargs.get("sentences", [])
    if isinstance(sentences, str):
        input_count = 1
    elif isinstance(sentences, list):
        input_count = len(sentences)
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="microsoft_e5",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            import numpy as np

            if isinstance(result, np.ndarray):
                dimensions = result.shape[-1] if result.ndim > 1 else result.shape[0]
            elif isinstance(result, list):
                dimensions = len(result[0]) if result else 0
            else:
                dimensions = 0

            tokens = _estimate_token_count(instance, sentences)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model_name)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)  # Local, free
        except Exception as attr_exc:
            logger.debug("Failed to set E5 embed span attributes: %s", attr_exc)

        try:
            _record_http_e5_embed(model_name, input_count, tokens, dimensions)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_e5_embed(
    model: str, input_count: int, tokens: int = 0, dimensions: int = 0
) -> None:
    """Record an E5 embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "embedding:e5",
        "prompt_preview": f"embed {input_count} text(s), dim={dimensions}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
