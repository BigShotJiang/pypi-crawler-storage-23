"""ColBERT/RAGatouille auto-instrumentor for waxell-observe.

Monkey-patches the RAGatouille and colbert-ai libraries to emit OTel spans
for late interaction retrieval and indexing operations.

Patched methods (ragatouille):
  - ``ragatouille.RAGPretrainedModel.search``  (retrieval span)
  - ``ragatouille.RAGPretrainedModel.index``   (tool span)

Patched methods (colbert-ai, best-effort):
  - ``colbert.Searcher.search``                (retrieval span)

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ColBERTInstrumentor(BaseInstrumentor):
    """Instrumentor for ColBERT/RAGatouille late interaction retrieval.

    Patches ``RAGPretrainedModel.search``, ``RAGPretrainedModel.index``,
    and (best-effort) ``colbert.Searcher.search`` to emit OTel spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        has_ragatouille = False
        has_colbert = False

        try:
            import ragatouille  # noqa: F401
            has_ragatouille = True
        except ImportError:
            logger.debug("ragatouille package not installed")

        try:
            import colbert  # noqa: F401
            has_colbert = True
        except ImportError:
            logger.debug("colbert-ai package not installed")

        if not has_ragatouille and not has_colbert:
            logger.debug("Neither ragatouille nor colbert-ai installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping ColBERT instrumentation")
            return False

        patched_any = False

        # --- RAGatouille ---
        if has_ragatouille:
            try:
                wrapt.wrap_function_wrapper(
                    "ragatouille",
                    "RAGPretrainedModel.search",
                    _sync_rag_search_wrapper,
                )
                patched_any = True
                logger.debug("RAGPretrainedModel.search patched")
            except Exception:
                logger.debug("Could not patch RAGPretrainedModel.search")

            try:
                wrapt.wrap_function_wrapper(
                    "ragatouille",
                    "RAGPretrainedModel.index",
                    _sync_rag_index_wrapper,
                )
                patched_any = True
                logger.debug("RAGPretrainedModel.index patched")
            except Exception:
                logger.debug("Could not patch RAGPretrainedModel.index")

        # --- colbert-ai Searcher ---
        if has_colbert:
            try:
                wrapt.wrap_function_wrapper(
                    "colbert",
                    "Searcher.search",
                    _sync_colbert_search_wrapper,
                )
                patched_any = True
                logger.debug("colbert.Searcher.search patched")
            except Exception:
                logger.debug("Could not patch colbert.Searcher.search")

        if not patched_any:
            logger.debug("Could not patch any ColBERT/RAGatouille methods")
            return False

        self._instrumented = True
        logger.debug("ColBERT/RAGatouille instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # RAGatouille
        try:
            import ragatouille

            cls = getattr(ragatouille, "RAGPretrainedModel", None)
            if cls is not None:
                for method_name in ("search", "index"):
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # colbert-ai
        try:
            import colbert

            cls = getattr(colbert, "Searcher", None)
            if cls is not None:
                method = getattr(cls, "search", None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(cls, "search", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("ColBERT/RAGatouille uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_model_name(instance) -> str:
    """Extract model name from a RAGPretrainedModel or Searcher instance."""
    # RAGPretrainedModel stores model path
    try:
        model_name = getattr(instance, "model_name", None)
        if model_name:
            return str(model_name)
    except Exception:
        pass

    try:
        model_name = getattr(instance, "pretrained_model_name_or_path", None)
        if model_name:
            return str(model_name)
    except Exception:
        pass

    # Colbert Searcher -- try config
    try:
        config = getattr(instance, "config", None)
        if config is not None:
            checkpoint = getattr(config, "checkpoint", None)
            if checkpoint:
                return str(checkpoint)
    except Exception:
        pass

    return "colbert"


def _extract_search_results(results) -> tuple[int, list[float]]:
    """Extract result count and scores from ColBERT/RAGatouille search results.

    RAGatouille returns a list of dicts with keys like:
      [{"content": ..., "score": ..., "rank": ...}, ...]

    colbert-ai Searcher.search returns (pids, ranks, scores) tuple.

    Returns (result_count, scores_list).
    """
    if isinstance(results, list):
        scores = []
        for item in results:
            if isinstance(item, dict):
                score = item.get("score")
                if score is not None:
                    scores.append(float(score))
        return len(results), scores

    # colbert-ai returns tuple (pids, ranks, scores)
    if isinstance(results, tuple) and len(results) >= 3:
        pids = results[0]
        scores_raw = results[2]
        try:
            count = len(pids) if hasattr(pids, "__len__") else 0
            scores = []
            if hasattr(scores_raw, "__iter__"):
                scores = [float(s) for s in scores_raw]
            return count, scores
        except Exception:
            pass

    return 0, []


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper functions -- RAGatouille
# ---------------------------------------------------------------------------


def _sync_rag_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``RAGPretrainedModel.search``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query = kwargs.get("query", args[0] if args else "")
    k = kwargs.get("k", args[1] if len(args) > 1 else 10)
    model_name = _extract_model_name(instance)

    query_preview = f"colbert.search(query={str(query)[:200]!r}, k={k})"

    try:
        span = start_retrieval_span(query=query_preview, source="colbert")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count, scores = _extract_search_results(result)
            top_score = max(scores) if scores else None

            span.set_attribute("waxell.retrieval.source", "colbert")
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("waxell.retrieval.matches_count", result_count)
            span.set_attribute("waxell.retrieval.top_k", int(k))
            span.set_attribute("waxell.rerank.system", "colbert")
            span.set_attribute("waxell.rerank.model", model_name)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set ColBERT search span attributes: %s", attr_exc)

        try:
            _record_colbert_retrieval(
                query=query_preview,
                result_count=result_count if "result_count" in dir() else 0,
                model=model_name,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_rag_index_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``RAGPretrainedModel.index``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # index() takes collection, index_name, etc.
    collection = kwargs.get("collection", args[0] if args else [])
    index_name = kwargs.get("index_name", args[1] if len(args) > 1 else "")
    doc_count = len(collection) if isinstance(collection, list) else 0
    model_name = _extract_model_name(instance)

    try:
        span = start_tool_span(tool_name="colbert.index", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "index")
            span.set_attribute("waxell.vectordb.vectors_count", doc_count)
            span.set_attribute("waxell.rerank.system", "colbert")
            span.set_attribute("waxell.rerank.model", model_name)
            if index_name:
                span.set_attribute("db.colbert.index_name", str(index_name))
        except Exception as attr_exc:
            logger.debug("Failed to set ColBERT index span attributes: %s", attr_exc)

        try:
            _record_colbert_write(
                operation="index",
                model=model_name,
                vectors_count=doc_count,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Sync wrapper functions -- colbert-ai Searcher
# ---------------------------------------------------------------------------


def _sync_colbert_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``colbert.Searcher.search``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query = kwargs.get("query", args[0] if args else "")
    k = kwargs.get("k", args[1] if len(args) > 1 else 10)
    model_name = _extract_model_name(instance)

    query_preview = f"colbert.searcher.search(query={str(query)[:200]!r}, k={k})"

    try:
        span = start_retrieval_span(query=query_preview, source="colbert")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count, scores = _extract_search_results(result)
            top_score = max(scores) if scores else None

            span.set_attribute("waxell.retrieval.source", "colbert")
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("waxell.retrieval.matches_count", result_count)
            span.set_attribute("waxell.retrieval.top_k", int(k))
            span.set_attribute("waxell.rerank.system", "colbert")
            span.set_attribute("waxell.rerank.model", model_name)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set colbert Searcher search span attributes: %s", attr_exc)

        try:
            _record_colbert_retrieval(
                query=query_preview,
                result_count=result_count if "result_count" in dir() else 0,
                model=model_name,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_colbert_retrieval(
    query: str,
    result_count: int,
    model: str,
) -> None:
    """Record a ColBERT retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"result_{i}"} for i in range(result_count)]
        ctx.record_retrieval(
            query=query,
            source="colbert",
            documents=documents,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_colbert_write(
    operation: str,
    model: str,
    vectors_count: int,
) -> None:
    """Record a ColBERT write operation (index) to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"colbert.{operation}",
            input={"model": model, "vectors_count": vectors_count},
            tool_type="vectordb",
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass
