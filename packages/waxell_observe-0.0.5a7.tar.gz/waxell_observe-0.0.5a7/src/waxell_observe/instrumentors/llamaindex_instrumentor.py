"""LlamaIndex auto-instrumentor for waxell-observe.

Registers callback handlers with LlamaIndex's instrumentation system to
instrument ALL sub-components: index construction, retrieval, query engines,
node parsing, response synthesis, LLM calls, embedding, agents, and workflows.

LlamaIndex v0.10+ provides two instrumentation approaches:
  1. Legacy CallbackManager with CBEventType (llama_index.core.callbacks)
  2. New instrumentation module with SpanHandler/EventHandler
     (llama_index.core.instrumentation)

This instrumentor attempts the new system first, falling back to legacy
callbacks.

All handler code is wrapped in try/except -- never breaks the user's
LlamaIndex calls.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Dict, Optional

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Class-name pattern matching for span creation
# ---------------------------------------------------------------------------

# Patterns matched against class names (case-insensitive) to determine
# which span creator to use.  Order matters -- first match wins.
_RETRIEVER_PATTERNS = (
    "retriever",
    "bm25retriever",
    "autoretrievalretriever",
)

_QUERY_ENGINE_PATTERNS = (
    "queryengine",
    "querybundle",
    "querycomponent",
    "retriverqueryengine",
    "subquestionqueryengine",
    "routerqueryengine",
    "sqlqueryengine",
    "pandasqueryengine",
    "citationqueryengine",
    "flarequeryengine",
    "knowledgegraphqueryengine",
    "customqueryengine",
)

_NODE_PARSER_PATTERNS = (
    "nodepars",
    "splitter",
    "sentencesplitter",
    "tokentextsplitter",
    "semanticsplitter",
    "hierarchicalnodepars",
    "sentencewindownodepars",
    "codespitter",
    "markdownnodepars",
    "htmlnodepars",
    "jsonnodepars",
    "unstructuredelementnodepars",
)

_INDEX_PATTERNS = (
    "index",
    "vectorstoreindex",
    "summaryindex",
    "treeindex",
    "keywordtableindex",
    "knowledgegraphindex",
    "documentstoreindex",
    "pandasindex",
    "sqlindex",
    "composablegraph",
)

_SYNTHESIZER_PATTERNS = (
    "synthesiz",
    "responsesynth",
    "treesum",
    "refine",
    "simplesummariz",
    "generation",
    "compact",
    "compactandrefin",
)

_AGENT_PATTERNS = (
    "agent",
    "openaiagent",
    "reactagent",
    "functioncallingagent",
    "agentrunner",
    "agentworker",
    "structuredplanneragent",
    "introspectiveagent",
    "languageagent",
)

_WORKFLOW_PATTERNS = (
    "workflow",
    "workflowstep",
)

_LLM_PATTERNS = (
    "llm",
    "openai",
    "anthropic",
    "gemini",
    "mistral",
    "cohere",
    "bedrock",
    "ollama",
    "huggingface",
    "replicate",
    "together",
    "groq",
    "palm",
    "vertex",
    "watsonx",
    "deepseek",
)

_EMBEDDING_PATTERNS = (
    "embed",
    "openaiembedding",
    "huggingfaceembedding",
    "cohereembedding",
    "googleembedding",
    "geminiembedding",
    "voyageembedding",
    "jinaembedding",
    "bedrockembedding",
    "togetherembedding",
    "instructor",
)

_RERANK_PATTERNS = (
    "rerank",
    "sentencetransformerrerank",
    "cohererank",
    "flagembeddingreranker",
    "llmrerank",
    "jinarank",
)

_POSTPROCESSOR_PATTERNS = (
    "postprocessor",
    "metadatareplacementpostprocessor",
    "longcontextreorder",
    "sentenceembeddingoptimizer",
    "prevnextpostprocessor",
    "keywordpostprocessor",
    "similaritypostprocessor",
    "fixedrecencypostprocessor",
    "embeddingrecencypostprocessor",
    "timeweightedpostprocessor",
)

_TOOL_PATTERNS = (
    "tool",
    "querytool",
    "queryenginetool",
    "functiontool",
    "retrivertool",
)

_READER_PATTERNS = (
    "reader",
    "simplereader",
    "pdfreader",
    "docxreader",
    "markdownreader",
    "jsonreader",
    "csvsreader",
    "webreader",
    "simpledirectoryreader",
    "notionreader",
    "confluencereader",
    "slackreader",
    "githubreader",
)

_STORAGE_PATTERNS = (
    "storagecontext",
    "docstore",
    "indexstore",
    "vectorstore",
    "graphstore",
)


def _classify_instance(class_name: str, module: str) -> tuple[str, str]:
    """Return (span_kind, span_name) for a LlamaIndex class.

    span_kind is one of: "retrieval", "query", "parse", "index",
    "synthesize", "agent", "workflow", "llm", "embedding", "rerank",
    "postprocess", "tool", "reader", "storage", "step".

    span_name is the human-readable span name prefix.
    """
    cn = class_name.lower()
    mod = module.lower()

    # Check module path first for strong signals
    if ".retrievers" in mod or ".retriever" in mod:
        return "retrieval", "llamaindex.retrieve"
    if ".query_engine" in mod:
        return "query", "llamaindex.query"
    if ".node_parser" in mod:
        return "parse", "llamaindex.parse"
    if ".indices" in mod or ".index" in mod:
        return "index", "llamaindex.index"
    if ".response_synthesizers" in mod or ".synthesizer" in mod:
        return "synthesize", "llamaindex.synthesize"
    if ".agent" in mod:
        return "agent", "llamaindex.agent"
    if ".workflow" in mod:
        return "workflow", "llamaindex.workflow"
    if ".llms" in mod:
        return "llm", "llamaindex.llm"
    if ".embeddings" in mod:
        return "embedding", "llamaindex.embed"
    if ".postprocessor" in mod:
        return "postprocess", "llamaindex.postprocess"
    if ".tools" in mod:
        return "tool", "llamaindex.tool"
    if ".readers" in mod or ".reader" in mod:
        return "reader", "llamaindex.read"
    if ".storage" in mod:
        return "storage", "llamaindex.storage"

    # Fall back to class name patterns
    if any(p in cn for p in _RETRIEVER_PATTERNS):
        return "retrieval", "llamaindex.retrieve"
    if any(p in cn for p in _QUERY_ENGINE_PATTERNS):
        return "query", "llamaindex.query"
    if any(p in cn for p in _NODE_PARSER_PATTERNS):
        return "parse", "llamaindex.parse"
    if any(p in cn for p in _SYNTHESIZER_PATTERNS):
        return "synthesize", "llamaindex.synthesize"
    if any(p in cn for p in _AGENT_PATTERNS):
        return "agent", "llamaindex.agent"
    if any(p in cn for p in _WORKFLOW_PATTERNS):
        return "workflow", "llamaindex.workflow"
    if any(p in cn for p in _EMBEDDING_PATTERNS):
        return "embedding", "llamaindex.embed"
    if any(p in cn for p in _LLM_PATTERNS):
        return "llm", "llamaindex.llm"
    if any(p in cn for p in _RERANK_PATTERNS):
        return "rerank", "llamaindex.rerank"
    if any(p in cn for p in _POSTPROCESSOR_PATTERNS):
        return "postprocess", "llamaindex.postprocess"
    if any(p in cn for p in _TOOL_PATTERNS):
        return "tool", "llamaindex.tool"
    if any(p in cn for p in _INDEX_PATTERNS):
        return "index", "llamaindex.index"
    if any(p in cn for p in _READER_PATTERNS):
        return "reader", "llamaindex.read"
    if any(p in cn for p in _STORAGE_PATTERNS):
        return "storage", "llamaindex.storage"

    return "step", f"llamaindex.{class_name}"


def _create_span_for_kind(kind: str, name: str, class_name: str, instance: Any):
    """Create an OTel span based on the classified kind."""
    try:
        from ..tracing.spans import (
            start_agent_span,
            start_embedding_span,
            start_llm_span,
            start_retrieval_span,
            start_step_span,
            start_tool_span,
        )
    except Exception:
        return None

    try:
        if kind == "retrieval":
            # Try to extract query from the instance
            query = ""
            try:
                q = getattr(instance, "_query", None) or getattr(
                    instance, "query", None
                )
                if q:
                    query = str(q)[:500]
            except Exception:
                pass
            span = start_retrieval_span(
                query=query, source=f"llamaindex.{class_name}"
            )
            span.set_attribute("waxell.llamaindex.component", class_name)
            return span

        if kind == "llm":
            model = ""
            try:
                model = (
                    getattr(instance, "model", "")
                    or getattr(instance, "model_name", "")
                    or getattr(instance, "_model", "")
                    or ""
                )
            except Exception:
                pass
            span = start_llm_span(
                model=model or "llamaindex-llm",
                provider_name="llamaindex",
            )
            span.set_attribute("waxell.llamaindex.component", class_name)
            return span

        if kind == "embedding":
            model = ""
            try:
                model = (
                    getattr(instance, "model_name", "")
                    or getattr(instance, "model", "")
                    or getattr(instance, "_model_name", "")
                    or ""
                )
            except Exception:
                pass
            span = start_embedding_span(
                model=model or "llamaindex-embed",
                provider_name="llamaindex",
            )
            span.set_attribute("waxell.llamaindex.component", class_name)
            return span

        if kind == "agent":
            agent_name = ""
            try:
                agent_name = (
                    getattr(instance, "name", "")
                    or getattr(instance, "agent_name", "")
                    or class_name
                )
            except Exception:
                agent_name = class_name
            span = start_agent_span(
                agent_name=agent_name or class_name,
                workflow_name="llamaindex_agent",
            )
            span.set_attribute("waxell.llamaindex.component", class_name)
            return span

        if kind == "tool":
            tool_name = ""
            try:
                tool_name = (
                    getattr(instance, "name", "")
                    or getattr(instance, "metadata", {}).get("name", "")
                    or class_name
                )
            except Exception:
                tool_name = class_name
            span = start_tool_span(tool_name=tool_name or class_name)
            span.set_attribute("waxell.llamaindex.component", class_name)
            return span

        # All other kinds: query, parse, index, synthesize, workflow,
        # rerank, postprocess, reader, storage, step
        span = start_step_span(step_name=name)
        span.set_attribute("waxell.llamaindex.component", class_name)
        span.set_attribute("waxell.llamaindex.kind", kind)
        return span

    except Exception as e:
        logger.debug("Failed to create span for %s (%s): %s", class_name, kind, e)
        return None


# ---------------------------------------------------------------------------
# CBEventType mapping for the legacy callback handler
# ---------------------------------------------------------------------------

_CBEVENT_MAP: Dict[str, tuple[str, str]] = {
    # CBEventType.LLM
    "LLM": ("llm", "llamaindex.llm"),
    # CBEventType.EMBEDDING
    "EMBEDDING": ("embedding", "llamaindex.embed"),
    # CBEventType.RETRIEVE
    "RETRIEVE": ("retrieval", "llamaindex.retrieve"),
    # CBEventType.QUERY
    "QUERY": ("query", "llamaindex.query"),
    # CBEventType.CHUNKING
    "CHUNKING": ("parse", "llamaindex.chunk"),
    # CBEventType.SYNTHESIZE
    "SYNTHESIZE": ("synthesize", "llamaindex.synthesize"),
    # CBEventType.NODE_PARSING
    "NODE_PARSING": ("parse", "llamaindex.parse"),
    # CBEventType.TEMPLATING
    "TEMPLATING": ("step", "llamaindex.template"),
    # CBEventType.SUB_QUESTION
    "SUB_QUESTION": ("query", "llamaindex.sub_question"),
    # CBEventType.TREE
    "TREE": ("step", "llamaindex.tree"),
    # CBEventType.RERANKING
    "RERANKING": ("rerank", "llamaindex.rerank"),
    # CBEventType.AGENT_STEP
    "AGENT_STEP": ("agent", "llamaindex.agent_step"),
    # CBEventType.FUNCTION_CALL
    "FUNCTION_CALL": ("tool", "llamaindex.function_call"),
    # CBEventType.EXCEPTION
    "EXCEPTION": ("step", "llamaindex.exception"),
}


# ---------------------------------------------------------------------------
# NEW instrumentation system handlers (v0.10.30+)
# ---------------------------------------------------------------------------

_NEW_SYSTEM_AVAILABLE = False

try:
    from llama_index.core.instrumentation.span_handler import BaseSpanHandler
    from llama_index.core.instrumentation.span import BaseSpan

    _NEW_SYSTEM_AVAILABLE = True

    class WaxellSpanHandler(BaseSpanHandler[BaseSpan]):
        """Tracks all LlamaIndex spans via OTel using the new
        instrumentation system (v0.10.30+).

        Thread-safe: uses a lock to protect the _open_spans dict.
        """

        def __init__(self) -> None:
            super().__init__()
            self._open_spans: Dict[str, Any] = {}
            self._span_meta: Dict[str, Dict[str, str]] = {}
            self._lock = threading.Lock()

        @classmethod
        def class_name(cls) -> str:
            return "WaxellSpanHandler"

        def new_span(
            self,
            id_: str,
            bound_args: Any,
            instance: Any = None,
            parent_span_id: Optional[str] = None,
            tags: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
        ) -> Optional[BaseSpan]:
            """Called when a new LlamaIndex span begins."""
            try:
                class_name = type(instance).__name__ if instance else "unknown"
                module = type(instance).__module__ if instance else ""

                kind, span_name = _classify_instance(class_name, module)
                span = _create_span_for_kind(kind, span_name, class_name, instance)

                if span is not None:
                    with self._lock:
                        self._open_spans[id_] = span
                        self._span_meta[id_] = {
                            "class_name": class_name,
                            "kind": kind,
                            "span_name": span_name,
                        }

                # Return a BaseSpan to keep LlamaIndex's dispatcher happy
                try:
                    return BaseSpan(id_=id_, parent_id=parent_span_id)
                except Exception:
                    return None

            except Exception as e:
                logger.debug("WaxellSpanHandler.new_span error: %s", e)
                return None

        def prepare_to_exit_span(
            self,
            id_: str,
            bound_args: Any,
            instance: Any = None,
            result: Optional[Any] = None,
            **kwargs: Any,
        ) -> None:
            """Called when a LlamaIndex span completes successfully."""
            try:
                with self._lock:
                    span = self._open_spans.pop(id_, None)
                    meta = self._span_meta.pop(id_, {})

                if span is None:
                    return

                kind = meta.get("kind", "")
                class_name = meta.get("class_name", "")

                # Set result attributes based on the kind
                _set_result_attrs(span, kind, class_name, instance, result)

                # HTTP dual-path recording for LLM/embedding events
                if kind == "llm":
                    _record_http_llm(instance, result)
                elif kind == "embedding":
                    _record_http_embedding(instance, result)

                span.end()

            except Exception as e:
                logger.debug("WaxellSpanHandler.prepare_to_exit_span error: %s", e)
                # Ensure span is ended even on error
                try:
                    if span is not None:
                        span.end()
                except Exception:
                    pass

        def prepare_to_drop_span(
            self,
            id_: str,
            bound_args: Any,
            instance: Any = None,
            err: Optional[BaseException] = None,
            **kwargs: Any,
        ) -> None:
            """Called when a LlamaIndex span is dropped due to an error."""
            try:
                with self._lock:
                    span = self._open_spans.pop(id_, None)
                    self._span_meta.pop(id_, None)

                if span is None:
                    return

                if err is not None:
                    _record_error(span, err)

                span.end()

            except Exception as e:
                logger.debug("WaxellSpanHandler.prepare_to_drop_span error: %s", e)
                try:
                    if span is not None:
                        span.end()
                except Exception:
                    pass

except ImportError:
    pass


# ---------------------------------------------------------------------------
# LEGACY callback handler (pre-v0.10.30)
# ---------------------------------------------------------------------------

_LEGACY_SYSTEM_AVAILABLE = False

try:
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler

    _LEGACY_SYSTEM_AVAILABLE = True

    class WaxellCallbackHandler(BaseCallbackHandler):
        """Legacy LlamaIndex callback handler for waxell-observe.

        Intercepts CBEventType events and emits OTel spans.
        Thread-safe via a lock on _spans.
        """

        def __init__(self) -> None:
            # Trace all event types by leaving lists empty
            super().__init__(event_starts_to_trace=[], event_ends_to_trace=[])
            self._spans: Dict[str, Any] = {}
            self._span_meta: Dict[str, Dict[str, str]] = {}
            self._lock = threading.Lock()

        def on_event_start(
            self,
            event_type: Any,
            payload: Optional[Dict[str, Any]] = None,
            event_id: str = "",
            parent_id: str = "",
            **kwargs: Any,
        ) -> str:
            """Called when a LlamaIndex event begins."""
            try:
                # Get the event type name string
                event_name = _get_event_type_name(event_type)

                mapping = _CBEVENT_MAP.get(event_name, ("step", f"llamaindex.{event_name.lower()}"))
                kind, span_name = mapping

                span = _create_span_for_cbevent(kind, span_name, event_name, payload)

                if span is not None:
                    # Attach payload attributes
                    _set_payload_start_attrs(span, kind, event_name, payload)

                    with self._lock:
                        self._spans[event_id] = span
                        self._span_meta[event_id] = {
                            "kind": kind,
                            "event_name": event_name,
                        }
            except Exception as e:
                logger.debug("WaxellCallbackHandler.on_event_start error: %s", e)

            return event_id

        def on_event_end(
            self,
            event_type: Any,
            payload: Optional[Dict[str, Any]] = None,
            event_id: str = "",
            **kwargs: Any,
        ) -> None:
            """Called when a LlamaIndex event completes."""
            try:
                with self._lock:
                    span = self._spans.pop(event_id, None)
                    meta = self._span_meta.pop(event_id, {})

                if span is None:
                    return

                kind = meta.get("kind", "")
                event_name = meta.get("event_name", "")

                # Set result attributes from payload
                _set_payload_end_attrs(span, kind, event_name, payload)

                # HTTP dual-path recording for LLM/embedding events
                if kind == "llm":
                    _record_http_llm_from_payload(payload)
                elif kind == "embedding":
                    _record_http_embedding_from_payload(payload)

                span.end()

            except Exception as e:
                logger.debug("WaxellCallbackHandler.on_event_end error: %s", e)
                try:
                    if span is not None:
                        span.end()
                except Exception:
                    pass

        def start_trace(self, trace_id: Optional[str] = None) -> None:
            """Called when a trace begins (top-level query, etc.)."""
            pass

        def end_trace(
            self,
            trace_id: Optional[str] = None,
            trace_map: Optional[Dict[str, list]] = None,
        ) -> None:
            """Called when a trace ends."""
            pass

except ImportError:
    pass


# ---------------------------------------------------------------------------
# Very old LlamaIndex callback handler (pre-0.10, llama_index.callbacks)
# ---------------------------------------------------------------------------

_VERY_OLD_SYSTEM_AVAILABLE = False

try:
    from llama_index.callbacks.base_handler import BaseCallbackHandler as OldBaseCallbackHandler

    _VERY_OLD_SYSTEM_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# LlamaIndexInstrumentor class
# ---------------------------------------------------------------------------


class LlamaIndexInstrumentor(BaseInstrumentor):
    """Instrumentor for the LlamaIndex framework (``llama-index`` package).

    Instruments all sub-components: indices, retrievers, query engines,
    node parsers, response synthesizers, LLM calls, embeddings, agents,
    workflows, tools, postprocessors, readers, rerankers, and storage.

    Attempts the new instrumentation system (v0.10.30+) first, then falls
    back to the legacy CallbackManager system.
    """

    _instrumented: bool = False
    _handler: Any = None
    _system: str = ""  # "new", "legacy", "very_old"
    _original_init: Any = None  # Saved original CallbackManager.__init__

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Try importing llama_index at all
        try:
            import llama_index.core  # noqa: F401
        except ImportError:
            try:
                import llama_index  # noqa: F401
            except ImportError:
                logger.debug(
                    "llama_index not installed -- skipping instrumentation"
                )
                return False

        # --- Strategy 1: New instrumentation system (v0.10.30+) ---
        if self._try_new_system():
            self._instrumented = True
            self._system = "new"
            logger.debug(
                "LlamaIndex instrumented via new instrumentation system "
                "(SpanHandler)"
            )
            return True

        # --- Strategy 2: Legacy CallbackManager patch ---
        if self._try_legacy_system():
            self._instrumented = True
            self._system = "legacy"
            logger.debug(
                "LlamaIndex instrumented via legacy CallbackManager patch"
            )
            return True

        # --- Strategy 3: Very old llama_index.callbacks ---
        if self._try_very_old_system():
            self._instrumented = True
            self._system = "very_old"
            logger.debug(
                "LlamaIndex instrumented via very old callback system patch"
            )
            return True

        logger.debug(
            "Could not find any LlamaIndex instrumentation system to patch"
        )
        return False

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            if self._system == "new":
                self._remove_new_system()
            elif self._system in ("legacy", "very_old"):
                self._remove_legacy_system()
        except Exception as e:
            logger.debug("Error uninstrumenting LlamaIndex: %s", e)

        self._instrumented = False
        self._handler = None
        self._system = ""
        logger.debug("LlamaIndex uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented

    # ------------------------------------------------------------------
    # Strategy 1: New instrumentation system
    # ------------------------------------------------------------------

    def _try_new_system(self) -> bool:
        """Try to register a WaxellSpanHandler with the new dispatcher."""
        if not _NEW_SYSTEM_AVAILABLE:
            return False

        try:
            from llama_index.core.instrumentation import get_dispatcher

            dispatcher = get_dispatcher()
            handler = WaxellSpanHandler()
            dispatcher.add_span_handler(handler)
            self._handler = handler
            return True
        except Exception as e:
            logger.debug("Failed to register new-system handler: %s", e)
            return False

    def _remove_new_system(self) -> None:
        """Remove our SpanHandler from the dispatcher."""
        try:
            from llama_index.core.instrumentation import get_dispatcher

            dispatcher = get_dispatcher()
            # The dispatcher stores handlers in span_handlers list
            handlers = getattr(dispatcher, "span_handlers", [])
            for i, h in enumerate(handlers):
                if isinstance(h, WaxellSpanHandler):
                    handlers.pop(i)
                    break
        except Exception as e:
            logger.debug("Failed to remove new-system handler: %s", e)

    # ------------------------------------------------------------------
    # Strategy 2: Legacy CallbackManager patch
    # ------------------------------------------------------------------

    def _try_legacy_system(self) -> bool:
        """Patch CallbackManager.__init__ to always include our handler."""
        if not _LEGACY_SYSTEM_AVAILABLE:
            return False

        try:
            from llama_index.core.callbacks import CallbackManager

            handler = WaxellCallbackHandler()
            self._handler = handler

            original_init = CallbackManager.__init__

            def patched_init(self_cm, handlers=None, *args, **kwargs):
                try:
                    if handlers is None:
                        handlers = []
                    # Ensure our handler is included
                    has_waxell = any(
                        isinstance(h, WaxellCallbackHandler) for h in handlers
                    )
                    if not has_waxell:
                        handlers = list(handlers) + [handler]
                except Exception:
                    pass
                return original_init(self_cm, handlers, *args, **kwargs)

            CallbackManager.__init__ = patched_init  # type: ignore[assignment]
            self._original_init = original_init

            # Also try to register with the global/default callback manager
            try:
                from llama_index.core import Settings

                if hasattr(Settings, "callback_manager"):
                    cm = Settings.callback_manager
                    if cm is not None:
                        _inject_handler(cm, handler)
                    else:
                        # Create a new CallbackManager with our handler
                        Settings.callback_manager = CallbackManager([handler])
            except Exception:
                pass

            return True
        except Exception as e:
            logger.debug("Failed to patch legacy CallbackManager: %s", e)
            return False

    def _try_very_old_system(self) -> bool:
        """Patch the very old llama_index.callbacks.CallbackManager."""
        if not _VERY_OLD_SYSTEM_AVAILABLE:
            return False

        try:
            from llama_index.callbacks import CallbackManager as OldCallbackManager

            # Create a compatible handler
            handler = _create_very_old_handler()
            if handler is None:
                return False

            self._handler = handler
            original_init = OldCallbackManager.__init__

            def patched_init(self_cm, handlers=None, *args, **kwargs):
                try:
                    if handlers is None:
                        handlers = []
                    handlers = list(handlers) + [handler]
                except Exception:
                    pass
                return original_init(self_cm, handlers, *args, **kwargs)

            OldCallbackManager.__init__ = patched_init  # type: ignore[assignment]
            self._original_init = original_init
            return True
        except Exception as e:
            logger.debug("Failed to patch very old callback system: %s", e)
            return False

    def _remove_legacy_system(self) -> None:
        """Restore the original CallbackManager.__init__."""
        if self._original_init is None:
            return

        try:
            try:
                from llama_index.core.callbacks import CallbackManager

                CallbackManager.__init__ = self._original_init  # type: ignore[assignment]
            except ImportError:
                pass

            try:
                from llama_index.callbacks import CallbackManager as OldCallbackManager

                OldCallbackManager.__init__ = self._original_init  # type: ignore[assignment]
            except ImportError:
                pass
        except Exception as e:
            logger.debug("Failed to restore CallbackManager.__init__: %s", e)

        self._original_init = None


# ---------------------------------------------------------------------------
# Helpers: inject handler into existing CallbackManager
# ---------------------------------------------------------------------------


def _inject_handler(callback_manager: Any, handler: Any) -> None:
    """Add our handler to an existing CallbackManager if not already present."""
    try:
        handlers = getattr(callback_manager, "handlers", [])
        for h in handlers:
            if type(h).__name__ == type(handler).__name__:
                return  # Already present
        handlers.append(handler)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers: very old system handler
# ---------------------------------------------------------------------------


def _create_very_old_handler() -> Optional[Any]:
    """Create a handler compatible with the very old callback system."""
    if not _VERY_OLD_SYSTEM_AVAILABLE:
        return None

    try:
        class WaxellOldCallbackHandler(OldBaseCallbackHandler):  # type: ignore[misc]
            def __init__(self) -> None:
                super().__init__(event_starts_to_trace=[], event_ends_to_trace=[])
                self._spans: Dict[str, Any] = {}
                self._lock = threading.Lock()

            def on_event_start(self, event_type, payload=None, event_id="", parent_id="", **kwargs):
                try:
                    event_name = _get_event_type_name(event_type)
                    mapping = _CBEVENT_MAP.get(event_name, ("step", f"llamaindex.{event_name.lower()}"))
                    kind, span_name = mapping
                    span = _create_span_for_cbevent(kind, span_name, event_name, payload)
                    if span is not None:
                        with self._lock:
                            self._spans[event_id] = span
                except Exception:
                    pass
                return event_id

            def on_event_end(self, event_type, payload=None, event_id="", **kwargs):
                try:
                    with self._lock:
                        span = self._spans.pop(event_id, None)
                    if span is not None:
                        span.end()
                except Exception:
                    pass

            def start_trace(self, trace_id=None):
                pass

            def end_trace(self, trace_id=None, trace_map=None):
                pass

        return WaxellOldCallbackHandler()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Helpers: event type name extraction
# ---------------------------------------------------------------------------


def _get_event_type_name(event_type: Any) -> str:
    """Extract a string name from a CBEventType enum value."""
    try:
        if hasattr(event_type, "name"):
            return event_type.name
        if hasattr(event_type, "value"):
            return str(event_type.value)
        return str(event_type)
    except Exception:
        return "UNKNOWN"


# ---------------------------------------------------------------------------
# Helpers: create span from CBEventType (legacy)
# ---------------------------------------------------------------------------


def _create_span_for_cbevent(
    kind: str, span_name: str, event_name: str, payload: Optional[Dict[str, Any]]
) -> Optional[Any]:
    """Create an OTel span for a legacy CBEvent."""
    try:
        from ..tracing.spans import (
            start_agent_span,
            start_embedding_span,
            start_llm_span,
            start_retrieval_span,
            start_step_span,
            start_tool_span,
        )
    except Exception:
        return None

    try:
        if kind == "llm":
            model = _extract_model_from_payload(payload)
            return start_llm_span(
                model=model or "llamaindex-llm",
                provider_name="llamaindex",
            )

        if kind == "embedding":
            model = _extract_embedding_model_from_payload(payload)
            return start_embedding_span(
                model=model or "llamaindex-embed",
                provider_name="llamaindex",
            )

        if kind == "retrieval":
            query = _extract_query_from_payload(payload)
            return start_retrieval_span(
                query=query, source="llamaindex"
            )

        if kind == "agent":
            return start_agent_span(
                agent_name=f"llamaindex.{event_name.lower()}",
                workflow_name="llamaindex_agent",
            )

        if kind == "tool":
            tool_name = _extract_tool_name_from_payload(payload)
            return start_tool_span(
                tool_name=tool_name or f"llamaindex.{event_name.lower()}"
            )

        # Default: step span
        return start_step_span(step_name=span_name)

    except Exception as e:
        logger.debug("Failed to create span for CBEvent %s: %s", event_name, e)
        return None


# ---------------------------------------------------------------------------
# Helpers: set payload attributes on spans (legacy)
# ---------------------------------------------------------------------------


def _set_payload_start_attrs(
    span: Any, kind: str, event_name: str, payload: Optional[Dict[str, Any]]
) -> None:
    """Set attributes from start-event payload."""
    if payload is None:
        return
    try:
        span.set_attribute("waxell.llamaindex.event_type", event_name)

        if kind == "llm":
            # Extract messages from payload
            messages = payload.get("messages")
            if messages:
                span.set_attribute(
                    "waxell.llamaindex.message_count", len(messages)
                )

            # Extract model
            model = _extract_model_from_payload(payload)
            if model:
                span.set_attribute("waxell.llamaindex.model", model)

            # Extract template
            template = payload.get("template")
            if template:
                span.set_attribute(
                    "waxell.llamaindex.template",
                    str(template)[:500],
                )

        elif kind == "retrieval":
            query = _extract_query_from_payload(payload)
            if query:
                span.set_attribute("waxell.llamaindex.query", query[:500])

        elif kind == "embedding":
            # Count chunks being embedded
            chunks = payload.get("serialized", payload.get("chunks"))
            if isinstance(chunks, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.embed_chunk_count", len(chunks)
                )

        elif kind == "parse":
            # Node parsing: count documents
            documents = payload.get("documents")
            if isinstance(documents, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.document_count", len(documents)
                )

        elif kind == "query":
            query_str = payload.get("query_str") or payload.get("query_bundle")
            if query_str:
                span.set_attribute(
                    "waxell.llamaindex.query_str", str(query_str)[:500]
                )
    except Exception:
        pass


def _set_payload_end_attrs(
    span: Any, kind: str, event_name: str, payload: Optional[Dict[str, Any]]
) -> None:
    """Set attributes from end-event payload."""
    if payload is None:
        return
    try:
        if kind == "llm":
            response = payload.get("response")
            if response:
                span.set_attribute(
                    "waxell.llamaindex.response_preview",
                    str(response)[:500],
                )

            # Extract token counts from completion response
            completion = payload.get("completion")
            if completion:
                raw = getattr(completion, "raw", None)
                if raw:
                    usage = getattr(raw, "usage", None)
                    if usage:
                        tokens_in = getattr(usage, "prompt_tokens", 0) or 0
                        tokens_out = getattr(usage, "completion_tokens", 0) or 0
                        _set_llm_token_attrs(span, tokens_in, tokens_out)

            # Try additional_kwargs
            additional = payload.get("additional_kwargs", {})
            if isinstance(additional, dict):
                tokens_in = additional.get("prompt_tokens", 0)
                tokens_out = additional.get("completion_tokens", 0)
                if tokens_in or tokens_out:
                    _set_llm_token_attrs(span, tokens_in, tokens_out)

        elif kind == "retrieval":
            nodes = payload.get("nodes")
            if isinstance(nodes, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.retrieved_node_count", len(nodes)
                )
                # Record node IDs if available
                node_ids = []
                for n in nodes[:20]:
                    try:
                        nid = getattr(n, "node_id", None) or getattr(
                            getattr(n, "node", None), "node_id", None
                        )
                        if nid:
                            node_ids.append(str(nid))
                    except Exception:
                        pass
                if node_ids:
                    span.set_attribute(
                        "waxell.llamaindex.retrieved_node_ids", node_ids
                    )

        elif kind == "embedding":
            embeddings = payload.get("embeddings")
            if isinstance(embeddings, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.embedding_count", len(embeddings)
                )
                # Record dimensions
                if embeddings and hasattr(embeddings[0], "__len__"):
                    try:
                        span.set_attribute(
                            "waxell.llamaindex.embedding_dimensions",
                            len(embeddings[0]),
                        )
                    except Exception:
                        pass

        elif kind == "parse":
            nodes = payload.get("nodes")
            if isinstance(nodes, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.parsed_node_count", len(nodes)
                )

        elif kind == "synthesize":
            response = payload.get("response")
            if response:
                span.set_attribute(
                    "waxell.llamaindex.synthesis_preview",
                    str(response)[:500],
                )

        elif kind == "query":
            response = payload.get("response")
            if response:
                span.set_attribute(
                    "waxell.llamaindex.query_response_preview",
                    str(response)[:500],
                )

        elif kind == "rerank":
            nodes = payload.get("nodes")
            if isinstance(nodes, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.reranked_node_count", len(nodes)
                )

    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers: set result attributes (new system)
# ---------------------------------------------------------------------------


def _set_result_attrs(
    span: Any, kind: str, class_name: str, instance: Any, result: Any
) -> None:
    """Set span attributes based on the result of a span (new system)."""
    if result is None:
        return
    try:
        if kind == "llm":
            # Try to extract token usage from the result
            raw = getattr(result, "raw", None)
            if raw:
                usage = getattr(raw, "usage", None)
                if usage:
                    tokens_in = getattr(usage, "prompt_tokens", 0) or 0
                    tokens_out = getattr(usage, "completion_tokens", 0) or 0
                    _set_llm_token_attrs(span, tokens_in, tokens_out)

            # Response text preview
            text = getattr(result, "text", None) or getattr(result, "message", None)
            if text:
                span.set_attribute(
                    "waxell.llamaindex.response_preview", str(text)[:500]
                )

            # Model name from response
            model = getattr(result, "model", None) or getattr(
                getattr(result, "raw", None), "model", None
            )
            if model:
                span.set_attribute("waxell.llamaindex.response_model", str(model))

        elif kind == "retrieval":
            # Result is typically a list of NodeWithScore
            if isinstance(result, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.retrieved_node_count", len(result)
                )
            elif hasattr(result, "nodes"):
                nodes = result.nodes
                if isinstance(nodes, (list, tuple)):
                    span.set_attribute(
                        "waxell.llamaindex.retrieved_node_count", len(nodes)
                    )

        elif kind == "embedding":
            if isinstance(result, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.embedding_count", len(result)
                )
                if result and hasattr(result[0], "__len__"):
                    try:
                        span.set_attribute(
                            "waxell.llamaindex.embedding_dimensions",
                            len(result[0]),
                        )
                    except Exception:
                        pass

        elif kind == "parse":
            if isinstance(result, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.parsed_node_count", len(result)
                )

        elif kind in ("query", "synthesize"):
            text = getattr(result, "response", None) or str(result)
            span.set_attribute(
                "waxell.llamaindex.response_preview", str(text)[:500]
            )

            # Source nodes
            source_nodes = getattr(result, "source_nodes", None)
            if isinstance(source_nodes, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.source_node_count", len(source_nodes)
                )

        elif kind == "agent":
            text = getattr(result, "response", None) or str(result)
            span.set_attribute(
                "waxell.llamaindex.agent_response_preview",
                str(text)[:500],
            )
            # Sources
            source_nodes = getattr(result, "source_nodes", None)
            if isinstance(source_nodes, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.source_node_count", len(source_nodes)
                )

        elif kind == "rerank":
            if isinstance(result, (list, tuple)):
                span.set_attribute(
                    "waxell.llamaindex.reranked_node_count", len(result)
                )

        # Record to WaxellContext if available
        _record_to_context(kind, class_name, result)

    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers: set LLM token attributes
# ---------------------------------------------------------------------------


def _set_llm_token_attrs(span: Any, tokens_in: int, tokens_out: int) -> None:
    """Set LLM token usage attributes on a span."""
    try:
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost

        span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
        span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
        span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
        span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
        span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)

        # Try to estimate cost (model may not be available here)
        model = ""
        try:
            # Get model from span attributes if possible
            model = getattr(span, "_attributes", {}).get(
                "waxell.llamaindex.model", ""
            )
        except Exception:
            pass
        if model:
            cost = estimate_cost(model, tokens_in, tokens_out)
            if cost > 0:
                span.set_attribute(WaxellAttributes.LLM_COST, cost)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers: payload extraction
# ---------------------------------------------------------------------------


def _extract_model_from_payload(payload: Optional[Dict[str, Any]]) -> str:
    """Extract the LLM model name from a callback payload."""
    if not payload:
        return ""
    try:
        # Direct model field
        model = payload.get("model")
        if model:
            return str(model)

        # Serialized dict
        serialized = payload.get("serialized", {})
        if isinstance(serialized, dict):
            model = serialized.get("model") or serialized.get("model_name")
            if model:
                return str(model)

        # Additional kwargs
        additional = payload.get("additional_kwargs", {})
        if isinstance(additional, dict):
            model = additional.get("model") or additional.get("model_name")
            if model:
                return str(model)
    except Exception:
        pass
    return ""


def _extract_embedding_model_from_payload(
    payload: Optional[Dict[str, Any]],
) -> str:
    """Extract embedding model name from a callback payload."""
    if not payload:
        return ""
    try:
        serialized = payload.get("serialized", {})
        if isinstance(serialized, dict):
            return str(
                serialized.get("model_name")
                or serialized.get("model")
                or ""
            )
    except Exception:
        pass
    return ""


def _extract_query_from_payload(payload: Optional[Dict[str, Any]]) -> str:
    """Extract query string from a callback payload."""
    if not payload:
        return ""
    try:
        query = (
            payload.get("query_str")
            or payload.get("query_bundle")
            or payload.get("query")
            or ""
        )
        if hasattr(query, "query_str"):
            return str(query.query_str)[:500]
        return str(query)[:500]
    except Exception:
        return ""


def _extract_tool_name_from_payload(payload: Optional[Dict[str, Any]]) -> str:
    """Extract tool name from a callback payload."""
    if not payload:
        return ""
    try:
        tool = payload.get("tool")
        if tool:
            name = getattr(tool, "name", None) or getattr(
                tool, "metadata", {}
            ).get("name", "")
            if name:
                return str(name)
        return payload.get("function_call", {}).get("name", "")
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# HTTP dual-path recording (new system)
# ---------------------------------------------------------------------------


def _record_http_llm(instance: Any, result: Any) -> None:
    """Record an LLM call to the HTTP path (context or collector)."""
    try:
        from ._context_var import _current_context
        from ._collector import _collector
        from ..cost import estimate_cost

        model = ""
        tokens_in = 0
        tokens_out = 0
        response_preview = ""

        try:
            model = (
                getattr(instance, "model", "")
                or getattr(instance, "model_name", "")
                or ""
            )
        except Exception:
            pass

        if result:
            raw = getattr(result, "raw", None)
            if raw:
                usage = getattr(raw, "usage", None)
                if usage:
                    tokens_in = getattr(usage, "prompt_tokens", 0) or 0
                    tokens_out = getattr(usage, "completion_tokens", 0) or 0

                result_model = getattr(raw, "model", None)
                if result_model:
                    model = str(result_model)

            text = getattr(result, "text", None) or getattr(result, "message", None)
            if text:
                response_preview = str(text)[:500]

        cost = estimate_cost(model, tokens_in, tokens_out) if model else 0.0

        call_data = {
            "model": model or "llamaindex-llm",
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": cost,
            "task": "llamaindex.llm",
            "response_preview": response_preview,
        }

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_llm_call(**call_data)
        else:
            _collector.record_call(call_data)

    except Exception:
        pass


def _record_http_embedding(instance: Any, result: Any) -> None:
    """Record an embedding call to the HTTP path."""
    try:
        from ._context_var import _current_context

        model = ""
        try:
            model = (
                getattr(instance, "model_name", "")
                or getattr(instance, "model", "")
                or ""
            )
        except Exception:
            pass

        embed_count = 0
        dimensions = 0
        if isinstance(result, (list, tuple)):
            embed_count = len(result)
            if result and hasattr(result[0], "__len__"):
                try:
                    dimensions = len(result[0])
                except Exception:
                    pass

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "llamaindex.embed",
                output={
                    "model": model,
                    "embed_count": embed_count,
                    "dimensions": dimensions,
                },
            )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# HTTP dual-path recording (legacy system)
# ---------------------------------------------------------------------------


def _record_http_llm_from_payload(payload: Optional[Dict[str, Any]]) -> None:
    """Record an LLM call from a legacy callback payload."""
    try:
        from ._context_var import _current_context
        from ._collector import _collector
        from ..cost import estimate_cost

        model = _extract_model_from_payload(payload) or "llamaindex-llm"
        tokens_in = 0
        tokens_out = 0
        response_preview = ""

        if payload:
            # Try to get token counts from completion
            completion = payload.get("completion")
            if completion:
                raw = getattr(completion, "raw", None)
                if raw:
                    usage = getattr(raw, "usage", None)
                    if usage:
                        tokens_in = getattr(usage, "prompt_tokens", 0) or 0
                        tokens_out = getattr(usage, "completion_tokens", 0) or 0

                    result_model = getattr(raw, "model", None)
                    if result_model:
                        model = str(result_model)

            # Additional kwargs may have token counts
            additional = payload.get("additional_kwargs", {})
            if isinstance(additional, dict) and not tokens_in:
                tokens_in = additional.get("prompt_tokens", 0) or 0
                tokens_out = additional.get("completion_tokens", 0) or 0

            # Response preview
            response = payload.get("response")
            if response:
                response_preview = str(response)[:500]

        cost = estimate_cost(model, tokens_in, tokens_out) if model else 0.0

        call_data = {
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": cost,
            "task": "llamaindex.llm",
            "response_preview": response_preview,
        }

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_llm_call(**call_data)
        else:
            _collector.record_call(call_data)

    except Exception:
        pass


def _record_http_embedding_from_payload(
    payload: Optional[Dict[str, Any]],
) -> None:
    """Record an embedding call from a legacy callback payload."""
    try:
        from ._context_var import _current_context

        model = _extract_embedding_model_from_payload(payload)
        embed_count = 0
        dimensions = 0

        if payload:
            embeddings = payload.get("embeddings")
            if isinstance(embeddings, (list, tuple)):
                embed_count = len(embeddings)
                if embeddings and hasattr(embeddings[0], "__len__"):
                    try:
                        dimensions = len(embeddings[0])
                    except Exception:
                        pass

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "llamaindex.embed",
                output={
                    "model": model,
                    "embed_count": embed_count,
                    "dimensions": dimensions,
                },
            )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers: record to WaxellContext
# ---------------------------------------------------------------------------


def _record_to_context(kind: str, class_name: str, result: Any) -> None:
    """Record step completion to WaxellContext if available."""
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if not ctx or not ctx.run_id:
            return

        output: Dict[str, Any] = {"component": class_name}

        if kind == "retrieval":
            count = 0
            if isinstance(result, (list, tuple)):
                count = len(result)
            elif hasattr(result, "nodes"):
                count = len(getattr(result, "nodes", []))
            output["retrieved_count"] = count

        elif kind in ("query", "synthesize"):
            response = getattr(result, "response", None) or str(result)
            output["response_preview"] = str(response)[:200]

        elif kind == "parse":
            if isinstance(result, (list, tuple)):
                output["parsed_count"] = len(result)

        elif kind == "agent":
            response = getattr(result, "response", None) or str(result)
            output["response_preview"] = str(response)[:200]

        else:
            output["result_preview"] = str(result)[:200]

        ctx.record_step(f"llamaindex.{kind}:{class_name}", output=output)

    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers: error recording
# ---------------------------------------------------------------------------


def _record_error(span: Any, exc: BaseException) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
