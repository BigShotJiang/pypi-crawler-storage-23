"""DeepEval auto-instrumentor for waxell-observe.

Monkey-patches ``deepeval.evaluate`` and ``deepeval.metrics.BaseMetric.measure``
(sync + async) to emit evaluation spans tracking metric scores and pass rates.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class DeepEvalInstrumentor(BaseInstrumentor):
    """Instrumentor for the DeepEval evaluation framework (``deepeval`` package).

    Patches evaluate(), BaseMetric.measure(), and BaseMetric.a_measure().
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import deepeval  # noqa: F401
        except ImportError:
            logger.debug("deepeval not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping DeepEval instrumentation")
            return False

        patched = False

        # Patch deepeval.evaluate (top-level batch evaluation)
        try:
            wrapt.wrap_function_wrapper(
                "deepeval",
                "evaluate",
                _evaluate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch deepeval.evaluate: %s", exc)

        # Patch BaseMetric.measure (individual metric evaluation)
        try:
            wrapt.wrap_function_wrapper(
                "deepeval.metrics",
                "BaseMetric.measure",
                _metric_measure_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch BaseMetric.measure: %s", exc)

        # Patch BaseMetric.a_measure (async individual metric evaluation)
        try:
            wrapt.wrap_function_wrapper(
                "deepeval.metrics",
                "BaseMetric.a_measure",
                _async_metric_measure_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch BaseMetric.a_measure: %s", exc)

        if not patched:
            logger.debug("Could not find DeepEval methods to patch")
            return False

        self._instrumented = True
        logger.debug("DeepEval instrumented (evaluate + BaseMetric.measure + a_measure)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import deepeval

            if hasattr(deepeval.evaluate, "__wrapped__"):
                deepeval.evaluate = deepeval.evaluate.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from deepeval.metrics import BaseMetric

            if hasattr(BaseMetric.measure, "__wrapped__"):
                BaseMetric.measure = BaseMetric.measure.__wrapped__
            if hasattr(getattr(BaseMetric, "a_measure", None), "__wrapped__"):
                BaseMetric.a_measure = BaseMetric.a_measure.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("DeepEval uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _evaluate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``deepeval.evaluate`` -- top-level batch evaluation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract test_cases and metrics from args/kwargs
    test_cases = []
    metrics = []
    try:
        if args:
            test_cases = args[0] if len(args) > 0 else []
            metrics = args[1] if len(args) > 1 else kwargs.get("metrics", [])
        else:
            test_cases = kwargs.get("test_cases", [])
            metrics = kwargs.get("metrics", [])
    except Exception:
        pass

    test_cases_count = 0
    metrics_count = 0
    try:
        test_cases_count = len(test_cases) if test_cases else 0
    except Exception:
        pass
    try:
        metrics_count = len(metrics) if metrics else 0
    except Exception:
        pass

    try:
        span = start_step_span(step_name="deepeval.evaluate")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "deepeval")
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, test_cases_count)
        span.set_attribute(WaxellAttributes.EVAL_METRICS_COUNT, metrics_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_eval_result(span, result, test_cases_count)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _metric_measure_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``BaseMetric.measure`` -- individual metric evaluation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    metric_name = ""
    threshold = None
    try:
        metric_name = type(instance).__name__
    except Exception:
        metric_name = "UnknownMetric"
    try:
        threshold = getattr(instance, "threshold", None)
    except Exception:
        pass

    try:
        span = start_step_span(step_name=f"deepeval.metric:{metric_name}")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "deepeval")
        span.set_attribute(WaxellAttributes.EVAL_METRIC_NAME, metric_name)
        if threshold is not None:
            span.set_attribute(WaxellAttributes.EVAL_THRESHOLD, float(threshold))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_metric_result(span, instance, metric_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _async_metric_measure_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``BaseMetric.a_measure`` -- async metric evaluation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return await wrapped(*args, **kwargs)

    metric_name = ""
    threshold = None
    try:
        metric_name = type(instance).__name__
    except Exception:
        metric_name = "UnknownMetric"
    try:
        threshold = getattr(instance, "threshold", None)
    except Exception:
        pass

    try:
        span = start_step_span(step_name=f"deepeval.metric:{metric_name}")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "deepeval")
        span.set_attribute(WaxellAttributes.EVAL_METRIC_NAME, metric_name)
        if threshold is not None:
            span.set_attribute(WaxellAttributes.EVAL_THRESHOLD, float(threshold))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_metric_result(span, instance, metric_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_eval_result(span, result, test_cases_count: int) -> None:
    """Extract batch evaluation results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    passed = 0
    failed = 0
    pass_rate = 0.0

    try:
        # DeepEval evaluate() returns a list of EvaluationResult or similar
        if isinstance(result, (list, tuple)):
            for r in result:
                try:
                    success = getattr(r, "success", None)
                    if success is None:
                        success = getattr(r, "passed", None)
                    if success:
                        passed += 1
                    else:
                        failed += 1
                except Exception:
                    pass
        else:
            # May return a single object with test_results attribute
            test_results = getattr(result, "test_results", None)
            if test_results is not None:
                for r in test_results:
                    try:
                        success = getattr(r, "success", None)
                        if success is None:
                            success = getattr(r, "passed", None)
                        if success:
                            passed += 1
                        else:
                            failed += 1
                    except Exception:
                        pass

        total = passed + failed
        if total > 0:
            pass_rate = passed / total
    except Exception:
        pass

    try:
        span.set_attribute(WaxellAttributes.EVAL_PASSED, passed)
        span.set_attribute("waxell.eval.failed", failed)
        span.set_attribute(WaxellAttributes.EVAL_PASS_RATE, pass_rate)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_eval(result, passed, failed, pass_rate, test_cases_count)
    except Exception:
        pass


def _record_metric_result(span, instance, metric_name: str) -> None:
    """Extract individual metric results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    score = None
    reason = ""
    passed = False

    try:
        score = getattr(instance, "score", None)
    except Exception:
        pass

    try:
        reason = getattr(instance, "reason", "") or ""
    except Exception:
        pass

    try:
        if hasattr(instance, "is_successful"):
            passed = bool(instance.is_successful())
        elif score is not None:
            threshold = getattr(instance, "threshold", None)
            if threshold is not None:
                passed = score >= threshold
    except Exception:
        pass

    try:
        if score is not None:
            span.set_attribute(WaxellAttributes.EVAL_SCORE, float(score))
        span.set_attribute(WaxellAttributes.EVAL_PASSED, passed)
        if reason:
            span.set_attribute(WaxellAttributes.EVAL_REASON, str(reason)[:500])
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_metric(metric_name, score, passed, reason)
    except Exception:
        pass


def _record_http_eval(result, passed: int, failed: int, pass_rate: float,
                      test_cases_count: int) -> None:
    """Record a batch evaluation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:deepeval.evaluate",
            output={
                "framework": "deepeval",
                "test_cases_count": test_cases_count,
                "passed": passed,
                "failed": failed,
                "pass_rate": pass_rate,
                "result_preview": str(result)[:500],
            },
        )


def _record_http_metric(metric_name: str, score, passed: bool, reason: str) -> None:
    """Record an individual metric evaluation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"eval:deepeval.metric:{metric_name}",
            output={
                "framework": "deepeval",
                "metric": metric_name,
                "score": float(score) if score is not None else None,
                "passed": passed,
                "reason": str(reason)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
