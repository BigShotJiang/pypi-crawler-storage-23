"""ScaNN auto-instrumentor for waxell-observe.

Monkey-patches Google's ScaNN library to emit OTel spans for
vector search operations.

Patched methods:
  - scann.ScannSearcher.search          (retrieval span)
  - scann.ScannSearcher.search_batched  (retrieval span)

All wrapper code is wrapped in try/except -- never breaks the user's ScaNN calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ScaNNInstrumentor(BaseInstrumentor):
    """Instrumentor for the Google ScaNN library (``scann`` package).

    Patches ``ScannSearcher.search`` and ``ScannSearcher.search_batched``
    for retrieval spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import scann  # noqa: F401
        except ImportError:
            logger.debug("scann package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping ScaNN instrumentation")
            return False

        patched_any = False

        # Patch ScannSearcher.search (single-query retrieval)
        try:
            wrapt.wrap_function_wrapper(
                "scann",
                "ScannSearcher.search",
                _search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch scann.ScannSearcher.search: %s", exc)

        # Patch ScannSearcher.search_batched (batch retrieval)
        try:
            wrapt.wrap_function_wrapper(
                "scann",
                "ScannSearcher.search_batched",
                _search_batched_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch scann.ScannSearcher.search_batched: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any ScaNN ScannSearcher methods")
            return False

        self._instrumented = True
        logger.debug("ScaNN ScannSearcher instrumented (search, search_batched)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import scann

            cls = getattr(scann, "ScannSearcher", None)
            if cls is not None:
                for method_name in ("search", "search_batched"):
                    method = getattr(cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("ScaNN ScannSearcher uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ScannSearcher.search`` (single-query retrieval).

    Args layout: searcher.search(q, final_num_neighbors=None, pre_reorder_num_neighbors=None,
                                  leaves_to_search=None)
        q: numpy array query vector
        final_num_neighbors: int, number of results to return
        leaves_to_search: int, number of leaves to search
    Returns: (indices, distances) tuple of numpy arrays
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    final_num_neighbors = 0
    leaves_to_search = 0

    try:
        if len(args) > 1:
            final_num_neighbors = int(args[1])
        final_num_neighbors = int(kwargs.get("final_num_neighbors", final_num_neighbors))
        if len(args) > 2:
            leaves_to_search_arg = args[2]
            if leaves_to_search_arg is not None:
                leaves_to_search = int(leaves_to_search_arg)
        leaves_val = kwargs.get("leaves_to_search", None)
        if leaves_val is not None:
            leaves_to_search = int(leaves_val)
    except Exception:
        pass

    try:
        span = start_retrieval_span(query="scann.search", source="scann")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Result is (indices, distances) tuple
            results_count = 0
            if isinstance(result, (list, tuple)) and len(result) >= 1:
                indices = result[0]
                if hasattr(indices, "shape"):
                    results_count = int(indices.shape[0])
                elif hasattr(indices, "__len__"):
                    results_count = len(indices)

            span.set_attribute("waxell.retrieval.source", "scann")
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            if final_num_neighbors:
                span.set_attribute("waxell.retrieval.top_k", final_num_neighbors)
            if leaves_to_search:
                span.set_attribute("waxell.scann.leaves_to_search", leaves_to_search)
        except Exception as attr_exc:
            logger.debug("Failed to set ScaNN search span attributes: %s", attr_exc)

        try:
            _record_scann_retrieval(
                query="scann.search",
                results_count=results_count if "results_count" in dir() else 0,
                top_k=final_num_neighbors,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _search_batched_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ScannSearcher.search_batched`` (batch retrieval).

    Args layout: searcher.search_batched(queries, final_num_neighbors=None,
                                          pre_reorder_num_neighbors=None,
                                          leaves_to_search=None)
        queries: numpy array of query vectors (nq, d)
        final_num_neighbors: int, number of results per query
        leaves_to_search: int, number of leaves to search
    Returns: (indices, distances) tuple of numpy arrays, each shape (nq, k)
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    nq = 0
    final_num_neighbors = 0
    leaves_to_search = 0

    try:
        if args:
            queries = args[0]
            if hasattr(queries, "shape"):
                if len(queries.shape) == 2:
                    nq = int(queries.shape[0])
                elif len(queries.shape) == 1:
                    nq = 1
        if len(args) > 1:
            final_num_neighbors = int(args[1])
        final_num_neighbors = int(kwargs.get("final_num_neighbors", final_num_neighbors))
        if len(args) > 2:
            pre_reorder = args[2]
            # skip pre_reorder_num_neighbors
        if len(args) > 3:
            leaves_val = args[3]
            if leaves_val is not None:
                leaves_to_search = int(leaves_val)
        leaves_val = kwargs.get("leaves_to_search", None)
        if leaves_val is not None:
            leaves_to_search = int(leaves_val)
    except Exception:
        pass

    try:
        span = start_retrieval_span(query="scann.search_batched", source="scann")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Result is (indices, distances) tuple, each shape (nq, k)
            results_count = 0
            if isinstance(result, (list, tuple)) and len(result) >= 1:
                indices = result[0]
                if hasattr(indices, "shape"):
                    if len(indices.shape) == 2:
                        results_count = int(indices.shape[0] * indices.shape[1])
                    elif len(indices.shape) == 1:
                        results_count = int(indices.shape[0])
                elif hasattr(indices, "__len__"):
                    results_count = len(indices)

            span.set_attribute("waxell.retrieval.source", "scann")
            span.set_attribute("waxell.retrieval.operation", "search_batched")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            span.set_attribute("waxell.scann.nq", nq)
            if final_num_neighbors:
                span.set_attribute("waxell.retrieval.top_k", final_num_neighbors)
            if leaves_to_search:
                span.set_attribute("waxell.scann.leaves_to_search", leaves_to_search)
        except Exception as attr_exc:
            logger.debug("Failed to set ScaNN search_batched span attributes: %s", attr_exc)

        try:
            _record_scann_retrieval(
                query="scann.search_batched",
                results_count=results_count if "results_count" in dir() else 0,
                top_k=final_num_neighbors,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_scann_retrieval(
    query: str,
    results_count: int,
    top_k: int,
) -> None:
    """Record a ScaNN retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="scann",
            results_count=results_count,
            top_k=top_k,
        )
