"""Langfuse auto-instrumentor for waxell-observe.

Monkey-patches ``langfuse.Langfuse.trace``, ``langfuse.Langfuse.generation``,
``langfuse.Langfuse.span``, and score methods to emit step, LLM, and
guardrail spans tracking Langfuse tracing and evaluation operations.

Langfuse is an open-source LLM observability and evaluation platform.
This instrumentor captures Langfuse trace, generation, and scoring
operations as Waxell spans for unified observability.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LangfuseInstrumentor(BaseInstrumentor):
    """Instrumentor for Langfuse (``langfuse`` package).

    Patches ``Langfuse.trace()``, ``Langfuse.generation()``,
    ``Langfuse.span()``, and ``Langfuse.score()``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import langfuse  # noqa: F401
        except ImportError:
            logger.debug("langfuse package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Langfuse instrumentation")
            return False

        patched = False

        # Patch Langfuse.trace()
        try:
            wrapt.wrap_function_wrapper(
                "langfuse",
                "Langfuse.trace",
                _trace_wrapper,
            )
            patched = True
            logger.debug("Langfuse.trace patched")
        except Exception as exc:
            logger.debug("Failed to patch Langfuse.trace: %s", exc)

        # Patch Langfuse.generation()
        try:
            wrapt.wrap_function_wrapper(
                "langfuse",
                "Langfuse.generation",
                _generation_wrapper,
            )
            patched = True
            logger.debug("Langfuse.generation patched")
        except Exception as exc:
            logger.debug("Failed to patch Langfuse.generation: %s", exc)

        # Patch Langfuse.span()
        try:
            wrapt.wrap_function_wrapper(
                "langfuse",
                "Langfuse.span",
                _span_wrapper,
            )
            patched = True
            logger.debug("Langfuse.span patched")
        except Exception as exc:
            logger.debug("Failed to patch Langfuse.span: %s", exc)

        # Patch Langfuse.score()
        try:
            wrapt.wrap_function_wrapper(
                "langfuse",
                "Langfuse.score",
                _score_wrapper,
            )
            patched = True
            logger.debug("Langfuse.score patched")
        except Exception as exc:
            logger.debug("Failed to patch Langfuse.score: %s", exc)

        if not patched:
            logger.debug("Could not find any Langfuse methods to patch")
            return False

        self._instrumented = True
        logger.debug("Langfuse instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import langfuse

            for attr in ("trace", "generation", "span", "score"):
                method = getattr(langfuse.Langfuse, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(langfuse.Langfuse, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Langfuse uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _trace_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Langfuse.trace()`` -- trace creation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    trace_name = kwargs.get("name", "") or ""
    trace_input = kwargs.get("input", None)
    trace_output = kwargs.get("output", None)
    trace_metadata = kwargs.get("metadata", {})
    user_id = kwargs.get("user_id", "")
    session_id = kwargs.get("session_id", "")

    try:
        span = start_step_span(
            step_name=f"langfuse.trace:{trace_name}" if trace_name else "langfuse.trace"
        )
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "langfuse")
        span.set_attribute("waxell.langfuse.operation", "trace")
        if trace_name:
            span.set_attribute("waxell.langfuse.trace_name", str(trace_name)[:200])
        if trace_input is not None:
            span.set_attribute("waxell.langfuse.trace_input", str(trace_input)[:500])
        if trace_output is not None:
            span.set_attribute("waxell.langfuse.trace_output", str(trace_output)[:500])
        if user_id:
            span.set_attribute("waxell.langfuse.user_id", str(user_id)[:100])
        if session_id:
            span.set_attribute("waxell.langfuse.session_id", str(session_id)[:100])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_langfuse_trace(trace_name, trace_input, trace_output, trace_metadata)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _generation_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Langfuse.generation()`` -- LLM generation tracking."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    gen_name = kwargs.get("name", "") or ""
    model = kwargs.get("model", "") or ""
    gen_input = kwargs.get("input", None)
    gen_output = kwargs.get("output", None)
    usage = kwargs.get("usage", None)
    model_parameters = kwargs.get("model_parameters", {})

    # Extract token counts from usage
    tokens_in = 0
    tokens_out = 0
    total_tokens = 0
    try:
        if usage is not None:
            if isinstance(usage, dict):
                tokens_in = usage.get("input", 0) or usage.get("prompt_tokens", 0) or 0
                tokens_out = usage.get("output", 0) or usage.get("completion_tokens", 0) or 0
                total_tokens = usage.get("total", 0) or usage.get("total_tokens", 0) or 0
            else:
                tokens_in = getattr(usage, "input", 0) or getattr(usage, "prompt_tokens", 0) or 0
                tokens_out = getattr(usage, "output", 0) or getattr(usage, "completion_tokens", 0) or 0
                total_tokens = getattr(usage, "total", 0) or getattr(usage, "total_tokens", 0) or 0
    except Exception:
        pass

    if total_tokens == 0:
        total_tokens = tokens_in + tokens_out

    try:
        span = start_llm_span(
            model=model or "langfuse-generation",
            provider_name="langfuse",
            tokens_in=tokens_in,
            tokens_out=tokens_out,
        )
        span.set_attribute("waxell.langfuse.operation", "generation")
        if gen_name:
            span.set_attribute("waxell.langfuse.generation_name", str(gen_name)[:200])
        if gen_input is not None:
            span.set_attribute("waxell.langfuse.generation_input", str(gen_input)[:500])
        if gen_output is not None:
            span.set_attribute("waxell.langfuse.generation_output", str(gen_output)[:500])
        if model:
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
        span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
        span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
        span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, total_tokens)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_langfuse_generation(gen_name, model, tokens_in, tokens_out, gen_input, gen_output)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _span_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Langfuse.span()`` -- span/step tracking."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    span_name = kwargs.get("name", "") or ""
    span_input = kwargs.get("input", None)
    span_output = kwargs.get("output", None)

    try:
        waxell_span = start_step_span(
            step_name=f"langfuse.span:{span_name}" if span_name else "langfuse.span"
        )
        waxell_span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "langfuse")
        waxell_span.set_attribute("waxell.langfuse.operation", "span")
        if span_name:
            waxell_span.set_attribute("waxell.langfuse.span_name", str(span_name)[:200])
        if span_input is not None:
            waxell_span.set_attribute("waxell.langfuse.span_input", str(span_input)[:500])
        if span_output is not None:
            waxell_span.set_attribute("waxell.langfuse.span_output", str(span_output)[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(waxell_span, exc)
        raise
    else:
        return result
    finally:
        waxell_span.end()


def _score_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Langfuse.score()`` -- scoring/evaluation."""
    try:
        from ..tracing.spans import start_guardrail_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    score_name = kwargs.get("name", "") or ""
    score_value = kwargs.get("value", None)
    trace_id = kwargs.get("trace_id", "")
    observation_id = kwargs.get("observation_id", "")
    comment = kwargs.get("comment", "")

    try:
        span = start_guardrail_span(
            guardrail_name=f"langfuse.score:{score_name}" if score_name else "langfuse.score",
            framework="langfuse",
        )
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "langfuse")
        span.set_attribute("waxell.langfuse.operation", "score")
        if score_name:
            span.set_attribute(WaxellAttributes.EVAL_METRIC_NAME, str(score_name)[:200])
        if score_value is not None:
            try:
                span.set_attribute(WaxellAttributes.EVAL_SCORE, float(score_value))
            except (ValueError, TypeError):
                span.set_attribute("waxell.langfuse.score_value", str(score_value)[:200])
        if trace_id:
            span.set_attribute("waxell.langfuse.trace_id", str(trace_id)[:100])
        if comment:
            span.set_attribute(WaxellAttributes.EVAL_REASON, str(comment)[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_langfuse_score(score_name, score_value, trace_id, comment)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_langfuse_trace(name, trace_input, trace_output, metadata) -> None:
    """Record a Langfuse trace to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"trace:langfuse:{name}" if name else "trace:langfuse",
            output={
                "framework": "langfuse",
                "trace_name": str(name)[:200] if name else "",
                "input_preview": str(trace_input)[:500] if trace_input else "",
                "output_preview": str(trace_output)[:500] if trace_output else "",
            },
        )


def _record_http_langfuse_generation(
    name: str, model: str, tokens_in: int, tokens_out: int,
    gen_input, gen_output
) -> None:
    """Record a Langfuse generation to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model or "langfuse-generation",
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,
        "task": f"langfuse.generation:{name}" if name else "langfuse.generation",
        "prompt_preview": str(gen_input)[:500] if gen_input else "",
        "response_preview": str(gen_output)[:500] if gen_output else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_langfuse_score(name: str, value, trace_id: str, comment: str) -> None:
    """Record a Langfuse score to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"eval:langfuse.score:{name}" if name else "eval:langfuse.score",
            output={
                "framework": "langfuse",
                "score_name": str(name)[:200] if name else "",
                "score_value": float(value) if value is not None else None,
                "trace_id": str(trace_id)[:100] if trace_id else "",
                "comment": str(comment)[:500] if comment else "",
            },
        )


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
