"""Mem0 auto-instrumentor for waxell-observe.

Monkey-patches the Mem0 Memory class methods to emit retrieval spans
(for search) and tool spans (for add/get_all operations).

Patched methods:
  - ``mem0.Memory.add``       (tool span -- memory write)
  - ``mem0.Memory.search``    (retrieval span -- memory search)
  - ``mem0.Memory.get_all``   (tool span -- memory read)
  - ``mem0.AsyncMemory.add``       (async tool span, if available)
  - ``mem0.AsyncMemory.search``    (async retrieval span, if available)
  - ``mem0.AsyncMemory.get_all``   (async tool span, if available)

All wrapper code is wrapped in try/except -- never breaks the user's Mem0 calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class Mem0Instrumentor(BaseInstrumentor):
    """Instrumentor for the Mem0 Python SDK (``mem0ai`` package).

    Patches ``Memory.add`` and ``Memory.get_all`` for tool spans,
    and ``Memory.search`` for retrieval spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import mem0  # noqa: F401
        except ImportError:
            logger.debug("mem0 package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Mem0 instrumentation")
            return False

        patched_any = False

        # --- Memory.add (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "mem0",
                "Memory.add",
                _sync_add_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch mem0 Memory.add: %s", exc)

        # --- Memory.search (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "mem0",
                "Memory.search",
                _sync_search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch mem0 Memory.search: %s", exc)

        # --- Memory.get_all (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "mem0",
                "Memory.get_all",
                _sync_get_all_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch mem0 Memory.get_all: %s", exc)

        # --- AsyncMemory (optional, may not exist) ---
        try:
            wrapt.wrap_function_wrapper(
                "mem0",
                "AsyncMemory.add",
                _async_add_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch mem0 AsyncMemory.add: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "mem0",
                "AsyncMemory.search",
                _async_search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch mem0 AsyncMemory.search: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "mem0",
                "AsyncMemory.get_all",
                _async_get_all_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch mem0 AsyncMemory.get_all: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any mem0 Memory methods")
            return False

        self._instrumented = True
        logger.debug("Mem0 instrumented (Memory.add, Memory.search, Memory.get_all)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import mem0

            # Restore sync Memory methods
            memory_cls = getattr(mem0, "Memory", None)
            if memory_cls is not None:
                for method_name in ("add", "search", "get_all"):
                    method = getattr(memory_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(memory_cls, method_name, method.__wrapped__)  # type: ignore[attr-defined]

            # Restore async AsyncMemory methods
            async_cls = getattr(mem0, "AsyncMemory", None)
            if async_cls is not None:
                for method_name in ("add", "search", "get_all"):
                    method = getattr(async_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(async_cls, method_name, method.__wrapped__)  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Mem0 uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_data(args, kwargs) -> str:
    """Extract the data/message string from add() args."""
    data = args[0] if args else kwargs.get("data", kwargs.get("messages", ""))
    if data is None:
        return ""
    return str(data)[:200]


def _extract_query(args, kwargs) -> str:
    """Extract the query string from search() args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _extract_user_id(kwargs) -> str:
    """Extract user_id from kwargs."""
    user_id = kwargs.get("user_id", "")
    return str(user_id) if user_id else ""


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_add_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Memory.add (store a memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="mem0.add", tool_type="memory")
    except Exception:
        return wrapped(*args, **kwargs)

    data_preview = _extract_data(args, kwargs)
    user_id = _extract_user_id(kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.operation", "add")
            if user_id:
                span.set_attribute("waxell.memory.user_id", user_id)
            if data_preview:
                span.set_attribute("waxell.memory.data_preview", data_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set mem0 add span attributes: %s", attr_exc)

        try:
            _record_mem0_operation(
                operation="add",
                user_id=user_id,
                data_preview=data_preview,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Memory.search (search memories)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query = _extract_query(args, kwargs)
    user_id = _extract_user_id(kwargs)

    try:
        span = start_retrieval_span(query=query[:500], source="mem0")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = len(response) if response is not None else 0
            span.set_attribute("waxell.retrieval.results_count", results_count)
            if user_id:
                span.set_attribute("waxell.memory.user_id", user_id)

            # Extract top score if available
            if response and isinstance(response, list) and len(response) > 0:
                first = response[0]
                if isinstance(first, dict) and "score" in first:
                    span.set_attribute("waxell.retrieval.top_score", float(first["score"]))
        except Exception as attr_exc:
            logger.debug("Failed to set mem0 search span attributes: %s", attr_exc)

        try:
            _record_mem0_retrieval(
                query=query,
                user_id=user_id,
                results_count=results_count if 'results_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_get_all_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Memory.get_all (list all memories)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    user_id = _extract_user_id(kwargs)

    try:
        span = start_tool_span(tool_name="mem0.get_all", tool_type="memory")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            memory_count = len(response) if response is not None else 0
            span.set_attribute("waxell.memory.operation", "get_all")
            span.set_attribute("waxell.memory.count", memory_count)
            if user_id:
                span.set_attribute("waxell.memory.user_id", user_id)
        except Exception as attr_exc:
            logger.debug("Failed to set mem0 get_all span attributes: %s", attr_exc)

        try:
            _record_mem0_operation(
                operation="get_all",
                user_id=user_id,
                memory_count=memory_count if 'memory_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def _async_add_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for AsyncMemory.add (store a memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="mem0.add", tool_type="memory")
    except Exception:
        return await wrapped(*args, **kwargs)

    data_preview = _extract_data(args, kwargs)
    user_id = _extract_user_id(kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.operation", "add")
            if user_id:
                span.set_attribute("waxell.memory.user_id", user_id)
            if data_preview:
                span.set_attribute("waxell.memory.data_preview", data_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set mem0 async add span attributes: %s", attr_exc)

        try:
            _record_mem0_operation(
                operation="add",
                user_id=user_id,
                data_preview=data_preview,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for AsyncMemory.search (search memories)."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query = _extract_query(args, kwargs)
    user_id = _extract_user_id(kwargs)

    try:
        span = start_retrieval_span(query=query[:500], source="mem0")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = len(response) if response is not None else 0
            span.set_attribute("waxell.retrieval.results_count", results_count)
            if user_id:
                span.set_attribute("waxell.memory.user_id", user_id)

            if response and isinstance(response, list) and len(response) > 0:
                first = response[0]
                if isinstance(first, dict) and "score" in first:
                    span.set_attribute("waxell.retrieval.top_score", float(first["score"]))
        except Exception as attr_exc:
            logger.debug("Failed to set mem0 async search span attributes: %s", attr_exc)

        try:
            _record_mem0_retrieval(
                query=query,
                user_id=user_id,
                results_count=results_count if 'results_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_get_all_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for AsyncMemory.get_all (list all memories)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    user_id = _extract_user_id(kwargs)

    try:
        span = start_tool_span(tool_name="mem0.get_all", tool_type="memory")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            memory_count = len(response) if response is not None else 0
            span.set_attribute("waxell.memory.operation", "get_all")
            span.set_attribute("waxell.memory.count", memory_count)
            if user_id:
                span.set_attribute("waxell.memory.user_id", user_id)
        except Exception as attr_exc:
            logger.debug("Failed to set mem0 async get_all span attributes: %s", attr_exc)

        try:
            _record_mem0_operation(
                operation="get_all",
                user_id=user_id,
                memory_count=memory_count if 'memory_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_mem0_retrieval(
    query: str,
    user_id: str,
    results_count: int = 0,
) -> None:
    """Record a Mem0 search operation to the context path.

    Mem0 searches are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="mem0",
            results_count=results_count,
        )


def _record_mem0_operation(
    operation: str,
    user_id: str,
    data_preview: str = "",
    memory_count: int = 0,
) -> None:
    """Record a Mem0 write/read operation to the context path.

    Operations are recorded as tool calls within an active WaxellContext.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"mem0.{operation}",
            input={"user_id": user_id, "memory_count": memory_count},
            tool_type="memory",
        )
