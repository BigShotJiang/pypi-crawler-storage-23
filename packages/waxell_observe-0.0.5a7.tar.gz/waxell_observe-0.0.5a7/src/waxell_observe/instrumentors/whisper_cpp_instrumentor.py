"""Whisper.cpp auto-instrumentor for waxell-observe.

Monkey-patches Whisper.cpp Python binding methods to emit OTel step spans
for local speech-to-text transcription:
  - ``pywhispercpp.Model.transcribe``  -- pywhispercpp binding
  - ``whispercpp.Whisper.transcribe``  -- whispercpp binding

Multiple Python bindings exist for whisper.cpp. This instrumentor attempts
to patch both ``pywhispercpp`` and ``whispercpp`` packages; whichever is
installed will be instrumented.

Whisper.cpp responses are typically lists of segments:
  pywhispercpp:
    - Returns list of ``Segment`` objects with ``.text``, ``.t0``, ``.t1``
    - Model name determined by model file path

  whispercpp:
    - Returns transcription text or segment list
    - Model loaded from file path (tiny/base/small/medium/large variants)

Cost is always 0.0 for local inference.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class WhisperCppInstrumentor(BaseInstrumentor):
    """Instrumentor for Whisper.cpp Python bindings.

    Patches ``pywhispercpp.Model.transcribe`` and/or
    ``whispercpp.Whisper.transcribe``, depending on which package
    is installed.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Whisper.cpp instrumentation")
            return False

        patched = False

        # Try pywhispercpp
        try:
            import pywhispercpp  # noqa: F401

            wrapt.wrap_function_wrapper(
                "pywhispercpp.model",
                "Model.transcribe",
                _pywhispercpp_transcribe_wrapper,
            )
            patched = True
            logger.debug("pywhispercpp Model.transcribe patched")
        except ImportError:
            logger.debug("pywhispercpp package not installed -- skipping")
        except Exception as exc:
            logger.debug("Could not patch pywhispercpp Model.transcribe: %s", exc)

        # Try whispercpp
        try:
            import whispercpp  # noqa: F401

            wrapt.wrap_function_wrapper(
                "whispercpp",
                "Whisper.transcribe",
                _whispercpp_transcribe_wrapper,
            )
            patched = True
            logger.debug("whispercpp Whisper.transcribe patched")
        except ImportError:
            logger.debug("whispercpp package not installed -- skipping")
        except Exception as exc:
            logger.debug("Could not patch whispercpp Whisper.transcribe: %s", exc)

        if not patched:
            logger.debug(
                "Neither pywhispercpp nor whispercpp installed -- skipping Whisper.cpp instrumentation"
            )
            return False

        self._instrumented = True
        logger.debug("Whisper.cpp instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Uninstrument pywhispercpp
        try:
            from pywhispercpp import model as pywcpp_model

            method = getattr(pywcpp_model.Model, "transcribe", None)
            if method is not None and hasattr(method, "__wrapped__"):
                setattr(pywcpp_model.Model, "transcribe", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Uninstrument whispercpp
        try:
            import whispercpp

            method = getattr(whispercpp.Whisper, "transcribe", None)
            if method is not None and hasattr(method, "__wrapped__"):
                setattr(whispercpp.Whisper, "transcribe", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Whisper.cpp uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Whisper.cpp responses
# ---------------------------------------------------------------------------


def _infer_model_name(instance) -> str:
    """Infer the Whisper model size name from the instance or model path.

    Looks for common model size indicators: tiny, base, small, medium,
    large, large-v2, large-v3 in the model file path.
    """
    model_path = ""

    # pywhispercpp stores model path in various attributes
    for attr in ("model_path", "_model_path", "model", "_model"):
        val = getattr(instance, attr, None)
        if val and isinstance(val, str):
            model_path = val
            break

    if not model_path:
        return "whisper-unknown"

    model_lower = model_path.lower()
    for size in ("large-v3", "large-v2", "large-v1", "large", "medium", "small", "base", "tiny"):
        if size in model_lower:
            return f"whisper-{size}"

    return "whisper-unknown"


def _extract_pywhispercpp_data(response, instance) -> dict:
    """Extract transcript data from a pywhispercpp response.

    pywhispercpp returns a list of Segment objects with .text, .t0, .t1
    """
    data = {
        "model": _infer_model_name(instance),
        "transcript": "",
        "segments_count": 0,
        "duration": 0.0,
        "language": "",
    }

    if response is None:
        return data

    try:
        if isinstance(response, list):
            data["segments_count"] = len(response)

            # Concatenate segment texts
            texts = []
            max_t1 = 0.0
            for seg in response:
                text = getattr(seg, "text", "")
                if isinstance(seg, dict):
                    text = seg.get("text", "")
                if text:
                    texts.append(str(text).strip())

                # Duration from last segment end time
                t1 = getattr(seg, "t1", 0)
                if isinstance(seg, dict):
                    t1 = seg.get("t1", 0)
                if isinstance(t1, (int, float)) and t1 > max_t1:
                    max_t1 = t1

            data["transcript"] = " ".join(texts)
            # t0/t1 are in centiseconds (10ms units) in pywhispercpp
            if max_t1 > 0:
                data["duration"] = max_t1 / 100.0

        elif isinstance(response, str):
            data["transcript"] = response
            data["segments_count"] = 1
    except Exception:
        pass

    # Try to get language from instance
    try:
        lang = getattr(instance, "language", "") or getattr(instance, "_language", "")
        if lang:
            data["language"] = str(lang)
    except Exception:
        pass

    return data


def _extract_whispercpp_data(response, instance) -> dict:
    """Extract transcript data from a whispercpp response."""
    data = {
        "model": _infer_model_name(instance),
        "transcript": "",
        "segments_count": 0,
        "duration": 0.0,
        "language": "",
    }

    if response is None:
        return data

    try:
        if isinstance(response, str):
            data["transcript"] = response
            data["segments_count"] = 1
        elif isinstance(response, list):
            data["segments_count"] = len(response)
            texts = []
            for seg in response:
                if isinstance(seg, str):
                    texts.append(seg.strip())
                elif isinstance(seg, dict):
                    texts.append(seg.get("text", "").strip())
                else:
                    text = getattr(seg, "text", "")
                    if text:
                        texts.append(str(text).strip())
            data["transcript"] = " ".join(texts)
        elif hasattr(response, "text"):
            data["transcript"] = str(getattr(response, "text", ""))
            data["segments_count"] = 1
    except Exception:
        pass

    return data


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _pywhispercpp_transcribe_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for pywhispercpp ``Model.transcribe``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract audio file from args
    audio_file = ""
    if args:
        audio_file = str(args[0]) if args[0] else ""
    audio_file = kwargs.get("media", kwargs.get("audio", audio_file))

    try:
        span = start_step_span(step_name="whisper_cpp.transcribe")
        if audio_file:
            span.set_attribute("waxell.whisper_cpp.audio_file", str(audio_file)[:200])
        span.set_attribute("waxell.whisper_cpp.binding", "pywhispercpp")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_pywhispercpp_data(response, instance)
            _set_transcribe_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set pywhispercpp span attributes: %s", attr_exc)

        try:
            _record_transcribe_call("whisper_cpp.transcribe", data, latency, str(audio_file)[:200])
        except Exception:
            pass

        return response
    finally:
        span.end()


def _whispercpp_transcribe_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for whispercpp ``Whisper.transcribe``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract audio file from args
    audio_file = ""
    if args:
        audio_file = str(args[0]) if args[0] else ""
    audio_file = kwargs.get("audio", kwargs.get("file", audio_file))

    try:
        span = start_step_span(step_name="whisper_cpp.transcribe")
        if audio_file:
            span.set_attribute("waxell.whisper_cpp.audio_file", str(audio_file)[:200])
        span.set_attribute("waxell.whisper_cpp.binding", "whispercpp")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_whispercpp_data(response, instance)
            _set_transcribe_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set whispercpp span attributes: %s", attr_exc)

        try:
            _record_transcribe_call("whisper_cpp.transcribe", data, latency, str(audio_file)[:200])
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_transcribe_span_attributes(span, data: dict, latency: float) -> None:
    """Set OTel span attributes from extracted whisper.cpp data."""
    span.set_attribute("waxell.whisper_cpp.model", data["model"])
    if data["language"]:
        span.set_attribute("waxell.whisper_cpp.language", data["language"])
    if data["transcript"]:
        span.set_attribute("waxell.whisper_cpp.transcript_preview", data["transcript"][:500])
    span.set_attribute("waxell.whisper_cpp.segments_count", data["segments_count"])
    if data["duration"]:
        span.set_attribute("waxell.whisper_cpp.duration", data["duration"])
    span.set_attribute("waxell.whisper_cpp.latency_ms", round(latency * 1000, 2))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_transcribe_call(
    task: str, data: dict, latency: float, audio_file: str
) -> None:
    """Record a Whisper.cpp transcription call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": data.get("model", "whisper-unknown"),
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,  # Local inference is always free
        "task": task,
        "prompt_preview": audio_file if audio_file else f"[audio segments={data.get('segments_count', 0)}]",
        "response_preview": str(data.get("transcript", ""))[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
